# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# EFHC Operator Kernel Standard

Status: ACTIVE NORM.
Archive: `v171.64`.
Replaces: `EFHC_OPERATOR_KERNEL_FIRST_STANDARD.md`, `EFHC_OPERATOR_KERNEL_PATCH_STANDARD.md`, `EFHC_OPERATOR_KERNEL_PERMISSION_STANDARD.md`, `EFHC_OPERATOR_KERNEL_VALIDATION_STANDARD.md`.

## 1. Entry and role

`START_HERE.md` is the only startup order. `KERNEL.md` is the active detailed dispatch layer immediately after it. Kernel stores operational routing detail—keywords, task types, canonical anchors, patch/permission boundaries, proof gates and validation gates—without duplicating full CANON, SSOT, NORM, Healer history, cycles or reports.

Kernel must never be demoted to navigation-only.

## 2. Kernel-first routing

Before broad reading or editing:

```text
user request
→ task classifier
→ smallest safe task type
→ routes.yaml primary route
→ required reads and canonical anchors
→ allowed writes and restrictions
→ bounded context capsule
→ targeted validation
→ proof/report/archive boundary
```

Compound request handling: a compound request must resolve to a dedicated compound route or expose secondary task types. A precise route cannot be replaced by full-archive reading.

## 3. Machine-index and reading boundary

- `file_map.summary.json` is the short startup map.
- `file_map.json` is a machine-search index and is never a default full-read AI document.
- `HEALER_CAPSULE.md` is the short Healer entry.
- Full Healer Atlas/Casebook, all reports, all audits, all cycles, full frontend/backend/tests are route-only. Ordinary familiarization is limited to the latest two relevant report/audit/cycle entries per layer.
- Read exact routed source files fully before editing them.
- A receipt proves file access/hash, not semantic correctness by itself.


## 3A. AI operational memory

- `docs/AI/` is the operational working brain of the AI, not a historical log.
- Temporary memory contains only unresolved or immediately actionable facts.
- User-approved decisions are promoted into CANON / SSOT / NORM and removed from temporary memory.
- Historical snapshots live under `docs/history/` and are not startup inputs.
- GitHub CI job timeout must remain within the user-approved 5–10 minute range; current canonical value is 10 minutes.

## 4. Patch plan

Before writing changes, hold a patch plan with:

1. primary and secondary task types;
2. configured routes;
3. active canonical anchors;
4. exact required-read files;
5. exact allowed-write files;
6. affected runtime/docs/tests;
7. restricted/manual-control files;
8. targeted validation;
9. proof/report/archive boundary.

Every changed file must answer which explicit requirement or confirmed regression it addresses. Proximity is not permission.

## 5. Conditional synchronization

- Runtime/CSS repair does not automatically create CANON/SSOT/Healer rules.
- CANON/SSOT/NORM changes occur only when product truth or mandatory procedure changes.
- Healer updates occur only for a confirmed incident/root cause with an independent guard.
- Cycle/report updates record work but cannot create product truth.
- Duplicate active control documents are consolidated into one canonical document; old active copies are removed or replaced by a compatibility pointer.

## 6. Permission modes

- `READ_ONLY`;
- `DRY_RUN`;
- `PATCH_PLANNED`;
- `APPROVED_WRITE`;
- `LOCAL_AUX_CHECK`;
- `DEVELOPMENT_BUILD`;
- `RELEASE_BUILD`;
- `BLOCKED`.

`routes.yaml` defines `required_read`, `allowed_write`, `restricted` and `validation`. A file outside `allowed_write` requires another exact route or direct user instruction.

## 7. High-risk and silent-change blocks

Require explicit scope, exact anchors and targeted guards for economy, wallet ownership, TonConnect, TonProof, transactions, withdraw, migrations, security and authentication.

Block silent changes to:

- `ci.yml` and `.github/workflows/*`;
- CANON/SSOT deletion or replacement;
- migrations outside an explicit migration route;
- FAQ/product/economy semantics outside their routes;
- wallet/TonConnect/TonProof/money-flow outside high-risk routes;
- the six canonical bottom buttons outside direct user instruction.

## 8. Validation vocabulary

- `VERIFIED` — command/evidence actually checked;
- `FOUND_NOT_VERIFIED` — artifact found but behavior not executed;
- `UNKNOWN` — insufficient evidence;
- `BLOCKED` — exact technical/external boundary recorded;
- `LOCAL_AUX_CHECK_ONLY` — local result, not GitHub CI.

Tests must prove behavior, not only file existence. In particular:

- YAML edits change resolver behavior without Python route edits;
- EFHC-specific and compound queries classify correctly;
- unknown fallback contains Kernel and route hints;
- startup does not full-read machine indexes or Healer history;
- frontend proof uses the real app and `page.goto()`;
- active Kernel remains a full dispatch layer.

## 9. Evidence and completion

Manual HTML, `page.set_content`, synthetic/mock pages and inherited PNG are not application proof. Local checks are not GitHub CI. Live Telegram, real TonConnect signature, real TonProof and real transaction claims require external exact-HEAD evidence.

A changed pass ends with:

- bounded targeted verification;
- refreshed file maps;
- clean sequential development archive;
- SHA-256, size, file count and ZIP integrity;
- exact remaining proof boundary.

Missing live proof blocks release claims, not honest development delivery.

## 10. Anti-demotion and anti-duplication lock

Forbidden:

1. demoting Kernel to navigation-only;
2. removing EFHC keywords, anchors or route map;
3. treating `routes.yaml` as dead config;
4. restoring full-archive startup reading;
5. keeping multiple active documents with the same rule and authority;
6. placing cycle reports or transient status documents in SSOT/NORM as active truth;
7. claiming release-ready or GitHub CI green without exact evidence.
