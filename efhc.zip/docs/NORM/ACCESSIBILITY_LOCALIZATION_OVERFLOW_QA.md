# Accessibility / Localization / Overflow QA

**Project:** EFHC Bot  
**Cycle:** 1494 — Accessibility / Localization / Overflow QA  
**Archive version:** v170.70  
**Status:** DONE locally  
**Mode:** UI accessibility / localization parity / overflow hardening / dashboard QA / docs / tests

## 1. Purpose

Cycle 1494 hardens the dashboard visual layer for real users on narrow Telegram Mini App and browser surfaces. The target is not a cosmetic redesign. The target is to prevent dashboard truth from becoming unreadable because of long numbers, long translations, status chips, filter rows, KPI values or compact mobile widths.

## 2. Scope

The cycle covers:

- admin dashboard shared UI kit accessibility markers;
- progress bars with explicit `role="progressbar"` and value metadata;
- status badges with explicit `role="status"`;
- KPI cards with safe `aria-label` text;
- dashboard surface overflow hardening for long text and numbers;
- mobile 430px layout hardening for dashboard panels, toolbars and action rows;
- localization cleanup for remaining `raw snapshot` placeholder values in Exchange/Profile dashboard labels;
- Russian labels on the real time-series filter controls.

## 3. What changed

### Shared admin dashboard UI kit

`frontend/src/components/admin/AdminDashboardUiKit.tsx` now exposes cycle-1494 accessibility/overflow markers on shared dashboard primitives:

- `AdminDashboardShell` has a region label;
- `AdminPanelStatus` and `AdminStatusBadge` use `role="status"`;
- `AdminKpiCard` has a derived `aria-label` from label/value;
- shared primitives carry `data-admin-accessibility-overflow-qa="1494"` markers.

### Progress system

`frontend/src/components/dashboard/ProgressSystem.tsx` now gives linear progress bars:

- `role="progressbar"`;
- `aria-valuemin="0"`;
- `aria-valuemax="100"`;
- `aria-valuenow` as the normalized percent;
- fallback label from the visible progress label.

### CSS overflow hardening

`frontend/src/styles/globals.css` now has a dedicated cycle-1494 hardening block:

- `min-width: 0` across dashboard nested content;
- `overflow-x: clip` on dashboard shells/panels/action tables/filter bars;
- `overflow-wrap: anywhere` and `hyphens: auto` for dashboard text;
- tabular numeric rendering for KPI values;
- mobile `max-width: 430px` grid fallback for toolbar/action rows.

### Localization cleanup

The remaining placeholder values like `Локализовано: raw snapshot` were removed from active locale JSON files for Exchange/Profile dashboard labels. English remains English; other languages now have localized equivalents for the snapshot label.

### Real time-series labels

`AdminObservabilityTimeseriesDashboardRuntime` now uses Russian visible filter labels:

- `Метрика`;
- `Шаг`;
- `Период`;
- `час` / `день`.

## 4. Safety boundaries

This cycle did not change:

- backend;
- OpenAPI;
- DB migrations;
- EFHC economy;
- money-flow;
- write-flow;
- idempotency;
- dependencies;
- lock files;
- CI/workflows.

## 5. Grafana and Sandbox policy

Grafana was used only as visual-pattern/reference layer for accessibility and dense dashboard layout discipline. Runtime code was not copied.

Песочница was used only as reference/navigation/prototype layer. Runtime code was not copied.

## 6. Acceptance criteria

- Shared dashboard primitives have explicit accessibility markers.
- Progress bars expose machine-readable accessibility values.
- Dashboard status badges expose status semantics.
- Long dashboard text and numbers are less likely to overflow mobile width.
- Locale placeholder strings for `raw snapshot` are cleaned from Exchange/Profile dashboard labels.
- No business logic or write endpoint changed.
