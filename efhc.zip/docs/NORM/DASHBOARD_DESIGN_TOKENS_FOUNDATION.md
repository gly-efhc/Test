
> Cycle 1465 note: Dashboard Toolbar Foundation consumes these tokens
> for toolbar surface, picker controls, refresh buttons and freshness
> badges. Active file: `frontend/src/components/dashboard/DashboardToolbar.tsx`.
> Cycle 1461 note: Admin Dashboard UI Kit Foundation is active in
> `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`.
> Additional Grafana element usage map is active in
> `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
> Runtime foundation extends
> `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
> Grafana and Песочница remain reference only.

# DASHBOARD DESIGN TOKENS FOUNDATION

Status: `ACTIVE_DASHBOARD_DESIGN_TOKENS_FOUNDATION`

Cycle: `1458`

Archive target: `v170.34`

## Purpose

This document fixes the EFHC-owned visual token layer for future
Dashboard Visual Direction cycles.

The goal is to make all future dashboard panels use the same visual
language before runtime dashboard components are expanded.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Dashboard kernel:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Grafana pattern map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Sandbox inventory:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime token file:

`frontend/src/styles/globals.css`

## Boundary

Grafana is visual-pattern reference only.

Песочница is reference, navigation and prototype layer only.

Runtime code, dependencies, lock files, CI files, backend logic,
wallet/payment logic and economics from Grafana or Песочница were not
copied.

This cycle adds EFHC-owned CSS variables and utility classes only.
It does not change EFHC economy, backend contracts, database schema,
CI, locks or money flow.

## Token families

### Surface tokens

- `--efhc-dash-bg`
- `--efhc-dash-surface`
- `--efhc-dash-panel`
- `--efhc-dash-panel-strong`

### Border tokens

- `--efhc-dash-border`
- `--efhc-dash-border-strong`

### Text tokens

- `--efhc-dash-text`
- `--efhc-dash-muted`
- `--efhc-dash-muted-2`

### Accent and semantic tokens

- `--efhc-dash-accent`
- `--efhc-dash-accent-strong`
- `--efhc-dash-success`
- `--efhc-dash-warning`
- `--efhc-dash-danger`
- `--efhc-dash-info`

### Geometry tokens

- `--efhc-dash-radius-sm`
- `--efhc-dash-radius-md`
- `--efhc-dash-radius-lg`
- `--efhc-dash-radius-xl`

### Spacing tokens

- `--efhc-dash-space-1`
- `--efhc-dash-space-2`
- `--efhc-dash-space-3`
- `--efhc-dash-space-4`
- `--efhc-dash-space-5`
- `--efhc-dash-space-6`

### Shadow and typography tokens

- `--efhc-dash-shadow-panel`
- `--efhc-dash-shadow-soft`
- `--efhc-dash-font-title`
- `--efhc-dash-font-value`

## Utility classes

The initial utility layer provides only primitive wrappers:

- `.efhc-dashboard-surface`
- `.efhc-dashboard-grid`
- `.efhc-dashboard-panel`
- `.efhc-dashboard-panel-strong`
- `.efhc-dashboard-panel-title`
- `.efhc-dashboard-panel-muted`
- `.efhc-dashboard-value`
- `.efhc-dashboard-status-success`
- `.efhc-dashboard-status-warning`
- `.efhc-dashboard-status-danger`
- `.efhc-dashboard-status-info`

These classes are not full dashboard components. They are visual
primitives for upcoming components such as `AdminPanelChrome`,
`SimPanelChrome`, `AdminDashboardGrid` and `SimDashboardGrid`.

## Light and dark mode

Dark mode remains the primary product visual mode.

Light mode receives matching dashboard tokens through
`html[data-theme="light"]` overrides.

Dashboard tokens must follow Telegram shell tokens where possible:

- dashboard text follows `--text`;
- dashboard muted text follows `--muted` and `--muted2`;
- dashboard accent follows EFHC gold;
- dashboard tokens are UI-only.

## Grafana pattern alignment

Grafana-inspired patterns mapped in cycle 1457 now have token support:

| Pattern | Token support |
|---|---|
| PanelChrome | panel, border, radius, shadow |
| DashboardGrid | spacing, responsive grid |
| Stat card | value font, title font, muted text |
| Status card | success, warning, danger, info |
| Inspector | panel-strong and border-strong |
| Freshness | muted and semantic tokens |

## Acceptance criteria

- Dashboard tokens exist in `frontend/src/styles/globals.css`.
- Tokens cover surface, border, text, accent, semantic states,
  radius, spacing, shadow and typography.
- Light mode has safe dashboard overrides.
- Utility classes use dashboard tokens instead of hardcoded visual
  values.
- No external Grafana or sandbox runtime code is copied.
- No economy, backend contract, DB, CI or lock-file change occurs.

## Forbidden

- Importing Grafana theme runtime.
- Copying Grafana CSS/SCSS files.
- Copying sandbox design systems as runtime truth.
- Adding heavy chart or UI dependencies.
- Changing money values, rates, idempotency or backend contracts.
- Using synthetic/demo numbers without explicit preview marking.

## Next cycle

Cycle `1459 — Dashboard Component Contract` must define component
props and required dashboard states: loading, empty, error, stale,
success, title, subtitle, source, updatedAt and actions.


## Cycle 1459 contract update

Dashboard design tokens are now paired with the component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Future components must combine:

- tokens for visual consistency;
- contract states for operational truth;
- source and freshness metadata for data honesty.

## Cycle 1460 consumer

`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx` is the
first simulation-side consumer of dashboard design tokens.

Its CSS classes are appended in `frontend/src/styles/globals.css` under
`Simulation Dashboard UI Kit Foundation`.
