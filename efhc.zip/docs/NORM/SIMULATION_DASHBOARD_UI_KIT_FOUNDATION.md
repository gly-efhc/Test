<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Cycle 1497 sync note

Cycle 1497 consolidated the Simulation UI Kit gap from dashboard audit. Added reusable wrappers: `SimPanelCard`, `SimPanelPortfolioSummary`, `SimRankCard`, `SimLeaderboardRow`, `SimRankTierLadder`, `SimCountdownBadge`, `SimLiveIndicator`, `SimValueDelta`, `SimBalanceTicker`, `SimLoadingCard`, `SimEmptyCard`, `SimErrorCard`, `SimSkeleton`.

# SIMULATION DASHBOARD UI KIT FOUNDATION

Status: `ACTIVE_SIMULATION_DASHBOARD_UI_KIT_FOUNDATION`

Cycle: `1460`

Archive target: `v170.36`

## Purpose

This document fixes the first EFHC-owned Simulation Dashboard UI Kit
foundation for user-facing dashboard work.

The kit is a lightweight runtime foundation for future Energy, Panels,
Ranks, Tasks, Referrals, Exchange and Web Profile dashboard cycles. It
uses dashboard design tokens and the dashboard component contract from
cycles 1458 and 1459.

## Active sources

- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`
- `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`
- `docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`
- `docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`
- `frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`
- `frontend/src/lib/dashboard/componentContract.ts`
- `frontend/src/styles/globals.css`

## Boundary

Grafana is visual-pattern reference only.

Песочница is reference, navigation and prototype layer only.

Runtime code, dependencies, lock files, CI files, backend logic,
wallet/payment logic and economics from Grafana or Песочница were not
copied.

The cycle does not change EFHC economics, backend contracts, database
schema, CI/workflows, lock files, money routes or idempotency guards.

## Added foundation components

- `SimDashboardShell`
- `SimDashboardSection`
- `SimDashboardGrid`
- `SimHeroEnergyCard`
- `SimStatCard`
- `SimSummaryCard`
- `SimProgressBar`
- `SimStatusPill`

## Component rules

Every simulation dashboard component must be:

1. mobile-first;
2. dark-theme safe;
3. token-based;
4. compatible with `DashboardComponentContract`;
5. explicit about source and state where data is live;
6. free of raw `global_id`, raw enum/reason and debug JSON;
7. visually clear without changing business truth.

## Visual states

The UI Kit must support the mandatory dashboard states from the active
contract:

- `loading`
- `empty`
- `error`
- `stale`
- `success`

Cycle 1460 creates visual primitives. Later cycles must wire each runtime
screen to real data and real states.

## Truth model

Allowed data kinds are inherited from the dashboard contract:

- `raw`
- `derived`
- `synthetic_preview`
- `real_timeseries`

Synthetic preview data is allowed only in clearly marked sandbox or
preview contexts. It must never be presented as runtime truth.

## CSS layer

Simulation UI classes are added to `frontend/src/styles/globals.css` and
must use the dashboard token families from cycle 1458:

- `--efhc-dash-surface`
- `--efhc-dash-panel`
- `--efhc-dash-border`
- `--efhc-dash-accent`
- `--efhc-dash-success`
- `--efhc-dash-warning`
- `--efhc-dash-danger`
- `--efhc-dash-info`

## Existing dashboards preservation

Cycle 1460 does not delete or replace old dashboards. Existing admin
dashboards and Grafana JSON dashboards remain preserved:

- `frontend/src/components/admin/AdminDashboardUiKit.tsx`
- `frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`
- `frontend/src/components/admin/AdminReportsVisualDashboardPanel.tsx`
- `ops/monitoring/grafana/dashboards/backend.json`
- `ops/monitoring/grafana/dashboards/scheduler.json`
- `ops/monitoring/grafana/dashboards/ton_watcher.json`

## Next cycle

`1461 — Admin Dashboard UI Kit Foundation`.
