# FRONTEND GITHUB WORKING ARCHITECTURE — OWNER CANON

Direct OWNER decisions: 2026-10-09.

## Roles
- **EFHC CODE** — bounded governance/orchestration, protected-scope control, reports/release discipline and repository-verification routing.
- **GitHub** — repository source/history/CI authority beneath OWNER/SSOT/CANON/NORM; synchronized in bounded batches, never used as an interactive filesystem.
- **Linear** — primary work-state metadata: cycle/scope/blockers/approvals/result/next step; no source or CI-log duplication.
- **Railway** — runtime/deploy control plane: services/environments/deployments/logs/metrics/configuration; explicit OWNER runtime scope required for mutations.
- **PostHog** — product analytics/telemetry, experiments/flags/error/session evidence when the task requires product behavior data.
- **Context7** — current library/framework/SDK/API/CLI documentation for technology-specific implementation decisions.
- **Notion** — durable long-form knowledge/spec/architecture documentation only when materially useful; not a source/backlog authority.
- **DigitalOcean** — persistent remote SSH engineering workspace when local execution is insufficient; not source or production deploy authority.
- **Atlassian** — reserve-only enterprise Jira/Confluence/Bitbucket/Loom/internal knowledge branch, activated only by OWNER; no parallel Jira implementation backlog while Linear is primary.
- Physical `FRONTEND_vNNN.zip` + matching HTML/Shop remain immutable release/provenance artifacts delivered to OWNER.
- Canonical source flow: local workspace → one bounded GitHub sync → GitHub Actions/CI → minimal exact-HEAD evidence → same local workspace. External evidence branches return to EFHC CODE/current report; no plugin can override OWNER or project authority.
- Any plugin outside these nine requires explicit OWNER approval before search/connection/use as a working dependency.

## Cycle numbering
- `0416–0425` = **NUMBERING GAP / NOT EXECUTED / NO RELEASE / NO REPORT** after direct OWNER reassignment of the next executable number to 0426.
- Recovery remap is factual and 1:1: former planned `0416→0426`, `0417→0427`, `0418→0428`, `0419→0429`.
- Historical completed cycle/report/release identities are immutable and are never backfilled into the numbering gap.
- Cycle0429 remains historical `OWNER-SPLIT / NOT CLOSED`; no retroactive report/release is created.
- OWNER-approved reports consolidation occupies `0430–0433`; Cycles0430–0432 are DONE, Cycle0433 remains OWNER HOLD / final anti-loss parity scope.
- Cycle0434 is OWNER-authorized process/tooling work: dynamic report navigation + approved plugin control plane. `0435–0439` remain OWNER RESERVED.
- The remaining Cycle0429 convergence/reproducibility scope is OWNER-assigned to ten future cycles `0440–0449`.
- `0450` remains OWNER RESERVED.
- Theme04 systemic-owner consolidation is assigned to `0451`; all subsequent Global Theme work is sequenced in the OWNER-controlled `0452+` theme lane, with exact bounded scopes assigned only by direct OWNER decision.

## CI levels
FAST: syntax/lint/typecheck/targeted tests.
FULL: full tests/build/integration/security/integrity as applicable.
RELEASE: FULL + version/archive/SHA-256/release artifact.
Use `paths`/`paths-ignore` so unrelated changes do not trigger expensive suites. `workflow_dispatch` is supplemental.

## Chat evidence algorithm
`commit SHA -> combined CI status -> PASS close / FAIL identify failed job -> failed step -> minimal log slice -> related files -> bounded fix -> new commit -> exact-SHA CI`.
A task is never DONE merely because a commit exists. If an inherited baseline defect prevents an unrelated current check, classify it as `BASELINE/OUT_OF_SCOPE`; do not repeat the same Kernel/check without changed input.

## Import staging and retained development lines
## Import staging
`_import/` — OWNER-PROTECTED постоянная transfer boundary. Она обязана существовать в canonical local workspace, GitHub repository и full-repository physical release и не удаляется автоматически. Основной transport payload — полный immutable `FRONTEND_vNNN.zip`, который OWNER вручную загружает прямо в `_import/`. `repository-import-sync` валидирует ZIP и зеркально приводит repository tree к содержимому полного physical release. После успешного sync transport ZIP удаляется из repository, но `_import/README.md` и сама папка сохраняются. Patch-only ZIP не является основным transport contract. Payload не является runtime/source authority: после materialization canonical source читается из обычных project paths. Nested ZIP разрешён только внутри `_import/`.

Recovery source precedence for текущего локального контура:
1. direct OWNER instruction;
2. current physical `FRONTEND_vNNN.zip` + local workspace;
3. current SSOT/CANON/NORM;
4. отдельно предоставленный OWNER recovery-source только на время конкретной recovery-задачи.

Root `routes/` and `tables/` are not production deploy components or independent runtime authorities. Cycle0426 proved canonical route/model/migration materialization; Cycle0428 completed final consumer/parity proof and removed those projections under the existing categorical OWNER approval. Current route authority is canonical backend source plus `backend/openapi/openapi.json`; current table authority is canonical backend models plus release migration source. If machine inventories are needed later, generate them from canonical source rather than restoring a second root copy.

`demo/` is a permanent evolving review/simulation surface. Full active development/CI tests and generated current machine registries remain in GitHub even when the production builder does not package them. `contracts/` are classified individually by real consumer/role.

## Reports architecture handoff
Cycle0429 does not restructure historical reports. Cycles0430–0432 already established the canonical `reports/` architecture: number-first `numbered/cycles/rules`, one continuous report numbering sequence and one authoritative `FRONTEND_REPORT_MANIFEST.json`; transitional `PENDING_0432`/parallel CSV authority is removed. Cycle0434 adds the dynamic navigation law: report drift is repaired during active work; strict sequence remains a closure gate and must not recreate a second report system.

## Authority
Direct OWNER instruction -> current physical/project SSOT/CANON/NORM -> proven newer GitHub source -> physical release provenance -> separate imported development-line provenance -> exact-head CI evidence -> Linear work state -> chat memory.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

