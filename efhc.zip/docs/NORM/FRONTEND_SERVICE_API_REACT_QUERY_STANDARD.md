# Frontend Service API React Query Standard

## Rule

Public UI must not call backend API paths directly. Server state enters public
and admin UI through this chain:

```text
DTO or validator
→ service function
→ React Query hook
→ view component
```

## Allowed access

- `frontend/src/lib/api/` may define API clients and generated seams.
- `frontend/src/services/` may call `apiRequest` and validate/normalize data.
- `frontend/src/queries/` may call services and own React Query keys.
- UI components may render props and call hook callbacks only.

## Forbidden in public UI

`/api/`, `apiRequest`, `fetch`, `axios`, `XMLHttpRequest`, `EventSource` and
`WebSocket` are forbidden in pages, features, views and components unless a
short-lived allowlist entry exists.

## Relationship to copy firewall

The service/query gate blocks the architecture path that usually returns raw
technical text. The public-copy firewall still blocks visible technical words.
Both gates must remain enabled.
