# RELEASE_ARCHIVE_HYGIENE_NORM

Status: NORM
Anchor: release ZIP / archive packaging / sandbox boundary

## Purpose

This document fixes the release-archive hygiene rules after the repeated
archive packaging incident where a project ZIP was produced without normal
compression and became much larger than expected.

## Canonical release ZIP rules

Every EFHC Bot release ZIP must be:

- flat at the archive root;
- compressed with normal ZIP deflate;
- free of `__pycache__`, `*.pyc`, `.pytest_cache`, `.ruff_cache`,
  `.mypy_cache` and transient logs;
- free of embedded sandbox/reference ZIP archives unless the user explicitly
  asks to include them;
- free of wrapper folders that change the expected project root layout.

## Compression guard

A sudden jump from the expected compressed size to a size close to the raw
uncompressed payload must be treated as an archive hygiene failure.

Required check before delivery:

- total compressed payload is materially smaller than total uncompressed
  payload for normal source archives;
- `ZIP_STORED` entries are allowed only for files that are naturally
  incompressible or where the packaging tool has a valid reason;
- the final report must mention archive integrity when archive size was a
  recent risk.

## Sandbox boundary

Sandbox/reference archives may be read and used for manual study. They must not
be embedded in the release ZIP and must not become active runtime source unless
a separate integration cycle explicitly adapts and verifies them.

## Reporting

Every release response must state the exact ZIP name. When archive hygiene was
part of the cycle, the report must also state:

- archive size;
- whether deflate compression was used;
- whether nested ZIPs or transient junk were found;
- whether the archive integrity test passed.
