<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Tasks earning module canon

Tasks is a canonical bottom menu page. It remains visible as Tasks.
Inside the page, tasks must be compact cards with clear reward, status,
action, and a human explanation when the button cannot be used.
Technical wording must not be shown to normal users.

## v168_23 language and payment additions

Profile language selector canon:

- show one button with the active language;
- tap opens a dropdown list of supported bot languages;
- choosing a language updates `settings.lang`;
- runtime UI text follows `loadDict(lang)`;
- bottom navigation stays English by EFHC canon.

Browser-Shop payment canon:

- public button label is `Оплатить` or localized equivalent;
- the returned `tonconnect_tx` is internal frontend payload only;
- public UI never renders raw transaction, wallet, memo or copy blocks;
- frontend must pass the normalized transaction to TonConnect wallet
  flow.

# VISUAL FRONTEND PUBLIC UI NORM

Status: NORM for public EFHC frontend visual roads.
Introduced during v168_17 planning pass after visual audit v002.

## Purpose

This NORM separates user-facing EFHC roads from internal diagnostic
roads. Public frontend must look like a clean Telegram-style energy
game and financial cabinet, not like an operator console.

## Public roads

- Direct Deposit: plus button in GlobalHeader, clean wallet-open
  direct deposit road with user-entered amount and memo-based
  reconciliation.
- HUB: minimal bridge with exactly two actions: Popolnit EFHC and EFHC
  VIP NFT.
- Storefront: separate Vitrina EFHC browser page with product cards
  from admin/shop and Pay opening TON wallet immediately.
- Profile: canonical public place for wallet state, balance details and
  Istoriya operatsiy.

## Forbidden public words and objects

- endpoint, API path, debug, contour, truth-layer, execution path,
  return path, canonical center.
- intent and watcher as raw technical words. Public replacements are
  active payment, active request, payment is checking, top-up done and
  payment error.
- wallet address, memo, copy wallet and copy memo on public storefront
  or Direct Deposit screens.
- SKU, code, item_type, status, internal category, intent id, order id
  on public storefront cards.

## Protected areas

- Bottom menu remains Energy, Panels, Exchange, Tasks, Referrals and
  Ranks.
- HUB title may remain English.
- VIP URL remains https://getgems.io/efhc-nft.
- Admin/shop remains the card source and may show admin fields.
- Admin/diagnostics is the single operator entry for technical visual
  and payment diagnostics.
- The visual cycle must not change the bank ledger or 1 kWh = 1 EFHC.

## Profile language rule

- Profile must contain a clear language selector.
- Language selection must change runtime user-facing UI labels, not only
  long descriptions or FAQ text.
- Settings persistence must not overwrite a previously selected
  language with defaults before stored settings load.
- Bottom menu labels remain protected in English even when the rest of
  the UI follows the selected language.
- This visual-label exception does not reduce the 13-language bot canon.
- Bottom-menu `aria-label` and `title` follow the selected language so the
  navigation remains accessible in every supported locale.

## Completion rule

A visual repair is not complete until the related code path is changed
and a guard or test proves the public UI no longer exposes the blocked
technical words, layout, fields or manual payment blocks.

## v168_19 Direct Deposit public UI status

Direct Deposit was repaired in code for work pass:

- GlobalHeader direct deposit action is the canonical `+`.
- Public DepositModal is now a short wallet-open modal.
- Shop launcher truth, active intent, watcher, wallet/memo/copy and
  package cards are absent from the public modal.
- Backend has `POST /deposit/direct-open` for free-amount wallet open.

This is not full visual release readiness. HUB and Browser-Shop still
need their public cleanup cycles, and browser screenshot proof was not
run in this pass.

## v168_20 HUB public boundary

Public HUB rule is now code-backed:

- the public `/hub` page must render exactly two user actions;
- the first action opens the EFHC storefront handoff;
- the second action opens `https://getgems.io/efhc-nft`;
- the public page must not render wallet state, active payment state,
  readiness, truth-layer, contour, endpoint labels, execution path,
  return path, FAQ/help blocks or diagnostic facts;
- technical HUB diagnostics belong to `/admin/diagnostics`.

Guard:
`tests/architecture/test_hub_public_cleanup_guard.py`.

## Browser-Shop layout canon after work pass

`/browser-shop` is an external storefront surface.  It must not be
rendered through the common Mini App `Layout`, `GlobalHeader` or bottom
navigation.  It uses dedicated `ShopLayout`.

The storefront top zone contains avatar, EFHC balance and Profile link.
Further storefront content must continue to be cleaned in later cycles
so public users do not see admin fields or payment diagnostics.

## Browser-Shop public content after work pass

The public storefront content is now code-backed as a clean card grid.
It must show only public product information and human payment states.

Allowed public product-card fields:

- title;
- description;
- price;
- Pay action;
- generic EFHC badge.

Forbidden on public storefront cards and payment blocks:

- SKU, code, item type and internal status;
- endpoint labels and route paths;
- wallet address, memo and copy buttons;
- payment-chain facts and operator lifecycle diagnostics;
- raw transaction payloads.

Browser-Shop technical diagnostics belong to `/admin/diagnostics`.

Guard:
`tests/architecture/`
`test_browser_shop_public_cleanup_guard.py`.


## v168_24 payment status and compression additions

Browser-Shop payment status rule:

- after Pay creates an intent and opens the TON wallet, the page keeps
  the active intent id;
- pending/checking states poll `/shopfront/intent-status`;
- public UI shows only human payment states;
- raw intent id, wallet, memo, endpoint labels and `tonconnect_tx` stay
  hidden from the public storefront.

Frontend compression rule:

- EFHC may adopt a Dragon-like compact interaction model;
- do not copy Dragon branding or external assets;
- keep EFHC routes and functions unless a separate migration approves
  moving them;
- first-level UI should become smaller, with secondary functions opened
  through cards, dropdowns, drawers or modals;
- disabled buttons must explain why they are unavailable instead of
  looking broken.

## v168_25 FAQ and compression norm

FAQ must follow the selected runtime language.

FAQ public helper labels must not be hardcoded in English.
They must use locale keys and the selected UI dictionary.

FAQ must fit the bot simulation shell:

- compact width;
- no horizontal overflow;
- sticky search/category area inside the bot frame;
- readable wrapped text on small mobile widths.

Frontend compression rule:

- six bottom menu buttons are canonical;
- compress subsections inside canonical pages;
- do not collapse canonical pages into one first button;
- audit visible functions before removal;
- move operator/debug/admin functions to admin.

## v168_26 work pass norm

The first screen is Energy/progress/generation.
It is not a first-action button grid.

The six bottom menu buttons are canonical and unchanged:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

Frontend compression means compression inside pages and subsections.
It does not mean collapsing canonical pages into one new menu.

Every visible function must be classified before removal:

- leave;
- delete;
- move to Admin;
- ask.

Dragon style is visual only.
Do not copy Dragon brand, names or assets.
Use the reference for compact cards, resource chips, progress bars,
button feel and browser shell direction.

Browser mode is allowed as a parallel shell.
Telegram Mini App behavior remains primary and must not regress.
## v168_27 shell and visible-function triage rule

The shared modal must behave as a Telegram-style bottom sheet while
keeping the existing `open/onClose/title/children` call API.

GlobalHeader may receive game-shell visual structure, but must preserve
Profile, Wallet, Direct Deposit and HUB actions.

Layout may receive game-shell navigation classes, but the bottom menu
labels and routes remain canonical: Energy, Panels, Exchange, Tasks,
Referrals and Ranks.

Visible user functions are not removed directly from static audits.
They must first be classified as leave, delete, admin or question.

PWA/browser mode uses the browser's system install flow only.
Do not add a custom EFHC install button without direct approval.


## work pass — Energy/Ranks boundary

Energy is the canonical first screen and shows progress, generation and
active energy signals.  The six bottom menu buttons are immutable:
Energy, Panels, Exchange, Tasks, Referrals and Ranks.

The 12 Energy progression thresholds are an internal skin/progress
source.  They must not be rendered as an open level catalogue inside
Ranks.  Ranks remains a leaderboard surface: my rank, generated kWh,
leaderboard rows and compact game-style presentation.

All questions and approvals are agreed in chat first.  Archive documents
may store memory and evidence, but they do not replace chat approval.

## v168_29 WebApp and visible function norm

EFHC is a dual-surface WebApp target:

- Telegram Mini App surface;
- browser/PWA surface.

The user-facing install action must remain the browser system install
prompt.  Do not add a separate custom install button.

Ranks may use compact Dragon-style cards, but it remains a leaderboard.
Panels, Exchange and Tasks remain canonical bottom-menu pages.  Their
inner functions must be audited before removal or movement.

## v168_30 Panels / Exchange compact norm

Panels and Exchange are canonical bottom-menu pages.  They must not be
merged into Wallet or Energy without chat approval.

Panels public norm:
- show a compact summary first;
- keep panel activation as the main action;
- keep 100 EFHC activation canon;
- show Active / Archive as a segmented control;
- move secondary metadata into expandable details where safe;
- use self-user routes for public frontend list roads.

Exchange public norm:
- keep kWh -> EFHC conversion visible on Exchange;
- keep withdraw on Exchange until Wallet details are approved in chat;
- secondary explanations may collapse into details;
- do not expose technical route or debug terms.

## Browser/PWA independence norm

Public game pages must render without Telegram `tg_id`.  Telegram
identity may personalize data and unlock real server actions, but it is
not allowed to control whether the game interface appears.  Browser/PWA
mode must show the same EFHC app, starting from Energy, with dark game
shell, progress bars and compact cards.

## 1225 browser independence and dark shell rule

EFHC public UI must never become blank because Telegram tg_id is absent.
Browser/PWA and Telegram WebApp show the same game interface.

Default first paint is dark. White first paint is a visual blocker.

Locale fetch failure is not allowed to hide the app behind SplashScreen.
The UI must render with fallback strings if needed.

Energy progress must be visibly present on the first screen, including
zero-progress state.

All visible element approvals happen only in chat.
Archive documents are working memory, not approval.

## v168_55 frontend control system norm

The active frontend visual control layer is `docs/frontend/`.

For all public UI and Admin visual tasks:

1. read `FRONTEND_VISUAL_CONTRACT.md`;
2. read `FRONTEND_SHELL_ARCHITECTURE.md`;
3. read screen/component/visual-element registries;
4. read `FRONTEND_DO_NOT_TOUCH.md`;
5. use the acceptance checklist;
6. use screenshot QA when browser runtime is available;
7. change one screen or one visual layer per cycle.

Public UI must never expose debug, proof text, route diagnostics, raw
payloads, raw wallet state codes, raw payment states or black text on a
dark background.

The Admin Panel is a Russian operator console.  It may contain technical
data only inside diagnostics/service areas, not as the main home-screen
visual layer.


## v168_61 page-description source-first correction

The page-description documents are present in the archive and must be
read before new frontend questions are asked.  The current source set
includes:

- `docs/history/legacy_artifacts/docs/audits/VISIBLE_FUNCTIONS_TRIAGE_TABLE.md`;
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_VISIBLE_FUNCTIONS_AUDIT.md`;
- `docs/history/legacy_artifacts/docs/audits/FRONTEND_VISIBLE_ELEMENTS_CHAT_AGREEMENT.md`;
- `docs/history/legacy_artifacts/docs/audits/CHAT_VISIBLE_FRONTEND_AGREEMENT.md`;
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`.

User clarifications from v168_61 are mandatory:

- FAQ shows all sections first, then expands vertically by user action;
- Profile FAQ is a button to full FAQ;
- Wallet list and common financial history are separate functions;
- Admin home is a section-card launcher;
- each Admin functional page has its own stats/graphs and actions;
- Browser-Shop uses large Web3 NFT/product images;
- Ranks uses vertical player cards;
- HUB actions are two equal aligned buttons unless chat approves more;
- do not invent Energy logo/card elements not present in page specs.

## Frontend recovery canon update — v168_65

Panel cards must show the panel lifecycle as a countdown to deactivation:
activation date, deactivation date, days/hours/minutes and live countdown.
Do not replace this with simple `days active` or age labels.

Browser/PWA must not show a white screen. If authentication through
Telegram is required, show a complete login page with demo-preview.


## Cold start and first-paint asset rule

Cold start is not an EFHC Bot MVP blocker when the public shell is
cached and visible immediately. The Energy first screen must not wait for
the database before showing the interface.

The bot/skin hero must use the optimized runtime asset
`frontend/public/skins/1.webp` for first paint. The PNG file may remain
as a source/compatibility asset, but heavy images must not block the
initial interface.

See: `docs/NORM/COLD_START_MVP_UX_CANON.md`.

## Funding labels and visual separation — current canon

- `Прямое пополнение` appears only in the GlobalHeader `+` modal and means EFHC jetton → EFHCm.
- `Пополнение` appears in HUB and means external store purchase of EFHCm for TON/GRAM or USDT jetton.
- Direct Deposit shows EFHC amount and EFHC jetton wallet action; it MUST NOT show a native TON amount field.
- HUB shows exactly two equal cards and never performs a payment itself.
- Browser Shop visibly exposes the available TON/GRAM and USDT payment methods without showing internal payment diagnostics.
