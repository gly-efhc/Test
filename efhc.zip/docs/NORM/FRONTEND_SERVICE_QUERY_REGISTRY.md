<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Current funding and Withdraw service/query registry — v171.36

| Flow | Service | Query/mutation | Backend |
|---|---|---|---|
| Direct EFHC metadata | `directDeposit.service.ts` | `useDirectDeposit` | `POST /deposit/direct-open` |
| Store catalogue/intent | `browserShop.service.ts` | Browser Shop queries | HUB shop routes |
| Withdraw list/details | `withdrawals.service.ts` | `useWithdrawals` | Withdraw routes |
| Withdraw create/cancel | `withdrawals.service.ts` | mutations + invalidation | Withdraw routes |

Direct Deposit and Store purchase are separate service contours.

---

# Current service/query registry update — Profile and History

- `useProfileWallets` -> `getProfileWallets` -> `GET /wallets/me`.
- `useProfileBalanceHistory` -> `getProfileBalanceHistoryPage` ->
  `GET /wallets/balance-history`.
- `useProfileWithdrawHistory` -> `getProfileWithdrawHistoryPage` ->
  `GET /withdraw/list/me`.
- Wallet mutations invalidate `queryKeys.profile.wallets(global_id)`.
- Both history queries use cursor-based infinite-query pagination.

---

# Cycle 1558 service/query registry update

| Flow | Validator | Query/mutation | Backend |
|---|---|---|---|
| Referral statistics | `referralStatsSchema` | `useReferralStats` | `GET /api/referrals/stats/me` |
| Referral lists | `referralsPageSchema` | `useReferralList` | active/inactive referral routes |
| My rank and TOP | `myPlusTopSchema` | `useMyRankWithTop` | `GET /api/ranks/my-plus-top/me` |
| More ranks | `topPageSchema` | `useRankTopPages` | `GET /api/ranks/top/me` |

All active public pages consume hooks rather than direct transport.

---

# Cycle 1557 service/query registry update

| Flow | Validator | Query/mutation | Backend |
|---|---|---|---|
| Tasks catalogue | `TaskCatalogItemSchema` | `useTasksCatalog` | `GET /api/tasks/catalog` |
| User task state | `MyTaskItemSchema` | `useMyTasks` | `GET /api/tasks/my` |
| Protected claim | `ClaimTaskResponseSchema` | `useClaimTask` | `POST /api/tasks/claim` |
| Advertising timer | Ads slot/callback schemas | `useBuiltinAdSlot`, `useFinishBuiltinTimerAd` | Ads slot/callback routes |

Claim and advertising completion invalidate user-task state and snapshot.

---

# Cycle 1556 service/query registry update

| Flow | DTO/validator | Service | Query/mutation | Backend |
|---|---|---|---|---|
| Panels list/summary | generated Panel schemas | `panels.service.ts` | `usePanelsList`, `usePanelsSummary` | `GET /api/panels/active`, `GET /api/panels/archive`, `GET /api/user/me/panels-summary` |
| Panel activation | generated activation schema | `panels.service.ts` | `usePanelActivation` | `POST /api/panels/activate` |
| Exchange preview | generated Exchange schemas | `exchange.service.ts` | `useExchangePreview` | `GET /api/exchange/preview` |
| Exchange convert | generated conversion schema | `exchange.service.ts` | `useExchangeConvert` | `POST /api/exchange/convert` |

Both public pages now consume hooks rather than transport or manual parallel
server state. Mutations invalidate all dependent query keys.

---

# Cycle 1555 service/query note

No backend service, DTO or query contract changed. The cycle retained the
cycle-1554 typed Energy snapshot chain. Shell and browser-proof changes remain
outside the server-state transport boundary.

---

# Snapshot service/query registry update — cycle 1554

| Flow | DTO/validator | Service | Query key | Hook | View | Backend |
|---|---|---|---|---|---|---|
| Energy snapshot | `syncSnapshotSchema` in `snapshot.service.ts` | `fetchSyncSnapshot` | `queryKeys.snapshot.current(global_id)` | `useSnapshot` | `index.tsx` / `LiveEnergyHeroAndProgress` | `POST /sync/user/{global_id}?fresh=1` |

The hook no longer imports `apiRequest`. Validation occurs before data reaches
the view. Existing backend schema and business services are unchanged.

---

# Frontend Service Query Registry

This registry records active server-state seams after the migration gate.

| Feature | Service | Query | Status |
|---|---|---|---|
| browser-shop | `frontend/src/services/browserShop.service.ts` | `frontend/src/queries/useBrowserShop.ts` | active |
| withdraw | `frontend/src/services/withdrawals.service.ts` | `frontend/src/queries/useWithdrawals.ts` | active |
| tasks | `frontend/src/services/tasks.service.ts` | `frontend/src/queries/useTasks.ts` | active |
| panels | `frontend/src/services/panels.service.ts` | `frontend/src/queries/usePanels.ts` | active |
| exchange | `frontend/src/services/exchange.service.ts` | `frontend/src/queries/useExchange.ts` | active |
| profile | `frontend/src/services/profile.service.ts` | profile query seam | active |
| app shell | `frontend/src/services/appShell.service.ts` | app shell use site | active |

Public UI direct API access is guarded by
`ops/ci_checks/check_no_direct_api_in_public_ui.py`.

## Current HUB and Direct Deposit linkage

- HUB service: `frontend/src/services/hub.service.ts`.
- HUB query: `frontend/src/queries/useHub.ts`.
- Deposit service: `frontend/src/services/directDeposit.service.ts`.
- Deposit query: `frontend/src/queries/useDirectDeposit.ts`.
- HUB page does not access the transport directly.
- Deposit modal does not access the transport directly.
- Reconciliation reads the typed financial-history service.


---

# Cycle 1565 complete service/query registry

The canonical complete inventory is generated at:

`docs/history/legacy_artifacts/reports/generated/complete_function_linkage_matrix_v171_41.json`.

| Scope | Actions | Complete | Partial |
|---|---:|---:|---:|
| Public | 38 | 38 | 0 |
| Admin | 43 | 43 | 0 |
| Total | 81 | 81 | 0 |

New shared boundaries:

- Admin: `adminLinked.service.ts` and `useAdminLinkedTransport.ts`;
- Shop launcher: `shopLauncher.service.ts` and `useShopLauncher.ts`;
- skins: `skins.service.ts` and `useSkins.ts`;
- Wallet transport: `WalletProvider` and provider adapters; legacy
  `useTonConnectLinkage.ts` remains only as a provider-backed compatibility facade;
- cursor lists: `cursorList.service.ts` and `useCursorList.ts`;
- Profile wallet mutations: `useProfileWalletActions`.

Exact generated DTO parsers are used where available. Legacy Admin operations
without generated domain schemas use a structural JSON DTO boundary until an
exact schema is added.
