<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# DATABASE MIGRATION INVARIANTS NORM

Статус: **NORM / ACTIVE**

## Structural invariants

- Схемы: `efhc_core`, `efhc_admin`.
- Единственный Alembic head:
  `backend/migrations/versions/0001_initial_release_schema.py`.
- Новая migration `0002+` запрещена без прямого решения пользователя.
- ORM, migration `0001`, raw SQL и machine inventory должны совпадать.

## Identity invariants

- `efhc_core.users.global_id` — физический canonical owner.
- `users.user_id` отсутствует.
- Provider identifiers запрещены в owner FK, business unique keys,
  financial idempotency и internal API ownership.
- Новые account-owned rows требуют строковый `global_id`.

## Upgrade invariants

- backfill выполняется до `NOT NULL`;
- обязательны orphan и mismatch checks;
- синхронизируются FK, indexes, unique и checks;
- retired triggers/functions удаляются без повторного использования номеров;
- dual-write owner после cutover запрещён.
