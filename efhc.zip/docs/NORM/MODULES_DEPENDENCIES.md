<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# MODULES_DEPENDENCIES (EFHC) — Схема модулей и зависимостей

Статус: NORM.
Якорь SSOT: docs/SSOT/SSOT_INDEX.md
Связанные SSOT: docs/SSOT/EFHC_CANON.md, docs/SSOT/PROJECT_GLOSSARY.md

Цель: единая карта слоёв, модулей и допустимых зависимостей.
Любое отклонение от правил ниже считается дефектом архитектуры.

---

## 1. Слои и направление зависимостей

Разрешённое направление зависимостей:

routes → services → crud → models → db

Дополнительно:
- services → integrations (TON, внешние API)
- scheduler/watchers → services (только через публичные методы)
- services → core (ошибки, логи, locks)

Запрещено:
- routes → db/models напрямую
- models → services/routes
- integrations → services (интеграции не знают бизнес-логику)

---

## 2. Каноничные каталоги и роли

### 2.1 backend/app/routes
Роль: HTTP-граница.
Правила:
- Валидация входа через схемы.
- Авторизация/права доступа.
- Не содержит бизнес-логики.

### 2.2 backend/app/services
Роль: бизнес-логика.
Правила:
- Целевой owner key — `global_id`. Existing `global_id` calls are legacy compatibility and may only decrease from the cycle-1593 baseline.
- Все операции баланса подчиняются EFHC bank канону.
- Денежные значения через Decimal.

### 2.3 backend/app/crud
Роль: доступ к данным.
Правила:
- Никакой бизнес-логики.
- Вся логика транзакций в services.

### 2.4 backend/app/models
Роль: ORM-модели.
Правила:
- Только структура данных и связи.
- Нет вычислений продукта.

### 2.5 backend/app/core
Роль: общие инварианты.
Содержит:
- system locks
- единый формат ошибок
- логирование

### 2.6 backend/app/integrations
Роль: внешние интеграции.
Содержит:
- TON API клиент
- разбор memo
- идемпотентность обработки

### 2.7 backend/app/scheduler и watchers
Роль: фоновые процессы.
Правила:
- Не обращаются к DB напрямую.
- Вызывают services.
- Любые ошибки логируются, silent-pass запрещён.

---

## 3. Модули продукта (доменная карта)

Ниже — домены, которые должны отражаться в коде и документах.

### 3.1 users
- профиль пользователя
- target owner: `GlobalId` / `global_id`
- current `global_id` ownership is LEGACY compatibility until read switch

### 3.2 energy
- генерация kWh/EFHC
- панели и коэффициенты

### 3.3 panels
- покупка панелей
- списание EFHC по канону

### 3.4 bank
- центральный баланс EFHC
- проводки и журнал

### 3.5 transactions
- пользовательский баланс
- причины (reason) + details (SSOT)

### 3.6 shop
- товары и покупки
- подтверждение платежа (TON/USDT)

### 3.7 withdrawals
- заявки на вывод
- аудит админ-действий

### 3.8 nft / vip
- проверка NFT
- применение статусов VIP

### 3.9 tasks / ads
- задания и вознаграждения
- события и аудит

---

## 4. Контракты и документы

SSOT документов:
- API: docs/NORM/API_CONTRACTS.md
- Ошибки: docs/NORM/ERROR_CODES.md
- Роли: docs/NORM/ADMIN_RBAC.md
- Термины: docs/SSOT/PROJECT_GLOSSARY.md

Правило:
- Любое изменение API или статусов должно отражаться в SSOT.

---

## 5. Интеграции и идемпотентность

Операции, меняющие баланс или статус, должны быть идемпотентны.
Рекомендуемый механизм: Idempotency-Key + записи обработки.

Требования к интеграции TON:
- повторная обработка одной TON tx запрещена
- memo валидируется
- все действия логируются и имеют event_name + details


## Current HEAD audit note

- Current HEAD keeps the core direction `routes → services → crud → models → db` intact as the primary dependency rule.
- Hub/admin/commercial boundaries should be read together with `docs/SSOT/HUB_SSOT.md`, `docs/NORM/ADMIN_RBAC.md` and `docs/GENERAL/ADMIN_PANEL_SPEC.md`.
- Background/self-healing follow-ups are now described through active task/resilience documentation rather than the old standalone observability plan.
