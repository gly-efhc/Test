# SECURITY EXCEPTIONS REGISTER

Статус: NORM (реестр контролируемых security-исключений).
Якорь SSOT: `docs/SSOT/SSOT_INDEX.md`

Реестр допустимых исключений безопасности и канона.

## Правило

Любой `# nosec`, осознанный raw SQL и другой special-case должен быть
объяснён и иметь место пересмотра.

## Обязательные правила исключений

- каждый новый special-case обязан иметь явную причину и owner review;
- любой exception должен быть локальным, а не распространяться как шаблон;
- exception не может ломать канон схем `efhc_core` / `efhc_admin`;
- raw SQL допускается только параметризованно и с каноничной схемой;
- обход `canon_schema()` и скрытые security tails запрещены.

## Текущий статус

- `# nosec` внутри SQL-литералов запрещён;
- схемы БД вне `efhc_core` / `efhc_admin` запрещены;
- raw SQL допускается только при каноничной схеме и параметрах;
- обход `canon_schema()` запрещён.

## Пересмотр

Каждый новый special-case должен добавляться сюда и в change report.


## Цикл 1747 — открытые provider/ops решения, не security exceptions

Следующие пункты зафиксированы как незакрытые эксплуатационные решения и **не** считаются разрешением ослабить security:

- frontend CSP требует точного provider-specific HTTPS allowlist; широкое `script-src https:` запрещено, а runtime-configurable Monetag/AdMaven hosts нельзя выдумывать;
- RichAds adapter использует документированный provider HTTP SSP endpoint; production TLS/egress policy требует отдельного подтверждённого решения провайдера/оператора;
- `forwarded_allow_ips="*"` допустим только пока deployment гарантирует недоступность backend от недоверенных peers; точный trusted proxy CIDR должен задаваться по фактической topology.
