# VIP external verification norm

## Canon

1. EFHC VIP NFT is an external asset.
2. The bot does not sell, mint, issue or activate VIP NFT inside
   Telegram.
3. The bot only checks ownership of EFHC VIP NFT in linked wallets
   and derives VIP status from that check.
4. VIP ownership check and VIP status are separate from EFHC balance
   top-up flow.
5. The Telegram-side handoff must not present VIP as an in-app product
   or activation flow.
6. The external VIP storefront may live in the same backend/admin repo,
   but remains an external storefront, not an in-Telegram sale flow.
