## Уточнение цикла 1748

- Внешняя NFT-проверка обязана подтверждать не только заявленный collection address, но и authoritative verification связи item с коллекцией.
- В TonAPI-контуре EFHC принимает NFT для VIP/Admin NFT только при `verified=true`; отсутствующее/ложное значение fail-closed.
- Для одного аккаунта проверяются все active verified TON wallets; результат VIP является агрегированным по владельцу `global_id`.

# VIP external verification norm

## Canon

1. EFHC VIP NFT is an external asset.
2. The bot does not sell, mint, issue or activate VIP NFT inside
   Telegram.
3. The bot only checks ownership of EFHC VIP NFT in linked wallets
   and derives VIP status from that check.
4. VIP ownership check and VIP status are separate from EFHC balance
   top-up flow.
5. The Telegram-side handoff must not present VIP as an in-app product
   or activation flow.
6. The external VIP storefront may live in the same backend/admin repo,
   but remains an external storefront, not an in-Telegram sale flow.

## Уточнение цикла 1725

Admin Panel может зафиксировать ручную выдачу либо отклонение уже оплаченного
внешнего VIP NFT заказа. Это операторская запись поверх существующего Shop
order: Telegram не превращается в механизм mint/продажи NFT и вторая manual
claim-заявка не создаётся. Сам VIP по-прежнему определяется только внешней
проверкой фактического владения NFT.
