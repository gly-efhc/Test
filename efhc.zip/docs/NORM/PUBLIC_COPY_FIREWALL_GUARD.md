# PUBLIC_COPY_FIREWALL_GUARD.md

## Status

- Cycle: `1545`.
- Archive line: `v171.20`.
- Policy: `PUBLIC_TECHNICAL_COPY_ALLOWED = false`.
- Scanner: enabled.
- Pytest guard: enabled.
- Static public-copy proof: passed.
- DOM visual proof: not performed in sandbox.

## Closed items

- `P0-PUBLIC-COPY-FIREWALL-GUARD`
- `PUBLIC_TECHNICAL_COPY_ALLOWED_FALSE`
- `PUBLIC_EMPTY_STATE_COPY_CLEANUP`
- `PUBLIC_COPY_CI_GATE_LINKAGE`

## Active files

```text
ops/policy/public_ui_forbidden_copy.json
ops/ci_checks/check_public_ui_forbidden_copy.py
tests/architecture/public_visual_cases/case_public_ui_no_technical_copy.py
docs/GENERAL/PUBLIC_COPY_FIREWALL.md
```

## Commands

```bash
python ops/ci_checks/check_public_ui_forbidden_copy.py --root .
pytest tests/architecture/public_visual_cases/case_public_ui_no_technical_copy.py -q
make public-copy
cd frontend && npm run check:public-copy
```

## Release rule

If the scanner finds forbidden technical copy in public UI scan zones, the
cycle must not be closed as release-ready.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- DOM visual proof.
- Live Telegram proof.
- Real TonConnect proof.
- Release-ready.
- Production-ready.
