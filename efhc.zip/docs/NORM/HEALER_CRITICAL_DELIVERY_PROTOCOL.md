# Healer Critical Delivery Protocol

Status: mandatory fail-closed release and handoff gate.

## Disease class

`HEAL-0112 / CASE-0121` — protocol-complete transfer falsification risk.

This is a critical process disease because it can preserve code changes while
corrupting the user's ability to verify what was actually done. The disease is
confirmed when any of the following occurs:

- current HEAD documents point to different versions or cycles;
- a cycle is declared fully/live complete without evidence, or advanced without either evidence or an explicit user-authorized deferral;
- synthetic, mock or generated imitation PNG is presented as an application
  screenshot;
- a screenshot archive is created without explicit provenance and hashes;
- the main archive contains technical screenshots or nested archives;
- Healer, casebook, registry and cycle report are not updated together;
- the final response says that work is complete before archives pass an
  independent integrity check and become available through clickable links.

## Mandatory state machine

```text
READING_LOCK
→ HEAD_SYNC
→ HEALER_TRIPLE_WRITE
→ EVIDENCE_CLASSIFICATION
→ CYCLE_CLAIM_GATE
→ ARCHIVE_BUILD
→ ARCHIVE_INTEGRITY
→ DELIVERY_RECEIPT
→ USER_DELIVERY_ALLOWED
```

Any failed state transitions immediately to:

```text
BLOCKED_PROTOCOL
```

While `BLOCKED_PROTOCOL` is active, the AI is forbidden to:

- say that the work is complete;
- advance the cycle without factual evidence or a valid `DEFERRED_POST_RELEASE_BY_USER` disposition;
- claim live, browser, Telegram, wallet or transaction proof;
- provide an archive as canonical;
- hide the failed gate behind a narrative report.

## Gate algorithm

The executable gate is:

`ops/healer/check_critical_delivery_protocol.py`

It must verify all of the following before user delivery:

1. **HEAD synchronization** — START HERE, Kernel, handoff, release status,
   cycle plan and reports index declare the same target version and cycle.
2. **Healer triple write** — `atlas.json`, `casebook.json`, both Healer
   markdown indexes and the error registry contain the same critical incident.
3. **Cycle claim integrity** — absent live evidence remains fail-closed. Cycle 1573 may advance only when all available local checks are complete and the generated report explicitly records `LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED`, `DEFERRED_POST_RELEASE_BY_USER`, `release_ready=false` and cycle 1574 as next.
4. **Screenshot provenance** — proof type and method are explicit. Synthetic,
   mock or generated imitation screenshots are rejected. An inherited baseline
   is allowed only when `ui_change=false`, `fresh_cycle_png_count=0` and
   `inherited_from` is present.
5. **Main archive integrity** — exact sequential name, ZIP integrity, required
   documents, no nested ZIP, no technical screenshots and no build caches.
6. **Screenshot archive integrity** — matching version, ZIP integrity, exact
   PNG set, size and SHA-256 parity with the manifest.
7. **Delivery receipt** — only a `PASS` receipt grants
   `USER_DELIVERY_ALLOWED`.

## Screenshot classification

Every screenshot package must use exactly one mode:

- `fresh`: UI changed; new browser/application captures are required;
- `inherited`: UI did not change; an earlier verified browser baseline may be
  repackaged, but must be labelled inherited and never called fresh;
- `none`: UI did not change and the user did not require screenshots.

The words `synthetic`, `mock`, `fabricated` or equivalent in screenshot proof
metadata block application-proof delivery.

## Final response rule

A final response is permitted only after the gate prints:

`CRITICAL_DELIVERY_PROTOCOL: PASS`

The response must contain clickable links to the main archive, the screenshot
archive when present, and the delivery receipt. When screenshots were requested,
they must also be visibly embedded in the chat with an honest provenance label.
