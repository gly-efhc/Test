# Public Error State Canon

User-facing public UI must not render raw technical text from exceptions,
HTTP status strings, backend JSON, stack traces, SQL, traceback, `undefined`,
`null`, `Failed to fetch` or `Error: ...`.

Canonical public behaviour:
- empty list: calm empty state;
- first load: skeleton or calm loading copy;
- recoverable page load failure: quiet page state with retry/refresh;
- form/action failure: inline state next to the action, not duplicate toast;
- success/info after action: toast is allowed;
- background refresh failure: silent or stale indicator;
- 401/403: session refresh copy;
- 404: product route fallback;
- 5xx/timeout/offline: service/offline fallback.

Transport must preserve technical details in `ApiError.status`, `payload`,
`requestId`, `code` and `retryable`, but user copy is created only by safe
mappers.
