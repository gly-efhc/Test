<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# PANEL CHROME FOUNDATION

Status: `ACTIVE_PANEL_CHROME_FOUNDATION`

Cycle: `1462`

Archive target: `v170.38`

## Purpose

This document fixes the shared panel chrome contract for EFHC Bot
Dashboard Visual Direction.

The goal is to make every future dashboard panel use one predictable
shell instead of separate ad-hoc card wrappers. The shell is EFHC-owned
and only inspired by Grafana visual discipline.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Dashboard kernel:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Grafana usage map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime shared component:

`frontend/src/components/dashboard/PanelChrome.tsx`

Runtime admin wrapper:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

Runtime simulation wrapper:

`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`

## Boundary

Grafana is visual-pattern reference only.

Песочница is reference, navigation and prototype layer only.

This cycle does not change EFHC economy, backend contracts, database
schema, CI, locks, money flow or user balances.

## Required structure

Every panel chrome must provide:

- title;
- optional subtitle;
- status badge;
- body slot;
- optional actions;
- optional footer;
- optional source label;
- optional updatedAt / freshness label;
- dashboard contract marker;
- data kind marker;
- synthetic marker.

## Runtime implementation

Shared shell:

`PanelChrome`

Admin wrapper:

`AdminPanelChrome`

Simulation wrapper:

`SimPanelChrome`

Shared version marker:

`EFHC_PANEL_CHROME_V1`

Admin UI kit marker:

`EFHC_ADMIN_DASHBOARD_UI_KIT_V2_PANEL_CHROME`

Simulation UI kit marker:

`EFHC_SIM_DASHBOARD_UI_KIT_V2_PANEL_CHROME`

## Supported modes

Allowed modes:

- `admin`;
- `simulation`.

Admin mode is for operator dashboards.

Simulation mode is for user-facing energy, panels, ranks, tasks,
referrals and exchange dashboards.

## Supported sizes

Allowed sizes come from the component contract:

- `compact`;
- `normal`;
- `hero`.

Size controls visual density only. It must not change truth, route,
amount, status or action semantics.

## Status rules

Allowed statuses are inherited from the dashboard contract:

- loading;
- empty;
- error;
- stale;
- success.

A panel without visible status is not allowed in new dashboard code.
Existing legacy cards may remain until migrated.

## Data truth rules

Panel chrome must expose the source and data kind when a contract is
provided.

Allowed data kinds:

- raw;
- derived;
- synthetic_preview;
- real_timeseries.

Synthetic preview data must be marked as synthetic and must not be
shown as runtime truth.

## Grafana alignment

Cycle 1462 maps concrete Grafana panel chrome pieces to EFHC-owned
implementation targets:

| Grafana anchor | EFHC target |
|---|---|
| `PanelChrome/PanelChrome.tsx` | `PanelChrome` |
| `PanelChrome/PanelStatus.tsx` | `PanelChrome` status badge |
| `PanelChrome/PanelMenu.tsx` | safe `actions` slot only |
| `PanelChrome/PanelDescription.tsx` | subtitle/source text |
| `PanelChrome/HoverWidget.tsx` | future safe details affordance |
| `PanelHeader/PanelHeaderMenuWrapper.tsx` | future panel menu wrapper |
| `PanelHeader/PanelHeaderNotice.tsx` | future stale/error notices |
| `PanelInspector.tsx` | safe inspector drawer only |

The mapping is conceptual. No Grafana runtime source is copied.

## Safety rules

Panel chrome must not:

- introduce money-changing actions outside existing canonical flows;
- show secrets, env values, raw initData or debug JSON;
- show raw `global_id` on public user surfaces;
- turn synthetic preview series into real analytics;
- hide loading, empty, error or stale states;
- add heavy chart dependencies;
- import `@grafana/*` packages.

## Acceptance criteria

- `PanelChrome.tsx` exists in `frontend/src/components/dashboard/`.
- `AdminPanelChrome` uses the shared chrome foundation.
- `SimPanelChrome` exists for simulation dashboards.
- Shared CSS classes exist in `globals.css`.
- Grafana is mapped as reference only in `docs/history/legacy_artifacts/map_element.md` and
  `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
- Runtime code from Grafana or Песочница is not copied.
- No economy, backend, DB, CI or lock files are changed.

## Next step

Cycle `1463 — Progress System Foundation` should build reusable
progress components on top of the dashboard contract and panel chrome.
