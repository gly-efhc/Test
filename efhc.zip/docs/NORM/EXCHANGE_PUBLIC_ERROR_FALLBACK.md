# Exchange Public Error Fallback

`publicApiErrorMessage(error, t, fallbackKey)` now preserves auth/session
handling while allowing operation-specific public copy for non-auth errors.

Exchange mutation uses:

`publicApiErrorMessage(e, t, "exchange.exchange_failed")`

Preview flow remains separate and may still use preview-specific keys.
