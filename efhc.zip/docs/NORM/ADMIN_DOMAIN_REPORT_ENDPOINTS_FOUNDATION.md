# ADMIN DOMAIN REPORT ENDPOINTS FOUNDATION

Status: `ACTIVE_CYCLE_1503`

Cycle: `1503 — DASH-02 Admin Domain Report Endpoints Foundation`

Archive target: `v170.79`

## Purpose

Cycle 1503 closes audit/TZ finding `DASH-02` by adding five
admin-only, read-only domain report endpoints for deeper dashboard
analytics. These endpoints are report/analytics contracts only; they
must not mutate balances, withdrawals, deposits, panels or users.

## New contracts

| Endpoint | Domain | Source tables |
|---|---|---|
| `GET /admin/reports/users` | users | `users`, `panels` |
| `GET /admin/reports/bank` | bank | `bank_balance`, `efhc_transfers_log` |
| `GET /admin/reports/panels` | panels | `panels` |
| `GET /admin/reports/withdrawals` | withdrawals | `withdraw_requests` |
| `GET /admin/reports/deposits` | deposits | `payment_intents` |

All five endpoints return:

```text
ok=true
data_kind=real_timeseries
synthetic=false
snapshot=<domain aggregates>
trend=<bucketed real rows>
```

## Safety boundary

- Only `GET` routes are allowed.
- `require_admin` is mandatory on every endpoint.
- `SET LOCAL statement_timeout = '3000ms'` is mandatory.
- Response payloads expose only aggregate counters and trends.
- No person-level identifiers or raw wallet/init/debug payloads are
  returned.
- No Alembic migration was added.
- No existing business route was changed.
- No money write-flow was changed.
- No dependency, lock file or CI/workflow file was changed.

## Frontend seam

`frontend/src/lib/api/generated/adminSeams.ts` now exports five path
constants and `AdminDomainReportResponse` for future admin dashboard
consumers. Cycle 1503 does not force UI adoption; it establishes the
safe read-only backend/reporting foundation.

## OpenAPI / SSOT

`backend/openapi/openapi.json`, `backend/openapi/openapi_manifest.json`
and `docs/SSOT/ssot_pack/SSOT_ROUTES*.csv` were rebuilt from backend
route source via the existing static route-source snapshot tool.

Live FastAPI `app.openapi()` proof is not claimed in this cycle.

## Grafana / Sandbox boundary

Grafana remains only a visual-pattern/reference layer. Runtime code was
not copied.

Песочница remains only a reference/navigation/prototype layer. Runtime
code was not copied.
