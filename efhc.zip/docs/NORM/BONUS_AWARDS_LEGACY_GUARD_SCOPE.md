# Bonus Awards Legacy Guard Scope

Status: ACTIVE NORM.
Archive target: `v170.99`.

## Canon

`bonus_awards` is a legacy/dead table and is not an active money-flow
source of truth.

## Guard allowed only here

The legacy table guard is allowed only in functions whose job is to read
or mutate `bonus_awards`:

- `list_bonus_awards()`
- `process_bonus_award()`
- `reject_bonus_award()`

`list_bonus_awards()` returns an empty list if the table is absent.
`process_bonus_award()` and `reject_bonus_award()` fail closed if the
table is absent.

## Guard forbidden here

The legacy guard is forbidden in the live `withdraw_requests` flow:

- `list_withdrawals()`
- `approve_withdrawal()`
- `reject_withdrawal()`
- repair-consistency flow
- outcome-preview flow
- bank/payment/wallet flows

## Regression test

`tests/architecture/test_bonus_awards_compatibility_boundary.py` parses the
service with AST and fails if the legacy guard returns to live withdrawal
functions.
