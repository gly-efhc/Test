# Offline and Route Fallback Canon

The Telegram/WebView user must receive product fallback pages instead of
framework default errors, raw offline responses or blank screens.

Required surfaces:
- `frontend/src/pages/404.tsx` — route not found;
- `frontend/src/pages/500.tsx` — recoverable screen fallback;
- `frontend/src/pages/_error.tsx` — Pages Router fallback;
- `frontend/public/offline.html` — service worker fallback;
- `frontend/public/sw.js` must precache `offline.html` during install.

No `Response("Offline")` may be the primary user product fallback.
