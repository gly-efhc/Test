# ADMIN_LOGS_EVENTS_DASHBOARD.md

**Cycle:** `1490 — Admin Logs / Events Dashboard`  
**Archive version:** `v170.66`  
**Status:** DONE locally  
**Runtime route:** `/admin/logs`  
**Runtime component:** `frontend/src/components/admin/AdminLogsEventsDashboardRuntime.tsx`

## Цель

Сделать `/admin/logs` полноценным read-only dashboard для безопасной
операторской ленты событий и логов без переноса write-flow в dashboard.

## Источник truth

Текущий цикл использует существующий read-only endpoint:

```text
GET /admin/logs/transfers?limit=80
```

Модель данных:

```text
raw + derived snapshot
```

`raw` — записи transfer-log из backend endpoint.  
`derived` — локальные агрегаты для статусов, источников и видимого среза.

## Что показывает dashboard

- общее количество событий в snapshot;
- derived attention/success/info distribution;
- derived source distribution по задачам, банку, выводам и депозитам;
- безопасную event feed без raw payload;
- status strip по текущему snapshot;
- operator drill-down boundary;
- truth/safety boundary.

## Запреты

Dashboard не имеет права:

- менять состояние системы;
- выполнять money-changing actions;
- создавать idempotency key;
- показывать raw meta payload;
- показывать debug JSON;
- показывать secrets/env/initData;
- строить fake time-series;
- выдавать snapshot distribution за настоящую историю.

## Лог-ремонт цикла

`logs_73159210416.zip` показал одно CI-падение:

```text
tests/architecture/test_energy_dashboard_visual_qa.py::
test_russian_locale_is_not_mixed_with_english_truth_labels
```

Root cause: в `frontend/public/locale/ru.json` значение
`energy.dashboard_raw_snapshot` снова стало `Локализовано: raw snapshot`
вместо каноничного `исходный снимок`.

Исправлено:

- `energy.dashboard_raw_snapshot`;
- `energy.dashboard_derived_snapshot`;
- `energy.dashboard_no_timeseries`;
- значения синхронизированы по всем активным locale files без изменения
  состава ключей.

## Песочница / Grafana

Песочница использована только как reference/navigation/prototype layer.
Runtime-код не переносился.

Grafana использована только как visual-pattern/reference layer.
Runtime-код не переносился.
