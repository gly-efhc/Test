# DASHBOARD TOOLBAR FOUNDATION

Status: `ACTIVE_DASHBOARD_TOOLBAR_FOUNDATION`

Cycle: `1465`

Archive target: `v170.41`

## Purpose

Cycle 1465 creates the reusable toolbar layer for EFHC Bot Dashboard
Visual Direction.

The toolbar gives Admin Dashboard Layer and Simulation Dashboard Layer a
single language for title, breadcrumb, time period, refresh, filters,
freshness, updated time and safe actions.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Component contract:

`docs/NORM/DASHBOARD_COMPONENT_CONTRACT.md`

Design tokens:

`docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`

Grafana usage map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime component:

`frontend/src/components/dashboard/DashboardToolbar.tsx`

Admin wrapper:

`frontend/src/components/admin/AdminDashboardUiKit.tsx`

Simulation wrapper:

`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`

## Runtime components

Shared exports:

- `DashboardToolbar`;
- `DashboardTimeRangePicker`;
- `DashboardRefreshPicker`;
- `DashboardFreshnessBadge`.

Admin wrappers:

- `AdminDashboardToolbar`;
- `AdminTimeRangePicker`;
- `AdminRefreshPicker`;
- `AdminFreshnessBadge`.

Simulation wrappers:

- `SimDashboardToolbar`;
- `SimPeriodSwitch`;
- `SimFreshnessBadge`.

## Required toolbar contract

Every dashboard toolbar must keep these concerns explicit:

- page or panel title;
- optional breadcrumb;
- time range or period switch if time data is shown;
- refresh control if live or stale data can be updated;
- updatedAt or freshness marker for runtime data;
- filters only as display controls, not business truth changes;
- safe actions only.

## Boundaries

The toolbar is a visual and navigation component only.

It does not change EFHC economy, backend contracts, database schema,
CI, locks, payment logic, wallet logic, user balances or admin write
flows.

Time range controls do not create synthetic analytics. If a chart uses
synthetic preview data, the panel must still be marked as preview by the
component contract and mini chart layer.

## Grafana reference

Grafana elements used as conceptual references only:

- `DashboardControls.tsx`;
- `TimeRangePicker.tsx`;
- `RelativeTimeRangePicker.tsx`;
- `RefreshPicker.tsx`;
- `PageToolbar.tsx`;
- `ToolbarButton.tsx`;
- `TimeRangeInput.tsx`.

No Grafana source code is copied.
No Grafana dependency is added.
No Grafana runtime schema is imported.

## Next cycle

`1466 — Variables / Filters System`.
