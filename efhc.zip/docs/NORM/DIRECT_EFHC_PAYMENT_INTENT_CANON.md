# Direct EFHC Payment Intent Canon

Статус: ACTIVE / обновлён циклом 1742.

## Canon

Direct EFHC Payment Intent является одноразовым server-owned settlement
контрактом с реальным TTL. Он фиксирует owner, asset, destination, exact amount,
payload и `expires_at`.

Новый автоматический settlement разрешён только для `PENDING` intent до
`expires_at`. После подтверждения, истечения, отмены или ручного закрытия этот
payload не может использоваться для новой финансовой операции.

## Idempotency

- тот же `tx_hash` после `CONFIRMED` — read-through, без второго начисления;
- другой `tx_hash` после `CONFIRMED` — fail-closed, нужен новый intent;
- один `tx_hash` во всей системе — один global settlement claim.

Прямой EFHC jetton deposit, который работает как отдельный product flow без
Payment Intent payload, остаётся отдельным контуром и также обязан заявлять
тот же глобальный `tx_hash` settlement lock перед начислением.

## Exact D8 — прямое решение OWNER Cycle0448

EFHC decimals = 8 во всех финансовых контурах. Atomic integer / 10^8
даёт точную сумму: 123456789 atomic = 1.23456789 EFHC. Direct/memo/no-memo
deposit, PaymentIntent, watcher/parser, reconciliation/replay, ledger,
balance/history, transfers, withdrawals и Admin financial operations
сохраняют эту сумму без округления, обрезки и искусственного dust.
Вход с более чем 8 дробными знаками отклоняется до изменения денег.
Единая backend-граница: `app.domain.finance.efhc_amounts.exact_efhc_d8`;
frontend: `parseEfhcJettonD8`. Blockchain atomic integer — первичный источник.

D2 разрешён только для определения цены Shop. Цена 1.23 соответствует
финансовой сумме 1.23000000 EFHC; полученные 1.23456789 не превращаются
в 1.23 для сравнения цены. GRAM сохраняет native D9, USDT — D6.
Технические старые D8-проекции внешних GRAM receipts не являются
источником settlement: точные atomic units остаются в transport metadata.

SUCCESS/CONFIRMED/CREDITED допустим только после commit финансового state.
SQL failure откатывает root transaction; повтор после восстановления
проводит одну операцию. Эквивалентные hex/base64 hash aliases одной
chain transaction не дают второго settlement, включая исторический alias.
Balance/audit reason — стабильный machine identifier длиной не более 64;
диагностика остаётся в metadata/note/logs.
