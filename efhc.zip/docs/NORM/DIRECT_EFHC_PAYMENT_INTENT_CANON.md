# Direct EFHC Payment Intent Canon

## Canon

Direct EFHC payment intent is not a price offer with expiry.

EFHC amount is constant: EFHC = EFHC.

Direct EFHC intent remains valid until one of these events:

1. correct on-chain payment execution;
2. explicit cancellation;
3. manual closure;
4. technical or abuse block.

`expires_at`, if present in model or API, is not price protection.
It must not automatically reject a correct direct EFHC incoming payment.

If a user sends two different on-chain payments for one intent, these
are two incoming deposits.

Idempotency applies to one on-chain transaction identity. It does not
turn the intent into a ban on repeated payment.

## Current V1 implementation

The first confirmed direct EFHC transaction may be stored in
`payment_intents.external_tx_hash`.

A later different `tx_hash` for the same direct EFHC intent is accepted
as a separate incoming deposit and credited by a transaction-scoped
idempotency key.

The same `tx_hash` replay is an idempotent no-op.
