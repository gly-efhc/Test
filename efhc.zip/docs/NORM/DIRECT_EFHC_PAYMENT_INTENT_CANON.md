# Direct EFHC Payment Intent Canon

Статус: ACTIVE / обновлён циклом 1742.

## Canon

Direct EFHC Payment Intent является одноразовым server-owned settlement
контрактом с реальным TTL. Он фиксирует owner, asset, destination, exact amount,
payload и `expires_at`.

Новый автоматический settlement разрешён только для `PENDING` intent до
`expires_at`. После подтверждения, истечения, отмены или ручного закрытия этот
payload не может использоваться для новой финансовой операции.

## Idempotency

- тот же `tx_hash` после `CONFIRMED` — read-through, без второго начисления;
- другой `tx_hash` после `CONFIRMED` — fail-closed, нужен новый intent;
- один `tx_hash` во всей системе — один global settlement claim.

Прямой EFHC jetton deposit, который работает как отдельный product flow без
Payment Intent payload, остаётся отдельным контуром и также обязан заявлять
тот же глобальный `tx_hash` settlement lock перед начислением.
