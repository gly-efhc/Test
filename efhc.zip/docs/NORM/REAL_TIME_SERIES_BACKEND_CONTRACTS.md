# Cycle 1503 sync note

Cycle 1503 adds five admin domain report endpoints under `GET /admin/docs/history/legacy_artifacts/reports/*`. They are read-only, admin-only and return aggregate real time-series contracts. Observability endpoints from cycle 1491 remain active.

# Cycle 1497 sync note

The dashboard audit accepted that public `/dashboard/*` endpoints are not needed because user dashboards are prop-fed. Remaining admin domain report endpoints are frozen into `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md` as `admin_domain_report_endpoints_backlog`.

# REAL_TIME_SERIES_BACKEND_CONTRACTS.md

**Проект:** EFHC Bot  
**Цикл:** 1491 — Real Time-Series Backend Contracts  
**Версия:** v170.67  
**Статус:** ACTIVE NORM  
**Режим:** backend read-only contracts / dashboard truth hardening

## 1. Назначение

Цикл 1491 переводит dashboard-направление от запрета fake trends к
каноничным read-only backend contracts для настоящих временных рядов.

Главный принцип:

```text
Real time-series = только история из runtime truth tables.
Один snapshot не является time-series.
Frontend не имеет права синтезировать историю из одного snapshot.
```

## 2. Новые backend contracts

Добавлен admin-only route module:

```text
backend/app/routes/admin_observability_routes.py
```

Новые endpoints:

```text
GET /admin/observability/summary
GET /admin/observability/timeseries
GET /admin/observability/events
GET /admin/observability/health
```

Все endpoints:

- только `GET`;
- требуют `require_admin`;
- не меняют состояние системы;
- не создают idempotency key;
- не вызывают money-changing services;
- не показывают raw payload, raw meta, debug JSON, secrets или initData;
- используют bounded queries и statement timeout;
- возвращают явный `data_kind`.

## 3. Truth model

### 3.1. Summary

`GET /admin/observability/summary` возвращает текущую агрегированную
сводку из runtime truth tables.

Data kind:

```text
raw + derived
```

Источники:

- `users`;
- `efhc_transfers_log`;
- `panels`;
- `withdraw_requests`;
- `payment_intents`.

### 3.2. Timeseries

`GET /admin/observability/timeseries` возвращает настоящий временной ряд,
сгруппированный по `hour` или `day`.

Data kind:

```text
real_timeseries
```

Разрешённые metrics:

- `users_created`;
- `panels_created`;
- `withdrawals_created`;
- `payment_intents_created`;
- `efhc_transfer_count`;
- `efhc_transfer_amount` — gross turnover, credit + debit, not net balance;
- `efhc_credit_amount` — amount where direction = credit;
- `efhc_debit_amount` — amount where direction = debit.

Если строк в выбранном диапазоне нет, endpoint возвращает пустой массив
`points` и `empty_reason = no_rows_in_selected_range`. Это не ошибка и не
повод для frontend synthetic fallback.

### 3.3. Events

`GET /admin/observability/events` является compatibility-only disabled duplicate и не читает `efhc_transfers_log`. Canonical административная лента transfer events — `/admin/logs/transfers`; новый frontend/Admin Workbench не должен использовать disabled endpoint.

### 3.4. Health

`GET /admin/observability/health` фиксирует наличие контрактов и их
safety boundary.

## 4. Запреты

Запрещено:

- строить runtime trend из одного snapshot;
- выдавать synthetic/demo data за real analytics;
- делать POST/PUT/PATCH/DELETE в dashboard contracts;
- создавать idempotency key внутри dashboard layer;
- читать или рендерить raw payload/debug JSON/secrets;
- скрывать backend defect frontend workaround;
- менять экономику EFHC ради графиков;
- переносить runtime-код Grafana или Песочницы.

## 5. Grafana / Песочница

Grafana использована только как visual-pattern/reference layer.
Runtime-код Grafana не переносился.

Песочница использована только как reference/navigation/prototype layer.
Runtime-код Песочницы не переносился.

## 6. Green CI proof

В цикл 1491 внесён green-proof по приложенным логам:

```text
logs_73205751012.zip
```

Зафиксировано:

- `pytest`: `1635 passed, 8 skipped, 1 warning`;
- frontend build: passed;
- gate summary: `OK: all gate steps passed`.

Доказательство сохранено в:

```text
docs/history/legacy_artifacts/reports/generated/green_ci_log_proof_v170_67.json
```

## 7. Acceptance criteria

Цикл считается выполненным, если:

1. `admin_observability_routes.py` подключён в route registry.
2. OpenAPI snapshot содержит `/admin/observability/*` paths.
3. Frontend seam exports содержат новые read-only paths/types.
4. Тесты защищают read-only / no synthetic / no raw payload boundary.
5. Dashboard docs, map_element, Kernel, reports и test manifest обновлены.


## 8. Cycle 1492 hardening follow-up

Cycle `1492 — Synthetic Data Cleanup / Truth Hardening` tightened two
contract details:

1. `_route_for_reason` no longer uses broad `"ref" in reason_s`. Referral
   drill-downs now require `referral` marker.
2. `efhc_transfer_amount` is explicitly labelled as `EFHC gross turnover`,
   and `efhc_credit_amount` / `efhc_debit_amount` are available for
   directional amount charts.

This prevents operators from mistaking ledger turnover for net balance.
