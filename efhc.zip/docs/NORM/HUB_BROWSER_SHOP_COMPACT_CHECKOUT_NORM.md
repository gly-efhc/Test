# HUB and Browser Shop compact checkout norm

Status: ACTIVE

## Public HUB

- Exactly two visible actions: `Пополнение` and `EFHC VIP NFT`.
- No subtitle or detail that explains purchase, shop, packages, currencies,
  price or checkout before leaving the application. The separate VIP NFT collection action is canonical and allowed.
- `Пополнение` requests a signed handoff and opens the returned external URL.
- `EFHC VIP NFT` opens the official external GetGems collection.
- Direct Deposit is never opened from HUB.

## Browser Shop

Commercial information is allowed only on the external Browser Shop page.
The page must support:

- TON / GRAM checkout;
- USDT jetton checkout on TON / GRAM;
- signed Telegram handoff;
- access-key creation from an authenticated Web session;
- preservation of selected SKU and payment method in URL/session state;
- return to the same checkout after account or wallet linking;
- one active payment intent per user;
- backend-issued `expires_at` and visible TTL;
- React Query polling every five seconds until a terminal state;
- human states for pending, checking, confirmed and failed/expired;
- no public wallet, memo, payload or operator diagnostics.

## Compact visual contract

- No duplicated stepper/trust rail or explanatory sections.
- Account/linking state is one compact row.
- Payment state and TTL are one compact row.
- Payment method buttons have equal height and width.
- Product cards align vertically within the grid.
- A catalogue may scroll; the current checkout decision and status must fit
  within a normal mobile viewport whenever possible.
