## Цикл 1747 — handoff credential hygiene

Signed Browser Shop bearer допускается принять из первичного handoff URL только как входной compatibility contract. После чтения frontend сохраняет его в `sessionStorage` и удаляет `token` из текущего URL/history; checkout return URL не имеет права повторно переносить bearer. Замена первичного query handoff на one-time opaque exchange code требует отдельного согласованного изменения server/frontend consumers.

# HUB and Browser Shop compact checkout norm

Status: ACTIVE

## Public HUB

- HUB is a dynamic Admin-managed catalog with no limit on the number of elements.
- Render all real active/non-empty catalog links in exactly two columns.
- Odd counts stay odd: no empty, disabled or prepared placeholder slots.
- Shop, VIP NFT and other destinations are elements of the same catalog.
- Routing, signed handoff/session and security contracts remain unchanged; changes require an explicit OWNER decision.
- The two canonical Shop and EFHC VIP NFT links remain fallback only when dynamic catalog data is absent.
- No subtitle or detail that explains purchase, shop, packages, currencies,
  price or checkout before leaving the application. The separate VIP NFT collection action is canonical and allowed.
- `Пополнение` requests a signed handoff and opens the returned external URL.
- `EFHC VIP NFT` opens the official external GetGems collection.
- Direct Deposit is never opened from HUB.

## Browser Shop

Commercial information is allowed only on the external Browser Shop page.
The page must support:

- TON / GRAM checkout;
- USDT jetton checkout on TON / GRAM;
- signed Telegram handoff;
- access-key creation from an authenticated Web session;
- preservation of selected SKU and payment method in URL/session state;
- return to the same checkout after account or wallet linking;
- one active payment intent per user;
- backend-issued `expires_at` and visible TTL;
- React Query polling every five seconds until a terminal state;
- human states for pending, checking, confirmed and failed/expired;
- no public wallet, memo, payload or operator diagnostics.

## Compact visual contract

- No duplicated stepper/trust rail or explanatory sections.
- Account/linking state is one compact row.
- Payment state and TTL are one compact row.
- Payment method buttons have equal height and width.
- Product cards align vertically within the grid.
- A catalogue may scroll; the current checkout decision and status must fit
  within a normal mobile viewport whenever possible.
