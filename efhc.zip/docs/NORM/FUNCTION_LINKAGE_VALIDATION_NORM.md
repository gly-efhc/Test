# FUNCTION LINKAGE VALIDATION NORM

Статус: **NORM / ACTIVE**

Каждое активное public или Admin действие должно иметь проверяемую цепочку:

`UI → React Query → service → DTO → API → business → DB → response → invalidation/refetch`.

- Генератор evidence: `ops/linkage/build_complete_function_linkage_matrix.py`.
- Generated matrix хранится в `reports/current/`/`reports/generated/` пока она operational; immutable итог цикла фиксируется в `reports/numbered/`, а superseded bytes не возвращаются в active HEAD.
- Static linkage не доказывает PostgreSQL atomicity, внешние Telegram/TON
  операции или exact-head CI.
- Public/Admin UI не вызывает transport напрямую.
- Route обязан иметь auth boundary, business boundary и DB boundary.
