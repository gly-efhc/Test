# ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS

**Project:** EFHC Bot  
**Cycle:** 1485 — Admin Deposits Dashboard Upgrade  
**Archive:** v170.61  
**Mode:** Grafana visual-pattern/reference analysis only

## 1. Boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

No Grafana source code, dependencies, backend logic, auth logic,
datasource logic, alerting logic or plugin logic is copied into EFHC Bot.

## 2. Useful Grafana patterns

| Grafana pattern | EFHC usage |
|---|---|
| DashboardControls | admin deposits toolbar rhythm |
| RefreshPicker | manual runtime summary refresh |
| Variables | display-only deposit scope filter |
| PanelChrome | pipeline/readiness/boundary panels |
| PanelStatus | fresh/stale/error state markers |
| BigValue | credited/manual/retry/intent counters |
| BarGauge | pipeline distribution snapshot |
| StatusHistoryPanel | deposit state strip idea |
| StateTimelinePanel | future real deposit timeline |
| PanelInspector | safe future details without payload dumps |

## 3. EFHC adaptation

The runtime component uses EFHC-owned components:

```text
AdminDashboardToolbar
AdminFreshnessBadge
AdminRefreshPicker
AdminFilterBar
AdminKpiCard
AdminPanelChrome
AdminMiniBarChart
AdminProgressBar
AdminHeatStrip
AdminFlowMapCard
```

## 4. Explicit non-goals

The deposits dashboard does not become Grafana.

It does not add real time-series until a read-only backend time-series
contract exists.

It does not show raw transaction payload, debug JSON, secrets or raw
wallet payload.

It does not execute replay, exception processing or force fulfill.
