
# Withdraw flow norm

Статус: active V1 canon.
Режим: документация, guard и regression protection.

## Purpose

Этот документ фиксирует нормативную модель статусов withdraw в EFHC Bot
V1. Он нужен, чтобы будущий разработчик видел допустимый flow прямо в
архиве проекта, без доступа к переписке или внешним пояснениям.

## Withdraw payout canon

В EFHC Bot V1 заявка на вывод считается выплаченной после выполнения
утверждённого admin/operator payout action.

После выполнения такого действия заявка переводится в статус `PAID`.

Статус `PAID` означает, что система считает обязательство по заявке
выполненным согласно текущему операционному процессу EFHC Bot V1.

EFHC Bot V1 не требует отдельного backend blockchain watcher proof для
каждого перехода withdraw request в `PAID`.

Отсутствие обязательного backend on-chain proof не является ошибкой для
EFHC Bot V1, если заявка закрыта через разрешённый admin/operator
payout-flow.

## Withdraw status semantics

`PENDING` — заявка создана и ожидает admin/operator payout action.

`PAID` — заявка закрыта как выплаченная после выполнения утверждённого
admin/operator payout action.

В V1 нет обязательных промежуточных статусов settlement-проверки.

Допустимый переход:

`PENDING -> PAID`

при условии, что действие выполнено через разрешённый admin/operator
payout-flow.

## wallet_send_confirmed canon

`wallet_send_confirmed=true` является операционным подтверждением
выполнения payout action через утверждённый admin/operator wallet-flow.

В EFHC Bot V1 этот сигнал является достаточным для перевода withdraw
request в статус `PAID`, если действие выполнено через разрешённый
admin payout-flow.

`wallet_send_confirmed` не обязан быть отдельным blockchain watcher
proof.

## payout_ref canon

`payout_ref` является внутренней операционной ссылкой на payout action.

`payout_ref` не обязан быть blockchain transaction proof.

Формат вида `wallet-send:<provider>:<timestamp>` допустим как ссылка на
способ и момент выполнения operator payout action.

## EFHC Bot V1 payout FSM canon

EFHC Bot V1 не использует обязательную многоступенчатую payout FSM вида:

- `PAYOUT_CONFIRMING`;
- `PAYOUT_CONFIRMED`;
- `FAILED_SEND`;
- `RETRY_PENDING`;
- `REFUND_REQUIRED`.

В EFHC Bot V1 payout считается выполненным после утверждённого
admin/operator payout action.

Статус `PAID` является финальным статусом заявки на вывод в рамках
текущего операционного процесса.

## Forbidden drift

Запрещено переписывать V1 withdraw canon так, будто `tx_hash` является
обязательным условием для каждого `PAID`.

Запрещено требовать mandatory backend watcher proof для каждого `PAID`,
если канон проекта не был явно изменён отдельным согласованным cycle.

Запрещено превращать текущий V1 payout-flow в банковскую settlement FSM
без отдельного утверждённого SSOT/NORM изменения.
