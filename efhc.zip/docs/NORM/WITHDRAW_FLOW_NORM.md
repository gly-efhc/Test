## Цикл 1746 — hold/refund repair atomicity

- Repair сначала повторно читает актуальную `withdraw_requests` row под `FOR UPDATE`, затем вызывает только `*_nocommit` money primitive.
- Один ledger idempotency key имеет один fingerprint: hold всегда `reason=withdraw_hold`, refund всегда `reason=withdraw_refund`, включая repair/autofix paths.
- Если marker UPDATE после money primitive не подтверждает ожидаемую row, текущая savepoint/root transaction откатывает денежное изменение.
- Active Admin approve/reject не использует committing money helper внутри withdrawal row lock.
- `/admin/withdrawals/repair-consistency` имеет actor-bound strict operation idempotency по HTTP `Idempotency-Key`.


# Withdraw flow norm

Статус: active V1 canon.
Режим: документация, guard и regression protection.

## Purpose

Этот документ фиксирует нормативную модель статусов withdraw в EFHC Bot
V1. Он нужен, чтобы будущий разработчик видел допустимый flow прямо в
архиве проекта, без доступа к переписке или внешним пояснениям.

## Withdraw payout canon

В EFHC Bot V1 заявка на вывод считается выплаченной после выполнения
утверждённого admin/operator payout action.

После выполнения такого действия заявка переводится в статус `PAID`.

Статус `PAID` означает, что система считает обязательство по заявке
выполненным согласно текущему операционному процессу EFHC Bot V1.

EFHC Bot V1 не требует отдельного backend blockchain watcher proof для
каждого перехода withdraw request в `PAID`.

Отсутствие обязательного backend on-chain proof не является ошибкой для
EFHC Bot V1, если заявка закрыта через разрешённый admin/operator
payout-flow.

## Withdraw status semantics

`PENDING` — заявка создана и ожидает admin/operator payout action.

`PAID` — заявка закрыта как выплаченная после выполнения утверждённого
admin/operator payout action.

В V1 нет обязательных промежуточных статусов settlement-проверки.

Допустимый переход:

`PENDING -> PAID`

при условии, что действие выполнено через разрешённый admin/operator
payout-flow.

## wallet_send_confirmed canon

`wallet_send_confirmed=true` является операционным подтверждением
выполнения payout action через утверждённый admin/operator wallet-flow.

В EFHC Bot V1 этот сигнал является достаточным для перевода withdraw
request в статус `PAID`, если действие выполнено через разрешённый
admin payout-flow.

`wallet_send_confirmed` не обязан быть отдельным blockchain watcher
proof.

## payout_ref canon

`payout_ref` является внутренней операционной ссылкой на payout action.

`payout_ref` не обязан быть blockchain transaction proof.

Формат вида `wallet-send:<provider>:<timestamp>` допустим как ссылка на
способ и момент выполнения operator payout action.

## EFHC Bot V1 payout FSM canon

EFHC Bot V1 не использует обязательную многоступенчатую payout FSM вида:

- `PAYOUT_CONFIRMING`;
- `PAYOUT_CONFIRMED`;
- `FAILED_SEND`;
- `RETRY_PENDING`;
- `REFUND_REQUIRED`.

В EFHC Bot V1 payout считается выполненным после утверждённого
admin/operator payout action.

Статус `PAID` является финальным статусом заявки на вывод в рамках
текущего операционного процесса.

## Forbidden drift

Запрещено переписывать V1 withdraw canon так, будто `tx_hash` является
обязательным условием для каждого `PAID`.

Запрещено требовать mandatory backend watcher proof для каждого `PAID`,
если канон проекта не был явно изменён отдельным согласованным cycle.

Запрещено превращать текущий V1 payout-flow в банковскую settlement FSM
без отдельного утверждённого SSOT/NORM изменения.

## Cycle 1794 — payout confirmation и External EFHC D2

Owner-Decision-Refs: `QA-2026-08-19-FIN3-01`, `FIN3-03`, `FIN3-10`, `FIN3-11`.

- Withdrawal asset — только EFHC.
- Request amount: raw external EFHC → D2 `ROUND_DOWN` → internal D8; этот же нормализованный amount используется для hold и внешней отправки.
- `< 0.01 EFHC` после D2 становится `0.00` и отклоняется; текущий product minimum применяется уже к нормализованной сумме.
- Operator flow: `PENDING → Оплатить → wallet/manual send → Оплачено → PAID`.
- Успешный wallet `sendTransaction()` сохраняется как payout evidence, но сам по себе не является `PAID` action.
- `Оплачено вручную` разрешено Admin с обязательным reason и audit.
- Withdrawal network fee платит проект; user EFHC amount не уменьшается на fee.
