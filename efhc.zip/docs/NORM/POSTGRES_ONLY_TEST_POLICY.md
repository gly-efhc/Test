# POSTGRES ONLY TEST POLICY

## Scope

Tests that rely on PostgreSQL-specific row locking, SQL functions or SQL syntax
must not pretend to be SQLite-compatible.

## Rules

- Tests that require `FOR UPDATE`, `SKIP LOCKED`, `now()`, `::numeric` and
  similar PostgreSQL semantics must be marked and treated as Postgres-only.
- Domain logic must not be simplified just to satisfy SQLite limitations where
  that would distort real production behavior.
- SQLite may still be used for lighter tests, but not as a false substitute for
  locking/payment-intent paths that are Postgres-sensitive.
