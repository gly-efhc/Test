# Playbook: совместимость код → маршруты → таблицы → миграции

Status: NORM
SSOT anchor: `docs/SSOT/SSOT_INDEX.md`


Дата генерации (UTC): 2026-03-26T17:05:00Z

Этот документ — рабочая инструкция, как проверять связку
маршруты → ORM → таблицы → миграция `0001_init.py` без смешения
источников истины.

## Канон истины

- Истина: ORM (`backend/app/models/**`, `Base.metadata`) + SSOT CSV в
  `docs/SSOT/ssot_pack`.
- Миграция `0001_init.py` — производный артефакт. Она создаёт схемы и
  ORM-таблицы из `Base.metadata`, но не расширяет истину.
- Схемы БД: ровно 2 — `efhc_core`, `efhc_admin`.
- Таблицы канона: ровно 35, при этом active docs layer must rely on current NORM invariants for exact schema/count distribution instead of stale duplicated formulas.
- Исторические аудиты не меняют active SSOT.

## Входные SSOT файлы

- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv` — истина таблиц (35).
- `docs/SSOT/ssot_pack/SSOT_TABLES_MIGRATIONS.csv` — карта таблица → 0001.
- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv` — маршрут →
  таблицы → миграция.
- `backend/migrations/versions/0001_init.py` — ORM-only первичная
  миграция.

## Что обязана подтверждать 0001

1. Существуют схемы `efhc_core` и `efhc_admin`.
2. Импортируются все `*_models.py`, чтобы `Base.metadata` содержала все
   active ORM-таблицы.
3. `create_all(..., checkfirst=True)` создаёт только ORM-таблицы.
4. Sanity сверяет фактическое число таблиц с
   `SSOT_TABLES_ORM.csv`.
5. `0001` остаётся идемпотентной и не добавляет raw-SQL extra tables.

## Как чинить расхождения

### Если расходится ORM ↔ SSOT
- Сначала исправить ORM/SSOT.
- Затем проверить, что `0001` импортирует нужные модели и sanity count
  совпадает с `SSOT_TABLES_ORM.csv`.

### Если расходится 0001 ↔ SSOT
- Чинить `0001_init.py` только как производный артефакт:
  импорт моделей, sanity, диагностические сообщения, idempotency.
- Не добавлять новые бизнес-таблицы raw SQL вручную.

### Если расходятся routes/docs ↔ tables
- Исправить `SSOT_ROUTES_TABLES_MIGRATIONS.csv` и связанные markdown
  docs, затем прогнать архитектурные guard-тесты.

## Запреты

- Нельзя возвращаться к старому efhc_core-only описанию таблиц.
- Нельзя держать устаревший числовой count таблиц.
- Нельзя добавлять в `0001` таблицы вне `Base.metadata`.
- Нельзя использовать migration docs как более высокий источник истины,
  чем ORM + SSOT.
## Current HEAD audit note

- This playbook remains useful as an active operational guide for audits of route → table → migration linkage.
- Exact schema/count figures should be taken from `docs/NORM/MIGRATION_INVARIANTS_HARDENING.md`, `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md` and `docs/SSOT/ssot_pack/**`, not from stale duplicated numbers inside older playbook revisions.
- Current MVP migration canon remains `0001 only`.
