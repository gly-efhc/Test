<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ROUTES / TABLES / MIGRATIONS PLAYBOOK

Статус: **NORM / ACTIVE**  
Версия среза: **v174.38 / цикл 1789 / static source+SSOT audit**

## Текущий контракт

- Public OpenAPI/source surface: **160 paths / 166 operations**.
- Hidden/internal/compatibility HTTP surface: **8 operations** (`include_in_schema=False`).
- Mounted HTTP surface: **174 operations**.
- Checked-in OpenAPI schemas: **169**.
- ORM-таблицы: **52**.
- Схемы: `efhc_core` (**45**) и `efhc_admin` (**7**).
- Alembic head: только `0001_initial_release_schema.py`.
- `0001` остаётся **frozen**; `0002+` запрещены без прямого решения владельца.
- Account owner: `users.global_id`; provider subjects не являются business owners.
- On-chain financial paths обязаны сохранять единый `tx_hash_locks` settlement-lock до начисления.

## Источники истины

1. Public route registry: `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` + exact current route source.
2. ORM registry: `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv` + exact model source.
3. Release schema: `backend/migrations/versions/0001_initial_release_schema.py`.
4. Checked-in OpenAPI snapshot: `backend/openapi/openapi.json` — evidence публичного API snapshot, не замена route source.

`SSOT_ROUTE_TABLE_MAP.csv` и `SSOT_ROUTES_TABLES_MIGRATIONS.csv` в текущем HEAD содержат historical/retired table names в части rows и имеют статус **STALE SUPPORTING EVIDENCE**. До отдельной доказательной regeneration они не могут переопределять route source, ORM SSOT или frozen `0001`.

## Порядок изменения

1. Получить direct owner scope, если изменение затрагивает frozen schema/migration.
2. Изменить runtime/ORM contract минимальным diff.
3. Если owner scope разрешает schema change — синхронно обновить frozen `0001`; `0002+` не создавать без отдельного решения.
4. Синхронизировать raw SQL, routes, DTO и exact SSOT registries.
5. Обновить tests/architecture guards под подтверждённый current contract; stale test не является authority над owner-approved change.
6. Route→table map регенерировать только по доказанным handler→service→repository/table traces, без guesswork.
7. Execution qualification получает следующий GitHub CI; локальные full tests/builds ассистентом не запускаются.

## Запреты

- новая migration `0002+` без решения владельца;
- owner FK на provider subject;
- stale duplicated table/route counts как current truth;
- raw SQL table, отсутствующая в ORM/SSOT/approved schema;
- фиктивная route→table regeneration без exact evidence;
- исправление теста возвратом superseded owner-approved frontend/runtime behavior.
