<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ROUTES / TABLES / MIGRATIONS PLAYBOOK

Статус: **NORM / ACTIVE**  
Версия среза: **v173.12 / цикл 1692**

## Текущий контракт

- HTTP routes в freeze: **132**.
- ORM-таблицы: **48**.
- Схемы: `efhc_core` (**42**) и `efhc_admin` (**6**).
- Alembic head: `0001_initial_release_schema.py`.
- Account owner: `users.global_id`.
- Provider subjects не являются business owners.

## Источники истины

1. Route registry:
   `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`.
2. ORM registry:
   `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.
3. Route/table map:
   `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`.
4. Release schema:
   `backend/migrations/versions/0001_initial_release_schema.py`.

## Порядок изменения

1. Изменить ORM и runtime contract.
2. Синхронизировать migration `0001`.
3. Синхронизировать raw SQL, routes и frontend DTO.
4. Обновить tests и architecture guards.
5. Перегенерировать SSOT CSV и diagnostics.
6. Проверить fresh database и upgrade pre-release database.

## Запреты

- новая migration `0002+` без решения пользователя;
- owner FK на provider subject;
- stale duplicated table/route counts;
- raw SQL table, отсутствующая в ORM/SSOT;
- исправление теста возвратом legacy ownership.
