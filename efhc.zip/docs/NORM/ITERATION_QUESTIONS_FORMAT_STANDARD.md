# Iteration Questions Format Standard

Status: ACTIVE.  
Scope: EFHC Bot AI/operator cycles, audit repair cycles, CI/log repair cycles and any blocked decision point.

## 1. Purpose

This standard fixes the user-approved format for asking iteration questions.
Questions must be simple, concrete and decision-oriented. The agent must not ask vague technical questions when a repair decision is needed.

## 2. Required question format

Every important iteration question must use this structure:

1. **Проблема** — explain the concrete issue in simple Russian words.
2. **Простой вопрос** — ask exactly what decision is needed.
3. **Варианты ответа** — list clear options.
4. **Моя рекомендация** — give one recommended option and why.
5. **Коротко: рекомендуемые ответы** — short answer block the user can approve quickly.

## 3. Language rule

Questions must be written in Russian. File names, route paths, table names and exact code symbols may remain in technical form.

## 4. No vague questions

Forbidden question style:

- "Как лучше?"
- "Подтвердить архитектуру?"
- "Что делаем с этим?"
- long English-only technical questions;
- questions without a recommended answer.

Required style:

- explain the problem plainly;
- show consequences;
- offer 2-3 concrete options;
- recommend one safe option.

## 5. User-approved decisions from cycle 1436 linkage freeze

The user approved these answers for future repair cycles:

1. **Admin Bank mint/burn:** do not create a separate `efhc_mint_burn` ledger/table. The operation is rare, so runtime must use only existing official/canonical tables and ledger surfaces.
2. **Admin wallet reset:** it must fully unbind canonical `wallet_bindings`, because this is how the operator understands the action.
3. **Admin Hub:** it is a separate admin section and its canonical path is `/admin/hub/*`.

## 6. Completion rule

When a question is answered by the user, the answer must be reflected in:

- `docs/GENERAL/CURRENT_DECISIONS.md`;
- the relevant cycle document;
- active repair plan / finding index if one exists;
- Kernel/map/routes docs when the decision affects future navigation.
