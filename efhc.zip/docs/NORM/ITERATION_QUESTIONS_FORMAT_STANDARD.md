# OWNER CLARIFICATION QUESTIONS — FRONTEND STANDARD
## ОБЯЗАТЕЛЬНОЕ ПРАВИЛО ЯЗЫКА ВОПРОСОВ OWNER

OWNER является архитектором системы, а не программистом. Любой вопрос OWNER сначала формулируется простым человеческим русским языком: что пользователь увидит, что изменится в поведении и какой выбор требуется утвердить. Нельзя делать главным содержанием вопроса названия внутренних файлов, CSS-классов, API-параметров, EAM-кодов, `aria-label`, cursor/seed/migration и другие инженерные термины. Если техническая деталь действительно нужна, она указывается только после простого вопроса как короткое пояснение. Один вопрос = одно понятное продуктовое/архитектурное решение.

Если OWNER сообщил, что вопрос непонятен, прежняя техническая формулировка не считается ответом: вопрос обязан быть переформулирован простым языком и повторно внесён в Q&A register.


Ask owner questions only when exact frontend SSOT/CANON/EAM/current source/main contract does not already resolve the decision.

Each question must contain:
- affected screen/function;
- exact current behavior or defect;
- why authority is insufficient or conflicting;
- concrete alternatives and their visible/business consequence;
- recommended default when technically safe.

Do not ask again about an owner decision already fixed in current authority.
