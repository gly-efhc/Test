# Iteration Questions Format Standard

Status: ACTIVE.  
Scope: EFHC Bot AI/operator cycles, audit repair cycles, CI/log repair cycles and any blocked decision point.

## 1. Purpose

This standard fixes the user-approved format for asking iteration questions.
Questions must be simple, concrete and decision-oriented. The agent must not ask vague technical questions when a repair decision is needed.

## 2. Required question format

Every important iteration question must use this structure:

1. **Проблема** — explain the concrete issue in simple Russian words.
2. **Простой вопрос** — ask exactly what decision is needed.
3. **Варианты ответа** — list clear options.
4. **Моя рекомендация** — give one recommended option and why.
5. **Коротко: рекомендуемые ответы** — short answer block the user can approve quickly.

## 3. Language rule

Questions must be written in Russian. File names, route paths, table names and exact code symbols may remain in technical form.

## 4. No vague questions

Forbidden question style:

- "Как лучше?"
- "Подтвердить архитектуру?"
- "Что делаем с этим?"
- long English-only technical questions;
- questions without a recommended answer.

Required style:

- explain the problem plainly;
- show consequences;
- offer 2-3 concrete options;
- recommend one safe option.

## 5. User-approved decisions from cycle 1436 linkage freeze

The user approved these answers for future repair cycles:

1. **Admin Bank mint/burn:** do not create a separate `efhc_mint_burn` ledger/table. The operation is rare, so runtime must use only existing official/canonical tables and ledger surfaces.
2. **Admin wallet reset:** it must fully unbind canonical `wallet_bindings`, because this is how the operator understands the action.
3. **Admin Hub:** it is a separate admin section and its canonical path is `/admin/hub/*`.

## 6. Completion rule

Канонический Q/A register: `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`.

Каждый owner-facing вопрос, требующий решения, обязан быть зарегистрирован **до отправки владельцу** со статусом `PENDING`. После ответа исходная запись сохраняется и получает ответ плюс статус `ANSWERED`; исходный вопрос не удаляется и не переписывается. Устаревшие решения сохраняются как история со статусом `SUPERSEDED`. Вывод ассистента запрещено записывать как ответ владельца.

После ответа владельца решение должно быть отражено в:

- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- `docs/GENERAL/CURRENT_DECISIONS.md` только пока решение ещё не перенесено в профильный CANON/SSOT;
- соответствующем документе цикла;
- активном repair plan / finding index, если он существует;
- Kernel/map/routes документах, если решение влияет на дальнейшую навигацию.

Если реестр отсутствует, неполон или был случайно выведен из active authority, его необходимо восстановить по точным reports/chat/archive evidence до отправки новых вопросов. Неизвестные исторические ответы запрещено выдумывать.


## 7. Historical recovery requirement

При прямом требовании владельца восстановить пропущенные Q/A недостаточно проверить текущий чат. Обязателен полный проход всех доступных numbered chat transcripts. Доказуемые ответы добавляются append-only; неполный контекст помечается явно и не становится решением владельца.
