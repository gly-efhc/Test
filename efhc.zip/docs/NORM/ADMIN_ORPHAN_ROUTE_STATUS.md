# Admin Orphan Route Status

Cycle: 1513

## Status values

- `LEGACY_INTERNAL_FINAL` means the backend route exists and is
  intentionally kept for compatibility/operator tooling, while the normal
  admin UI uses a different canonical action path.

## `/admin/shop/items/set-price`

Status: `LEGACY_INTERNAL_FINAL`

Decision: keep as legacy/internal.

Reason: the normal admin catalog edit UI uses
`/admin/shop/items/upsert` for price fields. A second dedicated price
form would duplicate the same mutation surface and is not needed in this
QA-hardening cycle.

Guard: `tests/architecture/test_admin_orphan_routes_documented.py` keeps
this route marked as documented legacy/internal so it is not treated as a
silent UI gap.

## `/admin/tasks/{task_id}`

Status: `LEGACY_INTERNAL_FINAL`

Decision: keep as internal/detail API.

Reason: the current admin tasks UI works through list, moderation,
submission and refresh-status flows. Single task GET remains available
for operator tooling/future detail UI, but it is not a missing mandatory
button for cycle 1513.

Guard: `tests/architecture/test_admin_orphan_routes_documented.py` keeps
this route marked as documented legacy/internal so it is not treated as a
silent UI gap.
