# Ranks Rules

Status: NORM

## Current canon

- Рейтинг является полным списком всех квалифицированных пользователей; `TOP-100` не является пределом данных или UI.
- Первая порция отображает места `1–100`; `Показать ещё` последовательно догружает `101–200`, `201–300` и далее по 100 записей до конца ranking universe.
- `Найти меня` получает backend-authoritative реальную позицию пользователя и позиционирует ranking surface на окне, содержащем это место.
- Пользователь не получает `rank_pos=0` только потому, что находится ниже первых 100/200 записей.
- Personal rank card допустима, но не заменяет переход к реальному месту в общем рейтинге.
- Current rank хранится непосредственно в `users.rank_position/rank_score_kwh/rank_calculated_at`; отдельные ranking snapshot/cache tables retired по решению владельца.
- Backend является единственным authority для rank position, pagination cursor, total participants и find-me context.
- Базовая kWh ranking surface опирается на `total_generated_kwh`; смена ranking formula требует отдельного owner decision.
- Active route surface рейтинга: `/ranks/my-plus-top/me` и `/ranks/top/me`. Referral leaderboard retired по решению владельца; referral economy остаётся отдельным контуром.
- Referral/ranking presentation является нефинансовым контуром: сортировка/позиция по referral metrics сама по себе не создаёт EFHCb rewards; monetary referral payouts принадлежат отдельным `REF_ACT_UNIT` и `REF_LVL` namespaces.

## Current HEAD audit note

- Historical UI/product notes about ranks should not override this NORM file once they diverge.

## Current visual hierarchy

- In leaderboard rows, `username` and generated energy use the same primary-text brightness and size; generated energy has the stronger weight (`900` vs username `800`).
- Generated energy must not use muted/secondary colour.
- The approved row geometry remains three columns `position | username | generated kWh`; theme changes do not alter ranking data/API semantics.
- Production and standalone preserve the same visual hierarchy.
