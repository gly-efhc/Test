# Ranks Rules

Status: NORM
SSOT anchor: `docs/SSOT/SSOT_INDEX.md`

## Current canon

- Рейтинг отображается как `Я + TOP-100`.
- Отдельно показывается блок текущего пользователя, затем общий top-list.
- Базовая ranking surface опирается на `total_generated_kwh`; любые future ranking formulas должны быть отдельно утверждены и не могут молча заменить этот канон.
- Snapshot/storage layer использует `efhc_core.ranks_snapshots`.
- Active route surface for ranks must stay aligned with current SSOT route maps (`/ranks/my-plus-top`, `/ranks/top`).

## Current HEAD audit note

- Правило `total_generated_kwh` как lifetime append-only metric должно читаться вместе с `docs/NORM/ARCHITECTURAL_LOCKS.md`, `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` и related route/table maps.
- Historical UI/product notes about ranks should not override this NORM file once they diverge.
