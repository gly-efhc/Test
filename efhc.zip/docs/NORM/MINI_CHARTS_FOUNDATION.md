# MINI CHARTS FOUNDATION

Status: `ACTIVE_MINI_CHARTS_FOUNDATION`

Cycle: `1464`

Archive target: `v170.40`

## Purpose

Cycle 1464 creates a lightweight EFHC-owned mini chart layer for
Dashboard Visual Direction Plan. The layer supports small charts for
Simulation and Admin dashboards without adding heavy chart dependencies.

## Runtime component

`frontend/src/components/dashboard/MiniCharts.tsx`

Exports:

- `DashboardMiniSparkline`
- `DashboardMiniAreaChart`
- `DashboardMiniBarChart`
- `DashboardActivityStrip`
- `buildMiniChartPolyline`
- `normalizeMiniChartPoints`
- `miniChartsFoundationVersion`

Simulation wrappers:

- `SimMiniSparkline`
- `SimMiniAreaChart`
- `SimMiniBarChart`
- `SimActivityStrip`

Admin wrappers:

- `AdminSparkline`
- `AdminAreaChart`
- `AdminMiniBarChart`
- `AdminHeatStrip`

## Data truth rules

Mini charts must declare data kind metadata:

- `raw`
- `derived`
- `synthetic_preview`
- `real_timeseries`

Synthetic preview series must be marked through the `synthetic` prop.
A pretty chart must never pretend to be runtime truth.

## Allowed use

- Energy growth preview when data source is explicit.
- Panels portfolio mini chart when based on real panel records.
- Ranks / tasks / referrals activity strips when data exists.
- Admin trend cards when based on read-only admin/report endpoints.

## Forbidden use

- Do not invent real analytics from one snapshot.
- Do not hide missing backend history behind decorative SVG.
- Do not add chart dependencies without a separate bundle audit.
- Do not copy Grafana runtime chart code.
- Do not copy Песочница runtime chart code.

## Grafana reference analysis

Grafana elements are used only as visual discipline:

| Grafana anchor | EFHC use |
|---|---|
| `Sparkline/Sparkline.tsx` | compact line chart discipline |
| `Sparkline/utils.ts` | normalization idea only |
| `Table/Cells/SparklineCell.tsx` | table-cell chart reference |
| `TimeSeriesPanel.tsx` | future full chart discipline |
| `TrendPanel.tsx` | future trend-panel discipline |
| `XYChartPanel.tsx` | future relationship chart discipline |
| `StatusHistoryPanel.tsx` | activity strip discipline |
| `StateTimelinePanel.tsx` | future timeline discipline |

No Grafana source code is copied.

## Safety boundaries

- Economy changed: no.
- Backend contracts changed: no.
- DB migrations changed: no.
- CI/workflows/lock files changed: no.
- New dependencies added: no.
- Runtime code copied from Grafana: no.
- Runtime code copied from Песочница: no.
