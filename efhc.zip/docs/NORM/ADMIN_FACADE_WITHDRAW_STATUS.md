# Admin facade withdraw status

Cycle 1533 closes the dead-code facade drift findings:

- `P2-DEAD-CODE-ADMIN-FACADE-APPROVE-WITHDRAW`
- `P2-DEAD-CODE-ADMIN-FACADE-REJECT-WITHDRAW`

Decision: keep the facade compatibility methods, but align them with the
current `WithdrawalsService` contracts.

Current status:

- `admin_approve_withdraw` passes `withdrawal_id`, `req` and `admin`.
- `admin_reject_withdraw` requires explicit `idempotency_key` and passes
  `withdrawal_id`, `reason`, `idempotency_key` and `admin`.
- Real admin routes remain unaffected and continue to call
  `WithdrawalsService` directly.

Guard:

- `tests/architecture/test_admin_facade_withdraw_contract.py`
