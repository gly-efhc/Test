## Цикл 1746 — Admin audit и transaction boundary

PAID/REJECTED и финансовый repair обязаны сохранить money/status, `AdminLogger.write(required=True)` и notification/outcome outbox до одного root commit. Telegram/network delivery выполняется только после успешного commit и не может определять успех финансовой transaction.

Это уточнение **не** вводит обязательный blockchain watcher proof, отдельную settlement FSM или обязательный `tx_hash` для каждого V1 `PAID`; ранее утверждённая V1 payout semantics сохраняется.


# Withdraw audit canon

Статус: active V1 audit canon.
Режим: audit guard, без изменения бизнес-логики.

## Purpose

Документ задаёт правила будущей проверки withdraw-flow. Проверка должна
идти от канона проекта, а не от внешней предпосылки о том, какой должна
быть банковская settlement-модель.

## Canon rule

Аудитор не должен классифицировать отсутствие отдельного backend
blockchain watcher proof как P0/P1 для EFHC Bot V1, если withdraw request
закрывается через утверждённый admin/operator payout-flow.

В EFHC Bot V1 статус `PAID` после admin/operator payout action является
ожидаемым поведением.

Любой аудит, требующий обязательную blockchain settlement FSM, обязан
сначала доказать, что такая FSM является частью текущего канона проекта.

Если такой нормы в проекте нет, требование settlement FSM считается
внешней предпосылкой аудитора, а не дефектом кода.

## Valid V1 payout signal

`wallet_send_confirmed=true` является допустимым V1 payout signal, если
он получен через разрешённый admin/operator payout-flow.

Этот сигнал не обязан быть отдельным blockchain watcher proof.

## payout_ref rule

`payout_ref` является operational reference на payout action.

`payout_ref` не обязан быть blockchain proof и не должен трактоваться как
обязательный `tx_hash`.

## Negative audit guard

Нельзя классифицировать как P0/P1 то, что EFHC Bot V1 не требует:

- mandatory `PAYOUT_CONFIRMING`;
- mandatory `PAYOUT_CONFIRMED`;
- mandatory `FAILED_SEND`;
- mandatory `RETRY_PENDING`;
- mandatory `REFUND_REQUIRED`;
- mandatory `tx_hash` for every `PAID`;
- mandatory backend watcher proof for every `PAID`.

Такие требования допустимы только как proposal для будущего V2, если
отдельно создан новый SSOT/NORM и отдельный controlled implementation
cycle.

## Reservation audit-event separation

The payout trail keeps distinct durable meanings and must not collapse them into one event:
1. `WITHDRAWAL_PAYOUT_ATTEMPT_RESERVED` — durable reservation/attempt start;
2. `WITHDRAWAL_WALLET_SEND_CONFIRMED` — approved wallet transport reported a successful Send;
3. `WITHDRAWAL_PAID` — final financial/status state committed.

The literal UI click is not itself a financial commit. Required audit persistence failure before the financial commit remains fail-closed. Financial state/outcome persistence precedes external notification delivery; notification/network delivery cannot define transaction success.

Current verified authority does not certify an automatic outgoing-withdrawal chain watcher/reconciler. Therefore ambiguous post-reservation state may remain `PENDING` for operator reconciliation; absence of automatic on-chain finality must not trigger automatic resend/refund or promotion of `boc/traceId` to canonical `tx_hash`.
