
# Withdraw audit canon

Статус: active V1 audit canon.
Режим: audit guard, без изменения бизнес-логики.

## Purpose

Документ задаёт правила будущей проверки withdraw-flow. Проверка должна
идти от канона проекта, а не от внешней предпосылки о том, какой должна
быть банковская settlement-модель.

## Canon rule

Аудитор не должен классифицировать отсутствие отдельного backend
blockchain watcher proof как P0/P1 для EFHC Bot V1, если withdraw request
закрывается через утверждённый admin/operator payout-flow.

В EFHC Bot V1 статус `PAID` после admin/operator payout action является
ожидаемым поведением.

Любой аудит, требующий обязательную blockchain settlement FSM, обязан
сначала доказать, что такая FSM является частью текущего канона проекта.

Если такой нормы в проекте нет, требование settlement FSM считается
внешней предпосылкой аудитора, а не дефектом кода.

## Valid V1 payout signal

`wallet_send_confirmed=true` является допустимым V1 payout signal, если
он получен через разрешённый admin/operator payout-flow.

Этот сигнал не обязан быть отдельным blockchain watcher proof.

## payout_ref rule

`payout_ref` является operational reference на payout action.

`payout_ref` не обязан быть blockchain proof и не должен трактоваться как
обязательный `tx_hash`.

## Negative audit guard

Нельзя классифицировать как P0/P1 то, что EFHC Bot V1 не требует:

- mandatory `PAYOUT_CONFIRMING`;
- mandatory `PAYOUT_CONFIRMED`;
- mandatory `FAILED_SEND`;
- mandatory `RETRY_PENDING`;
- mandatory `REFUND_REQUIRED`;
- mandatory `tx_hash` for every `PAID`;
- mandatory backend watcher proof for every `PAID`.

Такие требования допустимы только как proposal для будущего V2, если
отдельно создан новый SSOT/NORM и отдельный controlled implementation
cycle.
