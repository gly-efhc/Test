# ТЕКУЩИЙ OWNER OVERRIDE — ZIP-FIRST / corrective cycle 1849

- Test layer не является business SSOT.
- Если текущая правка непосредственно меняет guarded contract, stale test/guard source может быть синхронизирован в том же recovery; security/financial invariant ради GREEN не ослабляется.
- **Запуск** тестов не является обязательным условием упаковки Development ZIP.
- Абсолютный порядок: законченная безопасная реализация → минимальный governance/report → physical ZIP → только затем optional targeted checks.
- Full pytest/Ruff/Mypy/Flake8/Bandit/frontend build/PostgreSQL/Alembic qualification запрещены без прямого OWNER-разрешения.
- Любой более старый текст, который требует обязательного test execution / tests-before-ZIP, superseded этим OWNER override. Исторические записи сохраняются только как provenance.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

## Уточнение 2026-08-20 — owner frontend patch и same-iteration test sync

## ТЕКУЩИЙ ANTI-STALE ПРИМЕР — CI 89770160061 / cycle 1830

- Agent-skills guard ожидал старый English compatibility literal, хотя active document-language authority требует русскую описательную формулировку. Исправлен сам compatibility checker/test fixture на эквивалентный русский anchor; AGENTS не возвращён к запрещённой English prose.
- Frontend reconciliation guard ожидал stale magic count `33`; после OWNER CANON `16 FAQ + 16 locale + 3 base` правильный checked-in release-assets count равен `35`. Test приведён к вычисляемому contract `3 + len(RUNTIME_LANGS) + len(FAQ_LANGS)`.
- Product/financial/security invariants ради GREEN не ослаблялись.


## ТЕКУЩИЙ OWNER NORM — cycle 1829 / unfinished markers только в коде

- `TODO`, `FIXME`, `TBD`, `STUB`, `NotImplementedError` и сходные implementation markers контролируются только в shipping source-code scope, определённом соответствующим guard.
- Human-readable documents, reports и localized FAQ не являются code scope такого guard.
- Обычные слова естественного языка, включая Portuguese `todo`, в документах/FAQ разрешены и не должны переписываться ради code-marker regex.
- Если test расширяет unfinished-marker scan на документы, такой test является Anti-Stale относительно этого OWNER NORM и должен быть сужен; shipping-code fail-closed контроль сохраняется.


- При принятии owner-approved frontend patch все затронутые frontend tests/guards обязаны быть пересмотрены в той же итерации.
- Test, который проверяет superseded implementation shape patch-а и не защищает более высокий financial/security/business invariant, переписывается под current observable contract либо удаляется при высокой уверенности.
- Оставлять заранее известный stale frontend expectation до следующего CI запрещено.
- Подтверждённый frontend defect исправляется в source сразу; functional/visual product change без owner decision не маскируется как «исправление теста».

# TEST AUTHORITY / ANTI-STALE CONTRACT

Статус: **ACTIVE OWNER NORM**  
Дата решения владельца: **2026-08-19**  
Scope: весь активный test/qualification layer EFHC Bot.

## 1. Иерархия authority

Тест не является SSOT и не определяет продуктовый смысл самостоятельно.

Обязательная цепочка:

```text
последнее прямое OWNER DECISION
→ active CANON / SSOT / NORM
→ production runtime invariant
→ architecture / regression guard
→ test expectation
```

Если test expectation противоречит более высокому уровню authority, stale expectation обновляется или удаляется в той же итерации. Правильный production runtime запрещено откатывать только ради прохождения такого теста.

## 2. Что тест обязан защищать

Активный тест должен защищать хотя бы один действующий invariant:

1. финансовый или экономический invariant;
2. security/authentication/authorization invariant;
3. transaction/idempotency/replay/temporal invariant;
4. действующий API/business contract;
5. schema/release invariant, прямо закреплённый CANON/NORM;
6. observable behavior пользователя;
7. доказанную compatibility boundary, которая ещё является active contract.

Для P0 financial/security invariants тесты остаются fail-closed и не ослабляются ради удобства разработки.

## 3. Что не является допустимым development lock

Запрещено блокировать корректную разработку только потому, что тест фиксирует:

- точное текущее количество routes/operations/schemas/test files;
- точное количество тестовых функций в другом файле;
- historical version/cycle count как будто это продуктовый invariant;
- буквальную форму исходного кода, если сама форма не является security/financial invariant;
- удалённый compatibility seam после официального завершения compatibility;
- superseded UI/API/business behavior;
- вторую копию финансовой формулы или иного CANON внутри test-only implementation.

Точные количества допустимы только для конечного продуктового множества, которое само закреплено CANON, например действующий набор 13 release locales или frozen migration set.

## 4. Классификация RED

Перед изменением runtime каждый RED классифицируется как одно из:

- `RUNTIME_DEFECT` — runtime нарушает более высокий authority/invariant;
- `STALE_TEST` — test expectation относится к superseded contract;
- `QUALIFICATION_DRIFT` — manifest/generator/docs/guard не синхронизированы с действующим contract;
- `TOOLING_DEFECT` — lint/type/build/release tooling defect без изменения business semantics;
- `UNKNOWN` — данных недостаточно; runtime не меняется до доказательства.

Количество упавших тестов не равно количеству root causes.

## 5. Правило удаления stale tests

Тест или его часть удаляется, если одновременно доказано, что:

- он не защищает active financial/security/business invariant;
- его expectation superseded прямым owner decision или active CANON/NORM;
- либо он дублирует уже существующий canonical behavior/invariant test и добавляет только implementation freeze.

Если старый тест содержал полезный invariant, удаляется только stale часть, а invariant сохраняется behavioral/contract проверкой.

Удаление теста не используется как способ скрыть реальный runtime defect.

## 6. Mutable surface counts

Для развивающихся поверхностей запрещены exact equality locks вида:

```text
len(routes) == N
len(operations) == N
len(schemas) == N
len(tests) == N
```

Вместо этого использовать:

- set/parity comparison с authoritative generated/current source;
- required subset/invariant presence;
- monotonic minimum только если он защищает от случайного удаления и не запрещает расширение.

## 7. Generated artifacts

Generator и generated artifact проверяются на взаимную воспроизводимость и canonical contract. Нельзя поддерживать отдельную ручную копию того же API/business contract внутри тестов.

## 8. Compatibility tests

Compatibility test обязан иметь active compatibility boundary. Если boundary сохранён, тест адаптируется к текущему canonical signature. Если compatibility официально завершена, test удаляется вместе с retired boundary по отдельному доказанному scope.

## 9. Обязательное правило итерации

При owner-approved изменении CANON/runtime в той же итерации должны быть просмотрены связанные tests/guards/generators. Stale expectation обновляется или удаляется до упаковки candidate, чтобы следующий CI проверял новый смысл, а не предыдущую архитектуру.

## 10. Машинная защита

`scripts/ci/check_test_authority.py` запрещает известные brittle exact-count patterns для mutable test/API surface. `scripts/ci/check_test_suite_integrity.py` включает этот guard в structural qualification.

Этот guard не заменяет содержательную проверку финансовых/security invariants и не имеет права ослаблять их.

## 11. Порог доказательства перед удалением stale test — owner clarification 2026-08-20

Owner-Decision-Ref: `QA-2026-08-20-TESTAUTH-02`.

Удаление test разрешено только при **высокой уверенности**, что он больше не защищает действующий invariant. Обязательная проверка перед удалением:

1. latest direct OWNER DECISION;
2. active CANON/SSOT/NORM;
3. фактический current runtime invariant;
4. назначение test/guard и возможность того, что он защищает P0/P1 financial/security/business property.

Если после этой сверки остаётся сомнение, test **не удаляется**. Конфликт фиксируется и выносится владельцу. Anti-Stale policy запрещает массовое удаление tests только потому, что они мешают текущему patch или требуют обновления.

Проверка against current canon является основным способом доказать stale status. Tests реального финансового, security, authorization, idempotency, transaction или ledger invariant сохраняются fail-closed до отдельного owner decision.
