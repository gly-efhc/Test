# Frontend Owner Q&A Register

**Scope:** frontend-only owner decisions that are still required by active regression/CANON. Backend/main-project Q&A is intentionally excluded.

## FRONTEND Admin Modules — Module 01 «Пользователи»

### QA-2026-08-17-ADM-M01-01
Global ID is the primary operator identity. The selected user opens in a ready user-like Admin shell.

### QA-2026-08-17-ADM-M01-02
Ordinary Users UI is not an account-control surface and **не получает доступ к аккаунту пользователя**. No impersonation; panel deactivation is not exposed here.

### QA-2026-08-17-ADM-M01-03
Bulk VIP/NFT operations are not per-user controls.

### QA-2026-08-17-ADM-M01-04
Useful lifecycle metadata may be shown read-only and compactly.

### QA-2026-08-17-ADM-M01-05
Provider-linked lookup is approved. Where the exact resolver was absent historically, the **backend extension is recorded for the later production patch** rather than simulated in production.

### QA-2026-08-17-ADM-M01-06
One canonical History view is used for selected-user financial/activity verification; no duplicate mini-ledgers.

### QA-2026-08-17-ADM-M01-07
Profile needs Global ID, username, balances, kWh, panels, VIP and useful dates; user-facing visual primitives may be reused.

### QA-2026-08-17-ADM-M01-08
History is a read-only selected-user view; it does not impersonate the user session.

### QA-2026-08-17-ADM-M01-09
Reuse the existing History filters; do not invent a second filter model in Users.

### QA-2026-08-17-ADM-M01-10
Compact `Activ` and `VIP` status indicators are allowed and reflect live selected-user state.

### QA-2026-08-17-ADM-M01-11
Paid panel activation is an approved selected-user financial action; no extra fields are required.

### QA-2026-08-17-ADM-M01-12
No separate Deposits/Withdrawals/Transfers tables inside Users; use canonical History plus agreed targeted funds operations.

### QA-2026-08-17-ADM-M01-13
Providers is a secondary lookup surface; default Users entry remains one Global ID field.

### QA-2026-08-17-ADM-M01-14
Provider lookup resolves zero or one canonical Global ID; no multi-account picker.

### QA-2026-08-17-ADM-M01-15
Human Users UI exposes only agreed data/functions, not technical account-control routes.

### QA-2026-08-17-ADM-M01-16
Approved base composition: Global ID → selected profile → balances/statuses → Funds/History/Providers → paid panel activation.

### QA-2026-08-17-ADM-M01-20
Users follows **Profile geometry** and header-style `Activ`/`VIP` status language.

### QA-2026-08-17-ADM-M01-21
Use the canonical **Profile composition** instead of a separate hand-built Admin user card.

### QA-2026-08-17-ADM-M01-22
Selected-user History uses the **same banking History presentation component** with Admin-selected Global ID data.

### QA-2026-08-17-ADM-M01-23
Canonical `← Назад` and Android/browser Back preserve Admin hierarchy.

## FRONTEND Admin Modules — Module 06 «Задания»

**Cycle authority:** `FRONTEND_ADMIN_CYCLE_0016–0017`.

### QA-2026-08-19-ADM-M06-01 — automatic-only task model
Owner approved only automatically verifiable production tasks. Manual proof/submission moderation is not part of the human Module 06 surface.

### QA-2026-08-19-ADM-M06-02 — task families
Admin should support Telegram group/channel membership, connected advertising providers, partner Telegram bots/WebApps, external social actions where an official automatic verifier exists, and similar automatically verifiable tasks.

### QA-2026-08-19-ADM-M06-03 — Telegram verification
The EFHC bot in the target Telegram group/channel is the verification authority. If a required production verifier route is not exposed by the current backend contract, frontend must fail closed and must not simulate it in production.

### QA-2026-08-19-ADM-M06-04 — reward authority
Admin sets the exact D8 EFHCb reward for each task.

### QA-2026-08-19-ADM-M06-05 — limits
Ordinary tasks default to one completion per user. Global task limit is visible in Admin; when server authority reports it exhausted the task must be inactive/hidden from the user catalogue. Frontend must not invent the backend state transition.

### QA-2026-08-19-ADM-M06-06 — advertising limits
An advertising task is bound to one selected configured provider and defaults to 10 successful views per user per day. Multiple providers are represented by independent tasks. After the daily limit, user UI shows localized `Приходи завтра` semantics in all 13 locales; the advertising task remains available on following days.

### QA-2026-08-19-ADM-M06-07 — user states
Normal owner-visible task state is `Доступно → Выполнено`; advertising adds the daily-limit state `Приходи завтра`.

### QA-2026-08-19-ADM-M06-08 — no manual retry/reject flow
Manual proof, rejection and resubmission are not currently part of the product model.

### QA-2026-08-19-ADM-M06-09 — Admin composition
Module 06 is a user-page-oriented task editor with live preview/edit mode and aggregate task statistics. It is not a list of users who completed tasks.

### QA-2026-08-19-ADM-M06-10 — visible editor fields
Primary fields: task name, optional description, task/link target, automatic verification method, exact EFHCb reward, advertising provider where applicable, per-user/default limit, optional global total limit and active state. Technical proof fields are removed from the human editor.

### QA-2026-08-19-ADM-M06-11 — statistics
Show useful aggregate per-task statistics such as status, type, reward, completed total and remaining global limit where the exact backend contract supplies them. Do not show unique-user counts or user/submission lists. Do not synthesize unavailable `today`/payout aggregates in production.

### QA-2026-08-19-ADM-M06-12 — partner onboarding
Partner WebApp/bot actions should have a simple structured draft configuration (partner, target/action, verifier capability). Activation is allowed only when a real automatic server verification contract exists; no frontend-only callback/business-semantic simulation in production.

### QA-2026-08-19-ADM-M06-13 — advertising backend
Current backend AdManager is the production authority for provider selection, verification and daily-view enforcement. Admin Tasks selects from configured provider inventory; provider API credentials/configuration remain in the Ads module.

### QA-2026-08-19-ADM-M06-14 — standalone
Standalone HTML keeps the independent DEMO simulator behind the same route gateway. DEMO may exercise automatic task states/data; DIRECT mode calls canonical backend routes and must fail closed when a server verifier contract is absent.

### QA-2026-08-19-ADM-M06-15 — no operational queue
Task submissions/execution trace may remain historical/technical compatibility evidence, but they are not part of the owner-facing Module 06 workflow unless a later owner decision restores them.


## FRONTEND Admin Modules — Module 09 «Панели» — owner redesign v170

**Current authority:** this section is the complete active Q&A record for Admin Panels. Historical source documents are not required for ordinary work.

### QA-2026-08-20-ADM-M09-01
Admin Panels repeats the accepted Bank composition language: analytics first, controls below, CSV/XLSX export last.

### QA-2026-08-20-ADM-M09-02
No single central KPI. This supersedes the earlier ambiguous answer; use the approved ordered KPI set.

### QA-2026-08-20-ADM-M09-03
Top KPI order is Active panels; Completed/deactivated economic panels; New obligations; Net spent EFHCm+EFHCb on all panels; Converted kWh→EFHCm; Total generated kWh.

### QA-2026-08-20-ADM-M09-04
Graph 1 shows only the final New obligations value; do not show the 100×N baseline.

### QA-2026-08-20-ADM-M09-05
Graphs have no owner-visible series checkboxes.

### QA-2026-08-20-ADM-M09-06
Do not present New obligations minus Converted as a remaining-liability figure; the timing semantics differ.

### QA-2026-08-20-ADM-M09-07
No separate fleet-state summary block is authorized.

### QA-2026-08-20-ADM-M09-08
Normal economic population for New obligations is all already deactivated Panels regardless of deactivation reason; protectively voided Panels are excluded by QA-18.

### QA-2026-08-20-ADM-M09-09
Below analytics provide Global ID / Panel ID search, real Panel cards and authorized deactivation action placement.

### QA-2026-08-20-ADM-M09-10
Panel logs remain at the bottom in CSV and XLSX.

### QA-2026-08-20-ADM-M09-11
Final authority: no separate central KPI; preserve ordered indicators.

### QA-2026-08-20-ADM-M09-12
Panel spend KPI means EFHCm + EFHCb, not EFHCm + EFHCm.

### QA-2026-08-20-ADM-M09-13
New-obligation population is deactivated Panels, not active Panels and not only 180-day expiries; protective voids are excluded.

### QA-2026-08-20-ADM-M09-14
Panel spend is all-time actual successful Panel spend across active/deactivated Panels minus refunds/cancellations.

### QA-2026-08-20-ADM-M09-15
New-obligation graph uses only Σ generated_kwh of economic deactivated Panels − 100.00000000 × their count.

### QA-2026-08-20-ADM-M09-16
Search results reuse the real application Panel-card family and add Deactivate; Global ID or Panel ID are the approved search keys.

### QA-2026-08-20-ADM-M09-17
Protective deactivation uses gross refund `100.00000000 EFHC`, but current net refund is `NET = 100.00000000 - R`, where `R` is already-realized generation offset. The offset reduces the historical payment split first from EFHCb and then from EFHCm; it is not charged again from current balances and never creates debt.

### QA-2026-08-20-ADM-M09-18
Protective deactivation preserves Panel number/history, sets `generated_kwh = 0.00000000` and marks the row `protectively_voided=true` / human state `Мёртвая`. The voided Panel is excluded from ordinary Active/Archive and economic aggregates until an Admin reactivates the same Panel ID with a new real 100 EFHC purchase.

### QA-2026-08-20-ADM-M09-19
Global ID returns all that user’s Panel cards; Panel ID returns one concrete card.

## FRONTEND Admin Modules — Module 11 «Выдача / VIP NFT» — consolidated owner Q&A cycles 0050–0055

**Статус:** ACTIVE / DEDUPLICATION AUTHORITY. Перед новыми вопросами по Shop/VIP/NFT оператор обязан проверить этот раздел и не задавать уже решённый вопрос повторно.

### QA-2026-08-23-ADM-M11-01 — public Shop route
**Вопрос:** где должна жить публичная Shop surface и как её открывать из Telegram WebApp?  
**Ответ владельца:** `/browser-shop` на основном EFHC web-домене. В Telegram WebApp: signed handoff и открытие только во внешнем браузере. В обычном Web EFHC: переход в Shop в текущем web browser context. HUB никогда не рендерит Shop внутри себя или Telegram WebView.

### QA-2026-08-23-ADM-M11-02 — GetGems
**Вопрос:** оставлять ли отдельный GetGems путь?  
**Ответ владельца:** да. `https://getgems.io/efhc-nft` — рабочая каноническая коллекция и отдельная Hub-ссылка; не смешивать её с EFHC Shop checkout.

### QA-2026-08-23-ADM-M11-03 — fixed EFHC packages
**Вопрос:** какие номиналы EFHC packages доступны в Shop?  
**Ответ владельца / current CANON:** fixed package set is `10 / 50 / 100 / 150 / 200 / 250 / 300 / 350 / 500 / 750 / 1000 EFHCm`; additionally there is `Свободный выбор EFHCm` and one `EFHC VIP NFT`, for 13 owner-visible Shop positions total.

### QA-2026-08-23-ADM-M11-04 — Shop prices
**Вопрос:** откуда берутся цены товаров?  
**Ответ владельца:** цены выставляет Admin Panel. Browser Shop external business-price boundary остаётся D2.

### QA-2026-08-23-ADM-M11-05 — canonical VIP product
**Вопрос:** как называется VIP товар?  
**Ответ владельца:** `EFHC VIP NFT`; это одна generic product position, конкретный NFT выбирает Admin после оплаты.

### QA-2026-08-23-ADM-M11-06 — payment matrix
**Вопрос:** какими активами оплачиваются товары?  
**Ответ владельца:** EFHC packages = TON/GRAM + USDT; EFHC VIP NFT = TON/GRAM + USDT + internal EFHC.

### QA-2026-08-23-ADM-M11-07 — account/wallet gate before VIP purchase
**Вопрос:** когда нужен TON-кошелёк?  
**Ответ владельца:** до оплаты VIP NFT. Покупка выполняется в контексте Global ID/account и TON identity/binding.

### QA-2026-08-23-ADM-M11-08 — TON identity, do not ask again
**Вопрос:** что происходит при входе новым или уже известным TON-кошельком?  
**Ответ владельца:** новый подтверждённый `ton_wallet_id`, которого ещё нет в системе identity, создаёт новый `global_id`/account через canonical TON provider login; уже зарегистрированный TON wallet разрешается в существующий `global_id`. Это также физически закреплено в `docs/SSOT/WALLET_IDENTITY_SSOT.md`. Один TON wallet не принадлежит двум Global ID.

### QA-2026-08-23-ADM-M11-09 — delivery wallet selection/default
**Вопрос:** на какой кошелёк выдавать VIP NFT?  
**Ответ владельца:** пользователь может выбрать привязанный кошелёк. Если выбора нет, для external TON/USDT по умолчанию используется кошелёк оплаты; для internal EFHC по умолчанию используется кошелёк привязки аккаунта. Пользователь потом сам может переслать NFT куда ему нужно.

### QA-2026-08-23-ADM-M11-10 — Admin wallet display
**Вопрос:** показывать ли в Admin одновременно payer wallet и delivery wallet?  
**Ответ владельца:** нет. В человеческой карточке показывать только **кошелёк выдачи VIP NFT**. Payer/order/verified могут быть техническим источником вычисления адреса, но не отдельными owner-visible строками.

### QA-2026-08-23-ADM-M11-11 — immutable order snapshot target
**Вопрос:** должен ли выбранный delivery wallet быть snapshot конкретной покупки?  
**Ответ владельца:** да, когда backend физически поддерживает такое поле. Последующая смена primary wallet не должна менять уже сохранённый адрес конкретного заказа. До появления exact backend persistence frontend не симулирует запись поля.

### QA-2026-08-23-ADM-M11-12 — missing explicit destination
**Вопрос:** блокировать ли оплаченный заказ, если пользователь не ввёл отдельный delivery wallet?  
**Ответ владельца:** нет. Отдельный ввод не обязателен: действует default wallet rule из QA-M11-09. Для internal EFHC это привязанный wallet аккаунта; для external payment — wallet оплаты, если отдельного выбора не было.

### QA-2026-08-23-ADM-M11-13 — Admin issuance minimum data
**Вопрос:** какие данные обязательны в карточке выдачи?  
**Ответ владельца:** минимум Global ID покупателя, цена покупки и полный TON-кошелёк выдачи. Отдельный payment-wallet field на экране не нужен.

### QA-2026-08-23-ADM-M11-14 — queue UX
**Вопрос:** как должна открываться очередь `Выдача / VIP NFT`?  
**Ответ владельца:** как `Выплаты`: список заявок находится сверху; клик по заявке открывает отдельное окно решения/карточку, а не прячет очередь под аналитикой.

### QA-2026-08-23-ADM-M11-15 — queue order
**Вопрос:** в каком порядке показывать ожидающие заявки?  
**Ответ владельца:** FIFO — **самая старая оплаченная заявка сверху**.

### QA-2026-08-23-ADM-M11-16 — purchase recognition
**Вопрос:** что является authority факта покупки?  
**Ответ владельца/active CANON:** external TON/USDT подтверждает backend PaymentIntent watcher/reconciliation; internal EFHC — canonical Bank debit. Frontend polling не является authority покупки.

### QA-2026-08-23-ADM-M11-17 — paid status/manual issue
**Вопрос:** что происходит после подтверждения оплаты VIP NFT?  
**Ответ владельца:** ShopOrder переходит в `PAID_PENDING_MANUAL`; Admin вручную выбирает конкретный NFT, отправляет его on-chain на кошелёк выдачи и фиксирует результат.

### QA-2026-08-23-ADM-M11-18 — VIP entitlement
**Вопрос:** когда аккаунт получает VIP и влияет ли незакрытый Admin order?  
**Ответ владельца:** `is_vip` определяется автоматически фактическим владением canonical VIP NFT на active verified wallets аккаунта. Если ownership checker уже видит NFT, VIP может быть активен до ручного закрытия ShopOrder.

### QA-2026-08-23-ADM-M11-19 — multiple NFTs
**Вопрос:** суммируются ли привилегии от двух VIP NFT на одном аккаунте?  
**Ответ владельца:** нет. Второй NFT не усиливает привилегии того же аккаунта; его можно использовать на другом аккаунте после соответствующей wallet/account binding и ownership detection.

### QA-2026-08-23-ADM-M11-20 — support/disputes
**Вопрос:** нужен ли сейчас отдельный support CTA/refund workflow?  
**Ответ владельца:** отдельную кнопку пока не делать. Спорные случаи решаются вручную через существующую техподдержку; отдельный UI будет будущим scope.

### QA-2026-08-23-ADM-M11-21 — delivery tx hash
**Вопрос:** должен ли `delivery_tx_hash` быть обязательным owner field?  
**Ответ владельца:** отдельного требования сделать его обязательным не утверждено. Current contract допускает optional hash; обязательные human данные карточки определены QA-M11-13. Не задавать этот вопрос повторно без новой конкретной backend/аудит необходимости.

### QA-2026-08-23-ADM-M11-22 — current backend tail
**Вопрос:** может ли текущий frontend гарантированно сохранить выбранный/default delivery wallet в ShopOrder?  
**Ответ:** нет по physical current contract: `BrowserShopCreateIntentRequest` и internal EFHC purchase request не содержат подтверждённого outbound `delivery_wallet_address`. Frontend обязан читать exact order/payer snapshot, если backend его вернёт, и иначе применять разрешённый account-wallet fallback без заявления о server-side persistence.

## FRONTEND Admin Modules — sparse analytics Q&A cycles 0052–0053

### QA-2026-08-23-ADM-SPARSE-01
**Вопрос:** что показывать в `Рефералы`?  
**Ответ владельца:** только exact Global ID → сколько пригласил, Lvl, сколько бонусов получил; downloadable таблица одного пользователя. `active/inactive` нужны как технические CSV columns для расследования бонуса, но не как экранные карточки.

### QA-2026-08-23-ADM-SPARSE-02
**Вопрос:** дополнительно упрощать `Аналитику начислений`?  
**Ответ владельца:** нет. Сохранять подробные source/period/custom-date/Global-ID фильтры и добавить CSV/XLSX выбранного Global ID.

### QA-2026-08-23-ADM-SPARSE-03
**Вопрос:** как экспортировать `Отчёты и журналы`?  
**Ответ владельца:** применять текущие фильтры. По существующему contract system logs используют source/severity/time; Global ID остаётся отдельным user-history lookup, без fake backend filter.

### QA-2026-08-23-ADM-SPARSE-04
**Вопрос:** распространять sparse-list doctrine на Orders/Deposits/Withdrawals?  
**Ответ владельца:** нет; там массовые списки — рабочие очереди.

### QA-2026-08-23-ADM-SPARSE-05 — current regression authority
**Вопрос:** какой regression contour является обязательным после OWNER-approved governance cleanup?  
**Ответ владельца / current process law:** active authority is the current non-versioned regression suite routed by Kernel. Historical 136-function/versioned guard baseline больше не является default authority и не может расширять scope без прямого OWNER audit instruction.

## FRONTEND Admin Modules — Module 11 «Выдача / VIP NFT» — вопросы на продолжение цикла 0055

**Статус:** RESOLVED в owner instruction цикла 0056. Записи сохранены под теми же ID; семантические дубли не создавать.

### QA-2026-08-23-ADM-M11-23 — next request after decision
**Вопрос:** после подтверждения выдачи/отклонения и закрытия окна автоматически открывать следующую самую старую ожидающую заявку или возвращать Admin в очередь без автооткрытия?  
**Ответ владельца:** после решения автоматически открыть следующую самую старую ожидающую заявку, если она есть. Новое окно можно просто закрыть без решения. Заказы редкие, поэтому auto-open предпочтителен.

### QA-2026-08-23-ADM-M11-24 — queue search
**Вопрос:** добавить ли в очередь `Выдача / VIP NFT` поиск по `Global ID` и/или `ShopOrder ID`, сохранив FIFO как основной порядок очереди?  
**Ответ владельца:** да. Добавить поиск по Global ID и ShopOrder ID для расследования случаев, когда NFT не пришёл. FIFO остаётся основным порядком очереди.

### QA-2026-08-23-ADM-M11-25 — issued/rejected read-only detail
**Вопрос:** для уже выданных/отклонённых заявок оставлять открываемое read-only окно с данными решения и кошельком выдачи или достаточно строки в отфильтрованной очереди?  
**Ответ владельца:** да. Выданные/отклонённые заявки должны открываться read-only для аудита, поиска и проверки.

### QA-2026-08-23-ADM-M11-26 — VIP issuance audit export
**Вопрос:** нужен ли отдельный CSV/XLSX export журнала `Выдача / VIP NFT` с полями `order id / Global ID / цена / кошелёк выдачи / статус / timestamps`?  
**Ответ владельца:** да. Нужен отдельный CSV/XLSX журнал выдачи VIP NFT.

### QA-2026-08-23-ADM-M11-27 — queue age indicator
**Вопрос:** показывать ли в ожидающей очереди возраст заявки (`ждёт N минут/часов/дней`) рядом со временем оплаты, чтобы Admin видел просроченные ручные выдачи?  
**Ответ владельца:** да. Показывать возраст заявки рядом со временем оплаты.

## FRONTEND Admin Modules — Module 11 «Выдача / VIP NFT» — вопросы на продолжение цикла 0056

**Статус:** RESOLVED в owner instructions циклов 0057. Записи сохранены под теми же ID; семантические дубли не создавать.

### QA-2026-08-23-ADM-M11-28 — total counter semantics
**Вопрос:** `Всего заявок` должен считать только оплаченные/обработанные issuance-заявки (`PAID_PENDING_MANUAL / APPROVED / REJECTED`) или также неоплаченные `PENDING` VIP ShopOrder, если backend когда-нибудь вернёт их в этом endpoint?
**Ответ владельца:** Неоплаченного ShopOrder нет и быть не должно. До подтверждения оплаты существует только PaymentIntent. В `Всего заявок`, очереди, поиске и журнале `Выдача / VIP NFT` учитываются только реально оплаченные/обработанные issuance-records: `PAID_PENDING_MANUAL / APPROVED / FULFILLED / REJECTED`.

### QA-2026-08-23-ADM-M11-29 — search matching mode
**Вопрос:** поиск по Global ID / ShopOrder ID делать только точным совпадением или оставить удобный частичный поиск по введённому фрагменту?
**Ответ владельца:** Оставить частичный поиск. Это substring-поиск: достаточно ввести известный фрагмент Global ID или ShopOrder ID; пробелы по краям игнорируются, регистр не важен.

### QA-2026-08-23-ADM-M11-30 — audit export scope
**Вопрос:** кнопки CSV/XLSX по умолчанию должны скачивать полный журнал всех VIP/NFT заявок или только текущий фильтр/результат поиска?
**Ответ владельца:** CSV/XLSX всегда скачивает весь журнал VIP/NFT, независимо от текущего экранного фильтра или поисковой строки, с явными отметками `НЕ ВЫДАНО / ВЫДАНО / ОТКАЗ`.

### QA-2026-08-23-ADM-M11-31 — age warning thresholds
**Вопрос:** возраст заявки оставить нейтральным текстом или добавить визуальные пороги внимания, например после 24 часов и после 72 часов?
**Ответ владельца:** Возраст заявки оставить обычным текстом без порогов 24/72 часа. Ожидающие, ещё не выданные заявки выделять зелёным; выданные и отклонённые оставлять обычным цветом.

### QA-2026-08-23-ADM-M11-32 — demo test-order lifecycle
**Вопрос:** 26 DEMO test orders для owner-review держать в standalone следующих релизов до отдельной команды удалить или убрать сразу после окончательной приёмки модуля 0056?
**Ответ владельца:** 26 DEMO test orders сохранять в standalone HTML для регулярной owner-проверки регрессий. Production frontend/source patch остаётся чистым и не содержит DEMO orders или DEMO Shop renderer.

## FRONTEND Admin Modules — Module 11 / HUB Shop — вопросы и ответы продолжения цикла 0057

**Статус:** RESOLVED. Эти ответы управляют standalone owner-review Shop; production `/browser-shop` остаётся каноническим внешним Shop.

### QA-2026-08-24-ADM-M11-33 — external checkout interaction
**Вопрос:** для TON/USDT показывать два owner-visible шага `Создать PaymentIntent` → `Подтвердить TON Connect/reconciliation` или один обычный checkout-action при сохранении двухфазности внутри simulation engine?
**Ответ владельца:** «Сделай как надо». Реализация: один понятный owner-visible `Оплатить`; внутри движка обязательно последовательно выполняются `create-intent → TON Connect/reconciliation → intent-status`. До reconciliation ShopOrder отсутствует.

### QA-2026-08-24-ADM-M11-34 — history detail after external package purchase
**Вопрос:** записывать ли в пользовательскую Историю одновременно внешний TON/USDT расход и EFHC зачисление?
**Ответ владельца:** нет. Достаточно существующей записи о зачислении EFHC; отдельную внешнюю платежную строку в пользовательскую Историю не добавлять.

### QA-2026-08-24-ADM-M11-35 — price snapshot after intent creation
**Вопрос:** если Admin изменил цену после создания PaymentIntent, сохраняет ли уже созданный intent старую цену до expiry?
**Ответ владельца:** да. PaymentIntent фиксирует price snapshot на момент создания; новые Admin цены применяются только к новым intents.

### QA-2026-08-24-ADM-M11-36 — separate Shop order history
**Вопрос:** нужен ли отдельный полный раздел «История заказов» внутри Shop?
**Ответ владельца:** нет. Достаточно существующей пользовательской Истории и Admin audit/Orders surfaces; отдельный Shop-history экран не создавать.

### QA-2026-08-24-ADM-M11-37 — simulation reset scope
**Вопрос:** как должен работать ручной reset simulation data относительно Admin Shop catalog/prices?
**Ответ владельца:** решение несущественно, можно выбрать безопасную реализацию. Текущий цикл не добавляет новый reset-контур и не меняет существующий cache/storage law.

## FRONTEND Admin Modules — Module 11 / HUB Shop — новые вопросы после цикла 0057

**Статус:** UNRESOLVED. Перед формулировкой следующих вопросов сначала проверить M11-01…37 и не создавать семантические дубли.

### QA-2026-08-24-ADM-M11-38 — post-VIP-purchase owner-review navigation
**Вопрос:** после успешной DEMO-покупки `EFHC VIP NFT` в standalone автоматически предлагать открыть Admin `Выдача / VIP NFT` для проверки новой заявки или оставаться в Shop без перехода?
**Ответ владельца:** RESOLVED — убрать верхнее повторение. В верхнем блоке «Энергетические модули» строка «Активация панели 100 EFHC» удаляется; цена остаётся в отдельном блоке «Активация панели».

### QA-2026-08-24-ADM-M11-39 — technical route ledger visibility
**Вопрос:** route-ledger `create-intent / reconciliation / intent-status` в standalone Shop держать всегда видимым для owner-аудита или свернуть в раскрываемый технический блок?
**Ответ владельца:** RESOLVED — убрать отдельную кнопку «Загрузить ещё» и оставить только автоматическую подгрузку при прокрутке.

### QA-2026-08-24-ADM-M11-40 — unavailable payment method presentation
**Вопрос:** если Admin не задал цену для TON или USDT, соответствующий способ оплаты показывать disabled с пометкой «цена не задана» или полностью скрывать?
**Ответ владельца:** RESOLVED — при переключении «Активные / Архив» новый список всегда открывается с самого верха. Только стрелка старые/новые меняет направление списка.

### QA-2026-08-24-ADM-M11-41 — expired PaymentIntent audit
**Вопрос:** нужен ли в standalone технический audit-list истёкших PaymentIntent, которые не создали ShopOrder, или достаточно route-ledger/текущего intent state?
**Ответ владельца:** RESOLVED — Theme 8 нужно переделать по аналогии с одним из нормальных существующих вариантов. Scope ограничен только блоком «Активные / Архив» и карточками панелей; верхний Panels hero и блок активации в этой задаче не менять.

### QA-2026-08-24-ADM-M11-42 — multiple VIP purchases by one Global ID
**Вопрос:** если один Global ID сделал несколько оплаченных VIP NFT покупок, в `Выдача / VIP NFT` держать каждую покупку отдельной заявкой или группировать их по пользователю?
**Ответ владельца:** UNRESOLVED.

## FRONTEND Admin Modules — Module 11 / Shop execution chain — новые вопросы после итерации v213

**Статус:** UNRESOLVED. Вопросы M11-43…47 прошли semantic duplicate check по M11-01…42, OWNER_DECISION, active CANON/SSOT и не заменяют существующие записи.

### QA-2026-08-23-ADM-M11-43 — concurrent Admin decision conflict
**Вопрос:** если два администратора одновременно открыли одну заявку и один уже принял решение, что должен увидеть второй: обновлённую завершённую заявку и следующую в очереди или только сообщение, что решение уже принято?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-23-ADM-M11-44 — wallet resolution source in audit export
**Вопрос:** нужно ли в выгружаемых CSV/XLSX указывать, откуда система взяла кошелёк выдачи: из заказа, из оплаты или из привязанного аккаунта?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-23-ADM-M11-45 — deciding Admin identity in terminal audit
**Вопрос:** нужно ли показывать в завершённой заявке и выгружаемых таблицах Global ID администратора, который выдал NFT или отказал?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-23-ADM-M11-46 — retry while PaymentIntent remains alive
**Вопрос:** если оплата TON/USDT не завершилась, но созданная заявка на оплату ещё действует, повторять оплату по ней же или создавать новую?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-23-ADM-M11-47 — insufficient internal EFHC next action
**Вопрос:** при недостаточном основном EFHC balance в Shop достаточно показать ошибку без ShopOrder или дополнительно дать прямое действие перехода к пополнению?
**Ответ владельца:** это не ошибка. Показать обычное сообщение `Недостаточно средств.` без дополнительного перехода к пополнению. ShopOrder не создаётся.

## FRONTEND Admin Modules — Module 11 / внешний Shop — ответы владельца цикла 0059

**Статус:** RESOLVED в прямом owner instruction цикла 0059. Записи M11-48…52 обновлены под теми же ID без создания смысловых дублей.

### QA-2026-08-24-ADM-M11-48 — обычный браузер: текущая или новая вкладка
**Вопрос:** когда пользователь открывает Магазин из HUB в обычном браузере, открывать его в новой вкладке или переходить в Магазин в текущей вкладке?
**Ответ владельца:** В текущем проверочном HTML выбор между текущей и новой вкладкой несущественен: выпускать отдельный готовый файл `SHOP_vNNN.html`. HUB открывает его отдельной страницей; production HUB по-прежнему ведёт на реальный `/browser-shop` browser-версии EFHC.

### QA-2026-08-24-ADM-M11-49 — пометка проверочной страницы
**Вопрос:** оставлять ли на отдельной проверочной странице заметную надпись «Проверочная версия», чтобы её нельзя было спутать с настоящим Магазином на VPS?
**Ответ владельца:** нет. Не показывать надпись «Проверочная версия»: отдельная страница Магазина является частью EFHC browser web version.

### QA-2026-08-24-ADM-M11-50 — временная недоступность Магазина
**Вопрос:** если настоящий Магазин временно недоступен, показывать только сообщение «Магазин временно недоступен» или также кнопку «Повторить»?
**Ответ владельца:** нет. Не добавлять специальную кнопку «Повторить»; использовать обычную обработку сообщения о недоступности.

### QA-2026-08-24-ADM-M11-51 — возврат из внешнего Магазина
**Вопрос:** нужна ли на настоящей странице Магазина заметная кнопка «Вернуться в EFHC», ведущая обратно в HUB?
**Ответ владельца:** нет. Кнопка «Вернуться в EFHC» не нужна, потому что внешняя страница Магазина сама является EFHC — частью browser web version, идентичной входу через Telegram Web App.

### QA-2026-08-24-ADM-M11-52 — номер заказа после оплаты
**Вопрос:** после подтверждённой оплаты показывать ли пользователю ShopOrder ID и отдельную кнопку его копирования?
**Ответ владельца:** да, желательно. После подтверждённой оплаты показывать `ShopOrder ID` и кнопку копирования.

## FRONTEND Admin Modules — Module 11 / отдельная страница Shop — ответы владельца цикла 0060

**Статус:** RESOLVED. Вопросы M11-53…57 обновлены под теми же ID по прямому owner instruction цикла 0060; смысловые дубли не создавались.

### QA-2026-08-24-ADM-M11-53 — языки отдельной страницы
**Вопрос:** должна ли отдельная страница Магазина сразу поддерживать все языки EFHC или пока оставить её на русском языке для проверки владельцем?
**Ответ владельца:** поддерживать все текущие языки EFHC. Страница является обычным отдельным лендингом.

### QA-2026-08-24-ADM-M11-54 — вид пакетов EFHC
**Вопрос:** показывать шесть пакетов EFHC отдельными карточками одновременно или сделать одну карточку с выбором количества монет?
**Ответ владельца:** владелец передал исполнителю выбор самого простого варианта для обычного лендинга. Реализация цикла 0060 показывает все шесть утверждённых пакетов отдельными карточками без дополнительного селектора.

### QA-2026-08-24-ADM-M11-55 — подробная карточка товара
**Вопрос:** нужна ли отдельная подробная страница товара при нажатии на название или достаточно сразу выбирать оплату в карточке Магазина?
**Ответ владельца:** отдельная подробная страница не нужна. Покупка выполняется прямо на лендинге.

### QA-2026-08-24-ADM-M11-56 — изображение товара
**Вопрос:** если администратор не загрузил изображение товара, показывать фирменный значок EFHC или оставлять карточку без картинки?
**Ответ владельца:** для пакетов монет показывать фирменный значок EFHC. Для VIP NFT использовать официальный визуальный язык EFHC-коллекции, предварительно сверенный на GetGems.

### QA-2026-08-24-ADM-M11-57 — подтверждение копирования номера заказа
**Вопрос:** после копирования ShopOrder ID достаточно короткого сообщения «Скопировано» или отметка должна оставаться рядом с номером заказа постоянно?
**Ответ владельца:** достаточно короткого сообщения `Скопировано`.

## FRONTEND Admin Modules — Module 11 / Shop landing — решения итерации v217

**Статус:** PARTIALLY RESOLVED. Вопросы M11-58…62 физически проверены на смысловые дубли по M11-01…57, OWNER_DECISION и active CANON/SSOT. Прямые последующие ответы владельца разрешили M11-58…60; M11-61…62 не получили однозначного решения и остаются под теми же ID.

### QA-2026-08-24-ADM-M11-58 — главная кнопка первого экрана
**Вопрос:** главная кнопка вверху Магазина должна вести сначала к пакетам монет EFHC или сразу к EFHC VIP NFT?
**Ответ владельца:** отдельная главная кнопка-направление не нужна. Это обычная товарная страница; пользователь сам выбирает раздел и товар.

### QA-2026-08-24-ADM-M11-59 — количество примеров VIP NFT
**Вопрос:** в блоке EFHC VIP NFT показывать один крупный пример оформления или небольшую галерею из нескольких официальных примеров?
**Ответ владельца:** одна общая картинка раздела. Используется `EFHC VIP NFT #0000`; номер `0000` уже недоступен и не продаётся.

### QA-2026-08-24-ADM-M11-60 — объяснение покупки
**Вопрос:** добавить на лендинг короткий блок из трёх шагов «выбрать товар → оплатить → получить» или оставить страницу без такого объяснения?
**Ответ владельца:** отдельный направляющий блок не нужен. Страница остаётся обычной товарной страницей с самостоятельным выбором пользователя.

### QA-2026-08-24-ADM-M11-61 — запоминание языка
**Вопрос:** Магазин должен запоминать выбранный язык между посещениями или каждый раз брать язык из профиля EFHC?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-24-ADM-M11-62 — порядок товаров на телефоне
**Вопрос:** на телефоне сначала показывать пакеты монет EFHC или сначала крупный блок EFHC VIP NFT?
**Ответ владельца:** UNRESOLVED.

## FRONTEND Admin Modules — Module 11 / компактный Shop и VIP inventory — ответы владельца итерации v217

**Статус:** RESOLVED. Записи M11-63…70 объединяют только новые самостоятельные смыслы из последовательных owner-ответов после v216. Перед добавлением выполнен semantic duplicate check по M11-01…62, OWNER_DECISION и active CANON/SSOT.

### QA-2026-08-24-ADM-M11-63 — общий образ каждого раздела
**Вопрос:** использовать отдельную картинку для каждого товара или одну общую картинку для всего раздела монет и одну для VIP NFT?
**Ответ владельца:** одна общая картинка для каждого из двух разделов. Для VIP используется общий образ `#0000`; этот номер недоступен и не является товаром.

### QA-2026-08-24-ADM-M11-64 — компактный вид товаров
**Вопрос:** как показать ассортимент, чтобы не заваливать пользователя большим количеством карточек?
**Ответ владельца:** одна картинка раздела и компактный текстовый список товаров, похожий по плотности на календарь. Несколько позиций для монет EFHC и одна VIP-позиция с вариантами номера.

### QA-2026-08-24-ADM-M11-65 — единый выбор валюты
**Вопрос:** выбирать валюту отдельно у каждого товара или один раз для всей страницы?
**Ответ владельца:** один глобальный переключатель на весь Shop. По умолчанию `TON / GRAM`; доступны также `USDT` и `EFHC`. Все значения настраиваются в Admin → Магазин.

### QA-2026-08-24-ADM-M11-66 — шесть цен VIP NFT
**Вопрос:** как Admin задаёт цену обычной VIP-покупки и покупки с выбором конкретного номера?
**Ответ владельца:** Admin отдельно задаёт все шесть цен: любой номер и выбранный номер × EFHC, TON/GRAM, USDT.

### QA-2026-08-24-ADM-M11-67 — доступные четырёхзначные номера
**Вопрос:** какие номера показывать покупателю и сколько их может быть в текущей продаже?
**Ответ владельца (исправлено 27.08.2026):** всего возможны `0001…9999`; `0000` — недоступная общая иллюстрация. Фиксированного лимита опубликованных доступных номеров нет. Доступный набор определяется фактически введённым Admin списком и текущим системным состоянием/ownership по Global ID. Недоступные и занятые номера не должны становиться доступными автоматически.

### QA-2026-08-24-ADM-M11-68 — удержание выбранного номера
**Вопрос:** что делать с точным номером, пока пользователь оплачивает покупку?
**Ответ владельца:** временно удерживать номер за этим пользователем на время оплаты, чтобы его не купил другой пользователь.

### QA-2026-08-24-ADM-M11-69 — действие кнопки оплаты криптовалютой
**Вопрос:** что должно происходить после нажатия `Оплатить` для TON/GRAM или USDT?
**Ответ владельца:** сразу открыть подходящий криптокошелёк; если прямой выбор невозможен, показать выбор кошелька. После подключения продолжить оплату.

### QA-2026-08-24-ADM-M11-70 — смена кошелька
**Вопрос:** нужна ли в Shop отдельная возможность выбрать другой кошелёк перед оплатой?
**Ответ владельца:** да. `Сменить кошелёк` означает выбрать один из уже привязанных к EFHC TON wallet addresses/identities. Tonkeeper/MyTonWallet/TON Space и другие программы — transport/providers, а не кошельки и не варианты этого выбора. Полный TON address на public Shop page не отображается из соображений конфиденциальности.

## FRONTEND Admin Modules — Module 11 / ответы владельца после итерации v217

**Статус:** RESOLVED. Вопросы M11-71…75 обновлены под теми же ID по прямым ответам владельца, открывшим цикл 0061; смысловые дубли не создавались.

### QA-2026-08-24-ADM-M11-71 — количество покупок в «Мои заказы»
**Вопрос:** в разделе `Мои заказы` сначала показывать 20 последних покупок, а остальные раскрывать кнопкой `Показать ещё 20`?
**Ответ владельца:** да. Сначала показывать 20 последних оплаченных покупок, остальные раскрывать кнопкой `Показать ещё 20`.

### QA-2026-08-24-ADM-M11-72 — загрузка доступных номеров в Admin
**Вопрос:** как добавлять доступные VIP-номера в Admin: вставлять список в одно поле или также загружать готовый CSV-файл?
**Ответ владельца:** нужен не отдельный CSV-only сценарий, а карта всех `0001…9999` в Admin Shop с вводом доступных и недоступных номеров, защитой занятых номеров и отображением Global ID владельца, когда ownership checker физически возвращает эти данные. На сайте показывать только 100 доступных номеров.

### QA-2026-08-24-ADM-M11-73 — видимость времени удержания номера
**Вопрос:** показывать покупателю обратный отсчёт, сколько ещё выбранный VIP-номер удерживается за ним до завершения оплаты?
**Ответ владельца:** да. Показывать обратный отсчёт; срок удержания — ровно 10 минут.

### QA-2026-08-24-ADM-M11-74 — окончание удержания без оплаты
**Вопрос:** если время оплаты закончилось, сразу вернуть номер в общий список и попросить пользователя выбрать его заново?
**Ответ владельца:** да. После окончания 10 минут освободить номер и попросить пользователя выбрать доступный номер заново.

### QA-2026-08-24-ADM-M11-75 — назначение номера при покупке без выбора
**Вопрос:** если куплен вариант `Любой доступный номер`, конкретный номер выбирает Admin при выдаче или система должна автоматически назначить самый маленький свободный номер?
**Ответ владельца:** конкретный номер лучше назначает Admin вручную.

## FRONTEND Admin Modules — Module 11 / новые вопросы после итерации v218

**Статус:** UNRESOLVED. Вопросы M11-76…80 физически проверены на смысловые дубли по M11-01…75, OWNER_DECISION и active CANON/SSOT. Они сформулированы простым языком и не блокируют уже утверждённую реализацию.

### QA-2026-08-24-ADM-M11-76 — какие 100 номеров показывать
**Вопрос:** если Admin выставил больше 100 доступных VIP-номеров, какие 100 показывать в Магазине: самые маленькие по номеру или те, которые Admin сам поставил первыми?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-24-ADM-M11-77 — ввод диапазона номеров
**Вопрос:** в карте VIP NFT нужно разрешить вводить сразу диапазон, например `0100–0199`, или безопаснее добавлять каждый номер отдельно списком?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-24-ADM-M11-78 — переход к владельцу занятого NFT
**Вопрос:** при нажатии на занятый VIP-номер в Admin сразу открывать профиль Global ID его владельца?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-24-ADM-M11-79 — кошелёк отправителя во входящих платежах
**Вопрос:** во `Входящих платежах EFHC` показывать кошелёк отправителя сразу в строке операции или только после открытия подробностей?
**Ответ владельца:** UNRESOLVED.

### QA-2026-08-24-ADM-M11-80 — период на двух графиках Admin
**Вопрос:** графики `Резерв Банка` и `В обороте` должны показывать только текущее состояние или ещё историю изменений по дням?
**Ответ владельца:** UNRESOLVED.

## FRONTEND Admin Modules — Module 11 / recovery union v216–v218 / ответы владельца v219→v220

**Статус:** RESOLVED по прямым ответам владельца в циклах 0062–0063. Перед добавлением выполнен semantic duplicate check по физическому union M11-01…80 из v216/v217/v218, current OWNER_DECISION/CANON/SSOT. Восстановление подтвердило, что v218 register является superset прежних ID/owner answers; ранние RESOLVED ответы не понижаются и не теряются.

### QA-2026-08-25-ADM-M11-81 — номер VIP в «Мои заказы»
**Вопрос:** в строке оплаченной VIP-покупки в `Мои заказы` сразу показывать выбранный точный номер, а для варианта без выбора писать, что номер назначит Admin?
**Ответ владельца:** Да. В строке оплаченной VIP-покупки показывать выбранный точный номер; для варианта «любой номер» указывать, что конкретный номер назначает Admin.

### QA-2026-08-25-ADM-M11-82 — просмотр деталей оплаченного заказа
**Вопрос:** при нажатии на оплаченный заказ в `Мои заказы` открывать read-only детали покупки (ShopOrder ID, способ оплаты, сумма и время оплаты) или достаточно информации прямо в строке списка?
**Ответ владельца:** Добавить данные. По нажатию на оплаченный заказ открывать read-only детали покупки: ShopOrder ID, способ оплаты, сумма и время оплаты.

### QA-2026-08-25-ADM-M11-83 — экспорт карты VIP-номеров
**Вопрос:** нужен ли Admin отдельный CSV/XLSX export всей карты `0001…9999` со статусами доступен / недоступен / занят / не выставлен и Global ID владельца там, где он физически известен?
**Ответ владельца:** Да. Нужен CSV/XLSX export всей карты `0001…9999` с фактическими статусами и Global ID владельца там, где он известен.

### QA-2026-08-25-ADM-M11-84 — обновление владельца номера после on-chain transfer
**Вопрос:** если ownership checker позже подтвердил, что VIP NFT перешёл в другой verified wallet/Global ID, карта Admin должна автоматически обновить владельца номера при следующей проверке или изменение должно требовать ручного действия Admin?
**Ответ владельца:** Всегда строго автоматически обновлять владельца номера в таблице по фактическому ownership checker / мониторингу привязанных кошельков.

### QA-2026-08-25-ADM-M11-85 — смысл сохранения списков доступности
**Вопрос:** когда Admin вводит список доступных или недоступных VIP-номеров и нажимает сохранить, этот список должен полностью заменять прежнее состояние соответствующей группы или только добавлять/изменять перечисленные номера?
**Ответ владельца:** Список недоступных — это явный blacklist купленных/недоступных номеров. Если Admin добавляет `0002` в недоступные, `0001` остаётся доступным. Простое отсутствие номера в новом вводе не делает его недоступным.


## FRONTEND Admin Modules — Module 11 / внешний Shop и VIP NFT — ответы владельца цикла 0063

**Статус:** RESOLVED. Вопросы M11-86…94 не заменяют ранние ID; они фиксируют новые самостоятельные решения owner scope.

### QA-2026-08-25-ADM-M11-86 — стартовые цены вариантов VIP
**Вопрос:** должны ли стартовые цены варианта «любой номер» и варианта с выбранным конкретным номером быть одинаковыми?
**Ответ владельца:** да. Стартовая цена для обоих вариантов: `150 USDT`, `100 TON/GRAM`, `500 EFHC`; далее цены могут управляться Admin по утверждённой модели шести цен.

### QA-2026-08-25-ADM-M11-87 — тема Shop по умолчанию
**Вопрос:** какую тему Shop включать при первом открытии?
**Ответ владельца:** тёмную. Dark theme является default.

### QA-2026-08-25-ADM-M11-88 — сохранение темы
**Вопрос:** сохранять ли выбранную light/dark тему между посещениями?
**Ответ владельца:** да, сохранять.

### QA-2026-08-25-ADM-M11-89 — изображения Shop
**Вопрос:** должен ли Admin менять общие изображения пакетов EFHC и EFHC VIP NFT?
**Ответ владельца:** нет. Эти изображения постоянные.

### QA-2026-08-25-ADM-M11-90 — canonical VIP URL
**Вопрос:** нужен ли отдельный понятный canonical web-route для EFHC VIP NFT?
**Ответ владельца:** сделать правильно и красиво. Историческая реализация v220 создала `/efhc-vip-nft`, но M11-96 позже прямо закрепил: HUB VIP всегда ведёт только на GetGems. Самостоятельная судьба `/efhc-vip-nft` вне HUB не определена и вынесена отдельным вопросом M11-103.

### QA-2026-08-25-ADM-M11-91 — исправление выданного номера
**Вопрос:** разрешать ли Admin исправить ошибочно введённый фактически выданный номер с audit trail?
**Ответ владельца:** да. Исправление разрешено с audit trail; фактический Global ID владельца номера должен определяться автоматически периодическим мониторингом привязанных кошельков / ownership checker. Если production backend не предоставляет подтверждённый terminal audit-update endpoint, frontend обязан оставаться fail-closed и не выдумывать API.

### QA-2026-08-25-ADM-M11-92 — delivery wallet в Admin export
**Вопрос:** включать ли delivery TON wallet в CSV/XLSX полной карты VIP, если адрес физически известен?
**Ответ владельца:** да.

### QA-2026-08-25-ADM-M11-93 — история владельцев номера
**Вопрос:** достаточно ли текущего владельца номера или желательно хранить историю смен владельца?
**Ответ владельца:** текущего владельца достаточно; если реализация несложная, историю владельцев желательно сохранять для мониторинга. Это не должно блокировать текущую выдачу.

### QA-2026-08-25-ADM-M11-94 — delivery wallet в пользовательских заказах
**Вопрос:** показывать ли delivery TON wallet в пользовательском разделе `Мои заказы`?
**Ответ владельца:** нет. В пользовательских заказах delivery wallet не показывать.


## FRONTEND Admin Modules — Module 11 / HUB + Shop — owner correction cycle 0064

**Статус:** RESOLVED / OWNER LOCK.

### QA-2026-08-25-ADM-M11-95 — точный состав HUB
**Ответ владельца:** public HUB содержит ровно две ссылки: `Магазин` и `EFHC VIP NFT`. Дополнительные, пустые, disabled и подготовленные слоты запрещены.

### QA-2026-08-25-ADM-M11-96 — абсолютный GetGems destination
**Ответ владельца:** `EFHC VIP NFT` в HUB всегда и во всех контекстах напрямую открывает `https://getgems.io/efhc-nft`. Никакой `/efhc-vip-nft`, Shop deep-link, access-key или промежуточный EFHC route не заменяет эту ссылку.

### QA-2026-08-25-ADM-M11-97 — отдельные страницы Shop
**Ответ владельца:** внешний Web EFHC Shop имеет отдельные страницы `Магазин`, `Мои заказы`, `Профиль`; нажатие навигации открывает соответствующую страницу, а не показывает три секции одной страницы.

### QA-2026-08-25-ADM-M11-98 — privacy linked TON wallet
**Ответ владельца:** raw TON wallet address запрещено отображать на public Shop page. Система использует адрес внутренне; пользователь выбирает привязанный кошелёк через приватное обозначение, без публикации полного адреса.


## FRONTEND Admin Modules — Module 11 / ответы владельца cycle 0066

**Статус:** RESOLVED / OWNER LOCK для M11-99…103.

### QA-2026-08-25-ADM-M11-99 — scope смены кошелька в Shop
**Вопрос:** когда пользователь нажимает `Сменить кошелёк` в Shop и выбирает другой привязанный TON-адрес, это должно менять только кошелёк текущей покупки/Shop-сессии или одновременно делать его основным кошельком всего аккаунта EFHC?
**Ответ владельца:** выбранный кошелёк становится основным кошельком всего EFHC-аккаунта.

### QA-2026-08-25-ADM-M11-100 — запоминание выбранного Shop-кошелька
**Вопрос:** выбранный для Shop привязанный кошелёк нужно запоминать между посещениями Магазина или при новом открытии снова использовать основной кошелёк аккаунта?
**Ответ владельца:** сохранять. Это тот же account-wide primary wallet из M11-99, поэтому при следующем открытии используется сохранённый основной кошелёк.

### QA-2026-08-25-ADM-M11-101 — приватные названия кошельков
**Вопрос:** достаточно обозначений `Основной кошелёк / Дополнительный кошелёк 2...` или пользователь должен иметь возможность задавать привязанным кошелькам собственные приватные названия, не показывая адрес?
**Ответ владельца:** достаточно `Основной кошелёк / Дополнительный кошелёк N`; дополнительно разрешено показывать только последние 4 символа TON wallet address. Полный адрес запрещён.

### QA-2026-08-25-ADM-M11-102 — GetGems в обычном Web
**Вопрос:** при нажатии HUB `EFHC VIP NFT` в обычной Web EFHC версии прямую GetGems-ссылку открывать в текущей вкладке или в новой вкладке? В обоих случаях destination остаётся строго `https://getgems.io/efhc-nft`.
**Ответ владельца:** в обычном Web EFHC GetGems открывать в новой вкладке. Exact URL остаётся `https://getgems.io/efhc-nft`.

### QA-2026-08-25-ADM-M11-103 — судьба `/efhc-vip-nft` вне HUB
**Вопрос:** отдельный EFHC route `/efhc-vip-nft`, созданный ранее, оставить как необязательный direct deep-link к VIP-товару внутри внешнего Shop или полностью удалить, чтобы VIP существовал только как товар на `/browser-shop`, а HUB VIP — только GetGems?
**Ответ владельца:** полностью удалить. VIP внутри EFHC существует только как товар `/browser-shop`, а HUB VIP всегда ведёт только на GetGems.


## FRONTEND Admin Modules — Module 11 / финальные ответы cycle 0067

**Статус:** RESOLVED. Новые Shop-вопросы в этом чате не открываются.

### QA-2026-08-25-ADM-M11-104 — standalone Shop demo packaging
**Вопрос:** достаточно одного самодостаточного `SHOP_vNNN.html`, который как `FRONTEND_vNNN.html` внутри одного demo-файла имеет три независимых route-view `Магазин / Мои заказы / Профиль`, или дополнительно нужны три физических demo HTML-файла по одному на каждую страницу?
**Ответ владельца:** Достаточно одного самодостаточного `SHOP_vNNN.html` с тремя независимыми route-view. Это предпочтительный формат и он должен соответствовать релизному поведению.

### QA-2026-08-25-ADM-M11-105 — верхняя навигация Shop
**Вопрос:** в верхней навигации внешнего Shop должны оставаться только три page-кнопки `Магазин / Мои заказы / Профиль`, или на странице `Магазин` дополнительно разрешены быстрые якоря `Пакеты EFHC / VIP NFT`?
**Ответ владельца:** На странице `Магазин` разрешены дополнительные быстрые якоря `Пакеты EFHC / VIP NFT`. На `Мои заказы` и `Профиль` эти якоря не показываются.

### QA-2026-08-25-ADM-M11-106 — общий account strip
**Вопрос:** блок с Global ID / балансом / выбранным кошельком должен отображаться на всех трёх страницах Shop или только на `Профиль`, а на `Магазин` и `Мои заказы` оставить более компактную шапку?
**Ответ владельца:** Account strip с Global ID / балансом / выбранным кошельком оставить как сейчас на всех трёх страницах.

### QA-2026-08-25-ADM-M11-107 — поиск в «Мои заказы»
**Вопрос:** оставить `Мои заказы` как текущий paid-only журнал 20 + 20 по времени или добавить поиск по ShopOrder ID / VIP NFT номеру?
**Ответ владельца:** Оставить только paid-only журнал `20 + показать ещё 20`; поиск не добавлять.

### QA-2026-08-25-ADM-M11-108 — переход после успешной покупки
**Вопрос:** после подтверждённой покупки оставаться на странице `Магазин` с подтверждением и ShopOrder ID или автоматически переходить на отдельную страницу `Мои заказы`?
**Ответ владельца:** Владелец передал UX-решение оператору. Принято: после подтверждённой покупки автоматически открывать отдельную страницу `Мои заказы`, чтобы пользователь сразу видел созданный ShopOrder и его статус.


## FRONTEND Admin Modules — Admin Shop cleanup — OWNER answers cycle 0070

**Статус:** M11-109…119 RESOLVED точечными OWNER-ответами. M11-112 superseded подробным M11-119.

### QA-2026-08-26-ADM-M11-109 — состав фиксированных товарных позиций
**Вопрос:** в Admin → Магазин оставить ровно 7 основных товарных позиций: 6 пакетов EFHC `10/100/250/500/750/1000` + один `EFHC VIP NFT`, а технические `NFT_VIP_SELECTED_PRICE` и `NFT_VIP_NUMBER_0001…9999` не показывать как отдельные товары?
**Ответ владельца / current CANON:** этот старый 8-position промежуточный состав заменён текущим fixed catalogue: **13 owner-visible positions** = 11 fixed EFHCm packages `10/50/100/150/200/250/300/350/500/750/1000`, `Свободный выбор EFHCm`, `EFHC VIP NFT`. Canonical slots materialize even when unavailable; unavailable slot is shown as `Недоступно`, not removed.

### QA-2026-08-26-ADM-M11-110 — добавление новых товаров
**Вопрос:** кнопку `+ Добавить товар` полностью удалить и сделать каталог фиксированным, чтобы Admin мог только менять цены существующих approved позиций?
**Ответ владельца:** RESOLVED — да. Каталог фиксированный; owner-visible функция добавления произвольного товара удаляется.

### QA-2026-08-26-ADM-M11-111 — публикация и статусы
**Вопрос:** убрать из Admin Shop управление `live/hidden/draft`, публикацией, архивом и физическим удалением товаров, оставив товары всегда существующими в фиксированном каталоге?
**Ответ владельца:** RESOLVED — да. Owner-visible управление сводится к цене и бинарной доступности `доступно / недоступно`; draft/archive/delete/publication complexity не показывается.

### QA-2026-08-26-ADM-M11-112 — технические поля карточки
**Вопрос:** удалить из owner-visible редактора `code/SKU`, title, description, image URL, category, badge, action_mode, delivery_mode, sort_order и список currencies, оставив только название позиции и поля цен?
**Ответ владельца:** SUPERSEDED / ТРЕБУЕТ ПЕРЕФОРМУЛИРОВКИ — OWNER сообщил, что вопрос непонятен и требует описания назначения каждой функции/поля. До ответа на новый M11-119 эти поля не удалять.

### QA-2026-08-26-ADM-M11-113 — какие таблицы обязательно сохранить
**Вопрос:** когда вы говорите «таблицы сохранить», какие именно таблицы должны остаться внутри модуля Магазин: таблица товарных позиций + таблица цен, или также карта VIP-номеров / история / заказы?
**Ответ владельца:** RESOLVED — сохранить все перечисленные полезные таблицы, но более поздние прямые ответы M11-115…117 имеют приоритет: History удалить; Orders оставить отдельным Admin-модулем; VIP issuance оставить отдельным модулем. Внутри Shop сохранить товарные позиции/цены и VIP number map.

### QA-2026-08-26-ADM-M11-114 — Предпросмотр Shop
**Вопрос:** вкладку `Предпросмотр Shop` удалить полностью, так как визуальная проверка выполняется через физический `SHOP_vNNN.html` и внешний `/browser-shop`?
**Ответ владельца:** RESOLVED — да, удалить owner-visible Preview из Admin Shop.

### QA-2026-08-26-ADM-M11-115 — История изменений
**Вопрос:** вкладку `История изменений` удалить из Admin Shop или сохранить её как одну из тех таблиц, которые вы приказали оставить?
**Ответ владельца:** RESOLVED — удалить как функцию, не относящуюся непосредственно к управлению товарами и ценами.

### QA-2026-08-26-ADM-M11-116 — Заказы
**Вопрос:** все функции заказов полностью убрать из Admin Shop, потому что в launcher уже существует отдельный модуль `Заказы`, и `/admin/shop` должен отвечать только за каталог/цены?
**Ответ владельца:** RESOLVED — да. В обычном `Admin → Магазин` заказы не показываются. Отдельный launcher `Заказы` сохраняется; его существующий execution route `?module=orders` не удалять.

### QA-2026-08-26-ADM-M11-117 — Выдача / VIP NFT
**Вопрос:** все функции выдачи VIP NFT и переходы к issuance убрать из Admin Shop, оставив их только в отдельном модуле `Выдача / VIP NFT`?
**Ответ владельца:** RESOLVED — да. Issuance остаётся только в отдельном Admin-модуле `Выдача / VIP NFT`.

### QA-2026-08-26-ADM-M11-118 — выбранный номер в TON/USDT
**Вопрос:** правило `+50%` для выбора конкретного VIP номера относится только к оплате EFHC (`500 → 750 EFHC`), а TON/GRAM и USDT selected-number цены оставить равными стандартным, или для них тоже должен действовать коэффициент `+50%`?
**Ответ владельца:** RESOLVED — надбавка действует только для EFHC: `500 → 750 EFHC`. TON/GRAM и USDT при выборе номера используют стандартную цену VIP без надбавки.


### QA-2026-08-26-ADM-M11-119 — какие технические поля карточки оставить owner-visible
**Статус:** RESOLVED / OWNER ANSWERED IN CYCLE 0071.

**Контекст / current correction:** каталог фиксирован текущим Shop CANON: 13 owner-visible positions = 11 fixed EFHCm packages + `Свободный выбор EFHCm` + `EFHC VIP NFT`. Ниже перечислены owner-visible/technical fields; current visibility/editability задаётся единым `FRONTEND_EXTERNAL_SHOP_VIP_CANON.md`.

**Вопрос OWNER — для каждого пункта выбрать `редактировать / только показывать / скрыть`:**
1. **Код товара / SKU** — технический постоянный идентификатор позиции, связывающий каталог, checkout и ShopOrder. Для фиксированного каталога Admin обычно не требуется менять его после создания.
2. **Тип товара (`item_type`)** — сообщает runtime, является позиция пакетом EFHC или VIP NFT и определяет разные checkout/delivery правила. Для 8 фиксированных позиций тип можно держать системно, без ручного изменения.
3. **Название (`title`)** — текстовое имя товара, которое видит пользователь (`350 EFHC`, `EFHC VIP NFT`). Можно разрешить редактирование текста или зафиксировать канонические названия.
4. **Номинал EFHC (`quantity_efhc`)** — сколько EFHC получает покупатель пакета: `10/100/250/350/500/750/1000`. Это определяет саму товарную позицию; при fixed catalog ручное изменение фактически превращает её в другой товар.
5. **Описание (`description`)** — поясняющий текст карточки/товара для покупателя. Сейчас это отдельное редактируемое поле.
6. **Изображение / `image_url`** — ссылка на approved physical asset. По действующему image CANON Shop использует утверждённые изображения; ручная замена может изменить внешний вид товара.
7. **Категория (`category`)** — внутренний технический grouping/marker для Admin/runtime. Пользователь Shop напрямую это поле не выбирает.
8. **Badge / метка** — короткая дополнительная подпись/маркер карточки, если renderer её использует.
9. **Разрешённые валюты (`pay_currencies`)** — какие способы оплаты доступны: пакеты EFHC = TON/GRAM + USDT; VIP = TON/GRAM + USDT + EFHC. Сейчас это часть product contract.
10. **`action_mode`** — технически определяет действие товара, например обычный checkout или external link. Текущие Shop товары работают через checkout.
11. **`delivery_mode`** — технически указывает способ исполнения после оплаты: пакет EFHC и VIP имеют разные delivery semantics. Это не цена, но влияет на execution flow.
12. **`external_url`** — URL для товара, который должен вести наружу при external-link режиме. Для текущих Shop товаров отдельный внешний товарный URL не нужен.
13. **`sort_order`** — технический порядок отображения товаров. Для фиксированных 8 позиций порядок можно закрепить системно без ручного поля.

**Ответ владельца:**
1. `code/SKU` — скрыть из Admin; оставить внутренним неизменяемым identity.
2. `item_type` — скрыть из Admin; оставить внутренним системным типом.
3. `title` — оставить редактируемым.
4. `quantity_efhc` — оставить редактируемым; 8 owner-visible товарных позиций сохраняются как стабильные слоты, но nominal package card можно менять.
5. `description` — оставить редактируемым и разрешить пустое значение.
6. `image_url` — скрыть из Admin; approved physical asset сохраняется внутренне.
7. `category` — скрыть из Admin.
8. `badge` — оставить редактируемым и разрешить пустое значение.
9. `pay_currencies` — оставить редактируемым в рамках разрешённых для типа товара методов.
10. `action_mode` — оставить редактируемым.
11. `delivery_mode` — сохранить технически, но скрыть из Admin.
12. `external_url` — не менять существующее поведение/поле.
13. `sort_order` — сохранить технически, но скрыть из Admin.

**Current correction:** невыбранные `Магазин / Мои заказы / Профиль` = серые кнопки с чёрным текстом; выбранная = жёлтая с чёрным текстом. Current catalogue authority is 13 positions from `FRONTEND_EXTERNAL_SHOP_VIP_CANON.md`; every canonical package slot remains materialized when unavailable.

## FRONTEND regression recovery v260→v265 — cycle 0108 / 10 OWNER questions

**Статус:** RESOLVED. OWNER дал ответы в cycles 0109–0111; все десять вопросов закрыты. Вопрос 03 окончательно подтверждён простым повторным вопросом в cycle0111.

### QA-2026-08-29-FR-0108-01 — История: понятные названия операций
**Вопрос (переформулирован простым языком по требованию OWNER):** На странице «История» пользователь должен всегда видеть обычные понятные и переведённые названия операций, а не внутренние технические слова системы. Подтверждаете, что это правило нужно снова жёстко закрепить в документах, чтобы оно больше не терялось при обновлениях?
**Ответ владельца:** RESOLVED — да, обязательно. Пользователь на странице «История» должен видеть понятные переведённые названия, а не внутренние технические слова. OWNER отдельно отметил, что фактический интерфейс уже работает именно так; cycle0110 восстанавливает это правило в EAM/generator, чтобы документация не потеряла существующее поведение.

### QA-2026-08-29-FR-0108-02 — DEMO USER/ADMIN: нужна ли отдельная проверка
**Вопрос (переформулирован простым языком по требованию OWNER):** Правильно ли я понимаю, что отдельная автоматическая проверка кнопок Админа вообще не нужна: достаточно вручную переключать DEMO между USER и ADMIN, а экран и поведение в каждом режиме должны на 100% повторять реальное приложение?
**Ответ владельца:** RESOLVED — да. Отдельная автоматическая проверка USER/ADMIN не нужна. DEMO переключается вручную и обязана на 100% повторять реальное приложение по экрану и поведению; реальные server rights standalone не выдаёт.

### QA-2026-08-29-FR-0108-03 — Panels: список не должен прыгать при догрузке
**Вопрос (переформулирован простым языком по требованию OWNER):** Когда пользователь прокручивает список панелей и автоматически подгружаются следующие 20, нужно ли сделать так, чтобы экран оставался на той же карточке и список визуально не прыгал вверх или вниз?
**Ответ владельца:** RESOLVED в cycle0111 через повторный простой вопрос QA-2026-08-29-FR-0110-01 — да. При автоматической догрузке пользователь остаётся на той же карточке; визуальный скачок списка запрещён.

### QA-2026-08-29-FR-0108-04 — новая панель после покупки
**Вопрос:** Нужно ли вводить отдельное автоматическое действие, чтобы только что купленная новая панель сразу становилась видимой при режиме «сначала старые»?
**Ответ владельца:** RESOLVED — отдельную проблему не подтверждать и новый UX не вводить. OWNER указал, что уже существует стрелка переключения старых/новых панелей. Сохраняем эту стрелку как существующий способ переключения порядка.

### QA-2026-08-29-FR-0108-05 — как экранный помощник должен называть кнопку покупки
**Вопрос (переформулирован простым языком по требованию OWNER):** На кнопке пользователь видит «Купить панель». Что должен произносить экранный помощник для незрячего пользователя: тоже «Купить панель» или более подробное «Активировать одну солнечную панель»?
**Ответ владельца:** RESOLVED — пока не работаем над специальной поддержкой экранных помощников для незрячих. В cycle0110 и далее не вводить отдельное accessibility-поведение этой кнопки без нового OWNER запроса.

### QA-2026-08-29-FR-0108-06 — сохранять ли созданные DEMO-панели после обновления
**Вопрос (переформулирован простым языком по требованию OWNER):** Если в DEMO вы уже купили или создали тестовые панели, после обновления версии их нужно сохранить, или DEMO можно сбрасывать к стандартному тестовому набору 60 активных + 60 архивных панелей?
**Ответ владельца:** RESOLVED — DEMO можно сбрасывать к стандартным тестовым данным между версиями; обязательное сохранение созданных DEMO-панелей не требуется. Текущее сохранение через cache/storage допустимо, но не становится продуктовым контрактом.

### QA-2026-08-29-FR-0108-07 — USER/ADMIN в Technical Workbench
**Вопрос:** Нужна отдельная автоматическая кнопка «Проверить оба режима» или оставить ручные USER/ADMIN переключатели?
**Ответ владельца:** RESOLVED — оставить только ручные USER/ADMIN. DEMO должна быть 100% визуально-функциональной копией реального приложения; если отличается — это регресс. Standalone не выдаёт реальные серверные права.

### QA-2026-08-29-FR-0108-08 — порядок в Shop release metadata
**Вопрос:** Исправить ошибочную подпись cycle у historical companion `SHOP_v265`, не меняя сам Shop?
**Ответ владельца:** RESOLVED — да, если это нужно для порядка. Исправляется в cycle0109 только metadata/comment, Shop runtime не меняется.

### QA-2026-08-29-FR-0108-09 — пропущенный cycle0106 в перечне reports
**Вопрос:** Вернуть существующий cycle0106/reports_00072 в текстовую хронологию report manifest, не переписывая старые immutable reports?
**Ответ владельца:** RESOLVED — да.

### QA-2026-08-29-FR-0108-10 — какой реестр использовать для восстановления
**Вопрос:** Нужно ли создавать ещё один отдельный recovery-реестр разрешённых изменений?
**Ответ владельца:** RESOLVED — нет. Уже существует `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; оператор обязан обновлять этот реестр по OWNER вопросам/ответам и сверять с ним свои действия. Создание дублирующего Q&A/recovery реестра вместо существующего authority запрещено без отдельного OWNER решения. Вопрос cycle0108 №10 признан избыточным.


## FRONTEND regression recovery — cycle 0110 / 5 следующих вопросов OWNER

**Статус:** RESOLVED в cycle0111. Все пять ответов OWNER применяются только в подтверждённом scope cycle0111.

### QA-2026-08-29-FR-0110-01 — не терять место при подгрузке панелей
**Вопрос:** Если вы листаете панели вниз и приложение в этот момент подгружает ещё 20 старых панелей, список может сам сдвинуться и вы потеряете место, которое читали. Нужно сделать так, чтобы после подгрузки на экране оставалась та же панель?
**Ответ владельца:** RESOLVED — да. При автоматической подгрузке следующих 20 панелей пользователь должен остаться на той же читаемой карточке; список не должен визуально перескакивать на другой участок.

### QA-2026-08-29-FR-0110-02 — повтор цены активации в верхнем блоке
**Вопрос:** После переноса блока «Активация панели» вверх цена 100 EFHC видна и в этом блоке, и ещё раз в верхней части страницы рядом с «Энергетические модули». Оставить оба упоминания или убрать верхнее повторение?
**Ответ владельца:** RESOLVED — убрать верхнее повторение. В блоке «Энергетические модули» строка «Активация панели 100 EFHC» удаляется; отдельный компактный блок активации остаётся ниже.

### QA-2026-08-29-FR-0110-03 — кнопка «Загрузить ещё» и автоматическая догрузка
**Вопрос:** Реальное приложение умеет само подгружать следующие 20 панелей при прокрутке и при этом ещё показывает кнопку «Загрузить ещё». В DEMO такой отдельной кнопки сейчас нет. Как должно быть одинаково в обоих вариантах: оставить кнопку как запасной способ или убрать её и оставить только автоматическую догрузку?
**Ответ владельца:** RESOLVED — отдельную кнопку «Загрузить ещё» убрать. В production и DEMO остаётся только автоматическая подгрузка следующих 20 панелей при прокрутке.

### QA-2026-08-29-FR-0110-04 — переход Активные / Архив
**Вопрос:** Когда вы переключаетесь с «Активные» на «Архив» или обратно, новый список всегда должен открываться с самого верха, или приложение должно сохранять прежнее место прокрутки?
**Ответ владельца:** RESOLVED — новый список всегда открывается с самого верха. Только стрелка старые/новые меняет направление порядка и тем самым верх/конец списка.

### QA-2026-08-29-FR-0110-05 — что дальше делать с Theme 8
**Вопрос:** Theme 8 сейчас возвращена к виду v260, потому что увеличение текста в v265 стало хуже. Как исправлять дальше?
**Ответ владельца:** RESOLVED — сделать проблемный блок «Активные/Архив» и только карточки панелей похожими на другой нормальный вариант темы. Выбрать существующую удачную геометрию по аналогии самостоятельно. Другие части Theme 8 не менять.

## FRONTEND Panels — прямое решение владельца cycle 0112

**Статус:** RESOLVED / OWNER DIRECT.

### OWNER-DIRECT-2026-08-29-FR-0112-01 — отдельная страница портфеля
**Решение владельца:** блок `Активные / Архивные панели` вынести с основной страницы Panels на новую полноценную страницу. На основной странице оставить одну длинную кнопку перехода внизу, по тому же принципу, как `Обмен` открывает отдельный `Вывод EFHCm`.

**Зафиксированная реализация:** `/panels` = Hero + activation + одна full-width кнопка `Мои панели`; `/panels/portfolio` = существующие Active/Archive controls + карточки + old/new arrow + auto-load. Production и DEMO одинаковы.

**OWNER-уточнение названия кнопки:** `Мои панели`. Заголовок новой страницы остаётся отдельным понятием и этим уточнением не меняется.

## FRONTEND viewport / Withdraw / Admin parity — cycle 0113 / OWNER answers

### QA-2026-08-29-FR-0113-01 — Что оставить на странице «Вывод»
**Статус:** RESOLVED.
**Вопрос:** оставить простой сценарий `баланс → кошелёк → сумма → Создать заявку`, а технические верхние блоки удалить?
**Ответ владельца:** Да. Технические описания ordinary USER Withdraw удалить.

### QA-2026-08-29-FR-0113-02 — Оставлять ли заявки и историю на той же странице
**Статус:** RESOLVED.
**Ответ владельца:** Да, можно оставить на одной странице, но должна существовать реальная внутренняя прокрутка. Header и нижняя навигация статичны, центральная область прокручивается.

### QA-2026-08-29-FR-0113-03 — Какие статусы показывать пользователю
**Статус:** RESOLVED.
**Ответ владельца:** Достаточно четырёх понятных состояний: `В обработке / Выплачено / Отменено / Отклонено`.

### QA-2026-08-29-FR-0113-04 — Нужны ли фильтры Withdraw
**Статус:** RESOLVED.
**Ответ владельца:** Да, фильтры оставить.

### QA-2026-08-29-FR-0113-05 — Убирать ли внутренний инженерный язык
**Статус:** RESOLVED.
**Ответ владельца:** Да, обязательно убрать Money-Center, контур, холд, жизненный цикл, промо-зону и аналогичные технические описания. Провести аудит таких артефактов и дать список на удаление.

### QA-2026-08-29-FR-0113-06 — DEMO может прокручиваться, если production не может?
**Статус:** RESOLVED.
**Ответ владельца:** Нет. Это обязательный запрет. Иначе DEMO вводит OWNER в заблуждение.

### QA-2026-08-29-FR-0113-07 — Как должна прокручиваться Admin-страница
**Статус:** RESOLVED.
**Ответ владельца:** Вся Admin-страница прокручивается сверху вниз внутри приложения между статическими областями; общий закон распространяется и на USER страницы.

### QA-2026-08-29-FR-0113-08 — Что делать с верхней Admin-панелью
**Статус:** RESOLVED.
**Ответ владельца:** Оставлять постоянно видимой сверху.

### QA-2026-08-29-FR-0113-09 — Единый закон для всех разделов
**Статус:** RESOLVED.
**Ответ владельца:** Да. Один scroll/viewport contract для всех административных и пользовательских разделов.

### QA-2026-08-29-FR-0113-10 — Какой размер использовать в DEMO
**Статус:** RESOLVED.
**Ответ владельца:** Standalone/DEMO использует средний фиксированный размер адаптивного окна приложения для честной визуальной проверки; production обязательно остаётся адаптивным под реальные устройства. Для текущего canonical review сохраняется средний корпус 390×844.

## FRONTEND emergency Admin runtime recovery — cycle 0114 / OWNER DIRECT

### OWNER-DIRECT-2026-08-29-FR-0114-01 — v271 Admin regression
**Статус:** RESOLVED / IMPLEMENTED.

**Сигнал владельца:** physical `FRONTEND_v271` дал 100% regression: все Admin-страницы пропали. Требование — срочно прочитать runtime evidence и исправить системную причину.

**Подтверждено:** standalone global `renderPanelsData()` падал на удалённом `#listTitle` с `TypeError: Cannot set properties of null (setting 'textContent')`; из-за общего `render()` исключение блокировало Admin navigation. Отдельно подтверждён опасный production seam: `viewportHeight=0` мог быть записан в CSS при жёстком root height.

**Решение:** optional Panels DOM write переведён в fail-soft; Telegram viewport CSS принимает только строго положительные значения; emergency runtime smoke обязан подтверждать `16/16 Admin` и `Runtime.exceptionThrown=0`. Никаких редизайнов/переименований в cycle0114 нет.

## FRONTEND USER Tasks copy — cycle 0115 / 10 вопросов OWNER

**Статус:** RESOLVED direct OWNER 2026-08-29 / реализуется cycle0116 → FRONTEND_v274.

### QA-2026-08-29-FR-0115-01 — Telegram группа/канал
**Ответ OWNER:** выбран вариант B/«В». Отдельным ответом 7 URL запрещён в тексте, поэтому конечный USER title: `Вступите в Telegram группу/канал.`

### QA-2026-08-29-FR-0115-02 — Просмотр рекламы
**Ответ OWNER:** `Просмотр рекламы.`

### QA-2026-08-29-FR-0115-03 — Переход на сайт
**Ответ OWNER:** выбран вариант B/«В». Отдельным ответом 7 URL запрещён в тексте, поэтому конечный USER title: `Перейдите на сайт.`

### QA-2026-08-29-FR-0115-04 — приложение
**Ответ OWNER:** `Открыть приложение и ознакомиться.`

### QA-2026-08-29-FR-0115-05 — приложение
**Ответ OWNER:** `Запустите приложение.`

### QA-2026-08-29-FR-0115-06 — автоматическая проверка
**Ответ OWNER:** удалить полностью весь такой пользовательский copy. Никаких фраз про автоматическую проверку, verifier/provider или подтверждение выполнения в Tasks cards.

### QA-2026-08-29-FR-0115-07 — URL
**Ответ OWNER:** ссылка находится только в кнопке `Выполнить`; URL не показывается в тексте карточки.

### QA-2026-08-29-FR-0115-08 — descriptions
**Ответ OWNER:** отдельных описаний вообще не должно быть. Карточка использует только утверждённый action-template title.

### QA-2026-08-29-FR-0115-09 — технические/партнёрские названия
**Ответ OWNER:** ничего из перечисленного (`WebApp`, `Telegram bot`, `приложение партнёра`, `бот партнёра`) в USER copy не должно быть. Внутренние machine IDs сохраняются без owner-visible экспозиции.

### QA-2026-08-29-FR-0115-10 — EFHCb copy
**Ответ OWNER:** награда остаётся отдельным полем карточки; размер/бонус не повторяется в описательном тексте.

## FRONTEND cycle 0117 — DEMO startup / Referrals recovery

### QA-2026-08-29-FR-0117-01 — Как DEMO открывается по умолчанию?
**Ответ владельца:** RESOLVED — review-role по умолчанию ADMIN, но первая открытая product page — Energy (`/`).

### QA-2026-08-29-FR-0117-02 — Где должна быть кнопка «Мои Рефералы»?
**Ответ владельца:** RESOLVED — на основной пользовательской странице `/referrals`; кнопка ведёт на отдельную `/referrals/my`.


## FRONTEND Withdraw primary/history — cycle 0119 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0119-01 — где выбирается кошелёк для Вывода
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** основной выбор кошелька выполняется в Профиле. Остальные страницы и функции по умолчанию используют сохранённый основной кошелёк. На `Вывод` повторный список выбора кошельков не нужен.

**Зафиксированная реализация:** `Вывод` показывает только компактный read-only `Основной кошелёк`; при создании заявки existing request contract получает тот же `wallet_id`, но это id сохранённого primary wallet Профиля. Смена primary выполняется через Профиль.

### OWNER-DIRECT-2026-08-30-FR-0119-02 — initial status на странице Вывод
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** техническую запись `Заявка не создана.` убрать. Сообщение появляется только после фактического действия/ошибки.

### OWNER-DIRECT-2026-08-30-FR-0119-03 — Мои заявки и экспорт
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** `Мои заявки` сделать проще, по аналогии с `История`; стандартные файлы логов операций добавить в конце страницы.

**Зафиксированная реализация:** четыре существующих фильтра сохранены; заявки представлены History-style раскрываемыми строками без отдельной постоянной карточки деталей. В конце страницы доступны standard Profile History `CSV/XLSX`; новый API не создавался.


## FRONTEND Withdraw / Tasks — cycle 0121 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0121-01 — два равных блока Withdraw
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** `Доступно к выводу` и `Основной кошелёк` выровнять ровно по ширине в два равных блока.

### OWNER-DIRECT-2026-08-30-FR-0121-02 — MAX
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** кнопка `Макс.` на `Вывод` становится единым каноническим `MAX` для всех языков.

### OWNER-DIRECT-2026-08-30-FR-0121-03 — Tasks themes 09/12
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** исправить сломанную геометрию окон заданий в темах 09 и 12 и выровнять их аккуратно. Реализация сохраняет visual theme, но убирает конфликтующие historical layout rules после 80px compact-перехода.

## FRONTEND Withdraw / Tasks — cycle 0122 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0122-01 — Withdraw stats list вместо двух карточек
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** `Доступно к выводу` и `Основной кошелёк` оформить красивым вертикальным списком как на странице `Обмен`; соседние 50/50 блоки больше не использовать, так как содержимое обрезается.

**Зафиксированная реализация:** две строки `label → value` в одном list-контейнере; wallet value допускает перенос и не использует ellipsis/clipping.

### OWNER-DIRECT-2026-08-30-FR-0122-02 — единая rank-like геометрия Tasks
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** реализовать предложенную общую оптимизацию карточек заданий и сделать их похожими на список `Ранги`: текст и бонус слева в 2–3 ряда, кнопка справа.

**Зафиксированная реализация:** все активные TG themes используют одну structural anatomy `title + EFHCb слева | Выполнить справа`; тема сохраняет свою palette/background/border/radius.

## FRONTEND Withdraw / Tasks — cycle 0123 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0123-01 — Withdraw должен быть физическим списком
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** `Доступно к выводу` и `Основной кошелёк` сделать красивым списком как на `Обмен`; обрезание внутри переоформленных блоков неприемлемо.

**Зафиксированная реализация:** cycle0123 удаляет зависимость Withdraw summary от `GameStat/source-stat` и создаёт отдельные production/standalone list rows с переносимым wallet value.

### OWNER-DIRECT-2026-08-30-FR-0123-02 — Tasks Themes 09/12/13 и лёгкое выравнивание остальных
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** Themes 09, 12 и 13 исправить как сломанные; остальные темы признаны приемлемыми и требуют только небольшого выравнивания.

**Зафиксированная реализация:** финальный rank-like geometry layer сбрасывает legacy row stretching/height/reward-width constraints для всех themes; TG-09/TG-12/TG-13 получают explicit repair surfaces, остальные сохраняют theme-owned оформление.


## FRONTEND Energy / Header theme semantics — cycle 0124 / 10 вопросов OWNER

**Статус блока:** RESOLVED / IMPLEMENTED.  
**Источник:** direct OWNER 2026-08-30; current implementation anchors: `docs/SSOT/ENERGY_RULES.md` + `frontend/src/design-system/global-theme-color-canon.json`.

**Общий закон OWNER:** серый зарезервирован для inactive/deactivated индикаторов; белый — обычный технический/readable text; active indicator/name/icon использует цвет Global Theme; full-page glass запрещён.

### QA-2026-08-30-FR-0124-01 — active color Theme 06
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** «Неоновый или фиолетовый».  
**Реализация:** существующий system-violet `#a78bfa` используется как Theme 06 active accent.

### QA-2026-08-30-FR-0124-02 — active color Theme 10
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** существующий ice-blue можно использовать.  
**Реализация:** canonical active accent = `#7dd3fc` из authored border/glow family.

### QA-2026-08-30-FR-0124-03 — область закона gray=inactive
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** правило распространяется абсолютно на все индикаторы приложения.

### QA-2026-08-30-FR-0124-04 — что именно может оставаться белым
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** белый разрешён для обычного текста/чисел; active названия, active icons, Energy и active `Activ/VIP` белыми быть не должны.

### QA-2026-08-30-FR-0124-05 — Energy title
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** да, `Energy` всегда использует active color текущей Global Theme.

### QA-2026-08-30-FR-0124-06 — Activ / VIP
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** да, active `Activ` и `VIP` всегда используют active color текущей Global Theme.

### QA-2026-08-30-FR-0124-07 — Lvl
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** `Lvl` может оставаться белым как ordinary information.

### QA-2026-08-30-FR-0124-08 — Header balance
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** да, EFHC balance и lightning icon используют active color текущей темы.

### QA-2026-08-30-FR-0124-09 — номер темы с затемнением
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** скорее всего Theme 07; полное затемнение целых страниц запрещено.  
**Physical resolution:** source подтверждает именно Theme 07 как systematic blur/glass family.

### QA-2026-08-30-FR-0124-10 — Aurora Glass
**Статус:** RESOLVED / IMPLEMENTED.  
**Ответ OWNER:** стеклянный эффект страниц запрещён; элементы должны быть различимы и индивидуальны.  
**Реализация:** Theme 07 USER blur отключён, surfaces сделаны более непрозрачными; blue identity сохранён.


## FRONTEND Energy / Header follow-up — cycle 0125 / 5 вопросов OWNER

**Статус блока:** OPEN / НЕ БЛОКИРУЕТ ПРЯМО ЗАДАННЫЕ CORRECTIONS.  
**Источник:** direct OWNER 2026-08-30 + physical audit cycle0125.

### QA-2026-08-30-FR-0125-01 — область Theme 13 no-glass
**Статус:** OPEN.  
**Вопрос:** Theme 13 убрать glass/veil только на странице Energy или во всей USER-теме 13 на всех страницах? Текущая safe implementation отключает backdrop blur во всей USER Theme 13, потому что OWNER уже запретил page-level glass.

### QA-2026-08-30-FR-0125-02 — surfaces Theme 13
**Статус:** OPEN.  
**Вопрос:** после удаления glass сохранить Black/Gold palette и использовать более плотные solid dark карточки/панели без изменения geometry?

### QA-2026-08-30-FR-0125-03 — active numeric indicators Energy
**Статус:** OPEN.  
**Вопрос:** theme color должен применяться только к active name/icon или также к числовому значению/проценту, когда это именно status-indicator? Обычные informational numbers сейчас остаются readable white.

### QA-2026-08-30-FR-0125-04 — inactive gray token
**Статус:** OPEN.  
**Вопрос:** использовать один neutral inactive gray `#94a3b8` во всех Global Themes или допускаются разные theme-specific gray shades?

### QA-2026-08-30-FR-0125-05 — future anti-regression guard
**Статус:** OPEN.  
**Вопрос:** закрепить ли машинным общим guard-правилом, что будущие Theme CSS не могут перекрыть active `Energy / Activ / VIP / EFHC balance+icon` белым или серым?


## FRONTEND visual baseline / Ranks — cycle 0126 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0126-01 — visual baseline
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** закрепить дизайн `FRONTEND_v283`. До нового прямого указания OWNER существующие USER-страницы и Global Themes не должны получать самовольные визуальные изменения. Cycle0126 имеет исключение только для страницы `Ранги`.

### OWNER-DIRECT-2026-08-30-FR-0126-02 — компактные строки Ранги
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** уменьшить Rank rows примерно вдвое по вертикали и округлить размер. Реализация: canonical `32px` baseline и одна строка из трёх колонок `номер | username | сгенерированная энергия`. Ranking API/pagination/find-me и privacy contracts не меняются.


## FRONTEND visual baseline / Ranks — cycle 0127 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0127-01 — visual baseline v284
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** закрепить дизайн `FRONTEND_v284`. Все остальные USER surfaces остаются frozen до следующего прямого OWNER-указания.

### OWNER-DIRECT-2026-08-30-FR-0127-02 — одинаковая яркость username и генерации
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** на странице `Ранги` username и generated energy должны быть одинаково яркими; смысловой акцент раздела — генерация. Реализация: одинаковая primary-text яркость и размер `.68rem`, username weight `800`, generated kWh weight `900`; muted цвет генерации запрещён.


## FRONTEND visual baseline / Tasks — cycle 0128 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0128-01 — visual baseline v285
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** закрепить дизайн `FRONTEND_v285`. Все остальные USER surfaces остаются frozen до следующего прямого OWNER-указания.

### OWNER-DIRECT-2026-08-30-FR-0128-02 — текст задания меньше и без жирного
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** на странице `Задания` уменьшить видимый текст задания и убрать жирное выделение. Реализация: `.76rem / 400 / 1.28` в production и standalone. Действующий title-only contract сохраняется; description/helper строки не возвращаются.

## FRONTEND Tasks — cycle 0129 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0129-01 — ширина кнопки Выполнить
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** уменьшить кнопку `Выполнить` примерно на 25–30% по ширине и округлить размер. Реализация: предшествующие `7rem` (~112px) заменены единым `80px` action-column/button width для всех активных TG themes, включая narrow viewport. Это уменьшение примерно на 28.6%.

### OWNER-DIRECT-2026-08-30-FR-0129-02 — название задания немного ярче
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** сделать названия заданий немного ярче, не возвращая жирность. Реализация: typography `.76rem / 400 / 1.28` сохраняется, светлота повышена через `color-mix(in srgb, var(--tg-text) 90%, #fff 10%)` в production и standalone.

## FRONTEND visual baseline / Ranks + Tasks — cycle 0130 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0130-01 — visual baseline v287
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** закрепить дизайн `FRONTEND_v287`. Все остальные USER surfaces остаются frozen до следующего прямого OWNER-указания.

### OWNER-DIRECT-2026-08-30-FR-0130-02 — убрать пояснение на Ранги
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** удалить owner-visible поясняющую надпись над leaderboard. Реализация синхронна в production/standalone; locale keys не удаляются.

### OWNER-DIRECT-2026-08-30-FR-0130-03 — названия заданий немного ярче
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** сделать все названия заданий немного ярче, включая `Просмотр рекламы.`, `Открыть приложение и ознакомиться.` и остальные. Реализация: 20% white-mix при сохранении `.76rem / 400 / 1.28`; bold не возвращается.

## FRONTEND visual baseline / Ranks — cycle 0131 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0131-01 — visual baseline v288
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** закрепить дизайн `FRONTEND_v288`. Все остальные USER surfaces остаются frozen до следующего прямого OWNER-указания.

### OWNER-DIRECT-2026-08-30-FR-0131-02 — увеличить Моё место / Моя энергия
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** увеличить подписи `Моё место` и `Моя энергия` примерно на 50–65% и округлить размер. Реализация: предыдущие ~11.5px (`.72rem`) заменены scoped exact `18px` (~+56%) только в Rank hero production/standalone; значения и leaderboard geometry не меняются.



## FRONTEND Ranks — cycle 0132 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0132-01 — финальный размер Моё место / Моя энергия
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** после сравнения вариантов выбрать exact `15px` для подписей `Моё место` и `Моя энергия`. Cycle0131 `18px` признан слишком большим и superseded. Реализация scoped только к Rank hero production/standalone; values и leaderboard не меняются.


## OWNER-DIRECT-2026-08-30-FR-0133 — Profile History / Withdraw shortcut

Статус: **RESOLVED / IMPLEMENTED**.

1. **Q:** Расположение кнопки?  
   **A:** Не делать четыре кнопки в ряд. `Вывод` находится справа от `Обновить`, то есть под `Скачать XLSX`; итоговая сетка 2×2.
2. **Q:** Старую `Открыть вывод` оставить?  
   **A:** Нет. Физически удалить, должна остаться одна кнопка `Вывод`.
3. **Q:** Какой визуальный размер новой кнопки?  
   **A:** Полностью идентичный трём соседним: height/width/padding/border-radius/visual style.
4. **Q:** Менять действие/withdraw logic?  
   **A:** Нет. Сохраняется то же существующее действие и `/withdraw`; backend/financial contracts не меняются.
5. **Q:** Локализация?  
   **A:** `Вывод` локализуется во всех 16 языках через существующий localization contract. Cycle0133 синхронизирует `history.open_withdraw` с `withdraw.title`.

## FRONTEND Profile local navigation — cycle 0134 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0134-01 — USER Profile: История → Баланс
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** сам раздел `Профиль → История` оставить как есть и ничего внутри него не переименовывать. Изменить только одну USER-кнопку локальной навигации Профиля с `История` на `Баланс`. Admin selected-user `История` не менять. Реализация выполняется через существующий `profile.section_history_tab` во всех 16 runtime locales и standalone parity.


## FRONTEND Panels theme chroma — cycle 0135 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0135-01 — Theme 12 Panels = violet
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** USER `/panels` в Theme 12 должна быть фиолетовой как единая theme family; разные синий/золотой/фиолетовый accent residues исправляются только в Panels scope.

### OWNER-DIRECT-2026-08-30-FR-0135-02 — Panels VIP indicator follows theme
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** VIP generation-tier indicator на USER Panels должен соответствовать цветовым оттенкам выбранной Global Theme, а не быть одного фиксированного цвета во всех темах.

### OWNER-DIRECT-2026-08-30-FR-0135-03 — other theme discrepancies are review-only
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** сначала только выявить другие цветовые расхождения, без автоматической мутации. В следующем OWNER-решении Cycle0136 все пять выявленных кандидатов были одобрены и исправлены: Theme 10 Panels hero, Theme 10 Panels portfolio active tab, Theme 12 Tasks, Theme 03 Panels activation и Theme 11 Panels activation. Отдельный historical audit-файл больше не является current dependency.

## FRONTEND theme chroma — cycle 0136 / OWNER DIRECT

### OWNER-DIRECT-2026-08-30-FR-0136-01 — исправить пять findings cycle0135
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** исправить все пять ранее перечисленных цветовых расхождений: Theme 10 Panels hero + portfolio active tab, Theme 12 Tasks, Theme 03 Panels activation и Theme 11 Panels activation. Изменения chroma-only; geometry/runtime/business contracts не меняются.

### OWNER-DIRECT-2026-08-30-FR-0136-02 — повторный аудит color seam
**Статус:** RESOLVED / IMPLEMENTED.

**Решение владельца:** после исправления выполнить новый аудит тем на цветовые разногласия. Повторный аудит выявил девять локальных historical color seams: Theme 13 Bottom Navigation marker; Theme 11 Bottom Navigation halo; Theme 09 Panels portfolio nested fields; Theme 04 Panels activation inner surface; Theme 09 Tasks hero/cards; Theme 02 FAQ; Theme 02 Profile/Balance History; Theme 04 FAQ; Theme 03 Exchange preview. OWNER Cycle0138 закрыл A1–A9 единым route-token authority: ordinary USER hero/card/inset backgrounds получают active Global Theme route chroma, а semantic/status colours остаются исключениями. Все девять кандидатов считаются реализованными; отдельный historical audit-файл больше не является current dependency.

## FRONTEND Global Themes — cycle 0139 / OWNER DIRECT

### OWNER-DIRECT-2026-08-31-FR-0139-01 — Theme 13 same architecture as Themes 01–12
**Статус:** RESOLVED / IMPLEMENTED.

**Q:** Theme 13 должна полностью подчиняться общей архитектуре Themes 01–12?  
**A:** Да.

### OWNER-DIRECT-2026-08-31-FR-0139-02 — Theme 13 palette
**Статус:** RESOLVED / IMPLEMENTED.

**Q:** Palette Theme 13 остаётся Black/Gold?  
**A:** Да.

### OWNER-DIRECT-2026-08-31-FR-0139-03 — роль gold
**Статус:** RESOLVED / IMPLEMENTED.

**Q:** Gold выполняет ту же роль, что accent в остальных темах, а не заливает ordinary surfaces?  
**A:** Да.

### OWNER-DIRECT-2026-08-31-FR-0139-04 — отмена Theme 13 special mode
**Статус:** RESOLVED / IMPLEMENTED.

**Q:** Убрать старый Theme 13 `no-glass / solid Black-Gold` special mode, если он мешает parity?  
**A:** Да.

### OWNER-DIRECT-2026-08-31-FR-0139-05 — полный USER scope
**Статус:** RESOLVED / IMPLEMENTED.

**Q:** Проверить и привести Theme 13 по всем USER-страницам/Global Theme families?  
**A:** Да, полностью.

### OWNER-DIRECT-2026-08-31-FR-0139-06 — Theme 03 tonal canon
**Статус:** RESOLVED / IMPLEMENTED.

**Решение OWNER:** `Theme 3` является каноном по цветовым оттенкам. Все остальные Global Themes должны использовать ту же относительную tonal hierarchy, сохраняя собственную palette. Theme 03 сама не перекрашивается cycle0139 и остаётся physical reference.


## FRONTEND Balance visual requirements — Cycle 0151 continuation / OWNER answers

Статус: **RESOLVED / IMPLEMENTATION AUTHORIZED**.

OWNER ответил на `QA-2026-08-31-FR-0151-BAL-01…05`. Scope следующего прохода строго tonal-only: никакой перестройки композиции, действий, фильтров или списка операций.

### QA-2026-08-31-FR-0151-BAL-01 — что именно сейчас делает страницу хуже
**Статус:** RESOLVED.  
**Ответ OWNER:** страница стала глобально слишком светлой. Нужен общий оттенок такой же семьи и интенсивности, как у текущих балансов.

### QA-2026-08-31-FR-0151-BAL-02 — композиция трёх балансов
**Статус:** RESOLVED.  
**Ответ OWNER:** оставить точно как сейчас. Три баланса, их DOM/geometry/typography не менять.

### QA-2026-08-31-FR-0151-BAL-03 — цвет и материал Theme03
**Статус:** RESOLVED.  
**Ответ OWNER:** оттенок страницы должен быть как у балансов. Не создавать дополнительные локальные mini-shades.

### QA-2026-08-31-FR-0151-BAL-04 — действия и фильтры
**Статус:** RESOLVED.  
**Ответ OWNER:** вариант A — сохранить текущую сетку `CSV | XLSX / Обновить | Вывод` 2×2 и существующие фильтры.

### QA-2026-08-31-FR-0151-BAL-05 — вид списка операций
**Статус:** RESOLVED.  
**Ответ OWNER:** оставить текущий список операций без изменений.

### OWNER-DIRECT-2026-08-31-FR-0151-BAL-TONES — закон масштабируемых оттенков
**Статус:** RESOLVED / SUPERSEDED FOR CURRENT VISUAL SCOPE BY OWNER-DIRECT-2026-09-01-FR-0151-RANKS-REFERENCE-REBRAND.

На странице Баланс меняются только оттенки. Количество ordinary shades должно быть минимальным и масштабируемым на остальные Global Themes. Для текущего Theme03 запрещено создавать новый локальный оттенок специально для Balance: active Balance/History page должен использовать уже существующий semantic ordinary role `inset`, тот же role, который потребляют balance rows. Active/selected/CTA и `FINANCIAL_LOCAL` EFHC/EFHCm/EFHCb markers сохраняют отдельную семантику.

### OWNER-DIRECT-2026-08-31-FR-0151-DEMO-ADMIN-PARITY — закон DEMO access parity
**Статус:** RESOLVED / ACTIVE.

Standalone DEMO не имеет права напрямую рисовать, показывать или скрывать Admin UI через отдельную preview-role переменную. Каноническая цепочка: `simulated backend /admin/access → simulation engine response → frontend adminAccessState/isAdmin → conditional Admin UI`, то есть та же архитектурная граница, что и production. Workbench `USER / ADMIN` меняет только состояние движка имитации. Frontend обязан отобразить результат backend-access contract; USER закрывает Admin entrypoints/status/routes, ADMIN разрешает их. Это не выдаёт реальных серверных прав.


## FRONTEND Theme03 Profile / Balance / Exchange / Header / HUB — Cycle 0151 v315 OWNER DIRECT

### OWNER-DIRECT-2026-09-01-FR-0151-RANKS-REFERENCE-REBRAND
**Статус:** RESOLVED / IMPLEMENTED / OWNER VISUAL QUALIFICATION REQUIRED.

**Решение OWNER:** Profile и Balance признаны визуально регрессировавшими; прежний tonal-only scope для Balance больше не является текущим ограничением. Для обеих страниц визуальным примером является `Ранги`. Theme03 должен быть упрощён до небольшого масштабируемого набора material roles, чтобы корректировка темы не ломала соседние элементы.

**Реализация v315:** `Page/Canvas → Hero → Card → Inset → Accent/Active`; route-local mini-shades не добавляются. Profile generic layout row под conditional Admin marker transparent; Profile Hero не имеет local spotlight. Balance snapshot = Card, rows/operations/filters = Inset, active filter = Active. Runtime/data/D8/asset semantics защищены.

### OWNER-DIRECT-2026-09-01-FR-0151-THEME03-EXCHANGE-HEADER-HUB
**Статус:** RESOLVED / IMPLEMENTED / OWNER VISUAL QUALIFICATION REQUIRED.

**Решение OWNER:** Theme03: исправить ошибочный синий оттенок `Получите · EFHCm`, неправильный цвет Header `+ EFHC` и неправильный цвет HUB.

**Реализация v315:** Exchange receive value → existing Theme03 Accent; Header secondary actions (`+ EFHC` включительно) → neutral Text/ChromeInset, HUB primary → Accent; HU-03 launcher surfaces → Ranks-reference Card/Inset/Accent. Новые physical colour values не создаются.

## FRONTEND UI/UX audit/TZ — Cycle0224 OWNER Q&A round 1

Статус: **PARTIALLY RESOLVED / Q1–Q3 RESOLVED / Q4–Q5 OPEN / PLAN FREEZE DEFERRED BY OWNER SECURITY OVERRIDE IN CYCLE0225**.

### QA-2026-09-12-FR-0224-01 — состав хвостов 0226–0234
**Статус:** RESOLVED / OWNER=A.

**Q:** Подтверждаете, что Cycles0226–0234 до UI-программы закрывают именно этот набор технических хвостов: Operator Kernel route; Referrals selected CSV server scope + frontend wiring; VIP number-map owner scope + frontend wiring; Users→Balance/History future exact-one-user export guard; cumulative backend handoff; cross-contour security acceptance; tail closure?

**Варианты:** A — да, этот набор; B — нет, укажите какие хвосты добавить/убрать.

**Рекомендация оператора:** A — это все подтверждённые текущим HEAD pre-UI хвосты, без speculative refactor.

**Ответ OWNER:** A.

### QA-2026-09-12-FR-0224-02 — полный TON-адрес в приватном Профиле
**Статус:** RESOLVED / OWNER=A.

**Q:** Разрешить в приватном Профиле раскрытие и копирование полного адреса собственного привязанного TON-кошелька, при этом public Shop сохраняет действующий privacy-lock с маскированным адресом?

**Варианты:** A — да, полный адрес только в приватном Профиле; B — нет, сохранять маску и там.

**Рекомендация оператора:** A — пользователь сможет проверить собственный адрес перед действиями, а публичная граница Shop не ослабляется.

**Ответ OWNER:** A.

### QA-2026-09-12-FR-0224-03 — термины Wallet binding/session
**Статус:** RESOLVED / OWNER=A.

**Q:** Зафиксировать пользовательские термины: серверная запись кошелька = «Привязан», текущая TON Connect-сессия = «Подключён»?

**Варианты:** A — да; B — использовать другие термины, укажите формулировки.

**Рекомендация оператора:** A — это прямо разделяет два разных факта состояния без изменения wallet logic.

**Ответ OWNER:** A.

### QA-2026-09-12-FR-0224-04 — технический ID ожидания Shop
**Статус:** RESOLVED / OWNER=A in Cycle0226.

**Q:** В пользовательском сообщении ожидания Shop после удаления термина `PaymentIntent` сам технический идентификатор тоже скрыть или оставить как нейтральный «ID платежа»?

**Варианты:** A — скрыть технический ID из обычного customer notice; B — показывать как «ID платежа: …».

**Ответ OWNER:** A — скрыть технический ID из обычного customer notice. OWNER уточнил «если это опасно»; оператор квалифицирует публикацию внутреннего идентификатора как ненужное техническое раскрытие/UX-шум, поэтому customer notice должен его скрывать, сохраняя диагностический контур отдельно. Реализация остаётся в запланированном UI-22, после OWNER-сдвига это MAIN0273–0274.

### QA-2026-09-12-FR-0224-05 — визуальное согласование Header/Nav
**Статус:** RESOLVED / OWNER=B in Cycle0226.

**Q:** Для UI-23/UI-24 после реальных измерений Header и нижней навигации оператор должен применить минимальную EAM/canon-compliant коррекцию самостоятельно или сначала показать OWNER конкретный вариант до мутации?

**Варианты:** A — минимальную коррекцию можно применять самостоятельно после измеренного FAIL; B — сначала OWNER visual qualification конкретного варианта.

**Ответ OWNER:** B — после измеренного FAIL сначала показать OWNER конкретный вариант; Header/Nav не мутировать до OWNER visual qualification. После OWNER-сдвига +7 это относится к MAIN0275–0278.

### QA-2026-09-13-FR-0224-06 — восстановление геометрии Admin Search после регресса
**Статус:** RESOLVED / IMPLEMENTED IN CORRECTIVE CYCLE0224 / FRONTEND_v430.

**Q:** Как именно восстановить search-блоки после визуального регресса и какие Admin-модули охватить?

**Ответ OWNER:** использовать фактическое окно `Выдача / VIP NFT` из `FRONTEND_v425` как геометрический донор; текущую чёрно-фиолетовую цветовую схему v429 сохранить. На страницах `Входящие платежи EFHC`, `Выдача / VIP NFT`, `Отчёты и журналы`, `Заказы`, `Рефералы`, `Панели` search-блок должен иметь одну широкую строку ввода сверху и две равные кнопки `Найти` / `Сбросить` снизу. Меняется только search-блок; окружающие KPI/списки/журналы/прочие элементы не являются частью этого исправления.

**Отдельное решение OWNER по `Заказы`:** два прежних search-поля не сохранять. Использовать одно универсальное поле для `Global ID`, `ShopOrder ID` или `TON-кошелька`; не создавать второй визуальный search-контур.

**Граница реализации:** существующая server-authority сохраняется; TON/provider input разрешается только через уже существующий server resolver к однозначному `global_id`, без browser-owner inference и без нового speculative endpoint.

## FRONTEND Cycle0225 — Reports/Logs Global-ID security correction OWNER Q&A

### QA-2026-09-13-FR-0225-01 — selected Global ID export fail-closed
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** при выбранном Global ID журнал и экспорт обязаны использовать server-side owner scope; если backend не подтверждает scope, файл не скачивается. Общий export разрешён только когда Global ID не выбран.

### QA-2026-09-13-FR-0225-02 — foreign/unproven row
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** при selected Global ID любая строка другого пользователя либо строка без доказуемого owner блокирует весь scoped result/export. Browser-side отбрасывание чужих строк и продолжение запрещено.

### QA-2026-09-13-FR-0225-03 — frontend/backend boundary
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** Frontend исправляет единый page-local state и fail-closed поведение; отдельное backend requirement для `/admin/logs/transfers?global_id=...` фиксируется без ложного заявления, что official backend MAIN уже изменён.

### QA-2026-09-13-FR-0225-04 — Reports page composition
**Статус:** RESOLVED / OWNER=A/A/A.

**Решение OWNER:** удалить блок `Скачать отчёт`; на его место поставить canonical Global-ID search. Нижний отдельный блок `Global ID для экранного списка` удалить полностью. Единственный экранный user-event contour — `Журналы`. Без Global ID журнал имеет общий безопасный export; с Global ID экран и export используют один owner scope + текущие filters. Кнопки выровнять аккуратно.

### OWNER-DIRECT-2026-09-13-FR-0225-GLOBAL-ID-WHOLE-MODULE
**Статус:** ACTIVE OWNER LAW.

Если Admin-страница имеет поиск по Global ID, выбранный ID является единым page-local owner scope для всех user/player-bearing частей текущего открытого модуля. Независимые несинхронизированные state одного page key запрещены. Runtime/security authority: `docs/admin/ADMIN_GLOBAL_ID_EXPORT_CANON.md`.


### CYCLE0225-CLOSURE-2026-09-13

Cycle0225 direct OWNER security decisions are implemented in `FRONTEND_v431`. `QA-2026-09-12-FR-0224-04` and `QA-2026-09-12-FR-0224-05` remain OPEN; their reconciliation and the draft-roadmap freeze are deferred to Cycle0226. This deferral does not reopen resolved Q1–Q3 or the Cycle0225 security decisions.


### OWNER-DIRECT-2026-09-13-FR-0225-ADMIN-JSON-EXPORT
**Статус:** ACTIVE OWNER LAW / IMPLEMENTED v434.

Если Admin-модуль уже имеет функционирующую выгрузку, JSON обязан быть доступен как равноправный AI-friendly формат и использовать тот же scope, filters, row limits и security boundary, что существующий CSV/XLSX export. Нельзя создавать speculative backend endpoint либо обходить fail-closed ради JSON. Referrals остаётся исключён из работающей выгрузки до доказанного server-side selected-user scope.


### QA-2026-09-13-FR-0226-01 — OWNER cycle insertion / +7 shift
**Статус:** RESOLVED / DIRECT OWNER.

**Решение OWNER:** зарезервировать Cycles0226–0232 для решения текущих проблем. Прежний Cycle0226 переносится на Cycle0233; все прежние последующие 60 MAIN-циклов сдвигаются на +7 без потери их scope. Поэтому прежний tail 0226–0234 становится 0233–0241, UI/UX 0235–0285 становится 0242–0292, а comprehensive checkpoint MAIN0236 становится MAIN0243. Cycles0227–0232 не получают выдуманный scope: задача задаётся OWNER или подтверждённым текущим дефектом.


### QA-2026-09-13-FR-0227-01 — Withdrawals Global-ID scope
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** точный Global ID является page-local owner scope для всей пользовательской очереди «Выплаты»; Reset возвращает общий режим. Системная агрегированная аналитика `/admin/reports/withdrawals` остаётся общей.

### QA-2026-09-13-FR-0227-02 — payout journal dataset
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** журнал выгружает все выплаты по всем статусам `PENDING/PAID/REJECTED/CANCELED` независимо от текущего status/VIP-фильтра очереди. При selected Global ID — только выплаты этого owner.

### QA-2026-09-13-FR-0227-03 — payout journal formats
**Статус:** RESOLVED / OWNER=B.

**Решение OWNER:** журнал «Выплаты» имеет peer formats `JSON / CSV / TXT / XLSX` с компактными format-only labels.

### QA-2026-09-13-FR-0227-04 — backend route decision
**Статус:** RESOLVED / OWNER=A.

**Решение OWNER:** использовать backend canon/snapshot и создавать необходимые маршруты, если аналогов нет. Проверка v175_34 показала существующий `GET /admin/withdrawals` с optional `global_id`, `status`, `vip_only`, `limit`, `offset`; он достаточен как единый transport, поэтому speculative duplicate export route не создаётся. Selected rows дополнительно проходят frontend owner proof/fail-closed.


## FRONTEND Admin Withdrawals visual correction — Cycle0228 / OWNER DIRECT

### QA-2026-09-14-FR-0228-01 — cycle number after closed Cycle0227
**Вопрос:** переоткрывать Cycle0227 или использовать следующий reserved Cycle0228?  
**Ответ владельца:** A — использовать `FRONTEND_ADMIN_CYCLE_0228`; Cycle0227 не переоткрывать.

### QA-2026-09-14-FR-0228-02 — journal action geometry
**Вопрос:** как расположить `JSON / CSV / TXT / XLSX`?  
**Ответ владельца:** A — четыре равные кнопки на всю доступную ширину одной строкой; дополнительно уменьшить высоту примерно на 20%. Реализация фиксирует `1.6rem` minimum height против прежнего `2rem` strip baseline.

### QA-2026-09-14-FR-0228-03 — visible search heading
**Вопрос:** какое название оставить над Global-ID поиском?  
**Ответ владельца:** B — `Global ID`. Предыдущая машинная трактовка ответа `3. В` как варианта C была ошибкой оператора; OWNER не разрешал удалять надпись `Global ID`.

### OWNER-DIRECT-2026-09-14-FR-0228-04 — material/copy boundary
Search и `JSON / CSV / TXT / XLSX` привести к active black-violet Theme03 canon; удалить visible technical subtitle `Поиск ограничивает...`; удалить initial standalone footer hint `Перед подтверждением проверьте пользователя, адрес и точную сумму выплаты.`; рабочую Cycle0227 search/export/security логику сохранить.

## FRONTEND Admin Withdrawals matryoshka correction — Cycle0228 continuation / OWNER DIRECT

### OWNER-DIRECT-2026-09-14-FR-0228-05 — keep Cycle0228 open until Withdrawals is visually fixed
**Статус:** ACTIVE OWNER LAW.

Cycle0228 не закрывать и не переключать MAIN на 0229, пока OWNER не подтвердит исправление страницы «Выплаты». Каждая corrective iteration обновляет physical HEAD, numbered report, ledger и current authority, но остаётся `FRONTEND_ADMIN_CYCLE_0228`.

### QA-2026-09-14-FR-0228-06 — outer tools card vs matryoshka
**Ответ OWNER:** B — оставить одну общую внешнюю карточку Global-ID/search + JSON/CSV/TXT/XLSX, но убрать внутреннюю visual-card оболочку поиска.

### QA-2026-09-14-FR-0228-07 — Global-ID search material after flattening
**Ответ OWNER:** A — search wrapper не является отдельным окном; остаются только input + `Найти`/`Сбросить` на фоне общей внешней карточки. Black-violet применяется к самим input/buttons.

### QA-2026-09-14-FR-0228-08 — queue boundary
**Ответ OWNER:** A — блок `Очередь заявок` не менять; corrective scope ограничен tools-card перед очередью.

### OWNER-DIRECT-2026-09-14-FR-0228-09 — v438 outer-card rejection / full flatten
**Статус:** ACTIVE OWNER LAW / supersedes QA-2026-09-14-FR-0228-06 for current visual composition.

OWNER повторно сообщил, что в `FRONTEND_v438` запрещённая «матрёшка» не устранена. Поскольку v438 уже имел только один внешний tools-card и прозрачный внутренний search wrapper, оставшийся внешний visual-card material считается отвергнутым. Current correction: tools wrapper является только structural grouping и не рисует собственные border/background/radius/padding/shadow; input/buttons остаются самостоятельными controls. `Очередь заявок` не меняется.

### OWNER-DIRECT-2026-09-14-FR-0228-10 — Global ID label restoration
**Статус:** ACTIVE OWNER LAW.

OWNER не давал разрешения удалять надпись `Global ID`. Ответ `3. В` в исходном опросе соответствует варианту B — `Global ID`. Видимая подпись `Global ID` должна быть восстановлена как обычный label над полем без отдельной карточки/подложки.

## FRONTEND Admin Reports/Logs visual correction — Cycle0229 / OWNER DIRECT

### OWNER-DIRECT-2026-09-14-FR-0229-00 — advance to Cycle0229
**Статус:** ACTIVE OWNER LAW.

OWNER explicitly instructed to continue with `FRONTEND_ADMIN_CYCLE_0229`. This closes Cycle0228 at `FRONTEND_v439` and assigns reserved Cycle0229 to Admin «Отчёты и журналы». Cycle0229 stays open until OWNER visually accepts the page.

### QA-2026-09-14-FR-0229-01 — Global-ID matryoshka
**Ответ OWNER:** A — use the accepted Withdrawals pattern: no visual outer/search card. Keep plain visible `Global ID`, one full-width field and equal `Найти` / `Сбросить`; only actual controls carry Theme03 material.

### QA-2026-09-14-FR-0229-02 — journal export geometry
**Ответ OWNER:** A — `JSON / CSV / TXT / XLSX` are four equal buttons on one line and MUST scale with device/container width. Implementation uses responsive `repeat(4,minmax(0,1fr))`, not fixed pixel widths.

### QA-2026-09-14-FR-0229-03 — apply-button feedback
**Ответ OWNER:** B — keep text `Применить фильтры`; show a clearly visible pressed/flash reaction on click. No `Применено ✓` text and no extra status message.

### OWNER-DIRECT-2026-09-14-FR-0229-04 — filter action semantics and placement
`Журналы` is left and `Применить фильтры` right on the same top row. The button must be functional, not decorative: source/status/time selections are pending until apply, then become the active screen/export filter set. Existing server Global-ID scope/export security is unchanged.


### OWNER-DIRECT-2026-09-14-FR-0229-05 — export row vertical spacing / button height
**Статус:** ACTIVE OWNER LAW.

OWNER requested the `JSON / CSV / TXT / XLSX` row on Admin «Отчёты и журналы» to sit slightly lower and the four actions to be slightly taller, while preserving equal responsive widths. `FRONTEND_v441` keeps `repeat(4,minmax(0,1fr))`, adds a small vertical offset before the export row, and raises button minimum height from `1.6rem` to `1.9rem`. Global-ID flattening, visible `Global ID`, filter-apply behavior and export/security semantics remain unchanged.


## FRONTEND Admin Orders visual correction — Cycle0231 / OWNER DIRECT

### OWNER-DIRECT-2026-09-16-FR-0231-00 — advance to Cycle0231
**Статус:** ACTIVE OWNER LAW.

OWNER explicitly instructed to continue with `FRONTEND_ADMIN_CYCLE_0231`. This closes Cycle0230 at `FRONTEND_v442` and assigns reserved Cycle0231 to Admin «Заказы». Cycle0231 stays open until OWNER visually accepts the Orders page.

### QA-2026-09-16-FR-0231-01 — search panel width
**Ответ OWNER:** do not rebuild the internal universal-search geometry. «Просто панель расширить по ширине экрана аккуратно. Сейчас она немного сжата.» Implementation slightly widens the whole «Поиск заказа» panel symmetrically while preserving one full-width input + `Найти` / `Сбросить`.

### QA-2026-09-16-FR-0231-02 — paid-log export geometry
**Ответ OWNER:** A — `JSON / CSV / XLSX` are three equal responsive columns across the available width. Current canon action height `1.9rem` is retained.

### QA-2026-09-16-FR-0231-03 — copy-removal boundary
**Ответ OWNER:** B — remove only the three explicitly named technical records, not every helper/status string on the page. The production wording-equivalent of the paid-Shop-only subtitle is within this removal. Unrelated helper/status/error feedback remains. Invalid input feedback is neutralized to `Некорректный запрос.` rather than repeating the removed instruction.

### QA-2026-09-16-FR-0231-04 — universal-search placeholder
**Ответ OWNER:** A — preserve `Global ID, ShopOrder ID или TON-кошелёк` inside the search input.


## FRONTEND Admin Bank EFHC visual correction — Cycle0232 / OWNER DIRECT

### OWNER-DIRECT-2026-09-16-FR-0232-00 — advance to Cycle0232
**Статус:** ACTIVE OWNER LAW.

OWNER explicitly instructed to continue with `FRONTEND_ADMIN_CYCLE_0232`. This closes Cycle0231 at `FRONTEND_v443` and assigns reserved Cycle0232 to Admin «Банк EFHC». Cycle0232 stays open until OWNER visually accepts the Bank page.

### QA-2026-09-16-FR-0232-01 — Bank export geometry
**Ответ OWNER:** A — `JSON / CSV / XLSX` are three equal responsive columns across the available export width, with current canon action height `1.9rem`.

### QA-2026-09-16-FR-0232-02 — rows selector geometry and label
**Ответ OWNER:** A with clarification — the `<select>` itself must have the same `1.9rem` height as `JSON / CSV / XLSX` and share their lower baseline. Visible label `Строк` must be removed; an accessible `aria-label` remains.

### QA-2026-09-16-FR-0232-03 — Bank technical subtitle
**Ответ OWNER:** A — remove both production and standalone wording variants of `Полная выгрузка банковского журнала без постоянного списка на странице...` completely.

### OWNER-DIRECT-2026-09-16-FR-0232-04 — protected boundary
The two old Orders technical strings named again in the Cycle0232 task were already removed in Cycle0231 and must remain absent. Bank export transport, row-limit semantics, dataset/backend/security contracts and prior accepted donor pages are not part of this visual/copy correction.


### QA-2026-09-16-FR-0232-05 — Bank title/control separation
**Ответ OWNER:** A — keep one Bank card and separate `Логи Банка` from the export-control row by `.65rem`; do not create a nested card.

### QA-2026-09-16-FR-0232-06 — row-limit selector canon propagation
**Ответ OWNER:** A — use the Bank selector as the visual canon on every verified Admin export row-limit selector. Physical parent `FRONTEND_v444` contains four: Bank EFHC, Panels, Orders, Direct EFHC deposits. All use `1.9rem` height, `.55rem` radius, Theme03 black/violet material, no visible `Строк`, and `aria-label="Строк экспорта"`.

### QA-2026-09-16-FR-0232-07 — row-limit/export responsive composition
**Ответ OWNER:** A — selector left and existing export strip right on normal widths; on narrow screens the selector may stack above the buttons. Existing export formats and data semantics are unchanged.


### CYCLE0233-FREEZE-2026-09-17

Статус: **RESOLVED / FROZEN**.

Cycle0233 records existing OWNER answers without reopening them: `QA-2026-09-12-FR-0224-04 = A` and `QA-2026-09-12-FR-0224-05 = B`. Tail `0233–0241` and UI/UX `0242–0292` are frozen; active Kernel MAIN routing moves to `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md`.

### OWNER-DIRECT-2026-09-17-ADMIN-VISUAL-FREEZE

Статус: **ACTIVE OWNER LAW**.

OWNER visually accepts the current Admin panel state from `FRONTEND_v445` and declares the Admin panel visually ready. Before any subsequent owner-visible visual Admin change, the operator must warn OWNER in advance and identify the affected page/family. This does not remove stricter existing approval gates and does not authorize unrelated visual changes. Current canon: `docs/SSOT/ADMIN_FREEZE_CANON.md`.

## FRONTEND Admin Back/Menu clarification — Cycle0253 / 2026-09-21

### QA-2026-09-21-FR-0253-01 — Что означает «верхняя Admin-панель» из Cycle0113
**Статус:** RESOLVED / OWNER CORRECTION.

**Уточнение OWNER:** верхняя панель — это настоящий Header. Кнопки `← Назад` и `☰ Меню` к Header не относятся.

**Следствие для реализации:** прежнее распространение sticky-поведения `.efhc-admin-header` / standalone Admin topbar на блок `Назад / Меню` было ошибочной интерпретацией. Cycle0253 возвращает этот page-local блок в обычный поток прокрутки, не меняя статичность настоящего Header. Cycle0254 предназначен для проверки всех Admin-страниц и закрытия corrective.

## FRONTEND Bottom Nav canonical text boundary — Cycle0295 / 2026-09-22

### OWNER-DIRECT-2026-09-22-FR-0295-01 — Bottom Nav label maximum is the established area
**Статус:** ACTIVE OWNER LAW / supersedes Cycle0294 Candidate A application path.

OWNER explicitly forbids increasing Bottom Nav button-label font beyond the established canonical button/label area. If a fixed-English label reaches the boundary of that established area, that is its maximum permitted size and the canon.

The six labels remain exactly `Energy`, `Panels`, `Exchange`, `Tasks`, `Referrals`, `Ranks`. Fit must not be achieved by increasing text beyond the canonical area, shrinking/compressing/deforming it, `scaleX`, wrapping/splitting a word, enlarging cells for further text growth, converting the nav to 3×2, abbreviating/relabeling, removing items or changing order/routes.

Cycle0294 Candidate A is not approved and must not be applied. Cycle0295 is reassigned by direct OWNER instruction to documentation-only reconciliation of this canon; product Bottom Nav CSS/DOM/JS remains unchanged.



## Legacy Cycle0050 external Shop/VIP draft — absorbed

Статус: `RESOLVED / SOURCE ABSORBED`. Отдельный draft `FRONTEND_EXTERNAL_SHOP_VIP_CANON_QA_v199.md` больше не является самостоятельным документом. Его 10 вопросов не открываются повторно; ответы находятся в действующем реестре:

1. Общая commerce surface / routes → QA-M11-01, QA-M11-95…103.
2. Что означает открытие в web версии → QA-M11-01.
3. Telegram signed handoff для Shop/VIP → QA-M11-01, QA-M11-96, QA-M11-103.
4. Shop checkout против GetGems для VIP → QA-M11-02, QA-M11-05, QA-M11-95, QA-M11-96, QA-M11-103.
5. Generic VIP NFT против конкретного NFT → QA-M11-05, QA-M11-17.
6. Методы оплаты VIP NFT → QA-M11-06.
7. Paid/waiting/delivered status → QA-M11-17 и последующие M11 решения по заказам/выдаче.
8. Manual issuance против автоматического transfer/mint → QA-M11-17, QA-M11-21.
9. Судьба прямого GetGems пути → QA-M11-02, QA-M11-96, QA-M11-103.
10. Guest catalog / account gate → QA-M11-01, QA-M11-07 и последующие Shop account решения.

## OWNER Q&A — FRONTEND_ADMIN_CYCLE_0376 — audit Cycle0372 + Cycle0375

### QA-2026-10-04-FR-0376-01 — USER content under Bottom Nav
**Вопрос:** Контент при прокрутке должен никогда визуально не заходить под Bottom Nav?
**Ответ OWNER:** Да. Допустимо подходить по самому краю Bottom Nav, но страница не должна уходить под него.

### QA-2026-10-04-FR-0376-02 — lower scroll boundary
**Вопрос:** Где заканчивается нижняя граница прокрутки?
**Ответ OWNER:** По верхнему краю Bottom Nav.

### QA-2026-10-04-FR-0376-03 — coverage
**Вопрос:** Применять правило ко всем USER-страницам и подстраницам с Bottom Nav?
**Ответ OWNER:** Да, без исключений.

### QA-2026-10-04-FR-0376-04 — short pages
**Вопрос:** Нужен ли безопасный финальный отступ и на коротких страницах?
**Ответ OWNER:** Да, на всякий случай.

### QA-2026-10-04-FR-0376-05 — fixed Bottom Nav
**Вопрос:** Bottom Nav остаётся фиксированным, а исправляется именно область/граница прокрутки?
**Ответ OWNER:** Да.

### QA-2026-10-04-FR-0376-06 — Theme03 material authority
**Вопрос:** Какой стиль является каноническим для My Panels direction control в Theme03?
**Ответ OWNER:** Существующий чёрно-фиолетовый стиль Theme03, уже многократно закреплённый в документации и Kernel/каноне.

### QA-2026-10-04-FR-0376-07 — both directions
**Вопрос:** Одинаковый Theme03 стиль нужен и для `↑`, и для `↓`?
**Ответ OWNER:** Да.

### QA-2026-10-04-FR-0376-08 — full control, not glyph-only
**Вопрос:** Меняется только символ стрелки?
**Ответ OWNER:** Нет. Фон, рамка и стрелка должны соответствовать чёрно-фиолетовому Theme03. Текущий серый фон ошибочен. Геометрия и поведение не открыты.

### QA-2026-10-04-FR-0376-09 — exact observed defect
**Вопрос:** Серой является сама стрелка?
**Ответ OWNER:** Нет. Серой стрелки нет; проблема — ошибочный серый фон контрола.

### QA-2026-10-04-FR-0376-10 — verification method
**Вопрос:** Каким способом подтверждать исправления?
**Ответ OWNER:** Любым доступным способом; важно доказать фактический результат.

## FRONTEND Global Themes final material architecture — Cycle0381 OWNER answers

Статус: **RESOLVED / AUDIT AUTHORITY / IMPLEMENTATION STARTS AFTER CYCLE0381**.

### QA-2026-10-05-FR-0381-01 — Theme03 reference
**Ответ OWNER:** да. Сначала создать полную карту всех элементов Theme03, затем глобально исправлять остальные темы по этой архитектуре.

### QA-2026-10-05-FR-0381-02 — black material
**Ответ OWNER:** Theme03 black is not an empty/pure-black hole. Ordinary dark material must keep a subtle violet/plum tint.

### QA-2026-10-05-FR-0381-03 — scalable tonal levels
**Ответ OWNER:** дополнительные tonal levels допустимы только если они owned globally by the theme and can be projected to other themes; page-local mini-shades are not acceptable.

### QA-2026-10-05-FR-0381-04 — ordinary surface intensity
**Ответ OWNER:** prefer the first option: almost-black with a barely visible violet tint rather than a visibly purple eggplant surface.

### QA-2026-10-05-FR-0381-05 — hero
**Ответ OWNER:** hero should probably read slightly stronger than ordinary surfaces through tint/border, without a large violet slab.

### QA-2026-10-05-FR-0381-06 — secondary controls
**Ответ OWNER:** yes. Ordinary buttons/filters/secondary actions stay dark with a theme tint; violet is mainly contour/icon/text accent.

### QA-2026-10-05-FR-0381-07 — active/pressed
**Ответ OWNER:** yes. Active/pressed must not become a bright violet slab; use a somewhat stronger dark violet-tinted material plus accent contour.

### QA-2026-10-05-FR-0381-08 — primary actions
**Ответ OWNER:** primary may be stronger than secondary, but it still remains inside the same restrained Theme03 architecture.

### QA-2026-10-05-FR-0381-09 — state family
**Ответ OWNER:** yes. Hover/pressed/selected/active vary intensity of the same material family instead of jumping to unrelated colours.

### QA-2026-10-05-FR-0381-10 — glow
**Ответ OWNER:** focus on the already identified problem elements; do not create a new broad glow redesign.

### QA-2026-10-05-FR-0381-11 — one system, not 13 redesigns
**Ответ OWNER:** do not design 13 separate systems. Build one complete Theme03 system, then scale that architecture to the other themes.

### QA-2026-10-05-FR-0381-12 — common semantics
**Ответ OWNER:** yes. All 13 USER themes share the same element/material semantics and differ by palette.

### QA-2026-10-05-FR-0381-13 — preserve theme identity
**Ответ OWNER:** yes. Preserve each theme's individual palette/character while applying the common architecture.

### QA-2026-10-05-FR-0381-14 — no pre-audit of 12 other themes
**Ответ OWNER:** do not spend a separate visual-audit program on every other theme. Create the Theme03 element/rule matrix first; the other themes are then applied from zero by palette onto all mapped elements.

### QA-2026-10-05-FR-0381-15 — order of work
**Ответ OWNER:** yes. Finish Theme03 first, then scale its architecture globally.

### QA-2026-10-05-FR-0381-16 — Admin
**Ответ OWNER:** Admin remains untouched/frozen; use only as an already permitted visual reference where relevant.

### QA-2026-10-05-FR-0381-17 — Theme03 freeze status
**Ответ OWNER:** Theme03 is almost ready, but not fully final; its final material calibration is therefore reopened.

### QA-2026-10-05-FR-0381-18 — validation
**Ответ OWNER:** maintain a matrix of all elements for every theme; validation must be matrix-based rather than isolated CSS presence.

### QA-2026-10-05-FR-0381-19 — USER scope
**Ответ OWNER:** include Energy, Panels, Exchange, Tasks, Referrals/My Referrals, Ranks, Profile, Wallet/Balance/History, Withdraw, FAQ, Settings/Language and associated USER overlays/modals; current page registry coverage remains applicable.

### QA-2026-10-05-FR-0381-20 — Cycle0380 acceptance and next work
**Ответ OWNER:** yes. Cycle0380 is physically completed but not OWNER-accepted as the final visual result. Cycle0381 is audit/matrix/roadmap only; no product UI correction in this cycle.

## OWNER Q&A — Global Themes remediation / Cycle0451–0452 — 2026-10-14…15

Статус: **RESOLVED / CURRENT OWNER AUTHORITY**. Этот раздел фиксирует все последние раунды уточняющих вопросов, заданных OWNER перед исправлением Theme03 Ranks, social-share и запуском Cycle0452. Прямые OWNER-команды, которые не были вопросами, дополнительно отражены в действующих theme-docs и guards.

### Theme03 Ranks — shared action design

#### QA-2026-10-14-FR-0451-01 — nature of Ranks button defect
**Вопрос:** `Найти меня` и `Обновить` в Theme03 выглядят слишком чёрными из-за тёмного фона?
**Ответ OWNER:** нет. Они вообще не чёрные, они явно фиолетовые. Дефект состоит в том, что только Theme03 имеет другой дизайн этих кнопок.

#### QA-2026-10-14-FR-0451-02 — target comparison
**Вопрос:** сохранить отдельный фиолетовый характер Theme03, но сделать кнопки визуально похожими на Theme04?
**Ответ OWNER:** нет отдельного варианта. Theme03 должна быть согласована так же, как Themes01–02 и Themes04–13. Возникает вопрос именно почему Theme03 отличается от остальных.

#### QA-2026-10-14-FR-0451-03 — what to copy from other themes
**Вопрос:** какую часть material брать как эталон — shadow, highlight, background, border или весь дизайн?
**Ответ OWNER:** полностью использовать такой же дизайн одинаковых кнопок, как в Themes01–02 и Themes04–13.

#### QA-2026-10-14-FR-0451-04 — equality of the two Ranks actions
**Вопрос:** должны ли `Найти меня` и `Обновить` выглядеть одинаково в обычном состоянии?
**Ответ OWNER:** да, как во всех других темах.

#### QA-2026-10-14-FR-0451-05 — interactive states
**Вопрос:** должны ли hover / active / focus Theme03 использовать тот же визуальный принцип, что и остальные темы?
**Ответ OWNER:** да, как во всех других темах.

### Referrals social-share — brand ownership

#### QA-2026-10-14-FR-0451-06 — social buttons in scope
**Вопрос:** какие именно социальные кнопки требуют исправления?
**Ответ OWNER:** страница `Рефералы`, кнопки с логотипами социальных сетей для публикации/поделиться реферальной ссылкой.

#### QA-2026-10-14-FR-0451-07 — icon colour authority
**Вопрос:** должны ли логотипы соцсетей сохранять постоянные фирменные цвета независимо от Theme01–13?
**Ответ OWNER:** да. На момент фиксации проблема наблюдается в Theme01 и Theme02; в остальных темах цвета выглядят правильно.

#### QA-2026-10-14-FR-0451-08 — what remains theme-owned
**Вопрос:** должны ли фон/рамка social-share button оставаться theme-owned, а неизменным быть только цвет логотипа?
**Ответ OWNER:** да. Форма также остаётся индивидуальной для темы.

#### QA-2026-10-14-FR-0451-09 — social interactive states
**Вопрос:** должен ли фирменный цвет иконки сохраняться при hover / active / focus / pressed?
**Ответ OWNER:** да.

#### QA-2026-10-14-FR-0451-10 — global guard coverage
**Вопрос:** исправлять только Theme01/02 или зафиксировать глобальный brand-colour contract для всех Theme01–13?
**Ответ OWNER:** зафиксировать глобально для всех тем; фактически дефект был отмечен только в Theme01 и Theme02.

### Cycle0452 — Energy progress bar + Global Theme selector dots

#### QA-2026-10-14-FR-0452-01 — Energy progress scope
**Вопрос:** на странице `Энергия` тематизируется один основной progress bar или все возможные индикаторы?
**Ответ OWNER:** только основной индикатор прогресса; он там один.

#### QA-2026-10-14-FR-0452-02 — theme-linked progress colour
**Вопрос:** должен ли Theme01–13 иметь собственный progress colour, связанный с palette Global Theme?
**Ответ OWNER:** да.

#### QA-2026-10-14-FR-0452-03 — add only missing/wrong chroma
**Вопрос:** сохранять корректные существующие цвета и добавлять/исправлять только отсутствующие или чужие?
**Ответ OWNER:** да; при этом базовый размер/вид надо согласовать с уже удачными Theme01/Theme03 и систематизировать.

#### QA-2026-10-14-FR-0452-04 — mismatching existing colour
**Вопрос:** если существующий цвет формально отличается, но не соответствует теме, сохранять его?
**Ответ OWNER:** нет. Заменить на строго цвет темы. Theme01 и Theme03 приведены как уже удачные примеры.

#### QA-2026-10-14-FR-0452-05 — progress visual model
**Вопрос:** solid, gradient или сохранение локального material с заменой chroma?
**Ответ OWNER:** использовать Theme01/Theme03 как примеры цветового решения; далее базовый подход был уточнён как Theme01 PB-01 для всех тем.

#### QA-2026-10-14-FR-0452-06 — fill versus track
**Вопрос:** тематизировать только заполненную часть или также track/background?
**Ответ OWNER:** только заполненную часть progress bar.

#### QA-2026-10-14-FR-0452-07 — animation/glow
**Вопрос:** должны ли hover/animation/glow, если они существуют, тоже соответствовать активной теме?
**Ответ OWNER:** да; проверить фактическую реализацию.

#### QA-2026-10-14-FR-0452-08 — selector dots identity
**Вопрос:** под «точками выбора тем» имеются в виду круглые indicators Theme01–13 в theme selector?
**Ответ OWNER:** да.

#### QA-2026-10-14-FR-0452-09 — observed dot-row defect
**Вопрос:** в чём конкретно дефект выравнивания точек?
**Ответ OWNER:** есть пустота между 12 и 14.

#### QA-2026-10-14-FR-0452-10 — dot colours
**Вопрос:** менять ли цвета самих theme selector dots?
**Ответ OWNER:** нет, оставить как есть; исправляется геометрия/пустой разрыв.

#### QA-2026-10-14-FR-0452-11 — dot geometry
**Вопрос:** требуется ли дополнительно унифицировать размер/геометрию dots на mobile/desktop?
**Ответ OWNER:** существующая геометрия уже одинаковая; сохранить её.

#### QA-2026-10-14-FR-0452-12 — cycle identity
**Вопрос:** оставить работу продолжением Cycle0451 или оформить следующим MAIN-cycle?
**Ответ OWNER:** оформить как `FRONTEND_ADMIN_CYCLE_0452`.

#### QA-2026-10-14-FR-0452-13 — base progress geometry
**Вопрос:** что именно нормализовать по Theme01/Theme03 — высоту, ширину или весь базовый вид?
**Ответ OWNER:** сделать согласованный базовый цвет/размер/вид для каждой темы плюс сохранить индивидуальный выбор. Стартовый progress bar Theme01 должен стать базовым для всех тем, перекрашенным в цвет соответствующей темы.

#### QA-2026-10-14-FR-0452-14 — ownership split Global Theme versus local PB
**Вопрос:** может ли локальный `PB-*` сохранять собственную форму/анимацию, а Global Theme владеть стартовым fill/glow?
**Ответ OWNER:** да для стартового состояния; после глобального выбора индивидуальная настройка разрешена отдельно.

#### QA-2026-10-14-FR-0452-15 — similar theme accents
**Вопрос:** нужно ли искусственно различать progress chroma у тем с одинаковыми/близкими accent, например Theme11 и Theme12?
**Ответ OWNER:** нет. Оставлять похожие варианты; добавлять различие только там, где темы явно отличаются.

#### QA-2026-10-14-FR-0452-16 — reserved Theme14/15 in dot row
**Вопрос:** должны ли в dot-row физически занимать место только 13 существующих тем, а reserved 14–15 не создавать пустых layout-box?
**Ответ OWNER:** да.

#### QA-2026-10-15-FR-0452-17 — reset of locally selected PB on Global Theme change
**Вопрос:** должен ли ранее вручную выбранный `PB-*` сохраняться после смены Global Theme?
**Ответ OWNER:** нет. Выбор Global Theme меняет всё глобально и сбрасывает progress bar на привязанный к новой теме базовый вариант. После этого пользователь снова может индивидуально настроить элементы. Следующая смена Global Theme снова выполняет reset.

#### QA-2026-10-15-FR-0452-18 — baseline form and scale
**Вопрос:** использовать ли один Theme01-style PB-01 baseline для Theme01–13 с gradient/glow из palette темы?
**Ответ OWNER:** да. Базовый размер и вид уже определены Theme01. Для всех базовых вариантов высоту увеличить примерно на 10% относительно текущего Theme01 baseline.

#### QA-2026-10-15-FR-0452-19 — Theme09 stale teal
**Вопрос:** для Theme09 использовать ли канонический Emerald Green `#22C55E` только на Energy progress, не расширяя Cycle0452 на полную перекраску Theme09?
**Ответ OWNER:** да.

#### QA-2026-10-15-FR-0452-20 — preservation of the existing Energy PB library
**Коррекция OWNER:** существующие варианты progress bar удалять, скрывать, унифицировать или визуально стирать запрещено. Сохраняется полная существующая Energy PB library, включая физически существующие `PB-22/PB-23`; missing thematic starting variants добавляются только additive. Referrals `RP` этим расширением не затрагивается.

#### QA-2026-10-15-FR-0452-21 — full local PB visual ownership after Global Theme reset
**Коррекция OWNER:** после Global Theme reset ручной выбор Energy `PB-*` должен менять полный authored design, а не только форму. Локально выбранный PB владеет собственными fill/gradient/glow/track/geometry/animation; Global Theme не имеет права поздним CSS override перекрашивать его. Следующая смена Global Theme снова выполняет reset к starting PB новой темы.

#### QA-2026-10-15-FR-0452-22 — unique starting PB identity for all 13 current themes
**Вопрос:** должны ли Theme01–13 иметь отдельный starting PB ID даже при одинаковом accent?
**Ответ OWNER:** да. На текущем переходном Cycle0452 каждая из 13 тем получает собственный starting PB ID; совпадение цвета допустимо, но PB identity не делится между темами.

#### QA-2026-10-15-FR-0452-23 — progress fill frame boundary
**Вопрос:** что означает «выровнять заполнение» progress bar?
**Ответ OWNER:** заполнение должно всегда находиться строго внутри рамки progress track. Нельзя допускать выхода fill/glow за внешние границы; уникальная форма/дизайн старых PB при этом сохраняется.

#### QA-2026-10-15-FR-0452-24 — Theme09 color supersession
**Вопрос:** оставить Emerald Green `#22C55E` или вернуть historical teal?
**Ответ OWNER:** вернуть Theme09 в `#58C7B4` и вернуть этот цвет в официальный каталог цветов. Emerald `#22C55E` визуально отклонён как слишком ядовитый.

#### QA-2026-10-15-FR-0452-25 — Energy icon slot 7 identity
**Вопрос:** под значком progress bar имеется в виду `EI-07`?
**Ответ OWNER:** да.

#### QA-2026-10-15-FR-0452-26 — EI-07 current reset/local/reset semantics
**Вопрос:** на текущем Cycle0452 должен ли Global Theme reset выбирать `EI-07`, перекрашенный в цвет темы, после чего пользователь может вручную выбрать другой EI до следующего Global Theme reset?
**Ответ OWNER:** да.

#### QA-2026-10-15-FR-0452-27 — EI-07 theme-owned element register
**Вопрос:** добавить ли `EI-07 / Energy main icon` в официальный список элементов, цвет которых следует текущей теме?
**Ответ OWNER:** да.

### OWNER architecture direction — Color Theme × Universal Design — 2026-10-15

#### QA-2026-10-15-FR-COLOR-DESIGN-01 — independent color and form
**Вопрос:** как должна работать будущая упрощённая система после Cycle0452?
**Ответ OWNER:** смена `Color Theme` меняет исключительно цвет. Все выбранные пользователем формы/дизайны страниц и элементов сохраняются. Цвет и форма становятся независимыми измерениями.

#### QA-2026-10-15-FR-COLOR-DESIGN-02 — baseline design
**Вопрос:** какой общий initial/default design использовать для всех Color Themes?
**Ответ OWNER:** текущий формат Theme03. Это базовый design preset для initial/default состояния, но сама Theme03 implementation остаётся protected reference во время миграции.

#### QA-2026-10-15-FR-COLOR-DESIGN-03 — universal template library
**Вопрос:** что делать со всеми остальными Theme01–13 design variants?
**Ответ OWNER:** массово отвязать их от цвета и сделать универсальными шаблонами, доступными при любом Color Theme. Нельзя удалять уникальные формы/структуры только из-за dedup цвета.

#### QA-2026-10-15-FR-COLOR-DESIGN-04 — 13 colors to 10
**Вопрос:** как сократить каталог цветов?
**Ответ OWNER:** перейти с 13 coupled Global Themes на 10 уникальных Color Themes. Theme03/11/12 перестают быть тремя цветами: это один Violet Color Theme + три разных universal designs. Theme06/10 аналогично становятся одним Graphite Color Theme + два universal designs. Theme09 использует `#58C7B4`.

#### QA-2026-10-15-FR-COLOR-DESIGN-05 — future PB/EI semantics
**Вопрос:** что происходит с PB/EI после перехода на независимый Color Theme?
**Ответ OWNER architecture principle:** форма относится к universal design/local variant и должна сохраняться при смене Color Theme; Color Theme меняет chroma через semantic color roles. Текущий Cycle0452 reset-to-starting-PB/EI-07 является переходной совместимой моделью и будет superseded в отдельном migration cycle, а не внутри Cycle0452.

### Нормализованный итог этих ответов

- Theme03 `Ranks → Обновить / Найти меня` не имеет собственного material-варианта: base/hover/active/focus следуют shared action design Themes01–13; theme-specific остаётся только разрешённый общий accent/focus channel.
- Referrals social-share logos являются `brand-owned`: theme может менять форму/background/border контейнера, но не фирменный цвет логотипа, включая interactive states.
- Global Theme selection является верхнеуровневым materialization/reset: Energy PB сбрасывается на mapped starting PB ID, затем ручной PB полностью владеет своим authored visual identity до следующей смены Global Theme.
- Energy main progress: starting PB variants используют Theme01-derived геометрию, +10% высоты и neutral track; существующие PB-01..PB-23 сохраняются; additive starting library расширена до PB-35, чтобы Theme01–13 имели 13 отдельных starting PB ID; fill всех PB строго clipping внутри track frame; local PB после reset не перекрашивается Global Theme.
- Theme09 current color authority возвращён на Modular Teal `#58C7B4`; Emerald `#22C55E` superseded прямым OWNER решением.
- `EI-07` — текущий Energy theme-owned default: Global Theme reset возвращает EI-07 и theme chroma; manual EI сохраняет authored visual до следующего reset.
- Будущая архитектура после Cycle0452: `Color Theme × Universal Design`; Color Theme меняет только chroma и не сбрасывает формы. 10 unique colors, Theme03 design set = common initial baseline, все сохранённые design variants становятся universal.
- Theme selector dot-row содержит только authored Theme01–13; reserved 14–15 не занимают layout-space.


#### QA-2026-10-15-FR-COLOR-DESIGN-06 — Color Theme naming
**Решение OWNER:** названия будущих Color Themes должны описывать просто цвет, а не форму/композицию/характер старой Global Theme. Целевой каталог содержит 10 цветовых тем; legacy-названия `Violet Depth`, `Soft Pill`, `Split Focus`, `Graphite Minimal`, `Linear Ledger` и аналогичные сохраняются только как provenance design presets, а не как названия цветов.

#### QA-2026-10-15-FR-COLOR-DESIGN-07 — new color expansion law
**Решение OWNER:** любой новый цвет добавляет новый Color Theme и автоматически даёт новый комплект всех доступных комбинаций с существующей universal design library. Добавление цвета не разрешает и не требует копирования design variants. Формула целевой системы: `Color Theme × независимые design selections`.


### Cycle0454 persistent state split — OWNER start 2026-10-15

#### QA-2026-10-15-FR-COLOR-DESIGN-08 — canonical persisted state
**Решение OWNER / implementation authority:** `Color Theme` и формы сохраняются независимо. Канонический persisted state использует отдельный `color_theme_id` и единый `interface_variants` как authority формы. Legacy `global_theme_id` / `theme_overrides` допускаются только как временная runtime/rollback compatibility projection до завершения миграции.

#### QA-2026-10-15-FR-COLOR-DESIGN-09 — lossless 13→10 migration
**Решение OWNER / implementation authority:** при первом чтении старого состояния необходимо один раз воспроизвести фактически видимый legacy design (выбранная Theme01–13 + её сохранённые overrides), записать полный результат как независимые design selections и отдельно вывести `color_theme_id` по карте 13→10. Схлопывание цветов не имеет права схлопывать формы: Theme11/12 сохраняют свои design IDs под Violet, Theme10 сохраняет свои design IDs под Graphite.

#### QA-2026-10-15-FR-COLOR-DESIGN-10 — Cycle0452 reset supersession
**Решение OWNER / current architecture:** начиная с Cycle0454 смена Color Theme не сбрасывает PB, EI или design IDs страниц. Cycle0452 `Global Theme reset → starting PB/EI` остаётся историческим переходным поведением v682 и superseded для новой Color Theme state model. PB/EI сохраняют выбранную форму; их окончательное chroma-only подключение выполняется в Cycle0455.

### Cycle0455 Shared Color Contract + Referrals — OWNER decisions 2026-10-15

#### QA-2026-10-15-FR-0455-01 — TON Connect current SDK authority
**Уточнение OWNER:** проект давно полностью перешёл на `@tonconnect/sdk 5.0.0`. Любые current-тесты/guards, которые требуют `4.0.2`, трактуются как legacy artifact и должны быть currentized. Historical immutable reports/provenance не переписываются.

#### QA-2026-10-15-FR-0455-02 — one neutral shadow canon
**Вопрос:** должны ли тени различаться между Color Themes или universal designs?
**Ответ OWNER:** нет. Для всех 10 Color Themes и universal design templates используется один согласованный neutral shadow/elevation canon по текущему Theme03 reference. Color Theme не владеет обычной тенью. Glow является отдельным эффектом: наличие/форма/интенсивность относятся к DESIGN, hue — к текущему COLOR, если glow предусмотрен дизайном.

#### QA-2026-10-15-FR-0455-03 — one common initial design baseline including Energy locals
**Вопрос:** распространить ли общий стартовый Theme03-format baseline на локальные Energy controls?
**Ответ OWNER:** да. Для всех Color Themes используется один общий стартовый дизайн по согласованному Theme03 format. `EI-07` является общим initial Energy icon. PB/RP получают единый нейтральный progress-design baseline; цвет поступает отдельно от Color Theme. После пользовательского выбора design сохраняется при смене цвета.

#### QA-2026-10-15-FR-0455-04 — PB-24..PB-35 compatibility artifacts
**Вопрос:** что делать с поздними PB-24..PB-35, созданными как theme-specific color copies?
**Ответ OWNER:** выполнить anti-loss comparison. Чистые color-only duplicates не удалять безвозвратно: временно переносить/фиксировать как compatibility artifacts в отдельном контуре `Артефакты тем`; если вариант содержит уникальную geometry/effect/animation, сохранить его как universal design. На время миграции лишние theme-specific элементы разрешено складывать в `Артефакты тем` с provenance.

#### QA-2026-10-15-FR-0455-05 — one Shared Color Contract for CT-01..CT-10
**Вопрос:** сохранять ли отдельные правила CT-01..04 и CT-05..10?
**Ответ OWNER:** нет. Все `CT-01..CT-10` работают по одному Shared Color Contract. Различаются только значения color tokens. COLOR не меняет design ID, geometry, structure, radius, layout или animation. SEMANTIC и BRAND ownership остаются отдельными.

#### QA-2026-10-15-FR-0455-06 — Referrals progress independent selection
**Вопрос:** должен ли Referrals progress иметь независимый от Energy design selection?
**Ответ OWNER:** да. Referrals `RP` и Energy `PB` используют общую universal progress-design library, но сохраняются независимо: `PB state != RP state`. Color Theme задаёт chroma; выбранный design задаёт geometry/effects/animation.

#### QA-2026-10-15-FR-0455-07 — shared 35-design PB/RP library
**Вопрос:** расширить ли Referrals с 21 до полного набора 35 progress designs?
**Ответ OWNER:** да. Energy PB и Referrals RP должны использовать согласованную общую библиотеку из 35 progress designs без копирования CSS; выбор каждого контура независим.

#### QA-2026-10-15-FR-0455-08 — Referrals progress chroma optimization
**Вопрос:** убрать ли late legacy theme selectors, которые перекрашивают Referrals progress поверх выбранного design?
**Ответ OWNER:** да. Progress design universal; chroma поступает только из current `color_theme_id` через общий color contract. Старые `data-global-theme-id` chroma overrides должны быть retired/isolated как migration artifacts, а не оставаться действующим owner.

#### QA-2026-10-15-FR-0455-09 — Referrals achievement connector ownership
**Вопрос:** как разделить ownership линии и кружков уровней Referrals?
**Ответ OWNER:** connector и chroma контура уровней принадлежат COLOR; цифры/галочка остаются стандартными светлыми; геометрия/форма кружков относится к DESIGN.

#### QA-2026-10-15-FR-0455-10 — progress fill boundary for Energy and Referrals
**Вопрос:** применять ли единый frame-boundary contract ко всем 35 PB/RP designs?
**Ответ OWNER:** да. Fill всегда строго внутри track frame при 0–100%; выбранный design может менять форму/эффекты/анимацию, но не имеет права выпускать fill/glow за рамку.

### Нормализованный current authority Cycle0455
- `CT-01..CT-10` используют один Shared Color Contract; различаются только color-token values.
- Один Theme03-derived neutral shadow/elevation canon используется всеми цветами и universal designs.
- Color switch сохраняет все design selections; никаких theme-specific geometry/material reset.
- `EI-07` — общий initial Energy icon; PB/RP имеют общий neutral initial progress design.
- Energy PB и Referrals RP используют одну 35-design library, но сохраняются независимо.
- Referrals connector/level-outline chroma принадлежит COLOR; digits/check — standard light; geometry — DESIGN.
- Theme-specific color-only duplicates и obsolete selectors не уничтожаются во время migration: они изолируются в `Артефакты тем` с provenance до финального retirement.
- Current TON Connect SDK authority — exact `5.0.0`; `4.0.2` допустим только в historical provenance, не в current mutable contract.

### Cycle0455 regression recovery — OWNER finding 2026-10-15

#### QA-2026-10-15-FR-0455-11 — массовый visual regression после Shared Color Contract
**Наблюдение OWNER:** после Cycle0455 нарушены все дизайны и требуется полный regression функций/визуала.

**Root cause / current authority:** target-архитектура `COLOR ≠ DESIGN` сохраняется, но реализация `FRONTEND_v685` отвергнута. Поздний `color-theme-shared-contract.css` вышел за COLOR ownership: root `--tg-*`/surface variables и broad high-specificity `!important` selectors начали владеть background/border/shadow/material authored HS/EG/BN/page/design families. Это уничтожало визуальную независимость шаблонов. В recovery возвращается физический visual baseline `FRONTEND_v684`; безопасные изменения state split, TON Connect 5.0.0, PB/RP 35 и strict clipping сохраняются. Точный отвергнутый CSS хранится в `Артефакты тем/Cycle0455/regression-recovery/`.

**Новый обязательный guard:** будущая COLOR-миграция выполняется только узкими chroma adapters. COLOR-layer не имеет права через root/global variables или broad `!important` владеть authored material/geometry DESIGN. Перед physical release обязателен rendered parity gate по всей затронутой design library. Cycle0455 остаётся ACTIVE; Cycle0456 не запускать.
