# WebApp late referral binding — superseded design explanation

Status: PROTECTED EXPLANATORY / SUPERSEDED. This file explains why the former late-binding design is prohibited. It is not current operational authority.

## Prohibited model

The former WebApp flow that read `initDataUnsafe.start_param` and then called `POST /referrals/bind` after an authenticated user already existed is prohibited and removed. `/referrals/attach` is likewise not a public mutation path.

Reason:

- referral attribution is immutable first-creation state;
- attaching an inviter after authentication would mutate an already existing identity;
- an existing user, including a permanent `0 user`, may never acquire or change an inviter;
- late binding would weaken the atomic new-user + referral-link transaction boundary.

## What exists now instead

The frontend may preserve a normalized referral start parameter temporarily **before authentication completes** and pass it as `referral_start_param` only to the Telegram or TON authentication request. This is creation-time transport, not a referral-binding endpoint.

Current frontend transport:

```text
Telegram/Web launch start parameter
→ normalize + sessionStorage
→ scrub referral query from the visible URL
→ POST /auth/telegram/session or POST /auth/ton/proof
→ backend decides existing identity vs creation
→ clear on success or final invalid-referral error
→ retain only across transient failure within the same browser session
```

The canonical referral link remains a Telegram bot link:

```text
https://t.me/<BOT_USERNAME>?start=ref_<code>
```

The authoritative attribution law is `REFERRAL_DEEPLINK_BINDING_CANON.md`; current retry/transport behavior is described in `WEBAPP_BIND_RETRY_SEMANTICS.md`.
