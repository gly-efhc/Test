# WebApp late referral binding — superseded

Status: SUPERSEDED by the first-creation attribution canon in `v171.78`.

The former WebApp flow that read `initDataUnsafe.start_param` and called
`POST /referrals/bind` is prohibited and removed.

Reason:

- a frontend request occurs after the authenticated user is already known;
- late attachment contradicts immutable first-creation attribution;
- an existing user, including a 0 user, may never acquire or change an inviter.

The canonical referral link remains a Telegram bot link:

```text
https://t.me/<BOT_USERNAME>?start=ref_<code>
```

The bot validates the payload and creates the new user plus referral relation
atomically. WebApp frontend code has no referral-binding mutation.
