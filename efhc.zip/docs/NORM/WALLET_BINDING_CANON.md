## Цикл 1746 — TonConnect binding fail-closed

Client public key не доказывает связь с TON address сам по себе. Production wallet binding разрешён только после authoritative state-init resolution, проверки network/address/public key и Ed25519 signature. Отсутствующий/неразрешимый authoritative key не допускает binding.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Wallet binding canon

## Active mechanism

The active wallet binding mechanism in EFHC Bot is:

1. TonConnect proof.
2. Signature verification.
3. Payload/domain/expiry/user binding validation.
4. Wallet binding to `global_id`.
5. Storage in `wallet_bindings`.
6. Replay protection via `wallet_proof_token_uses`.
7. Idempotency via `wallet_connect_idempotency`.

## Single active table

`wallet_bindings` is the single active wallet binding table.

`wallet_connect_idempotency` is active only for connect idempotency.

`wallet_proof_token_uses` is active only for proof replay protection.

## Legacy mechanisms

Legacy wallet binding through memo, bind request or transaction proof is
not active runtime canon.

The former `wallet_binding_service.py` memo/bind-request service is not
part of active runtime after PACK-02. Runtime wallet routes use
`wallets_service.py` and TonConnect proof path.

Docs may mention old mechanisms only as historical/deprecated context.
They must not describe them as active canon.

## Admin legacy wallet contour closure

The separate admin wallet contour based on `efhc_core.crypto_wallets` is
not active wallet-binding canon. Cycle 1508 removes
`backend/app/services/admin/admin_wallets_service.py` from runtime.

Runtime code must not import `AdminWalletsService` or use
`crypto_wallets` for wallet ownership, conflict checks, watcher lookup
or admin wallet tools.
