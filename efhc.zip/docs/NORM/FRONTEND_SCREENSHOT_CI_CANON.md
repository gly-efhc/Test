# FRONTEND SCREENSHOT CI CANON

Статус: **CANON / ACTIVE**

- Screenshot CI проверяет утверждённый набор маршрутов и viewport-профилей.
- Generated PNG являются evidence, а не source of truth интерфейса.
- Изменение route set, viewport set или visual threshold требует явного
  изменения канона и соответствующего architecture guard.
- Старые screenshots и отчёты после закрытия цикла перемещаются в
  `docs/history/`.
- Локальный screenshot run не заменяет exact-head GitHub CI.
