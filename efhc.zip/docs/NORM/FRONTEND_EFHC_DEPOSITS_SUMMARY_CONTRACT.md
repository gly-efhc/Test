# FRONTEND EFHC DEPOSITS SUMMARY CONTRACT — CURRENT

Status: **ACTIVE / OWNER-DIRECT / FAIL-CLOSED**

## Four KPI semantics

1. `Всего операций` — count only successfully confirmed and credited incoming EFHC operations over all time.
2. `Всего EFHC` — EFHC sum over the same successfully credited incoming operations.
3. `30 дней` — EFHC sum whose trusted external operation time is within the rolling last 30×24 hours from one server-side time anchor.
4. `24 часа EFHC` — EFHC sum whose trusted external operation time is within the rolling last 24 hours from that same server-side time anchor.

Pending, failed, rejected, unmatched or otherwise unsuccessful operations do not enter these KPI.

## Data authority

- Frontend must not derive production KPI from a loaded page, cursor, row count or UI state.
- All four KPI use one server-side aggregate/time anchor.
- EFHC Jetton amount must not be inferred from native TON transport amount. EFHC amount authority comes from EFHC transport evidence/atomic amount plus token decimals and the current EFHC external business boundary.
- Rolling windows use trusted operation time, not row-render time.

## Fail-closed

No client-side first-page sum, no pending/failed rows, no substitution of native TON amount for EFHC, and no conversion of rolling windows into calendar-day/month semantics.
