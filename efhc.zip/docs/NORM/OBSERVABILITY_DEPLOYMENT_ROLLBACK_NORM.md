# Observability, deployment and rollback norm

## Status

This document is a normative release contract for the EFHC Bot runtime.
It does not claim that production deployment has already occurred.

## Observability boundary

Runtime observability may store only aggregate technical facts:

- HTTP method;
- normalized route pattern;
- response status class;
- bounded request duration;
- watcher heartbeat age;
- readiness state;
- build SHA and immutable image digest.

It must not store request bodies, query strings, Telegram InitData,
wallet proofs, signatures, seed phrases, private keys, cookies, raw
Authorization headers or unnormalized user identifiers.

Every runtime response must preserve the correlation ID. Structured
logs must redact protected fields before serialization.

## Readiness

`/api/health/readiness` is the deployment readiness contract. A ready
response requires all applicable checks to pass:

1. PostgreSQL accepts `SELECT 1`.
2. Alembic revision equals the current linear head `0002`.
3. The watcher heartbeat is fresh when the scheduler is enabled.
4. No critical in-process runtime alert is active.

A failed readiness check returns HTTP 503. Liveness remains a separate
process-health signal and must not hide dependency failures.

## Deployment

Production deployment must use immutable backend and frontend image
digests. The tag `latest` is forbidden in the production manifests.

The default rolling strategy is:

- at least two replicas;
- `maxUnavailable: 0`;
- `maxSurge: 1`;
- startup, readiness and liveness probes;
- resource requests and limits;
- non-root execution;
- dropped Linux capabilities;
- TLS ingress with forced HTTPS.

Secrets must be supplied by a secret store or a Kubernetes Secret. They
must never be embedded in manifests, images, frontend bundles or
release reports.

## Migrations

The active migration canon is the linear chain `0001 -> 0002`.
Deployment preflight must confirm that the target database and
application both expect head `0002`. Revision `0002` is a backward-
compatible nullable EXPAND and does not mutate financial data.

A rollback must not downgrade the database below a revision required by
persisted data. When schema compatibility is uncertain, the rollout is
blocked rather than repaired automatically.

## Rollback

Rollback is a controlled operator action. Before any mutation:

1. Validate the previous release archive and its SHA-256.
2. Verify the previous backend and frontend image digests.
3. Confirm the Alembic revision and backup availability.
4. Freeze new rollout activity.
5. Produce the exact `kubectl set image` commands in plan-only mode.
6. Obtain operator approval.
7. Apply the image rollback.
8. Wait for readiness and run public/Admin smoke checks.
9. Record the result and any residual risk.

The provided rollback drill tool is plan-only and never changes a
cluster by itself.

## Alert ownership

Critical alerts stop a rollout. The operator must investigate:

- high 5xx ratio;
- failed readiness;
- stale watcher heartbeat;
- migration mismatch;
- missing immutable image digest.

Warnings require review but do not independently prove a production
incident. Alert payloads must remain privacy-safe.
