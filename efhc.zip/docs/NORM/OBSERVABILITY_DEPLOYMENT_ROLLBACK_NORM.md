# Норма наблюдаемости, deployment и rollback

## Статус

Это активный нормативный контракт production runtime EFHC. Он описывает допустимое поведение release/DevOps-инструментов и не утверждает, что конкретный production VPS уже настроен или развернут.

## Наблюдаемость и приватность

Диагностика хранит только технические агрегаты: состояние сервисов, HTTP status health endpoint, bounded duration/heartbeat, состояние Docker/PostgreSQL, ресурсы VPS, release version, migration revision, backup/deployment status и системные OOM-события.

Запрещено помещать в diagnostic bundle request bodies, query strings, Telegram InitData, wallet proofs, signatures, seed phrases, private keys, cookies, `.env`, backup passphrase, API secrets, raw Authorization headers и приватные пользовательские данные.

## Production topology

Production deployment использует одну production VPS и существующий Docker Compose release contour: PostgreSQL, migrate, backend, scheduler, frontend и proxy в приватной compose-сети; наружу публикуется только proxy. Вторая production/monitoring VPS и обязательный отдельный monitoring host запрещены active contract. Kubernetes/Helm не являются active deployment contract и не должны вводиться без отдельного решения владельца.

## Readiness

`/api/health/readiness` и существующие Docker healthchecks являются deployment readiness contract. PostgreSQL, backend, scheduler, frontend и proxy должны пройти соответствующие проверки перед successful deployment.

## Миграции

Pre-release migration canon содержит один head: `0001_initial_release_schema.py`. Любое ожидание `0002+` является stale до отдельного решения владельца. Deployment обязан fail-closed остановиться при несовпадении текущей/целевой migration compatibility.

## Backup перед изменением production

Перед database-changing update существующей БД обязателен canonical recovery backup. Backup generation считается сформированным после создания/проверки PostgreSQL dump, построения recovery bundle, шифрования всего bundle и проверки canonical encrypted artifact.

Canonical encrypted artifact сохраняется локально на production VPS. VPS хранит только 10 последних backup generations. Database backup через Telegram запрещён active owner contract.

Владелец сохраняет выбранные `.enc`/`.sha256` на ПК или смартфон по защищённому SSH/SFTP каналу. Database-changing update считается разрешённым после successful создания и проверки собственного pre-update encrypted artifact; внешняя доставка backup не является prerequisite update.

## Автономное лечение

Автоматически разрешены только ограниченные и обратимые действия: повтор health-check/локального backup creation и bounded restart обычных application services (`backend`, `scheduler`, `frontend`, `proxy`) с обязательной повторной проверкой результата.

Автоматически запрещены: restore production-БД, удаление PostgreSQL/Docker volumes, опасные изменения SSH/firewall, необратимые migration actions и rollback, требующий восстановления БД. При такой ситуации система прекращает автоматические действия, сохраняет состояние, формирует privacy-safe diagnostic bundle и уведомляет владельца.

## Rollback

Rollback остаётся отдельным контролируемым release action поверх существующих `rollback*.sh`. Он не восстанавливает production-БД автоматически. Если совместимость schema не доказана, rollback блокируется.

## ONE VPS monitoring boundary

Active EFHC V1 не требует отдельный monitoring host. Внутренние status/autopilot checks работают на единственной production VPS. Полная потеря VPS относится к Disaster Recovery и не решается обязательным постоянно работающим вторым сервером.
