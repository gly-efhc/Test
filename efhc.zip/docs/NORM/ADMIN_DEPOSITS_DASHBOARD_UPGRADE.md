# ADMIN_DEPOSITS_DASHBOARD_UPGRADE

**Project:** EFHC Bot  
**Cycle:** 1485 — Admin Deposits Dashboard Upgrade  
**Archive:** v170.61  
**Status:** ACTIVE / DONE LOCALLY  
**Layer:** Admin Dashboard Layer  
**Mode:** runtime UI-only / read-only deposits dashboard

## 1. Purpose

Cycle 1485 upgrades `/admin/efhc-deposits` into a read-only
money-path dashboard for the EFHC deposit domain.

The dashboard helps the operator see runtime summary, automation health,
manual backlog, pending intents, retry/user error queues, canonical order
of actions and safety boundaries before using any exception path.

The dashboard does not replace the existing operator actions. Replay,
manual exception processing and force fulfill stay in the existing guarded
controls.

## 2. Runtime component

```text
frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/efhc-deposits.tsx
```

## 3. Data sources

The dashboard uses existing page state and the existing read-only route:

```text
GET /admin/efhc-deposits/runtime-summary
```

No new backend endpoint is added.

## 4. Truth model

```text
raw + derived snapshot
```

Allowed:

- auto credited count;
- pending manual count;
- retry error count;
- user error count;
- pending deposit intents count;
- derived automation ratio;
- derived exception backlog ratio;
- local operator input readiness indicators.

Forbidden:

- fake deposit history;
- fake time-series;
- synthetic admin analytics;
- raw payload dumps;
- debug JSON;
- secrets;
- dashboard write actions;
- dashboard idempotency key generation.

## 5. Write-flow boundary

The dashboard is read-only. It does not call `apiRequest`, `fetch`,
`POST`, `PATCH`, `PUT`, `DELETE` or `newIdempotencyKey`.

Existing guarded actions stay in the page:

- replay automated path;
- exception path processing;
- force fulfill fallback;
- confirmation modal;
- idempotency key creation in the existing action handlers.

## 6. Money-path boundary

Canonical operator order:

```text
runtime summary → replay automated path → exception path → final result
```

The dashboard makes this order visible but does not execute any step.

## 7. Grafana / Sandbox boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## 8. Acceptance

Cycle 1485 is complete when:

- `AdminDepositsDashboardRuntime` exists;
- `/admin/efhc-deposits` integrates it;
- runtime summary is shown as raw/derived snapshot;
- no fake time-series or synthetic analytics are shown;
- no raw payload/debug JSON/secrets are visible in dashboard;
- replay/exception/force fulfill remain outside dashboard;
- architecture guard protects the boundary.
