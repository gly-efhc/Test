# EFHC Operator Kernel First Standard — compatibility pointer

Status: DEPRECATED PATH / NOT AN ACTIVE RULE SOURCE.

The active consolidated rule is `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`. This `FIRST` path remains only so historical references do not break.
