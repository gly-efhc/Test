# FRONTEND OPERATOR ERROR REGISTER

Статус: **ACTIVE / OWNER-DIRECTED INCIDENT MEMORY**.

Назначение: фиксировать систематические operator-errors, чтобы они не превращались в новую архитектуру или «новый канон».

## ERR-001 — самовольная замена GetGems link

**Факт:** в v220 HUB `EFHC VIP NFT` был самовольно перенаправлен на `/efhc-vip-nft`, хотя M11-02 и HUB authority сохраняли direct `https://getgems.io/efhc-nft`.

**Причина:** команда о внешней VIP web-странице была ошибочно интерпретирована как отмена старой GetGems link.

**Запрет:** ADD не означает REPLACE. GetGems link нельзя менять без прямого OWNER `CHANGE/REMOVE`.

**Исправление:** v221 возвращает exact direct GetGems destination.

## ERR-002 — переписывание test authority под ошибочный код

**Факт:** historical assertions, защищавшие GetGems/direct старое поведение, ранее менялись под новую реализацию без доказанной OWNER отмены.

**Запрет:** если historical test мешает новому patch, сначала искать прямой OWNER authority. Если его нет — не переписывать тест и запросить решение.

## ERR-003 — путаница wallet application и TON wallet address

**Факт:** `Сменить кошелёк` ошибочно представлялся как выбор `Tonkeeper / MyTonWallet / TON Space`, то есть программ/providers вместо уже привязанных TON smart-contract addresses.

**Canonical distinction:**
- wallet = адрес/identity в сети TON;
- Tonkeeper/MyTonWallet/TON Space = приложения/transport providers;
- transport provider никогда не заменяет выбранный linked wallet address.

**Исправление:** Shop выбирает существующую linked wallet identity; provider остаётся только техническим transport и не показывается как «кошелёк».

## ERR-004 — утечка raw TON address на Shop page

**Факт:** полный TON address отображался в account strip, Profile, checkout и wallet chooser.

**OWNER:** это нарушение конфиденциальности.

**Запрет:** public Shop не рендерит полный TON address и не помещает его в user-visible DOM attributes/text. UI использует приватные обозначения `Основной кошелёк / Дополнительный кошелёк N`; raw address используется только внутренней логикой операции.

## ERR-005 — дополнительные/пустые HUB slots

**Факт:** v218+ standalone/public-related mechanics содержали `prepared`/dynamic HUB slots и `Свободный слот HUB`.

**OWNER:** разрешены ровно две ссылки; пустые и дополнительные слоты запрещены.

**Исправление:** v221 exact-two-no-empty-slots.

## ERR-006 — повторные проверки вместо результата

**Факт:** одинаковые audit/test/manifest/clean-unpack циклы многократно повторялись и задерживали физический release.

**Запрет:** short-cycle process v221: one targeted test + one release check; повтор только после реального изменения соответствующего source или нового конкретного failure.

## ERR-007 — задержка архива вопреки прямой команде

**Факт:** физический archive/HTML неоднократно откладывался ради необязательного QA/процесса.

**Запрет:** завершённая фактическая итерация всегда получает physical checkpoint в том же цикле. Необязательный QA не блокирует выдачу.


## ERR-008 — wallet scope был определён без OWNER ответа
**Факт:** сначала standalone самовольно делал выбранный адрес account-wide primary, затем v222 самовольно зафиксировал противоположную session-local семантику до ответа владельца.
**Причина:** оператор дважды выбирал одну из двух допустимых семантик вместо запроса OWNER.
**Запрет:** при неоднозначной семантике wallet/account scope не принимать архитектурное решение самостоятельно.
**OWNER RESOLUTION v223 / M11-99…100:** выбор в Shop делает кошелёк основным для всего EFHC-аккаунта и сохраняется.

## ERR-009 — nested Shop routes получали application shell
**Факт:** `_app.tsx` исключал shell только для exact `/browser-shop`, но не `/browser-shop/orders` и `/browser-shop/profile`.
**Запрет:** все canonical external Shop pages принадлежат одной separate-document boundary.
**Исправление:** v222 route-family shell guard.

## ERR-010 — standalone Shop выдавался за multi-page, оставаясь tab renderer
**Факт:** production имел `/browser-shop`, `/browser-shop/orders`, `/browser-shop/profile`, но historical standalone Shop companion оставался одной DOM-страницей с `shopPanel/ordersPanel/profilePanel` и `activeTab`; переключение зависело от повторной загрузки companion-файла.
**Последствие:** owner demo не доказывал реальную page-navigation parity; в sandbox `Мои заказы` и `Профиль` могли фактически не открываться.
**Запрет:** нельзя объявлять отдельные страницы реализованными только по наличию трёх кнопок/hidden panels. Standalone owner-review должен иметь достижимый route engine и Back/Forward parity.
**Исправление:** v223 использует frontend-style browser-history routing и отдельные route-view `shop/orders/profile`; неактивные page-view принудительно исключены из видимой композиции.

## ERR-011 — отсутствие уточняющих вопросов при неоднозначности
**Факт:** несколько Shop циклов выполнялись без вопросов, хотя смысл «отдельные страницы», scope смены кошелька и судьба `/efhc-vip-nft` имели несколько технически возможных трактовок.
**Запрет:** если OWNER формулировка допускает более одной существенно различной реализации и active CANON не выбирает одну из них, оператор обязан зарегистрировать и задать уточняющий вопрос. При этом безопасные и однозначные части текущего OWNER DELTA выполняются без задержки релиза.

## ERR-012 — Global-ID structural wrapper превращён в visual Card

**Факт:** Reports/Logs сохранял `AdminPanelChrome/source-card` и общий `data-admin-global-id-search-canon`, из-за чего structural grouping вокруг Global-ID search визуально становился дополнительным окном («матрёшкой»). Аналогичный дефект ранее пришлось исправлять на Withdrawals.

**Запрет:** после OWNER-команды flatten structural wrapper не должен получать card material через общий search canon. Видимый label `Global ID` также нельзя удалять без прямого OWNER-разрешения.

**Исправление Cycle0229:** Reports/Logs использует прозрачные route-specific wrappers; material остаётся только на input/buttons. Export geometry и filter-apply UX закрепляются route-local, без широкого repaint.
## ERR-013 — archive size pressure must not prune historical project evidence

**Факт:** в промежуточной Cycle0229 packaging-попытке ради 15 MiB лимита были удалены superseded generated EAM snapshots. До physical release они восстановлены из `FRONTEND_v439` byte-for-byte.

**Запрет:** лимит архива нельзя обеспечивать удалением исторических OWNER/EAM/report/project evidence. Использовать более плотную стандартную Deflate-упаковку либо иной OWNER-approved способ, сохраняя историю.

## ERR-014 — backend authority mistaken for missing because the operator searched for a nested ZIP

**Факт:** в начале Cycle0234 оператор повторно запросил у OWNER `EFHC_Bot_v175_34.zip`, хотя текущий physical FRONTEND HEAD уже содержит canonical backend authority в `contracts/backend_snapshot/EFHC_Bot_v175_34/`, а `SOURCE.json` фиксирует provenance исходного backend archive и его SHA-256.

**Root cause:** неверный порядок retrieval. Оператор искал буквальный вложенный `.zip` и ошибочно приравнял отсутствие nested ZIP к отсутствию backend authority. Это противоречит release-law `nested ZIP = 0`: backend authority внутри FRONTEND представлена распакованным snapshot/evidence, а не обязана лежать вторым ZIP-файлом.

**Запрет (current):** до вопроса OWNER о backend-файлах сначала проверить текущий physical HEAD: canonical `backend/`, root `api/`, `docs/backend/BACKEND_SOURCE_AUTHORITY.md` и, только для integration-задач, `contracts/integration/`. Нельзя требовать отдельный backend archive, если current full repository checkpoint уже содержит canonical backend source.

**Question law:** перед каждым MAIN-циклом сначала задать OWNER простые вопросы до примерно 99% уверенности, не повторяя уже отвеченное authority. Вопросы формулируются о понятном результате/поведении. Нельзя перекладывать на OWNER выбор query-параметров, response schema, cursor semantics или другой внутренней API-архитектуры, если смысл уже можно реализовать по SSOT/CANON/security/minimal-patch law.

**Cycle0234 correction:** backend authority считается доступной из текущего FRONTEND HEAD; технический контракт выбирает оператор по доказанному source/evidence и security law.

**Cycle0433 correction:** version-bound `contracts/backend_snapshot/EFHC_Bot_v175_34/` и exact duplicate `backend/api/` удалены после parity/provenance proof. Current backend authority теперь только `backend/` + deployment wrapper `api/`; historical snapshot references не являются current retrieval path.



## ERR-015 — owner-visible technical/process copy leaked into Admin UI

**Факт:** на Admin → Referrals в owner-visible интерфейсе повторно появилась служебная запись вида «Общего списка нет. Показываются только…». OWNER классифицировал это как систематическую проблему: внутренние ограничения реализации, процессные пояснения и технические комментарии не должны становиться пользовательским текстом интерфейса.

**Запрет:** без прямого OWNER-разрешения нельзя выводить в owner-visible Admin UI технические/процессные записи о внутреннем устройстве, отключённых контурах, server-side scope, fail-closed механике, отсутствии общего списка, архитектуре API, временных ограничениях реализации или причинах разработки. Такие сведения относятся в SSOT/CANON/report/error register, а не в интерфейс.

**Разрешено:** краткие пользовательские названия, поля, действия, бизнес-статусы и понятные ошибки, необходимые для выполнения операции. Ошибка не должна раскрывать внутреннюю архитектуру, если это не требуется OWNER.

**Cycle0236 OWNER correction:** с Admin → Referrals удалена служебная запись; пустое состояние сведено к нейтральному «Введите Global ID». Постоянный запрет добавлен в Admin visual freeze.

**Cycle0237 application:** OWNER отдельно указал ещё две owner-visible технические записи на Direct EFHC / Panels. Они удалены без замены инженерным текстом; отступ между заголовком и управляющими окнами сохранён. Это повторное применение ERR-015, а не новый тип исключения.

## ERR-016 — dense ZIP repack corrupted numbered-report filename encoding

**Факт:** physical `FRONTEND_v451.zip` содержал 36 numbered-report filenames с повреждённой кодировкой имени. Содержимое и SHA-256 файлов совпадали, но physical paths перестали совпадать с canonical UTF-8 paths в `FRONTEND_REPORT_MANIFEST.json`, поэтому следующий Operator Kernel корректно завершился fail-closed до маршрутизации.

**Причина:** release repack сохранил method-8 payload, но неверно перенёс filename encoding/UTF-8 flag для части исторических имён. Предыдущая поверхностная CRC/entry проверка не доказала path identity.

**Запрет:** при плотной/кастомной repack-упаковке недостаточно проверить CRC, duplicates и compression method. Финальная clean-unpack проверка обязана запускать `ops/reports/check_numbered_reports.py` на распакованном дереве и тем самым доказать canonical filename/path identity.

**Исправление v452:** 36 физических имён восстановлены строго по уже существующему report manifest; содержимое numbered reports не менялось. Kernel в той же сессии повторно не запускался.


## ERR-017 — stale Shop companion identity blocked Operator Kernel

**Факт:** startup Operator Kernel на physical `FRONTEND_v454` завершился `FAIL-CLOSED`, потому что root Shop companion существовал, но его верхняя release identity оставалась предыдущей; startup identity guard корректно остановил operation.

**Причина:** corrective packaging v454 обновил имя physical Shop companion, но не синхронизировал его внутреннюю release-identity декларацию.

**Запрет:** каждый новый physical HEAD обязан обновлять не только root filename, но и current release token внутри `FRONTEND_vNNN.html` и `SHOP_vNNN.html`. Перед упаковкой проверять оба current tokens в первых 8000 байтах, как это делает Operator Kernel.

**Cycle0238 correction:** следующий исправленный Shop companion получает matching release identity; customer Shop runtime/theme не меняется. Единственный Kernel запуск в сессии не повторяется и остаётся честно зафиксирован как FAIL на parent v454.

## ERR-018 — planned resolution cycle was hidden behind indefinite blocker wording

**Факт:** после Cycle0238 оператор сообщил, что Users→Balance/History export «остаётся заблокированным до появления доказанного server-side owner contract», хотя active roadmap уже прямо назначал следующий Cycle0239 на cumulative backend handoff/evidence refresh. OWNER пришлось отдельно спрашивать, кто должен доказать scope и как долго проблема будет висеть.

**Причина:** инженерный статус был сообщён без обязательного временного/планового контекста. Формально fail-closed формулировка была безопасной, но она скрыла уже известный путь и конкретный цикл закрытия, создавая ложное впечатление неопределённого ожидания.

**Запрет:** если обнаруженная проблема не закрывается в текущем цикле, но active roadmap уже назначает конкретный будущий MAIN-cycle для её доказательства/ремедиации, оператор обязан в том же сообщении:

1. назвать точный номер этого цикла;
2. кратко объяснить, почему закрытие относится именно туда;
3. назвать обязательный результат этого цикла (`prove existing scope` либо `produce exact remediation`, без неопределённого переноса);
4. не использовать самостоятельные формулировки вида «остаётся заблокированным до появления…» без указанного scheduled closure.

Если конкретного цикла в плане нет, оператор обязан прямо сказать, что задача **не запланирована**, вместо создания впечатления, что она автоматически решится позже.

**Cycle0239 correction:** exact `EFHC_Bot_v175_34.zip` найден в доступной Project Library и физически проверен. `/admin/users/{global_id}/history` доказан как exact-owner server source до cursor/limit; Cycle0238 per-row-only blocker снят. В дальнейшем scheduled resolution cycle должен называться сразу.

## ERR-019 — current OWNER_DECISION omitted explicit Physical HEAD anchor

**Факт:** startup Operator Kernel на physical `FRONTEND_v481` завершился `FAIL-CLOSED`: `OWNER_DECISION_v481.md` содержал строку `HEAD FRONTEND_v481`, но не обязательную явную форму `Physical HEAD: FRONTEND_v481`, которую проверяет Kernel.

**Причина:** release-state update Cycle0263 сократил current OWNER decision и потерял обязательный machine-verifiable physical anchor. Содержательный NEXT/scope при этом совпадал с `START_HERE.md`, `KERNEL.md` и active roadmap.

**Current correction:** per-release `OWNER_DECISION_vNNN.md` больше не является startup authority и не создаётся/не требуется Kernel. Прямое текущее сообщение OWNER является runtime authority; physical HEAD фиксируется `START_HERE.md`/`VERSION`, а current CANON/SSOT/NORM выбираются через `ACTIVE_DOCUMENTATION_INDEX.md`.

**Historical note:** старое восстановление через versioned OWNER file относится только к истории инцидента. Current Kernel не использует этот механизм.

