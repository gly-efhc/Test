# Toast and Empty State Canon

Toast is for short success/info confirmation and limited blocking alerts.
It is not the default channel for recoverable errors already shown inline or
as page state.

Rules:
- success/info after an action may use toast;
- operation failure uses one channel: inline or page state;
- load failure uses quiet state with retry;
- background failure is silent/stale;
- toast must dedupe repeated messages and expose accessible roles;
- identical error must not be shown simultaneously in toast and card/inline.

## Distinct list-state semantics

For filterable history/analytics lists, the following states are distinct and must not collapse into one another:

- loading;
- true-empty (the underlying dataset has no rows);
- filter-empty (the active filter/query has no matching rows);
- read/load error.

A recoverable read error uses a local retry/refresh path, preserves the active filter/query/scope, and never renders raw technical payload. If usable rows are already present, a background/partial refresh failure must not replace those rows with an empty state. Standalone mirrors only states it can actually source; it must not invent a synthetic network-error path.
