# Toast and Empty State Canon

Toast is for short success/info confirmation and limited blocking alerts.
It is not the default channel for recoverable errors already shown inline or
as page state.

Rules:
- success/info after an action may use toast;
- operation failure uses one channel: inline or page state;
- load failure uses quiet state with retry;
- background failure is silent/stale;
- toast must dedupe repeated messages and expose accessible roles;
- identical error must not be shown simultaneously in toast and card/inline.
