# EFHC — канон ручной защитной деактивации и повторной активации Панелей

**Статус:** OWNER DECISION / IMPLEMENTATION CONTRACT  
**Дата:** 2026-08-20  
**Frontend authority:** `FRONTEND_v182`  
**Backend integration basis:** `EFHC_Bot_v174.60`  
**Приоритет:** более позднее прямое решение владельца имеет приоритет над более ранними формулировками при пересечении смысла.

## 1. Назначение документа

Документ фиксирует согласованный простой алгоритм редкой ручной защитной деактивации Панели администратором, её состояния «мёртвая», возврата EFHC, аннулирования генерации и последующей повторной активации. Цель — не строить отдельную бухгалтерию по каждой Панели и не связывать каждый исторический обмен `kWh → EFHCm` с конкретным `Panel ID`.

Также фиксируются связанные решения по `bank_metrics_snapshot`, Admin exports и frontend/backend reconciliation, которые были согласованы в той же серии owner decisions.

## 2. Базовые неизменяемые правила Панелей

1. Обычная активация Панели всегда стоит ровно `100.00000000 EFHC`.
2. Обычная оплата выполняется действующим каноном: сначала `EFHCb`, затем `EFHCm`.
3. Если совокупных доступных `EFHCb + EFHCm < 100.00000000`, активация запрещается целиком. Частичной активации, кредита и отрицательного баланса нет.
4. Обычные Панели после естественного завершения срока остаются архивными и продолжают существовать в списках. Они не становятся «мёртвыми».
5. «Мёртвой» может стать только Панель, которую администратор вручную защитно деактивировал.

## 3. Термины и обозначения

- `G` — фактическая накопленная генерация деактивируемой Панели на момент операции, D8 kWh.
- `A` — текущий общий `available_kwh` аккаунта пользователя перед защитной операцией.
- `U = min(G, A)` — часть генерации, которая ещё существует в доступных необменённых kWh и может быть просто аннулирована.
- `R = G - U` — уже реализованная часть генерации: она больше не находится в `available_kwh`, потому что была ранее обменена `kWh → EFHCm`.
- `B` — историческая часть цены Панели, оплаченная из `EFHCb`.
- `M` — историческая часть цены Панели, оплаченная из `EFHCm`.
- Для одной Панели всегда `B + M = 100.00000000`.
- `NET = 100.00000000 - R` — чистый возврат пользователю при защитной деактивации.

Owner decision: случай `R > 100.00000000` считается невозможным для корректной Панели. Если такой факт когда-либо обнаружен, это data anomaly: операция должна fail closed, а не создавать debt, отрицательный баланс или новый кредитный контур.

## 4. Почему не нужна привязка обмена к конкретной Панели

`kWh` внутри аккаунта являются агрегированным ресурсом. Для защитной деактивации не требуется знать, из какой именно Панели происходил каждый исторический обмен.

Достаточно знать:

- сколько всего сгенерировала удаляемая Панель (`G`);
- сколько kWh сейчас остаётся доступно в аккаунте (`A`).

Из общего `available_kwh` аннулируется `U = min(G, A)`. Остаток `R = G - U` считается уже реализованным экономическим результатом этой Панели и уменьшает возврат стоимости Панели.

Это специально устраняет необходимость в:

- per-panel exchange ledger;
- FIFO/LIFO распределении обменов между Панелями;
- отдельной debt table;
- отрицательных пользовательских балансах;
- попытках возвращать уже выполненный внешний Withdraw.

## 5. Атомарный алгоритм ручной защитной деактивации

Операция разрешена только администратору и выполняется одной root transaction: либо применяются все изменения, либо ни одно.

### 5.1. Подготовка

1. Авторизовать администратора и зафиксировать actor/reason/idempotency context.
2. В корневой транзакции сначала заблокировать финансового владельца, затем догнать все его живые Панели до единой временной границы и заблокировать целевую Panel row.
3. Зафиксировать `Panel ID`, `global_id`, исторический payment split `B/M`, текущие `G`, актуальный общий `A`, `total_generated_kwh`, `exchanged_kwh_total`.
4. Исторический payment split брать из canonical activation evidence (`spent_bonus` / `spent_main`), а не угадывать из текущих пользовательских балансов. Для новых активаций split сохраняется прямо в `panels.meta.activation_payment_split`. Legacy batch со смешанным общим `spent_bonus/spent_main`, который не доказывает split конкретной Панели, должен fail closed; автоматическая ретроспективная догадка запрещена.

### 5.2. Расчёт аннулирования

```text
U = min(G, A)
R = G - U
NET = 100.00000000 - R
```

Поскольку owner canon считает `R > 100` невозможным, `NET` должен находиться в диапазоне `0..100`. Если это не так — fail closed + audit/anomaly.

### 5.3. Энергетическое состояние пользователя

Текущий backend хранит зеркальный invariant:

```text
available_kwh = total_generated_kwh - exchanged_kwh_total
```

Чтобы после void этот invariant сохранился без per-panel accounting:

```text
total_generated_kwh' = total_generated_kwh - G
exchanged_kwh_total' = exchanged_kwh_total - R
available_kwh' = available_kwh - U
```

`available_kwh` является вычисляемым зеркальным значением; после изменения двух authority-полей он должен автоматически стать `A - U`.

Смысл:

- необменённая часть `U` исчезает из доступной энергии;
- уже обменённая часть `R` удаляется из агрегированного exchanged total как аннулированный результат мёртвой Панели;
- никакой исторический exchange log не удаляется: факт исходной операции остаётся в audit/history, а protective void фиксирует её экономическую компенсацию.

### 5.4. Финансовый возврат

Gross refund Панели остаётся `100.00000000 EFHC` и базируется на историческом split `B/M`.

Но уже реализованная генерация `R` компенсируется **взаимозачётом внутри этого возврата**, а не отдельным списанием текущих средств пользователя:

```text
realized_offset = R
gross_refund = 100.00000000
net_refund = gross_refund - realized_offset
```

Порядок уменьшения refund, согласованный в пользу пользователя:

1. сначала уменьшается возвращаемая часть `EFHCb`;
2. затем, если `R` больше `B`, уменьшается возвращаемая часть `EFHCm`.

Формально:

```text
offset_b = min(B, R)
offset_m = R - offset_b
refund_b = B - offset_b
refund_m = M - offset_m
refund_b + refund_m = NET
```

Важно: `R` не списывается повторно с текущих `main_balance`/`bonus_balance`. Если пользователь уже вывел ранее полученные EFHCm, система не пытается отменить Withdraw. Реализованная часть просто уменьшает сумму refund, которую система должна выдать сейчас.

### 5.5. Состояние Панели после операции

После успешной защитной деактивации:

- `panel.generated_kwh = 0.00000000`;
- Панель получает canonical machine marker `meta.protectively_voided = true`;
- human/operator semantics: **«Мёртвая»**;
- Панель физически не удаляется;
- `Panel ID` и вся история сохраняются;
- она не читается обычными Active/Archive/user списками;
- она не участвует в Panel/Bank aggregates и расчётах;
- Admin authority продолжает видеть мёртвые Панели и может их восстановить.

Canonical правило выборок: operational Panel queries обязаны исключать `protectively_voided=true`. Admin dead/audit contour является исключением и может читать такие строки.

## 6. Повторная активация мёртвой Панели

Повторно активировать можно только Панель с `protectively_voided=true`, и только администратором.

Алгоритм:

1. Найти ту же физическую Panel row.
2. Сохранить тот же `Panel ID` и историческую audit/history цепочку.
3. Проверить доступные текущие `EFHCb + EFHCm` пользователя.
4. Выполнить обычную активационную оплату `100.00000000 EFHC`: сначала `EFHCb`, затем `EFHCm`.
5. Если средств меньше 100 EFHC — отказать целиком; dead marker и Panel state не менять.
6. При успехе снять `meta.protectively_voided` и вернуть Панель в active contour.
7. Аннулированная старая генерация не возвращается; текущая `generated_kwh` после protective void равна нулю, а новый рабочий период генерирует новую энергию по обычному runtime contract.
8. Новый payment split этой повторной активации становится актуальным split для возможной будущей ручной защитной деактивации этой же Панели.

Точные lifecycle timestamps (`activated_at`, `expires_at`, `last_generated_at`) должны применяться по обычному действующему алгоритму активации; этот документ не вводит отдельную формулу срока жизни.

## 7. Примеры

### Пример A — генерация ещё не обменивалась

Панель куплена: `70 EFHCb + 30 EFHCm`.  
`G = 15`, общий `A = 40`.

```text
U = min(15, 40) = 15
R = 15 - 15 = 0
NET = 100 - 0 = 100
```

Результат:

- доступные kWh уменьшаются на 15;
- `total_generated_kwh` уменьшается на 15;
- `exchanged_kwh_total` не меняется;
- пользователю возвращается `70 EFHCb + 30 EFHCm`;
- Панель становится мёртвой, `generated_kwh=0`.

### Пример B — вся генерация уже обменена и EFHCm выведены

Панель куплена: `70 EFHCb + 30 EFHCm`.  
Панель сгенерировала `15 kWh`, пользователь обменял их на `15 EFHCm` и уже вывел эти EFHCm.  
На момент protective deactivation `G = 15`, `A = 0`.

```text
U = 0
R = 15
NET = 100 - 15 = 85
```

Уменьшаем refund сначала по EFHCb:

```text
offset_b = 15
offset_m = 0
refund_b = 55
refund_m = 30
```

Итог: пользователь получает `85 EFHC = 55 EFHCb + 30 EFHCm`.

Никаких попыток вернуть старый Withdraw нет. Никакого долга нет.

### Пример C — часть генерации обменена

Панель куплена: `40 EFHCb + 60 EFHCm`.  
`G = 15`, общий доступный остаток `A = 6`.

```text
U = 6
R = 9
NET = 91
```

Refund:

```text
offset_b = 9
refund_b = 31
refund_m = 60
```

Итог: `91 EFHC`.

### Пример D — realized offset больше исторической EFHCb части

Панель куплена: `20 EFHCb + 80 EFHCm`.  
`G = 75`, `A = 5`.

```text
U = 5
R = 70
NET = 30
```

Refund:

```text
offset_b = 20
offset_m = 50
refund_b = 0
refund_m = 30
```

Итог: `30 EFHCm`.

### Пример E — вся стоимость экономически реализована

`G = 100`, `A = 0`.

```text
R = 100
NET = 0
```

Панель становится мёртвой, её генерация аннулируется, но дополнительного EFHC refund пользователю нет. Долг не создаётся.

### Пример F — повторная активация

Мёртвая Панель `ID00001234` сохранена в БД и истории. У пользователя:

```text
EFHCb = 70
EFHCm = 40
```

Для повторной активации нужно 100:

```text
списать EFHCb = 70
списать EFHCm = 30
остаток EFHCm = 10
```

Та же `ID00001234` становится активной. Если было бы `40 EFHCb + 50 EFHCm = 90`, активация была бы полностью отклонена.

## 8. Что принципиально НЕ делаем

- не создаём per-panel exchange ledger;
- не распределяем исторические обмены между Панелями по FIFO/LIFO;
- не создаём пользовательский debt для этой операции;
- не разрешаем отрицательные `EFHCm`, `EFHCb` или `available_kwh`;
- не пытаемся отменять уже выполненные Withdraw;
- не удаляем Panel row и не переиспользуем `Panel ID`;
- не смешиваем мёртвые Панели с обычным Archive;
- не возвращаем мёртвую Панель в operational calculations до её успешной повторной активации.

## 9. Bank snapshot — связанный канон

`efhc_core.bank_metrics_snapshot` — обязательная singleton D8-таблица удобного server-side сбора итоговых Bank metrics. Она не заменяет первичные ledgers/Users/Panels как источники фактов, но является единственной read authority для формул Admin Bank: browser не пересчитывает финансовые формулы самостоятельно.

Согласованный режим:

1. Таблица должна существовать во всех production/greenfield установках и обновлениях схемы.
2. При открытии Admin раздела и каждого соответствующего Admin-модуля backend оперативно refresh-ит snapshot из текущих canonical данных.
3. Admin Bank читает готовые значения только из snapshot.
4. Если snapshot отсутствует или не может быть корректно обновлён — fail closed; browser не строит fallback-математику.
5. Мёртвые Панели (`protectively_voided=true`) не входят в Panel-derived snapshot aggregates.
6. Для `panel_spent` каждый `protective_deactivate` полностью сторнирует исходный payment split `B+M=100` этого lifecycle. Фактический NET refund `100-R` остаётся реальной BANK-проводкой, но `R` является компенсацией уже реализованной генерации и не должен сохраняться как Panel spend.

## 10. Admin exports

Для CSV/XLSX экспорта согласован выбор объёма:

- `100`;
- `1 000`;
- `100 000`;
- `1 000 000`;
- `Все`.

Большие выборки должны формироваться server-side с pagination/keyset/streaming-подходом; frontend не должен загружать весь dataset для последующей реконструкции экспорта в браузере.

## 11. FRONTEND_v182 и устранение разногласий

`FRONTEND_v182` — текущая frontend authority. Одновременно более поздние прямые owner decisions имеют приоритет при конфликте.

Правило интеграции:

1. Подтверждённые frontend bugs исправляются непосредственно.
2. Owner-approved visual/functional contract FRONTEND_v182 не откатывается из-за stale implementation tests.
3. Tests/guards, противоречащие принятому frontend patch только по старой implementation shape, синхронизируются в той же итерации.
4. Backend и frontend не должны иметь параллельные разные финансовые формулы.
5. Все обнаруженные расхождения между FRONTEND_v182 owner Q&A и production backend должны быть перечислены в отдельном handoff-документе frontend-команде и устранены согласованно, а не скрыты локальным override.

## 12. Атомарность и audit

Protective deactivation и dead-panel reactivation являются финансовыми административными операциями. Для каждой операции требуется:

- один root transaction boundary;
- idempotency/replay protection по действующему финансовому канону;
- блокировка затрагиваемых финансовых/Panel rows до mutation;
- no partial success;
- полный Admin audit с `Panel ID`, `global_id`, actor, reason, pre/post state и финансовыми компонентами;
- исторические logs не удаляются даже после повторной активации.

Минимально audit protective deactivation должен позволять восстановить:

- исходный payment split `B/M`;
- `G`, `A`, `U`, `R`;
- gross refund `100`;
- realized offset `R`;
- фактические `refund_b/refund_m`;
- факт установки/снятия `protectively_voided`;
- admin actor/reason/timestamps.

## 13. Короткий reference algorithm

```text
MANUAL ADMIN PROTECTIVE DEACTIVATE

G = panel.generated_kwh
A = user.available_kwh
B = original panel spent_bonus
M = original panel spent_main
assert B + M == 100.00000000

U = min(G, A)
R = G - U
assert 0 <= R <= 100.00000000

user.total_generated_kwh -= G
user.exchanged_kwh_total -= R
# available_kwh becomes A - U through canonical mirror

panel.generated_kwh = 0.00000000
panel.meta.protectively_voided = true

offset_b = min(B, R)
offset_m = R - offset_b
refund_b = B - offset_b
refund_m = M - offset_m
NET = refund_b + refund_m = 100.00000000 - R

credit only NET to user as protective refund settlement
exclude dead panel from ordinary lists and aggregates
preserve Panel ID + audit/history
COMMIT ONCE
```

```text
ADMIN REACTIVATE DEAD PANEL

require panel.meta.protectively_voided == true
require user.EFHCb + user.EFHCm >= 100.00000000
spend 100 by ordinary rule: EFHCb first, then EFHCm
keep same Panel ID/history
remove protectively_voided marker
return panel to normal active lifecycle
generated_kwh remains 0 and new generation starts normally
store new activation payment split
COMMIT ONCE
```

## 14. Authority references

- `EFHC_FRONTEND_OWNER_QA_v182.md`: FRONTEND_v182 authority, Panel price, protective deactivation semantics, Bank snapshot, exact D8/math rules.
- `EFHC_Bot_v174.60`: current runtime mirror `available_kwh = total_generated_kwh - exchanged_kwh_total`, Panel activation price 100 EFHC, spend order EFHCb → EFHCm, no-negative-balance invariants.
- Latest direct OWNER DECISION in chat dated 2026-08-20: simplified aggregate-kWh void algorithm, `100 − realized` net refund, no debt, dead marker semantics, Admin visibility/reactivation, same Panel ID/history, reactivation requires real 100 EFHC and fails on insufficient funds.
