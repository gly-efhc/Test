# Payment Intent Flow Norm

## Direct EFHC flow

A direct EFHC payment intent uses this accounting rule:

```text
same tx_hash = idempotent replay
different tx_hash = separate incoming deposit
```

`expires_at` is not price protection for `deposit_efhc`.

A direct EFHC intent may end by execution, cancellation, manual close,
or technical/abuse block.

## Confirmation behavior

For `deposit_efhc`, a confirmed intent does not silence later real
incoming transactions. If the later transaction has a different
`tx_hash`, it must become a visible accounting event and may be credited
under its own transaction-scoped idempotency key.

For `shop_external`, the order flow remains one order payment flow and
is not converted into repeated package delivery by this norm.
