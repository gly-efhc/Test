# Payment Intent Flow Norm

Статус: ACTIVE после финансового Audit 3/10, цикл 1744.

## Confirmation behavior

Canonical reconciliation работает fail-closed:

```text
FOR UPDATE intent
→ status must be PENDING
→ expires_at must exist and be in the future
→ exact asset
→ exact destination
→ exact amount
→ global tx_hash settlement claim
→ financial operation
```

`CONFIRMED + same tx_hash` — только идемпотентный read-through уже выполненной
операции.

`CONFIRMED + different tx_hash` — не новый депозит через старый intent.
Требуется новый `PENDING` intent.

`EXPIRED`, `CANCELED`, отсутствующий TTL и любой иной non-PENDING status —
автоматическое подтверждение запрещено. Полученная on-chain операция может
быть только видимой для ручной reconciliation, но не должна начислять EFHC
через просроченный/закрытый intent.

## Direct EFHC

Direct EFHC Payment Intent больше не является бессрочным reusable payload.
Его `expires_at` — реальная server-side граница автоматического settlement.
Это не меняет отдельный канонический direct EFHC jetton flow, если он не
использует Payment Intent payload.

## Global tx_hash rule

Разные business idempotency keys разрешены для разных доменов, но они не
могут обойти один общий settlement claim по blockchain `tx_hash`.
См. `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`.


## Creation/replay NORM — cycle 1744

```text
lookup (global_id, purpose, idempotency_key)
→ no row: create from server-owned canonical inputs
→ row exists: compare package_id + asset + amount_asset_d8
              + efhc_amount_d8 + to_address
→ mismatch: 409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD
→ exact match: response only from saved DB row
```

Нельзя строить гибридный response, где `payload`/`intent_id` взяты из старой
DB-row, а amount/asset/destination — из нового request. Exact replay также не
может выдавать TonConnect `validUntil` позднее сохранённого `expires_at`.
