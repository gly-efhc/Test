# ADMIN_OVERVIEW_DASHBOARD_UPGRADE

**Project:** EFHC Bot  
**Cycle:** 1481 — Admin Overview Dashboard Upgrade  
**Archive:** v170.57  
**Status:** ACTIVE / DONE LOCALLY  
**Layer:** Admin Dashboard Layer  
**Mode:** runtime UI-only / read-only overview / operator navigation

## 1. Purpose

Cycle 1481 turns `/admin` into the main operator overview dashboard.
The page must give the operator a system picture in about ten seconds:
status, counters, domain links, service boundaries and safe drill-downs.

The dashboard does not replace backend truth. It visualizes existing
admin overview data and existing admin routes.

## 2. Runtime component

```text
frontend/src/components/admin/AdminOverviewDashboardRuntime.tsx
```

The component is integrated into:

```text
frontend/src/pages/admin/index.tsx
```

## 3. Data model

Truth model:

```text
raw + derived snapshot
```

Sources:

```text
/admin/reports/overview
admin module map from existing /admin page
routes.yaml / map_element navigation discipline
```

No synthetic analytics are introduced in runtime.

## 4. What the dashboard shows

The overview dashboard shows:

- backend overview state;
- Telegram admin session state;
- live/helper/deferred admin module coverage;
- backend counter count;
- key facts from the overview payload;
- derived chart display for existing facts;
- quick links into core, operation and service admin areas;
- truth/safety boundary.

## 5. Safety boundaries

The dashboard is read-only. It must not:

- call write APIs;
- create idempotency keys;
- mutate money state;
- change backend routes;
- change OpenAPI;
- show secrets;
- show raw payload dumps;
- show debug JSON;
- hide backend defects behind frontend polish.

Existing write-capable admin actions remain in their previous controlled
locations and are not duplicated inside the dashboard component.

## 6. Grafana / Песочница boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## 7. Acceptance result

- `/admin` has a real operator overview dashboard layer.
- Existing admin sections remain reachable.
- Read-only overview data is visualized without changing business logic.
- Money/write flows, dependencies, lock files, CI and backend are not
  changed.
