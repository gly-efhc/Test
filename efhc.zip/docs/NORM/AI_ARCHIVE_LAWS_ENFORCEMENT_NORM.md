# ТЕКУЩИЙ OWNER RULE — cycle 1813 / document language boundary

Маркер: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`.

Human-readable `documents/reports/cycles/chat` используют Russian descriptive
prose и English technical terms/concepts. `Source code` исключён из этой
policy. Нельзя исправлять code ради document language; при таком finding
исправляется только `guard scope`.

# AI_ARCHIVE_LAWS_ENFORCEMENT_NORM

Status: ACTIVE NORM.
Cycle: 1573.
Archive: `v171.62`.

## Startup enforcement

1. Start from the latest canonical archive, not a previous sandbox.
2. Verify and unpack once per session.
3. Read `START_HERE.md` and the active detailed `KERNEL.md` fully.
4. Read the law lock/canon/NORM chain and Kernel startup core.
5. Resolve the exact task through EFHC keywords and `routes.yaml`.
6. Read `file_map.summary.json`, not the full machine map.
7. Read exact route/source/test files before editing.
8. Record a startup receipt for required files.

Alternative startup orders, repeated active Current HEAD blocks and Kernel demotion are forbidden.

## Kernel enforcement

- Kernel contains operational keywords, task types, anchors, route summaries, patch/permission/proof/validation gates.
- Full CANON/SSOT/NORM remain in their source documents; Kernel maps to them explicitly.
- `routes.yaml` is primary runtime route truth.
- Full `file_map.json` and full Healer/history are route-only, not universal preload.
- Precise route reading replaces broad archive reading.

## Logs, CI and tests

Read the exact error, identify root cause, run targeted verification first and use bounded broader checks only when relevant. Do not weaken protections. Local checks are not GitHub CI.

## Screenshots

Application proof requires a real running app and `page.goto()` with route/app-root/error/overflow evidence. Manual HTML, `page.set_content`, synthetic/mock and inherited PNG cannot prove new application UI.

## Delivery

After changed files and relevant guards, refresh both file maps, create and deliver the next sequential development archive. Missing live proof blocks release claims, not the development snapshot.
## Owner-facing answer and artifact verification

Before every owner-facing answer, re-read the exact final sources supporting all
material claims. After the last write to any artifact, reopen the exact final
handoff path, validate required markers/structure, then recompute SHA-256 and
size. CI claims require the exact run/log + Gate Summary; ZIP claims require
final integrity/content/mode qualification. Memory, intent and intermediate
state are not evidence. Unrevalidated facts must be marked unverified.

The 2026-08-16 incident where an older `ci_github.yml` was twice handed off as
if the SHA-256 block had been verified is recorded as a verification-integrity
incident. Active owner rule: `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md`.



## Q/A recovery enforcement

При owner order на восстановление Q/A обязателен full numbered-chat scan и exact evidence inventory. `QUESTIONS_AND_ANSWERS_REGISTER.md` — append-only authority; unanswered/context-incomplete historical markers не повышаются до owner CANON.
