<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EVENT CONTRACTS NORM

Статус: **NORM / ACTIVE**

Каждое событие содержит `event_name` и структурированный `details`.

## Common details

- `at`: ISO-8601 UTC datetime;
- `source`: `api | scheduler | admin | worker`;
- `request_id`: string или null;
- `correlation_id`: string или null;
- `global_id`: string pattern `^[0-9]{10}$` или null;
- `actor_global_id`: string pattern `^[0-9]{10}$` или null;
- `idempotency_key`: string или null.

`tg_id` допускается только как Telegram provider/delivery metadata и не
заменяет owner `global_id`.

Для balance/status mutations обязателен canonical idempotency key.
Ошибки не могут завершаться silent-pass и обязаны формировать error event.
