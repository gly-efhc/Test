# SKILL ARCHITECTURE CANON

Status: **ACTIVE STABLE ARCHITECTURAL NORM**.

1. `START_HERE` remains the project entry point.
2. Kernel owns state, authority, scope and Skill-route resolution.
3. CANON / SSOT / NORM own facts and normative behavior.
4. Skills own repeatable execution procedures and must not duplicate domain authority.
5. Tools/ops own execution primitives.
6. Guards/tests own proof of correctness.
7. Reports record results but do not become domain authority.
8. Skill IDs are stable and independent of physical release numbers.
9. Only `ACTIVE` Skills are automatically selectable.
10. Invalid registry/manifest, missing dependency, dependency cycle, required-input failure, permission violation and release-integrity failure are fail-closed.
11. Phase 1 remains self-contained inside the physical archive and preserves backward-compatible non-Skill routing.
12. Skill routing must minimize context and must not require loading project history unless declared or required by a real authority conflict.
13. Kernel/Skill startup must be clean-tree read-only: importing or resolving Skills must not create bytecode/cache files inside the Physical HEAD.
14. Planning must expose the selected Skill graph's declared required inputs; execution with an explicit input set fails closed when any required input is absent.
15. Unknown symbolic Skill context references and unresolved required context are fail-closed architecture errors.
16. Every current procedural inventory entry must classify the source responsibility and map only repeatable capabilities to Skills; tools/guards/authority/history are not automatically Skills.
17. Composite Skills must compose child Skill IDs instead of reproducing child workflows.
18. Kernel must expose per-node minimal context planning; graph-wide context union is diagnostic and must not force every Skill to load unrelated context.
