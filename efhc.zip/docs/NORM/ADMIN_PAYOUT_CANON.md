# Admin payout canon

Withdraw payout in EFHC Bot is performed through TonConnect payment from
an approved operator wallet.

Admin does not receive technical access to project treasury/private
funds.

Admin withdraw action is an operator payout action, not direct access to
project funds.

Incoming transactions are processed automatically through watcher and
payment processing.

Outgoing withdraw payout is performed by the operator through wallet
flow.

Therefore the existence of admin payout action must not be treated as
technical treasury/private funds access.

This document does not change PACK-01 withdraw canon. An approved
admin/operator payout action may still finalize a withdraw request as
`PAID` in EFHC Bot V1.

## Relation to wallet cleanup

Admin payout canon is unchanged by cycle 1508. Removing the legacy
`crypto_wallets` admin wallet contour does not convert admin payout into
treasury custody. Withdraw payout remains an operator wallet-flow.
