<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ТЗ — Account Registration Service

Статус: **ACTIVE / GLOBAL_ID CANON**.

## Цель

Создание и разрешение единого аккаунта EFHC независимо от провайдера входа.

## Канон

1. Внутренний account owner — только `global_id`.
2. Внешний `global_id` — строка ровно из 10 ASCII-цифр; `0000000000`
   запрещён.
3. Provider identity хранится как `provider + subject -> global_id`.
4. Telegram subject имеет каноническое имя `tg_id` и используется только в
   Telegram ingress/delivery/provider mapping.
5. TON subject — `ton_wallet_id`; Google — `google_id`; Apple — `apple_id`;
   Facebook — `fb_id`; Discord — `discord_id`; GitHub — `github_id`.
6. Создание account сначала создаёт/получает canonical `global_id`, после чего
   привязывает подтверждённую provider identity к этому account.
7. Business rows, financial keys, cache keys и internal API никогда не
   используют provider subject как owner.
8. Повторная регистрация той же пары `provider + subject` возвращает ровно тот
   же `global_id`.
9. Конфликт identity завершается fail closed; автоматическое слияние аккаунтов
   запрещено без отдельного подтверждённого процесса.
10. Все физические pre-release schema rules находятся только в
    `backend/migrations/versions/0001_initial_release_schema.py`.

## Telegram flow

`tg_id -> identity resolution -> global_id -> business runtime`.

`tg_id` может оставаться в provider metadata или delivery context, но после
resolution не передаётся в business-service owner arguments.

## TON flow

`ton_wallet_id -> verified proof -> identity resolution -> global_id -> business runtime`.

TON registration не требует Telegram account и не создаёт искусственную пару
между `ton_wallet_id`, `tg_id` и `global_id`.

## Acceptance

- `business-owner tg_id = 0`;
- каждая provider identity разрешается ровно в один `global_id`;
- owner FK указывает на `users.global_id`;
- внешний API сериализует `global_id` только строкой;
- test fixtures не используют `tg_id = global_id`;
- exact-head GitHub CI требуется для квалификации.
