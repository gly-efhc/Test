<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# TECHNICAL SPECIFICATIONS

Статус: **ACTIVE INDEX**

## Active

- `TZ_account_registration_service.md` — технический контракт единого
  account registration service.

## Historical

Завершённые migration/cutover ТЗ находятся в:

- `docs/history/legacy_artifacts/docs/NORM/TZ/`.

Исторические ТЗ не являются current NORM и не используются как owner
contract.
