# EFHC Report History NORM

Статус: **ACTIVE**.

1. История reports является обязательной частью истории развития EFHC и не
   удаляется при очистке active documentation.
2. Все immutable reports хранятся в `reports/numbered/`.
3. Имя каждого файла начинается с монотонного номера `reports_NNNNN__`.
4. Номер никогда не переиспользуется и не уменьшается.
5. Каждый завершённый пользовательский запрос, который реально изменяет
   проект, создаёт следующий numbered report. Несколько технических действий
   внутри одного запроса входят в один отчёт, а не создают искусственный шум.
6. Каждый завершённый цикл обязан иметь минимум один numbered report.
7. `reports/current/` содержит только текущие operational pointers/ledgers и
   не заменяет immutable history.
8. Восстановленный из чата отчёт маркируется `RECOVERED_FROM_CHAT_CONTEXT` и
   не выдаётся за исходный потерянный файл.
9. `ops/reports/check_numbered_reports.py` fail-closed проверяет непрерывность
   нумерации, manifest и SHA-256.
