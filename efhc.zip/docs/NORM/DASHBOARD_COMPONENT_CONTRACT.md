<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

> Cycle 1501 note: Dashboard UI Kit Consolidation QA closes
> CYC-1459 from the audit/TZ. `DashboardPanelAction` supports
> `onClick` and `actionKind` in contract version V2. Mutation-safe
> guards remain in parent pages; dashboard components do not mutate.


> Cycle 1465 note: Dashboard Toolbar Foundation adds the shared
> toolbar, time range, refresh and freshness marker layer. Active
> runtime file: `frontend/src/components/dashboard/DashboardToolbar.tsx`.

> Cycle 1462 note: Panel Chrome Foundation is active in
> `docs/NORM/PANEL_CHROME_FOUNDATION.md`. Shared runtime shell lives in
> `frontend/src/components/dashboard/PanelChrome.tsx`; admin and
> simulation wrappers are `AdminPanelChrome` and `SimPanelChrome`.
> Grafana and Песочница remain reference only.

> Cycle 1461 note: Admin Dashboard UI Kit Foundation is active in
> `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md`.
> Additional Grafana element usage map is active in
> `docs/NORM/DASHBOARD_VISUAL_KERNEL.md`.
> Runtime foundation extends
> `frontend/src/components/admin/AdminDashboardUiKit.tsx`.
> Grafana and Песочница remain reference only.

# DASHBOARD COMPONENT CONTRACT

Status: `ACTIVE_DASHBOARD_COMPONENT_CONTRACT`

Cycle: `1459`

Archive target: `v170.35`

## Purpose

This document fixes the EFHC dashboard component contract before
runtime dashboard UI kits are expanded.

The contract defines the minimum fields and states every future
Admin Dashboard Layer and Simulation Dashboard Layer panel must have.
It prevents visually beautiful panels from hiding missing data,
unknown freshness, fake metrics or missing loading/error states.

## Active sources

Primary direction:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Dashboard kernel:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Design tokens:

`docs/NORM/DASHBOARD_DESIGN_TOKENS_FOUNDATION.md`

Grafana pattern map:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Sandbox inventory:

`docs/NORM/DASHBOARD_VISUAL_KERNEL.md`

Runtime contract file:

`frontend/src/lib/dashboard/componentContract.ts`

## Boundary

Grafana is visual-pattern reference only.

Песочница is reference, navigation and prototype layer only.

This cycle adds an EFHC-owned contract and TypeScript type layer. It
does not change EFHC economy, backend contracts, database schema,
CI, locks, money flow or user balances.

## Required panel fields

Every dashboard panel must have:

- `id`;
- `mode` as `admin` or `simulation`;
- `title`;
- optional `subtitle`;
- optional `description`;
- `source`;
- `state`;
- optional `actions`;
- optional `ariaLabel`.

## Required source fields

Every live or derived panel must declare:

- source `label`;
- optional source `route`;
- `dataKind`;
- optional `synthetic` marker.

Allowed data kinds:

- `raw`;
- `derived`;
- `synthetic_preview`;
- `real_timeseries`.

Synthetic preview data is allowed only in Песочница or clearly
marked preview surfaces. Synthetic preview data must never be
presented as runtime truth.

## Required states

Every dashboard panel must support the same state vocabulary:

- `loading`;
- `empty`;
- `error`;
- `stale`;
- `success`.

The `state` object may also include:

- user-readable `message`;
- `updatedAt` timestamp;
- `freshness` value.

Allowed freshness values:

- `fresh`;
- `stale`;
- `unknown`.

## Required tones

Panels must use the shared semantic tones:

- `neutral`;
- `info`;
- `success`;
- `warning`;
- `danger`.

Tones are UI meaning only. They do not change backend truth or EFHC
economy.

## Action rules

Panel actions must be safe and explicit.

Allowed action fields:

- `label`;
- optional `href`;
- optional `onClick`;
- optional `disabled`;
- optional `danger`;
- optional `actionKind`.

Money-changing actions must not be introduced in dashboard widgets
unless they already exist in canonical runtime flows and preserve
existing guards, confirmations and idempotency.

## Action kinds

| actionKind | When to use | Parent obligation |
|---|---|---|
| `nav` | Drill-down or route transition | `href` is required |
| `mutation-safe` | Retry, approve, cancel | Guard + confirm + idempotency in page |
| `copy` | Copy address or ID | `clipboard.writeText` in `onClick` |
| `external` | Open external link | `target` + `rel` protection |

Dashboard components never call `apiRequest` or `mutateAsync`
directly. Mutation actions are passed through
`props.actions[].onClick` and implemented at page level.

The dashboard contract is now
`EFHC_DASHBOARD_CONTRACT_V2`. This is a type-contract extension
only. It does not add runtime mutations, backend routes, OpenAPI
changes, migrations, dependencies, CI/workflow changes or money-flow
changes.

## Admin layer requirements

Admin dashboard panels must prefer:

- Russian operator labels;
- source and freshness visibility;
- drill-down links into existing admin routes;
- safe inspector drawer only when it hides secrets and payloads.

Admin panels must not show secrets, raw initData, env values,
private payloads or debug JSON in normal operator UI.

## Simulation layer requirements

Simulation dashboard panels must prefer:

- human-readable user labels;
- mobile-first layout;
- progress and simple visual summaries;
- clear empty/error states;
- no raw `global_id`, raw enum, raw reason or technical fallback text.

Simulation panels must not invent financial returns, fake rankings or
unmarked synthetic charts.

## Grafana pattern alignment

Cycle 1457 mapped Grafana patterns to EFHC-owned implementations. This
cycle defines the contract those future implementations must follow:

| Pattern | Contract requirement |
|---|---|
| PanelChrome | title, source, state and actions |
| DashboardGrid | panels keep status and no-overflow states |
| RefreshPicker | freshness and updatedAt are explicit |
| Variables | filters change display only, not truth |
| Inspector | safe drawer, no secrets or raw payload |
| BigValue | source and data kind remain visible |
| Sparkline | synthetic flag required for preview data |

## Acceptance criteria

- The contract document exists and is active.
- Runtime type file exists under `frontend/src/lib/dashboard/`.
- Required states are loading, empty, error, stale and success.
- Data kinds distinguish raw, derived, synthetic preview and real
  time-series data.
- Actions are documented and do not bypass money-flow guards.
- Grafana and Песочница remain reference-only sources.
- No economy, backend, migration, CI or lock file changes are made.

## Next step

Cycle `1460 — Simulation Dashboard UI Kit Foundation` should create
user-facing dashboard primitives that implement this contract.

Compatibility anchor:

Synthetic preview data must never be presented as runtime truth.

## Cycle 1460 implementation note

`frontend/src/components/dashboard/SimulationDashboardUiKit.tsx`
implements the first simulation-side runtime primitives that must follow
this contract.

The components must not show synthetic preview data as runtime truth and
must not bypass existing money routes or user identity protections.


## Cycle 1463 progress contract extension

Dashboard progress components must keep the same truth model as any
panel: source, data kind and synthetic marker are required when a
progress widget depends on generated or preview data.

Active runtime anchor:

`frontend/src/components/dashboard/ProgressSystem.tsx`

Allowed progress kinds:

- `linear`;
- `segmented`;
- `circular`;
- `countdown`;
- `milestone`.

Progress widgets are display-only and must not bypass money-flow
guards or mutate backend state.


## Cycle 1464 mini chart contract note

Mini charts must preserve dashboard data-kind metadata and synthetic
preview markers. `synthetic_preview` data must be explicitly marked and
must not be presented as live runtime truth.

