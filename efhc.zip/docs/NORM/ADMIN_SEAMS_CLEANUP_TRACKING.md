# Admin Seams Cleanup Tracking

Status: CLOSED_FULL_SEAMS_MIGRATION

Marker: NO_RAW_ADMIN_APIREQUEST_IN_ADMIN_PAGES

Cycle: 1513

`frontend/src/lib/api/generated/adminSeams.ts` is the single admin
frontend API entrypoint for admin pages.

## Current proof

- OpenAPI `/admin` paths: `59`.
- `adminSeams.ts` path constants: `59`.
- Missing admin seam paths: `0`.
- Extra stale admin seam paths: `0`.
- Raw `apiRequest('/admin...')` in `frontend/src/pages/admin/*.tsx`: `0`.
- Raw `apiRequest(ADMIN_...)` in admin pages: `0`.
- Direct import from `../../lib/api` in admin pages: `0`.

## Canon

Admin pages must not call `apiRequest` directly for `/admin` routes.
They must use `adminApiRequest`, `adminPath` and path constants exported
from `frontend/src/lib/api/generated/adminSeams.ts`.

Allowed low-level raw API client locations:

- `frontend/src/lib/api.ts`;
- `frontend/src/lib/api/generated/adminSeams.ts`;
- test mocks.

## Guard

`tests/architecture/test_admin_frontend_uses_admin_seams.py` is strict as
of cycle 1513 and fails if admin pages return to raw admin `apiRequest`.
