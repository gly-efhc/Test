# Referrals Rules

Status: ACTIVE NORM
Runtime anchors:
- `backend/app/services/referral_service.py`;
- `backend/app/routes/referrals_routes.py`;
- `frontend/src/pages/referrals.tsx`.

## 1. Referral attribution

- Referral attribution is fixed atomically only when a new user record is first
  created in PostgreSQL.
- An existing user can never be attached, reattached or reassigned to an
  inviter.
- A new user who arrives without any invite is a permanent `0 user`; no
  referral link row and no referral reward are created for that user.
- A supplied malformed or unknown referral code is rejected before user
  creation; it is never silently converted into a `0 user`.
- Every player may invite new players.
- Rewards and level counts use direct referrals only.

## 2. Active referral

- A direct referral becomes active after acquiring the first panel.
- Active referral status is permanent even if that panel is archived later.
- First-panel purchase, referral activation and all referral rewards belong to
  one database transaction.

## 3. Monetary rewards

All referral monetary rewards are credited to `bonus_balance` and therefore are denominated in `EFHCb`. The inviter receives both independent reward types:

1. `0.1 EFHCb` once for each active direct referral, limited to the first
   `10 000` active direct referrals.
2. A one-time monetary reward when a direct-referral Lvl threshold is reached:

| Lvl | Active direct referrals | One-time Lvl reward |
|---:|---:|---:|
| 1 | 10 | 1 EFHCb |
| 2 | 100 | 10 EFHCb |
| 3 | 1 000 | 100 EFHCb |
| 4 | 3 000 | 300 EFHCb |
| 5 | 10 000 | 1 000 EFHCb |

All payments:

- come only from the EFHC bank;
- go to the inviter bonus balance;
- use no-commit bank operations inside the first-panel transaction;
- use independent idempotency keys for direct and Lvl rewards.

### Cumulative economic truth

The public UI must not confuse the last activation event with the cumulative
reward earned by the threshold.

- Lvl 1: `10 × 0.1 + 1 = 2 EFHCb` cumulative.
- Lvl 2: `100 × 0.1 + 1 + 10 = 21 EFHCb` cumulative.
- Lvl 3: `1 000 × 0.1 + 1 + 10 + 100 = 211 EFHCb` cumulative.
- Lvl 4: `3 000 × 0.1 + 1 + 10 + 100 + 300 = 711 EFHCb` cumulative.
- Lvl 5: `10 000 × 0.1 + 1 + 10 + 100 + 300 + 1 000 = 2 411 EFHCb`
  cumulative.

### Numbered direct-reward slots

Прямой reward `0.1 EFHCb` идемпотентен по фактически выданному номерному monetary slot. Для каждого inviter существует максимум `10 000` slots `1..10000`.

- Slot allocation атомарно сериализуется на inviter boundary.
- Один slot принадлежит ровно одному inviter и одной direct-referral activation.
- Canonical financial idempotency identity детерминирован inviter + issued slot: `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`.
- Повтор обработки того же slot — idempotent read-through; slot нельзя переназначить другой activation.
- `10001`-й active referral активируется штатно, но не получает direct `0.1 EFHCb` slot и не создаёт direct monetary operation.
- Persistence обеспечивает uniqueness, эквивалентную `UNIQUE(inviter_global_id, unit_reward_no)`, и диапазон `1..10000`.
- Lvl rewards остаются в независимом idempotency namespace `REF_LVL:G{inviter_global_id}:L{level}` и не расходуют numbered direct slots.
- Один threshold activation законно может создать две выплаты: numbered `REF_ACT_UNIT` и соответствующий `REF_LVL`; их idempotency identities никогда не пересекаются.
- Каждый Lvl `1..5` выплачивается одному inviter не более одного раза; повторная синхронизация использует тот же canonical Lvl key. Historical Lvl keys читаются только для bounded compatibility/read-through и не создают повторной выплаты.
- Referral ranking является нефинансовым display/sort контуром и не создаёт `REF_ACT_UNIT`, `REF_LVL` или другие monetary operations.


## 4. Referrals page product contract

The `/referrals` page must contain in one route:

1. a visible progress bar to the next referral Lvl;
2. the permanent referral link, copy action and share buttons for Telegram and
   supported social networks;
3. two segmented tabs, matching the Panels interaction pattern: `Active` and
   `Inactive`, with their lists rendered inside the same page;
4. explicit `Lvl 0–5` display and the complete Lvl threshold/reward scale.

The Lvl scale must receive canonical economics from the backend stats response,
not duplicate reward calculations as frontend constants. Each step shows:

- direct-referral rewards at the threshold in `EFHCb`;
- the one-time reward of the current Lvl in `EFHCb`;
- the accumulated sum of all Lvl rewards reached by that threshold;
- the cumulative total reward in `EFHCb`.

The full cycle must be shown without hidden arithmetic:

```text
10 000 × 0.1 EFHCb = 1 000 EFHCb
1 + 10 + 100 + 300 + 1 000 = 1 411 EFHCb
1 000 + 1 411 = 2 411 EFHCb
```

Only the current user's direct referral lists are public. Raw Telegram IDs are
not displayed.


## 5. Admin Referrals surface
- Human Admin Referrals is sparse and investigation-oriented: exact Global ID lookup, then invited total, referral level and bonus amount.
- `active/inactive` may exist as technical/export columns for investigation but are not separate owner-facing KPI cards.
- Single-user CSV export may include `global_id, invited_total, active, inactive, referral_level, bonus_efhcb`.
- User-facing `/referrals` and `/ranks` are independent and must not be reduced by the Admin sparse doctrine.
- Production must not invent unsupported backend query/filter semantics.
## Admin selected-referral scope
- Selected-referral summary/log/export is server-scoped by exact Global ID; browser all-user fallback is forbidden.
- Owner proof must be validated before selected-user rows/export are accepted.
- Filtering by selected owner happens before limit/pagination.
- A single-user export may combine summary and detail rows, but both remain within the same proven selected-owner scope.

## 6. Current frontend list/share presentation

- User Active/Inactive lists use the existing self routes `/referrals/active/me` and `/referrals/inactive/me` with cursor pagination and an explicit frontend page size of `20`; each load-more request advances only through backend `next_cursor`.
- Already loaded referral rows are normalized newest-first by `invited_at`; `joined_at` is the fallback timestamp, and exact ties preserve original backend order. Frontend does not invent unsupported backend sort parameters.
- Public referral sharing uses the permanent backend referral link and the current five targets: Telegram, WhatsApp, Viber, Facebook and X. Copy and share remain separate user actions.
- `bonus_asset` and `level_steps` are backend-authoritative presentation inputs; frontend does not substitute a different asset or synthesize referral levels.
- `global_id`/`child_global_id` may be used internally for identity/keying but are not displayed as the public username.
