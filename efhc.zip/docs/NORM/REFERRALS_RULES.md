# Referrals Rules

Status: NORM
SSOT anchor: `docs/SSOT/SSOT_INDEX.md`

## Current canon

- Referral bonus is paid only from the EFHC bank.
- Referral bonus events are recorded in `efhc_transfers_log` with operation type `referral_bonus`.
- A referred user becomes active after acquiring the first panel.
- Active status is permanent and does not disappear if a panel later becomes inactive.
- Referral bonuses are начисляются only for active invited users according to the current project canon.

## Current HEAD audit note

- This document should be read together with `docs/SSOT/BANK_CANON.md`, `docs/SSOT/EFHC_CANON.md` and current activation canon for panels.
- Historical referral notes must not override the permanent-active referral rule once they diverge.
