# ADMIN_LOGS_EVENTS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md

**Cycle:** `1490 — Admin Logs / Events Dashboard`  
**Status:** reference-only analysis

## Grafana-like patterns

| Grafana pattern | EFHC-owned usage |
|---|---|
| `DashboardControls` | `AdminDashboardToolbar` |
| `RefreshPicker` | manual refresh для read-only events snapshot |
| `Variables` | display-only source/severity/time filters |
| `PanelChrome` | dashboard panels for event feed and boundaries |
| `BigValue` | KPI cards for total/attention/success/volume |
| `BarGauge` / bar display | `AdminMiniBarChart` for current distribution |
| `StatusHistoryPanel` | `AdminHeatStrip` for current snapshot status strip only |
| `PanelInspector` | not enabled; safe boundary is rendered without raw payload |

## Boundary

EFHC Bot не становится Grafana. `/admin/logs` получает Grafana-grade
визуальную дисциплину, но использует только EFHC-owned components and styles.

No Grafana runtime code, dependencies, plugins, datasource logic, backend logic,
alerting logic, auth logic, lock files or CI files are copied.

## Truth rule

`AdminHeatStrip` and `AdminMiniBarChart` in this cycle are derived snapshot
visualizations. They are not real time-series and must not be described as
history over time until cycle `1491 — Real Time-Series Backend Contracts` or
another explicit backend contract cycle provides real time-series endpoints.
