<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# LEADERBOARD_VISUAL_SYSTEM.md

**Project:** EFHC Bot  
**Cycle:** `1476 — Leaderboard Visual System`  
**Archive:** `v170.52`  
**Status:** ACTIVE FOUNDATION  
**Date:** 2026-06-07

## Purpose

This document defines the shared visual system for EFHC leaderboard
surfaces.

The goal is to make Ranks visually stronger while preserving the
runtime truth boundary:

```text
Leaderboard is visualized from backend truth. It is not invented by UI.
```

## Scope

Created component:

```text
frontend/src/components/dashboard/LeaderboardVisualSystem.tsx
```

Integrated into runtime Ranks dashboard:

```text
frontend/src/components/dashboard/RanksDashboardRuntime.tsx
```

Runtime route remains:

```text
frontend/src/pages/ranks.tsx
```

## Components

The shared visual system contains:

- `SimLeaderboardCard`;
- `SimLeaderboardPodium`;
- `SimLeaderboardList`;
- `buildLeaderboardVisualItem`;
- `leaderboardVisualSystemVersion`.

## Visual rules

Leaderboard cards must show:

- public display name or safe hidden-user fallback;
- rank position;
- score and unit;
- optional VIP badge;
- optional current-user badge;
- optional derived mini trend;
- no raw `global_id` in public text.

Podium cards may visually highlight:

- `#1` as gold tone;
- `#2` as silver tone;
- `#3` as bronze tone;
- current user with a separate border.

## Truth model

Allowed data types:

- `raw` backend leaderboard rows;
- `derived` visual score trend generated from loaded row score;
- `empty` state when backend truth is missing.

Forbidden:

- fake runtime rows;
- fake rank position;
- synthetic runtime leaderboard;
- public 12 Energy-level catalogue;
- economic bonuses or rewards added by leaderboard UI.

## Privacy boundary

The visual layer is username-only.

Raw `global_id` may exist in backend DTO and React internal keys, but it must
not be rendered as public text. Public UI must use `username` or a safe
hidden-user fallback.

## Runtime integration

`RanksDashboardRuntime.tsx` now uses the shared leaderboard visual
system for podium and near-me cards.

The old runtime truth boundary remains:

```text
raw + derived snapshot
```

No backend route, OpenAPI contract, database migration, dependency,
lock file, CI workflow, wallet flow, write flow or money flow was
changed in this cycle.

## Reference layers

Grafana is used only as visual-pattern/reference layer. Runtime code is not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.
