# Archive filename hygiene policy

## Purpose

Archive filenames must stay readable, short and semantic. Numbered work-pass labels are not allowed in product, AI, SSOT, NORM, GENERAL, backend, frontend, ops, tests, admin, or testing-support filenames. Release version labels such as `v169_35` remain allowed only when they identify release lineage and are not used as fresh work-pass noise.

## Exceptions

The following traceability sections may keep numbered work-pass labels when they are needed for history:

- `docs/cycles/`
- `docs/audits/`
- `reports/`
- `docs/chats/`
- `docs/PLANS/WORK_PLAN_1693-1707.md`
- `docs/GENERAL/ARCHIVE_NAV_INDEX.md`

`docs/testing/` is not an exception layer. Test-support documents must use stable semantic names. If cycle traceability is needed in `docs/testing/`, it must be written inside the document body, not in the filename.

## Hard size limits

- Maximum UTF-8 size of one path component: 120 bytes.
- Maximum UTF-8 size of the relative path inside the archive: 220 bytes.

If a name would exceed these limits, shorten the filename and move extra context into the document body.

## Rules

- Keep semantic descriptions in filenames.
- Keep release version labels only where they identify release lineage.
- Do not add numbered work-pass labels to non-exception filenames.
- Do not add mojibake or copy suffixes such as `(1)`.
- Keep original-source markdown names short and human-readable.
- If traceability is needed outside exception sections, place it in the document body without turning it into a filename suffix.
- Do not create names like `*_1390.md`, `*_cycle_1390.md`, or `*_v169_71.md` outside the explicit traceability exceptions listed above.


## Python dunder safety

Filename cleanup must never rewrite Python protocol tokens. The following forms
must remain intact in code and tests: `__future__`, `__file__`, `__name__`,
`__main__`, `__all__`, `__init__`, `__repr__`, `__dict__`, `__import__`,
`__path__` and `__pycache__`.
