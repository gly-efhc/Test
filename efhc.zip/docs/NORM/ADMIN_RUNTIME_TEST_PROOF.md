# Admin Runtime Test Proof

Cycle: 1513

## Scope

Runtime tests added in cycle 1512:

- `tests/efhc_backend/admin/test_admin_withdrawals_hold_repair_runtime.py`
- `tests/efhc_backend/admin/test_admin_bank_bonus_debit_runtime.py`

## Fresh input log status

Source: `logs_74025005532.zip`.

The uploaded GitHub CI log for the input archive was red:

- `ruff`: failed on `E402/I001` in the runtime test files;
- `pytest`: failed during collection because importing
  `admin_withdrawals_service` reached a bot circular import path through
  `outcome_service`;
- `mypy`: passed;
- `bandit`: passed;
- frontend build: passed;
- gate summary: failed.

## Repair in cycle 1513

- Test import layout is repaired for ruff.
- `outcome_service` no longer imports `get_bot` at module import time;
  the bot accessor is loaded lazily only when telegram delivery is sent.
- The historical `admin__main__handlers` wrapper now exports `router`, so
  the compatibility import path is coherent.

## Local proof status

In the limited sandbox, backend dependencies can be installed, but no
PostgreSQL test service is available. Therefore the runtime DB tests are
collected and import cleanly, but skip on missing `DATABASE_URL`.

This is not claimed as final runtime proof.

## Required GitHub CI proof

A fresh GitHub CI rerun for the output archive must show:

- withdraw hold repair runtime test: `PASSED`;
- withdraw hold repair replay test: `PASSED`;
- withdraw insufficient balance test: `PASSED`;
- admin bonus debit runtime test: `PASSED`;
- admin bonus debit replay test: `PASSED`;
- admin bonus insufficient balance test: `PASSED`;
- raw `TypeError`: `NOT FOUND`.

Until that fresh rerun exists, final status is:

`RUNTIME_P1_TESTS_READY_BUT_NOT_PROVEN_BY_FRESH_CI`.
