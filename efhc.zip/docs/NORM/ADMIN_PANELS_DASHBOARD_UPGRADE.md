# ADMIN_PANELS_DASHBOARD_UPGRADE

**Project:** EFHC Bot  
**Cycle:** 1487 — Admin Panels Dashboard Upgrade  
**Archive:** v170.63  
**Status:** ACTIVE / DONE LOCALLY  
**Layer:** Admin Dashboard Layer  
**Mode:** runtime UI-only / read-only panels dashboard

## 1. Purpose

Cycle 1487 upgrades `/admin/panels` with a read-only dashboard for panel
lifecycle control.

The dashboard helps the operator see active/archive distribution, 180-day
lifecycle progress, expiring-soon markers, missing-expiry attention
markers, generated kWh totals, base generation-rate audit totals, panel
age buckets and a recent safe panel snapshot before using the existing
guarded panel controls.

The dashboard does not replace or move the existing panel activation or
deactivation controls.

## 2. Runtime component

```text
frontend/src/components/admin/AdminPanelsDashboardRuntime.tsx
```

Integrated into:

```text
frontend/src/pages/admin/panels.tsx
```

## 3. Data sources

The dashboard uses the existing read-only route only:

```text
GET /admin/panels
GET /admin/panels?tg_id=...
```

The existing page list can still use:

```text
GET /admin/panels?tg_id=...&is_active=true
```

No new backend endpoint is added.

## 4. Truth model

```text
raw + derived snapshot
```

Allowed:

- active panel count from real `is_active`;
- archive count from real `is_active=false`;
- expiring-soon marker derived from real `expires_at`;
- missing-expiry marker when active row has no `expires_at`;
- average lifecycle progress only from real `created_at` and `expires_at`;
- generated kWh total from real `generated_kwh`;
- base generation-rate audit total from real `base_gen_per_sec`;
- panel age buckets derived from `created_at`;
- recent safe panel snapshot.

Forbidden:

- fake activation trends;
- fake panel history;
- synthetic admin analytics;
- panel lifecycle rewrite;
- 180-day canon changes;
- generation-rate changes;
- activation/deactivation bypass;
- raw payload dumps;
- debug JSON;
- secrets;
- dashboard write actions.

## 5. Write-flow boundary

The dashboard component is read-only. It does not call `apiRequest`,
`fetch`, `POST`, `PATCH`, `PUT`, `DELETE` or create idempotency keys.

Existing guarded controls stay in the page:

- active-only table filter;
- panel activate action;
- panel deactivate action;
- idempotency key creation in existing action handlers.

## 6. Lifecycle boundary

The dashboard can display the 180-day lifecycle and derived progress, but
it cannot change panel lifecycle rules.

If lifecycle dates are missing, the dashboard shows an unknown/attention
state instead of inventing dates or progress.

## 7. Previous UX debt fixed in this cycle

The 1485 deposits dashboard had two progress bars using the same
`observedTotal` denominator:

```text
Automation credited = auto / observedTotal
Exception backlog = exceptionTotal / observedTotal
```

Because `pending_intents` is also part of `observedTotal`, the two bars
could visually sum to less than 100%.

Cycle 1487 adds a third read-only progress bar:

```text
Pending intents = pending_intents / observedTotal
```

This is a UI-only clarity fix. It does not change deposits backend,
replay, exception processing, force fulfill, idempotency or money flow.

## 8. Grafana / Sandbox boundary

Grafana is used only as visual-pattern/reference layer. Runtime code is
not copied.

Песочница is used only as reference/navigation/prototype layer. Runtime
code is not copied.

## 9. Acceptance

Cycle 1487 is complete when:

- `AdminPanelsDashboardRuntime` exists;
- `/admin/panels` integrates it;
- dashboard uses only existing read-only panel list snapshots;
- guarded panel controls remain outside the dashboard;
- no fake activation trends or fake panel history are introduced;
- no raw payload/debug JSON/secrets are visible in dashboard;
- 180-day lifecycle and generation logic are not changed;
- architecture guard protects the boundary;
- 1485 progress-bar coverage UX debt is closed safely.
