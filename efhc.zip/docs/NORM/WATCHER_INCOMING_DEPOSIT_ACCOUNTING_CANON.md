# Watcher Incoming Deposit Accounting Canon

Watcher учитывает входящие EFHC/TON события по уникальной on-chain
идентичности транзакции.

Одна уникальная on-chain транзакция = один видимый accounting outcome.

Повтор того же `tx_hash` является идемпотентным read-through и не может
создать второе начисление.

Другой `tx_hash` является другой on-chain транзакцией, но сам по себе не
получает право повторно использовать уже закрытый или истёкший Payment Intent.
Для автоматического settlement через Payment Intent требуется новый живой
`PENDING` intent либо отдельный canonical direct-deposit flow.

Watcher не имеет права молча терять второй реальный входящий платёж: транзакция
должна получить видимый результат (`pending_manual`, conflict или иной
канонический статус), но отсутствие нового допустимого intent не разрешает
автоматическое начисление.

## V1 identity

Текущая V1 on-chain identity — `tx_hash`.

Глобальный settlement claim по `tx_hash` описан в
`docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`.
