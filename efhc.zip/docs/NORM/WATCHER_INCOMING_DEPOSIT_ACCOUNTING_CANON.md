# Watcher Incoming Deposit Accounting Canon

Watcher accounts incoming EFHC/TON events by unique on-chain
transaction identity.

One unique on-chain transaction identity = one incoming deposit record.

Replay of the same transaction identity is an idempotent no-op and must
not create a second credit.

A new on-chain transaction identity is a new incoming deposit, even if
payload, comment, or intent matches a previous transaction.

Watcher must not silently drop a second real incoming payment only
because the intent or payload was used before.

## V1 identity

Current V1 identity is `tx_hash`.

Future hardening may extend identity with network, logical time,
message hash, or out message hash.
