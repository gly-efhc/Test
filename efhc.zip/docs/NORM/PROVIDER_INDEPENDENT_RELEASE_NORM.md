# Provider-independent release norm

Status: ACTIVE NORM.
SSOT: `docs/SSOT/PROVIDER_INDEPENDENT_DEPLOYMENT_SSOT.md`.

## Mandatory release contents

Every production release archive must contain:

- backend and frontend production code;
- `Dockerfile.backend` and `Dockerfile.frontend`;
- a root `docker-compose.yml`;
- PostgreSQL migrations;
- `.env.example` without secrets;
- a Caddy HTTPS proxy configuration;
- an Ubuntu 24.04 Docker installer;
- deploy and health verification scripts;
- PostgreSQL backup, restore and restore-drill scripts;
- domain and Telegram webhook reconfiguration scripts;
- off-site backup synchronization support;
- a daily persistent backup timer;
- migration, rollback and disaster-recovery instructions;
- preservation of the exact release ZIP for off-site recovery;
- file and archive checksums;
- `UPDATE_POLICY.json` with an explicit database migration class;
- safe full-archive update and bounded application rollback scripts.

## Forbidden release dependencies

The deployment contract must not require:

- an OVHcloud-specific API or panel;
- Vercel runtime or deployment metadata;
- Neon-only PostgreSQL functions;
- Google Cloud-only runtime services;
- a proprietary provider plugin;
- secrets committed to the archive;
- a production `.env` file;
- seed phrases or user private keys.

Optional provider integrations are allowed only outside the core runtime
and only when a standard portable path remains complete.

## Deployment safety

Deployment scripts must:

1. fail when `.env` is absent or contains placeholders;
2. require restrictive `.env` permissions;
3. validate Docker Compose before starting;
4. wait for PostgreSQL health;
5. apply Alembic migrations before serving traffic;
6. verify backend and frontend health;
7. preserve a rollback and database recovery path;
8. avoid printing secret values.

## Database safety

Backups use PostgreSQL custom format with `--no-owner` and `--no-acl`.
Restores require checksum verification and explicit operator confirmation.
A restore drill uses a separate temporary database and never proves a
production restore by merely checking that a dump file exists.

## Release status

A package may be marked:

- `LOCAL_PRE_RELEASE_99_PERCENT` after all locally executable gates pass;
- `READY_FOR_TECHNICAL_DEPLOYMENT` when the portable archive is valid;
- `PRODUCTION_RELEASE_READY` only after external deployment, Telegram,
  wallet and transaction gates are complete.


## Full-release update safety

Production updates must use a complete release ZIP. The updater must reject
unsafe paths, symbolic links, checksum mismatches, equal or older versions and
incompatible database migration classes. It must deploy into a separate
version directory and switch the active symlink only after all healthchecks.
Automatic rollback is forbidden unless the release explicitly declares the
database change `BACKWARD_COMPATIBLE`. Database restore is never implicit.
