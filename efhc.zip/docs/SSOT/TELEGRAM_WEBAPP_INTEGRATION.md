## Цикл 1791 — atomic Telegram webhook transaction boundary (v174.42)

- После проверки `TELEGRAM_WEBHOOK_SECRET` JSON body валидируется до dedupe state.
- `processed_external_events` marker вставляется без commit и принадлежит той же root transaction, что `process_update()`.
- Один final commit выполняет webhook только после успешной business processing.
- Duplicate branch делает rollback/read-only close и возвращает `dedupe=True`.
- Dedupe storage unavailable → rollback + `503 WEBHOOK_DEDUPE_UNAVAILABLE`; ordinary exception/cancellation → rollback + re-raise.
- Manual compensating DELETE processed marker запрещён.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Telegram WebApp integration (EFHC CANON / SSOT)

## Цели

1) Каноничный UX в Telegram WebApp
   без влияния на SSOT.
2) Идентичность пользователя
   подтверждается только через initData.
3) Запрет хранения финансовых данных
   на клиенте.

## Frontend (канон)

### Safe-access слой

Единый модуль: `frontend/src/lib/telegram.ts`.

Обязательные правила:

- Доступ к `window.Telegram`
  только через helper `tg()`.
- `tgReady()` вызывается один раз
  при старте приложения.
- Интеграция не должна затрагивать
  расчёты D8/SSOT.

### Theme sync

- Цвета/параметры Telegram
  применяются только как CSS vars.
- Нельзя менять SSOT числа
  при синхронизации темы.

### Telegram Theme Tokens (канон)

Контракт визуальной темы EFHC WebApp фиксируется через
единый
набор CSS tokens.
Компоненты SSOT-зоны используют только
эти переменные, без хардкода цветов.

Обязательные tokens (MUST):

- `--tg-bg`
- `--tg-text`
- `--tg-hint`
- `--tg-link`
- `--tg-button`
- `--tg-button-text`
- `--tg-secondary-bg`

Маппинг из `Telegram.WebApp.themeParams`:

- `bg_color` -> `--tg-bg`
- `text_color` -> `--tg-text`
- `hint_color` -> `--tg-hint`
- `link_color` -> `--tg-link`
- `button_color` -> `--tg-button`
- `button_text_color` -> `--tg-button-text`
- `secondary_bg_color` -> `--tg-secondary-bg`

Fallback правила:

- Если `secondary_bg_color` отсутствует,
  использовать `bg_color`.
- Если отдельный параметр отсутствует,
  оставить дефолт token из `globals.css`.
- Никаких преобразований D8/балансов:
  только UI.

### Haptics

- Допускается только на UI-события:
  - tap
  - success / error
- Запрещено привязывать haptics к расчётам
  балансов.

### MainButton / BackButton

- BackButton показывается только на
  подэкранах/модалках.
- На корневых вкладках BackButton скрыт.
- MainButton — UI-триггер.
  Все балансы/решения берутся с backend.

### CloudStorage (жёсткий запрет для финансов)

Разрешено хранить только UI-настройки,
например:

- выбранная вкладка
- фильтр
- локальные UI переключатели

Запрещено хранить (MUST NOT):

- balance / main_balance
- available / available_kwh
- withdraw / exchange значения и статусы
- права, VIP/NFT, результаты операций

## Backend (канон)

### initData verification

- Подпись initData валидируется на сервере
  (HMAC по Telegram).
- `global_id` извлекается только из
  валидированного initData (или серверной
  сессии), не из клиента.

## Guards / Tests

- UI SSOT guard валит CI при `Number(`
  / `parseFloat(` / `toFixed(`
  / `toExponential(` в фиксированных SSOT UI путях.
- CloudStorage guard валит CI при попытке
  использовать ключи financial/state-типа
  (`balance`, `withdraw`, `exchange` и т.п.).

## v169_53 shell polish lock

Telegram Mini App shell integration now has an explicit viewport/theme/BackButton/safe-area lock:

- `frontend/src/lib/telegram.ts` remains the only safe-access module for Telegram WebApp helpers.
- `applyTelegramCssVars()` must expose Telegram/browser shell markers and safe-area variables without touching SSOT financial values.
- Public non-root routes may show Telegram BackButton; root route and admin routes must not use public route BackButton behavior.
- Deposit/TonConnect modal states own or suppress BackButton behavior while active.
- Safe-area and viewport changes are UI-only. They must not alter balances, rights, panels, wallet status, exchange rates or operation outcomes.
- Sandbox Telegram templates are reference-only and must not be copied as runtime framework code.

## v169.75 CI verification note

The fresh supplied CI log `logs_72181359058.zip` showed that the
Telegram/WebApp shell guard lane did not fail after v169.74. The Next.js
build completed and the route table retained `/api/tonconnect-manifest`
without exposing raw wallet or payment internals as public diagnostics.

This is CI/source evidence only. It is not a live Telegram client run and
not a real TonConnect transaction proof.

