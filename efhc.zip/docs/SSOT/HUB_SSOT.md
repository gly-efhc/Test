<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# HUB SSOT (Single Source of Truth)
Version: v1
Status: ACTIVE
Scope: EFHC Bot / WebApp / Admin / FAQ

---

## 1. Назначение Hub

Hub — это раздел навигации и переходов к ключевым действиям проекта.

Hub НЕ является магазином.

Hub НЕ является платёжным интерфейсом.

Hub НЕ является местом выполнения финансовых операций.

---


## 1.1. Exact funding labels and public-copy lock

- `Прямое пополнение` is not a HUB function. It belongs only to the `+` button and means EFHC jetton → EFHCm.
- The public HUB shows exactly two visible actions: `Пополнение` and `EFHC VIP NFT`.
- Before the user leaves the application, the `Пополнение` action MUST NOT mention purchase, shop, package, TON, GRAM, USDT, price, currency or checkout. The separate canonical `EFHC VIP NFT` collection action is allowed.
- HUB MUST NOT render explanatory descriptions under either action; only the two canonical action labels and buttons are visible.
- The signed handoff may open Browser Shop, where commerce copy becomes allowed.
- HUB MUST NOT open the Direct Deposit modal.
- GlobalHeader `+` MUST NOT open Browser Shop.

## 1.2. Чат поддержки — отдельный контактный контур

- «Чат поддержки» существует отдельно от публичного Hub и **не считается третьим действием Hub**: пользовательский Hub по-прежнему показывает ровно `Пополнение` и `EFHC VIP NFT`.
- Admin → «Центр ссылок» имеет отдельный блок «Чат поддержки» для управления текущими способами связи.
- Контакты поддержки используют зарезервированный namespace `support_` в существующем хранилище `hub_links`; новая миграция `0002+` не требуется.
- Публичное чтение контактов выполняется через `GET /hub/support-links`. Управление выполняется отдельными маршрутами `/admin/hub/support-links...`; generic Hub CRUD не должен изменять `support_` записи.
- Допустимы безопасные способы связи `https`, `tg`, `mailto`, `tel`; остальные схемы URL должны отклоняться fail-closed.
- Frontend Profile ведёт пользователя на отдельную страницу поддержки. Если доступных контактов временно нет, пользователь может открыть FAQ и повторить загрузку позже.

## 2. Определение

Hub = navigation layer

Hub — это интерфейс, который:
- отображает карточки действий
- перенаправляет пользователя
- не выполняет операции напрямую

---

## 3. Основные принципы

### 3.1 MUST

Hub обязан:

- показывать только карточки действий
- использовать безопасные переходы (external / internal routes)
- не хранить бизнес-логику операций
- не инициировать оплату
- не инициировать транзакции
- не обрабатывать финансы

### 3.2 MUST NOT

Hub запрещено:

- содержать цены (TON, USDT, EFHC)
- содержать поля price, currency
- выполнять покупку
- запускать TonConnect
- выполнять deposit
- выполнять withdraw
- выполнять exchange
- показывать товарный каталог
- выступать как marketplace
- выступать как магазин

---

## 4. Допустимые public-действия HUB

На действующем public-маршруте разрешены ровно две равные кнопки:

### 4.1 Пополнение

Требования:
- видимый текст только `Пополнение`;
- без описания назначения до выхода из приложения;
- только signed external handoff;
- никакой оплаты внутри HUB.

### 4.2 EFHC VIP NFT

Требования:
- видимый текст `EFHC VIP NFT`;
- внешний переход в официальную коллекцию GetGems;
- без цены, покупки, оплаты или checkout внутри HUB;
- функция не может удаляться без прямого решения пользователя.

## 5. EFHC Top-up Flow (обязательный)

Flow:

Telegram или Web → Hub → Пополнение → backend → signed handoff token → внешний Browser Shop → покупка EFHCm за TON/GRAM или USDT jetton

### 5.1 Правила

- global_id НЕЛЬЗЯ передавать напрямую
- используется только backend-issued token
- token должен:
  - иметь exp (TTL)
  - иметь jti (одноразовость)
  - быть подписан

---

## 6. VIP NFT

EFHC VIP NFT отображается как вторая каноническая кнопка HUB.
Кнопка ведёт только во внешнюю официальную коллекцию GetGems и не превращает HUB во внутренний магазин или checkout.

## 7. Скины (канон)

Скины:

- НЕ являются товаром
- НЕ продаются
- НЕ находятся в Hub
- НЕ имеют цены

Скины:

- выдаются только через систему достижений
- привязаны к 12 уровням прогресса
- имеют отдельный concept-layer switcher вне Hub и вне commerce-domain

Подробный концепт switcher-а фиксируется отдельным документом:
- `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`

---

## 8. Admin Hub Rules

Админ управляет:

- карточками Hub
- ссылками
- порядком отображения
- текстами

Админ НЕ управляет:

- ценами
- товарами
- оплатой
- валютами

---

## 9. Shop Alias Policy (временный)

На переходный период:

- shop → hub (alias)
- все старые маршруты shop ведут в hub
- пользователь видит только Hub

### 9.1 MUST

- сохранять алиас до полной миграции

### 9.2 MUST NOT

- использовать слово Shop в новых местах
- создавать новый функционал под именем Shop

### 9.3 Removal

После завершения миграции:

- удалить только подтверждённые alias traces `shop`;
- не удалять backend commerce domain и history-only traces без
  отдельного аудита;
- выполнять removal по документу
  `docs/HUB_FINAL_ALIAS_REMOVAL_DESIGN.md`;
- оставлять только `Hub` как user-facing/admin-facing термин.

---

## 10. Guard Rules

Обязательные проверки:

- Hub UI не содержит price
- Hub UI не содержит currency
- Hub UI не вызывает TonConnect
- Hub не вызывает purchase endpoints
- Hub не создаёт orders

---

## 11. FAQ Alignment

FAQ должен отражать:

- Hub = navigation layer
- EFHC покупается вне бота
- HUB показывает отдельную кнопку EFHC VIP NFT, но не показывает цены, оплату или описание покупки
- Hub — это переходы
- скины — это достижения

---

## 12. Инварианты

Следующие правила неизменны:

- Hub не становится магазином
- Hub не становится платёжным интерфейсом
- Hub не содержит экономику
- Hub остаётся navigation layer

---

## 13. Нарушения

Любое из ниже считается нарушением SSOT:

- добавление цены в Hub
- добавление кнопки “купить” в Hub
- запуск TonConnect из Hub
- добавление товаров в Hub
- возврат модели Shop

---

## 14. Статус

Документ обязателен для:

- backend
- frontend
- admin panel
- FAQ
- QA
- guard checks

---

END OF DOCUMENT

## Current HEAD audit note

- Current admin/hub boundary is aligned with `docs/GENERAL/ADMIN_PANEL_SPEC.md` and `docs/NORM/ADMIN_RBAC.md`: Hub manager remains a navigation/links layer and does not replace commerce reporting.
- Current commerce boundary remains compatible with backend commerce domain and legacy compatibility aliases; Hub must not be read as a payment execution surface.
- FAQ/user-facing alignment for Hub must be read together with `docs/SSOT/FAQ_SSOT.md`.
- Historical alias/wave/handoff documents in audits/artifacts are no longer current-state truth for HEAD.


## 4. Внешний browser-shop

Hub остаётся только навигационным и handoff-слоем.

Подтверждённая линия проекта:
- HUB показывает две кнопки: `Пополнение` и `EFHC VIP NFT`;
- `Пополнение` не содержит коммерческого описания до внешнего перехода;
- после нажатия signed handoff переводит пользователя во внешний сектор;
- Hub не превращается во внутренний checkout и не выполняет оплату внутри
  Telegram-интерфейса.

## 5. Связь Hub и внешнего Shop

Hub может:
- передавать пользователя во внешний Shop по handoff key;
- быть быстрым входом во внешний commerce-flow.

Hub не должен:
- становиться корзиной;
- смешивать navigation layer с checkout layer;
- заменять внешний status/checkout flow.


## Signed handoff authentication boundary

Audience-bound Hub/Browser Shop token обязан проверять `aud=efhc_buy_site`
не только после decode, но и самим JWT decoder через expected audience.
Проверки `kind` и canonical owner claim остаются дополнительной domain
separation.

Разрешение handoff owner всегда повторно проверяет, что canonical
`efhc_core.users.global_id` существует и `is_active IS TRUE`. Поэтому
деактивация account прекращает действие ранее выданного stateless handoff
даже до его `exp`.
