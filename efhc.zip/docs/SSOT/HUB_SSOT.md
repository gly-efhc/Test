# HUB SSOT (Single Source of Truth)
Version: v1
Status: ACTIVE
Scope: EFHC Bot / WebApp / Admin / FAQ

---

## 1. Назначение Hub

Hub — это раздел навигации и переходов к ключевым действиям проекта.

Hub НЕ является магазином.

Hub НЕ является платёжным интерфейсом.

Hub НЕ является местом выполнения финансовых операций.

---

## 2. Определение

Hub = navigation layer

Hub — это интерфейс, который:
- отображает карточки действий
- перенаправляет пользователя
- не выполняет операции напрямую

---

## 3. Основные принципы

### 3.1 MUST

Hub обязан:

- показывать только карточки действий
- использовать безопасные переходы (external / internal routes)
- не хранить бизнес-логику операций
- не инициировать оплату
- не инициировать транзакции
- не обрабатывать финансы

### 3.2 MUST NOT

Hub запрещено:

- содержать цены (TON, USDT, EFHC)
- содержать поля price, currency
- выполнять покупку
- запускать TonConnect
- выполнять deposit
- выполнять withdraw
- выполнять exchange
- показывать товарный каталог
- выступать как marketplace
- выступать как магазин

---

## 4. Допустимые карточки Hub

На старте разрешены:

### 4.1 EFHC

Назначение:
- переход на внешний контур покупки EFHC

Требования:
- только переход
- никакой оплаты внутри Hub

---

### 4.2 VIP

Назначение:
- переход на внешний NFT-маркетплейс (GetGems)

Требования:
- Hub не продаёт NFT
- Hub не обрабатывает NFT-покупку
- Hub только открывает внешний ресурс

---

### 4.3 Допустимые расширения

Допускается добавление карточек только если:

- они не являются продажей
- они не запускают оплату
- они не содержат цены
- они не нарушают принципы Hub

---

## 5. EFHC Top-up Flow (обязательный)

Flow:

Telegram → Hub → EFHC → backend → handoff token → внешний сайт →
покупка

### 5.1 Правила

- tg_id НЕЛЬЗЯ передавать напрямую
- используется только backend-issued token
- token должен:
  - иметь exp (TTL)
  - иметь jti (одноразовость)
  - быть подписан

---

## 6. VIP NFT

- покупка происходит только вне Hub
- источник: GetGems или другой внешний маркетплейс
- Hub не участвует в продаже
- Hub только даёт ссылку
- VIP определяется через wallet ownership

---

## 7. Скины (канон)

Скины:

- НЕ являются товаром
- НЕ продаются
- НЕ находятся в Hub
- НЕ имеют цены

Скины:

- выдаются только через систему достижений
- привязаны к 12 уровням прогресса
- имеют отдельный concept-layer switcher вне Hub и вне commerce-domain

Подробный концепт switcher-а фиксируется отдельным документом:
- `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`

---

## 8. Admin Hub Rules

Админ управляет:

- карточками Hub
- ссылками
- порядком отображения
- текстами

Админ НЕ управляет:

- ценами
- товарами
- оплатой
- валютами

---

## 9. Shop Alias Policy (временный)

На переходный период:

- shop → hub (alias)
- все старые маршруты shop ведут в hub
- пользователь видит только Hub

### 9.1 MUST

- сохранять алиас до полной миграции

### 9.2 MUST NOT

- использовать слово Shop в новых местах
- создавать новый функционал под именем Shop

### 9.3 Removal

После завершения миграции:

- удалить только подтверждённые alias traces `shop`;
- не удалять backend commerce domain и history-only traces без
  отдельного аудита;
- выполнять removal по документу
  `docs/HUB_FINAL_ALIAS_REMOVAL_DESIGN.md`;
- оставлять только `Hub` как user-facing/admin-facing термин.

---

## 10. Guard Rules

Обязательные проверки:

- Hub UI не содержит price
- Hub UI не содержит currency
- Hub UI не вызывает TonConnect
- Hub не вызывает purchase endpoints
- Hub не создаёт orders

---

## 11. FAQ Alignment

FAQ должен отражать:

- Hub = navigation layer
- EFHC покупается вне бота
- VIP покупается вне бота
- Hub — это переходы
- скины — это достижения

---

## 12. Инварианты

Следующие правила неизменны:

- Hub не становится магазином
- Hub не становится платёжным интерфейсом
- Hub не содержит экономику
- Hub остаётся navigation layer

---

## 13. Нарушения

Любое из ниже считается нарушением SSOT:

- добавление цены в Hub
- добавление кнопки “купить” в Hub
- запуск TonConnect из Hub
- добавление товаров в Hub
- возврат модели Shop

---

## 14. Статус

Документ обязателен для:

- backend
- frontend
- admin panel
- FAQ
- QA
- guard checks

---

END OF DOCUMENT

## Current HEAD audit note

- Current admin/hub boundary is aligned with `docs/GENERAL/ADMIN_PANEL_SPEC.md` and `docs/NORM/ADMIN_RBAC.md`: Hub manager remains a navigation/links layer and does not replace commerce reporting.
- Current commerce boundary remains compatible with backend commerce domain and legacy compatibility aliases; Hub must not be read as a payment execution surface.
- FAQ/user-facing alignment for Hub must be read together with `docs/SSOT/FAQ_SSOT.md`.
- Historical alias/wave/handoff documents in audits/artifacts are no longer current-state truth for HEAD.


## 4. Внешний browser-shop

Hub остаётся только навигационным и handoff-слоем.

Подтверждённая линия проекта:
- покупка EFHC и VIP NFT выполняется во внешнем browser-shop;
- Hub внутри Telegram показывает карточки/ссылки и переводит пользователя во
  внешний сектор;
- Hub не превращается во внутренний checkout и не выполняет оплату внутри
  Telegram-интерфейса.

## 5. Связь Hub и внешнего Shop

Hub может:
- передавать пользователя во внешний Shop по handoff key;
- открывать внешние ссылки проекта (например, VIP/GetGems);
- быть быстрым входом во внешний commerce-flow.

Hub не должен:
- становиться корзиной;
- смешивать navigation layer с checkout layer;
- заменять внешний status/checkout flow.
