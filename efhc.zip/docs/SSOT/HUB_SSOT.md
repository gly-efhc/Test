<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# HUB SSOT — CURRENT

Статус: **ACTIVE / OWNER LOCK / CURRENT-ONLY**.
Область: public HUB, HUB launchers, Admin HUB representation, standalone HUB demo.

## 1. Единственное назначение

HUB — navigation layer / хранилище разрешённых OWNER ссылок на внешние сервисы EFHC. HUB не является Shop, checkout, каталогом, платёжным интерфейсом, TonConnect surface и не показывает товары, цены, кошельки или финансовые данные. Целевой сервис никогда не рендерится внутри HUB.

## 2. Public HUB — ровно две ссылки

1. `Магазин`.
2. `EFHC VIP NFT`.

Третья ссылка запрещена без нового прямого OWNER решения. Empty/disabled/placeholder/«подготовленные» слоты и динамическое добавление дополнительных public links запрещены. Исторические backend/Admin записи не дают права рендерить дополнительные public HUB links. Отсутствие любой из двух канонических ссылок является регрессией.

## 3. Магазин

Canonical destination: Web EFHC `/browser-shop`. Shop является отдельной web surface.

- Telegram WebApp: `POST /shopfront/access-key` → backend signed `redirect_url` → `Telegram.WebApp.openLink(redirect_url)` → внешний системный браузер.
- Обычный Web EFHC: signed handoff → `window.location.assign(redirect_url)` в текущем browser context.

Запрещено рендерить Shop внутри HUB/Telegram WebView, показывать HUB-пакеты/цены/checkout/wallets или заменять Shop fake/internal renderer.

## 4. EFHC VIP NFT / GetGems

Canonical exact URL: `https://getgems.io/efhc-nft`.

Кнопка HUB `EFHC VIP NFT` всегда открывает этот URL напрямую:
- Telegram WebApp: `Telegram.WebApp.openLink(...)`;
- ordinary Web EFHC: новая вкладка через `window.open(..., "_blank", "noopener,noreferrer")`.

Любой `/efhc-vip-nft` route удалён и не может быть промежуточным destination. Также запрещены `/browser-shop#vip`, `/shopfront/access-key`, signed Shop handoff или внутренний EFHC VIP renderer как замена direct GetGems link. Товар `EFHC VIP NFT` внутри внешнего Shop — отдельная commerce-функция и не меняет назначение HUB-ссылки.

## 5. Separation law

Не смешивать:
- HUB Shop launcher;
- HUB GetGems link;
- товар `EFHC VIP NFT` внутри внешнего Shop;
- Header `+ EFHC` deposit.

## 6. Admin HUB

До нового OWNER решения Admin HUB не является конструктором произвольных public links. Owner-visible Admin HUB отражает только две канонические ссылки и не показывает/публикует дополнительные или пустые slots. Исторические backend endpoints управления HUB links не расширяют public authority.

## 7. Release guard

Регрессия, если:
- visible HUB actions != 2;
- GetGems URL отличается от exact canonical URL;
- HUB VIP использует Shop access-key или intermediate EFHC route;
- Shop в Telegram остаётся внутри WebView;
- Shop рендерится внутри HUB;
- существует visible empty/custom HUB slot;
- ordinary Web GetGems navigation перестаёт быть direct new-tab navigation;
- ordinary Web Shop перестаёт использовать same-context signed handoff.

END OF ACTIVE SSOT.
