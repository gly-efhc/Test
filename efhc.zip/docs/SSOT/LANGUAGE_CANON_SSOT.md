# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ/FAQ — цикл 1839

## ТЕКУЩИЙ POINTER — v174.99 / cycle 1839

Application localization, FAQ runtime и FAQ SSOT остаются `16/16`; FAQ содержит `20` разделов / `206` Q&A. В cycle `1839` переводная волна не выполнялась, потому что после OWNER-коррекции ни одна переработанная русская формулировка `N40`, `N45–N57` не получила финальный approval. После такого approval перевод и SSOT/runtime mutation выполняются синхронно по всем `16` языкам.

---

## ТЕКУЩИЙ REVIEW-СТАТУС — v174.98 / цикл 1838

Языковой/FAQ CANON не изменён: application runtime, FAQ runtime и FAQ SSOT остаются `16/16`; фактический FAQ — `20` разделов × `206` Q&A при верхнем лимите `250`. Cycle `1838` сформировал только DRAFT `N39–N53`; FAQ content delta `0`, `49/49` controlled paths byte-equal input. Переводы не выполнялись, поскольку OWNER approval на новые Q&A отсутствует. После approval русский semantic source и остальные `15` языков должны обновляться параллельно в одном цикле. `FAQ-APPROVAL-0026` и protected progression series `18` Q&A остаются без изменений.

## ТЕКУЩИЙ REVIEW-СТАТУС — v174.97 / цикл 1837

Языковой и FAQ CANON не менялся: application runtime, FAQ runtime и FAQ SSOT остаются `16/16`; FAQ содержит `20` разделов и фактически `206` Q&A на язык при верхнем лимите `250`. `FAQ-APPROVAL-0026` продолжает защищать 12 Energy + 6 referral level Q&A. Новые `N1–N31` и `N34–N38` остаются DRAFT OWNER-review; `N32/N33` не могут автоматически интегрироваться как новые coverage gaps без отдельного OWNER approval. FAQ content delta цикла `1837` равен `0`. Следующая плановая волна `1838` допускает только явно утверждённые OWNER Q&A.

## ТЕКУЩИЙ FAQ OWNER-КАНОН — цикл 1836

## ТЕКУЩИЙ OWNER-КАНОН — v174.96 / цикл 1836

FAQ SSOT/runtime остаётся `16/16`. Внутри раздела уровней защищены две семантические серии: 12 Energy statuses и 6 referral statuses. Исторические ссылки `19-7…19-18` и `19-19…19-24` после reindex цикла `1835` соответствуют текущим позициям `19-6…19-17` и `19-18…19-23`. Эти Q&A нельзя удалять/объединять/использовать как replacement pool; допускается только синхронное улучшение описаний на всех `16` языках без изменения самих уровней, порядка и порогов. Authority: `docs/SSOT/faq_ssot/RU_FAQ_LEVEL_SERIES_CANON.md`. Новые `N1–N38` пока не утверждены.

Application runtime, FAQ checked-in runtime и FAQ SSOT остаются `16/16`. Для FAQ обязательны ровно `20` разделов, максимум `250` Q&A на язык и одинаковая per-section структура всех `16` языков. После утверждённых OWNER удалений фактический размер равен `206` Q&A на язык; свободно `44` слота. Две уровневые серии раздела 19 — 12 Energy levels и 6 Referral levels — защищены и не входят в эти свободные/заменяемые слоты. FAQ fallback не заменяет физический каталог поддерживаемого языка. Новые Q&A не добавляются до отдельного OWNER approval.

### Актуальный план FAQ после цикла 1835 — циклы 1836–1847

- **1836:** exact-head CI repair и закрепление protected-canon статуса 12 Energy levels + 6 Referral levels; `N1–N38` остаются неутверждёнными.
- **1837:** только первая отдельно утверждённая волна новых Q&A; protected level series сохраняются как отдельные канонические ступени.
- **1838:** утверждённая волна Browser Shop / Wallet / payments / Withdraw и сверка финансово-security формулировок.
- **1839:** утверждённая волна Profile / History / Legal.
- **1840:** утверждённая волна Skins / Ranks / Referrals.
- **1841:** утверждённая волна Tasks / Ads / FAQ search.
- **1842:** исправление подтверждённых stale RU FAQ items из аудита `1833`, волна 1, затем синхронная 16-языковая коррекция.
- **1843:** исправление оставшихся подтверждённых stale RU FAQ items из аудита `1833`, волна 2, затем синхронная 16-языковая коррекция.
- **1844:** межъязыковая semantic/structural reconciliation, волна 1; спорные Q&A автоматически не удалять.
- **1845:** межъязыковая reconciliation, волна 2; numeric/security/financial terminology parity.
- **1846:** финальный duplicate/coverage/fact audit и отдельный OWNER candidate list; спорные изменения автоматически не применять.
- **1847:** только OWNER-approved закрывающие удаления/замены и финальная FAQ reconciliation/release.

После завершения цикла `1835` остаётся `12` циклов: `1836–1847`.

### Защищённый progression invariant

Исторические серии `19-7…19-18` и `19-19…19-24` после текущего переиндексирования соответствуют `19-6…19-17` и `19-18…19-23`. Это 12 Energy-level statuses и 6 Referral-level statuses. Они не могут удаляться, сливаться или использоваться как replacement pool. Разрешено улучшать их описания, но сам набор уровней и порядок progression обязаны сохраняться во всех `16` SSOT/runtime FAQ. Authority: `docs/SSOT/faq_ssot/RU_FAQ_LEVEL_SERIES_CANON.md`.

---

# Language canon SSOT

## ТЕКУЩИЙ FAQ OWNER-REVIEW — v174.94 / цикл 1834

Канон локализации не меняется: application runtime `16/16`, FAQ runtime `16/16`, FAQ SSOT `16/16`. Cycle `1834` создаёт только OWNER-review документы и расширяет FAQ-план; FAQ Q&A bytes не меняются. Новые Q&A сначала утверждаются на русском semantic source, затем переносятся параллельно во все `15` переводных слоёв и оба FAQ-контура.

### Актуальный OWNER-план FAQ после расширения cycle 1834 — циклы 1835–1847

- **1835:** OWNER-review wave 1: согласование номеров дублей из `RU_FAQ_DUPLICATE_DELETION_APPROVAL.md` и согласование первой группы новых Q&A `N1–N20`; без неутверждённых удалений.
- **1836:** применение только OWNER-approved duplicate/replacement wave 1 синхронно во всех `16` FAQ SSOT/runtime; сохранить структурную и межъязыковую parity.
- **1837:** интеграция утверждённых P0 Q&A Browser Shop / Wallet / payments / Withdraw, первая законченная волна во всех `16` языках.
- **1838:** P0 integration wave 2 и финансово-security reconciliation FAQ по фактическим current contracts.
- **1839:** интеграция утверждённых P1 Q&A Profile / History / Legal во всех `16` языках.
- **1840:** интеграция утверждённых P1 Q&A Skins / Ranks / Referrals во всех `16` языках.
- **1841:** интеграция утверждённых P2 Q&A Tasks / Ads / FAQ search во всех `16` языках.
- **1842:** исправление подтверждённых stale RU FAQ items из аудита `1833`, волна 1, затем синхронная 16-языковая коррекция.
- **1843:** исправление оставшихся подтверждённых stale RU FAQ items из аудита `1833`, волна 2, затем синхронная 16-языковая коррекция.
- **1844:** полная межъязыковая semantic/structural reconciliation, волна 1; без автоматического удаления спорных Q&A.
- **1845:** полная межъязыковая semantic/structural reconciliation, волна 2; numeric/security/financial terminology parity.
- **1846:** финальный duplicate/coverage/fact audit и отдельный OWNER exception/candidate list; ничего спорного не удалять автоматически.
- **1847:** только OWNER-approved финальные удаления/замены и заключительная FAQ reconciliation/release.

После завершения cycle `1834` остаются `13` циклов: `1835–1847`.

---

# Language canon SSOT

## ТЕКУЩИЙ FAQ AUDIT — v174.93 / cycle 1833

Канон остаётся ровно `16` runtime-языков и `16` физических FAQ SSOT/runtime каталогов. Cycle `1833` не меняет FAQ Q&A bytes: русский semantic source прошёл полный audit `20 × 250`; найденные расхождения и дубли вынесены в OWNER-review очередь. До OWNER approval удаление/замена запрещены. После approval любое изменение русского FAQ должно быть синхронно перенесено в остальные `15` языков с параллельным контролем SSOT↔runtime.

---

## ТЕКУЩИЙ QUALITY PASS — v174.90 / cycle 1830

Языковой канон остаётся ровно `16` runtime-языков и `16` физических FAQ SSOT/runtime каталогов: `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`. Cycle `1830` не меняет keyset или registry shape; он исправляет только подтверждённые Korean FAQ формулировки при обязательной параллельной SSOT↔runtime синхронизации. Human linguistic certification всего массива `16 × 250` не заявляется.


## Purpose

This document fixes the EFHC Bot language canon and prevents drift between the
Russian semantic source, player-facing translations and Russian-first
admin/operator wording.

## Head rule — Russian semantic source

Russian is the mandatory semantic source language for EFHC Bot canon text.

All product wording, FAQ meaning, public UI translations, bot text meaning,
SSOT/NORM language decisions and translation repair tasks must start from the
verified Russian canon.

Other languages are translation layers from the verified Russian meaning. They
must not become independent sources of product meaning and must not silently
correct or replace the Russian canon.

## Source priority

When a language or FAQ meaning conflict is found, use this priority:

1. Direct user decisions in chat and `docs/GENERAL/CURRENT_DECISIONS.md`.
2. FAQ approval layer and approval records.
3. Russian FAQ / Russian SSOT, only if they do not contradict Q/A decisions.
4. English FAQ / English locale as translation layer and fallback layer.
5. Other locale files as translation QA layers.

SSOT can regress. If Russian SSOT and Q/A diverge, do not translate blindly and
do not use English as a stronger source. Create a semantic alignment audit and
mark the item as needing a canon decision.

## Player-facing surfaces

Player-facing UI is multilingual, but the source meaning is Russian.

For completed translation work:

- first verify or repair the Russian wording;
- then translate every non-Russian locale from the verified Russian meaning;
- never translate Russian from English;
- never use English as the semantic source when Russian/Q&A canon exists;
- preserve placeholders, units and protected names exactly.

Runtime fallback for missing or failed player-facing locale loading may remain
English as a technical safety fallback, because showing Russian to users of
other languages was previously identified as a user-facing regression. This
English fallback is not a semantic source and must not be described as completed
translation.

## Admin/operator surfaces

Admin/operator UI is Russian-first by default. This covers admin panel,
operator actions, admin withdrawals, bank/admin reports,
templates/admin-management, diagnostics/helper/internal admin surfaces and
admin preview/control wording.

## Trust-sensitive comments and outcomes

Trust-sensitive player comments and outcome messages must be translated from
the verified Russian meaning. If a high-quality translation is not ready,
runtime fallback may show English as a technical fallback, but the translation
work remains incomplete until the locale is repaired from Russian.

## FAQ-specific canon

FAQ work is Russian-first by meaning:

- Q/A register and direct user decisions are the first authority;
- Russian FAQ/SSOT is the normal canonical FAQ text when aligned with Q/A;
- English FAQ is a translation layer;
- all other FAQ languages must follow the Russian canonical meaning;
- if Russian FAQ and Russian SSOT agree and do not contradict Q/A, other
  languages must translate that Russian canon;
- if Russian FAQ/SSOT conflicts with Q/A, stop and create a semantic gate.

## Prohibitions

Forbidden:

- translating Russian from English;
- treating English FAQ or English locale as the stronger source when Russian
  canon/Q&A exists;
- making non-Russian locales independent product meaning sources;
- declaring fallback text to be completed translation;
- silently changing Russian FAQ/SSOT meaning because an English string differs;
- using machine translation inside an active manual localization repair range;
- disabling or hiding locales instead of repairing them;
- keeping live admin/operator UI in English after it belongs to the
  Russian-first operator contour.

## Working rule

- Semantic source = verified Russian canon.
- Admin/operator runtime = Russian-first.
- Player-facing runtime = translated locale; technical fallback may be English.
- FAQ = Q/A verified Russian meaning, then all languages translated from it.

## Manual localization completion rule

When the user assigns a full localization repair task, the assistant must
complete it manually by cycles instead of narrowing the scope.

Forbidden:

- disabling a locale instead of fixing it;
- hiding a locale from the user instead of fixing it;
- downgrading a locale to a dormant state as a substitute for repair;
- declaring fallback text to be a completed translation;
- using machine translation inside the active manual localization repair range;
- compressing many planned cycles into one false completion claim.

If the assigned range is not enough, the work continues into additional cycles.
The residual must be documented honestly, and only actually completed cycles may
be marked done.

## 16 активных runtime-языков локализации — OWNER CANON cycle 1829

Активный обязательный набор приложения и FAQ одинаков и содержит ровно `16` языков:
`ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.

- Application runtime: `16/16`; common locale keyset `1829`, placeholders и registries обязаны иметь parity.
- FAQ checked-in runtime: `16/16`; для каждого языка физический `frontend/public/faq/<lang>.json`.
- FAQ SSOT duplicate-control: `16/16`; для каждого языка физические `faq_<lang>.md` и `faq_<lang>.json`.
- Каждый FAQ catalog: ровно `20` разделов и максимум `250` Q&A; после цикла `1835` фактически `206` Q&A. Per-section структура обязана совпадать во всех `16` языках.
- Для поддерживаемого `Lang` отсутствие FAQ catalog является release defect, а не разрешённым controlled fallback. Технический fallback player-facing application text при аварийной загрузке не является переводом и не отменяет физическую полноту FAQ `16/16`.
- Обычное Portuguese слово `todo` в документации/FAQ не является implementation marker. `TODO/FIXME/TBD` policy относится только к shipping source code.
- Исторические counts `13/14` в evidence ниже сохраняются как история и не являются текущим authority.

Cycles `1830–1832` после owner-ускорения completeness используются только для quality/corrective reconciliation подтверждённых findings; полнота `16/16` уже является обязательным current state. Cycles `1833–1837` сохраняют Russian FAQ revision, добавление новых Q&A, межъязыковую сверку и только OWNER-approved удаления/замены повторов.

## Scope-protection clarification — cycle 1555

Полный runtime localization scope EFHC Bot всегда равен указанному выше набору из 16 языков. A focused smoke sample written as `RU/UK/EN` or `RU / UK / EN` is
only a minimum test sample and must never be interpreted as the complete bot
language set, a release scope reduction, or permission to skip the other thirteen
locales.

The three external EFHC Google Sites in Russian, Ukrainian and English are a
separate website/publication contour. Their language count does not define or
limit the EFHC Bot interface language canon.

The protected English visual labels in the bottom navigation are a narrow UI
exception. They do not reduce localization coverage: page copy, accessible
labels, titles, settings, FAQ and other user-facing text continue to follow the
selected one of all 16 supported runtime languages.
