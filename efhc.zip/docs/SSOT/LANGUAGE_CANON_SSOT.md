# Language canon SSOT

## Purpose

This document fixes the EFHC Bot language canon and prevents drift between the
Russian semantic source, player-facing translations and Russian-first
admin/operator wording.

## Head rule — Russian semantic source

Russian is the mandatory semantic source language for EFHC Bot canon text.

All product wording, FAQ meaning, public UI translations, bot text meaning,
SSOT/NORM language decisions and translation repair tasks must start from the
verified Russian canon.

Other languages are translation layers from the verified Russian meaning. They
must not become independent sources of product meaning and must not silently
correct or replace the Russian canon.

## Source priority

When a language or FAQ meaning conflict is found, use this priority:

1. Direct user decisions in chat and `docs/GENERAL/CURRENT_DECISIONS.md`.
2. FAQ approval layer and approval records.
3. Russian FAQ / Russian SSOT, only if they do not contradict Q/A decisions.
4. English FAQ / English locale as translation layer and fallback layer.
5. Other locale files as translation QA layers.

SSOT can regress. If Russian SSOT and Q/A diverge, do not translate blindly and
do not use English as a stronger source. Create a semantic alignment audit and
mark the item as needing a canon decision.

## Player-facing surfaces

Player-facing UI is multilingual, but the source meaning is Russian.

For completed translation work:

- first verify or repair the Russian wording;
- then translate every non-Russian locale from the verified Russian meaning;
- never translate Russian from English;
- never use English as the semantic source when Russian/Q&A canon exists;
- preserve placeholders, units and protected names exactly.

Runtime fallback for missing or failed player-facing locale loading may remain
English as a technical safety fallback, because showing Russian to users of
other languages was previously identified as a user-facing regression. This
English fallback is not a semantic source and must not be described as completed
translation.

## Admin/operator surfaces

Admin/operator UI is Russian-first by default. This covers admin panel,
operator actions, admin withdrawals, bank/admin reports,
templates/admin-management, diagnostics/helper/internal admin surfaces and
admin preview/control wording.

## Trust-sensitive comments and outcomes

Trust-sensitive player comments and outcome messages must be translated from
the verified Russian meaning. If a high-quality translation is not ready,
runtime fallback may show English as a technical fallback, but the translation
work remains incomplete until the locale is repaired from Russian.

## FAQ-specific canon

FAQ work is Russian-first by meaning:

- Q/A register and direct user decisions are the first authority;
- Russian FAQ/SSOT is the normal canonical FAQ text when aligned with Q/A;
- English FAQ is a translation layer;
- all other FAQ languages must follow the Russian canonical meaning;
- if Russian FAQ and Russian SSOT agree and do not contradict Q/A, other
  languages must translate that Russian canon;
- if Russian FAQ/SSOT conflicts with Q/A, stop and create a semantic gate.

## Prohibitions

Forbidden:

- translating Russian from English;
- treating English FAQ or English locale as the stronger source when Russian
  canon/Q&A exists;
- making non-Russian locales independent product meaning sources;
- declaring fallback text to be completed translation;
- silently changing Russian FAQ/SSOT meaning because an English string differs;
- using machine translation inside an active manual localization repair range;
- disabling or hiding locales instead of repairing them;
- keeping live admin/operator UI in English after it belongs to the
  Russian-first operator contour.

## Working rule

- Semantic source = verified Russian canon.
- Admin/operator runtime = Russian-first.
- Player-facing runtime = translated locale; technical fallback may be English.
- FAQ = Q/A verified Russian meaning, then all languages translated from it.

## Manual localization completion rule

When the user assigns a full localization repair task, the assistant must
complete it manually by cycles instead of narrowing the scope.

Forbidden:

- disabling a locale instead of fixing it;
- hiding a locale from the user instead of fixing it;
- downgrading a locale to a dormant state as a substitute for repair;
- declaring fallback text to be a completed translation;
- using machine translation inside the active manual localization repair range;
- compressing many planned cycles into one false completion claim.

If the assigned range is not enough, the work continues into additional cycles.
The residual must be documented honestly, and only actually completed cycles may
be marked done.

## 13 active localization languages

The active EFHC Bot localization set contains 13 languages:
`ru`, `en`, `uk`, `de`, `fr`, `es`, `it`, `tr`, `pl`, `da`, `hi`, `id`, `sw`.

Any bot translation or localization cycle works against the complete set by
default. English may remain runtime fallback for missing player-facing strings,
but English never replaces Russian as the semantic translation source.

## Scope-protection clarification — cycle 1555

The complete EFHC Bot runtime localization scope is always the 13-language
set above. A focused smoke sample written as `RU/UK/EN` or `RU / UK / EN` is
only a minimum test sample and must never be interpreted as the complete bot
language set, a release scope reduction, or permission to skip the other ten
locales.

The three external EFHC Google Sites in Russian, Ukrainian and English are a
separate website/publication contour. Their language count does not define or
limit the EFHC Bot interface language canon.

The protected English visual labels in the bottom navigation are a narrow UI
exception. They do not reduce localization coverage: page copy, accessible
labels, titles, settings, FAQ and other user-facing text continue to follow the
selected one of all 13 supported languages.
