# Withdraw Outcome Service SSOT

## Назначение

`withdraw outcome service` — это backend truth-layer для результата вывода.
Он собирает один готовый outcome bundle для bot/web и не позволяет
frontend становиться главным резолвером текста.

## Канонические правила

- один `resolved outcome bundle` на одну заявку вывода;
- язык пользователя берётся из профиля (`users.meta`);
- `success` и `reject` разведены по смыслу и тону;
- `reject` не имеет promo-zone;
- `success` получает promo-zone через fallback promo EFHC,
  если нет отдельной campaign-логики;
- manual override остаётся исключением и должен быть аудируемым;
- auto-translation не подменяет канонические locale templates.

## Domain tables

### `efhc_core.withdraw_outcome_events`

Хранит уже собранный truth-layer результата вывода:
- outcome kind;
- locale;
- comment template key / text / source;
- manual override and auto-translation flags;
- promo fields;
- source snapshot metadata.

### `efhc_core.outcome_fallback_promos`

Хранит fallback promo EFHC для success outcome.
Минимальный V1-домен:
- domain;
- locale;
- context;
- title/body/cta;
- active flag.

## Runtime API

Пользовательский runtime endpoint:
- `GET /api/v1/me/withdraw-outcomes/{request_id}`

Ответ должен содержать:
- `outcome_kind`
- `locale`
- `comment`
- `promo` или `null`
- `top_zone_enabled`
- `metadata`

## Lifecycle integration

`approve_withdrawal()` и `reject_withdrawal()` не просто меняют статус.
Они обязаны:
- собрать canonical outcome bundle;
- сохранить event;
- вернуть один truth result наружу.

## Запреты

Нельзя:
- делать promo при reject;
- держать независимый bot-text path и web-text path;
- делать frontend главным генератором comment block;
- превращать machine translation в основной источник канонического текста.


## work pass actualization 2026-04-16

- Admin case preview lives in `/admin/withdrawals` near the specific withdraw case.
- `/admin/templates` remains the governance/editing surface, not the main operator preview path.
- Web-Profile is the first full user-facing outcome surface.
- Telegram delivery alignment is intentionally deferred to work pass.
- Outcome tables are integrated into `0001_init.py`; any `0002+` migration remains forbidden before release.


## work pass actualization 2026-04-16

- Telegram does not render a second full outcome reality.
- Telegram delivery is a short notification plus a signed link into `Web-Profile`.
- `Web-Profile` remains the canonical full outcome view.
- Auto-translation remains allowed only for manual override comments.
- Promo text stays on prepared locale copy and is not auto-translated in this phase.
- Outcome event metadata stores Telegram delivery mark and signed profile URL when available.
- work pass re-audit confirmed success/reject separation and one-profile continuity across admin, web and Telegram delivery.
