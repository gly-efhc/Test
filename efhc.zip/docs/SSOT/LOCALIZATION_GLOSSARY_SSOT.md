# LOCALIZATION GLOSSARY SSOT

Статус: CANON / SSOT.

Документ фиксирует языковой канон EFHC Bot для пользовательского
мультиязычного контура и русского операторского контура админ-панели.

## 1. Основные термины

| Concept | RU canon | EN canon |
|---|---|---|
| EFHC | EFHC | EFHC |
| Main balance | EFHCm / основной баланс | EFHCm / main balance |
| Bonus balance | EFHCb / бонусный баланс | EFHCb / bonus balance |
| Total balance | EFHC / общий баланс | EFHC / total balance |
| Deposit / Top up | Пополнение | Top up / Deposit |
| Withdraw | Вывод | Withdraw |
| Withdrawal request | Заявка на вывод | Withdrawal request |
| Exchange | Обмен kWh на EFHC | Exchange kWh to EFHC |
| Panel | Панель | Panel |
| Panel activation | Активация панели 100 EFHC | Panel activation 100 EFHC |
| Tasks | Задания | Tasks |
| Referrals | Рефералы | Referrals |
| Ranks | Ранги | Ranks |
| Activities | Активности | Activities |
| Activity cycle | Цикл активности | Activity cycle |
| Participation condition | Условие участия | Participation condition |
| Accrual | Начисление | Accrual |
| Bonus accrual | Бонусное начисление | Bonus accrual |
| Profile | Профиль | Profile |
| Wallet | Кошелёк | Wallet |
| Available to exchange | Доступно для обмена | Available to exchange |

## 2. Разрешённые нейтральные контуры

Tasks / Задания — разрешённый рабочий контур. Задания означают работу или
действие пользователя. Начисление за выполненное задание не является
игровым или случайным контуром, если нет ставки, случайности, розыгрыша
или финансового соревнования.

Activities / Активности — разрешённый нейтральный термин EFHC Bot. Он не
означает запрещённый контур, если используется для описания обычных
действий, программ, прогресса или рабочих циклов без азартной механики.


## 2A. Игра как разрешённое описание

Игра / игровой / игровой проект / игровой процесс — разрешённые
описания EFHC Bot, если речь идёт о нормальной игровой логике продукта:
панели, генерация энергии, прогресс, задания, рефералы, ранги и развитие
аккаунта.

Эти слова не равны азартной игре. Запрещён отдельный слой: лотерея,
розыгрыш, ставка, турнирный финансовый контур, случайный выигрыш и
случайный приз.

## 3. Контекстные слова

Слово «награда» / reward больше не является канонической user-facing
формулировкой EFHC Bot. В активном пользовательском контуре его нужно
заменять на «бонус», «бонусное начисление» или «начисление» по смыслу.

Слово «приз» / prize в активном пользовательском контуре запрещено
полностью.

Победа / win разрешена только в нефинансовом, неазартном и неслучайном
смысле. В финансовых сценариях EFHC, начислений, ставок, розыгрышей и
случайной выдачи она запрещена без отдельного решения пользователя.

## 4. Panel canon

Канон:

- Активация панели 100 EFHC;
- Panel activation 100 EFHC.

Запрещены user-facing формулировки покупки панели и цены панели.

## 5. Deposit / Top up policy

RU user-facing:

- Пополнение;
- Пополнить;
- История пополнений.

EN user-facing:

- Top up for the user action;
- Deposit for the object/history where the existing flow uses that term.

В одном screen flow нельзя хаотично смешивать стиль.

## 6. Withdraw policy

RU:

- Вывод;
- Вывести;
- Заявка на вывод;
- Ожидает обработки;
- Одобрено;
- Отклонено;
- Отменено;
- Выплачено.

EN:

- Withdraw;
- Withdrawal request;
- Pending;
- Approved;
- Rejected;
- Canceled;
- Paid.

## 7. Exchange policy

RU:

- Обмен kWh на EFHC;
- Обменять kWh;
- Доступно для обмена.

EN:

- Exchange kWh to EFHC;
- Exchange kWh;
- Available to exchange.

Курс 1 kWh = 1 EFHC не должен искажаться.


## Запрет оправдательного тона

EFHC Bot может прямо описываться как игра, игровой бот и игровой проект. При этом в user-facing, FAQ, help и канонических документах запрещён оправдательный тон: продукт не должен объяснять себя как виноватый, оправдываться или занимать защитную позицию без необходимости. Нужно описывать правила, механику и канон как факты.

- Use neutral wording by default in code, aliases and user-facing copy: prefer short neutral names, avoid accidental reward/prize/winner wording unless explicitly approved by the user.
