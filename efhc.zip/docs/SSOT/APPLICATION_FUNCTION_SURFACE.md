# ТЕКУЩИЙ APPLICATION FUNCTION SURFACE — v174.92 / цикл 1832

- Cycle `1832` не изменил product function surface: exact-head `v174.91` полностью GREEN, Japanese FAQ reconciliation не потребовал text delta.

- Канон application localization: ровно `16` runtime-языков — `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`; общий locale keyset `1829` и placeholders обязаны иметь parity.
- Канон FAQ: те же `16/16` физических checked-in runtime + SSOT catalogs, каждый имеет ровно `20` разделов и максимум `250` Q&A; после цикла `1835` фактически `206`; поддерживаемый язык не использует FAQ fallback вместо каталога.
- Korean `ko` и Japanese `ja` FAQ добавлены физически. Financial/security/Shop contracts этим localization scope не изменены.
- `TODO/FIXME/TBD` unfinished-marker guard относится только к shipping source code; документы и localized FAQ, включая Portuguese `todo`, вне code scope.

> Исторические function-surface snapshots ниже являются evidence и не переопределяют этот блок.

# APPLICATION FUNCTION SURFACE CURRENT — cycle 1820 / Shop reconciliation closure

- Atomic selected VIP number reservation backend существует; selected-number checkout может переходить из preview в payment только через этот server-side contract.
- External Browser Shop TON/USDT production flow интегрирован как `PaymentIntent → immutable snapshot → chain transaction → reconciliation → PAID → ShopOrder`; settlement authority остаётся backend native-atomic comparison.
- Catalog остаётся `15 fixed EFHCm + EFHC_PACKAGE_CUSTOM`; Custom total пересчитывает backend как Admin D2 rate × whole quantity.
- Operational VIP SKU: `EFHC_VIP_NFT_ANY`; legacy payment-specific SKU — history/read compatibility only.
- Runtime locales `16`; FAQ checked-in catalogs `13` с controlled fallback.

> Historical blocks ниже являются evidence only.

# APPLICATION FUNCTION SURFACE CURRENT — cycle 1818 / Shop product contract supersession

- `EFHC_PACKAGE_CUSTOM` is now a current product capability: user enters an integer quantity from `1 EFHCm`; frontend sends `custom_efhc_amount_d8`; backend must recompute the authoritative total from the Admin D2 rate per `1 EFHCm`.
- Fixed catalog is code-governed to 15 denominations: `10,50,100,150,200,250,300,350,500,750,1000,1500,2000,2500,3000 EFHCm`, plus Custom. Admin controls prices/availability, not arbitrary replacement denominations.
- VIP operational surface is one customer-facing product with TON/USDT/EFHC methods; legacy payment-specific SKU are read/history compatibility only.
- Selected VIP number remains preview-only until atomic reservation backend exists.
- External TON/USDT production checkout is fail-closed until complete reconciliation. `ShopOrder` is created only after confirmed payment; `PaymentIntent` history remains separate.

> Historical function-surface snapshots below are evidence only.

# CURRENT APPLICATION SURFACE — v174.61 / cycle 1801

Static public HTTP surface remains `165 paths / 171 public operations / 169 schemas`; cycle 1801 changes semantics, not route count. Newly protected runtime symbols include `panels_rules`, `admin_panel_protective_service` and `checkpoint_user_energy_nocommit`. FRONTEND authority is `INTEGRATED_FRONTEND_SOURCE_v174.61_FRONTEND_v182`. Exact live/runtime proof remains the next GitHub CI.

# APPLICATION FUNCTION SURFACE CURRENT — v174.60 / цикл 1800

- Checked-in static OpenAPI: **165 paths / 171 public operations / 169 schemas**.
- Hidden operations: **8**; expected mounted total: **179**.
- New public compatibility operations required by FRONTEND_v182: `GET /admin/panels/{panel_id}`, `GET /admin/logs/export.csv`, `GET /admin/logs/export.xlsx`. Existing `/meta/health_db` is preserved.
- ORM current source: **53 tables = 46 efhc_core + 7 efhc_admin**; owner-approved `bank_metrics_snapshot` is the only schema addition in this scope.
- Frontend authority: `FRONTEND_v182` integrated source with higher financial/security CANON overlays preserved.
- Protective Panel deactivation remains fail-closed in frontend because its atomic refund/annul backend contract is not owner-approved yet.

> Historical blocks below remain evidence only.

# APPLICATION FUNCTION SURFACE CURRENT — v174.58 / цикл 1797

- Function/route/runtime surface этой docs-only итерацией не менялась: `162 paths / 168 public operations / 169 schemas`.
- Admin Panels owner Q&A зарегистрированы как authority decisions; implementation по ним этим переносом не открывается автоматически.
- FRONTEND_v168/current runtime bytes наследуются без изменения от `v174.57`.

# APPLICATION FUNCTION SURFACE CURRENT — v174.57 / цикл 1797

- Backend HTTP/OpenAPI functional surface в этом цикле не изменяется; текущая source authority остаётся `162 paths / 168 public operations / 169 schemas`.
- FRONTEND_v168 bugfix scope: TypeScript/null safety Shop и exact bigint-derived Bank visual ratio; новые routes/functions не добавляются.
- Stale frontend implementation tests синхронизированы по Test Authority; function preservation lock не ослаблен.

# APPLICATION FUNCTION SURFACE CURRENT — v174.56 / цикл 1796 owner clarifications

- Runtime/backend HTTP surface не менялась этой итерацией: `162 paths / 168 public operations / 169 schemas`; hidden `8`; mounted `176`.
- `frontend/src` и `frontend/public` не менялись: current owner-controlled frontend authority остаётся `FRONTEND_v168`, controlled set `211` paths.
- Финансовая терминология уточнена без нового runtime path: внешний EFHC deposit/withdraw и внешний Shop относятся к D2 boundary; внутренние EFHC операции остаются D8; отдельного внутреннего Shop surface не существует.
- Manual recovery capability не добавляется: используется уже существующий Admin Panel модуль `Пользователи`; новая route/function surface не создаётся.
- Test Authority deletion policy усилена: удаление stale test требует доказанного отсутствия актуального invariant после сверки с active authority.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# APPLICATION FUNCTION SURFACE CURRENT — v174.55 / цикл 1796

- Backend HTTP surface не менялась: `162 paths / 168 public operations / 169 schemas`; hidden `8`; mounted `176`.
- Owner-approved FRONTEND_v168 интегрирован в normal source: `41` patch paths; frontend authority manifest теперь контролирует `211` paths. Новый frontend source не объявляется новым backend route.
- Финансовая D2-корректировка меняет validation/execution boundary существующих Shop/Admin deposit paths, но не добавляет таблицы, migration или новый денежный asset.
- Generic external TON/USDT execution остаётся atomic `9/6`; internal EFHC остаётся D8; Test Authority / Anti-Stale Contract продолжает запрещать brittle exact-count veto для развивающейся поверхности.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# APPLICATION FUNCTION SURFACE CURRENT — v174.54 / цикл 1795

- Public/product surface не менялась: `162 paths / 168 public operations / 169 schemas`; hidden `8`; mounted `176`.
- Эта итерация исправляет только qualification/tooling/governance drift CI `87533782588`; routes/functions/pages/business capabilities не добавлялись и не удалялись.
- Frontend authority metadata синхронизирована с `v174.54`; owner-approved FRONTEND_v146 entry hashes и visual/text runtime не менялись.
- Test Authority / Anti-Stale Contract сохраняет behavioural/parity/P0 financial/security invariants и запрещает mutable exact-count veto.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.53 / цикл 1795 / CI `87522913463` + Test Authority / Anti-Stale

- GitHub CI `87522913463` проверил exact `v174.52`: SHA-256 `f06ccd41922f753debecf32196815994eb3bc845ed06d9dfa20d6a9959901de0`, checkout `c55f6b0a9478df58b6c2bc40115a282d56fd7913`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED: Ruff `4`, Mypy `1`, pytest `4 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: четыре Ruff import-order diagnostics; один Mypy return-type diagnostic в ADS scheduler adapter; один stale hardcoded Admin seam count; один реальный compatibility regression, породивший три pytest failure — `wallets_service._confirm_payment_intent()` не пропускал canonical `external_amount_atomic/external_decimals`.
- Runtime repair ограничен compatibility facade и не меняет финансовую модель: atomic TON/USDT, external EFHC D2, ledger, replay/time barrier, Shop pricing и Oracle/FX prohibition сохранены.
- OWNER DECISION: действует `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`. Тест не является SSOT; authority: OWNER DECISION → CANON/SSOT/NORM → runtime invariant → guard/test. Stale expectation обновляется или удаляется в той же итерации; правильный runtime запрещено откатывать только ради stale implementation test.
- Удалены brittle exact-count locks для mutable test/API surface; behavioural/parity/security/financial invariants сохранены. Structural anti-stale guard включён в test-suite integrity.
- Frozen `0001` не меняется; `0002+` не создаются. Последний exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.53` требует fresh exact-head GitHub CI.
- Immutable report `02371`; следующий `02372`; canonical handoff `EFHC_Bot_v174_53.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.52 / цикл 1795 / CI `87512306629` remediation

- GitHub CI `87512306629` проверил exact `v174.51`: SHA-256 `79d07b081fb73060f1ecd85b0cec61b4800912ade2f865fb7bb2968abfbb0e11`, checkout `1d022dfba994e4f09d35ffdf7f177823abb0b379`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic и npm install. RED: Ruff `6`, Mypy `7`, frontend build `1` TypeScript error, pytest `20 failed / 1722 passed / 22 skipped / 1 warning`.
- Подтверждённые причины сгруппированы: release executable-mode defect; generated frontend/admin seam drift; source lint/type diagnostics; stale qualification expectations после owner-approved Financial Audit №3; history/directory/hash manifest drift.
- Исправления не меняют Shop economics, asset-native TON/USDT settlement, external EFHC D2, withdrawal `Оплатить → Оплачено`, NFT paid gate, Admin audit, ADS reconciliation, P0 temporal barrier или canonical ledger reporting. Oracle/FX не восстанавливаются.
- Frozen `0001` не меняется; `0002+` не создаются. Public source surface остаётся `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`; новые routes в этом цикле не добавлялись.
- Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.52` требует собственного fresh exact-head GitHub CI.
- Immutable report `02370`; следующий `02371`; canonical handoff `EFHC_Bot_v174_52.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.51 / цикл 1794 / Financial Audit №3 remediation

- GitHub CI `87472108257` проверил exact `v174.50`: SHA-256 `ec735a9a631fde9c6275d62b19cdc5b15d53c0b5daca9d3fb85066699df46cc3`, checkout `22d9a9a7b95e42c4980c3019bea6fa53d99807e3`; все recorded gates GREEN, pytest `1729 passed / 22 skipped / 1 warning`. `v174.50` теперь **EXACT-HEAD GREEN**.
- Цикл 1794 исполняет direct owner-approved Financial Audit №3: FIN-01/03/04/05/06/07/08/09 подтверждены source и исправлены; FIN-10 остаётся закрытым, Oracle/FX не восстанавливаются.
- External TON/USDT отделены от EFHC D8 и фиксируются/settle в asset-native atomic units; внешний EFHC deposit/withdraw использует D2 ROUND_DOWN → internal D8.
- Withdrawal разделён на payout evidence и explicit `Оплачено`; NFT unpaid approval запрещён; Shop force-fulfill имеет required Admin audit; zero-price fail-closed; ADS reward reconciliation и canonical ledger reporting добавлены.
- P0 порядок settlement: trusted time → 180-day barrier → replay/idempotency → mutation → ledger. Frozen `0001` неизменён, `0002+` отсутствуют.
- Static public surface после двух новых explicit withdrawal actions: `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`. Live proof — следующий GitHub CI.
- Immutable report `02369`; следующий `02370`; canonical handoff `EFHC_Bot_v174_51.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.50 / цикл 1793 / CI `87405882481` qualification repair

- GitHub CI `87405882481` проверил exact `v174.49`: SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768`, checkout `b69ed98e13c7995343429df2975fe2e893ada297`. SHA payload полностью совпадает с предоставленным физическим HEAD.
- GREEN: Development HEAD SHA-256, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic upgrade, npm install и frontend build. RED только pytest: `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая первопричина — drift русскоязычной инженерной документации: active guard обнаружил `14` новых англоязычных narrative-строк (`6` в `KERNEL.md`, `8` в `START_HERE.md`). Это корректный fail-closed qualification guard, а не stale test и не runtime defect.
- Исправлены только эти `14` строк. Baseline и сам test не изменялись; backend/frontend runtime, Shop pricing, financial SSOT, schema и transaction ownership не откатывались.
- Последний подтверждённый exact-head GREEN остаётся `v174.47` / CI `87290901436`. `v174.50` GREEN не считается до fresh exact-head GitHub CI.
- Immutable report `02368`; следующий `02369`; canonical handoff `EFHC_Bot_v174_50.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.49 / цикл 1793 CI qualification repair

- Run `87290901436` полностью квалифицировал exact `v174.47`: SHA-256 `587c43298864805e7339ce6f88c8f7e284660c59a50449433a5811009b21b698`, checkout `cf3aea612813ce3cf43fe9b64d0ecfcdf35a4976`, все recorded gate exits `0`. `v174.47` = **EXACT-HEAD GREEN**.
- Более новый run `87386543243` проверил exact `v174.48`: SHA-256 `607da2ba1f2643266d2e62eb070790a1f8b3d2e5c3bbd46c31c44208ef22d826`, checkout `6760c21915d6cd605c7e461e99485b043a0fd980`; все recorded gates GREEN, кроме pytest `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — brittle Shop architecture guard: после подтверждения всех runtime invariants он требовал буквальную форму `"ручную цену"`, тогда как active NORM уже фиксирует `администратор независимо задаёт` `price_ton`/`price_usdt` и manual price runtime authority.
- Исправлен только guard: он проверяет канонический смысл, а не падежный литерал. Shop runtime/NORM, owner pricing decision, frozen `0001`, FAQ и FRONTEND_v146 не откатываются.
- Локальные project tests/build/CI не запускались. Immutable report `02367`; следующий `02368`; canonical handoff `EFHC_Bot_v174_49.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# APPLICATION FUNCTION SURFACE CURRENT — v174.48 / цикл 1793 ручные цены Shop

- Public route/function surface не изменён. Shop checkout сохраняет TON и USDT как существующие способы оплаты.
- Pricing semantics упрощены по direct owner decision: каждый товар использует только ручные `price_ton` / `price_usdt` из canonical Shop item model; автоматический FX/oracle/custom-amount pricing отсутствует.
- `custom_efhc_amount_d8` остаётся compatibility-only входным полем и не создаёт отдельную product capability.
- Payment Intent фиксирует выбранную admin price на TTL. Schema, FAQ, Exchange и visual frontend surface не меняются.

# APPLICATION FUNCTION SURFACE CURRENT — v174.44 / цикл 1792 deep backend remediation

- Public/product surface сохраняется: `160 paths / 166 operations / 169 schemas`; counts hidden/mounted/pages не меняются. Ни route, ни table, ни FAQ feature, ни visual frontend capability не добавлены и не удалены.
- Внутренние execution contracts усилены: canonical startup/lifespan, ownership DB session, scheduler cancellation, FSM atomicity, single-UoW Shop/payment, CRUD savepoints, finance SSOT, bounded queries Tasks/Referral и export lifecycle.
- Новые private helpers/adapters не являются новыми публичными product functions.
- Frozen schema и visual/UX/text authority FRONTEND_v146 остаются без изменений.

# APPLICATION FUNCTION SURFACE CURRENT — v174.43 / цикл 1792

- Public/product surface unchanged from v174.42: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`; frontend product pages `39`.
- Cycle 1792 is qualification/config repair only. No route, financial feature, Admin capability, FAQ function, page or database table is added/removed.
- Watcher P0 and Telegram webhook repaired transaction semantics remain authoritative; failing legacy tests were adapted rather than runtime rolled back.
- Frontend controlled visual/UX/text source remains FRONTEND_v146.

# APPLICATION FUNCTION SURFACE CURRENT — v174.42 / цикл 1791 re-audit repair

- Public API counts не менялись: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`.
- Telegram `/tg/webhook` сохраняет route/function capability, но transaction semantics усилены до single-root atomic dedupe + processing.
- `/start` сохраняет referral/onboarding semantics; новый transaction-neutral core не создаёт новый public route.
- Admin Shop/Withdrawals/Hub capabilities сохраняются; изменена только 5xx error redaction boundary.
- Wallet/TonConnect routes сохраняются; production proof domain теперь canonical configured-domain-first.
- Frontend product surface сохраняется; `PwaRuntimeStatus` получил listener cleanup без visual/UX/text изменения.
- Registered preservation contract остаётся minimum/fail-closed surface; новые private helpers не объявляются отдельным product API автоматически.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# APPLICATION FUNCTION SURFACE — current protected baseline / цикл 1791

## ACTIVE SNAPSHOT — v174.41 / цикл 1791 full application audit

- Exact-head GitHub CI `87088984879` полностью GREEN для `v174.40`: archive SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`; все gate exits `0`; pytest `1670 passed / 22 skipped / 1 warning`; frontend production build и PostgreSQL/Alembic PASS.
- Exact current public route surface: **160 paths / 166 operations / 169 schemas**; hidden `include_in_schema=False`: **8**; mounted total: **174**. Route source, checked-in OpenAPI и `SSOT_ROUTES.csv` совпадают по method/path/handler set.
- ORM current source: **52 tables = 45 efhc_core + 7 efhc_admin**; exact set совпадает с machine SSOT и frozen `0001_initial_release_schema.py`; `0002+` не существует и без отдельного owner decision запрещён.
- Full static functional audit cycle 1791 сохраняет все registered routes/pages/capabilities и исправляет только доказанные fail-closed defects: external watcher P0 time-before-replay ordering, readiness exact migration head `0001`, prod/stage cron strict scheduler registration, mandatory encrypted-recovery ciphertext checksum и canonical release archive filename без descriptive suffix.
- Frontend authority для target `v174.41`: `INTEGRATED_FRONTEND_SOURCE_v174.41_FRONTEND_v146`; approved frontend runtime bytes не изменяются. FAQ/locale/PWA остаются standalone checked-in release assets; packaging only verifies application bytes.
- Current product semantics: referral economy сохраняется, но referral leaderboard public routes retired; Skins — progression-only catalog/activation/switcher, а `POST /skins/buy/{skin_id}` остаётся только fail-closed compatibility surface с `409 SKIN_COMMERCE_DISABLED`, без money flow.

> Historical snapshots below are evidence only and do not override this active snapshot.


## ACTIVE SNAPSHOT — v174.38 / цикл 1789 continuation

- Supplied exact-head CI `86992003426` для `v174.37`: SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d`, checkout `7384e8284dbde416086a13bd23de7136be585681`; frontend build и PostgreSQL/Alembic GREEN, pytest qualification RED только по 3 stale/test-contract failures.
- Exact current static public route surface: **160 paths / 166 operations**; hidden `include_in_schema=False`: **8**; mounted total: **174**.
- Checked-in `backend/openapi/openapi.json`: **160 paths / 166 operations / 169 schemas**.
- `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` exact method/path/handler set совпадает с current route source: mismatch **0**.
- ORM current source: **52 tables = 45 efhc_core + 7 efhc_admin**; exact set совпадает с `SSOT_TABLES_ORM.csv`: mismatch **0**.
- Frozen `0001_initial_release_schema.py` содержит exact release table set **52/52**; migration lock остаётся active, `0002+` без direct owner decision запрещены.
- Historical route→table map CSVs имеют stale rows и являются supporting evidence, не current authority до доказательной regeneration.
- Frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.38_FRONTEND_v146`; approved controlled frontend bytes cycle 1789 continuation не менялись.

## Активный snapshot — v174.30 / qualification repair 1783–1784

Exact-head CI `86637043314` на `v174.29` подтвердил checked-in public OpenAPI `159 paths / 165 operations / 168 schemas`; hidden internal operations `8`. Qualification failure выявил только stale aggregate arithmetic в application surface contract: mounted HTTP total должен быть **173**, а не 172. Candidate `v174.30` исправляет только этот count; route set, symbols, financial semantics и hidden routes не меняются.

## ACTIVE SNAPSHOT — v174.29 / refinement циклов 1783–1784

Owner-approved Admin user operations дополнены одной read-only public operation: `GET /admin/users/{global_id}/history`. Она повторно использует canonical Unified Profile History service для выбранного Global ID; balances берутся из существующего Admin user DTO. Checked-in static OpenAPI candidate: **159 paths / 165 public operations / 168 checked-in schemas**. Скрытые operations остаются **8**, ожидаемый mounted surface — **173 operations**. Публичный `/profile/history` остаётся session-owner-bound; новый финансовый источник истины не создаётся. Локальный runtime OpenAPI export не выполнялся по project CANON; exact-head GitHub CI обязан квалифицировать candidate.

## ACTIVE SNAPSHOT — v174.28 / циклы 1783–1784

Owner-approved Admin user operations добавляют одну public operation: `POST /admin/users/{global_id}/panels/activate`. Она вызывает существующую каноническую платную активацию панели; бесплатная admin-активация запрещена. Checked-in static OpenAPI candidate: **158 paths / 164 public operations / 168 checked-in schemas**. Скрытые operations остаются **8**, ожидаемый mounted surface — **172 operations**. Локальный runtime OpenAPI export не выполнялся по project CANON; exact-head GitHub CI обязан квалифицировать candidate.

## ACTIVE SNAPSHOT — v174.26 / циклы 1778–1782

Owner-approved Unified Profile History добавляет три public operations без удаления compatibility surface: `GET /profile/history`, `GET /profile/history/export.csv`, `GET /profile/history/export.xlsx`. Checked-in static OpenAPI candidate: **157 paths / 163 public operations / 168 checked-in schemas**. Скрытые operations остаются **8**, ожидаемый mounted surface — **171 operations**. Live runtime OpenAPI export локально не выполнялся по project CANON; schema count `168` относится только к checked-in static snapshot и требует exact-head GitHub CI qualification.

## ACTIVE SNAPSHOT — v174.07 / цикл 1772

По прямому owner decision referral leaderboard public surface retired: удалены `GET /ranks/referrals/my-plus-top/me` и `GET /ranks/referrals/top/me`; referral economy сохранена. Candidate checked-in OpenAPI: **154 paths / 160 public operations / 168 schemas**. Скрытые operations остаются **8**, поэтому ожидаемый mounted surface — **168 operations**. Public `/panels/archive`, health/readiness, Browser Shop aliases и skins compatibility surfaces сохраняются. До exact-head GitHub CI эти counts имеют статус static candidate.

## Цикл 1756 квалифицирован — exact-head v173.96

- Exact-head CI `86315641419` полностью green; application surface в qualification-итерации не менялся.
- Factual floor остаётся: OpenAPI `156/162/168`, hidden `8`, mounted `170`, protected `355/66/81`, frontend pages `39`, ORM `56`, Alembic только `0001`.
- `v173.97` — traceability handoff; следующий функциональный цикл `1757`.

## Цикл 1756 — current source authority / no Offline Demo

- Offline Demo/Simulation runtime удалён по owner decision; product route/API/DB surface при этом не сокращался.
- Ads main session/provider flow сохранён в состоянии до frontend patch.
- Frontend visual/text authority теперь закреплён current integrated source hashes, а не patch payload.
- Factual API/DB floor: OpenAPI `156/162/168`, hidden `8`, mounted `170`, ORM `56`, Alembic `0001`.

## Текущая точка — кандидат v173.91 / цикл 1754 continuation — CI repair + полный change-authority audit

- Input `EFHC_Bot_v173_90.zip`: SHA-256 `7a0980b886d43a49eb77efba782bca624d88af350252669d334d783ae2c34e84`, size `12606599`, entries `4609`, ZIP integrity clean.
- Exact-head CI `86127461152`: checkout `25ddf1b8f7f56c7486dcfda9c61ee55aa67e7c8b`, CI archive size `12606599`; SHA-256 CI payload не опубликован. Failed gates: Ruff (`1 I001`) и pytest (`3 failed / 1590 passed / 22 skipped / 1 warning`).
- Исправления строго по логам и без удаления/восстановления runtime surfaces: import-order `main.py`, два exact identity line pointers, один русскоязычный historical text drift и stale Tasks guard, который теперь проверяет отсутствие использования compatibility Ads helpers активным Tasks-контуром, а не их физическое отсутствие.
- Проведён полный статический аудит `v173.85 -> v173.90`: migration `0001` неизменна; ORM `56` (`49 core + 7 admin`); OpenAPI `156/162/168`, hidden `8`, mounted `170`; protected `355/66/81`; frontend protected pages `39`; весь `frontend/src` в `v173.90` byte-identical `v173.87`; PATCH_002 EXACT_PATCH `131/131` без mismatch.
- Никаких новых delete/restore решений по результатам аудита не применено. Все спорные routes/CANON/backend/frontend/DevOps вопросы вынесены владельцу: ровно 10 вопросов находятся в immutable report 02294.
- Immutable report: `reports/numbered/reports_02294__cycle_1754_exact_head_ci_v173_90_full_change_audit.md`, SHA-256 `49d07daed4bc8b44822ce7573da5fb6c832be7eda9292a5cfac0f1041ebdf5fd`.
- Candidate `v173.91` требует exact-head GitHub CI; cycle `1755` не начинается до green qualification.

## Текущий кандидат v173.90 / цикл 1754 continuation — compatibility restore

- Exact-head CI `86118458343` для input `v173.89` имеет единственный failing gate pytest: `1 failed / 1590 passed / 22 skipped / 1 warning`; Flake8 critical/full, Ruff, Mypy, Bandit, compileall, Alembic/PostgreSQL и frontend gates успешны.
- Единственный CI failure: `frontend/src/lib/adminRouteCatalog.ts` нарушил PATCH_002 byte-exact authority; файл восстановлен до canonical SHA-256 `fa66585b1344924f3be3dd423f2ca2c7be72bf5251daed1e49b9e438e94d1507`.
- По прямому owner decision восстановлены compatibility/DevOps routes: `GET /meta/health_db` с HTTP 503 при недоступной БД, `GET /health/db-schema`, fail-closed `POST /skins/buy/{skin_id}` и четыре hidden `/hub/browser-shop-*` aliases.
- Factual surface после восстановления: `156 OpenAPI paths / 162 public operations / 168 schemas / 8 hidden / 170 mounted`; protected `355 symbols / 66 modules / 81 files`; frontend pages `39`; ORM `56`.
- Public compatibility URL нельзя удалять только по repository no-caller search: требуется direct owner decision либо production-level external-use proof.
- Telegram database-backup infrastructure остаётся удалённой по отдельному прямому owner decision; database backup — local encrypted newest-10 + owner SSH/SFTP export на ПК/смартфон.
- Candidate `v173.90` требует следующий exact-head GitHub CI; локальные application tests/guards/build не выполнялись.
- Immutable report: `reports/numbered/reports_02293__cycle_1754_exact_head_ci_v173_89_compatibility_restore.md`, SHA-256 `30d9ab73b46879c2e9e5823086f3813a34ea2ee21330d197cf96d0f7c3127ba7`.

## Текущий кандидат v173.89 / цикл 1754 continuation

- Exact-head CI `86108318744` для input `v173.88` содержит failures, поэтому functional cycle 1755 не начат; выполняется burn-down цикла 1754.
- HTTP/OpenAPI surface не меняется относительно `v173.88`: `153 paths / 159 public operations / 168 schemas / 4 hidden / 163 mounted`.
- Protected application contract остаётся `355 symbols / 66 modules / 81 required files`; frontend pages `39`; ORM tables `56`; migration head только `0001`.
- PATCH_002 exact surface `AdminSalePackagesPage.tsx` восстановлен; визуальный/text CANON не изменён.
- Candidate `v173.89` требует следующий exact-head GitHub CI; локальные application tests/guards/build не выполнялись.

## Current candidate v173.88 / cycle 1754

- Exact-head GitHub CI для input `v173.87` полностью green; functional cycle 1754 выполняет owner-approved route cleanup и DevOps hardening.
- Protected application contract остаётся `355 symbols / 66 modules / 81 required files`; удаляемые handlers/compatibility facades не входят в protected symbol floor.
- Checked-in OpenAPI factual surface: `153 paths / 159 public operations / 168 schemas`; mounted HTTP operations `163` = `159` OpenAPI + `4` hidden internal operations.
- Удалены 7 repository-dead/retired HTTP surfaces: 4 hidden `/hub/browser-shop-*` aliases, `POST /skins/buy/{skin_id}`, `GET /health/db-schema`, `GET /meta/health_db`. Canonical replacements остаются `/shopfront/*`, progression skin switcher и `/api/health/db`.
- Frontend pages остаются `39`; ORM tables `56`; PostgreSQL schema/migration surface не меняется.
- Backup database transport через Telegram удалён owner decision; DevOps backup authority — local encrypted newest-10 + owner SSH/SFTP export на ПК/смартфон.
- Candidate `v173.88` требует следующий exact-head GitHub CI; локальные application tests/guards/build не выполнялись.

## Current candidate v173.82 / cycle 1751

- Unified Deep Audit 7 закрывает семь подтверждённых Energy/ADS/Tasks/Referrals/Ranks/Skins defects без удаления registered routes/functions.
- Protected application contract остаётся `355 symbols / 66 modules / 81 required files`.
- Checked-in OpenAPI остаётся `156 paths / 162 public operations / 168 schemas`; mounted HTTP operations `170`.
- Frontend pages `39`; ORM tables `56` после добавления `efhc_core.ad_provider_claims`.
- `/skins/buy/{skin_id}` сохраняется compatibility route, но current runtime fail-closed возвращает `409 SKIN_COMMERCE_DISABLED` и не создаёт money flow.
- Ranks route paths сохраняются, а `/ranks/top/me` и `/ranks/referrals/top/me` получают nonvisual `around_me` context query для backend-authoritative find-me.
- Test inventory после Audit-7 guard: `271` architecture / `451` Python files.
- Candidate `v173.82` требует exact-head GitHub CI; локальные application tests/guards/build не выполнялись.

## Current candidate v173.81 / cycle 1750

- Audit 6 изменяет auth/session security semantics без удаления registered compatibility surface.
- Protected application contract остаётся `355 symbols / 66 modules / 81 required files`.
- Checked-in OpenAPI остаётся `156 paths / 162 public operations / 168 schemas`; mounted HTTP operations `170`.
- Frontend pages `39`; ORM tables `55`.
- Новый `_ton_challenge_client_fingerprint` является private transport-security helper и не расширяет public/protected function contract.
- Test inventory после нового CI-only Audit-6 guard: `270` architecture / `450` Python files.
- Candidate `v173.81` локально не квалифицировался; требуется exact-head GitHub CI.

## Exact-head CI guard/document repair — кандидат v173.79 / цикл 1749

- Registered protected function/route/page floor не сокращается и не расширяется: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted operations `170`, ORM `55`, schemas `168`.
- Runtime/backend/frontend/API/schema/ORM в цикле 1749 не изменялись.
- Единственный code change — форматирование CI-only Audit-5 architecture guard по подтверждённой Ruff `SIM102`; guard assertions и protected runtime semantics не изменены.
- Единственный CANON change — удаление служебного numbered work-pass label из heading без изменения VIP/NFT нормы.
- Следующий verifier — exact-head GitHub CI `v173.79`.

## Audit 5/10 VIP/NFT semantics — кандидат v173.78 / цикл 1748

- Registered protected function/route/page floor не сокращается: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted operations `170`, ORM `55`, schemas `168`.
- Новых HTTP routes и OpenAPI schemas нет. Изменяется только semantics существующего VIP/NFT checker, wallet deactivation и scheduler tick.
- `NftCheckService.check_user_vip` агрегирует все active verified TON wallets одного `global_id`; compatibility `get_wallet_for_user` сохраняется и возвращает первый canonical wallet source.
- Provider `verified=true` становится обязательной частью collection-membership proof; cache без verification state не является authority.
- Добавлен один CI-only architecture guard; следующий verifier — exact-head GitHub CI `v173.78`.

## Security hardening + exact-head CI burn-down — кандидат v173.77 / цикл 1747

- Protected function/route/page floor не сокращается: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted operations `170`, ORM `55`, schemas `168`.
- HTTP route count не меняется. Monetag/AdMaven существующие postback routes получают независимый provider secret `efhc_token`; signed correlation остаётся второй проверкой, но больше не является самостоятельным authority.
- Browser/client ad completion не является reward authority без независимой provider-side проверки. `builtin_timer` сохраняется только как test-mode diagnostic contour и не может начислять EFHCb.
- Browser Shop меняется только невизуально: reusable bearer удаляется из URL/history после первичного handoff и не переносится в checkout return URL; visual/text PATCH_002 не меняется.
- Следующий verifier — exact-head GitHub CI кандидата `v173.77`; локальные tests/guards/build не выполнялись.

## Audit 4/10 security/withdraw hardening — кандидат v173.76 / цикл 1746

- Protected function/route/page floor не сокращается: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted operations `170`, ORM `55`, schemas `168`.
- Existing wallet/withdraw/Admin routes меняют только security/transaction semantics; новый HTTP route не добавляется.
- Checked-in OpenAPI сохраняет `156/162/168`, но TonConnect request schemas теперь fail-closed требуют `state_init`, `public_key`, `network`.
- Добавлен один CI-only architecture guard; frontend visual/text authority не изменена.

## Audit 3/10 financial surface — кандидат v173.73 / цикл 1744

- Registered fail-closed floor: **355 critical Python symbols / 66 modules / 81 required files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**.
- Mounted HTTP surface: **170 operations** = **162 OpenAPI operations / 156 paths** + **8 `include_in_schema=False` internal/compatibility operations**.
- Новый public surface только один: `POST /admin/bank/transfers/{transfer_log_id}/rollback`; он выводит уже существующую canonical Bank reversal capability после source-row/double-reversal hardening. Protected facade дополнен `AdminService.rollback_bank_user_tx`.
- Shop/PaymentIntent fixes изменяют financial semantics существующих operations, но не удаляют routes/functions. `ShopOrderExternalIn.quantity` остаётся public compatibility field с canonical constraint `1`.
- ORM table count остаётся **55**; `shop_orders` получает owner-scoped unique idempotency constraint внутри единственного pre-release `0001`. Checked-in OpenAPI schema inventory остаётся **168**.
- `/admin/sale-packages` mutating routes сохраняются в API/function union, но до переноса release SSOT fail-closed возвращают `409 SALE_PACKAGES_NOT_RELEASE_SSOT`.
- Frontend visual/text authority PATCH_002 не изменяется; новый exact-head GitHub CI обязателен.

## Exact-head CI continuation — кандидат v173.71 / цикл 1743

- Exact-head CI `85540647405` проверил входной `v173.70`; runtime surface не расширяется и не сокращается.
- Registered fail-closed floor остаётся **354 critical Python symbols / 66 modules / 81 required files / 155 OpenAPI paths / 161 operations / 39 frontend pages**.
- Emergency deposit сохраняет тот же route, но idempotency authority явно классифицирован как external immutable `tx_hash`; отдельный HTTP `Idempotency-Key` dependency удалён.
- Panels service сохраняет `archived_at` semantics; SQL owner predicate теперь представлен двумя фиксированными parameterized statements без динамической конкатенации.
- Frontend PATCH_002 и OpenAPI route/schema counts не изменены.
- Следующий verifier — exact-head GitHub CI кандидата `v173.71`.

## Financial settlement hardening — кандидат v173.69 / цикл 1742

- Registered fail-closed floor: **342 critical Python symbols / 63 modules / 78 required files / 155 OpenAPI paths / 161 operations / 39 frontend pages**.
- Новая защищённая capability: `shop_payment_tx_hash_lock_service.TxHashSettlementClaim` + `claim_tx_hash_settlement` как общий immutable settlement claim для одной on-chain `tx_hash`; старый `acquire_tx_hash_lock` сохранён compatibility facade для PaymentIntent.
- HTTP/OpenAPI/frontend page surface в цикле 1742 не изменяется; новая route не создаётся.
- ORM table count остаётся **55**; `tx_hash_locks.intent_id` становится nullable внутри существующего pre-release `0001`, чтобы direct watcher/Admin recovery claims могли использовать тот же глобальный lock без фиктивного PaymentIntent.
- Legacy SKU/BUY MEMO parser сохраняется compatibility-only; пользовательский `qty` не является финансовым authority.
- PaymentIntent settlement: только live `PENDING`; exact same confirmed `tx_hash` — idempotent read-through; expired или другой tx fail-closed.
- Новый exact-head GitHub CI обязателен; локальные application tests/guards/build/CI не выполнялись.

## Полный function / route / table audit — кандидат v173.67 / цикл 1741

- Exact-head GitHub CI `85400569189` квалифицировал входной `v173.66`: все canonical gates `exit=0`; pytest `1534 passed / 22 skipped / 1 warning`.
- Static source audit: **345** production Python files, **1815** function definitions; AST parse errors `0`. Registered fail-closed floor: **339/339 symbols**, **62 modules**, **77/77 required files**, missing `0`.
- HTTP: **169 mounted FastAPI operations** = **161 OpenAPI operations / 155 paths** + **8 `include_in_schema=False` internal/compatibility operations**. OpenAPI↔`SSOT_ROUTES.csv` exact mismatch `0`.
- Hidden operations защищены отдельно через `SSOT_INTERNAL_ROUTES.csv`: 4 Browser-Shop compatibility aliases + metrics/deployment + cron/webhook.
- Frontend registered pages: **39/39**; visual/text authority PATCH_002 не менялся.
- ORM: **55/55 tables** = `48 efhc_core + 7 efhc_admin`; source↔ORM SSOT mismatch `0`; ORM↔migration SSOT mismatch `0`. Exact-head Alembic CI: `metadata_tables=55`, `tables_in_schemas=56`, `0001: ok`.
- Подробный machine inventory: `docs/audits/APPLICATION_FUNCTION_ROUTE_TABLE_AUDIT_1741.json`.
- Runtime code не изменяется; исправлен только подтверждённый documentation/guard drift table-count/internal-route inventory.

## Exact-head CI guard-only repair — кандидат v173.66 / цикл 1740

- Exact-head CI `85386896242` на входном `v173.65`: все canonical gates кроме pytest `exit=0`; pytest `1 failed / 1533 passed / 22 skipped / 1 warning`.
- Единственный failure — Russian Engineering NORM в имени одной test-function. Production/function surface не изменялась.
- Current fail-closed floor остаётся **339 critical Python symbols / 62 modules / 77 required files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; checked-in OpenAPI **168 schemas**.
- PATCH_002 visual/text authority, ADS mediation, identity/economy/security contracts сохранены без изменений.
- Локальные application tests/build/CI не выполнялись; exact-head GitHub CI для `v173.66` обязателен.

## ADS mediation function-surface — кандидат v173.65 / цикл 1739

- Current registered fail-closed floor: **339 critical Python symbols / 62 modules / 77 required files / 155 OpenAPI paths / 161 operations / 39 frontend pages**.
- Checked-in OpenAPI schema inventory: **168 schemas**; Admin surface: **74 paths / 80 operations**.
- ADS mediation adds server session/fallback/postback/Admin/analytics capabilities without deleting historical `/ads/slot`, `/ads/callback/{provider}`, `efhc_core.ads` or frontend PATCH_002 visual/text authority.
- Canonical ADS implementation: `docs/backend/ADS_MEDIATION_CANON.md`; function-specific SDK/API remains adapter-isolated from Tasks.
- Frontend authority manifest registers only owner-approved ADS changes plus existing nonvisual/function-union exceptions; old Bot frontend remains forbidden as visual donor.
- Local application tests/build/CI were not run. Exact-head GitHub CI for `v173.65` is required.

---

## Frontend authority corrective merge — кандидат v173.60 / цикл 1734

- Registered function surface не сокращается: **312 symbols / 58 modules / 68 required files / 138 OpenAPI paths / 143 operations / 39 frontend pages**.
- PATCH_002 — visual/text authority; cycle-1733 old-visual restoration interpretation superseded. Function preservation означает сохранение capability, а не сохранение старой presentation-реализации.
- Machine policy: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; stale visual guards мигрируются, contracts/security остаются fail-closed.
- Новый exact-head GitHub CI обязателен; локальные application tests/build не выполнялись.

## Exact-head CI regression repair — кандидат v173.59 / цикл 1733

- CI `85239758056` на входном `v173.58` подтвердил frontend regression после overlay: protected Hub/Profile/Header/Admin/provider surfaces и ряд architecture guards были нарушены, при этом общий registered function floor не сокращался.
- Cycle 1733 восстанавливает только эти подтверждённые protection invariants и исправляет exact Ruff/Mypy/TypeScript failures; новые bridge API и утверждённые Withdraw/Sale Packages contracts цикла 1732 сохраняются.
- Current fail-closed floor остаётся **312 symbols / 58 modules / 68 required files / 138 OpenAPI paths / 143 operations / 39 frontend pages**.
- Новый candidate `v173.59` не проверялся локальными application tests/guards/build и требует exact-head GitHub CI пользователя.

## Внедрение frontend patch — кандидат v173.58 / цикл 1732

- Входной HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002`: 176 overlay files (`131 modify + 45 add`); все source SHA manifest точно совпали с входным HEAD, target SHA patch payload совпали с manifest.
- Production overlay: 162 frontend files + 14 backend bridge/OpenAPI files; standalone/demo/simulation runtime отсутствует.
- Добавлены frontend bridge contracts `GET /auth/profile-photos` и `GET /tasks/earnings/me`; supplied live OpenAPI также вернул уже существующий `GET /meta/health_db`, ранее отсутствовавший в static snapshot.
- Canonical wallet boundary адаптирован поверх patch: selected verified wallet lookup принимает строковый 10-digit `global_id` и конвертирует его только через `_global_id_db`; произвольный `int(global_id)` в новом wallet service seam не сохранён.
- Новый Admin helper `/admin/api-workbench` сохранён как диагностическая capability, но его видимый launcher/title humanized как «Проверка функций»; raw technical contract остаётся внутри специализированной диагностики, не как язык основных Admin-разделов.
- Current protected floor после синхронизации: **312 symbols / 58 modules / 68 required files**, OpenAPI **138 paths / 143 operations**, frontend pages **39**.
- Локальные tests/guards/lint/type/build/Alembic/CI не запускались. Кандидат `v173.58` требует exact-head GitHub CI.

## Итоговая блокировка backend/frontend audit — кандидат v173.57 / цикл 1731

- Exact-head CI `85157912581` на `v173.56`: все canonical gates `exit=0`; pytest `1502 passed / 22 skipped / 1 warning`.
- Статическая сверка checked-in contract/source: **312 symbols / 58 modules / 68 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**; отсутствующих зарегистрированных элементов не найдено.
- `backend/openapi/openapi_manifest.json` синхронизирован с фактическим `backend/openapi/openapi.json`: `135 paths / 140 operations / 154 schemas`.
- Main HTTP/Admin operation inventory и frontend page inventory ниже синхронизированы с текущими checked-in artifacts.
- Runtime/backend/frontend production code не менялся; unresolved identity/Admin UX вопросы переданы в handoff backlog.
- `v173.57` требует следующего exact-head GitHub CI.

## Текущая блокировка exact-head qualification — кандидат v173.56 / цикл 1730 continuation

- CI `85153784574` на exact-size `v173.55` не подтвердил backend/frontend function-surface regression; единственный failure — SHA drift cycle-range manifest.
- Protected floor остаётся без изменений: **312 symbols / 58 modules / 68 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**.
- Runtime/function surface в этом patch не меняется; compatibility и решения 1719–1729 сохраняются.
- Следующий exact-head GitHub CI обязателен; цикл 1731 начинается только после закрытия текущего CI burn-down.

## Текущая блокировка exact-head qualification — кандидат v173.55 / цикл 1730

- CI `85145865998` не выявил подтверждённого удаления/изменения публичной function surface; исправления цикла 1730 ограничены typing/test/current-state drift.
- Protected floor остаётся без изменений: **312 symbols / 58 modules / 68 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**.
- Compatibility и решения 1719–1729 сохраняются; `no caller != delete proof` остаётся действующим правилом.
- Следующий exact-head GitHub CI обязателен; локальная qualification не выполнялась.

## Текущая блокировка Consolidation 1719–1728 — кандидат v173.54 / цикл 1729

- Десять решений 1719–1728 сведены в `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Статусы решений: `KEEP / CONNECT_UI / RESTORE_FACADE / REPLACE / REMOVE_APPROVED`.
- Удалены только 7 private transitional aliases из `sql_aliases_core`; strict canonical schemas/tables остаются.
- ENV/provider/Pydantic/TON historical aliases и явно утверждённые compatibility facades не удалялись.
- Function floor: **312 symbols / 58 modules / 68 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**.
- Следующий exact-head GitHub CI обязателен; локальная qualification не выполнялась.

## Текущая блокировка Runtime Compatibility — кандидат v173.53 / цикл 1728

- `create_app`, DB getter facades, `d8` и `order_models.ShopOrder` являются бессрочными compatibility contracts; отсутствие caller не разрешает delete.
- `app.bot.states` является официальным стабильным public FSM facade.
- Historical Admin/scheduler/task-maintenance seams сохраняются тонкими и не становятся вторым runtime/canon.
- `RBAC.is_superadmin` — helper уже разрешённой роли, а не отдельный auth-path.
- Active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: **312 symbols / 58 modules / 67 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**.
- Следующий exact-head GitHub CI обязателен; локальная qualification не выполнялась.

## Текущая блокировка Bonus / Withdraw / manual credits — кандидат v173.51

- Завершён цикл 1726: ручные MAIN/BONUS операции сведены к единому `BankService.manual_bank_user_transfer`; `/admin/transfer` является тонким Admin API.
- Compatibility `credit_bonus_efhc`, `credit_regular_efhc`, `adjust_user_balance_via_bank` сохранены и делегируют тому же BankService.
- Созданы `GET /admin/bonuses` и `/admin/bonuses`: активная история из заданий, рефералов и банковских ручных бонусов; новый денежный write-route не создан.
- `efhc_admin.bonus_awards` остаётся dead/legacy compatibility boundary и не используется новым UI.
- Bonus и Withdraw разделены: EFHCb не выводится; Withdraw работает только с EFHCm. `admin_mark_withdraw_paid` — `REPLACED_BY_CANON`, сохранён для compatibility с комментарием причины.
- Видимый Withdraw/User/Bonus UI приведён к человекопонятному Admin language canon.
- Function floor: **305 symbols / 56 modules / 63 required files**, OpenAPI **135 paths / 140 operations**, frontend pages **38**.
- Следующий exact-head GitHub CI обязателен; локальная qualification не выполнялась.

## Текущая блокировка Admin VIP / NFT — кандидат v173.50

- Завершён цикл 1725: ручное назначение VIP заменено канонической проверкой фактического владения NFT.
- Admin NFT остаётся отдельным fail-closed credential через `TON_ADMIN_NFT_IDS`; business actor — только `global_id`.
- Historical `submit_manual_vip_nft_claim(tg_id, ...)` имеет статус `REPLACED_BY_CANON / DO_NOT_RESTORE`.
- Оплаченный `ShopOrder(type=NFT, status=PAID_PENDING_MANUAL)` является единственной заявкой на ручную выдачу VIP NFT; дублирующая заявка не создаётся.
- `/admin/shop` получил понятный модуль «Заявки на выдачу VIP NFT»: ожидание, подтверждение фактической выдачи, отказ с обязательной причиной и аудит решения.
- `/admin/users` получил единый блок «Проверка VIP и NFT»: проверка выбранного пользователя и всех пользователей через единый NFT service.
- Function floor: **299 symbols / 54 modules / 59 required files**, OpenAPI **134 paths / 139 operations**.
- Следующий exact-head GitHub CI обязателен; локальная qualification не выполнялась.

## Current financial/status utility lock — v173.48 candidate

- `/admin/reports/bank` protects BANK_EFHC-only amount and event counters plus typed Bank Policy.
- `/admin/reports/withdrawals` protects DB-wide TOTAL/PENDING/PAID/REJECTED/CANCELED counters.
- `/admin/withdrawals` consumes the global status snapshot while preserving the operator list separately.
- Historical `efhc_transfers_recent_total`, `get_admin_bank_config`, `withdraw_status_counters` are REPLACED and must not be restored as legacy facades.
- Function floor: **283 symbols / 51 modules / 49 required files**, OpenAPI **128 paths / 133 operations**.

## Cycle 1722 continuation — Referrals/Ranks frontend integration lock — v173.47 candidate

- Промежуточный статус `DEFERRED_TO_FRONTEND_MERGE` снят прямым новым ТЗ пользователя в том же cycle 1722.
- `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` являются `UI_CONNECTED` и защищённой frontend capability.
- `/ranks/referrals/my-plus-top/me` и `/ranks/referrals/top/me` используются mode `referrals`; kWh routes сохраняются отдельно.
- `RankMode` входит в React Query keys; смешивание kWh/referral cache запрещено.
- `global_id` остаётся внутренним owner/key и запрещён как публичное display name.
- Referral data/link/bonus asset/level steps берутся только из backend; offline/demo/mock runtime запрещён.
- Function floor: **280 symbols / 50 modules / 48 required files**, OpenAPI **128 paths / 133 operations**.
- Active frontend canon: `docs/frontend/REFERRALS_RANKS_FRONTEND_CANON.md`.

## Cycle 1722 — Referral/Ranks frontend merge defer lock — v173.46 candidate

- Backend referral/ranking capabilities сохраняются без изменения semantics.
- `/ranks/referrals/my-plus-top/me` и `/ranks/referrals/top/me` являются protected backend contracts.
- Пользователь подтвердил, что полный Ranks/Referrals frontend существует отдельно и будет объединён позднее.
- Статус отсутствующей current integration: `DEFERRED_TO_FRONTEND_MERGE`, а не `RECOVERY_CANDIDATE` и не `REMOVAL_CANDIDATE`.
- Отсутствие current frontend caller не разрешает cleanup.
- Function floor остаётся **280 symbols / 50 modules / 48 required files**, OpenAPI **128 paths / 133 operations**.

## Этап Shop Management — единый Shop lock — v173.45 candidate

- Admin Shop Editor, внешний `/browser-shop`, `/shopfront/profile`, каталог и Order Control являются одной защищённой capability.
- Физическая Shop item model: `sku/title/description/quantity_efhc/is_active/extra JSONB`; новые карточки расширяются через canonical `extra`, а не выдуманные DB columns.
- `/admin/shop/items/upsert` — основной редактор; `/items/set-price` сохраняется как compatibility API через ту же model/history.
- `GET /admin/shop/orders/status-counters` восстанавливает глобальные status counters по всей таблице.
- `admin_force_fulfill_order` восстановлен как recovery action на `global_id`; EFHC credit — только через BANK/idempotency.
- `/shopfront/profile` переведён из integration candidate в `UI_CONNECTED_EXTERNAL_SHOP` и используется Browser Shop после signed handoff.
- Physical delete карточки fail-closed блокируется при order history; история карточки сохраняется.
- Shop owner только `global_id`; возврат `tg_id` ownership запрещён.
- Canon: `docs/admin/ADMIN_SHOP_MANAGEMENT_CANON.md`.
- Новый function floor: **280 symbols / 50 modules / 48 required files**, OpenAPI **128 paths / 133 operations**; локально не запускался.

## Cycle 1720 — Admin Tasks Editor preservation lock

- Полный Admin Tasks CRUD подключён к `/admin/tasks`; detail-route больше не API-only.
- `TaskDeleteBlockedError` и `TaskCodeChangeBlockedError` защищают task history fail-closed.
- submissions/moderation и bank/idempotency path сохраняются.
- `tasks_autorestart.run_once` — canonical task lock maintenance; `check_ton_inbox.run_tick` — отдельный TON watcher/reconciliation contour.
- `/admin/ads` — отдельная provider-management/status surface; `admin_ads_service.list_providers` защищён.
- Canon: `docs/admin/ADMIN_TASKS_EDITOR_CANON.md`.
- Новый control manifest расширен до **265 symbols / 48 modules / 19 required files**; локально не запускался.


## Cycle 1719 — Admin Reports/Observability decision lock

- `admin_observability_events` сохраняется как `STUBBED_DUPLICATE`: route существует как compatibility boundary, но DB-read отключён; replacement — `/admin/logs/transfers`.
- `reports_users` — `ACTIVE/UI_CONNECTED`; panels ownership join только `global_id`.
- `reports_bank` — `ACTIVE/UI_CONNECTED`; единственный bank balance — `EFHC_MAIN`, transfer aggregation только `system_entity=BANK_EFHC`.
- `reports_bank` также защищает Bank Policy и bank-side event counters (`credit/debit/total`) без возврата `efhc_transfers_recent_total`/`get_admin_bank_config`.
- `reports_panels`, `reports_withdrawals`, `reports_deposits` — `ACTIVE/UI_CONNECTED`.
- `reports_withdrawals` содержит DB-wide `TOTAL/PENDING/PAID/REJECTED/CANCELED`; `/admin/withdrawals` использует их для глобального status dashboard.
- `frontend/src/components/admin/AdminDomainReportsDashboardRuntime.tsx` соединяет пять domain report routes со страницей `/admin/reports`.
- `AdminObservabilityTimeseriesDashboardRuntime` подключён к `/admin/reports` и остаётся real-timeseries read-only surface.
- Release scripts являются protected operational surface; cleanup или изменение executable mode без прямого ТЗ/CI evidence запрещены.

<!-- EFHC_APPLICATION_FUNCTION_SURFACE_V1: ACTIVE -->
# APPLICATION FUNCTION SURFACE — current protected baseline / цикл 1738

## 1. Назначение

Этот документ — active SSOT каталога функций приложения после завершённого `global_id` cutover и продолженного аудита сохранности функций. Он фиксирует **application capabilities**, public/operational entrypoints, HTTP surface, frontend pages, background/Admin boundaries и восстановленные compatibility entrypoints. Private helpers не считаются отдельными пользовательскими функциями и не дают основания удалять public/operational surface.

Контрольный контракт: `contracts/application_function_surface_v1.json`.
Контрольный CI-test: `tests/architecture/test_application_function_surface_manifest.py` — расширен в цикле 1717 и **локально не запускался**.

Зафиксированная surface текущего HEAD:

- exported OpenAPI paths: **155**;
- exported HTTP operations: **161**;
- frontend page files: **39**;
- critical registered Python module symbols: **339** в **62** модулях;
- обязательные protected files: **77**.

Правило сохранности: отсутствие caller, UI-кнопки или прямого импорта **не означает**, что capability можно удалить. Для удаления требуется отдельное решение пользователя и доказательство по Fail-Closed Delete Policy.

## 2. Identity / authentication / session

- Provider subjects: Telegram `tg_id`, TON `ton_wallet_id`, Google `google_id`, Apple `apple_id`, Facebook `fb_id`, Discord `discord_id`, GitHub `github_id`.
- Canonical chain: `provider + subject -> global_id -> business runtime`.
- Server-side session owns application identity by `global_id`.
- Telegram and TON login/proof routes remain provider boundaries; business ownership does not return to `tg_id`/wallet address.
- Logout/session/auth challenge/proof surfaces are preserved in OpenAPI.

## 3. Admin access and Admin capabilities

- Normal Admin: server-side session -> `global_id` -> Admin list/RBAC.
- Admin NFT: server-side session -> `global_id` -> verified TON wallet -> collection check -> exact item address from `TON_ADMIN_NFT_IDS` -> full Admin access.
- Admin actor remains `global_id`; `ton_wallet_id` is not business owner.
- Admin functional domains: access, users, BANK, bonuses, withdrawals, shop, tasks, panels, referrals, ADS, TON/deposits, reports, templates, sale packages, hub, observability, logs.
- Existing Admin API is preserved even when no frontend caller is currently found.

## 3.1. VIP / NFT management — цикл 1725

- VIP пользователя является вычисляемым состоянием по фактическому владению NFT на подтверждённом TON-кошельке; ручная запись `users.is_vip` из Admin UI запрещена.
- `POST /admin/users/{global_id}/vip/check` и `POST /admin/users/vip/check-all` используют единый canonical NFT checker.
- `PATCH /admin/users/{global_id}/vip` сохранён только как compatibility boundary и также выполняет фактическую проверку вместо ручного переключения.
- Admin NFT credential не смешивается с VIP: точный item из `TON_ADMIN_NFT_IDS` даёт отдельный путь Admin-доступа, actor после допуска остаётся `global_id`.
- `GET /admin/shop/nft-requests` и `POST /admin/shop/nft-requests/{order_id}/decision` формируют операторский workflow ручной выдачи оплаченных внешних VIP NFT.
- Historical `submit_manual_vip_nft_claim(tg_id, ...)` — `REPLACED_BY_CANON / DO_NOT_RESTORE`; второй ShopOrder-заявка запрещена.
- Canon: `docs/admin/ADMIN_VIP_NFT_MANAGEMENT_CANON.md`.

## 4. BANK / economy / accounting

- System bank entity: `BANK_EFHC`, no fake user/global_id/tg_id.
- Canonical bank balance: `efhc_core.bank_balance`, key `EFHC_MAIN`.
- User credit: `BANK_EFHC -> USER`; system debit: `USER -> BANK_EFHC`.
- Reversal is compensating operation; original operation is immutable.
- P2P prohibited. Mint/Burn remain emergency Admin mechanisms.
- Exchange, panels, withdrawals, tasks/ADS/referrals and shop economic surfaces remain separate domain capabilities.

## 5. Пользовательские домены

- **Energy/Profile:** account/session snapshot, balance/history, panel summary, wallet bindings, profile bootstrap.
- **Panels:** activation, active list, archive, 180-day lifetime, max active limit by canon.
- **Exchange:** preview, convert `1 kWh -> 1 EFHCm`, history.
- **Withdraw:** request/list/detail/cancel for user; Admin approve/reject/outcome/repair.
- **Referrals:** counters, active/inactive lists, stats, deep-link/referral registration and bank-backed rewards.
- **Ranks:** overall leaderboard + my-plus-top; referral leaderboard public routes retired by owner decision, referral economy remains active.
- **Tasks/ADS:** task catalog/claim/my tasks; canonical server-owned AdManager sessions/fallback/provider postbacks/verified reward; Admin moderation, provider management, dashboard и Revenue Optimizer. Legacy slot/callback остаются compatibility-only.
- **Shop/Shopfront:** catalog, EFHC purchase, external order, user orders, browser shop access/bootstrap/catalog/payment intent/status/profile; Admin catalog/order management.
- **Payments/TON:** payment intents, TON proof, deposit/reconciliation/watcher surfaces, unmatched/manual-state handling.
- **NFT/VIP:** VIP ownership/status check; Admin NFT access uses exact item IDs from ENV through the NFT/VIP contour.
- **Skins:** progression-only catalog, activate and switcher; `POST /skins/buy/{skin_id}` is compatibility-only and fail-closed with `409 SKIN_COMMERCE_DISABLED`, without a money flow.
- **Health/operations:** health/readiness/db/db-schema/runtime and Admin observability endpoints.

### 5.1. ADS mediation — циклы 1735–1737

- Active canon: `docs/backend/ADS_MEDIATION_CANON.md`.
- `backend/app/services/ads/ad_manager.py` — единственный backend mediation/reward verifier; `frontend/src/lib/ads/AdManager.ts` — единственный frontend facade.
- Provider registry/adapters: AdsGram, Monetag, RichAds, AdMaven, Adexium; TADS/MyBid зарегистрированы fail-closed до подтверждённого cabinet reward contract; `builtin_timer` — только DEV/CI/diagnostics.
- `Admin DB override → ENV fallback`; secrets шифруются и не возвращаются frontend.
- `ad_sessions` фиксирует `global_id`, primary/actual provider и immutable `reward_snapshot_efhcb`; provider не определяет EFHCb.
- UTC daily limit использует concurrency-safe `global_id + task_code + date`; default `10`, если Task ADS config не задаёт другое значение.
- Append-only `ad_events` сохраняет provider-attempt telemetry; fallback A→B не скрывает no-fill/error A.
- Reward идёт только через существующий `tasks_service`/`TaskCompleteLock`; второго balance/bonus механизма нет.
- Admin ADS/Tasks visible additions прямо разрешены owner ТЗ 1735–1737; пользовательский Tasks layout остаётся PATCH_002 visual authority.

## 6. Background / scheduler / operational entrypoints

- `SchedulerService.run_single_tick` is canonical scheduler execution surface.
- Historical scheduler entrypoints are retained through safe compatibility facades (`tick`, `TickContext`, `SchedulerError`, `JobTimeout`, maintenance `run_once`).
- Background identity boundaries keep canonical `global_id` as owner and resolve Telegram delivery subject only when delivery is required.

## 7. Восстановленные safe compatibility surfaces

### 7.1. Восстановления предыдущего этапа

| Файл | Surface | Статус / назначение |
|---|---|---|
| `backend/app/init.py` | `create_app` | `RESTORED_SAFE_COMPAT` — startup facade; canonical object остаётся `app.main.app`. |
| `backend/app/database.py` | `get_engine, get_session_factory` | `RESTORED_SAFE_COMPAT` — DB import facade поверх `database_core`. |
| `backend/app/core/decimal_utils.py` | `d8` | `RESTORED_SAFE_COMPAT` — historical decimal helper re-export. |
| `backend/app/models/order_models.py` | `ShopOrder` | `RESTORED_SAFE_COMPAT` — ORM import re-export на `shop_models.ShopOrder`. |
| `backend/app/bot/states.py` | FSM public API | `RESTORED_SAFE_COMPAT` — re-export current FSM. |
| `backend/app/bot/handlers/admin/admin__main__handlers.py` | `handler, router, kb_admin_entry, ADMIN_HUB_LABEL` | `RESTORED_SAFE_COMPAT` — historical Admin bot entrypoint facade. |
| scheduler compatibility files | `TickContext, SchedulerError, JobTimeout, tick, run_once` | `RESTORED_SAFE_COMPAT` — делегирование current scheduler runtime. |
| `backend/app/services/admin/admin_rbac.py` | `RBAC.is_superadmin` | `RESTORED_SAFE_COMPAT` — pure role helper, не отдельный источник полномочий. |

### 7.2. Дополнительные восстановления цикла 1717

| Файл | Surface | Статус / назначение |
|---|---|---|
| `backend/app/services/admin/admin_facade.py` | `AdminService.credit_bonus_efhc`, `credit_regular_efhc` | `RESTORED_SAFE_COMPAT` — manual Admin credit через canonical BANK transfer по `global_id`. |
| `backend/app/services/admin/admin_users_service.py` | `credit_bonus_efhc`, `credit_regular_efhc` | `RESTORED_SAFE_COMPAT` — делегирование `adjust_user_balance_via_bank`; BONUS/MAIN bucket определяется явно. |
| `backend/app/services/wallets_service.py` | `credit_user_from_bank`, `_confirm_payment_intent`, `STATUS_CREDITED`, `STATUS_ERROR_SYS` | `RESTORED_SAFE_COMPAT` — payment/watcher compatibility поверх current transaction/reconciliation runtime. |
| `backend/app/services/watcher_service.py` | `_confirm_payment_intent` injection seam | `ACTIVE/RESTORED_COMPAT` — передача bank-credit dependency в reconciliation без изменения ownership. |
| `backend/app/services/nft_requests_service.py` | `refresh_vip_status_due_batch`, `refresh_vip_status_for_due_users`, `check_vip_nft_due_batch` | `RESTORED_SAFE_COMPAT` — historical maintenance facade к current NFT/VIP checker. |

Не восстановлен historical `submit_manual_vip_nft_claim(tg_id, ...)`: старая реализация создавала `tg_id`-era business/admin metadata и противоречит final identity CANON.

### 7.3. Усиленный fail-closed floor

Manifest `contracts/application_function_surface_v1.json` теперь регистрирует:

- **339** критических Python symbols в **62** модулях;
- **77** обязательных protected files;
- exact OpenAPI set: **155 paths / 161 operations**;
- frontend page inventory: **39** files;
- публичные Admin/Bank/Payment/NFT/Task/Shop/Referral/Rank/runtime compatibility anchors, перечисленные в contract, сохраняются fail-closed.

Этот floor не является whitelist: незарегистрированная функция не становится удаляемой.

## 8. Admin HTTP surface

Current checked-in OpenAPI содержит **74 Admin paths / 80 Admin operations**. Таблица фиксирует exact current operation inventory; отсутствие frontend caller не отменяет контракт.

| Method | Path | operationId |
|---|---|---|
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin_api_admin_tasks__task_id__delete` |
| `GET` | `/admin/access` | `admin_access_api_admin_access_get` |
| `GET` | `/admin/ads/dashboard` | `admin_ads_dashboard_api_admin_ads_dashboard_get` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers_api_admin_ads_providers_get` |
| `GET` | `/admin/ads/providers/{code}` | `admin_ads_provider_api_admin_ads_providers__code__get` |
| `GET` | `/admin/ads/revenue-optimizer` | `admin_ads_revenue_optimizer_api_admin_ads_revenue_optimizer_get` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance_api_admin_bank_balance_get` |
| `GET` | `/admin/bonuses` | `admin_bonus_activity_api_admin_bonuses_get` |
| `GET` | `/admin/efhc-deposits/inbox` | `admin_efhc_deposits_inbox_api_admin_efhc_deposits_inbox_get` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary_api_admin_efhc_deposits_runtime_summary_get` |
| `GET` | `/admin/efhc-deposits/unmatched` | `admin_efhc_deposits_unmatched_api_admin_efhc_deposits_unmatched_get` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list_api_admin_hub_links_get` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers_api_admin_logs_transfers_get` |
| `GET` | `/admin/observability/events` | `admin_observability_events_api_admin_observability_events_get` |
| `GET` | `/admin/observability/health` | `admin_observability_health_api_admin_observability_health_get` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary_api_admin_observability_summary_get` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries_api_admin_observability_timeseries_get` |
| `GET` | `/admin/panels/` | `admin_panels_list_api_admin_panels__get` |
| `GET` | `/admin/referrals/summary` | `get_summary_api_admin_referrals_summary_get` |
| `GET` | `/admin/reports/bank` | `reports_bank_api_admin_reports_bank_get` |
| `GET` | `/admin/reports/deposits` | `reports_deposits_api_admin_reports_deposits_get` |
| `GET` | `/admin/reports/overview` | `reports_overview_api_admin_reports_overview_get` |
| `GET` | `/admin/reports/panels` | `reports_panels_api_admin_reports_panels_get` |
| `GET` | `/admin/reports/users` | `reports_users_api_admin_reports_users_get` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals_api_admin_reports_withdrawals_get` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages_api_admin_sale_packages__get` |
| `GET` | `/admin/shop/items` | `admin_items_api_admin_shop_items_get` |
| `GET` | `/admin/shop/nft-requests` | `admin_vip_nft_requests_api_admin_shop_nft_requests_get` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order_api_admin_shop_order__order_id__get` |
| `GET` | `/admin/shop/orders` | `admin_orders_api_admin_shop_orders_get` |
| `GET` | `/admin/shop/orders/status-counters` | `admin_shop_order_status_counters_api_admin_shop_orders_status_counters_get` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders_api_admin_shop_orders_user__global_id__get` |
| `GET` | `/admin/tasks/` | `list_tasks_admin_api_admin_tasks__get` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin_api_admin_tasks__task_id__get` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin_api_admin_tasks__task_id__subs_get` |
| `GET` | `/admin/templates` | `list_templates_admin_api_admin_templates_get` |
| `GET` | `/admin/users/search` | `admin_users_search_api_admin_users_search_get` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get_api_admin_users__global_id__get` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals_api_admin_withdrawals_get` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview_api_admin_withdrawals__request_id__outcome_preview_get` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate_api_admin_panels__panel_id__activate_patch` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate_api_admin_panels__panel_id__deactivate_patch` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin_api_admin_tasks__task_id__patch` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active_api_admin_users__global_id__active_patch` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip_api_admin_users__global_id__vip_patch` |
| `POST` | `/admin/ads/providers/{code}/reset-errors` | `admin_ads_reset_errors_api_admin_ads_providers__code__reset_errors_post` |
| `POST` | `/admin/ads/providers/{code}/secrets/delete` | `admin_ads_delete_secret_api_admin_ads_providers__code__secrets_delete_post` |
| `POST` | `/admin/ads/providers/{code}/secrets/replace` | `admin_ads_replace_secret_api_admin_ads_providers__code__secrets_replace_post` |
| `POST` | `/admin/ads/providers/{code}/test` | `admin_ads_test_provider_api_admin_ads_providers__code__test_post` |
| `POST` | `/admin/ads/revenue-optimizer/apply` | `admin_ads_apply_revenue_optimizer_api_admin_ads_revenue_optimizer_apply_post` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn_api_admin_bank_burn_post` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint_api_admin_bank_mint_post` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit_api_admin_efhc_deposits_process_post` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx_api_admin_efhc_deposits_reprocess__tx_hash__post` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create_api_admin_hub_links_post` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder_api_admin_hub_links_reorder_post` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle_api_admin_hub_links__link_id__toggle_post` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package_api_admin_sale_packages__post` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package_api_admin_sale_packages__package_id__toggle_post` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item_api_admin_shop_items_delete_post` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price_api_admin_shop_items_set_price_post` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status_api_admin_shop_items_status_post` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item_api_admin_shop_items_upsert_post` |
| `POST` | `/admin/shop/nft-requests/{order_id}/decision` | `admin_vip_nft_request_decision_api_admin_shop_nft_requests__order_id__decision_post` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order_api_admin_shop_orders__order_id__force_fulfill_post` |
| `POST` | `/admin/tasks/` | `create_task_admin_api_admin_tasks__post` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin_api_admin_tasks_refresh_statuses_post` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin_api_admin_tasks_submissions__submission_id__moderate_post` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile_api_admin_ton_reconcile_post` |
| `POST` | `/admin/transfer` | `admin_transfer_api_admin_transfer_post` |
| `POST` | `/admin/users/vip/check-all` | `admin_users_check_all_vip_nft_api_admin_users_vip_check_all_post` |
| `POST` | `/admin/users/{global_id}/vip/check` | `admin_users_check_vip_nft_api_admin_users__global_id__vip_check_post` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet_api_admin_users__global_id__wallet_reset_post` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency_api_admin_withdrawals_repair_consistency_post` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve_api_admin_withdrawals__request_id__approve_post` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject_api_admin_withdrawals__request_id__reject_post` |
| `PUT` | `/admin/ads/providers/{code}` | `admin_ads_save_provider_api_admin_ads_providers__code__put` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update_api_admin_hub_links__link_id__put` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package_api_admin_sale_packages__package_id__put` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin_api_admin_templates__key__put` |


## 9. Полный HTTP operation inventory

Current checked-in OpenAPI содержит **155 paths / 161 operations**.

| Method | Path | operationId |
|---|---|---|
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin_api_admin_tasks__task_id__delete` |
| `DELETE` | `/wallets/{wallet_id}` | `delete_wallet_api_wallets__wallet_id__delete` |
| `GET` | `/admin/access` | `admin_access_api_admin_access_get` |
| `GET` | `/admin/ads/dashboard` | `admin_ads_dashboard_api_admin_ads_dashboard_get` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers_api_admin_ads_providers_get` |
| `GET` | `/admin/ads/providers/{code}` | `admin_ads_provider_api_admin_ads_providers__code__get` |
| `GET` | `/admin/ads/revenue-optimizer` | `admin_ads_revenue_optimizer_api_admin_ads_revenue_optimizer_get` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance_api_admin_bank_balance_get` |
| `GET` | `/admin/bonuses` | `admin_bonus_activity_api_admin_bonuses_get` |
| `GET` | `/admin/efhc-deposits/inbox` | `admin_efhc_deposits_inbox_api_admin_efhc_deposits_inbox_get` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary_api_admin_efhc_deposits_runtime_summary_get` |
| `GET` | `/admin/efhc-deposits/unmatched` | `admin_efhc_deposits_unmatched_api_admin_efhc_deposits_unmatched_get` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list_api_admin_hub_links_get` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers_api_admin_logs_transfers_get` |
| `GET` | `/admin/observability/events` | `admin_observability_events_api_admin_observability_events_get` |
| `GET` | `/admin/observability/health` | `admin_observability_health_api_admin_observability_health_get` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary_api_admin_observability_summary_get` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries_api_admin_observability_timeseries_get` |
| `GET` | `/admin/panels/` | `admin_panels_list_api_admin_panels__get` |
| `GET` | `/admin/referrals/summary` | `get_summary_api_admin_referrals_summary_get` |
| `GET` | `/admin/reports/bank` | `reports_bank_api_admin_reports_bank_get` |
| `GET` | `/admin/reports/deposits` | `reports_deposits_api_admin_reports_deposits_get` |
| `GET` | `/admin/reports/overview` | `reports_overview_api_admin_reports_overview_get` |
| `GET` | `/admin/reports/panels` | `reports_panels_api_admin_reports_panels_get` |
| `GET` | `/admin/reports/users` | `reports_users_api_admin_reports_users_get` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals_api_admin_reports_withdrawals_get` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages_api_admin_sale_packages__get` |
| `GET` | `/admin/shop/items` | `admin_items_api_admin_shop_items_get` |
| `GET` | `/admin/shop/nft-requests` | `admin_vip_nft_requests_api_admin_shop_nft_requests_get` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order_api_admin_shop_order__order_id__get` |
| `GET` | `/admin/shop/orders` | `admin_orders_api_admin_shop_orders_get` |
| `GET` | `/admin/shop/orders/status-counters` | `admin_shop_order_status_counters_api_admin_shop_orders_status_counters_get` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders_api_admin_shop_orders_user__global_id__get` |
| `GET` | `/admin/tasks/` | `list_tasks_admin_api_admin_tasks__get` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin_api_admin_tasks__task_id__get` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin_api_admin_tasks__task_id__subs_get` |
| `GET` | `/admin/templates` | `list_templates_admin_api_admin_templates_get` |
| `GET` | `/admin/users/search` | `admin_users_search_api_admin_users_search_get` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get_api_admin_users__global_id__get` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals_api_admin_withdrawals_get` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview_api_admin_withdrawals__request_id__outcome_preview_get` |
| `GET` | `/ads/postback/admaven` | `admaven_postback_api_ads_postback_admaven_get` |
| `GET` | `/ads/postback/adsgram` | `adsgram_reward_url_signal_api_ads_postback_adsgram_get` |
| `GET` | `/ads/postback/monetag` | `monetag_postback_api_ads_postback_monetag_get` |
| `GET` | `/ads/session/{session_id}` | `ads_session_state_api_ads_session__session_id__get` |
| `GET` | `/ads/slot` | `get_ad_slot_api_ads_slot_get` |
| `GET` | `/auth/profile-photos` | `get_profile_photo_sources_api_auth_profile_photos_get` |
| `GET` | `/auth/session` | `get_current_auth_session_api_auth_session_get` |
| `GET` | `/deposit/packages` | `list_deposit_packages_api_deposit_packages_get` |
| `GET` | `/exchange/history` | `history_api_exchange_history_get` |
| `GET` | `/exchange/preview` | `preview_api_exchange_preview_get` |
| `GET` | `/health` | `health_api_health_get` |
| `GET` | `/health/db` | `health_db_api_health_db_get` |
| `GET` | `/health/readiness` | `health_readiness_api_health_readiness_get` |
| `GET` | `/health/runtime` | `health_runtime_api_health_runtime_get` |
| `GET` | `/hub/shop-truth` | `get_hub_shop_truth_api_hub_shop_truth_get` |
| `GET` | `/nft/has_vip` | `has_vip_nft_api_nft_has_vip_get` |
| `GET` | `/panels/active` | `list_my_active_panels_api_panels_active_get` |
| `GET` | `/panels/archive` | `list_my_archived_panels_api_panels_archive_get` |
| `GET` | `/payment-intents/{intent_id}` | `get_payment_intent_status_api_payment_intents__intent_id__get` |
| `GET` | `/ranks/my-plus-top/me` | `get_my_kwh_rank_me_api_ranks_my_plus_top_me_get` |
| `GET` | `/ranks/referrals/my-plus-top/me` | `get_my_referrals_rank_me_api_ranks_referrals_my_plus_top_me_get` |
| `GET` | `/ranks/referrals/top/me` | `get_referrals_top_me_api_ranks_referrals_top_me_get` |
| `GET` | `/ranks/top/me` | `get_kwh_top_me_api_ranks_top_me_get` |
| `GET` | `/referrals/active/me` | `get_my_referrals_active_api_referrals_active_me_get` |
| `GET` | `/referrals/counters/me` | `get_my_referral_counters_api_referrals_counters_me_get` |
| `GET` | `/referrals/inactive/me` | `get_my_referrals_inactive_api_referrals_inactive_me_get` |
| `GET` | `/referrals/stats/me` | `get_my_referrals_stats_api_referrals_stats_me_get` |
| `GET` | `/shop/catalog` | `get_shop_catalog_api_shop_catalog_get` |
| `GET` | `/shop/orders` | `get_orders_api_shop_orders_get` |
| `GET` | `/shopfront/bootstrap` | `shopfront_bootstrap_api_shopfront_bootstrap_get` |
| `GET` | `/shopfront/catalog` | `shopfront_catalog_api_shopfront_catalog_get` |
| `GET` | `/shopfront/intent-status` | `shopfront_intent_status_api_shopfront_intent_status_get` |
| `GET` | `/shopfront/profile` | `shopfront_profile_api_shopfront_profile_get` |
| `GET` | `/skins/catalog` | `skins_catalog_api_skins_catalog_get` |
| `GET` | `/skins/my` | `skins_my_api_skins_my_get` |
| `GET` | `/skins/switcher` | `skins_switcher_api_skins_switcher_get` |
| `GET` | `/tasks/catalog` | `get_tasks_catalog_api_tasks_catalog_get` |
| `GET` | `/tasks/earnings/me` | `get_my_task_earnings_api_tasks_earnings_me_get` |
| `GET` | `/tasks/my` | `get_my_tasks_api_tasks_my_get` |
| `GET` | `/user/me` | `get_me_api_user_me_get` |
| `GET` | `/user/me/panels-summary` | `get_my_panels_summary_api_user_me_panels_summary_get` |
| `GET` | `/v1/me` | `me_api_v1_me_get` |
| `GET` | `/v1/me/withdraw-outcomes/{request_id}` | `me_withdraw_outcome_api_v1_me_withdraw_outcomes__request_id__get` |
| `GET` | `/wallets/balance-history` | `balance_history_api_wallets_balance_history_get` |
| `GET` | `/wallets/me` | `wallets_me_api_wallets_me_get` |
| `GET` | `/wallets/tonconnect/proof-payload` | `tonconnect_proof_payload_api_wallets_tonconnect_proof_payload_get` |
| `GET` | `/withdraw/list` | `get_withdraw_list_api_withdraw_list_get` |
| `GET` | `/withdraw/list/me` | `get_withdraw_list_api_withdraw_list_me_get` |
| `GET` | `/withdraw/{request_id}` | `get_withdraw_detail_api_withdraw__request_id__get` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate_api_admin_panels__panel_id__activate_patch` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate_api_admin_panels__panel_id__deactivate_patch` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin_api_admin_tasks__task_id__patch` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active_api_admin_users__global_id__active_patch` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip_api_admin_users__global_id__vip_patch` |
| `POST` | `/admin/ads/providers/{code}/reset-errors` | `admin_ads_reset_errors_api_admin_ads_providers__code__reset_errors_post` |
| `POST` | `/admin/ads/providers/{code}/secrets/delete` | `admin_ads_delete_secret_api_admin_ads_providers__code__secrets_delete_post` |
| `POST` | `/admin/ads/providers/{code}/secrets/replace` | `admin_ads_replace_secret_api_admin_ads_providers__code__secrets_replace_post` |
| `POST` | `/admin/ads/providers/{code}/test` | `admin_ads_test_provider_api_admin_ads_providers__code__test_post` |
| `POST` | `/admin/ads/revenue-optimizer/apply` | `admin_ads_apply_revenue_optimizer_api_admin_ads_revenue_optimizer_apply_post` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn_api_admin_bank_burn_post` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint_api_admin_bank_mint_post` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit_api_admin_efhc_deposits_process_post` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx_api_admin_efhc_deposits_reprocess__tx_hash__post` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create_api_admin_hub_links_post` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder_api_admin_hub_links_reorder_post` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle_api_admin_hub_links__link_id__toggle_post` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package_api_admin_sale_packages__post` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package_api_admin_sale_packages__package_id__toggle_post` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item_api_admin_shop_items_delete_post` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price_api_admin_shop_items_set_price_post` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status_api_admin_shop_items_status_post` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item_api_admin_shop_items_upsert_post` |
| `POST` | `/admin/shop/nft-requests/{order_id}/decision` | `admin_vip_nft_request_decision_api_admin_shop_nft_requests__order_id__decision_post` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order_api_admin_shop_orders__order_id__force_fulfill_post` |
| `POST` | `/admin/tasks/` | `create_task_admin_api_admin_tasks__post` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin_api_admin_tasks_refresh_statuses_post` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin_api_admin_tasks_submissions__submission_id__moderate_post` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile_api_admin_ton_reconcile_post` |
| `POST` | `/admin/transfer` | `admin_transfer_api_admin_transfer_post` |
| `POST` | `/admin/users/vip/check-all` | `admin_users_check_all_vip_nft_api_admin_users_vip_check_all_post` |
| `POST` | `/admin/users/{global_id}/vip/check` | `admin_users_check_vip_nft_api_admin_users__global_id__vip_check_post` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet_api_admin_users__global_id__wallet_reset_post` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency_api_admin_withdrawals_repair_consistency_post` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve_api_admin_withdrawals__request_id__approve_post` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject_api_admin_withdrawals__request_id__reject_post` |
| `POST` | `/ads/callback/{provider}` | `ads_callback_api_ads_callback__provider__post` |
| `POST` | `/ads/session` | `ads_session_create_api_ads_session_post` |
| `POST` | `/ads/session/{session_id}/client-complete` | `ads_session_client_complete_api_ads_session__session_id__client_complete_post` |
| `POST` | `/ads/session/{session_id}/event` | `ads_session_client_event_api_ads_session__session_id__event_post` |
| `POST` | `/ads/session/{session_id}/fallback` | `ads_session_fallback_api_ads_session__session_id__fallback_post` |
| `POST` | `/ads/session/{session_id}/shown` | `ads_session_shown_api_ads_session__session_id__shown_post` |
| `POST` | `/auth/logout` | `logout_auth_session_api_auth_logout_post` |
| `POST` | `/auth/telegram/session` | `issue_telegram_auth_session_api_auth_telegram_session_post` |
| `POST` | `/auth/ton/challenge` | `issue_ton_login_challenge_api_auth_ton_challenge_post` |
| `POST` | `/auth/ton/proof` | `verify_ton_login_proof_api_auth_ton_proof_post` |
| `POST` | `/deposit/direct-open` | `open_direct_deposit_api_deposit_direct_open_post` |
| `POST` | `/deposit/efhc` | `deposit_efhc_api_deposit_efhc_post` |
| `POST` | `/exchange/convert` | `convert_api_exchange_convert_post` |
| `POST` | `/hub/efhc-handoff` | `create_efhc_handoff_api_hub_efhc_handoff_post` |
| `POST` | `/panels/activate` | `activate_panel_route_api_panels_activate_post` |
| `POST` | `/shop/order-external` | `create_order_external_api_shop_order_external_post` |
| `POST` | `/shop/purchase-efhc` | `purchase_efhc_api_shop_purchase_efhc_post` |
| `POST` | `/shopfront/access-key` | `shopfront_access_key_api_shopfront_access_key_post` |
| `POST` | `/shopfront/create-intent` | `shopfront_create_intent_api_shopfront_create_intent_post` |
| `POST` | `/skins/activate/{skin_id}` | `skins_activate_api_skins_activate__skin_id__post` |
| `POST` | `/skins/switcher/activate/{skin_id}` | `skins_switcher_activate_api_skins_switcher_activate__skin_id__post` |
| `POST` | `/sync/me` | `sync_current_owner_snapshot_api_sync_me_post` |
| `POST` | `/tasks/claim` | `post_claim_my_task_api_tasks_claim_post` |
| `POST` | `/wallets/connect` | `connect_wallet_api_wallets_connect_post` |
| `POST` | `/wallets/tonconnect/check-proof` | `tonconnect_check_proof_api_wallets_tonconnect_check_proof_post` |
| `POST` | `/wallets/{wallet_id}/make-primary` | `make_primary_api_wallets__wallet_id__make_primary_post` |
| `POST` | `/withdraw/request` | `post_withdraw_request_api_withdraw_request_post` |
| `POST` | `/withdraw/{request_id}/cancel` | `post_withdraw_cancel_api_withdraw__request_id__cancel_post` |
| `PUT` | `/admin/ads/providers/{code}` | `admin_ads_save_provider_api_admin_ads_providers__code__put` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update_api_admin_hub_links__link_id__put` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package_api_admin_sale_packages__package_id__put` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin_api_admin_templates__key__put` |


## 10. Frontend page inventory

- `frontend/src/pages/404.tsx`
- `frontend/src/pages/500.tsx`
- `frontend/src/pages/_app.tsx`
- `frontend/src/pages/_document.tsx`
- `frontend/src/pages/_error.tsx`
- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/api-workbench.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/bonuses.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`
- `frontend/src/pages/ads.tsx`
- `frontend/src/pages/app.tsx`
- `frontend/src/pages/browser-shop.tsx`
- `frontend/src/pages/exchange.tsx`
- `frontend/src/pages/faq.tsx`
- `frontend/src/pages/hub.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/ranks.tsx`
- `frontend/src/pages/referrals.tsx`
- `frontend/src/pages/referrals/active.tsx`
- `frontend/src/pages/referrals/inactive.tsx`
- `frontend/src/pages/tasks.tsx`
- `frontend/src/pages/web-profile.tsx`
- `frontend/src/pages/withdraw.tsx`

## 11. Контроль сохранности

`contracts/application_function_surface_v1.json` фиксирует fail-closed current floor: **339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages**. GitHub CI guard остаётся единственным test contour; локально в цикле 1738 он не запускался.

Frontend visual/text authority остаётся PATCH_002. Owner-approved ADS scope зарегистрирован в `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; старый Bot UI не может быть возвращён architecture guard'ом.

Отсутствие caller/UI-кнопки/import не является delete-proof. Compatibility/public/provider/operational surface удаляется только по отдельному решению пользователя и полному Fail-Closed Delete Policy.

Статус v173.65 candidate: **PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

## Audit 2/10 security surface — кандидат v173.70 / цикл 1743

- Registered fail-closed floor расширен до **354 critical Python symbols / 66 modules / 81 required files / 155 OpenAPI paths / 161 operations / 39 frontend pages**.
- Новые защищённые security surfaces: `require_admin_write`, `RBAC.admin_from_auth_context`, strict financial `IdempotencyPayloadConflictError`, caller-owned bank supply nocommit boundaries, Admin notification outbox delivery, canonical Admin Panels service и materialized-only emergency deposit service.
- Public route count не меняется; изменяется authorization и request schema существующего `/admin/efhc-deposits/process`.
- ORM table count остаётся **55**; Alembic schema в цикле 1743 не меняется.
- Frontend visual/text PATCH_002 не изменяется.

---

# ТЕКУЩЕЕ ДОПОЛНЕНИЕ ПОВЕРХНОСТИ ФУНКЦИЙ — v175.01 / цикл 1842

- Статическая OpenAPI после утверждённого OWNER контура поддержки: `170` путей / `177` публичных операций; скрытых операций `8`, ожидаемый общий итог `185`.
- Пользовательская поверхность frontend содержит `41` страницу; добавлена страница `frontend/src/pages/support.tsx`.
- Новый контур поддержки использует `GET /hub/support-links` и отдельные Admin-маршруты `/admin/hub/support-links...`. Контакты поддержки не расширяют публичный Hub: его канон остаётся ровно `2` действия.
- Основа хранения — существующая замороженная схема `0001` / `hub_links`; миграции `0002+` не создавались.
- FAQ после финальной OWNER-волны: `16/16` языков, `20` разделов, `222/250` Q&A; approval `FAQ-APPROVAL-0030`.
- Входной `v175.00` подтверждён exact-head GitHub CI `90038758717`: все canonical gates GREEN, pytest `1785 passed / 22 skipped / 1 warning`. Новый `v175.01` требует собственного exact-head CI.

