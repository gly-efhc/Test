
## Cycle 1719 — Admin Reports/Observability decision lock

- `admin_observability_events` сохраняется как `STUBBED_DUPLICATE`: route существует как compatibility boundary, но DB-read отключён; replacement — `/admin/logs/transfers`.
- `reports_users` — `ACTIVE/UI_CONNECTED`; panels ownership join только `global_id`.
- `reports_bank` — `ACTIVE/UI_CONNECTED`; единственный bank balance — `EFHC_MAIN`, transfer aggregation только `system_entity=BANK_EFHC`.
- `reports_panels`, `reports_withdrawals`, `reports_deposits` — `ACTIVE/UI_CONNECTED`.
- `frontend/src/components/admin/AdminDomainReportsDashboardRuntime.tsx` соединяет пять domain report routes со страницей `/admin/reports`.
- `AdminObservabilityTimeseriesDashboardRuntime` подключён к `/admin/reports` и остаётся real-timeseries read-only surface.
- Release scripts являются protected operational surface; cleanup или изменение executable mode без прямого ТЗ/CI evidence запрещены.

<!-- EFHC_APPLICATION_FUNCTION_SURFACE_V1: ACTIVE -->
# APPLICATION FUNCTION SURFACE — v173.42 / цикл 1718

## 1. Назначение

Этот документ — active SSOT каталога функций приложения после завершённого `global_id` cutover и продолженного аудита сохранности функций. Он фиксирует **application capabilities**, public/operational entrypoints, HTTP surface, frontend pages, background/Admin boundaries и восстановленные compatibility entrypoints. Private helpers не считаются отдельными пользовательскими функциями и не дают основания удалять public/operational surface.

Контрольный контракт: `contracts/application_function_surface_v1.json`.
Контрольный CI-test: `tests/architecture/test_application_function_surface_manifest.py` — расширен в цикле 1717 и **локально не запускался**.

Зафиксированная surface текущего HEAD:

- exported OpenAPI paths: **127**;
- exported HTTP operations: **132**;
- frontend page files: **37**;
- critical registered Python module symbols: **259** в **44** модулях;
- обязательные core/SSOT files: **14**.

Правило сохранности: отсутствие caller, UI-кнопки или прямого импорта **не означает**, что capability можно удалить. Для удаления требуется отдельное решение пользователя и доказательство по Fail-Closed Delete Policy.

## 2. Identity / authentication / session

- Provider subjects: Telegram `tg_id`, TON `ton_wallet_id`, Google `google_id`, Apple `apple_id`, Facebook `fb_id`, Discord `discord_id`, GitHub `github_id`.
- Canonical chain: `provider + subject -> global_id -> business runtime`.
- Server-side session owns application identity by `global_id`.
- Telegram and TON login/proof routes remain provider boundaries; business ownership does not return to `tg_id`/wallet address.
- Logout/session/auth challenge/proof surfaces are preserved in OpenAPI.

## 3. Admin access and Admin capabilities

- Normal Admin: server-side session -> `global_id` -> Admin list/RBAC.
- Admin NFT: server-side session -> `global_id` -> verified TON wallet -> collection check -> exact item address from `TON_ADMIN_NFT_IDS` -> full Admin access.
- Admin actor remains `global_id`; `ton_wallet_id` is not business owner.
- Admin functional domains: access, users, BANK, withdrawals, shop, tasks, panels, referrals, ADS, TON/deposits, reports, templates, sale packages, hub, observability, logs.
- Existing Admin API is preserved even when no frontend caller is currently found.

## 4. BANK / economy / accounting

- System bank entity: `BANK_EFHC`, no fake user/global_id/tg_id.
- Canonical bank balance: `efhc_core.bank_balance`, key `EFHC_MAIN`.
- User credit: `BANK_EFHC -> USER`; system debit: `USER -> BANK_EFHC`.
- Reversal is compensating operation; original operation is immutable.
- P2P prohibited. Mint/Burn remain emergency Admin mechanisms.
- Exchange, panels, withdrawals, tasks/ADS/referrals and shop economic surfaces remain separate domain capabilities.

## 5. Пользовательские домены

- **Energy/Profile:** account/session snapshot, balance/history, panel summary, wallet bindings, profile bootstrap.
- **Panels:** activation, active list, archive, 180-day lifetime, max active limit by canon.
- **Exchange:** preview, convert `1 kWh -> 1 EFHCm`, history.
- **Withdraw:** request/list/detail/cancel for user; Admin approve/reject/outcome/repair.
- **Referrals:** counters, active/inactive lists, stats, deep-link/referral registration and bank-backed rewards.
- **Ranks:** overall leaderboard + my-plus-top; backend also exposes referral leaderboard routes.
- **Tasks/ADS:** task catalog/claim/my tasks; ADS slot/callback; Admin moderation/provider management.
- **Shop/Shopfront:** catalog, EFHC purchase, external order, user orders, browser shop access/bootstrap/catalog/payment intent/status/profile; Admin catalog/order management.
- **Payments/TON:** payment intents, TON proof, deposit/reconciliation/watcher surfaces, unmatched/manual-state handling.
- **NFT/VIP:** VIP ownership/status check; Admin NFT access uses exact item IDs from ENV through the NFT/VIP contour.
- **Skins:** catalog, purchase, activate, switcher.
- **Health/operations:** health/readiness/db/db-schema/runtime and Admin observability endpoints.

## 6. Background / scheduler / operational entrypoints

- `SchedulerService.run_single_tick` is canonical scheduler execution surface.
- Historical scheduler entrypoints are retained through safe compatibility facades (`tick`, `TickContext`, `SchedulerError`, `JobTimeout`, maintenance `run_once`).
- Background identity boundaries keep canonical `global_id` as owner and resolve Telegram delivery subject only when delivery is required.

## 7. Восстановленные safe compatibility surfaces

### 7.1. Восстановления предыдущего этапа

| Файл | Surface | Статус / назначение |
|---|---|---|
| `backend/app/init.py` | `create_app` | `RESTORED_SAFE_COMPAT` — startup facade; canonical object остаётся `app.main.app`. |
| `backend/app/database.py` | `get_engine, get_session_factory` | `RESTORED_SAFE_COMPAT` — DB import facade поверх `database_core`. |
| `backend/app/core/decimal_utils.py` | `d8` | `RESTORED_SAFE_COMPAT` — historical decimal helper re-export. |
| `backend/app/models/order_models.py` | `ShopOrder` | `RESTORED_SAFE_COMPAT` — ORM import re-export на `shop_models.ShopOrder`. |
| `backend/app/bot/states.py` | FSM public API | `RESTORED_SAFE_COMPAT` — re-export current FSM. |
| `backend/app/bot/handlers/admin/admin__main__handlers.py` | `handler, router, kb_admin_entry, ADMIN_HUB_LABEL` | `RESTORED_SAFE_COMPAT` — historical Admin bot entrypoint facade. |
| scheduler compatibility files | `TickContext, SchedulerError, JobTimeout, tick, run_once` | `RESTORED_SAFE_COMPAT` — делегирование current scheduler runtime. |
| `backend/app/services/admin/admin_rbac.py` | `RBAC.is_superadmin` | `RESTORED_SAFE_COMPAT` — pure role helper, не отдельный источник полномочий. |

### 7.2. Дополнительные восстановления цикла 1717

| Файл | Surface | Статус / назначение |
|---|---|---|
| `backend/app/services/admin/admin_facade.py` | `AdminService.credit_bonus_efhc`, `credit_regular_efhc` | `RESTORED_SAFE_COMPAT` — manual Admin credit через canonical BANK transfer по `global_id`. |
| `backend/app/services/admin/admin_users_service.py` | `credit_bonus_efhc`, `credit_regular_efhc` | `RESTORED_SAFE_COMPAT` — делегирование `adjust_user_balance_via_bank`; BONUS/MAIN bucket определяется явно. |
| `backend/app/services/wallets_service.py` | `credit_user_from_bank`, `_confirm_payment_intent`, `STATUS_CREDITED`, `STATUS_ERROR_SYS` | `RESTORED_SAFE_COMPAT` — payment/watcher compatibility поверх current transaction/reconciliation runtime. |
| `backend/app/services/watcher_service.py` | `_confirm_payment_intent` injection seam | `ACTIVE/RESTORED_COMPAT` — передача bank-credit dependency в reconciliation без изменения ownership. |
| `backend/app/services/nft_requests_service.py` | `refresh_vip_status_due_batch`, `refresh_vip_status_for_due_users`, `check_vip_nft_due_batch` | `RESTORED_SAFE_COMPAT` — historical maintenance facade к current NFT/VIP checker. |

Не восстановлен historical `submit_manual_vip_nft_claim(tg_id, ...)`: старая реализация создавала `tg_id`-era business/admin metadata и противоречит final identity CANON.

### 7.3. Усиленный fail-closed floor

Manifest `contracts/application_function_surface_v1.json` теперь регистрирует:

- **259** критических Python symbols в **44** модулях;
- полный публичный `AdminService` — **28** методов;
- `AdminUsersService` manual MAIN/BONUS credit facades;
- Admin bot handler `router`/`handler` surfaces;
- Admin NFT authority anchors;
- payment/watcher compatibility anchors;
- NFT maintenance facade;
- **14** обязательных файлов.

Этот floor не является whitelist: незарегистрированная функция не становится удаляемой.

## 8. Admin HTTP surface

Current static OpenAPI содержит **58 Admin paths**. Таблица ниже фиксирует операции; отсутствие frontend caller не отменяет контракт.

| Method | Path | operationId |
|---|---|---|
| `GET` | `/admin/access` | `admin_access` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers` |
| `GET` | `/admin/observability/events` | `admin_observability_events` |
| `GET` | `/admin/observability/health` | `admin_observability_health` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries` |
| `GET` | `/admin/panels/` | `admin_panels_list` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate` |
| `GET` | `/admin/referrals/summary` | `get_summary` |
| `GET` | `/admin/reports/bank` | `reports_bank` |
| `GET` | `/admin/reports/deposits` | `reports_deposits` |
| `GET` | `/admin/reports/overview` | `reports_overview` |
| `GET` | `/admin/reports/panels` | `reports_panels` |
| `GET` | `/admin/reports/users` | `reports_users` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package` |
| `GET` | `/admin/shop/items` | `admin_items` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order` |
| `GET` | `/admin/shop/orders` | `admin_orders` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order` |
| `GET` | `/admin/tasks/` | `list_tasks_admin` |
| `POST` | `/admin/tasks/` | `create_task_admin` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin` |
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin` |
| `GET` | `/admin/templates` | `list_templates_admin` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile` |
| `POST` | `/admin/transfer` | `admin_transfer` |
| `GET` | `/admin/users/search` | `admin_users_search` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject` |

## 9. Полный HTTP operation inventory

| Method | Path | operationId |
|---|---|---|
| `GET` | `/admin/access` | `admin_access` |
| `GET` | `/admin/ads/providers` | `admin_ads_providers` |
| `GET` | `/admin/bank/balance` | `admin_bank_balance` |
| `POST` | `/admin/bank/burn` | `admin_bank_burn` |
| `POST` | `/admin/bank/mint` | `admin_bank_mint` |
| `POST` | `/admin/efhc-deposits/process` | `admin_process_efhc_deposit` |
| `POST` | `/admin/efhc-deposits/reprocess/{tx_hash}` | `admin_reprocess_efhc_deposit_tx` |
| `GET` | `/admin/efhc-deposits/runtime-summary` | `admin_efhc_deposits_runtime_summary` |
| `GET` | `/admin/hub/links` | `admin_hub_links_list` |
| `POST` | `/admin/hub/links` | `admin_hub_link_create` |
| `POST` | `/admin/hub/links/reorder` | `admin_hub_links_reorder` |
| `PUT` | `/admin/hub/links/{link_id}` | `admin_hub_link_update` |
| `POST` | `/admin/hub/links/{link_id}/toggle` | `admin_hub_link_toggle` |
| `GET` | `/admin/logs/transfers` | `admin_logs_transfers` |
| `GET` | `/admin/observability/events` | `admin_observability_events` |
| `GET` | `/admin/observability/health` | `admin_observability_health` |
| `GET` | `/admin/observability/summary` | `admin_observability_summary` |
| `GET` | `/admin/observability/timeseries` | `admin_observability_timeseries` |
| `GET` | `/admin/panels/` | `admin_panels_list` |
| `PATCH` | `/admin/panels/{panel_id}/activate` | `admin_panels_activate` |
| `PATCH` | `/admin/panels/{panel_id}/deactivate` | `admin_panels_deactivate` |
| `GET` | `/admin/referrals/summary` | `get_summary` |
| `GET` | `/admin/reports/bank` | `reports_bank` |
| `GET` | `/admin/reports/deposits` | `reports_deposits` |
| `GET` | `/admin/reports/overview` | `reports_overview` |
| `GET` | `/admin/reports/panels` | `reports_panels` |
| `GET` | `/admin/reports/users` | `reports_users` |
| `GET` | `/admin/reports/withdrawals` | `reports_withdrawals` |
| `GET` | `/admin/sale-packages/` | `admin_list_sale_packages` |
| `POST` | `/admin/sale-packages/` | `admin_create_sale_package` |
| `PUT` | `/admin/sale-packages/{package_id}` | `admin_update_sale_package` |
| `POST` | `/admin/sale-packages/{package_id}/toggle` | `admin_toggle_sale_package` |
| `GET` | `/admin/shop/items` | `admin_items` |
| `POST` | `/admin/shop/items/delete` | `admin_delete_shop_item` |
| `POST` | `/admin/shop/items/set-price` | `admin_set_item_price` |
| `POST` | `/admin/shop/items/status` | `admin_set_shop_item_status` |
| `POST` | `/admin/shop/items/upsert` | `admin_upsert_shop_item` |
| `GET` | `/admin/shop/order/{order_id}` | `admin_get_order` |
| `GET` | `/admin/shop/orders` | `admin_orders` |
| `GET` | `/admin/shop/orders/user/{global_id}` | `admin_list_user_orders` |
| `POST` | `/admin/shop/orders/{order_id}/force-fulfill` | `admin_force_fulfill_shop_order` |
| `GET` | `/admin/tasks/` | `list_tasks_admin` |
| `POST` | `/admin/tasks/` | `create_task_admin` |
| `POST` | `/admin/tasks/refresh-statuses` | `refresh_task_statuses_admin` |
| `POST` | `/admin/tasks/submissions/{submission_id}/moderate` | `moderate_submission_admin` |
| `DELETE` | `/admin/tasks/{task_id}` | `delete_task_admin` |
| `GET` | `/admin/tasks/{task_id}` | `get_task_admin` |
| `PATCH` | `/admin/tasks/{task_id}` | `update_task_admin` |
| `GET` | `/admin/tasks/{task_id}/subs` | `list_task_submissions_admin` |
| `GET` | `/admin/templates` | `list_templates_admin` |
| `PUT` | `/admin/templates/{key}` | `update_template_admin` |
| `POST` | `/admin/ton/reconcile` | `ton_reconcile` |
| `POST` | `/admin/transfer` | `admin_transfer` |
| `GET` | `/admin/users/search` | `admin_users_search` |
| `GET` | `/admin/users/{global_id}` | `admin_users_get` |
| `PATCH` | `/admin/users/{global_id}/active` | `admin_users_set_active` |
| `PATCH` | `/admin/users/{global_id}/vip` | `admin_users_set_vip` |
| `POST` | `/admin/users/{global_id}/wallet/reset` | `admin_users_reset_wallet` |
| `GET` | `/admin/withdrawals` | `admin_list_withdrawals` |
| `POST` | `/admin/withdrawals/repair-consistency` | `admin_repair_consistency` |
| `POST` | `/admin/withdrawals/{request_id}/approve` | `admin_approve` |
| `GET` | `/admin/withdrawals/{request_id}/outcome-preview` | `admin_withdraw_outcome_preview` |
| `POST` | `/admin/withdrawals/{request_id}/reject` | `admin_reject` |
| `POST` | `/ads/callback/{provider}` | `ads_callback` |
| `GET` | `/ads/slot` | `get_ad_slot` |
| `POST` | `/auth/logout` | `logout_auth_session` |
| `GET` | `/auth/session` | `get_current_auth_session` |
| `POST` | `/auth/telegram/session` | `issue_telegram_auth_session` |
| `POST` | `/auth/ton/challenge` | `issue_ton_login_challenge` |
| `POST` | `/auth/ton/proof` | `verify_ton_login_proof` |
| `POST` | `/deposit/direct-open` | `open_direct_deposit` |
| `POST` | `/deposit/efhc` | `deposit_efhc` |
| `GET` | `/deposit/packages` | `list_deposit_packages` |
| `POST` | `/exchange/convert` | `convert` |
| `GET` | `/exchange/history` | `history` |
| `GET` | `/exchange/preview` | `preview` |
| `GET` | `/health` | `health` |
| `GET` | `/health/db` | `health_db` |
| `GET` | `/health/db-schema` | `health_db_schema` |
| `GET` | `/health/readiness` | `health_readiness` |
| `GET` | `/health/runtime` | `health_runtime` |
| `POST` | `/hub/efhc-handoff` | `create_efhc_handoff` |
| `GET` | `/hub/shop-truth` | `get_hub_shop_truth` |
| `GET` | `/nft/has_vip` | `has_vip_nft` |
| `POST` | `/panels/activate` | `activate_panel_route` |
| `GET` | `/panels/active` | `list_my_active_panels` |
| `GET` | `/panels/archive` | `list_my_archived_panels` |
| `GET` | `/payment-intents/{intent_id}` | `get_payment_intent_status` |
| `GET` | `/ranks/my-plus-top/me` | `get_my_kwh_rank_me` |
| `GET` | `/ranks/referrals/my-plus-top/me` | `get_my_referrals_rank_me` |
| `GET` | `/ranks/referrals/top/me` | `get_referrals_top_me` |
| `GET` | `/ranks/top/me` | `get_kwh_top_me` |
| `GET` | `/referrals/active/me` | `get_my_referrals_active` |
| `GET` | `/referrals/counters/me` | `get_my_referral_counters` |
| `GET` | `/referrals/inactive/me` | `get_my_referrals_inactive` |
| `GET` | `/referrals/stats/me` | `get_my_referrals_stats` |
| `GET` | `/shop/catalog` | `get_shop_catalog` |
| `POST` | `/shop/order-external` | `create_order_external` |
| `GET` | `/shop/orders` | `get_orders` |
| `POST` | `/shop/purchase-efhc` | `purchase_efhc` |
| `POST` | `/shopfront/access-key` | `shopfront_access_key` |
| `GET` | `/shopfront/bootstrap` | `shopfront_bootstrap` |
| `GET` | `/shopfront/catalog` | `shopfront_catalog` |
| `POST` | `/shopfront/create-intent` | `shopfront_create_intent` |
| `GET` | `/shopfront/intent-status` | `shopfront_intent_status` |
| `GET` | `/shopfront/profile` | `shopfront_profile` |
| `POST` | `/skins/activate/{skin_id}` | `skins_activate` |
| `POST` | `/skins/buy/{skin_id}` | `skins_buy` |
| `GET` | `/skins/catalog` | `skins_catalog` |
| `GET` | `/skins/my` | `skins_my` |
| `GET` | `/skins/switcher` | `skins_switcher` |
| `POST` | `/skins/switcher/activate/{skin_id}` | `skins_switcher_activate` |
| `POST` | `/sync/me` | `sync_current_owner_snapshot` |
| `GET` | `/tasks/catalog` | `get_tasks_catalog` |
| `POST` | `/tasks/claim` | `post_claim_my_task` |
| `GET` | `/tasks/my` | `get_my_tasks` |
| `GET` | `/user/me` | `get_me` |
| `GET` | `/user/me/panels-summary` | `get_my_panels_summary` |
| `GET` | `/v1/me` | `me` |
| `GET` | `/v1/me/withdraw-outcomes/{request_id}` | `me_withdraw_outcome` |
| `GET` | `/wallets/balance-history` | `balance_history` |
| `POST` | `/wallets/connect` | `connect_wallet` |
| `GET` | `/wallets/me` | `wallets_me` |
| `POST` | `/wallets/tonconnect/check-proof` | `tonconnect_check_proof` |
| `GET` | `/wallets/tonconnect/proof-payload` | `tonconnect_proof_payload` |
| `DELETE` | `/wallets/{wallet_id}` | `delete_wallet` |
| `POST` | `/wallets/{wallet_id}/make-primary` | `make_primary` |
| `GET` | `/withdraw/list` | `get_withdraw_list` |
| `GET` | `/withdraw/list/me` | `get_withdraw_list` |
| `POST` | `/withdraw/request` | `post_withdraw_request` |
| `GET` | `/withdraw/{request_id}` | `get_withdraw_detail` |
| `POST` | `/withdraw/{request_id}/cancel` | `post_withdraw_cancel` |

## 10. Frontend page inventory

- `frontend/src/pages/404.tsx`
- `frontend/src/pages/500.tsx`
- `frontend/src/pages/_app.tsx`
- `frontend/src/pages/_document.tsx`
- `frontend/src/pages/_error.tsx`
- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/bank.tsx`
- `frontend/src/pages/admin/diagnostics.tsx`
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/hub.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/sale-packages.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/system.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/templates.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`
- `frontend/src/pages/ads.tsx`
- `frontend/src/pages/app.tsx`
- `frontend/src/pages/browser-shop.tsx`
- `frontend/src/pages/exchange.tsx`
- `frontend/src/pages/faq.tsx`
- `frontend/src/pages/hub.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/ranks.tsx`
- `frontend/src/pages/referrals.tsx`
- `frontend/src/pages/referrals/active.tsx`
- `frontend/src/pages/referrals/inactive.tsx`
- `frontend/src/pages/tasks.tsx`
- `frontend/src/pages/web-profile.tsx`
- `frontend/src/pages/withdraw.tsx`

## 11. Контроль сохранности

`tests/architecture/test_application_function_surface_manifest.py` проверяет manifest зарегистрированной application surface: обязательные files/symbols, exact exported OpenAPI path+operation set и frontend pages. Тест не импортирует `app.*` production-модули. В текущем цикле он только создан; локально **не запускался**. Его фактический результат должен дать следующий exact-head GitHub CI.

Статус v173.42: **PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
