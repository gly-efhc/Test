# ADMIN FREEZE CANON — ACTIVE

## OWNER correction: visual-only freeze

Admin is product-accepted as to **visual presentation only**. The freeze protects its approved geometry, layout, styles, color/material roles, typography, visual content arrangement and owner-visible appearance in production and standalone UI. No unsolicited redesign, visual retheming or layout changes are authorized.

**Correction of confirmed Admin errors is a priority and is NOT blocked by visual freeze.** This includes Python/TypeScript/React errors, lint/static typing, backend Admin API routes/services, incorrect processing, authentication/authorization/RBAC bugs, security vulnerabilities, broken functionality and relevant evergreen tests. An Admin file or directory is not inherently `BLOCKED_OWNER` merely because its name contains `admin`. Current OWNER authorization and precise task scope still apply; do not perform unrelated changes.

For an Admin error correction:
1. Prove the specific issue on current physical source/logs; make the minimal needed repair, preserve unrelated behavior and all independent financial, security, identity, TON, ENV and history contracts.
2. Keep the existing visual component identical. Formatting-only Python changes require before/after AST identity and syntax validation; runtime changes require relevant functional checks when authorized.
3. If TSX/JSX/style or other rendered source is changed, demonstrate visual invariance through scope-appropriate rendered/DOM/computed evidence, or declare `VISUAL_NOT_QUALIFIED` until checked. A green linter alone is not visual proof.
4. Existing source-only SHA fingerprints of all Admin `.tsx`/`.ts` files are historical audit provenance, **not a veto of technical fixes**. The machine freeze guard enforces byte-exact visual palette/style/mapping artifacts and file presence. Rebaseline of visual fingerprints requires direct visual OWNER scope/acceptance; technical fixes do not require design re-approval when visual invariance holds.
5. Historical reports remain immutable. This correction supersedes older blanket `Admin product/source/behavior frozen` clauses in current documents; old reports remain evidence only.

## Existing approved visual details

- Owner-visible Admin UI does not display internal architecture notes/server implementation commentary; show operator-facing labels, statuses and concise errors.
- In search blocks with two actions, order remains `Сбросить` then `Найти`.
- Compact-operation identifiers may wrap within their existing tracks; amount/time cells and existing density/grid remain unchanged.
- Page-local `← Назад` / `☰ Меню` topbar scrolls with Admin page; it is not the `GlobalHeader`.

Visual lock evidence: `frontend/tests/regression/admin-freeze-manifest.json`, `frontend/tests/regression/current-admin-freeze.test.mjs`; Admin Theme03 canon and visual artifacts remain unchanged.
