# ADMIN FREEZE CANON — ACTIVE

- Admin panel is complete and accepted as the current product baseline.
- Admin product/source/UI/behavior is frozen.
- No cycle, cleanup, regression finding or global visual operation may mutate Admin without a direct explicit OWNER decision naming Admin scope.
- Historical Admin correction/audit documents and tests are not active authority.
- Current freeze is mechanically represented by `frontend/tests/regression/admin-freeze-manifest.json` and `current-admin-freeze.test.mjs`.
- A direct OWNER Admin change must explicitly update the freeze baseline after acceptance.
- Owner-visible Admin UI must not expose internal implementation notes, server/fail-closed explanations, temporary engineering constraints or architecture commentary unless OWNER explicitly requests them. Keep only operator-facing labels, business statuses/actions and concise understandable errors.
- Where one Admin search block contains both actions, canonical action order is `Сбросить` first and `Найти` second. Any change to that order or surrounding geometry requires direct OWNER scope.

- Accepted compact-operation wrapping is part of the frozen Admin baseline: operation/subject identifiers may wrap within their existing tracks to prevent horizontal overflow, while amount/time cells and the existing density/grid remain unchanged. This is not authority for a new Admin redesign.
- The page-local Admin `← Назад` / `☰ Меню` topbar is ordinary page content: it scrolls with the Admin page and is not the application `GlobalHeader`. The real `GlobalHeader` sticky contract remains separate and unchanged.
