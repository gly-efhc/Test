# ТЕКУЩИЙ RELEASE POINTER — v175.22 / цикл 1854 завершён

- OWNER прямо назначил плановый TR/PL scope цикла `1854`; он завершён как `20` screen-name/UI-label FAQ corrections без расширения product scope.
- CI `90332278146` не exact-head для входного `v175.21`; повторный repair historical RED не выполнялся.
- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`; следующий цикл `1855` только по прямой OWNER-команде.
- Report `02442`; следующий `02443`; остаётся `30` циклов `1855–1884`.
- Short Operator / ZIP-first / one-tree / finding!=scope правила ниже остаются active.

> Предыдущий верхний блок ниже сохраняется как historical evidence и не переопределяет текущий указатель.

---

# ТЕКУЩИЙ RELEASE POINTER — v175.21 / цикл 1854, qualification repair

- Exact-head CI `90332278146` для `v175.20` обработан как обязательный CI repair scope.
- Исправлены два подтверждённых pytest RED; active forbidden-word policy routing не откатывался.
- Плановая TR/PL работа цикла `1854` не выполнялась и остаётся pending до прямой OWNER-команды.
- Report `02441`; следующий `02442`; candidate `v175.21` требует нового exact-head CI.
- Short Operator / ZIP-first / one-tree / finding!=scope правила ниже остаются active.

> Более ранние pointer/boundary blocks ниже являются history; нормативные правила документа сохраняют силу.

---

# ТЕКУЩИЙ RELEASE POINTER — v175.20 / цикл 1853

- OWNER прямо назначил цикл `1853`; scope завершён как CI `90313326320` repair + ES/IT screen-name reconciliation.
- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`; следующий `1854` только по прямому OWNER-сообщению.
- Report `02440`; следующий `02441`.
- Short Operator / ZIP-first / one-tree / finding!=scope правила ниже остаются active.

> Более ранние pointer/boundary blocks ниже являются history; нормативные правила документа сохраняют силу.

---

# ПРИОРИТЕТ OWNER / SHORT OPERATOR / ZIP-FIRST — АКТИВНЫЙ CANON

Статус: **ACTIVE / OWNER OVERRIDE / цикл выбирается прямым сообщением OWNER**.

## Текущий release pointer

- Candidate `v175.19` / цикл `1852`: forbidden-word CANON и scoped machine guards reconciled по OWNER-approved `blacklist_tz.md`.
- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`; следующий цикл `1853` только по прямому сообщению OWNER.
- Report `02439`; следующий `02440`.

## Иерархия authority

1. Последнее прямое указание OWNER в текущем чате имеет абсолютный приоритет над более старыми конфликтующими указаниями, SSOT/CANON/NORM, Kernel, tests, reports, plans и historical evidence.
2. Старое указание продолжает действовать только в части, которая не конфликтует с более новым.
3. Запрещено пытаться «совместить» несовместимые старое и новое решения.
4. Текущий рабочий цикл задаётся последним прямым сообщением OWNER. План, CI или historical status не переключают цикл автоматически.
5. Утверждённый план выполняется только по циклу, который OWNER прямо назвал в сообщении; автоматического перехода к следующему циклу нет.

## История и immutable evidence

1. Старые чаты сохраняются в архиве как историческое evidence и не переписываются для удаления ошибок.
2. Ошибочные historical claims сохраняются как provenance; их исправление оформляется current authority, новым report или новым corrective record.
3. Immutable approval/history record не переписывается для изменения прошлого. Ошибка в его current interpretation исправляется новым authority layer.
4. Исторический чат, report или temporary working tree не заменяет physical Development HEAD.

## Завершение release

1. Любая итерация с физическими изменениями обязана завершиться новым physical Development ZIP в том же рабочем ответе.
2. Нет ZIP = изменения не являются project state и не могут называться выполненными.
3. Порядок: минимальная законченная безопасная реализация → минимальный governance/report → физический ZIP → optional targeted checks только если осталось время.
4. Full local suites/build запрещены без прямого OWNER permission.
5. Targeted checks не могут задерживать ZIP.

## Режим Short Operator

1. Один physical HEAD → одна распаковка → один рабочий каталог → один output ZIP.
2. Operator Kernel запускается один раз как navigation layer; после него разрешена только bounded task-relevant работа.
3. `Finding != scope`: новая находка переносится, если она не блокирует ZIP, не является current exact-head CI RED, critical security/financial corruption или прямым OWNER scope.
4. 25 минут — аварийный hard stop, не рабочий бюджет. Простые задачи не растягиваются ради анализа.
5. Нельзя делать claims по temporary working tree. Final claims относятся только к физическому output ZIP.

## Текущая граница

- OWNER прямым сообщением назначил цикл `1851`; он выполнен как DE/FR screen-name/navigation reconciliation по утверждённому плану.
- Exact-head CI `90304130073` для `v175.17` полностью GREEN.
- Candidate release: `v175.18`; immutable report `02438`; qualification требует следующего exact-head GitHub CI.
- Утверждённый план `1849–1883` сохраняется без самовольного перенумерования.
- Следующий плановый цикл `1852` не запускается автоматически и выполняется только после прямого сообщения OWNER.
- После цикла `1851` остаётся `32` плановых цикла `1852–1883`.
- Дополнительный `blacklist_tz.md` не внедрялся в cycle `1851`; отдельная reconciliation выполняется только по новому OWNER scope.
