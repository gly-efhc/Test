## Цикл 1746 — authoritative TonConnect proof lock

Для `/wallets/tonconnect/check-proof` и `/wallets/connect` действуют обязательные условия:

- `state_init`, `public_key` и wire `network` обязательны на HTTP boundary;
- wire TON chain id (`-239` mainnet, `-3` testnet) должен совпадать с configured `TON_NETWORK`;
- public key/address разрешаются только через canonical authoritative state-init resolver;
- client-supplied public key обязан совпасть с authoritative public key;
- ветка `PROOF_VERIFIED_CLIENT_KEY_ONLY` запрещена;
- невозможность authoritative resolution означает fail-closed отказ, а не verified wallet binding.

`wallet_bindings` может становиться financial attribution authority только после такого cryptographic proof.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Актуальный wallet identity SSOT — цикл 1618

Один canonical TON wallet разрешается в один `global_id`. Повторный login
не создаёт второй account или identity, но может выдать новую независимую
hashed server-side session. Logout отзывает только текущую session и не
изменяет wallet binding. Фиктивный `global_id` отсутствует.

## TON provider subject naming — утверждено 2026-08-08

`ton_wallet_id` — каноническое имя TON provider subject. Его значение — сам
канонический адрес TON-кошелька; отдельного числового TON ID нет.

Первый подтверждённый вход по новому `ton_wallet_id` создаёт новый
`global_id` и связь `provider=ton + ton_wallet_id → global_id`. Повторный
вход по уже зарегистрированному `ton_wallet_id` использует существующий
`global_id`. Один `ton_wallet_id` не может принадлежать двум `global_id`;
конфликт завершается fail closed без auto-merge.

Generic storage `efhc_core.user_identities.provider_subject` остаётся
provider-neutral колонкой; для `provider=ton` она содержит `ton_wallet_id`.
`wallet_bindings.wallet_address`, `users.ton_wallet` и функции
`app.lib.ton_address` являются wallet/address storage или parsing concepts,
а не альтернативными именами TON provider subject.

---

# Актуальный wallet identity SSOT — цикл 1617

`ton_wallet_id` (канонический TON address) является значением generic `provider_subject` и unique lookup key.
Один wallet соответствует одному `global_id`. Legacy verified binding может
быть привязан к существующему account; неподтверждённый или конфликтующий
binding завершается fail closed. Fake `global_id` для TON-only account запрещён.

# TON wallet identity addendum — cycle 1616

Значение `ton_wallet_id` как TON provider subject имеет формат
`<workchain>:<64 lowercase hex account_id>`. Client public key не является
authoritative: он обязан совпасть с key, полученным из проверенного
state-init. Network, domain, timestamp, signature, TTL и replay проверяются
до любых account/identity/session side effects.

---

# TON login identity addendum — cycle 1615

Новый TON login challenge не зависит от Telegram и не использует `tg_id`.
Канонический `ton_wallet_id` — только raw lowercase address
`<workchain>:<64 lowercase hex account_id>`. Существующий Telegram wallet
binding path остаётся отдельным compatibility-контуром. Proof verification и
identity/session issue выполняются в последующих циклах `1616–1618`.

---

# Wallet identity SSOT

## Active identity rule

EFHC Bot accepts valid TON address formats at the input boundary.

EFHC Bot stores and compares one canonical internal address format:

```text
<workchain>:<64 lowercase hex account_id>
```

Wallet ownership is defined only by that canonical address.

`wallet_bindings` is the active wallet binding table.

TonConnect proof is the active wallet ownership proof mechanism.

UI may display friendly, short or masked address. UI display format
must not define DB ownership, watcher lookup, conflict checks or unique
constraints.

## Canonical address users

Canonical address is used for:

- DB ownership;
- wallet conflict check;
- watcher lookup;
- unique constraint;
- admin wallet reset / wallet tools;
- regression tests.

## Active wallet proof path

The active binding path is:

```text
TonConnect proof
-> signature verification
-> wallet ownership proof
-> global_id binding
-> wallet_bindings
-> replay protection
-> idempotency
```

Legacy memo/bind-request flows are not active runtime canon.

## Legacy admin crypto wallet closure

`efhc_core.crypto_wallets` is not active wallet identity storage. The
legacy admin service that used it was removed from active runtime in
cycle 1508.

All active wallet identity, ownership, conflict checks and lookup logic
use `wallet_bindings.wallet_address` after canonicalization.

## Existing database migration/backfill

The active migration layer contains a compatibility repair that converts
old valid `wallet_bindings.wallet_address` values to canonical form.
This protects existing databases created before canonical storage was
made explicit.


## TON login challenge storage boundary

Публичная выдача TON login challenge остаётся допустимой authentication
boundary, но DB INSERT не является безлимитным. До создания новой строки
сервер применяет DB-backed ограничения выдачи: rate window по необратимому
client fingerprint, общий предел незавершённых challenge для provider/purpose
и bounded cleanup expired/consumed/invalidated строк. Raw transport IP в
`auth_challenges` не сохраняется.

Проверка квот и INSERT сериализуются PostgreSQL advisory transaction lock,
чтобы параллельные запросы не обходили предел. Ошибка storage в этом контуре
fail-closed: challenge не выдаётся. Expiry index остаётся canonical опорой для
bounded retention cleanup; отдельная schema/table для limiter не создаётся.

## Server binding vs live TON Connect session

Server/account wallet state and live connection-session state are separate facts.

- `wallet_bindings` records, including active/primary state, describe server/account binding.
- A live TON Connect session is derived independently from the current session address.
- Session ownership matches a bound wallet only through canonical TON-address comparison.
- Primary-wallet status, TON proof, server binding and live session ownership must not be conflated.

Current Profile wallet presentation is address-centric. `wallet_app` is internal transport/history metadata, not public wallet identity or branding authority. TON Connect session status is rendered separately from bound-wallet identity.

## Profile address verification and privacy

- Private Profile may display the full bound TON address for verification and native copy.
- Copy-success feedback is allowed only after the clipboard write resolves successfully.
- If clipboard access fails or is unavailable, the full address remains visible/selectable for manual copy and success must not be faked.
- Public Browser Shop privacy masking remains independent and must not be relaxed by the private Profile rule.

## Profile Wallet current presentation
- Each bound wallet uses one visual container; identity/status, address and management actions are separate zones.
- The Primary wallet is always rendered as visual list item #1. A successful make-primary mutation may update the local query snapshot optimistically, but mutation failure must roll back and the settled state is authoritative-refetched.
- The full wallet address is the first/top content inside the Primary card and is shown once in a dedicated row, wraps safely at narrow widths and is itself the native copy control. Duplicate `Full address` disclosure and a second Copy button are forbidden.
- Copy hover/focus uses translucent background feedback rather than underline. After a successful clipboard write, localized `wallet.copied` feedback is transient (current runtime: 1400 ms) and then clears; success is never shown before a successful clipboard write.
- The Primary badge is the final/lower-right semantic content of the Primary card. Primary and ordinary wallet cards keep the same frame material; Primary must not gain a special border merely to signal primary status.
- Only the primary wallet may show `Основной / Primary`. Bound-wallet cards do not show per-card `Bound` or `Connected`; exact TON Connect session state belongs to the separate session-status block.
- Error and true-empty Wallet states are mutually exclusive. At narrow boundaries identity/status and management actions may stack, but wallet semantics and handlers do not change.
- Public wallet-application branding is not identity. `wallet_app` remains internal transport/history metadata; official SDK/registry metadata is the public chooser authority.

