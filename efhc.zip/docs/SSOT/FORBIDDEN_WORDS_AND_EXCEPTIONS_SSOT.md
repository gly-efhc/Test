# FORBIDDEN SEMANTIC VOCABULARY AND POLICY ROUTING SSOT

Статус: **CANON / SSOT / ACTIVE**

Цель документа — определять только постоянные semantic prohibitions и
маршрутизировать остальные типы ограничений в их профильные CANON.

Этот документ больше не является общим хранилищем всех исторических
rebranding tokens, runtime aliases, source-quality markers и
architecture literals.

## 1. Классификация

Все ограничения терминологии EFHC относятся ровно к одному из четырёх
классов:

1. `PERMANENT_SEMANTIC_BAN`
2. `PUBLIC_UI_COPY_RESTRICTION`
3. `ARCHITECTURE_CANON`
4. `SOURCE_QUALITY_GUARD`

Слово или identifier нельзя объявлять глобально запрещённым только
потому, что оно когда-либо участвовало в завершённом ребрендинге,
migration или техническом cleanup.

## 2. PERMANENT_SEMANTIC_BAN

Постоянно запрещён продуктовый смысл, который представляет EFHC как:

- азартную механику;
- лотерею;
- raffle / lottery mechanic;
- betting mechanic;
- jackpot mechanic;
- случайную финансовую награду;
- случайный финансовый выигрыш;
- финансовый конкурс, в котором вознаграждение зависит от случая,
  ставки или аналогичной gambling-механики.

Этот запрет является semantic, а не простым substring/token ban.

## 3. Hard semantic indicators

Следующие понятия являются прямыми индикаторами запрещённого контура,
если используются для описания механики EFHC:

- lottery / лотерея;
- loto;
- raffle;
- gambling / азартная игра;
- jackpot / джекпот;
- random financial reward / случайная финансовая награда;
- betting / bet в значении азартной ставки.

Они не должны использоваться как действующая продуктовая механика,
route/schema/service/function/UI concept EFHC.

Историческое описание удалённой механики не превращает historical
evidence в active product contract.

## 4. Contextual terms are not automatic blockers

Следующие слова не являются глобально запрещёнными токенами:

- game / игра;
- tournament / турнир;
- round / раунд;
- draw / розыгрыш;
- winner / победитель;
- win / winning / победа / выигрыш;
- prize / приз;
- reward / награда;
- chance / шанс;
- bet / ставка;
- competition / конкурс.

Их допустимость определяется смыслом.

Примеры допустимого контекста:

- обычный игровой процесс;
- раунд технической обработки;
- ставка генерации;
- награда за выполнение обычного задания;
- победитель неазартного конкурса;
- шанс как обычная языковая конструкция;
- draw как технический/графический термин.

Пример запрещённого контекста:

случай, ставка или lottery/gambling mechanic определяют получение
денежной, токенной, EFHC или иной финансово значимой награды.

При сомнении оценивается весь semantic context, а не отдельное слово.

## 5. Игра разрешена

EFHC Bot может описываться как:

- игра;
- игровой бот;
- игровой проект;
- игровой процесс.

Разрешены обычные игровые понятия:

- прогресс;
- панели;
- энергия;
- задания;
- рефералы;
- Ranks;
- уровни;
- развитие аккаунта.

Игровой характер продукта сам по себе не относится к gambling contour.

## 6. PUBLIC_UI_COPY_RESTRICTION

Ограничения пользовательской лексики не являются repo-wide forbidden
vocabulary.

Authority:

- `docs/SSOT/USER_FACING_WORDING_CANON.md`;
- `docs/SSOT/FAQ_SSOT.md`;
- `docs/NORM/PUBLIC_ERROR_STATE_CANON.md`;
- `docs/NORM/PUBLIC_ERROR_MESSAGE_CANON.md`;
- `docs/NORM/TOAST_AND_EMPTY_STATE_CANON.md`;
- `ops/policy/public_ui_forbidden_copy.json`;
- `ops/policy/public_ui_active_copy.json`.

Developer/technical words могут быть нормальными в:

- backend;
- frontend source;
- Admin;
- diagnostics;
- logs;
- API/OpenAPI;
- engineering documentation;
- tests.

Они ограничиваются только там, где их показ обычному пользователю
нарушает user-facing wording CANON.

## 7. ARCHITECTURE_CANON

Architecture identifiers, aliases, field names, provider names,
generation constants и завершённые rebranding names не относятся к
этому forbidden vocabulary SSOT.

Их authority находится в профильных документах.

Identity:

- `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`;
- `docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md`;
- `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`;
- `docs/SSOT/IDENTITY_GLOSSARY.md`.

Ranks:

- `docs/frontend/REFERRALS_RANKS_FRONTEND_CANON.md`;
- профильные frontend/route CANON.

Generation rates:

- профильный generation-rate runtime/architecture contract;
- machine architecture guards.

Если профильный CANON запрещает alias в определённом runtime scope,
это architecture violation, а не глобальный lexical violation.

## 8. SOURCE_QUALITY_GUARD

Source-quality ограничения также не являются permanent forbidden
vocabulary.

### 8.1 Raw UI strings

Правило:

- user-facing UI copy должна использовать translation/i18n layer;
- корректная пользовательская фраза не становится запрещённой сама по
  себе;
- запрещается hardcoded/raw delivery там, где CANON требует i18n key.

### 8.2 Unfinished markers

`TODO/FIXME/TBD` регулируются только shipping source-code unfinished
marker policy.

Документы, FAQ, historical evidence и естественная лексика языков не
являются этим code scope.

Authority:

- `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`;
- `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`;
- текущие OWNER decisions.

## 9. Panel wording

Формулировки:

- `купить панель`;
- `покупка панели`;
- `цена панели`;

не относятся к gambling semantic ban.

Они являются отдельным `PUBLIC_UI_COPY_RESTRICTION`.

User-facing CANON:

- `активировать панель`;
- `активация панели`;
- `для активации панели необходимо ...`.

Authority:

`docs/SSOT/USER_FACING_WORDING_CANON.md`.

## 10. Investment / income wording

Инвестиционно-доходные ограничения user-facing текста также не являются
repo-wide lexical ban.

Они регулируются:

`docs/SSOT/USER_FACING_WORDING_CANON.md`.

Ограничение применяется к публичному пользовательскому смыслу, а не к
engineering documentation, API naming, accounting explanation или
historical evidence как таковым.

## 11. Historical evidence

Historical reports, chats, cycle records, audit records, imported
original sources и immutable evidence могут содержать старые слова и
идентификаторы.

Historical evidence не является active product wording authority.

Исторические документы не переписываются только ради современной
терминологии.

## 12. Guard design

Machine guard обязан проверять тот scope, которому принадлежит правило.

Запрещено:

- превращать semantic restriction в бесконтекстный repo-wide substring
  search;
- использовать завершённый rebranding как вечный глобальный lexical
  blacklist;
- блокировать нормальное слово из-за совпадения подстроки;
- распространять user-facing restriction на backend/docs/Admin;
- распространять source-code unfinished-marker rule на документы или
  естественную локализованную лексику.

При конфликте:

1. последнее прямое OWNER decision;
2. профильный SSOT/CANON;
3. NORM;
4. runtime invariant;
5. machine guard/test.

Stale guard должен быть исправлен; CANON нельзя откатывать только ради
старой реализации guard.

## 13. Итоговый принцип

Permanent forbidden vocabulary EFHC должен быть минимальным и
semantic.

Все остальные ограничения должны жить в собственном профильном
contract:

- semantic gambling ban → этот SSOT;
- public wording → USER_FACING/FAQ/Public UI policy;
- identifiers/constants → architecture CANON;
- hardcode/unfinished markers → source-quality policy.
