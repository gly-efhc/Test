<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# FORBIDDEN WORDS AND EXCEPTIONS SSOT

Статус: CANON / SSOT

Цель: зафиксировать запрещённые слова, группы терминов, правила узких
исключений и обязательную иерархию лечения forbidden-word drift.

## 1. Базовое правило

- Широкие исключения запрещены.
- Допустимы только узкие исключения, отдельно утверждённые пользователем.
- Предпочтительный способ лечения: переписать wording, а не ослаблять
  guard-tests.

Иерархия лечения:
1. Переписать wording.
2. Сузить контекст.
3. Narrow exception — только как last resort.

## 2. Legacy rank vocabulary

Канон проекта: `rank / ranks / Ranks`.

Запрещено repo-wide во всех активных слоях:
- legacy score/rank wording from the removed naming family;
- любые user-facing, AI-facing, code-comment и control-layer замены,
  которые возвращают старый смысл старого score-family vocabulary.

Узкие исключения допускаются только в:
- historical reports;
- archived docs;
- imported vendor/sandbox files.

AI docs в исключения не входят.

## 3. Removed-domain / gambling vocabulary

Полностью запрещены как removed-domain vocabulary:
- английская removed-domain family для chance/promo vocabulary;
- русские/украинские эквиваленты removed-domain слоя;
- competition/bracket term from the removed promo/gambling family.

Особое правило для short EN draw-token:
- глобальный тотальный запрет не используется;
- short EN draw-token запрещается только в removed-domain / gambling
  контексте.

Узкие исключения допускаются только в:
- historical reports;
- archived docs;
- imported vendor/sandbox files.

## 4. Runtime identifiers canon

Канон runtime-layer для пользователя: только `global_id`.

Запрещённые alias-формы в runtime:
- `user_id`;
- `telegram_id`;
- `userId`;
- `telegramId`;
- `uid`;
- `tgid`;
- другие дублирующие alias-формы.

Правило scope:
- runtime-code only;
- historical migrations могут содержать legacy names как исторический
  слой и не являются runtime-source of truth.

ENV standard:
- допустимы только `*_TG_ID*` и `*_TG_IDS*`;
- формы `*_TELEGRAM_ID*` и `*_TELEGRAM_IDS*` считаются запрещёнными для
  нового runtime/config wording.

## 5. UI raw strings

Правило UI-layer:
- raw hardcoded UI strings запрещены;
- user-facing UI copy должна идти через translation layer / i18n keys /
  shared constants / glossary-aligned labels.

Критические домены первичного аудита:
- Wallet & Finance;
- Common Actions;
- System Errors & Alerts;
- Navigation & Empty States;
- Rewards & Social.

## 6. Generation-rate canon

Разрешённый стандарт generation-rate:
- `0.00000692`;
- `0.00000741`.

Запрещены legacy aliases и derived literals вроде daily aliases и старых
неканоничных чисел.

## 7. Placeholder markers

В активном HEAD полностью запрещены:
- `TODO`;
- `FIXME`.

Широкие исключения не допускаются.

## 8. Vague / weakening phrases

Отдельный расширенный banned-list для vague phrases сейчас не вводится
как самостоятельный SSOT-block.

При этом всё ещё запрещены ложные утверждения о CI, релизной готовности
и завершённости без доказательства свежими логами, кодом и фактическим
HEAD.

## 9. Multi-language rule

Forbidden-layer должен контролироваться на всех поддерживаемых языках
проекта. Для UI primary defense — запрет неразмеченного raw text в
user-facing UI слоях.

## 10. Исключения

Допустимые узкие исключения:
- historical reports;
- archived docs;
- imported vendor/sandbox files.

Недопустимые исключения:
- tests;
- AI docs.

Если слово попало в недопустимый слой, его надо лечить wording repair, а
не whitelist-исключением.

## 11. Gambling / loto contour hard ban

Статус: CANON.

EFHC Bot может использовать игровые описания и описание бота как игры.
Слово `игра` и обычный игровой слой не запрещены.
Запрещён только азартный, лотерейный, розыгрышный, турнирный,
ставочный и случайный финансовый контур в active release scope.

Запрещены не только пользовательские слова, но и keys, functions, routes,
services, schemas, models, tests, fixtures, comments, templates и
user-facing backend/frontend copy.

Полный список запрещённых терминов хранится здесь как список запрета, а
не как рабочий продуктовый текст:

- tournament / турнир / турниры / турнирный;
- round / раунд;
- entry cost / стоимость входа;
- loto / лотерея;
- draw / розыгрыш;
- draw-prize;
- winner / победитель;
- win / выигрыш / выиграть / winning;
- prize / приз;
- bet / ставка;
- gambling / азарт;
- jackpot / джекпот;
- random reward / случайная награда;
- chance / шанс выиграть;
- buy panel / купить панель;
- panel price / цена панели.

Разрешённые места для явного перечисления этих слов:

- этот SSOT-документ;
- NORM-регламент запрета;
- Healer-карточка запрета;
- файл guard-проверки, где хранится forbidden list;
- historical reports, audits, Healer, logs и cycle records, если слова
  используются как историческое описание старой ошибки.

AI docs не должны вводить запрещённые азартные или лотерейные
слова как допустимый продуктовый канон. Если AI docs ссылаются на
запрет, они должны направлять к этому SSOT.


## 11A. Игра разрешена, азартный контур запрещён

Статус: CANON.

Допустимы игровые описания EFHC Bot, если они описывают обычную игру,
игровой проект, игровой процесс, внутриигровой прогресс, генерацию
энергии, панели, задания, рефералов, ранги и развитие аккаунта.

Недопустимы описания, которые вводят азартный, лотерейный,
розыгрышный, турнирный, ставочный или случайный финансовый смысл.

Иными словами:
- `игра / игровой / игровой процесс / игровой проект` разрешены;
- `лотерея / турнир / ставка / выигрыш / приз случайного характера`
  запрещены в active release scope.

## 12. Contextual suspicious words

Награда / reward и победа / win не являются автоматическим blocker во всех
случаях. Они являются suspicious terms.

Если такие слова используются в нефинансовом, неазартном и неслучайном
контексте, они могут быть допустимы. Если рядом есть EFHC, баланс,
начисление, случайность, ставка, розыгрыш или запрещённый removed-domain
смысл, ассистент обязан остановиться и задать русскоязычную итерацию с
пояснением.
