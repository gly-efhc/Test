# GREENFIELD V8 CANON — целевая архитектура первого production launch

Статус: **ACTIVE OWNER-APPROVED TARGET / STAGED IMPLEMENTATION**  
Источник решения владельца: `EFHC_GREENFIELD_FULL_AUDIT_TZ_V8_173_99_READY.zip`, база `v173.99`.

## 1. Authority и режим

Этот документ фиксирует согласованные владельцем целевые решения Greenfield V8. Production DB/data ещё не являются исходным migration constraint: целевой первый launch строится как clean initial schema. При этом действующий hard-delete lock сохраняется: физическое удаление compatibility/API/code/schema surface выполняется только отдельным явно разрешённым deletion action, а не по одному отсутствию внутренних callers.

Текущий staged HEAD не обязан реализовывать все разделы V8 одновременно. Причина — финансовая чувствительность и требование exact-head GitHub CI между high-blast этапами. Отложенный пункт остаётся owner-approved target, а не отменённым решением.

## 2. Identity и lifetime identifiers

- Business owner: `users.global_id` / canonical `global_id`.
- Provider subjects используются только для разрешения canonical owner.
- Retained lifetime PK/FK/identity в целевой initial schema: PostgreSQL `BIGINT` там, где это определено V8 registry.
- Lifetime IDs через JSON/frontend: **decimal strings**, не JavaScript `number`.
- Изменение wire contracts выполняется отдельным compatibility этапом с OpenAPI/generated seams/frontend синхронизацией.

## 3. Время и energy

- Business timezone: UTC.
- Elapsed game time должен быть устойчив к скачкам wall clock во время жизни процесса.
- BASE↔VIP: старая ставка начисляется точно до подтверждённого transition time; затем checkpoint; затем меняется `is_vip`; новая ставка действует только после границы.
- Других generation-speed modifiers целевой канон не вводит.
- Persistent daily ranking claim в 02:00 UTC остаётся отдельным target; process-local monotonic anchor не заменяет DB-backed claim.

## 4. Panels

- Целевой lifecycle: одна business table, lifetime ровно 180 дней, максимум 1000 одновременно active panels на owner, planning average 10.
- Истёкшая панель не активируется повторно.
- Конкурентные create/reactivate должны сериализовать limit-check по owner, чтобы лимит 1000 был invariant, а не best effort.
- Владелец явно разрешил удаление `panels_archive`; canonical archive остаётся в единой `panels`, а public `/panels/archive` сохраняется.

## 5. Wallet binding и replay

- Явная пользовательская detach физически освобождает binding/address для другого подтверждённого owner.
- Stale connect idempotency не может воскресить удалённый binding.
- TonConnect proof anti-replay window: 24 часа.
- Wallet connect idempotency window: 7 дней.
- Внешнее финансовое событие может впервые изменить деньги только раньше строгой границы **180 суток** от проверенного `trusted_operation_at`; ровно 180 суток и старше — `EXPIRED / NO CREDIT` до replay/idempotency и до money mutation.
- Для settlement обязательна двойная временная проверка: trusted external operation time + сохранённый server first-seen. Более новое first-seen не может «омолодить» старую операцию.
- `tx_hash`/ordinary external replay protection обязана покрывать всё 180-дневное окно финансовой исполнимости. После green qualification barrier постоянное хранение таких replay markers больше не требуется; target retention — до окончания 180 суток.
- До отдельного exact-head retention stage текущие replay records физически не сокращаются: сначала barrier должен быть подтверждён GitHub CI.
- 180-дневная time/replay boundary является P0 security invariant. Обязательная qualification включает точные boundary tests (`<180d` разрешено, `>=180d` запрещено), missing/naive/future/inverted evidence, запрет rejuvenation и real PostgreSQL proof, что заблокированное событие не создаёт `tx_hash_locks` claim.

## 6. Ledger / BANK_EFHC

- `BANK_EFHC` остаётся core economic account и может иметь отрицательное значение по действующему бизнес-канону.
- Completed movement immutable; исправление — компенсирующее движение.
- Необъяснимое расхождение денежной массы — P0 security/integrity incident.
- Для обычных non-emission движений контрольный conservation invariant: `SUM(users.main_balance) + SUM(users.bonus_balance) + BANK_EFHC = const`. History/ledger объясняет происхождение изменения, а этот invariant контролирует сохранность текущей денежной массы.
- Оптимизация BANK critical section допускается только без изменения экономического смысла и после evidence/benchmark.

## 7. Ranking

Целевое состояние:
- score authority: только `users.total_generated_kwh`;
- только active users;
- один current rank, без rank history/snapshots/cache tables;
- daily calculation: 02:00 UTC application time;
- `DENSE_RANK` с tie semantics `77,78,78,79`;
- сохраняются current `rank_position`, `rank_score_kwh`, `rank_calculated_at`;
- find-me читает сохранённый rank, не запускает global recalculation;
- referral leaderboard отсутствует в target, referral economy сохраняется.

Ranking schema/job/removal changes выполняются отдельным exact-head этапом после schema/wire-contract qualification.

## 8. Profile History

Owner-approved banking operation center из `v173.99` сохраняется.

Целевой contract:
- 50 **логических** операций на page;
- keyset pagination;
- корректный global ordering;
- current balances читаются как current state, независимо от загруженной history;
- полный export: CSV + XLSX, bounded/streaming memory;
- lifetime operation/wallet/withdraw IDs — decimal strings over JSON;
- spreadsheet formula-injection protection сохраняется.
- Решение владельца 2026-08-15: для XLSX разрешён `openpyxl` как production dependency; фактическое добавление dependency выполняется только в History/export cycle.

Недопустима подмена target простым запросом `50+50+50` к трём независимым источникам: это не 50 логических операций и увеличивает request amplification. До unified read model или доказанного bounded merge сохраняется current compatible three-source behavior.

## 9. Initial schema / retention

- Target перед первым production launch: deterministic clean `0001_initial_release_schema.py`, без `0002+`.
- Retention/replay/index policy закладывается в production design до первых production rows; simple financial retention не требует partition schema rewrite.
- Переписывание `0001` — high-blast schema action и выполняется отдельным этапом с owner-approved V8 target + exact-head Alembic/CI verification.
- Никакой искусственной legacy-data backfill choreography для несуществующей production DB.
- Qualification frozen `0001` должна включать не только smoke `alembic upgrade head`, но и fresh-DB physical parity замороженного `RELEASE_METADATA`: table/column/type/nullability/PK/UNIQUE/FK/CHECK/index surface и повторный upgrade noop.
- Решение владельца 2026-08-15: expired/revoked auth sessions удаляются после 14 дней; active sessions этим retention не затрагиваются.
- Решение владельца 2026-08-15: admin/security audit хранится online 3 года.
Решение владельца 2026-08-16: frozen migration-local `RELEASE_METADATA` утверждён владельцем как окончательная форма `0001`; literal SQL DDL отдельно не требуется. Замороженный `0001` является контрольной копией physical schema до финальной сверки.
Решение владельца 2026-08-16 (последнее и приоритетное): financial retention разделён на execution window и simple history retention. Внешняя операция имеет право на **первичное** зачисление только при `trusted age < 180 days`; при `trusted age >= 180 days` она навсегда получает `EXPIRED / NO CREDIT` до replay/idempotency и money mutation. Detailed financial history на шести approved tables хранится в обычных PostgreSQL tables без monthly partitioning: `created_at age >= 370 days` делает запись delete-eligible независимо от lifecycle status; cleanup запускается только при oldest history `age >= 400 days` и удаляет всё eligible history `created_at <= now_utc - 370 days`. `users` balances и `BANK_EFHC` хранятся FOREVER.

Physical monthly partitioning **отменён владельцем** как избыточно сложный и не соответствующий цели упрощения/экономии. Не вводятся `PARTITION BY`, composite PK ради partition key, month-aware FK и `DROP PARTITION`. Simple history retention относится к тем же шести tables: `efhc_transfers_log`, `payment_intents`, `shop_orders`, `withdraw_requests`, `withdraw_outcome_events`, `ton_inbox_logs`. `unmatched_incoming` и mixed-retention `processed_external_events` остаются вне этого контура до отдельной classification; `referral_bonus_ledger` сохраняется forever.

Отдельный eternal financial-idempotency registry владельцем **не требуется**: после строгого 180-day barrier старое событие уже не может впервые изменить деньги. `tx_hash_locks` и ordinary external replay/idempotency target-retention — 180 суток; physical cleanup выполняется отдельным staged cycle.


### Schema reconciliation цикла 1766

Static reconciliation после green `v174.04` установил: supplied `sql/001_TARGET_GREENFIELD_SCHEMA.sql` содержит 13 `CREATE TABLE` при current baseline 56 ORM tables и сам объявлен authority только для объектов, изменяемых аудитом. Поэтому файл **не является полным replacement manifest для `0001`**; отсутствие таблицы в этом design artifact не является delete proof.

До deterministic rewrite требуется полный schema contract с сохранением всех production capabilities, которые не были явно retired. Отдельно должны быть устранены gaps supplied DDL: отсутствующие current-rank поля в `users`, referential-integrity model для `transfer_annotations`/financial idempotency при partitioned ledger и единая authority для permanent tx replay вместо параллельных registry.

Owner deletion decisions получены: разрешено удалить `panels_archive`; три `ranks_*` после переноса current rank в `users`; referral leaderboard surface; `users.id` после refactor; `users.tg_id` после retirement consumers; `users.ton_wallet` после перевода consumers на `wallet_bindings`. Эти решения не распространяются на другие compatibility surfaces.

## 10. Admin user operations по Global ID

Прямое решение владельца 2026-08-16: понятия prize/reward для цикла `1783` нет. Target — единый user-centric Admin action surface после выбора canonical `global_id`: «отправить», «забрать», «активировать». BANK↔user операция повторно использует `BankService.manual_bank_user_transfer`; EFHCb/EFHCm являются целевыми назначениями одной экономической единицы EFHC, default target — EFHCb, default amount — `100.00000000`, комментарий редактируемый с default `Admin перевод средств`. Платная активация повторно использует canonical `panels_service.activate_panel` с обычным bonus→main fallback, атомарным user→BANK списанием и созданием панели. Бесплатные Admin create/reactivate запрещены; `_create_new_panel` удаляется, legacy reactivate fail-closed. Transfer и paid activation подтверждаются отдельно и имеют разные idempotency keys. Candidate требует exact-head financial qualification.
Прямое уточнение владельца 2026-08-16 для цикла `1783`: выбранный `global_id` в `/admin/users` обязан показывать текущие канонические EFHCm/EFHCb balances и историю операций. Отдельный balance/ledger source запрещён: Admin history повторно использует `list_profile_history_page()` и тот же keyset максимум `50`; public `/profile/history` остаётся привязан к собственной user-session и не используется для Admin impersonation. После Admin write-action список и detail выбранного Global ID обновляются так, чтобы свежие balances/history оставались видимыми.


## 11. Sharding

Single PostgreSQL deployment остаётся production baseline первого launch. Shard-ready design допустим, но physical sharding выключен до отдельного решения по BANK_EFHC coordination и global external-replay authority. Population target порядка 100K users/shard является planning policy, а не доказанным hardware limit.

## 12. Staged implementation state

Квалифицировано/реализовано к green `v174.04`:
- process-local monotonic `ApplicationClock` для `app.lib.time.utcnow` и выбранных business elapsed paths;
- PostgreSQL lifetime-ID decimal-string JSON/OpenAPI/frontend boundary квалифицирован green `v174.04`;
- frontend elapsed display использует `performance.now()` на Dashboard/Panels;
- BASE↔VIP checkpoint в едином VIP writer path;
- explicit wallet detach освобождает binding; replay/idempotency windows ограничены 24h/7d;
- expired panel activation закрыта; admin create/reactivate limit-check сериализован по owner;
- owner-approved Profile History UI сохранён без ложной `50+50+50` реализации;
- source guards добавлены для staged invariants;
- цикл 1767: kWh ranking получил persistent DB claim по UTC business-day, scheduler boundary 02:00 UTC и canonical `DENSE_RANK`; user read-paths читают сохранённый snapshot и не запускают global refresh;
- Greenfield candidate `v174.07`: current rank перенесён в `users.rank_position/rank_score_kwh/rank_calculated_at`; три `ranks_*` storage tables retired по owner approval.
- Exact-head CI `86531880820` на `v174.09` полностью квалифицировал Greenfield identity/schema consolidation: `52 ORM / 53 physical`, `0001: ok`, physical BIGINT validators, pytest `1613 passed / 22 skipped / 1 warning`, все canonical gates `exit=0`. Цикл `1772` закрыт.

Реализовано/квалифицировано последующими staged cycles:
- unified 50-operation History + server CSV/XLSX — cycles 1780–1782;
- Admin user-centric BANK transfer + canonical paid panel activation — cycle 1783;
- 180-day external financial execution barrier + double trusted-time evidence — cycle 1774 qualified;
- 180-day replay cleanup + Simple Financial Retention 370/400 без partitioning — cycles 1777–1779;
- retention/index/performance audit без speculative schema changes — cycle 1784;
- Admin humanization, category analytics и Shop operator decomposition — cycles 1785–1787.

Отложено только до отдельного owner decision/evidence: physical sharding activation и новые performance/schema changes, если production metrics докажут необходимость.

### Цикл 1773 — frozen 0001 candidate

После green qualification физической схемы `v174.09` единственный `0001_initial_release_schema.py` переведён с зависимости от текущего ORM на migration-local frozen `RELEASE_METADATA`. Snapshot содержит 52 application tables (`45 efhc_core + 7 efhc_admin`), полный physical column surface и все 40 module-level ORM indexes. Migration не импортирует `app.models`, поэтому последующее изменение ORM не может молча изменить DDL уже замороженного `0001`. Existing clean-schema validation, physical BIGINT checks, identity/FK invariants, sequence ownership и initial seed logic сохранены.

CI `86541701491` на `v174.12` подтвердил Alembic frozen `0001`: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Полный HEAD пока не green только из-за трёх pytest traceability/portability drifts. Владелец 2026-08-16 утвердил frozen SQLAlchemy `RELEASE_METADATA` как окончательную форму deterministic `0001`; literal SQL DDL не требуется.

### Цикл 1774 — 180-day external financial execution barrier candidate

По прямому решению владельца staged runtime получает единый fail-closed порядок для внешнего первичного зачисления: `trusted operation time -> server first-seen check -> age < 180 days -> replay/idempotency -> money mutation -> ledger`. `trusted_operation_at` берётся из доверенного on-chain/provider источника; `server_first_seen_at` фиксируется сервером и не может заменить более старое trusted time. Reprocess обязан использовать сохранённое trusted time, а не синтезировать новое из времени повторной обработки.

На этом этапе replay/idempotency retention **не сокращается**. После exact-head GREEN barrier владелец сначала исследовал monthly partitioning, затем отменил его как неоправданно сложный. Current staged target — Simple Financial Retention без schema rewrite.

### Циклы 1775–1777 — retention foundation → Simple Retention supersession

`1775` и `1776` квалифицировали недеструктивный retention foundation и доказали, почему physical partitioning создаёт лишние PK/UNIQUE/FK blockers. Exact-head GREEN `v174.23` подтвердил основной контур. После этого владелец 2026-08-16 прямо отменил весь physical partitioning plan `1777–1779`.

Current cycle `1777` заменяет partition-specific planner на pure age-based Simple Financial Retention: execution window `180d`, history delete cutoff `370d`, cleanup trigger `400d`, six ordinary PostgreSQL history tables, lifecycle status не продлевает retention после cutoff. Active detailed SSOT: `docs/SSOT/FINANCIAL_RETENTION_CANON.md`. Production batch DELETE остаётся отдельным cycle `1778`; replay/idempotency cleanup — `1779`.

## 13. Verification boundary

`v174.06` квалифицирован GitHub CI `86497534419`, checkout `8e762d5df1c757bf56f840072cbb5ea2884a0605`; после этого владелец дал прямые deletion decisions по `panels_archive`, `ranks_*`, referral leaderboard и legacy/technical `users` columns. Exact-head CI `86531880820` на `v174.09` полностью квалифицировал итоговый ORM-driven clean `0001` и post-retirement runtime: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`, pytest `1613 passed / 22 skipped / 1 warning`, все canonical gates `exit=0`. Цикл `1772` закрыт. Green `v174.09` квалифицировал ORM-driven physical schema. Frozen `RELEASE_METADATA` утверждён владельцем как окончательная форма `0001`; CI `86541701491` на `v174.12` уже подтвердил Alembic frozen schema, а `v174.13` содержит только qualification repair трёх pytest policy/traceability drifts и ещё требует exact-head CI.

### Цикл 1774 — qualification hardening после CI v174.16

GitHub CI `86555575826` подтвердил, что P0 barrier suite реально блокирует qualification: smoke Alembic прошёл, но deep physical-parity test и security/static guards сделали общий pytest красным при обнаруженных расхождениях. Candidate `v174.17` не меняет financial runtime и не сокращает retention. Guard теперь проверяет фактический двухслойный контур `external time validation -> settlement branch -> canonical tx_hash claim -> повторный require_external_financial_execution -> replay INSERT -> money mutation`; PostgreSQL negative suite дополнительно проверяет missing/inverted/future evidence и binding точного replay к исходным time evidence. Monthly DROP и 180-day replay cleanup остаются запрещены до green exact-head CI этого усиленного контура.


### Исторический static preflight monthly financial partitioning — цикл 1774 (SUPERSEDED)

Этот раздел сохраняется как доказательство ранее обнаруженной сложности. Owner decision 2026-08-16 отменил physical monthly partitioning; его blockers больше не являются current implementation target.


До green exact-head qualification 180-day barrier физическая retention/partitioning остаётся выключенной. Static dependency audit шести утверждённых history tables установил:

- базовый partition key target — server-side `created_at` с месячными PostgreSQL RANGE partitions;
- текущие PK/UNIQUE `efhc_transfers_log.id/idempotency_key`, `payment_intents.id/(global_id,purpose,idempotency_key)/external_tx_hash`, `shop_orders.id/tx_hash/(global_id,idempotency_key)`, `withdraw_requests.id/idempotency_key/processing_idempotency_key/payout_ref`, `withdraw_outcome_events.id/withdraw_request_id`, `ton_inbox_logs.id/tx_hash` нельзя механически переносить в partitioned parent без включения partition key либо отдельной global authority;
- ordinary financial replay/idempotency authority должна сохраняться вне droppable history partitions на всё 180-дневное окно, но не FOREVER;
- blockchain `tx_hash` authority остаётся в `tx_hash_locks` до завершения 180 суток; только после green barrier допускается 180-day cleanup;
- `withdraw_outcome_events.withdraw_request_id -> withdraw_requests.id` требует month-aware referential contract при partitioning обеих таблиц; FK нельзя молча удалить;
- DROP старого месяца fail-closed: незавершённые/manual-review/unresolved financial records блокируют removal соответствующего history segment;
- `unmatched_incoming`, BANK/current balances, `processed_external_events` mixed-retention storage и referral bonus ledger не включаются в этот простой monthly DROP.

Это подготовительный design-proof; physical schema не меняется до следующего green CI.


## 14. Admin launcher / Shop decomposition — owner lock cycles 1785–1787

Прямое решение владельца 2026-08-16: главная Admin остаётся одной непрерывной сеткой ровно `20` плиток; смысловые блоки `4×5` не используются. Плитки различаются ненавязчивым category-color accent по системам. `Admin API Workbench` остаётся отдельным техническим модулем для будущего системного администратора.

Shop decomposition после exact-head аудита: отдельный модуль `Товары` **не создаётся**, потому что `/admin/shop` уже является каталогом товаров и общей обзорной страницей магазина. В сетке 20 используются прямые operator entry points `Заказы` → `/admin/shop?module=orders` и `Выдача / VIP NFT` → `/admin/shop?module=nft`; одна резервная плитка остаётся свободной. Эти плитки не создают новый backend route, ledger, payment flow или финансовую семантику: они только открывают существующие modes канонического Shop.
