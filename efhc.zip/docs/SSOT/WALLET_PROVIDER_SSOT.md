# WALLET PROVIDER SSOT

Status: ACTIVE.
Archive line: `v171.66`.
Cycle: `1574`.

## 1. Canonical architecture

EFHC WebApp consumes one application-owned wallet boundary:

```text
WalletProvider
├── TonConnectAdapter
├── TelegramWalletAdapter   (Wallet in Telegram)
└── NativeGramWalletAdapter (Native Gram Wallet)
```

Application pages, components and money-flow UI MUST depend on
`frontend/src/lib/wallet-provider/**`, not directly on an external wallet SDK.

TonConnect remains the currently operational adapter. It is not the application
architecture itself.

## 2. Adapter contract

Every adapter implements the same EFHC-owned contract:

- availability and session snapshot;
- restore-settled state;
- wallet discovery where supported;
- ownership-proof preparation;
- connect;
- verified backend binding;
- disconnect;
- TON-compatible transaction dispatch;
- provider-independent user-rejection classification.

The canonical transaction request is `TonWalletTransaction` from
`frontend/src/lib/ton/tx.ts`. It is an EFHC/TON-domain request and is not owned
by TonConnect.

## 3. Current adapters

### TonConnectAdapter

Maps the existing TonConnect SDK and existing verified TonProof/backend binding
onto the common `WalletAdapter` contract. Current production-like local flows
continue through this adapter by default.

### TelegramWalletAdapter

Stable integration boundary for a future official `Wallet in Telegram` API.
Until an official API surface is available and mapped, the adapter is
fail-closed and unavailable. No unpublished Telegram method, payload or event
name may be guessed and treated as official.

### NativeGramWalletAdapter

Stable integration boundary for a future native GRAM wallet runtime. Until an
authorized runtime bridge is installed, the adapter is fail-closed and
unavailable. It must not emulate a successful wallet, signature or transaction.

## 4. Bridge boundary

Unpublished/native APIs enter through `EfhcWalletAdapterBridgeV1`. The bridge
is installed only inside the corresponding adapter module. The rest of WebApp
must not know the external API shape.

When Telegram publishes or changes its wallet API, the required implementation
change is bounded to the relevant adapter/bridge mapping and its adapter tests.
Public pages, checkout, deposit, profile and admin payout flows remain on the
same `WalletProvider` contract.

## 5. Selection

Adapter selection order is:

1. explicit `NEXT_PUBLIC_EFHC_WALLET_PROVIDER`, if available;
2. previously selected available adapter;
3. current active adapter;
4. fallback order: TonConnect, Wallet in Telegram, Native Gram Wallet.

Valid configuration values:

- `tonconnect`;
- `telegram_wallet`;
- `native_gram_wallet`.

Unavailable configured adapters fail over to an available adapter; they are
never represented as connected.

## 6. Security and settlement truth

A frontend session or native bridge response is not settlement truth.

Mandatory invariants:

- no seed phrase or private key is requested, stored or logged;
- ownership binding remains backend-verified;
- proof nonce, expiry, domain, signature and replay rules remain authoritative;
- transaction signing does not equal inclusion, confirmation or settlement;
- backend/on-chain reconciliation remains the only business settlement truth;
- duplicate/replayed events cannot produce duplicate credit;
- adapter availability cannot bypass WalletGate or authorization;
- a bridge cannot independently mark a financial operation settled.

## 7. Evidence boundary

This architecture proves local code separation only. It does not prove:

- existence of an unpublished Telegram wallet API;
- a live Telegram wallet connection;
- a real native GRAM signature;
- a real transaction broadcast, confirmation or settlement.

Those remain external release/post-release verification items.
