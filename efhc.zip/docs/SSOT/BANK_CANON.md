# EFHC BANK CANON / SSOT

Статус: **ACTIVE CANON / SSOT**  
Версия решения: **v173.31 / emergency cleanup cycle 1707**  
Q/A evidence: `docs/GENERAL/BANK_QUESTIONS_ANSWERS_REGISTRY.md`

## 1. Назначение BANK_EFHC

`BANK_EFHC` — единый Центральный банк всего приложения EFHC.

Через него должны проходить все внутренние денежные движения EFHC. Экономические подсистемы не имеют права создавать или уничтожать пользовательский баланс прямым изменением `users.main_balance` / `users.bonus_balance` в обход банковского сервиса.

Главная модель — **параллельная финансовая реальность**:

- внешнее движение подтверждается во внешней системе;
- внутренний банк отражает ему соответствующую противоположную внутреннюю проводку;
- внешняя транзакция не создаёт второй внутренний денежный баланс, а является settlement/evidence для связанной банковской операции.

## 2. Идентичность Центрального банка

Банк является самостоятельной системной сущностью, а не пользователем.

Каноническая банковская сторона записи:

```text
global_id     = NULL
system_entity = BANK_EFHC
tg_id         = NULL
```

Запрещено для новых операций:

- создавать фиктивного пользователя `BANK_EFHC`;
- назначать банку пользовательский `global_id`;
- использовать Telegram `tg_id` как ID банка;
- использовать numeric ENV alias как owner новой банковской проводки.

`global_id` идентифицирует владельца пользовательского аккаунта. Он не является обязательным номером бухгалтерского счёта каждой системной сущности.

Numeric `BANK_EFHC` ENV запрещён. Банк не имеет цифрового user/provider alias; единственная идентичность банка в ledger — `system_entity=BANK_EFHC`.

## 3. Единственный счёт банка

SSOT банковского баланса:

```text
efhc_core.bank_balance
key = EFHC_MAIN
```

Канонический стартовый баланс:

```text
5 000 000.00000000 EFHC
```

Банк хранит **один единый EFHC balance**. Отдельного банковского BONUS-счёта нет.

Баланс `BANK_EFHC` может быть отрицательным. Отрицательный баланс сам по себе не блокирует операцию, поскольку модель допускает внешнее обеспечение.

## 4. MAIN и BONUS пользователя

`EFHCm` и `EFHCb` — одна экономическая сущность EFHC с разным целевым назначением на стороне пользователя.

- `main_balance` (`EFHCm`) — выводимый баланс;
- `bonus_balance` (`EFHCb`) — невыводимый баланс;
- при возврате средств в Центральный банк различие MAIN/BONUS исчезает: банк получает просто EFHC в `EFHC_MAIN`.

Следовательно:

```text
USER MAIN  -X -> BANK EFHC +X
USER BONUS -X -> BANK EFHC +X
```

## 5. Главный закон проводок

Любое пользовательское начисление:

```text
BANK_EFHC debit  X
USER      credit X
```

Любое системное списание пользователя:

```text
USER      debit  X
BANK_EFHC credit X
```

Обе стороны являются частями одного логического экономического события и связываются idempotency/mirror metadata.

### 5.1 Ledger representation

Пользовательская строка:

```text
global_id     = USER_GLOBAL_ID
system_entity = NULL
```

Банковская зеркальная строка:

```text
global_id     = NULL
system_entity = BANK_EFHC
tg_id         = NULL
balance_type  = main
```

`efhc_core.efhc_transfers_log` является canonical audit/idempotency ledger банковских движений.

## 6. Запрет P2P

Прямые переводы `USER_A -> USER_B` запрещены системой.

Если когда-либо требуется административная корректировка между двумя пользователями, она может быть выражена только как две отдельные банковские операции:

```text
USER_A -> BANK_EFHC
BANK_EFHC -> USER_B
```

Это не пользовательский P2P-механизм.

## 7. Внешний депозит

После того как внешняя транзакция подтверждена и пользователь разрешён:

```text
EXTERNAL USER -> PROJECT EXTERNAL WALLET
BANK_EFHC      -> USER EFHCm
```

Внутренняя операция:

```text
BANK_EFHC debit X
USER MAIN credit X
```

В ledger/evidence сохраняются доступные внешние атрибуты, включая:

- `tx_hash`;
- внешний sender/address;
- receiver/address;
- payment intent / memo при наличии;
- `external_settlement=received`;
- `settlement_status=confirmed`.

Внешний депозит не является `mint`: пользователь получает сумму из внутреннего баланса банка.

## 8. Withdraw

При создании/принятии hold вывода внутренняя финансовая операция:

```text
USER MAIN debit X
BANK_EFHC credit X
```

После разрешённого admin/operator payout-action внешний перевод **не списывает EFHC внутри второй раз**.

EFHC Bot V1 считает выплату выполненной по разрешённому payout action и переводит заявку в `PAID`. Обязательный backend blockchain watcher proof после payout не требуется.

TON-транзакция после отправки считается внешним процессом; система по умолчанию считает утверждённую payout-операцию выплаченной согласно `WITHDRAW_FLOW_NORM`.

Если заявка отменена/отклонена до завершённой выплаты, возврат выполняется отдельной компенсирующей операцией:

```text
BANK_EFHC debit X
USER MAIN credit X
```

Исходная проводка не удаляется и не переписывается.

Связанный norm: `docs/NORM/WITHDRAW_FLOW_NORM.md`.

## 9. Reversal / исправление ошибочных операций

Историческая денежная запись неизменяема по экономическому смыслу.

Запрещено исправлять ошибку удалением исходной проводки или переписыванием её суммы/направления.

Коррекция создаётся отдельной compensating/reversal operation с противоположным движением средств и ссылкой на исходную операцию.

## 10. Mint и Burn

### Обычная экономика

Обычные начисления и списания **никогда не являются mint/burn**. Они всегда являются проводками `BANK <-> USER`.

### Аварийный резерв

Пользователь утвердил сохранение существующих admin `Mint` и `Burn` как аварийных механизмов управления резервным балансом Центрального банка.

Они:

- доступны только существующему привилегированному admin-контуру;
- не являются обычным экономическим маршрутом приложения;
- изменяют только резерв `efhc_core.bank_balance[EFHC_MAIN]`;
- обязаны оставлять запись в canonical ledger/admin audit;
- не используются как замена возврату пользовательских средств в банк.

## 11. Все подсистемы экономики

После завершения emergency economy repair все источники пользовательских EFHC должны двигать деньги через `transactions_service`:

- Energy / Exchange;
- Panels;
- tasks/rewards;
- referrals;
- ranks/achievements;
- compensation;
- Shop и покупки;
- deposits;
- withdrawals/refunds;
- admin manual corrections;
- любые другие balance-affecting domains.

Ни один domain не должен самостоятельно «нарисовать» пользовательский EFHC без противоположной банковской стороны.

## 12. Idempotency

Каждая денежная операция обязана иметь стабильный `idempotency_key`.

Повтор того же события не должен повторно менять пользовательский или банковский баланс.

Банковская mirror-строка использует связанный mirror idempotency key и сохраняет связь с пользовательской операцией через metadata.

## 13. Админ-панель

Не вводится новая самостоятельная банковская админ-панель вместо существующей.

Сохраняются уже реализованные маршруты и функции admin bank surface:

- просмотр банковского баланса;
- Bank ↔ User операции;
- история;
- reversal/rollback через compensating transaction;
- аварийные Mint/Burn;
- существующие RBAC ограничения и admin logging.

Emergency BANK repair меняет только identity/storage банковской стороны и не расширяет полномочия администратора.

## 14. Bootstrap / migration

Production bootstrap обязан создавать/сохранять:

```text
efhc_core.bank_balance[key=EFHC_MAIN]
```

с начальным значением `5 000 000 EFHC`, только если запись отсутствует.

Bootstrap больше не обязан создавать `BANK_EFHC` в `efhc_core.users`.

Для существующих pre-release БД:

- `efhc_transfers_log.system_entity` добавляется в существующую единственную migration `0001_initial_release_schema.py`;
- банковские mirror-строки имеют только `system_entity=BANK_EFHC`; numeric/provider aliases и `bank_alias_tg_id` не являются частью действующей схемы;
- старые numeric-bank rows разрешены только для historical read-through;
- существующую старую строку system user не удалять автоматически в emergency patch, чтобы не выполнять разрушительную cleanup-операцию.

## 15. Жёсткие запреты

Запрещено:

- P2P user-to-user;
- прямой balance UPDATE вне canonical money service;
- пользовательский отрицательный MAIN/BONUS;
- блокировать движение только из-за отрицательного bank balance;
- использовать `tg_id` как owner банка;
- выдавать банку фиктивный пользовательский `global_id`;
- создавать новые банковские mirror rows с обоими owner-полями NULL без `system_entity=BANK_EFHC`;
- использовать Burn вместо нормальной проводки USER → BANK;
- требовать обязательный blockchain watcher proof для V1 `PAID` после разрешённого payout action;
- удалять исторические проводки вместо reversal.
