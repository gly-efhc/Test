# BANK CANON

Статус: CANON / SSOT (банковый канон).
Якорь SSOT: `docs/SSOT/SSOT_INDEX.md`

Короткий жёсткий канон банкового контура EFHC.

## Истина

- банковый ключ баланса: `EFHC_MAIN`;
- `BANK_EFHC` — логический alias для mirror-log, а не реальное хранилище bank balance;
- банк может уходить в минус;
- пользовательские балансы в минус уходить не могут.

## Направления проводок

- `user credit ⇒ bank debit`
- `user debit ⇒ bank credit`

Других смыслов у проводок нет.

## Границы балансов

- внешнее пополнение EFHC идёт только в `main_balance`;
- вывод возможен только из `main_balance`;
- `bonus_balance` тратится на всё, кроме вывода;
- внутренние траты EFHC идут по канону `bonus -> main`.

## Критические таблицы

- `efhc_core.bank_balance`
- `efhc_core.efhc_transfers_log`
- `efhc_core.withdraw_requests`
- `efhc_admin.admin_action_log`

## Недопустимо

- ручной SQL-апдейт денег вне сервисного контура;
- смешение `main` и `bonus` в выводе;
- обход idempotency для денежных POST.

## Дефицит банка: operational boundary

- Отрицательный баланс банка сам по себе не является дефектом, если он
  укладывается в проектный канон внешнего обеспечения.
- Инцидентом считается не сам минус банка, а неканоничные ошибки:
  `insufficient bank balance`, неучтённые двойные проводки, отсутствие
  idempotency, повторная обработка external events и потеря audit trail.
- Корректировки выполняются только через сервисный контур и admin actions,
  а не ручным SQL.
