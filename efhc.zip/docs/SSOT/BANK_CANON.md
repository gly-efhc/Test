# CURRENT FORMULA AUTHORITY — cycle 1804 / Admin → Банк

- Полный active формульный канон страницы Admin → Банк: `docs/NORM/BANK_METRICS_INTEGER_SNAPSHOT.md`.
- Этот документ фиксирует все 11 строк Балансовой карты, блок `Целостность системы`, canonical DB sources, `expected_supply`, `integrity_delta`, percentage denominators, D8/percentage rounding, zero-denominator semantics и protective-void exclusions.
- `efhc_core.bank_metrics_snapshot` остаётся единственной read authority готовой Bank-математики для frontend; первичная финансовая истина остаётся в canonical BANK/user/Panel/ledger sources.
- FRONTEND_v182 не пересчитывает финансовые формулы: он отображает готовые snapshot facts и выполняет только presentation formatting.

# CURRENT BANK LINK — v174.61 / protective Panels

- `BANK_EFHC` остаётся единственным денежным контрагентом системных Panel операций.
- Обычная/повторная активация Панели: `USER → BANK`, цена `100.00000000 EFHC`, порядок пользовательского списания `EFHCb → EFHCm`.
- Protective Admin-deactivation: `BANK → USER` только на вычисленный `NET = 100 - R`; refund split формируется из historical payment split с offset сначала EFHCb, затем EFHCm.
- Уже выполненные исторические `kWh → EFHCm`/Withdraw не переписываются; economic void отражается уменьшением текущих energy aggregates и меньшим Panel refund.
- `bank_metrics_snapshot` является обязательной read authority готовых Admin Bank показателей; dead Panels исключаются из Panel-row generated/fixed aggregates. Для `panel_spent` каждая protective deactivation полностью аннулирует исходный Panel spend `B+M=100`: activation/reactivation user debit уменьшается на полный исторический payment split из canonical protective event. Фактический NET refund остаётся неизменяемой BANK ledger history и не подменяет Panel aggregate.
- Snapshot refresh выполняется server-side при открытии Admin/модулей; browser fallback finance запрещён.
- Protective service transaction-neutral; commit/rollback принадлежит Admin route.

## CURRENT — v174.60 / Admin Bank integer snapshot

- Owner-approved `efhc_core.bank_metrics_snapshot` materializes server-calculated Admin Bank metrics as D8 BIGINT values and D8-scaled percentages.
- BANK/ledger tables remain the primary financial truth; browser/frontend must not reconstruct Bank formulas from capped lists or floating-point arithmetic.
- Snapshot refresh service is transaction-neutral; `/admin/reports/overview` owns commit/rollback.
- FRONTEND_v182 renders `bank_metrics_*` facts from the server snapshot.
- Current application DB surface: 53 ORM tables; this single owner-approved table does not globally unlock schema changes.

# EFHC BANK CANON / SSOT

Статус: **ACTIVE CANON / SSOT**  
Версия решения: **v173.73 / cycle 1744**  
Q/A evidence: `docs/GENERAL/BANK_QUESTIONS_ANSWERS_REGISTRY.md`

## 1. Назначение BANK_EFHC

`BANK_EFHC` — единый Центральный банк всего приложения EFHC.

Через него должны проходить все внутренние денежные движения EFHC. Экономические подсистемы не имеют права создавать или уничтожать пользовательский баланс прямым изменением `users.main_balance` / `users.bonus_balance` в обход банковского сервиса.

Главная модель — **параллельная финансовая реальность**:

- внешнее движение подтверждается во внешней системе;
- внутренний банк отражает ему соответствующую противоположную внутреннюю проводку;
- внешняя транзакция не создаёт второй внутренний денежный баланс, а является settlement/evidence для связанной банковской операции.

## 2. Идентичность Центрального банка

Банк является самостоятельной системной сущностью, а не пользователем.

Каноническая банковская сторона записи:

```text
global_id     = NULL
system_entity = BANK_EFHC
tg_id         = NULL
```

Запрещено для новых операций:

- создавать фиктивного пользователя `BANK_EFHC`;
- назначать банку пользовательский `global_id`;
- использовать Telegram `tg_id` как ID банка;
- использовать numeric ENV alias как owner новой банковской проводки.

`global_id` идентифицирует владельца пользовательского аккаунта. Он не является обязательным номером бухгалтерского счёта каждой системной сущности.

Numeric `BANK_EFHC` ENV запрещён. Банк не имеет цифрового user/provider alias; единственная идентичность банка в ledger — `system_entity=BANK_EFHC`.

## 3. Единственный счёт банка

SSOT банковского баланса:

```text
efhc_core.bank_balance
key = EFHC_MAIN
```

Канонический стартовый баланс:

```text
5 000 000.00000000 EFHC
```

Банк хранит **один единый EFHC balance**. Отдельного банковского BONUS-счёта нет.

Для обычных non-emission движений действует контроль денежной массы: `SUM(users.main_balance) + SUM(users.bonus_balance) + BANK_EFHC = const`. Этот invariant отвечает на вопрос «сколько EFHC сейчас», а ledger отвечает на вопрос «почему состояние стало таким».

Баланс `BANK_EFHC` может быть отрицательным. Отрицательный баланс сам по себе не блокирует операцию, поскольку модель допускает внешнее обеспечение.

## OWNER LOCK 2026-08-16 — целевое назначение EFHCm / EFHCb

Суффиксы `m` и `b` в `EFHCm` / `EFHCb` являются индикатором целевого назначения одной и той же экономической единицы EFHC на стороне пользователя. Они не создают два разных банковских актива.

Для ручной операции Admin по Global ID оператор выбирает целевое назначение: `EFHCb` (`bonus_balance`) или `EFHCm` (`main_balance`). По умолчанию UI выбирает `EFHCb`. Любое начисление идёт из единого `BANK_EFHC`, любое изъятие возвращается в тот же единый `BANK_EFHC`.

## 4. MAIN и BONUS пользователя

`EFHCm` и `EFHCb` — одна экономическая сущность EFHC с разным целевым назначением на стороне пользователя.

- `main_balance` (`EFHCm`) — выводимый баланс;
- `bonus_balance` (`EFHCb`) — невыводимый баланс;
- при возврате средств в Центральный банк различие MAIN/BONUS исчезает: банк получает просто EFHC в `EFHC_MAIN`.

Следовательно:

```text
USER MAIN  -X -> BANK EFHC +X
USER BONUS -X -> BANK EFHC +X
```

## 5. Главный закон проводок

Любое пользовательское начисление:

```text
BANK_EFHC debit  X
USER      credit X
```

Любое системное списание пользователя:

```text
USER      debit  X
BANK_EFHC credit X
```

Обе стороны являются частями одного логического экономического события и связываются idempotency/mirror metadata.

### 5.1 Ledger representation

Пользовательская строка:

```text
global_id     = USER_GLOBAL_ID
system_entity = NULL
```

Банковская зеркальная строка:

```text
global_id     = NULL
system_entity = BANK_EFHC
tg_id         = NULL
balance_type  = main
```

`efhc_core.efhc_transfers_log` является canonical audit/idempotency ledger банковских движений.

## 6. Запрет P2P

Прямые переводы `USER_A -> USER_B` запрещены системой.

Если когда-либо требуется административная корректировка между двумя пользователями, она может быть выражена только как две отдельные банковские операции:

```text
USER_A -> BANK_EFHC
BANK_EFHC -> USER_B
```

Это не пользовательский P2P-механизм.

## 7. Внешний депозит

После того как внешняя транзакция подтверждена и пользователь разрешён:

```text
EXTERNAL USER -> PROJECT EXTERNAL WALLET
BANK_EFHC      -> USER EFHCm
```

Внутренняя операция:

```text
BANK_EFHC debit X
USER MAIN credit X
```

В ledger/evidence сохраняются доступные внешние атрибуты, включая:

- `tx_hash`;
- внешний sender/address;
- receiver/address;
- payment intent / memo при наличии;
- `external_settlement=received`;
- `settlement_status=confirmed`.

Внешний депозит не является `mint`: пользователь получает сумму из внутреннего баланса банка.

## 8. Withdraw

При создании/принятии hold вывода внутренняя финансовая операция:

```text
USER MAIN debit X
BANK_EFHC credit X
```

После разрешённого admin/operator payout-action внешний перевод **не списывает EFHC внутри второй раз**.

EFHC Bot V1 считает выплату выполненной по разрешённому payout action и переводит заявку в `PAID`. Обязательный backend blockchain watcher proof после payout не требуется.

TON-транзакция после отправки считается внешним процессом; система по умолчанию считает утверждённую payout-операцию выплаченной согласно `WITHDRAW_FLOW_NORM`.

Если заявка отменена/отклонена до завершённой выплаты, возврат выполняется отдельной компенсирующей операцией:

```text
BANK_EFHC debit X
USER MAIN credit X
```

Исходная проводка не удаляется и не переписывается.

Связанный norm: `docs/NORM/WITHDRAW_FLOW_NORM.md`.

## 9. Reversal / исправление ошибочных операций

Историческая денежная запись неизменяема по экономическому смыслу.

Запрещено исправлять ошибку удалением исходной проводки или переписыванием её суммы/направления.

Коррекция создаётся отдельной compensating/reversal operation с противоположным движением средств и ссылкой на исходную операцию.

## 10. Mint и Burn

### Обычная экономика

Обычные начисления и списания **никогда не являются mint/burn**. Они всегда являются проводками `BANK <-> USER`.

### Аварийный резерв

Пользователь утвердил сохранение существующих admin `Mint` и `Burn` как аварийных механизмов управления резервным балансом Центрального банка.

Они:

- доступны только существующему привилегированному admin-контуру;
- не являются обычным экономическим маршрутом приложения;
- изменяют только резерв `efhc_core.bank_balance[EFHC_MAIN]`;
- обязаны оставлять запись в canonical ledger/admin audit;
- не используются как замена возврату пользовательских средств в банк.

## 11. Все подсистемы экономики

После завершения emergency economy repair все источники пользовательских EFHC должны двигать деньги через `transactions_service`:

- Energy / Exchange;
- Panels;
- tasks/rewards;
- referrals;
- ranks/achievements;
- compensation;
- Shop и покупки;
- deposits;
- withdrawals/refunds;
- admin manual corrections;
- любые другие balance-affecting domains.

Ни один domain не должен самостоятельно «нарисовать» пользовательский EFHC без противоположной банковской стороны.

## 12. Idempotency

Каждая денежная операция обязана иметь стабильный `idempotency_key`.

Повтор того же события не должен повторно менять пользовательский или банковский баланс. Для внешнего события перед ordinary idempotency/replay обязательно выполняется строгая 180-дневная trusted-time validation. После 180 суток внешнее событие не может впервые изменить деньги, даже если replay record уже удалён последующим retention stage.

Банковская mirror-строка использует связанный mirror idempotency key и сохраняет связь с пользовательской операцией через metadata.

## 13. Админ-панель

Не вводится новая самостоятельная банковская админ-панель вместо существующей.

Сохраняются уже реализованные маршруты и функции admin bank surface:

- просмотр банковского баланса;
- Bank ↔ User операции;
- история;
- reversal/rollback через compensating transaction;
- аварийные Mint/Burn;
- существующие RBAC ограничения и admin logging.

Emergency BANK repair меняет только identity/storage банковской стороны и не расширяет полномочия администратора.

## 14. Bootstrap / migration

Production bootstrap обязан создавать/сохранять:

```text
efhc_core.bank_balance[key=EFHC_MAIN]
```

с начальным значением `5 000 000 EFHC`, только если запись отсутствует.

Bootstrap больше не обязан создавать `BANK_EFHC` в `efhc_core.users`.

Для существующих pre-release БД:

- `efhc_transfers_log.system_entity` добавляется в существующую единственную migration `0001_initial_release_schema.py`;
- банковские mirror-строки имеют только `system_entity=BANK_EFHC`; numeric/provider aliases и `bank_alias_tg_id` не являются частью действующей схемы;
- старые numeric-bank rows разрешены только для historical read-through;
- существующую старую строку system user не удалять автоматически в emergency patch, чтобы не выполнять разрушительную cleanup-операцию.

## 15. Жёсткие запреты

Запрещено:

- P2P user-to-user;
- прямой balance UPDATE вне canonical money service;
- пользовательский отрицательный MAIN/BONUS;
- блокировать движение только из-за отрицательного bank balance;
- использовать `tg_id` как owner банка;
- выдавать банку фиктивный пользовательский `global_id`;
- создавать новые банковские mirror rows с обоими owner-полями NULL без `system_entity=BANK_EFHC`;
- использовать Burn вместо нормальной проводки USER → BANK;
- требовать обязательный blockchain watcher proof для V1 `PAID` после разрешённого payout action;
- удалять исторические проводки вместо reversal.

## Цикл 1743 — атомарность Admin money + audit и строгая идемпотентность

Для state-changing Admin bank operations денежная проводка и обязательный
`admin_action_log` принадлежат одной root DB transaction. Внутренний
notification outbox сохраняется до того же commit; Telegram/network delivery
разрешён только после commit и не является частью денежной атомарности.

Повторный `Idempotency-Key` является read-through только при точном совпадении
canonical payload: owner + operation family/reason + direction + balance type
+ amount. Несовпадение возвращает
`IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD` (`HTTP 409` на Admin API) и
не маскируется успешным ответом старой операции.

Rollback — отдельная компенсирующая операция. `balance_type` определяется
исключительно из исходной ledger-строки (`main → REGULAR`, `bonus → BONUS`).
Caller не имеет права перенаправлять rollback на другой тип баланса.


## Цикл 1744 — canonical Admin Bank reversal surface

`rollback_bank_user_tx` является частью существующего Admin Bank surface, а
не dead code. Public operation использует исходный `transfer_log_id` как
business identity reversal.

Перед компенсацией исходная ledger row блокируется `FOR UPDATE`. Reversal
разрешён только для исходной **user-side Admin manual** проводки. Bank mirror,
уже компенсирующая запись и произвольная non-admin ledger row не являются
допустимым source. Amount, обратное direction и `balance_type` всегда
выводятся из исходной ledger row; caller не может их заменить.

На один source `transfer_log_id` допускается не более одной compensating
operation. Внутренняя business idempotency compensation детерминирована:
`admin_bank_rollback:<transfer_log_id>`. Новый внешний HTTP
`Idempotency-Key` не создаёт право повторно компенсировать тот же source;
он сохраняется как request/audit attribute. Exact повтор является read-through
существующей compensation после проверки source/amount/direction/balance.

Компенсация использует тот же атомарный Admin money contour: ledger +
обязательный `admin_action_log` + notification outbox фиксируются одной root
transaction; Telegram/network delivery допускается только после commit.

## Цикл 1744 — Shop domain transaction boundary

Внутренняя покупка Shop за EFHC не может коммитить Bank debit отдельно от
`shop_order`. Domain обязан использовать caller-owned nocommit money primitive
и выполнить единственный root commit после успешной записи/проверки order.
Любая ошибка до commit откатывает и USER↔BANK движение, и Shop order.

## Cycle 1794 — Financial Audit №3 Admin/fees lock

Owner-Decision-Refs: `QA-2026-08-19-FIN3-02`, `FIN3-07`, `FIN3-10`.

EFHC business commission отсутствует. Deposit network fee платит пользователь; withdrawal network fee платит проект.
`SHOP_FORCE_FULFILL` является ручной денежной Admin operation: actor/reason обязательны, money mutation + order state + required `admin_action_log` фиксируются одной transaction; audit failure обязан откатить финансовое действие.
Фраза owner decision об Admin authority не отменяет RBAC/audit.
