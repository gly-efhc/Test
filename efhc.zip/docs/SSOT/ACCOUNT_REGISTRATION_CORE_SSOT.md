<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Account Registration Core SSOT — v172.56

## Единственный центр создания account

`backend/app/identity/account_registration.py` является единственным
runtime-местом создания действительно нового `efhc_core.users`.

Callers:

- Telegram Bot `/start`;
- Telegram WebApp initData session;
- TON Proof registration.

`PostgreSQLIdentityResolver` сначала определяет existing identity или
conflict. Provider-specific identity, wallet binding и session остаются в
профильных сервисах, но новый `User` создаётся только общим core.

## Referral attribution

- нормализация едина;
- invalid/missing code — fail closed до commit;
- существующему account late binding запрещён;
- `ReferralLink` создаётся атомарно с `User`;
- canonical owner fields — `inviter_global_id` и `invitee_global_id`;
- Telegram provider fields сохраняются, но `invitee_tg_id` nullable для
  TON-first account;
- уникальность `invitee_global_id` запрещает вторую attribution;
- self-ref проверяется по provider ID до вставки и по `global_id` после
  получения sequence-backed owner.

## Transaction boundary

Registration core не выполняет `commit()` или `rollback()`. Caller владеет
общей транзакцией user + referral + identity/binding + session. Любая
последующая provider-ошибка откатывает весь новый account.

## Corrective qualification v172.56

Exact CI `83583696254` подтвердил production registration runtime; один
failure находился в test fixture, которая назначала существующему TON-first
account новый `global_id` и сразу добавляла `ReferralCode`. Fixture теперь
выполняет явный `flush()` между UPDATE пользователя и INSERT кода. Production
core, ORM и FK не менялись.

```text
ACCOUNT_REGISTRATION_CORE_READY
BOT_REGISTRATION_USES_SINGLE_CENTER
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
```
