# ТЕКУЩИЙ OWNER AMENDMENT — cycle 1813 / document language boundary

Маркер: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`.

Для `documents`, `reports`, `cycles` и owner-facing `chat` используется русский
описательный текст; `technical terms` и `concepts` сохраняются на English.
`Document language policy` не управляет `source code`, `identifiers`,
`test names`, `comments`, `docstrings` или `machine literals`. Если guard
заходит в source code, исправляется `guard scope`, а не code.

Direct OWNER permission позволяет закрепить это правило в AI layer и Healer.

# AI_ARCHIVE_LAWS_CANON

Status: CANON / SSOT.
Cycle: 1813.
Archive: v174.73.

## Canonical source

The only full law text is `docs/AI/AI_ARCHIVE_LAWS.md`.

Lock: `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`.

Current SHA-256:

```text
321a43fe23002d6d7c8243f374ec26263da33737242a1f91cdd1168c29919a8d
```

The v171.62 amendment was made with direct user permission and restores Operator Kernel as a full detailed dispatch layer while preserving `START_HERE.md` as the single startup order. It requires YAML-primary runtime routing, project keywords, bounded machine-index use and behavior guards against demotion/drift.

The v174.21 amendment was made with direct user permission after a verification-integrity incident. It requires final-source revalidation before every owner-facing factual claim, exact final artifact read-back after the last write, post-write SHA-256/size, exact-run CI revalidation, and explicit `UNVERIFIED` status when revalidation is unavailable. The incident and operational rule are anchored in `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md`.

## Priority

AI Archive Laws bind AI docs, CANON, SSOT, NORM, Kernel, Healer, tests, CI, reports and packaging. Changes require direct user permission and synchronized lock/canon/guard updates.

## Invariant

Repair root cause; never weaken protection, fabricate evidence, create duplicate truth sources, force full archive reading where a precise route exists, or withhold the required development archive.


## Owner amendment — historical Q/A recovery

При прямом owner order полный historical Q/A recovery требует scan всех доступных numbered chat transcripts, append-only регистрации доказуемых ответов и явной маркировки unresolved/context-incomplete evidence. Архив не заменяет чат как канал согласования.
