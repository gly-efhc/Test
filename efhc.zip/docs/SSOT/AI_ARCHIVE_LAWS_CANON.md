# AI_ARCHIVE_LAWS_CANON

Status: CANON / SSOT.
Cycle: 1573.
Archive: v171_62.

## Canonical source

The only full law text is `docs/AI/AI_ARCHIVE_LAWS.md`.

Lock: `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`.

Current SHA-256:

```text
d8b01f95f1fa0d7e1845d0f73b14a0c84904a89a98a3ba754ea8ad101a72c7d8
```

The v171.62 amendment was made with direct user permission and restores Operator Kernel as a full detailed dispatch layer while preserving `START_HERE.md` as the single startup order. It requires YAML-primary runtime routing, project keywords, bounded machine-index use and behavior guards against demotion/drift.

## Priority

AI Archive Laws bind AI docs, CANON, SSOT, NORM, Kernel, Healer, tests, CI, reports and packaging. Changes require direct user permission and synchronized lock/canon/guard updates.

## Invariant

Repair root cause; never weaken protection, fabricate evidence, create duplicate truth sources, force full archive reading where a precise route exists, or withhold the required development archive.
