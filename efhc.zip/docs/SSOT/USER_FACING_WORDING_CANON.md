# User-facing wording canon

Этот документ фиксирует допустимые и запрещённые формулировки для
user-facing слоя EFHC Bot: FAQ, bot/help, WebApp UI, locale labels,
user-facing docs и публичные описания функций.

## Главный принцип

User-facing text for players must be:
- English-first by default
- neutral
- clear
- short
- technically precise
- free from investment-toxic wording
- free from internal developer language

Admin/operator UI lives under a separate Russian-first canon and must
not be mixed into player-facing wording decisions.

## Запрещённые формулировки

### Запрещённый ряд покупок
- купить
- покупка
- купить панель
- купить EFHC

### Запрещённый инвестиционный ряд
- заработать
- заработал
- заработанные
- заработай
- доход
- доходность
- инвестиция
- инвестировать
- прибыль
- дивиденд
- депозит
- покупательная способность

### Запрещённые user-facing слова для panels
- цена
- цена панели

## Канонические нейтральные замены

### Panels
- купить панель -> активировать панель
- покупка панели -> активация панели
- цена панели -> для активации панели необходимо 100 EFHC
- активные панели -> Active
- архивные панели -> Archive
- деактивированные панели -> архивные панели

### Permanent account status labels
- постоянный активный статус аккаунта -> `Activ`
- VIP-статус -> `VIP`
- `Activ` and `VIP` remain English and unchanged in all 13 locales.
- `Active` is not the account-status label. It remains allowed only as a generic English word or a canonical tab/list label such as active panels or active referrals.

### EFHC / Hub
- купить EFHC -> пополнить EFHC
- покупка EFHC -> пополнение EFHC
- депозит EFHC -> пополнение EFHC

### Exchange
- заработанные кВт -> сгенерированные кВт
- заработать EFHC -> получить EFHC через игровую логику проекта

## Дополнительные правила

- Внутренние developer-формулы не переносятся в FAQ без отдельного
  согласования.
- Все новые и изменённые FAQ сначала согласуются на русском языке как на source-of-meaning уровне; player-facing runtime fallback при отсутствии качественной локали остаётся English.
- Любая замена вопроса/ответа проходит через явный replacement protocol.
