# User-facing wording canon

Этот документ фиксирует допустимые и запрещённые формулировки для
user-facing слоя EFHC Bot: FAQ, bot/help, WebApp UI, locale labels,
user-facing docs и публичные описания функций.

## Главный принцип

User-facing text for players must be:
- English-first by default
- neutral
- clear
- short
- technically precise
- free from investment-toxic wording
- free from internal developer language

Admin/operator UI lives under a separate Russian-first canon and must
not be mixed into player-facing wording decisions.

## PUBLIC_UI_COPY_RESTRICTION

Ограничения этого раздела действуют только в player-facing/display
слоях.

Это НЕ repo-wide forbidden vocabulary.

Те же слова могут использоваться в engineering documentation,
backend/API, Admin, diagnostics, accounting explanations и historical
evidence, если это соответствует их реальному техническому смыслу.

### Ограниченный ряд торговых формулировок

В player-facing EFHC wording использовать нейтральный продуктовый язык:

- `купить EFHC` → `пополнить EFHC`;
- `покупка EFHC` → `пополнение EFHC`;
- `депозит EFHC` → `пополнение EFHC`.

### Инвестиционно-доходный ряд

Без отдельного OWNER approval не использовать player-facing
формулировки, которые представляют EFHC как обещание инвестиционного
дохода:

- заработать;
- заработал;
- заработанные;
- заработай;
- доход;
- доходность;
- инвестиция;
- инвестировать;
- прибыль;
- дивиденд;
- покупательная способность — если формулировка создаёт обещание
  инвестиционной доходности.

### Panels

Для пользовательского описания панели действует отдельный product
wording contract:

- `купить панель` → `активировать панель`;
- `покупка панели` → `активация панели`;
- `цена панели` → `для активации панели необходимо ...`.

Это semantic/product wording restriction, а не gambling ban и не
глобальный лексический запрет.

## Канонические нейтральные замены

### Panels
- активные панели -> Active
- архивные панели -> Archive
- деактивированные панели -> архивные панели

### Permanent account status labels
- постоянный активный статус аккаунта -> `Activ`
- VIP-статус -> `VIP`
- `Activ` and `VIP` remain English and unchanged in all 13 locales.
- `Active` is not the account-status label. It remains allowed only as a generic English word or a canonical tab/list label such as active panels or active referrals.

### EFHC / Hub
- купить EFHC -> пополнить EFHC
- покупка EFHC -> пополнение EFHC
- депозит EFHC -> пополнение EFHC

### Exchange
- заработанные кВт -> сгенерированные кВт
- заработать EFHC -> получить EFHC через игровую логику проекта

## Дополнительные правила

- Внутренние developer-формулы не переносятся в FAQ без отдельного
  согласования.
- Все новые и изменённые FAQ сначала согласуются на русском языке как на source-of-meaning уровне; player-facing runtime fallback при отсутствии качественной локали остаётся English.
- Любая замена вопроса/ответа проходит через явный replacement protocol.
