# ROUTE_RESPONSE_ERROR_CANON

Статус: CANON / SSOT (канон response/error surface маршрутов).
Якорь SSOT: `docs/SSOT/SSOT_INDEX.md`

Цикл 34 фиксирует подтверждённые требования response/error surface:

- `backend/app/main.py` обязан регистрировать `setup_exception_handlers(app)`.
- `HTTPException` обязан проходить через канонический JSON-ответ.
- Если route передаёт `detail` как объект, объект обязан иметь ключи:
  - `error`
  - `message`
  - `details`
- Строковые `detail=...` остаются legacy-формой до отдельной волны
  нормализации; цикл 34 их не переписывает массово без CI-подтверждения.

Подтверждённые исправления цикла 34:

- `payment_intents_routes.py` — `INTENT_NOT_FOUND` приведён к
  каноническому объекту ошибки.
- `wallets_routes.py` — TonConnect / wallet conflict / invalid address
  приведены к каноническому объекту ошибки.
- `errors_core.py` — зарегистрирован handler для `HTTPException`.
- `main.py` — включён `setup_exception_handlers(app)`.


## Граница legacy-совместимости

- объект ошибки `{error, message, details}` остаётся канонической формой;
- строковый `detail=...` допускается только как legacy-tail до отдельной
  подтверждённой волны полной нормализации;
- новые маршруты и новые правки не должны вводить свежие строковые ошибки
  поверх канонического JSON-объекта.
