## CURRENT PANEL PROTECTIVE FINANCIAL TOPOLOGY — v174.61

Ручная защитная Admin-деактивация Панели является узким внутренним D8-контуром. Цена Панели 100 EFHC не меняется. После checkpoint всех живых Панелей владельца рассчитываются `U=min(G,A)`, `R=G-U`, `NET=100-R`; refund уменьшается сначала по исторической EFHCb части, затем по EFHCm. Energy mirror корректируется `total_generated_kwh -= G`, `exchanged_kwh_total -= R`. Debt, отрицательные пользовательские балансы и per-Panel exchange attribution не вводятся. Dead Panel исключается из обычных списков/scheduler/aggregates, но остаётся в exact Admin lookup/audit/export. Повторная активация той же dead Panel требует новую реальную оплату 100 EFHC. Authority: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`.

## CURRENT DERIVED ADMIN SNAPSHOT — v174.60

`efhc_core.bank_metrics_snapshot` is a derived/materialized Admin Bank snapshot, not a new money ledger. Monetary and kWh fields are D8-scaled BIGINT; percentages are percentage × D8. Its source authority remains canonical BANK/user/panel/transfer data. This addition does not alter the established external D2 vs internal D8 boundary, TON 9-decimal atomic execution, USDT 6-decimal atomic execution, or Shop manual-price authority.

# FINANCIAL TOPOLOGY SSOT

Статус: **ACTIVE / OWNER-LOCKED / cycle 1794**

Owner-Decision-Refs: `QA-2026-08-19-FIN3-01`…`QA-2026-08-19-FIN3-13`, `QA-2026-08-20-FIN3-14`…`QA-2026-08-20-FIN3-16`, `QA-HIST-CHAT21-SHOP-TON-USDT`.
Machine projection: `docs/SSOT/FINANCIAL_TOPOLOGY_LOCK.json`.

## 1. Внутренний денежный контур

Внутренние денежные сущности приложения:

- `EFHCm`;
- `EFHCb`;
- `BANK_EFHC`.

Единственный monetary SSOT для денежных движений — `efhc_core.efhc_transfers_log`.
Domain/shadow logs разрешены как evidence и детализация, но не являются независимой денежной суммой.

Внутренний EFHC хранится и считается в D8. **Все внутренние денежные операции EFHC выполняются только в D8.**
D2 не является внутренней точностью EFHC: это boundary только внешних операций, определённых ниже.

## 2. Внешние rails покупки EFHC

Shop является **внешним магазином**: отдельной открываемой HTML-страницей, связанной с backend и Admin Panel. Отдельного внутреннего магазина в приложении не существует и создавать его запрещено без нового owner decision.


`TON` и `USDT` существуют только как внешние средства покупки EFHC:

- native TON: integer nanotons, `10^9` units;
- USDT jetton: integer token units, текущая technical precision `10^6`.

TON/USDT не являются внутренними EFHC balances, не являются EFHC и не нормализуются через EFHC `d8()`.
Успешный внешний платёж приводит только к внутренней проводке `BANK_EFHC → USER EFHC` на `efhc_amount_d8`.

## 3. Shop pricing

Product/runtime price authority карточки — сохранённые Admin значения `price_ton` и `price_usdt`.
Они независимы. Oracle, FX, автоматический курс и fixed-rate custom pricing отсутствуют и запрещены без нового owner decision.

При создании PaymentIntent выбранная ручная цена один раз преобразуется в native atomic units соответствующего asset и фиксируется как immutable execution snapshot на TTL intent.

Manual Admin price precision lock:
- `price_ton` = максимум D2;
- `price_usdt` = максимум D2;
- precision >D2 недопустима и отклоняется;
- silent rounding Admin price запрещён;
- `0.00` = товар остаётся доступным/видимым, но действие покупки по этому rail деактивировано;
- после D2 validation цена преобразуется в native atomic units только для immutable PaymentIntent execution snapshot.

D2 Shop является product/Admin price boundary. Техническая execution precision TON остаётся 9 decimals, USDT — 6 decimals.
Изменение карточки после создания intent не меняет snapshot существующего intent.

`price = 0.00` является допустимым сохранённым состоянием карточки: товар не скрывается, но действие покупки деактивировано. Backend fail-closed не создаёт order/intent как бесплатную покупку. Отрицательная цена недопустима.

## 4. PaymentIntent v2

Логический contract новых external intents:

```text
asset
external_amount_atomic
external_decimals
efhc_amount_d8
```

Новый payload:

```text
EFHC2:<purpose>:<intent_id>:G<global_id>:<asset>:<atomic>
```

Физическое `payment_intents.amount_asset_d8` сохраняется только как compatibility projection frozen schema и не является settlement authority для v2.
Settlement v2 сравнивает exact integer atomic equality.

## 5. Внешняя D2-граница

Owner-Decision-Ref: `QA-2026-08-20-FIN3-14`.

D2 применяется **только** к внешним операциям:
- внешний ввод EFHC;
- внешний вывод EFHC;
- ручная цена внешнего Shop (`price_ton` / `price_usdt`).

Все внутренние EFHC operations остаются D8.

Внешний EFHC ввод/вывод:

```text
raw external EFHC
→ D2 ROUND_DOWN
→ internal D8 representation
```

Raw amount, нормализованная сумма и rounding dust сохраняются в финансовом metadata/evidence.
Withdrawal asset — только EFHC.

## 6. Withdrawal payout

Operator flow:

```text
PENDING
→ Оплатить
→ wallet send или ручная внешняя отправка
→ Оплачено
→ PAID
```

Wallet `sendTransaction()` является желательным evidence, но blockchain watcher не обязателен.
Manual `Оплачено` разрешено Admin только с reason и required Admin audit.
`Одобрить` не является синонимом факта выплаты.

## 7. Fees

- EFHC business commission: отсутствует;
- deposit network fee платит пользователь;
- withdrawal network fee платит проект;
- пользовательский EFHC withdrawal amount не уменьшается на network fee.

## 8. Admin financial authority

Admin может выполнять разрешённое ручное/emergency решение в существующих административных контурах, но обязательны authorization, actor identity, reason для manual override и `admin_action_log`.

Для случая, когда автоматический EFHC recovery не может завершиться по точному evidence, **новый recovery UI/API не создаётся**: владелец подтвердил, что ручная функция уже реализована через Admin Panel → `Пользователи`. D2 remediation не должен дублировать этот контур.
Денежная мутация, domain state и required audit должны принадлежать одной root transaction соответствующего use-case.

`SHOP_FORCE_FULFILL` является ручной денежной Admin operation и требует audit.

## 9. NFT

Без подтверждённой оплаты выдача NFT невозможна.
Canonical переход:

```text
PENDING → payment confirmed → PAID_PENDING_MANUAL → APPROVED/REJECTED
```

`NFT PENDING → APPROVED` запрещён.

## 10. ADS

Verified/completed view является финальным независимо от результата reward delivery.
Reward — отдельное idempotent obligation и доводится reconciliation-механизмом ровно один раз с ключом `ads-session:<session_id>`.

## 11. Retry внешних TON events

Retry обязан сохранять исходные transport asset/master/atomic amount.
Legacy row без transport metadata сначала refetch'ится по authoritative `tx_hash`; если exact event восстановить нельзя — `PENDING_MANUAL`.
Fallback неизвестного legacy event в TON запрещён.

Продуктовый вопрос об обязательности автоматического retry остаётся `QA-2026-08-19-FIN3-05 = PENDING`.

## 12. P0 порядок внешнего финансового события

```text
trusted time
→ 180-day barrier
→ replay/idempotency
→ mutation
→ ledger
```

Replay/final-status decision не выполняется раньше temporal barrier.
