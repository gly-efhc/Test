<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Cycle 1440 Admin Hub route prefix canon

- Admin Hub is a separate admin section.
- Canonical path: `/admin/hub/*`.
- Canonical route module: `backend/app/routes/admin_hub_routes.py`.
- `backend/app/routes/admin_shop_routes.py` is shop-only and must not include/nest Hub router.
- Accidental `/admin/shop/admin/hub/*` runtime shape is forbidden.

# EFHC_CANON

Статус: NORM.
Якорь SSOT: docs/SSOT/SSOT_INDEX.md.

Этот документ фиксирует продуктовые инварианты EFHC Bot.
Любое расхождение кода/API/UI/доков с этим файлом — дефект.

---

## 1) Канон глобального аккаунта

Каноничный персональный идентификатор: `global_id`.

Правила:
- `global_id` — единственный owner внутренних объектов и денег;
- физическая колонка — `efhc_core.users.global_id`;
- `tg_id` — только Telegram provider subject на входных границах;
- после `tg_id → global_id` business runtime использует только `global_id`;
- `user_id` запрещён как новый API/DTO/ORM owner;
- `id` допустим только как локальный идентификатор сущности;
- provider subjects не формируют и не заменяют `global_id`;
- активный SSOT: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

---

## 2) Экономика и арифметика

Подробный active SSOT экономики: `docs/SSOT/ECONOMY_CANON.md`.

Фиксированный курс внутри продукта:
- **1 EFHC = 1 kWh** (обратной конверсии EFHC→kWh нет).

Decimal-канон:
- Все значения EFHC и kWh считаются через `Decimal`.
- Точность: `Decimal(30, 8)`.
- Округление: всегда вниз (`ROUND_DOWN`), если не указано иначе.

Per-sec ставки генерации (истина только здесь и в system_locks):
- `GEN_PER_SEC_BASE_KWH = 0.00000692`
- `GEN_PER_SEC_VIP_KWH  = 0.00000741`

Канон обозначений EFHC:
- `EFHC`  — Energy for Humanity Coin.
- `EFHCm` — основные монеты пользователя.
- `EFHCb` — бонусные монеты пользователя.
- `EFHCj` — внешний EFHC jetton в сети TON.
- `EFHC` как общий баланс = `EFHCm + EFHCb`.

Правило слоя:
- Эти сокращения разрешены только для пользовательского frontend,
  FAQ, UI-текстов, документации и других display-слоёв.
- В backend-коде, БД, ORM, сервисах, миграциях и тестах ядра
  запрещено заменять канонические имена полей на `EFHCm`,
  `EFHCb`, `EFHCj`.

Карта соответствий канона:
- `EFHCm` -> `main_balance`
- `EFHCb` -> `bonus_balance`
- `EFHCj` -> внешний EFHC jetton
- `EFHC` (общий баланс) -> `main_balance + bonus_balance`

Запреты:
- Никаких «суточных» ставок и множителей вне канона.
- Пользователь не может уйти в минус.

---

## 3) EFHC Bank (центральный баланс)

Каноничное имя банка: `BANK_EFHC`.

`BANK_EFHC` — главный центральный банк бота.
Начальный баланс банка (единый EFHC): **5000000.00000000**.

Правила банка:
- У банка один неделимый баланс EFHC; EFHCm/EFHCb — только пользовательское целевое разделение.
- У пользователя есть EFHCm (`main_balance`) и EFHCb (`bonus_balance`).
- Разрешены только операции «Банк ↔ Пользователь».
- P2P между пользователями запрещён.
- В системе нет понятий «списание/пополнение баланса».
  Есть только проводки credit/debit между пользователем и банком.
- Банк может уходить в минус.
  Причина: есть внешнее дополнительное обеспечение.

Хранение баланса банка (канон):
- Истина баланса банка хранится как системный объект в БД:
  `efhc_core.bank_balance` с ключом `EFHC_MAIN`.
- Любые изменения только через `transactions_service`.

Каноничные проводки банка:
- Начисление пользователю (на main или bonus):
  `user credit ⇒ bank debit` (источник — bank main).
- Возврат пользователя (bonus и main):
  `user debit ⇒ bank credit` (приёмник — bank main).

Журналирование:
- Каждое движение EFHC фиксируется в `efhc_transfers_log`.
- Пара записей образует двойную бухгалтерию:
  - запись пользователя (`global_id = account`)
  - зеркальная запись банка (`BANK_EFHC`)
  - одинаковый `idempotency_key`.

Эмиссия (крайний случай):
- Mint/Burn меняют только единый баланс банка и являются аварийными admin-механизмами.
- Эмиссия не используется для прямой раздачи пользователям.
- Если банк ушёл в минус, аварийный Mint может увеличить резервный баланс; обычные пользовательские операции не требуют эмиссии.
- Эмиссия доступна только админам (admin whitelist) и всегда
  идемпотентна.

Внешний вход (EFHC jetton / покупка EFHC):
- Внешнее событие является триггером внутренней проводки
  `user credit ⇒ bank debit` 1:1 (d8).
- Внутренний банк при этом не «пополняется» отдельной операцией.



## 3A) Канон пользовательских формулировок

Для FAQ, bot/help, WebApp UI и других user-facing display-слоёв
запрещены без отдельного утверждения слова:
- `купить`
- `покупка` и производные
- `депозит`

Нейтральные направления замены:
- EFHC: `пополнить`, `пополнение`
- панели: отдельное согласование по переходу на модель
  `активация / деактивация панели`

Этот запрет относится к пользовательскому слою.
Технические developer-facing документы, маршруты, схемы и сервисы
допускают служебную терминологию до отдельной cleanup-волны.

## 4) Причины транзакций и обязательные details

Поле `reason` — короткий SSOT-код причины операции.
Произвольный текст в `reason` запрещён.

Минимальный SSOT-набор `reason`:
- `exchange_kwh_to_efhc`
- `shop_purchase`
- `panel_activation`
- `referral_bonus`
- `task_reward`
- `ads_reward`
- `admin_mint`
- `admin_burn`
- `withdraw_request`
- `withdraw_paid`
- `withdraw_rejected`

`details` (meta) обязателен по смыслу операции.
Минимальные ключи (если применимо):
- `ton_tx_hash` (входящий платёж)
- `order_id` (Shop)
- `sku` (Shop)
- `withdraw_id` (вывод)
- `admin_global_id` (админ-действия)

---

## 5) Выводы EFHC (withdrawals)

Вывод оформляется как заявка. Выплата выполняется админом.

Статусы заявки:
- `PENDING` — создана, ждёт обработки
- `PAID` — успешно выплачена
- `REJECTED` — отклонена админом
- `ERROR` — ошибка обработки, нужна ручная проверка

Канон обработки:
- Любое действие админа должно оставлять audit-след.
- Приоритетная обработка VIP — допустима, если включена правилами.

---

## 5A) Канон внешнего EFHC jetton (TON)

Каноничный on-chain EFHC jetton master address:
- `EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw`

Каноничные параметры:
- `EFHC_JETTON_MASTER_ADDRESS` =
  `EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw`
- `EFHC_JETTON_DECIMALS` = `8`

Правила:
- Это внешний EFHC jetton (`EFHCj`) в сети TON.
- Любые watcher/matcher/purchase/deposit сценарии,
  работающие с внешним EFHC jetton, обязаны опираться
  именно на этот master address.
- Подмена, альтернативные master address и
  "временные тестовые" значения в live-контурах запрещены
  без отдельного подтверждения пользователя и синхронного
  обновления канона.
- Различать слои обязательно:
  - `EFHCj` — внешний jetton в TON;
  - `EFHCm` / `EFHCb` — внутренние балансы бота.

## 6) TON и MEMO (идемпотентность и валидация)

MEMO используется для однозначной привязки платежа
к пользователю и цели.

Каноничные форматы:
- Депозит EFHC: `EFHC|UID:<global_id>`
- Покупка пакета: `BUY|UID:<global_id>|QTY:<qty>|OID:<order_id>`

Идемпотентность:
- Повторная обработка одной и той же TON-транзакции запрещена.
- Для денежных HTTP-операций обязателен заголовок `Idempotency-Key`.
- `idempotency_key` уникален в системе и в БД.

---

## 7) Логирование и события

Правила:
- Запрещён silent-pass (`except: pass`). Любая ошибка должна быть
  залогирована минимум как `warning`.
- Для аудита и аналитики события обязаны иметь:
  - `event_name`
  - структурированный `details`
  - `global_id`;
  - `source_tg_id` только для Telegram source metadata.

SSOT матрица событий ведётся в `docs/NORM/EVENT_CONTRACTS_NORM.md`.

---

## 8) Запреты продукта

Запрещено:
- P2P переводы EFHC между пользователями.
- Обратная конверсия EFHC→kWh.
- Автоматическая выдача NFT (только заявка и ручная обработка).

Терминологические запреты и каноничные термины:
- `docs/SSOT/PROJECT_GLOSSARY.md`.

## API

### Пагинация (курсоры)
- Списки возвращают CursorPage: items + next_cursor (или null).
- next_cursor кодируется (encode_cursor) и декодируется
  (decode_cursor) без раскрытия внутренних ключей.
## Логи и журнал ошибок

- Все excerpt из CI/traceback записываются **1:1** (как есть),
  без правок.
- Файл **EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md**
  является журналом ошибок
  команды и может содержать строки из логов.
- Любые log-артефакты (например, `*.log`, каталоги `logs/`,
  `.local_artifacts/`) **обязаны быть исключены** из guard-тестов,
  чтобы не создавать ложные падения по фрагментам логов.
- Исключение: тест **tests/architecture/test_max_line_length_72.py**
  продолжает проверять формат строк (72), включая журнал и логи.

## FAQ line72 canon

- MUST: JSON-файлы FAQ SSOT (`docs/SSOT/faq_ssot/*/faq_*.json`)
  освобождаются от ограничения 72 символа в строке.
- MUST: Для FAQ SSOT JSON приоритетны структурная целостность,
  валидность JSON и точная синхронизация с Markdown.
- MUST: Раздел FAQ во frontend (`frontend/src/data/faq/**`,
  `frontend/src/components/faq/**`, `frontend/src/pages/faq.tsx`,
  `frontend/src/components/profile/ProfileFaqSection.tsx`)
  освобождается от ограничения 72 символа в строке.
- MUST: Это исключение не отменяет требований к корректности
  TypeScript/TSX, логике FAQ и синхронизации с русским каноном.

## NORM: Общие логи проекта

- MUST: immutable история выполненных работ хранится в `reports/numbered/`.
- MUST: каждая завершённая итерация получает следующий `reports_NNNNN`; номер
  не переиспользуется и последовательность контролируется manifest/guard.
- MUST: текущие operational evidence хранятся в `reports/current/` и
  `reports/generated/`; они не заменяют immutable numbered report.
- MUST NOT: возвращать `АРТЕФАКТЫ/` или `docs/history/` в active HEAD ради
  старых тестов, ссылок или tooling. Устаревшие snapshots хранятся только во
  внешнем artifacts history ZIP.

## Канон чисел d8 (EFHC и кВт·ч)

- Любые значения EFHC и кВт·ч в API/DTO/ответах/логах отображения
  сериализуются **строкой** формата d8: `0.00000000` (8 знаков).
- Математика внутри сервисов ведётся в `Decimal` с `quantize` до d8 и
  `ROUND_DOWN`.
- Запрещено отдавать наружу `str(Decimal)` как формат числа: для нулей
  Python может вернуть `0E-8`. Наружу — только через `d8_str()`.


## D8_Serialization (MUST)

- Все денежные/энергетические значения в API-ответах сериализуются
  как строка d8 (8 знаков после запятой) с ROUND_DOWN.
- Запрещено полагаться на str(Decimal) как на формат вывода.
- Канонная функция: app.schemas.common_schemas.d8_str.
- Канонная база схем: app.schemas.common_schemas.EfhcBaseModel.

## Facade modules

Канон:
- init.py в services/schemas не агрегирует импорты.
- Для коротких импортов разрешены facade.py (services/schemas).
- facade.py содержит только re-export без побочных эффектов.


## Канон банка BANK_EFHC

Определения:
- BANK_EFHC — главный центральный банк бота.
- Истина баланса банка хранится как системный объект
  efhc_core.bank_balance (вариант A).
- Запрещены любые `DB_SCHEMA_SHOP`, `DB_SCHEMA_REFERRAL`,
  `DB_SCHEMA_TASKS`, `efhc_shop`, `efhc_ref*`, `efhc_tasks`.
- Любые shop/referral/tasks таблицы работают только в `efhc_core`;
  админ-таблицы — только в `efhc_admin`.
- Обход `canon_schema()` для схем запрещён.
- У банка один неделимый баланс EFHC; EFHCm/EFHCb — только пользовательское целевое разделение.
- У пользователя есть EFHCm (`main_balance`) и EFHCb (`bonus_balance`).
- Банк может уходить в минус: это допустимо, есть внешнее
  дополнительное обеспечение.

Начальный банк:
- BANK_EFHC main стартует с баланса
  5000000.00000000 (d8).
- Физический seed живёт в `backend/migrations/versions/0001_initial_release_schema.py`:
  `efhc_core.bank_balance`, `key='EFHC_MAIN'`,
  `balance=Decimal('5000000.00000000')`.
- Runtime fallback/инициализация живёт в
  `backend/app/services/admin/admin_bank_service.py` как
  `BANK_INITIAL_TOTAL`.
- Живой баланс банка всегда читается из `efhc_core.bank_balance`;
  `efhc_admin.bank_balances`, `users.ton_wallet`, `user_wallets` и
  отдельный mint/burn ledger не являются SSOT баланса банка.

- Будущий mint/rewrite баланса банка через Alembic migration запрещён.
  Единственное разрешённое исключение — genesis/bootstrap seed в
  `backend/migrations/versions/0001_initial_release_schema.py`, где создаётся
  `5000000.00000000 EFHC` для `efhc_core.bank_balance / EFHC_MAIN`.
  Операционный mint/burn после запуска выполняется только через
  `AdminBankService` + `transactions_service` с idempotency/audit.

Запреты:
- В системе нет "пополнений" и "списаний".
  Есть только изменения credit/debit между пользователем и банком.
- Любые денежные движения и записи efhc_transfers_log выполняются
  только через transactions_service с idempotency_key.

Канон направления:
- user credit ⇒ bank debit
- user debit  ⇒ bank credit

Внешний вход (EFHC jetton / покупка EFHC в TON сети):
- Входящее внешнее событие триггерит внутренний commit
  user credit ⇒ bank debit (1:1, d8) в EFHC main или EFHC bonus.

Вывод:
- Пользователь создаёт заявку: user debit ⇒ bank credit
  (возвращает EFHC bonus и EFHC main в BANK_EFHC main).
- Внешняя выплата фиксируется статусом заявки и tx_hash;
  внутренние балансы повторно не меняются.

Эмиссия (крайний случай):
- Эмиссия меняет только BANK_EFHC (bank-only).
- Пример: банк -10000 ⇒ эмиссия +20000 ⇒ банк +10000.
- Эмиссия выполняется только админом из whitelist.

## Канон балансов пользователя

- У пользователя два баланса: **EFHC_MAIN** и **EFHC_BONUS**.
- **EFHC_BONUS**: начисления за задания, рефералов и иных бонусных механик.
- EFHC_BONUS можно тратить на всё, **кроме вывода**.
- **Вывод возможен только и только из EFHC_MAIN**.
- Внешние пополнения и покупка EFHC (TON/USDT в сети TON) зачисляются
  **только в EFHC_MAIN** пользователя.
- Балансы пользователя **не могут уходить в минус** (жёстко).


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` описывает только реальный active `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/DATABASE_MIGRATION_INVARIANTS_NORM.md`.


## FAQ SSOT

- Канон FAQ фиксируется в `docs/SSOT/FAQ_SSOT.md`.

- FAQ SSOT дополняется 16 правилами содержания, точности,
  полноты и запрета смыслового сжатия.
- Русский FAQ — первоисточник.
- Канонических разделов FAQ не может быть меньше 20.
- Верхний уровень FAQ фиксируется 20 разделами
  без подразделов.
- Канонические темы вопросов удалять нельзя.
- Для вопросов с точным ответом FAQ обязан сохранять
  точные факты, числа, сроки, лимиты и условия.
- Добавлять новые разделы и вопросы можно,
  уменьшать FAQ ниже канонического минимума нельзя.


## FAQ SSOT files

Канонический FAQ хранится в файловом каталоге `docs/SSOT/faq_ssot/`.

Правила:
- главный нормативный FAQ: `docs/SSOT/faq_ssot/ru/faq_ru.md`;
- главный машинно-читаемый FAQ: `docs/SSOT/faq_ssot/ru/faq_ru.json`;
- языковые каталоги `docs/SSOT/faq_ssot/*` допустимы только как перенос
  русского канона;
- пока нормативно заполнен только русский FAQ SSOT.


FAQ SSOT: whole directory docs/SSOT/faq_ssot is exempt from line72.

## 11) Legacy DB / migration policy

- Канон активной БД: только `efhc_core` и `efhc_admin`.
  в `backend/migrations/**`, current audit/evidence и numbered reports только там, где это необходимо как действующая проверяемая ссылка; устаревшие snapshots находятся во внешнем history archive.
  SSOT, runtime-код, API, ORM, config или user-facing docs.
- Новые migrations для удаления legacy следов в этой серии нельзя
  добавлять без отдельного подтверждения по DB/CI/audit.


## Hub canon (summary)

- Public HUB — navigation/handoff layer с одной видимой кнопкой `Пополнение`.
- До внешнего перехода HUB не показывает описание покупки, валюты, цены, пакеты, VIP NFT или второе действие.
- Hub не хранит price/order/purchase semantics в user-facing слое.
- Public Hub flow: `POST /hub/efhc-handoff`.
- Admin Hub manager: `/admin/hub/links*`.
- Legacy `/shop` и `/admin/shop` допустимы только как технические алиасы.


Дополнительно запрещены user-facing производные от:
- `заработать`
- `заработал`
- `заработанные`
- `заработай`
- другие формулировки, создающие инвестиционный или доходный смысл
  (`доход`, `доходность`, `инвестиция`, `инвестировать`, `прибыль`,
  `дивиденд` и сходные по смыслу слова).

- `цена` и производные в user-facing layer заменяются на нейтральные
  формулировки вида `для активации необходимо 100 EFHC`.

## Panels approval absorption

Approved panel activation wording and related user-facing panel semantics are considered absorbed by the active canon and SSOT layer. Standalone historical approval packages should not be treated as current source-of-truth once their content is reflected in active docs/runtime.

## 3B) Дефицит банка: различение канона и инцидента

Минус банка EFHC допустим как часть проектного канона при наличии внешнего
обеспечения. Инцидентом считаются неканоничные состояния: ошибки вида
`insufficient bank balance`, двойные списания, повторная обработка внешних
событий без dedupe и отсутствие audit trail для корректирующих действий.
