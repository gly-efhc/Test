# EFHC_OPERATOR_KERNEL_SSOT

Status: ACTIVE SSOT.
Archive: `v171.64`.

## Single source of truth

Operator Kernel is the active detailed operational dispatch layer of EFHC Bot.

Top goal:

```text
accelerate AI work by mapping project-specific keywords
→ task type
→ exact route
→ canonical anchors
→ exact files
→ patch boundary
→ targeted validation
→ proof/archive boundary
```

Kernel must not be demoted to navigation-only.

## Runtime truth

- Route configuration SSOT: `ops/operator_kernel/config/routes.yaml`.
- Runtime resolver: `ops/operator_kernel/route_resolver.py`.
- Task language: `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md` plus `task_classifier.py`.
- Domain map: `docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md`.
- Startup map: `ops/operator_kernel/cache/file_map.summary.json`.
- Machine index: `ops/operator_kernel/cache/file_map.json`, not full-read.
- Context packet: `ops/operator_kernel/context_capsule.py`.

## Protected invariants

1. Single startup entrypoint: `START_HERE.md`.
2. Detailed operational Kernel with no duplicate historical Current HEAD blocks.
3. YAML-primary route resolution.
4. EFHC-specific classifier behavior.
5. Precise route reading instead of full archive reading.
6. Route-backed screenshot proof for frontend work.
7. Exact evidence boundary for CI/live/release claims.
8. Separate development and release archives.
9. Fixed six-button bottom navigation unless directly changed by user.
10. Compound requests preserve a primary route and bounded secondary routes.
11. Duplicate active control rules are consolidated; compatibility paths contain pointers only.
12. AI documents are operational memory, not history; approved decisions are promoted and removed from temporary memory.
13. История хранится только в канонических `docs/cycles/`, `docs/chats/`, `reports/numbered/` и во внешнем `ARTIFACTS_HISTORY` ZIP; удалённые `docs/history/`/`АРТЕФАКТЫ/` не являются runtime dependency.
14. Canonical GitHub CI job timeout is 10 minutes.

## Current state

`v173.26 / cycles 1704-1705`: Operator Kernel использует только active authority и канонические history roots. Удалённые `docs/history/` и `АРТЕФАКТЫ/` не читаются и не восстанавливаются из-за старых tests/guards. `reports/numbered/` остаётся immutable evidence, а production RELEASE не содержит development history.
