# OPERATOR KERNEL SSOT — v175.17 / цикл 1850

- Input HEAD `v175.16`, SHA `3efdc5cf854da28afb8d5707db05937500ab3735206362e70e0dbb8293fbfab4`; exact-head CI `90300463463`.
- Operator Kernel выполнен ровно один раз. Классификация: `frontend_i18n_guarded_work`; основной маршрут `i18n_public_surface_guard`; затем применена только ограниченная task-relevant работа.
- Единственный CI RED: русский язык документа `EFHC_OPERATOR_KERNEL_SSOT.md:493–497`; исправлены только пять авторских строк, test/guard не менялись.
- OWNER scope цикла `1850`: RU/EN/UK screen-name и navigation reconciliation; EN — только остаток после `1849`.
- Выполнено `26` FAQ-позиций: RU `8`, EN `9`, UK `9`; SSOT/runtime/bundled синхронизированы.
- Current report `02437`; next `02438`; candidate `v175.17` требует следующего exact-head CI.
- Следующий плановый цикл `1851` — только по прямой команде OWNER.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ DEVELOPMENT HEAD — v175.11 / цикл 1849

- Physical input: `EFHC_Bot_v175_10.zip`, SHA `8c289bcd2e06f3abf89176a03438264bd8a8284c75464e82c41f6ca30deb0388`, CRC PASS.
- Exact-head CI `90187413583` для `v175.10`: подтверждены Ruff `I001` и два overbroad legacy-rank guard FAIL; исправлены точечно.
- Cycle `1849`: минимальная EN screen-name wave `14-2/14-12/14-17` по фактическому UI-label `Profile`; FAQ `16/16 × 20 × 230`, approval `FAQ-APPROVAL-0040`; RU semantic source/protected section 19 без изменений.
- OWNER утвердил новый plan `1849–1883`: `docs/PLANS/WORK_PLAN_1849-1883_MULTILINGUAL_CERTIFICATION.md`. Следующий cycle `1850`, report `02432`; остаётся `34` цикла `1850–1883`.
- Frontend `239/239`; source-lock `d723086542513f51b4b34106b29f6ef605b2b3f6859f285f8bcaccd059ff008d`; PWA `efhc-797b605a530e7e82`; release assets `35/35`.
- Immutable report `02431`. `v175.11` остаётся candidate до нового exact-head GitHub CI.
- Full local suites и targeted tests в этом cycle не запускались; release ZIP имел приоритет по прямому OWNER-правилу.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.10 / цикл 1848, wave 1

- Physical input `v175.09` подтверждён SHA/CRC; Operator Kernel запущен один раз в начале прохода и далее не перезапускался.
- Exact-head CI `90184764129`: pytest завершён, `2` FAIL одного EN public-copy root cause; Ruff `1 × I001`.
- Подтверждённые RED исправлены точечно; full local suites не запускались; exact Ruff `0.16.5` локально недоступен из-за отсутствия сети, поэтому Ruff PASS не заявляется.
- OWNER-directed cycle `1848` wave 1 ограничен EN long answers: `23` reviewed, `22` wording corrections; `14` non-RU языков остаются pending.
- Кандидат `v175.10`; report `02430`; FAQ `230/250`, approval `FAQ-APPROVAL-0039`; интерфейс `239/239`, source-lock `941c848a45302e5f43a8177e0738213ccd04b8d795b44f7efaa0bf85b2563ce7`, PWA `efhc-9234a824ec69aac1`, assets `35/35`.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.08 / цикл 1847, продолжение

- Exact-head CI `90173501468` для `v175.07`: pytest GREEN и завершён за `122.17 s`; единственный RED — Ruff `3 × I001`.
- OWNER-approved semantic source `12-2/12-13` применён параллельно во всех `16` FAQ; approval `FAQ-APPROVAL-0037`; размер `230/250`.
- `6-15`, `7-6`, `10-2` остаются OWNER-review; без отдельного решения runtime не меняется.
- Release candidate `v175.08`; report `02428`; далее `1848/02429`; frontend `239/239`, source-lock `ab04e1d34edb5ba8c05d5d18194a6f751e3408d47947a33c5afa93c20244cee8`, PWA `efhc-c0c05eac6bad9dc9`, assets `35/35`.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.07 / цикл 1847

- Exact-head CI `90168142245` для `v175.06`: Ruff RED + pytest RED/timeout; подтверждённые defects исправлены точечно.
- FAQ остаётся `16 × 20 × 230`; `FAQ-APPROVAL-0036`; RU/protected section 19 без изменений.
- RU-source exceptions вынесены на OWNER-review; переводной план продолжается циклами `1848–1851`.
- Release candidate `v175.07`; report `02427`; далее `1848/02428`; frontend `239/239`, source-lock `91dbb1fa41f1770502f90b37d0c745258432f5617ca358b4043dc09ea346e2c0`, PWA `efhc-60cc251133db2ed3`, assets `35/35`.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.06 / цикл 1846, волна 2

- Вход `v175.05`; новых GitHub CI logs нет. Последнее exact-head GREEN evidence: `v175.00 / CI 90038758717`.
- Прямой OWNER scope: продолжить ручной аудит переводов без добавления новых Q&A.
- FAQ итог `230/250`, `16/16`, approval `FAQ-APPROVAL-0035`; wave 2 исправила `74` подтверждённых non-RU позиций; RU FAQ и protected section 19 сохранены.
- Release candidate `v175.06`; report `02426`; далее `1847/02427`; frontend `239/239`, source-lock `0889662bd03dcc7be9e0115ef87dd3b8a196ad2afb4103c314c69ff59d7382bd`, PWA `efhc-834077ae40d50bc6`, release assets `35/35`.
- Полная linguistic certification не заявляется; cycle `1847` завершает оставшуюся ручную сверку и отдельный review RU-source exceptions.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.05 / цикл 1846

- Вход `v175.04`; новых GitHub CI logs нет. Последнее exact-head GREEN evidence: `v175.00 / CI 90038758717`.
- Прямой OWNER scope: отклонить `N93–N97`, оставить текущие `230` Q&A и начать аккуратную ручную межъязыковую reconciliation.
- FAQ итог `230/250`, `16/16`, approval `FAQ-APPROVAL-0034`; wave 1 исправила `150` доказанных non-RU drift-позиций; protected `18` progression Q&A сохранены.
- Release candidate `v175.05`; report `02425`; далее `1847/02426`; frontend `239/239`, source-lock `bab1265789da2df39d3af03ce5c87c5ac91f9fffa2b09e772de23de7c2095385`, PWA `efhc-1699bd0379c3e381`, release assets `35/35`.
- Полная linguistic certification не заявляется; cycle `1847` продолжает оставшуюся ручную сверку.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.04 / цикл 1845

- Вход `v175.03`; новых GitHub CI logs нет. Последнее exact-head GREEN evidence: `v175.00 / CI 90038758717`.
- Прямой OWNER scope: внедрить `N83–N86`; `N87–N92` отклонить; после достижения `230` подготовить пять резервных вариантов без внедрения.
- FAQ итог `230/250`, `16/16`, approval `FAQ-APPROVAL-0033`; protected `18` progression Q&A сохранены.
- Release candidate `v175.04`; report `02424`; далее `1846/02425`; frontend `239/239`, source-lock `fb87acf540a68f42b44ecf4cee663d2893ed1a871d7597fe8fa13f8903304e63`, PWA `efhc-2a60a088400dda9b`, release assets `35/35`.
- `v175.04` требует fresh exact-head GitHub CI.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.03 / цикл 1844

- Input `v175.02`; новых GitHub CI logs нет. Последнее exact-head GREEN evidence: `v175.00 / CI 90038758717`.
- Direct OWNER scope: внедрить `N73–N75`; `N76–N82` отклонить из FAQ из-за внешнего Магазина; проверить дополнительные OWNER-вопросы на дубли; подготовить `N83–N92` как новые user-facing DRAFT.
- FAQ итог `226/250`, `16/16`, approval `FAQ-APPROVAL-0032`; protected `18` progression Q&A сохранены.
- Release candidate `v175.03`; report `02423`; далее `1845/02424`; frontend `239/239`, source-lock `e0a90ffbf8434c96494cc6da8635780ddc49b457ed2656cfa1272a8097f0ba28`, PWA `efhc-3bef905119aff3be`, release assets `35/35`.
- `v175.03` требует fresh exact-head GitHub CI.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v175.02 / цикл 1843

- Input `v175.01`; новых GitHub CI logs нет. Последнее exact-head GREEN evidence: `v175.00 / CI 90038758717`.
- Direct OWNER scope: внедрить только `N69`; `N65–N68` и `N70–N72` отклонены; подготовить `N73–N82` как новые user-facing DRAFT без runtime rewrite.
- FAQ итог `223/250`, `16/16`, approval `FAQ-APPROVAL-0031`; protected `18` progression Q&A сохранены.
- Release candidate `v175.02`; report `02422`; далее `1844/02423`; frontend `239/239`, source-lock `922ce247549464f8fe0a81d76aaa2aa8a1ede97b272a12f816078d3d4288ff8c`, PWA `efhc-e399f5b3293bb510`, release assets `35/35`.
- `v175.02` требует fresh exact-head GitHub CI.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v174.100 / цикл 1840

- Input `EFHC_Bot_v174_99.zip` / `6e48627fbcacfbf0589b7aea184c6708aa8518c3689904b67bea405f28891066`; новых CI logs нет.
- OWNER-approved `N40`, `N45–N52`, `N54` синхронно внедрены в `16/16` FAQ; итог `216/250`; approval `FAQ-APPROVAL-0027`.
- Protected `18` progression Q&A сохранены; `N53`/`N58` не внедрены без отдельного approval; support contact не заявляется без подтверждённого канала.
- Frontend `238/238`, source-lock `0e084adcc2b140f551027d258299c3c7911dfca2f07d4e9bda4dc6009200f89f`, PWA `efhc-0423379583e6d736`, release assets `35/35` перед verify-only.
- Report `02419`; далее `1841/02420`. `v174.100` требует нового exact-head GitHub CI.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

## ТЕКУЩИЙ POINTER — v174.99 / цикл 1839

- Operator Kernel запущен один раз в начале cycle `1839`; после OWNER-коррекции повторно не запускался.
- Direct OWNER correction выше startup capsule: не внедрять `N40`, `N45–N57` до повторного финального approval.
- FAQ фактически `16 × 20 × 206`; runtime bytes после отката не изменены.
- Immutable report `02418`; следующий cycle `1840`.

---

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v174.98 / цикл 1838

- Physical input `v174.97`; новых exact-head CI logs для него не предоставлено. Последний подтверждённый GREEN evidence остаётся `v174.96 / CI 89999164826`.
- OWNER-directed scope: task-relevant audit current player-facing application source; сформированы DRAFT `N39–N53`, exact normalized duplicates против current `206` + prior `38` draft — `0`.
- FAQ catalogs не менялись: `16/16`, `20` разделов, `206/250`, `49/49` byte-equal input; protected 18 level Q&A неизменны.
- Release candidate: `v174.98`; report `02417`; далее `1839/02418`; frontend authority `238/238`, source-lock `218d58c70fa6fbde564017d7d4bfa9ca6a83b4a31f2d96f4befae92dfb99abc6`, PWA `efhc-5908e296c26aa109`, release assets `35/35`.
- `v174.98` требует fresh exact-head GitHub CI; старый GREEN автоматически не переносится.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v174.97 / цикл 1837

- Входной `v174.96` квалифицирован exact-head GitHub CI `89999164826`: все canonical gates GREEN, pytest `1780 passed / 22 skipped / 1 warning`; подтверждённых CI RED нет.
- OWNER FAQ canon не менялся: `16/16`, `20` разделов, `206/250`; 12 Energy + 6 referral level Q&A остаются protected и не подлежат удалению/объединению.
- `N1–N31` и `N34–N38` остаются DRAFT OWNER-review; `N32/N33` не допускаются к автоматической интеграции из-за пересечения с protected level series. FAQ content delta `0`.
- Состояние release candidate: `v174.97`; report `02416`; далее `1838/02417`; frontend authority `238/238`, source-lock `218d58c70fa6fbde564017d7d4bfa9ca6a83b4a31f2d96f4befae92dfb99abc6`, PWA `efhc-6b94558e2e10e65a`, release assets `35/35 PASS`.
- `v174.97` требует нового exact-head GitHub CI; GREEN статус входного `v174.96` автоматически не переносится.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v174.96 / цикл 1836

- Exact-head CI `89965077040` для `v174.95`: только два pytest Anti-Stale/governance RED; исправлены точечно.
- OWNER FAQ canon: `16/16`, `20` разделов, `206/250`; 12 Energy + 6 referral level Q&A защищены от удаления/объединения.
- FAQ content bytes в cycle `1836` не менялись; новые `N1–N38` не утверждены.
- Release candidate: `v174.96`; report `02415`; next `1837/02416`; frontend authority `238/238`, source-lock `218d58c70fa6fbde564017d7d4bfa9ca6a83b4a31f2d96f4befae92dfb99abc6`, PWA `efhc-5ecbb269573de6c0`, release assets `35/35`.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

# ТЕКУЩИЙ OPERATOR KERNEL SSOT — v174.89 / цикл 1829

- Physical input: `EFHC_Bot_v174_88.zip`; exact-head GitHub CI `89757049268` подтвердил два governance RED, исправляемых в cycle `1829`.
- OWNER localization canon: application `16/16` и FAQ checked-in runtime + SSOT `16/16`: `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
- Application locale keyset: `1829` на каждом языке; FAQ: ровно `20` разделов и максимум `250` Q&A на каждом языке; после цикла `1835` фактически `206`; KO/JA physical catalogs обязательны, FAQ fallback не заменяет catalog.
- Unfinished-marker `TODO/FIXME/TBD` контролируется только в shipping code; документы/FAQ и естественное Portuguese `todo` вне code scope.
- Release candidate: `v174.89`; report `02408`; next `1830/02409`; frontend authority `238/238`, source-lock `7899790584a41de7010490a98f9273107544565e4f95319b9ed51255573b25be`, PWA `efhc-61b8d4be18adc3e5`, release assets `35/35`.

> Исторические kernel snapshots ниже являются evidence и не переопределяют этот блок.

# CURRENT OPERATOR KERNEL STATE — v174.80 / cycle 1820

- Текущий candidate: `v174.80`; cycle `1820`; report `02399`; next `1821/02400`.
- Exact-head CI `89575037872` для `v174.79` дал `10/12 GREEN`; RED pytest/frontend build классифицированы и targeted repairs внесены.
- Frontend authority `235/235`, source-lock `f47f530aa92788f8e35016d9470d3379f9078517ce0f791bebf82516437afb95`; backend Shop reconciliation/atomic VIP reservation реализованы в cycle 1820.
- Последний fully GREEN exact-head: `v174.76 / CI 88320337434`.

> Historical content ниже retained as evidence.

# EFHC OPERATOR KERNEL SSOT CURRENT — v174.79 / cycle 1819

- Physical candidate `v174.79` построен поверх exact `v174.78` SHA-256 `b63e7b317da3d412224e58af581c72f75fbc01dbaf963897e43174e576402b26`; last exact-head GREEN `v174.76 / CI 88320337434`.
- Cycles 1818–1819 интегрировали approved frontend foundation + product surfaces; current authority `235/235`, source-lock `7975ef8ae0f8c2fcd47fb817e9ee786e808b11d4f4239ed6fdceb9ca35808dad`.
- Shop locks: Custom integer `>=1 EFHCm`, D2 unit rate, no automatic production prices, canonical 15 fixed + Custom, one customer VIP, ShopOrder-only orders.
- External TON/USDT и selected-number payment остаются fail-closed. Five backend Shop donor files переходят в explicit cycle-1820 reconciliation scope и пока byte-equal input.
- Templates module отсутствует в UI; stale generated frontend seams удалены. Next cycle `1820`, report `02399`; fresh exact-head CI required.

> Historical kernel state ниже сохраняется как evidence.

# EFHC OPERATOR KERNEL SSOT CURRENT — v174.78 / cycle 1818

- Current development candidate: `v174.78` поверх physical `v174.77` SHA-256 `203595386261feb3e13d3d7a63dcfbc96918437117e4a92ad3fa557af3d83316`. Last exact-head GREEN: `v174.76 / CI 88320337434`.
- OWNER reconciliation `QA-2026-08-27-FRONTEND248-01…10` завершена. Current Shop locks: Custom integer `>=1 EFHCm`, D2 unit rate; no automatic production prices; canonical 15 fixed + Custom; consolidated VIP; ShopOrder-only orders; external TON/USDT and selected-number payment fail-closed до backend completion.
- Primary Wallet Router: primary TON address является security authority; unresolved `wallet_app` допускает generic chooser, но mismatched canonical address блокируется.
- Partial frontend authority `INTEGRATED_FRONTEND_SOURCE_v174.78_FRONTEND_v248_CYCLE_1818_PARTIAL`, `227/227`, source-lock `1314ec0d88b5a7c15497a770b2c9235a0ecbc40917b7b8e67f784ae2abdffda0`. Five backend Shop donor files deferred to cycle 1820; frozen `0001` unchanged.
- Runtime locale `16`, FAQ runtime `13`, build-id `efhc-a633d1168ae3f1c4`, release assets `32/32 PASS`.
- Report `02397`; next cycle `1819`, next report `02398`; fresh exact-head GitHub CI required.

# CURRENT HEAD — v174.60 / cycle 1800 — FRONTEND_v182 + owner-approved Bank snapshot

- Base exact-head CI evidence: GitHub CI `87706114541` tested exact `v174.58` SHA-256 `93f80c6a3fdd95952f7d9bc5dc977d4d42db3c50d560309d5c8a68edd820ee73`, checkout `29be709f31bff90898826c07994373deeda436a8`; all recorded gates GREEN except one stale pytest raw-error implementation guard (`1 failed / 1749 passed / 22 skipped / 1 warning`).
- CI log archive SHA-256: `b8530b8ffd22aa421e7207fdf2edcee9d27d0349e870444a6e4e2737f3a6927d`.
- Owner donor/sample `EFHC_Bot_v174_59.zip` SHA-256 `956844e259b8294e7de35bbf5a5ba99db305bed368bf10182621e4bbb1ab6fd9` supplied FRONTEND_v182 + Bank snapshot integration. Merge is selective: higher Shop D2/zero-price, atomic PaymentIntent, withdrawal Paid and FAQ checked-in CANON are preserved.
- FRONTEND_v182 is current owner-controlled frontend authority. Current approved source manifest: `INTEGRATED_FRONTEND_SOURCE_v174.60_FRONTEND_v182`, `211/211` paths.
- New owner-approved canonical table: `efhc_core.bank_metrics_snapshot`; ORM surface `53 = 46 efhc_core + 7 efhc_admin`; expected clean physical surface `54` including `alembic_version`. Frozen lineage remains only `0001`; no `0002+`. Existing DB compatibility: root `URGENT_BANK_METRICS_SNAPSHOT.sql`.
- Snapshot service is transaction-neutral; application route owns commit/rollback. BANK/ledger/source tables remain primary financial truth.
- FRONTEND_v182 backend compatibility adds `GET /admin/panels/{panel_id}`, cursor Panel list and Admin logs CSV/XLSX export. Checked-in static OpenAPI: `165 paths / 171 public operations / 169 schemas`; hidden `8`; mounted expected `179`.
- Protective Panel deactivation remains fail-closed until separate owner-approved atomic refund/split/generated-kWh-annul backend contract. Admin Panels Q&A `ADM-M09-01…19` remains authority.
- Candidate `v174.60` requires fresh exact-head GitHub CI; no GREEN claim transfers from `v174.58` or donor `v174.59`.

# EFHC OPERATOR KERNEL SSOT CURRENT — v174.58 / цикл 1797

- Docs-only owner Q&A import: `ADM-M09-01…19` перенесены в active Q&A register.
- Backend/frontend/tests не изменяются; source document не даёт самостоятельного разрешения на backend/main implementation.
- Next exact-head CI требуется для нового archive SHA.

# CURRENT HEAD — v174.57 / цикл 1797 / CI `87591506394` repair

- Physical input: `v174.56` SHA-256 `411b1c34e5fb05ac54004f589ec1bde453f79c31f93e2c5fe1e89082eac2aa9f`; supplied CI logs ZIP SHA-256 `3a3dcce04e744d53cab0ba991dda4ab7dec2945518c744abfeb6c0f6ebb32aa3`. Checkout: `22bb7d02d48a4aaaab4b7df3cf43646a8aec7630`.
- CI GREEN: Development SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install. RED: Ruff `2`, Mypy `3`, frontend build `2` TypeScript errors, pytest `12 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые source defects: Ruff import order; Mypy typed-return boundaries; два TypeScript defects `admin/shop.tsx`; запрещённый financial UI `Number()` в Bank ratio. Исправлены минимально без нового frontend functionality.
- Pytest qualification debt после FRONTEND_v168: stale Bank emergency href, old Users `limit=50`, old logs virtualization marker, old Tasks runtime/label literals, old zero-price expectation, raw-error state-name expectation; directory/test/current-manifest drift. Tests перепривязаны к current observable/invariant contract, а не к superseded implementation shape.
- OWNER clarification: confirmed frontend defects исправляются сразу; новые functional/visual changes требуют ТЗ/owner patch. Tests, противоречащие owner-approved frontend patch только по старой implementation shape, обязаны синхронизироваться в той же итерации.
- Frozen `0001`, отсутствие `0002+`, D2/D8 boundary, TON/USDT native atomic, Oracle/FX prohibition, BANK/ledger, Telegram transaction ownership не меняются.
- Immutable report `02375`; следующий `02376`; canonical handoff `EFHC_Bot_v174_57.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.56 / цикл 1796 / owner clarifications documentation sync

- База этой итерации: `v174.55` SHA-256 `08211128a3220112b6d1e76b3b8a451aad19edff67a59a531d704fc8e3123f9b`; runtime source из `v174.55` не переписывается данной документационной синхронизацией.
- Последний подтверждённый exact-head GREEN остаётся `v174.54`, GitHub CI `87542599519`, checkout `2c8b5fab3b21f608d77daa54782963e971f9ff35`, pytest `1745 passed / 22 skipped / 1 warning`.
- Прямое решение владельца уточняет финансовую границу: **D2 только на внешних операциях** — внешний ввод EFHC, внешний вывод EFHC и внешний Shop. Все внутренние операции EFHC остаются D8. Внутреннего магазина не существует и не должно существовать; Shop — отдельная открываемая HTML-страница, связанная с backend и Admin Panel.
- `0.00` сохраняется как допустимое состояние цены товара: товар остаётся доступным/видимым, но действие покупки при нулевой цене деактивировано; бесплатная покупка и создание payment flow при `0.00` запрещены.
- Новый manual recovery UI/API не создаётся: владелец подтвердил, что необходимый ручной контур уже реализован в Admin Panel через модуль `Пользователи`; D2/emergency remediation не должен его дублировать.
- `FRONTEND_v168` — owner-controlled frontend authority. Самостоятельные изменения frontend runtime/UX/text в backend/financial циклах запрещены: при необходимости оператор готовит ТЗ и предложенный код владельцу, а изменение входит в следующий owner frontend patch. Текущая итерация не меняет `frontend/src` или `frontend/public`.
- Test Authority уточнён: stale test разрешено удалить только при высокой уверенности после сверки с актуальными OWNER DECISION/CANON/NORM/SSOT; при сомнении test сохраняется и конфликт эскалируется владельцу. P0 financial/security/business invariants не ослабляются.
- Immutable report `02374`; следующий `02375`; canonical handoff `EFHC_Bot_v174_56.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.55 / цикл 1796 / CI `87542599519` GREEN + FRONTEND_v168 + D2

- GitHub CI `87542599519` проверил точный `v174.54`: SHA-256 `fc8d18a59f9d7dec91cd2ecb8d0ca0cfaa8ae1cb9c015ad5014f4aec2f196861`, checkout `2c8b5fab3b21f608d77daa54782963e971f9ff35`; все recorded gates GREEN, pytest `1745 passed / 22 skipped / 1 warning`. `v174.54` является новым подтверждённым точным GREEN-якорем.
- В цикл 1796 внедрён owner-approved `FRONTEND_v168`: patch SHA-256 `6de94223431af7ee8856bfdf069b8e39efd22df6486525cb485f274cc070963d`, `41` frontend path, конфликтов применения не было; внешний `.patch` не является частью текущего HEAD/релизного ZIP.
- Frontend authority переведён на FRONTEND_v168 и расширен до `211` контролируемых source-path. FAQ остаётся checked-in production authority; FAQ SSOT не переписывает runtime FAQ.
- Финальное owner-уточнение D2: ручные Shop `price_ton`/`price_usdt` имеют максимум D2; значения >D2 отклоняются без скрытого округления. После проверки цена конвертируется в native atomic units: TON `10^9`, USDT `10^6`; внутренний EFHC и `efhc_amount_d8` остаются D8.
- Emergency EFHC deposit получает сумму из exact transport-v2 `amount_atomic/token_decimals`, затем применяет external EFHC D2 ROUND_DOWN; автоматический fallback на native `ton_inbox_logs.amount` не используется. Legacy row без evidence делает authoritative refetch либо завершается fail-closed.
- Frozen `0001` не менялся; `0002+` не создавались. Backend HTTP surface остаётся `162 paths / 168 public operations / 169 schemas / 8 hidden / 176 mounted`.
- Immutable report `02373`; следующий `02374`; canonical handoff `EFHC_Bot_v174_55.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.54 / цикл 1795 / CI `87533782588` qualification repair

- GitHub CI `87533782588` проверил exact `v174.53`: SHA-256 `b850f2ccd6cb1f43300e6b476ed6331f35594b1f82328e3c50acac5ee28de0df`, checkout `f5e1540bd7856b31a655e98d55e50334877a40fd`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED только pytest: `4 failed / 1741 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: missing AI Archive Laws reference в новом Test Guard manifest; stale current frontend authority version metadata; три сдвинутых exact identity line anchors; direct-script import defect Anti-Stale checker.
- Все repairs относятся к qualification/tooling/governance. Backend/frontend runtime, финансовая модель, Shop pricing, TON/USDT atomic settlement, external EFHC D2, BANK/ledger, temporal/replay ordering и Telegram transaction ownership не менялись.
- Test Authority / Anti-Stale Contract сохраняется без ослабления: полезные fail-closed invariant tests не удалялись; stale implementation expectations не имеют права переопределять active OWNER DECISION/CANON/NORM/SSOT.
- Frozen `0001` не меняется; `0002+` не создаются. Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.54` требует fresh exact-head GitHub CI.
- Immutable report `02372`; следующий `02373`; canonical handoff `EFHC_Bot_v174_54.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.53 / цикл 1795 / CI `87522913463` + Test Authority / Anti-Stale

- GitHub CI `87522913463` проверил exact `v174.52`: SHA-256 `f06ccd41922f753debecf32196815994eb3bc845ed06d9dfa20d6a9959901de0`, checkout `c55f6b0a9478df58b6c2bc40115a282d56fd7913`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED: Ruff `4`, Mypy `1`, pytest `4 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: четыре Ruff import-order diagnostics; один Mypy return-type diagnostic в ADS scheduler adapter; один stale hardcoded Admin seam count; один реальный compatibility regression, породивший три pytest failure — `wallets_service._confirm_payment_intent()` не пропускал canonical `external_amount_atomic/external_decimals`.
- Runtime repair ограничен compatibility facade и не меняет финансовую модель: atomic TON/USDT, external EFHC D2, ledger, replay/time barrier, Shop pricing и Oracle/FX prohibition сохранены.
- OWNER DECISION: действует `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`. Тест не является SSOT; authority: OWNER DECISION → CANON/SSOT/NORM → runtime invariant → guard/test. Stale expectation обновляется или удаляется в той же итерации; правильный runtime запрещено откатывать только ради stale implementation test.
- Удалены brittle exact-count locks для mutable test/API surface; behavioural/parity/security/financial invariants сохранены. Structural anti-stale guard включён в test-suite integrity.
- Frozen `0001` не меняется; `0002+` не создаются. Последний exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.53` требует fresh exact-head GitHub CI.
- Immutable report `02371`; следующий `02372`; canonical handoff `EFHC_Bot_v174_53.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.52 / цикл 1795 / CI `87512306629` remediation

- GitHub CI `87512306629` проверил exact `v174.51`: SHA-256 `79d07b081fb73060f1ecd85b0cec61b4800912ade2f865fb7bb2968abfbb0e11`, checkout `1d022dfba994e4f09d35ffdf7f177823abb0b379`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic и npm install. RED: Ruff `6`, Mypy `7`, frontend build `1` TypeScript error, pytest `20 failed / 1722 passed / 22 skipped / 1 warning`.
- Подтверждённые причины сгруппированы: release executable-mode defect; generated frontend/admin seam drift; source lint/type diagnostics; stale qualification expectations после owner-approved Financial Audit №3; history/directory/hash manifest drift.
- Исправления не меняют Shop economics, asset-native TON/USDT settlement, external EFHC D2, withdrawal `Оплатить → Оплачено`, NFT paid gate, Admin audit, ADS reconciliation, P0 temporal barrier или canonical ledger reporting. Oracle/FX не восстанавливаются.
- Frozen `0001` не меняется; `0002+` не создаются. Public source surface остаётся `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`; новые routes в этом цикле не добавлялись.
- Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.52` требует собственного fresh exact-head GitHub CI.
- Immutable report `02370`; следующий `02371`; canonical handoff `EFHC_Bot_v174_52.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.51 / цикл 1794 / Financial Audit №3 remediation

- GitHub CI `87472108257` проверил exact `v174.50`: SHA-256 `ec735a9a631fde9c6275d62b19cdc5b15d53c0b5daca9d3fb85066699df46cc3`, checkout `22d9a9a7b95e42c4980c3019bea6fa53d99807e3`; все recorded gates GREEN, pytest `1729 passed / 22 skipped / 1 warning`. `v174.50` теперь **EXACT-HEAD GREEN**.
- Цикл 1794 исполняет direct owner-approved Financial Audit №3: FIN-01/03/04/05/06/07/08/09 подтверждены source и исправлены; FIN-10 остаётся закрытым, Oracle/FX не восстанавливаются.
- External TON/USDT отделены от EFHC D8 и фиксируются/settle в asset-native atomic units; внешний EFHC deposit/withdraw использует D2 ROUND_DOWN → internal D8.
- Withdrawal разделён на payout evidence и explicit `Оплачено`; NFT unpaid approval запрещён; Shop force-fulfill имеет required Admin audit; zero-price fail-closed; ADS reward reconciliation и canonical ledger reporting добавлены.
- P0 порядок settlement: trusted time → 180-day barrier → replay/idempotency → mutation → ledger. Frozen `0001` неизменён, `0002+` отсутствуют.
- Static public surface после двух новых explicit withdrawal actions: `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`. Live proof — следующий GitHub CI.
- Immutable report `02369`; следующий `02370`; canonical handoff `EFHC_Bot_v174_51.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.50 / цикл 1793 / CI `87405882481` qualification repair

- GitHub CI `87405882481` проверил exact `v174.49`: SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768`, checkout `b69ed98e13c7995343429df2975fe2e893ada297`. SHA payload полностью совпадает с предоставленным физическим HEAD.
- GREEN: Development HEAD SHA-256, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic upgrade, npm install и frontend build. RED только pytest: `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая первопричина — drift русскоязычной инженерной документации: active guard обнаружил `14` новых англоязычных narrative-строк (`6` в `KERNEL.md`, `8` в `START_HERE.md`). Это корректный fail-closed qualification guard, а не stale test и не runtime defect.
- Исправлены только эти `14` строк. Baseline и сам test не изменялись; backend/frontend runtime, Shop pricing, financial SSOT, schema и transaction ownership не откатывались.
- Последний подтверждённый exact-head GREEN остаётся `v174.47` / CI `87290901436`. `v174.50` GREEN не считается до fresh exact-head GitHub CI.
- Immutable report `02368`; следующий `02369`; canonical handoff `EFHC_Bot_v174_50.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.49 / цикл 1793 CI qualification repair

- Run `87290901436` полностью квалифицировал exact `v174.47`: SHA-256 `587c43298864805e7339ce6f88c8f7e284660c59a50449433a5811009b21b698`, checkout `cf3aea612813ce3cf43fe9b64d0ecfcdf35a4976`, все recorded gate exits `0`. `v174.47` = **EXACT-HEAD GREEN**.
- Более новый run `87386543243` проверил exact `v174.48`: SHA-256 `607da2ba1f2643266d2e62eb070790a1f8b3d2e5c3bbd46c31c44208ef22d826`, checkout `6760c21915d6cd605c7e461e99485b043a0fd980`; все recorded gates GREEN, кроме pytest `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — brittle Shop architecture guard: после подтверждения всех runtime invariants он требовал буквальную форму `"ручную цену"`, тогда как active NORM уже фиксирует `администратор независимо задаёт` `price_ton`/`price_usdt` и manual price runtime authority.
- Исправлен только guard: он проверяет канонический смысл, а не падежный литерал. Shop runtime/NORM, owner pricing decision, frozen `0001`, FAQ и FRONTEND_v146 не откатываются.
- Локальные project tests/build/CI не запускались. Immutable report `02367`; следующий `02368`; canonical handoff `EFHC_Bot_v174_49.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.48 / цикл 1793 ручное Shop pricing

- Прямое owner decision: Shop TON/USDT pricing является ручным. `price_ton` и `price_usdt` карточки — единственный runtime authority; внешняя price/oracle/FX dependency отсутствует.
- `backend/app/routes/hub_routes.py` больше не имеет special-case `CUSTOM_EFHC`, автоматического курса `0.3` или TON oracle blocker. Любой checkout item проходит canonical Shop service и использует сохранённую admin price.
- Legacy `custom_efhc_amount_d8` оставлен compatibility-only и игнорируется. Payment Intent фиксирует выбранную цену на TTL; reprice существующего intent запрещён.
- Public route count/schema shape сохраняются; поле compatibility не удалено. Frozen `0001`, `0002+` отсутствует, FAQ/FRONTEND_v146 не меняются.
- Локальные project tests/build/CI не выполнялись. `v174.48` — CANDIDATE до следующего exact-head GitHub CI.
- Immutable report `02366`; следующий `02367`; handoff `EFHC_Bot_v174_48.zip`.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# OPERATOR KERNEL CURRENT — v174.47 / цикл 1793 CI qualification repair

- Exact evidence: CI `87288059313` на `v174.46` SHA `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`; все recorded gates GREEN кроме одного pytest language-policy failure.
- Current repair authority: не переписывать historical handoff evidence; baseline `CONTINUE_IN_NEW_CHAT.md` синхронизирован с фактическими `53` historical English fragments вместо stale `36`.
- Runtime/schema/FAQ/FRONTEND_v146 не меняются. Текущий report `02365`, следующий `02366`; `v174.47` требует fresh exact-head GitHub CI.

# OPERATOR KERNEL CURRENT — v174.46 / цикл 1793 CI qualification repair

- Exact evidence: CI `87285361835` на `v174.45` SHA `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`; RED локализован в Ruff import-order и 17 pytest failures.
- Current repair authority: Panels использует canonical financial SSOT напрямую; stale import-format и unsafe-JSONB guards синхронизированы с current source; `deps.py` import-order исправлен.
- Frozen schema/FAQ/FRONTEND_v146 сохраняются. Current report `02364`, next `02365`; `v174.46` требует fresh exact-head GitHub CI.

# OPERATOR KERNEL CURRENT — v174.45 / цикл 1793 CI qualification repair

- Exact evidence: CI `87278222904` на `v174.44` SHA `54b882e871626e7190161c419e9c1f407c9b6a6080478465570ab08856354154`, checkout `001316adea12d34348a510da3cc8b401cbc6f199`; frontend/PostgreSQL/Alembic GREEN, qualification RED локализован.
- Current repair authority: устранить только подтверждённые missing import, JSONB bind-cast и stale qualification expectations; deep-remediation ownership contracts не откатывать.
- Frozen schema/FAQ/FRONTEND_v146 сохраняются. Текущий report `02363`, следующий `02364`; `v174.45` требует fresh exact-head GitHub CI.

# OPERATOR KERNEL CURRENT — v174.44 / цикл 1792 deep backend remediation

- Exact source baseline: v174.43 SHA `0b36f6f734c8a0e3dd94d68b5b35c05331a078845d657bf5021620280d19c739`; CI `87235658448`, checkout `ce2f5085551ff06c1e6a1512eccc6dec3749f049`; это входное доказательство цикла.
- Утверждённый владельцем Deep Backend Remediation Spec SHA `5873aeff006f6cb52b3c2642ce6f7e326615ba6f94ca2ad735ec78dc801af16c` разрешает исправление подтверждённых DEF-01…18.
- Active ownership canon: application boundary владеет root transaction; scheduler/runtime DB использует `db_session`; cancellation пробрасывается; FSM RMW атомарен по key; financial spend runtime импортирует canonical rule.
- Owner locks frozen schema/FAQ/FRONTEND_v146 не меняются. Потенциальные scale/deployment risks без evidence не повышаются до статуса defects.
- Текущий report `02362`; следующий `02363`; v174.44 требует fresh exact-head GitHub CI.

# OPERATOR KERNEL CURRENT — v174.43 / цикл 1792 CI qualification repair

- Exact supplied GitHub CI `87220054352` проверил `v174.42` SHA-256 `2ef41df8ec14235d584ccc2a2994cca780c58d0e993de2aacdba3957c56384c8`, checkout `fe6d0d4f32a75d8419f0d165afffc18fef76cc02`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend production build.
- RED: Ruff `16`; Mypy `1`; pytest `11 failed / 1691 passed / 22 skipped / 1 warning`.
- Confirmed repair scope: 15× Ruff B904 exception chaining + 1× UP037; TonConnect typed/stable fail-closed reason; scheduler `HEALTH_MAX_AGE_SEC` direct alias; owner env template parity; watcher/test harness adaptation to trusted-time-before-replay; webhook test-double signatures.
- P0 watcher order, Telegram atomic webhook transaction, FAQ authority, FRONTEND_v146 visual/UX/text, schema/frozen `0001` and application route surface не откатываются.
- Current report `02361`; next `02362`; next exact-head GitHub CI required for `v174.43`.

# OPERATOR KERNEL CURRENT — v174.42 / цикл 1791 corrective re-audit

- Physical Development HEAD после текущего repair: `v174.42`; canonical archive name `EFHC_Bot_v174_42.zip`.
- GREEN anchor: exact `v174.40`, CI `87088984879`; current `v174.42` не квалифицирован и обязан пройти fresh exact-head CI.
- Owner-authorized input: technical spec SHA-256 `7f17d680a06cca5cc581a27a0cf1577d5c0a51e9cbe1c3184ad40ae0969b75e8` для exact `v174.41` input `baf1ab7b318c69988a4079d8aef022092e4a0499579058e99431cf58903b9a2c`.
- Active routing приоритет: owner ТЗ → active SSOT/CANON/NORM → exact source → immutable evidence. Re-audit defects исправлены без FAQ/schema/economy drift.
- Telegram transaction boundary, 5xx redaction, trusted host/TonConnect domain, idempotency, scheduler, logging, PWA cleanup и DB-session lifecycle являются текущими repaired contracts.
- Report current `02360`; next `02361`; cycle `1791`; next exact-head GitHub CI required.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.41 / цикл 1791 exact-head GREEN + полный функциональный аудит

- GitHub CI `87088984879` полностью квалифицировал exact `v174.40`: archive SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`; все recorded gate exits `0`; pytest `1670 passed / 22 skipped / 1 warning`; frontend production build и PostgreSQL/Alembic PASS. `v174.40` зафиксирован как **EXACT-HEAD GREEN**.
- По прямому owner order открыт цикл `1791` и выполнен полный статический аудит зарегистрированной application surface и всех финансово/security/ops-critical mutation contours. Public surface сохранён: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`; registered protected Python surface `371 symbols / 70 modules / 86 files`; frontend product pages `39`.
- Подтверждённые repairs нового candidate: watcher P0 `trusted time → 180-day barrier → replay → mutation → ledger`; readiness принимает только authorized migration `0001`; `/cron/tick` в prod/stage регистрирует scheduler jobs strict; encrypted recovery требует ciphertext SHA-256; production update/release contour использует канонический `EFHC_Bot_vNNN_NN.zip` без `_RELEASE`.
- DR/VPS runbooks и current application-function authority синхронизированы с exact source. Referral leaderboard public routes отмечены retired при сохранённой referral economy; Skins — progression-only, `/skins/buy/{skin_id}` остаётся fail-closed compatibility `409 SKIN_COMMERCE_DISABLED`.
- Database schema не менялась: ORM `52 = 45 core + 7 admin`, frozen `0001` сохранён, `0002+` отсутствует. Schema lock — governance lock на неутверждённый DDL, не runtime table/CRUD lock.
- FRONTEND_v146 runtime bytes не менялись. Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.41_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ/locale/PWA остаются standalone checked-in release assets.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI после audit repairs не запускались. Поэтому `v174.41` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**, а не GREEN.
- Immutable report: `02359`; следующий `02360`. Canonical handoff: `EFHC_Bot_v174_41.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.40 / цикл 1790 CI qualification hygiene

- GitHub CI `87074955772` проверил exact `v174.39`: SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872`, checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`. GREEN все recorded gates кроме pytest; pytest `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Единственный confirmed defect — два английских docstring в development-only FAQ duplicate-control verifier. Исправлены только docstring; runtime/frontend/backend/schema semantics не менялись.
- FAQ остаётся самостоятельным checked-in release asset; SSOT — duplicate control only, без runtime write. Release packaging остаётся application-byte verify-only.
- Важно: database/schema lock — это governance lock на неутверждённые DDL/schema/migration changes, **не** runtime lock таблиц и **не** запрет CRUD. Существующие 52 таблицы работают штатно. Frozen `0001` и запрет `0002+` сохраняются до отдельного direct owner decision о schema unlock/change.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.40_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. Frontend controlled bytes не менялись.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не запускались. Candidate `v174.40` требует следующего exact-head GitHub CI.
- Immutable report: `02358`; следующий `02359`. Canonical handoff: `EFHC_Bot_v174_40.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.39 / цикл 1790 release-asset independence + CI qualification repair

- GitHub CI `87062684580` проверил exact `v174.38`: SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75`, checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`. GREEN: Development HEAD SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures классифицированы как qualification-only: hardcoded frontend authority предыдущей версии и два legacy-term guards, ошибочно сканировавшие current control-plane/evidence summaries. Runtime/backend/frontend product behavior этим CI не опровергнут.
- Прямое owner decision цикла 1790: checked-in frontend FAQ является самостоятельным production release asset; FAQ SSOT остаётся только дублирующим контролем и не может генерировать или переписывать runtime FAQ.
- Release packaging переведён в verify-only application-asset mode: `build_release_archive.py` проверяет заранее готовые FAQ/locale/PWA assets и не запускает FAQ/PWA generators. Packaging создаёт только собственные release metadata/checksums в staging.
- Dependency audit: frontend prebuild уже verify-only; OpenAPI/API/backend/schema runtime не генерируются из docs/SSOT при release packaging; development generators остаются вне packaging.
- Database migration lock остаётся active: frozen `0001_initial_release_schema.py`; `0002+`/schema expansion только по отдельному direct owner decision. В cycle 1790 schema не менялась.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.39_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ content Q/A bytes не менялись; изменён только authority header и release-control metadata.
- Локальные tests/build/CI/Alembic/PostgreSQL не запускались. Candidate `v174.39` требует следующего exact-head GitHub CI.
- Immutable report: `02357`; следующий `02358`. Canonical handoff: `EFHC_Bot_v174_39.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.38 / цикл 1789 continuation CI qualification repair

- GitHub CI `86992003426` проверил exact `v174.37`: SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d`, checkout `7384e8284dbde416086a13bd23de7136be585681`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures repaired только в qualification layer: stale Admin history literal → current functional contract; FAQ test function name → Russian engineering policy; stale `current_cycle` → current state key `cycle`. Approved FRONTEND_v146 runtime не откатывался.
- FAQ current parity: `13 × 250/250` SSOT↔runtime. Runtime/prebuild SSOT-independent; release packaging пока SSOT-generating. Standalone verify-only FAQ packaging — **RECOMMENDATION, не owner decision**, поэтому release scripts не менялись.
- Routes/schema audit: `160 paths / 166 public ops / 8 hidden / 174 mounted`; OpenAPI `169 schemas`; ORM/frozen migration exact `52 = 45 core + 7 admin`. Migration lock остаётся active: `0001` frozen; `0002+` только по direct owner decision.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.38_FRONTEND_v146`; entries `195`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`. Backend routes/services, frozen `0001`, FAQ runtime и release scripts cycle continuation не менялись.
- Локальные tests/build/CI не запускались. Candidate `v174.38` требует следующего exact-head GitHub CI.
- Immutable report: `02356`; следующий `02357`. Canonical handoff: `EFHC_Bot_v174_38.zip`; descriptive suffixes/owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

## CURRENT DISPATCH — v174.37 / cycle 1789

Direct owner order 2026-08-18 opens cycle `1789`. Exact supplied CI `86988434882` tested `v174.36` SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77`, checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`; all recorded gates GREEN except pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. All three are stale qualification guards against owner-approved FRONTEND_v146 and are repaired without runtime rollback. Frontend runtime prebuild is detached from docs/SSOT, while release packaging still intentionally regenerates FAQ from FAQ SSOT before staging under the existing release architecture. Current candidate `v174.37` requires exact-head GitHub CI. Canonical archive name: `EFHC_Bot_v174_37.zip`.

# EFHC_OPERATOR_KERNEL_SSOT

Status: ACTIVE SSOT.
Archive: `v171.64`.

## Single source of truth

Operator Kernel is the active detailed operational dispatch layer of EFHC Bot.

Top goal:

```text
accelerate AI work by mapping project-specific keywords
→ task type
→ exact route
→ canonical anchors
→ exact files
→ patch boundary
→ targeted validation
→ proof/archive boundary
```

Kernel must not be demoted to navigation-only.

## Runtime truth

- Route configuration SSOT: `ops/operator_kernel/config/routes.yaml`.
- Runtime resolver: `ops/operator_kernel/route_resolver.py`.
- Task language: `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md` plus `task_classifier.py`.
- Domain map: `docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md`.
- Startup map: `ops/operator_kernel/cache/file_map.summary.json`.
- Machine index: `ops/operator_kernel/cache/file_map.json`, not full-read.
- Context packet: `ops/operator_kernel/context_capsule.py`.

## Protected invariants

1. Single startup entrypoint: `START_HERE.md`.
2. Detailed operational Kernel with no duplicate historical Current HEAD blocks.
3. Основное разрешение маршрутов выполняется через YAML.
4. Классификатор сохраняет специфичное для EFHC поведение.
5. Используется точечное чтение маршрута вместо полного чтения архива.
6. Для frontend-работ используется screenshot-доказательство, привязанное к маршруту.
7. Для утверждений о CI, live и release действует точная граница доказательств.
8. Раздельные development и release archives.
9. Фиксированная нижняя навигация из шести кнопок, если OWNER прямо её не изменил.
10. Составные запросы сохраняют primary route и ограниченные secondary routes.
11. Дубли active control rules консолидируются; compatibility paths содержат только pointers.
12. AI documents являются operational memory, а не историей; approved decisions переносятся в active authority и удаляются из temporary memory.
13. История хранится только в канонических `docs/cycles/`, `docs/chats/`, `reports/numbered/` и во внешнем `ARTIFACTS_HISTORY` ZIP; удалённые `docs/history/`/`АРТЕФАКТЫ/` не являются runtime dependency.
14. Канонический тайм-аут задания GitHub CI составляет 10 минут.
15. Вопросы и ответы для OWNER ведутся только с добавлением новых записей в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`: каждый вопрос регистрируется до отправки, а ответ никогда не стирает исходный вопрос. При подозрении на пробел или прямом указании OWNER на восстановление Kernel обязан проверить все доступные нумерованные стенограммы чатов и не выводить отсутствующие ответы предположением.

## Текущее состояние

`v173.26 / cycles 1704-1705`: Operator Kernel использует только active authority и канонические history roots. Удалённые `docs/history/` и `АРТЕФАКТЫ/` не читаются и не восстанавливаются из-за старых tests/guards. `reports/numbered/` остаётся immutable evidence, а production RELEASE не содержит development history.


## Текущее состояние — v174.33 / cycles 1786–1787

GREEN parent `v174.32` квалифицирован exact-head CI `86656504640` со всеми GREEN gates. Operator Kernel обязан считать direct OWNER scope `1786–1787` authority. Текущая Admin Shop navigation использует один canonical `/admin/shop` source с deep-links `?module=orders|nft`; cycle `1787` требует синхронизации Q/A + current SSOT/handoff + numbered chat transcripts перед финальным ZIP handoff. После `1787` будущий functional cycle автоматически не открывается.


## Текущее состояние — v174.34 / cycle 1787 historical Q/A recovery

Exact-head `v174.33` квалифицирован GitHub CI `86661926957`, все gates GREEN. Cycle `1787` сохраняет OWNER-approved scope консолидации archive/Q&A/SSOT. Проверены все `35` доступных numbered chat transcripts; инвентаризированы `58` explicit Q/A markers, recoverable OWNER decisions append-only добавлены в canonical Q/A register, а context-incomplete/unanswered historical items оставлены non-canonical. Production/backend/frontend semantics не изменены. После cycle `1787` будущий functional cycle автоматически не открывается.

## Текущее состояние — v174.35 / cycle 1788 FRONTEND_v146 integration

Direct OWNER order от 2026-08-18 открывает cycle `1788`. Physical HEAD остаётся `v174.35`; FRONTEND_v146 runtime-only patch интегрирован в normal frontend source и удалён после merge. Integrated source authority: `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`. Backend/CANON сохраняет authority для API/data/security/identity/economy. Последний доступный exact-head GREEN остаётся `v174.33` / CI `86661926957`; новый `v174.35` требует собственного exact-head GitHub CI. В текущем handoff нет нового CI-log artifact, поэтому CI failure не выводится. Future range `1801-1900` создан без automatic cycle approval.

## Текущее состояние — v174.61 / cycle 1801 protective Panel lifecycle

Direct owner scope реализует упрощённый protective Panel contract без debt/per-panel exchange attribution. Перед void выполняется transaction-neutral checkpoint всех живых Панелей пользователя; затем `U=min(G,A)`, `R=G-U`, `NET=100-R`, energy mirror корректируется `total_generated_kwh -= G` и `exchanged_kwh_total -= R`. Dead marker `panels.meta.protectively_voided=true` исключается из обычных списков/scheduler/aggregates, но доступен exact Admin lookup и audit/export. Повторная активация только dead Panel и только за новые 100 EFHC. FRONTEND_v182 reconciliation handoff является обязательным входом следующего owner frontend patch. Candidate требует fresh exact-head CI.
