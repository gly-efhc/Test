<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT: Архитектура защиты и реконсиляции Shop-транзакций (External Payment Flow)

**ID документа:** SSOT-SHOP-PAYMENTS-001  
**Статус:** УТВЕРЖДЕНО (Канон)  
**Уровень строгости:** КРИТИЧЕСКИЙ (Финансовый контур)  
**Цель:** Стандартизация процесса покупки через внешние криптокошельки, обеспечение гарантии атомарности «один товар = одна транзакция» и защита от фрода.

## 1. Фундаментальные инварианты (Canon)
1. **Запрет анонимных платежей:** Любая транзакция без валидного, сгенерированного сервером MEMO считается нераспознанной и не зачисляется в систему.
2. **Серверная генерация Payload:** Клиент не имеет права формировать MEMO/Payload. Идентификатор платежа генерируется исключительно на бэкенде в момент создания заявки.
3. **Принцип «Товарная карточка» (Intent First):** Транзакция может быть подтверждена только при наличии в БД предварительно созданной записи ShopOrder / PaymentIntent в строгом статусе PENDING.
4. **Фиксация цены:** Сумма к оплате (`amount_asset_d8`) фиксируется в момент создания PENDING заказа. Последующие изменения цен в каталоге на этот заказ не влияют.
5. **Двойная изоляция (Scheduler):** API-роуты фронтенда никогда не подтверждают факт оплаты. Подтверждение осуществляется исключительно изолированным фоновым процессом (Watcher/Scheduler), который читает данные из блокчейна (`TonInboxLog`).

## 2. Формат и защита идентификатора (MEMO)
MEMO выступает как криптографический маркер связи между внешним миром и внутренней БД.

- **Обязательный формат:** Строка должна включать `global_id` покупателя и `order_id` (или `intent_id`). Пример: `BUY:EFHC:<qty>:TG:<global_id>:OID:<order_id>`.
- **Защита от Altruistic Attacks:** Наличие `global_id` в MEMO гарантирует, что оплата будет зачислена только владельцу заказа. Watcher обязан сверять `global_id` из MEMO с `global_id` владельца карточки заказа в БД.

## 3. Специфика сверки сумм и ассетов (Asset Verification)
Процесс реконсиляции строго разделен на две ветки в зависимости от типа валюты (`asset_currency`). Сравнение сумм происходит на абсолютное равенство (`==`), частичные оплаты (`<`) и переплаты (`>`) не зачисляются автоматически.

### Ветка А: Нативный TON
1. Извлекается поле `incoming_tx.value`.
2. Ожидаемая сумма `intent.amount_asset` приводится к нанотонам (`10^9`).
3. **Условие:** `incoming_tx.value == expected_value_in_nanotons`.

### Ветка Б: USDT (Jettons)
1. **Проверка контракта:** Watcher обязан проверить адрес смарт-контракта отправителя события (`JettonTransferNotification`), чтобы исключить поддельные Scam-токены.
2. **Извлечение суммы:** Нативный `value` транзакции игнорируется (содержит газ). Сумма извлекается из поля `forward_amount` / Jetton payload.
3. **Условие:** Сверка происходит с учетом 6 знаков (`10^6`) для USDT в сети TON: `jetton_amount == expected_usdt_amount`.

## 4. Жизненный цикл заказа (State Machine)
1. **PENDING (Ожидание):** Заказ создан. Зафиксированы `global_id`, `amount_asset`, `asset_currency`. Активирован TTL.
2. **PAID_AUTO / COMPLETED (Успех):** Watcher нашёл транзакцию, MEMO совпало, суммы совпали, контракт валиден. Товар зачисляется.
3. **CANCELLED (Отмена пользователем):** Связка «Мемо-Заказ» разорвана. Поступившие после этого платежи по данному MEMO не зачисляются.
4. **EXPIRED (Таймаут):** TTL истек. Обработка аналогична CANCELLED.

## 5. Идемпотентность (Idempotency Lock)
Для предотвращения атаки двойного списания (Double Spending) или дублирования начисления при перезапуске Watcher:

- Ключом идемпотентности выступает хэш транзакции блокчейна: `tx_hash`.
- Глобальная on-chain settlement identity хранится в `efhc_core.tx_hash_locks` с `UNIQUE(tx_hash)`.
- Business idempotency keys в ledger могут существовать дополнительно, но не заменяют global settlement lock.
- **Процесс:** До смены статуса и любого начисления `tx_hash` атомарно заявляется через canonical settlement service. Conflict другого purpose/owner/intent/order немедленно блокирует финансовое действие. Точный повтор того же claim допускается только как идемпотентный read-through.

## 6. Директива для интеграции
Любой код, обрабатывающий маршрут `/shop/order-external` или процесс `AdminTonReconcile`, обязан строго соответствовать каждому пункту данного документа. При расхождении кода и данного SSOT код считается содержащим критический дефект и подлежит рефакторингу.


## 7. Cycle 1744 — owner-scoped order idempotency и атомарная EFHC-покупка

Для `shop_orders` canonical business idempotency identity — пара
`(global_id, idempotency_key)`. Fresh pre-release schema обязана обеспечивать
её `UNIQUE`; `ON CONFLICT`/read-through используют ту же owner-scoped пару.

Наличие совпавшего ключа само по себе не является успешным replay. До
read-through сервер обязан сверить immutable fingerprint исходного заказа:
`sku`, item type, payment method, request quantity, unit/snapshot amount,
expected amount и destination, когда она относится к external payment.
Несовпадение является конфликтом повторного ключа и не создаёт новый order.

Покупка Shop за внутренний EFHC является одной root DB transaction:

```text
USER BONUS/MAIN debit + BANK_EFHC credit
→ shop_order
→ один commit
```

Shop использует только caller-owned nocommit money primitive. Если создание
или проверка `shop_order` завершается ошибкой, root transaction откатывает и
проводку, и order. Для replay дополнительно проверяются фактические derived
ledger keys `:bonus`/`:main` и сохранённый financial payload, чтобы старый
денежный key нельзя было принять за покупку другого SKU/quantity.

Успешный EFHC purchase response формируется из фактически сохранённых
order/ledger facts, а не из нового request поверх уже committed operation.

## 8. External Shop quantity contract

Поле `ShopOrderExternalIn.quantity` сохраняется как public compatibility
surface. В текущем release-контуре один external Shop order соответствует
ровно одной catalog position, поэтому допустимо только `quantity = 1`.
Значение больше `1` не может молча игнорироваться. Поддержка multi-quantity
требует отдельного server-side CANON для price snapshot, stock/limits и
fulfillment и не вводится неявно.

## 9. Sale package release authority

Release pricing/quantity authority для пользовательских deposit packages —
`efhc_core.shop_items`. Legacy `efhc_admin.efhc_sale_packages` не является
SSOT реальной продажи и не может создавать ложный writable control plane.

Поэтому до отдельной owner-approved миграции editor на canonical ShopItem:

- read/compatibility surface может сохраняться;
- mutating `/admin/sale-packages` create/update/toggle обязаны fail-closed
  возвращать `409 SALE_PACKAGES_NOT_RELEASE_SSOT`;
- успешная запись только в `efhc_admin.efhc_sale_packages` не должна
  представляться как изменение цены/количества реальной продажи.


## 10. 180-дневная финансовая исполнимость внешнего settlement

Новый external settlement может впервые изменить деньги только при строгом
`trusted_operation_at` age `< 180 days`. Ровно 180 суток и старше —
`EXPIRED / NO CREDIT`. До любого `tx_hash` replay/idempotency claim и до
BANK/user mutation сервер обязан проверить две независимые временные authority:
доверенное время внешней операции и сохранённый server first-seen. Более новое
first-seen не может продлить срок старой операции. Повторная обработка обязана
использовать ранее сохранённое trusted time.

Физический retention `tx_hash_locks` пока не сокращается: target 180 суток
вводится отдельным retention-cycle только после green exact-head CI этого
barrier.

## Cycle 1794 — external amount boundary

Owner-Decision-Refs: `QA-2026-08-19-FIN3-09`, `FIN3-11`, `FIN3-12`.

- TON settlement authority = exact integer nanotons equality.
- USDT settlement authority = exact integer token-unit equality (`10^6`).
- TON/USDT amount не является EFHC D8.
- Internal financial result successful Shop payment = только `BANK_EFHC → USER EFHC` на `efhc_amount_d8`.
- Frozen `amount_asset_d8` = compatibility storage, не v2 settlement authority.
- `price_ton` / `price_usdt` остаются единственной manual catalog authority; atomic payload — immutable snapshot intent, не второй price SSOT.
- `price <= 0` запрещает checkout/PaymentIntent.
- Oracle/FX/automatic conversion отсутствуют и не восстанавливаются.
