# SUPERSEDED — исторический CANON monthly financial partitioning

Статус: **SUPERSEDED BY OWNER DECISION 2026-08-16**.

Physical monthly partitioning отменён владельцем как избыточно сложный и
не соответствующий главной цели упрощения/экономии. Active authority:
`docs/SSOT/FINANCIAL_RETENTION_CANON.md`. Ни один раздел ниже не разрешает
новый `PARTITION BY`, monthly partition или `DROP PARTITION`. Текст ниже
сохранён исключительно как engineering history прежнего design stage.

---

# CANON финансового retention / partition

Исторический статус до supersession: **OWNER-APPROVED FOUNDATION**.  
Цикл: `1777`, owner-decision gate после exact-head GREEN qualification циклов `1774–1776`.

## 1. Разделение двух границ

Финансовая исполнимость внешнего события и срок хранения history — разные
политики:

- первичное внешнее зачисление допустимо только при `trusted age < 180 days`;
- при `trusted age >= 180 days` результат всегда `EXPIRED / NO CREDIT` до
  replay/idempotency и до денежной мутации;
- detailed financial history хранится как текущий UTC-месяц + 12 предыдущих
  UTC-месяцев;
- целиком вышедший за окно безопасный month partition может быть удалён только
  после fail-closed проверки состояния;
- `users` balances и `BANK_EFHC` не входят в monthly DROP и хранят current
  state без этой retention-границы.

## 2. Ровно шесть monthly history tables

Owner-approved набор:

1. `efhc_transfers_log`;
2. `payment_intents`;
3. `shop_orders`;
4. `withdraw_requests`;
5. `withdraw_outcome_events`;
6. `ton_inbox_logs`.

Partition key foundation для всех шести: trusted server-side `created_at`.
Граница partition: полуинтервал `[YYYY-MM-01 00:00:00 UTC, next month)`.

Панели, `users`, `bank_balance`, `unmatched_incoming`,
`processed_external_events` и `referral_bonus_ledger` в этот DROP-контур не
входят.

## 3. Fail-closed contract конечных состояний

Calendar age сам по себе **никогда** не разрешает DROP.

- `payment_intents`: terminal — `CONFIRMED`, `EXPIRED`, `CANCELED`;
  `PENDING` блокирует.
- `shop_orders`: terminal — `PAID_AUTO`, `APPROVED`, `REJECTED`,
  `CANCELED`/compatibility `CANCELLED`; `PENDING` и
  `PAID_PENDING_MANUAL` блокируют.
- `withdraw_requests`: `PENDING` блокирует; `PAID` требует завершённого
  processing evidence; `REJECTED`/`CANCELED` безопасны только если hold не
  создавался либо refund уже завершён.
- `withdraw_outcome_events`: удаление допустимо только вместе с доказанно
  terminal parent `withdraw_requests`; FK нельзя ослаблять ради partitioning.
- `ton_inbox_logs`: terminal-safe только `credited`, `paid_auto`,
  `expired_no_credit`; retry/mapping/manual/error states блокируют DROP.
- `efhc_transfers_log`: append-only history не имеет lifecycle status, но
  удаляется только как часть полностью проверенного month bundle.

Month bundle считается безопасным только когда проверены **все шесть** таблиц.
Отсутствие данных о любой из них трактуется как блокировка.

## 4. Replay cleanup

`tx_hash_locks` не является detailed-history partition из списка шести.
Его отдельная owner-approved retention — 180 суток по
`trusted_operation_at`.

Cleanup boundary:

`trusted_operation_at <= now_utc - 180 days`.

Маркер моложе 180 суток сохраняется. На точной границе 180 суток marker уже
может быть удалён, потому что соответствующая external operation сначала
блокируется execution barrier и не способна впервые изменить деньги.

## 5. Current foundation и запрет destructive activation

Candidate foundation `v174.22` добавляет только pure planning/state-policy
service и tests. Он:

- не выполняет `PARTITION BY`;
- не выполняет `DROP`;
- не удаляет `tx_hash_locks`;
- не меняет frozen `0001`;
- не меняет BANK/balances/ledger mutation ordering;
- не создаёт permanent global idempotency registry.

Контрольная pre-partition копия:
`reports/generated/GREENFIELD_SCHEMA_CHECKPOINT_PRE_FINANCIAL_PARTITION_v174_21.json`.

Физический schema rewrite разрешается отдельным следующим этапом только после
GitHub CI этого foundation. До него сохраняются unresolved blockers:
PostgreSQL partition-key требования к global PK/UNIQUE и month-aware
referential integrity `withdraw_requests -> withdraw_outcome_events`.

## 6. Правило владельца о продолжении работы

Прямое решение владельца 2026-08-16: qualification-only failures не должны
останавливать дальнейшую разработку, если основной runtime/financial/schema
контур зелёный. Поэтому цикл `1774` сохраняется как qualification tail, а
цикл `1775` открыт staged-параллельно. Это не разрешает destructive retention
до CI foundation и не ослабляет P0 financial barrier.

## 7. Цикл 1776 — physical partition contract без DDL

Exact-head CI `86601931863` криптографически проверил `v174.22`.
Основной runtime/schema/frontend контур GREEN. Два red gate являются
qualification-only: Ruff import-order в architecture test и stale
`TEST_GUARD_MANIFEST` count `277` при фактических `278` test-файлах.

По прямому решению владельца это не блокирует функциональное продолжение.
Цикл `1775` считается функционально завершённым staged foundation, а `1776`
фиксирует физические blockers до любой destructive activation.

Добавлены:

- explicit current PK для каждой из шести tables;
- explicit global UNIQUE/idempotency authorities;
- explicit FK dependency graph;
- отдельный cross-table blocker
  `withdraw_outcome_events -> withdraw_requests`;
- fail-closed API `physical_partition_activation_allowed()`, который остаётся
  `False`, пока все blockers не разрешены;
- generated dependency graph
  `reports/generated/FINANCIAL_PARTITION_DEPENDENCY_GRAPH_v174_23.json`.

Цикл `1776` **не** выполняет `PARTITION BY`, `DROP`, rewrite frozen `0001`
или cleanup `tx_hash_locks`.

## 8. Зафиксированный функциональный roadmap после 1776

При сохранении текущего scope остаются восемь плановых функциональных циклов:

- `1777` — разрешение physical PK/UNIQUE/FK strategy;
- `1778` — monthly partition schema implementation + creation;
- `1779` — serialized fail-closed retention runner, guarded DROP и
  180-day replay cleanup;
- `1780` — Unified Profile History: ровно 50 logical operations,
  global ordering, stable keyset cursor;
- `1781` — CSV export;
- `1782` — XLSX export через `openpyxl`, bounded memory и formula-injection
  protection;
- `1783` — historical Admin user-operation concept `+100 BONUS` из BANK с ledger evidence
  и deterministic idempotency;
- `1784` — evidence-based retention/index/performance tuning.

Qualification repair iterations выполняются внутри соответствующего цикла и
не увеличивают этот функциональный roadmap автоматически.
## 9. Exact-head GREEN v174.23 и decision gate цикла 1777

GitHub CI `86603967868` криптографически проверил exact `v174.23`: SHA-256
`3c138eaa0be729f899ea1b6f75d65883f5c4e03b4049b2fd1decf7d6e065c73b`;
все gate exits равны `0`, pytest `1653 passed / 22 skipped / 1 warning`.

На этом основании:

- `1774` закрыт;
- staged foundation `1775` квалифицирован;
- physical blocker contract `1776` квалифицирован;
- открыт `1777` для утверждения physical PK/UNIQUE/FK strategy.

PostgreSQL declarative RANGE partitioning не позволяет сохранить прежние
`PRIMARY KEY`/`UNIQUE`, которые не включают partition key. Поэтому до прямого
решения владельца сохраняется fail-closed состояние:

- `physical_partition_activation_allowed() == False`;
- physical `PARTITION BY` не выполняется;
- `DROP` не выполняется;
- `tx_hash_locks` не очищается физически;
- frozen `0001` не изменяется.

Следующий шаг `1777` требует owner approval по глобальной idempotency/uniqueness
authority, composite physical PK и month-aware FK
`withdraw_outcome_events -> withdraw_requests`.

