# SSOT: Admin Withdraw TonConnect Flow

Дата: 2026-04-10
Статус: утверждённый рабочий контур V1 Blitz
Уровень строгости: высокий

## Назначение
Документ фиксирует канон ручного вывода через админ-панель с TonConnect как operator wallet runtime.

## Канон потока
1. Пользователь создаёт `/withdraw/request`.
2. Backend создаёт заявку со статусом `PENDING`.
3. Backend делает SSOT-hold EFHC на балансе пользователя.
4. Админ-панель показывает готовые payout cards без обязательного провала в detail.
5. Карточка должна содержать минимум:
   - id заявки;
   - внешний адрес пользователя;
   - сумму выплаты;
   - asset/runtime transport metadata;
   - action-path для оплаты.\
6. Администратор подтверждает payout через подключённый кошелёк TonConnect.
7. После успешного wallet-sign интерфейс завершает заявку через approve-path.
8. Если автоматический payout-path не сработал, остаётся manual fallback через approve/reject.

## Что считать деградацией
Деградацией считается любое состояние, при котором:
- admin withdrawals снова требуют копипаста адресов вручную;
- payout action скрыт за лишним detail-drilldown;
- TonConnect payout metadata отсутствуют в backend list response;
- approve-path существует, но TonConnect-path для администратора исчезает.

## Почему деградация вообще произошла
Подтверждённая причина по current HEAD:
- предыдущие волны концентрировались на финансовой безопасности:
  hold, status canon, approve/reject, audits;
- при этом operator runtime path деградировал до detail-split moderation shell;
- карточный payout UX и TonConnect operator path не были закреплены отдельным SSOT-документом;
- из-за отсутствия отдельного SSOT часть старого функционального смысла “withdraw as wallet-assisted payout” растворилась в общем admin withdrawals UI.

## Канон V1 Blitz
- фронт и бэкенд должны отдавать и использовать ready-to-pay card data;
- оператор не должен вручную переписывать адрес и сумму;
- TonConnect используется как wallet execution layer;
- approve-path остаётся финальным backend status transition;
- manual fallback остаётся допустимым safety path.


## Outbound Blitz Flow: «Магазин наоборот»
### 1. Генерация заявки
- Игрок в Telegram WebApp создаёт запрос на вывод.
- Backend мгновенно проверяет доступный баланс.
- Сумма переводится в d8 и замораживается через SSOT-hold.
- В БД создаётся `withdraw_request` со статусом `PENDING`.

### 2. Витрина выплат
- Администратор открывает `/admin/withdrawals` с мобильного устройства.
- Вместо бухгалтерской таблицы основной рабочей поверхностью становятся immutable cards.
- Карточка обязана показывать:
  - идентификатор игрока или заявки;
  - сумму выплаты;
  - адрес кошелька;
  - transport/runtime metadata для кошелька.
- Эти поля не должны редактироваться вручную.

### 3. Процесс «покупки» администратором
- Администратор нажимает `Оплатить`.
- Фронтенд использует TonConnect SDK и открывает кошелёк администратора.
- Кошелёк получает готовую транзакцию из карточки/metadata без ручного copy-paste.
- Администратор подписывает payout своим кошельком.

### 4. Instant Success
- После успешного wallet-sign фронтенд отправляет сигнал бэкенду.
- Бэкенд переводит заявку из `PENDING` в `COMPLETED/PAID` по текущему withdraw canon.
- Ранее замороженные EFHC окончательно списываются из системы.
- Для V1 Blitz backend доверяет факту operator wallet-sign как финальному сигналу завершения.

### 5. Визуальный финал
- После смены статуса карточка исчезает из активной витрины.
- Администратор сразу видит следующую заявку.

## Почему это безопасно для MVP
- не требует полноценной автоматической ончейн-оркестрации;
- сохраняет средства под контролем оператора;
- исключает ручной ввод адреса и суммы;
- оставляет manual fallback path через approve/reject.


## 2026-04-11 — уточнение канона после audit iteration

### Главная правка смысла
- Для текущего канона вывода подтверждением выплаты считается факт
  нажатия кнопки `Send / Отправить` в Tonkeeper, MyTonWallet или
  совместимом кошельке администратора.
- Не требуется вводить отдельную обязательную стадию
  «блокчейн окончательно подтвердил tx» как единственный валидный proof
  для operator approve-path.
- Логика причины: после нажатия `Send` транзакция уходит на уже
  вшитые ботом реквизиты, а оператор не управляет дальнейшим сетевым
  прохождением транзакции.

### Что считать proof в V1 Hardening
- primary proof: нажатие `Send` в совместимом кошельке;
- secondary technical evidence: `tx_hash` можно сохранять как
  дополнительный атрибут журнала, если он уже доступен;
- нельзя требовать ручного копипаста адреса и суммы как доказательства;
- нельзя притворяться, что доказательство отсутствует, если был
  зафиксирован реальный wallet-send action.

### Обновлённый truth-path
1. Игрок создаёт заявку на вывод.
2. Администратор открывает payout-card.
3. Фронтенд передаёт в кошелёк уже готовую payout-транзакцию на вшитые
   реквизиты.
4. Администратор нажимает `Send / Отправить`.
5. Именно этот факт считается валидным подтверждением вывода в текущем
   каноне.
6. `tx_hash` может быть записан дополнительно, но не является
   единственным разрешённым proof-trigger.


## V1 Canon: operator payout finalizes withdraw

В EFHC Bot V1 admin/operator payout action является финальным
операционным действием для заявки на вывод.

После выполнения payout action заявка переводится в `PAID`.

`wallet_send_confirmed=true` является достаточным операционным
подтверждением для V1.

`payout_ref` является внутренней ссылкой на payout action и не обязан
быть blockchain proof.

Отдельный backend watcher proof не является обязательным условием для
`PAID` в V1.

## PACK-02 admin payout canon

Admin payout does not grant technical access to project treasury/private
funds. The operator performs withdraw payout through TonConnect and an
approved operator wallet.

Admin withdraw action is an operator payout action. It is not direct
treasury custody and does not change PACK-01 V1 rule that approved
operator payout may finalize withdraw as `PAID`.

## Cycle 1794 — `Оплатить` не равно `Оплачено`

Wallet `sendTransaction()` после кнопки `Оплатить` записывает evidence через отдельный action и оставляет заявку `PENDING`.
Только explicit `Оплачено`/`Оплачено вручную` переводит заявку в `PAID`; manual path требует reason. Automatic blockchain receipt не является обязательным owner condition.
External EFHC amount уже нормализован D2 `ROUND_DOWN` до hold; проект оплачивает network fee отдельно.
