<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# GLOBAL IDENTITY BOUNDARY LOCK

Статус: **SYSTEM LOCK / ACTIVE**

1. `global_id` — единственный внутренний owner.
2. `tg_id` — только Telegram provider subject.
3. Нормативная формула: `provider + subject → global_id`.
4. Обязательная Telegram-цепочка:
   `tg_id → identity mapping → global_id → business runtime`.
5. Owner FK, idempotency, cache, reconciliation и audit actor
   используют `global_id`.
6. Telegram delivery использует реальный `tg_id`, разрешённый в
   provider layer из canonical account.
7. `global_id = tg_id`, numeric external `global_id`,
   `tg_provider_id` и `telegram_provider_id` запрещены.
8. Исторический read-through разрешён только для уже существующей
   legacy-записи; новые записи создаются только по `global_id`.
9. Действующий SSOT:
   `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Post-migration runtime boundary — cycle 1713

Retired business routes/selectors by `tg_id`, owner read/write switches and legacy account-adoption fallbacks are prohibited. Telegram `tg_id` remains valid only as Telegram provider subject, delivery recipient/payment metadata or bounded historical external-data read-through. Active business lookup from Telegram must resolve `user_identities(provider=telegram, subject=tg_id) -> global_id`.
