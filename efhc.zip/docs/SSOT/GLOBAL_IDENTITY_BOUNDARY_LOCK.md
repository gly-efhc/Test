<!-- Канон EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Якорь identity: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# БЛОКИРОВКА ГРАНИЦ GLOBAL IDENTITY

Статус: **SYSTEM LOCK / ACTIVE**

1. `global_id` — единственный внутренний owner.
2. `tg_id` — только Telegram provider subject.
3. Нормативная формула: `provider + subject → global_id`.
4. Обязательная Telegram-цепочка:
   `tg_id → identity mapping → global_id → business runtime`.
5. Owner FK, idempotency, cache, reconciliation и audit actor
   используют `global_id`.
6. Telegram delivery использует реальный `tg_id`, разрешённый в
   provider layer из canonical account.
7. `global_id = tg_id`, numeric external `global_id`,
   `tg_provider_id` и `telegram_provider_id` недопустимы в этой
   architecture/runtime boundary. Это identity contract, а не
   глобальный лексический запрет.
8. Исторический read-through разрешён только для уже существующей
   legacy-записи; новые записи создаются только по `global_id`.
9. Действующий SSOT:
   `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

Нарушения identity naming классифицируются как
`ARCHITECTURE_CANON`, а не `PERMANENT_SEMANTIC_BAN`.

## Runtime-граница после migration — цикл 1713

Выведенные из использования business routes/selectors по `tg_id`, owner read/write switches и legacy account-adoption fallbacks запрещены. Telegram `tg_id` остаётся допустимым только как Telegram provider subject, получатель delivery/payment metadata или ограниченный historical external-data read-through. Активный business lookup из Telegram обязан разрешаться через `user_identities(provider=telegram, subject=tg_id) -> global_id`.
