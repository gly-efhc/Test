<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия: `v173.41`.
- Завершён цикл: `1717 — exact-head CI repair + extended function/Admin/routes/docs preservation audit`.
- Следующий цикл: `1718 — exact-head CI follow-up`.
- Последний предоставленный exact-head CI: `v173.40`, GitHub CI `84948550953`, checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`, archive size `12124946` bytes.
- Green gates на `v173.40`: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Failed gates на `v173.40`: Ruff (`1` I001) и pytest (`45 failed, 1456 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: final-cutover referral/account test contracts, Telegram/TON expectations, payment-intent compatibility/reconciliation seam, ENV alias expectations, reason length и document/manifest expectations.
- По прямому ТЗ продолжен historical audit against `v171.89`; восстановлены безопасные Admin credit, wallet/payment и NFT-maintenance compatibility surfaces без возврата `tg_id` ownership.
- Frontend page tree относительно `v171.89`: `38/38` путей сохранены; подтверждённых исчезнувших page-файлов нет.
- Static OpenAPI: `v171.89 = 125 paths / 130 ops`; current = `127 paths / 132 ops`.
- Function-preservation registry расширен до `259` критических symbols / `44` modules / `14` required files; расширенный control test локально не запускался.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- `production_release_ready=false`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
