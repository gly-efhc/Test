<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия: `v173.40`.
- Завершён цикл: `1716 — exact-head CI repair + function preservation/Admin/routes/docs audit`.
- Следующий цикл: `1717 — exact-head CI follow-up`.
- Последний предоставленный exact-head CI: `v173.39`, GitHub CI `84942802763`, checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`, archive size `12095859` bytes.
- Green gates на `v173.39`: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Failed gates на `v173.39`: Ruff (`3` I001) и pytest (`61 failed, 1307 passed, 22 skipped, 130 errors`).
- Cycle 1716: исправлены подтверждённые CI causes; stale test migration-control contracts переведены на final-cutover expectations без возврата transition schema/runtime.
- По прямому ТЗ выполнен historical audit against `v171.89`, Admin/function/routes/docs preservation audit, восстановлены safe compatibility facades и создан fail-closed application function surface control.
- Function-presence test создан, но локально не запускался.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- `production_release_ready=false`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
