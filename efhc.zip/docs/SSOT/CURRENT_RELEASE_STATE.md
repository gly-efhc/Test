<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия: `v173.39`.
- Завершён цикл: `1715 — exact-head CI Ruff + pytest collection repair`.
- Следующий цикл: `1716 — exact-head CI follow-up`.
- Последний предоставленный exact-head CI: `v173.38`, GitHub CI `84940689623`, checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`, archive size `11816383` bytes.
- Green gates на `v173.38`: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates на `v173.38`: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` collection errors; test execution не началось).
- В `v173.39` исправлены только подтверждённые причины этих двух failed gates: production import hygiene и четыре exact CI-failed test compatibility locations, приведённые к действующим canonical interfaces.
- Retired financial/nonfinancial read switches, migration control и test-only idempotency facade в production не восстанавливались.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- Локальные test/lint/type/build/Alembic/CI проверки для `v173.39` не запускались.
- `production_release_ready=false`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
