<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия-кандидат следующего Development HEAD: `v173.44`.
- Завершённый рабочий цикл: `1720 — Admin Tasks CRUD/editor + task maintenance qualification`.
- Следующий цикл: `1721 — Admin Shop, order status и Shopfront profile`.
- Последний предоставленный exact-head CI: `v173.43`, GitHub CI `84962812842`.
- Green supplied gates на `v173.43`: Alembic/PostgreSQL, Flake8, Ruff, Mypy, Bandit, `compileall`, frontend production build.
- Pytest supplied result: `5 failed / 1497 passed / 22 skipped`.
- Подтверждённые причины пяти failures: отсутствующий manifest row `02246`, устаревший SHA cycle-range, остаточные English engineering docstrings и запрещённый shipping-code marker `stub` в сознательной observability compatibility-заглушке.
- CI causes patched: заглушка сохраняет поведение с machine status `disabled_duplicate`; изменённые docstrings русифицированы; history manifests синхронизируются один раз при закрытии cycle 1720.
- Cycle 1720 decision: полный Admin Tasks Editor подключает create/detail/update/deactivate/fail-closed delete; `performed_count` read-only; изменение `code` после history блокируется.
- Task submissions/moderation остаются canonical operational surface; approve сохраняет bank + idempotency path.
- `/admin/tasks/refresh-statuses` сохранён как compatibility boundary и отображается как обслуживание `task_complete_lock`, а не «синхронизация статусов».
- `/admin/ads` — отдельная Admin provider surface; показывает `builtin_timer`/`adsgram` registry и readiness без раскрытия ENV secrets.
- Historical `admin_tasks_crud.py` не был Task CRUD; его чужие utilities распределены по циклам 1721/1723/1724/1726. Historical `job_tasks_maintenance.py` runtime-функции не содержал.
- Task maintenance и TON watcher разделены: `tasks_autorestart.run_once` обслуживает task locks; `check_ton_inbox/job_ton_watcher` проверяет/догоняет входящие TON payments и reconciliation.
- Release/ops scripts — protected operational surface; release archives будут готовиться после завершения code phase по отдельному решению пользователя.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`; единственный bank balance key — `EFHC_MAIN`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- `production_release_ready=false`.
- Локальные application tests/guards/builds/CI в cycle 1720 не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
