<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия: `v173.42`.
- Завершён цикл: `1718 — exact-head CI repair + function recovery decision plan`.
- Следующий цикл: `1719 — Admin Observability и Reports: исследование и согласование`.
- Последний предоставленный exact-head CI: `v173.41`, GitHub CI `84954546920`, archive size `12135299` bytes.
- Green gates на `v173.41`: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff, frontend production build.
- Failed gates на `v173.41`: Mypy (`2` `no-any-return`) и pytest (`17 failed, 1485 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: типизация восстановленных Admin credit facades, Account Registration ordering по active SSOT, stale final-cutover test contracts/fixtures, payment watcher injection contract и новые Russian engineering language violations.
- Final `global_id` ownership не ослаблялся: hidden `users.tg_id` owner fallback, retired migration-control/read-switch layers не возвращены.
- Packaging regression `v173.41` исправлена по previous HEAD evidence: executable modes восстановлены у `50` release/ops scripts; `28` historical report filenames возвращены к исходным Unicode-именам без изменения содержимого.
- Active function-preservation registry остаётся `259` критических symbols / `44` modules / `14` required files.
- Создан active decision plan `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- `production_release_ready=false`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
