<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT RELEASE STATE

- Версия: `v173.43`.
- Завершён цикл: `1719 — exact-head CI repair + Admin Reports/Observability integration`.
- Следующий цикл: `1720 — Admin Tasks CRUD и task maintenance: исследование и согласование`.
- Последний предоставленный exact-head CI: `v173.42`, GitHub CI `84958133454`, checkout `a1cee9337b4a02d319bd494567f93d9dd3a59fe6`, archive size `12145552` bytes.
- Green gates на `v173.42`: Alembic/PostgreSQL, Flake8 critical/full, Ruff, Mypy, Bandit, `compileall`, npm ci, frontend production build.
- Failed gate: pytest `2 failed / 1500 passed / 22 skipped`: AI archive laws integrity reference и Russian engineering language policy.
- Подтверждённые CI causes патчены; локальные tests/guards/builds не запускались.
- Cycle 1719 decision: `/admin/observability/events` — compatibility stub `disabled_duplicate` с replacement `/admin/logs/transfers`; пять domain report routes подключены к `/admin/reports`.
- `reports/users`: ownership join только `global_id`. `reports/bank`: только `EFHC_MAIN` + `system_entity=BANK_EFHC`.
- Admin Reports UI: новый `AdminDomainReportsDashboardRuntime` + подключён существующий real-timeseries observability dashboard.
- Release/ops scripts — protected operational surface; release archives будут готовиться после завершения code phase по отдельному решению пользователя.
- Active function-preservation registry сохраняется; route удалений в цикле 1719 не было.
- Identity migration остаётся **QUALIFIED on v173.36**; `global_id` — единственный business/account/privileged/audit owner.
- BANK: `system_entity=BANK_EFHC`, bank row `global_id=NULL`, `tg_id=NULL`; единственный bank balance key — `EFHC_MAIN`.
- Admin list: `admin_whitelist.global_id + RBAC`; Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`.
- Alembic active head: `0001_initial_release_schema.py`.
- `production_release_ready=false`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
