# Watcher Accounting SSOT

## Incoming deposit identity

V1 watcher accounting identity is `tx_hash`.

Same `tx_hash` replay is idempotent no-op.

Different `tx_hash` is a new incoming deposit and must have visible
accounting outcome.

## Direct EFHC intent interaction

A direct EFHC intent may receive more than one real on-chain payment.
Each unique `tx_hash` is accounted separately.

Watcher and reconciliation must not use `intent already confirmed` as a
reason to silently drop a later different `tx_hash`.
