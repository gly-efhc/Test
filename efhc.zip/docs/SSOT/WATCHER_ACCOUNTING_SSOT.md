# Watcher Accounting SSOT

## Incoming deposit identity

V1 watcher accounting identity — `tx_hash`.

Повтор того же `tx_hash` является идемпотентным read-through и не создаёт
вторую финансовую операцию.

Другой `tx_hash` является отдельной on-chain транзакцией и должен иметь
видимый accounting outcome.

## Payment Intent interaction

Один `PaymentIntent` не является бессрочно переиспользуемым payload.
Новый автоматический settlement допускается только для живого `PENDING`
intent в пределах `expires_at`.

`CONFIRMED + same tx_hash` — идемпотентный read-through.

`CONFIRMED + different tx_hash` — автоматическое начисление через старый intent
запрещено; требуется новый `PENDING` intent либо отдельный canonical
direct-deposit flow.

Watcher и reconciliation не должны молча терять второй реальный incoming
payment: он должен быть видим в accounting/recovery contour, но это требование
не даёт права обходить Payment Intent lifecycle или global `tx_hash` settlement
lock.
