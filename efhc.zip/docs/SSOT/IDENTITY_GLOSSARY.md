<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# IDENTITY GLOSSARY

Статус: **CANON / ACTIVE**

- `global_id` — главный персональный идентификатор EFHC; единственный
  account owner и business owner; внешне string из 10 ASCII-цифр.
- `GlobalId` — типизированное имя проверенного `global_id` в коде.
- `provider` — внешний источник идентичности.
- `subject` — идентификатор пользователя внутри provider namespace.
- `provider identity` — конкретная пара `provider + subject`.
- `identity mapping` — связь provider identity с одним `global_id`.
- `identity resolution` — получение `global_id` до business runtime.
- `account owner` — владелец единого аккаунта, всегда `global_id`.
- `business owner` — владелец доменного или финансового объекта,
  всегда `global_id`.
- `tg_id` — Telegram provider subject, не owner.
- `Telegram ingress` — `initData`, Login, webhook или update до
  немедленного identity resolution.
- `Telegram delivery` — Bot API, notification, membership или payment
  metadata на внешней Telegram-границе.
- `historical read-through` — чтение реально существующего legacy-key
  без создания новых legacy-записей.
- `user_id` — retired legacy name, запрещён для новых owner contracts.
- `id` / `row_id` — локальный технический идентификатор строки.

Действующий закон: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.
