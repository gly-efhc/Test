# SSOT: схемы и таблицы EFHC Bot (истина)

Этот документ — **источник истины** по физической схеме БД для EFHC Bot.

## Схемы (ровно 2)

- `efhc_core` — основная схема приложения (пользовательские,
  игровые и финансовые данные).
- `efhc_admin` — админская схема (служебные и управленческие
  таблицы).

## Таблицы (ровно 35)

### efhc_core (30)
- `achievements`
- `ads`
- `app_settings`
- `bank_balance`
- `efhc_transfers_log`
- `panels`
- `payment_intents`
- `processed_external_events`
- `ranks_snapshots`
- `ranks_top_cache`
- `referral_bonus_ledger`
- `referral_codes`
- `referral_links`
- `scheduler_task_log`
- `shop_items`
- `shop_orders`
- `task_submissions`
- `tasks`
- `ton_inbox_logs`
- `unmatched_incoming`
- `user_cosmetics`
- `user_skins`
- `users`
- `wallet_bindings`
- `wallet_connect_idempotency`
- `withdraw_requests`
- `withdrawals`

### efhc_admin (5)
- `admin_action_log`
- `admin_role`
- `admin_whitelist`
- `efhc_sale_packages`
- `idempotency_key`

## Обязательная проверка (CI / Alembic sanity)

После `alembic upgrade head` должны существовать **все**
`schema.table` из списка выше. Проверка выполняется через
`SELECT to_regclass('schema.table')`.

Источник списка — `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.

## Правило historical traces

Historical traces допустимы только в `docs/audits/`,
`reports/`, Healer и migration-history. Они не считаются частью
active SSOT и не расширяют список канонических схем или таблиц.
