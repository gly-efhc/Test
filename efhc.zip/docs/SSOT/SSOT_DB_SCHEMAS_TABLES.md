## ACTIVE OWNER SCHEMA CHANGE — v174.60 / циклы 1799–1800

- Прямое решение владельца разрешает одну новую canonical application table: `efhc_core.bank_metrics_snapshot`.
- Current ORM surface: **53 = 46 efhc_core + 7 efhc_admin**; clean PostgreSQL physical surface: **54** с `alembic_version`.
- Frozen release lineage остаётся одной migration `0001_initial_release_schema.py`; `0002+` не создаётся. `0001` расширена owner-approved таблицей для clean install.
- Для уже существующей БД используется idempotent `URGENT_BANK_METRICS_SNAPSHOT.sql`; это compatibility DDL именно для утверждённой таблицы, не общий schema unlock.
- Machine source: `SSOT_TABLES_ORM.csv`; runtime/model/migration/table-set должны совпадать.
- Snapshot — materialized Admin Bank authority, но BANK/ledger/source tables остаются первичной финансовой истиной.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT DB SCHEMAS AND TABLES

Статус: **SSOT / ACTIVE**  
Версия среза: **v174.25 / цикл 1777, Simple Financial Retention**

## Таблицы — Greenfield candidate

- `efhc_core`: **45** ORM-таблиц.
- `efhc_admin`: **7** ORM-таблиц.
- Всего ORM-таблиц: **52**.
- При clean Alembic install ожидается **53** physical tables с учётом служебной `alembic_version`.

Источники истины текущего pre-release contract: ORM declarations для runtime, migration-local frozen `RELEASE_METADATA` в единственном `0001_initial_release_schema.py` для initial DDL и `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`. Exact-head CI `86531880820` на `v174.09` подтвердил `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`; pytest `1613 passed / 22 skipped / 1 warning`, все canonical gates `exit=0`.

## Identity contract

- Account owner и physical PK: `efhc_core.users.global_id`.
- Retained V8 P0 lifetime PK/reference fields создаются как PostgreSQL `BIGINT`; bounded catalog/counter fields могут оставаться `INTEGER`.
- `users.id`, `users.user_id`, `users.tg_id`, `users.ton_wallet` отсутствуют.
- Provider identity: `user_identities.provider + provider_tenant + provider_subject -> global_id`.
- Wallet ownership: active verified `wallet_bindings.global_id`.
- Account-owned FK направляются на `users.global_id`.

## Owner-approved retirement

Удалены из clean candidate: `panels_archive`, `ranks_snapshots`, `ranks_top_cache`, `ranks_user_snapshots`. Public `/panels/archive` сохраняется и читает unified `panels`; referral economy сохраняется, удалён только referral leaderboard surface.

## Migration contract

Alembic head один: `0001_initial_release_schema.py`. Новая migration `0002+` без прямого решения владельца запрещена. Cycle 1773 замораживает physical schema внутри migration-local `RELEASE_METADATA`, без import current ORM; candidate требует exact-head Alembic/GitHub CI. CI `86540554973` выявил пропуск 11 колонок `scheduler_task_log`; v174.12 восстановил их. CI `86541701491` уже подтвердил frozen migration на clean PostgreSQL: `52 ORM / 53 physical / 0001: ok`. Владелец 2026-08-16 утвердил frozen `RELEASE_METADATA` как финальную форму `0001`. `0001` — clean initial schema первого production launch, не in-place upgrade существующей применённой БД.

## Latest qualification evidence

CI `86566046574` криптографически проверил exact `v174.20` и подтвердил Alembic `52 ORM / 53 physical / 0001: ok`; pytest имел только один stale frontend guard failure. Candidate `v174.21` schema не меняет.

## Simple Financial Retention v174.25

Schema surface остаётся `52 ORM / 53 physical`; frozen `0001` не изменён.
Owner decision 2026-08-16 отменил physical monthly partitioning. Текущие
BIGINT PK, global UNIQUE и FK остаются без redesign. Cycle `1777` вводит
только age-based retention planner: history `created_at age >=370d`
delete-eligible, cleanup trigger oldest `>=400d`; фактический bounded DELETE
будет отдельным cycle `1778`.

