<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT DB SCHEMAS AND TABLES

Статус: **SSOT / ACTIVE**  
Версия среза: **v173.12 / цикл 1692**

## Таблицы (ровно 48)

### efhc_core (42)

- **42** таблицы.
### efhc_admin (6)

- **6** таблиц.
- Всего ORM-таблиц: **48**.

Источники истины:

- ORM `Base.metadata`;
- `backend/migrations/versions/0001_initial_release_schema.py`;
- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.

## Identity contract

- Account owner: `efhc_core.users.global_id`.
- `users.user_id` отсутствует.
- `users.tg_id` — nullable Telegram provider attribute.
- Account-owned FK направляются только на `users.global_id`.
- Provider IDs допускаются только как source/delivery/proof metadata.

## Migration contract

Alembic head один: `0001_initial_release_schema.py`. Новая migration
`0002+` без прямого решения пользователя запрещена.
