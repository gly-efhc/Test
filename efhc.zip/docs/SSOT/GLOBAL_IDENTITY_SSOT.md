<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# GLOBAL IDENTITY SSOT

Статус: **CANON / SSOT / ACTIVE**  
Версия среза: **v174.13 / цикл 1773, frozen 0001 qualification repair**

## ACTIVE SNAPSHOT — physical identity consolidation

- `efhc_core.users.global_id` — единственный physical PRIMARY KEY и business/account owner.
- Диапазон canonical `global_id`: `1..9999999999`; внешний контракт остаётся десятизначной decimal-string.
- `users.id`, `users.user_id`, `users.tg_id`, `users.ton_wallet` удалены из clean Greenfield schema по прямому решению владельца.
- Telegram и другие provider subjects существуют только в `user_identities`; Telegram Bot/API delivery metadata может по-прежнему использовать `tg_id` вне `users`.
- TON wallet ownership существует только через active verified `wallet_bindings`; provider TON identity — через `user_identities`.
- Все user-owned FK продолжают ссылаться на `users.global_id`; отдельного technical user PK больше нет.
- Exact-head CI `86531880820` на `v174.09` полностью квалифицировал physical identity consolidation: `52 ORM / 53 physical`, `0001: ok`, pytest `1613 passed / 22 skipped / 1 warning`, все canonical gates `exit=0`.
- Cycle 1773 не меняет identity semantics: он только замораживает уже green-qualified physical identity shape внутри self-contained migration-local `RELEASE_METADATA`; новый `0001` candidate требует exact-head CI. CI `86540554973` подтвердил, что failure относится к freeze snapshot `scheduler_task_log`, а не к identity shape; v174.12 восстановил snapshot. CI `86541701491` подтвердил frozen `0001` через Alembic; оставшиеся три pytest failures — только traceability/portability policy drift. v174.13 не меняет `global_id`/provider/wallet contract.

Ниже сохранены исторические разделы. При конфликте этот ACTIVE SNAPSHOT и более поздние прямые решения владельца имеют приоритет.

## 1. Единственный внутренний владелец

`global_id` — главный персональный идентификатор EFHC и единственный
внутренний account owner и business owner.

- Физическая колонка: `efhc_core.users.global_id`.
- Диапазон внутреннего значения: `1..9999999999`.
- Внешний контракт: string, pattern `^[0-9]{10}$`.
- `0000000000` запрещён.
- Числовое приведение во внешнем API, Python и JavaScript запрещено.
- Все owner FK, финансовые ключи, audit actors и internal cache keys
  используют `global_id`.
- `users.user_id` не является физической owner-колонкой.
- Локальный `users.id` — только технический primary key строки.

## 2. Provider identity

Единственная модель разрешения внешней идентичности:

`provider + subject → global_id → business runtime`.

Один `global_id` может иметь несколько provider identities. Каждая
конкретная пара `provider + subject` разрешается ровно в один
`global_id`; конфликт завершается fail closed.

## 3. Telegram boundary

`tg_id` — только Telegram provider subject. Он допустим в Telegram
аутентификации, `initData`, Login, update/webhook sender, Bot API
recipient, notification delivery, membership, Telegram payment
metadata и identity mapping.

После resolution бизнес-код использует только `global_id`. Новые
business rows, owner FK, idempotency keys и API selectors по `tg_id`
запрещены.

## 4. Другие provider subjects

- Telegram: `tg_id`;
- TON: `ton_wallet_id`;
- Google: `google_id`;
- Apple: `apple_id`;
- Facebook: `fb_id`;
- Discord: `discord_id`;
- GitHub: `github_id`.

Имена `tg_provider_id`, `telegram_provider_id` и provider-subject alias `ton_address` запрещены. `ton_wallet_id` — канонический адрес TON-кошелька в роли TON provider subject; это не внутренний ID строки БД.

Classification note: перечисленные в identity-разделах non-canonical
aliases являются ограничением `ARCHITECTURE_CANON`, а не частью
глобального forbidden-word vocabulary. Они недопустимы только в том
runtime/schema/provider scope, который определён этим SSOT. Само
упоминание такого legacy identifier в historical evidence, migration
analysis или engineering documentation не является lexical violation.

Production auth-provider wire values: `telegram`, `ton`, `google`, `apple`, `facebook`, `discord`, `github`. `mock` существует только как test-only provider, запрещён в production registry/storage и не является production provider identity.

## 5. Schema и migration

- Alembic head один.
- Единственная pre-release migration:
  `backend/migrations/versions/0001_initial_release_schema.py`.
- `0002+` запрещена без прямого решения пользователя.
- ORM, `0001`, raw SQL, services, routes, frontend, tests и guards
  обязаны выражать один owner-контракт.

## 6. Критерий завершения

Главная кодовая метрика: `business-owner tg_id = 0`.

Полное завершение дополнительно требует exact-head GitHub CI и
согласованности runtime, schema, API, frontend, tests и active docs.

## 7. Архивные документы

Устаревшее содержимое бывшего `АРТЕФАКТЫ/` вынесено из active HEAD в
отдельный external history ZIP. В репозитории остаются только канонические
`docs/cycles/`, `docs/chats/`, `reports/numbered/` и необходимые current
machine manifests. Внешняя история не является active canon и не может
переопределять этот SSOT.

## Provider wire naming

Канонические production wire names следуют утверждённым именам провайдеров: `telegram`, `ton`, `google`, `apple`, `facebook`, `discord`, `github`. Provider aliases в runtime не поддерживаются. `ton_wallet` является retired auth-provider alias; одноимённое legacy wallet-data поле `users.ton_wallet` имеет другую семантику и этим правилом не переименовывается.

## 8. Security и audit identity — цикл 1703

- privileged/session ownership использует только `global_id`;
- provider subjects не используются как privileged actor или audit owner;
- `admin_action_log.actor_global_id` ссылается на `users.global_id`;
- новые signed handoff tokens содержат canonical `global_id`, без Telegram provider subject;
- provider-specific subjects редактируются из auth diagnostics и raw application logs;
- Telegram ID допускается в delivery/ingress и bounded historical read-through, но не как финансовый или audit owner.


## 10. Admin privilege ownership — cycle 1705

Admin privilege принадлежит canonical account `global_id`. Provider login только
разрешает пользователя в EFHC account и не может сам по себе выдать admin role.
Backend проверяет active `admin_whitelist.global_id` и явную `admin_role`; отсутствие
роли означает deny. Frontend узнаёт право только через защищённый `/admin/access`.
Retired public provider allowlists не являются authority и подлежат удалению в
циклах 1708–1709 после проверки consumers.

## 11. Зарезервированный SuperAdmin Global ID

По прямому решению пользователя `global_id=1313131313` зарезервирован
исключительно для владельца SuperAdmin EFHC. Обычная регистрация обязана
пропускать это значение и не может выдать его пользовательскому аккаунту.
Резервирование не выдаёт права само по себе: административные права возникают
только после явной server-side записи `admin_whitelist.global_id` и RBAC-роли
`superadmin`. Provider subject (Telegram, TON и другие) может быть связан с этим
аккаунтом только через обычный provider identity mapping.

## Qualification and post-migration cleanup — cycles 1712–1713

`v173.36` qualified the ownership migration by exact-head CI `84923645231`: business owner `tg_id` = 0, actionable identity queue = 0, semantic mix = 0, PostgreSQL `0001` and all canonical gates GREEN. Cycle 1713 removes retired runtime owner-switch/dual-write/alias infrastructure. Provider subjects remain only at provider ingress, delivery, mapping or bounded historical read-through boundaries. `v173.37` requires exact-head CI after cleanup.


## Active-account authority для authentication lifecycle

`efhc_core.users.is_active` является обязательным server-side gate после
`provider + subject -> global_id` для выдачи и использования authentication
session. Деактивированный core account не может сохранять действующую session,
read-owner capability, Admin credential или signed handoff capability только
потому, что provider identity, whitelist/NFT cache либо ранее выданный token
остаются технически валидными.

При переходе account `active -> inactive` все active `auth_sessions` этого
`global_id` отзываются в той же DB transaction. Проверка active-state также
выполняется при session issue/authenticate и при разрешении financial/nonfinancial
read owner. Business owner остаётся только `global_id`; данный kill-switch не
создаёт новый owner или provider fallback.
