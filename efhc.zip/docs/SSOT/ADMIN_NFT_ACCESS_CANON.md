<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ADMIN NFT ACCESS CANON

Статус: **ACTIVE CORE CANON / USER CONFIRMED**  
Версия: **v173.35 / цикл 1710**

## 1. Назначение

Admin NFT — резервный способ получить полный доступ к Admin Panel через текущее
владение одним из специально назначенных NFT той же TON-коллекции, которая
используется для VIP.

Существуют два независимых источника административного доступа:

1. **Admin list** — active `efhc_admin.admin_whitelist.global_id` + явная
   RBAC-роль.
2. **Admin NFT** — фактическое владение конкретным NFT-item, точный адрес
   которого перечислен в `TON_ADMIN_NFT_IDS` и который принадлежит
   `TON_NFT_COLLECTION`.

Любой обнаруженный Admin NFT из `TON_ADMIN_NFT_IDS` даёт полный обычный Admin
access. Он не повышает пользователя до отдельного SuperAdmin-статуса.

## 2. Канонический идентификатор Admin NFT

Единственный канонический Admin NFT ID — **точный TON NFT-item address**.
`token_id`, `index`, имя NFT, metadata name и URL не являются Admin NFT ID.

Пример, подтверждённый владельцем проекта:

- collection address: `EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0`;
- конкретный Admin NFT item address:
  `EQDvvZCMEs5WIOrdO4r-F9NmsyEU5HyVN0uo1yfAqLG3qyLj`.

В GetGems URL item address соответствует последнему сегменту пути конкретного
NFT.

## 3. ENV authority

Единственное active ENV-имя:

`TON_ADMIN_NFT_IDS`

Значение — список точных NFT-item address, например:

```text
TON_ADMIN_NFT_IDS=["EQDvvZCMEs5WIOrdO4r-F9NmsyEU5HyVN0uo1yfAqLG3qyLj"]
```

Промежуточные ENV-алиасы удалены и не являются частью active-контракта.

Пустой `TON_ADMIN_NFT_IDS` означает fail-closed: резервный Admin NFT access
выключен.

## 4. Единый VIP/Admin NFT обработчик

`backend/app/services/nft_check_service.py` получает NFT-активы TON-кошелька
одним штатным fetch и использует один результат для двух независимых решений:

- VIP: кошелёк владеет хотя бы одним NFT из `TON_NFT_COLLECTION`;
- Admin NFT: кошелёк владеет NFT из `TON_NFT_COLLECTION`, чей точный
  `item_address` входит в `TON_ADMIN_NFT_IDS`.

Обычный VIP NFT сам по себе административных прав не даёт.

## 5. Материализованный derived state

`efhc_admin.admin_nft_whitelist` — не ручной whitelist и не самостоятельный
источник права. Это только materialized cache последней успешной штатной
NFT-проверки.

Для подтверждённого владельца хранится:

- `ton_wallet_id` — verified TON provider subject владельца;
- `nft_id` — точный NFT-item address из `TON_ADMIN_NFT_IDS`;
- `source='env_nft'`;
- `role='admin'`;
- `is_active=true`;
- timestamps проверки/revocation.

При обнаружении того же `nft_id` у другого TON-кошелька предыдущий active
materialized owner этого NFT деактивируется, а новый владелец становится
active. Таким образом административное право следует за NFT.

## 6. Несколько TON-кошельков одного global_id

Если один `global_id` имеет несколько active verified TON identities, достаточно
владения Admin NFT **на любом** из этих кошельков.

`ton_wallet_id` остаётся provider subject и не становится business owner.
Административный actor после успешной авторизации остаётся canonical
`global_id` server-side session.

## 7. Передача NFT

Право принадлежит NFT, а не прежнему кошельку или пользователю навсегда.

После следующей успешной штатной NFT/VIP проверки:

- старый владелец, у которого Admin NFT больше нет, теряет derived access;
- новый владелец Admin NFT получает full Admin access;
- при обнаружении NFT у нового владельца materialized state предыдущего
  владельца этого же `nft_id` деактивируется.

Дополнительный внешний TON API запрос на каждый Admin route не требуется.
До следующего refresh действует fail-closed freshness boundary
`NFT_CACHE_TTL_SECONDS`; просроченный materialized state не даёт доступ.

## 8. Вход в Admin Panel

Поток обычного Admin list:

```text
server-side authenticated session
        ↓
canonical global_id
        ↓
active admin_whitelist + RBAC
        ↓
Admin Panel
```

Поток Admin NFT:

```text
server-side authenticated session
        ↓
canonical global_id
        ↓
любой active verified TON identity этого global_id
        ↓
ton_wallet_id
        ↓
fresh derived admin_nft_whitelist state
        ↓
nft_id присутствует в текущем TON_ADMIN_NFT_IDS
        ↓
full Admin access
        ↓
Admin Panel
```

Оба пути сходятся в `require_admin_or_nft_or_key`.

## 9. Frontend

Frontend не определяет Admin NFT ownership самостоятельно. После
аутентификации используется `GET /admin/access`. Если server-side gate вернул
разрешение, существующая кнопка Admin Panel отображается.

## 10. Fail-closed правила

Admin NFT access запрещён, если хотя бы одно условие выполняется:

- отсутствует проверенная server-side session;
- нет active verified TON identity, связанной с session `global_id`;
- `TON_ADMIN_NFT_IDS` пуст;
- `nft_id` отсутствует в текущем `TON_ADMIN_NFT_IDS`;
- materialized row не имеет `source='env_nft'`;
- row inactive или revoked;
- row старше `NFT_CACHE_TTL_SECONDS`;
- NFT принадлежит не `TON_NFT_COLLECTION` при штатной NFT-проверке.

Client-controlled Telegram headers, `X-Admin-Id`, `SECRET_KEY` и аналогичные
обходы не являются частью Admin NFT канона.

## 11. Зафиксированные ответы пользователя

1. Admin NFT идентифицируется точным NFT-item address; пример подтверждён через
   конкретный GetGems item URL.
2. Каноническое ENV-имя — `TON_ADMIN_NFT_IDS`.
3. Любой найденный Admin NFT даёт полный Admin access.
4. Достаточно Admin NFT на любом verified TON-кошельке одного `global_id`.
5. При передаче NFT доступ должен исчезнуть у старого владельца и появиться у
   нового владельца; это делает тот же штатный NFT/VIP refresh, а freshness TTL
   блокирует устаревший derived state.
