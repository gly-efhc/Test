## CURRENT OWNER EXCEPTION — v174.60 / цикл 1799

Direct owner decision разрешил конкретное изменение frozen `0001`: добавить `efhc_core.bank_metrics_snapshot`. Текущий clean-install contract: **53 application ORM tables / 54 physical including `alembic_version`**. Это не снимает общий запрет на неутверждённые DDL и не разрешает `0002+`. Existing databases получают только owner-supplied idempotent `URGENT_BANK_METRICS_SNAPSHOT.sql`.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT DB 0001 CANON

Статус: **SSOT / ACTIVE**  
Версия среза: **v174.38 / цикл 1789; frozen 0001 confirmed locked**

- Схемы: `efhc_core` и `efhc_admin`.
- ORM-таблицы candidate: **52** (`efhc_core`: 45, `efhc_admin`: 7).
- Единственная release migration: `backend/migrations/versions/0001_initial_release_schema.py`.
- Alembic head один; `0002+` запрещена без нового прямого решения владельца.

- Cycle 1789 verification: exact current ORM/SSOT/migration table set `52/52` (`45 core + 7 admin`), mismatch `0`; GitHub CI `86992003426` PostgreSQL/Alembic gates GREEN for exact `v174.37`.
- **Lock state:** schema/migrations глобально не разблокированы. `0001` остаётся frozen; `0002+` запрещены без прямого owner decision. Конкретное schema change допустимо только в отдельно утверждённом scope с синхронным ORM/SSOT/`0001` contract.
- `users.global_id` — физический PRIMARY KEY, canonical owner и единственный user FK target.
- Retained V8 P0 lifetime IDs создаются как PostgreSQL `BIGINT` сразу в clean initial schema; physical type проверяется самим `0001`.
- `users.id`, `users.user_id`, `users.tg_id`, `users.ton_wallet` физически отсутствуют в clean Greenfield candidate.
- Telegram identity хранится в `user_identities`; wallet ownership — в `wallet_bindings`.
- Current ranking state хранится в `users.rank_position`, `users.rank_score_kwh`, `users.rank_calculated_at`.
- Owner-approved retired tables отсутствуют: `panels_archive`, `ranks_snapshots`, `ranks_top_cache`, `ranks_user_snapshots`.
- `efhc_core.tx_hash_locks.tx_hash` остаётся глобально unique settlement claim; cycle 1774 добавляет `trusted_operation_at` и `server_first_seen_at` как обязательное time evidence. Физический replay-retention пока не сокращён: target 180 суток допускается только после green qualification execution barrier.
- `efhc_core.ton_inbox_logs.trusted_operation_at` сохраняет доверенное on-chain время; отсутствие trusted time для нового credit-path трактуется fail-closed.

Exact-head CI `86531880820` на `v174.09` полностью подтвердил clean Greenfield install и runtime integration: `metadata_tables=52`, `tables_in_schemas=53`, `create_all_done`, `0001: ok`; pytest `1613 passed / 22 skipped / 1 warning`, все canonical gates `exit=0`. В cycle 1773 тот же physical contract заморожен внутри migration-local `RELEASE_METADATA`: `0001` больше не импортирует current `app.models`. Static parity candidate: `52/52` tables, `45/7` schema split, physical columns без drift, `40/40` module-level indexes. Новый snapshot требует exact-head Alembic/GitHub CI и не считается green до этого verification. CI `86540554973` выявил structural freeze defect `scheduler_task_log`; repair v174.12 восстановил 11 колонок. CI `86541701491` подтвердил frozen `0001` в реальном Alembic/PostgreSQL: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Владелец 2026-08-16 утвердил frozen `RELEASE_METADATA` как окончательную форму `0001`; full HEAD qualification ожидает repair трёх pytest policy drifts.


## Цикл 1774 — временная финансовая граница

`v174.14` сохраняет table surface `52 ORM / 53 physical including alembic_version`. В frozen `0001` добавлены только time-evidence columns для уже существующих `ton_inbox_logs` и `tx_hash_locks`; новых таблиц и `0002+` нет. Цель — доказать exact-head CI, что строгая граница `trusted age < 180 days` стоит до replay/idempotency и до любого внешнего первичного зачисления. До green CI физическая очистка replay rows и monthly financial partitioning не активируются.

## Цикл 1774 — qualification repair после CI v174.14

CI `86550681430` повторно подтвердил frozen `0001` на clean PostgreSQL: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Red gates данного CI относятся к Ruff import-order и watcher/payment test compatibility seams; schema failure отсутствует. Candidate `v174.15` не меняет frozen schema semantics, table count или migration set.

## Цикл 1774 — physical qualification после CI v174.16

CI `86555575826` подтвердил smoke clean frozen `0001`: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`, но deep physical-parity test внутри общего pytest отдельно остановил qualification на `wallet_connect_idempotency`: frozen metadata содержит логически избыточный UNIQUE по тем же колонкам, что composite PRIMARY KEY, а PostgreSQL inspector не экспонирует второй отдельный UNIQUE constraint. Candidate `v174.17` не меняет frozen `0001`; comparator нормализует только UNIQUE, полностью совпадающий с уже проверенным PK, и продолжает fail-closed сверку остальных UNIQUE/FK/CHECK/indexes.


## Цикл 1774 — усиленная Alembic qualification после CI v174.15

CI `86553398408` снова подтвердил clean frozen `0001`: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`; schema gate был green, единственный red gate всего CI — один pytest watcher mock. Candidate `v174.16` не меняет schema semantics, но усиливает qualification: fresh PostgreSQL DB сверяется с frozen `RELEASE_METADATA` по table/column/type/nullability/PK/UNIQUE/FK/CHECK/index surface, BIGINT/global_id invariants и повторному `upgrade head` noop. Внутренний workflow получает отдельный mandatory physical-schema exit; общий pytest сохраняет независимое повторное выполнение integration tests.


## Цикл 1774 — qualification repair после CI v174.17

CI `86557392563` снова подтвердил clean frozen `0001` smoke: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Deep physical comparator остановился не на DDL drift, а на representation PostgreSQL native ENUM `efhc_admin.enum_admin_role`: SQLAlchemy metadata содержит type-bound pseudo-CHECK, тогда как PostgreSQL native ENUM физически создаётся как TYPE без CHECK. Candidate `v174.18` не меняет frozen `0001`; comparator исключает только такой native-ENUM pseudo-CHECK и отдельно fail-closed сверяет существование ENUM type и точный набор labels.

Static retention preflight не меняет schema: direct monthly partitioning шести approved history tables нельзя выполнять простым добавлением `PARTITION BY`, пока глобальные UNIQUE/idempotency и `withdraw_requests`→`withdraw_outcome_events` referential integrity не вынесены/адаптированы к month-aware contract. Реализация остаётся после green P0 barrier.

## Цикл 1774 — qualification после CI v174.18

CI `86560117373` снова подтвердил clean frozen `0001`: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Deep physical schema qualification и 180-day P0 barrier/replay suite failures не дали. Единственный red pytest относится к stale SHA expectation canonical workflow и не требует изменения migration/runtime/schema. Candidate `v174.19` сохраняет frozen `0001` и physical schema без функциональных изменений; retention/partition DROP остаётся выключенным до полного green exact-head CI.


## Цикл 1774 — qualification после CI v174.19

CI `86563906491` на `v174.19` снова подтвердил clean frozen `0001` на newest Python dependency set: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`; общий pytest `1639 passed / 22 skipped / 1 warning`. Единственный red gate относится к frontend TypeScript 7 config compatibility. Candidate `v174.20` не меняет migration, ORM, schemas, tables, constraints или financial storage semantics.


## Цикл 1774 — qualification после exact-head CI v174.20

CI `86566046574` криптографически проверил exact payload `v174.20` (SHA-256 `54469a34839c3d57d54247611bd876f3f5bd43facce7bd21240d60c6795afd33`) и снова подтвердил frozen `0001`: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Red gates относятся только к stale frontend architecture guard и Zod 4 frontend typing/API compatibility. Candidate `v174.21` migration, ORM, table/constraint/index surface и financial storage semantics не меняет.


## Цикл 1775 — pre-partition foundation

Candidate `v174.22` не меняет frozen `0001`, ORM table surface или physical schema. Exact pre-partition checkpoint фиксирует current migration SHA-256 `99b3770a5dd02892879bb0edbca343b4af0ad3f0860c93e7929ad08c45314ef1`, 52 application tables (`45 core + 7 admin`) и шесть owner-approved history tables. Physical partition rewrite остаётся отдельным следующим этапом после GitHub CI foundation.

## Цикл 1776 — physical partition blocker qualification

`v174.23` не меняет frozen `0001` и не выполняет physical partition rewrite.
На основе current ORM source зафиксированы PK/UNIQUE/FK blockers всех шести
approved history tables. До разрешения этих blockers physical activation
fail-closed запрещена. Generated dependency graph:
`reports/generated/FINANCIAL_PARTITION_DEPENDENCY_GRAPH_v174_23.json`.


## Цикл 1777 — owner supersession physical partitioning

Owner decision 2026-08-16 отменил весь physical monthly partitioning plan как
неоправданно сложный. `v174.25` **не меняет** frozen `0001`, ORM tables,
PK/FK/UNIQUE или indexes. Simple Financial Retention выполняется поверх
обычных tables через age-based bounded DELETE в последующем cycle. Ранее
зафиксированные partition blockers сохраняются только как historical evidence
того, почему partitioning был отменён, и больше не являются implementation
target. Active retention authority: `docs/SSOT/FINANCIAL_RETENTION_CANON.md`.
