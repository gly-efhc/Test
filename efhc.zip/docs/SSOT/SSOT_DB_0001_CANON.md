<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT DB 0001 CANON

Статус: **SSOT / ACTIVE**  
Версия среза: **v173.12 / цикл 1692**

- Схемы: `efhc_core` и `efhc_admin`.
- ORM-таблицы: **48** (`efhc_core`: 42, `efhc_admin`: 6).
- Единственная release migration:
  `backend/migrations/versions/0001_initial_release_schema.py`.
- Alembic head один.
- `users.global_id` — физический owner и FK target.
- `users.user_id` физически отсутствует.
- `users.tg_id` — nullable provider subject, не owner.
- Fresh install и upgrade существующей pre-release базы должны
  завершаться одинаковым schema contract.
- `0002+` без прямого решения пользователя запрещена.
