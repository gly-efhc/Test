# SSOT DB 0001 CANON

## Истина
- Истина структуры БД = ORM: `backend/app/models/**` → `Base.metadata`.
- Миграции — производные артефакты. Они подтверждают истину, но не
  диктуют её.

## 0001 (первичная миграция)

### Схемы
- Создаёт ровно две схемы:
  - `efhc_core`
  - `efhc_admin`

### Таблицы
- Создаёт только ORM-таблицы из `Base.metadata`.
- Канон active HEAD: 35 таблиц по `SSOT_TABLES_ORM.csv`.
- Расклад по схемам:
  - `efhc_core`: 27
  - `efhc_admin`: 5
- Sanity в `0001_init.py` обязан сверять count с
  `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.

### Sanity (детерминированно)
- Схемы: `pg_namespace`
- Таблицы: `to_regclass('<schema>.<table>')`
- При несовпадении — падать с полным списком missing objects.

## Запреты
- Запрещено добавлять extra tables из raw SQL через миграцию.
- Запрещено указывать `schema=...` внутри `sa.Column(...)`.
- Любой raw SQL на не-ORM таблицу = дефект кода, а не повод расширять
  0001 вручную.
