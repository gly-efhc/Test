<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ACTIVE DOCUMENTATION INDEX

Статус: **SSOT INDEX / ACTIVE**  
Версия: **v173.42 / цикл 1718 завершён / 1719 next**

## Identity law

1. `docs/SSOT/GLOBAL_IDENTITY_SSOT.md` — главный identity SSOT.
2. `docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md` — запрет provider ownership.
3. `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md` — provider mapping.
4. `docs/SSOT/IDENTITY_GLOSSARY.md` — identity terminology.
5. `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md` — runtime/test/doc norm.
6. `ops/identity/tg_id_domain_boundary_baseline.json` — точный provider-boundary baseline.
7. `ops/identity/check_multi_provider_resolution_hardening.py` — uniqueness/collision/linking/session-owner hardening цикла 1702.
8. `contracts/identity/identity_resolver_contract_v1.json` — machine contract resolver, включая hardening 1702.
9. `ops/identity/check_security_audit_identity.py` — privileged/session/audit ownership и privacy/minimization guard цикла 1703.
10. `ops/identity/check_cross_layer_consistency.py` — cross-layer identity/admin consistency guard цикла 1705.
11. `ops/reports/check_release_history_integrity.py` — fail-closed canonical history/RELEASE exclusion guard цикла 1704.
12. `backend/app/bot/handlers/admin/admin_access.py` + `tests/architecture/test_admin_bot_provider_boundary.py` — Telegram admin provider boundary: `tg_id -> global_id -> RBAC`.
11. `docs/security/ADMIN_ROUTE_GUARD_CANON.md` — server-side global_id + explicit RBAC admin access canon.

## Product / economy

- `docs/SSOT/ECONOMY_CANON.md` — единый active economic contract.
- `docs/SSOT/BANK_CANON.md` — Центральный банк и ledger identity.
- `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md` — обычный Admin list + резервный доступ по точному Admin NFT-item address из `TON_ADMIN_NFT_IDS`.
- `docs/SSOT/PANELS_SSOT.md` — Panels.
- `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` — Exchange/Withdraw.
- `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md` — fail-closed каталог application capabilities / HTTP / frontend / Admin / background surface.
- `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md` — active historical/Admin/routes/docs preservation audit.

## Current state

- `docs/SSOT/CURRENT_RELEASE_STATE.md`;
- `docs/cycles/WORK_CYCLES_1701-1800.md`;
- `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `docs/PLANS/WORK_PLAN_1693-1709.md`;
- `reports/current/CURRENT_EVIDENCE_INDEX.md`;
- `reports/current/FAILURE_LEDGER_CURRENT.md`;
- `reports/current/IDENTITY_MIGRATION_STATE_CURRENT.md`.

## Test layer

- `docs/testing/TEST_GUARD_MANIFEST.json`;
- `contracts/application_function_surface_v1.json` — registered application surface;
- `tests/architecture/test_application_function_surface_manifest.py` — CI-only fail-closed function-presence control;
- `docs/testing/TEST_GUARD_MANIFEST.md`;
- `ops/identity/check_active_test_surface.py`;
- `ops/identity/force_test_global_id_cutover.py`;
- `docs/NORM/TEMPORARY_FILES_LIFECYCLE_NORM.md`;
- `reports/manifests/TEMPORARY_FILES_REGISTRY.json`;
- `ops/reports/manage_temporary_files.py`.

## Immutable project history

- внешний `EFHC_Bot_*_ARTIFACTS_HISTORY.zip` — устаревшая архивная история,
  отсутствующая в active HEAD;
- `docs/NORM/IMMUTABLE_HISTORY_NORM.md` — обязательное правило numbered reports;
- `docs/cycles/` — канонические диапазонные cycle documents;
- `docs/chats/` — numbered chat transcripts и recovery registry;
- `reports/numbered/` — immutable reports;
- `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`;
- `reports/manifests/CHAT_ARCHIVE_MANIFEST.csv`;
- `reports/manifests/REPORTS_NUMBERING_MANIFEST.csv`.

External artifacts history не определяет current runtime и не входит в production RELEASE.
Исторические chats/cycles/reports и три current manifests хранятся только в указанных выше канонических разделах; `АРТЕФАКТЫ/` и `docs/history/` отсутствуют.

- TON provider subject canon: `ton_wallet_id` = адрес TON-кошелька; anchor — `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.

## SuperAdmin Global ID reservation v173.27

- `backend/app/identity/reserved_global_ids.py` — machine constant reservation.
- `tests/architecture/test_superadmin_global_id_reservation.py` — fail-closed reservation guard.
- `docs/NORM/ADMIN_RBAC.md` — обычный VIP не является admin credential; Admin NFT-доступ разрешается только через конкретный NFT-item address из `TON_ADMIN_NFT_IDS` и свежий derived state штатной NFT-проверки.
