> OWNER 2026-10-18: прежние EAM-матрицы, производные registry-файлы и физические census/provenance snapshots Theme01/02/04 удалены из current archive; ожидание новой OWNER-матрицы. Исторические reports сохраняются, runtime-реестры CT/design не затронуты.

# ACTIVE DOCUMENTATION INDEX — CURRENT

Назначение: единственная навигация по **актуальным** документам. Этот файл не хранит историю и не расширяет Kernel scope.

**OWNER (актуально):** обязательные номерные отчёты, физические ZIP-SAVEPOINT и два HTML после каждого завершённого материального блока, upgrade-only обновления, исправление тестов, изолированная DigitalOcean-среда и правила GitHub по текущему OWNER scope закреплены в `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`.

## Entry / process

| Document | Назначение |
|---|---|
| `START_HERE.md` | Physical HEAD, freeze status и точка старта. |
| `AGENTS.md` | Root frontend-agent boundary: frontend-only authority, backend read-only unless OWNER authorizes. |
| `CLAUDE.md` | Root frontend work boundary and mandatory START_HERE entrypoint. |
| `KERNEL.md` | Единственный Operator Kernel / execution-whitelist contract; максимум 8 запусков за MAIN-cycle и 2 за итерацию по решению OWNER Cycle0511. |
| `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md` | Текущие правила работы AI/OWNER; решения 25.10.2026 о обязательных номерных отчётах, SAVEPOINT, тестах, upgrade-only, DigitalOcean и GitHub по актуальному scope. |
| `docs/AI/FRONTEND_READING_ORDER.md` | Минимальный порядок чтения, маршрут Kernel и оба уровня лимитов 8/2. |
| `ops/operator_kernel/config/routes.yaml` | Действующая machine-связь START_HERE → KERNEL → SSOT index → roadmap → cycle ledgers → reports manifest. |
| `reports/cycles/0501-0600__cycles_FRONTEND_ADMIN_CYCLES_0501-0600.md` | Текущий реестр разрешённых циклов 0501–0600, включая Cycle0509. |
| `tests/architecture/test_kernel_two_runs_per_cycle_policy.py` | Постоянная проверка правила: максимум 8/цикл и 2/итерацию, включая FAIL-CLOSED, без обхода лимитов. |
| `docs/testing/DEFECT_REGRESSION_TEST_POLICY.md` | OWNER: каждый подтверждённый дефект или регрессия получает постоянный воспроизводимый тест вместо накопительной подсистемы карточек. |
| `docs/AI/FRONTEND_ARCHIVE_LAWS.md` | Состав и чистота рабочего архива. |
| `release_config/UPDATE_POLICY.json` | Current machine release/update compatibility policy consumed by frontend budget/release tooling. |
| `release_config/TON_PUBLIC_RUNTIME.json` | Machine OWNER authority for public non-secret TON network/project receiver/NFT/EFHC/USDT runtime constants used by real transaction tests. |
| `docs/AI/SKILL_ARCHITECTURE.md` | Current permanent Skill architecture/responsibility/context-minimization process document used by Operator Kernel. |
| `docs/AI/SKILL_ROUTING.md` | Current permanent deterministic Skill routing/permission/context-plan process document used by Operator Kernel. |
| `docs/AI/SKILL_WORKFLOW_INVENTORY.md` | Current Skill workflow classification inventory; historical tools do not participate in routing. |
| `skills/registry.json` | Current machine Skill registry used by Operator Kernel discovery. |
| `skills/workflow_inventory.json` | Current machine workflow-to-Skill inventory. |
| `skills/dependency_graph.json` | Current machine Skill dependency snapshot verified against registry/manifests. |
| `skills/COMMON_EXECUTION_CONTRACT.md` | Current shared fail-closed execution contract for all active Skills. |
| `skills/README.md` | Current Skill layer entry/readme used by Operator Kernel relevant-file resolution. |
| `skills/schemas/skill-manifest.schema.json` | Current machine schema for Skill manifests. |
| `skills/schemas/skill-registry.schema.json` | Current machine schema for the Skill registry. |
| `docs/NORM/FRONTEND_GITHUB_WORKING_ARCHITECTURE.md` | OWNER-approved nine-plugin working architecture/causality: EFHC CODE, PostHog, Linear, Notion, Context7, DigitalOcean, Railway, Atlassian, GitHub; exact-SHA GitHub CI and `_import/` canon. |
| `_import/README.md` | OWNER-protected persistent full-release transfer boundary: OWNER uploads complete `FRONTEND_vNNN.zip`; successful mirror removes only transport ZIP and preserves `_import/`. |
| `docs/NORM/EFHC_REPORTING_RULES_TZ.md` | OWNER-approved reporting canon: dynamic non-blocking navigation during work, strict closure integrity, short human closure, artifact hygiene, single preflight, 15–20 minute law. |
| `docs/NORM/FRONTEND_REPORT_STANDARD.md` | Frontend reporting canon: work-mode navigation drift is repairable/non-blocking; closure-mode sequence is strict; one immutable report per completed iteration and one JSON manifest authority. |
| `reports/rules/00001__rules_reports_section_numbering_and_logging_canon.md` | OWNER-approved reports section structure, number-first naming, iteration-level immutability and log/evidence law. |
| `reports/rules/00002__rules_dynamic_reports_navigation_nonblocking_work.md` | OWNER-approved dynamic report navigation: pointer/manifest drift is repaired during work; strict sequence is closure gate, not startup blocker. |
| `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md` | Текущий и будущий MAIN-cycle план; product work resumed by direct OWNER instruction after Cycle0369 governance closure. |
| `docs/frontend/FRONTEND_COLOR_THEME_DESIGN_DECOUPLING_ROADMAP.md` | OWNER-approved future migration plan: 13 coupled Global Themes → 10 Color Themes × universal design library; Cycles0453–0460 planned/not started. |
| `docs/frontend/FRONTEND_REPOSITORY_RECOVERY_0426-0429_PLAN.md` | Historical recovery sequence 0426–0429 plus current OWNER split of remaining 0429 scope into Cycles0435–0444. |
| `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md` | Current frontend↔backend merge, function-union, security-conflict and stale-guard migration canon. |
| `docs/backend/BACKEND_SOURCE_AUTHORITY.md` | Current single backend source authority: canonical `backend/`, deployment wrapper `api/`, duplicate snapshot/projection ban. |
| `docs/frontend/FRONTEND_DOCUMENTATION_SCOPE.md` | Current frontend documentation scope and protected history boundary. |
| `docs/frontend/FRONTEND_DO_NOT_TOUCH.md` | Current protected frontend routes/product/financial/backend boundaries. |
| `docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md` | Current rendered/runtime visual QA protocol. |
| `docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md` | Current owner-visible screen acceptance and final-ZIP checklist. |
| `contracts/admin/admin_efhc_deposits_summary.json` | Current machine contract for Admin EFHC deposits four-KPI backend-derived summary. |
| `ops/ci_checks/check_frontend_get_operation_chain.py` | Current fail-closed task-specific service GET → hook → view/explicit-status completeness checker; regenerates the current GET-operation registry. |
| `ELEMENT_AUTHORITY_POLICY.md` | Текущие EAM/CSS ownership laws. |
| `docs/SSOT/ADMIN_FREEZE_CANON.md` | Admin **visual-only frozen**; functional/API/code/lint/test error fixes authorized by current OWNER task are priority and not blocked by visual freeze. |
| `docs/frontend/FRONTEND_ADMIN_THEME03_CANON.md` | Единственный current human canon Admin Theme03; machine mapping хранится в `frontend/src/design-system/admin-theme03-canon.json`. |
| `docs/frontend/FRONTEND_BALANCE_SEMANTIC_COLOR_CANON.md` | Current protected Balance financial/status color semantics. |
| `docs/frontend/FRONTEND_PANELS_CANON.md` | Единственный current frontend Panels canon: routes, portfolio, protective dead/reactivation semantics. |
| `docs/frontend/FRONTEND_USER_TASKS_COPY_CANON.md` | Единственный current USER Tasks copy/target presentation canon. |
| `docs/frontend/FRONTEND_DEMO_ENTRY_REFERRALS_CANON.md` | Current standalone DEMO entry/access + Referrals entrypoint canon. |
| `docs/frontend/FRONTEND_THEME03_CANON.md` | Единственный current global Theme03 visual canon; machine palette in `frontend/src/design-system/theme03-chroma.json`. |
| `docs/frontend/FRONTEND_GLOBAL_THEME_ELEMENT_MATRIX.md` | Current human USER Global Theme element/material matrix: Theme03 reference rows + 13-theme palette-projection contract. |
| `docs/SSOT/GLOBAL_THEME_ELEMENT_MATRIX.json` | Machine companion for the current Global Theme element/material matrix. |
| `frontend/src/design-system/theme02-residual-polish-review.json` | Machine evidence for Cycle0398 conditional Theme02 residual review and no-mutation decision. |
| `frontend/src/design-system/theme02-owner-acceptance.json` | Current direct OWNER acceptance: Theme02 is ready at FRONTEND_v622; former separate Theme02 Cycle0399 acceptance waived and untouched future tail compacted by one cycle. |
| `docs/frontend/FRONTEND_THEME02_OWNER_ACCEPTANCE.md` | Human current record of the 2026-10-08 OWNER decision closing Theme02 and moving to Theme04. |
| `frontend/src/design-system/theme03-chroma.json` | Current machine Global Theme03 chroma canon. |
| `frontend/src/design-system/theme03-reference-lock.json` | Historical Theme03 baseline record; immutable USER-only lock is SUPERSEDED by direct OWNER Cycle0468. Admin separate. |
| `frontend/src/design-system/global-theme-role-schema.json` | Current frozen 18-role semantic architecture shared by Global Themes; Foundation II tooling is ready, target projection remains pending. |
| `frontend/src/design-system/theme01-owner-good-baseline.json` | OWNER-good Theme01 visual baseline lock: FRONTEND_v609 rendered character; broad generated projection is forbidden after Cycle0390 recovery unless OWNER explicitly reopens redesign. |
| `frontend/src/design-system/theme01-preservation-map.json` | Theme01 Cycle0391 51-row semantic preservation index; retained as navigation/evidence but superseded as a complete audit method by Cycle0392 Physical Element Census. |
| `docs/frontend/FRONTEND_THEME01_PRESERVATION_MAP.md` | Human Cycle0391 semantic preservation map; historical/current navigation evidence only, not a complete physical colour audit. |
| `docs/frontend/FRONTEND_THEME_AUDIT_CENSUS_PROTOCOL.md` | Current OWNER law for complete Global Theme audits: 51-row semantic index + physical DOM/SVG/pseudo census + chroma census + cascade provenance; palette mismatch is error unless explicit protected exception applies. |
| `docs/frontend/FRONTEND_THEME01_PHYSICAL_ELEMENT_CENSUS.md` | Human Theme01 Cycle0392 physical census summary and audit boundary. |
| `frontend/src/design-system/theme04-color-canon-classification.json` | Theme04 Cycle0400 machine classification of all 285 Cycle0399 computed tokens: palette-family / neutral / explicit semantic / transparent / old-teal FAIL / foreign FAIL; no Chromium rerun and no product mutation. |
| `frontend/src/design-system/theme04-base-fail-provenance-a.json` | Theme04 Cycle0401 base winning-cascade evidence for Shell / Overlay / Energy / Panels / Exchange FAIL owners; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-base-fail-provenance-b.json` | Theme04 Cycle0402 base winning-cascade evidence for Tasks / Referrals / Ranks FAIL owners; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-base-fail-provenance-c.json` | Theme04 Cycle0403 base winning-cascade evidence for Profile / Wallet / History / Settings / Hub FAIL owners; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-base-fail-provenance-d.json` | Theme04 Cycle0404 base winning-cascade evidence for FAQ / Withdraw / Ads / Error / dialogs / overlays FAIL owners; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-browser-shop-base-fail-provenance.json` | Theme04 Cycle0405 Browser Shop base FAIL winning-cascade evidence; audit-only, no forced states and no visual mutation. |
| `frontend/src/design-system/theme04-user-forced-states-a.json` | Theme04 Cycle0406 strict-canon USER forced-state evidence for Shell / Energy / Panels / Exchange / Tasks / Referrals / Ranks; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-user-forced-states-b.json` | Theme04 Cycle0407 strict-canon USER forced-state evidence for Profile / Wallet / History / Settings / Hub / FAQ / Withdraw / Ads / Error; audit-only, no visual mutation. |
| `frontend/src/design-system/theme04-browser-shop-forced-states.json` | Theme04 Cycle0408 strict-canon Browser Shop forced-state evidence; audit-only, no visual mutation. |
| `docs/frontend/FRONTEND_THEME04_COLOR_CANON_CLASSIFICATION.md` | Human Cycle0400 Theme04 classification summary, strict old-teal override, 75 FAIL-token handoff and bounded Cycle0401 boundary. |
| `docs/frontend/FRONTEND_THEME04_PHYSICAL_ELEMENT_CENSUS.md` | Human Cycle0399 Theme04 classic Telegram Blue physical census, old-teal discovery and OWNER gate boundary. |
| `docs/frontend/FRONTEND_THEME02_PHYSICAL_ELEMENT_CENSUS.md` | Human Theme02 Cycle0395 physical census summary and OWNER gate boundary. |
| `docs/frontend/FRONTEND_THEME02_CHROMA_PROVENANCE_AUDIT.md` | Human Cycle0396 Theme02 findings, frozen technical/Admin exclusions and bounded OWNER correction gate. |
| `frontend/src/design-system/theme02-correction-acceptance.json` | Theme02 Cycle0397 machine bounded-correction acceptance: zero USER/Browser-Shop base foreign owner groups, targeted state residual zero, frozen technical/Admin exclusions explicit. |
| `docs/frontend/FRONTEND_THEME02_CORRECTION_ACCEPTANCE.md` | Human Cycle0397 Theme02 bounded-correction acceptance and exact post-correction evidence boundary; Cycle0399 remains full rendered/computed acceptance. |
| `docs/frontend/FRONTEND_THEME02_RESIDUAL_POLISH_REVIEW.md` | Current Cycle0398 conditional residual visual/computed review; no new Theme02 product mutation; handoff to full Cycle0399 acceptance. |
| `docs/frontend/FRONTEND_THEME01_CHROMA_PROVENANCE_AUDIT.md` | Human Cycle0393 findings and OWNER correction gate for Theme01. |
| `frontend/src/design-system/theme01-correction-acceptance.json` | Theme01 Cycle0394 machine acceptance: minimal bounded correction, zero USER/Shop base/state foreign chroma, technical/Admin exclusions explicit. |
| `docs/frontend/FRONTEND_THEME01_CORRECTION_ACCEPTANCE.md` | Human Cycle0394 Theme01 palette-qualification closure. |
| `frontend/src/styles/theme01-bounded-chroma-corrections.css` | Minimal Theme01-only correction layer; broad projection forbidden. |
| `docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json` | Current `Color Theme × Universal Design` SSOT; Cycle0454 state split active (`color_theme_id` + independent `interface_variants`), legacy 13-slot rendering projection retained until later migration. |
| `docs/frontend/FRONTEND_COLOR_DESIGN_DECOUPLING_CENSUS.md` | Human Cycle0453 full COLOR/DESIGN/SEMANTIC/BRAND census and reduction metrics. |
| `frontend/src/design-system/color-theme-registry.json` | Canonical target registry of 10 Color Themes named only by color; adding a new color does not clone designs. |
| `frontend/src/design-system/universal-design-registry.json` | Complete current interface design/semantic/Admin variant census with provenance and preservation law. |
| `frontend/src/design-system/legacy-global-theme-decoupling-map.json` | Deterministic legacy Theme01–13 → target Color Theme + preserved design-set mapping for Cycle0454. |
| `frontend/src/design-system/theme-ownership-classification.json` | COLOR / DESIGN / SEMANTIC / BRAND ownership partition and hard-coded chroma census. |
| `frontend/src/design-system/global-theme-color-canon.json` | Transitional current-runtime 13-theme color map; target architecture authority is `color-theme-registry.json`. |
| `frontend/src/design-system/global-theme-projection-registry.json` | Current Foundation II target-theme registry, write gates, adapter paths and production↔standalone projection boundary. |
| `frontend/src/design-system/global-theme-role-vector.schema.json` | Exact 18-role JSON contract for bounded target-theme vectors; Theme03 is excluded as a target. |
| `frontend/src/styles/generated/global-theme-projections.css` | Generated target-theme aggregate hook; intentionally contains no target runtime rules before authorized theme projection. |
| `frontend/scripts/generate-global-theme-projection.mjs` | Fail-closed target-theme projection generator; Theme03 forbidden, pending targets cannot write. |
| `tools/check_global_theme_projection_foundation.py` | Foundation II implementation guard for Theme03 lock, pending targets, generator boundary and exact 51-row probe coverage. |
| `frontend/scripts/run-global-theme-matrix-harness.mjs` | Dependency-free Chromium/CDP computed-style harness used by later bounded theme acceptance cycles. |
| `frontend/tests/visual/global-theme-matrix-probes.json` | Exact reusable 51-row Global Theme matrix probe plan; harness PASS is evidence, not final visual acceptance. |
| `tools/check_global_theme_role_schema.py` | Current fail-closed Foundation/Theme03-reference guard for the 18-role schema, 51-row pending projection boundary and locked Theme03 implementation. |
| `frontend/src/design-system/balance-semantic-color-canon.json` | Current machine protected Balance semantic/status color canon. |
| `frontend/src/design-system/admin-theme03-canon.json` | Current machine frozen Admin Theme03 mapping. |
| `frontend/src/design-system/admin-element-instances.json` | Current machine frozen Admin element-instance mapping/evidence. |
| `frontend/src/design-system/admin-visual-primitives.json` | Current machine frozen Admin visual primitives canon. |
| `docs/frontend/FRONTEND_EXTERNAL_SHOP_VIP_CANON.md` | Единственный current frontend Shop/VIP canon: surface, catalogue, checkout, wallet, orders and issuance boundaries. |
| `docs/admin/ADMIN_TASKS_EDITOR_CANON.md` | Current self-contained Admin Tasks editor/backend-boundary canon. |
| `docs/admin/ADMIN_GLOBAL_ID_EXPORT_CANON.md` | Current page-local Global-ID selection and server-scoped export security canon. |
| `docs/admin/ADMIN_BONUSES_AND_MANUAL_CREDITS_CANON.md` | Current Admin bonuses analytics and single manual-credit money-road canon. |
| `docs/admin/ADMIN_DIAGNOSTICS_TECHNICAL_BOUNDARY.md` | Current frozen Admin diagnostics technical-only/no-business-mutation boundary. |
| `docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md` | Current human Admin route/navigation map; listed method/path rows verified against indexed backend snapshot. |
| `docs/admin/ADMIN_VISIBLE_FUNCTIONS_GUARD_MATRIX.md` | Current frozen-Admin visible-function/backend-road guard matrix; navigation/evidence layer, not product SSOT. |
| `docs/admin/ADMIN_FINANCIAL_STATUS_UTILITIES_CANON.md` | Current Admin financial/status utility semantics and do-not-restore boundaries. |
| `docs/admin/ADMIN_HUMAN_LANGUAGE_CANON.md` | Current human-facing Admin wording boundary; technical identifiers remain protected contracts. |
| `docs/admin/ADMIN_REPORTS_AND_OBSERVABILITY_CANON.md` | Current Admin reports/observability route and real-data semantics canon. |
| `docs/admin/ADMIN_SHOP_MANAGEMENT_CANON.md` | Current frozen Admin Shop management/catalog boundary. |
| `docs/admin/ADMIN_TASKS_CATALOG_UX.md` | Current Admin Tasks template/catalog operator UX boundary. |
| `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md` | Current Admin TON/EFHC deposit recovery, atomicity and fail-closed canon. |
| `docs/admin/ADMIN_VIP_NFT_MANAGEMENT_CANON.md` | Current Admin VIP/NFT ownership and management canon. |


## Backend integration authority / pending handoff — task-relevant only

Current backend code authority is `docs/backend/BACKEND_SOURCE_AUTHORITY.md` + canonical `backend/` source. Version-bound backend snapshots are not current authority.

| Artifact | Role |
|---|---|
| `contracts/integration/FRONTEND_BACKEND_HANDOFF_CUMULATIVE_THROUGH_0234_v175_34.patch` | Preserved pending historical integration payload; not current backend source and not applied automatically. |

## Identity / authentication machine contracts — protected task-relevant authority

Эти machine contracts фиксируют provider-neutral identity/auth boundaries и не являются разрешением автоматически менять backend/main. Они читаются только при identity/auth/integration scope.

| Contract | Role |
|---|---|
| `contracts/identity/auth_context_contract_v1.json` | Safe provider-neutral AuthContext response/resolver boundary. |
| `contracts/identity/auth_provider_registry_v1.json` | Closed provider registry and fail-closed provider enablement rules. |
| `contracts/identity/identity_resolver_contract_v1.json` | Transactional provider-subject → global_id resolver invariants. |
| `contracts/identity/telegram_auth_session_contract_v1.json` | Telegram auth/session/registration atomicity contract. |
| `contracts/identity/telegram_init_data_contract_v1.json` | Telegram init-data verification adapter contract. |
| `contracts/identity/ton_auth_session_contract_v1.json` | TON auth/session and frontend bearer transport contract. |
| `contracts/identity/ton_login_challenge_contract_v1.json` | TON login challenge/storage/canonical-address contract. |
| `contracts/identity/ton_proof_verification_contract_v1.json` | TON proof verification/replay/side-effect boundary. |

## SSOT / CANON — current domain facts

| Document | Что в нём |
|---|---|
| `docs/SSOT/ACCOUNT_SURFACES_SSOT.md` | ACCOUNT SURFACES SSOT |
| `docs/SSOT/ADMIN_FREEZE_CANON.md` | ADMIN FREEZE CANON — ACTIVE |
| `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md` | ADMIN NFT ACCESS CANON |
| `docs/SSOT/BANK_CANON.md` | EFHC BANK CANON / SSOT |
| `docs/SSOT/ECONOMY_CANON.md` | EFHC ECONOMY CANON |
| `docs/SSOT/ENERGY_RULES.md` | Energy Rules (SSOT) |
| `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` | EFHC SSOT: Механика Обменника и Вывода |
| `docs/SSOT/FAQ_SSOT.md` | FAQ SSOT EFHC; 16-language JSON/MD mirrors live under `docs/SSOT/faq_ssot/<locale>/`. |
| `docs/SSOT/FORBIDDEN_WORDS_AND_EXCEPTIONS_SSOT.md` | FORBIDDEN WORDS AND EXCEPTIONS SSOT |
| `docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md` | GLOBAL IDENTITY BOUNDARY LOCK |
| `docs/SSOT/GLOBAL_IDENTITY_SSOT.md` | GLOBAL IDENTITY SSOT |
| `docs/SSOT/HUB_SSOT.md` | HUB SSOT |
| `docs/SSOT/IDENTITY_GLOSSARY.md` | IDENTITY GLOSSARY |
| `docs/SSOT/LANGUAGE_CANON_SSOT.md` | Language canon SSOT |
| `docs/SSOT/LOCALIZATION_GLOSSARY_SSOT.md` | LOCALIZATION GLOSSARY SSOT |
| `docs/SSOT/LOCALIZATION_SCOPE_SSOT.md` | LOCALIZATION SCOPE SSOT |
| `docs/SSOT/NEUTRAL_ALIASES_CANON_SSOT.md` | NEUTRAL ALIASES CANON SSOT |
| `docs/SSOT/PANELS_SSOT.md` | SSOT: Panels |
| `docs/SSOT/PAYMENT_INTENTS_PRODUCT_STATE_MACHINE_SSOT.md` | Payment Intents Product State Machine SSOT |
| `docs/SSOT/PAYMENT_INTENT_SSOT.md` | Payment Intent SSOT |
| `docs/SSOT/PROJECT_ASSET_LINKS.md` | Project asset links |
| `docs/SSOT/PROJECT_GLOSSARY.md` | PROJECT GLOSSARY |
| `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md` | PROVIDER IDENTITY MAPPING SSOT |
| `docs/SSOT/ROUTE_RESPONSE_ERROR_CANON.md` | ROUTE_RESPONSE_ERROR_CANON |
| `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md` | SSOT: Архитектура защиты и реконсиляции Shop-транзакций (External Payment Flow) |
| `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md` | Skin switcher concept SSOT |
| `docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md` | Telegram WebApp integration (EFHC CANON / SSOT) |
| `docs/SSOT/TON_MEMO_SPEC.md` | TON MEMO Spec (SSOT) |
| `docs/SSOT/USER_FACING_WORDING_CANON.md` | User-facing wording canon |
| `docs/SSOT/WALLETS_TONCONNECT_SSOT.md` | Wallet transport architecture addendum — v171.66 |
| `docs/SSOT/WALLET_IDENTITY_SSOT.md` | Актуальный wallet identity SSOT — цикл 1618 |
| `docs/SSOT/WALLET_PROVIDER_SSOT.md` | WALLET PROVIDER SSOT |
| `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md` | SSOT: Admin Withdraw TonConnect Flow |

## Current governance registries / approval boundaries

| Document | Что в нём |
|---|---|
| `docs/GENERAL/BANK_QUESTIONS_ANSWERS_REGISTRY.md` | Current OWNER-approved Bank questions/answers register used by BANK_CANON. |
| `docs/GENERAL/FAQ_APPROVAL_GOVERNANCE.md` | Current FAQ approval/change-control boundary referenced by FAQ SSOT. |
| `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md` | Current FAQ approval register referenced by FAQ governance. |
| `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json` | Current machine FAQ approval manifest. |
| `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` | Current per-language human translation/review status; structural runtime parity is tracked separately. |
| `docs/GENERAL/PUBLIC_COPY_FIREWALL.md` | Current public-copy product-language firewall boundary. |

## NORM — current implementation rules

| Document | Что в нём |
|---|---|
| `docs/NORM/ADMIN_DASHBOARD_UI_KIT_FOUNDATION.md` | Cycle 1497 sync note |
| `docs/NORM/ADMIN_LOGS_EVENTS_DASHBOARD.md` | ADMIN_LOGS_EVENTS_DASHBOARD.md |
| `docs/NORM/ADMIN_PAYOUT_CANON.md` | Admin payout canon |
| `docs/NORM/FRONTEND_GET_OPERATION_STATUS.json` | Current explicit NO_UI/RETIRED status exceptions for GET-operation chain completeness. |
| `docs/NORM/FRONTEND_GET_OPERATION_REGISTRY.json` | Current generated service GET/hook/view + Admin-linked GET callsite registry; regenerated by the indexed checker. |
| `docs/NORM/ADMIN_SAFE_ERROR_SUMMARY_CANON.md` | Admin Safe Error Summary Canon |
| `docs/NORM/ADMIN_SYSTEM_HEALTH_DASHBOARD.md` | ADMIN_SYSTEM_HEALTH_DASHBOARD.md |
| `docs/NORM/API_CONTRACTS.md` | API contracts |
| `contracts/identity/global_id_api_contract_v1.json` | Machine Global ID wire-format/API contract referenced by current API NORM. |
| `contracts/identity/identity_registry_v2.json` | Machine provider-subject → global_id identity registry referenced by current identity/API authority. |
| `docs/NORM/BACKEND_SIGNATURE_DRIFT_GUARD.md` | Backend signature drift guard |
| `docs/NORM/BONUS_AWARDS_LEGACY_GUARD_SCOPE.md` | Bonus Awards Legacy Guard Scope |
| `docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md` | BROWSER_SHOP_PAYMENT_FLOW_NORM |
| `docs/NORM/COLD_START_MVP_UX_CANON.md` | Cold Start MVP UX Canon |
| `docs/NORM/DIRECT_EFHC_PAYMENT_INTENT_CANON.md` | Direct EFHC Payment Intent Canon |
| `docs/NORM/EVENT_CONTRACTS_NORM.md` | EVENT CONTRACTS NORM |
| `docs/NORM/EXCHANGE_DASHBOARD_SUPPORT_WIDGETS.md` | Exchange Dashboard Support Widgets |
| `docs/NORM/EXCHANGE_PUBLIC_ERROR_FALLBACK.md` | Exchange Public Error Fallback |
| `docs/NORM/FRONTEND_API_I18N_CONSISTENCY.md` | Cycle 1517 addendum — Frontend Buttons / API / i18n Drift Audit |
| `docs/NORM/FRONTEND_CYCLE_TIMEBOX_CANON.md` | FRONTEND CYCLE TIMEBOX CANON |
| `docs/NORM/FRONTEND_EFHC_DEPOSITS_SUMMARY_CONTRACT.md` | Current EFHC Deposits four-KPI/server-time/data-authority contract. |
| `docs/NORM/FRONTEND_OPERATOR_ERROR_REGISTER.md` | FRONTEND OPERATOR ERROR REGISTER |
| `docs/NORM/FRONTEND_SERVICE_API_REACT_QUERY_STANDARD.md` | Frontend Service API React Query Standard |
| `docs/NORM/FRONTEND_SERVICE_QUERY_REGISTRY.md` | Current funding and Withdraw service/query registry — v171.36 |
| `docs/NORM/FRONTEND_TON_RUNTIME_PATH_NORM.md` | FRONTEND TON RUNTIME PATH NORM |
| `docs/NORM/HUB_BROWSER_SHOP_COMPACT_CHECKOUT_NORM.md` | HUB and Browser Shop compact checkout norm |
| `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md` | OWNER CLARIFICATION QUESTIONS — FRONTEND STANDARD |
| `docs/NORM/LANGUAGE_CANON_CORRECTION_PROTOCOL.md` | LANGUAGE CANON CORRECTION PROTOCOL |
| `docs/NORM/LEADERBOARD_VISUAL_SYSTEM.md` | LEADERBOARD_VISUAL_SYSTEM.md |
| `docs/NORM/LOCALIZATION_WORKFLOW_NORM.md` | LOCALIZATION WORKFLOW NORM |
| `docs/NORM/MINI_CHARTS_FOUNDATION.md` | MINI CHARTS FOUNDATION |
| `docs/NORM/OFFLINE_ROUTE_FALLBACK_CANON.md` | Offline and Route Fallback Canon |
| `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md` | Payment Intent Flow Norm |
| `docs/NORM/PUBLIC_ACTIVE_COPY_GUARD_NORM.md` | Public active-copy guard norm |
| `docs/NORM/PUBLIC_COPY_FIREWALL_GUARD.md` | PUBLIC_COPY_FIREWALL_GUARD.md |
| `docs/NORM/PUBLIC_ERROR_MESSAGE_CANON.md` | Public error message canon |
| `docs/NORM/PUBLIC_ERROR_STATE_CANON.md` | Public Error State Canon |
| `docs/NORM/PUBLIC_VISUAL_BASELINE_CANON.md` | PUBLIC VISUAL BASELINE CANON |
| `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` | Frontend Owner Q&A Register |
| `docs/NORM/RANKS_RULES.md` | Ranks Rules |
| `docs/NORM/REFERRALS_RULES.md` | Referrals Rules |
| `docs/NORM/REFERRAL_DEEPLINK_BINDING_CANON.md` | Referral first-creation attribution canon |
| `docs/NORM/SKILL_ARCHITECTURE_CANON.md` | SKILL ARCHITECTURE CANON |
| `docs/NORM/TASKS_STANDARD.md` | TASKS_STANDARD |
| `docs/NORM/TOAST_AND_EMPTY_STATE_CANON.md` | Toast and Empty State Canon |
| `docs/NORM/TONCONNECT_E2E_SANDBOX_GUARD.md` | TonConnect e2e sandbox guard |
| `docs/NORM/TON_WALLET_CANON_ADMIN_PAYOUT.md` | PACK-02 TON Wallet Canon / Admin Payout Canon |
| `docs/NORM/UNIFIED_EXTERNAL_STOREFRONT_NORM.md` | Unified external storefront norm |
| `docs/NORM/VIP_EXTERNAL_VERIFICATION_NORM.md` | VIP external verification norm |
| `docs/NORM/VIP_NFT_TONCONNECT_SYNC_CANON.md` | VIP / NFT TonConnect Sync Canon — Cycle 1516 |
| `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md` | VISUAL FRONTEND PUBLIC UI NORM |
| `docs/NORM/VISUAL_PERFORMANCE_BUNDLE_SAFETY.md` | Visual Performance / Bundle Safety |
| `docs/NORM/WALLET_BINDING_CANON.md` | Wallet binding canon |
| `docs/NORM/WALLET_CANONICAL_ADDRESS_NORM.md` | TON canonical address norm |
| `docs/NORM/WALLET_PROVIDER_ADAPTER_NORM.md` | WALLET PROVIDER ADAPTER NORM |
| `docs/NORM/WEBAPP_BIND_RETRY_SEMANTICS.md` | Current pre-auth referral start-param transport/retry semantics; no late-bind mutation. |
| `docs/NORM/WITHDRAW_AUDIT_CANON.md` | Withdraw audit canon |
| `docs/NORM/WITHDRAW_FLOW_NORM.md` | Withdraw flow norm |

## Current process/tooling guards

| Path | Role |
|---|---|
| `ops/operator_kernel/run.py` | Current fail-closed Operator Kernel; when a physical archive is supplied, report continuity is verified through the complete ZIP sequence. |
| `ops/reports/check_numbered_reports.py` | Current numbered-report integrity gate; supports local strict mode and physical-ZIP virtual continuity for immutable legacy filenames. |
| `ops/reports/create_numbered_report.py` | Current numbered-report creator; derives N+1 only from a verified complete sequence and accepts parent ZIP for legacy filename boundary. |
| `tools/audit_skill_workflow_inventory.py` | Current-only Skill workflow inventory/dependency audit; historical workflow class is forbidden. |
| `tools/check_theme_physical_census.py` | Current complete-census structural guard for audited Global Themes including Theme01/Theme02/Theme04: verifies declared scene/viewport coverage, static hidden surface inventory, palette law, no runtime projection and Theme03 lock. |
| `tools/check_theme02_bounded_correction.py` | Cycle0397 fail-closed guard for Theme02 bounded correction acceptance, Theme02-only selector scope, Shop Global Theme binding and Theme03/Admin/garbage-cleanup freezes. |
| `tools/compact_theme01_chroma_provenance.py` | Compacts raw Cycle0393 provenance/state parts into the current Theme01 machine audit. |
| `tools/compact_theme_physical_census.py` | Current standard-library compactor for isolated Chromium physical-census evidence + static DOM inventory. |
| `frontend/scripts/run-theme-physical-element-census.mjs` | Dependency-free Chromium/CDP physical DOM/SVG/pseudo/computed-chroma census runner. |
| `tools/check_global_theme_color_canon.py` | Current global-theme semantic color guard; validates 13 theme IDs/colors without binding to a historical release identity. |
| `ops/operator_kernel/cache/file_map.summary.json` | Non-authoritative current-head cache; regenerated at release closure. |


| `docs/AI/EFHC_AVAILABLE_PLUGINS_AND_SKILLS.md` | OWNER-approved exact nine-plugin whitelist, role boundaries, causality graph and new-plugin approval gate. |

### Protected explanatory companions — not operational authority

These files are retained because they explain rejected/superseded concepts and the reasons behind current boundaries. They do not compete with current CANON/SSOT/NORM.

- `docs/NORM/WEBAPP_START_PARAM_BINDING.md` — protected explanation of the prohibited late referral-binding design and its distinction from current creation-time auth transport.

## Historical/audit boundary

- `reports/cycles/` — canonical number-first historical cycle-document layer after completed Cycle0432 migration; читать только если Kernel/OWNER прямо требует audit/regression.
- `reports/` — final work-block/cycle reports, not a log of micro-operations: related tasks are grouped in one report after completion; separate reports require genuinely independent completed blocks/iterations; missed tasks are recovered in one consolidated report. Finalized numbered report contents are immutable; `FRONTEND_REPORT_MANIFEST.json` is the sole machine report index; `reports/evidence/` is historical/contract-required compatibility only and is not a parallel log layer.
- Versioned/superseded документы вне этого index не являются active authority и подлежат дальнейшей cleanup-процедуре.
- External `Артефакты` находятся вне project root и никогда не читаются Kernel автоматически.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Постоянное прямое правило OWNER: ни один ENV-файл проекта нельзя удалять без прямого решения OWNER.** Это включает `.env`, `.env.*`, production/development/local profiles, templates/examples, recovery copies и будущие ENV-файлы. Удаление+создание замены, потеря исходного пути при migration/refactor/cleanup/release/update и объявление файла legacy не являются разрешением. `.gitignore`, security concern и наличие defaults также не разрешают удаление.

Cycle0447 прямо разрешает восстанавливать отсутствующие подтверждённые несекретные settings и исправлять их конфликт с OWNER canon в существующей ENV-архитектуре. Существующие значения сохраняются без основания для изменения; секреты не менять, не публиковать и не угадывать. **Application configuration values, numeric settings, public URLs and public blockchain addresses are NOT project secrets.** **EFHC Bank address is public canonical project data and must not be deleted.**

Публичный SSOT: `TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW` — EFHC Bank / Банк EFHC. Payment receiver не должен создавать другой project-wallet canon. Изменения Cycle0447 выполняются commit/PR, без physical release по прямой OWNER-команде. Существующая fail-closed защита physical mirror остаётся действующей; нового approval/governance-слоя нет. Простой Git deletion guard проверяет потерю ENV-файла, без контроля количества ключей.

Подтверждённая несекретная configuration восстановлена из текущего кода/public profiles/templates. Исторический incident неизвестных утраченных runtime/secret values остаётся `RECOVERY_REQUIRED`: они не объявляются восстановленными. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; physical mirror policy: `release_config/ENV_OWNER_PROTECTION.json`; единственный secret-free ENV canon: `docs/SSOT/ENV_PROTECTION_SSOT.md`.


| `frontend/src/design-system/color-design-persistent-state-contract.json` | Cycle0454 machine contract for settings v17 / standalone V041, exact legacy migration and v16/V040 rollback compatibility. |

## Дополнительная тематическая навигация — OWNER 2026-10-21 (v747)

Тематика (не меняет Kernel scope и порядок запуска):
- [`docs/README.md`](../README.md) — вход в новую документацию;
- [`docs/frontend/INDEX.md`](../frontend/INDEX.md) — пользовательский интерфейс;
- [`docs/backend/INDEX.md`](../backend/INDEX.md) — backend и финансы;
- [`docs/shared/INDEX.md`](../shared/INDEX.md) — общие правила;
- [`docs/shared/decisions/OWNER_DECISIONS_v747.md`](../shared/decisions/OWNER_DECISIONS_v747.md) — решения OWNER;
- [`docs/backend/finance/PANEL_PROTECTIVE_100_REFUND_OWNER_A.md`](../backend/finance/PANEL_PROTECTIVE_100_REFUND_OWNER_A.md) — историческое решение А по Панелям, **SUPERSEDED** новой OWNER-операцией; текущий SSOT: `docs/SSOT/PANELS_SSOT.md` §12.3.

Записи индексов — навигация, а не автоматическое повышение черновиков до SSOT.
