<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# PROVIDER IDENTITY MAPPING SSOT

Статус: **CANON / SSOT / ACTIVE**

## Нормативная формула

`provider + subject → global_id → business runtime`.

| Provider | Canonical subject |
|---|---|
| Telegram | `tg_id` |
| TON | `ton_wallet_id` |
| Google | `google_id` |
| Apple | `apple_id` |
| Facebook | `fb_id` |
| Discord | `discord_id` |
| GitHub | `github_id` |

## Инварианты

- одна пара `provider + subject` принадлежит ровно одному `global_id`;
- один `global_id` может иметь несколько provider identities;
- добавление или отключение provider не меняет business owner;
- provider proof проверяется до identity resolution;
- business API после авторизации не принимает provider subject как
  owner selector;
- Telegram delivery остаётся provider boundary и не создаёт ownership.

## Fail-closed правила

- конфликт mapping не разрешается автоматическим merge;
- неизвестный provider subject не создаёт business row;
- provider subject не преобразуется численно в `global_id`;
- новая binding обязана ссылаться на существующий canonical account.

## Канонические provider wire names

| Провайдер | Wire name | Subject field |
|---|---|---|
| Telegram | `telegram` | `tg_id` |
| TON | `ton` | `ton_wallet_id` |
| Google | `google` | `google_id` |
| Apple | `apple` | `apple_id` |
| Facebook | `facebook` | `fb_id` |
| Discord | `discord` | `discord_id` |
| GitHub | `github` | `github_id` |

`ton_wallet_id` содержит сам адрес TON-кошелька и используется вместо отдельного номера TON. В generic `user_identities.provider_subject` хранится это же каноническое значение для `provider=ton`. Runtime provider aliases не принимаются. Устаревшее wire-имя `ton_wallet` запрещено как auth-provider identifier. Поле `users.ton_wallet` относится к данным TON-кошелька и не является provider identifier. `mock` допускается только в test-layer.

## Runtime hardening 1702

- production wire providers: `telegram`, `ton`, `google`, `apple`, `facebook`, `discord`, `github`;
- `mock` разрешён только в test-контуре и не входит в production registry;
- storage uniqueness: `(provider, provider_tenant, provider_subject)`;
- одинаковое значение subject у разных providers является разными identity keys;
- collision одной provider-key между двумя accounts завершается fail closed;
- automatic account merge запрещён;
- session owner — `global_id`; composite `(identity_id, global_id)` обязан ссылаться на ту же identity;
- Telegram/TON linking допускается только к уже доказанному canonical `global_id`.

## Security/audit boundary 1703

После provider resolution privileged context, signed internal handoff и audit actor используют `global_id`. Provider subject допускается только для доказательства/доставки на provider boundary и не переносится в privileged owner claims.
