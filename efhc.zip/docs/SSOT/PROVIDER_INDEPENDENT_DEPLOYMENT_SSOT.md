# Provider-independent deployment SSOT

Status: ACTIVE SSOT.
Archive line: `v171.91`.

## Canonical decision

EFHC must not depend on OVHcloud, Vercel, Neon, Google Cloud or any other
specific infrastructure provider. A provider is only a current hosting
location. It is not part of the application architecture.

## Runtime contract

The production runtime is:

```text
Caddy HTTPS proxy
├── Next.js frontend
├── FastAPI backend
└── standard PostgreSQL
```

All services run through standard Docker images and Docker Compose.
The required first-start command is:

```text
./scripts/release/deploy.sh
```

Plain `docker compose up -d` is not the canonical first-start command because
it does not by itself express the complete preflight, backup, migration,
validation, seed and smoke-test sequence.

No provider panel, proprietary build button, managed-function API or
provider-only database extension is required.

## Domain contract

The application uses project-owned hostnames:

- `APP_DOMAIN` for Web App, PWA and Telegram Mini App;
- `API_DOMAIN` for API and Telegram webhook.

A host migration changes DNS records, not application routes. When the
same project domains are preserved, the Telegram Mini App link and
TonProof domain remain stable.

## Database contract

PostgreSQL remains standard PostgreSQL. Schema changes use Alembic.
Logical transfer uses `pg_dump` custom format and `pg_restore`.
Provider-only SQL extensions or storage APIs are forbidden unless the
user explicitly approves them and a portable fallback exists.

## Secret contract

Production secrets exist only in a server-side `.env` file or an
equivalent external secret store. They are never included in source,
GitHub, Docker images or release archives.

The production configuration backup must be encrypted and stored outside
the active hosting account.

## Backup contract

A recoverable EFHC installation requires:

- a daily PostgreSQL dump;
- an encrypted production configuration backup;
- the exact release archive;
- SHA-256 checksums;
- several recent generations;
- at least one off-site copy outside the current provider.

## Portability proof

Static portability is proved by the release package and guards.
Operational portability is proved only by deploying the same release and
backup on a second host, restoring PostgreSQL and completing the smoke
matrix. Until that drill is executed, the status is
`PORTABILITY_PREPARED / CROSS_PROVIDER_DRILL_PENDING`.


## Update contract

Every later production version is delivered as a complete sequential release
ZIP plus SHA-256 sidecar. The active release directory is never overwritten.
`update.sh` verifies the external checksum, safely extracts the target, checks
the internal file inventory and update policy, runs the target deployment, and
switches `/opt/efhc/current` only after healthchecks. File-by-file production
patching is forbidden.
