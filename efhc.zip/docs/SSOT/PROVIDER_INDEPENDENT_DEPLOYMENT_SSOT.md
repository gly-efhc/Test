# Provider-independent deployment SSOT

Status: ACTIVE SSOT.
Archive line: `v171.91`.

## Canonical decision

EFHC must not depend on OVHcloud, Vercel, Neon, Google Cloud or any other
specific infrastructure provider. A provider is only a current hosting
location. It is not part of the application architecture.

## Runtime contract

The production runtime is:

```text
Caddy HTTPS proxy
├── Next.js frontend
├── FastAPI backend
└── standard PostgreSQL
```

All services run through standard Docker images and Docker Compose.
The required first-start command is:

```text
./scripts/release/deploy.sh
```

Plain `docker compose up -d` is not the canonical first-start command because
it does not by itself express the complete preflight, backup, migration,
validation, seed and smoke-test sequence.

No provider panel, proprietary build button, managed-function API or
provider-only database extension is required.

## Domain contract

The application uses project-owned hostnames:

- `APP_DOMAIN` for Web App, PWA and Telegram Mini App;
- `API_DOMAIN` for API and Telegram webhook.

A host migration changes DNS records, not application routes. When the
same project domains are preserved, the Telegram Mini App link and
TonProof domain remain stable.

## Database contract

PostgreSQL remains standard PostgreSQL. Schema changes use Alembic.
Logical transfer uses `pg_dump` custom format and `pg_restore`.
Provider-only SQL extensions or storage APIs are forbidden unless the
user explicitly approves them and a portable fallback exists.

## Secret contract

Production secrets находятся только в server-side `.env` либо в эквивалентном защищённом secret store. Они не включаются в source, GitHub, Docker images или release archives.

Production configuration внутри recovery bundle шифруется. Для независимого аварийного хранения владелец вручную скачивает canonical encrypted recovery artifact на свой ПК или смартфон по SSH/SFTP; обязательный второй server/host не используется.

## Backup contract

Восстанавливаемая EFHC installation требует:

- daily PostgreSQL backup;
- encrypted production configuration внутри recovery bundle;
- точный release archive;
- SHA-256 checksums;
- несколько последних локальных generations;
- owner-managed encrypted copy на ПК или смартфоне, если требуется независимая от VPS recovery-копия.

## Portability proof

Static portability подтверждается release package и guards. Operational portability подтверждается только restore drill на чистом заменяющем VPS/test-safe environment из полного release + encrypted backup. Это не постоянная вторая VPS и не monitoring host. До такого drill статус остаётся `PORTABILITY_PREPARED / CLEAN_REPLACEMENT_VPS_DRILL_PENDING`.


## Update contract

Каждая следующая production version поставляется как полный последовательный release ZIP с SHA-256 sidecar. Active release directory не перезаписывается.

`update.sh` проверяет внешний checksum, безопасно извлекает target, сверяет internal file inventory/update policy и завершает target pre-commit deployment checks до явной update commit boundary. Post-commit qualification всегда записывает детерминированное terminal state. File-by-file production patching запрещён.
