<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# ACCOUNT SURFACES SSOT

Статус: **SSOT / ACTIVE**

## Один аккаунт

Все пользовательские поверхности работают с одним EFHC account,
владельцем которого является `global_id`. Telegram, TON, Google, Apple,
Facebook, Discord и GitHub являются provider identities, а не отдельными
аккаунтами и не business owners.

## Роли поверхностей

- Telegram — текущая launch/auth/delivery surface.
- Hub — переход и краткое truth-summary.
- Browser Shop — внешний execution surface для shop/payment intents.
- Web Profile — канонический account, payment и history center.
- ProfileModal — компактный operational overlay, не второй профиль.

## External sector

Внешний Web Shop визуально отделён, но использует тот же `global_id`,
единый economic truth и общую историю EFHC.

## Запреты

- нельзя создавать отдельный Telegram-owned профиль;
- нельзя делать Browser Shop главным account center;
- нельзя превращать ProfileModal во второй полный профиль;
- provider context после identity resolution не становится owner.
