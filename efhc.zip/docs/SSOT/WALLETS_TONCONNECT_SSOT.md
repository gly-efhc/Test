## Цикл 1746 — canonical proof verification

Wallet TonConnect API требует полный proof envelope: `state_init`, `public_key`, `network`, signature/domain/timestamp/payload. `network` проверяется против configured `TON_NETWORK`; authoritative key/address берутся через общий canonical TON proof resolver/primitives из `app.identity.ton_proof_verification`. Client-key-only verification запрещена.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# Wallet transport architecture addendum — v171.66

The application-facing wallet boundary is now `WalletProvider`. TonConnect is
one adapter, not the only WebApp architecture:

```text
WalletProvider
├── TonConnectAdapter
├── TelegramWalletAdapter
└── NativeGramWalletAdapter
```

The existing TonConnect/TonProof backend security and settlement rules in this
SSOT remain unchanged. Application features must call the common provider
contract. Provider-specific TonConnect behavior is isolated in
`frontend/src/lib/wallet-provider/adapters/TonConnectAdapter.ts`. Future
Telegram/native adapters must meet the same verified ownership and fail-closed
transaction boundaries. Full architecture truth is in
`docs/SSOT/WALLET_PROVIDER_SSOT.md`.

---

## Admin wallet reset semantic repair — cycle 1441

Admin reset route:

```text
POST /admin/users/{global_id}/wallet/reset
```

Canonical meaning:

- `efhc_core.users.ton_wallet` retired; reset работает только через canonical `efhc_core.wallet_bindings`;
- deactivate canonical `efhc_core.wallet_bindings` for that `global_id`;
- set `is_active=false` and `is_primary=false`;
- write admin audit log with `wallet_bindings_deactivated=...`;
- commit once after canonical reset and audit log are staged.

Reset обязан деактивировать canonical bindings; отдельного legacy wallet field больше нет.

Frontend Admin получает отображаемый wallet из canonical bindings и не использует `users.ton_wallet` как authority.

# WALLETS + TONCONNECT SSOT

## Current funding canon — cycles 1560 repair / 1561

Two financial contours are separate and MUST NOT be merged.

### Direct deposit — `Прямое пополнение`

- Entry: only the `+` button in `GlobalHeader`.
- Asset sent by the user: external EFHC jetton (`EFHCj`).
- Destination result: internal main balance (`EFHCm` / `EFHC_MAIN`).
- Accounting rule: exact asset quantity, `1 EFHCj = 1 EFHCm`.
- Backend open route: `POST /deposit/direct-open`.
- Wallet action: TEP-74 EFHC jetton transfer through TonConnect.
- Current legacy memo: `EFHC:<global_id>`. Target memo is `EFHC|UID:0000000001|...`; legacy watcher parsing remains until the cycle-1604 source-event migration.
- Native TON, TON/EFHC pricing, packages and store checkout are forbidden in this contour.

### Store purchase — `Пополнение`

- Entry: HUB card `Пополнение`.
- HUB is navigation only and opens the external Browser Shop through a signed handoff.
- Purchase assets: native TON/GRAM or USDT jetton on TON/GRAM.
- Product result: purchased EFHCm credited to the internal main balance.
- Payment requires a pre-created payment intent, fixed asset, amount, payload, TTL and watcher reconciliation.
- TON uses a native TonConnect transfer.
- USDT uses a real TEP-74 jetton transfer.

The route `POST /deposit/efhc` is a package/payment-intent compatibility route. It is not the GlobalHeader direct-deposit action and MUST NOT be described as `Прямое пополнение`.

## Термины

- **global_id** — системный владелец данных EFHC. Историческая колонка `users.user_id` удалена; физический owner — `users.global_id`.
- **tg_id** — внешний Telegram provider subject. До read switch
  legacy runtime разрешает его как compatibility owner key.
  Новый TON login не требует заранее известного `global_id`.

- **wallet_connected** — у global_id есть минимум 1 активная привязка
  TON-кошелька.

- **Direct deposit / Прямое пополнение** — прямой перевод EFHC jetton через кнопку `+` с точным зачислением во внутренний `EFHC_MAIN`. Каноничный endpoint открытия контура: `POST /deposit/direct-open`.

- **Hub EFHC external purchase / Пополнение** — внешний поток покупки EFHCm за TON/GRAM или USDT jetton. User-facing стартует только из Hub и Browser Shop.

- **Hub internal EFHC flow (off-chain)** — внутренний backend commerce flow за EFHC. TonConnect не обязателен, если отдельно не закреплено иначе. Backend commerce endpoint: `POST /shop/purchase-efhc`.

## Источник истины

- UI не решает, подключён ли кошелёк.
- UI запрашивает статус через `GET /wallets/me`.

## WalletGate (server-side MUST)

До TonConnect запрещены операции:

1. `POST /deposit/efhc`
2. `POST /shop/order-external`
3. `POST /withdraw/request`

При запрете сервер возвращает:

- HTTP 403
- `code = WALLET_REQUIRED`
- `details.feature` = имя фичи

Важно:

- `POST /shop/purchase-efhc` — shop_internal (off-chain) и не
  должен возвращать `WALLET_REQUIRED` по умолчанию.

## Семантика endpoints и details.feature

Норма: `details.feature` используется **только** в ответе
`403 WALLET_REQUIRED` и не должен подменять семантику endpoint.

- `POST /deposit/efhc`
  - семантика: Deposit EFHC (on-chain покупка EFHC)
  - WalletGate: да
  - details.feature: `deposit`

- `POST /shop/order-external`
  - семантика: Hub EFHC external (TON/USDT on-chain; user-facing entry lives in Hub)
  - WalletGate: да
  - details.feature: `shop_external`

- `POST /withdraw/request`
  - семантика: Withdraw (только MAIN)
  - WalletGate: да
  - details.feature: `withdraw`

- `POST /shop/purchase-efhc`
  - семантика: Shop internal
  - пояснение: Hub internal EFHC flow (off-chain списание; user-facing entry is not a Shop screen)
  - WalletGate: нет
  - details.feature: не применяется
`403 WALLET_REQUIRED` и не должен подменять семантику endpoint.

## A+B контур on-chain оплаты (Payment Intents)

Источник истины — сервер.

1) WebApp делает запрос на создание intent (Idempotency-Key обязателен):

- Deposit: `POST /deposit/efhc` (body: package_id)
- Hub EFHC external: `POST /shop/order-external`

2) Сервер создаёт/возвращает `payment_intent` и отдаёт TonConnect tx.

### Assets: TON и USDT (TON jetton)

Поддерживаются assets:

- `TON` — обычный перевод TON на адрес получателя.
- `USDT` — jetton transfer в TON сети.

Каноничные настройки (ENV / Settings):

- `PAYMENTS_RECEIVER_ADDRESS` — адрес получателя on-chain оплат.
- `EFHC_JETTON_MASTER_ADDRESS` — master address EFHC jetton
  (`EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw`).
- `EFHC_JETTON_DECIMALS` — decimals EFHC jetton (`8`).
- `USDT_JETTON_MASTER_ADDRESS` — master address USDT jetton.
- `JETTON_TRANSFER_FEE_NANO` — TON fee для jetton transfer сообщения.

Важно различать:
- `EFHC` внутри бота = внутренний off-chain учёт
  `main_balance + bonus_balance`;
- `EFHCj` = внешний EFHC jetton в сети TON;
- `USDT` = отдельный внешний jetton и отдельный payment flow.

Для `USDT` каноничный payload передаётся как **forward payload** в
jetton-transfer. Watcher допускает payload как отдельную строку
`EFHC:...` или как подстроку (например `FORWARD_PAYLOAD=EFHC:...`).

Watcher матчится на **каноничный payload** `EFHC:...` и проверяет asset,
адрес назначения и сумму.

3) WebApp вызывает `tonconnect.sendTransaction(tx)`.

4) Watcher подтверждает оплату по входящей транзакции TON:

- извлекает memo/comment
- матчится на `payment_intents.payload`
- атомарно переводит intent в CONFIRMED
- выполняет side-effects:
  - deposit_efhc: кредит MAIN (main_balance)
  - shop_external: заказ PAID_AUTO (+ EFHC_PACKAGE → кредит MAIN)

Инварианты подтверждения:

- Один `external_tx_hash` не может подтверждать два разных intent.
- Повторный confirm для одного и того же intent — no-op (без повторного
  начисления).

### Unmatched incoming (без payload) — без автоначисления

Если входящая on-chain транзакция пришла на адрес получателя проекта, но её
memo/comment **не содержит** каноничный payload `EFHC:<purpose>:<intent_id>:<global_id>`
или payload не матчится ни на один существующий intent, то автоначисление
запрещено.

Watcher обязан:

- записать строку в `unmatched_incoming` (idempotent по `tx_hash`)
- финализировать обработку как `pending_manual`

Это гарантирует, что "непонятные" переводы не начисляются пользователю
автоматически.

### Статусы и UX "ожидание подтверждения"

Статусы intent:

- `SENT` — сервер выдал TonConnect tx (готово к оплате).
- `CONFIRMED` — watcher подтвердил оплату.

Для UX polling истины используется owner-only endpoint:

- `GET /payment-intents/{intent_id}`

Ответ включает `status`, `asset`, суммы, `created_at`, `expires_at` и
`external_tx_hash` (после CONFIRMED).

### Каноничный payload

Формат фиксирован (обязателен для watcher match):

`EFHC:<purpose>:<intent_id>:<global_id>`

Пример:

`EFHC:deposit_efhc:12345:99887766`

Норма: payload задаётся **сразу финальным при создании intent**. Запрещены
временные placeholder вида `EFHC:<purpose>:0:<global_id>` — они ломают
`UNIQUE(payload)` и делают невозможным сценарий "2 платежа = 2 пополнения".

## API: /wallets/*

### GET /wallets/me

Возвращает список привязок и `is_connected`.

### POST /wallets/connect

- Требует `Idempotency-Key`.
- Привязывает `address` к global_id.
- Идемпотентность: сервер фиксирует `Idempotency-Key` и повтор
  возвращает тот же результат (wallet_id).
- Глобальная уникальность: один address не может принадлежать
  двум global_id.
- Конфликт (адрес у другого global_id): `WALLET_CONFLICT`.

### POST /wallets/{wallet_id}/make-primary

Делает кошелёк primary для global_id.

### DELETE /wallets/{wallet_id}

Деактивирует привязку.

## CloudStorage (MUST NOT)

Запрещено хранить как "истину":

- wallet, wallets, address, connected, tonconnect

CloudStorage допускается только для UI-настроек.

## TonProof

TonProof предусмотрен архитектурно, но включается отдельным циклом.

## Current Browser Shop payment state

- TON/GRAM native payment is implemented locally.
- USDT jetton payment uses the TEP-74 transfer builder locally.
- Both assets remain payment-intent and watcher gated.
- Local implementation does not claim a real signed network transaction.


## TonConnect manifest source

Canonical TonConnect manifest source for runtime is `/api/tonconnect-manifest`.
The static `frontend/public/tonconnect-manifest.json` file is fallback-only and
contains an explicit `_note` marker. Do not treat the static file as the primary
manifest in EFHC Bot integrations.

## PACK-02 wallet identity canon

EFHC Bot accepts valid TON address formats at input boundary, but
stores and compares one canonical internal address format.

Canonical format is `<workchain>:<64 lowercase hex account_id>`.

`wallet_bindings.wallet_address` stores this canonical address and is
used for ownership, conflict check, watcher lookup and unique constraint.

The active wallet binding mechanism is TonConnect proof, signature
verification, `global_id` binding, `wallet_bindings`, replay protection and
idempotency. Legacy memo/bind-request wallet binding is not active
runtime canon.

## Cycle 1563 runtime closure

### Restore semantics

`restoreConnection()` must run once on provider initialization. Restore
completion and restored connectivity are different facts:

- `restoreSettled=false` means restore is still running;
- `restoreSettled=true` with no wallet means disconnected;
- a restored wallet plus an existing backend binding means connected;
- a restored wallet without a valid binding requires a fresh proof.

The wallet hook must be React-reactive through connector status subscription.
Reading `connector.wallet` without a state subscription is forbidden.

### Complete TonProof binding envelope

The active wallet-binding request must include the full proof envelope:

- address;
- wallet application;
- payload token;
- public key;
- network;
- timestamp;
- domain and `lengthBytes`;
- signature;
- payload;
- state init when supplied.

A frontend proof check followed by an incomplete `/wallets/connect` request is
forbidden. The binding endpoint remains the authoritative verification and
replay-protection boundary.

### Rejection and transaction states

Connection rejection and transaction rejection must be visible human states.
TonConnect rejection code `300` is not a generic backend error. Transaction UX
must distinguish `signing`, `signed`, `rejected` and `error`.

## Current TON Connect chooser accessibility / keyboard contract

- Chooser dialog programmatic name follows the active view title: main chooser title on the main view and localized `All wallets` title on the full-wallet view.
- Wallet search has a localized accessible name; selected wallet-category filters expose programmatic pressed state (`aria-pressed`) in addition to visual state.
- `All wallets` remains a native button. Opening the full-wallet view moves focus to search. `Back` clears query/filter state and returns focus to the `All wallets` control.
- Escape in the full-wallet view performs `Back`; Escape on the main chooser closes it. Busy state blocks Escape/back/close transitions that could interrupt the operation.
- Standalone mirrors the same view-name/search/filter/keyboard contract and remembers the exact opener. Closing the chooser, including the normal wallet-selection close path, returns focus to that opener when it still exists.
- These accessibility/keyboard laws do not change registry source, QR presentation, wallet selection semantics, TonProof, payment routing or financial behavior.

## OWNER public TON runtime canon — restored

Machine authority for public, non-secret TON transaction targets is `release_config/TON_PUBLIC_RUNTIME.json`; dotenv mirror for test/deploy tooling is `env.ton.public`. These values are intentionally retained in the physical release and Git repository because real transaction tests require a deterministic destination.

- `TON_NETWORK=mainnet`
- `TON_API_BASE_URL=https://tonapi.io`
- `TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW`
- `TON_WALLET_ADDRESS=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW`
- `PAYMENTS_RECEIVER_ADDRESS=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW`
- `TON_NFT_COLLECTION=EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0`
- `EFHC_JETTON_MASTER_ADDRESS=EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw` (`D8`)
- `USDT_JETTON_MASTER_ADDRESS=EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCixRv7Nw2Id_sDs` (`D6`)

These entries contain no private key, seed phrase, signing secret or provider API key. Removing/replacing them with placeholders makes real TON/EFHC routing tests non-authoritative and is forbidden unless a direct OWNER decision changes the public runtime canon.

`NativeGramWalletAdapter` remains fail-closed until an authorized runtime bridge exists. Therefore a real native GRAM signature/broadcast/settlement MUST NOT be claimed as tested merely because TON/EFHC routing passes.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

