# Payment Intents Product State Machine SSOT

Status: ACTIVE  
Phase: work pass

## Canonical product states
- `created`
- `active`
- `pending_external`
- `terminal_success`
- `terminal_failed`
- `expired`
- `manual_review`

## Mapping intent
This is a product/runtime mapping layer for user-facing continuity.
It does not replace low-level DB statuses. It standardizes how Browser-Shop,
Hub, Web-Profile and Telegram describe the same active payment situation.

## Canonical meanings
- `created` — intent exists, but the payment path has not started.
- `active` — the user is in the live payment path.
- `pending_external` — the external/network side has seen the payment, but
  final settlement is not complete.
- `terminal_success` — the flow finished successfully.
- `terminal_failed` — the flow finished without success.
- `expired` — the intent lifetime ended and must not be reused.
- `manual_review` — the flow needs operator review and must not spawn a
  duplicate intent.

## Continuity rules
- one state name per runtime situation
- one CTA family per state
- one canonical return path to Web-Profile
- one latest active payment summary in the canonical center
