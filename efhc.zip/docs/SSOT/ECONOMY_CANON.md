# EFHC ECONOMY CANON

Статус: **ACTIVE SSOT / EMERGENCY RESTORATION 1708**  
Версия решения: **v173.33**

Этот документ фиксирует экономическую механику приложения. Последнее явное
решение пользователя имеет приоритет над этим файлом.

## 1. Денежные сущности

- `EFHCm` — основной пользовательский баланс (`main_balance`).
- `EFHCb` — бонусный пользовательский баланс (`bonus_balance`).
- `EFHC` — общий/агрегатный смысл: `EFHCm + EFHCb`.
- `EFHCj` — внешний EFHC jetton в TON.
- У `BANK_EFHC` нет разделения на EFHCm/EFHCb: возврат любого пользовательского
  баланса поступает в один баланс банка как EFHC.

Функциональный UI обязан показывать конкретное назначение:
- Exchange и Withdraw: `EFHCm`;
- Referrals и Tasks/ADS rewards: `EFHCb`;
- общий баланс и цена, оплачиваемая смесью двух балансов: `EFHC`.

## 2. Центральный банк

Все денежные изменения пользователя проходят только через `BANK_EFHC`.

- начисление: `BANK_EFHC -> USER`;
- системное списание: `USER -> BANK_EFHC`;
- прямой `USER -> USER` запрещён;
- пользовательские балансы не могут уходить в минус;
- баланс банка может уходить в минус;
- банковская ledger-строка: `system_entity=BANK_EFHC`, `global_id=NULL`,
  `tg_id=NULL`;
- баланс банка: `efhc_core.bank_balance[key=EFHC_MAIN]`; имя ключа техническое,
  экономически это единый баланс EFHC банка.

`Mint` и `Burn` существуют только как аварийные административные механизмы банка,
не как обычная часть экономики пользователя.

## 3. Energy

Панели генерируют kWh, а не EFHC.

- BASE: `0.00000692 kWh/s` на активную панель;
- VIP: `0.00000741 kWh/s` на активную панель;
- lifetime panel: `180 days`;
- максимум активных панелей: `1000`;
- lifetime `total_generated_kwh` не уменьшается.

Доступная к обмену энергия вычисляется:

`available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`.

## 4. Exchange

- направление только `kWh -> EFHCm`;
- курс строго `1 kWh = 1 EFHCm`;
- `EFHCm/EFHCb -> kWh` запрещено;
- при обмене банк дебетуется на ту же сумму, на которую кредитуется EFHCm
  пользователя;
- EFHCb в Exchange не участвует.

## 5. Panels

- цена активации одной Panel: `100 EFHC`;
- **OWNER 2026-10-21:** единый путь для активации, реактивации и
  защитного возврата/отмены: сначала `EFHCb`, затем `EFHCm`, затем
  недостающее `kWh` конвертируется `1:1` в `EFHCm` и списывается;
- списывается ровно одна цена `100.00000000` за Панель, без долга;
  обмен и финальное списание — отдельные реальные зеркальные проводки
  в одной транзакции; исторические записи не редактируются;
- движение: `USER -> BANK_EFHC`;
- денежное списание и создание Panel должны оставаться одной логической
  атомарной операцией;
- P2P отсутствует.

### Admin analytics: deactivated-Panel obligations and net Panel spend (owner v170)

For owner Admin analytics, one Panel has canonical acquisition base exactly `100.00000000 EFHC`. The New obligations population is all deactivated **economic** Panels regardless of deactivation reason, excluding any Panel that was protectively voided with the OWNER-2026-10-21 new 100 EFHC settlement and generation annulment. The exact-D8 whole-application metric is:

`new_obligations = Σ deactivated_economic.generated_kwh - 100.00000000 × deactivated_economic_count`.

Use actual stored `generated_kwh`. Production authority must be server-global; a capped frontend list is not an aggregate. The `1 kWh = 1 EFHCm` Exchange canon makes the excess-kWh number numerically equal to the corresponding EFHCm obligation, but it does not redefine EFHC as kWh.

`panel_spend_net = successful EFHCm + EFHCb Panel acquisition debits - Panel acquisition refunds/cancellations`, all-time across active and deactivated Panels.

OWNER 2026-10-21 amendment: protective manual deactivation creates a NEW audited settlement of `100.00000000 EFHC` via current EFHCb -> EFHCm -> available kWh converted 1:1 to EFHCm and then debited to BANK, without backdated refund. Preserve Panel number/history, cancel its generated kWh and exclude it from operational Panel analytics. Historical full-refund and `100-R` formulations are superseded; previous ledger entries remain immutable.

## 6. Referrals

Активный direct referral — пользователь, который активировал первую Panel.

- за первого activation-event каждого direct referral: `0.1 EFHCb`;
- этот unit bonus действует максимум для первых `10 000` active direct referrals;
- level rewards:
  - 10 active -> `1 EFHCb`;
  - 100 active -> `10 EFHCb`;
  - 1000 active -> `100 EFHCb`;
  - 3000 active -> `300 EFHCb`;
  - 10000 active -> `1000 EFHCb`;
- все rewards: `BANK_EFHC -> USER EFHCb`.

## 7. Tasks / ADS

- task/advertising reward начисляется только в `EFHCb`;
- начисление только `BANK_EFHC -> USER EFHCb`;
- прямой UPDATE пользовательского денежного баланса запрещён.

## 8. Withdraw

- выводится только `EFHCm`;
- minimum: `10 EFHCm`;
- создание/hold: `USER EFHCm -> BANK_EFHC`;
- EFHCb не выводится;
- после разрешённого payout action заявка считается `PAID` по утверждённому
  канону; обязательная backend-проверка фактического включения TON-транзакции
  не требуется;
- отклонение/отмена до финальной выплаты возвращает EFHCm отдельной
  компенсирующей проводкой банка.

## 9. External deposits / external Shop settlement

После подтверждения внешнего входящего события внутренний денежный эффект —
`BANK_EFHC -> USER EFHCm` на утверждённую сумму. Внешний settlement является
доказательством/metadata внутренней проводки, а не вторым внутренним балансом.

Первичное зачисление по внешнему событию допускается только при проверенном `trusted_operation_at` младше 180 суток и согласованном server first-seen. Порядок обязателен: time validation -> replay/idempotency -> BANK/user mutation -> ledger. Событие возрастом ровно 180 суток или старше остаётся только history/audit и не может впервые изменить баланс.

Внутри приложения товарные карточки не являются пользовательским магазином;
пользовательский магазин открывается внешней HTML-витриной через утверждённый
handoff. Backend payment/order mechanisms сохраняются для этой внешней витрины.

## 10. Запреты

- P2P EFHC;
- обратный `EFHC -> kWh`;
- отрицательные пользовательские денежные балансы;
- прямые денежные UPDATE вне `transactions_service`/канонического bank helper;
- двойное списание одной покупки с EFHCb и EFHCm;
- автоматическое создание новых денежных rewards для Ranks/Achievements без
  отдельного утверждённого reward-contract;
- запрещённые денежные риск-механики и риск-розыгрыши.
