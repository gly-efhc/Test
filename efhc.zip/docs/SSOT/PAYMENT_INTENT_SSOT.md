# Payment Intent SSOT

## Active purposes

`deposit_efhc` is the direct EFHC top-up purpose.

`shop_external` is the external shop payment purpose.

## Direct EFHC top-up canon

Direct EFHC top-up intent remains valid until execution,
cancellation, manual close, or technical/abuse block.

`expires_at` is not price protection for direct EFHC top-up.
It may be used for UI freshness or recommended payment window, but not
as automatic rejection of a correct direct EFHC incoming payment.

## Transaction identity

Same `tx_hash` is idempotent replay.

Different `tx_hash` is a separate incoming deposit.

For V1 the minimum on-chain identity is `tx_hash`. Future hardening may
extend it with network, logical time, message hash, or out message hash.
