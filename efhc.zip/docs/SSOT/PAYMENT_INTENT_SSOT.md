# Payment Intent SSOT

Статус: ACTIVE / финансовый CANON после цикла 1744.

## Active purposes

`deposit_efhc` — прямое пополнение EFHC через Payment Intent.

`shop_external` — внешняя оплата Shop.

## Жизненный цикл и TTL

Новый on-chain settlement разрешён только если строка Payment Intent,
заблокированная `FOR UPDATE`, одновременно удовлетворяет условиям:

- `status = PENDING`;
- `expires_at IS NOT NULL`;
- `expires_at > current time`.

Истёкший, отменённый, уже подтверждённый или неизвестный статус не может
создать новое автоматическое начисление. Для истёкшего intent пользователь
создаёт новый intent с новой актуальной фиксацией условий.

Единственное исключение — точный идемпотентный read-through: если intent уже
`CONFIRMED` и `external_tx_hash` полностью совпадает с повторно полученным
`tx_hash`, повтор не создаёт новую финансовую операцию и возвращает уже
достигнутый результат.

## Transaction identity

`tx_hash` является глобальной on-chain settlement identity. Один blockchain
`tx_hash` может иметь только один immutable settlement claim в
`efhc_core.tx_hash_locks`, независимо от того, через какой business path он
пришёл: watcher, Payment Intent, direct deposit или Admin recovery.

Другой `tx_hash` не может повторно использовать уже `CONFIRMED` Payment Intent.
Для новой on-chain операции требуется новый `PENDING` intent либо отдельный
канонический direct-deposit flow, если именно он предусмотрен продуктом.

Профильный lock CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`.


## Creation idempotency — cycle 1744

Creation key имеет DB authority `UNIQUE(global_id, purpose, idempotency_key)`.
При повторе ключа exact read-through разрешён только после сравнения полного
immutable creation fingerprint:

- `package_id`;
- `asset`;
- `amount_asset_d8`;
- `efhc_amount_d8`;
- `to_address`.

Если хотя бы одно поле отличается, API обязан fail-closed вернуть
`409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD` и не смешивать старый
intent с новым request.

При полном совпадении response строится только из persisted PaymentIntent row:
`intent_id`, `global_id`, `purpose`, `asset`, обе суммы, destination, payload и
`expires_at`. Новый HTTP request не имеет права подменить финансовые поля
старого intent. TonConnect `validUntil` для read-through выводится из
сохранённого `expires_at`; replay не продлевает TTL. Exact existing intent
проверяется до pending-intent limit, чтобы лимит не разрушал идемпотентный
read-through уже существующей операции.


## External execution window — cycle 1774

Для нового on-chain подтверждения lifecycle/TTL Payment Intent является
необходимым, но недостаточным условием. До replay/idempotency claim и до
денежной мутации дополнительно обязательна строгая проверка:
`trusted_operation_at` age `< 180 days` и согласованный сохранённый
`server_first_seen_at`. Ровно 180 суток и старше — `EXPIRED / NO CREDIT`.
Точный read-through уже подтверждённого `CONFIRMED + same tx_hash` не является
новым credit и сохраняется.

## Cycle 1794 — PaymentIntent v2: external atomic authority

Owner-Decision-Refs: `QA-2026-08-19-FIN3-11`, `QA-2026-08-19-FIN3-12`.

Для новых TON/USDT intents logical contract:

```text
asset
external_amount_atomic
external_decimals
efhc_amount_d8
```

Новый payload фиксирует immutable external snapshot:

```text
EFHC2:<purpose>:<intent_id>:G<global_id>:<asset>:<atomic>
```

`amount_asset_d8` физически остаётся в frozen schema **LEGACY / FROZEN SCHEMA COMPATIBILITY ONLY** и не является settlement authority для PaymentIntent v2.

Создание intent преобразует manual Shop `price_ton`/`price_usdt` в native atomic units ровно один раз. Catalog price остаётся product authority; payload atomic amount — execution snapshot только данного intent.

V2 idempotency fingerprint включает package/order context, asset, exact atomic amount, native decimals, `efhc_amount_d8`, destination и payload version. Settlement сравнивает `actual_atomic == expected_atomic`.

P0 порядок действует и для exact replay: trusted operation time → 180-day barrier → replay/idempotency → mutation → ledger. `CONFIRMED + same tx_hash` read-through не проверяется раньше temporal barrier.

## Cycle 1796 — Shop D2 catalog boundary before atomic snapshot

Owner-Decision-Refs: `QA-2026-08-19-FIN3-13`, `QA-2026-08-20-FIN3-14`.

Для **внешнего Shop** intents manual catalog `price_ton` / `price_usdt` должна уже удовлетворять owner-lock max D2. Внутреннего Shop и отдельного внутреннего D2-pricing contour не существует. PaymentIntent не выполняет D2 rounding. Invalid >D2 catalog price отклоняется до intent creation.

```text
D2 catalog price
→ native atomic conversion once
→ immutable PaymentIntent snapshot
```

Native execution precision сохраняется: TON = 9 atomic decimals, USDT = 6 atomic decimals. `efhc_amount_d8` остаётся внутренним D8 результатом покупки EFHC.

