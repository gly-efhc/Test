# LOCALIZATION SCOPE SSOT

Статус: CANON / SSOT.

Этот документ фиксирует границы языковых контуров EFHC Bot.

## 1. Пользовательский контур

Пользовательский контур EFHC Bot является мультиязычным.

В него входят:

- Telegram bot user messages;
- public frontend UI;
- Hub;
- Browser Shop;
- wallet, top up, deposit;
- withdraw;
- exchange;
- panels;
- tasks;
- referrals;
- ranks;
- profile, Web Profile, Profile Modal;
- FAQ;
- user notifications;
- user-visible moderation messages;
- user-visible system templates;
- payment, order and watcher statuses.

Для этого контура обязательны полные переводы, единая терминология,
отсутствие raw i18n keys, fallback leaks, mixed-language screens и
hardcoded user copy вне i18n.

## 2. Админ-панель

Админ-панель EFHC Bot является русским операторским контуром.

Админ-панель не входит в обязательный multilingual coverage.

Не требуется:

- переводить admin UI на другие языки;
- считать отсутствие admin.* в non-ru locale blocker-ошибкой;
- рефакторить уже существующие дополнительные non-ru admin-переводы без
  отдельного указания пользователя.

Требуется:

- админка работает на русском языке;
- admin.* существует в ru;
- admin UI не показывает raw keys;
- admin UI не показывает English fallback без технической причины;
- admin.* не используется в пользовательском UI.

## 3. Правило admin.*

- admin.* проверяется как ru-only operator contour.
- admin.* в non-ru locale не является blocker.
- user-facing использование admin.* является blocker.
- Если дополнительные non-ru admin-переводы уже есть, они не удаляются и
  не рефакторятся без прямой команды пользователя.

## 4. Templates scope

System templates делятся на:

- user_visible;
- admin_internal;
- system_internal.

user_visible templates должны быть locale-aware. admin_internal templates
являются ru-only. system_internal templates не должны отправляться
пользователю.

## 5. Forbidden contour boundary

Активный release-контур проверяется на запрещённый gambling/loto
contour. Исторические reports, audits, Healer, logs и cycle records не
чистятся и не считаются blocker, если слово используется как
историческое описание ошибки.


## 6. Игра и азартный контур

EFHC Bot может описываться как игра, игровой бот, игровой проект и
игровой процесс. Эти формулировки не запрещены сами по себе.

Запрещён не игровой слой как таковой, а азартный, лотерейный,
розыгрышный, турнирный и соревновательный финансовый контур.

Guard-проверки не должны автоматически удалять или блокировать слова
`игра`, `игровой`, `игровой процесс`, если они не создают запрещённый
финансовый смысл.


## Запрет оправдательного тона

EFHC Bot может прямо описываться как игра, игровой бот и игровой проект. При этом в user-facing, FAQ, help и канонических документах запрещён оправдательный тон: продукт не должен объяснять себя как виноватый, оправдываться или занимать защитную позицию без необходимости. Нужно описывать правила, механику и канон как факты.
