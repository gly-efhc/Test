## Addendum cycle 1748 — VIP derived-state integrity

Energy service продолжает использовать `users.is_vip` как materialized derived state для выбора Base/VIP ставки. Поэтому wallet/NFT contour обязан fail-closed поддерживать его актуальность: после исчезновения последнего допустимого TON wallet source `is_vip=FALSE`, `vip_since=NULL`, `vip_checked_at` обновляется; массовый reconciliation лечит ранее накопившийся stale VIP. Формулы и ставки энергии этим addendum не изменяются.

# Energy Rules (SSOT)

Статус: CANON / SSOT.

Этот документ фиксирует правила генерации энергии (kWh) в EFHC Bot.
Любые расчёты на клиенте запрещены: клиент только отображает значения,
полученные из снапшота/SSOT.

## 1) Per-sec генерация (MUST)

Генерация начисляется только по времени (per-sec) и выполняется на
бэкенде.

Формула начисления:

```
generated_kwh = panels_count * gen_per_sec * elapsed_seconds
```

Где:
- panels_count — активные панели пользователя.
- gen_per_sec — ставка генерации (Base или VIP).
- elapsed_seconds — прошедшее время в секундах.

## 2) Константы и источник истины (MUST)

Каноничные значения:

```
GEN_PER_SEC_BASE_KWH = 0.00000692
GEN_PER_SEC_VIP_KWH  = 0.00000741
EFHC_KWH_RATE        = 1.0
```

Источник истины:
- Settings (backend/app/core/config_core.py) хранит значения строками.
- system_locks.assert_per_sec_canon() обязан валидировать канон.
- Сервисы получают ставки только через SSOT-helper (d8, ROUND_DOWN).

VIP-логика:
- Если VIP=true, то все панели пользователя работают по VIP-ставке.
- Если VIP=false, то все панели работают по Base-ставке.

## 3) Decimal и округление (MUST)

- Все значения kWh/EFHC считаются через Decimal.
- Точность: 8 знаков после запятой.
- Округление: всегда вниз (ROUND_DOWN).
- Запрещено использовать float/Number и любые научные представления.

## 4) Batch начисления (MUST)

- Начисление выполняется пакетно (backfill) и детерминировано.
- Для конкурентной обработки использовать блокировки строк.
- Любые начисления должны быть идемпотентны и аудируемы.
- Для одной generation boundary сумма `Δ panels.generated_kwh` пользователя обязана точно равняться `Δ users.total_generated_kwh` в той же DB transaction.
- Generation delta вычисляется только из pre-update `last_generated_at`; после продвижения timestamp этот же интервал повторно не вычисляется из нового значения.
- Успешный generation commit запрещён, если panel delta и user lifetime delta расходятся.


## 4A) Связь с exchange и available_kwh

- `available_kwh` не редактируется вручную и рассматривается как
  вычисляемое зеркало текущего HEAD.
- Обмен kWh -> EFHC регулируется смежным SSOT:
  `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`.
- Energy rules не создаёт отдельный альтернативный канон обмена.
## Active Energy/theme semantic law
- Active Energy indicators/titles use the active theme semantic accent; gray is reserved for inactive/deactivated meaning and white must not replace an active semantic accent merely as a fallback.
- Full-page/globally glassed darkening is not an accepted substitute for individual theme surfaces.
## EI/PB customization boundary
- `EI` and `PB` are independent user-switchable customization libraries. Their authored local colours/visual identities are not Global Theme defects and must not be repainted, normalized, redrawn or silently reselected by Theme corrections.
- Theme03 may style the surrounding Energy page/frame, but it does not force-bind an `EI`/`PB` preset to Theme03. Existing violet presets remain optional local choices only.
- Global Theme work must preserve Energy calculations, economics, runtime/data semantics and the independent EI/PB selection state.
- Current authored violet examples remain optional local choices: `EI-07` (Energy icon) and `PB-20` (progress material). Their existence does not bind Theme03 to those presets and does not authorize repainting other EI/PB variants.


## Cycle0455 Color Theme supersession

Energy color is now projected from canonical `color_theme_id` (`CT-01..CT-10`) independently from design selection. `PB` and `EI` IDs survive Color Theme changes. Common unset-state defaults are `EI-07` and `PB-01`. Referrals `RP` is separate state but uses the same 35 progress designs, with common unset-state default `PB-01`. All PB/RP fill is clipped inside its track. Ordinary elevation is the shared neutral Theme03-derived shadow; glow hue follows Color Theme while glow topology remains design-owned.
