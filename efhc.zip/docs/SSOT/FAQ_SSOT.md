# FAQ SSOT EFHC — CURRENT

Status: **ACTIVE / CURRENT / RUNTIME-MIRRORED**  
Last synchronized from application runtime: `2026-10-02`.

## 1. Current authority model

The checked-in application FAQ content is `frontend/src/data/faq/catalogs.ts`. For the current physical HEAD it is the factual runtime corpus and contains exactly **16 languages × 20 sections × 230 Q&A items**.

`docs/SSOT/faq_ssot/<lang>/faq_<lang>.json` and `.md` are synchronized human/machine mirrors of that checked-in runtime corpus. They must not silently diverge from it.

For future FAQ wording/business changes, direct OWNER decisions + `QUESTIONS_AND_ANSWERS_REGISTER.md` + FAQ approval records remain the semantic change authority. This synchronization cycle is a recovery action explicitly ordered by OWNER: **application FAQ → FAQ SSOT/documents**, without changing application FAQ text.

## 2. Languages

Current runtime/mirror set:

`ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.

Each language has:
- `faq_<lang>.json` — machine mirror with runtime section/question IDs;
- `faq_<lang>.md` — human-readable mirror generated from the same runtime catalog.

## 3. Current structure

- sections: `20`;
- subsections: `20` (one runtime subsection per section in the current corpus);
- Q&A items per language: `230`;
- total localized runtime FAQ items: `3680`;
- Levels section: `19`;
- FAQ / Help section: `20`.

Question IDs (`1-1` … `20-6` according to each section range) are runtime identities and must be preserved by mirrors.

## 4. Russian semantic anchor

Russian runtime catalog `faqCatalogByLang.ru` is the primary semantic-language anchor for comparison with OWNER/Q&A decisions. Its synchronized mirrors are:

- `docs/SSOT/faq_ssot/ru/faq_ru.json`;
- `docs/SSOT/faq_ssot/ru/faq_ru.md`.

Mirror files are not allowed to invent questions or retain removed runtime questions.

## 5. Translation status

Structural/runtime parity does **not** mean full human linguistic certification. Per-language translation/human-review status is tracked in `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md`.

## 6. Approval/change boundary

Ordinary future FAQ edits follow `docs/GENERAL/FAQ_APPROVAL_GOVERNANCE.md`. A semantic FAQ change must be approved before runtime mutation. A recovery/parity audit may mirror the already checked-in runtime into documentation only when OWNER explicitly orders runtime→SSOT synchronization, as in Cycle0356.

## 7. Hard parity rule

For each of the 16 languages, runtime and SSOT mirrors must agree on:
- section count/order/IDs/titles;
- question IDs/order;
- question text;
- answer text.

A mismatch is a documentation/runtime drift and must fail closed until reconciled from the explicitly selected authority direction.

## 8. Current FAQ search / expanded-answer / accessibility contract

- An expanded FAQ search result renders the full canonical answer from the current runtime catalog; excerpts may be used only for preview/list purposes, never as the opened answer body.
- One current search contract is shared by production fallback and Worker and mirrored by standalone: lowercase → Unicode NFKD → remove combining U+0300–U+036F marks → `ё`→`е` → replace non-letter/non-number/non-space characters with spaces → collapse whitespace → trim. Empty normalized query returns no search results.
- Normalized query is split into non-empty terms. Matching is substring-based and additive; terms do not require an all-terms match. Per-term weights are: question `5`, keywords `4`, subsection title `3`, section title `2`, answer `1`; one term may score in multiple fields.
- Include only items with total score > 0. Order is descending score; ties use ascending `item.id` with JavaScript `localeCompare`. Sort first, then return at most `24` results.
- Production Worker/fallback and standalone preserve parity for case differences, `ё/е`, no-result and >24-result cases.
- FAQ search input has a persistent localized programmatic name. The clear action reuses the localized reset-search label as accessible name/title. Active search exposes a polite atomic localized result-count status. Clear restores the unfiltered FAQ tree and returns focus to search.
- These rules govern search/runtime presentation only; they do not authorize semantic FAQ text changes outside the approval/change boundary above.

## 9. Current FAQ multi-open / page-local open-state contract

- FAQ question expansion is **multi-open**: opening one question must not close any other already-open question.
- Repeating the activation on an open question closes **only that question**. There is no singleton accordion owner for question state.
- Open question IDs are page-local runtime state. The optional URL `item` value remains a deeplink/anchor compatibility field and must not collapse the open set to one item.
- FAQ rerenders, search activation/clear and runtime language changes must preserve the current set of open question IDs while the user remains on FAQ. Search-result expansion uses the same open set as the normal FAQ tree.
- Leaving the FAQ page resets the page-local open set. Re-entering FAQ without an explicit deeplink starts with no questions open.
- Production React and standalone must preserve these semantics in parity. Parent section/subsection containers may reopen as needed to expose an already-open question after rerender; this does not change question open-state ownership.
- This interaction contract does not authorize FAQ text, search ranking, geometry, Theme03 material, section ordering or backend changes.
