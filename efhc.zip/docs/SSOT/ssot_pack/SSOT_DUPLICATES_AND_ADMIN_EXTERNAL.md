# SSOT_DUPLICATES_AND_ADMIN_EXTERNAL

## Current active state
- Physical ORM duplicates: none confirmed.
- Logical ORM ↔ 0001 mismatches: none confirmed in active HEAD.
- Active schemas: only `efhc_core` and `efhc_admin`.

## 0001 vs ORM vs SSOT summary
- `backend/migrations/versions/0001_init.py` is ORM-only.
- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv` currently contains 35 active
  tables.
- `0001` creates tables from `Base.metadata` and sanity-checks count
  against `SSOT_TABLES_ORM.csv`.

## Admin schema tables present in active ORM
- `efhc_admin.admin_action_log`
- `efhc_admin.admin_role`
- `efhc_admin.admin_whitelist`
- `efhc_admin.efhc_sale_packages`
- `efhc_admin.idempotency_key`

## Historical note
Older mismatch inventories remain valid only as historical audit
materials. They are not active SSOT for the current HEAD.
