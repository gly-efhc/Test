# Skin switcher concept SSOT

Date: 2026-03-28
Cycle: 91
Status: ACTIVE
Scope: concept layer only

## 1. Purpose

Skin switcher is a separate user-facing layer for selecting which already
available progression skin is active on the main screen.

Skin switcher is not Hub.

Skin switcher is not a commerce screen.

Skin switcher does not perform purchases.

## 2. Separation of domains

### 2.1 Hub

Hub remains a navigation layer only.
Hub can mention that skins exist in the project, but it must not host the
switcher itself and must not contain skin activation or purchase logic.

### 2.2 Progression rewards

Skins are unlocked by account progress only.
The canonical progression source is the 12-level scale already fixed in
`frontend/src/lib/skins.ts` as `USER_LEVEL_SKINS`.

### 2.3 Legacy commerce bridge

Current routes/models still keep a legacy commerce bridge:
- `POST /skins/buy/{skin_id}`
- `price_efhc`
- `purchased_at`

This bridge remains implementation history and must not define the new
switcher concept.

## 3. Canonical switcher meaning

Skin switcher answers only three questions:

1. which skins are unlocked now;
2. which skin is active now;
3. which unlocked skin the user wants to activate.

Skin switcher does not answer how a skin was historically obtained.

## 4. Unlock source

The canonical unlock source is current user progression.

Unlock rule:
- `skin_id = 1` is the base skin and is always available;
- each next progression level unlocks its corresponding skin;
- unlocked set is cumulative: if the user has level N, all skins with
  `skin_id <= N` are available.

The switcher must therefore use the current progress level as the truth
source for availability, not old purchase history.

## 5. Active skin rule

`active_skin_id` is the selected visual theme for the main screen artwork.
It is a user choice inside the set of currently unlocked skins.

Decision rule:
- if stored `active_skin_id` belongs to the unlocked set, keep it;
- otherwise fallback to the highest unlocked skin;
- if anything is broken or missing, fallback to `skin_id = 1`.

This keeps selection independent from old commerce traces.

## 6. Minimal runtime shape for cycle 92

Cycle 92 should expose a clean switcher-facing runtime shape like:

- `current_level`
- `available_skin_ids`
- `active_skin_id`
- `items[]` with `skin_id`, `title`, `asset_path`, `is_unlocked`, `is_active`

The switcher-facing shape must not require:
- `price_efhc`
- `purchased_at`
- `buySkin(...)`
- `skin_purchase`

## 7. UI boundary

The future switcher screen must:
- live outside Hub;
- show only unlocked/locked progression skins;
- allow activation only for unlocked skins;
- show locked skins as progress targets, not as products.

The future switcher screen must not:
- show EFHC price;
- show TON/USDT price;
- trigger TonConnect;
- create orders;
- mix with EFHC/VIP Hub cards.

## 8. Storage boundary

Current storage can keep `efhc_core.user_cosmetics.active_skin_id` as the
active selection field.

Future implementation may keep legacy `user_skins` history during the
migration period, but switcher availability must be derived from progression
canon first.

## 9. Non-goals of cycle 91

Cycle 91 does not:
- remove `/skins/buy/{skin_id}`;
- rename backend schemas;
- remove `price_efhc` or `purchased_at`;
- implement the runtime screen;
- change OpenAPI;
- remove history-only legacy traces.

Those tasks belong to cycle 92 and later cleanup waves.

## 10. Result

The skin switcher concept is now closed as a separate SSOT layer:
- separate from Hub;
- separate from commerce domain;
- tied to the 12-level progression canon;
- centered on `available_skin_ids` and `active_skin_id` only.
