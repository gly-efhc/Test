# SSOT_INDEX (EFHC) — индекс источников истины

## NORM: Абсолютный запрет удаления из артефакта

- MUST NOT: ИИ или разработчик не имеет права удалять/исключать какие-либо файлы или каталоги из артефакта проекта (ZIP `EFHC_Bot_v*.zip`) без явного письменного разрешения пользователя.
- MUST: Любое изменение состава артефакта фиксируется в `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` (что удалено/добавлено и зачем).
- MUST: Артефакт обязан содержать SSOT-документацию и реестр ошибок; отсутствие ловится guard-проверкой якорей (`ops/canon_guard.py` + `ops/canon_rules.yaml`: `artifact_anchors.required_paths`).


Статус: NORM.

Цель: сделать проект самодостаточным по смыслу и правилам без
зависимости от чатов.

SSOT = single source of truth.

---

## Аудиты (архив PDF)

- Раздел: [`docs/audits/`](./audits/)
- Индекс: [`docs/audits/README.md`](./audits/README.md)

---


## NORM: Артефакт проекта и имя ZIP (CI-истина)

- Рекомендуемый workflow-файл (шаблон): `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml`.

- SSOT: Источником истины в CI является **архив проекта** — файл `efhc.zip` в корне репозитория.
- MUST: В корне репозитория должен находиться **ровно один** `efhc.zip`.
- NOTE: Версионные сборки ИИ имеют имя `EFHC_Bot_v*.zip`, но в репозиторий они кладутся переименованными в `efhc.zip`.
- MUST: CI распаковывает `efhc.zip` в `extracted/` и проверяет только его содержимое (backend/frontend/tests/ops/docs/реестр).

## 1. Правило приоритета

Если два документа или код противоречат друг другу, применяется
следующий порядок (от более сильного к более слабому):

1) Этот индекс (SSOT_INDEX).
2) NORM-документы.
3) Runtime-код (backend/app, ops, frontend) и тесты.
4) DERIVED-документы.

Если конфликт не разрешается, запрещено "угадывать". Нужно:
- зафиксировать конфликт в ADR (docs/GENERAL/ADR/)
- обновить NORM и/или код так, чтобы конфликт исчез

---

## 2. Список документов и статус

### 2.1 NORM (нормативные)

1) docs/SSOT/SSOT_INDEX.md
   - определяет приоритет и статусы документов

2) docs/SSOT/EFHC_CANON.md
   - канон продукта: tg_id, экономика, банк, транзакции, выводы,
   - БД и первичная миграция 0001: docs/SSOT/SSOT_DB_0001_CANON.md
     TON/memo, события, запреты

3) docs/SSOT/TERMS_GLOSSARY.md

- docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md (SSOT: Exchange/Withdraw)
   - каноничные термины и список запрещённых слов
   - включает next_cursor/encode_cursor/decode_cursor/CursorPage
   - единственное разрешённое место, где запрещённые слова могут
     встречаться в явном виде (как словарь)
   - это исключение фиксируется в ops/canon_rules.yaml


- docs/SSOT/PANELS_SSOT.md (SSOT: Panels)
   - каноничная модель панелей: global public_id
   - срок 180 дней (UTC), Active/Archive, idempotency, audit
   - server_now_utc для таймера
4) docs/NORM/ARCHITECTURAL_LOCKS.md
   - норматив для разработки: архитектурные ограничения и инварианты

5) backend/app/core/system_locks.py
6) docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md
   - канон интеграции Telegram WebApp: ready/theme/buttons
   - Telegram Theme Tokens (канон): --tg-* vars и маппинг
   - запрет CloudStorage для финансов/статусов, guard-требования
   - исполняемые инварианты системы (runtime locks)

7) docs/NORM/TESTS_CATALOG.md
   - каталог всех тестов проекта (общая нумерация, группы)
   - для каждого теста: описание в 3 строки
   - MUST: любой новый тест добавляется в этот документ

8) docs/SSOT/WALLETS_TONCONNECT_SSOT.md
   - канон привязки TON-кошельков к tg_id через TonConnect
   - WalletGate для deposit/shop external/withdraw
   - запрет CloudStorage для wallet state

9) docs/SSOT/FAQ_SSOT.md

- FAQ SSOT включает 20 канонических разделов верхнего
  уровня без подразделов и 16 правил содержания,
  точности и полноты.
   - минимальный FAQ-канон: 20 обязательных разделов
   - русский FAQ — первоисточник
   - удалять канонические разделы и темы вопросов нельзя

10) docs/NORM/TASKS_STANDARD.md
   - технический NORM-стандарт для `asyncio.create_task()`
   - запрещает тихую смерть фоновых задач
   - закрепляет единый helper и след исключений в логах

11) docs/SSOT/BANK_CANON.md
   - короткий NORM-канон банкового контура
   - фиксирует `BANK_EFHC`, направления проводок и границы
     `main_balance` / `bonus_balance`

12) docs/SSOT/DTO_INPUT_CANON.md
   - технический NORM-канон входящих DTO
   - фиксирует `StrictIn` / `extra="forbid"` для входных схем

### 2.2 DERIVED (производные)

1) docs/GENERAL/architecture.md
   - объяснения и примеры архитектуры
   - не вводит новых правил

2) docs/GENERAL/specification.md
   - примеры API/поведения
   - не вводит новых правил

3) docs/API_REFERENCE.md
   - гид по API
   - не вводит новых правил

4) docs/GENERAL/DB_SCHEMA.md
   - обзор схемы
   - не вводит новых правил

Другие документы без явной пометки статуса считаются DERIVED.

---

## 3. Якоря смысла

- Канон идентификатора пользователя: docs/SSOT/EFHC_CANON.md
- Термины и запретные слова: docs/SSOT/TERMS_GLOSSARY.md
- Канон FAQ: docs/SSOT/FAQ_SSOT.md

- docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md (SSOT: Exchange/Withdraw)
- Архитектурные ограничения разработки: docs/NORM/ARCHITECTURAL_LOCKS.md
- Исполняемые инварианты runtime: backend/app/core/system_locks.py
- Telegram WebApp theme tokens:
  docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md

---

## 4. Правило изменений

- Любая новая норма добавляется только в NORM-документ.
- DERIVED-документы могут содержать только пояснения и примеры.
- Любая правка NORM должна сопровождаться обновлением guard/тестов,
  если они должны это фиксировать.

- **FULL‑ARTIFACT GUARD (MUST):** артефакт efhc.zip обязан содержать `docs/` и `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`; это проверяется тестом (удалённый тест артефакта).

## NORM: Общие логи изменений (reports/)

- MUST: Все подробные отчёты циклов хранятся в `reports/`.
- MUST: Каждый цикл создаёт новый отчёт в `reports/`.
- MUST: `reports/REPORTS_INDEX.md` ведётся как нумерованный
  реестр `append-only`.
- MUST: Все записи в `reports/` добавляются строго по порядку,
  без пропусков номера в индексе.
- MUST: Имя файла цикла:
  `change_cycle_YYYY-MM-DD_HHMM_vNNN_XX_slug.md`.

## Канон сборки efhc.zip (clean → guard → zip)

- Скрипт сборки: `ops/build_efhc_zip.sh` (запуск из корня репозитория).
- Порядок: clean → `python ops/canon_guard.py` → сборка FLAT `efhc.zip` → post-pack проверки.
## SSOT Audit Pack

Канонический пакет артефактов аудита: `docs/SSOT/ssot_pack/README.md`.

- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv` — свод: маршрут → таблицы → миграция(0001) (детерминированный контроль согласованности).

- `docs/SSOT/ssot_pack/SSOT_TABLES_SCHEMAS_DESCRIPTION_RU.md` — описание SSOT по схемам/таблицам (RU)
- `docs/SSOT/ssot_pack/SSOT_ROUTES_DESCRIPTION_RU.md` — описание
  SSOT по маршрутам (RU)
- `docs/SSOT/ssot_pack/SSOT_TABLES_PURPOSE_RU.md` — назначение
  таблиц (RU)
- docs/audits/2026-03-01_audit_migrations_timestampmixin_ru.md — аудит поломок миграций из-за TimestampMixin (RU)


## Overview docs sync (MUST)

- Обзорные документы обязаны совпадать с `docs/SSOT/ssot_pack/*`.
- `docs/NORM/TESTS_CATALOG.md` обязан совпадать с реальным `tests/**`.
- Для быстрого аудита использовать `docs/OVERVIEW_SSOT_SYNC.md` и
  `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md`.

- `docs/SSOT/faq_ssot/ru/faq_ru.md` — нормативный русский FAQ SSOT.
- `docs/SSOT/faq_ssot/ru/faq_ru.json` — машинно-читаемый русский FAQ SSOT.


## Healer

- `atlas.json`
- `casebook.json`
- `HEALER_ATLAS.md`
- `docs/healer/README.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `reports/REPORTS_INDEX.md`

Новые болезни и лечения цикла фиксируются во все три места:
Healer, `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` и `reports/`.

- `docs/GENERAL/DOCKER_LOCAL.md` — локальный Docker-стенд.

- `docs/AI/CONTINUE_NEW_CHAT_V157_PROMPT.md` — каноничный промт продолжения для нового чата и серии `v157_`.

- `docs/NORM/MIGRATION_INVARIANTS_HARDENING.md` — NORM hardening-документ migration-layer с подтверждёнными инвариантами текущего HEAD.

- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` — NORM continuity register of user decisions and agreed interpretations for active work cycles.

- `docs/NORM/RANKS_RULES.md` — NORM rules for rank display, rank basis and ranks snapshot surface.

- `docs/NORM/REFERRALS_RULES.md` — NORM rules for referral bonus canon and permanent active-referral rule.

- `docs/NORM/ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md` — NORM operational playbook for audits of route → table → migration linkage.

- 2026-04-01: Reorg rule — active documents are organized under `docs/SSOT/`, `docs/NORM/`, `docs/GENERAL/`, `docs/AI/`; all inventory and audit documents of any form must live under `docs/audits/`.

- `docs/SSOT/ROUTE_RESPONSE_ERROR_CANON.md`
- `docs/NORM/SECURITY_EXCEPTIONS_REGISTER.md`
- docs/SSOT/BANK_CANON.md
- docs/SSOT/DTO_INPUT_CANON.md
- docs/SSOT/ENERGY_RULES.md
- docs/SSOT/ROUTE_RESPONSE_ERROR_CANON.md
- docs/SSOT/TERMS_GLOSSARY.md
- docs/SSOT/TON_MEMO_SPEC.md
- docs/SSOT/USER_FACING_WORDING_CANON.md
- docs/SSOT/SYSTEM_LOCK_TG_ID.md
- docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md
- docs/SSOT/DOCUMENT_LAYER_CANON.md