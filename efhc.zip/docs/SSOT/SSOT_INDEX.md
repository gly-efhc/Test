<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
# SSOT INDEX

Статус: **CANONICAL INDEX / ACTIVE**

## Приоритет

1. Последнее явное решение пользователя.
2. `docs/SSOT/EFHC_CANON.md`.
3. Профильный SSOT из этого индекса.
4. Действующие документы `docs/NORM/`.
5. Код и machine guards.
6. `reports/numbered/` и внешний artifacts history ZIP — только history/evidence, не active authority.

## Identity

- `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`;
- `docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md`;
- `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`;
- `docs/SSOT/IDENTITY_GLOSSARY.md`;
- `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.

## Документальный слой

- `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`;
- `docs/SSOT/DOCUMENT_LAYER_CANON.md`;
- `docs/SSOT/PROJECT_GLOSSARY.md`.

## Schema

- `docs/SSOT/SSOT_DB_0001_CANON.md`;
- `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md`;
- единственная migration: `0001_initial_release_schema.py`.

## Продукт

- `docs/SSOT/ECONOMY_CANON.md`;
- `docs/SSOT/BANK_CANON.md`;
- `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`;
- `docs/SSOT/PANELS_SSOT.md`;
- `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`;
- `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`;
- `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md`;
- `docs/SSOT/HUB_SSOT.md`.

## AI archive laws

- `docs/AI/AI_ARCHIVE_LAWS.md`;
- `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`;
- `docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md`.
