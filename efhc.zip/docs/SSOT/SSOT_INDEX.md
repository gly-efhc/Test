# ТЕКУЩИЙ SSOT INDEX POINTER — v175.22 / цикл 1854 завершён

- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`; TR/PL часть `1854` завершена.
- FAQ SSOT/runtime parity обновлена только для `20` screen-name/UI-label позиций TR/PL.
- CI `90332278146` не exact-head для входного `v175.21`; fresh qualification требуется для `v175.22`.
- Текущий report `02442`; следующий `02443`; следующий цикл `1855` только по OWNER-команде.

> Предыдущий верхний блок ниже сохраняется как historical evidence и не переопределяет текущий указатель.

---

# ТЕКУЩИЙ SSOT INDEX POINTER — v175.21 / цикл 1854, qualification repair

- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`; TR/PL часть `1854` остаётся pending.
- Exact-head CI `90332278146` для `v175.20`: два pytest RED исправлены без изменения active forbidden-word CANON.
- Текущий report `02441`; следующий `02442`; candidate `v175.21` требует fresh exact-head CI.

> Исторические snapshots индекса ниже не переопределяют этот current pointer.

---

# ТЕКУЩИЙ SSOT INDEX POINTER — v175.20 / цикл 1853

- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`.
- Exact-head CI `90313326320`: четыре blacklist-reconciliation RED исправлены без отката current CANON.
- ES/IT screen-name reconciliation завершена; report `02440`; следующий цикл `1854` только по OWNER-сообщению.

> Исторические snapshots индекса ниже не переопределяют этот current pointer.

---

# ТЕКУЩИЙ SSOT INDEX POINTER — v175.19 / цикл 1852

- Active plan: `docs/PLANS/WORK_PLAN_1849-1884_MULTILINGUAL_CERTIFICATION.md`.
- Маршрутизация forbidden-word пересмотрена: semantic ban / public UI wording / architecture CANON / source-quality guards являются раздельными authority.
- Report `02439`; следующий цикл `1853` только по прямому сообщению OWNER.

> Исторические snapshots индекса ниже не переопределяют этот текущий указатель.

---

# ТЕКУЩИЙ SSOT INDEX — v175.18 / цикл 1851

- Physical input: `EFHC_Bot_v175_17.zip` / `e1a79a388d997f869360291cad50c850f09e3dcec83a590927fdd5311036b1df`.
- Exact-head CI `90304130073`: полностью GREEN; pytest `1790 passed / 22 skipped / 1 warning`, Ruff PASS, Gate summary PASS.
- Текущий immutable report: `02438`; следующий `02439`.
- Active plan: цикл `1851` выполнен; следующий плановый `1852`, только по OWNER-сообщению; остаётся `32` цикла `1852–1883`.
- FAQ SSOT: `16 × 20 × 230`; цикл `1851` — `20` DE/FR screen-name/navigation позиций; новых Q&A нет.
- Frontend source-lock `8b8ff7fbfb3b8725c785dae129f95bdc2a43dc1a36d7342000c0c5e495611a3a`; PWA `efhc-d7603ead642687b8`; assets `35`.
- Active Short Operator CANON: `docs/SSOT/OWNER_PRIORITY_AND_SHORT_OPERATOR_CANON.md`.
- `blacklist_tz.md` в этот release не внедрялся; его document+machine-guard reconciliation остаётся отдельным scope.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ SSOT INDEX — v175.17 / цикл 1850

- Physical input: `EFHC_Bot_v175_16.zip` / `3efdc5cf854da28afb8d5707db05937500ab3735206362e70e0dbb8293fbfab4`.
- Exact-head CI `90300463463`: pytest `1 failed / 1789 passed / 22 skipped / 1 warning`; единственный RED в `EFHC_OPERATOR_KERNEL_SSOT.md:493–497` исправлен точечно. Ruff и остальные зафиксированные non-pytest gates exit `0`.
- Текущий immutable report: `02437`; следующий `02438`.
- Active plan: цикл `1850` выполнен; следующий плановый `1851`, только по OWNER-сообщению; остаётся `33` цикла `1851–1883`.
- FAQ SSOT: `16 × 20 × 230`; цикл `1850` — `26` RU/EN/UK screen-name/navigation позиций; новых Q&A нет.
- Frontend source-lock `73ac1a9278a423eb4196bff6d434c2e75fd2192fd830107ffaf057b3178d3144`; PWA `efhc-9a6e6e4eee2b5298`; assets `35`.
- Active Short Operator CANON: `docs/SSOT/OWNER_PRIORITY_AND_SHORT_OPERATOR_CANON.md`.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1847, продолжение / v175.09

- FAQ `16/16 × 20 × 230`; ceiling `250`; `FAQ-APPROVAL-0038`.
- `6-15`, `7-6`, `10-2`, `12-2`, `12-13` закрыты OWNER-решениями и синхронизированы по соответствующим approval.
- Exact-head CI `90177840427`: pytest завершён без зависания; подтверждён EN public-copy defect и один Ruff `I001`, оба исправлены в candidate `v175.09`.
- Следующий план: `1848–1851` — ручная языковая сертификация и остаточный semantic drift.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1847, продолжение

- FAQ `16/16 × 20 × 230`; ceiling `250`.
- `FAQ-APPROVAL-0037`: `12-2/12-13` утверждены OWNER и синхронно применены во всех языках.
- `6-15`, `7-6`, `10-2` остаются OWNER-review.
- Exact-head CI `90173501468` подтвердил устранение pytest hang; текущий RED ограничен Ruff `3 × I001`.
- Следующий план: `1848–1851` по ручной языковой сертификации и остаточному semantic drift.

> Исторические snapshots ниже являются evidence и не переопределяют текущий блок.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1847

- FAQ: `16/16 × 20 × 230`; `FAQ-APPROVAL-0036`; новых Q&A нет.
- `6-15`, `7-6`, `10-2`, `12-2`, `12-13` — DRAFT OWNER-review, без runtime rewrite.
- Exact-head CI `90168142245` для `v175.06` неполный; `v175.07` требует следующего CI.
- План языковой сертификации продолжен циклами `1848–1851`.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1846, волна 2

## ТЕКУЩИЙ POINTER — v175.06 / cycle 1846

- Последнее exact-head GREEN evidence — `v175.00 / CI 90038758717`; `v175.06` является candidate до следующего exact-head CI.
- FAQ: `16/16`, `20` разделов, `230/250` Q&A, approval `FAQ-APPROVAL-0035`; новых Q&A нет.
- Ручная межъязыковая сверка wave 2 исправила `74` подтверждённых non-RU позиций; RU semantic source и protected progression series не изменены.
- Cycle `1847` — финальная ручная языковая сверка, literals/numeric/security/financial reconciliation и review RU-source exceptions.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1846

## ТЕКУЩИЙ POINTER — v175.05 / cycle 1846

- Последнее exact-head GREEN evidence — `v175.00 / CI 90038758717`; `v175.05` является candidate до следующего exact-head CI.
- FAQ: `16/16`, `20` разделов, `230/250` Q&A, approval `FAQ-APPROVAL-0034`; новых Q&A нет.
- `N93–N97` отклонены OWNER.
- Ручная межъязыковая reconciliation wave 1 выполнена по доказанным drift-позициям; RU semantic source и protected progression series не изменены.
- Cycle `1847` — оставшаяся ручная сверка и final reconciliation.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1845

## ТЕКУЩИЙ POINTER — v175.04 / cycle 1845

- Последнее exact-head GREEN evidence — `v175.00 / CI 90038758717`; новый `v175.04` является candidate до следующего exact-head CI.
- FAQ: `16/16` SSOT/runtime языков, `20` разделов, `230/250` Q&A, approval `FAQ-APPROVAL-0033`; protected `18` progression Q&A сохранены.
- `N83–N86` утверждены и реализованы во всех языках; `N87–N92` отклонены OWNER.
- `N93–N97` являются DRAFT-кандидатами для OWNER-review; они могут быть добавлены в пределах свободных слотов до потолка `250` только после отдельного утверждения OWNER.

---

# ТЕКУЩИЙ OWNER-КАНОН FAQ — цикл 1843

## ТЕКУЩИЙ POINTER — v175.02 / cycle 1843

- Последнее exact-head GREEN evidence — `v175.00 / CI 90038758717`; новый `v175.02` является candidate до следующего exact-head CI.
- FAQ: `16/16` SSOT/runtime языков, `20` разделов, `223/250` Q&A, approval `FAQ-APPROVAL-0031`; protected `18` progression Q&A сохранены.
- `N69` утверждён и реализован во всех языках; `N65–N68` и `N70–N72` отклонены OWNER.
- `N73–N82` являются только DRAFT для OWNER-review и не входят в FAQ без отдельного утверждения.

---

# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ/FAQ — цикл 1838

## ТЕКУЩИЙ POINTER — v174.98 / cycle 1838

Application localization, FAQ runtime и FAQ SSOT остаются `16/16`; FAQ содержит `20` разделов и `206` Q&A на язык при лимите `250`. Cycle `1838` не меняет FAQ catalogs: `N39–N53` являются только DRAFT OWNER-review. `N1–N53` не интегрируются без явного OWNER approval; после approval любая вставка выполняется параллельно во всех `16` SSOT/runtime языках. Protected 12 Energy + 6 Referral Q&A остаются обязательным каноном.

---

# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ/FAQ — цикл 1837

## ТЕКУЩИЙ POINTER — v174.97 / cycle 1837

Application localization, FAQ runtime и FAQ SSOT остаются физически полными `16/16`; FAQ содержит `20` разделов и `206/250` Q&A на язык. Exact-head CI `89999164826` полностью GREEN для физического `v174.96`. Новые `N1–N31` и `N34–N38` остаются DRAFT; `N32/N33` не интегрируются автоматически из-за перекрытия protected progression series. Protected 12 Energy + 6 Referral Q&A остаются обязательным каноном.

---

# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ/FAQ — цикл 1836

## ТЕКУЩИЙ POINTER — v174.96 / cycle 1836

Application localization, FAQ runtime и FAQ SSOT остаются физически полными `16/16`; FAQ содержит `20` разделов и фактически `206/250` Q&A на язык. Protected level-series authority: `docs/SSOT/faq_ssot/RU_FAQ_LEVEL_SERIES_CANON.md`. 12 Energy statuses и 6 referral statuses нельзя удалять, объединять или использовать как replacement pool; допускается только улучшение описаний с сохранением уровней/порогов и параллельной 16-языковой синхронизацией. Новые Q&A `N1–N38` не утверждены.

---

# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ — цикл 1834

## ТЕКУЩИЙ POINTER — v174.94 / cycle 1834

Application localization, FAQ runtime и FAQ SSOT остаются физически полными `16/16`. Cycle `1834` не меняет FAQ text: подготовлены OWNER-review lists `43` duplicate deletions и `38` новых Q&A; применение разрешено только после явного OWNER approval и затем синхронно во всех `16` языках. FAQ-план продлён до cycle `1847`.

---

# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ — цикл 1829

## ТЕКУЩИЙ POINTER — v174.92 / cycle 1832

Текущий language/FAQ authority: application `16/16`, FAQ runtime `16/16`, FAQ SSOT `16/16`; cycle `1832` завершил Japanese reconciliation без text delta. Exact-head GREEN evidence входного HEAD — CI `89879947424`; immutable report — `reports/numbered/reports_02411__cycle_1832_ci_89879947424_japanese_faq_reconciliation.md`.


- Application runtime localization = `16/16`: `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
- FAQ application + FAQ SSOT = тот же физический набор `16/16`, каждый имеет ровно `20` разделов и максимум `250` Q&A; после цикла `1835` фактически `206` Q&A`; language-key/placeholder/registry guards обязаны охватывать все `16`.
- FAQ fallback не считается полноценным каталогом поддерживаемого языка. `TODO/FIXME/TBD` document scan запрещён; unfinished-marker policy относится только к shipping code, Portuguese `todo` в документах допустимо.
- Исторические `13/14` counts ниже сохраняются только как evidence.

## ACTIVE ADDITIONS — v174.61 / cycle 1801

- `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md` — direct OWNER contract ручной protective Panel lifecycle.
- `docs/frontend/EFHC_FRONTEND_OWNER_QA_v182.md` — consolidated FRONTEND_v182 owner Q&A evidence/authority, subject to later direct owner decisions.
- `docs/frontend/FRONTEND_v182_BACKEND_RECONCILIATION_HANDOFF.md` — обязательный handoff для следующего frontend archive.
- `docs/SSOT/PANELS_SSOT.md`, `BANK_CANON.md`, `ECONOMY_CANON.md` — current runtime interpretation.
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` — append-only latest owner decisions.

- `docs/NORM/BANK_METRICS_INTEGER_SNAPSHOT.md` — ACTIVE CANON/NORM: полный формульный authority Admin → Банк / integer snapshot / 53-table schema exception.
<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
# SSOT INDEX

Статус: **CANONICAL INDEX / ACTIVE**

## Приоритет

1. Последнее явное решение пользователя.
2. `docs/SSOT/EFHC_CANON.md`.
3. Профильный SSOT из этого индекса.
4. Действующие документы `docs/NORM/`.
5. Код и machine guards.
6. `reports/numbered/` и внешний artifacts history ZIP — только history/evidence, не active authority.

## Identity

- `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`;
- `docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md`;
- `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`;
- `docs/SSOT/IDENTITY_GLOSSARY.md`;
- `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.

## Документальный слой

- `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`;
- `docs/SSOT/DOCUMENT_LAYER_CANON.md`;
- `docs/SSOT/PROJECT_GLOSSARY.md`.

## Терминология и user-facing wording

- `docs/SSOT/FORBIDDEN_WORDS_AND_EXCEPTIONS_SSOT.md` —
  только `PERMANENT_SEMANTIC_BAN` и policy routing;
- `docs/SSOT/USER_FACING_WORDING_CANON.md` —
  `PUBLIC_UI_COPY_RESTRICTION`;
- `docs/SSOT/FAQ_SSOT.md` —
  authority пользовательских формулировок и approval для FAQ;
- `docs/NORM/PUBLIC_ERROR_STATE_CANON.md` —
  безопасная граница public error/technical text;
- `docs/NORM/PUBLIC_ERROR_MESSAGE_CANON.md` —
  формулировки public error;
- `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md` —
  authority source-quality и Anti-Stale test-layer.

Имена identity/provider, generation literals и другие runtime-identifiers
не регулируются forbidden-word SSOT. Они относятся к своим профильным
architecture SSOT/CANON.

## Schema

- `docs/SSOT/SSOT_DB_0001_CANON.md`;
- `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md`;
- единственная migration: `0001_initial_release_schema.py`.

## Продукт

- `docs/SSOT/ECONOMY_CANON.md`;
- `docs/SSOT/FINANCIAL_TOPOLOGY_SSOT.md`;
- `docs/SSOT/FINANCIAL_TOPOLOGY_LOCK.json` — machine projection, не независимый SSOT;
- `docs/SSOT/BANK_CANON.md`;
- `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`;
- `docs/SSOT/PANELS_SSOT.md`;
- `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`;
- `docs/SSOT/WALLETS_TONCONNECT_SSOT.md`;
- `docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md`;
- `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`;
- `docs/SSOT/HUB_SSOT.md`.
- `docs/SSOT/AUTONOMOUS_DEVOPS_SSOT.md` — CANON производственного мониторинга, безопасного автоматического восстановления, локального шифрованного резервного копирования, OWNER-экспорта по SSH/SFTP и диагностики.
- `docs/backend/ADS_MEDIATION_CANON.md` — CANON AdManager, вознаграждаемой рекламы, посредничества провайдеров, подтверждения награды и аналитики.

## Безопасность и авторизация Admin

- `docs/NORM/ADMIN_RBAC.md`;
- `docs/security/ADMIN_ROUTE_GUARD_CANON.md`;
- `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`;
- `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`;
- `docs/SSOT/BANK_CANON.md`.

## Authority слияния frontend

- `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md`;
- `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`;
- `docs/frontend/FRONTEND_FUNCTION_UNION_MAP.json`;
- `docs/frontend/FRONTEND_POST_MERGE_ALLOWED_CHANGES.json`.

Правило: утверждённый frontend patch имеет приоритет для visual/UX/user-facing text; backend/CANON — для API, data, security, identity, economy и business semantics. CI guard не может самовольно восстановить старый Bot UI поверх утверждённого patch.

## Законы AI archive

- `docs/AI/AI_ARCHIVE_LAWS.md`;
- `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`;
- `docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md`.
- `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md` — OWNER-правила повторной верификации финального ответа/артефакта и трассируемости инцидентов.
- `docs/backend/RUNTIME_COMPATIBILITY_CANON.md` — runtime compatibility/import facade canon и delete-policy.

## Testing / qualification

- `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md` — authority и anti-stale policy активного test-layer; тест не является SSOT.
- `docs/NORM/TESTS_CATALOG.md` — каталог активного test-layer.
- `docs/testing/TEST_GUARD_MANIFEST.json` — machine/evidence projection, не самостоятельный продуктовый SSOT.


## Текущий аудит русского FAQ — cycle 1833

- `docs/SSOT/faq_ssot/RU_FAQ_AUDIT.md` — полный current-app drift/gap audit русского FAQ.
- `docs/SSOT/faq_ssot/RU_FAQ_OWNER_REPLACEMENT_QUEUE.md` — OWNER-review очередь дублей/замен; удаление без OWNER approval запрещено.

## ТЕКУЩИЙ FAQ-УКАЗАТЕЛЬ — цикл 1839

- OWNER-коррекция: исправленные предложения FAQ требуют повторного утверждения до любого изменения SSOT/runtime.
- Текущий FAQ остаётся `16 × 20 × 206`; документ `RU_FAQ_NEW_QA_PROPOSALS.md` хранит статусы отклонения, повторного review и DRAFT до `N57`.
- Неизменяемый отчёт: `reports/numbered/reports_02418__cycle_1839_faq_owner_review_correction_and_application_audit.md`.

