<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# SSOT: Panels

## 0) Канон и замки (MUST)

1) Истина проекта — SSOT/канон.

2) Идентификатор пользователя — только `global_id` (snake_case).

3) Запрещённые токены/подстроки из канона проекта нельзя
   использовать ни в коде, ни в документах, ни в примерах.
   В документации описываем запреты смыслом, без буквального
   написания запрещённых токенов.

4) Никаких новых алиасов/дублирующих эндпоинтов вне канонического API.

5) Числа/балансы: `Decimal(scale=8)`, округление **DOWN**,
   без scientific notation.

6) `Idempotency-Key` обязателен для операций создания панели
   (активация) и любых повторяемых операций.

7) Аудит обязателен: попытка/результат,
   включая replay по идемпотентности.

8) Экономические замки проекта сохраняются:
   lifetime-счётчики не уменьшаются; зеркальные расчёты
   обменника не затрагиваются этим SSOT.

---

## 1) Цель

Сделать вкладку **Panels** каноничной и завершённой:

- Пользователь видит описание механики панелей.
- Пользователь может активировать панель — идемпотентно.
  на Panels (в нижней навигации отдельного пункта нет).
- Есть переключатель **Active / Archive** (Variant A),
  который показывает один список ниже.
- Каждая панель — отдельная запись, привязана к `global_id`,
  имеет глобальный `public_id` формата `ID########`, даты
  `activated_at`, `expires_at`, статус и таймер “Осталось”.
- Срок жизни панели: **180 дней** от `activated_at` в UTC.
- UI таймер “Осталось” синхронизирован с `server_now_utc`.

---

## 2) SSOT-модель панелей (логика и время)

### 2.1 Дата активации и срок

- Дата активации панели фиксируется в `activated_at`.
- `expires_at = activated_at + 180 days` (UTC).
- Панель активна, если: `server_now_utc < expires_at`.
- Панель архивная, если: `server_now_utc >= expires_at`.

### 2.2 Таймер “Осталось”

Только UI.

**MUST:** UI не использует локальные часы устройства как истину времени.

**MUST:** `server_now_utc` (или `server_now_iso`) —
обязательная опорная точка; локальные часы используются
только как секундомер.

Формула:

- `remaining_seconds = max(0, expires_at - now_utc)`
- `now_utc = server_now_utc + (client_now - client_received_at)`

UI формат:

- `Осталось: {days}д {hours}ч {mins}м`

### 2.3 Глобальный ID панелей

ID панелей нумеруются глобально по всему боту и всем пользователям.

Используется DB sequence / auto-increment (BIGSERIAL).

Публичный ID:

- `public_id = "ID" + zfill(id, 8)`

Пример:

- `ID00000001`

Примечание: sequence может иметь пропуски при rollback/crash.
Это нормально. Требование “не создать новую панель при повторе
одного запроса” обеспечивается идемпотентностью активации.

---

## 3) База данных: схема и миграции (Alembic)

### 3.1 Таблица `panels` (новая или приведение существующей)

`panels`

- `id BIGSERIAL PRIMARY KEY` — глобальный автоинкремент
  (источник для `public_id`)
- `global_id BIGINT NOT NULL` — владелец панели
- `public_id TEXT UNIQUE` — глобальный публичный ID
  (до заполнения допускается NULL)
- `activated_at TIMESTAMPTZ NOT NULL DEFAULT now()` — UTC
- `expires_at TIMESTAMPTZ NOT NULL` —
  `activated_at + interval '180 days'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Индексы:

- `CREATE INDEX panels_global_id_idx ON panels (global_id);`

CHECK (Postgres):

- `expires_at > activated_at`

### 3.2 Идемпотентность активации панели (техническая таблица)

Если в проекте уже есть общий механизм хранения
идемпотентности — использовать его.

Если нет — добавить техническую таблицу:

`panel_issuance`

- `id BIGSERIAL PRIMARY KEY`
- `global_id BIGINT NOT NULL`
- `idempotency_key TEXT NOT NULL`
- `panel_id BIGINT NOT NULL REFERENCES panels(id)`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Constraints:

- `UNIQUE (global_id, idempotency_key)`
- (опционально) `UNIQUE (panel_id)`

Индекс:

- `INDEX panel_issuance_global_id_idx (global_id)`

### 3.3 Миграции Alembic (план)

Migration A: `create_panels_table`

- create table `panels`
- add index `panels_global_id_idx`
- add UNIQUE на `public_id`
- add CHECK `expires_at > activated_at`

Migration B: `create_panel_issuance_table`

- create table `panel_issuance`
- add UNIQUE `(global_id, idempotency_key)`
- add FK to `panels(id)`

### 3.4 Генерация `public_id`

**Канон:** `public_id` при INSERT должен быть **NULL**,
а заполняется сразу после получения `id` в той же транзакции.

В схеме: `public_id TEXT UNIQUE` и разрешить NULL до заполнения
(Postgres допускает множественные NULL в UNIQUE).

Алгоритм:

1) INSERT и получение id:

```sql
INSERT INTO panels(
  global_id, public_id, activated_at, expires_at
) VALUES (
  :global_id, NULL, :activated_at, :expires_at
) RETURNING id;
```

2) `public_id = "ID" + zfill(id, 8)`

3) Обновление public_id:

```sql
UPDATE panels SET public_id = :public_id WHERE id = :id;
```

---

## 4) Backend: сервис генерации панелей (SSOT)

### 4.1 Контракт сервиса (MUST)

`create_panel_for_user(global_id: int, idempotency_key: str) -> PanelDTO`

Требования:

- атомарно (транзакция)
- idempotent replay: повтор возвращает тот же `panel_id/public_id`
- пишет аудит attempt/result

### 4.2 Create — алгоритм (строго)

**MUST (Idempotency invariants):**

- Один `(global_id, Idempotency-Key)` всегда возвращает
  одну и ту же панель: `panel_id` и `public_id` неизменны.
- При replay сервис не создаёт новую запись `panels` и
  не берёт новый sequence `id`.
- Audit фиксирует `status="replay"`.

В одной транзакции:

1) Replay check:

```sql
SELECT panel_id
FROM panel_issuance
WHERE global_id = :global_id
  AND idempotency_key = :key;
```

- если найдено → вернуть панель (replay)

2) Create panel:

- `activated_at = now_utc()`
- `expires_at = activated_at + 180 days`
- INSERT/UPDATE public_id выполняется по канону раздела 3.4.

3) Bind idempotency:

```sql
INSERT INTO panel_issuance(
  global_id, idempotency_key, panel_id
) VALUES (
  :global_id, :key, :panel_id
);
```

4) Audit (см. раздел 6)

5) Commit и вернуть DTO.

### 4.3 Сервис выборки списков

`list_user_panels(
  global_id, kind: "active"|"archive", limit, cursor,
  server_now_utc
) -> list[PanelDTO]`

Фильтры должны зависеть только от `:server_now_utc` (без `now()` БД):

- Active: `expires_at > :server_now_utc`
- Archive: `expires_at <= :server_now_utc`

Причина: одинаковое поведение в Postgres/SQLite и отсутствие дрейфа.

Сортировка:

- `activated_at DESC` (или `id DESC` — допускается)

---

## 5) API (без алиасов)

### 5.1 Страница Panels должна получать

- список Active или Archive панелей (по переключателю)
- `server_now_utc` (как часть снапшота или отдельного ответа)

Если в проекте уже есть snapshot с
`server_now_iso`/`server_now_utc` — использовать его.

### 5.2 Операция активации панели

Если каноничный endpoint активации панелей уже существует —
использовать **только его**.

Если его нет — допускается добавить ровно один каноничный endpoint:

- `POST /panels/activate/{global_id}` — каноничная операция активации панели; `POST /panels/buy/{global_id}` сохранён как compat path

Headers:

- `Idempotency-Key: <uuid>`

Body:

- пустой (активация = 1 панель)

Response:

- созданная панель (PanelDTO)
- `server_now_utc`

**MUST NOT:** любые вторые маршруты,
альтернативные endpoints или алиасы активации панели.

---

## 6) Аудит (MUST)

### 6.1 PANEL_CREATE audit extra_info

Пишется всегда: `success`, `replay`, `error`.

Поля:

- `audit__schema__version: "v1"`
- `global_id`
- `op_type: "PANEL_CREATE"`
- `idempotency_key`
- `panel_id`
- `panel_public_id`
- `activated_at`
- `expires_at`
- `status: success | replay | error`
- `reason` (для error)

---

## 7) UI: структура страницы Panels (строго)

### 7.1 Верхний блок “Описание”

- краткий текст о панелях и генерации
- для активации панели необходимо 100 EFHC
- без лишних обещаний

### 7.2 Блок действий

Кнопки 2×2:

1) Активация панели

2) Призовой контур (историческая запись удалённого перехода)

3) Active

4) Archive

Active/Archive управляют одним списком ниже.

### 7.3 Список панелей (один, переключаемый)

Карточка панели (MUST):

- `public_id` (пример: `ID00000001`)
- `activated_at` (формат до минут)
- `expires_at` (формат до минут)
- `Осталось: 179д 23ч 59м` (для Active; для Archive
  можно не показывать или `0д 0ч 0м`)
- Статус: Active/Archive по `server_now_utc < expires_at`
- Описание: коротко

Формат дат:

- `DD.MM.YYYY HH:MM (UTC)` без секунд.

---

## 8) Тесты (pytest + статические guards)

### 8.1 Backend tests (MUST)

1) Idempotency create panel:

- два вызова активации/создания с одним ключом → одна и
  та же панель (`panel_id`, `public_id` одинаковы)

2) Global ID ordering:

- создать панель для `global_id` A, затем для `global_id` B →
  `id` глобально растёт; `public_id` различны и корректны

3) 180 days:

- `expires_at - activated_at == 180 days` (UTC)

4) Active/Archive classification:

- если `server_now_utc < expires_at` → Active
- иначе Archive

### 8.2 Static guard tests (SHOULD)

- запрет локального ручного форматирования чисел/дат
  в Panels UI при наличии общего форматтера.

---

## 9) Definition of Done

Готово, если:

1) В БД есть таблица `panels` с глобальным auto-increment и
   `public_id` формата `ID########` (уникальная по всему боту).

2) Активация панели идемпотентна: повтор не создаёт
   новую панель и возвращает ту же.

3) У панели есть `activated_at` и
   `expires_at = activated_at + 180 days` (UTC).

4) UI Panels показывает: описание + кнопки (Активация панели,
   переключатель Active/Archive, один список
   ниже, карточки с ID/датами до минут, “Осталось”, статус.

5) Таймер “Осталось” синхронизирован с `server_now_utc`.

6) Тесты PASS: idempotency, global id, 180 days, active/archive.

7) Канон запретов соблюдён: нет запрещённых токенов,
   нет неканоничных идентификаторов; нет алиасов.

## Approval absorption note

- Consolidated user-approved panels package is no longer maintained as a standalone active document.
- The active canon now absorbs approved panel activation wording, compatibility boundaries, FAQ-linked panel wording and admin-facing panel semantics through current SSOT/canon documents and runtime sources.
- Historical approval package traces belong to archive history and should not override this SSOT.

## Compatibility route and event freeze

- Canonical route for panel activation is `POST /panels/activate/{global_id}`.
- Compatibility route `POST /panels/buy/{global_id}` remains a technical compatibility surface until a future sunset wave has proof that external clients no longer depend on it.
- Frontend must use only the canonical activation route.
- Technical event names may still keep the old buy-form as compatibility names, but their meaning is panel activation.
- Historical standalone notes about route/OpenAPI sync, compat freeze and draft bot-help/UI wording are no longer active source-of-truth once absorbed here and in внешнем `ARTIFACTS_HISTORY` ZIP (historical cycle evidence).

## 12) Admin Panel economics and protective control — owner law v170

This section supersedes the v168 Admin-only 180-day-completed analytics rule. User Panel lifecycle remains 180 days; this section defines owner Admin analytics/control.

### 12.1 Owner-visible analytics
- Canonical acquisition price is exactly `100.00000000 EFHC`.
- `Новые обязательства` uses actual stored `generated_kwh` for all deactivated **economic** Panels, regardless of why they became inactive.
- A Panel that is protectively voided under 12.3 is not an economic deactivated Panel and is excluded.
- Whole-application exact-D8 formula: `SUM(deactivated_economic.generated_kwh) - 100.00000000 * COUNT(deactivated_economic)`.
- Production MUST consume a server whole-application D8 aggregate. It MUST NOT sum the currently loaded/capped Admin Panels list.
- Top KPI order is fixed by owner v170: Active; Completed/deactivated economic; New obligations; net spent EFHCm+EFHCb; converted kWh→EFHCm; total generated kWh.
- Panel spend derives from real ledger entries (acquisition plus the OWNER-2026-10-21 new protective-settlement debits); historical backdated refunds are forbidden.
- Exchange remains an independent all-time successful `kWh → EFHCm` fact; it is not subtracted from New obligations as a remaining-liability calculation.

### 12.2 Admin search/card placement
- Search input accepts 10-digit Global ID or Panel ID/public ID.
- Global ID returns all that user's Panels; Panel ID returns one concrete Panel.
- Results reuse the real Panel-card family and add Admin `Деактивировать` only for active Panels.
- Permanent Panel registry is not part of the owner-visible analytics page; full logs remain CSV/XLSX export.

### 12.3 Protective manual deactivation — OWNER amendment 2026-10-21

**New direct OWNER decision supersedes the earlier variant A historical
purchase-split refund and `NET=100-R`.** Protective deactivation is a
new real financial reversal/settlement of **100.00000000 EFHC**, never a
retroactive edit of the original purchase or a synthetic history refund.
It must use the **same forward ledger settlement route** as panel activation
and dead-panel reactivation:

1. Charge current available `EFHCb` (bonus) first, then `EFHCm` (main).
2. If their combined balance is insufficient, exchange precisely the
   deficit in available `kWh` to `EFHCm` at `1 kWh = 1 EFHCm` using a real
   ledger event `BANK_EFHC -> USER MAIN` and its bank mirror; then spend
   the newly obtained `EFHCm` through a second real ledger event
   `USER -> BANK_EFHC` and its bank mirror.
3. Invariant: `spent_EFHCb + spent_EFHCm = 100.00000000` including
   EFHCm produced in step 2. Neither the user EFHC balances nor available
   kWh can go negative. If total coverage is insufficient, reject the
   entire operation and do not change the Panel.
4. The financial entries, energy exchange, energy cancellation,
   protective-dead marker, historical Panel ID and audited metadata are
   one atomic, idempotent transaction; no backdated changes.
5. On cancellation, keep `G`, `U=min(G,A)`, `R=G-U` for energy accounting
   (where `A` is available kWh immediately BEFORE the new exchange). The
   generation from the voided Panel is removed; kWh newly exchanged from
   that cancelled generation are annulled with it; any exchange sourced
   beyond it remains accounted against other Panels. Previously completed
   independent exchange/withdrawal ledger events remain immutable.
6. Dead Panel can be reactivated only by Admin, the original ID and
   lifecycle history stay intact, and another 100 EFHC is charged through
   the identical EFHCb -> EFHCm -> kWh route.

Example: EFHCb `50`, EFHCm `30`, available kWh `20`. Real ledger:
`-50 EFHCb`; `-30 EFHCm`; `-20 kWh` plus `+20 EFHCm` conversion;
`-20 EFHCm` to BANK. Aggregate debit = **100 EFHC**, all D8.

This clause supersedes earlier refund-split paragraphs in historical
reports and earlier parts of this document. Direct OWNER permission in
Cycle0473 separately authorizes alignment of Admin Panels presentation
and standalone DEMO to this rule; no authorization extends to external
repositories, CI, roles, unrelated Admin modules or production deployment.
