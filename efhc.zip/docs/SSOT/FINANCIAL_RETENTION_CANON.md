# CANON Simple Financial Retention

Статус: **ACTIVE SSOT / OWNER-APPROVED**.  
Дата решения владельца: `2026-08-16`.  
Текущий функциональный этап: циклы `1778–1782` реализованы; цикл `1784` выполняет evidence-based проверку retention/index/performance без speculative schema changes. Candidate `v174.28` не вводит новые индексы без production query-plan/latency evidence.

Этот CANON отменяет как current target весь physical monthly partitioning plan
циклов `1777–1779`. Предыдущий
`docs/SSOT/FINANCIAL_RETENTION_PARTITION_CANON.md` сохранён только как
исторический superseded design и больше не является authority.

## 1. Главная цель

Retention должен уменьшать стоимость и сложность системы, а не создавать
новые PK/UNIQUE/FK/partition coordination problems. Для первого production
launch используются обычные PostgreSQL tables и обычный bounded `DELETE`.

Запрещено вводить для этого retention:

- `PARTITION BY`;
- monthly partitions;
- composite PK только ради partition key;
- month-aware FK;
- `DROP PARTITION`;
- permanent global financial idempotency registry только ради retention.

Текущие PK/FK/UNIQUE остаются обычными PostgreSQL guarantees.

## 2. Две независимые временные границы

### Financial execution window

P0 invariant не меняется:

- `trusted age < 180 days` — external operation ещё потенциально исполнима;
- `trusted age >= 180 days` — `EXPIRED / NO CREDIT` до replay/idempotency,
  BANK/user balance mutation и ledger credit.

Эта граница определяется trusted financial evidence, а не history retention.

### Detailed financial history

Для шести approved history tables retention clock — server-side `created_at`.

- до `370 days` запись хранится как detailed financial history;
- при `age >= 370 days` запись delete-eligible;
- lifecycle status после этой границы retention не продлевает;
- `PENDING`, unresolved, retry или manual-review не являются вечной защитой
  history row, потому что external primary execution уже запрещён P0 barrier
  начиная с `180 days`.

Чтобы не выполнять cleanup постоянно, runner запускает удаление только когда
oldest retained history достигает `400 days`.

При срабатывании trigger:

`delete_before = now_utc - 370 days`.

То есть накопление 370–399 дней допускается как простой operational buffer,
а при достижении 400 дней удаляется всё history старше 370 дней.

Точные boundary semantics:

- `created_at > now - 370d` — не удалять;
- `created_at <= now - 370d` — delete-eligible;
- oldest `> now - 400d` — cleanup не запускать;
- oldest `<= now - 400d` — cleanup запускать.

## 3. Scope шести history tables

Simple history retention применяется к:

1. `efhc_transfers_log`;
2. `payment_intents`;
3. `shop_orders`;
4. `withdraw_requests`;
5. `withdraw_outcome_events`;
6. `ton_inbox_logs`.

Не входят в этот 370/400-day contour:

- `users` и balances;
- `BANK_EFHC` / current bank state;
- current ownership/state;
- `referral_bonus_ledger` — FOREVER по owner decision;
- Admin/security audit — отдельные 3 года;
- expired/revoked auth sessions — отдельные 14 дней;
- `unmatched_incoming` и mixed-semantics `processed_external_events` — до
  отдельного owner-approved classification.

## 4. FK и порядок удаления

Physical schema не меняется. Существующий FK
`withdraw_outcome_events.withdraw_request_id -> withdraw_requests.id`
сохраняется.

При batch cleanup child history удаляется раньше parent history:

1. `withdraw_outcome_events`;
2. остальные независимые history tables;
3. `withdraw_requests` после child rows.

Никакой FK не отключается и не ослабляется ради cleanup.

## 5. Replay/idempotency retention

`tx_hash_locks` не относится к detailed 370-day history. Его target retention
остаётся `180 days` по `trusted_operation_at`.

Точная граница:

`trusted_operation_at <= now_utc - 180 days`.

Marker на точной границе 180 суток уже может быть удалён, потому что
соответствующая external operation прежде блокируется P0 execution barrier.
Ordinary external idempotency получает тот же 180-day target отдельным
Simple Retention cycle. Eternal registry не создаётся.

## 6. Staged rollout

- `1777` — owner policy + pure age-based planner; physical partitioning окончательно отменён.
- `1778` — bounded batch `DELETE` executor и ежедневный advisory-lock runner. Перед history deletion старые `PENDING` withdrawals на границе `>=180d` переводятся в canonical cancel/refund path; unresolved monetary hold остаётся fail-closed blocker. Parent `withdraw_requests` не удаляется, если у него существует outcome-событие моложе history cutoff, поэтому `ON DELETE CASCADE` не сокращает 370-дневный минимум.
- `1779` — bounded cleanup `tx_hash_locks` по `trusted_operation_at <= now-180d` и ordinary idempotency: explicit `expires_at <= now`, а legacy financial `withdraw_approve` — только `created_at <= now-180d`. Permanent registry не создаётся.
- `1780` — Unified Profile History: один globally ordered keyset stream, public page size ровно `50`, logical sources — canonical `efhc_transfers_log` и `withdraw_requests`; отдельные shop/payment-intent rows не дублируют ledger.
- `1781` — server-side CSV export с bounded keyset reads и защитой Excel formula injection.
- `1782` — server-side XLSX через `openpyxl` write-only, bounded keyset reads и formula-injection guard.
- `1783` — Admin user-centric BANK transfer + paid panel activation по Global ID.
- `1784` — evidence-based retention/index/performance tuning.

## 7. Current implementation boundary

Candidate `v174.26` включает runtime циклов `1778–1782`, но его execution correctness ещё требует exact-head GitHub CI. Локальные pytest/Ruff/Mypy/Bandit/npm/Alembic/PostgreSQL не запускаются по owner rule.

Simple Retention не меняет physical schema: frozen `0001`, обычные PK/FK/UNIQUE, BANK/balances и P0 settlement ordering сохраняются. Cleanup не использует lifecycle status как retention-привилегию после cutoff, но отдельно fail-closed защищает реальное незавершённое денежное обязательство withdrawal hold до canonical refund.

