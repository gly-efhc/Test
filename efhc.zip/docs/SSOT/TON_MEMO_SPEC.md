<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# TON MEMO Spec (SSOT)

Назначение: единый формат MEMO для авто-обработки платежей.

Поддерживаемые форматы:

1) Депозит EFHC (прямое пополнение EFHC 1:1):
- `EFHC:<global_id>`

2) Покупка EFHC-пакета за TON/USDT:
- `BUY:EFHC:<qty>:TG:<global_id>`
- (опционально) `BUY:EFHC:<qty>:TG:<global_id>:OID:<order_id>`

Правила:
- `<global_id>` — каноничный идентификатор пользователя.
- `<qty>` — сколько EFHC надо зачислить пользователю.
- Вотчер проверяет сумму на блокчейне и валидирует MEMO.

Если MEMO отсутствует, платёж не считается каноничным и не должен
автоматически зачисляться без явного сценария SSOT.
