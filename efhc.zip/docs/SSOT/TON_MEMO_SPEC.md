<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# TON MEMO Spec (SSOT)

Назначение: единые routing/compatibility форматы MEMO для входящих TON/Jetton
операций. MEMO само по себе **не является доказательством цены или суммы
внутреннего начисления**.

## Canonical Payment Intent payload

Для автоматической покупки/внешней оплаты используется server-generated
Payment Intent payload вида:

- `EFHC:<purpose>:<intent_id>:G<global_id>`

Автоматический settlement возможен только через canonical reconciliation:

`PENDING + live TTL + expected asset + expected destination + exact amount +
global tx_hash lock`.

## Direct EFHC routing MEMO

- `EFHC:GID:<global_id>` — direct EFHC jetton routing.

## Historical/compatibility package MEMO

Парсер сохраняет read-through поддержку старых форматов, включая:

- `BUY:EFHC:<qty>:GID:<global_id>[:OID:<order_id>]`;
- `BUY:EFHC:<qty>:TG:<provider_tg_id>[:OID:<order_id>]`;
- `SKU:EFHC|Q:<qty>|GID:<global_id>`;
- `SKU:EFHC|Q:<qty>|TG:<provider_tg_id>`.

**Критический запрет:** `qty` из этих MEMO никогда не является источником
`amount_efhc`, цены или доказательством оплаты. Watcher не имеет права
переводить заказ в `PAID_AUTO` и не имеет права вызывать
`credit_user_from_bank()` только по такому MEMO. Если полноценный Payment
Intent payload отсутствует, операция переводится в `pending_manual`.

Telegram selector разрешён только как provider compatibility и сначала
разрешается в canonical `global_id`.
