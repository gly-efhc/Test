# DOCUMENT_LAYER_CANON

Статус: CANON / SSOT

## Назначение

Документ фиксирует, какие типы документов могут жить в CANON / SSOT, NORM, GENERAL, AUDITS, CYCLES и ARTIFACTS.

## CANON / SSOT

Разрешено: фундаментальные каноны, инварианты, базовые словари, ключевые контракты смысла системы.

В CANON / SSOT запрещено: временные решения, backlog, планы, dated wave-docs, operational notes, инвентаризации, working drafts.

## NORM

Разрешено: действующие нормативные правила, policies, standards, operational regimes.

В NORM запрещено: планы, backlog, dated wave-docs, cycle-programs, refresh-lists, инвентаризации, аудиты, временные migration notes, working notes.

## GENERAL

Разрешено: навигация, обзоры, описания, общие документы, материалы которым не место в CANON / NORM.

## AUDITS

Разрешено: аудиты, инвентаризации, dated diagnostics, review docs.

## CYCLES

Разрешено: рабочие циклы, диапазоны циклов, прогресс, переносы, история выполнения и смысл временных планов после переноса из active surface.

## Split rule

Если документ смешивает постоянное правило и временный план, временная часть выносится в CYCLES/AUDITS, а в active документе остаётся только правило.
