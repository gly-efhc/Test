<!-- EFHC_GLOBAL_IDENTITY_CANON_V4 -->
# DOCUMENT LAYER CANON

Статус: **CANON / SSOT / ACTIVE**

## CANON / SSOT

Разрешены только фундаментальные инварианты и единственные точки истины.
В CANON / SSOT запрещено хранить планы, audits, dated waves, backlog,
snapshots и отчёты исполнения.

## NORM

Разрешены только стабильные исполнимые policies, standards, contracts и
runbooks. В NORM запрещено хранить reports, proof, analysis, repair, status,
upgrade, tracking, wave и временные migration notes.

## История проекта

Канонические долговременные разделы истории:

- `docs/cycles/` — диапазонные документы циклов;
- `docs/chats/` — пользовательские transcripts;
- `reports/numbered/` — immutable numbered reports;
- `reports/manifests/` — только необходимые current machine manifests истории
  и нумерации.

Корневой каталог `АРТЕФАКТЫ/` и его копии под `docs/history/` запрещены в
active HEAD. Устаревшее содержимое хранится только во внешнем history ZIP.
Если конкретный файл снова становится необходим действующему проекту, его
возврат требует отдельного подтверждённого назначения, а не старой ссылки
из теста или tooling.

## Split rule

Если файл смешивает постоянный закон и историю исполнения, закон остаётся в
active SSOT/NORM, а устаревший snapshot выносится во внешний history archive.
Active pointer-файл со старым именем не создаётся.
