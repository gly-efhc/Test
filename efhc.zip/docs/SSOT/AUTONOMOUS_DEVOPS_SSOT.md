# AUTONOMOUS DEVOPS SSOT

## Authority

Этот документ фиксирует production DevOps contract EFHC. Существующие Docker Compose deployment, local encrypted backup, restore drill, update lock, safe extraction, migration validation, current/previous release и rollback scripts сохраняются и развиваются как один контур.

## Состояния

Owner-facing итог использует три верхнеуровневых состояния:

- `ВСЁ РАБОТАЕТ`;
- `ЕСТЬ ПРОБЛЕМЫ, НО EFHC РАБОТАЕТ`;
- `EFHC ТРЕБУЕТ ВНИМАНИЯ`.

Все owner-facing operational messages формируются по-русски; technical identifiers допускаются вместе с понятным объяснением.

## Production topology

EFHC V1 использует **ровно одну production VPS**. PostgreSQL, migrate, backend, scheduler, frontend, proxy, DevOps/Autopilot и local newest-10 encrypted backups находятся на этой VPS.

Обязательная вторая production/monitoring/backup VPS, отдельный monitoring host и отдельный backup host запрещены active contract. Полная потеря VPS относится к Disaster Recovery на новом заменяющем VPS.

## Backup и owner export

Production database backup **не отправляется в Telegram** и не зависит от Telegram file limits, Local Telegram Bot API Server, backup chat ID, delivery receipts или retry queue.

Каждый backup generation создаёт один canonical encrypted recovery artifact `.tar.gz.enc`. Production VPS хранит rolling window только из **10 последних** canonical backup generations. Raw PostgreSQL dump и незашифрованный recovery bundle являются staging-only material и после формирования `.enc` не являются retained backups.

Owner export выполняется вручную по защищённому SSH/SFTP каналу: владелец скачивает выбранный `.enc` и соответствующий `.enc.sha256` на ПК или смартфон. EFHC не поднимает отдельный публичный database-backup download service.

Backup encryption key создаётся только explicit initial installation и не регенерируется runtime при потере. Владелец обязан хранить отдельную off-VPS копию key для восстановления скачанных backups.

## Backup/update boundary

Daily backup и pre-update backup используют одну canonical цепочку:

`PostgreSQL dump -> validation/checksum -> recovery bundle -> whole-bundle encryption -> local canonical .enc -> newest-10 retention`.

Database-changing update existing schema не начинается без successful создания и проверки собственного pre-update encrypted artifact. Внешняя доставка backup не входит в update boundary.

## Safe autopilot

Autopilot наблюдает service health, canonical public health `/api/health`, backup freshness и ресурсы. Самостоятельный restart разрешён только application services `backend`, `scheduler`, `frontend`, `proxy`, с bounded attempts и обязательной повторной проверкой.

При активном update/rollback OS-level lock Autopilot работает observation-only и не выполняет mutations. PostgreSQL restart/restore, volume deletion, SSH/firewall mutation и destructive rollback не входят в auto-healing allowlist.

При неустранённой проблеме создаётся privacy-safe diagnostic ZIP; в него запрещено включать `.env`, токены, private keys, backup passphrase, Authorization headers, request bodies и private user data.

## Плановые операции

- daily — создание canonical encrypted recovery artifact и сохранение newest-10 локально;
- каждую минуту — bounded internal health/autopilot check;
- weekly — privacy-safe diagnostic health report; diagnostic bundle остаётся локально и скачивается владельцем по SSH/SFTP при необходимости;
- monthly — end-to-end restore drill последнего canonical encrypted backup в изолированном temporary PostgreSQL instance/volume без записи в production PostgreSQL cluster;
- after reboot — проверка production contour и owner notification через обычный Telegram Bot API, если configured Admin recipient доступен.

## ENV

`env.release.example` / release `.env.example` являются owner-facing configuration template. Secret values не включаются в Git/release/docs. Version labels выводятся из root `VERSION`, а не задаются владельцем в `.env`.

Backup-specific `TELEGRAM_BACKUP_*`, `TELEGRAM_API_ID`, `TELEGRAM_API_HASH`, Local Telegram Bot API и external-monitor host fields запрещены в active owner ENV.
