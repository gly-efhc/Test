# NEUTRAL ALIASES CANON SSOT

## Статус

Канонический документ нейтральных алиасов для переходного слоя 1089+
при очистке старых `reward*` имён без ломки совместимости.

## Главный принцип

- пользовательский слой использует короткие нейтральные слова;
- бонусный слой использует `bonus`;
- общий денежный слой использует `main` и при необходимости `credit`;
- старые `reward*` имена допускаются только как временный алиас до
  полного перевода всех путей.

## Канон

- `reward_efhc` -> `bonus_efhc`
- `reward_bonus_efhc` -> `bonus_efhc` или `bonus_credit_efhc`
- `task_reward` -> `task_bonus`
- `ad_reward` -> `ad_bonus`
- `referral_reward` -> `referral_bonus`
- `level_reward` -> `level_bonus`
- `task_rewards_log` -> `task_bonus_log` (pre-release 0001 rename approved)

## Правило переходного слоя

1. Сначала добавить новый нейтральный алиас.
2. Проверить backend, frontend, admin и маршруты.
3. Только после полного прохождения циклов удалить старый алиас.

## Нейтральные слова

Предпочтение:
- `bonus`
- `main`
- `credit`
- `grant`

Избегать без итерации:
- `reward`
- `prize`
- `winner`
- `winning`

- `reward_amount_efhc` -> `bonus_amount_efhc` (pre-release 0001 rename approved)
