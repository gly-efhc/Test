# EFHC FAQ (ID)

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. Tentang Proyek

### 1-1. Apa itu EFHC?

EFHC adalah proyek game tentang energi, progres, dan pengembangan akun di dalam bot. Pengguna mengaktifkan panel, mengumpulkan energi, menukarkannya menjadi EFHC, memantau saldo, naik level, bergerak dalam peringkat, dan menggunakan fitur tambahan proyek.

Penjelasan:
— EFHC — Energy for Humanity Coin
— EFHCm — koin utama
— EFHCb — koin bonus
— EFHCj — jetton EFHC eksternal
— EFHC — total saldo (bonus + utama)

### 1-2. Bagaimana semuanya bekerja di sini?

Di dalam proyek, semuanya dibangun di sekitar energi dan pertumbuhan akun. Pengguna bekerja dengan panel, mengumpulkan energi, menukarkannya menjadi EFHC utama, memantau saldo, menghubungkan wallet, memperkuat progres, dan menggunakan mekanik tambahan proyek.

### 1-3. Apa yang harus saya lakukan di bot ini?

Tugas utama Anda adalah mengembangkan akun. Untuk itu, pengguna bekerja dengan panel, memantau pembangkitan energi, menggunakan Exchange, memeriksa saldo, menghubungkan wallet, berpartisipasi dalam mekanik tambahan proyek, dan secara bertahap memperkuat progresnya.

### 1-4. Bagaimana cara tumbuh dan maju di sini?

Pertumbuhan di dalam bot dibangun di sekitar energi dan aktivitas. Semakin banyak panel, energi, tindakan yang berguna, dan progres yang dimiliki pengguna, semakin kuat akun berkembang dan semakin tinggi posisinya dalam sistem level dan rank.

### 1-5. Apa makna utama proyek ini?

Makna utama proyek ini adalah menunjukkan jalur dari aktivasi panel ke pembangkitan energi, lalu ke hasil dalam EFHC. Pengguna tidak melihat angka abstrak, tetapi jalur yang saling terhubung: panel, energi, Exchange, saldo, progres, level, dan posisi di antara peserta lain.

### 1-6. Apakah ini hanya hiburan atau ada logika perkembangan?

Di sini ada logika pertumbuhan yang utuh. Pengguna tidak hanya menekan tombol, tetapi secara bertahap memperkuat akunnya: mengaktifkan panel, memulai pembangkitan, mendapatkan Activ status, mengumpulkan bonus, mengembangkan sistem referral, dan melihat hasil dari jalurnya.

### 1-7. Dari mana EFHC pertama saya muncul?

EFHC pertama muncul dari dua sumber utama: bonus accruals (ke dalam koin bonus EFHCb) dan penukaran energi melalui Exchange (ke dalam koin utama EFHCm). Jalur terkuat adalah panel → energi → Exchange → saldo utama.

### 1-8. Dari mana energi saya berasal?

Energi berasal dari panel aktif Anda. Selama panel tetap aktif, panel akan menghasilkan energi, dan energi itu terakumulasi sebagai energi tersedia untuk Exchange.

### 1-9. Apa yang paling memengaruhi pertumbuhan saya dalam proyek?

Yang paling besar memengaruhi pertumbuhan adalah jumlah panel aktif dan total generation-nya. Penguat kedua adalah VIP (jika ada), karena itu memengaruhi generation. Tasks, iklan, dan referrals adalah tambahan yang berguna, tetapi bukan fondasi utama.

### 1-10. Bagaimana saya tahu bahwa saya bergerak ke arah yang benar?

Jika tiga hal bertumbuh — generation, energi tersedia, dan saldo utama setelah Exchange — berarti Anda bergerak ke arah yang benar. Cara tercepat untuk memeriksanya adalah melalui halaman Energy dan riwayat operasi.

## 2. Layar Utama

### 2-1. Apa yang ditampilkan layar utama?

Layar utama adalah halaman Energy. Halaman ini mengumpulkan elemen utama dari keadaan akun saat ini: tindakan cepat, informasi tentang progres, dan titik masuk ke bagian-bagian penting bot.

### 2-2. Mengapa layar utama diperlukan?

Layar utama diperlukan agar pengguna langsung melihat hal yang paling penting tentang akunnya dan cepat memahami keadaan saat ini, progres, dan apa yang bisa dilakukan selanjutnya.

### 2-3. Apa yang harus dilihat lebih dulu?

Pertama-tama, perhatikan panel atas, total saldo, layar Energy, dan tindakan yang tersedia. Justru elemen-elemen ini yang paling cepat menunjukkan keadaan akun saat ini dan apa yang bisa dilakukan berikutnya.

### 2-4. Di mana progres saya saat ini terlihat?

Progres saat ini tercermin dalam bagian bot yang terkait dengan energi, panel, level, dan peringkat. Dari sana terlihat bagaimana pengguna bergerak maju di dalam proyek.

### 2-5. Mengapa layar utama penting setiap hari?

Karena justru di sinilah paling cepat terlihat bagaimana akun berubah: berapa banyak energi saat ini, berapa panel aktif, bagaimana progres bertumbuh, dan langkah berikutnya apa yang sudah siap untuk dilakukan pengguna.

### 2-6. Dari mana sebaiknya saya mulai?

Sebaiknya mulai dengan melihat panel atas, memahami saldo yang Anda miliki, membuka halaman Energy, melihat bagian Panels, lalu mempelajari FAQ tentang tindakan utama. Jika tindakan yang diperlukan membutuhkan wallet, langkah berikutnya adalah menghubungkannya.

### 2-7. Tombol mana di layar utama yang paling penting?

Tindakan utama adalah Panels, Exchange, Isi Saldo Langsung di bilah atas, dan Hub. Hub hanya menampilkan tombol Isi Saldo.

### 2-8. Apa yang harus saya periksa di layar utama setiap hari?

Tiga hal: 1) berapa banyak panel aktif, 2) kecepatan generation, 3) berapa banyak energi tersedia yang sudah terkumpul untuk Exchange.

### 2-9. Mengapa layar utama berubah seiring waktu?

Karena layar utama mencerminkan keadaan akun yang hidup. Ketika panel, energi, dan operasi mulai muncul, layar tidak lagi kosong dan mulai menampilkan lebih banyak data yang berguna serta progres.

### 2-10. Bagaimana memahami dari layar utama bahwa akun berkembang?

Ketika Anda melihat pertumbuhan berdasarkan fakta: generation tidak nol, energi terus terakumulasi, dan setelah Exchange saldo utama meningkat. Itulah tanda perkembangan yang paling jujur.

## 3. Panel Atas

### 3-1. Apa itu panel atas?

Panel atas adalah elemen antarmuka yang terpisah dan blok informasi cepat utama yang tersedia di halaman-halaman utama bot.

### 3-2. Apa yang ditampilkan di bilah atas?

Di bilah atas ditampilkan avatar, nama, tingkat progres energi, status VIP, saldo total, tombol Top Up, dan tombol Hub.

### 3-3. Mengapa panel atas penting?

Karena panel atas membantu Anda langsung melihat hal yang paling penting tentang akun tanpa perpindahan yang tidak perlu: siapa Anda, bagaimana progres Anda, apakah ada VIP, berapa total koin yang Anda miliki, dan tindakan cepat apa yang tersedia sekarang.

### 3-4. Apa yang ditunjukkan total saldo di panel atas?

Total saldo menunjukkan berapa banyak koin yang Anda miliki secara keseluruhan. Ini dibuat agar nyaman, supaya Anda tidak perlu menjumlahkan sumber daya sendiri untuk tindakan internal dan untuk memahami kondisi akun di dalam game secara umum.

### 3-5. Mengapa total saldo nyaman untuk tindakan internal?

Karena total saldo menunjukkan daya beli keseluruhan pemain di dalam game dan membantu cepat memahami apakah sumber daya yang ada sudah cukup untuk tindakan internal.

### 3-6. Mengapa total saldo tidak sama dengan jumlah yang bisa ditarik sekarang juga?

Karena total saldo mencakup koin utama dan koin bonus. Koin bonus dibutuhkan untuk proses game dan tidak ditarik secara langsung.

### 3-7. Kapan sebaiknya saya menggunakan tombol “Top Up” di panel atas?

Gunakan tombol itu ketika Anda ingin cepat masuk ke alur isi ulang saldo utama yang tersedia di aplikasi tanpa membuka bagian tambahan secara manual.

### 3-8. Mengapa membuka Hub dari bilah atas?

Agar Anda bisa dengan cepat membuka kartu tindakan terkait proyek dan berpindah ke alur eksternal yang dibutuhkan tanpa navigasi tambahan di antarmuka.

### 3-9. Mengapa panel atas terlihat di berbagai halaman?

Karena panel atas adalah “dashboard” akun: panel ini dibutuhkan agar Anda selalu melihat hal yang paling penting — saldo, status, dan tindakan cepat — bahkan saat membuka bagian lain.

### 3-10. Apa yang harus dilakukan jika data di panel atas tampak salah?

Pertama, segarkan halaman lalu periksa riwayat saldo: di sana terlihat fakta setiap operasi. Jika riwayat dan saldo cocok, berarti datanya benar — bisa jadi Anda hanya melihat saldo yang berbeda, misalnya total saldo, bukan saldo utama.

## 4. Profil

### 4-1. Apa itu bagian Profil/Pengaturan?

Profil/Pengaturan adalah bagian tempat pengguna mengelola profil dan parameter bot. Di sini terlihat status utama dan tersedia pengaturan antarmuka yang bersifat personal.

### 4-2. Apa yang bisa dilakukan di profil?

Di profil terkumpul pengaturan utama pengguna dan pintasan ke bagian penting: Wallet, riwayat saldo, FAQ, dan titik pengelolaan berguna lainnya.

### 4-3. Apa yang ditampilkan di bagian atas Profil/Pengaturan?

Di bagian atas Profil/Pengaturan ditampilkan avatar, nama Telegram, serta status Activ dan VIP jika status tersebut sudah dimiliki.

### 4-4. Di mana mengubah bahasa?

Bahasa diubah di bagian Profil/Pengaturan.

### 4-5. Mengapa profil diperlukan?

Profil diperlukan sebagai titik kendali pribadi untuk akun. Di sini pengguna bukan hanya melihat status, tetapi juga membuka subbagian penting yang berkaitan dengan wallet, riwayat, bahasa, dan bantuan.

### 4-6. Di mana membuka riwayat saldo di profil?

Di bagian Profil/Pengaturan ada pintu masuk terpisah ke riwayat saldo, tempat semua pemasukan dan pengeluaran terlihat.

### 4-7. Di mana mengganti bahasa di profil?

Penggantian bahasa ada di Profil/Pengaturan karena itu adalah pengaturan personal akun.

### 4-8. Di mana membuka Wallet di Profil untuk bekerja dengan wallet?

Di bagian Profil ada menu Wallet terpisah. Buka menu itu saat Anda perlu menghubungkan wallet, memeriksa binding, atau masuk ke tindakan yang berkaitan dengan wallet.

### 4-9. Di mana cepat membuka FAQ di Profil jika saya membutuhkan jawaban?

Di bagian Profil ada akses ke FAQ. Buka bagian itu saat Anda membutuhkan jawaban cepat tentang antarmuka, balance, panels, energy, exchange, withdrawal, atau fungsi WebApp lainnya.

### 4-10. Apa yang ada di bagian “Dukungan dan informasi”?

Di sana terkumpul poin-poin bantuan: FAQ, petunjuk/informasi, dan semua hal yang membantu pengguna memahami proyek tanpa kebingungan.

### 4-11. Dalam berapa bahasa antarmuka proyek tersedia?

Antarmuka bot dan sistem bantuan (FAQ) telah diterjemahkan ke dalam 13 bahasa. Anda dapat memilih bahasa yang paling nyaman di pengaturan profil, dan sistem akan segera menyesuaikan semua teks dan antarmuka sesuai pilihan Anda.

## 5. Wallet

### 5-1. Untuk apa dompet utama diperlukan?

Dompet utama digunakan untuk tindakan yang terkait dengan operasi eksternal proyek: penarikan, pengisian saldo, konfirmasi kepemilikan alamat, dan tindakan terkait lain yang membutuhkan dompet tertaut.

### 5-2. Apakah wallet utama bisa diganti?

Ya. Pengguna dapat memilih wallet utama lain dari wallet yang sudah terhubung.

### 5-3. Apakah wallet yang terhubung bisa dihapus?

Ya. Jika wallet itu tidak lagi diperlukan, tautannya dapat dihapus.

### 5-4. Mengapa dompet yang sama tidak bisa ditautkan ke dua akun?

Dompet yang sama tidak boleh digunakan pada dua akun berbeda secara bersamaan. Jika dompet sudah tertaut ke satu akun, dompet itu harus dilepas dari akun pertama sebelum ditautkan ke akun lain. Ini mencegah kebingungan pada status, pemeriksaan, dan hasil yang terkait dengan dompet.

### 5-5. Apa yang terjadi jika saya menekan tindakan yang membutuhkan wallet, tetapi saya belum punya wallet?

Jika fungsi yang dipilih membutuhkan wallet, bot akan terlebih dahulu menjalankan logika penghubungan wallet. Setelah itu Anda dapat kembali ke tindakan yang dibutuhkan dan menyelesaikannya dengan normal.

### 5-6. Apakah saya bisa menghubungkan beberapa wallet dan untuk apa itu diperlukan?

Ya. Anda dapat menghubungkan beberapa wallet agar memiliki alamat cadangan atau memisahkan beberapa skenario penggunaan. Pada saat yang sama, satu wallet dipilih sebagai wallet utama — wallet inilah yang digunakan secara default untuk operasi yang membutuhkan alamat terpilih.

### 5-7. Apa yang harus dilakukan jika saya ingin menggunakan wallet saya di akun lain?

Pertama, wallet ini harus dilepas dari akun saat ini. Baru setelah itu wallet dapat ditautkan ke akun lain. Wallet yang sama tidak boleh ditautkan ke dua akun secara bersamaan.

### 5-8. Apakah penarikan bisa dilakukan ke wallet yang bukan utama?

Secara default sistem menggunakan wallet utama. Jika Anda membutuhkan alamat lain, jadikan wallet itu sebagai wallet utama di Wallet terlebih dahulu, lalu ajukan permintaan penarikan.

### 5-9. Apa yang harus dilakukan jika wallet sudah terhubung, tetapi penarikan tetap tidak tersedia?

Periksa tiga hal: apakah wallet utama sudah dipilih, apakah saldo utama mencukupi, dan apakah jumlah penarikan tidak kurang dari 10 EFHC.

### 5-10. Di mana saya bisa memeriksa wallet mana yang saat ini tertaut ke akun saya?

Periksa di bagian Wallet. Di sana pengguna melihat wallet mana saja yang tertaut ke akun dan wallet mana yang digunakan dalam akun tersebut.

### 5-11. Apa yang harus saya lakukan jika saya kehilangan akses ke wallet TON utama saya?

Karena proyek ini memungkinkan Anda menautkan beberapa wallet, Anda dapat menautkan wallet baru di bagian Wallet, menjadikannya sebagai wallet utama, dan menghapus alamat lama yang terkompromi secara permanen dari daftar wallet yang tertaut.

## 6. Saldo dan Riwayat

### 6-1. Mengapa saya punya tiga saldo yang berbeda?

Karena dana di dalam bot memiliki peran yang berbeda. Total saldo menampilkan semuanya sekaligus, saldo bonus diperlukan untuk siklus game internal, sedangkan saldo utama menunjukkan hasil yang sudah bisa digunakan untuk operasi penting dan penarikan.

### 6-2. Apa itu saldo bonus?

Saldo bonus adalah saldo game internal. Saldo ini digunakan untuk pengembangan di dalam bot, dikreditkan dari tugas, referral, hadiah, dan mekanisme internal proyek lainnya, tetapi tidak ditarik secara langsung.

### 6-3. Apa itu saldo utama?

Saldo utama adalah EFHC utama. Ke saldo inilah hasil dari siklus game berubah, dan justru dari saldo inilah operasi penting, termasuk penarikan, tersedia.

### 6-4. Mengapa satu tindakan internal bisa memengaruhi saldo bonus dan saldo utama sekaligus?

Untuk semua pengeluaran internal proyek, dana dipotong terlebih dahulu dari saldo bonus. Jika itu tidak cukup, sisanya dipotong dari saldo utama.

### 6-5. Mengapa ada beberapa catatan sekaligus di riwayat?

Satu operasi bisa menyentuh beberapa bagian pergerakan dana, karena itu bot menampilkannya dalam beberapa baris agar perubahan yang berbeda terlihat secara terpisah.

### 6-6. Di mana saya bisa melihat EFHC masuk ke mana atau keluar dari mana?

Untuk itu ada bagian riwayat saldo. Bagian ini menampilkan pemasukan, pengeluaran, Exchange, tindakan internal, Withdraw, dan perubahan dana lainnya.

### 6-7. Mengapa total saldo saya bisa besar, tetapi jumlah yang bisa saya tarik lebih kecil?

Karena total saldo menjumlahkan saldo utama dan saldo bonus. Withdraw hanya diizinkan dari saldo utama, sedangkan saldo bonus ditujukan untuk siklus internal proyek. Karena itu, untuk Withdraw Anda harus melihat saldo utama.

### 6-8. Di mana cara tercepat melihat apa yang tepatnya mengubah saldo saya?

Di riwayat saldo. Di sana terlihat operasi mana yang memberi pemasukan atau pengeluaran, dan saldo mana yang terdampak.

### 6-9. Mengapa saldo bonus tidak bisa ditarik langsung?

Karena koin bonus adalah bagian dari siklus internal proyek. Withdraw hanya diizinkan dari saldo utama.

### 6-10. Mengapa setelah Withdraw atau Exchange riwayat tidak langsung berubah sama di semua tempat?

Karena layar yang berbeda tidak selalu diperbarui pada saat yang sama. Periksa dengan urutan ini: muat ulang bagian → periksa saldo → periksa riwayat.

### 6-11. Apa yang terjadi jika, saat internet lemah, saya tanpa sengaja menekan tombol beli atau exchange beberapa kali berturut-turut? Apakah koin tambahan akan terpotong?

Tidak. Koin tambahan tidak akan terpotong. Inti sistem memiliki perlindungan ketat terhadap pemotongan ganda. Bahkan jika Anda menekan tombol 10 kali karena jaringan macet, operasi dijamin hanya akan dijalankan tepat satu kali.

## 7. Panels

### 7-1. Berapa EFHC yang diperlukan untuk mengaktifkan satu panel?

Diperlukan 100 EFHC untuk mengaktifkan satu panel.

### 7-2. Apa yang langsung diberikan aktivasi panel pertama?

Aktivasi panel pertama langsung memulai pembangkitan energi, membuka jalan menuju progres, menciptakan jalur ke EFHC utama, dan memberi Activ status permanen.

### 7-3. Kapan pembangkitan panel dimulai?

Pembangkitan dimulai segera setelah panel diaktifkan.

### 7-4. Berapa lama masa hidup sebuah panel?

Setiap panel memiliki siklus panel selama 180 hari.

### 7-5. Apa yang terjadi dengan panel setelah siklus 180 hari berakhir?

Setelah siklus 180 hari selesai, panel dinonaktifkan dan dipindahkan ke Archive sebagai memori progres energi peserta.

### 7-6. Dua status panel apa yang ada di antarmuka?

Di antarmuka ada Activ dan Archive. Activ adalah panel yang ikut dalam pembangkitan. Archive adalah panel yang sudah menyelesaikan siklus aktifnya dan menyimpan riwayat perjalanan.

### 7-7. Bisakah saya mengaktifkan lebih dari satu panel sekaligus?

Ya. Anda dapat mengaktifkan panel secara bertahap, menambah jumlah panel aktif. Semakin banyak panel aktif, semakin tinggi total pembangkitan energi dan semakin cepat progres Anda tumbuh.

### 7-8. Apa arti timer “Tersisa” pada panel?

Timer menunjukkan berapa banyak waktu yang tersisa sampai akhir siklus panel 180 hari. Ketika waktu habis, panel akan otomatis berpindah ke Archive dan berhenti menjadi aktif.

### 7-9. Mengapa setelah mengaktifkan panel pertama saya menjadi Activ?

Karena Activ adalah konfirmasi partisipasi nyata dan perlindungan proyek dari bot. Proyek mengaitkan Activ dengan aktivasi panel pertama agar status ini hanya diberikan kepada peserta yang benar-benar hidup.

### 7-10. Mengapa panel aktif lebih penting daripada panel arsip?

Panel aktif menghasilkan energi sekarang — justru merekalah yang memberi tempo pertumbuhan Anda saat ini. Panel arsip adalah panel yang sudah selesai; mereka menyimpan riwayat, tetapi tidak memberi pembangkitan saat ini.

### 7-11. Mengapa panel aktif saya lebih sedikit daripada jumlah yang saya aktifkan?

Karena sebagian panel mungkin sudah menyelesaikan masa 180 hari dan berpindah ke Archive. Panel aktif adalah panel yang bekerja sekarang. Archive adalah panel yang sudah selesai dan tidak memberi pembangkitan saat ini.

### 7-12. Bisakah panel aktif “menghilang” karena batas 1000?

Tidak. Batas 1000 berarti pada saat yang sama Anda tidak bisa memiliki lebih dari 1000 panel aktif. Panel aktif yang sudah diaktifkan tidak “hilang”: mereka tetap aktif sampai akhir masa kerjanya, lalu berpindah ke Archive.

### 7-13. Apa yang harus saya lakukan jika saya mengaktifkan panel, tetapi pembangkitan tidak langsung berubah?

Periksa:
— Muat ulang bagian Panels
— Lihat apakah panel muncul di Active
— Buka Energy dan periksa kecepatan pembangkitan
— Periksa riwayat saldo (harus ada pengurangan 100 EFHC)

### 7-14. Bisakah saya mengaktifkan panel jika saya punya kurang dari 100 EFHC?

Tidak. Diperlukan 100 EFHC untuk mengaktifkan panel. Jika dana kurang, aktivasi tidak akan berhasil.

### 7-15. Mengapa panel Archive penting jika mereka sudah tidak menghasilkan?

Archive menyimpan riwayat panel Anda dan siklus yang sudah dilalui. Ini adalah “biografi pertumbuhan” Anda, tetapi pembangkitan saat ini hanya diberikan oleh panel aktif.

### 7-16. Bisakah saya mengaktifkan panel dan langsung melihat bahwa panel itu aktif?

Ya. Panel yang diaktifkan harus muncul dalam daftar Active, dan aktivasinya tercermin di riwayat saldo.

### 7-17. Berapa banyak energi yang dihasilkan satu panel selama 180 hari?

Satu panel pada tarif dasar menghasilkan 107.61984000 kWh selama 180 hari. Jika Anda memiliki EFHC VIP NFT, generasinya menjadi 115.24032000 kWh.

## 8. Energy

### 8-1. Apa yang ditampilkan halaman Energy?

Halaman Energy menampilkan progres energi, progress bar pembangkitan energi, jumlah panel aktif, total pembangkitan panel per detik, dan indikator penting lain dari keadaan saat ini.

### 8-2. Apa yang ditampilkan progress bar di halaman Energy?

Progress bar menunjukkan jalur menuju level progres pemain berikutnya dalam skala 12 level.

### 8-3. Apa arti total pembangkitan panel per detik?

Itu adalah konstanta pembangkitan dasar atau VIP yang dikalikan dengan jumlah panel aktif.

### 8-4. Mengapa energi begitu penting?

Karena energi adalah dasar pusat dari progres di EFHC. Melalui energi, pengguna bergerak dari panel menuju hasil yang memengaruhi saldo, level, rank, dan perkembangan akun.

### 8-5. Bisakah saya memahami seberapa kuat akun saya dari Energy?

Ya. Halaman Energy dengan cepat menunjukkan kekuatan sistem saat ini: berapa banyak panel yang bekerja, pembangkitan apa yang sedang berjalan sekarang, berapa banyak energi yang sudah terkumpul, dan seberapa jauh pengguna maju ke level berikutnya.

### 8-6. Mengapa available energy dan saldo utama dihitung terpisah?

Karena keduanya adalah dua entitas yang berbeda. Available energy menunjukkan kWh yang telah terkumpul, sedangkan saldo utama menunjukkan EFHC utama yang sudah diterima. Nilai-nilai ini saling berkaitan, tetapi bukan hal yang sama.

### 8-7. Mengapa energy bertambah sendiri, tetapi saldo utama tidak naik otomatis?

Karena akumulasi energy dan pertumbuhan saldo utama terjadi pada tahap yang berbeda. Mula-mula panel menghasilkan energy, dan saldo utama baru bertambah setelah tindakan exchange terpisah atau skenario lain yang mengkreditkan EFHC utama.

### 8-8. Apa yang ditunjukkan kecepatan pembangkitan per detik?

Itu adalah indikator seberapa cepat panel aktif Anda menghasilkan energi saat ini, yaitu tempo pertumbuhan Anda sekarang.

### 8-9. Apa yang paling penting dipantau di Energy setiap hari?

Jumlah panel aktif, kecepatan pembangkitan, dan available energy — itulah tiga penanda utama keadaan akun.

### 8-10. Bagaimana memahami dari Energy bahwa panel saya benar-benar bekerja?

Jika di Energy terlihat panel aktif dan pembangkitan yang tidak nol, sementara available energy bertambah secara bertahap, berarti panel bekerja. Jika pembangkitan 0 dan energi tidak bertambah, berarti tidak ada panel aktif atau Anda sedang melihat blok yang salah.

### 8-11. Mengapa angka energi yang bergerak di layar kadang-kadang bisa sedikit dikoreksi atau meloncat?

Demi kenyamanan Anda, angka energi yang terkumpul diperbarui di layar secara real time, menunjukkan proses generasi yang berkelanjutan. Namun, sumber kebenaran utama selalu server. Secara berkala, dan juga setelah setiap tindakan Anda, aplikasi melakukan sinkronisasi dengan server untuk memastikan akurasi matematis absolut. Pada saat itu, dapat terjadi mikro-koreksi angka di layar ke nilai server yang tepat.

## 9. Exchange

### 9-1. Apa itu Exchange?

Exchange adalah bagian tempat energi diubah menjadi EFHC utama. Ini adalah salah satu tahap kunci dalam perjalanan pengguna di dalam proyek.

### 9-2. Bagaimana cara kerja penukaran energi menjadi EFHC?

Exchange adalah konversi progres menjadi EFHC utama. Energi yang terkumpul diubah menjadi koin utama proyek.

### 9-3. Apa arti aturan 1 kWh = 1 EFHC?

Itu adalah kurs internal tetap proyek. Setiap unit energi dikonversi menjadi jumlah EFHC yang sama.

### 9-4. Apa yang terjadi setelah Exchange?

Setelah Exchange, hasil energi muncul di saldo utama dalam bentuk EFHC utama. Ini sudah bukan hanya energi yang terkumpul, tetapi hasil yang ikut dalam operasi penting proyek.

### 9-5. Mengapa Exchange begitu penting?

Karena justru melalui Exchange pengguna memindahkan energi yang terkumpul menjadi hasil utama. Ini adalah titik ketika jalur energi berubah menjadi EFHC utama.

### 9-6. Bisakah koin bonus ditukar langsung tanpa energi?

Tidak. Koin bonus pertama-tama ikut dalam siklus internal: dengan koin bonus diaktifkan panel, panel menghasilkan energi, dan baru setelah itu energi ditukar menjadi EFHC utama.

### 9-7. Mengapa hasil Exchange langsung masuk ke saldo utama, bukan ke saldo bonus?

Karena Exchange adalah perubahan energi menjadi hasil utama. Di proyek sudah ditetapkan aturan: 1 kWh = 1 EFHC, dan hasil Exchange selalu dikreditkan ke saldo utama, dari mana operasi penting dan Withdraw tersedia.

### 9-8. Apa yang harus saya lakukan jika saya sudah melakukan Exchange, tetapi belum melihat hasilnya?

Pertama, muat ulang bagian Exchange dan periksa saldo utama. Lalu buka riwayat saldo: di sana harus ada catatan tentang Exchange. Jika catatan itu ada, berarti Exchange sudah dilakukan, meskipun Anda belum langsung melihat perubahan di layar.

— Muat ulang bagian
— Periksa saldo
— Periksa riwayat

### 9-9. Bisakah saya menukar energi lalu langsung mengajukan Withdraw?

Ya, jika setelah Exchange saldo utama memiliki EFHC yang cukup, jumlah Withdraw tidak kurang dari 10 EFHC, dan wallet sudah terhubung serta dipilih sebagai utama.

### 9-10. Mana yang lebih baik: sering Exchange atau menabung?

Itu tergantung tujuan Anda. Exchange yang sering nyaman untuk kontrol dan operasi, sedangkan menabung nyaman untuk langkah besar yang jarang. Aturannya satu: hasil Exchange masuk ke saldo utama.

### 9-11. Mengapa available energy berkurang setelah Exchange?

Karena Anda memindahkan sebagian energi yang sudah terkumpul menjadi EFHC melalui Exchange. Energi tidak hilang — energi berubah menjadi koin.

Penting: jumlah energi pada halaman utama Energy tidak boleh “berkurang” sebagai progres total Anda dan tidak memengaruhi rank maupun level ke belakang — angka itu mencerminkan jalur pertumbuhan Anda dan hasil pembangkitan secara keseluruhan.

### 9-12. Energi mana yang sudah bisa saya tukar?

Yang bisa ditukar adalah energi yang sudah terkumpul dan menjadi available. Itulah available energy — volume yang sudah siap digunakan di bagian Exchange.

### 9-13. Apakah ada batas minimum untuk menukar energi menjadi EFHC utama?

Tidak ada batas ketat, tetapi matematika exchange mengikuti kurs 1 kWh = 1 EFHC. Sebaiknya Anda mengumpulkan dan menukar nilai energi bulat mulai dari 1 kWh agar hasilnya langsung terlihat di saldo utama.

## 10. Withdraw

### 10-1. Mengapa saya tidak bisa menarik EFHC?

Biasanya penyebabnya adalah saldo utama tidak cukup, wallet belum terhubung, atau jumlahnya di bawah ambang minimum penarikan. Pemeriksaan sebaiknya dimulai dari Wallet dan saldo utama.

### 10-2. Bagaimana proses penarikan berlangsung?

Sebuah permintaan Withdraw dibuat, setelah itu permintaan tersebut diproses secepat mungkin oleh operator pertama yang tersedia.

### 10-3. Mengapa setelah membuat permintaan Withdraw saldo langsung berubah?

Karena bot langsung memperhitungkan awal operasi ini di dalam sistem. Ini diperlukan agar pengguna melihat bahwa tindakan tersebut sudah terkait dengan dananya dan telah diterima oleh sistem.

### 10-4. Dari balance mana withdrawal bisa dilakukan?

Withdrawal hanya tersedia dari balance utama.

### 10-5. Mengapa Withdraw hanya tersedia dari saldo utama?

Karena saldo utama adalah hasil yang sudah menjadi milik pengguna sebagai hasil proses game atau sebagai koin yang diaktifkan. Koin bonus ikut dalam siklus internal dan tidak bisa ditarik secara langsung.

### 10-6. Berapa minimum Withdraw?

Jumlah minimum Withdraw adalah 10 EFHC.

### 10-7. Biasanya berapa lama permintaan Withdraw diproses?

Withdraw melalui tahap permintaan dan pemrosesan oleh operator. Jika hasilnya tidak terlihat segera, periksa status permintaan dan riwayat operasi — di sanalah keadaan nyata tercermin. Jika permintaan lama tidak berubah, biasanya membantu untuk memuat ulang bagian dan memeriksa lagi nanti.

### 10-8. Bisakah saya membatalkan permintaan Withdraw?

Ya, jika permintaan itu belum diproses. Pembatalan tersedia untuk permintaan yang masih menunggu. Setelah pembatalan, periksa saldo utama dan riwayat operasi: jika dana sempat ditahan, dana itu dikembalikan kembali.

### 10-9. Mengapa permintaan Withdraw bisa “tertahan” dalam status menunggu?

Karena Withdraw melewati proses pemrosesan. Jika status permintaan tidak berubah, periksa status permintaan dan riwayat operasi, lalu muat ulang bagian itu lagi nanti.

### 10-10. Di mana saya bisa melihat bahwa permintaan telah dibatalkan?

Itu terlihat dari status permintaan dan dari catatan di riwayat operasi. Setelah pembatalan, periksa juga saldo utama.

### 10-11. Mengapa minimum Withdraw justru 10 EFHC?

Karena di proyek telah ditetapkan ambang batas di bawahnya permintaan tidak diterima. Minimum adalah 10 EFHC.

Selain itu: biaya Withdraw dibayar oleh proyek, sehingga menarik jumlah di bawah 10 EFHC tidak masuk akal.

### 10-12. Mengapa withdrawal bisa tidak tersedia walaupun saya punya EFHC?

Karena untuk withdrawal hanya balance utama yang dihitung. Jika EFHC berada di bagian bonus dari balance, withdrawal untuk saldo itu tidak bisa diajukan.

### 10-13. Apa yang harus dilakukan setelah mengajukan permintaan Withdraw?

Periksa status permintaan dan riwayat operasi — di sana terlihat keadaan nyata permintaan dan pergerakan dana.

### 10-14. Dalam token apa dan di jaringan apa penarikan dilakukan?

Penarikan hanya dilakukan dalam token EFHC dan hanya di jaringan blockchain TON (The Open Network). Tidak ada opsi penarikan lain di dalam proyek.

### 10-15. Berapa lama pemrosesan manual penarikan oleh operator?

Permintaan penarikan diproses oleh operator dalam antrean langsung. Biasanya pemrosesan memakan waktu dari beberapa menit hingga 24 jam, tergantung beban jaringan dan jumlah permintaan. Anda selalu dapat membatalkan permintaan yang belum diproses, dan dana akan langsung kembali ke saldo Anda.

## 11. Tasks

### 11-1. Apa yang diberikan oleh penyelesaian tugas?

Tugas hanya memberikan koin bonus dan mendorong Anda untuk ikut serta dalam kehidupan pemain di dalam proyek.

### 11-2. Bagaimana cara mendapatkan hadiah untuk tugas?

Anda perlu memenuhi syarat tugas, setelah itu bot akan secara otomatis mencatat penyelesaiannya dan memberikan hadiah yang yang ditetapkan untuk tugas tersebut.

### 11-3. Mengapa tugas tidak terselesaikan?

Ini bisa terjadi jika syaratnya belum terpenuhi sepenuhnya, tindakan belum diselesaikan sampai akhir, atau hasilnya belum sempat diperbarui di dalam sistem.

### 11-4. Bisakah saya melakukan tugas yang sama lagi?

Itu tergantung pada jenis tugasnya. Sebagian tugas hanya sekali, dan sebagian lagi dapat berulang sesuai logika proyek.

### 11-5. Apakah semua tugas memberikan hadiah yang sama?

Tidak. Besarnya hadiah bergantung pada tugas tertentu dan syaratnya. Tetapi jenis hadiahnya di sini tetap satu — koin bonus.

### 11-6. Mengapa tugas dibutuhkan jika sudah ada Panels?

Tasks adalah jalur pertumbuhan tambahan. Mereka tidak menggantikan Panels, tetapi membantu mengumpulkan koin bonus yang kemudian bisa digunakan di dalam siklus permainan.

### 11-7. Mengapa hadiah tugas tidak masuk ke saldo utama?

Karena tugas memberikan bonus EFHC. Ini adalah hadiah internal untuk siklus permainan, dan ia masuk ke saldo bonus.

### 11-8. Mengapa tugas kadang berakhir atau menghilang?

Karena tugas bisa bersifat sementara atau memiliki batas. Jika sebuah tugas tidak ada, berarti tugas itu sudah selesai atau sedang tidak aktif.

### 11-9. Di mana saya bisa melihat semua tugas yang tersedia?

Di bagian Tasks — di sana ditampilkan daftar tugas yang tersedia dan syarat-syaratnya.

### 11-10. Mengapa hadiah untuk tugas tidak langsung muncul?

Kadang sistem memerlukan waktu untuk memperbarui hasil. Periksa: muat ulang Tasks → periksa saldo bonus → periksa riwayat operasi.

### 11-11. Saya sudah berlangganan channel yang diminta dalam task, tetapi task tidak selesai. Mengapa?

Terkadang verifikasi langganan membutuhkan waktu karena caching di sisi server Telegram. Jika bot tidak langsung menghitung langganan Anda, kembali ke bagian Tasks setelah beberapa menit dan tekan tombol pemeriksaan sekali lagi.

## 12. Referrals

### 12-1. Apa nama bagian-bagian di halaman Referrals?

Di halaman Referrals digunakan bagian Aktif dan Tidak aktif.

### 12-2. Apa arti referral aktif dan tidak aktif?

Referral aktif adalah pemain yang sudah mengaktifkan setidaknya satu panel dan mendapatkan Activ status. Referral tidak aktif adalah pemain yang belum masuk ke siklus permainan dan masih belum memberi hak atas bonus.

### 12-3. Kapan bonus referral diberikan?

Bonus referral diperiksa oleh bot secara otomatis. Begitu pemain menjadi aktif, bonus langsung diberikan secara otomatis.

### 12-4. Apa manfaat Activ status untuk referrals?

Activ status penting bagi logika referral karena proyek menggunakannya sebagai bagian dari filter partisipasi nyata dan perlindungan dari bot, bot farm, dan aktivitas palsu.

### 12-5. Bagaimana hubungan Activ dengan referrals?

Activ menunjukkan bahwa pengguna adalah peserta nyata proyek, bukan akun bot. Ini penting untuk kerja yang jujur dari sistem referral dan perlindungan dari bot farm.

### 12-6. Berapa bonus dasar untuk setiap referral aktif?

Untuk setiap referral langsung Anda, satu bonus 0.1 EFHCb diberikan hanya sekali — saat referral tersebut mengaktifkan panel pertamanya dan memperoleh Activ.

### 12-7. Mengapa referrals saya ada, tetapi bonusnya belum masuk?

Bonus diberikan hanya setelah referral langsung mengaktifkan panel pertamanya. Sebelum itu ia tetap tidak aktif; panel berikutnya tidak menghasilkan bonus referral ulang.

### 12-8. Ke mana 0.1 EFHCb untuk referral aktif dikreditkan?

Hadiah aktivasi 0.1 EFHCb untuk referral langsung dikreditkan satu kali ke saldo bonus. Hadiah Lvl juga dikreditkan ke saldo EFHCb yang sama. Siklus penuh adalah 1.000 EFHCb untuk 10.000 referral langsung aktif ditambah 1.411 EFHCb hadiah Lvl, total 2.411 EFHCb.

### 12-9. Mengapa orang yang saya undang ada di daftar, tetapi tidak dihitung sebagai aktif?

Karena ia menjadi aktif hanya setelah mengaktifkan panel pertama dan mendapatkan Activ. Selama itu belum terjadi, ia tetap berada di bagian daftar yang tidak aktif.

### 12-10. Di mana saya bisa mengambil tautan referral saya?

Di bagian Referrals — di sana ditampilkan tautan referral Anda dan daftar orang yang Anda undang.

### 12-11. Apakah diperbolehkan membuat akun tambahan dengan link referral milik sendiri?

Ya. Aturan proyek tidak melarang hal itu. Namun, membuat akun kosong tidak akan memberi Anda manfaat. Ekonomi sistem dibangun sedemikian rupa sehingga bonus referral dan pertumbuhan peringkat hanya dikreditkan untuk peserta dengan status Activ — yaitu setelah akun yang diundang benar-benar masuk ke permainan dan mengaktifkan setidaknya satu panel.

### 12-12. Bisakah saya mengganti pengundang saya setelah pendaftaran?

Tidak. Hubungan referral ditetapkan pada saat pertama kali Anda masuk ke proyek melalui link undangan dan tidak dapat diubah setelah itu.

## 13. Hub

### 13-1. Apa yang dapat saya lakukan di Hub?

Hub memiliki dua tindakan: Isi Saldo dan EFHC VIP NFT. Detail jalur eksternal hanya muncul setelah keluar dari Hub.

### 13-2. Untuk apa Hub digunakan?

Hub adalah bagian navigasi singkat untuk dua tindakan eksternal proyek.

### 13-3. Berapa tindakan yang tersedia di Hub?

Tepat dua: Isi Saldo dan EFHC VIP NFT. Keduanya merupakan fungsi kanonik.

### 13-4. Apa fungsi tombol «Isi Saldo»?

Tombol ini membuka kelanjutan pada halaman Web eksternal. Produk, harga, dan metode pembayaran tidak ditampilkan sebelum keluar dari Hub.

### 13-5. Ke saldo mana top-up EFHC masuk setelah konfirmasi?

Top-up EFHCm dikreditkan ke saldo utama.

### 13-6. Mengapa hasil top-up mungkin tidak muncul seketika?

Tahap eksternal dari operasi harus dikonfirmasi terlebih dahulu, lalu hasilnya diperbarui. Periksa Hub, saldo utama, dan riwayat operasi.

### 13-7. Jika saya menerima VIP NFT melalui GetGems, di mana saya bisa melihat bahwa itu aktif?

Periksa status VIP di aplikasi dan keberadaan NFT di wallet yang terhubung.

### 13-8. Saya sudah melalui alur eksternal dari Hub, tetapi belum ada hasil. Apa yang harus saya lakukan?

Periksa Hub, saldo utama, dan riwayat operasi. Jika masih belum ada hasil, berarti operasi belum tertarik masuk atau memerlukan pemrosesan terpisah.

### 13-9. Saldo mana yang menerima top-up melalui Top Up dan Hub?

Top-up EFHCm dikreditkan ke saldo utama.

### 13-10. Apakah saya memerlukan wallet yang terhubung untuk tindakan dari Hub?

Untuk tindakan eksternal berbasis wallet dibutuhkan Wallet yang terhubung. Hub sendiri terbuka tanpa tindakan internal terpisah dan berfungsi sebagai titik perpindahan.

### 13-11. Di mana saya bisa memeriksa bahwa top-up EFHC benar-benar sudah masuk?

Periksa saldo utama dan riwayat operasi: jejak top-up harus muncul di sana.

### 13-12. Apakah ada skin di Hub?

Skin bukan kartu Hub.

### 13-13. Bagaimana cara mendapatkan skin proyek?

Skin terbuka seiring progres akun dan terikat pada 12 tingkat pencapaian.

## 14. Navigasi dan aturan

### 14-1. Kapan saya harus membuka bagian “Navigasi dan Aturan”?

Buka bagian ini saat kamu perlu cepat memahami logika layar, menemukan fungsi yang dibutuhkan di WebApp, atau memperjelas aturan dasar penggunaan bagian-bagian aplikasi.

### 14-2. Layar mana yang sebaiknya saya buka lebih dulu jika saya masuk ke WebApp untuk pertama kali atau setelah jeda yang panjang?

Sebaiknya mulai dari layar utama, bilah atas, dan profil. Setelah itu akan lebih mudah berpindah ke Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History, dan Hub sesuai tugas Anda saat ini.

### 14-3. Bagaimana saya tahu di bagian mana saya harus mencari fungsi yang saya butuhkan?

Pilih bagian sesuai tindakan: Profile untuk akun, Wallet untuk dompet, Panels untuk panel, Energy untuk generasi, Exchange untuk pertukaran, Withdraw untuk penarikan, Tasks untuk tugas, Referrals untuk undangan, dan Hub untuk perpindahan Isi Saldo.

### 14-4. Di mana akses ke Profile?

Akses ke Profile ada di bagian atas antarmuka melalui tombol “Profile”.

### 14-5. Mengapa beberapa tindakan memerlukan konfirmasi terpisah?

Konfirmasi terpisah melindungi akun dan mengurangi risiko tindakan tidak sengaja pada operasi penting.

### 14-6. Mengapa beberapa tindakan langsung tersedia sementara yang lain bergantung pada status akun?

Beberapa fungsi bergantung pada status akun, adanya panel, wallet yang terhubung, riwayat aktivitas, atau kondisi internal proyek lainnya.

### 14-7. Bagaimana memahami perbedaan antara Profile, Wallet, dan History?

Profile adalah bagian berisi data akun dan pintu masuk ke fungsi terkait. Wallet adalah bagian untuk menghubungkan dan memeriksa dompet. History adalah riwayat operasi dan pergerakan saldo.

### 14-8. Apa yang harus saya lakukan jika tidak melihat tombol atau bagian yang diperlukan?

Pertama segarkan layar dan periksa apakah bagian lain sedang terbuka. Lalu kembali ke layar utama, panel atas, atau Profile, dan buka lagi fungsi tersebut sesuai tujuannya.

### 14-9. Apa yang harus dilakukan jika data di layar terlihat lama atau tidak sesuai harapan?

Pertama segarkan layar, lalu buka bagian profil yang terkait dengan informasi itu. Saldo dan pergerakan lebih mudah diperiksa di History, panel di Panels, generasi di Energy, operasi dompet di Wallet, dan tindakan penarikan di Withdraw.

### 14-10. Bagaimana mengetahui bahwa bagian yang terbuka bukan bagian yang tepat?

Pilih bagian sesuai tindakan: Profile untuk akun, Wallet untuk dompet, Panels untuk panel, Energy untuk generasi, Exchange untuk pertukaran, Withdraw untuk penarikan, Tasks untuk tugas, Referrals untuk undangan, dan Hub untuk perpindahan Isi Saldo.

### 14-11. Urutan pemeriksaan layar apa yang nyaman saat masuk WebApp setiap hari?

Biasanya nyaman melihat layar utama dan panel atas terlebih dahulu, lalu membuka bagian yang terkait dengan tugas saat ini: Panels, Energy, History, Tasks, Referrals, Hub, Exchange, atau Withdraw. Urutan ini membantu memahami keadaan akun saat ini dengan cepat dan menuju tindakan yang diperlukan.

### 14-12. Bagian mana yang berguna untuk diperiksa rutin meskipun tidak ada tugas mendesak?

Berguna untuk rutin memeriksa layar utama, panel atas, Panels, Energy, History, Tasks, Referrals, dan Hub. Ini membantu melihat perubahan saldo, aktivitas panel, dan tindakan yang tersedia tepat waktu.

### 14-13. Mengapa penting melakukan tindakan di bagiannya sendiri, bukan mencarinya di semua tempat?

Ini mengurangi kesalahan dan tindakan tidak sengaja. Ketika pengguna melakukan pertukaran di Exchange, penarikan di Withdraw, dan bekerja dengan panel di Panels, logika WebApp tetap jelas dan aman.

### 14-14. Tanda apa yang menunjukkan bahwa suatu tindakan penting dan perlu perhatian?

Perhatian ekstra diperlukan ketika tindakan memengaruhi saldo, panel, energi, pertukaran, penarikan, penautan dompet, riwayat operasi, atau status akun. Sebelum mengonfirmasi tindakan seperti itu, sebaiknya periksa lagi layar dan tombol yang dipilih.

### 14-15. Apa yang harus dilakukan jika layar berubah setelah pembaruan bot?

Ikuti nama bagian terbaru dan tujuannya. Elemen visual dapat berubah, tetapi logika layar harus tetap mudah dipahami dan konsisten.

### 14-16. Aturan dasar apa yang membantu menghindari kesalahan saat memakai WebApp?

Lakukan tindakan hanya di bagian yang tepat, baca nama layar dan tombol dengan cermat sebelum konfirmasi, dan jika ragu periksa dulu bagian profil daripada menekan elemen antarmuka secara acak.

### 14-17. Kapan sebaiknya membuka FAQ saat menggunakan WebApp?

FAQ berguna dibuka ketika Anda perlu cepat memperjelas arti layar, tombol, tindakan, atau aturan dari fungsi tertentu. Ini memudahkan mencocokkan pertanyaan dengan bagian yang tepat dan menghindari langkah yang tidak perlu di dalam WebApp.

## 15. Ads

### 15-1. Bagian apa ini?

Bagian Ads adalah subbagian di dalam Tasks. Bagian ini menampilkan tindakan iklan yang tersedia, melalui mana pengguna dapat memperoleh koin bonus tambahan.

### 15-2. Apa manfaatnya bagi saya?

Bagian ini hanya memberikan koin bonus untuk tayangan, jika iklan saat ini tersedia untuk akun pengguna.

### 15-3. Mengapa di sini tidak ada apa-apa?

Jika bagian ini kosong, berarti untuk akun pengguna saat ini tidak ada penawaran aktif atau iklan sedang dinonaktifkan sementara.

### 15-4. Di mana letak bagian Ads?

Bagian Ads berada sebagai subbagian di dalam Tasks. Ini adalah salah satu kemungkinan tambahan di dalam blok tugas.

### 15-5. Jenis hadiah apa yang diberikan Ads?

Ads hanya memberikan koin bonus untuk tayangan. Ini bukan saldo utama dan bukan penarikan langsung, melainkan cara internal tambahan untuk memperkuat jalur permainan.

### 15-6. Mengapa Ads berguna?

Karena ini adalah sumber tambahan koin bonus. Ads tidak menggantikan Panels dan generation, tetapi bisa membantu memperkuat siklus permainan internal dengan lebih cepat.

### 15-7. Mengapa iklan ada pada pengguna lain, tetapi tidak ada pada saya?

Karena penawaran mungkin tidak tersedia untuk akun tertentu atau iklan sedang dinonaktifkan sementara. Ads yang kosong tidak berarti akun Anda rusak.

### 15-8. Apa yang harus dilakukan jika saya menyelesaikan tindakan di Ads, tetapi tidak ada hasil?

Periksa: muat ulang Tasks/Ads → periksa saldo bonus → periksa riwayat operasi.

### 15-9. Mengapa di Ads bisa ada penawaran yang berbeda untuk pengguna yang berbeda?

Karena penawaran bergantung pada ketersediaan kampanye iklan untuk akun tertentu. Ini normal: pada satu pengguna ada penawaran, pada pengguna lain sementara tidak ada.

### 15-10. Apakah saya perlu mengaktifkan sesuatu untuk menggunakan Ads?

Tidak. Ads adalah cara untuk mendapatkan bonus EFHC, dan tidak memerlukan tindakan internal wajib.

## 16. Ranks

### 16-1. Mengapa pertumbuhan saya di ranking itu penting?

Pertumbuhan di ranking menunjukkan bagaimana progress Anda terlihat dibanding peserta lain. Ini membantu memahami posisi Anda saat ini dan melihat seberapa aktif akun berkembang.

### 16-2. Apa bedanya level dan peringkat?

Level menunjukkan progres pribadi di dalam sistem, sedangkan peringkat menunjukkan posisi pengguna di antara peserta lain.

### 16-3. Bagaimana level dan peringkat saling terkait?

Keduanya terhubung oleh satu logika pertumbuhan yang sama melalui generation kWh oleh Panels dan progress bar umum di halaman Energy.

### 16-4. Apakah peringkat hanya angka yang terlihat indah?

Tidak. Peringkat membantu memahami bagaimana jalur Anda terlihat dibandingkan dengan peserta lain.

### 16-5. Apa yang memengaruhi pertumbuhan posisi saya di ranking?

Pertumbuhan posisi Anda di ranking dipengaruhi oleh progress keseluruhan akun: perkembangan panels, generasi kWh, dan pergerakan umum di jalur energi proyek.

### 16-6. Bisakah saya naik level dan peringkat secara bersamaan?

Ya. Saat pengguna mengembangkan Panels, generation, dan progres energi secara umum, biasanya ia juga memperkuat levelnya dan posisinya di peringkat.

### 16-7. Mengapa level saya tinggi, tetapi posisi peringkat saya bukan yang pertama?

Karena peringkat adalah posisi di antara semua peserta, bukan hanya progres pribadi Anda. Pemain lain juga bertumbuh, jadi posisi Anda bisa berubah meskipun level Anda sudah bagus.

### 16-8. Mengapa peringkat saya bisa bergeser tanpa ada tindakan baru dari saya?

Karena peringkat tidak hidup sendirian, melainkan berubah dibandingkan dengan semua peserta. Saat Anda tidak mengubah apa pun, pengguna lain tetap berkembang, dan itu memengaruhi posisi Anda.

### 16-9. Di mana saya bisa melihat posisi saya dalam peringkat?

Di bagian Ranks — di sana ditampilkan posisi Anda di antara peserta lain.

### 16-10. Mengapa peringkat saya bisa turun meskipun saya sedang berkembang?

Karena peringkat tidak hanya bergantung pada pertumbuhan Anda sendiri, tetapi juga pada kecepatan pertumbuhan peserta lain. Bahkan jika akun Anda makin kuat, posisi Anda bisa turun ketika pengguna lain menyalip Anda lebih cepat.

## 17. Activ-status

### 17-1. Apa arti status Activ?

Activ adalah status aktif permanen. Ini berarti permainan benar-benar telah dimulai, karena setidaknya satu panel sudah diaktifkan.

### 17-2. Bagaimana cara mendapatkan Activ?

Untuk mendapatkan Activ, cukup mengaktifkan satu panel. Setelah tindakan internal ini, status diberikan secara permanen.

### 17-3. Apakah Activ bersifat sementara atau permanen?

Activ adalah status permanen.

### 17-4. Apakah Activ tetap tersimpan jika panel nanti masuk ke Archive?

Ya. Bahkan jika panel nanti masuk ke Archive, status Activ tetap tersimpan.

### 17-5. Mengapa Activ itu penting?

Activ membantu membedakan pemain nyata dari pendaftaran acak, bot, dan bot farm. Ini menegaskan partisipasi nyata pengguna dalam proyek.

### 17-6. Apakah Activ bisa hilang nanti?

Tidak. Activ adalah status permanen dan tetap tersimpan meskipun panel pertama nantinya masuk ke Archive.

### 17-7. Mengapa Activ diperlukan untuk perlindungan dari bot dan bot farm?

Karena Activ menegaskan partisipasi nyata, bukan akun kosong untuk manipulasi. Ini membuat sistem referral dan ekonomi proyek lebih jujur.

### 17-8. Apa yang berubah pada akun setelah mendapatkan Activ?

Akun dianggap sebagai peserta hidup proyek yang sudah terkonfirmasi. Ini memengaruhi kerja referral yang adil dan tingkat kepercayaan terhadap aktivitas akun.

### 17-9. Mengapa Activ muncul justru setelah panel pertama?

Karena aktivasi panel pertama adalah tanda yang jelas dari partisipasi nyata. Proyek memakai langkah ini sebagai filter terhadap akun kosong.

### 17-10. Apakah Activ bisa hilang karena tidak aktif?

Tidak. Activ adalah status permanen dan tidak hilang karena ketidakaktifan.

## 18. VIP NFT

### 18-1. Apa itu EFHC VIP NFT?

EFHC VIP NFT adalah kartu klub, kunci ke seluruh ekosistem masa depan EFHC, tanda kepemilikan digital, dan kunci untuk peluang masa depan proyek.

### 18-2. Apa yang diberikan oleh kepemilikan satu EFHC VIP NFT?

Memiliki satu EFHC VIP NFT memberikan generation yang lebih tinggi untuk semua Panels milik pemain.

### 18-3. Dari tanda apa terlihat bahwa VIP sudah diperhitungkan?

Jika VIP NFT sudah diperhitungkan oleh sistem, antarmuka menampilkan status VIP dan keuntungan akun yang terkait mulai terlihat.

### 18-4. Di mana saya akan melihat efek VIP?

Efek VIP terlihat di bagian-bagian tempat proyek memperhitungkan keunggulan VIP NFT, serta di top bar dan di Profil/Pengaturan.

### 18-5. Apakah saya perlu mengaktifkan VIP secara manual?

Tidak. Logika proyek dirancang untuk pemeriksaan wallet secara otomatis dan pembaruan otomatis status VIP setelah NFT ditemukan di koleksi yang diperlukan.

### 18-6. Apakah 2 atau 3 VIP NFT memberi hak istimewa tambahan bagi pemain?

Tidak. Bagi pemain, memiliki 2 atau 3 VIP NFT tidak memberikan hak istimewa tambahan di luar satu VIP NFT.

### 18-7. Mengapa VIP NFT kedua tidak memperkuat efek?

Di dalam proyek, VIP memberikan penguatan generation sebagai satu status aktif. VIP NFT tambahan tidak memberi penguatan tambahan agar efeknya tidak terus meningkat tanpa batas.

### 18-8. Apakah VIP memengaruhi satu panel atau semua panel?

VIP memengaruhi generation semua Panels milik pengguna, bukan hanya satu panel tertentu.

### 18-9. Bagaimana cara memeriksa bahwa VIP benar-benar memengaruhi akun?

Periksa bukan hanya keberadaan status VIP, tetapi juga keuntungan terkait di mekanik akun, terutama di tempat efek VIP diperhitungkan, termasuk generasi.

### 18-10. Apakah wallet harus terhubung agar bot bisa melihat VIP NFT saya?

Ya. Agar bot bisa melihat VIP NFT, bot harus memahami wallet mana yang terkait dengan akun. Karena itu Wallet harus terhubung, lalu Anda memeriksa status VIP di antarmuka.

### 18-11. Bisakah saya menggunakan VIP NFT saya sesuka saya?

Ya. EFHC VIP NFT dapat dipindahkan, dihadiahkan, dan dijual di marketplace.

### 18-12. Jika saya menjual atau memindahkan VIP NFT saya ke wallet lain, apa yang akan terjadi pada generation saya?

Bot secara rutin memindai blockchain dan memeriksa keberadaan NFT di wallet tertaut Anda. Jika Anda menjual, menghadiahkan, atau memindahkan VIP NFT Anda ke alamat lain, sistem akan mendeteksinya, menonaktifkan status VIP Anda, dan generation semua panel Anda akan otomatis kembali ke tarif dasar.

## 19. Levels

### 19-1. Mengapa saya perlu menaikkan level?

Kenaikan level menunjukkan progres pengguna di dalam proyek dan membantu melihat bagaimana akun berkembang. Ini adalah indikator visual dan bermakna dari gerak maju.

### 19-2. Apa yang termasuk dalam bagian Levels?

Bagian Levels menampilkan semua skala pertumbuhan proyek: 12 level progres energi, 6 level sistem referral, dan jalur level lain dalam proyek jika nanti ditambahkan.

### 19-3. Berapa banyak level progres energi yang ada dalam proyek?

Di dalam proyek terdapat 12 level progres energi.

### 19-4. Berapa banyak level dalam sistem referral?

Di dalam proyek terdapat 6 level sistem referral: dari 0 sampai 5.

### 19-5. Apa manfaat level bagi pemain biasa?

Level membantu memahami di mana posisi Anda sekarang, berapa banyak yang sudah dilakukan, ke mana harus bergerak selanjutnya, dan batas berikutnya apa yang menunggu di depan.

### 19-6. Bagaimana level energi, level referral, dan pertumbuhan total akun saling terkait?

Semuanya adalah bagian dari satu jalur umum. Generation energi mendorong progres utama, referral aktif memperkuat jalur referral, dan bersama-sama keduanya menunjukkan seberapa kuat akun berkembang.

### 19-7. Eco Initiate (0 kWh)

**Makna bagi pemain:** Panel pertama Anda sudah dipasang dan siap bekerja. Anda mengambil langkah utama untuk menjadi produsen energi bersih yang mandiri. Ini adalah status awal Anda — Anda baru saja masuk ke jalur generation.

**Aturan yang tepat:** Level Eco Initiate sesuai dengan tanda 0 kWh.

**Konsekuensi praktis:** Langkah berikutnya adalah memulai pertumbuhan generation melalui Panels dan membawa progres hingga 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Makna bagi pemain:** Kilowatt pertama sudah mulai berjalan! Panels Anda berhasil menghasilkan energi hijau, memberi alam harapan akan masa depan tanpa karbon. Anda sudah melihat hasil nyata pertama: energi mulai mengalir dan progres bergerak.

**Aturan yang tepat:** Level Hope Bringer dimulai dari 100 kWh.

**Konsekuensi praktis:** Tujuan berikutnya adalah membangun kestabilan dan mencapai 300 kWh untuk tahap selanjutnya.

### 19-9. Energy Seeker (300 kWh)

**Makna bagi pemain:** Sistem bekerja dengan sangat baik, secara stabil memasok jaringan dengan listrik ramah lingkungan. Setiap unit energi yang dihasilkan Panels menggantikan bahan bakar fosil. Akun telah masuk ke mode pertumbuhan yang stabil: Anda bukan lagi pendatang baru, melainkan pengguna dengan generation nyata.

**Aturan yang tepat:** Level Energy Seeker dimulai dari 300 kWh.

**Konsekuensi praktis:** Secara praktis ini adalah sinyal: Anda bisa memperkuat Panels dan lebih sering menggunakan Exchange untuk mengubah energi menjadi saldo utama.

### 19-10. Nature's Voice (600 kWh)

**Makna bagi pemain:** Kontribusi Anda mulai terlihat. Dengan menghasilkan energi melalui teknologi hijau, Anda menjadi suara alam, membuktikan bahwa progres bisa ramah lingkungan. Kontribusi Anda menjadi semakin nyata: progres sudah terasa bukan sebagai kebetulan, melainkan sebagai lintasan.

**Aturan yang tepat:** Level Nature's Voice dimulai dari 600 kWh.

**Konsekuensi praktis:** Patokan berikutnya adalah 1000 kWh (Earth Ally). Berguna untuk memeriksa tempo di Energy dan jumlah Panels aktif.

### 19-11. Earth Ally (1000 kWh)

**Makna bagi pemain:** Satu megawatt-jam pertama telah dihasilkan! Panels Anda telah menghasilkan volume energi bersih yang mengesankan. Sekarang Anda adalah peserta penting dalam transisi hijau dan sekutu setia bagi planet ini. Anda telah melewati tonggak penting: 1000 kWh sudah merupakan volume generation yang serius.

**Aturan yang tepat:** Level Earth Ally dimulai dari 1000 kWh.

**Konsekuensi praktis:** Secara praktis ini adalah titik ketika pertumbuhan menjadi lebih dapat diprediksi: perkuat armada Panels dan jaga pertukaran energi secara teratur.

### 19-12. Climate Fighter (2000 kWh)

**Makna bagi pemain:** Generation Anda memberi pukulan nyata terhadap perubahan iklim. Setiap kilowatt yang dihasilkan secara langsung mengurangi kebutuhan pembakaran batu bara dan gas. Anda sudah menekan pertumbuhan secara sistematis: progres terlihat baik pada level maupun pada dinamika umum akun.

**Aturan yang tepat:** Level Climate Fighter dimulai dari 2000 kWh.

**Konsekuensi praktis:** Langkah berikutnya adalah mengunci tempo dan naik ke 3500 kWh. Perhatikan kecepatan generation dan gunakan VIP bila diperlukan.

### 19-13. Green Sentinel (3500 kWh)

**Makna bagi pemain:** Aliran energi yang stabil dari Panels Anda menjaga udara bersih. Anda memberi manfaat yang terasa bagi masyarakat tanpa meninggalkan jejak karbon. Akun Anda menjadi penjaga generation yang stabil: pertumbuhan berjalan dengan mantap.

**Aturan yang tepat:** Level Green Sentinel dimulai dari 3500 kWh.

**Konsekuensi praktis:** Secara praktis ini berarti Panels sudah bekerja sebagai sebuah sistem — pertahankan Panels aktif dan rencanakan pertumbuhan menuju 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Makna bagi pemain:** 5000 kWh generation bersih! Daya Panels Anda bekerja seperti perisai tak terlihat yang melindungi atmosfer dari ribuan kilogram emisi gas rumah kaca. 5000 kWh adalah tanda skala yang besar: Anda sudah berada di zona peserta kuat dalam energi.

**Aturan yang tepat:** Level Planet Defender dimulai dari 5000 kWh.

**Konsekuensi praktis:** Patokan berikutnya adalah 7500 kWh. Sering kali pada tahap ini pemain memperkuat Panels sekaligus jaringan referral.

### 19-15. Eco Champion (7500 kWh)

**Makna bagi pemain:** Volume produksi yang luar biasa! Anda adalah juara sejati energi hijau, yang kontribusinya benar-benar mengubah keseimbangan energi global ke arah yang lebih baik. Ini adalah level bagi mereka yang secara stabil menjaga tempo generation yang tinggi.

**Aturan yang tepat:** Level Eco Champion dimulai dari 7500 kWh.

**Konsekuensi praktis:** Secara praktis: jaga disiplin — Panels aktif, Exchange rutin, serta kontrol riwayat dan saldo.

### 19-16. Planet Saver (10000 kWh)

**Makna bagi pemain:** 10 megawatt-jam! Anda telah menghasilkan begitu banyak energi bersih sehingga secara harfiah membantu menyelamatkan seluruh ekosistem, membuktikan efektivitas maksimal Panels Anda. 10.000 kWh sudah merupakan tahap progres yang sangat kuat.

**Aturan yang tepat:** Level Planet Saver dimulai dari 10000 kWh.

**Konsekuensi praktis:** Langkah berikutnya adalah 15000 kWh. Pada tahap ini masuk akal untuk mengoptimalkan semuanya: Panels, VIP, referral, dan tindakan internal.

### 19-17. Green Commander (15000 kWh)

**Makna bagi pemain:** Unggulan generation yang ramah lingkungan. Panels Anda memberi tenaga bagi masa depan, dan volume hasil yang mengesankan menetapkan standar baru yang tinggi bagi seluruh komunitas. Anda sudah dekat dengan puncak: ini adalah level energi berskala pemimpin.

**Aturan yang tepat:** Level Green Commander dimulai dari 15000 kWh.

**Konsekuensi praktis:** Secara praktis: jaga kestabilan dan tingkatkan hingga 20000+ kWh, sambil memantau Panels aktif dan tempo di Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Makna bagi pemain:** Puncak evolusi. Dengan menghasilkan lebih dari 20 MWh energi yang sepenuhnya bersih, kamu telah menjadi Guardian of Earth sejati. Panels kamu mengambil kekuatan dari alam itu sendiri untuk memberi daya pada dunia ini dan menjaganya bagi generasi mendatang. Ini adalah puncak tangga: kamu telah mencapai level progres tertinggi yang diakui.

**Aturan tepat:** Level Guardian of Earth sesuai dengan 20000+ kWh.

**Efek praktis:** Dalam praktiknya, kamu telah mengamankan status tertinggi. Dari sini fokusnya adalah menjaga sistem, memperbesar panels, dan memperkuat partisipasi ekosistem melalui panels, VIP, dan pertumbuhan referral.

### 19-19. Level referral 0

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 0 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-20. Level referral 1

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 1 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-21. Level referral 2

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 10 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-22. Level referral 3

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 100 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-23. Level referral 4

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 300 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-24. Level referral 5

**Makna bagi pemain:** Ini adalah tanda pertumbuhan Anda dalam sistem referral — ini menunjukkan skala pengguna aktif yang Anda undang.

**Aturan yang tepat:** Untuk mencapai level ini, diberikan bonus satu kali: 1000 EFHCb.

**Konsekuensi praktis:** Secara praktis: setelah mencapai level, periksa bonus balance dan riwayat operasi untuk melihat kredit masuk.

### 19-25. Bagaimana memahami progres level tanpa kesalahan?

**Makna bagi pemain:** Blok ini membantu menilai progres secara jernih dan melihat level melalui generasi energi yang sebenarnya.

**Aturan tepat:** Level ditentukan oleh akumulasi generasi dalam kWh. Semakin besar total generasi, semakin tinggi level kamu.

**Efek praktis:** Dalam praktiknya, fokus pada pertumbuhan energi, jumlah panels aktif, dan ritme generasi keseluruhan. Itulah yang memberikan progres level nyata.

### 19-26. Mengapa nama level terkait dengan ekologi dan planet?

Karena inti ide permainan ini terkait dengan energi hijau virtual, motivasi orang-orang, dan kontribusi simbolis terhadap pemulihan planet Bumi.

## 20. FAQ / Bantuan

### 20-1. Di mana saya bisa membuka FAQ?

FAQ dibuka dari profil sebagai bagian bantuan internal bot, tempat jawaban tentang tindakan utama, layar, dan aturan proyek dikumpulkan.

### 20-2. Untuk apa FAQ / Bantuan diperlukan?

Bagian ini diperlukan agar pengguna dapat dengan cepat menemukan jawaban yang jelas, angka yang tepat, aturan proyek yang nyata, dan makna tindakan utama tanpa tebakan dan kebingungan.

### 20-3. Mengapa FAQ dijelaskan sedetail ini?

Karena proyek ini berlapis-lapis, dan bantuan singkat yang kering tidak menutup pertanyaan nyata pemain. Di sini yang penting adalah makna, kejelasan, angka yang tepat, dan konsekuensi nyata dari tindakan.

### 20-4. Apakah saya bisa memahami seluruh jalur pemain di dalam bot melalui FAQ?

Ya. FAQ yang baik harus menjelaskan bukan hanya tombol terpisah, tetapi juga seluruh jalur: dari panel pertama ke energi, Exchange, balances, levels, status, dan pertumbuhan akun.

### 20-5. Apa yang harus dilakukan jika saya tidak menemukan jawaban pada percobaan pertama?

Lebih baik buka bagian yang paling dekat secara makna dan lihat pertanyaan-pertanyaan di sekitarnya. Dalam bot besar, banyak jawaban saling terhubung, dan satu blok sering membantu memahami blok berikutnya.

### 20-6. Bagaimana menggunakan FAQ dengan benar?

Cara terbaik adalah bergerak bagian demi bagian: pahami dulu logika umum proyek, lalu layar dan tindakanmu, dan setelah itu lihat aturan spesifik tentang saldo, penarikan, VIP, referral, level, dan fungsi bot lainnya.

### 20-7. Apa yang harus diperiksa jika “semuanya terlihat rusak”?

Periksa tiga hal: 1) Wallet — apakah wallet terhubung dan wallet utama sudah dipilih, 2) balances dan history — apakah ada jejak operasi Anda di sana, 3) bagian yang diperlukan (Panels / Energy / Exchange / Withdraw). Biasanya jawabannya ada di salah satu tempat ini.

### 20-8. Apa cara tercepat untuk memahami apa yang terjadi dengan EFHC saya?

Buka history balance. Riwayat menunjukkan secara tepat apa yang mengubah balances: bonus accrual, tindakan internal, Exchange, atau Withdraw.

### 20-9. Dari mana saya harus mulai jika saya baru pertama kali membuka bot dan tidak mengerti apa-apa?

Mulailah dari Energy (layar utama), lalu buka Panels, lihat balances dan history, dan baru setelah itu putuskan apakah Anda membutuhkan wallet dan top up.

### 20-10. Bagaimana cara tercepat menemukan pertanyaan yang dibutuhkan di FAQ?

Cara tercepat adalah membuka bagian yang sesuai dengan topik (Wallet / Panels / Exchange / Withdraw dan seterusnya) lalu mencari pertanyaannya di sana. Jika Anda ragu, mulai dari bagian FAQ / Bantuan dan orientasikan diri dengan kata-kata kunci.
