# EFHC FAQ (IT) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. Sul progetto

### 1-1. Che cos'è EFHC?

EFHC è un progetto di gioco dedicato all'energia, al progresso e alla crescita dell'account all'interno del bot. L'utente acquista pannelli, accumula energia, la converte in EFHC, monitora i saldi, sale di livello, avanza nella classifica e utilizza le funzionalità aggiuntive del progetto.

Definizioni:
— EFHC — Energy for Humanity Coin
— EFHCm — monete principali
— EFHCb — monete bonus
— EFHCj — jetton esterno EFHC
— EFHC — saldo totale (bonus + principale)

### 1-2. Come funziona tutto qui?

All'interno del progetto tutto ruota attorno all'energia e alla crescita dell'account. L'utente lavora con i pannelli, accumula energia, la converte in EFHC principali, monitora i saldi, collega il wallet, rafforza i propri progressi e utilizza le meccaniche aggiuntive del progetto.

### 1-3. Che cosa devo fare in questo bot?

Il compito principale è sviluppare il proprio account. Per farlo, l'utente lavora con i pannelli, monitora la generazione di energia, usa l'Exchange, controlla i propri saldi, collega il wallet, partecipa alle meccaniche aggiuntive del progetto e rafforza gradualmente i propri progressi.

### 1-4. Come posso crescere e avanzare qui?

La crescita all'interno del bot si basa su energia e attività. Più pannelli, energia, azioni utili e progressi ha l'utente, più forte diventa l'account e più in alto sale nel sistema di livelli e rank.

### 1-5. Qual è il significato principale del progetto?

L'idea centrale del progetto è mostrare il percorso dall'acquisto di un pannello alla generazione di energia e poi al risultato in EFHC. L'utente vede non numeri astratti, ma una catena collegata: pannello, energia, exchange, saldo, progresso, livelli e posizione tra gli altri partecipanti.

### 1-6. È solo intrattenimento o esiste una logica di sviluppo?

Qui esiste una vera logica di crescita. L'utente non si limita a premere pulsanti, ma rafforza gradualmente il proprio account: acquista pannelli, avvia la generazione, ottiene lo stato attivo, raccoglie ricompense, sviluppa il sistema di referral e vede il risultato del proprio percorso.

### 1-7. Come compaiono i miei primi EFHC?

I primi EFHC arrivano da due fonti principali: le ricompense (in monete bonus EFHCb) e lo scambio dell'energia tramite Exchange (in monete principali EFHCm). Il percorso più forte è pannelli → energia → exchange → saldo principale.

### 1-8. Da dove arriva la mia energia?

L'energia proviene dai tuoi pannelli attivi. Finché i pannelli sono attivi, generano energia e questa si accumula come energia disponibile per lo scambio.

### 1-9. Che cosa influisce di più sulla mia crescita nel progetto?

Ciò che incide di più sulla crescita è il numero di pannelli attivi e la loro generazione totale. Il secondo potenziatore è il VIP (se presente), perché influisce sulla generazione. Tasks, Ads e Referrals sono un'aggiunta utile, ma non sono la base.

### 1-10. Come faccio a capire se mi sto muovendo nella direzione giusta?

Se crescono tre cose — generazione, energia disponibile e saldo principale dopo lo scambio — ti stai muovendo correttamente. Il modo più rapido per verificarlo è tramite Energy e la cronologia delle operazioni.

## 2. Schermata principale

### 2-1. Che cosa mostra la schermata principale?

La schermata principale è la pagina Energy. Riunisce gli elementi chiave dello stato attuale dell'account: azioni rapide, informazioni sui progressi e punti di accesso alle sezioni importanti del bot.

### 2-2. Perché serve la schermata principale?

Serve affinché l'utente veda subito le cose più importanti del proprio account e capisca rapidamente lo stato attuale, i progressi e ciò che si può fare dopo.

### 2-3. Che cosa dovrei guardare per prima cosa?

Per prima cosa conviene guardare la barra superiore, il saldo totale, la schermata Energy e le azioni disponibili. Sono proprio questi elementi a mostrare più rapidamente lo stato attuale dell'account e ciò che si può fare dopo.

### 2-4. Dove posso vedere i miei progressi attuali?

I progressi attuali si riflettono nelle sezioni del bot collegate a energia, pannelli, livelli e ranking. Da lì si vede come l'utente avanza all'interno del progetto.

### 2-5. Perché la schermata principale è importante ogni giorno?

Perché è proprio qui che si vede più rapidamente come è cambiato l'account: quanta energia c'è ora, quanti pannelli attivi ci sono, come cresce il progresso e a quale passo successivo l'utente è già pronto.

### 2-6. Da dove è meglio iniziare?

Per prima cosa conviene guardare la barra superiore, capire quali saldi hai, aprire la pagina Energy, controllare la sezione Panels e poi consultare la FAQ sulle azioni principali. Se per l'azione necessaria serve un wallet, il passo successivo sarà collegarlo.

### 2-7. Quali pulsanti della schermata principale sono i più importanti?

I più importanti sono quelli che portano alle azioni chiave: Panels ed Exchange, così come i pulsanti rapidi della barra superiore — Top Up e Hub — se vuole aprire azioni collegate a EFHC e VIP.

### 2-8. Che cosa devo controllare ogni giorno nella schermata principale?

Tre cose: 1) quanti pannelli attivi hai, 2) la velocità di generazione, 3) quanta energia disponibile si è già accumulata per lo scambio.

### 2-9. Perché la schermata principale cambia nel tempo?

Perché riflette lo stato vivo dell'account. Quando compaiono pannelli, energia e operazioni, la schermata smette di essere vuota e inizia a mostrare più dati utili e più progresso.

### 2-10. Come posso capire dalla schermata principale che l'account si sta sviluppando?

Quando vedi crescita nei fatti: la generazione non è zero, l'energia si accumula e dopo lo scambio aumenta il saldo principale. Questi sono i segnali più onesti di sviluppo.

## 3. Barra superiore

### 3-1. Che cos'è la barra superiore?

La barra superiore è un elemento separato dell'interfaccia e il principale blocco informativo rapido disponibile nelle pagine principali del bot.

### 3-2. Che cosa viene mostrato nella barra superiore?

Nella barra superiore vengono mostrati avatar, nome, livello di progresso energetico, stato VIP, saldo totale, il pulsante Top Up e il pulsante Hub.

### 3-3. Perché la barra superiore è importante?

Perché aiuta a vedere subito le cose principali del proprio account senza passaggi inutili: chi sei, qual è il tuo progresso, se hai il VIP, quante monete hai in totale e quali azioni rapide sono disponibili in questo momento.

### 3-4. Che cosa mostra il saldo totale nella barra superiore?

Il saldo totale mostra quante monete hai complessivamente. Serve per comodità, così non devi sommare da solo le risorse per gli acquisti e per capire in generale lo stato del gioco.

### 3-5. Perché il saldo totale è comodo per gli acquisti?

Perché mostra il potere d'acquisto complessivo del giocatore all'interno del gioco e aiuta a capire rapidamente se le risorse bastano per le azioni interne.

### 3-6. Perché il saldo totale non è uguale a ciò che posso prelevare subito?

Perché il saldo totale include sia le monete principali sia quelle bonus. Le monete bonus servono per il gameplay e non si prelevano direttamente.

### 3-7. Quando conviene usare il pulsante “Top Up” nella barra superiore?

Usalo quando vuoi passare rapidamente al flusso di ricarica del saldo principale disponibile nell’app, senza aprire manualmente sezioni aggiuntive.

### 3-8. Perché aprire Hub dalla barra superiore?

Per aprire rapidamente le schede delle azioni collegate al progetto e passare al flusso esterno necessario senza passaggi extra nell’interfaccia.

### 3-9. Perché la barra superiore è visibile in pagine diverse?

Perché è il “cruscotto” dell'account: serve per vedere sempre le cose principali — saldo, stati e azioni rapide — anche quando apri un'altra sezione.

### 3-10. Che cosa devo fare se i dati nella barra superiore sembrano errati?

Prima aggiorna la pagina e controlla la cronologia dei saldi: lì si vedono i fatti delle operazioni. Se cronologia e saldo coincidono, i dati sono corretti; forse stavi guardando il saldo sbagliato, per esempio il totale invece del principale.

## 4. Profilo

### 4-1. Che cos'è la sezione Profilo/Impostazioni?

Profilo/Impostazioni è la sezione in cui si gestiscono il profilo e i parametri del bot. Qui sono visibili gli stati principali e sono disponibili le impostazioni personali dell'interfaccia.

### 4-2. Che cosa si può fare nel profilo?

Nel profilo sono raccolte le impostazioni principali dell'utente e i collegamenti rapidi alle sezioni importanti: Wallet, cronologia dei saldi, FAQ e altri punti utili di gestione.

### 4-3. Che cosa viene mostrato nella parte superiore di Profilo/Impostazioni?

Nella parte superiore di Profilo/Impostazioni vengono mostrati l'avatar, il nome Telegram e gli stati Activ e VIP, se sono già presenti.

### 4-4. Dove posso cambiare lingua?

La lingua si cambia in Profilo/Impostazioni.

### 4-5. Perché in generale serve il profilo?

Il profilo serve come punto personale di gestione dell'account. Qui l'utente non solo vede gli stati, ma apre anche importanti sottosezioni legate al wallet, alla cronologia, alla lingua e all'aiuto.

### 4-6. Dove apro nel profilo la cronologia dei saldi?

Nella sezione Profilo/Impostazioni c'è un accesso separato alla cronologia dei saldi, dove si vedono entrate e uscite.

### 4-7. Dove cambio lingua nel profilo?

Il cambio lingua si trova in Profilo/Impostazioni, perché è un'impostazione personale dell'account.

### 4-8. Dove aprire Wallet nel Profilo per lavorare con il wallet?

Nella sezione Profilo c’è una voce separata Wallet. Aprila quando devi collegare un wallet, controllare il binding o passare ad azioni legate al wallet.

### 4-9. Dove aprire rapidamente FAQ nel Profilo se mi serve una risposta?

Nella sezione Profilo c’è l’accesso a FAQ. Aprilo quando ti serve una risposta rapida su interfaccia, balance, panels, energy, exchange, withdrawal o altre funzioni della WebApp.

### 4-10. Che cosa si trova nella sezione “Supporto e informazioni”?

Lì sono raccolti gli elementi di aiuto: FAQ, suggerimenti/informazioni e tutto ciò che aiuta l'utente a capire il progetto senza confusione.

### 4-11. In quante lingue è disponibile l’interfaccia del progetto?

L’interfaccia del bot e il sistema di aiuto (FAQ) sono tradotti in 13 lingue. Puoi scegliere la lingua più comoda nelle impostazioni del profilo e il sistema adatterà immediatamente tutti i testi e l’interfaccia alla tua scelta.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. Posso cambiare il wallet principale?

Sì. L'utente può scegliere un altro wallet principale tra quelli già collegati.

### 5-3. Posso eliminare un wallet collegato?

Sì. Se il wallet non serve più, il collegamento può essere rimosso.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. Che cosa succede se avvio un'azione per cui serve un wallet ma io non ce l'ho?

Se per la funzione scelta è necessario un wallet, il bot avvierà prima la logica di collegamento del wallet. Dopo di ciò potrai tornare all'azione desiderata ed eseguirla normalmente.

### 5-6. Posso collegare più wallet e perché può servire?

Sì. Puoi collegare più wallet per avere un indirizzo di riserva o per separare diversi scenari d'uso. Allo stesso tempo uno dei wallet viene scelto come principale — è proprio quello che viene usato per impostazione predefinita nelle operazioni in cui serve un indirizzo selezionato.

### 5-7. Che cosa succede se cambio il wallet principale?

Potrai scegliere un altro wallet come principale. Dopo il cambio, il sistema userà il nuovo indirizzo principale per le operazioni in cui è richiesto. Prima di un prelievo o di un acquisto è meglio controllare una volta quale wallet è attualmente impostato come principale.

### 5-8. Posso prelevare su un wallet non principale?

Di default il sistema si basa sul wallet principale. Se ti serve un altro indirizzo, prima rendilo principale in Wallet e solo dopo invia la richiesta di prelievo.

### 5-9. Che cosa devo fare se il wallet è collegato ma il prelievo è comunque non disponibile?

Controlla tre cose: se è selezionato il wallet principale, se c'è abbastanza saldo principale e se l'importo del prelievo non è inferiore a 10 EFHC.

### 5-10. Posso giocare e svilupparmi anche se il wallet non è ancora collegato?

Sì. Il wallet serve per alcune operazioni, per esempio il prelievo, ma puoi comunque sviluppare l'account, orientarti nell'interfaccia e accumulare progressi anche senza di esso.

### 5-11. Cosa devo fare se perdo l’accesso al mio wallet TON principale?

Poiché il progetto consente di collegare più wallet, puoi collegarne uno nuovo nella sezione Wallet, impostarlo come principale e rimuovere definitivamente il vecchio indirizzo compromesso dall’elenco dei wallet collegati.

## 6. Saldi e cronologia

### 6-1. Perché ho tre saldi diversi?

Perché all’interno del bot i fondi hanno ruoli diversi. Il saldo totale mostra tutto insieme, il saldo bonus serve per il ciclo di gioco interno, mentre il saldo principale mostra il risultato che può già essere usato per le operazioni chiave e per il prelievo.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Che cos’è il saldo principale?

Il saldo principale è costituito dagli EFHC principali. È proprio in questo saldo che si trasforma il risultato del ciclo di gioco, ed è da qui che sono disponibili le operazioni chiave, incluso il prelievo.

### 6-4. Perché un solo acquisto può influire sia sul saldo bonus sia su quello principale?

In tutte le spese interne del progetto, i fondi vengono scalati prima dal saldo bonus. Se non basta, il resto viene scalato dal saldo principale.

### 6-5. Perché nella cronologia compaiono subito più registrazioni?

Una singola operazione può interessare più movimenti di fondi, quindi il bot la mostra in più righe per riflettere separatamente i diversi cambiamenti.

### 6-6. Dove posso vedere dove sono arrivati o da dove sono usciti gli EFHC?

Per questo serve la sezione della cronologia del saldo. Mostra accrediti, addebiti, exchange, acquisti, prelievi e altri cambiamenti dei fondi.

### 6-7. Perché il saldo totale può essere alto, ma io posso prelevare meno?

Perché il saldo totale somma il saldo principale e quello bonus. Il prelievo è consentito solo dal saldo principale, mentre il saldo bonus è destinato al ciclo interno del progetto. Per il prelievo devi quindi guardare proprio il saldo principale.

### 6-8. Dove posso vedere più rapidamente che cosa ha cambiato il mio saldo?

Nella cronologia del saldo. Lì si vede quale operazione ha generato un accredito o un addebito e quale saldo è stato interessato.

### 6-9. Perché il saldo bonus non può essere prelevato direttamente?

Perché le monete bonus fanno parte del ciclo interno del progetto. Il prelievo è consentito solo dal saldo principale.

### 6-10. Perché dopo un prelievo o un exchange la cronologia non si aggiorna subito allo stesso modo ovunque?

Perché le diverse schermate non si aggiornano sempre nello stesso momento. Controlla così: aggiorna la sezione → controlla il saldo → controlla la cronologia.

### 6-11. Cosa succede se, con una connessione debole, premo per errore più volte di seguito il pulsante di acquisto o di scambio? Verranno scalate monete extra?

No. Non verranno scalate monete extra. Il nucleo del sistema ha una protezione rigorosa contro i doppi addebiti. Anche se premi il pulsante 10 volte a causa di un blocco della rete, l’operazione verrà eseguita esattamente una sola volta.

## 7. Panels

### 7-1. Quanti EFHC servono per attivare un pannello?

Per attivare un pannello servono 100 EFHC.

### 7-2. Che cosa dà subito l’attivazione del primo pannello?

L’attivazione del primo pannello avvia subito la generazione di energia, apre la strada ai progressi, crea il percorso verso gli EFHC principali e conferisce lo status Activ permanente.

### 7-3. Quando inizia la generazione del pannello?

La generazione inizia subito dopo l’attivazione del pannello.

### 7-4. Qual è la durata di vita di un pannello?

Ogni pannello ha un ciclo di 180 giorni.

### 7-5. Che cosa succede al pannello dopo la fine del ciclo di 180 giorni?

Dopo la fine del ciclo di 180 giorni il pannello viene disattivato e passa in Archive come memoria del progresso energetico del partecipante.

### 7-6. Quali sono i due stati dei pannelli nell’interfaccia?

Nell’interfaccia ci sono Activ e Archive. Activ sono i pannelli che partecipano alla generazione. Archive sono i pannelli che hanno già concluso il ciclo attivo e conservano la cronologia del percorso.

### 7-7. Si può acquistare più di un pannello alla volta?

Sì. Puoi acquistare i pannelli in sequenza, aumentando il numero di pannelli attivi. Più pannelli attivi hai, maggiore è la generazione totale di energia e più rapidamente cresce il tuo progresso.

### 7-8. Che cosa indica il timer “Rimanente” del pannello?

Il timer mostra quanto tempo resta fino alla fine del ciclo di 180 giorni del pannello. Quando il tempo finisce, il pannello passa automaticamente in Archive e smette di essere attivo.

### 7-9. Perché dopo aver acquistato il primo pannello sono diventato Activ?

Perché Activ è una conferma della partecipazione reale e una protezione del progetto contro i bot. Il progetto collega Activ all’attivazione del primo pannello affinché questo status venga dato solo ai partecipanti reali.

### 7-10. Perché i pannelli attivi sono più importanti di quelli in archivio?

I pannelli attivi generano energia adesso: sono loro a dare il tuo ritmo di crescita attuale. I pannelli in archivio sono pannelli conclusi, conservano la cronologia ma non producono generazione attuale.

### 7-11. Perché ho meno pannelli attivi di quanti ne ho attivati?

Perché alcuni pannelli possono aver concluso il periodo di 180 giorni e essere passati in Archive. I pannelli attivi sono quelli che funzionano ora. Archive contiene i pannelli conclusi, che non danno generazione attuale.

### 7-12. I pannelli attivi possono “sparire” a causa del limite di 1000?

No. Il limite di 1000 significa che non puoi avere più di 1000 pannelli attivi contemporaneamente. I pannelli attivi già attivati non “spariscono”: restano attivi fino alla fine del loro periodo, poi passano in Archive.

### 7-13. Che cosa devo fare se ho acquistato un pannello ma la generazione non è cambiata subito?

Controlla:
— aggiorna la sezione Panels
— verifica se il pannello è comparso in Active
— apri Energy e controlla la velocità di generazione
— controlla la cronologia del saldo (deve esserci l’addebito di 100 EFHC)

### 7-14. Posso attivare un pannello se ho meno di 100 EFHC?

No. Per attivare un pannello servono 100 EFHC. Se i fondi sono inferiori, l’acquisto non andrà a buon fine.

### 7-15. Perché i pannelli Archive sono importanti se non generano più?

Archive conserva la cronologia dei tuoi pannelli e dei cicli già completati. È la tua “biografia di crescita”, ma la generazione attuale è data solo dai pannelli attivi.

### 7-16. Posso attivare un pannello e vedere subito che è attivo?

Sì. Il pannello attivato deve comparire nella lista Active e il suo acquisto deve essere visibile nella cronologia del saldo.

### 7-17. Quanta energia genera un pannello in 180 giorni?

Un pannello alla tariffa base genera 107.61984000 kWh in 180 giorni. Con EFHC VIP NFT, la generazione è di 115.24032000 kWh.

## 8. Energy

### 8-1. Che cosa mostra la pagina Energy?

La pagina Energy mostra il progresso energetico, la barra di avanzamento della generazione di energia, il numero di pannelli attivi, la generazione totale dei pannelli al secondo e altri indicatori chiave dello stato attuale.

### 8-2. Che cosa mostra la barra di avanzamento nella pagina Energy?

La barra di avanzamento mostra il percorso verso il livello successivo del progresso del giocatore sulla scala dei 12 livelli.

### 8-3. Che cosa significa la generazione totale dei pannelli al secondo?

È la costante di generazione base o VIP moltiplicata per il numero di pannelli attivi.

### 8-4. Perché l’energia è così importante?

Perché l’energia è la base centrale del progresso in EFHC. Attraverso di essa l’utente passa dai pannelli al risultato che influisce sul saldo, sui livelli, sul ranking e sullo sviluppo dell’account.

### 8-5. Da Energy posso capire quanto è forte il mio account?

Sì. La pagina Energy mostra rapidamente la forza attuale del sistema: quanti pannelli stanno lavorando, quale generazione è in corso in questo momento, quanta energia è già stata accumulata e quanto manca al livello successivo.

### 8-6. Perché l’energia disponibile e il saldo principale vengono conteggiati separatamente?

Perché sono due entità diverse. L’energia disponibile mostra i kWh accumulati, mentre il saldo principale mostra gli EFHC principali già ricevuti. Questi valori sono collegati, ma non sono la stessa cosa.

### 8-7. Perché l’energia cresce da sola mentre il saldo principale non aumenta automaticamente?

Perché l’accumulo di energia e la crescita del saldo principale avvengono in fasi diverse. Prima i pannelli generano energia, e il saldo principale aumenta solo dopo un’azione separata di scambio o un altro scenario di accredito degli EFHC principali.

### 8-8. Che cosa mostra la velocità di generazione al secondo?

È l’indicatore di quanto velocemente i tuoi pannelli attivi stanno producendo energia adesso, cioè il tuo ritmo di crescita attuale.

### 8-9. Che cosa è particolarmente importante controllare in Energy ogni giorno?

Il numero di pannelli attivi, la velocità di generazione e l’energia disponibile: questi sono i tre principali punti di riferimento dello stato dell’account.

### 8-10. Come posso capire da Energy che i miei pannelli stanno davvero funzionando?

Se in Energy vedi pannelli attivi e una generazione diversa da zero, mentre l’energia disponibile cresce gradualmente, i pannelli stanno funzionando. Se la generazione è 0 e l’energia non si accumula, non ci sono pannelli attivi oppure stai guardando il blocco sbagliato.

### 8-11. Perché i numeri dell’energia sullo schermo a volte possono essere leggermente corretti o fare un piccolo salto?

Per tua comodità, i valori dell’energia accumulata vengono aggiornati sullo schermo in tempo reale, mostrando un processo continuo di generazione. Tuttavia, la fonte principale di verità è sempre il server. Periodicamente, e anche dopo ogni tua azione, l’app si sincronizza con il server per garantire un’accuratezza matematica assoluta. In quel momento può verificarsi una micro-correzione dei numeri sullo schermo fino al valore esatto del server.

## 9. Exchange

### 9-1. Che cos’è Exchange?

Exchange è la sezione in cui l’energia viene trasformata in EFHC principali. È una delle fasi chiave del percorso dell’utente all’interno del progetto.

### 9-2. Come funziona lo scambio di energia in EFHC?

L’exchange è la conversione del progresso in EFHC principali. L’energia accumulata viene trasformata nelle monete principali del progetto.

### 9-3. Che cosa significa la regola 1 kWh = 1 EFHC?

È il tasso interno fisso del progetto. Ogni unità di energia viene convertita in una quantità uguale di EFHC.

### 9-4. Che cosa succede dopo l’exchange?

Dopo l’exchange il risultato dell’energia compare nel saldo principale sotto forma di EFHC principali. Non è più solo energia accumulata, ma un risultato che partecipa alle operazioni chiave del progetto.

### 9-5. Perché l’exchange è così importante?

Perché è proprio attraverso l’exchange che l’utente trasferisce l’energia accumulata nel risultato principale. È il punto in cui il percorso energetico diventa EFHC principali.

### 9-6. Si possono scambiare direttamente le monete bonus senza energia?

No. Le monete bonus partecipano prima al ciclo interno: con esse si acquista un pannello, il pannello genera energia e solo dopo l’energia viene scambiata in EFHC principali.

### 9-7. Perché l’exchange va subito nel saldo principale e non in quello bonus?

Perché Exchange è la trasformazione dell’energia nel risultato principale. Nel progetto è fissata la regola: 1 kWh = 1 EFHC, e il risultato dell’exchange viene sempre accreditato nel saldo principale, dal quale sono disponibili le operazioni chiave e il prelievo.

### 9-8. Che cosa devo fare se ho effettuato l’exchange ma non vedo subito il risultato?

Per prima cosa aggiorna la sezione Exchange e controlla il saldo principale. Poi apri la cronologia del saldo: lì deve comparire la registrazione dell’exchange. Se la registrazione c’è, l’exchange è stato eseguito anche se non noti subito il cambiamento sullo schermo.

— aggiorna la sezione
— controlla il saldo
— controlla la cronologia

### 9-9. Si può scambiare energia e presentare subito una richiesta di prelievo?

Sì, se dopo l’exchange nel saldo principale ci sono abbastanza EFHC, l’importo del prelievo non è inferiore a 10 EFHC e il wallet è collegato e selezionato come principale.

### 9-10. Che cosa è meglio: fare exchange spesso o accumulare?

Dipende dal tuo obiettivo. Un exchange frequente è comodo per il controllo e per le operazioni, accumulare è comodo per passi grandi e più rari. La regola è una sola: il risultato dell’exchange va nel saldo principale.

### 9-11. Perché dopo l’exchange l’energia disponibile diminuisce?

Perché stai trasferendo una parte dell’energia accumulata in EFHC tramite Exchange. L’energia non scompare: si trasforma in monete.

Importante: la quantità di energia nella schermata principale Energy non deve “diminuire” come tuo progresso complessivo e non influisce all’indietro su ranking e livello — riflette il tuo percorso di crescita e il risultato complessivo della generazione.

### 9-12. Quale energia posso già scambiare?

Puoi scambiare l’energia che si è già accumulata ed è diventata disponibile. Questa è l’energia disponibile: il volume pronto per l’azione nella sezione Exchange.

### 9-13. Esiste un limite minimo per scambiare energia in EFHC principali?

Non esistono limiti rigidi, ma la logica dello scambio segue il tasso 1 kWh = 1 EFHC. È sensato accumulare e scambiare valori interi di energia a partire da 1 kWh, in modo che il risultato sia subito visibile sul saldo principale.

## 10. Withdraw

### 10-1. Perché non riesco a prelevare EFHC?

Di solito il motivo è che non ci sono fondi sufficienti nel saldo principale, il wallet non è collegato oppure l’importo è inferiore alla soglia minima di prelievo. Bisogna iniziare il controllo dal Wallet e dal saldo principale.

### 10-2. Come avviene il prelievo?

Viene creata una richiesta di prelievo, dopo di che essa viene elaborata il più rapidamente possibile dal primo operatore disponibile.

### 10-3. Perché dopo la richiesta di prelievo il saldo è cambiato subito?

Perché il bot registra immediatamente l’inizio di questa operazione nel sistema. Questo serve affinché l’utente veda che l’azione è già collegata ai suoi fondi ed è stata presa in carico dal sistema.

### 10-4. Da quale balance si può fare un withdrawal?

Il withdrawal è disponibile solo dal balance principale.

### 10-5. Perché il prelievo è disponibile solo dal saldo principale?

Perché il saldo principale è ciò che appartiene già all’utente come risultato del processo di gioco o come monete acquistate. Le monete bonus partecipano al ciclo interno e non vengono prelevate direttamente.

### 10-6. Qual è il prelievo minimo?

L’importo minimo di prelievo è di 10 EFHC.

### 10-7. Quanto tempo richiede di solito l’elaborazione di una richiesta di prelievo?

Il prelievo passa attraverso una richiesta e l’elaborazione da parte di un operatore. Se il risultato non è visibile subito, controlla lo stato della richiesta e la cronologia delle operazioni: lì si riflette lo stato reale. Se la richiesta non cambia per molto tempo, di solito aiuta aggiornare la sezione e ricontrollare più tardi.

### 10-8. Si può annullare una richiesta di prelievo?

Sì, se la richiesta non è ancora stata elaborata. L’annullamento è disponibile per una richiesta in attesa. Dopo l’annullamento controlla il saldo principale e la cronologia delle operazioni: se i fondi erano stati trattenuti, vengono restituiti.

### 10-9. Perché una richiesta di prelievo può restare “in attesa”?

Perché il prelievo passa attraverso un’elaborazione. Se la richiesta non cambia, controlla lo stato della richiesta e la cronologia delle operazioni, poi aggiorna la sezione più tardi.

### 10-10. Dove vedo che la richiesta è stata annullata?

Questo si vede dallo stato della richiesta e dalla registrazione nella cronologia delle operazioni. Dopo l’annullamento controlla anche il saldo principale.

### 10-11. Perché il prelievo minimo è proprio 10 EFHC?

Perché nel progetto è fissata una soglia sotto la quale le richieste non vengono accettate. Il minimo è 10 EFHC.

Inoltre: la commissione di prelievo viene pagata dal progetto, e prelevare importi inferiori a 10 EFHC non è opportuno.

### 10-12. Perché il withdrawal può non essere disponibile anche se ho EFHC?

Perché per il withdrawal viene considerato solo il balance principale. Se gli EFHC si trovano nella parte bonus del balance, non è possibile fare un withdrawal su di essi.

### 10-13. Che cosa devo fare dopo aver presentato una richiesta di prelievo?

Controlla lo stato della richiesta e la cronologia delle operazioni: lì si vede lo stato reale della richiesta e il movimento dei fondi.

### 10-14. In quale token e su quale rete vengono effettuati i prelievi?

I prelievi vengono effettuati solo in token EFHC ed esclusivamente sulla rete blockchain TON (The Open Network). Non esistono altre opzioni di prelievo nel progetto.

### 10-15. Quanto tempo richiede l’elaborazione manuale di un prelievo da parte di un operatore?

Le richieste di prelievo vengono elaborate dagli operatori in coda viva. Di solito l’elaborazione richiede da pochi minuti fino a 24 ore, a seconda del carico della rete e del numero di richieste. Puoi sempre annullare una richiesta non ancora elaborata e i fondi torneranno immediatamente sul tuo saldo.

## 11. Attività

### 11-1. Che cosa dà il completamento delle attività?

Le attività danno solo monete bonus e motivano a partecipare alla vita del giocatore nel progetto.

### 11-2. Come posso ottenere la ricompensa per un’attività?

Bisogna soddisfare le condizioni dell’attività. Dopo questo, il bot registra automaticamente il completamento e accredita la ricompensa prevista.

### 11-3. Perché l’attività non è stata completata?

Succede se le condizioni non sono ancora state soddisfatte del tutto, l’azione non è stata conclusa completamente oppure il risultato non si è ancora aggiornato nel sistema.

### 11-4. Posso fare di nuovo la stessa attività?

Dipende dal tipo di attività. Alcune sono una tantum, mentre altre possono ripetersi secondo la logica del progetto.

### 11-5. Tutte le attività danno la stessa ricompensa?

No. L’importo della ricompensa dipende dall’attività specifica e dalle sue condizioni. Però il tipo di ricompensa qui è uno solo: monete bonus.

### 11-6. Perché servono le attività se ci sono già i pannelli?

Le attività sono un percorso di crescita aggiuntivo. Non sostituiscono i pannelli, ma aiutano a raccogliere monete bonus che poi possono essere usate all’interno del ciclo di gioco.

### 11-7. Perché la ricompensa delle attività non arriva nel saldo principale?

Perché le attività danno EFHC bonus. È una ricompensa interna del ciclo di gioco e viene accreditata nel saldo bonus.

### 11-8. Perché le attività a volte finiscono o scompaiono?

Perché alcune attività possono essere temporanee o avere un limite. Se non vedi più un’attività, significa che è terminata oppure al momento non è attiva.

### 11-9. Dove posso vedere tutte le attività disponibili?

Nella sezione Tasks: lì viene mostrato l’elenco delle attività disponibili e delle loro condizioni.

### 11-10. Perché la ricompensa per l’attività non è apparsa subito?

A volte serve un po’ di tempo perché il risultato si aggiorni. Controlla: aggiorna Tasks → verifica il saldo bonus → verifica la cronologia delle operazioni.

### 11-11. Mi sono iscritto al canale richiesto dal task, ma il task non viene completato. Perché?

A volte la verifica dell’iscrizione richiede tempo a causa della cache lato server di Telegram. Se il bot non ha conteggiato subito l’iscrizione, torna nella sezione Tasks dopo qualche minuto e premi di nuovo il pulsante di verifica.

## 12. Referral

### 12-1. Come si chiamano le sezioni nella pagina Referrals?

Nella pagina Referrals vengono usate le sezioni Attivi e Inattivi.

### 12-2. Che cosa significa referral attivo e inattivo?

Un referral attivo è un giocatore che ha già attivato almeno un pannello e ha ottenuto lo stato Activ. Un referral inattivo è chi non è ancora entrato nel ciclo di gioco e quindi non dà ancora diritto al bonus.

### 12-3. Quando vengono accreditati i bonus referral?

I bonus referral vengono controllati automaticamente dal bot. Non appena il giocatore diventa attivo, il bonus viene accreditato subito in automatico.

### 12-4. Che cosa dà lo stato attivo per i referral?

Lo stato attivo è importante per la logica referral, perché il progetto lo usa come filtro di partecipazione reale e come protezione contro bot, bot farm e attività falsa.

### 12-5. Come è collegato Activ ai referral?

Activ mostra che l’utente è un partecipante reale del progetto e non un account bot. Questo è importante per il corretto funzionamento del sistema referral e per la protezione dalle bot farm.

### 12-6. Qual è il bonus base per ogni referral attivo?

Per ogni referral attivo vengono accreditati 0.1 EFHC nel saldo bonus.

### 12-7. Perché vedo i miei referral ma il bonus non è stato accreditato?

Il bonus viene accreditato solo per i referral attivi, cioè per chi ha acquistato almeno un pannello e ha ottenuto Activ. Controlla le schede “Attivi” e “Inattivi”: spesso gli invitati non sono ancora passati alla fase attiva.

### 12-8. Dove vengono accreditati gli 0.1 EFHC per un referral attivo?

Il bonus di 0.1 EFHC viene accreditato nel saldo bonus. È una ricompensa interna del sistema referral ed è visibile nel saldo bonus e nella cronologia delle operazioni.

### 12-9. Perché l’invitato è nell’elenco ma non viene considerato attivo?

Perché diventa attivo solo dopo l’attivazione del primo pannello e dopo aver ottenuto Activ. Fino a quel momento rimane nella parte inattiva dell’elenco.

### 12-10. Dove posso trovare il mio link referral?

Nella sezione Referrals: lì vengono mostrati il tuo link referral e l’elenco degli invitati.

### 12-11. È consentito creare account aggiuntivi tramite il proprio link referral?

Sì. Le regole del progetto non lo vietano. Tuttavia, creare account vuoti non ti porterà alcun vantaggio. L’economia del sistema è costruita in modo tale che i bonus referral e la crescita del ranking vengano accreditati solo per un partecipante con stato Activ, cioè dopo che l’account invitato entra davvero nel gioco e attiva almeno un pannello.

### 12-12. Posso cambiare il mio invitante dopo la registrazione?

No. Il legame referral viene fissato al momento del tuo primo ingresso nel progetto tramite un link di invito e non può essere modificato in seguito.

## 13. Hub

### 13-1. Che cosa posso fare in Hub?

In Hub sono disponibili schede che portano alle azioni collegate al progetto: il passaggio al flusso esterno per ottenere EFHC e il passaggio alla collezione esterna di VIP NFT.

### 13-2. A cosa serve Hub?

Hub serve come navigation layer per passaggi rapidi verso azioni collegate e flussi esterni del progetto.

### 13-3. Quali schede ci sono in Hub?

Nella fase attuale in Hub sono disponibili due schede: EFHC e VIP.

### 13-4. Che cosa fa la scheda EFHC?

La scheda EFHC avvia il passaggio al flusso esterno per ottenere EFHC.

### 13-5. Dove viene accreditato il top-up di EFHC dopo la conferma?

Un top-up di EFHC jetton viene accreditato sul saldo principale.

### 13-6. Perché il risultato del top-up potrebbe non apparire subito?

Prima deve essere confermata la fase esterna dell’operazione, poi il risultato viene aggiornato. Controlli Hub, il saldo principale e la cronologia delle operazioni.

### 13-7. Se ho ricevuto un VIP NFT tramite GetGems, dove posso vedere che è attivo?

Controlli lo stato VIP nell’app e la presenza dell’NFT nel wallet collegato.

### 13-8. Ho completato il flusso esterno da Hub, ma non c’è alcun risultato. Che cosa devo fare?

Controlli Hub, il saldo principale e la cronologia delle operazioni. Se ancora non c’è risultato, l’operazione non è stata ancora recepita oppure richiede un’elaborazione separata.

### 13-9. Su quale saldo arriva un top-up tramite Top Up e Hub?

Un top-up di EFHC jetton viene accreditato sul saldo principale.

### 13-10. Mi serve un wallet collegato per le azioni di Hub?

Per le azioni esterne basate su wallet è necessario un Wallet collegato. Hub stesso si apre senza un acquisto separato e funge da punto di passaggio.

### 13-11. Dove posso verificare che il top-up di EFHC sia stato davvero accreditato?

Controlli il saldo principale e la cronologia delle operazioni: lì deve comparire una traccia del top-up.

### 13-12. Ci sono skin in Hub?

Le skin non sono schede di Hub.

### 13-13. Come ottengo le skin del progetto?

Le skin si sbloccano man mano che l’account progredisce e sono legate ai 12 livelli di achievement.

## 14. Navigazione e regole

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Quali schermate dovrei aprire per prime se entro nella WebApp per la prima volta o dopo una lunga pausa?

È meglio iniziare dalla schermata principale, dalla barra superiore e dal profilo. Dopo sarà più facile passare a Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History e Hub in base al compito attuale.

### 14-3. Come capisco in quale sezione cercare la funzione che mi serve?

Si orienti in base al significato dell’azione: Profile — per i dati dell’account e le informazioni di riferimento, Wallet — per il wallet, Panels — per i pannelli, Energy — per la generazione, Exchange — per lo scambio, Withdraw — per i prelievi, Tasks — per i compiti, Referrals — per gli utenti invitati, e Hub — per i passaggi verso azioni collegate a EFHC e VIP.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Pubblicità

### 15-1. Che cos’è questa sezione?

La sezione Ads è una sottosezione dentro Tasks. Mostra le azioni pubblicitarie disponibili tramite cui l’utente può ottenere monete bonus aggiuntive.

### 15-2. Che cosa mi dà?

Dà solo monete bonus per le visualizzazioni, se la pubblicità è attualmente disponibile per l’account dell’utente.

### 15-3. Perché qui non c’è nulla?

Se la sezione è vuota, significa che per l’account dell’utente al momento non ci sono offerte attive oppure la pubblicità è temporaneamente disattivata.

### 15-4. Dove si trova la sezione Ads?

La sezione Ads si trova come sottosezione dentro Tasks. È una delle possibilità aggiuntive del blocco delle attività.

### 15-5. Che tipo di ricompensa dà Ads?

Ads dà solo monete bonus per le visualizzazioni. Non è saldo principale né prelievo diretto, ma un modo interno aggiuntivo per rafforzare il percorso di gioco.

### 15-6. Perché Ads è utile?

Perché è una fonte aggiuntiva di monete bonus. Non sostituisce i pannelli e la generazione, ma può aiutare a rafforzare più velocemente il ciclo di gioco interno.

### 15-7. Perché altri hanno la pubblicità e io no?

Perché le offerte possono non essere disponibili per uno specifico account oppure la pubblicità può essere temporaneamente disattivata. Un Ads vuoto non significa che l’account sia rotto.

### 15-8. Che cosa fare se ho completato un’azione in Ads ma non vedo il risultato?

Controlla: aggiorna Tasks/Ads → verifica il saldo bonus → verifica la cronologia delle operazioni.

### 15-9. Perché in Ads utenti diversi possono avere offerte diverse?

Perché le offerte dipendono dalla disponibilità delle campagne pubblicitarie per il singolo account. È normale: un utente può avere offerte, un altro temporaneamente no.

### 15-10. Bisogna comprare qualcosa per usare Ads?

No. Ads è un modo per ottenere EFHC bonus e non richiede acquisti obbligatori.

## 16. Ranks

### 16-1. Perché per me è importante crescere nel ranking?

La crescita nel ranking mostra come appare il tuo progresso rispetto agli altri partecipanti. Questo aiuta a capire la tua posizione attuale e a vedere quanto attivamente si sviluppa l’account.

### 16-2. In cosa il livello è diverso dalla classifica?

Il livello mostra il progresso personale all'interno del sistema, mentre la classifica mostra la posizione dell'utente rispetto agli altri partecipanti.

### 16-3. Come sono collegati tra loro il livello e la classifica?

Sono collegati dalla stessa logica generale di crescita attraverso la generazione di kWh da parte dei pannelli e dalla barra di progresso complessiva nella pagina Energy.

### 16-4. La classifica è solo un bel numero?

No. La classifica aiuta a capire come appare il tuo percorso rispetto a quello degli altri partecipanti.

### 16-5. Che cosa influisce sulla crescita della mia posizione nel ranking?

Sulla crescita della tua posizione nel ranking influisce il progresso generale dell’account: sviluppo dei panels, generazione di kWh e movimento complessivo lungo il percorso energetico del progetto.

### 16-6. Si può crescere contemporaneamente di livello e in classifica?

Sì. Quando l'utente sviluppa i pannelli, la generazione e il progresso energetico complessivo, di solito rafforza sia il proprio livello sia la propria posizione in classifica.

### 16-7. Perché ho un livello alto ma il mio posto in classifica non è il primo?

Perché la classifica è una posizione tra tutti i partecipanti, non solo il tuo progresso personale. Anche gli altri giocatori crescono, quindi il tuo posto può cambiare.

### 16-8. Perché il mio ranking può spostarsi anche senza nuove azioni da parte mia?

Perché il ranking non esiste da solo, ma in confronto con tutti i partecipanti. Mentre tu non cambi nulla, gli altri utenti continuano comunque a crescere, e questo influisce sulla tua posizione.

### 16-9. Dove posso vedere la mia posizione in classifica?

Nella sezione Ranks, dove viene mostrata la tua posizione rispetto agli altri partecipanti.

### 16-10. Perché il mio ranking può scendere anche se sto facendo progressi?

Perché per il ranking conta non solo la tua crescita, ma anche la velocità di crescita degli altri partecipanti. Anche se il tuo account si rafforza, la tua posizione può scendere quando gli altri ti superano più velocemente.

## 17. Stato Activ

### 17-1. Che cosa significa lo stato Activ?

Activ è uno stato attivo permanente. Significa che il gioco è iniziato davvero, perché è stato acquistato almeno un pannello.

### 17-2. Come si ottiene Activ?

Per ottenere Activ è sufficiente attivare un pannello. Dopo questa attivazione, lo stato viene assegnato in modo permanente.

### 17-3. Activ è temporaneo o permanente?

Activ è uno stato permanente.

### 17-4. Activ rimane se il pannello in seguito passa in Archive?

Sì. Anche se in seguito il pannello passa in Archive, lo stato Activ rimane.

### 17-5. Perché Activ è importante?

Activ aiuta a distinguere i giocatori reali dalle registrazioni casuali, dai bot e dalle bot farm. Conferma la partecipazione reale dell'utente al progetto.

### 17-6. Activ può scomparire più tardi?

No. Activ è uno stato permanente e rimane anche se il primo pannello in seguito passa in Archive.

### 17-7. Perché Activ è necessario per la protezione da bot e bot farm?

Perché Activ conferma una partecipazione reale, non un account vuoto creato per gonfiare artificialmente i numeri. Questo rende più onesti il sistema referral e l'economia del progetto.

### 17-8. Che cosa cambia nell'account dopo aver ottenuto Activ?

L'account viene considerato come quello di un partecipante reale e confermato del progetto. Questo influisce sul funzionamento corretto dei referral e sulla fiducia nell'attività dell'utente.

### 17-9. Perché Activ appare proprio dopo il primo pannello?

Perché l'attivazione del primo pannello è un segnale chiaro di partecipazione reale. Il progetto usa questo passaggio come filtro contro gli account vuoti.

### 17-10. Si può perdere Activ a causa dell'inattività?

No. Activ è uno stato permanente e non scompare a causa dell'inattività.

## 18. VIP NFT

### 18-1. Che cos'è EFHC VIP NFT?

EFHC VIP NFT è una carta club, una chiave per tutto il futuro ecosistema EFHC, un segno digitale di appartenenza e una chiave per le future opportunità del progetto.

### 18-2. Che cosa dà il possesso di un EFHC VIP NFT?

Il possesso di un EFHC VIP NFT aumenta la generazione di tutti i pannelli del giocatore.

### 18-3. Da quali segnali si vede che VIP è già preso in considerazione?

Se il sistema ha già preso in considerazione il VIP NFT, nell’interfaccia è visibile lo stato VIP e diventano evidenti i vantaggi collegati dell’account.

### 18-4. Dove vedrò l'effetto VIP?

L'effetto VIP è visibile nelle sezioni in cui il progetto tiene conto dei vantaggi del VIP NFT, così come nella barra superiore e nel Profilo/Impostazioni.

### 18-5. Bisogna attivare manualmente il VIP?

No. La logica del progetto è pensata per controllare automaticamente il wallet e aggiornare automaticamente lo stato VIP dopo aver rilevato l'NFT nella collezione corretta.

### 18-6. Avere 2 o 3 VIP NFT dà privilegi aggiuntivi al giocatore?

No. Per il giocatore, avere 2 o 3 VIP NFT non dà privilegi aggiuntivi oltre a quelli di un solo VIP NFT.

### 18-7. Perché il secondo VIP NFT non aumenta l'effetto?

Nel progetto il VIP aumenta la generazione come un unico stato attivo. I VIP NFT aggiuntivi non aumentano ulteriormente l'effetto, per evitare che il bonus cresca in modo incontrollato.

### 18-8. Il VIP influisce su un pannello o su tutti?

Il VIP influisce sulla generazione di tutti i pannelli dell'utente, non di uno solo.

### 18-9. Come posso verificare che VIP influenzi davvero l’account?

Controlla non solo la presenza dello stato VIP, ma anche i vantaggi collegati nella meccanica dell’account, soprattutto nei punti in cui viene considerato l’effetto VIP, inclusa la generazione.

### 18-10. Serve un wallet collegato perché il bot veda il mio VIP NFT?

Sì. Per vedere il VIP NFT, il bot deve capire quale wallet appartiene all'account. Per questo il Wallet deve essere collegato e poi va controllato lo stato.

### 18-11. Posso gestire il mio VIP NFT come voglio?

Sì. L’EFHC VIP NFT può essere trasferito, regalato e venduto sui marketplace.

### 18-12. Se vendo o trasferisco il mio VIP NFT a un altro wallet, cosa succederà alla mia generazione?

Il bot esegue regolarmente la scansione della blockchain e verifica la presenza dell’NFT sul tuo wallet collegato. Se vendi, regali o sposti il tuo VIP NFT su un altro indirizzo, il sistema lo rileverà, disattiverà il tuo stato VIP e la generazione di tutti i tuoi pannelli tornerà automaticamente alla tariffa base.

## 19. Livelli

### 19-1. Perché dovrei aumentare di livello?

La crescita di livello mostra i progressi dell'utente all'interno del progetto e aiuta a vedere come si sviluppa l'account. È un indicatore sia visivo sia sostanziale del percorso.

### 19-2. Che cosa include la sezione Livelli?

La sezione Livelli mostra tutte le scale di crescita del progetto: 12 livelli di progresso energetico, 6 livelli del sistema referral e altre linee di crescita a livelli.

### 19-3. Quanti livelli di progresso energetico ci sono nel progetto?

Nel progetto sono previsti 12 livelli di progresso energetico.

### 19-4. Quanti livelli ci sono nel sistema referral?

Nel progetto sono previsti 6 livelli del sistema referral: da 0 a 5.

### 19-5. In che modo i livelli sono utili per un giocatore normale?

I livelli aiutano a capire dove ti trovi ora, quanto hai già fatto, verso cosa andare dopo e quale traguardo ti aspetta in seguito.

### 19-6. Come sono collegati i livelli energetici, i livelli referral e la crescita complessiva dell'account?

Sono parti di un unico percorso generale. La generazione di energia spinge il progresso principale, i referral attivi rafforzano la linea referral e insieme mostrano l'evoluzione dell'account.

### 19-7. Eco Initiate (0 kWh)

**Significato per il giocatore:** Il tuo primo pannello è installato ed è pronto a lavorare. Stai facendo il passo principale per diventare un produttore indipendente di energia pulita.

**Che cosa significa in pratica:** Questo è il punto di partenza del tuo percorso energetico in EFHC. Il sistema riconosce che hai già avviato il processo di generazione con i pannelli.

### 19-8. Hope Bringer (100 kWh)

**Significato per il giocatore:** I primi kilowatt sono arrivati! I tuoi pannelli generano con successo energia verde, dando alla natura speranza per un futuro senza carbonio.

**Che cosa significa in pratica:** Hai superato la soglia iniziale di generazione e il tuo progresso energetico sta già diventando visibile nel sistema.

### 19-9. Energy Seeker (300 kWh)

**Significato per il giocatore:** Il sistema funziona molto bene e fornisce in modo stabile elettricità ecologicamente pulita. Ogni unità di energia prodotta dai pannelli ti avvicina a un ruolo importante nel futuro energetico.

**Che cosa significa in pratica:** Hai accumulato un volume tangibile di generazione e il tuo account non è più all'inizio del percorso.

### 19-10. Nature's Voice (600 kWh)

**Significato per il giocatore:** Il tuo contributo sta diventando visibile. Generando energia con tecnologie verdi, diventi la voce della natura e dimostri che uno sviluppo pulito è reale.

**Che cosa significa in pratica:** La tua generazione è già abbastanza alta da mostrare una dinamica stabile di crescita.

### 19-11. Earth Ally (1000 kWh)

**Significato per il giocatore:** È stato generato il primo megawattora! I tuoi pannelli hanno prodotto un volume importante di energia pulita. Ora sei un partecipante significativo al percorso energetico.

**Che cosa significa in pratica:** Hai raggiunto la soglia simbolica del primo grande traguardo energetico.

### 19-12. Climate Fighter (2000 kWh)

**Significato per il giocatore:** La tua generazione infligge un colpo reale al cambiamento climatico. Ogni kilowatt prodotto riduce direttamente il bisogno di energia da fonti inquinanti.

**Che cosa significa in pratica:** Il tuo volume di generazione è già abbastanza grande da essere percepito come un contributo serio.

### 19-13. Green Sentinel (3500 kWh)

**Significato per il giocatore:** Il flusso stabile di energia dei tuoi pannelli difende l'aria pulita. Stai portando un beneficio tangibile alla società senza fermarti ai primi successi.

**Che cosa significa in pratica:** Hai consolidato una traiettoria forte di crescita energetica e continui a salire.

### 19-14. Planet Defender (5000 kWh)

**Significato per il giocatore:** 5000 kWh di generazione pulita! La potenza dei tuoi pannelli lavora come uno scudo invisibile che protegge l'atmosfera da migliaia di chilogrammi di emissioni dannose.

**Che cosa significa in pratica:** Hai raggiunto un livello elevato di contributo energetico e il tuo progresso appare ormai convincente.

### 19-15. Eco Champion (7500 kWh)

**Significato per il giocatore:** Volumi di produzione eccezionali! Sei un vero campione dell'energia verde, il cui contributo cambia in modo percepibile il panorama energetico globale.

**Che cosa significa in pratica:** Hai superato una soglia molto seria di generazione e sei entrato nella categoria dei partecipanti più forti.

### 19-16. Planet Saver (10000 kWh)

**Significato per il giocatore:** 10 megawattora! Hai generato così tanta energia pulita da contribuire letteralmente alla salvaguardia di interi ecosistemi, dimostrando la massima forza del tuo sviluppo energetico.

**Che cosa significa in pratica:** Hai raggiunto uno dei traguardi chiave dell'intero percorso energetico.

### 19-17. Green Commander (15000 kWh)

**Significato per il giocatore:** Ammiraglia della generazione ecologica. I tuoi pannelli alimentano il futuro e gli impressionanti volumi di produzione fissano standard completamente nuovi di progresso energetico.

**Che cosa significa in pratica:** Sei già al di sopra del livello di crescita standard e ti stai avvicinando al picco del sistema.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Livello referral 0

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** da 0 a 1 referral attivi.

### 19-20. Livello referral 1

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** da 2 a 3 referral attivi.

### 19-21. Livello referral 2

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** da 4 a 5 referral attivi.

### 19-22. Livello referral 3

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** da 6 a 10 referral attivi.

### 19-23. Livello referral 4

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** da 11 a 25 referral attivi.

### 19-24. Livello referral 5

**Significato per il giocatore:** È il segno della tua crescita nel sistema referral: mostra la scala degli utenti invitati attivi.

**Regola esatta:** più di 25 referral attivi.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Perché i nomi dei livelli sono legati all’ecologia e al pianeta?

Perché l’idea stessa del gioco è legata all’energia verde virtuale, alla motivazione delle persone e a un contributo simbolico alla guarigione del pianeta Terra.

## 20. FAQ / Aiuto

### 20-1. Dove si apre il FAQ?

Il FAQ si apre dal profilo come sezione di aiuto integrata del bot, dove sono raccolte le risposte sulle azioni principali, sulle schermate e sulle regole del progetto.

### 20-2. A che cosa serve FAQ / Aiuto?

Questa sezione serve per permettere all'utente di trovare rapidamente risposte chiare, numeri precisi, regole reali del progetto e il significato delle azioni principali senza inutili ricerche.

### 20-3. Perché il FAQ è descritto in modo così dettagliato?

Perché il progetto è multilivello e una guida breve e secca non copre le vere domande del giocatore. Qui contano significato, chiarezza, numeri precisi e collegamento tra le sezioni.

### 20-4. Dal FAQ si può capire tutto il percorso del giocatore dentro il bot?

Sì. Un buon FAQ deve spiegare non solo i singoli pulsanti, ma l'intero percorso: dal primo pannello fino a energia, exchange, saldi, livelli, stati e meccaniche aggiuntive.

### 20-5. Che cosa devo fare se non trovo subito la risposta?

È meglio aprire una sezione vicina per significato e guardare le domande accanto. In un bot grande molte risposte sono collegate tra loro e un blocco spesso completa l'altro.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. Che cosa controllare se «sembra tutto rotto»?

Controlla tre cose: 1) Wallet — se il wallet è collegato e se quello principale è selezionato, 2) saldi e cronologia — se lì c'è traccia della tua operazione, 3) la sezione giusta — se stai guardando esattamente la schermata in cui dovrebbe comparire il risultato.

### 20-8. Qual è il modo più rapido per capire che cosa è successo ai miei EFHC?

Apri la cronologia del saldo. La cronologia mostra che cosa ha cambiato esattamente i saldi: ricompensa, acquisto, exchange o withdraw.

### 20-9. Da dove cominciare se apro il bot per la prima volta e non capisco nulla?

Inizia da Energy (schermata principale), poi apri Panels, controlla saldi e cronologia, e solo dopo decidi se ti servono il wallet e il deposito.

### 20-10. Come trovare più velocemente la domanda giusta nel FAQ?

Il modo più rapido è aprire la sezione tematica corretta (Wallet / Panels / Exchange / Withdraw ecc.) e cercare lì la domanda. Se non sei sicuro, inizia dalle sezioni più generali e poi restringi.
