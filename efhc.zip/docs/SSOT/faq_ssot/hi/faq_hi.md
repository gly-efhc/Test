# EFHC FAQ (HI) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. परियोजना के बारे में

### 1-1. EFHC क्या है?

EFHC बॉट के अंदर ऊर्जा, प्रगति और अकाउंट के विकास पर आधारित एक गेम प्रोजेक्ट है। उपयोगकर्ता पैनल खरीदता है, ऊर्जा जमा करता है, उसे EFHC में Exchange करता है, बैलेंस पर नज़र रखता है, स्तरों में आगे बढ़ता है, रैंकिंग में ऊपर जाता है और प्रोजेक्ट की अतिरिक्त सुविधाओं का उपयोग करता है।

अर्थ:
— EFHC — Energy for Humanity Coin
— EFHCm — मुख्य कॉइन्स
— EFHCb — बोनस कॉइन्स
— EFHCj — बाहरी EFHC jetton
— EFHC — कुल बैलेंस (बोनस + मुख्य)

### 1-2. यहाँ सब कुछ कैसे काम करता है?

प्रोजेक्ट के अंदर सब कुछ ऊर्जा और अकाउंट के विकास के इर्द-गिर्द बना है। उपयोगकर्ता पैनलों के साथ काम करता है, ऊर्जा जमा करता है, उसे मुख्य EFHC में Exchange करता है, बैलेंस पर नज़र रखता है, वॉलेट जोड़ता है, अपनी प्रगति को मजबूत करता है और प्रोजेक्ट की अतिरिक्त mechanics का उपयोग करता है।

### 1-3. मुझे इस बॉट में क्या करना है?

मुख्य काम अपने अकाउंट को विकसित करना है। इसके लिए उपयोगकर्ता पैनलों के साथ काम करता है, ऊर्जा generation पर नज़र रखता है, Exchange का उपयोग करता है, अपने बैलेंस देखता है, वॉलेट जोड़ता है, प्रोजेक्ट की अतिरिक्त mechanics में भाग लेता है और धीरे-धीरे अपनी प्रगति मजबूत करता है।

### 1-4. यहाँ बढ़ना और आगे बढ़ना कैसे होता है?

बॉट के अंदर विकास ऊर्जा और सक्रियता पर आधारित है। उपयोगकर्ता के पास जितने अधिक पैनल, ऊर्जा, उपयोगी actions और प्रगति होगी, अकाउंट उतना ही मजबूत होगा और वह levels तथा rank system में उतना ही ऊपर जाएगा।

### 1-5. प्रोजेक्ट का मुख्य अर्थ क्या है?

प्रोजेक्ट का मुख्य अर्थ panel activation से लेकर ऊर्जा generation तक, और फिर EFHC में परिणाम तक का रास्ता दिखाना है। उपयोगकर्ता को सिर्फ अमूर्त संख्याएँ नहीं दिखतीं, बल्कि एक जुड़ी हुई श्रृंखला दिखती है: panel, energy, Exchange, balance, progress, levels और दूसरे प्रतिभागियों के बीच उसकी position।

### 1-6. क्या यह सिर्फ मनोरंजन है या यहाँ विकास की कोई logic भी है?

यहाँ विकास की पूरी logic है। उपयोगकर्ता सिर्फ बटन नहीं दबाता, बल्कि धीरे-धीरे अपने अकाउंट को मजबूत करता है: पैनल खरीदता है, generation शुरू करता है, Activ status प्राप्त करता है, rewards इकट्ठा करता है, referral system विकसित करता है और अपनी यात्रा का परिणाम देखता है।

### 1-7. मेरे पहले EFHC यहाँ कैसे आते हैं?

पहले EFHC दो मुख्य स्रोतों से आते हैं: rewards (बोनस कॉइन्स EFHCb में) और Exchange के ज़रिए energy का conversion (मुख्य कॉइन्स EFHCm में)। सबसे मजबूत रास्ता है — panels → energy → Exchange → main balance।

### 1-8. मेरे पास ऊर्जा कहाँ से आती है?

ऊर्जा आपके active panels से आती है। जब तक panels active हैं, वे energy generate करते हैं, और यह Exchange के लिए उपलब्ध ऊर्जा के रूप में जमा होती रहती है।

### 1-9. प्रोजेक्ट में मेरी growth पर सबसे ज़्यादा क्या असर डालता है?

सबसे बड़ा असर active panels की संख्या और उनकी कुल generation का होता है। दूसरा booster — VIP है (यदि आपके पास है), क्योंकि वह generation को प्रभावित करता है। Tasks, ads और referrals उपयोगी जोड़ हैं, लेकिन आधार नहीं।

### 1-10. मैं कैसे समझूँ कि मैं सही दिशा में बढ़ रहा हूँ?

यदि तीन चीज़ें बढ़ रही हैं — generation, उपलब्ध energy, और Exchange के बाद main balance — तो आप सही दिशा में आगे बढ़ रहे हैं। इसे जल्दी जाँचने के लिए Energy और operation history देखी जा सकती है।

## 2. मुख्य स्क्रीन

### 2-1. मुख्य स्क्रीन क्या दिखाती है?

मुख्य स्क्रीन Energy page है। यह अकाउंट की वर्तमान स्थिति के मुख्य elements को एक जगह लाती है: quick actions, progress की जानकारी और बॉट के महत्वपूर्ण sections में जाने के entry points।

### 2-2. मुख्य स्क्रीन की ज़रूरत क्यों है?

यह इसलिए ज़रूरी है ताकि उपयोगकर्ता अपने अकाउंट की सबसे महत्वपूर्ण जानकारी तुरंत देख सके और जल्दी समझ सके कि उसकी वर्तमान स्थिति क्या है, progress कैसी है और आगे क्या किया जा सकता है।

### 2-3. सबसे पहले किस चीज़ पर ध्यान देना चाहिए?

पहले top bar, total balance, Energy screen और उपलब्ध actions को देखना चाहिए। यही सबसे तेज़ी से अकाउंट की वर्तमान स्थिति और अगले कदम को दिखाते हैं।

### 2-4. मेरी वर्तमान प्रगति कहाँ दिखाई देती है?

वर्तमान progress बॉट के उन sections में दिखाई देती है जो energy, panels, levels और ranking से जुड़े हैं। उन्हीं से पता चलता है कि उपयोगकर्ता प्रोजेक्ट के अंदर कैसे आगे बढ़ रहा है।

### 2-5. मुख्य स्क्रीन हर दिन क्यों महत्वपूर्ण है?

क्योंकि यहीं सबसे जल्दी पता चलता है कि अकाउंट में क्या बदला है: अभी कितनी energy है, कितने active panels हैं, progress कैसे बढ़ रही है और अगला कदम क्या हो सकता है।

### 2-6. शुरुआत कहाँ से करना बेहतर है?

पहले top bar देखें, समझें कि आपके कौन-कौन से balances हैं, फिर Energy page खोलें, Panels section देखें और उसके बाद मुख्य actions के बारे में FAQ पढ़ें। यदि किसी ज़रूरी action के लिए wallet चाहिए, तो अगला कदम उसे connect करना होगा।

### 2-7. मुख्य स्क्रीन पर सबसे महत्वपूर्ण बटन कौन से हैं?

सबसे महत्वपूर्ण वे हैं जो मुख्य कार्रवाइयों तक ले जाते हैं: Panels और Exchange, साथ ही ऊपरी बार के तेज़ बटन — Top Up और Hub — अगर आप EFHC और VIP से जुड़ी कार्रवाइयाँ खोलना चाहते हैं।

### 2-8. मुझे मुख्य स्क्रीन पर हर दिन क्या जाँचना चाहिए?

तीन चीज़ें: 1) कितने active panels हैं, 2) generation की speed क्या है, 3) Exchange के लिए कितनी available energy जमा हो चुकी है।

### 2-9. मुख्य स्क्रीन समय के साथ क्यों बदलती है?

क्योंकि यह अकाउंट की जीवित स्थिति को दिखाती है। जब panels, energy और operations दिखाई देते हैं, तो स्क्रीन खाली नहीं रहती और अधिक उपयोगी data तथा progress दिखाने लगती है।

### 2-10. मुख्य स्क्रीन से कैसे समझें कि अकाउंट विकसित हो रहा है?

जब आप वास्तविक वृद्धि देखते हैं: generation शून्य नहीं है, energy जमा हो रही है, और Exchange के बाद main balance बढ़ता है। यही विकास के सबसे ईमानदार संकेत हैं।

## 3. ऊपरी पैनल

### 3-1. ऊपरी पैनल क्या है?

ऊपरी पैनल इंटरफ़ेस की एक अलग इकाई और मुख्य तेज़ जानकारी ब्लॉक है, जो बॉट के मुख्य पन्नों पर उपलब्ध रहता है.

### 3-2. ऊपरी बार में क्या दिखता है?

ऊपरी बार में अवतार, नाम, ऊर्जा प्रगति स्तर, VIP स्थिति, कुल बैलेंस, Top Up बटन और Hub बटन दिखते हैं।

### 3-3. ऊपरी पैनल महत्वपूर्ण क्यों है?

क्योंकि यह बिना अतिरिक्त sections खोले अकाउंट की सबसे ज़रूरी जानकारी तुरंत दिखा देता है: आप कौन हैं, आपकी progress क्या है, VIP है या नहीं, कुल कितने coins हैं और अभी कौन-से quick actions उपलब्ध हैं.

### 3-4. ऊपरी पैनल में कुल balance क्या दिखाता है?

कुल balance यह दिखाता है कि कुल मिलाकर आपके पास कितने coins हैं। यह सुविधा के लिए है, ताकि खरीदारी के लिए resources को अलग से जोड़ना न पड़े और गेम के अंदर अपनी स्थिति जल्दी समझ में आए.

### 3-5. कुल balance खरीदारी के लिए सुविधाजनक क्यों है?

क्योंकि यह गेम के अंदर खिलाड़ी की कुल purchasing power दिखाता है और जल्दी समझने में मदद करता है कि अंदरूनी actions के लिए resources पर्याप्त हैं या नहीं.

### 3-6. कुल balance उस राशि के बराबर क्यों नहीं है जिसे अभी तुरंत withdraw किया जा सकता है?

क्योंकि कुल balance में main और bonus दोनों coins शामिल होते हैं। Bonus coins गेम की mechanics के लिए होते हैं और उन्हें सीधे withdraw नहीं किया जाता.

### 3-7. ऊपरी पैनल में “Top up” बटन का उपयोग कब करना चाहिए?

जब आप बिना अतिरिक्त सेक्शन खोले ऐप में उपलब्ध main balance top-up flow तक जल्दी पहुँचना चाहते हैं, तब इस बटन का उपयोग करें।

### 3-8. ऊपरी बार से Hub क्यों खोलें?

ताकि प्रोजेक्ट की संबंधित कार्रवाई कार्ड जल्दी खुल सकें और इंटरफ़ेस में अतिरिक्त नेविगेशन के बिना ज़रूरी बाहरी फ़्लो में जाया जा सके।

### 3-9. ऊपरी पैनल अलग-अलग पन्नों पर क्यों दिखाई देता है?

क्योंकि यह अकाउंट का “dashboard” है: इसका काम हमेशा मुख्य चीज़ें दिखाना है — balance, statuses और quick actions — चाहे आप कोई दूसरा section ही क्यों न खोलें.

### 3-10. यदि ऊपरी पैनल का data गलत लगे तो क्या करना चाहिए?

पहले पेज को refresh करें और balance history देखें: वही operations के तथ्य दिखाती है। यदि history और balance मेल खाते हैं, तो data सही है; संभव है कि आप किसी दूसरे balance को देख रहे थे, जैसे total की जगह main.

## 4. प्रोफ़ाइल / सेटिंग्स

### 4-1. प्रोफ़ाइल / सेटिंग्स section क्या है?

प्रोफ़ाइल / सेटिंग्स वह section है जहाँ profile और bot settings को manage किया जाता है। यहाँ मुख्य statuses दिखाई देते हैं और इंटरफ़ेस की personal settings उपलब्ध होती हैं.

### 4-2. प्रोफ़ाइल में क्या किया जा सकता है?

प्रोफ़ाइल में मुख्य user settings और महत्वपूर्ण sections के लिए quick entries एक जगह होती हैं: Wallet, balance history, FAQ और दूसरे उपयोगी management points.

### 4-3. प्रोफ़ाइल / सेटिंग्स के ऊपरी हिस्से में क्या दिखता है?

प्रोफ़ाइल / सेटिंग्स के ऊपरी हिस्से में avatar, Telegram name और Activ तथा VIP statuses दिखते हैं, यदि वे पहले से उपलब्ध हैं.

### 4-4. भाषा कहाँ बदली जाती है?

भाषा प्रोफ़ाइल / सेटिंग्स में बदली जाती है.

### 4-5. प्रोफ़ाइल की ज़रूरत ही क्यों है?

प्रोफ़ाइल अकाउंट के लिए एक personal control point है। यहाँ उपयोगकर्ता केवल statuses नहीं देखता, बल्कि wallet, history, language और help से जुड़े महत्वपूर्ण subsections भी खोलता है.

### 4-6. प्रोफ़ाइल में balance history कहाँ खोलें?

प्रोफ़ाइल / सेटिंग्स section में balance history के लिए अलग entry होती है, जहाँ incoming और outgoing operations दिखाई देते हैं.

### 4-7. प्रोफ़ाइल में भाषा कहाँ बदलें?

Language switch प्रोफ़ाइल / सेटिंग्स में होता है, क्योंकि यह अकाउंट की personal setting है.

### 4-8. प्रोफ़ाइल में Wallet कहाँ खोलें ताकि wallet के साथ काम किया जा सके?

प्रोफ़ाइल सेक्शन में Wallet का अलग बिंदु है। जब wallet connect करना हो, binding जाँचनी हो या wallet से जुड़ी actions पर जाना हो, तब इसे खोलें।

### 4-9. अगर मुझे जवाब चाहिए तो प्रोफ़ाइल में FAQ जल्दी कहाँ खोलूँ?

प्रोफ़ाइल सेक्शन में FAQ का प्रवेश है। जब interface, balance, panels, energy, exchange, withdrawal या WebApp की दूसरी functions पर जल्दी जवाब चाहिए, तब उसे खोलें।

### 4-10. «Support and information» section में क्या होता है?

वहाँ help items एकत्र होते हैं: FAQ, hints / information और वह सब कुछ जो उपयोगकर्ता को बिना confusion के प्रोजेक्ट समझने में मदद करे.

### 4-11. प्रोजेक्ट का इंटरफ़ेस कितनी भाषाओं में उपलब्ध है?

बॉट का इंटरफ़ेस और सहायता प्रणाली (FAQ) 13 भाषाओं में अनुवादित हैं। आप प्रोफ़ाइल सेटिंग्स में अपनी सुविधाजनक भाषा चुन सकते हैं, और सिस्टम तुरंत सभी टेक्स्ट और इंटरफ़ेस को आपके चयन के अनुसार अनुकूलित कर देगा।

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. क्या मुख्य wallet बदला जा सकता है?

हाँ। उपयोगकर्ता पहले से जुड़े wallets में से कोई दूसरा wallet मुख्य के रूप में चुन सकता है.

### 5-3. क्या जुड़े हुए wallet को हटाया जा सकता है?

हाँ। यदि wallet की अब ज़रूरत नहीं है, तो उसकी binding हटाई जा सकती है.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. अगर मैं ऐसा action दबाऊँ जहाँ wallet चाहिए, लेकिन मेरे पास wallet न हो, तो क्या होगा?

यदि चुनी हुई function के लिए wallet ज़रूरी है, तो बॉट पहले wallet connection logic शुरू करेगा। उसके बाद आप उसी action पर लौटकर उसे सामान्य रूप से पूरा कर सकेंगे.

### 5-6. क्या कई wallets जोड़े जा सकते हैं और इसकी ज़रूरत क्यों पड़ती है?

हाँ। कई wallets जोड़े जा सकते हैं, ताकि आपके पास backup address हो या अलग-अलग usage scenarios को अलग रखा जा सके। लेकिन उनमें से एक wallet मुख्य चुना जाता है — वही उन operations में default रूप से उपयोग होता है जहाँ चुना हुआ address चाहिए.

### 5-7. अगर मैं मुख्य wallet बदल दूँ तो क्या होगा?

आप किसी दूसरे wallet को मुख्य के रूप में चुन सकेंगे। बदलाव के बाद system उन्हीं operations में नए मुख्य address का उपयोग करेगी जहाँ इसकी आवश्यकता है। Withdraw या purchase से पहले एक बार यह देख लेना बेहतर है कि अभी कौन-सा wallet मुख्य सेट है.

### 5-8. क्या non-primary wallet पर withdraw किया जा सकता है?

डिफ़ॉल्ट रूप से system मुख्य wallet पर निर्भर करती है। यदि आपको कोई दूसरा address चाहिए, तो पहले उसे Wallet में main बनाइए, और उसके बाद withdraw request भेजिए.

### 5-9. यदि wallet जुड़ा हुआ है, लेकिन withdraw फिर भी उपलब्ध नहीं है, तो क्या करें?

तीन चीज़ें जाँचें: क्या मुख्य wallet चुना गया है, क्या main balance पर्याप्त है, और क्या withdraw amount 10 EFHC से कम तो नहीं है.

### 5-10. यदि wallet अभी तक connect नहीं किया है, तो क्या फिर भी खेलना और आगे बढ़ना संभव है?

हाँ। Wallet कुछ operations के लिए ज़रूरी है, जैसे withdraw, लेकिन अकाउंट विकसित करना, इंटरफ़ेस समझना और progress जमा करना उसके बिना भी संभव है.

### 5-11. अगर मैं अपने मुख्य TON वॉलेट तक पहुँच खो दूँ तो मुझे क्या करना चाहिए?

क्योंकि प्रोजेक्ट कई वॉलेट जोड़ने की अनुमति देता है, आप Wallet सेक्शन में नया वॉलेट जोड़ सकते हैं, उसे मुख्य वॉलेट बना सकते हैं, और पुराने compromised पते को linked wallets की सूची से हमेशा के लिए हटा सकते हैं।

## 6. बैलेंस और हिस्ट्री

### 6-1. मेरे पास तीन अलग-अलग balances क्यों हैं?

क्योंकि बॉट के अंदर funds की भूमिकाएँ अलग-अलग हैं। Total balance सब कुछ साथ में दिखाता है, bonus balance internal game cycle के लिए होता है, और main balance वह परिणाम दिखाता है जिसे key operations और withdraw के लिए इस्तेमाल किया जा सकता है।

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Main balance क्या है?

Main balance मुख्य EFHC है। Game cycle का परिणाम इसी में बदलता है, और key operations, including withdraw, इसी balance से उपलब्ध होते हैं।

### 6-4. एक ही purchase bonus और main balance दोनों को क्यों छू सकती है?

प्रोजेक्ट के सभी आंतरिक खर्चों में राशि पहले बोनस बैलेंस से काटी जाती है। अगर वह पर्याप्त नहीं है, तो बाकी राशि मेन बैलेंस से काटी जाती है।

### 6-5. History में एक ही action की कई entries क्यों दिखती हैं?

एक ही operation funds की movement के कई हिस्सों को छू सकती है, इसलिए बॉट उसे कई lines में दिखाता है, ताकि हर बदलाव अलग से साफ दिखाई दे।

### 6-6. मैं कहाँ देखूँ कि EFHC कहाँ आए या कहाँ गए?

इसके लिए balance history section है। वहीं incoming, spending, Exchange, purchases, withdraw और funds के दूसरे changes दिखाई देते हैं।

### 6-7. Total balance बड़ा क्यों दिखता है, लेकिन मैं उससे कम क्यों withdraw कर सकता हूँ?

क्योंकि total balance main और bonus दोनों को जोड़ता है। Withdraw सिर्फ main balance से allowed है, जबकि bonus balance project के internal cycle के लिए है। इसलिए withdraw के लिए हमेशा main balance देखना चाहिए।

### 6-8. सबसे जल्दी कहाँ दिखता है कि मेरे balance में क्या बदला?

Balance history में। वहाँ साफ दिखता है कि कौन-सा operation incoming या spending लाया और किस balance को affect किया।

### 6-9. Bonus balance को सीधे withdraw क्यों नहीं किया जा सकता?

क्योंकि bonus coins project के internal cycle का हिस्सा हैं। Withdraw सिर्फ main balance से allowed है।

### 6-10. Withdraw या Exchange के बाद history हर जगह एक साथ क्यों नहीं बदलती?

क्योंकि अलग-अलग screens हमेशा एक ही पल में refresh नहीं होतीं। पहले section refresh करें, फिर balance देखें, और उसके बाद history check करें।

### 6-11. अगर कमजोर इंटरनेट के कारण मैं खरीद या exchange बटन को कई बार लगातार दबा दूँ, तो क्या अतिरिक्त कॉइन कटेंगे?

नहीं। अतिरिक्त कॉइन नहीं कटेंगे। सिस्टम के कोर में double debit से सुरक्षा के लिए सख्त सुरक्षा बनी हुई है। भले ही नेटवर्क अटकने की वजह से आप बटन 10 बार दबाएँ, ऑपरेशन की execution ठीक एक बार ही होगी।

## 7. Panels

### 7-1. एक panel को activate करने के लिए कितने EFHC चाहिए?

एक panel को activate करने के लिए 100 EFHC चाहिए।

### 7-2. पहला panel activate करते ही क्या मिलता है?

पहला panel activate करते ही energy generation शुरू हो जाती है, progress का रास्ता खुलता है, main EFHC तक पहुँच बनती है और स्थायी Activ status मिलता है।

### 7-3. Panel की generation कब शुरू होती है?

Panel खरीदने के तुरंत बाद generation शुरू हो जाती है।

### 7-4. एक panel का life cycle कितना होता है?

हर panel का 180-day cycle होता है।

### 7-5. 180-day cycle पूरा होने के बाद panel के साथ क्या होता है?

180-day cycle पूरा होने के बाद panel deactivate हो जाता है और participant की energy progress history के लिए Archive में चला जाता है।

### 7-6. Interface में panels की कौन-सी दो states होती हैं?

Interface में Activ और Archive होती हैं। Activ वे panels हैं जो generation में भाग लेते हैं। Archive वे panels हैं जिन्होंने active cycle पूरा कर लिया है और history संभाल कर रखते हैं।

### 7-7. क्या मैं एक से ज़्यादा panel activate कर सकता हूँ?

हाँ। आप panels को क्रम से activate कर सकते हैं और active panels की संख्या बढ़ा सकते हैं। जितने ज़्यादा active panels होंगे, उतनी ज़्यादा total energy generation होगी और progress उतनी तेज़ बढ़ेगी।

### 7-8. Panel पर दिखने वाला «Remaining» timer क्या बताता है?

यह timer दिखाता है कि panel के 180-day cycle के अंत तक कितना समय बचा है। समय पूरा होते ही panel अपने-आप Archive में चला जाएगा और active नहीं रहेगा।

### 7-9. पहला panel activate करने के बाद मैं Activ क्यों बन गया?

क्योंकि Activ real participation की पुष्टि है और project को bots से बचाने में मदद करता है। Project Activ status को पहले panel की activation से जोड़ता है, ताकि यह status सिर्फ जीवित participants को मिले।

### 7-10. Active panels Archive panels से ज़्यादा महत्वपूर्ण क्यों हैं?

क्योंकि active panels अभी energy generate करते हैं — वही आपकी वर्तमान growth speed तय करते हैं। Archive panels history संभालते हैं, लेकिन current generation नहीं देते।

### 7-11. मैंने जितने panels activate किए, active उससे कम क्यों दिख रहे हैं?

क्योंकि कुछ panels 180-day term पूरा करके Archive में जा चुके हो सकते हैं। Active panels वे हैं जो अभी काम कर रहे हैं। Archive panels current generation नहीं देते।

### 7-12. क्या active panels 1000 limit की वजह से “गायब” हो सकते हैं?

नहीं। 1000 limit का मतलब सिर्फ इतना है कि एक समय में 1000 से ज़्यादा active panels नहीं हो सकते। पहले से activate किए हुए active panels गायब नहीं होते: वे term पूरा होने तक active रहते हैं, फिर Archive में जाते हैं।

### 7-13. अगर मैंने panel activate किया, लेकिन generation तुरंत नहीं बदली, तो क्या करूँ?

Panels section refresh करें, देखें कि panel Active list में आया या नहीं, फिर Energy खोलकर generation speed check करें, और balance history में 100 EFHC की spending entry देखें।

### 7-14. क्या मैं panel activate कर सकता हूँ अगर मेरे पास 100 EFHC से कम हैं?

नहीं। Panel activate करने के लिए 100 EFHC चाहिए। यदि funds कम हैं, तो activation नहीं होगी।

### 7-15. Archive panels महत्वपूर्ण क्यों हैं, अगर वे अब generate नहीं करते?

क्योंकि Archive आपके panels और पूरे हुए cycles की history रखता है। यह आपकी growth biography है, लेकिन current generation सिर्फ active panels देते हैं।

### 7-16. क्या panel activate करते ही मैं देख सकता हूँ कि वह active है?

हाँ। Activate किया गया panel Active list में दिखना चाहिए, और उसकी activation balance history में भी reflect होनी चाहिए।

### 7-17. 180 दिनों में एक panel कितनी energy देता है?

Base rate पर एक panel 180 दिनों में 107.61984000 kWh देता है। EFHC VIP NFT होने पर generation 115.24032000 kWh होती है।

## 8. Energy

### 8-1. Energy page क्या दिखाती है?

Energy page energy progress, generation progress bar, active panels की संख्या, panels की total generation per second और current state के दूसरे key indicators दिखाती है।

### 8-2. Energy page का progress bar क्या दिखाता है?

Progress bar खिलाड़ी की progress का रास्ता 12 levels की scale पर अगले स्तर तक दिखाता है।

### 8-3. Panels की total generation per second का क्या मतलब है?

यह basic या VIP generation constant को active panels की संख्या से multiply करने का परिणाम है।

### 8-4. Energy इतनी महत्वपूर्ण क्यों है?

क्योंकि Energy EFHC में progress की केंद्रीय नींव है। इसी के ज़रिए user panels से उस परिणाम तक पहुँचता है जो balance, levels, rating और account development को affect करता है।

### 8-5. क्या Energy से समझा जा सकता है कि account कितना मजबूत है?

हाँ। Energy page बहुत जल्दी दिखाती है कि system अभी कितनी मजबूत है: कितने panels काम कर रहे हैं, अभी कितनी generation चल रही है, कितनी energy जमा हो चुकी है और user अगले level से कितना दूर है।

### 8-6. Available energy और main balance अलग-अलग क्यों गिने जाते हैं?

क्योंकि ये दो अलग इकाइयाँ हैं। Available energy जमा हुए kWh दिखाती है, जबकि main balance पहले से प्राप्त main EFHC दिखाता है। ये मान आपस में जुड़े हैं, लेकिन एक ही चीज़ नहीं हैं।

### 8-7. Energy अपने आप बढ़ती है, लेकिन main balance अपने आप क्यों नहीं बढ़ता?

क्योंकि energy का accumulation और main balance की growth अलग-अलग चरणों में होती है। पहले panels energy बनाते हैं, और main balance केवल किसी अलग exchange action या main EFHC credit करने वाले दूसरे scenario के बाद बढ़ता है।

### 8-8. Generation per second की speed क्या दिखाती है?

यह दिखाती है कि आपके active panels अभी किस गति से energy बना रहे हैं। यही आपकी current growth speed है।

### 8-9. Energy में रोज़ कौन-सी चीज़ें सबसे ज़रूरी track करनी चाहिए?

तीन चीज़ें: active panels की संख्या, generation speed और available energy। यही account state के मुख्य daily indicators हैं।

### 8-10. Energy से कैसे समझूँ कि मेरे panels सच में काम कर रहे हैं?

यदि Energy में active panels दिख रहे हैं, generation zero नहीं है और available energy धीरे-धीरे बढ़ रही है, तो panels काम कर रहे हैं। यदि generation 0 है और energy नहीं बढ़ रही, तो active panels नहीं हैं या आप गलत block देख रहे हैं।

### 8-11. स्क्रीन पर चलने वाले energy numbers कभी-कभी थोड़ा correct या jump क्यों कर सकते हैं?

आपकी सुविधा के लिए accumulated energy के numbers स्क्रीन पर real time में update होते रहते हैं, जिससे generation की continuous process दिखती है। लेकिन truth का मुख्य source हमेशा server होता है। समय-समय पर और आपकी हर action के बाद ऐप absolute mathematical accuracy बनाए रखने के लिए server के साथ sync होता है। उसी समय स्क्रीन के numbers exact server value तक micro-correction कर सकते हैं।

## 9. Exchange

### 9-1. Exchange क्या है?

Exchange वह section है जहाँ energy main EFHC में बदलती है। यह project के अंदर user journey के सबसे महत्वपूर्ण steps में से एक है।

### 9-2. Energy को EFHC में Exchange कैसे किया जाता है?

Exchange progress को main EFHC में convert करता है। जमा हुई energy project के main coins में बदल जाती है।

### 9-3. Rule 1 kWh = 1 EFHC का क्या मतलब है?

यह project का fixed internal rate है। Energy की हर इकाई बराबर मात्रा के EFHC में convert होती है।

### 9-4. Exchange के बाद क्या होता है?

Exchange के बाद energy का परिणाम main balance में main EFHC के रूप में आता है। यह अब सिर्फ accumulated energy नहीं रहती, बल्कि project की key operations में भाग लेने वाला परिणाम बन जाती है।

### 9-5. Exchange इतना महत्वपूर्ण क्यों है?

क्योंकि इसी stage पर user जमा हुई energy को main result में बदलता है। यही वह point है जहाँ energy journey main EFHC में बदलती है।

### 9-6. क्या bonus coins को energy के बिना सीधे Exchange किया जा सकता है?

नहीं। Bonus coins पहले internal cycle में काम करते हैं: उनसे panel activate किया जाता है, panel energy generate करता है, और उसके बाद ही energy main EFHC में Exchange होती है।

### 9-7. Exchange का result bonus में नहीं, main balance में ही क्यों जाता है?

क्योंकि Exchange energy को main result में बदलता है। Project में fixed rule है: 1 kWh = 1 EFHC, इसलिए Exchange का result हमेशा main balance में जाता है, जहाँ से key operations और withdraw उपलब्ध होते हैं।

### 9-8. अगर मैंने Exchange किया, लेकिन result तुरंत नहीं दिखा, तो क्या करूँ?

पहले Exchange section refresh करें और main balance check करें। फिर balance history खोलें: वहाँ Exchange की entry होनी चाहिए। यदि entry है, तो Exchange हो चुका है, भले ही screen पर change आपने तुरंत न देखा हो।

— Section refresh करें
— Balance check करें
— History check करें

### 9-9. क्या energy Exchange करके तुरंत withdraw request भेजी जा सकती है?

हाँ, यदि Exchange के बाद main balance में पर्याप्त EFHC हैं, withdraw amount कम-से-कम 10 EFHC है, और wallet connected होने के साथ main के रूप में selected है।

### 9-10. क्या बेहतर है: बार-बार Exchange करना या energy जमा करना?

यह आपकी strategy पर निर्भर करता है। Frequent Exchange control और operations के लिए convenient है, जबकि accumulation बड़े steps के लिए useful है। Rule एक ही है: Exchange का result main balance में जाता है।

### 9-11. Exchange के बाद available energy कम क्यों हो जाती है?

क्योंकि आप accumulated energy का एक हिस्सा Exchange के ज़रिए EFHC में बदलते हैं। Energy गायब नहीं होती — वह coins में बदल जाती है।

महत्वपूर्ण: Energy main screen पर energy का कुल progress पीछे नहीं जाता और rating या level को वापस कम नहीं करता — वह आपकी growth path और generation के कुल result को दिखाता है।

### 9-12. मैं कौन-सी energy अभी Exchange कर सकता हूँ?

वही energy Exchange की जा सकती है जो पहले से जमा हो चुकी है और available बन चुकी है। यही available energy है — Exchange section में action के लिए तैयार volume।

### 9-13. Energy को main EFHC में exchange करने के लिए क्या कोई minimum limit है?

कोई सख्त limit नहीं है, लेकिन exchange की mathematics 1 kWh = 1 EFHC rate से बंधी है। 1 kWh से शुरू होने वाले whole energy values को जमा करके exchange करना अधिक व्यावहारिक है, ताकि result तुरंत main balance में दिखाई दे।

## 10. Withdraw

### 10-1. मैं EFHC withdraw क्यों नहीं कर पा रहा हूँ?

आम तौर पर वजह यह होती है कि main balance में पर्याप्त funds नहीं हैं, wallet connected नहीं है, या amount minimum withdraw threshold से कम है। Check की शुरुआत Wallet और main balance से करनी चाहिए।

### 10-2. Withdraw कैसे होता है?

पहले withdraw request बनाई जाती है, उसके बाद उसे पहले available operator द्वारा यथासंभव जल्दी process किया जाता है।

### 10-3. Withdraw request के बाद balance तुरंत क्यों बदल गया?

क्योंकि बॉट system के अंदर इस operation की शुरुआत को तुरंत account कर लेता है। इससे user देखता है कि action पहले ही उसके funds से जुड़ चुका है और system ने उसे accept कर लिया है।

### 10-4. किस balance से withdrawal किया जा सकता है?

Withdrawal सिर्फ main balance से उपलब्ध है।

### 10-5. Withdraw सिर्फ main balance से ही क्यों allowed है?

क्योंकि main balance वही हिस्सा है जो game process के result या purchased coins के रूप में user का होता है। Bonus coins internal cycle में भाग लेते हैं और सीधे withdraw नहीं किए जाते।

### 10-6. Minimum withdraw कितना है?

Minimum withdraw amount 10 EFHC है।

### 10-7. आमतौर पर withdraw request process होने में कितना समय लगता है?

Withdraw request और operator processing के through जाती है। यदि result तुरंत नहीं दिखता, तो request status और operations history check करें — वहीं real state दिखती है। अगर request लंबे समय तक नहीं बदलती, तो section refresh करके बाद में फिर check करना उपयोगी होता है।

### 10-8. क्या withdraw request cancel की जा सकती है?

हाँ, यदि request अभी तक processed नहीं हुई है। Pending request को cancel किया जा सकता है। Cancel के बाद main balance और operations history check करें: यदि funds hold हुए थे, तो वे वापस लौट आते हैं।

### 10-9. Withdraw request pending में “अटकी” क्यों रह सकती है?

क्योंकि withdraw processing से होकर गुजरता है। यदि request नहीं बदल रही, तो request status और operations history check करें, फिर कुछ समय बाद section को फिर refresh करें।

### 10-10. मैं कहाँ देखूँ कि request cancel हो गई है?

यह request status और operations history की entry दोनों में दिखता है। Cancel के बाद main balance भी check करें।

### 10-11. Minimum withdraw 10 EFHC ही क्यों है?

क्योंकि project में 10 EFHC से कम requests accept नहीं की जातीं। Minimum threshold 10 EFHC है।

इसके अलावा, withdraw fee project pay करता है, इसलिए 10 EFHC से कम amount निकालना उचित नहीं माना जाता।

### 10-12. मेरे पास EFHC होने पर भी withdrawal उपलब्ध क्यों नहीं हो सकता?

क्योंकि withdrawal के लिए केवल main balance गिना जाता है। अगर EFHC balance के bonus हिस्से में हैं, तो उन पर withdrawal नहीं किया जा सकता।

### 10-13. Withdraw request भेजने के बाद क्या करना चाहिए?

Request status और operations history check करें — वहीं request की real state और funds movement साफ दिखाई देती है।

### 10-14. Withdrawal किस token में और किस network पर किया जाता है?

Withdrawal केवल EFHC tokens में और सिर्फ TON blockchain network (The Open Network) पर किया जाता है। प्रोजेक्ट में withdrawal का कोई दूसरा विकल्प मौजूद नहीं है।

### 10-15. Operator द्वारा manual withdrawal processing में कितना समय लगता है?

Withdrawal requests को operators live queue के क्रम में process करते हैं। आमतौर पर processing कुछ मिनटों से लेकर 24 घंटे तक ले सकती है, यह network load और requests की संख्या पर निर्भर करता है। आप किसी भी unprocessed request को cancel कर सकते हैं, और funds तुरंत आपके balance में वापस आ जाएंगे।

## 11. Tasks

### 11-1. Tasks पूरा करने से क्या मिलता है?

Tasks केवल bonus coins देते हैं और player को project life में सक्रिय भागीदारी के लिए motivate करते हैं।

### 11-2. Task की reward कैसे मिलती है?

Task की conditions पूरी करनी होती हैं। उसके बाद bot completion को automatically detect करता है और तय reward credit कर देता है।

### 11-3. Task complete क्यों नहीं हुआ?

ऐसा तब हो सकता है जब conditions अभी पूरी तरह पूरी न हुई हों, action अंत तक complete न हुआ हो, या result अभी system में update न हुआ हो।

### 11-4. क्या एक ही task फिर से किया जा सकता है?

यह task के type पर निर्भर करता है। कुछ tasks one-time होते हैं, और कुछ project logic के अनुसार repeat हो सकते हैं।

### 11-5. क्या सभी tasks एक जैसी reward देते हैं?

नहीं। Reward का size हर task और उसकी conditions पर निर्भर करता है। लेकिन reward का type यहाँ एक ही है — bonus coins।

### 11-6. जब panels हैं, तो tasks की जरूरत क्यों है?

Tasks growth का एक अतिरिक्त रास्ता हैं। वे panels की जगह नहीं लेते, बल्कि bonus coins इकट्ठा करने में मदद करते हैं, जिन्हें बाद में game cycle के अंदर इस्तेमाल किया जा सकता है।

### 11-7. Task की reward main balance में क्यों नहीं आती?

क्योंकि tasks bonus EFHC देते हैं। यह game cycle की internal reward है, इसलिए यह bonus balance में credit होती है।

### 11-8. Tasks कभी-कभी खत्म या गायब क्यों हो जाते हैं?

क्योंकि tasks temporary हो सकते हैं या उनकी limit हो सकती है। यदि task दिख नहीं रहा, तो उसका मतलब है कि वह समाप्त हो गया है या अभी active नहीं है।

### 11-9. सभी available tasks कहाँ देखे जा सकते हैं?

Tasks section में — वहीं available tasks की list और उनकी conditions दिखाई जाती हैं।

### 11-10. Task की reward तुरंत क्यों नहीं दिखी?

कभी-कभी result update होने में समय लगता है। Check करें: Tasks refresh करें → bonus balance check करें → operations history check करें।

### 11-11. मैंने task में दिए गए channel को join किया, लेकिन task complete नहीं हो रहा। क्यों?

कभी-कभी Telegram servers की caching की वजह से subscription verification में समय लगता है। अगर bot ने subscription को तुरंत count नहीं किया, तो कुछ मिनट बाद Tasks सेक्शन में वापस जाएँ और check button फिर से दबाएँ।

## 12. Referrals

### 12-1. Referrals page पर sections के नाम क्या हैं?

Referrals page पर Active और Inactive sections उपयोग किए जाते हैं।

### 12-2. Active और inactive referral का क्या मतलब है?

Active referral वह player है जिसने कम-से-कम एक panel खरीद लिया है और Activ status पा लिया है। Inactive referral वह है जो अभी game cycle में enter नहीं हुआ और अभी bonus का अधिकार नहीं देता।

### 12-3. Referral bonuses कब credit होते हैं?

Referral bonuses bot द्वारा automatically check किए जाते हैं। जैसे ही player active बनता है, bonus automatically credit हो जाता है।

### 12-4. Referrals के लिए active status क्या देता है?

Referral logic के लिए active status महत्वपूर्ण है, क्योंकि project इसे real participation के filter और bots, bot farms तथा fake activity से protection के हिस्से के रूप में उपयोग करता है।

### 12-5. Activ status referrals से कैसे जुड़ा है?

Activ दिखाता है कि user project का real participant है, bot account नहीं। Referral system के honest काम और bot farms से protection के लिए यह महत्वपूर्ण है।

### 12-6. हर active referral के लिए base bonus कितना मिलता है?

हर active referral के लिए bonus balance में 0.1 EFHC credit होता है।

### 12-7. मेरे referrals हैं, फिर भी bonus क्यों नहीं मिला?

Bonus केवल active referrals के लिए credit होता है — यानी उन users के लिए जिन्होंने कम-से-कम एक panel खरीदा है और Activ status पा लिया है। Active और Inactive tabs check करें: अक्सर invited users अभी active status तक नहीं पहुँचे होते।

### 12-8. Active referral के लिए 0.1 EFHC कहाँ credit होता है?

0.1 EFHC bonus balance में credit होता है। यह referral system की internal reward है और bonus balance तथा operations history दोनों में दिखाई देती है।

### 12-9. Invited user list में है, फिर भी active क्यों नहीं माना जाता?

क्योंकि वह तभी active बनता है जब पहली panel खरीद ली जाए और Activ मिल जाए। उससे पहले वह list के inactive हिस्से में ही रहता है।

### 12-10. अपनी referral link कहाँ मिलेगी?

Referrals section में — वहीं आपकी referral link और invited users की list दिखाई जाती है।

### 12-11. क्या अपनी ही referral link से अतिरिक्त accounts बनाना allowed है?

हाँ। प्रोजेक्ट के rules इसे प्रतिबंधित नहीं करते। लेकिन खाली accounts बनाकर आपको कोई लाभ नहीं मिलेगा। सिस्टम की economy इस तरह बनाई गई है कि referral bonuses और rating growth केवल Activ status वाले participant के लिए ही credit होते हैं — यानी तब, जब invited account वास्तव में game में आए और कम से कम एक panel खरीदे।

### 12-12. क्या registration के बाद मैं अपने inviter को बदल सकता हूँ?

नहीं। Referral connection आपके project में invite link से पहली entry के समय fix हो जाता है और बाद में बदला नहीं जा सकता।

## 13. Hub

### 13-1. मैं Hub में क्या कर सकता हूँ?

Hub में ऐसे कार्ड उपलब्ध हैं जो प्रोजेक्ट की संबंधित कार्रवाइयों तक ले जाते हैं: EFHC प्राप्त करने वाले बाहरी फ़्लो तक जाना और बाहरी VIP NFT कलेक्शन तक जाना।

### 13-2. Hub किस लिए है?

Hub तेज़ ट्रांज़िशन के लिए एक navigation layer है, जो संबंधित कार्रवाइयों और प्रोजेक्ट के बाहरी फ़्लो तक ले जाता है।

### 13-3. Hub में कौन से कार्ड हैं?

इस चरण पर Hub में दो कार्ड उपलब्ध हैं: EFHC और VIP।

### 13-4. EFHC कार्ड क्या करता है?

EFHC कार्ड, EFHC प्राप्त करने वाले बाहरी फ़्लो तक जाने की शुरुआत करता है।

### 13-5. पुष्टि के बाद EFHC टॉप-अप किस बैलेंस में जाता है?

EFHC jetton टॉप-अप मुख्य बैलेंस में जमा होता है।

### 13-6. टॉप-अप का परिणाम तुरंत क्यों नहीं दिख सकता?

पहले ऑपरेशन का बाहरी चरण पुष्टि होना चाहिए, उसके बाद परिणाम अपडेट होता है। Hub, मुख्य बैलेंस और ऑपरेशन हिस्ट्री जाँचें।

### 13-7. अगर मुझे GetGems के ज़रिए VIP NFT मिला है, तो मैं कहाँ देखूँ कि वह सक्रिय है?

ऐप में VIP स्थिति और जुड़े हुए वॉलेट में NFT की मौजूदगी जाँचें।

### 13-8. मैं Hub से बाहरी फ़्लो पूरा कर चुका हूँ, लेकिन परिणाम नहीं है। मुझे क्या करना चाहिए?

Hub, मुख्य बैलेंस और ऑपरेशन हिस्ट्री जाँचें। अगर अभी भी परिणाम नहीं है, तो ऑपरेशन अभी तक सिस्टम में नहीं आया है या उसे अलग प्रोसेसिंग चाहिए।

### 13-9. Top Up और Hub के ज़रिए किया गया टॉप-अप किस बैलेंस में जाता है?

EFHC jetton टॉप-अप मुख्य बैलेंस में जमा होता है।

### 13-10. क्या Hub की कार्रवाइयों के लिए जुड़ा हुआ वॉलेट चाहिए?

बाहरी wallet-based कार्रवाइयों के लिए जुड़ा हुआ Wallet चाहिए। Hub स्वयं बिना अलग खरीद के खुलता है और ट्रांज़िशन पॉइंट की तरह काम करता है।

### 13-11. मैं कहाँ जाँच सकता हूँ कि EFHC टॉप-अप वास्तव में जमा हुआ है?

मुख्य बैलेंस और ऑपरेशन हिस्ट्री जाँचें: वहाँ टॉप-अप का रिकॉर्ड दिखना चाहिए।

### 13-12. क्या Hub में skins हैं?

Skins, Hub कार्ड नहीं हैं।

### 13-13. मैं प्रोजेक्ट के skins कैसे प्राप्त करूँ?

जैसे-जैसे अकाउंट आगे बढ़ता है, skins खुलते जाते हैं और वे 12 achievement levels से जुड़े होते हैं।

## 14. नेविगेशन और नियम

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. अगर मैं पहली बार या लंबे अंतराल के बाद WebApp में आ रहा हूँ, तो पहले कौन सी स्क्रीन खोलूँ?

सबसे अच्छा है कि मुख्य स्क्रीन, ऊपरी बार और प्रोफ़ाइल से शुरू करें। उसके बाद अपनी मौजूदा ज़रूरत के अनुसार Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History और Hub पर जाना आसान होगा।

### 14-3. मुझे कैसे समझ आए कि जिस फ़ंक्शन की ज़रूरत है वह किस सेक्शन में है?

कार्रवाई के अर्थ के अनुसार चुनें: Profile — अकाउंट डेटा और संदर्भ जानकारी के लिए, Wallet — वॉलेट के लिए, Panels — पैनलों के लिए, Energy — जनरेशन के लिए, Exchange — एक्सचेंज के लिए, Withdraw — निकासी के लिए, Tasks — कार्यों के लिए, Referrals — आमंत्रित उपयोगकर्ताओं के लिए, और Hub — EFHC व VIP से जुड़ी कार्रवाइयों के ट्रांज़िशन के लिए।

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Ads

### 15-1. यह कौन-सा section है?

Ads, Tasks section के अंदर एक subsection है। यह available advertising actions दिखाता है, जिनके जरिए user अतिरिक्त bonus coins पा सकता है।

### 15-2. यह मुझे क्या देता है?

यदि user account के लिए ads अभी available हैं, तो यह views के लिए केवल bonus coins देता है।

### 15-3. यहाँ कुछ भी क्यों नहीं दिख रहा?

यदि section खाली है, तो इसका मतलब है कि इस समय user account के लिए कोई active offers नहीं हैं या ads temporarily disabled हैं।

### 15-4. Ads section कहाँ होता है?

Ads, Tasks के अंदर subsection के रूप में होता है। यह task block के अंदर की अतिरिक्त possibilities में से एक है।

### 15-5. Ads किस type की reward देता है?

Ads views के लिए केवल bonus coins देता है। यह main balance नहीं है और न ही direct withdraw, बल्कि game path को strengthen करने का अतिरिक्त internal तरीका है।

### 15-6. Ads useful क्यों है?

क्योंकि यह bonus coins का अतिरिक्त source है। यह panels और generation की जगह नहीं लेता, लेकिन internal game cycle को तेज़ी से मजबूत करने में मदद कर सकता है।

### 15-7. दूसरों के पास ads हैं, लेकिन मेरे पास क्यों नहीं?

क्योंकि specific account के लिए offers unavailable हो सकते हैं या ads अस्थायी रूप से बंद हो सकती हैं। Empty Ads का मतलब account broken होना नहीं है।

### 15-8. मैंने Ads में action पूरा किया, लेकिन result नहीं आया — क्या करूँ?

Check करें: Tasks/Ads refresh करें → bonus balance check करें → operations history check करें।

### 15-9. अलग-अलग users को Ads में अलग offers क्यों मिल सकते हैं?

क्योंकि offers specific account के लिए advertising campaigns की availability पर निर्भर करते हैं। यह सामान्य है: किसी user के पास offers हैं, और दूसरे के पास अस्थायी रूप से नहीं।

### 15-10. Ads इस्तेमाल करने के लिए क्या कुछ खरीदना पड़ता है?

नहीं। Ads bonus EFHC पाने का तरीका है; इसके लिए कोई अनिवार्य purchase नहीं चाहिए।

## 16. Ranks

### 16-1. मेरे लिए ranking में बढ़ना क्यों महत्वपूर्ण है?

Ranking में बढ़त दिखाती है कि आपका progress दूसरे participants की तुलना में कैसा है। इससे अपना current place समझने और account कितनी सक्रियता से बढ़ रहा है, यह देखने में मदद मिलती है।

### 16-2. Level और ranking में क्या अंतर है?

Level सिस्टम के भीतर आपकी व्यक्तिगत प्रगति दिखाता है, जबकि ranking दूसरे प्रतिभागियों के बीच आपकी जगह दिखाती है।

### 16-3. Level और ranking आपस में कैसे जुड़े हैं?

दोनों एक ही वृद्धि-तर्क से जुड़े हैं: panels द्वारा kWh generation और Energy page पर दिखाई देने वाला समग्र progress bar।

### 16-4. क्या ranking सिर्फ एक सुंदर संख्या है?

नहीं। Ranking यह समझने में मदद करती है कि बाकी खिलाड़ियों की तुलना में आपका सफर कैसा दिख रहा है।

### 16-5. Ranking में मेरी position के बढ़ने पर क्या असर पड़ता है?

Ranking में आपकी position की growth account के overall progress पर निर्भर करती है: panels का development, kWh generation और project के energy path पर कुल movement।

### 16-6. क्या level और ranking दोनों साथ‑साथ बढ़ सकते हैं?

हाँ। जब खिलाड़ी panels, generation और समग्र ऊर्जा‑प्रगति को विकसित करता है, तो आम तौर पर उसका level भी बढ़ता है और ranking में उसकी स्थिति भी मजबूत होती है।

### 16-7. मेरा level ऊँचा है, लेकिन ranking में मैं पहले स्थान पर क्यों नहीं हूँ?

क्योंकि ranking सभी प्रतिभागियों के बीच आपकी जगह दिखाती है, केवल आपकी निजी प्रगति नहीं। दूसरे खिलाड़ी भी बढ़ रहे होते हैं, इसलिए अच्छा level होने पर भी आपकी position बदल सकती है।

### 16-8. मेरे नए actions के बिना भी मेरी ranking क्यों बदल सकती है?

क्योंकि ranking अपने आप नहीं रहती; यह सभी participants की तुलना में बदलती है। जब आप कुछ नहीं बदलते, तब भी दूसरे users बढ़ते रहते हैं, और उसका असर आपकी position पर पड़ता है।

### 16-9. मैं ranking में अपनी जगह कहाँ देख सकता हूँ?

Ranks section में — वहीं दूसरे प्रतिभागियों के बीच आपकी current position दिखाई जाती है।

### 16-10. मेरी खुद की progress होने पर भी मेरी ranking नीचे क्यों जा सकती है?

क्योंकि ranking केवल आपकी growth पर नहीं, बल्कि दूसरे participants की growth speed पर भी निर्भर करती है। आपका account मजबूत हो रहा हो, फिर भी दूसरे users अगर आपसे तेज़ आगे निकलें तो आपकी position नीचे जा सकती है।

## 17. Activ-status

### 17-1. Activ status का क्या मतलब है?

Activ एक स्थायी active status है। इसका मतलब है कि खेल वास्तव में शुरू हो चुका है, क्योंकि कम से कम एक panel activate किया जा चुका है।

### 17-2. Activ कैसे मिलता है?

Activ पाने के लिए एक panel खरीदना पर्याप्त है। पहली खरीद के बाद यह status स्थायी रूप से assign हो जाता है।

### 17-3. क्या Activ temporary है या permanent?

Activ एक permanent status है।

### 17-4. अगर बाद में panel Archive में चला जाए, तो क्या Activ बना रहता है?

हाँ। बाद में panel Archive में चला जाए तब भी Activ status बना रहता है।

### 17-5. Activ क्यों महत्वपूर्ण है?

Activ असली खिलाड़ियों को random registrations, bots और bot farms से अलग करने में मदद करता है। यह project में उपयोगकर्ता की वास्तविक भागीदारी की पुष्टि करता है।

### 17-6. क्या Activ बाद में गायब हो सकता है?

नहीं। Activ एक स्थायी status है और पहली panel बाद में Archive में चली जाए तब भी बना रहता है।

### 17-7. Bots और bot farms से सुरक्षा के लिए Activ क्यों ज़रूरी है?

क्योंकि Activ वास्तविक भागीदारी की पुष्टि करता है, न कि सिर्फ inflation के लिए बनाए गए खाली अकाउंट की। इससे referral system और project economy अधिक ईमानदार रहती है।

### 17-8. Activ मिलने के बाद अकाउंट में क्या बदलता है?

अकाउंट को project का verified live participant माना जाता है। इसका असर referrals की fair functioning और user activity पर trust पर पड़ता है।

### 17-9. Activ पहली panel के बाद ही क्यों दिखाई देता है?

क्योंकि पहली panel की खरीद वास्तविक भागीदारी का स्पष्ट संकेत है। Project इस step को empty accounts को फ़िल्टर करने के लिए इस्तेमाल करता है।

### 17-10. क्या inactivity की वजह से Activ खोया जा सकता है?

नहीं। Activ एक permanent status है और inactivity के कारण गायब नहीं होता।

## 18. VIP NFT

### 18-1. EFHC VIP NFT क्या है?

EFHC VIP NFT एक club card, पूरी future EFHC ecosystem की key, belonging का digital sign और project की future opportunities तक पहुँच का माध्यम है।

### 18-2. एक EFHC VIP NFT रखने से क्या मिलता है?

एक EFHC VIP NFT का ownership खिलाड़ी के सभी panels के लिए increased generation देता है।

### 18-3. कौन-से संकेत दिखाते हैं कि VIP पहले से account में लिया जा चुका है?

अगर system ने VIP NFT को पहले से account में ले लिया है, तो interface में VIP status दिखता है और account के जुड़े advantages नज़र आने लगते हैं।

### 18-4. मुझे VIP effect कहाँ दिखाई देगा?

VIP effect उन sections में दिखाई देता है जहाँ project VIP NFT के benefits को ध्यान में रखता है, साथ ही top bar और Profile में भी।

### 18-5. क्या VIP को manually enable करना पड़ता है?

नहीं। Project logic wallet की automatic checking और सही collection में NFT मिलने पर VIP status के automatic update के लिए बनाई गई है।

### 18-6. क्या 2 या 3 VIP NFT रखने पर अतिरिक्त privileges मिलते हैं?

नहीं। खिलाड़ी के लिए 2 या 3 VIP NFT होना एक VIP NFT से अधिक अतिरिक्त privileges नहीं देता।

### 18-7. दूसरा VIP NFT effect को और क्यों नहीं बढ़ाता?

Project में VIP generation boost को एक single active status की तरह देता है। अतिरिक्त VIP NFT अतिरिक्त boost नहीं देते, ताकि effect अनंत रूप से न बढ़े।

### 18-8. VIP एक panel पर असर करता है या सभी पर?

VIP उपयोगकर्ता के सभी panels की generation को प्रभावित करता है, किसी एक अलग panel को नहीं।

### 18-9. मैं कैसे जाँचूँ कि VIP सच में account को प्रभावित कर रहा है?

सिर्फ VIP status की मौजूदगी ही नहीं, बल्कि account mechanics में उससे जुड़े advantages भी जाँचें, खासकर वहाँ जहाँ VIP effect generation सहित account में लिया जाता है।

### 18-10. क्या bot को मेरा VIP NFT देखने के लिए connected wallet चाहिए?

हाँ। Bot को यह समझना होता है कि कौन‑सा wallet आपके अकाउंट से जुड़ा है। इसलिए Wallet connected होना चाहिए, और उसके बाद आप interface में VIP status check करते हैं।

### 18-11. क्या मैं अपने VIP NFT का उपयोग अपनी इच्छा से कर सकता हूँ?

हाँ। EFHC VIP NFT को transfer, gift और marketplaces पर sell किया जा सकता है।

### 18-12. अगर मैं अपना VIP NFT बेच दूँ या दूसरे wallet में transfer कर दूँ, तो मेरी generation पर क्या असर पड़ेगा?

Bot नियमित रूप से blockchain को scan करता है और आपके linked wallet पर NFT की मौजूदगी check करता है। अगर आप अपना VIP NFT बेचते हैं, gift करते हैं या किसी दूसरे address पर भेजते हैं, तो सिस्टम इसे detect करेगा, आपका VIP status बंद करेगा, और आपके सभी panels की generation अपने आप base rate पर लौट जाएगी।

## 19. Levels

### 19-1. मुझे अपना level क्यों बढ़ाना चाहिए?

Level की वृद्धि project के भीतर उपयोगकर्ता की प्रगति दिखाती है और यह समझने में मदद करती है कि अकाउंट कैसे विकसित हो रहा है। यह आगे बढ़ने का visual और semantic indicator है।

### 19-2. Levels section में क्या शामिल है?

Levels section project की सभी growth scales दिखाता है: ऊर्जा‑प्रगति के 12 levels, referral system के 6 levels, और future में जोड़ी जाने वाली अन्य level lines।

### 19-3. Project में energy progress के कितने levels हैं?

Project में energy progress के कुल 12 levels हैं।

### 19-4. Referral system में कितने levels हैं?

Project में referral system के 6 levels हैं: 0 से 5 तक।

### 19-5. एक साधारण खिलाड़ी के लिए levels किस काम के हैं?

Levels यह समझने में मदद करते हैं कि आप अभी कहाँ हैं, कितना काम हो चुका है, आगे किस दिशा में बढ़ना है और अगला milestone कौन‑सा है।

### 19-6. Energy levels, referral levels और अकाउंट की overall growth आपस में कैसे जुड़ी हैं?

ये सब एक ही समग्र रास्ते के हिस्से हैं। Energy generation मुख्य progress को आगे बढ़ाती है, active referrals referral line को मजबूत करते हैं, और साथ मिलकर वे दिखाते हैं कि अकाउंट कितनी मजबूती से विकसित हो रहा है।

### 19-7. Eco Initiate (0 kWh)

**खिलाड़ी के लिए अर्थ:** आपकी पहली panel स्थापित हो चुकी है और काम के लिए तैयार है। आपने clean energy का independent producer बनने की दिशा में मुख्य कदम उठा लिया है। यह आपका शुरुआती status है — आप अभी generation के रास्ते में प्रवेश कर रहे हैं.

**सटीक नियम:** Eco Initiate level 0 kWh के निशान के अनुरूप है।

**व्यावहारिक परिणाम:** अगला कदम panels के माध्यम से generation बढ़ाना और progress को 100 kWh तक पहुँचाना है।

### 19-8. Hope Bringer (100 kWh)

**खिलाड़ी के लिए अर्थ:** पहले kilowatts आ चुके हैं! आपकी panels सफलतापूर्वक green energy generate कर रही हैं और प्रकृति को carbon‑free future की आशा दे रही हैं। अब आप पहले वास्तविक नतीजे देख रहे हैं: energy flow शुरू हो चुका है और progress आगे बढ़ गई है।

**सटीक नियम:** Hope Bringer level 100 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** अगला लक्ष्य stability बढ़ाना और अगले stage के लिए 300 kWh तक पहुँचना है।

### 19-9. Energy Seeker (300 kWh)

**खिलाड़ी के लिए अर्थ:** सिस्टम उत्कृष्ट रूप से काम कर रहा है और grid को लगातार eco‑friendly electricity से भर रहा है। Panels द्वारा बनाई गई हर unit fossil fuel को replace करती है। अकाउंट sustainable growth mode में प्रवेश कर चुका है: आप अब केवल “newcomer” नहीं, बल्कि real generation वाले user हैं।

**सटीक नियम:** Energy Seeker level 300 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** व्यवहार में यह संकेत है कि panels को मजबूत किया जा सकता है और energy को main balance में बदलने के लिए Exchange का अधिक उपयोग किया जा सकता है।

### 19-10. Nature's Voice (600 kWh)

**खिलाड़ी के लिए अर्थ:** आपका योगदान अब noticeable हो रहा है। Green technologies की मदद से energy generate करके आप प्रकृति की आवाज़ बन जाते हैं और दिखाते हैं कि progress भी ecological हो सकती है। अब आपका progress किसी संयोग की तरह नहीं, बल्कि एक स्पष्ट trajectory की तरह महसूस होता है।

**सटीक नियम:** Nature's Voice level 600 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** अगला लक्ष्य 1000 kWh (Earth Ally) है। Energy में tempo और active panels की संख्या पर नज़र रखना उपयोगी है।

### 19-11. Earth Ally (1000 kWh)

**खिलाड़ी के लिए अर्थ:** पहला megawatt‑hour generate हो चुका है! आपकी panels ने clean energy का प्रभावशाली volume तैयार किया है। अब आप green transition के एक महत्वपूर्ण participant और planet के सच्चे ally हैं। आपने एक महत्वपूर्ण सीमा पार कर ली है: 1000 kWh अब accumulated generation का गंभीर पैमाना है।

**सटीक नियम:** Earth Ally level 1000 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** व्यवहार में यह वह बिंदु है जहाँ growth predictable होने लगती है: panel fleet को मजबूत करें और नियमित energy exchange बनाए रखें।

### 19-12. Climate Fighter (2000 kWh)

**खिलाड़ी के लिए अर्थ:** आपकी generation climate change पर वास्तविक प्रहार करती है। हर generated kilowatt सीधे coal और gas को जलाने की आवश्यकता कम करता है। अब आपकी growth व्यवस्थित हो चुकी है: progress level पर भी दिखती है और अकाउंट की overall dynamics में भी।

**सटीक नियम:** Climate Fighter level 2000 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** अगला कदम tempo को स्थिर करना और 3500 kWh तक पहुँचना है। Generation speed पर नज़र रखें और ज़रूरत होने पर VIP का उपयोग करें।

### 19-13. Green Sentinel (3500 kWh)

**खिलाड़ी के लिए अर्थ:** आपकी panels से आने वाला stable energy flow clean air की रक्षा करता है। आप समाज को ठोस लाभ पहुँचाते हैं और carbon footprint नहीं छोड़ते। आपका अकाउंट stable generation के “sentinel” की तरह बन जाता है: growth आत्मविश्वास से आगे बढ़ती है।

**सटीक नियम:** Green Sentinel level 3500 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** व्यवहार में इसका मतलब है कि panels अब एक system की तरह काम कर रही हैं — active panels को बनाए रखें और 5000 kWh तक growth की योजना बनाएँ।

### 19-14. Planet Defender (5000 kWh)

**खिलाड़ी के लिए अर्थ:** 5000 kWh clean generation! आपकी panels की क्षमता एक अदृश्य shield की तरह काम करती है, जो atmosphere को greenhouse gases के हज़ारों किलोग्राम उत्सर्जन से बचाती है। 5000 kWh scale का बड़ा संकेत है: अब आप energy के मामले में strong participants के क्षेत्र में हैं।

**सटीक नियम:** Planet Defender level 5000 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** अगला लक्ष्य 7500 kWh है। अक्सर इसी चरण पर खिलाड़ी panels और referral network दोनों को मजबूत करते हैं।

### 19-15. Eco Champion (7500 kWh)

**खिलाड़ी के लिए अर्थ:** उत्पादन का outstanding volume! आप green energy के वास्तविक champion हैं, जिनका योगदान global energy balance को बेहतर दिशा में स्पष्ट रूप से बदलता है। यह उन लोगों का level है जो generation की उच्च गति को लगातार बनाए रखते हैं।

**सटीक नियम:** Eco Champion level 7500 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** व्यवहार में: discipline बनाए रखें — active panels, नियमित Exchange, history और balances पर नियंत्रण।

### 19-16. Planet Saver (10000 kWh)

**खिलाड़ी के लिए अर्थ:** 10 megawatt‑hours! आपने इतनी clean energy generate की है कि आप सचमुच पूरे ecosystems को बचाने जैसा प्रभाव पैदा करते हैं, और अपनी panels की अधिकतम efficiency दिखाते हैं। 10000 kWh generation का बहुत शक्तिशाली चरण है।

**सटीक नियम:** Planet Saver level 10000 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** अगला कदम 15000 kWh है। इस चरण पर panels, VIP, referrals और purchases — सब कुछ optimize करना समझदारी है।

### 19-17. Green Commander (15000 kWh)

**खिलाड़ी के लिए अर्थ:** Eco‑friendly generation का flagship. आपकी panels future को power देती हैं और impressive production volumes पूरे community के लिए नए ऊँचे standards तय करते हैं। आप शीर्ष के बहुत करीब हैं: यह energy leadership scale का level है।

**सटीक नियम:** Green Commander level 15000 kWh से शुरू होता है।

**व्यावहारिक परिणाम:** व्यवहार में: stability बनाए रखें और 20000+ kWh तक growth करें, active panels और Energy में tempo पर नज़र रखते हुए।

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Referral level 0

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 0 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-20. Referral level 1

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 1 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-21. Referral level 2

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 10 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-22. Referral level 3

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 100 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-23. Referral level 4

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 300 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-24. Referral level 5

**खिलाड़ी के लिए अर्थ:** यह referral system में आपकी growth का संकेत है — यह active invited users के scale को दिखाता है।

**सटीक नियम:** इस level पर one‑time bonus: 1000 EFHC.

**व्यावहारिक परिणाम:** Level प्राप्त होने के बाद bonus balance और operation history देखें, ताकि crediting दिखाई दे।

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Levels के नाम ecology और planet से जुड़े क्यों हैं?

क्योंकि गेम की मूल अवधारणा virtual green energy, लोगों की motivation और पृथ्वी ग्रह के स्वस्थ होने में एक symbolic contribution से जुड़ी हुई है।

## 20. FAQ / Help

### 20-1. FAQ कहाँ खोलें?

FAQ profile से bot के built‑in help section के रूप में खुलता है, जहाँ project की मुख्य actions, screens और rules के उत्तर एकत्रित हैं।

### 20-2. FAQ / Help किस लिए है?

यह section इसलिए है ताकि user बिना अनुमान और भ्रम के जल्दी से स्पष्ट उत्तर, सटीक संख्याएँ, project के वास्तविक rules और मुख्य actions का अर्थ पा सके।

### 20-3. FAQ इतनी विस्तार से क्यों लिखा गया है?

क्योंकि project multi‑layered है और छोटी, सूखी help खिलाड़ी के वास्तविक सवालों को cover नहीं करती। यहाँ अर्थ, clarity, exact figures और actions के real consequences महत्वपूर्ण हैं।

### 20-4. क्या FAQ से bot के भीतर खिलाड़ी का पूरा रास्ता समझा जा सकता है?

हाँ। एक अच्छा FAQ केवल अलग‑अलग buttons नहीं समझाता, बल्कि पूरा path भी समझाता है: पहली panel से लेकर energy, exchange, balances, levels, statuses और account growth तक।

### 20-5. अगर मुझे पहली बार में उत्तर न मिले तो क्या करूँ?

अर्थ के हिसाब से सबसे पास वाले section को खोलें और पास के questions भी देखें। बड़े bot में बहुत‑से answers एक‑दूसरे से जुड़े होते हैं, और एक block अक्सर अगले block को समझने में मदद करता है।

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. अगर “सब कुछ टूटा हुआ” लगता है, तो क्या check करें?

तीन चीजें देखें: 1) Wallet — क्या wallet connected है और primary चुना गया है, 2) balances और history — क्या वहाँ आपकी operation का trace है, 3) सही section (Panels / Energy / Exchange / Withdraw)। आम तौर पर उत्तर इन्हीं में से किसी एक जगह मिलता है।

### 20-8. सबसे तेज़ तरीके से कैसे समझूँ कि मेरे EFHC के साथ क्या हुआ?

Balance history खोलें। History दिखाती है कि balances में बदलाव किस कारण हुआ: reward, purchase, exchange या withdraw।

### 20-9. अगर मैंने पहली बार bot खोला है और कुछ समझ नहीं आ रहा, तो कहाँ से शुरू करूँ?

Energy (main screen) से शुरू करें, फिर Panels खोलें, balances और history देखें, और उसके बाद तय करें कि Wallet और top‑up की ज़रूरत है या नहीं।

### 20-10. FAQ में ज़रूरी सवाल सबसे जल्दी कैसे ढूँढें?

सबसे तेज़ तरीका है topic के हिसाब से सही section खोलना (Wallet / Panels / Exchange / Withdraw आदि) और वहीं सवाल ढूँढना। यदि आप सुनिश्चित नहीं हैं, तो FAQ / Help section से शुरू करें और keywords के आधार पर आगे बढ़ें।
