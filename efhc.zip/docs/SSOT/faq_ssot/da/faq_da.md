# EFHC FAQ (DA) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. Om projektet

### 1-1. Hvad er EFHC?

EFHC er et spilprojekt om energi, fremskridt og udvikling af kontoen inde i botten. Brugeren aktiverer paneler, samler energi, veksler den til EFHC, følger sine saldi, stiger i niveauer, bevæger sig op i ranglisten og bruger projektets ekstra muligheder.

Forklaring:
— EFHC — Energy for Humanity Coin
— EFHCm — hovedmønter
— EFHCb — bonusmønter
— EFHCj — ekstern EFHC-jetton
— EFHC — samlet saldo (bonus + hovedsaldo)

### 1-2. Hvordan fungerer det hele her?

Inde i projektet er alt bygget op omkring energi og vækst af kontoen. Brugeren arbejder med paneler, samler energi, veksler den til hoved-EFHC, følger saldi, forbinder en wallet, styrker sin fremgang og bruger projektets ekstra mekanikker.

### 1-3. Hvad skal jeg gøre i denne bot?

Din hovedopgave er at udvikle din konto. For at gøre det arbejder du med paneler, følger energigenereringen, bruger Exchange, ser dine saldi, forbinder en wallet, deltager i projektets ekstra mekanikker og styrker gradvist din fremgang.

### 1-4. Hvordan vokser jeg og kommer videre her?

Vækst inde i botten er bygget op omkring energi og aktivitet. Jo flere paneler, jo mere energi, jo flere nyttige handlinger og jo mere fremgang brugeren har, desto stærkere udvikler kontoen sig, og desto højere stiger den i projektets struktur.

### 1-5. Hvad er projektets vigtigste idé?

Den vigtigste idé i projektet er at vise vejen fra aktivering af et panel til generering af energi og derefter til et resultat i EFHC. Brugeren ser ikke abstrakte tal, men en sammenhængende kæde: panel, energi, veksling, saldo og udvikling.

### 1-6. Er det bare underholdning, eller er der en logik for udvikling?

Der er en fuld logik for vækst her. Brugeren trykker ikke bare på knapper, men styrker gradvist sin konto: aktiverer paneler, starter generering, får aktiv status, samler saldi og bruger forskellige projektværktøjer.

### 1-7. Hvordan får jeg mine første EFHC her?

De første EFHC kommer fra to hovedkilder: belønninger (som bonusmønter EFHCb) og veksling af energi gennem Exchange (til hovedmønter EFHCm). Den stærkeste vej er paneler → energi → Exchange → hovedsaldo.

### 1-8. Hvor kommer min energi fra?

Energi kommer fra dine aktive paneler. Så længe panelerne er aktive, genererer de energi, og den samler sig som tilgængelig energi til veksling.

### 1-9. Hvad påvirker min vækst i projektet mest?

Det, der påvirker væksten mest, er antallet af aktive paneler og deres samlede generering. Den anden forstærker er VIP (hvis du har det), fordi det påvirker genereringen. Opgaver, reklamer og henvisninger er ekstra vækstkanaler.

### 1-10. Hvordan forstår jeg, at jeg bevæger mig den rigtige vej?

Hvis tre ting vokser — generering, tilgængelig energi og hovedsaldoen efter veksling — så bevæger du dig den rigtige vej. Du kan hurtigt kontrollere det gennem Energy og historikken over handlinger.

## 2. Hovedskærm

### 2-1. Hvad viser hovedskærmen?

Hovedskærmen er siden Energy. Den samler de vigtigste elementer i kontoens aktuelle tilstand: hurtige handlinger, information om fremgang og indgange til botens vigtige sektioner.

### 2-2. Hvorfor er hovedskærmen nødvendig?

Den er nødvendig, så brugeren straks kan se det vigtigste om sin konto og hurtigt forstå den aktuelle tilstand, fremgangen og hvad der kan gøres videre.

### 2-3. Hvad skal jeg kigge på først?

Først bør du se på topbjælken, den samlede saldo, Energy-skærmen og de tilgængelige handlinger. Det er netop de ting, der hurtigst viser kontoens aktuelle tilstand og hvad du kan gøre videre.

### 2-4. Hvor kan jeg se min aktuelle fremgang?

Den aktuelle fremgang vises i sektionerne, der er knyttet til energi, paneler, niveauer og rangering i botten. Der kan du se, hvordan brugeren bevæger sig frem i projektet.

### 2-5. Hvorfor er hovedskærmen vigtig hver dag?

Fordi det er her, du hurtigst kan se, hvordan kontoen har ændret sig: hvor meget energi der er nu, hvor mange aktive paneler der er, hvordan fremgangen vokser, og hvilket næste skridt brugeren allerede er på vej mod.

### 2-6. Hvor er det bedst at starte?

Det er bedst først at se på topbjælken, forstå hvilke saldi du har, åbne Energy-siden, se sektionen Panels og derefter læse FAQ om de vigtigste handlinger. Hvis du mangler noget for den ønskede handling, bliver det hurtigt tydeligt.

### 2-7. Hvilke knapper på hovedskærmen er de vigtigste?

De vigtigste er dem, der fører til nøglehandlinger: Panels og Exchange samt hurtigknapperne i topbjælken — Top Up og Hub — hvis du vil åbne relaterede handlinger for EFHC og VIP.

### 2-8. Hvad skal jeg kontrollere på hovedskærmen hver dag?

Tre ting: 1) hvor mange aktive paneler du har, 2) hastigheden på genereringen, 3) hvor meget tilgængelig energi der allerede er samlet til veksling.

### 2-9. Hvorfor ændrer hovedskærmen sig med tiden?

Fordi den afspejler kontoens levende tilstand. Når der kommer paneler, energi og handlinger, holder skærmen op med at være tom og begynder at vise flere nyttige data og mere fremgang.

### 2-10. Hvordan kan jeg se på hovedskærmen, at kontoen udvikler sig?

Når du ser vækst i fakta: genereringen er ikke nul, energi samler sig, og efter veksling vokser hovedsaldoen. Det er de mest ærlige tegn på udvikling.

## 3. Topbjælke

### 3-1. Hvad er topbjælken?

Topbjælken er et selvstændigt element i brugerfladen og den vigtigste hurtige informationsblok, som er tilgængelig på botens hovedsider.

### 3-2. Hvad vises i topbjælken?

I topbjælken vises avatar, navn, energifremgangsniveau, VIP-status, samlet saldo, knappen Top Up og knappen Hub.

### 3-3. Hvorfor er topbjælken vigtig?

Fordi den hjælper dig med straks at se det vigtigste om din konto uden ekstra overgange: hvem du er, hvilken fremgang du har, om du har VIP, hvor mange mønter du samlet har, og hvilke hurtige handlinger der er tilgængelige.

### 3-4. Hvad viser den samlede saldo i topbjælken?

Den samlede saldo viser, hvor mange mønter du har i alt. Det er gjort for bekvemmelighed, så du ikke selv behøver at lægge ressourcer sammen for køb og for at få et hurtigt overblik over kontoen i spillet.

### 3-5. Hvorfor er den samlede saldo praktisk til køb?

Fordi den viser spillerens samlede købekraft inde i spillet og hjælper med hurtigt at forstå, om der er nok ressourcer til interne handlinger.

### 3-6. Hvorfor er den samlede saldo ikke det samme som det, jeg kan hæve lige nu?

Fordi den samlede saldo omfatter både hovedmønter og bonusmønter. Bonusmønter bruges til spilprocessen og kan ikke hæves direkte.

### 3-7. Hvornår bør jeg bruge knappen “Top up” i topbjælken?

Brug den, når du hurtigt vil gå til den top-up-proces for hovedsaldoen, som er tilgængelig i appen, uden manuelt at åbne ekstra sektioner.

### 3-8. Hvorfor åbne Hub fra topbjælken?

For hurtigt at åbne projektets kort med relaterede handlinger og gå til det nødvendige eksterne flow uden ekstra navigation i grænsefladen.

### 3-9. Hvorfor er topbjælken synlig på forskellige sider?

Fordi den er kontoens “instrumentbræt”: den skal altid vise det vigtigste — saldo, statusser og hurtige handlinger — selv når du har åbnet en anden sektion.

### 3-10. Hvad skal jeg gøre, hvis data i topbjælken virker forkerte?

Opdatér først siden og kontrollér saldohistorikken: den viser de faktiske operationer. Hvis historikken og saldoen stemmer overens, er dataene korrekte — du har måske bare kigget på den forkerte saldo, for eksempel den samlede i stedet for den primære eller bonussaldoen.

## 4. Profil

### 4-1. Hvad er sektionen Profil/Indstillinger?

Profil/Indstillinger er sektionen, hvor du styrer profilen og botens indstillinger. Her vises de vigtigste statuser, og personlige grænsefladeindstillinger er tilgængelige.

### 4-2. Hvad kan man gøre i profilen?

I profilen er de vigtigste brugerindstillinger samlet samt hurtige overgange til vigtige sektioner: Wallet, saldohistorik, FAQ og andre nyttige kontrolpunkter.

### 4-3. Hvad vises øverst i Profil/Indstillinger?

Øverst i Profil/Indstillinger vises avatar, Telegram-navn samt statusserne Activ og VIP, hvis du allerede har dem.

### 4-4. Hvor skifter jeg sprog?

Sproget ændres i Profil/Indstillinger.

### 4-5. Hvorfor er profilen overhovedet nødvendig?

Profilen er nødvendig som dit personlige kontrolpunkt for kontoen. Her ser brugeren ikke kun statusser, men åbner også vigtige undersektioner, der er forbundet med wallet, historik, sprog og hjælpesystemet.

### 4-6. Hvor åbner jeg saldohistorikken i profilen?

I sektionen Profil/Indstillinger er der en særskilt indgang til saldohistorikken, hvor indbetalinger og fradrag vises.

### 4-7. Hvor skifter jeg sprog i profilen?

Sprogskiftet ligger i Profil/Indstillinger, fordi det er en personlig kontoindstilling.

### 4-8. Hvor i Profil kan jeg åbne Wallet for at arbejde med walleten?

I Profil er der et særskilt punkt Wallet. Åbn det, når du skal forbinde en wallet, kontrollere bindingen eller gå til handlinger, der er knyttet til walleten.

### 4-9. Hvor i Profil kan jeg hurtigt åbne FAQ, hvis jeg har brug for et svar?

I Profil er der adgang til FAQ. Åbn den, når du har brug for et hurtigt svar om interfacet, saldoen, paneler, energi, exchange, withdrawal eller andre WebApp-funktioner.

### 4-10. Hvad findes i sektionen “Support og information”?

Der er samlet hjælpepunkter: FAQ, tips/information og alt det, der hjælper brugeren med at forstå projektet uden forvirring.

### 4-11. Hvor mange sprog er projektets interface tilgængeligt på?

Bot-interfacet og hjælpesystemet (FAQ) er oversat til 13 sprog. Du kan vælge det sprog, der passer dig bedst, i profilindstillingerne, og systemet tilpasser straks alle tekster og hele interfacet til dit valg.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. Kan jeg skifte den primære wallet?

Ja. Brugeren kan vælge en anden primær wallet blandt de allerede tilknyttede.

### 5-3. Kan jeg slette en tilknyttet wallet?

Ja. Hvis en wallet ikke længere er nødvendig, kan dens tilknytning fjernes.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. Hvad sker der, hvis jeg trykker på en handling, hvor en wallet kræves, men jeg ikke har en?

Hvis den valgte funktion kræver en wallet, starter botten først logikken for at forbinde en wallet. Derefter kan du vende tilbage til den ønskede handling og udføre den normalt.

### 5-6. Kan jeg forbinde flere wallets, og hvorfor er det nyttigt?

Ja. Du kan forbinde flere wallets, så du har en reserveadresse eller kan adskille forskellige brugsscenarier. Samtidig vælges én wallet som primær — det er netop den, systemet bruger som standard.

### 5-7. Hvad sker der, hvis jeg ændrer den primære wallet?

Du kan vælge en anden wallet som primær. Efter skiftet vil systemet bruge den nye primære adresse til de operationer, hvor det kræves. Før en hævning eller et køb er det bedst at kontrollere, at den rigtige wallet er valgt.

### 5-8. Kan jeg hæve til en ikke-primær wallet?

Som standard bruger systemet den primære wallet. Hvis du har brug for en anden adresse, skal du først gøre den til primær i Wallet og derefter oprette anmodningen om hævning.

### 5-9. Hvad skal jeg gøre, hvis wallet er forbundet, men hævning stadig ikke er tilgængelig?

Kontrollér tre ting: om den primære wallet er valgt, om der er nok på den primære saldo, og om hævningsbeløbet ikke er under 10 EFHC.

### 5-10. Kan jeg spille og udvikle mig, hvis wallet endnu ikke er forbundet?

Ja. Wallet er nødvendig til visse operationer, for eksempel hævning, men du kan udvikle kontoen, lære grænsefladen at kende og samle fremgang også uden den.

### 5-11. Hvad skal jeg gøre, hvis jeg mister adgangen til min primære TON-wallet?

Da projektet giver dig mulighed for at knytte flere wallets, kan du tilføje en ny wallet i Wallet-sektionen, gøre den til primær og permanent fjerne den gamle kompromitterede adresse fra listen over tilknyttede wallets.

## 6. Balancer og historik

### 6-1. Hvorfor har jeg tre forskellige saldi?

Fordi midlerne har forskellige roller inde i botten. Den samlede saldo viser alt samlet, bonussaldoen er nødvendig til den interne spilcyklus, og hovedsaldoen viser det resultat, som allerede kan bruges til nøglehandlinger og udbetaling.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Hvad er hovedsaldoen?

Hovedsaldoen er de primære EFHC. Det er netop her resultatet af spilcyklussen bliver til, og det er netop herfra nøglehandlinger, inklusive udbetaling, er tilgængelige.

### 6-4. Hvorfor kan ét køb påvirke både bonus- og hovedsaldoen?

Ved alle interne udgifter i projektet trækkes midler først fra bonussaldoen. Hvis det ikke er nok, trækkes resten fra hovedsaldoen.

### 6-5. Hvorfor er der flere poster i historikken med det samme?

Én handling kan påvirke flere dele af bevægelsen af midler, derfor viser botten den med flere linjer for at afspejle de forskellige ændringer separat.

### 6-6. Hvor kan jeg se, hvor EFHC kom fra eller hvor de blev brugt?

Til det findes sektionen for balancehistorik. Den viser indbetalinger, fradrag, veksling, køb, udbetaling og andre ændringer af midlerne.

### 6-7. Hvorfor kan den samlede saldo være høj, men jeg kan hæve mindre?

Fordi den samlede saldo lægger hoved- og bonussaldo sammen. Udbetaling er kun tilladt fra hovedsaldoen, mens bonussaldoen er beregnet til projektets interne cyklus. Derfor skal du se på netop hovedsaldoen ved udbetaling.

### 6-8. Hvor ser jeg hurtigst, hvad der præcist ændrede min saldo?

I balancehistorikken. Der kan du se, hvilken handling der gav en indbetaling eller et fradrag, og hvilken saldo der blev berørt.

### 6-9. Hvorfor kan bonussaldoen ikke hæves direkte?

Fordi bonusmønter er en del af projektets interne cyklus. Udbetaling er kun tilladt fra hovedsaldoen.

### 6-10. Hvorfor ændrer historikken sig ikke helt ens overalt med det samme efter udbetaling eller veksling?

Fordi forskellige skærme ikke altid opdateres samtidig. Tjek: opdater sektionen → kontroller saldoen → kontroller historikken.

### 6-11. Hvad sker der, hvis jeg ved svag internetforbindelse ved et uheld trykker på køb- eller exchange-knappen flere gange i træk? Bliver der trukket ekstra coins?

Nej. Der bliver ikke trukket ekstra coins. Systemets kerne har en streng beskyttelse mod dobbelte debiteringer. Selv hvis du trykker 10 gange på grund af netværkshæng, udføres handlingen garanteret præcis én gang.

## 7. Panels

### 7-1. Hvor meget koster ét panel?

Ét panel koster altid 100 EFHC.

### 7-2. Hvad giver aktivering af det første panel med det samme?

Køb af det første panel starter straks energigenerering, åbner vejen til fremskridt, skaber vejen til hoved-EFHC og giver den permanente aktive status Activ.

### 7-3. Hvornår starter et panel med at generere?

Genereringen starter straks efter aktivering af panelet.

### 7-4. Hvor lang levetid har et panel?

Hvert panel har en 180-dages panelcyklus.

### 7-5. Hvad sker der med panelet efter den 180 dage lange cyklus er afsluttet?

Når den 180 dage lange cyklus er afsluttet, deaktiveres panelet og flyttes til Archive som en del af deltagerens energiske fremskridtshistorik.

### 7-6. Hvilke to paneltilstande findes i interfacet?

I interfacet findes Activ og Archive. Activ er de paneler, der deltager i genereringen. Archive er de paneler, som allerede har afsluttet den aktive cyklus og bevarer historikken om brugerens vej.

### 7-7. Kan jeg aktivere mere end ét panel med det samme?

Ja. Du kan aktivere paneler efter hinanden og dermed øge antallet af aktive paneler. Jo flere aktive paneler, desto højere samlet energigenerering og desto hurtigere vokser dine fremskridt.

### 7-8. Hvad betyder timeren “Tilbage” på et panel?

Timeren viser, hvor meget tid der er tilbage, før panelets 180-dages cyklus slutter. Når tiden udløber, flytter panelet automatisk til Archive og holder op med at være aktivt.

### 7-9. Hvorfor blev jeg Activ efter aktivering af det første panel?

Fordi Activ er en bekræftelse på reel deltagelse og en beskyttelse af projektet mod bots. Projektet knytter Activ til aktiveringen af det første panel, så kun levende deltagere får status.

### 7-10. Hvorfor er aktive paneler vigtigere end arkivpaneler?

Aktive paneler genererer energi nu — det er dem, der giver dit nuværende væksttempo. Arkivpaneler er afsluttede paneler; de bevarer historikken, men giver ikke nuværende generering.

### 7-11. Hvorfor har jeg færre aktive paneler, end jeg har købt?

Fordi en del af panelerne kan have afsluttet deres 180-dages periode og flyttet til Archive. Aktive paneler er dem, der arbejder nu. Archive er afsluttede paneler; de giver ikke nuværende generering.

### 7-12. Kan aktive paneler “forsvinde” på grund af grænsen på 1000?

Nej. Grænsen på 1000 betyder, at du ikke kan have mere end 1000 aktive paneler samtidigt. Allerede aktiverede aktive paneler “forsvinder” ikke: de forbliver aktive indtil periodens slutning og flytter derefter til Archive.

### 7-13. Hvad skal jeg gøre, hvis jeg har aktiveret et panel, men genereringen ikke ændrede sig med det samme?

Kontrollér:
— Opdater sektionen Panels
— Se om panelet er dukket op i Active
— Åbn Energy og kontrollér genereringshastigheden
— Kontrollér balancehistorikken (der skal være et fradrag på 100 EFHC)

### 7-14. Kan jeg aktivere et panel, hvis jeg har mindre end 100 EFHC?

Nej. Panelprisen er fast: 100 EFHC. Hvis du har færre midler, går købet ikke igennem.

### 7-15. Hvorfor er Archive-paneler vigtige, hvis de ikke længere genererer?

Archive gemmer historikken om dine paneler og gennemførte cyklusser. Det er din “vækstbiografi”, men den aktuelle generering kommer kun fra aktive paneler.

### 7-16. Kan jeg aktivere et panel og straks se, at det er aktivt?

Ja. Det aktiverede panel skal vises i listen Active, og aktiveringen af det afspejles i balancehistorikken.

### 7-17. Hvor meget energi giver ét panel på 180 dage?

Ét panel ved basisraten giver 107.61984000 kWh på 180 dage. Med EFHC VIP NFT er genereringen 115.24032000 kWh.

## 8. Energy

### 8-1. Hvad viser siden Energy?

På siden Energy vises energifremgang, en fremskridtsbjælke for energigenerering, antallet af aktive paneler, den samlede panelgenerering pr. sekund og andre nøgleindikatorer for den aktuelle tilstand.

### 8-2. Hvad viser fremskridtsbjælken på siden Energy?

Fremskridtsbjælken viser vejen til spillerens næste fremskridtsniveau på skalaen med 12 niveauer.

### 8-3. Hvad betyder samlet panelgenerering pr. sekund?

Det er den grundlæggende eller VIP-baserede genereringskonstant ganget med antallet af aktive paneler.

### 8-4. Hvorfor er energi så vigtig?

Fordi energi er den centrale kerne i fremskridt i EFHC. Gennem den går brugeren fra paneler til et resultat, som påvirker saldo, niveauer, rangering og udviklingen af kontoen.

### 8-5. Kan man ud fra Energy forstå, hvor stærk kontoen er?

Ja. Siden Energy viser hurtigt systemets aktuelle styrke: hvor mange paneler der arbejder, hvilken generering der kører lige nu, hvor meget energi der allerede er akkumuleret, og hvor langt brugeren er fra næste niveau.

### 8-6. Hvorfor tælles tilgængelig energi og hovedsaldo separat?

Fordi det er to forskellige størrelser. Tilgængelig energi viser de akkumulerede kWh, mens hovedsaldoen viser de vigtigste EFHC, som allerede er modtaget. Disse værdier hænger sammen, men de er ikke det samme.

### 8-7. Hvorfor vokser energien af sig selv, mens hovedsaldoen ikke stiger automatisk?

Fordi energiakkumulering og vækst i hovedsaldoen sker på forskellige trin. Først genererer panelerne energi, og hovedsaldoen stiger først efter en separat exchange-handling eller et andet scenarie, der krediterer hoved-EFHC.

### 8-8. Hvad viser genereringshastigheden pr. sekund?

Det er en indikator for, hvor hurtigt dine aktive paneler skaber energi lige nu — altså dit nuværende væksttempo.

### 8-9. Hvad er især vigtigt at følge i Energy hver dag?

Antallet af aktive paneler, genereringshastigheden og den tilgængelige energi — det er de tre vigtigste pejlemærker for kontoens tilstand.

### 8-10. Hvordan kan jeg se i Energy, at mine paneler virkelig arbejder?

Hvis du i Energy kan se aktive paneler og ikke-nul generering, og den tilgængelige energi gradvist vokser, så arbejder panelerne. Hvis genereringen er 0 og energien ikke akkumuleres, er der ingen aktive paneler, eller du ser på den forkerte blok.

### 8-11. Hvorfor kan de løbende energital på skærmen nogle gange blive lidt korrigeret eller hoppe?

For din bekvemmelighed opdateres de akkumulerede energital på skærmen i realtid og viser en kontinuerlig genereringsproces. Serveren er dog altid den primære sandhedskilde. Med jævne mellemrum og også efter hver af dine handlinger synkroniserer appen med serveren for at sikre absolut matematisk præcision. I det øjeblik kan der ske en mikrokorrektion af tallene på skærmen til den nøjagtige serverværdi.

## 9. Exchange

### 9-1. Hvad er Exchange?

Exchange er den sektion, hvor energi bliver til hoved-EFHC. Det er et af de vigtigste trin på brugerens vej inde i projektet.

### 9-2. Hvordan fungerer veksling af energi til EFHC?

Veksling er en konvertering af fremskridt til hoved-EFHC. Den akkumulerede energi bliver til projektets primære mønter.

### 9-3. Hvad betyder reglen 1 kWh = 1 EFHC?

Det er projektets faste interne kurs. Hver energienhed konverteres til den samme mængde EFHC.

### 9-4. Hvad sker der efter vekslingen?

Efter vekslingen vises energiens resultat på hovedsaldoen som hoved-EFHC. Det er ikke længere bare akkumuleret energi, men et resultat, der deltager i projektets nøglehandlinger.

### 9-5. Hvorfor er veksling så vigtig?

Fordi det er netop gennem vekslingen, at brugeren overfører den akkumulerede energi til hovedresultatet. Det er punktet, hvor den energimæssige vej bliver til hoved-EFHC.

### 9-6. Kan man veksle bonusmønter direkte uden energi?

Nej. Bonusmønter deltager først i den interne cyklus: gennem dem aktiveres et panel, panelet genererer energi, og først derefter veksles energien til hoved-EFHC.

### 9-7. Hvorfor går vekslingen direkte til hovedsaldoen og ikke til bonussaldoen?

Fordi Exchange er omdannelsen af energi til hovedresultatet. I projektet er reglen fastsat: 1 kWh = 1 EFHC, og resultatet af vekslingen krediteres altid hovedsaldoen, hvorfra nøglehandlinger og udbetaling er tilgængelige.

### 9-8. Hvad skal jeg gøre, hvis jeg har foretaget en veksling, men ikke ser resultatet med det samme?

Opdater først sektionen Exchange og kontrollér hovedsaldoen. Åbn derefter balancehistorikken: der skal være en post om vekslingen. Hvis posten er der, er vekslingen gennemført, selv om du ikke straks lagde mærke til ændringen på skærmen.

— Opdater sektionen
— Kontrollér saldoen
— Kontrollér historikken

### 9-9. Kan jeg veksle energi og straks anmode om udbetaling?

Ja, hvis der efter vekslingen er nok EFHC på hovedsaldoen, udbetalingsbeløbet ikke er lavere end 10 EFHC, og walleten er tilsluttet og valgt som primær.

### 9-10. Hvad er bedst: at veksle ofte eller at akkumulere?

Det afhænger af dit mål. Hyppig veksling er praktisk til kontrol og handlinger, mens akkumulering er praktisk til sjældnere og større skridt. Reglen er én: resultatet af vekslingen går til hovedsaldoen.

### 9-11. Hvorfor falder den tilgængelige energi efter veksling?

Fordi du overfører en del af den akkumulerede energi til EFHC gennem Exchange. Energien forsvinder ikke — den bliver til mønter.

Vigtigt: mængden af energi på hovedskærmen i Energy skal ikke “falde” som dine samlede fremskridt og påvirker ikke rangering og niveau bagud — den afspejler din vækstvej og det samlede genereringsresultat.

### 9-12. Hvilken energi kan jeg allerede veksle?

Du kan veksle den energi, som allerede er akkumuleret og blevet tilgængelig. Det er netop den tilgængelige energi — den klar-til-brug mængde til handling i sektionen Exchange.

### 9-13. Findes der en minimumsgrænse for at veksle energi til hoved-EFHC?

Der er ingen faste grænser, men vekslingslogikken følger kursen 1 kWh = 1 EFHC. Det er fornuftigt at opsamle og veksle hele energiværdier fra 1 kWh, så resultatet straks kan ses på hovedsaldoen.

## 10. Withdraw

### 10-1. Hvorfor kan jeg ikke hæve EFHC?

Normalt skyldes det, at der ikke er nok midler på hovedsaldoen, at walleten ikke er tilsluttet, eller at beløbet er mindre end den minimale udbetalingstærskel. Du bør starte kontrollen med Wallet og hovedsaldoen.

### 10-2. Hvordan foregår udbetalingen?

Der oprettes en udbetalingsanmodning, hvorefter den behandles så hurtigt som muligt af den første ledige operatør.

### 10-3. Hvorfor ændrede saldoen sig med det samme efter udbetalingsanmodningen?

Fordi botten straks registrerer starten på denne handling i systemet. Det er nødvendigt, så brugeren kan se, at handlingen allerede er knyttet til hans midler og accepteret af systemet.

### 10-4. Fra hvilken saldo kan man foretage withdrawal?

Withdrawal er kun tilgængelig fra hovedsaldoen.

### 10-5. Hvorfor er udbetaling kun tilgængelig fra hovedsaldoen?

Fordi hovedsaldoen er det, der allerede tilhører brugeren som resultat af spilprocessen eller som købte mønter. Bonusmønter deltager i den interne cyklus og kan ikke hæves direkte.

### 10-6. Hvad er minimumsudbetalingen?

Minimumsbeløbet for udbetaling er 10 EFHC.

### 10-7. Hvor lang tid tager en udbetalingsanmodning normalt at blive behandlet?

Udbetaling sker gennem en anmodning og behandling af en operatør. Hvis resultatet ikke er synligt med det samme, så kontrollér anmodningens status og historikken over handlinger — der afspejles den reelle tilstand. Hvis anmodningen ikke ændrer sig i lang tid, hjælper det normalt at opdatere sektionen og kontrollere igen senere.

### 10-8. Kan man annullere en udbetalingsanmodning?

Ja, hvis anmodningen endnu ikke er behandlet. Annullering er tilgængelig for en ventende anmodning. Efter annulleringen skal du kontrollere hovedsaldoen og historikken over handlinger: hvis midlerne blev tilbageholdt, returneres de.

### 10-9. Hvorfor kan en udbetalingsanmodning “hænge” i venteposition?

Fordi udbetaling går gennem behandling. Hvis anmodningen ikke ændrer sig, så kontrollér anmodningens status og historikken over handlinger og opdater derefter sektionen senere.

### 10-10. Hvor kan jeg se, at anmodningen er annulleret?

Det ses på anmodningens status og på posten i historikken over handlinger. Efter annullering bør du også kontrollere hovedsaldoen.

### 10-11. Hvorfor er minimumsudbetalingen netop 10 EFHC?

Fordi projektet har fastsat en tærskel, under hvilken anmodninger ikke accepteres. Minimum er 10 EFHC.

Desuden: gebyret for udbetaling betales af projektet, og det er ikke hensigtsmæssigt at hæve beløb under 10 EFHC.

### 10-12. Hvorfor kan withdrawal være utilgængelig, selv om jeg har EFHC?

Fordi kun hovedsaldoen tæller til withdrawal. Hvis EFHC ligger i bonusdelen af saldoen, kan du ikke oprette en withdrawal på dem.

### 10-13. Hvad skal jeg gøre efter at have indsendt en udbetalingsanmodning?

Kontrollér anmodningens status og historikken over handlinger — der kan du se den reelle status for anmodningen og bevægelsen af midler.

### 10-14. I hvilke tokens og på hvilket netværk foretages udbetalinger?

Udbetalinger sker kun i EFHC-tokens og udelukkende på TON-blockchain-netværket (The Open Network). Der findes ingen andre udbetalingsmuligheder i projektet.

### 10-15. Hvor lang tid tager manuel behandling af en udbetaling af en operatør?

Udbetalingsanmodninger behandles af operatører i levende kø. Behandlingen tager normalt fra få minutter op til 24 timer afhængigt af netværksbelastning og antal anmodninger. Du kan altid annullere en ubehandlet anmodning, og midlerne vender straks tilbage til din saldo.

## 11. Opgaver

### 11-1. Hvad giver opgaver mig?

Opgaver giver kun bonusmønter og motiverer spilleren til at deltage i kontoens aktivitet.

### 11-2. Hvordan modtager jeg en belønning for en opgave?

Du skal opfylde opgavens betingelser, hvorefter botten automatisk registrerer fuldførelsen og krediterer den angivne belønning.

### 11-3. Hvorfor blev opgaven ikke fuldført?

Det kan ske, hvis betingelserne endnu ikke er opfyldt helt, handlingen ikke blev gennemført helt, eller resultatet endnu ikke er opdateret i systemet.

### 11-4. Kan jeg udføre den samme opgave igen?

Det afhænger af opgavetypen. Nogle opgaver er kun engangsopgaver, mens andre kan gentages efter projektets logik.

### 11-5. Giver alle opgaver den samme belønning?

Nej. Belønningens størrelse afhænger af den konkrete opgave og dens betingelser. Men belønningstypen er den samme her: bonusmønter.

### 11-6. Hvorfor har jeg brug for opgaver, hvis der findes paneler?

Opgaver er en ekstra vej til vækst. De erstatter ikke paneler, men hjælper dig med at samle bonusmønter, som senere kan bruges inde i spilcyklussen.

### 11-7. Hvorfor går belønningen fra opgaver ikke til hovedsaldoen?

Fordi opgaver giver bonus-EFHC. Det er en intern belønning i spilcyklussen, så den krediteres bonussaldoen.

### 11-8. Hvorfor slutter eller forsvinder opgaver nogle gange?

Fordi opgaver kan være midlertidige eller begrænsede. Hvis en opgave er væk, betyder det, at den er afsluttet eller ikke er aktiv lige nu.

### 11-9. Hvor kan jeg se alle tilgængelige opgaver?

I sektionen Opgaver. Der vises listen over tilgængelige opgaver og deres betingelser.

### 11-10. Hvorfor kom belønningen for opgaven ikke med det samme?

Nogle gange tager det tid, før resultatet opdateres. Kontrollér: opdater Opgaver → kontrollér bonussaldoen → kontrollér historikken over handlinger.

### 11-11. Jeg abonnerede på kanalen i opgaven, men opgaven bliver ikke godkendt. Hvorfor?

Nogle gange tager abonnementskontrollen tid på grund af caching på Telegrams serverside. Hvis botten ikke godkendte abonnementet med det samme, så gå tilbage til Tasks-sektionen efter et par minutter og tryk på kontrolknappen igen.

## 12. Henvisninger

### 12-1. Hvad hedder sektionerne på siden Henvisninger?

Siden Henvisninger bruger sektionerne Aktiv og Inaktiv.

### 12-2. Hvad er en aktiv og en inaktiv henvisning?

En aktiv henvisning er en spiller, som allerede har aktiveret mindst ét panel og fået Activ-status. En inaktiv henvisning er en, som endnu ikke er gået ind i spilcyklussen og derfor endnu ikke kvalificerer sig til bonus.

### 12-3. Hvornår krediteres henvisningsbonusser?

Henvisningsbonusser kontrolleres automatisk af botten. Så snart en spiller bliver aktiv, krediteres bonussen automatisk med det samme.

### 12-4. Hvad betyder aktiv status for henvisninger?

Aktiv status er vigtig for henvisningslogikken, fordi projektet bruger den som en del af et filter for reel deltagelse og som beskyttelse mod bots, botfarme og falsk aktivitet.

### 12-5. Hvordan hænger Activ sammen med henvisninger?

Activ viser, at en bruger er en reel deltager i projektet og ikke en botkonto. Det er vigtigt for en fair henvisningsmodel og beskyttelse mod botfarme.

### 12-6. Hvilken grundbonus krediteres for hver aktiv henvisning?

For hver aktiv henvisning krediteres 0.1 EFHC til bonussaldoen.

### 12-7. Hvorfor har jeg henvisninger, men ingen bonus blev krediteret?

Bonussen krediteres kun for aktive henvisninger — dem, der har aktiveret mindst ét panel og fået Activ. Kontrollér fanerne Aktiv og Inaktiv: i de fleste tilfælde er de inviterede brugere endnu ikke blevet aktive.

### 12-8. Hvor krediteres 0.1 EFHC for en aktiv henvisning?

Bonussen på 0.1 EFHC krediteres bonussaldoen. Det er en intern belønning i henvisningssystemet, og den kan ses i bonussaldoen og i historikken over handlinger.

### 12-9. Hvorfor står en inviteret bruger på listen, men tælles ikke som aktiv?

Fordi en bruger først bliver aktiv efter aktivering af det første panel og modtagelse af Activ. Indtil da bliver personen i den inaktive del af listen.

### 12-10. Hvor kan jeg få mit henvisningslink?

I sektionen Henvisninger. Der vises dit henvisningslink og listen over inviterede brugere.

### 12-11. Er det tilladt at oprette ekstra konti via dit eget referralslink?

Ja. Projektets regler forbyder det ikke. Men tomme konti giver dig ingen fordel. Systemets økonomi er bygget sådan, at referralbonusser og ranking-vækst kun tilskrives en deltager med Activ-status — altså først efter at den inviterede konto faktisk går ind i spillet og aktiverer mindst ét panel.

### 12-12. Kan jeg ændre min inviterer efter registrering?

Nej. Referral-forbindelsen fastlægges i det øjeblik, du første gang går ind i projektet via et invitationslink, og den kan ikke ændres senere.

## 13. Hub

### 13-1. Hvad kan jeg gøre i Hub?

I Hub findes der kort, der fører til relaterede projekthandlinger: overgang til det eksterne flow for at få EFHC og overgang til den eksterne VIP NFT-samling.

### 13-2. Hvad bruges Hub til?

Hub fungerer som et navigation layer til hurtige overgange til relaterede handlinger og eksterne projektflows.

### 13-3. Hvilke kort findes der i Hub?

På nuværende trin findes der to kort i Hub: EFHC og VIP.

### 13-4. Hvad gør EFHC-kortet?

EFHC-kortet starter overgangen til det eksterne flow for at få EFHC.

### 13-5. Hvor bliver EFHC-top-up krediteret efter bekræftelse?

Et EFHC jetton-top-up krediteres hovedsaldoen.

### 13-6. Hvorfor vises resultatet af top-up måske ikke med det samme?

Først skal den eksterne fase af operationen bekræftes, og derefter opdateres resultatet. Tjek Hub, hovedsaldoen og historikken over operationer.

### 13-7. Hvis jeg har modtaget en VIP NFT via GetGems, hvor kan jeg se, at den er aktiv?

Tjek VIP-status i appen og at NFT’en findes i den tilknyttede wallet.

### 13-8. Jeg gennemførte det eksterne flow fra Hub, men der er intet resultat. Hvad skal jeg gøre?

Tjek Hub, hovedsaldoen og historikken over operationer. Hvis der stadig ikke er noget resultat, er operationen endnu ikke hentet ind eller kræver separat behandling.

### 13-9. Hvilken saldo modtager et top-up via Top Up og Hub?

Et EFHC jetton-top-up krediteres hovedsaldoen.

### 13-10. Har jeg brug for en tilsluttet wallet til handlinger fra Hub?

En tilsluttet Wallet er nødvendig for eksterne wallet-baserede handlinger. Hub åbnes uden et særskilt køb og fungerer som overgangspunkt.

### 13-11. Hvor kan jeg kontrollere, at EFHC-top-up faktisk blev krediteret?

Tjek hovedsaldoen og historikken over operationer: der bør være et spor af top-up dér.

### 13-12. Er der skins i Hub?

Skins er ikke Hub-kort.

### 13-13. Hvordan får jeg projektets skins?

Skins låses op, efterhånden som kontoen udvikler sig, og de er knyttet til de 12 achievements-niveauer.

## 14. Navigation og regler

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Hvilke skærme bør jeg åbne først, hvis jeg går ind i WebApp første gang eller efter en lang pause?

Det er bedst at starte med hovedskærmen, topbjælken og profilen. Derefter er det lettere at gå til Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History og Hub alt efter din aktuelle opgave.

### 14-3. Hvordan forstår jeg, i hvilken sektion jeg skal lede efter den funktion, jeg har brug for?

Vælg sektion ud fra handlingens betydning: Profile — til kontodata og referenceinformation, Wallet — til wallet, Panels — til paneler, Energy — til generering, Exchange — til udveksling, Withdraw — til udbetalinger, Tasks — til opgaver, Referrals — til inviterede brugere, og Hub — til overgange til relaterede EFHC- og VIP-handlinger.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Annoncer

### 15-1. Hvad er denne sektion?

Sektionen Annoncer er en undersektion inde i Opgaver. Den viser tilgængelige annoncehandlinger, hvorigennem brugeren kan få ekstra bonusmønter.

### 15-2. Hvad giver den mig?

Den giver kun bonusmønter for visninger, forudsat at annoncering i øjeblikket er tilgængelig for brugerkontoen.

### 15-3. Hvorfor er der ikke noget her?

Hvis sektionen er tom, betyder det, at der i øjeblikket ikke er nogen aktive tilbud for brugerkontoen, eller at annoncering midlertidigt er slået fra.

### 15-4. Hvor ligger sektionen Annoncer?

Sektionen Annoncer ligger som en undersektion inde i Opgaver. Det er en af de ekstra muligheder i opgaveblokken.

### 15-5. Hvilken type belønning giver Annoncer?

Annoncer giver kun bonusmønter for visninger. Det er ikke hovedsaldoen og ikke en direkte udbetaling, men en ekstra intern måde at styrke spilvejen på.

### 15-6. Hvorfor er Annoncer nyttige?

Fordi det er en ekstra kilde til bonusmønter. Det erstatter ikke paneler og generering, men det kan hjælpe med at styrke den interne spilcyklus hurtigere.

### 15-7. Hvorfor har andre annoncer, mens jeg ikke har?

Fordi tilbud kan være utilgængelige for en bestemt konto, eller annoncering kan være midlertidigt slået fra. En tom Annoncer-sektion betyder ikke, at kontoen er i stykker.

### 15-8. Hvad skal jeg gøre, hvis jeg udførte en handling i Annoncer, men der ikke er noget resultat?

Kontrollér: opdater Opgaver/Annoncer → kontrollér bonussaldoen → kontrollér historikken over handlinger.

### 15-9. Hvorfor kan forskellige brugere have forskellige tilbud i Annoncer?

Fordi tilbud afhænger af tilgængeligheden af annoncekampagner for en bestemt konto. Det er normalt: én bruger kan have tilbud, mens en anden midlertidigt ikke har.

### 15-10. Skal jeg købe noget for at bruge Annoncer?

Nej. Annoncer er en måde at få bonus-EFHC på og kræver ikke obligatoriske køb.

## 16. Ranks

### 16-1. Hvorfor er det vigtigt for mig at vokse i rangeringen?

Vækst i rangeringen viser, hvordan din fremgang ser ud i forhold til andre deltagere. Det hjælper dig med at forstå din nuværende placering og se, hvor aktivt kontoen udvikler sig.

### 16-2. Hvad er forskellen på niveau og rangliste?

Niveau viser din personlige fremgang inde i systemet, mens ranglisten viser din placering blandt andre deltagere.

### 16-3. Hvordan hænger niveau og rangliste sammen?

De er forbundet af den samme vækstlogik gennem generering af kWh med paneler og den samlede fremskridtslinje på Energy-siden.

### 16-4. Er ranglisten bare et flot tal?

Nej. Ranglisten hjælper dig med at forstå, hvordan din rejse ser ud sammenlignet med andre deltagere.

### 16-5. Hvad påvirker væksten af min placering i rangeringen?

Væksten af din placering i rangeringen afhænger af kontoens samlede fremgang: udvikling af paneler, generering af kWh og den samlede bevægelse langs projektets energivej.

### 16-6. Kan man stige i både niveau og rangliste samtidig?

Ja. Når en bruger udvikler paneler, generation og den samlede energifremgang, styrker det normalt både niveauet og placeringen i ranglisten.

### 16-7. Hvorfor har jeg et højt niveau, men ikke førstepladsen i ranglisten?

Fordi ranglisten er din placering blandt alle deltagere, ikke kun din personlige fremgang. Andre spillere vokser også, så din placering kan ændre sig, selv om dit niveau er godt.

### 16-8. Hvorfor kan min rangering flytte sig uden nye handlinger fra mig?

Fordi rangeringen ikke eksisterer for sig selv, men ændrer sig i forhold til alle deltagere. Mens du ikke ændrer noget, fortsætter andre brugere med at vokse, og det påvirker din placering.

### 16-9. Hvor kan jeg se min placering i ranglisten?

I afsnittet Ranks — der vises din placering blandt andre deltagere.

### 16-10. Hvorfor kan min rangering falde, selv om jeg gør fremskridt?

Fordi rangeringen ikke kun afhænger af din egen vækst, men også af hvor hurtigt andre deltagere vokser. Selv hvis din konto bliver stærkere, kan din placering falde, når andre overhaler dig hurtigere.

## 17. Activ-status

### 17-1. Hvad betyder Activ-status?

Activ er en permanent aktiv status. Den betyder, at spillet for alvor er begyndt, fordi der er aktiveret mindst ét panel.

### 17-2. Hvordan får jeg Activ?

For at få Activ er det nok at aktivere ét panel. Efter dette køb tildeles status permanent.

### 17-3. Er Activ midlertidig eller permanent?

Activ er en permanent status.

### 17-4. Bevares Activ, hvis et panel senere går til Archive?

Ja. Selv hvis et panel senere går til Archive, bevares Activ-status.

### 17-5. Hvorfor er Activ vigtig?

Activ hjælper med at skelne rigtige spillere fra tilfældige registreringer, bots og botfarme. Den bekræfter brugerens reelle deltagelse i projektet.

### 17-6. Kan Activ forsvinde senere?

Nej. Activ er en permanent status og bevares, selv hvis det første panel senere går til Archive.

### 17-7. Hvorfor er Activ nødvendig som beskyttelse mod bots og botfarme?

Fordi Activ bekræfter reel deltagelse og ikke bare en tom konto til kunstig oppustning. Det gør henvisningssystemet og økonomien mere retfærdige.

### 17-8. Hvad ændrer sig på kontoen, når man får Activ?

Kontoen betragtes som bekræftet af en rigtig deltager i projektet. Det påvirker den fair funktion af henvisninger og tilliden til aktivitet.

### 17-9. Hvorfor vises Activ netop efter det første panel?

Fordi aktivering af det første panel er et tydeligt tegn på reel deltagelse. Projektet bruger dette skridt som filter mod tomme konti.

### 17-10. Kan man miste Activ på grund af inaktivitet?

Nej. Activ er en permanent status og forsvinder ikke på grund af inaktivitet.

## 18. VIP NFT

### 18-1. Hvad er EFHC VIP NFT?

EFHC VIP NFT er et klubkort, nøglen til hele EFHC’s fremtidige økosystem, et digitalt tegn på tilhørsforhold og en nøgle til projektets fremtidige muligheder.

### 18-2. Hvad giver det at eje én EFHC VIP NFT?

At eje én EFHC VIP NFT giver øget generation for alle spillerens paneler.

### 18-3. Hvilke tegn viser, at VIP allerede er taget i betragtning?

Hvis VIP NFT allerede er taget i betragtning af systemet, vises VIP-status i interfacet, og de tilknyttede kontofordele bliver mærkbare.

### 18-4. Hvor kan jeg se VIP-effekten?

VIP-effekten er synlig i de afsnit, hvor projektet tager højde for fordelene ved VIP NFT, samt i topbjælken og i Profil/Indstillinger.

### 18-5. Skal jeg aktivere VIP manuelt?

Nej. Projektets logik er bygget til automatisk at kontrollere wallet og automatisk opdatere VIP-status, når NFT’en opdages i den rigtige samling.

### 18-6. Giver 2 eller 3 VIP NFT ekstra privilegier til spilleren?

Nej. For spilleren giver 2 eller 3 VIP NFT ikke ekstra privilegier ud over én VIP NFT.

### 18-7. Hvorfor forstærker den anden VIP NFT ikke effekten?

I projektet giver VIP et generationsboost som én aktiv status. Ekstra VIP NFT giver ikke ekstra boost, så effekten ikke vokser uendeligt.

### 18-8. Påvirker VIP ét panel eller alle?

VIP påvirker generationen fra alle brugerens paneler, ikke kun ét enkelt.

### 18-9. Hvordan kan jeg kontrollere, at VIP virkelig påvirker kontoen?

Kontrollér ikke kun, at VIP-status findes, men også de tilknyttede fordele i kontomekanikken, især dér hvor VIP-effekten tages i betragtning, herunder generering.

### 18-10. Skal en wallet være tilsluttet, for at botten kan se min VIP NFT?

Ja. For at botten kan se VIP NFT, skal den vide, hvilken wallet der hører til kontoen. Derfor skal Wallet være forbundet, og derefter kontrollerer du VIP-status i interfacet.

### 18-11. Kan jeg disponere over mit VIP NFT, som jeg vil?

Ja. EFHC VIP NFT kan overføres, gives som gave og sælges på markedspladser.

### 18-12. Hvis jeg sælger eller flytter mit VIP NFT til en anden wallet, hvad sker der så med min generering?

Botten scanner regelmæssigt blockchainen og kontrollerer, om NFT’en findes på din tilknyttede wallet. Hvis du sælger, giver væk eller flytter dit VIP NFT til en anden adresse, registrerer systemet det, deaktiverer din VIP-status, og genereringen fra alle dine paneler vender automatisk tilbage til basisraten.

## 19. Niveauer

### 19-1. Hvorfor skal jeg hæve mit niveau?

Vækst i niveau viser brugerens fremgang inde i projektet og hjælper med at se, hvordan kontoen udvikler sig. Det er en visuel og meningsfuld indikator for bevægelse fremad.

### 19-2. Hvad indeholder afsnittet Niveauer?

Afsnittet Niveauer viser alle projektets vækstskalaer: 12 niveauer af energifremgang, 6 niveauer i henvisningssystemet og andre niveaulinjer i projektet, hvis de senere bliver tilføjet.

### 19-3. Hvor mange niveauer af energifremgang findes der i projektet?

Projektet har 12 niveauer af energifremgang.

### 19-4. Hvor mange niveauer er der i henvisningssystemet?

Projektet har 6 niveauer i henvisningssystemet: fra 0 til 5.

### 19-5. Hvordan er niveauer nyttige for en almindelig spiller?

Niveauer hjælper dig med at forstå, hvor du er nu, hvor meget der allerede er gjort, hvad du skal bevæge dig mod næste gang, og hvilken næste milepæl der venter foran.

### 19-6. Hvordan hænger energiniveauer, henvisningsniveauer og den samlede kontovækst sammen?

De er dele af én samlet vej. Energigenerering driver hovedfremgangen, aktive henvisninger styrker henvisningslinjen, og sammen viser de, hvor stærkt kontoen udvikler sig.

### 19-7. Eco Initiate (0 kWh)

**Betydning for spilleren:** Dit første panel er installeret og klar til arbejde. Du tager det vigtigste skridt mod at blive en uafhængig producent af ren energi. Dette er din startstatus — du er lige trådt ind på generationsvejen.

**Præcis regel:** Niveauet Eco Initiate svarer til markeringen 0 kWh.

**Praktisk konsekvens:** Næste skridt er at starte vækst i generation gennem paneler og føre fremgangen op til 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Betydning for spilleren:** De første kilowatt er kommet i gang. Dine paneler genererer med succes grøn energi og giver naturen håb om en fremtid uden kulstof. Du ser allerede de første reelle resultater: energi er begyndt at komme, og fremgangen har flyttet sig.

**Præcis regel:** Niveauet Hope Bringer starter ved 100 kWh.

**Praktisk konsekvens:** Det næste mål er at opbygge stabilitet og nå 300 kWh til næste trin.

### 19-9. Energy Seeker (300 kWh)

**Betydning for spilleren:** Systemet fungerer fremragende og fylder stabilt nettet med miljøvenlig elektricitet. Hver energienhed, som panelerne producerer, fortrænger fossile brændstoffer. Kontoen er gået ind i en fase med stabil vækst: du er ikke længere en nybegynder, men en bruger med reel generation.

**Præcis regel:** Niveauet Energy Seeker starter ved 300 kWh.

**Praktisk konsekvens:** I praksis er dette et signal om, at du kan styrke panelerne og oftere bruge Exchange til at omdanne energi til hovedsaldo.

### 19-10. Nature's Voice (600 kWh)

**Betydning for spilleren:** Dit bidrag bliver mærkbart. Ved at generere energi med grøn teknologi bliver du naturens stemme og viser, at fremgang kan være miljøvenlig. Dit bidrag bliver mere synligt: fremgangen føles ikke længere som et tilfælde, men som en tydelig retning.

**Præcis regel:** Niveauet Nature's Voice starter ved 600 kWh.

**Praktisk konsekvens:** Det næste mål er 1000 kWh (Earth Ally). Det er nyttigt at sammenligne tempoet i Energy og antallet af aktive paneler.

### 19-11. Earth Ally (1000 kWh)

**Betydning for spilleren:** Den første megawatt-time er genereret. Dine paneler har produceret en imponerende mængde ren energi. Nu er du en vigtig deltager i den grønne omstilling og en trofast allieret for planeten. Du har passeret en vigtig milepæl: 1000 kWh er allerede en seriøs mængde akkumuleret generation.

**Præcis regel:** Niveauet Earth Ally starter ved 1000 kWh.

**Praktisk konsekvens:** I praksis er dette punktet, hvor væksten bliver mere forudsigelig: styrk din park af paneler, og hold energiudvekslingen regelmæssig.

### 19-12. Climate Fighter (2000 kWh)

**Betydning for spilleren:** Din generation gør en reel forskel mod klimaforandringer. Hver produceret kilowatt reducerer direkte behovet for at brænde kul og gas. Du presser allerede systematisk fremad: fremgang er synlig både i niveauet og i kontoens samlede dynamik.

**Præcis regel:** Niveauet Climate Fighter starter ved 2000 kWh.

**Praktisk konsekvens:** Næste skridt er at fastholde tempoet og nå 3500 kWh. Hold øje med generationshastigheden og brug VIP om nødvendigt.

### 19-13. Green Sentinel (3500 kWh)

**Betydning for spilleren:** Den stabile energistrøm fra dine paneler står vagt om ren luft. Du skaber mærkbar nytte for samfundet uden at efterlade et CO2-aftryk. Din konto bliver en vogter af stabil generation: væksten går sikkert fremad.

**Præcis regel:** Niveauet Green Sentinel starter ved 3500 kWh.

**Praktisk konsekvens:** I praksis betyder det, at panelerne allerede arbejder som et system — hold aktive paneler kørende og planlæg vækst mod 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Betydning for spilleren:** 5000 kWh ren generation. Kraften fra dine paneler fungerer som et usynligt skjold, der beskytter atmosfæren mod tusindvis af kilo drivhusgasudledning. 5000 kWh er allerede et tydeligt tegn på skala: du er nu blandt de stærke energideltagere.

**Præcis regel:** Niveauet Planet Defender starter ved 5000 kWh.

**Praktisk konsekvens:** Det næste mål er 7500 kWh. På dette trin styrker spillere ofte både paneler og deres henvisningsnetværk.

### 19-15. Eco Champion (7500 kWh)

**Betydning for spilleren:** Enestående produktionsvolumener. Du er en sand forkæmper for grøn energi, og dit bidrag ændrer mærkbart den globale energibalance til det bedre. Dette er niveauet for dem, der stabilt holder et højt generationstempo.

**Præcis regel:** Niveauet Eco Champion starter ved 7500 kWh.

**Praktisk konsekvens:** I praksis: hold disciplinen — aktive paneler, regelmæssig Exchange og kontrol over historik og saldi.

### 19-16. Planet Saver (10000 kWh)

**Betydning for spilleren:** 10 megawatt-timer. Du har genereret så meget ren energi, at du bogstaveligt talt hjælper med at redde hele økosystemer og viser maksimal effektivitet af dine paneler. 10.000 kWh er allerede ti megawatt-timer generation — et meget stærkt trin i fremgangen.

**Præcis regel:** Niveauet Planet Saver starter ved 10000 kWh.

**Praktisk konsekvens:** Det næste trin er 15000 kWh. På dette niveau giver det mening at optimere alt: paneler, VIP, henvisninger og køb.

### 19-17. Green Commander (15000 kWh)

**Betydning for spilleren:** Flagskibet for miljøvenlig generation. Dine paneler driver fremtiden, og de imponerende produktionsvolumener sætter helt nye, høje standarder for hele fællesskabet. Du er tæt på toppen: dette er et niveau i energiens lederklasse.

**Præcis regel:** Niveauet Green Commander starter ved 15000 kWh.

**Praktisk konsekvens:** I praksis: hold stabiliteten og voks mod 20000+ kWh, mens du følger aktive paneler og tempoet i Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Henvisningsniveau 0

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 0 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-20. Henvisningsniveau 1

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 1 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-21. Henvisningsniveau 2

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 10 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-22. Henvisningsniveau 3

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 100 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-23. Henvisningsniveau 4

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 300 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-24. Henvisningsniveau 5

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Der krediteres en engangsbonus for at nå dette niveau: 1000 EFHC.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Hvorfor er niveauernes navne knyttet til økologi og planeten?

Fordi selve spillets idé er knyttet til virtuel grøn energi, motivation af mennesker og et symbolsk bidrag til helingen af planeten Jorden.

## 20. FAQ / Hjælp

### 20-1. Hvor kan jeg åbne FAQ’en?

FAQ’en åbnes fra profilen som bottens indbyggede hjælpesektion, hvor svar på de vigtigste handlinger, skærme og projektregler er samlet.

### 20-2. Hvad er FAQ / Hjælp til?

Dette afsnit findes, så brugeren hurtigt kan finde klare svar, præcise tal, de reelle projektregler og betydningen af de vigtigste handlinger uden gætteri eller forvirring.

### 20-3. Hvorfor er FAQ’en skrevet så detaljeret?

Fordi projektet er flerlaget, og en kort, tør reference ikke dækker spillerens reelle spørgsmål. Her betyder mening, klarhed, præcise tal og de faktiske konsekvenser af handlinger noget.

### 20-4. Kan FAQ’en hjælpe mig med at forstå hele spillerens vej inde i botten?

Ja. En god FAQ skal ikke kun forklare enkelte knapper, men hele vejen: fra det første panel til energi, Exchange, saldi, niveauer, statuser og vækst i kontoen.

### 20-5. Hvad skal jeg gøre, hvis jeg ikke fandt svaret første gang?

Det er bedre at åbne et nærliggende afsnit efter mening og se på de tilstødende spørgsmål. I en stor bot hænger mange svar sammen, og én blok hjælper ofte med at forstå den næste.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. Hvad skal jeg kontrollere, hvis alt ser ødelagt ud?

Kontrollér tre ting: 1) Wallet — er wallet forbundet, og er hoved-wallet valgt, 2) saldi og historik — findes der et spor af din handling der, 3) det nødvendige afsnit (Panels / Energy / Exchange / Withdraw). Som regel ligger svaret et af disse steder.

### 20-8. Hvad er den hurtigste måde at forstå, hvad der skete med min EFHC?

Åbn saldohistorikken. Historikken viser præcist, hvad der ændrede saldoerne: en belønning, et køb, en veksling eller en udbetaling.

### 20-9. Hvor skal jeg begynde, hvis jeg åbner botten for første gang og ikke forstår noget?

Start med Energy (hovedskærmen), åbn derefter Panels, se på saldi og historik, og beslut først derefter, om du har brug for en wallet og en top-up.

### 20-10. Hvad er den hurtigste måde at finde det rigtige spørgsmål i FAQ’en på?

Den hurtigste måde er at åbne det relevante afsnit efter emne (Wallet / Panels / Exchange / Withdraw og så videre) og lede efter spørgsmålet der. Hvis du er i tvivl, så start med afsnittet FAQ / Hjælp og navigér efter nøgleord.
