# EFHC FAQ (DA)

Status: **RUNTIME MIRROR / CURRENT**
Runtime source: `frontend/src/data/faq/catalogs.ts`
Synced from checked-in application FAQ: `2026-10-11`.
Structure: 20 sections / 20 subsections / 230 Q&A items.

## 1. Om projektet

### 1-1. Hvad er EFHC?

EFHC er et spilprojekt om energi, fremskridt og udvikling af kontoen inde i botten. Brugeren aktiverer paneler, samler energi, veksler den til EFHC, følger sine saldi, stiger i niveauer, bevæger sig op i ranglisten og bruger projektets ekstra muligheder.

Forklaring:
— EFHC — Energy for Humanity Coin
— EFHCm — hovedmønter
— EFHCb — bonusmønter
— EFHCj — et eksternt EFHC-token på TON-netværket
— EFHC — samlet saldo (bonus + hovedsaldo)

### 1-2. Hvad skal jeg gøre i denne bot?

Din hovedopgave er at udvikle din konto. For at gøre det arbejder du med paneler, følger energigenereringen, bruger Exchange, ser dine saldi, forbinder en wallet, deltager i projektets ekstra mekanikker og styrker gradvist din fremgang.

### 1-3. Hvordan vokser jeg og kommer videre her?

Vækst inde i botten er bygget op omkring energi og aktivitet. Jo flere paneler, jo mere energi, jo flere nyttige handlinger og jo mere fremgang brugeren har, desto stærkere udvikler kontoen sig, og desto højere stiger den i projektets struktur.

### 1-4. Hvad er projektets vigtigste idé?

Den vigtigste idé i projektet er at vise vejen fra aktivering af et panel til generering af energi og derefter til et resultat i EFHC. Brugeren ser ikke abstrakte tal, men en sammenhængende kæde: panel, energi, veksling, saldo og udvikling.

### 1-5. Hvordan får jeg mine første EFHC her?

De første EFHC kommer fra to hovedkilder: belønninger (som bonusmønter EFHCb) og veksling af energi gennem Exchange (til hovedmønter EFHCm). Den stærkeste vej er paneler → energi → Exchange → hovedsaldo.

### 1-6. Hvor kommer min energi fra?

Energi kommer fra dine aktive paneler. Så længe panelerne er aktive, genererer de energi, og den samler sig som tilgængelig energi til veksling.

### 1-7. Hvad påvirker min vækst i projektet mest?

Det, der påvirker væksten mest, er antallet af aktive paneler og deres samlede generering. Den anden forstærker er VIP (hvis du har det), fordi det påvirker genereringen. Opgaver, reklamer og henvisninger er ekstra vækstkanaler.

### 1-8. Hvordan forstår jeg, at jeg bevæger mig den rigtige vej?

Hvis tre ting vokser — generering, tilgængelig energi og hovedsaldoen efter veksling — så bevæger du dig den rigtige vej. Du kan hurtigt kontrollere det gennem Energy og historikken over handlinger.

## 2. Hovedskærm

### 2-1. Hvad viser hovedskærmen?

Hovedskærmen er siden Energy. Den samler de vigtigste elementer i kontoens aktuelle tilstand: hurtige handlinger, information om fremgang og indgange til botens vigtige sektioner.

### 2-2. Hvad skal jeg kigge på først?

Først bør du se på topbjælken, den samlede saldo, Energy-skærmen og de tilgængelige handlinger. Det er netop de ting, der hurtigst viser kontoens aktuelle tilstand og hvad du kan gøre videre.

### 2-3. Hvor kan jeg se min aktuelle fremgang?

Den aktuelle fremgang vises i sektionerne, der er knyttet til energi, paneler, niveauer og rangering i botten. Der kan du se, hvordan brugeren bevæger sig frem i projektet.

### 2-4. Hvilke knapper på hovedskærmen er de vigtigste?

De vigtigste handlinger er Panels, Exchange, Direkte optankning i topbjælken og Hub. Hub viser kun knappen Optankning.

### 2-5. Hvad skal jeg kontrollere på hovedskærmen hver dag?

Tre ting: 1) hvor mange aktive paneler du har, 2) hastigheden på genereringen, 3) hvor meget tilgængelig energi der allerede er samlet til veksling.

### 2-6. Hvorfor ændrer hovedskærmen sig med tiden?

Fordi den afspejler kontoens levende tilstand. Når der kommer paneler, energi og handlinger, holder skærmen op med at være tom og begynder at vise flere nyttige data og mere fremgang.

### 2-7. Hvordan kan jeg se på hovedskærmen, at kontoen udvikler sig?

Når du ser vækst i fakta: genereringen er ikke nul, energi samler sig, og efter veksling vokser hovedsaldoen. Det er de mest ærlige tegn på udvikling.

## 3. Topbjælke

### 3-1. Hvad er topbjælken?

Topbjælken er et selvstændigt element i brugerfladen og den vigtigste hurtige informationsblok, som er tilgængelig på botens hovedsider.

### 3-2. Hvad vises i kontoens øverste bjælke?

Den øverste bjælke viser den samlede saldo, knapper til hurtig adgang til vigtige sektioner og kontoens statuslinje: VIP, Activ, niveau og brugernavn.

### 3-3. Hvorfor er topbjælken vigtig?

Fordi den hjælper dig med straks at se det vigtigste om din konto uden ekstra overgange: hvem du er, hvilken fremgang du har, om du har VIP, hvor mange mønter du samlet har, og hvilke hurtige handlinger der er tilgængelige.

### 3-4. Hvad viser den samlede saldo i topbjælken?

Den samlede saldo viser, hvor mange mønter du har i alt. Det er gjort for bekvemmelighed, så du ikke selv behøver at lægge ressourcer sammen for intern handling og for at få et hurtigt overblik over kontoen i spillet.

### 3-5. Hvorfor er den samlede saldo praktisk til intern handling?

Fordi den viser spillerens samlede aktiverekraft inde i spillet og hjælper med hurtigt at forstå, om der er nok ressourcer til interne handlinger.

### 3-6. Hvorfor er den samlede saldo ikke det samme som det, jeg kan hæve lige nu?

Fordi den samlede saldo omfatter både hovedmønter og bonusmønter. Bonusmønter bruges til spilprocessen og kan ikke hæves direkte.

### 3-7. Hvad bruges knappen «+» i den øverste bjælke til?

Knappen «+» starter en direkte EFHC-opfyldning via projektets tilknyttede eksterne forløb.

### 3-8. Hvorfor åbne Hub fra topbjælken?

For hurtigt at åbne projektets kort med relaterede handlinger og gå til det nødvendige eksterne flow uden ekstra navigation i grænsefladen.

### 3-9. Hvilke kontostatusser vises i den øverste bjælke?

Den øverste bjælke viser VIP-status, Activ-status, aktuelt niveau og kontoens brugernavn.

### 3-10. Hvad skal jeg gøre, hvis data i topbjælken virker forkerte?

Opdatér først siden og kontrollér saldohistorikken: den viser de faktiske operationer. Hvis historikken og saldoen stemmer overens, er dataene korrekte — du har måske bare kigget på den forkerte saldo, for eksempel den samlede i stedet for den primære eller bonussaldoen.

## 4. Profil

### 4-1. Hvad er sektionen Profil/Indstillinger?

Profil/Indstillinger er sektionen, hvor du styrer profilen og botens indstillinger. Her vises de vigtigste statuser, og personlige grænsefladeindstillinger er tilgængelige.

### 4-2. Hvad kan man gøre i profilen?

I profilen er de vigtigste brugerindstillinger samlet samt hurtige overgange til vigtige sektioner: Wallet, saldohistorik, FAQ og andre nyttige kontrolpunkter.

### 4-3. Hvad vises øverst i Profil/Indstillinger?

Øverst i Profil/Indstillinger vises avatar, Telegram-navn samt statusserne Activ og VIP, hvis du allerede har dem.

### 4-4. Hvad er Global ID, og hvor kan jeg se det?

Global ID er den permanente identifikator for din EFHC-konto. Den vises i Profil under dit brugernavn. Global ID gør det muligt at identificere din konto præcist, for eksempel når du kontakter support.

### 4-5. Hvor skifter jeg sprog?

Sproget ændres i Profil/Indstillinger.

### 4-6. Hvordan indstiller jeg lyde og haptisk feedback?

Åbn Profil. Tryk på tandhjulet i kortet „Interface”. Find afsnittet „Lyd og haptisk feedback” i vinduet, der åbnes. Her kan du slå interfacelyde til eller fra, justere lydstyrken og slå haptisk feedback til eller fra.

### 4-7. Hvorfor er profilen overhovedet nødvendig?

Profilen er nødvendig som dit personlige kontrolpunkt for kontoen. Her ser brugeren ikke kun statusser, men åbner også vigtige undersektioner, der er forbundet med wallet, historik, sprog og hjælpesystemet.

### 4-8. Hvor åbner jeg saldohistorikken i profilen?

I sektionen Profil/Indstillinger er der en særskilt indgang til saldohistorikken, hvor indbetalinger og fradrag vises.

### 4-9. Hvor i Profil kan jeg åbne Wallet for at arbejde med walleten?

I Profil er der et særskilt punkt Wallet. Åbn det, når du skal forbinde en wallet, kontrollere bindingen eller gå til handlinger, der er knyttet til walleten.

### 4-10. Hvor i Profil kan jeg hurtigt åbne FAQ, hvis jeg har brug for et svar?

I Profil er der adgang til FAQ. Åbn den, når du har brug for et hurtigt svar om interfacet, saldi, paneler, energi, veksling, udbetaling eller andre appfunktioner.

### 4-11. Hvad findes i sektionen “Support og information”?

Der er samlet hjælpepunkter: FAQ, tips/information og alt det, der hjælper brugeren med at forstå projektet uden forvirring.

### 4-12. Hvor mange sprog er projektets interface tilgængeligt på?

Bot-interfacet og hjælpesystemet (FAQ) er oversat til 16 sprog. Du kan vælge det sprog, der passer dig bedst, i profilindstillingerne, og systemet tilpasser straks alle tekster og hele interfacet til dit valg.

## 5. Wallet-skærm

### 5-1. Hvorfor er hovedwalleten nødvendig?

Den primære TON-wallet er standardadressen for eksterne TON/USDT-handlinger i Browser Shop. Ved en sådan betaling skal den tilsluttede adresse matche den primære adresse præcist; en anden adresse er ikke tilladt. Withdraw har en særskilt regel: enhver aktiv tilknyttet wallet kan vælges, mens den primære kun er standardvalget.

### 5-2. Skal jeg oplyse EFHC om min seed phrase, private nøgle eller wallet-adgangskode?

Nej. EFHC beder ikke om din hemmelige gendannelsesfrase til din wallet (seed phrase), private nøgle eller wallet-adgangskode. Del aldrig disse oplysninger med nogen, heller ikke hvis en besked ser ud til at komme fra projektet eller supporten.

### 5-3. Kan jeg skifte den primære wallet?

Ja. Brugeren kan vælge en anden primær wallet blandt de allerede tilknyttede.

### 5-4. Kan jeg slette en tilknyttet wallet?

Ja. Hvis en wallet ikke længere er nødvendig, kan dens tilknytning fjernes.

### 5-5. Hvorfor kan den samme wallet ikke knyttes til to konti?

Den samme wallet må ikke bruges i to forskellige konti samtidig. Hvis en wallet allerede er knyttet til én konto, skal den først fjernes fra den konto, før den kan knyttes til en anden. Det forhindrer forvirring i statusser, kontroller og resultater, der er knyttet til walleten.

### 5-6. Hvad sker der, hvis jeg trykker på en handling, hvor en wallet kræves, men jeg ikke har en?

Hvis den valgte funktion kræver en wallet, starter botten først logikken for at forbinde en wallet. Derefter kan du vende tilbage til den ønskede handling og udføre den normalt.

### 5-7. Kan jeg forbinde flere wallets, og hvorfor er det nyttigt?

Ja. Du kan forbinde flere wallets, så du har en reserveadresse eller kan adskille forskellige brugsscenarier. Samtidig vælges én wallet som primær — det er netop den, systemet bruger som standard.

### 5-8. Hvad skal jeg gøre, hvis jeg vil bruge min wallet på en anden konto?

Først skal denne wallet fjernes fra den nuværende konto. Først derefter kan den knyttes til en anden konto. Den samme wallet må ikke være knyttet til to konti samtidig.

### 5-9. Kan jeg hæve til en ikke-primær wallet?

Ja. I Withdraw kan du vælge enhver aktiv tilknyttet wallet. Den primære wallet er valgt som standard, men en anden aktiv wallet behøver ikke først at blive gjort primær.

### 5-10. Hvad skal jeg gøre, hvis wallet er forbundet, men hævning stadig ikke er tilgængelig?

Kontrollér tre ting: Der er valgt en aktiv tilknyttet wallet til udbetalingen, hovedsaldoen i EFHCm er tilstrækkelig, og udbetalingsbeløbet er mindst 10 EFHCm. Den primære wallet er ikke påkrævet, hvis en anden aktiv tilknyttet wallet er valgt.

### 5-11. Hvor kan jeg tjekke, hvilken wallet der aktuelt er knyttet til min konto?

Det skal tjekkes i Wallet-sektionen. Her ser brugeren, hvilke wallets der er knyttet til kontoen, og hvilken af dem der bruges inden for kontoen.

### 5-12. Hvad skal jeg gøre, hvis jeg mister adgangen til min primære TON-wallet?

Tilknyt en ny TON-wallet, gør den primær om nødvendigt, og fjern tilknytningen til den gamle kompromitterede adresse. Efter frakoblingen bruges den gamle adresse ikke længere af denne konto; frakobling betyder ikke, at adressen slettes uigenkaldeligt på TON-netværket.

## 6. Balancer og historik

### 6-1. Hvorfor har jeg tre forskellige saldi?

Fordi midlerne har forskellige roller inde i botten. Den samlede saldo viser alt samlet, bonussaldoen er nødvendig til den interne spilcyklus, og hovedsaldoen viser det resultat, som allerede kan bruges til nøglehandlinger og udbetaling.

### 6-2. Hvad er bonusbalancen?

Bonusbalancen er en intern spilbalance. Den bruges til udvikling inde i botten, krediteres for opgaver, henvisninger, gaver og andre interne projektmekanikker, men kan ikke udbetales direkte.

### 6-3. Hvad er hovedsaldoen?

Hovedsaldoen er de primære EFHCm. Det er netop her resultatet af spilcyklussen bliver til, og det er netop herfra nøglehandlinger, inklusive udbetaling, er tilgængelige.

### 6-4. Hvorfor kan ét intern handling påvirke både bonus- og hovedsaldoen?

Ved alle interne udgifter i projektet trækkes midler først fra bonussaldoen. Hvis det ikke er nok, trækkes resten fra hovedsaldoen.

### 6-5. Hvorfor er der flere poster i historikken med det samme?

Én handling kan påvirke flere dele af bevægelsen af midler, derfor viser botten den med flere linjer for at afspejle de forskellige ændringer separat.

### 6-6. Hvor kan jeg se, hvor EFHC kom fra eller hvor de blev brugt?

Til det findes sektionen for balancehistorik. Den viser indbetalinger, fradrag, veksling, intern handling, udbetaling og andre ændringer af midlerne.

### 6-7. Hvorfor kan den samlede saldo være høj, men jeg kan hæve mindre?

Fordi den samlede saldo lægger hoved- og bonussaldo sammen. Udbetaling er kun tilladt fra hovedsaldoen, mens bonussaldoen er beregnet til projektets interne cyklus. Derfor skal du se på netop hovedsaldoen ved udbetaling.

### 6-8. Hvor ser jeg hurtigst, hvad der præcist ændrede min saldo?

I balancehistorikken. Der kan du se, hvilken handling der gav en indbetaling eller et fradrag, og hvilken saldo der blev berørt.

### 6-9. Hvordan vælger jeg den type operationer, der skal vises i Historik?

Åbn Profil → Historik og vælg det ønskede filter: „Alle“, „Køb“, „Veksling“, „Udbetaling“, „Bonusser“ eller „Paneler“. Listen viser derefter operationer af den valgte type.

### 6-10. Hvilke oplysninger kan jeg se i detaljerne for en operation i Historik?

Åbn den ønskede operation i Historik. Detaljerne kan vise dato og klokkeslæt, status, operationstype, beløb og andre tilgængelige oplysninger. Det præcise indhold afhænger af operationen.

### 6-11. Hvordan ser jeg ældre operationer i Historik?

Åbn Profil → Historik. Hvis der findes ældre poster, skal du trykke på „Indlæs flere“ nederst på listen. Hvis du vil gemme hele operationsloggen og se den separat, kan du hente den som CSV eller XLSX med knapperne over operationslisten.

### 6-12. Hvad betyder advarslen om, at Historik ikke er indlæst fuldstændigt?

Det betyder, at en del af historikken ikke kunne hentes lige nu. Poster, der allerede er vist, kan blive stående på skærmen. Tryk på „Opdater“, og kontroller Historik igen.

### 6-13. Hvorfor kan bonussaldoen ikke hæves direkte?

Fordi bonusmønter er en del af projektets interne cyklus. Udbetaling er kun tilladt fra hovedsaldoen.

### 6-14. Hvorfor ændrer historikken sig ikke helt ens overalt med det samme efter udbetaling eller veksling?

Fordi forskellige skærme ikke altid opdateres samtidig. Tjek: opdater sektionen → kontroller saldoen → kontroller historikken.

### 6-15. Hvad sker der, hvis jeg ved svag internetforbindelse ved et uheld trykker på knappen til panelaktivering eller veksling flere gange i træk? Bliver der trukket ekstra coins?

Mens en handling behandles, bør gentagne tryk ikke medføre en ny debitering for den samme handling. En ny handling, som du bekræfter separat, kan medføre en ny debitering. Bekræft den derfor ikke igen uden grund.

## 7. Paneler

### 7-1. Hvor mange EFHC kræves for at aktivere ét panel?

Der kræves 100 EFHC for at aktivere ét panel.

### 7-2. Hvad giver aktivering af det første panel med det samme?

Intern handling af det første panel starter straks energigenerering, åbner vejen til fremskridt, skaber vejen til hoved-EFHCm og giver den permanente aktive status Activ.

### 7-3. Hvornår starter et panel med at generere?

Genereringen starter straks efter aktivering af panelet.

### 7-4. Hvor lang levetid har et panel?

Hvert panel har en 180-dages panelcyklus.

### 7-5. Hvad sker der med panelet efter den 180 dage lange cyklus er afsluttet?

Når den 180 dage lange cyklus er afsluttet, deaktiveres panelet og flyttes til Archive som en del af deltagerens energiske fremskridtshistorik.

### 7-6. Hvilke to paneltilstande findes i interfacet?

I sektionen “Paneler” er der to faner: “Aktive paneler” og “Arkiv”. Under “Aktive paneler” findes paneler, som fortsætter genereringscyklussen. I “Arkiv” findes paneler, som har afsluttet den aktive cyklus, med deres historik bevaret.

### 7-7. Hvad viser kortet for hvert panel?

Panelkortet viser panelets nummer, aktiveringsdato, hvor meget energi det allerede har genereret, og hvor lang tid der er tilbage. For et afsluttet panel i Arkiv vises også deaktiveringsdatoen.

### 7-8. Kan jeg aktivere mere end ét panel med det samme?

Ja. Du kan aktivere paneler efter hinanden og dermed øge antallet af aktive paneler. Jo flere aktive paneler, desto højere samlet energigenerering og desto hurtigere vokser dine fremskridt.

### 7-9. Hvad betyder timeren “Tilbage” på et panel?

Timeren viser, hvor meget tid der er tilbage, før panelets 180-dages cyklus slutter. Når tiden udløber, flytter panelet automatisk til Archive og holder op med at være aktivt.

### 7-10. Hvorfor blev jeg Activ efter aktivering af det første panel?

Fordi Activ er en bekræftelse på reel deltagelse og en beskyttelse af projektet mod bots. Projektet knytter Activ til aktiveringen af det første panel, så kun levende deltagere får status.

### 7-11. Hvorfor er aktive paneler vigtigere end arkivpaneler?

Aktive paneler genererer energi nu — det er dem, der giver dit nuværende væksttempo. Arkivpaneler er afsluttede paneler; de bevarer historikken, men giver ikke nuværende generering.

### 7-12. Hvorfor har jeg færre aktive paneler, end jeg har aktiveret?

Fordi en del af panelerne kan have afsluttet deres 180-dages periode og flyttet til Archive. Aktive paneler er dem, der arbejder nu. Archive er afsluttede paneler; de giver ikke nuværende generering.

### 7-13. Kan aktive paneler “forsvinde” på grund af grænsen på 1000?

Nej. Grænsen på 1000 betyder, at du ikke kan have mere end 1000 aktive paneler samtidigt. Allerede aktiverede aktive paneler “forsvinder” ikke: de forbliver aktive indtil periodens slutning og flytter derefter til Archive.

### 7-14. Hvad skal jeg gøre, hvis jeg har aktiveret et panel, men genereringen ikke ændrede sig med det samme?

Kontrollér:
— Opdater sektionen Panels
— Se om panelet er dukket op i Active
— Åbn Energy og kontrollér genereringshastigheden
— Kontrollér balancehistorikken (der skal være et fradrag på 100 EFHC)

### 7-15. Hvorfor er Archive-paneler vigtige, hvis de ikke længere genererer?

Archive gemmer historikken om dine paneler og gennemførte cyklusser. Det er din “vækstbiografi”, men den aktuelle generering kommer kun fra aktive paneler.

### 7-16. Kan jeg aktivere et panel og straks se, at det er aktivt?

Ja. Det aktiverede panel skal vises i listen Active, og aktiveringen af det afspejles i balancehistorikken.

### 7-17. Hvor meget energi giver ét panel på 180 dage?

Ét panel ved basisraten giver 107.61984000 kWh på 180 dage. Med EFHC VIP NFT er genereringen 115.24032000 kWh.

## 8. Energi

### 8-1. Hvad viser siden Energy?

På siden Energy vises energifremgang, en fremskridtsbjælke for energigenerering, antallet af aktive paneler, den samlede panelgenerering pr. sekund og andre nøgleindikatorer for den aktuelle tilstand.

### 8-2. Hvad viser fremskridtsbjælken på siden Energy?

Fremskridtsbjælken viser vejen til spillerens næste fremskridtsniveau på skalaen med 12 niveauer.

### 8-3. Hvad betyder panelernes samlede generering pr. sekund?

Grundgenereringen for ét aktivt panel er 0.00000692 kWh pr. sekund. Med VIP genererer ét aktivt panel 0.00000741 kWh pr. sekund. Den samlede generering pr. sekund er den gældende sats ganget med antallet af aktive paneler.

### 8-4. Hvorfor er energi så vigtig?

Fordi energi er den centrale kerne i fremskridt i EFHC. Gennem den går brugeren fra paneler til et resultat, som påvirker saldo, niveauer, rangering og udviklingen af kontoen.

### 8-5. Kan man ud fra Energy forstå, hvor stærk kontoen er?

Ja. Siden Energy viser hurtigt systemets aktuelle styrke: hvor mange paneler der arbejder, hvilken generering der kører lige nu, hvor meget energi der allerede er akkumuleret, og hvor langt brugeren er fra næste niveau.

### 8-6. Hvorfor tælles tilgængelig energi og hovedsaldo separat?

Fordi det er to forskellige størrelser. Tilgængelig energi viser de akkumulerede kWh, mens hovedsaldoen viser de vigtigste EFHCm, som allerede er modtaget. Disse værdier hænger sammen, men de er ikke det samme.

### 8-7. Hvorfor vokser energien af sig selv, mens hovedsaldoen ikke stiger automatisk?

Fordi energiakkumulering og vækst i hovedsaldoen sker på forskellige trin. Først genererer panelerne energi, og hovedsaldoen stiger først efter en separat exchange-handling eller et andet scenarie, der krediterer hoved-EFHCm.

### 8-8. Hvad er især vigtigt at følge i Energy hver dag?

Antallet af aktive paneler, genereringshastigheden og den tilgængelige energi — det er de tre vigtigste pejlemærker for kontoens tilstand.

### 8-9. Hvordan kan jeg se i Energy, at mine paneler virkelig arbejder?

Hvis du i Energy kan se aktive paneler og ikke-nul generering, og den tilgængelige energi gradvist vokser, så arbejder panelerne. Hvis genereringen er 0 og energien ikke akkumuleres, er der ingen aktive paneler, eller du ser på den forkerte blok.

### 8-10. Hvorfor kan de løbende energital på skærmen nogle gange blive lidt korrigeret eller hoppe?

Energitallene på skærmen opdateres løbende. Når appen kontrollerer den opsamlede energimængde, kan den viste værdi ændre sig lidt.

## 9. Veksling

### 9-1. Hvad er Exchange?

Exchange er den sektion, hvor energi bliver til hoved-EFHCm. Det er et af de vigtigste trin på brugerens vej inde i projektet.

### 9-2. Hvad betyder reglen 1 kWh = 1 EFHCm?

Det er projektets faste interne kurs. Hver energienhed konverteres til den samme mængde EFHCm.

### 9-3. Hvad sker der efter vekslingen?

Efter vekslingen vises energiens resultat på hovedsaldoen som hoved-EFHCm. Det er ikke længere bare akkumuleret energi, men et resultat, der deltager i projektets nøglehandlinger.

### 9-4. Kan man veksle bonusmønter direkte uden energi?

Nej. Bonusmønter deltager først i den interne cyklus: gennem dem aktiveres et panel, panelet genererer energi, og først derefter veksles energien til hoved-EFHCm.

### 9-5. Hvad skal jeg gøre, hvis jeg har foretaget en veksling, men ikke ser resultatet med det samme?

Opdater først sektionen Exchange og kontrollér hovedsaldoen. Åbn derefter balancehistorikken: der skal være en post om vekslingen. Hvis posten er der, er vekslingen gennemført, selv om du ikke straks lagde mærke til ændringen på skærmen.

— Opdater sektionen
— Kontrollér saldoen
— Kontrollér historikken

### 9-6. Kan jeg veksle energi og straks anmode om udbetaling?

Ja, hvis der efter vekslingen er nok EFHCm på hovedsaldoen, udbetalingsbeløbet ikke er lavere end 10 EFHCm, og walleten er tilsluttet og valgt som primær.

### 9-7. Hvad er bedst: at veksle ofte eller at akkumulere?

Det afhænger af dit mål. Hyppig veksling er praktisk til kontrol og handlinger, mens akkumulering er praktisk til sjældnere og større skridt. Reglen er én: resultatet af vekslingen går til hovedsaldoen.

### 9-8. Hvorfor falder den tilgængelige energi efter veksling?

Fordi du overfører en del af den akkumulerede energi til EFHCm gennem Exchange. Energien forsvinder ikke — den bliver til mønter.

Vigtigt: mængden af energi på hovedskærmen i Energy skal ikke “falde” som dine samlede fremskridt og påvirker ikke rangering og niveau bagud — den afspejler din vækstvej og det samlede genereringsresultat.

### 9-9. Hvilken energi kan jeg allerede veksle?

Du kan veksle den energi, som allerede er akkumuleret og blevet tilgængelig. Det er netop den tilgængelige energi — den klar-til-brug mængde til handling i sektionen Exchange.

### 9-10. Findes der en minimumsgrænse for at veksle energi til hoved-EFHCm?

Der er ingen faste grænser, men vekslingslogikken følger kursen 1 kWh = 1 EFHCm. Det er fornuftigt at opsamle og veksle hele energiværdier fra 1 kWh, så resultatet straks kan ses på hovedsaldoen.

## 10. Udbetaling

### 10-1. Hvorfor kan jeg ikke hæve EFHC?

Normalt skyldes det, at der ikke er nok midler på hovedsaldoen, at walleten ikke er tilsluttet, eller at beløbet er mindre end den minimale udbetalingstærskel. Du bør starte kontrollen med Wallet og hovedsaldoen.

### 10-2. Hvordan foregår udbetalingen?

Når anmodningen er sendt, går den til behandling. Når anmodningen er bekræftet, sendes midlerne til den angivne wallet. Den aktuelle status kan kontrolleres i sektionen “Udbetaling”.

### 10-3. Hvorfor ændrede saldoen sig med det samme efter udbetalingsanmodningen?

Fordi botten straks registrerer starten på denne handling i systemet. Det er nødvendigt, så brugeren kan se, at handlingen allerede er knyttet til hans midler og accepteret af systemet.

### 10-4. Fra hvilken saldo kan man foretage en udbetaling?

Udbetaling er kun mulig fra hovedsaldoen.

### 10-5. Hvad er minimumsudbetalingen?

Minimumsbeløbet for udbetaling er 10 EFHCm.

### 10-6. Hvor lang tid tager en udbetalingsanmodning normalt at blive behandlet?

Udbetaling sker gennem en anmodning og behandling af en operatør. Hvis resultatet ikke er synligt med det samme, så kontrollér anmodningens status og historikken over handlinger — der afspejles den reelle tilstand. Hvis anmodningen ikke ændrer sig i lang tid, hjælper det normalt at opdatere sektionen og kontrollere igen senere.

### 10-7. Kan man annullere en udbetalingsanmodning?

Ja, hvis anmodningen endnu ikke er behandlet. Annullering er tilgængelig for en ventende anmodning. Efter annulleringen skal du kontrollere hovedsaldoen og historikken over handlinger: hvis midlerne blev tilbageholdt, returneres de.

### 10-8. Hvor kan jeg se, at anmodningen er annulleret?

Det ses på anmodningens status og på posten i historikken over handlinger. Efter annullering bør du også kontrollere hovedsaldoen.

### 10-9. Hvad skal jeg gøre efter at have indsendt en udbetalingsanmodning?

Kontrollér anmodningens status og historikken over handlinger — der kan du se den reelle status for anmodningen og bevægelsen af midler.

### 10-10. I hvilke tokens og på hvilket netværk foretages udbetalinger?

Udbetalinger sker kun i EFHC-tokens og udelukkende på TON-blockchain-netværket (The Open Network). Der findes ingen andre udbetalingsmuligheder i projektet.

## 11. Opgaver

### 11-1. Hvad giver opgaver mig?

Opgaver giver kun bonusmønter og motiverer spilleren til at deltage i kontoens aktivitet.

### 11-2. Hvor kan jeg se, hvor mange bonus-EFHCb jeg har tjent på opgaver?

Åbn Opgaver. Øverst på skærmen kan du se, hvor mange bonus-EFHCb du har tjent i alt, og hvor meget der er tilbage på din bonussaldo. Du kan også se disse saldi under Profil → Transaktionshistorik, hvor samlet saldo, hovedsaldo og bonussaldo vises øverst.

### 11-3. Hvordan modtager jeg en belønning for en opgave?

Du skal opfylde opgavens betingelser, hvorefter botten automatisk registrerer fuldførelsen og krediterer den angivne belønning.

### 11-4. Hvorfor blev opgaven ikke fuldført?

Det kan ske, hvis betingelserne endnu ikke er opfyldt helt, handlingen ikke blev gennemført helt, eller resultatet endnu ikke er opdateret i systemet.

### 11-5. Kan jeg udføre den samme opgave igen?

Det afhænger af opgavetypen. Nogle opgaver er kun engangsopgaver, mens andre kan gentages efter projektets logik.

### 11-6. Giver alle opgaver den samme belønning?

Nej. Belønningens størrelse afhænger af den konkrete opgave og dens betingelser. Men belønningstypen er den samme her: bonusmønter.

### 11-7. Hvorfor har jeg brug for opgaver, hvis der findes paneler?

Opgaver er en ekstra vej til vækst. De erstatter ikke paneler, men hjælper dig med at samle bonusmønter, som senere kan bruges inde i spilcyklussen.

### 11-8. Hvorfor går belønningen fra opgaver ikke til hovedsaldoen?

Fordi opgaver giver bonus-EFHCb. Det er en intern belønning i spilcyklussen, så den krediteres bonussaldoen.

### 11-9. Hvorfor slutter eller forsvinder opgaver nogle gange?

Fordi opgaver kan være midlertidige eller begrænsede. Hvis en opgave er væk, betyder det, at den er afsluttet eller ikke er aktiv lige nu.

### 11-10. Hvor kan jeg se alle tilgængelige opgaver?

I sektionen Opgaver. Der vises listen over tilgængelige opgaver og deres betingelser.

### 11-11. Hvad viser et opgavekort?

Et opgavekort viser opgavens navn og beskrivelse, EFHCb-bonussen, opgavetypen, en statusbesked og handlingsknappen. Kortet gør det nemt at se, hvad du skal gøre, og om handlingen er tilgængelig nu.

### 11-12. Hvilke typer opgaver kan vises i sektionen "Opgaver"?

I "Opgaver" kan der vises opgaver om at se reklamer, udføre handlinger i Telegram, interagere med partnere og sociale netværk, besøge et website og andre tilgængelige handlinger. Det konkrete udvalg kan ændre sig. Følg beskrivelsen og handlingsknappen på opgavekortet.

### 11-13. Hvorfor kom belønningen for opgaven ikke med det samme?

Nogle gange tager det tid, før resultatet opdateres. Kontrollér: opdater Opgaver → kontrollér bonussaldoen → kontrollér historikken over handlinger.

### 11-14. Jeg abonnerede på kanalen i opgaven, men opgaven bliver ikke godkendt. Hvorfor?

Kontrollen af et abonnement tager nogle gange et par minutter. Hvis dit abonnement endnu ikke er registreret, så vend tilbage til Tasks senere og tryk på kontrolknappen igen.

## 12. Henvisninger

### 12-1. Hvad hedder sektionerne på siden Henvisninger?

Siden Henvisninger bruger sektionerne Aktiv og Inaktiv.

### 12-2. Hvad er en aktiv og en inaktiv henvisning?

En aktiv henvisning er en spiller, som allerede har aktiveret mindst ét panel og fået Activ-status. En inaktiv henvisning har endnu ikke aktiveret sit første panel og giver derfor endnu ikke ret til en henvisningsbonus.

### 12-3. Hvad kan jeg se på listen over mine henviste brugere?

På listerne over aktive og inaktive henviste brugere kan du se brugerens navn, Activ-status, antal paneler og den samlede generering, hvis oplysningerne er tilgængelige. Siden viser også antallet af aktive, inaktive og alle henviste brugere.

### 12-4. Hvornår krediteres henvisningsbonusser?

Henvisningsbonusser kontrolleres automatisk af botten. Så snart en spiller bliver aktiv, krediteres bonussen automatisk med det samme.

### 12-5. Hvordan hænger Activ sammen med henvisninger?

Activ viser, at en bruger er en reel deltager i projektet og ikke en botkonto. Det er vigtigt for en fair henvisningsmodel og beskyttelse mod botfarme.

### 12-6. Hvilken grundbonus krediteres for hver aktiv henvisning?

For hver af dine direkte henvisninger krediteres én bonus på 0.1 EFHCb — kun én gang, når henvisningen aktiverer sit første panel og får Activ.

### 12-7. Hvorfor har jeg henvisninger, men ingen bonus blev krediteret?

Bonussen krediteres først, når en direkte henvisning aktiverer sit første panel. Indtil da er personen inaktiv; senere paneler udløser ikke endnu en henvisningsbonus.

### 12-8. Hvor krediteres 0.1 EFHCb for en aktiv henvisning?

Bonusen på 0.1 EFHCb for aktivering af en direkte henvisning krediteres én gang til bonussaldoen. Lvl-belønninger krediteres også til den samme EFHCb-bonussaldo. Hele cyklussen er 1.000 EFHCb for 10.000 aktive direkte henvisninger plus 1.411 EFHCb i Lvl-belønninger, i alt 2.411 EFHCb.

### 12-9. Hvor kan jeg se, hvor mange henvisningsbonusser jeg har optjent i alt?

Åbn "Henvisninger". Øverst på siden kan du se, hvor mange henvisningsbonusser du har optjent i alt, og hvor mange bonus-EFHCb der aktuelt er tilbage på din bonussaldo.

### 12-10. Hvordan ser jeg, hvor mange aktive henvisninger der mangler til næste Lvl?

Åbn «Henvisninger» og se kortet «Henvisningsniveau». Det viser dit nuværende Lvl, antal aktive henvisninger, målet for næste niveau og din fremgang. Hvis du har nået maksimumsniveauet, vises det særskilt.

### 12-11. Hvor kan jeg få mit henvisningslink?

I sektionen Henvisninger. Der vises dit henvisningslink og listen over inviterede brugere.

### 12-12. Hvordan deler jeg mit henvisningslink?

Åbn Henvisninger. Du kan kopiere dit link eller sende det direkte via Telegram, WhatsApp, Viber, Facebook eller X. Vælg den metode, du foretrækker, og send invitationen.

### 12-13. Er det tilladt at oprette ekstra konti via dit eget referralslink?

Ja. Projektets regler forbyder det ikke. Men tomme konti giver ingen fordel. Henvisningsbonusser tæller først, når den inviterede konto faktisk begynder at deltage i projektet, aktiverer mindst ét panel og får Activ-status.

### 12-14. Kan jeg ændre min inviterer efter registrering?

Nej. Referral-forbindelsen fastlægges i det øjeblik, du første gang går ind i projektet via et invitationslink, og den kan ikke ændres senere.

## 13. Hub

### 13-1. Hvad kan jeg gøre i Hub?

Hub har to handlinger: Optankning og EFHC VIP NFT. Detaljer om de eksterne forløb vises først efter, at du forlader Hub.

### 13-2. Hvad gør knappen «Optankning»?

Den åbner fortsættelsen på en ekstern Web-side. Produkter, priser og betalingsmetoder vises ikke, før du forlader Hub.

### 13-3. Hvor bliver EFHC-top-up krediteret efter bekræftelse?

Et EFHCm-top-up krediteres hovedsaldoen.

### 13-4. Hvis jeg har modtaget en VIP NFT via GetGems, hvor kan jeg se, at den er aktiv?

Tjek VIP-status i appen og at NFT’en findes i den tilknyttede wallet.

### 13-5. Har jeg brug for en tilsluttet wallet til handlinger fra Hub?

Handlinger gennem en ekstern wallet kræver en tilsluttet wallet. Hub åbnes uden en særskilt intern udgift og fungerer som udgangspunkt for at åbne links.

### 13-6. Hvor kan jeg kontrollere, at EFHC-top-up faktisk blev krediteret?

Tjek hovedsaldoen og historikken over operationer: der bør være et spor af top-up dér.

### 13-7. Er der skins i Hub?

Skins er ikke Hub-kort.

### 13-8. Hvordan får jeg projektets skins?

Skins låses op, efterhånden som kontoen udvikler sig, og de er knyttet til de 12 achievements-niveauer.

## 14. Navigation og regler

### 14-1. Hvornår bør jeg åbne afsnittet “Navigation og regler”?

Åbn dette afsnit, når du hurtigt skal forstå skærmenes logik, finde den nødvendige funktion i appen eller afklare de grundlæggende regler for appens sektioner.

### 14-2. Hvilke skærme bør jeg åbne først, hvis jeg bruger appen for første gang eller efter en lang pause?

Det er bedst at starte med hovedskærmen, topbjælken og Profil. Derefter er det lettere at gå til Wallet, Panels, Energy, Exchange, Udbetaling, Tasks, Referrals, Transaktionshistorik og Hub alt efter din aktuelle opgave.

### 14-3. Hvordan forstår jeg, i hvilken sektion jeg skal lede efter den funktion, jeg har brug for?

Vælg sektionen efter handlingen: Profil til kontoen, Wallet til wallet, Panels til paneler, Energy til generering, Exchange til udveksling, Udbetaling til udbetalinger, Tasks til opgaver, Referrals til invitationer og Hub til overgangen Optankning.

### 14-4. Hvor er indgangen til Profil?

Indgangen til Profil findes øverst i grænsefladen via knappen “Profil”.

### 14-5. Hvordan åbner jeg appens indstillinger for udseende?

På appens hovedskærme finder du tandhjulsknappen nederst til højre ved siden af den nederste navigation. Tryk på den for at åbne redigering af udseendet. Når redigeringen er åben, erstattes tandhjulet af en knap med et flueben til at gemme ændringerne.

### 14-6. Hvad er forskellen på appens overordnede tema og udseendet af enkelte elementer?

Det overordnede tema ændrer hele appens udseende. I redigeringstilstand kan du også vælge en anden variant for enkelte understøttede elementer. Varianterne kan skiftes med et tryk eller et vandret swipe.

### 14-7. Hvordan gemmer jeg det valgte udseende?

Når du er færdig med at tilpasse udseendet, trykker du på knappen med fluebenet nederst til højre. Det valgte udseende gemmes derefter og bruges i appen.

### 14-8. Hvorfor kræver nogle handlinger en separat bekræftelse?

En separat bekræftelse beskytter kontoen og reducerer risikoen for utilsigtede handlinger ved vigtige operationer.

### 14-9. Hvorfor er nogle handlinger tilgængelige straks, mens andre afhænger af kontotilstanden?

Nogle funktioner afhænger af kontotilstanden, om der findes et panel, en tilsluttet wallet, aktivitetshistorik eller andre interne projektbetingelser.

### 14-10. Hvordan forstår jeg forskellen mellem Profil, Wallet og Transaktionshistorik?

Profil er afsnittet med kontodata og indgange til relaterede funktioner. Wallet er afsnittet til at tilknytte og kontrollere en wallet. Transaktionshistorik er historikken over operationer og saldo-bevægelser.

### 14-11. Hvad gør jeg, hvis jeg ikke kan se den nødvendige knap eller sektion?

Opdater først skærmen og kontroller, om en anden sektion er åben. Gå derefter tilbage til hovedskærmen, topbjælken eller Profil, og gå igen til funktionen efter dens formål.

### 14-12. Hvad gør jeg, hvis data på skærmen virker forældede eller ikke svarer til forventningen?

Opdater først skærmen, og åbn derefter den profilsektion, som informationen hører til. Saldo og bevægelser kontrolleres bedst i Transaktionshistorik, paneler i Panels, generering i Energy, wallet-operationer i Wallet og udbetalingshandlinger i Udbetaling.

### 14-13. Hvilken rækkefølge er praktisk til at tjekke skærme ved almindelig daglig adgang til appen?

Normalt er det praktisk først at se hovedskærmen og topbjælken og derefter åbne de sektioner, der passer til den aktuelle opgave: Panels, Energy, Transaktionshistorik, Tasks, Referrals, Hub, Exchange eller Udbetaling. Den rækkefølge hjælper med hurtigt at forstå kontoens aktuelle tilstand og gå til den nødvendige handling.

### 14-14. Hvilke sektioner er nyttige at tjekke regelmæssigt, selv uden en hastesag?

Det er nyttigt regelmæssigt at tjekke hovedskærmen, topbjælken, Panels, Energy, Transaktionshistorik, Tasks, Referrals og Hub. Det hjælper med at se saldoændringer, panelaktivitet og tilgængelige handlinger i tide.

### 14-15. Hvorfor er det vigtigt at udføre handlinger i deres egen sektion i stedet for at lede efter dem overalt?

Det giver færre fejl og tilfældige handlinger. Når brugeren foretager udveksling i Exchange, udbetaling i Udbetaling og arbejder med paneler i Panels, forbliver appens logik klar og sikker.

### 14-16. Hvilke tegn viser, at en handling er vigtig og kræver opmærksomhed?

Ekstra opmærksomhed er nødvendig, når en handling påvirker saldo, paneler, energi, udveksling, udbetaling, tilknytning af wallet, operationshistorik eller kontostatus. Før sådanne handlinger bekræftes, er det nyttigt at kontrollere skærmen og den valgte knap igen.

### 14-17. Hvilke grundregler hjælper med at undgå fejl i appen?

Det er nyttigt kun at udføre en handling i den rigtige sektion, læse skærmnavnet og knappen grundigt før bekræftelse og ved tvivl først kontrollere profilsektionerne i stedet for at trykke på tilfældige interface-elementer.

### 14-18. Hvornår er det værd at åbne FAQ direkte under arbejdet med appen?

FAQ er nyttig, når du hurtigt skal afklare betydningen af en skærm, knap, handling eller regel for en bestemt funktion. Så er det lettere straks at matche spørgsmålet med den rigtige sektion og undgå unødige trin i appen.

## 15. Annoncer

### 15-1. Hvad er denne sektion?

Sektionen Annoncer er en undersektion inde i Opgaver. Den viser tilgængelige annoncehandlinger, hvorigennem brugeren kan få ekstra bonusmønter.

### 15-2. Hvor ligger sektionen Annoncer?

Sektionen Annoncer ligger som en undersektion inde i Opgaver. Det er en af de ekstra muligheder i opgaveblokken.

### 15-3. Hvilken type belønning giver Annoncer?

Annoncer giver kun bonusmønter for visninger. Det er ikke hovedsaldoen og ikke en direkte udbetaling, men en ekstra intern måde at styrke spilvejen på.

### 15-4. Hvorfor har andre annoncer, mens jeg ikke har?

Fordi tilbud kan være utilgængelige for en bestemt konto, eller annoncering kan være midlertidigt slået fra. En tom Annoncer-sektion betyder ikke, at kontoen er i stykker.

### 15-5. Hvad skal jeg gøre, hvis jeg udførte en handling i Annoncer, men der ikke er noget resultat?

Kontrollér: opdater Opgaver/Annoncer → kontrollér bonussaldoen → kontrollér historikken over handlinger.

### 15-6. Hvorfor er en reklameopgave utilgængelig indtil i morgen?

En reklameopgave kan have en daglig grænse. Hvis dagens grænse er nået, viser appen en tilsvarende besked. Gå tilbage til opgaven næste dag.

### 15-7. Hvorfor kan forskellige brugere have forskellige tilbud i Annoncer?

Fordi tilbud afhænger af tilgængeligheden af annoncekampagner for en bestemt konto. Det er normalt: én bruger kan have tilbud, mens en anden midlertidigt ikke har.

### 15-8. Skal jeg aktivere noget for at bruge Annoncer?

Nej. Annoncer er en måde at få bonus-EFHCb på og kræver ikke obligatoriske intern handling.

## 16. Ranger

### 16-1. Hvorfor er det vigtigt for mig at vokse i rangeringen?

Vækst i rangeringen viser, hvordan din fremgang ser ud i forhold til andre deltagere. Det hjælper dig med at forstå din nuværende placering og se, hvor aktivt kontoen udvikler sig.

### 16-2. Hvad er forskellen på niveau og rangliste?

Niveau viser din personlige fremgang inde i systemet, mens ranglisten viser din placering blandt andre deltagere.

### 16-3. Hvordan hænger niveau og rangliste sammen?

De er forbundet af den samme vækstlogik gennem generering af kWh med paneler og den samlede fremskridtslinje på Energy-siden.

### 16-4. Hvad påvirker væksten af min placering i rangeringen?

Væksten af din placering i rangeringen afhænger af kontoens samlede fremgang: udvikling af paneler, generering af kWh og den samlede bevægelse langs projektets energivej.

### 16-5. Kan man stige i både niveau og rangliste samtidig?

Ja. Når en bruger udvikler paneler, generation og den samlede energifremgang, styrker det normalt både niveauet og placeringen i ranglisten.

### 16-6. Hvorfor har jeg et højt niveau, men ikke førstepladsen i ranglisten?

Fordi ranglisten er din placering blandt alle deltagere, ikke kun din personlige fremgang. Andre spillere vokser også, så din placering kan ændre sig, selv om dit niveau er godt.

### 16-7. Hvor kan jeg se min placering i ranglisten?

I afsnittet Ranks — der vises din placering blandt andre deltagere.

### 16-8. Hvordan finder jeg hurtigt mig selv i den samlede rangliste?

Åbn Ranger og tryk på “Find mig”. Appen viser din række og placeringerne omkring dig, så du ikke behøver at rulle hele ranglisten igennem manuelt.

### 16-9. Hvad viser en deltagerrække i "Ranger"?

Deltagerrækken viser placeringen i ranglisten, brugernavnet og den samlede genererede energi i kWh. Så kan du sammenligne din position med andre deltagere.

### 16-10. Hvad viser listen "Topliste" i "Ranger"?

"Topliste" viser den samlede rangliste over deltagere efter mængden af genereret energi. Hvis der er flere deltagere end dem, der vises nu, kan du indlæse de næste placeringer.

## 17. Activ-status

### 17-1. Hvad betyder Activ-status?

Activ er en permanent aktiv status. Den betyder, at spillet for alvor er begyndt, fordi der er aktiveret mindst ét panel.

### 17-2. Hvordan får jeg Activ?

For at få Activ er det nok at aktivere ét panel. Efter dette intern handling tildeles status permanent.

### 17-3. Bevares Activ, hvis et panel senere går til Archive?

Ja. Selv hvis et panel senere går til Archive, bevares Activ-status.

### 17-4. Hvorfor er Activ vigtig?

Activ er vigtig i kampen mod botfarme. Activ hjælper med at skelne rigtige spillere fra tilfældige registreringer, bots og botfarme. Den bekræfter brugerens reelle deltagelse i projektet.

### 17-5. Kan Activ forsvinde senere?

Nej. Activ er en permanent status og bevares, selv hvis det første panel senere går til Archive.

### 17-6. Hvad ændrer sig på kontoen, når man får Activ?

Kontoen betragtes som bekræftet af en rigtig deltager i projektet. Det påvirker den fair funktion af henvisninger og tilliden til aktivitet.

## 18. VIP NFT

### 18-1. Hvad er EFHC VIP NFT?

EFHC VIP NFT er et klubkort, nøglen til hele EFHC’s fremtidige økosystem, et digitalt tegn på tilhørsforhold og en nøgle til projektets fremtidige muligheder.

### 18-2. Hvad giver det at eje én EFHC VIP NFT?

At eje én EFHC VIP NFT giver øget generation for alle spillerens paneler.

### 18-3. Hvor kan jeg se VIP-effekten?

VIP-effekten er synlig i de afsnit, hvor projektet tager højde for fordelene ved VIP NFT, samt i topbjælken og i Profil/Indstillinger.

### 18-4. Hvordan hænger tilknyttede tegnebøger sammen med automatisk VIP-kontrol?

VIP-status bestemmes automatisk ud fra et EFHC VIP NFT i de tegnebøger, der er knyttet til kontoen. For at kontrollen virker korrekt, skal NFT’et ligge i en tegnebog, der er knyttet til den pågældende konto.

### 18-5. Giver 2 eller 3 VIP NFT ekstra privilegier til spilleren?

Nej. For spilleren giver 2 eller 3 VIP NFT ikke ekstra privilegier ud over én VIP NFT.

### 18-6. Påvirker VIP ét panel eller alle?

VIP påvirker generationen fra alle brugerens paneler, ikke kun ét enkelt.

### 18-7. Hvor tjekker jeg selve NFT’et, og hvor tjekker jeg den aktive VIP-status?

Selve EFHC VIP NFT’et tjekkes i de tilknyttede tegnebøger. Den aktive VIP-status tjekkes inde på kontoen — i Profil og i den øverste bjælke. De to kontroller supplerer hinanden.

### 18-8. Hvad gør jeg, hvis jeg har et EFHC VIP NFT, men VIP-status ikke vises?

Tjek først VIP-status inde på kontoen — i Profil og i den øverste bjælke. Hvis den ikke vises, skal du kontrollere, om EFHC VIP NFT’et findes i en af kontoens tilknyttede tegnebøger. Et NFT i en anden tegnebog, som ikke er knyttet til kontoen, aktiverer ikke VIP-status for den konto.

### 18-9. Kan jeg disponere over mit VIP NFT, som jeg vil?

Ja. EFHC VIP NFT kan overføres, gives som gave og sælges på markedspladser.

### 18-10. Hvad sker der med VIP-status, hvis NFT’et ikke længere findes i en tegnebog, der er knyttet til kontoen?

Hvis EFHC VIP NFT’et ikke længere findes i nogen af kontoens tilknyttede tegnebøger, deaktiveres VIP-status for alle paneler på kontoen. VIP er utilgængelig, indtil NFT’et igen findes i en tilknyttet tegnebog. Et EFHC VIP NFT i en tilknyttet tegnebog er nødvendigt for VIP-status.

## 19. Niveauer

### 19-1. Hvad indeholder afsnittet Niveauer?

Afsnittet Niveauer viser alle projektets vækstskalaer: 12 niveauer af energifremgang, 6 niveauer i henvisningssystemet og andre niveaulinjer i projektet, hvis de senere bliver tilføjet.

### 19-2. Hvor mange niveauer af energifremgang findes der i projektet?

Projektet har 12 niveauer af energifremgang.

### 19-3. Hvor mange niveauer er der i henvisningssystemet?

Projektet har 6 niveauer i henvisningssystemet: fra 0 til 5.

### 19-4. Hvordan er niveauer nyttige for en almindelig spiller?

Niveauer hjælper dig med at forstå, hvor du er nu, hvor meget der allerede er gjort, hvad du skal bevæge dig mod næste gang, og hvilken næste milepæl der venter foran.

### 19-5. Hvordan hænger energiniveauer, henvisningsniveauer og den samlede kontovækst sammen?

De er dele af én samlet vej. Energigenerering driver hovedfremgangen, aktive henvisninger styrker henvisningslinjen, og sammen viser de, hvor stærkt kontoen udvikler sig.

### 19-6. Eco Initiate (0 kWh)

**Betydning for spilleren:** Dit første panel er installeret og klar til arbejde. Du tager det vigtigste skridt mod at blive en uafhængig producent af ren energi. Dette er din startstatus — du er lige trådt ind på generationsvejen.

**Præcis regel:** Niveauet Eco Initiate svarer til markeringen 0 kWh.

**Praktisk konsekvens:** Næste skridt er at starte vækst i generation gennem paneler og føre fremgangen op til 100 kWh.

### 19-7. Hope Bringer (100 kWh)

**Betydning for spilleren:** De første kilowatt er kommet i gang. Dine paneler genererer med succes grøn energi og giver naturen håb om en fremtid uden kulstof. Du ser allerede de første reelle resultater: energi er begyndt at komme, og fremgangen har flyttet sig.

**Præcis regel:** Niveauet Hope Bringer starter ved 100 kWh.

**Praktisk konsekvens:** Det næste mål er at opbygge stabilitet og nå 300 kWh til næste trin.

### 19-8. Energy Seeker (300 kWh)

**Betydning for spilleren:** Systemet fungerer fremragende og fylder stabilt nettet med miljøvenlig elektricitet. Hver energienhed, som panelerne producerer, fortrænger fossile brændstoffer. Kontoen er gået ind i en fase med stabil vækst: du er ikke længere en nybegynder, men en bruger med reel generation.

**Præcis regel:** Niveauet Energy Seeker starter ved 300 kWh.

**Praktisk konsekvens:** I praksis er dette et signal om, at du kan styrke panelerne og oftere bruge Exchange til at omdanne energi til hovedsaldo.

### 19-9. Nature's Voice (600 kWh)

**Betydning for spilleren:** Dit bidrag bliver mærkbart. Ved at generere energi med grøn teknologi bliver du naturens stemme og viser, at fremgang kan være miljøvenlig. Dit bidrag bliver mere synligt: fremgangen føles ikke længere som et tilfælde, men som en tydelig retning.

**Præcis regel:** Niveauet Nature's Voice starter ved 600 kWh.

**Praktisk konsekvens:** Det næste mål er 1000 kWh (Earth Ally). Det er nyttigt at sammenligne tempoet i Energy og antallet af aktive paneler.

### 19-10. Earth Ally (1000 kWh)

**Betydning for spilleren:** Den første megawatt-time er genereret. Dine paneler har produceret en imponerende mængde ren energi. Nu er du en vigtig deltager i den grønne omstilling og en trofast allieret for planeten. Du har passeret en vigtig milepæl: 1000 kWh er allerede en seriøs mængde akkumuleret generation.

**Præcis regel:** Niveauet Earth Ally starter ved 1000 kWh.

**Praktisk konsekvens:** I praksis er dette punktet, hvor væksten bliver mere forudsigelig: styrk din park af paneler, og hold energiudvekslingen regelmæssig.

### 19-11. Climate Fighter (2000 kWh)

**Betydning for spilleren:** Din generation gør en reel forskel mod klimaforandringer. Hver produceret kilowatt reducerer direkte behovet for at brænde kul og gas. Du presser allerede systematisk fremad: fremgang er synlig både i niveauet og i kontoens samlede dynamik.

**Præcis regel:** Niveauet Climate Fighter starter ved 2000 kWh.

**Praktisk konsekvens:** Næste skridt er at fastholde tempoet og nå 3500 kWh. Hold øje med generationshastigheden og brug VIP om nødvendigt.

### 19-12. Green Sentinel (3500 kWh)

**Betydning for spilleren:** Den stabile energistrøm fra dine paneler står vagt om ren luft. Du skaber mærkbar nytte for samfundet uden at efterlade et CO2-aftryk. Din konto bliver en vogter af stabil generation: væksten går sikkert fremad.

**Præcis regel:** Niveauet Green Sentinel starter ved 3500 kWh.

**Praktisk konsekvens:** I praksis betyder det, at panelerne allerede arbejder som et system — hold aktive paneler kørende og planlæg vækst mod 5000 kWh.

### 19-13. Planet Defender (5000 kWh)

**Betydning for spilleren:** 5000 kWh ren generation. Kraften fra dine paneler fungerer som et usynligt skjold, der beskytter atmosfæren mod tusindvis af kilo drivhusgasudledning. 5000 kWh er allerede et tydeligt tegn på skala: du er nu blandt de stærke energideltagere.

**Præcis regel:** Niveauet Planet Defender starter ved 5000 kWh.

**Praktisk konsekvens:** Det næste mål er 7500 kWh. På dette trin styrker spillere ofte både paneler og deres henvisningsnetværk.

### 19-14. Eco Champion (7500 kWh)

**Betydning for spilleren:** Enestående produktionsvolumener. Du er en sand forkæmper for grøn energi, og dit bidrag ændrer mærkbart den globale energibalance til det bedre. Dette er niveauet for dem, der stabilt holder et højt generationstempo.

**Præcis regel:** Niveauet Eco Champion starter ved 7500 kWh.

**Praktisk konsekvens:** I praksis: hold disciplinen — aktive paneler, regelmæssig Exchange og kontrol over historik og saldi.

### 19-15. Planet Saver (10000 kWh)

**Betydning for spilleren:** 10 megawatt-timer. Du har genereret så meget ren energi, at du bogstaveligt talt hjælper med at redde hele økosystemer og viser maksimal effektivitet af dine paneler. 10.000 kWh er allerede ti megawatt-timer generation — et meget stærkt trin i fremgangen.

**Præcis regel:** Niveauet Planet Saver starter ved 10000 kWh.

**Praktisk konsekvens:** Det næste trin er 15000 kWh. På dette niveau giver det mening at optimere alt: paneler, VIP, henvisninger og intern handling.

### 19-16. Green Commander (15000 kWh)

**Betydning for spilleren:** Flagskibet for miljøvenlig generation. Dine paneler driver fremtiden, og de imponerende produktionsvolumener sætter helt nye, høje standarder for hele fællesskabet. Du er tæt på toppen: dette er et niveau i energiens lederklasse.

**Præcis regel:** Niveauet Green Commander starter ved 15000 kWh.

**Praktisk konsekvens:** I praksis: hold stabiliteten og voks mod 20000+ kWh, mens du følger aktive paneler og tempoet i Energy.

### 19-17. Guardian of Earth (20000+ kWh)

**Betydning for spilleren:** Toppen af udviklingen. Ved at generere mere end 20 MWh helt ren energi er du blevet en ægte Guardian of Earth. Dine panels henter styrke fra naturen selv for at drive denne verden og bevare den for kommende generationer. Dette er toppen af stigen: du har nået det højeste anerkendte fremskridtsniveau.

**Præcis regel:** Guardian of Earth-niveauet svarer til 20000+ kWh.

**Praktisk effekt:** I praksis har du sikret den højeste status. Herfra er fokus at vedligeholde systemet, skalere panels og styrke økosystemdeltagelsen gennem panels, VIP og henvisningsvækst.

### 19-18. Henvisningsniveau 0

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 0 aktive direkte henvisninger; niveauets engangsbelønning er 0 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-19. Henvisningsniveau 1

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 10 aktive direkte henvisninger; niveauets engangsbelønning er 1 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-20. Henvisningsniveau 2

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 100 aktive direkte henvisninger; niveauets engangsbelønning er 10 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-21. Henvisningsniveau 3

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 1000 aktive direkte henvisninger; niveauets engangsbelønning er 100 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-22. Henvisningsniveau 4

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 3000 aktive direkte henvisninger; niveauets engangsbelønning er 300 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-23. Henvisningsniveau 5

**Betydning for spilleren:** Dette er en markør for din vækst i henvisningssystemet — den viser omfanget af aktive inviterede brugere.

**Præcis regel:** Niveauet starter ved 10000 aktive direkte henvisninger; niveauets engangsbelønning er 1000 EFHCb.

**Praktisk konsekvens:** I praksis: efter at have nået niveauet, så tjek din bonussaldo og operationshistorik for at se krediteringen.

### 19-24. Hvordan forstår jeg niveauprogression uden fejl?

**Betydning for spilleren:** Denne blok hjælper dig med at vurdere fremskridt nøgternt og se niveauer gennem faktisk energigenerering.

**Præcis regel:** Niveauer bestemmes af akkumuleret generering i kWh. Jo større den samlede generering er, desto højere er dit niveau.

**Praktisk effekt:** I praksis bør du fokusere på væksten i energi, antallet af aktive panels og det samlede genereringstempo. Det er det, der giver reel niveauprogression.

### 19-25. Hvorfor er niveauernes navne knyttet til økologi og planeten?

Fordi selve spillets idé er knyttet til virtuel grøn energi, motivation af mennesker og et symbolsk bidrag til helingen af planeten Jorden.

## 20. FAQ / Hjælp

### 20-1. Hvor kan jeg åbne FAQ’en?

FAQ’en åbnes fra profilen som bottens indbyggede hjælpesektion, hvor svar på de vigtigste handlinger, skærme og projektregler er samlet.

### 20-2. Hvordan kontakter jeg support?

Åbn Profil, tryk på tandhjulet til indstillinger, og gå til “Support og information” → “Supportchat”. Vælg en tilgængelig kontaktmulighed, og kontakt support. De tilgængelige kontaktmuligheder kan ændre sig.

### 20-3. Hvad bør jeg skrive til support med det samme, så problemet kan afklares hurtigere?

Beskriv kort, hvad der skete, hvilken skærm problemet opstod på, og hvilken handling du var i gang med. Vedhæft om muligt et skærmbillede, og oplys din Global ID. Send aldrig din hemmelige gendannelsesfrase til din wallet (seed phrase), private nøgle eller wallet-adgangskode.

### 20-4. Hvordan bør jeg bruge FAQ korrekt?

Det er bedst at gå sektion for sektion: forstå først projektets generelle logik, derefter dine skærme og handlinger, og først derefter se på specifikke regler for saldi, udbetalinger, VIP, henvisninger, niveauer og andre bot-funktioner.

### 20-5. Hvad skal jeg kontrollere, hvis alt ser ødelagt ud?

Kontrollér tre ting: 1) Wallet — til Withdraw er en aktiv tilknyttet wallet valgt; ved en ekstern TON/USDT-betaling i Browser Shop matcher den tilsluttede adresse den primære TON-wallet; 2) saldi og Historik — operationen er registreret; 3) det relevante område (Panels / Energy / Exchange / Withdraw).

### 20-6. Hvordan finder jeg hurtigst det svar, jeg har brug for, i FAQ?

Brug søgefeltet øverst i FAQ. Skriv et ord eller en sætning — søgningen gennemgår sektioner, spørgsmål og svar og viser passende resultater. Hvis der ikke findes noget, så prøv et kortere eller andet nøgleord.
