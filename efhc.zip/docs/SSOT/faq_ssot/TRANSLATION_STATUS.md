# EFHC FAQ Translation Status — CURRENT

Status date: `2026-10-02`  
Runtime source: `frontend/src/data/faq/catalogs.ts`.

## Current structural state

- Application FAQ locales: **16** — `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
- FAQ SSOT mirrors: **16** matching language directories.
- Each runtime catalog and each synchronized mirror: **20 sections / 20 subsections / 230 Q&A items**.
- Total runtime FAQ items across localized catalogs: **3680**.
- Runtime→SSOT synchronization completed on `2026-10-02` by direct OWNER instruction.

The previous 13-language / 250-item documentation state is superseded and must not be treated as current.

## Semantic/human-review boundary

Structural parity means the checked-in application text is mirrored exactly. It does not independently certify linguistic quality.

- `ru`: semantic anchor; current runtime text mirrored.
- `en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`: current runtime text mirrored; human linguistic certification is not newly claimed by this synchronization.

Future semantic changes must follow FAQ approval governance. Future parity audits must compare the selected current runtime source and all 16 mirrors by IDs and text, not only by file presence or counts.
