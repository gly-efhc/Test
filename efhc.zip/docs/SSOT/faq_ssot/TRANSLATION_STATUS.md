ru — complete
en — complete
uk — complete
de — complete
fr — complete
es — complete
it — complete
tr — complete
pl — complete
da — complete
hi — complete
id — complete
sw — complete

- all 13 languages — sections 1–20 translated
- Russian canon updated with 1 replacement and 15 new Q&A
- all translations synchronized across md/json
