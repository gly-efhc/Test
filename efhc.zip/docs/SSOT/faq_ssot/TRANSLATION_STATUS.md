# EFHC FAQ Translation Status

Status date: 2026-06-02
Current status source: `docs/frontend/FAQ_SEMANTIC_ALIGNMENT_REPAIR.md`
Previous repair source: `docs/frontend/FAQ_WAVE3_TRANSLATION_STATUS_REPAIR.md`
Audit source: `docs/history/legacy_artifacts/docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md`

## Structural status

- Required languages: ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw.
- FAQ structure: 20 sections and 250 Q&A items per language.
- JSON/MD files exist for all 13 languages.
- Key/item parity is structurally complete.
- `frontend/src/data/faq/catalogs.ts` is generated from `docs/SSOT/faq_ssot/*/faq_*.json`.

## Semantic governance status

The old flat `complete` status remains superseded. FAQ readiness is tracked in
four separate layers:

1. structural parity;
2. translation-quality repair;
3. semantic alignment against Q/A and FAQ approval records;
4. human linguistic approval.

The FAQ repair lane had two sub-passes:

- v169_49 repaired wave-3 identical-to-English FAQ tails;
- v169_50 performed corrective semantic alignment for changed items against Q/A
  and RU/FAQ anchors.

## Current policy

| Language | Structural parity | Translation repair | Semantic alignment | Human linguistic status |
|---|---:|---:|---:|---|
| ru | PASS | READY | Q/A_ANCHOR_CHECKED | READY |
| en | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| uk | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| de | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| fr | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| es | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| it | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| tr | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| pl | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| da | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| hi | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| id | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |
| sw | PASS | REPAIRED | SEMANTIC_ALIGNED_TO_RU_QA | PENDING_REVIEW |

## Repair lane history

- 1369 fixed critical i18n runtime and value-level blockers.
- 1370 addressed priority public UI untranslated keys and user-visible error/confirmation messages.
- translation-tail repair repaired FAQ wave-3 identical-to-English answers/questions and regenerated the frontend FAQ catalog.
- semantic-alignment repair corrected semantic alignment for changed FAQ items where EN/wave wording drifted from RU/Q&A meaning.

## Current boundary

The FAQ is semantically aligned at static-source level for the repaired 1371
items. This does not claim full human linguistic certification for every phrase
in all 13 languages. Future FAQ work must not collapse the four statuses above
into a single `complete` label.

## v169_51 FAQ semantic approval gate

Status after the corrective gate:

- Structural parity: PASS — 13 languages, 20 sections, 250 Q&A.
- FAQ wave-3 translation-tail repair: PASS for the audited tail.
- FAQ semantic alignment: PASS for the reviewed high-risk items and the
  corrected Wallet residual drift items 48 and 51.
- Human linguistic certification: NOT CLAIMED.

Semantic hierarchy:

1. Q/A register and direct user decisions;
2. FAQ approval manifest/register;
3. Russian FAQ/SSOT if it matches the Q/A meaning;
4. English and all other languages as translations from that Russian canon.


## v169_55 reaudit intake note

The v169.54 i18n reaudit is imported as
`docs/history/legacy_artifacts/docs/audits/I18N_REAUDIT_REPORT_V169_54_2026_06_03.md`.
It confirms that critical C1-C4 localization findings are fixed and that FAQ
identical-answer tail is closed. It does not certify full public UI translation
completion.

Remaining public locale work must proceed manually:

- UK: public manual pass completed in cycle 1377;
- DE/FR/HI/SW/TR/PL/DA/IT/ES/ID: about 152-154 public keys per language;
- all translations must source from verified Russian meaning, not from English
  fallback or sandbox labels.

Cycle 1376 only performs audit intake, formula allowlist, two controlled task
terminology micro-edits, and guard/precondition repair. Human linguistic status
for non-RU languages remains `PENDING_REVIEW`.


## v169_57 Ukrainian public manual pass note

Cycle 1377 completed the Ukrainian public UI translation tail identified by the v169.54 reaudit. This note concerns the public locale bundle, not full human linguistic certification. FAQ status remains structurally repaired and semantically aligned at static-source level, with human linguistic status still pending.

Remaining public locale work is now focused on DE/FR/HI/SW/TR/PL/DA/IT/ES/ID wave-3 languages, starting with `public_engagement`.


## v169_58 wave-3 public engagement note

Cycle 1378 completed the wave-3 public UI `public_engagement.*` translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. This is not FAQ human linguistic certification and not full locale completion. Remaining public UI domains must continue as manual, Russian-source domain passes.


## v169_59 wave-3 portal/shop note

Cycle 1379 completed the wave-3 public UI portal/shop pass for
DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. This concerns runtime public locale bundles, not
FAQ human linguistic certification and not full locale completion. Remaining
public UI domains must continue as manual, Russian-source domain passes.


## v169_60 wave-3 profile/trust note

Cycle 1380 completed the wave-3 public UI profile/trust pass for
DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. This concerns runtime public locale bundles, not
FAQ human linguistic certification and not full locale completion. Remaining
public UI domains must continue as manual, Russian-source domain passes.


## v169.61 public locale note

Cycle 1381 completed the wave-3 `panels.*`, `tasks.*` and `history.*` guarded
manual translation pass for DE/FR/HI/SW/TR/PL/DA/IT/ES/ID. This is a public UI
locale-source update, not a FAQ semantic or human linguistic certification
claim. FAQ statuses above remain unchanged.

## v169.62 public locale tail note

Cycle 1382 completed a public locale manual-tail pass for wave-3 languages over
`hub.*`, `energy.*`, `wallet.*`, `ranks.*` and `referrals.*`. This note concerns
public locale bundles only; FAQ structural/semantic status above remains
unchanged and still does not claim human linguistic certification.


## v169.63 public locale consolidation note

Cycle 1383 added a cross-locale public-bundle consolidation guard after the
manual locale passes 1377-1382. It concerns runtime public locale bundles only,
not FAQ human linguistic certification. The FAQ status table above remains
unchanged: structural and semantic static-source status is tracked separately
from human linguistic approval.

The consolidation guard reports 0 unexpected English-identical values and 0
wave-3 Cyrillic tails after approved protocol/brand/formula, admin-scope and
key-specific UI abbreviation exclusions.


## v169_64 browser text stress note

Cycle 1384 adds screenshot-readiness planning for multilingual public UI text after manual i18n consolidation. This does not change FAQ semantic status and does not claim human linguistic certification or browser screenshot evidence.

## v169.65 consolidation note

Manual i18n repair lane 1376–1385 is source/static complete with consolidation guards. This is not human linguistic certification.
