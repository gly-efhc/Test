# EFHC FAQ (FR) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. À propos du projet

### 1-1. Qu’est-ce que l’EFHC ?

EFHC est un projet de jeu centré sur l’énergie, le progrès et le développement du compte à l’intérieur du bot. L’utilisateur achète des panels, accumule de l’énergie, l’échange contre des EFHC, suit ses balances, progresse par niveaux, monte dans le classement et utilise les fonctionnalités supplémentaires du projet.

Décryptage :
— EFHC — Energy for Humanity Coin
— EFHCm — monnaies principales
— EFHCb — monnaies bonus
— EFHCj — jetton EFHC externe
— EFHC — solde total (bonus + principal)

### 1-2. Comment obtenir mes premiers EFHC ici ?

Vos premiers EFHC apparaissent lorsque vous alimentez votre solde dans le projet ou lorsque vous commencez à utiliser ses mécanismes internes. Le point de départ le plus simple est d’activer un panel, puis d’accumuler de l’énergie et de développer progressivement votre compte.

### 1-3. D’où vient mon énergie ?

L’énergie dans le projet est générée par vos panels. Plus votre base de panels est forte et plus vous interagissez régulièrement avec le projet, plus votre progression est stable.

### 1-4. Qu’est-ce qui influence le plus ma croissance dans le projet ?

Votre croissance est surtout influencée par quatre éléments : le nombre de panels, l’activité de votre compte, l’accumulation d’énergie, et l’utilisation cohérente des sections principales du projet. La progression est plus forte lorsque vous avancez de manière régulière et non chaotique.

### 1-5. Comment savoir que j’avance correctement ?

Vous avancez correctement si votre compte devient progressivement plus solide : l’énergie s’accumule, les soldes évoluent, de nouvelles sections deviennent utiles, l’activité reste régulière et votre position dans le projet se renforce avec le temps.

### 1-6. L’EFHC est-il une monnaie ou une unité de jeu ?

À l’intérieur du bot, l’EFHC fonctionne comme une unité interne du projet, liée à votre progression, à l’énergie et aux mécanismes de jeu. Selon le contexte, l’utilisateur peut voir l’EFHC comme l’unité d’activité, de croissance et d’interaction économique au sein de l’écosystème.

### 1-7. Pourquoi le projet est-il lié à l’énergie ?

Parce que l’idée centrale de l’EFHC repose sur l’énergie comme base du développement. Les panels, l’accumulation, l’échange, la progression et les niveaux sont intégrés dans une logique unique où la croissance du compte est reliée au thème de la production et du mouvement de l’énergie.

### 1-8. Que se passe-t-il si j’utilise le projet de façon irrégulière ?

Si l’utilisation est irrégulière, votre progression ralentit. Cela ne signifie pas forcément une perte du compte, mais un développement stable se construit justement grâce à une participation régulière, à l’attention portée aux sections clés et à un contrôle de votre état dans le projet.

### 1-9. Quelle logique générale faut-il comprendre dès le début ?

La logique générale est simple : vous renforcez votre compte, développez les panels, accumulez de l’énergie, suivez vos soldes, utilisez les fonctionnalités du projet et avancez pas à pas. L’EFHC est construit sur la croissance progressive, et non sur des actions ponctuelles au hasard.

### 1-10. Comment faut-il aborder le projet au début ?

Au début, il vaut mieux aborder l’EFHC comme un système unique : comprendre l’interface, examiner le solde, l’énergie, les panels, le profil et les sections principales. Plus votre vision d’ensemble est claire dès le départ, plus il sera facile d’avancer de manière cohérente.

## 2. Écran principal

### 2-1. Que montre l’écran principal ?

L’écran principal est la page Energy. Il regroupe les éléments essentiels de l’état actuel du compte : actions rapides, informations sur la progression et points d’entrée vers les sections importantes du bot.

### 2-2. Pourquoi l’écran principal est-il considéré comme central ?

Parce que c’est sur cet écran que l’utilisateur voit le plus rapidement l’état général du compte. Il sert de point de repère : on y constate la dynamique du projet, l’évolution des indicateurs et l’accès aux fonctions clés.

### 2-3. Quels boutons de l’écran principal sont les plus importants ?

Les plus importants sont ceux qui mènent vers les sections-clés liées à l’énergie, aux panels, au solde, au profil, à Panels, à Exchange, ainsi qu’aux actions rapides Top Up et Hub, qui ouvrent les actions liées à EFHC et VIP.

### 2-4. Que dois-je vérifier chaque jour sur l’écran principal ?

Chaque jour, il faut vérifier l’état général du compte : les soldes, l’énergie, l’activité des sections clés, l’affichage des éléments importants et la cohérence des données visibles. Ce contrôle quotidien aide à ne pas manquer les changements utiles.

### 2-5. Pourquoi l’écran principal change-t-il avec le temps ?

Parce que le compte se développe. Avec la progression, l’activité, les panels et le statut de l’utilisateur, de nouveaux éléments visuels, de nouveaux indicateurs ou différentes priorités d’interface peuvent apparaître.

### 2-6. Comment comprendre via l’écran principal que le compte progresse ?

Quand le compte progresse, cela se voit par la stabilité des indicateurs, l’apparition de nouvelles possibilités, le mouvement des soldes, la croissance de l’énergie et le renforcement général de la position du compte dans le projet.

### 2-7. Quels boutons de l’écran principal sont les plus importants ?

Les plus importants sont ceux qui mènent aux actions clés : Panels et Exchange, ainsi que les boutons rapides de la barre supérieure — Top Up et Hub — si vous ouvrez des actions liées à EFHC et VIP.

### 2-8. Que faire si l’écran principal semble trop simple au début ?

C’est normal. Au début, l’interface peut paraître sobre, car l’état du compte est encore limité. À mesure que vous utilisez le projet, l’écran principal devient plus informatif et plus dense.

### 2-9. Peut-on utiliser l’écran principal comme repère de progression ?

Oui. C’est l’un des repères les plus pratiques. Si les indicateurs deviennent plus solides, que de nouvelles sections gagnent en importance et que le compte paraît plus avancé dans l’ensemble, alors vous progressez dans la bonne direction.

### 2-10. Quel est le rôle global de l’écran principal dans l’EFHC ?

Le rôle global de l’écran principal est de réunir les éléments clés du projet en un seul point : état du compte, navigation rapide, suivi du progrès et accès aux fonctions importantes.

## 3. Barre supérieure

### 3-1. Qu’est-ce que la barre supérieure ?

La barre supérieure est un élément d’interface distinct et le principal bloc d’information rapide disponible sur les pages principales du bot.

### 3-2. Que voit-on dans la barre supérieure ?

La barre supérieure affiche l’avatar, le nom, le niveau de progression énergétique, le statut VIP, le solde total, le bouton Top Up et le bouton Hub.

### 3-3. Pourquoi la barre supérieure est-elle importante ?

Parce qu’elle permet de voir immédiatement les informations essentielles sur votre compte sans navigation inutile : qui vous êtes, quelle est votre progression, si vous avez le VIP, combien de pièces vous avez au total et quelles actions rapides sont disponibles maintenant.

### 3-4. Que montre le solde total dans la barre supérieure ?

Le solde total montre combien de pièces vous avez au total. C’est pratique, car vous n’avez pas besoin d’additionner vous-même les ressources pour les achats et pour comprendre l’état général de votre compte dans le jeu.

### 3-5. Pourquoi le solde total est-il pratique pour les achats ?

Parce qu’il montre le pouvoir d’achat global du joueur à l’intérieur du jeu et aide à comprendre rapidement si les ressources suffisent pour les actions internes.

### 3-6. Pourquoi le solde total n’est-il pas égal à ce que je peux retirer tout de suite ?

Parce que le solde total inclut à la fois les pièces principales et les pièces bonus. Les pièces bonus servent au cycle interne du jeu et ne sont pas retirées directement.

### 3-7. Quand faut-il utiliser le bouton « Recharger » dans la barre supérieure ?

Utilisez-le lorsque vous voulez accéder rapidement au scénario de recharge du solde principal disponible dans l’application, sans ouvrir manuellement des sections supplémentaires.

### 3-8. Pourquoi ouvrir Hub depuis la barre supérieure ?

Pour ouvrir rapidement les cartes des actions liées au projet et passer au flux externe nécessaire sans navigation supplémentaire dans l’interface.

### 3-9. Pourquoi la barre supérieure est-elle visible sur différentes pages ?

Parce qu’elle sert de tableau de bord du compte : elle vous permet de toujours voir l’essentiel — le solde, les statuts et les actions rapides — même lorsque vous ouvrez une autre section.

### 3-10. Que faire si les données de la barre supérieure semblent incorrectes ?

Commencez par actualiser la page et vérifier l’historique des soldes : il montre les opérations réelles. Si l’historique et le solde coïncident, les données sont correctes ; vous avez peut-être simplement regardé le mauvais solde, par exemple le solde total au lieu du solde principal.

## 4. Profil

### 4-1. Qu’est-ce que la section Profil/Paramètres ?

Profil/Paramètres est la section où vous gérez votre profil et les réglages du bot. On y voit les statuts principaux et on y trouve les paramètres personnels de l’interface.

### 4-2. Que puis-je faire dans le profil ?

Le profil regroupe les principaux réglages utilisateur et des accès rapides vers les sections importantes : Wallet, historique des soldes, FAQ et autres points de contrôle utiles.

### 4-3. Qu’est-ce qui est affiché en haut de Profil/Paramètres ?

En haut de Profil/Paramètres s’affichent l’avatar, le nom Telegram ainsi que les statuts Activ et VIP, si vous les avez déjà.

### 4-4. Où puis-je changer la langue ?

La langue se change dans Profil/Paramètres.

### 4-5. Pourquoi ai-je besoin d’un profil ?

Le profil est votre point personnel de gestion du compte. Ici, l’utilisateur ne se contente pas de voir ses statuts : il ouvre aussi des sous-sections importantes liées au wallet, à l’historique, à la langue et à l’aide.

### 4-6. Où ouvrir l’historique des soldes dans le profil ?

Dans Profil/Paramètres, il existe une entrée séparée vers l’historique des soldes, où l’on voit les entrées et les sorties.

### 4-7. Où changer la langue dans le profil ?

Le changement de langue se trouve dans Profil/Paramètres, car il s’agit d’un réglage personnel du compte.

### 4-8. Où ouvrir Wallet dans Profil pour travailler avec le wallet ?

Dans la section Profil, il y a une entrée distincte Wallet. Ouvrez-la quand vous devez connecter un wallet, vérifier l’association ou passer à des actions liées au wallet.

### 4-9. Où ouvrir rapidement FAQ dans Profil si j’ai besoin d’une réponse ?

Dans la section Profil, il y a un accès à FAQ. Ouvrez-le quand vous avez besoin d’une réponse rapide sur l’interface, le balance, les panels, l’énergie, l’exchange, le withdrawal ou d’autres fonctions du WebApp.

### 4-10. Que contient la section « Support et informations » ?

Cette section regroupe les éléments d’aide : FAQ, conseils/informations et tout ce qui aide l’utilisateur à comprendre le projet sans confusion.

### 4-11. En combien de langues l’interface du projet est-elle disponible ?

L’interface du bot et le système d’aide (FAQ) sont traduits en 13 langues. Vous pouvez choisir la langue qui vous convient dans les paramètres du profil, et le système adapte immédiatement tous les textes et l’interface à votre choix.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. Puis-je changer de wallet principal ?

Oui. L’utilisateur peut choisir un autre wallet principal parmi ceux qui sont déjà connectés.

### 5-3. Puis-je supprimer un wallet lié ?

Oui. Si ce wallet n’est plus nécessaire, sa liaison peut être supprimée.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. Que se passe-t-il si j’appuie sur une action qui nécessite un wallet alors que je n’en ai pas ?

Si la fonction choisie nécessite un wallet, le bot lancera d’abord la logique de connexion du wallet. Ensuite, vous pourrez revenir à l’action voulue et l’exécuter normalement.

### 5-6. Puis-je connecter plusieurs wallets et pourquoi cela serait-il utile ?

Oui. Vous pouvez connecter plusieurs wallets afin d’avoir une adresse de réserve ou de séparer différents scénarios d’utilisation. En même temps, un wallet est choisi comme principal — c’est lui qui est utilisé par défaut pour les opérations où un wallet sélectionné est nécessaire.

### 5-7. Que se passe-t-il si je change de wallet principal ?

Vous pourrez désigner un autre wallet comme principal. Après ce changement, le système utilisera la nouvelle adresse principale pour les opérations où cela est requis. Avant un retrait ou un achat, il vaut mieux vérifier une fois quel wallet est actuellement défini comme principal.

### 5-8. Puis-je retirer vers un wallet non principal ?

Par défaut, le système utilise le wallet principal. Si vous avez besoin d’une autre adresse, définissez-la d’abord comme principale dans Wallet, puis soumettez la demande de retrait.

### 5-9. Que faire si le wallet est connecté mais que le retrait reste indisponible ?

Vérifiez trois choses : si un wallet principal est sélectionné, si le solde principal est suffisant et si le montant du retrait n’est pas inférieur à 10 EFHC.

### 5-10. Puis-je jouer et progresser même si le wallet n’est pas encore connecté ?

Oui. Le wallet est nécessaire pour certaines opérations, par exemple les retraits, mais vous pouvez développer votre compte, comprendre l’interface et accumuler de la progression même sans wallet connecté.

### 5-11. Que faire si je perds l’accès à mon portefeuille TON principal ?

Comme le projet permet de lier plusieurs portefeuilles, vous pouvez lier un nouveau portefeuille dans la section Wallet, le définir comme principal et supprimer définitivement l’ancienne adresse compromise de la liste des portefeuilles liés.

## 6. Soldes et historique

### 6-1. Pourquoi ai-je trois soldes différents ?

Parce que les fonds ont des rôles différents à l’intérieur du bot. Le solde total regroupe tout, le solde bonus sert au cycle interne du jeu, et le solde principal montre le résultat que vous pouvez déjà utiliser pour les opérations clés et le withdraw.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Qu’est-ce que le solde principal ?

Le solde principal correspond aux EFHC principaux. C’est vers lui que se transforme le résultat du cycle de jeu, et c’est depuis lui que les opérations clés, y compris le withdraw, deviennent disponibles.

### 6-4. Pourquoi un seul achat peut-il affecter à la fois le solde bonus et le solde principal ?

Pour toutes les dépenses internes du projet, les fonds sont d’abord débités du solde bonus. Si cela ne suffit pas, le reste est débité du solde principal.

### 6-5. Pourquoi y a-t-il plusieurs lignes dans l’historique pour une seule opération ?

Une seule opération peut toucher plusieurs parties du mouvement des fonds. Le bot l’affiche donc sous plusieurs lignes afin de montrer séparément les différents changements.

### 6-6. Où puis-je voir d’où les EFHC sont arrivés ou d’où ils sont partis ?

Pour cela, utilisez la section de l’historique des soldes. Elle affiche les crédits, les débits, l’exchange, les achats, le withdraw et les autres changements de fonds.

### 6-7. Pourquoi mon solde total peut-il être élevé alors que je peux retirer moins ?

Parce que le solde total additionne le principal et le bonus. Le withdraw n’est autorisé que depuis le solde principal, tandis que le bonus est destiné au cycle interne du projet. Pour un retrait, il faut donc regarder précisément le solde principal.

### 6-8. Où voir le plus vite ce qui a modifié mon solde ?

Dans l’historique des soldes. Vous y voyez quelle opération a ajouté ou retiré des fonds et quel solde a été affecté.

### 6-9. Pourquoi le solde bonus ne peut-il pas être retiré directement ?

Parce que les pièces bonus font partie du cycle interne du projet. Le withdraw n’est autorisé que depuis le solde principal.

### 6-10. Pourquoi, après un withdraw ou un exchange, l’historique ne se met-il pas à jour partout de la même façon immédiatement ?

Parce que les différents écrans ne se mettent pas toujours à jour en même temps. Vérifiez dans cet ordre : actualiser la section → vérifier le solde → vérifier l’historique.

### 6-11. Que se passe-t-il si, avec une connexion faible, j’appuie plusieurs fois de suite sur le bouton d’achat ou d’échange ? Des pièces supplémentaires seront-elles débitées ?

Non. Aucune pièce supplémentaire ne sera débitée. Le cœur du système dispose d’une protection stricte contre les doubles débits. Même si vous appuyez 10 fois à cause d’un blocage réseau, l’opération sera exécutée exactement une seule fois.

## 7. Panels

### 7-1. Combien d’EFHC faut-il pour activer un panel ?

Il faut 100 EFHC pour activer un panel.

### 7-2. Que donne immédiatement l’activation du premier panel ?

L’activation du premier panel lance immédiatement la génération d’énergie, ouvre la voie à la progression, crée un chemin vers les EFHC principaux et attribue le statut actif permanent Activ.

### 7-3. Quand la génération du panel commence-t-elle ?

La génération commence immédiatement après l’activation du panel.

### 7-4. Quelle est la durée de vie d’un panel ?

Chaque panel possède un cycle de 180 jours.

### 7-5. Que se passe-t-il avec un panel après la fin du cycle de 180 jours ?

Après la fin du cycle de 180 jours, le panel est désactivé et part dans Archive comme mémoire du progrès énergétique du participant.

### 7-6. Quels sont les deux états des panels dans l’interface ?

L’interface contient Activ et Archive. Activ regroupe les panels qui participent à la génération. Archive regroupe les panels qui ont déjà terminé leur cycle actif et conservent l’historique du parcours.

### 7-7. Puis-je activer plus d’un panel à la fois ?

Oui. Vous pouvez activer des panels successivement en augmentant le nombre de panels actifs. Plus vous avez de panels actifs, plus la génération totale d’énergie est élevée et plus votre progression grandit vite.

### 7-8. Que signifie le minuteur « Remaining » sur un panel ?

Le minuteur montre combien de temps il reste avant la fin du cycle de 180 jours du panel. Quand le temps s’achève, le panel passe automatiquement dans Archive et cesse d’être actif.

### 7-9. Pourquoi suis-je devenu Activ après l’activation du premier panel ?

Parce que le statut Activ confirme une participation réelle et protège le projet contre les bots. Le projet relie Activ à l’activation du premier panel afin que seuls les participants réels obtiennent ce statut.

### 7-10. Pourquoi les panels actifs sont-ils plus importants que les panels archivés ?

Les panels actifs génèrent de l’énergie maintenant : ce sont eux qui donnent votre rythme de croissance actuel. Les panels archivés sont des panels terminés ; ils conservent l’historique, mais ne produisent plus de génération actuelle.

### 7-11. Pourquoi ai-je moins de panels actifs que je n’en ai activés ?

Parce qu’une partie des panels a pu terminer sa période de 180 jours et passer dans Archive. Les panels actifs sont ceux qui fonctionnent maintenant. Archive contient les panels terminés, qui ne donnent plus de génération actuelle.

### 7-12. Les panels actifs peuvent-ils « disparaître » à cause de la limite de 1000 ?

Non. La limite de 1000 signifie qu’il est impossible d’avoir plus de 1000 panels actifs en même temps. Les panels actifs déjà activés ne « disparaissent » pas : ils restent actifs jusqu’à la fin de leur durée, puis passent dans Archive.

### 7-13. Que faire si j’ai activé un panel mais que la génération n’a pas changé tout de suite ?

Vérifiez :
— actualiser la section Panels
— voir si le panel est apparu dans Active
— ouvrir Energy et vérifier le taux de génération
— vérifier l’historique des soldes (il doit y avoir un débit de 100 EFHC)

### 7-14. Puis-je activer un panel si j’ai moins de 100 EFHC ?

Non. Il faut 100 EFHC pour activer un panel. Si vous avez moins, l’activation ne passera pas.

### 7-15. Pourquoi les panels Archive sont-ils importants s’ils ne génèrent plus ?

Archive conserve l’historique de vos panels et des cycles que vous avez traversés. C’est votre « biographie de croissance », mais seule la génération actuelle provient des panels actifs.

### 7-16. Puis-je activer un panel et voir immédiatement qu’il est actif ?

Oui. Le panel activé doit apparaître dans la liste Active, et son activation doit aussi se refléter dans l’historique des soldes.

### 7-17. Combien d’énergie un panneau produit-il en 180 jours ?

Un panneau au taux de base produit 107.61984000 kWh en 180 jours. Avec un EFHC VIP NFT, la génération est de 115.24032000 kWh.

## 8. Energy

### 8-1. Que montre la page Energy ?

La page Energy affiche la progression énergétique, la barre de progression de génération d’énergie, le nombre de panels actifs, la génération totale des panels par seconde et d’autres indicateurs clés de l’état actuel.

### 8-2. Que montre la barre de progression sur la page Energy ?

La barre de progression montre le chemin vers le prochain niveau de progression du joueur sur l’échelle des 12 niveaux.

### 8-3. Que signifie la génération totale des panels par seconde ?

C’est la constante de génération de base ou VIP multipliée par le nombre de panels actifs.

### 8-4. Pourquoi l’énergie est-elle si importante ?

Parce que l’énergie est la base centrale de la progression dans EFHC. C’est par elle que l’utilisateur passe des panels au résultat qui influence le solde, les niveaux, le classement et le développement du compte.

### 8-5. Peut-on comprendre avec Energy à quel point un compte est fort ?

Oui. La page Energy montre rapidement la force actuelle du système : combien de panels fonctionnent, quelle génération est en cours maintenant, quelle quantité d’énergie a déjà été accumulée et à quelle distance l’utilisateur se trouve du prochain niveau.

### 8-6. Pourquoi l’énergie disponible et le solde principal sont-ils comptés séparément ?

Parce qu’il s’agit de deux entités différentes. L’énergie disponible montre les kWh accumulés, tandis que le solde principal montre les EFHC principaux déjà reçus. Ces valeurs sont liées, mais ce ne sont pas la même chose.

### 8-7. Pourquoi l’énergie augmente-t-elle d’elle-même alors que le solde principal n’augmente pas automatiquement ?

Parce que l’accumulation d’énergie et l’augmentation du solde principal se produisent à des étapes différentes. D’abord les panneaux génèrent de l’énergie, et le solde principal n’augmente qu’après une action d’échange distincte ou un autre scénario de crédit des EFHC principaux.

### 8-8. Que montre la vitesse de génération par seconde ?

C’est l’indicateur de la vitesse à laquelle vos panels actifs créent de l’énergie maintenant, c’est-à-dire votre rythme de croissance actuel.

### 8-9. Qu’est-ce qu’il est particulièrement important de suivre chaque jour dans Energy ?

Le nombre de panels actifs, la vitesse de génération et l’énergie disponible : ce sont les trois repères principaux de l’état du compte.

### 8-10. Comment comprendre via Energy que mes panels fonctionnent réellement ?

Si Energy montre des panels actifs et une génération non nulle, tandis que l’énergie disponible augmente progressivement, vos panels fonctionnent. Si la génération est à 0 et que l’énergie ne s’accumule pas, il n’y a pas de panels actifs ou vous regardez le mauvais bloc.

### 8-11. Pourquoi les chiffres d’énergie affichés à l’écran peuvent-ils parfois être légèrement corrigés ou sauter ?

Pour votre confort, les chiffres d’énergie accumulée sont mis à jour en temps réel à l’écran afin de montrer un processus de génération continu. Cependant, la principale source de vérité reste toujours le serveur. Périodiquement, et aussi après chacune de vos actions, l’application se synchronise avec le serveur pour garantir une précision mathématique absolue. À ce moment-là, une micro-correction des chiffres affichés vers la valeur exacte du serveur peut se produire.

## 9. Exchange

### 9-1. Qu’est-ce que Exchange ?

Exchange est la section où l’énergie se transforme en EFHC principaux. C’est l’une des étapes clés du parcours de l’utilisateur à l’intérieur du projet.

### 9-2. Comment fonctionne l’échange d’énergie contre des EFHC ?

L’échange est la conversion de la progression en EFHC principaux. L’énergie accumulée se transforme en pièces principales du projet.

### 9-3. Que signifie la règle 1 kWh = 1 EFHC ?

C’est le taux interne fixe du projet. Chaque unité d’énergie est convertie en une quantité égale d’EFHC.

### 9-4. Que se passe-t-il après l’échange ?

Après l’échange, le résultat énergétique apparaît sur le solde principal sous forme d’EFHC principaux. Ce n’est plus simplement de l’énergie accumulée, mais un résultat qui participe aux opérations clés du projet.

### 9-5. Pourquoi l’échange est-il si important ?

Parce que c’est par l’échange que l’utilisateur convertit l’énergie accumulée en résultat principal. C’est le point où le parcours énergétique devient des EFHC principaux.

### 9-6. Peut-on échanger directement des pièces bonus sans énergie ?

Non. Les pièces bonus participent d’abord au cycle interne : elles servent à activer un panel, le panel génère de l’énergie, et ce n’est qu’ensuite que l’énergie est échangée contre des EFHC principaux.

### 9-7. Pourquoi l’échange arrive-t-il immédiatement sur le solde principal et non sur le bonus ?

Parce que Exchange est la transformation de l’énergie en résultat principal. Dans le projet, la règle 1 kWh = 1 EFHC est fixée, et le résultat de l’échange est toujours crédité sur le solde principal, à partir duquel les opérations clés et le withdraw sont disponibles.

### 9-8. Que faire si j’ai effectué un échange mais que je ne vois pas le résultat tout de suite ?

Commencez par actualiser la section Exchange et vérifiez le solde principal. Ouvrez ensuite l’historique des soldes : il doit contenir une ligne d’échange. Si cette ligne existe, l’échange a bien été effectué, même si vous ne remarquez pas tout de suite le changement à l’écran.

### 9-9. Puis-je échanger l’énergie et demander un withdraw immédiatement ?

Oui, si le solde principal contient assez d’EFHC après l’échange, si le montant du withdraw n’est pas inférieur à 10 EFHC et si le wallet est connecté et sélectionné comme principal.

### 9-10. Qu’est-ce qui est préférable : échanger souvent ou accumuler ?

Cela dépend de votre objectif. Un échange fréquent est pratique pour le contrôle et les opérations, tandis que l’accumulation est pratique pour des étapes importantes plus rares. Une seule règle ne change pas : le résultat de l’échange va sur le solde principal.

### 9-11. Pourquoi l’énergie disponible diminue-t-elle après l’échange ?

Parce que vous transférez une partie de l’énergie accumulée en EFHC via Exchange. L’énergie ne disparaît pas : elle se transforme en pièces. Important : la quantité d’énergie sur l’écran principal Energy ne doit pas « diminuer » en tant que progression totale ; seule la partie disponible pour l’action d’échange est consommée.

### 9-12. Quelle énergie puis-je déjà échanger ?

Vous pouvez échanger l’énergie qui s’est déjà accumulée et qui est devenue disponible. C’est précisément l’énergie disponible : le volume déjà prêt pour l’action dans la section Exchange.

### 9-13. Existe-t-il une limite minimale pour échanger l’énergie contre des EFHC principaux ?

Il n’existe pas de limite stricte, mais la logique d’échange suit le taux 1 kWh = 1 EFHC. Il est raisonnable d’accumuler et d’échanger des valeurs entières d’énergie à partir de 1 kWh afin que le résultat soit immédiatement visible sur le solde principal.

## 10. Withdraw

### 10-1. Pourquoi ne puis-je pas retirer mes EFHC ?

La raison la plus fréquente est un manque de fonds sur le solde principal, un wallet non connecté ou un montant inférieur au seuil minimal de withdraw. Il faut commencer la vérification par Wallet et par le solde principal.

### 10-2. Comment se déroule le withdraw ?

Une demande de withdraw est créée, puis elle est traitée aussi vite que possible par le premier opérateur disponible.

### 10-3. Pourquoi le solde a-t-il changé immédiatement après la demande de withdraw ?

Parce que le bot prend immédiatement en compte le début de cette opération dans le système. Cela permet à l’utilisateur de voir que l’action est déjà liée à ses fonds et qu’elle a été acceptée par le système.

### 10-4. Depuis quel balance peut-on faire un withdrawal ?

Le withdrawal est disponible uniquement depuis le balance principal.

### 10-5. Pourquoi le withdraw n’est-il disponible que depuis le solde principal ?

Parce que le solde principal correspond à ce qui appartient déjà à l’utilisateur comme résultat du processus de jeu ou comme pièces achetées. Les pièces bonus participent au cycle interne et ne sont pas retirées directement.

### 10-6. Quel est le montant minimal du withdraw ?

Le montant minimal du withdraw est de 10 EFHC.

### 10-7. Combien de temps la demande de withdraw est-elle habituellement traitée ?

Le withdraw passe par une demande puis par un traitement par opérateur. Si le résultat n’est pas visible immédiatement, vérifiez le statut de la demande et l’historique des opérations : c’est là que se trouve l’état réel. Si la demande ne change pas pendant longtemps, actualiser la section aide souvent.

### 10-8. Puis-je annuler une demande de withdraw ?

Oui, si la demande n’a pas encore été traitée. L’annulation est disponible pour une demande en attente. Après l’annulation, vérifiez le solde principal et l’historique des opérations : si des fonds avaient été retenus, ils reviennent.

### 10-9. Pourquoi une demande de withdraw peut-elle rester « en attente » ?

Parce que le withdraw passe par un traitement. Si la demande ne change pas, vérifiez le statut de la demande et l’historique des opérations, puis actualisez la section plus tard.

### 10-10. Où puis-je voir que la demande a été annulée ?

Cela se voit au statut de la demande et à la ligne correspondante dans l’historique des opérations. Après l’annulation, vérifiez aussi le solde principal.

### 10-11. Pourquoi le minimum de withdraw est-il précisément de 10 EFHC ?

Parce qu’un seuil est fixé dans le projet, en dessous duquel les demandes ne sont pas acceptées. Le minimum est de 10 EFHC. En plus, la commission de withdraw est payée par le projet, et retirer des montants inférieurs à 10 EFHC n’est pas rationnel.

### 10-12. Pourquoi le withdrawal peut-il être indisponible même si j’ai des EFHC ?

Parce que seul le balance principal est pris en compte pour le withdrawal. Si les EFHC se trouvent dans la partie bonus du balance, il est impossible de faire un withdrawal sur eux.

### 10-13. Que faire après avoir déposé une demande de withdraw ?

Vérifiez le statut de la demande et l’historique des opérations : c’est là que se voit l’état réel de la demande et du mouvement des fonds.

### 10-14. Dans quel token et sur quel réseau les retraits sont-ils effectués ?

Les retraits sont effectués uniquement en tokens EFHC et exclusivement sur le réseau blockchain TON (The Open Network). Aucun autre mode de retrait n’existe dans le projet.

### 10-15. Combien de temps prend le traitement manuel d’un retrait par un opérateur ?

Les demandes de retrait sont traitées par les opérateurs dans une file d’attente en temps réel. Le traitement prend généralement de quelques minutes à 24 heures selon la charge du réseau et le nombre de demandes. Vous pouvez toujours annuler une demande non traitée, et les fonds reviendront instantanément sur votre solde.

## 11. Tâches

### 11-1. Que donne l’accomplissement des tâches ?

Les tâches donnent uniquement des monnaies bonus et encouragent à participer à la vie du joueur dans le projet.

### 11-2. Comment obtenir la récompense d’une tâche ?

Il faut remplir les conditions de la tâche. Ensuite, le bot enregistre automatiquement l’accomplissement et crédite la récompense prévue.

### 11-3. Pourquoi la tâche n’a-t-elle pas été validée ?

Cela arrive si les conditions ne sont pas encore remplies entièrement, si l’action n’a pas été terminée jusqu’au bout, ou si le résultat n’a pas encore eu le temps d’être mis à jour dans le système.

### 11-4. Peut-on refaire la même tâche ?

Cela dépend du type de tâche. Certaines tâches sont uniques, tandis que d’autres peuvent se répéter selon la logique du projet.

### 11-5. Toutes les tâches donnent-elles la même récompense ?

Non. Le montant de la récompense dépend de la tâche et de ses conditions. Mais le type de récompense est ici toujours le même : des monnaies bonus.

### 11-6. Pourquoi les tâches sont-elles utiles s’il y a déjà les panels ?

Les tâches sont une voie de progression supplémentaire. Elles ne remplacent pas les panels, mais aident à accumuler des monnaies bonus qui pourront ensuite être utilisées à l’intérieur du cycle de jeu.

### 11-7. Pourquoi la récompense des tâches n’arrive-t-elle pas sur le solde principal ?

Parce que les tâches donnent des EFHC bonus. C’est une récompense interne du cycle de jeu, créditée sur le solde bonus.

### 11-8. Pourquoi les tâches se terminent-elles parfois ou disparaissent-elles ?

Parce que certaines tâches peuvent être temporaires ou limitées. Si une tâche n’est plus là, cela signifie qu’elle est terminée ou qu’elle n’est pas active en ce moment.

### 11-9. Où voir toutes les tâches disponibles ?

Dans la section Tasks : la liste des tâches disponibles et leurs conditions y est affichée.

### 11-10. Pourquoi la récompense d’une tâche n’est-elle pas apparue immédiatement ?

Parfois, il faut un peu de temps pour que le résultat se mette à jour. Vérifiez : actualiser Tasks → vérifier le solde bonus → vérifier l’historique des opérations.

### 11-11. Je me suis abonné au canal demandé dans la tâche, mais la tâche ne se valide pas. Pourquoi ?

Parfois, la vérification de l’abonnement prend du temps à cause de la mise en cache côté serveurs Telegram. Si le bot n’a pas comptabilisé l’abonnement immédiatement, revenez dans la section Tasks après quelques minutes et appuyez de nouveau sur le bouton de vérification.

## 12. Parrainage

### 12-1. Comment s’appellent les sections sur la page Referrals ?

Sur la page Referrals, les sections utilisées sont Actifs et Inactifs.

### 12-2. Que signifie un filleul actif ou inactif ?

Un filleul actif est un joueur qui a déjà acheté au moins un panel et obtenu le statut Activ. Un filleul inactif est un joueur qui n’est pas encore entré dans le cycle de jeu et ne donne donc pas encore droit à un bonus.

### 12-3. Quand les bonus de parrainage sont-ils crédités ?

Les bonus de parrainage sont vérifiés automatiquement par le bot. Dès qu’un joueur devient actif, le bonus est crédité automatiquement.

### 12-4. À quoi sert le statut actif pour les filleuls ?

Le statut actif est important pour la logique de parrainage, car le projet l’utilise comme filtre de participation réelle et comme protection contre les bots, les fermes de bots et la fausse activité.

### 12-5. Quel lien existe entre Activ et les filleuls ?

Activ montre que l’utilisateur est un participant réel du projet et non un compte automatisé. C’est essentiel pour le fonctionnement honnête du système de parrainage et pour la protection contre les fermes de bots.

### 12-6. Quel bonus de base est crédité pour chaque filleul actif ?

Pour chaque filleul actif, 0.1 EFHC est crédité sur le solde bonus.

### 12-7. Pourquoi mes filleuls sont-ils visibles, mais le bonus n’a-t-il pas été crédité ?

Le bonus n’est crédité que pour les filleuls actifs, c’est-à-dire ceux qui ont acheté au moins un panel et obtenu Activ. Vérifiez les onglets « Actifs » et « Inactifs » : le plus souvent, les invités ne sont pas encore passés au statut actif.

### 12-8. Où sont crédités les 0.1 EFHC pour un filleul actif ?

Le bonus de 0.1 EFHC est crédité sur le solde bonus. C’est une récompense interne du système de parrainage, visible dans le solde bonus et dans l’historique des opérations.

### 12-9. Pourquoi la personne invitée figure-t-elle dans la liste sans être comptée comme active ?

Parce qu’elle ne devient active qu’après l’activation du premier panel et l’obtention du statut Activ. Tant que cela n’est pas arrivé, elle reste dans la partie inactive de la liste.

### 12-10. Où trouver mon lien de parrainage ?

Dans la section Referrals : votre lien de parrainage et la liste des personnes invitées y sont affichés.

### 12-11. Est-il autorisé de créer des comptes supplémentaires via son propre lien de parrainage ?

Oui. Les règles du projet ne l’interdisent pas. Toutefois, créer des comptes vides ne vous apportera aucun avantage. L’économie du système est construite de manière à ce que les bonus de parrainage et la progression du classement ne soient crédités que pour un participant ayant le statut Activ — c’est-à-dire après que le compte invité est réellement entré dans le jeu et a acheté au moins un panneau.

### 12-12. Puis-je changer mon parrain après l’inscription ?

Non. Le lien de parrainage est fixé au moment de votre première entrée dans le projet via un lien d’invitation et ne peut plus être modifié ensuite.

## 13. Hub

### 13-1. Que puis-je faire dans Hub ?

Dans Hub, des cartes mènent aux actions liées au projet : l’accès au flux externe d’obtention d’EFHC et l’accès à la collection externe de VIP NFT.

### 13-2. À quoi sert Hub ?

Hub sert de navigation layer pour des transitions rapides vers les actions liées et les flux externes du projet.

### 13-3. Quelles cartes sont disponibles dans Hub ?

À ce stade, Hub contient deux cartes : EFHC et VIP.

### 13-4. Que fait la carte EFHC ?

La carte EFHC lance la transition vers le flux externe d’obtention d’EFHC.

### 13-5. Où le rechargement EFHC est-il crédité après confirmation ?

Un rechargement EFHC jetton est crédité sur le solde principal.

### 13-6. Pourquoi le résultat du rechargement peut-il ne pas apparaître immédiatement ?

L’étape externe de l’opération doit d’abord être confirmée, puis le résultat est mis à jour. Vérifiez Hub, le solde principal et l’historique des opérations.

### 13-7. Si j’ai reçu un VIP NFT via GetGems, où puis-je voir qu’il est actif ?

Vérifiez le statut VIP dans l’application et la présence du NFT dans le wallet lié.

### 13-8. J’ai terminé le flux externe depuis Hub, mais il n’y a aucun résultat. Que faire ?

Vérifiez Hub, le solde principal et l’historique des opérations. S’il n’y a toujours aucun résultat, l’opération n’a pas encore été récupérée ou nécessite un traitement séparé.

### 13-9. Sur quel solde arrive un rechargement via Top Up et Hub ?

Un rechargement EFHC jetton est crédité sur le solde principal.

### 13-10. Ai-je besoin d’un wallet connecté pour les actions de Hub ?

Un Wallet connecté est nécessaire pour les actions externes basées sur le wallet. Hub lui-même s’ouvre sans achat séparé et sert de point de transition.

### 13-11. Où puis-je vérifier que le rechargement EFHC a bien été crédité ?

Vérifiez le solde principal et l’historique des opérations : une trace du rechargement doit y apparaître.

### 13-12. Y a-t-il des skins dans Hub ?

Les skins ne sont pas des cartes Hub.

### 13-13. Comment obtenir les skins du projet ?

Les skins se débloquent à mesure que le compte progresse et sont liés aux 12 niveaux de réussite.

## 14. Navigation et règles

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Quels écrans dois-je ouvrir en premier si j’entre dans la WebApp pour la première fois ou après une longue pause ?

Le mieux est de commencer par l’écran principal, la barre supérieure et le profil. Ensuite, il est plus facile d’aller vers Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History et Hub selon votre tâche actuelle.

### 14-3. Comment comprendre dans quelle section chercher la fonction dont j’ai besoin ?

Choisissez la section selon le sens de l’action : Profile — pour les données du compte et les informations de référence, Wallet — pour le wallet, Panels — pour les panneaux, Energy — pour la génération, Exchange — pour l’échange, Withdraw — pour les retraits, Tasks — pour les tâches, Referrals — pour les utilisateurs invités, et Hub — pour les transitions vers les actions liées à EFHC et VIP.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Publicité

### 15-1. Qu’est-ce que cette section ?

La section Ads est une sous-section de Tasks. Elle montre les actions publicitaires disponibles par lesquelles l’utilisateur peut obtenir des monnaies bonus supplémentaires.

### 15-2. Que m’apporte-t-elle ?

Elle donne uniquement des monnaies bonus pour les vues, si la publicité est actuellement disponible pour le compte de l’utilisateur.

### 15-3. Pourquoi n’y a-t-il rien ici ?

Si la section est vide, cela signifie qu’il n’y a actuellement aucune offre active pour ce compte utilisateur ou que la publicité est temporairement désactivée.

### 15-4. Où se trouve la section Ads ?

La section Ads se trouve comme sous-section à l’intérieur de Tasks. C’est l’une des possibilités supplémentaires du bloc des tâches.

### 15-5. Quel type de récompense donne Ads ?

Ads donne uniquement des monnaies bonus pour les vues. Ce n’est ni le solde principal ni un retrait direct, mais une manière interne supplémentaire de renforcer le parcours de jeu.

### 15-6. Pourquoi Ads est-il utile ?

Parce que c’est une source supplémentaire de monnaies bonus. Il ne remplace ni les panels ni la génération, mais peut aider à renforcer plus rapidement le cycle de jeu interne.

### 15-7. Pourquoi d’autres ont-ils de la publicité et pas moi ?

Parce que les offres peuvent être indisponibles pour un compte donné ou que la publicité est temporairement désactivée. Un Ads vide ne signifie pas que le compte est cassé.

### 15-8. Que faire si j’ai effectué une action dans Ads, mais qu’il n’y a aucun résultat ?

Vérifiez : actualiser Tasks/Ads → vérifier le solde bonus → vérifier l’historique des opérations.

### 15-9. Pourquoi les utilisateurs peuvent-ils avoir des offres différentes dans Ads ?

Parce que les offres dépendent de la disponibilité des campagnes publicitaires pour un compte donné. C’est normal : l’un peut avoir des offres, l’autre pas pour le moment.

### 15-10. Faut-il acheter quelque chose pour utiliser Ads ?

Non. Ads est un moyen d’obtenir des EFHC bonus et ne requiert aucun achat obligatoire.

## 16. Ranks

### 16-1. Pourquoi la progression dans le classement est-elle importante pour moi ?

La progression dans le classement montre à quoi ressemble votre avancée par rapport aux autres participants. Cela aide à comprendre votre place actuelle et à voir à quel point le compte se développe activement.

### 16-2. Quelle est la différence entre le niveau et le classement ?

Le niveau montre votre progression personnelle à l’intérieur du système, tandis que le classement montre votre place parmi les autres participants.

### 16-3. Comment le niveau et le classement sont-ils liés ?

Ils sont liés par une même logique de croissance via la génération de kWh par les panels et la barre de progression générale sur la page Energy.

### 16-4. Le classement, ce n’est qu’un joli chiffre ?

Non. Le classement aide à comprendre à quoi ressemble votre parcours par rapport aux autres participants.

### 16-5. Qu’est-ce qui influence la progression de ma position dans le classement ?

La progression de votre position dans le classement dépend du progrès global du compte : développement des panels, génération de kWh et mouvement général sur le parcours énergétique du projet.

### 16-6. Peut-on progresser en même temps en niveau et en classement ?

Oui. Quand l’utilisateur développe ses panels, sa génération et sa progression énergétique globale, il renforce généralement à la fois son niveau et sa position dans le classement.

### 16-7. Pourquoi ai-je un niveau élevé, mais pas la première place au classement ?

Parce que le classement correspond à votre place parmi tous les participants, et pas seulement à votre progression personnelle. Les autres joueurs progressent aussi, donc votre position peut changer même avec un bon niveau.

### 16-8. Pourquoi mon classement peut-il bouger sans nouvelles actions de ma part ?

Parce que le classement n’existe pas isolément ; il évolue par comparaison avec tous les participants. Pendant que vous ne changez rien, les autres utilisateurs continuent de progresser, et cela influence votre position.

### 16-9. Où puis-je voir ma place dans le classement ?

Dans la section Ranks — votre position parmi les autres participants y est affichée.

### 16-10. Pourquoi mon classement peut-il baisser même quand je progresse ?

Parce que le classement dépend non seulement de votre propre progression, mais aussi de la vitesse de progression des autres participants. Même si votre compte se renforce, votre place peut baisser lorsque d’autres vous dépassent plus vite.

## 17. Statut Activ

### 17-1. Que signifie le statut Activ ?

Activ est un statut actif permanent. Il signifie que le jeu a vraiment commencé, parce qu’au moins un panel a été activé.

### 17-2. Comment obtenir Activ ?

Pour obtenir Activ, il suffit d’activer un panel. Après cet achat, le statut est attribué de façon permanente.

### 17-3. Activ est-il temporaire ou permanent ?

Activ est un statut permanent.

### 17-4. Activ est-il conservé si un panel passe plus tard dans Archive ?

Oui. Même si un panel passe plus tard dans Archive, le statut Activ est conservé.

### 17-5. Pourquoi Activ est-il important ?

Activ aide à distinguer les vrais joueurs des inscriptions aléatoires, des bots et des fermes à bots. Il confirme la participation réelle de l’utilisateur au projet.

### 17-6. Activ peut-il disparaître plus tard ?

Non. Activ est un statut permanent et il reste même si le premier panel passe plus tard dans Archive.

### 17-7. Pourquoi Activ est-il nécessaire pour se protéger des bots et des fermes à bots ?

Parce qu’Activ confirme une participation réelle, et non un compte vide créé pour gonfler artificiellement les chiffres. Cela rend le système de parrainage et l’économie plus honnêtes.

### 17-8. Qu’est-ce qui change dans le compte après l’obtention d’Activ ?

Le compte est considéré comme confirmé comme participant réel du projet. Cela influence le fonctionnement honnête des parrainages et la confiance accordée à l’activité.

### 17-9. Pourquoi Activ apparaît-il précisément après le premier panel ?

Parce que l’activation du premier panel est un signe clair de participation réelle. Le projet utilise cette étape comme filtre contre les comptes vides.

### 17-10. Peut-on perdre Activ à cause de l’inactivité ?

Non. Activ est un statut permanent et ne disparaît pas à cause de l’inactivité.

## 18. VIP NFT

### 18-1. Qu’est-ce qu’un EFHC VIP NFT ?

EFHC VIP NFT est une carte de club, une clé vers tout le futur écosystème EFHC, un signe numérique d’appartenance et une clé vers les futures possibilités du projet.

### 18-2. Que donne la possession d’un EFHC VIP NFT ?

La possession d’un EFHC VIP NFT donne une génération renforcée pour tous les panels du joueur.

### 18-3. Quels signes montrent que VIP est déjà pris en compte ?

Si le VIP NFT est déjà pris en compte par le système, l’interface affiche le statut VIP et les avantages liés au compte deviennent visibles.

### 18-4. Où verrai-je l’effet VIP ?

L’effet VIP est visible dans les sections où le projet prend en compte les avantages du VIP NFT, ainsi que dans la barre supérieure et dans Profil / Paramètres.

### 18-5. Faut-il activer le VIP manuellement ?

Non. La logique du projet est conçue pour vérifier automatiquement le wallet et mettre à jour automatiquement le statut VIP après la détection du NFT dans la collection requise.

### 18-6. Est-ce que 2 ou 3 VIP NFT donnent des privilèges supplémentaires au joueur ?

Non. Pour le joueur, posséder 2 ou 3 VIP NFT ne donne pas de privilèges supplémentaires au-delà d’un seul VIP NFT.

### 18-7. Pourquoi un deuxième VIP NFT ne renforce-t-il pas l’effet ?

Dans le projet, le VIP donne un bonus de génération comme un seul statut actif. Des VIP NFT supplémentaires ne donnent pas de bonus supplémentaire afin que l’effet ne s’emballe pas à l’infini.

### 18-8. Le VIP agit-il sur un seul panel ou sur tous ?

Le VIP agit sur la génération de tous les panels de l’utilisateur, et non sur un seul panel.

### 18-9. Comment vérifier que VIP influence réellement le compte ?

Vérifiez non seulement la présence du statut VIP, mais aussi les avantages associés dans la mécanique du compte, surtout là où l’effet VIP est pris en compte, y compris la génération.

### 18-10. Faut-il connecter le wallet pour que le bot voie mon VIP NFT ?

Oui. Pour que le bot voie le VIP NFT, il doit comprendre quel wallet appartient au compte. Le Wallet doit donc être connecté, puis vous vérifiez le statut VIP dans l’interface.

### 18-11. Puis-je disposer librement de mon VIP NFT ?

Oui. L’EFHC VIP NFT peut être transféré, offert et vendu sur les marketplaces.

### 18-12. Si je vends ou transfère mon VIP NFT vers un autre portefeuille, qu’arrivera-t-il à ma génération ?

Le bot scanne régulièrement la blockchain et vérifie la présence du NFT sur votre portefeuille lié. Si vous vendez, offrez ou déplacez votre VIP NFT vers une autre adresse, le système le détectera, désactivera votre statut VIP et la génération de tous vos panneaux reviendra automatiquement au taux de base.

## 19. Niveaux

### 19-1. Pourquoi devrais-je augmenter mon niveau ?

La progression du niveau montre l’avancement de l’utilisateur dans le projet et aide à voir comment le compte se développe. C’est un indicateur visuel et concret du mouvement vers l’avant.

### 19-2. Que comprend la section Niveaux ?

La section Niveaux montre toutes les échelles de progression du projet : 12 niveaux de progression énergétique, 6 niveaux du système de parrainage et d’autres lignes de progression du projet si elles sont ajoutées plus tard.

### 19-3. Combien y a-t-il de niveaux de progression énergétique dans le projet ?

Le projet prévoit 12 niveaux de progression énergétique.

### 19-4. Combien y a-t-il de niveaux dans le système de parrainage ?

Le projet prévoit 6 niveaux dans le système de parrainage : de 0 à 5.

### 19-5. En quoi les niveaux sont-ils utiles pour un joueur ordinaire ?

Les niveaux aident à comprendre où vous en êtes, ce qui a déjà été accompli, vers quoi avancer ensuite et quel prochain palier vous attend.

### 19-6. Comment les niveaux d’énergie, les niveaux de parrainage et la croissance globale du compte sont-ils liés ?

Ce sont des parties d’un même parcours global. La génération d’énergie fait avancer la progression principale, les filleuls actifs renforcent la ligne de parrainage, et ensemble ils montrent à quel point le compte se développe.

### 19-7. Eco Initiate (0 kWh)

**Sens pour le joueur :** Votre premier panel est installé et prêt à fonctionner. Vous faites le pas principal pour devenir un producteur indépendant d’énergie propre. C’est votre statut de départ — vous entrez seulement dans le parcours de génération.

**Règle exacte :** Le niveau Eco Initiate correspond au seuil de 0 kWh.

**Conséquence pratique :** L’étape suivante consiste à lancer la croissance de la génération grâce aux panels et à amener la progression à 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Sens pour le joueur :** Les premiers kilowatts sont là ! Vos panels génèrent avec succès de l’énergie verte, donnant à la nature l’espoir d’un avenir sans carbone. Vous voyez déjà les premiers résultats réels : l’énergie est lancée et la progression a bougé.

**Règle exacte :** Le niveau Hope Bringer commence à 100 kWh.

**Conséquence pratique :** L’objectif suivant est d’augmenter la stabilité et d’atteindre 300 kWh pour l’étape suivante.

### 19-9. Energy Seeker (300 kWh)

**Sens pour le joueur :** Le système fonctionne très bien, en alimentant de manière stable le réseau en électricité écologique. Chaque unité d’énergie produite par les panels remplace les combustibles fossiles. Le compte est entré en phase de croissance durable : vous n’êtes plus un « nouveau », mais un utilisateur avec une génération réelle.

**Règle exacte :** Le niveau Energy Seeker commence à 300 kWh.

**Conséquence pratique :** En pratique, c’est un signal : vous pouvez renforcer les panels et utiliser plus souvent Exchange pour transformer l’énergie en solde principal.

### 19-10. Nature's Voice (600 kWh)

**Sens pour le joueur :** Votre contribution devient visible. En générant de l’énergie à l’aide de technologies vertes, vous devenez la voix de la nature, en prouvant que le progrès peut être écologique. Votre contribution devient plus visible : la progression n’est plus perçue comme un hasard, mais comme une trajectoire.

**Règle exacte :** Le niveau Nature's Voice commence à 600 kWh.

**Conséquence pratique :** Le prochain repère est 1000 kWh (Earth Ally). Il est utile de vérifier le rythme dans Energy et le nombre de panels actifs.

### 19-11. Earth Ally (1000 kWh)

**Sens pour le joueur :** Le premier mégawattheure a été généré ! Vos panels ont produit un volume impressionnant d’énergie propre. Vous êtes maintenant un acteur important de la transition verte et un allié fidèle de la planète. Vous avez franchi un cap important : 1000 kWh, c’est déjà un volume sérieux de génération accumulée.

**Règle exacte :** Le niveau Earth Ally commence à 1000 kWh.

**Conséquence pratique :** En pratique, c’est le point où la croissance devient prévisible : renforcez votre parc de panels et maintenez un échange d’énergie régulier.

### 19-12. Climate Fighter (2000 kWh)

**Sens pour le joueur :** Votre génération porte un coup réel au changement climatique. Chaque kilowatt produit réduit directement le besoin de brûler du charbon et du gaz. Vous exercez déjà une pression systémique par votre croissance : la progression se voit à la fois sur le niveau et sur la dynamique générale du compte.

**Règle exacte :** Le niveau Climate Fighter commence à 2000 kWh.

**Conséquence pratique :** L’étape suivante consiste à consolider le rythme et à atteindre 3500 kWh. Surveillez la vitesse de génération et utilisez le VIP si nécessaire.

### 19-13. Green Sentinel (3500 kWh)

**Sens pour le joueur :** Le flux stable d’énergie provenant de vos panels veille sur un air propre. Vous apportez un bénéfice tangible à la société sans laisser d’empreinte carbone. Votre compte devient le « gardien » d’une génération stable : la progression avance avec assurance.

**Règle exacte :** Le niveau Green Sentinel commence à 3500 kWh.

**Conséquence pratique :** En pratique, cela signifie que les panels fonctionnent déjà comme un système — maintenez les panels actifs et planifiez la croissance jusqu’à 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Sens pour le joueur :** 5000 kWh de génération propre ! La puissance de vos panels agit comme un bouclier invisible, protégeant l’atmosphère contre des milliers de kilogrammes d’émissions de gaz à effet de serre. 5000 kWh est un grand signe d’ampleur : vous êtes déjà dans la zone des participants les plus forts en énergie.

**Règle exacte :** Le niveau Planet Defender commence à 5000 kWh.

**Conséquence pratique :** Le prochain repère est 7500 kWh. Souvent, à ce stade, les joueurs renforcent à la fois leurs panels et leur réseau de parrainage.

### 19-15. Eco Champion (7500 kWh)

**Sens pour le joueur :** Des volumes de production remarquables ! Vous êtes un véritable champion de l’énergie verte, dont la contribution modifie sensiblement l’équilibre énergétique mondial dans le bon sens. C’est le niveau de ceux qui maintiennent durablement un rythme de génération élevé.

**Règle exacte :** Le niveau Eco Champion commence à 7500 kWh.

**Conséquence pratique :** En pratique : gardez la discipline — panels actifs, Exchange régulier, contrôle de l’historique et des soldes.

### 19-16. Planet Saver (10000 kWh)

**Sens pour le joueur :** 10 mégawattheures ! Vous avez généré tant d’énergie propre que vous sauvez littéralement des écosystèmes entiers, en démontrant l’efficacité maximale de vos panels. 10 000 kWh, c’est déjà « dix mégawattheures » de génération, une étape très forte de progression.

**Règle exacte :** Le niveau Planet Saver commence à 10000 kWh.

**Conséquence pratique :** L’étape suivante est 15000 kWh. À ce stade, il est logique d’optimiser tout : panels, VIP, parrainages, achats.

### 19-17. Green Commander (15000 kWh)

**Sens pour le joueur :** Vaisseau amiral de la génération écologique. Vos panels alimentent l’avenir, et des volumes de production impressionnants fixent de nouveaux standards élevés pour toute la communauté. Vous êtes proche du sommet : c’est un niveau de leadership sur le plan énergétique.

**Règle exacte :** Le niveau Green Commander commence à 15000 kWh.

**Conséquence pratique :** En pratique : gardez la stabilité et montez vers 20000+ kWh, en surveillant les panels actifs et le rythme dans Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Niveau de parrainage 0

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 0 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-20. Niveau de parrainage 1

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 1 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-21. Niveau de parrainage 2

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 10 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-22. Niveau de parrainage 3

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 100 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-23. Niveau de parrainage 4

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 300 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-24. Niveau de parrainage 5

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 1000 EFHC.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Pourquoi les noms des niveaux sont-ils liés à l’écologie et à la planète ?

Parce que l’idée même du jeu est liée à l’énergie verte virtuelle, à la motivation des personnes et à une contribution symbolique à la restauration de la planète Terre.

## 20. FAQ / Aide

### 20-1. Où ouvrir la FAQ ?

La FAQ s’ouvre depuis le profil comme section d’aide intégrée du bot, où sont rassemblées les réponses sur les actions principales, les écrans et les règles du projet.

### 20-2. À quoi sert la FAQ / Aide ?

Cette section sert à permettre à l’utilisateur de trouver rapidement des réponses claires, des chiffres exacts, les règles réelles du projet et le sens des actions principales, sans suppositions ni confusion.

### 20-3. Pourquoi la FAQ est-elle décrite de façon si détaillée ?

Parce que le projet est multicouche et qu’une aide courte et sèche ne couvre pas les vraies questions du joueur. Ici, le sens, la clarté, les chiffres exacts et les conséquences réelles des actions sont importants.

### 20-4. Peut-on comprendre tout le parcours du joueur dans le bot grâce à la FAQ ?

Oui. Une bonne FAQ doit expliquer non seulement des boutons séparés, mais aussi tout le parcours : du premier panel à l’énergie, à l’échange, aux soldes, aux niveaux, aux statuts et à la croissance du compte.

### 20-5. Que faire si je n’ai pas trouvé la réponse du premier coup ?

Il vaut mieux ouvrir une section proche par le sens et regarder les questions voisines. Dans un grand bot, beaucoup de réponses sont liées entre elles, et un bloc aide souvent à comprendre le suivant.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. Que vérifier si « tout semble cassé » ?

Vérifiez trois choses : 1) Wallet — le wallet est-il connecté et le principal est-il sélectionné, 2) les soldes et l’historique — y a-t-il la trace de votre opération, 3) la section concernée (Panels / Energy / Exchange / Withdraw). En général, la réponse se trouve dans l’un de ces endroits.

### 20-8. Quel est le moyen le plus rapide de comprendre ce qui est arrivé à mes EFHC ?

Ouvrez l’historique des soldes. L’historique montre exactement ce qui a modifié les soldes : récompense, achat, échange ou retrait.

### 20-9. Par quoi commencer si j’ouvre le bot pour la première fois et que je ne comprends rien ?

Commencez par Energy (l’écran principal), puis ouvrez Panels, regardez les soldes et l’historique, et seulement ensuite décidez si vous avez besoin d’un wallet et d’un rechargement.

### 20-10. Comment trouver le plus vite possible la bonne question dans la FAQ ?

Le moyen le plus rapide est d’ouvrir la section correspondant au sujet (Wallet / Panels / Exchange / Withdraw, etc.) et de chercher la question là. Si vous n’êtes pas sûr, commencez par la section FAQ / Aide et repérez-vous grâce aux mots-clés.
