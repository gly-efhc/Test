# EFHC FAQ (FR)

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. À propos du projet

### 1-1. Qu’est-ce que l’EFHC ?

EFHC est un projet de jeu centré sur l’énergie, le progrès et le développement du compte à l’intérieur du bot. L’utilisateur achète des panels, accumule de l’énergie, l’échange contre des EFHC, suit ses balances, progresse par niveaux, monte dans le classement et utilise les fonctionnalités supplémentaires du projet.

Décryptage :
— EFHC — Energy for Humanity Coin
— EFHCm — monnaies principales
— EFHCb — monnaies bonus
— EFHCj — jetton EFHC externe
— EFHC — solde total (bonus + principal)

### 1-2. Comment obtenir mes premiers EFHC ici ?

Vos premiers EFHC apparaissent lorsque vous alimentez votre solde dans le projet ou lorsque vous commencez à utiliser ses mécanismes internes. Le point de départ le plus simple est d’activer un panel, puis d’accumuler de l’énergie et de développer progressivement votre compte.

### 1-3. D’où vient mon énergie ?

L’énergie dans le projet est générée par vos panels. Plus votre base de panels est forte et plus vous interagissez régulièrement avec le projet, plus votre progression est stable.

### 1-4. Qu’est-ce qui influence le plus ma croissance dans le projet ?

Votre croissance est surtout influencée par quatre éléments : le nombre de panels, l’activité de votre compte, l’accumulation d’énergie, et l’utilisation cohérente des sections principales du projet. La progression est plus forte lorsque vous avancez de manière régulière et non chaotique.

### 1-5. Comment savoir que j’avance correctement ?

Vous avancez correctement si votre compte devient progressivement plus solide : l’énergie s’accumule, les soldes évoluent, de nouvelles sections deviennent utiles, l’activité reste régulière et votre position dans le projet se renforce avec le temps.

### 1-6. L’EFHC est-il une monnaie ou une unité de jeu ?

À l’intérieur du bot, l’EFHC fonctionne comme une unité interne du projet, liée à votre progression, à l’énergie et aux mécanismes de jeu. Selon le contexte, l’utilisateur peut voir l’EFHC comme l’unité d’activité, de croissance et d’interaction économique au sein de l’écosystème.

### 1-7. Pourquoi le projet est-il lié à l’énergie ?

Parce que l’idée centrale de l’EFHC repose sur l’énergie comme base du développement. Les panels, l’accumulation, l’échange, la progression et les niveaux sont intégrés dans une logique unique où la croissance du compte est reliée au thème de la production et du mouvement de l’énergie.

### 1-8. Que se passe-t-il si j’utilise le projet de façon irrégulière ?

Si l’utilisation est irrégulière, votre progression ralentit. Cela ne signifie pas forcément une perte du compte, mais un développement stable se construit justement grâce à une participation régulière, à l’attention portée aux sections clés et à un contrôle de votre état dans le projet.

### 1-9. Quelle logique générale faut-il comprendre dès le début ?

La logique générale est simple : vous renforcez votre compte, développez les panels, accumulez de l’énergie, suivez vos soldes, utilisez les fonctionnalités du projet et avancez pas à pas. L’EFHC est construit sur la croissance progressive, et non sur des actions ponctuelles au hasard.

### 1-10. Comment faut-il aborder le projet au début ?

Au début, il vaut mieux aborder l’EFHC comme un système unique : comprendre l’interface, examiner le solde, l’énergie, les panels, le profil et les sections principales. Plus votre vision d’ensemble est claire dès le départ, plus il sera facile d’avancer de manière cohérente.

## 2. Écran principal

### 2-1. Que montre l’écran principal ?

L’écran principal est la page Energy. Il regroupe les éléments essentiels de l’état actuel du compte : actions rapides, informations sur la progression et points d’entrée vers les sections importantes du bot.

### 2-2. Pourquoi l’écran principal est-il considéré comme central ?

Parce que c’est sur cet écran que l’utilisateur voit le plus rapidement l’état général du compte. Il sert de point de repère : on y constate la dynamique du projet, l’évolution des indicateurs et l’accès aux fonctions clés.

### 2-3. Que dois-je regarder en premier ?

Les plus importants sont ceux qui mènent vers les sections-clés liées à l’énergie, aux panels, au solde, au profil, à Panels, à Exchange, ainsi qu’aux actions rapides Top Up et Hub, qui ouvrent les actions liées à EFHC et VIP.

### 2-4. Que dois-je vérifier chaque jour sur l’écran principal ?

Chaque jour, il faut vérifier l’état général du compte : les soldes, l’énergie, l’activité des sections clés, l’affichage des éléments importants et la cohérence des données visibles. Ce contrôle quotidien aide à ne pas manquer les changements utiles.

### 2-5. Pourquoi l’écran principal change-t-il avec le temps ?

Parce que le compte se développe. Avec la progression, l’activité, les panels et le statut de l’utilisateur, de nouveaux éléments visuels, de nouveaux indicateurs ou différentes priorités d’interface peuvent apparaître.

### 2-6. Comment comprendre via l’écran principal que le compte progresse ?

Quand le compte progresse, cela se voit par la stabilité des indicateurs, l’apparition de nouvelles possibilités, le mouvement des soldes, la croissance de l’énergie et le renforcement général de la position du compte dans le projet.

### 2-7. Quels boutons de l’écran principal sont les plus importants ?

Les actions principales sont Panels, Exchange, Rechargement direct dans la barre supérieure et Hub. Hub affiche uniquement le bouton Recharger.

### 2-8. Que faire si l’écran principal semble trop simple au début ?

C’est normal. Au début, l’interface peut paraître sobre, car l’état du compte est encore limité. À mesure que vous utilisez le projet, l’écran principal devient plus informatif et plus dense.

### 2-9. Peut-on utiliser l’écran principal comme repère de progression ?

Oui. C’est l’un des repères les plus pratiques. Si les indicateurs deviennent plus solides, que de nouvelles sections gagnent en importance et que le compte paraît plus avancé dans l’ensemble, alors vous progressez dans la bonne direction.

### 2-10. Quel est le rôle global de l’écran principal dans l’EFHC ?

Le rôle global de l’écran principal est de réunir les éléments clés du projet en un seul point : état du compte, navigation rapide, suivi du progrès et accès aux fonctions importantes.

## 3. Barre supérieure

### 3-1. Qu’est-ce que la barre supérieure ?

La barre supérieure est un élément d’interface distinct et le principal bloc d’information rapide disponible sur les pages principales du bot.

### 3-2. Que voit-on dans la barre supérieure ?

La barre supérieure affiche l’avatar, le nom, le niveau de progression énergétique, le statut VIP, le solde total, le bouton Top Up et le bouton Hub.

### 3-3. Pourquoi la barre supérieure est-elle importante ?

Parce qu’elle permet de voir immédiatement les informations essentielles sur votre compte sans navigation inutile : qui vous êtes, quelle est votre progression, si vous avez le VIP, combien de pièces vous avez au total et quelles actions rapides sont disponibles maintenant.

### 3-4. Que montre le solde total dans la barre supérieure ?

Le solde total montre combien de pièces vous avez au total. C’est pratique, car vous n’avez pas besoin d’additionner vous-même les ressources pour les action internes et pour comprendre l’état général de votre compte dans le jeu.

### 3-5. Pourquoi le solde total est-il pratique pour les action internes ?

Parce qu’il montre le pouvoir d’action interne global du joueur à l’intérieur du jeu et aide à comprendre rapidement si les ressources suffisent pour les actions internes.

### 3-6. Pourquoi le solde total n’est-il pas égal à ce que je peux retirer tout de suite ?

Parce que le solde total inclut à la fois les pièces principales et les pièces bonus. Les pièces bonus servent au cycle interne du jeu et ne sont pas retirées directement.

### 3-7. Quand faut-il utiliser le bouton « Recharger » dans la barre supérieure ?

Utilisez-le lorsque vous voulez accéder rapidement au scénario de recharge du solde principal disponible dans l’application, sans ouvrir manuellement des sections supplémentaires.

### 3-8. Pourquoi ouvrir Hub depuis la barre supérieure ?

Pour ouvrir rapidement les cartes des actions liées au projet et passer au flux externe nécessaire sans navigation supplémentaire dans l’interface.

### 3-9. Pourquoi la barre supérieure est-elle visible sur différentes pages ?

Parce qu’elle sert de tableau de bord du compte : elle vous permet de toujours voir l’essentiel — le solde, les statuts et les actions rapides — même lorsque vous ouvrez une autre section.

### 3-10. Que faire si les données de la barre supérieure semblent incorrectes ?

Commencez par actualiser la page et vérifier l’historique des soldes : il montre les opérations réelles. Si l’historique et le solde coïncident, les données sont correctes ; vous avez peut-être simplement regardé le mauvais solde, par exemple le solde total au lieu du solde principal.

## 4. Profil

### 4-1. Qu’est-ce que la section Profil/Paramètres ?

Profil/Paramètres est la section où vous gérez votre profil et les réglages du bot. On y voit les statuts principaux et on y trouve les paramètres personnels de l’interface.

### 4-2. Que puis-je faire dans le profil ?

Le profil regroupe les principaux réglages utilisateur et des accès rapides vers les sections importantes : Wallet, historique des soldes, FAQ et autres points de contrôle utiles.

### 4-3. Qu’est-ce qui est affiché en haut de Profil/Paramètres ?

En haut de Profil/Paramètres s’affichent l’avatar, le nom Telegram ainsi que les statuts Activ et VIP, si vous les avez déjà.

### 4-4. Où puis-je changer la langue ?

La langue se change dans Profil/Paramètres.

### 4-5. Pourquoi ai-je besoin d’un profil ?

Le profil est votre point personnel de gestion du compte. Ici, l’utilisateur ne se contente pas de voir ses statuts : il ouvre aussi des sous-sections importantes liées au wallet, à l’historique, à la langue et à l’aide.

### 4-6. Où ouvrir l’historique des soldes dans le profil ?

Dans Profil/Paramètres, il existe une entrée séparée vers l’historique des soldes, où l’on voit les entrées et les sorties.

### 4-7. Où changer la langue dans le profil ?

Le changement de langue se trouve dans Profil/Paramètres, car il s’agit d’un réglage personnel du compte.

### 4-8. Où ouvrir Wallet dans Profil pour travailler avec le wallet ?

Dans la section Profil, il y a une entrée distincte Wallet. Ouvrez-la quand vous devez connecter un wallet, vérifier l’association ou passer à des actions liées au wallet.

### 4-9. Où ouvrir rapidement FAQ dans Profil si j’ai besoin d’une réponse ?

Dans la section Profil, il y a un accès à FAQ. Ouvrez-le quand vous avez besoin d’une réponse rapide sur l’interface, le balance, les panels, l’énergie, l’exchange, le withdrawal ou d’autres fonctions du WebApp.

### 4-10. Que contient la section « Support et informations » ?

Cette section regroupe les éléments d’aide : FAQ, conseils/informations et tout ce qui aide l’utilisateur à comprendre le projet sans confusion.

### 4-11. En combien de langues l’interface du projet est-elle disponible ?

L’interface du bot et le système d’aide (FAQ) sont traduits en 13 langues. Vous pouvez choisir la langue qui vous convient dans les paramètres du profil, et le système adapte immédiatement tous les textes et l’interface à votre choix.

## 5. Wallet

### 5-1. Pourquoi le portefeuille principal est-il nécessaire ?

Le portefeuille principal sert aux actions liées aux opérations externes du projet : retraits, rechargements, preuve de possession de l’adresse et autres actions associées où un portefeuille lié est nécessaire.

### 5-2. Puis-je changer de wallet principal ?

Oui. L’utilisateur peut choisir un autre wallet principal parmi ceux qui sont déjà connectés.

### 5-3. Puis-je supprimer un wallet lié ?

Oui. Si ce wallet n’est plus nécessaire, sa liaison peut être supprimée.

### 5-4. Pourquoi le même portefeuille ne peut-il pas être lié à deux comptes ?

Le même portefeuille ne doit pas être utilisé en même temps dans deux comptes différents. Si un portefeuille est déjà lié à un compte, il faut d’abord le détacher de ce compte avant de le lier à un autre. Cela évite la confusion dans les statuts, les vérifications et les résultats liés au portefeuille.

### 5-5. Que se passe-t-il si j’appuie sur une action qui nécessite un wallet alors que je n’en ai pas ?

Si la fonction choisie nécessite un wallet, le bot lancera d’abord la logique de connexion du wallet. Ensuite, vous pourrez revenir à l’action voulue et l’exécuter normalement.

### 5-6. Puis-je connecter plusieurs wallets et pourquoi cela serait-il utile ?

Oui. Vous pouvez connecter plusieurs wallets afin d’avoir une adresse de réserve ou de séparer différents scénarios d’utilisation. En même temps, un wallet est choisi comme principal — c’est lui qui est utilisé par défaut pour les opérations où un wallet sélectionné est nécessaire.

### 5-7. Que faire si je veux utiliser mon wallet dans un autre compte ?

Il faut d’abord dissocier ce wallet du compte actuel. Ce n’est qu’ensuite qu’il peut être lié à un autre compte. Le même wallet ne doit pas être lié à deux comptes en même temps.

### 5-8. Puis-je retirer vers un wallet non principal ?

Par défaut, le système utilise le wallet principal. Si vous avez besoin d’une autre adresse, définissez-la d’abord comme principale dans Wallet, puis soumettez la demande de retrait.

### 5-9. Que faire si le wallet est connecté mais que le retrait reste indisponible ?

Vérifiez trois choses : si un wallet principal est sélectionné, si le solde principal est suffisant et si le montant du retrait n’est pas inférieur à 10 EFHC.

### 5-10. Où vérifier quel wallet est actuellement lié à mon compte ?

Il faut vérifier cela dans la section Wallet. C’est là que l’utilisateur voit quels wallets sont liés au compte et lequel est utilisé dans le cadre du compte.

### 5-11. Que faire si je perds l’accès à mon portefeuille TON principal ?

Comme le projet permet de lier plusieurs portefeuilles, vous pouvez lier un nouveau portefeuille dans la section Wallet, le définir comme principal et supprimer définitivement l’ancienne adresse compromise de la liste des portefeuilles liés.

## 6. Soldes et historique

### 6-1. Pourquoi ai-je trois soldes différents ?

Parce que les fonds ont des rôles différents à l’intérieur du bot. Le solde total regroupe tout, le solde bonus sert au cycle interne du jeu, et le solde principal montre le résultat que vous pouvez déjà utiliser pour les opérations clés et le withdraw.

### 6-2. Qu’est-ce que le solde bonus ?

Le solde bonus est un solde de jeu interne. Il sert au développement dans le bot, il est crédité pour les tâches, les parrainages, les cadeaux et d’autres mécaniques internes du projet, mais il n’est pas retiré directement.

### 6-3. Qu’est-ce que le solde principal ?

Le solde principal correspond aux EFHC principaux. C’est vers lui que se transforme le résultat du cycle de jeu, et c’est depuis lui que les opérations clés, y compris le withdraw, deviennent disponibles.

### 6-4. Pourquoi un seul action interne peut-il affecter à la fois le solde bonus et le solde principal ?

Pour toutes les dépenses internes du projet, les fonds sont d’abord débités du solde bonus. Si cela ne suffit pas, le reste est débité du solde principal.

### 6-5. Pourquoi y a-t-il plusieurs lignes dans l’historique pour une seule opération ?

Une seule opération peut toucher plusieurs parties du mouvement des fonds. Le bot l’affiche donc sous plusieurs lignes afin de montrer séparément les différents changements.

### 6-6. Où puis-je voir d’où les EFHC sont arrivés ou d’où ils sont partis ?

Pour cela, utilisez la section de l’historique des soldes. Elle affiche les crédits, les débits, l’exchange, les action internes, le withdraw et les autres changements de fonds.

### 6-7. Pourquoi mon solde total peut-il être élevé alors que je peux retirer moins ?

Parce que le solde total additionne le principal et le bonus. Le withdraw n’est autorisé que depuis le solde principal, tandis que le bonus est destiné au cycle interne du projet. Pour un retrait, il faut donc regarder précisément le solde principal.

### 6-8. Où voir le plus vite ce qui a modifié mon solde ?

Dans l’historique des soldes. Vous y voyez quelle opération a ajouté ou retiré des fonds et quel solde a été affecté.

### 6-9. Pourquoi le solde bonus ne peut-il pas être retiré directement ?

Parce que les pièces bonus font partie du cycle interne du projet. Le withdraw n’est autorisé que depuis le solde principal.

### 6-10. Pourquoi, après un withdraw ou un exchange, l’historique ne se met-il pas à jour partout de la même façon immédiatement ?

Parce que les différents écrans ne se mettent pas toujours à jour en même temps. Vérifiez dans cet ordre : actualiser la section → vérifier le solde → vérifier l’historique.

### 6-11. Que se passe-t-il si, avec une connexion faible, j’appuie plusieurs fois de suite sur le bouton d’action interne ou d’échange ? Des pièces supplémentaires seront-elles débitées ?

Non. Aucune pièce supplémentaire ne sera débitée. Le cœur du système dispose d’une protection stricte contre les doubles débits. Même si vous appuyez 10 fois à cause d’un blocage réseau, l’opération sera exécutée exactement une seule fois.

## 7. Panels

### 7-1. Combien d’EFHC faut-il pour activer un panel ?

Il faut 100 EFHC pour activer un panel.

### 7-2. Que donne immédiatement l’activation du premier panel ?

L’activation du premier panel lance immédiatement la génération d’énergie, ouvre la voie à la progression, crée un chemin vers les EFHC principaux et attribue le statut actif permanent Activ.

### 7-3. Quand la génération du panel commence-t-elle ?

La génération commence immédiatement après l’activation du panel.

### 7-4. Quelle est la durée de vie d’un panel ?

Chaque panel possède un cycle de 180 jours.

### 7-5. Que se passe-t-il avec un panel après la fin du cycle de 180 jours ?

Après la fin du cycle de 180 jours, le panel est désactivé et part dans Archive comme mémoire du progrès énergétique du participant.

### 7-6. Quels sont les deux états des panels dans l’interface ?

L’interface contient Activ et Archive. Activ regroupe les panels qui participent à la génération. Archive regroupe les panels qui ont déjà terminé leur cycle actif et conservent l’historique du parcours.

### 7-7. Puis-je activer plus d’un panel à la fois ?

Oui. Vous pouvez activer des panels successivement en augmentant le nombre de panels actifs. Plus vous avez de panels actifs, plus la génération totale d’énergie est élevée et plus votre progression grandit vite.

### 7-8. Que signifie le minuteur « Remaining » sur un panel ?

Le minuteur montre combien de temps il reste avant la fin du cycle de 180 jours du panel. Quand le temps s’achève, le panel passe automatiquement dans Archive et cesse d’être actif.

### 7-9. Pourquoi suis-je devenu Activ après l’activation du premier panel ?

Parce que le statut Activ confirme une participation réelle et protège le projet contre les bots. Le projet relie Activ à l’activation du premier panel afin que seuls les participants réels obtiennent ce statut.

### 7-10. Pourquoi les panels actifs sont-ils plus importants que les panels archivés ?

Les panels actifs génèrent de l’énergie maintenant : ce sont eux qui donnent votre rythme de croissance actuel. Les panels archivés sont des panels terminés ; ils conservent l’historique, mais ne produisent plus de génération actuelle.

### 7-11. Pourquoi ai-je moins de panels actifs que je n’en ai activés ?

Parce qu’une partie des panels a pu terminer sa période de 180 jours et passer dans Archive. Les panels actifs sont ceux qui fonctionnent maintenant. Archive contient les panels terminés, qui ne donnent plus de génération actuelle.

### 7-12. Les panels actifs peuvent-ils « disparaître » à cause de la limite de 1000 ?

Non. La limite de 1000 signifie qu’il est impossible d’avoir plus de 1000 panels actifs en même temps. Les panels actifs déjà activés ne « disparaissent » pas : ils restent actifs jusqu’à la fin de leur durée, puis passent dans Archive.

### 7-13. Que faire si j’ai activé un panel mais que la génération n’a pas changé tout de suite ?

Vérifiez :
— actualiser la section Panels
— voir si le panel est apparu dans Active
— ouvrir Energy et vérifier le taux de génération
— vérifier l’historique des soldes (il doit y avoir un débit de 100 EFHC)

### 7-14. Puis-je activer un panel si j’ai moins de 100 EFHC ?

Non. Il faut 100 EFHC pour activer un panel. Si vous avez moins, l’activation ne passera pas.

### 7-15. Pourquoi les panels Archive sont-ils importants s’ils ne génèrent plus ?

Archive conserve l’historique de vos panels et des cycles que vous avez traversés. C’est votre « biographie de croissance », mais seule la génération actuelle provient des panels actifs.

### 7-16. Puis-je activer un panel et voir immédiatement qu’il est actif ?

Oui. Le panel activé doit apparaître dans la liste Active, et son activation doit aussi se refléter dans l’historique des soldes.

### 7-17. Combien d’énergie un panneau produit-il en 180 jours ?

Un panneau au taux de base produit 107.61984000 kWh en 180 jours. Avec un EFHC VIP NFT, la génération est de 115.24032000 kWh.

## 8. Energy

### 8-1. Que montre la page Energy ?

La page Energy affiche la progression énergétique, la barre de progression de génération d’énergie, le nombre de panels actifs, la génération totale des panels par seconde et d’autres indicateurs clés de l’état actuel.

### 8-2. Que montre la barre de progression sur la page Energy ?

La barre de progression montre le chemin vers le prochain niveau de progression du joueur sur l’échelle des 12 niveaux.

### 8-3. Que signifie la génération totale des panels par seconde ?

C’est la constante de génération de base ou VIP multipliée par le nombre de panels actifs.

### 8-4. Pourquoi l’énergie est-elle si importante ?

Parce que l’énergie est la base centrale de la progression dans EFHC. C’est par elle que l’utilisateur passe des panels au résultat qui influence le solde, les niveaux, le classement et le développement du compte.

### 8-5. Peut-on comprendre avec Energy à quel point un compte est fort ?

Oui. La page Energy montre rapidement la force actuelle du système : combien de panels fonctionnent, quelle génération est en cours maintenant, quelle quantité d’énergie a déjà été accumulée et à quelle distance l’utilisateur se trouve du prochain niveau.

### 8-6. Pourquoi l’énergie disponible et le solde principal sont-ils comptés séparément ?

Parce qu’il s’agit de deux entités différentes. L’énergie disponible montre les kWh accumulés, tandis que le solde principal montre les EFHC principaux déjà reçus. Ces valeurs sont liées, mais ce ne sont pas la même chose.

### 8-7. Pourquoi l’énergie augmente-t-elle d’elle-même alors que le solde principal n’augmente pas automatiquement ?

Parce que l’accumulation d’énergie et l’augmentation du solde principal se produisent à des étapes différentes. D’abord les panneaux génèrent de l’énergie, et le solde principal n’augmente qu’après une action d’échange distincte ou un autre scénario de crédit des EFHC principaux.

### 8-8. Que montre la vitesse de génération par seconde ?

C’est l’indicateur de la vitesse à laquelle vos panels actifs créent de l’énergie maintenant, c’est-à-dire votre rythme de croissance actuel.

### 8-9. Qu’est-ce qu’il est particulièrement important de suivre chaque jour dans Energy ?

Le nombre de panels actifs, la vitesse de génération et l’énergie disponible : ce sont les trois repères principaux de l’état du compte.

### 8-10. Comment comprendre via Energy que mes panels fonctionnent réellement ?

Si Energy montre des panels actifs et une génération non nulle, tandis que l’énergie disponible augmente progressivement, vos panels fonctionnent. Si la génération est à 0 et que l’énergie ne s’accumule pas, il n’y a pas de panels actifs ou vous regardez le mauvais bloc.

### 8-11. Pourquoi les chiffres d’énergie affichés à l’écran peuvent-ils parfois être légèrement corrigés ou sauter ?

Pour votre confort, les chiffres d’énergie accumulée sont mis à jour en temps réel à l’écran afin de montrer un processus de génération continu. Cependant, la principale source de vérité reste toujours le serveur. Périodiquement, et aussi après chacune de vos actions, l’application se synchronise avec le serveur pour garantir une précision mathématique absolue. À ce moment-là, une micro-correction des chiffres affichés vers la valeur exacte du serveur peut se produire.

## 9. Exchange

### 9-1. Qu’est-ce que Exchange ?

Exchange est la section où l’énergie se transforme en EFHC principaux. C’est l’une des étapes clés du parcours de l’utilisateur à l’intérieur du projet.

### 9-2. Comment fonctionne l’échange d’énergie contre des EFHC ?

L’échange est la conversion de la progression en EFHC principaux. L’énergie accumulée se transforme en pièces principales du projet.

### 9-3. Que signifie la règle 1 kWh = 1 EFHC ?

C’est le taux interne fixe du projet. Chaque unité d’énergie est convertie en une quantité égale d’EFHC.

### 9-4. Que se passe-t-il après l’échange ?

Après l’échange, le résultat énergétique apparaît sur le solde principal sous forme d’EFHC principaux. Ce n’est plus simplement de l’énergie accumulée, mais un résultat qui participe aux opérations clés du projet.

### 9-5. Pourquoi l’échange est-il si important ?

Parce que c’est par l’échange que l’utilisateur convertit l’énergie accumulée en résultat principal. C’est le point où le parcours énergétique devient des EFHC principaux.

### 9-6. Peut-on échanger directement des pièces bonus sans énergie ?

Non. Les pièces bonus participent d’abord au cycle interne : elles servent à activer un panel, le panel génère de l’énergie, et ce n’est qu’ensuite que l’énergie est échangée contre des EFHC principaux.

### 9-7. Pourquoi l’échange arrive-t-il immédiatement sur le solde principal et non sur le bonus ?

Parce que Exchange est la transformation de l’énergie en résultat principal. Dans le projet, la règle 1 kWh = 1 EFHC est fixée, et le résultat de l’échange est toujours crédité sur le solde principal, à partir duquel les opérations clés et le withdraw sont disponibles.

### 9-8. Que faire si j’ai effectué un échange mais que je ne vois pas le résultat tout de suite ?

Commencez par actualiser la section Exchange et vérifiez le solde principal. Ouvrez ensuite l’historique des soldes : il doit contenir une ligne d’échange. Si cette ligne existe, l’échange a bien été effectué, même si vous ne remarquez pas tout de suite le changement à l’écran.

### 9-9. Puis-je échanger l’énergie et demander un withdraw immédiatement ?

Oui, si le solde principal contient assez d’EFHC après l’échange, si le montant du withdraw n’est pas inférieur à 10 EFHC et si le wallet est connecté et sélectionné comme principal.

### 9-10. Qu’est-ce qui est préférable : échanger souvent ou accumuler ?

Cela dépend de votre objectif. Un échange fréquent est pratique pour le contrôle et les opérations, tandis que l’accumulation est pratique pour des étapes importantes plus rares. Une seule règle ne change pas : le résultat de l’échange va sur le solde principal.

### 9-11. Pourquoi l’énergie disponible diminue-t-elle après l’échange ?

Parce que vous transférez une partie de l’énergie accumulée en EFHC via Exchange. L’énergie ne disparaît pas : elle se transforme en pièces. Important : la quantité d’énergie sur l’écran principal Energy ne doit pas « diminuer » en tant que progression totale ; seule la partie disponible pour l’action d’échange est consommée.

### 9-12. Quelle énergie puis-je déjà échanger ?

Vous pouvez échanger l’énergie qui s’est déjà accumulée et qui est devenue disponible. C’est précisément l’énergie disponible : le volume déjà prêt pour l’action dans la section Exchange.

### 9-13. Existe-t-il une limite minimale pour échanger l’énergie contre des EFHC principaux ?

Il n’existe pas de limite stricte, mais la logique d’échange suit le taux 1 kWh = 1 EFHC. Il est raisonnable d’accumuler et d’échanger des valeurs entières d’énergie à partir de 1 kWh afin que le résultat soit immédiatement visible sur le solde principal.

## 10. Withdraw

### 10-1. Pourquoi ne puis-je pas retirer mes EFHC ?

La raison la plus fréquente est un manque de fonds sur le solde principal, un wallet non connecté ou un montant inférieur au seuil minimal de withdraw. Il faut commencer la vérification par Wallet et par le solde principal.

### 10-2. Comment se déroule le withdraw ?

Une demande de withdraw est créée, puis elle est traitée aussi vite que possible par le premier opérateur disponible.

### 10-3. Pourquoi le solde a-t-il changé immédiatement après la demande de withdraw ?

Parce que le bot prend immédiatement en compte le début de cette opération dans le système. Cela permet à l’utilisateur de voir que l’action est déjà liée à ses fonds et qu’elle a été acceptée par le système.

### 10-4. Depuis quel balance peut-on faire un withdrawal ?

Le withdrawal est disponible uniquement depuis le balance principal.

### 10-5. Pourquoi le withdraw n’est-il disponible que depuis le solde principal ?

Parce que le solde principal correspond à ce qui appartient déjà à l’utilisateur comme résultat du processus de jeu ou comme pièces achetées. Les pièces bonus participent au cycle interne et ne sont pas retirées directement.

### 10-6. Quel est le montant minimal du withdraw ?

Le montant minimal du withdraw est de 10 EFHC.

### 10-7. Combien de temps la demande de withdraw est-elle habituellement traitée ?

Le withdraw passe par une demande puis par un traitement par opérateur. Si le résultat n’est pas visible immédiatement, vérifiez le statut de la demande et l’historique des opérations : c’est là que se trouve l’état réel. Si la demande ne change pas pendant longtemps, actualiser la section aide souvent.

### 10-8. Puis-je annuler une demande de withdraw ?

Oui, si la demande n’a pas encore été traitée. L’annulation est disponible pour une demande en attente. Après l’annulation, vérifiez le solde principal et l’historique des opérations : si des fonds avaient été retenus, ils reviennent.

### 10-9. Pourquoi une demande de withdraw peut-elle rester « en attente » ?

Parce que le withdraw passe par un traitement. Si la demande ne change pas, vérifiez le statut de la demande et l’historique des opérations, puis actualisez la section plus tard.

### 10-10. Où puis-je voir que la demande a été annulée ?

Cela se voit au statut de la demande et à la ligne correspondante dans l’historique des opérations. Après l’annulation, vérifiez aussi le solde principal.

### 10-11. Pourquoi le minimum de withdraw est-il précisément de 10 EFHC ?

Parce qu’un seuil est fixé dans le projet, en dessous duquel les demandes ne sont pas acceptées. Le minimum est de 10 EFHC. En plus, la commission de withdraw est payée par le projet, et retirer des montants inférieurs à 10 EFHC n’est pas rationnel.

### 10-12. Pourquoi le withdrawal peut-il être indisponible même si j’ai des EFHC ?

Parce que seul le balance principal est pris en compte pour le withdrawal. Si les EFHC se trouvent dans la partie bonus du balance, il est impossible de faire un withdrawal sur eux.

### 10-13. Que faire après avoir déposé une demande de withdraw ?

Vérifiez le statut de la demande et l’historique des opérations : c’est là que se voit l’état réel de la demande et du mouvement des fonds.

### 10-14. Dans quel token et sur quel réseau les retraits sont-ils effectués ?

Les retraits sont effectués uniquement en tokens EFHC et exclusivement sur le réseau blockchain TON (The Open Network). Aucun autre mode de retrait n’existe dans le projet.

### 10-15. Combien de temps prend le traitement manuel d’un retrait par un opérateur ?

Les demandes de retrait sont traitées par les opérateurs dans une file d’attente en temps réel. Le traitement prend généralement de quelques minutes à 24 heures selon la charge du réseau et le nombre de demandes. Vous pouvez toujours annuler une demande non traitée, et les fonds reviendront instantanément sur votre solde.

## 11. Tâches

### 11-1. Que donne l’accomplissement des tâches ?

Les tâches donnent uniquement des monnaies bonus et encouragent à participer à la vie du joueur dans le projet.

### 11-2. Comment obtenir la récompense d’une tâche ?

Il faut remplir les conditions de la tâche. Ensuite, le bot enregistre automatiquement l’accomplissement et crédite la récompense prévue.

### 11-3. Pourquoi la tâche n’a-t-elle pas été validée ?

Cela arrive si les conditions ne sont pas encore remplies entièrement, si l’action n’a pas été terminée jusqu’au bout, ou si le résultat n’a pas encore eu le temps d’être mis à jour dans le système.

### 11-4. Peut-on refaire la même tâche ?

Cela dépend du type de tâche. Certaines tâches sont uniques, tandis que d’autres peuvent se répéter selon la logique du projet.

### 11-5. Toutes les tâches donnent-elles la même récompense ?

Non. Le montant de la récompense dépend de la tâche et de ses conditions. Mais le type de récompense est ici toujours le même : des monnaies bonus.

### 11-6. Pourquoi les tâches sont-elles utiles s’il y a déjà les panels ?

Les tâches sont une voie de progression supplémentaire. Elles ne remplacent pas les panels, mais aident à accumuler des monnaies bonus qui pourront ensuite être utilisées à l’intérieur du cycle de jeu.

### 11-7. Pourquoi la récompense des tâches n’arrive-t-elle pas sur le solde principal ?

Parce que les tâches donnent des EFHC bonus. C’est une récompense interne du cycle de jeu, créditée sur le solde bonus.

### 11-8. Pourquoi les tâches se terminent-elles parfois ou disparaissent-elles ?

Parce que certaines tâches peuvent être temporaires ou limitées. Si une tâche n’est plus là, cela signifie qu’elle est terminée ou qu’elle n’est pas active en ce moment.

### 11-9. Où voir toutes les tâches disponibles ?

Dans la section Tasks : la liste des tâches disponibles et leurs conditions y est affichée.

### 11-10. Pourquoi la récompense d’une tâche n’est-elle pas apparue immédiatement ?

Parfois, il faut un peu de temps pour que le résultat se mette à jour. Vérifiez : actualiser Tasks → vérifier le solde bonus → vérifier l’historique des opérations.

### 11-11. Je me suis abonné au canal demandé dans la tâche, mais la tâche ne se valide pas. Pourquoi ?

Parfois, la vérification de l’abonnement prend du temps à cause de la mise en cache côté serveurs Telegram. Si le bot n’a pas comptabilisé l’abonnement immédiatement, revenez dans la section Tasks après quelques minutes et appuyez de nouveau sur le bouton de vérification.

## 12. Parrainage

### 12-1. Comment s’appellent les sections sur la page Referrals ?

Sur la page Referrals, les sections utilisées sont Actifs et Inactifs.

### 12-2. Que signifie un filleul actif ou inactif ?

Un filleul actif est un joueur qui a déjà acheté au moins un panel et obtenu le statut Activ. Un filleul inactif est un joueur qui n’est pas encore entré dans le cycle de jeu et ne donne donc pas encore droit à un bonus.

### 12-3. Quand les bonus de parrainage sont-ils crédités ?

Les bonus de parrainage sont vérifiés automatiquement par le bot. Dès qu’un joueur devient actif, le bonus est crédité automatiquement.

### 12-4. À quoi sert le statut actif pour les filleuls ?

Le statut actif est important pour la logique de parrainage, car le projet l’utilise comme filtre de participation réelle et comme protection contre les bots, les fermes de bots et la fausse activité.

### 12-5. Quel lien existe entre Activ et les filleuls ?

Activ montre que l’utilisateur est un participant réel du projet et non un compte automatisé. C’est essentiel pour le fonctionnement honnête du système de parrainage et pour la protection contre les fermes de bots.

### 12-6. Quel bonus de base est crédité pour chaque filleul actif ?

Un bonus de 0.1 EFHCb est crédité pour chacun de vos filleuls directs — une seule fois, lorsqu’il active son premier panneau et obtient Activ.

### 12-7. Pourquoi mes filleuls sont-ils visibles, mais le bonus n’a-t-il pas été crédité ?

Le bonus n’est crédité qu’après l’activation du premier panneau par un filleul direct. Avant cela, il reste inactif ; les panneaux suivants ne créent aucun nouveau bonus de parrainage.

### 12-8. Où sont crédités les 0.1 EFHCb pour un filleul actif ?

La récompense d’activation de 0.1 EFHCb pour un filleul direct est créditée une fois sur le solde bonus. Les récompenses Lvl sont créditées sur le même solde EFHCb. Le cycle complet représente 1 000 EFHCb pour 10 000 filleuls directs actifs plus 1 411 EFHCb de récompenses Lvl, soit 2 411 EFHCb.

### 12-9. Pourquoi la personne invitée figure-t-elle dans la liste sans être comptée comme active ?

Parce qu’elle ne devient active qu’après l’activation du premier panel et l’obtention du statut Activ. Tant que cela n’est pas arrivé, elle reste dans la partie inactive de la liste.

### 12-10. Où trouver mon lien de parrainage ?

Dans la section Referrals : votre lien de parrainage et la liste des personnes invitées y sont affichés.

### 12-11. Est-il autorisé de créer des comptes supplémentaires via son propre lien de parrainage ?

Oui. Les règles du projet ne l’interdisent pas. Toutefois, créer des comptes vides ne vous apportera aucun avantage. L’économie du système est construite de manière à ce que les bonus de parrainage et la progression du classement ne soient crédités que pour un participant ayant le statut Activ — c’est-à-dire après que le compte invité est réellement entré dans le jeu et a acheté au moins un panneau.

### 12-12. Puis-je changer mon parrain après l’inscription ?

Non. Le lien de parrainage est fixé au moment de votre première entrée dans le projet via un lien d’invitation et ne peut plus être modifié ensuite.

## 13. Hub

### 13-1. Que puis-je faire dans Hub ?

Hub propose deux actions : Recharger et EFHC VIP NFT. Les détails des parcours externes apparaissent uniquement après avoir quitté Hub.

### 13-2. À quoi sert Hub ?

Hub est une section de navigation courte vers deux actions externes du projet.

### 13-3. Combien d’actions sont disponibles dans Hub ?

Exactement deux : Recharger et EFHC VIP NFT. Les deux fonctions sont canoniques.

### 13-4. Que fait le bouton « Recharger » ?

Il ouvre la suite sur une page Web externe. Les produits, prix et moyens de paiement ne sont pas affichés avant de quitter Hub.

### 13-5. Où le rechargement EFHC est-il crédité après confirmation ?

Un rechargement EFHCm est crédité sur le solde principal.

### 13-6. Pourquoi le résultat du rechargement peut-il ne pas apparaître immédiatement ?

L’étape externe de l’opération doit d’abord être confirmée, puis le résultat est mis à jour. Vérifiez Hub, le solde principal et l’historique des opérations.

### 13-7. Si j’ai reçu un VIP NFT via GetGems, où puis-je voir qu’il est actif ?

Vérifiez le statut VIP dans l’application et la présence du NFT dans le wallet lié.

### 13-8. J’ai terminé le flux externe depuis Hub, mais il n’y a aucun résultat. Que faire ?

Vérifiez Hub, le solde principal et l’historique des opérations. S’il n’y a toujours aucun résultat, l’opération n’a pas encore été récupérée ou nécessite un traitement séparé.

### 13-9. Sur quel solde arrive un rechargement via Top Up et Hub ?

Un rechargement EFHCm est crédité sur le solde principal.

### 13-10. Ai-je besoin d’un wallet connecté pour les actions de Hub ?

Un Wallet connecté est nécessaire pour les actions externes basées sur le wallet. Hub lui-même s’ouvre sans action interne séparé et sert de point de transition.

### 13-11. Où puis-je vérifier que le rechargement EFHC a bien été crédité ?

Vérifiez le solde principal et l’historique des opérations : une trace du rechargement doit y apparaître.

### 13-12. Y a-t-il des skins dans Hub ?

Les skins ne sont pas des cartes Hub.

### 13-13. Comment obtenir les skins du projet ?

Les skins se débloquent à mesure que le compte progresse et sont liés aux 12 niveaux de réussite.

## 14. Navigation et règles

### 14-1. Quand dois-je ouvrir la section « Navigation et règles » ?

Ouvre cette section lorsque tu dois comprendre rapidement la logique des écrans, trouver la fonction nécessaire dans la WebApp ou clarifier les règles de base des sections de l’application.

### 14-2. Quels écrans dois-je ouvrir en premier si j’entre dans la WebApp pour la première fois ou après une longue pause ?

Le mieux est de commencer par l’écran principal, la barre supérieure et le profil. Ensuite, il est plus facile d’aller vers Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History et Hub selon votre tâche actuelle.

### 14-3. Comment comprendre dans quelle section chercher la fonction dont j’ai besoin ?

Choisissez la section selon l’action : Profile pour le compte, Wallet pour le portefeuille, Panels pour les panneaux, Energy pour la génération, Exchange pour l’échange, Withdraw pour les retraits, Tasks pour les tâches, Referrals pour les invitations et Hub pour la transition Recharger.

### 14-4. Où se trouve l’accès au profil ?

L’accès au profil se trouve dans la partie supérieure de l’interface, via le bouton « Profile ».

### 14-5. Pourquoi certaines actions demandent-elles une confirmation séparée ?

Une confirmation séparée protège le compte et réduit le risque d’actions accidentelles lors d’opérations importantes.

### 14-6. Pourquoi certaines actions sont-elles disponibles immédiatement alors que d’autres dépendent de l’état du compte ?

Certaines fonctions dépendent de l’état du compte, de la présence d’un panel, d’un portefeuille connecté, de l’historique d’activité ou d’autres conditions internes du projet.

### 14-7. Comment comprendre la différence entre Profile, Wallet et History ?

Profile est la section avec les données du compte et les points d’entrée vers les fonctions liées. Wallet sert à connecter et vérifier le portefeuille. History contient l’historique des opérations et des mouvements de solde.

### 14-8. Que faire si je ne vois pas le bouton ou la section nécessaire ?

Actualisez d’abord l’écran et vérifiez si une autre section n’est pas ouverte. Revenez ensuite à l’écran principal, à la barre supérieure ou à Profile, puis retournez à la fonction selon sa destination.

### 14-9. Que faire si les données à l’écran semblent dépassées ou ne correspondent pas à mes attentes ?

Actualisez d’abord l’écran, puis ouvrez la section de profil liée à cette information. Les soldes et mouvements se vérifient plus facilement dans History, les panneaux dans Panels, la génération dans Energy, les opérations de portefeuille dans Wallet et les actions de retrait dans Withdraw.

### 14-10. Comment savoir que la mauvaise section est ouverte ?

Choisissez la section selon l’action : Profile pour le compte, Wallet pour le portefeuille, Panels pour les panneaux, Energy pour la génération, Exchange pour l’échange, Withdraw pour les retraits, Tasks pour les tâches, Referrals pour les invitations et Hub pour la transition Recharger.

### 14-11. Quel ordre de vérification des écrans est pratique lors d’une entrée quotidienne normale dans la WebApp ?

Il est généralement pratique de regarder d’abord l’écran principal et la barre supérieure, puis d’ouvrir les sections liées à la tâche actuelle : Panels, Energy, History, Tasks, Referrals, Hub, Exchange ou Withdraw. Cet ordre aide à comprendre rapidement l’état actuel du compte et à passer à l’action nécessaire.

### 14-12. Quelles sections est-il utile de vérifier régulièrement même sans tâche urgente ?

Il est utile de vérifier régulièrement l’écran principal, la barre supérieure, Panels, Energy, History, Tasks, Referrals et Hub. Cela aide à voir à temps les changements de solde, l’activité des panneaux et les actions disponibles.

### 14-13. Pourquoi est-il important d’effectuer les actions dans leur section au lieu de les chercher partout ?

Cela réduit les erreurs et les actions accidentelles. Quand l’utilisateur fait l’échange dans Exchange, le retrait dans Withdraw et travaille avec les panneaux dans Panels, la logique de la WebApp reste claire et sûre.

### 14-14. Comment reconnaître qu’une action est importante et demande de l’attention ?

Une attention supplémentaire est nécessaire lorsqu’une action touche le solde, les panneaux, l’énergie, l’échange, le retrait, la liaison du portefeuille, l’historique des opérations ou le statut du compte. Avant de confirmer ces actions, il est utile de vérifier encore une fois l’écran et le bouton choisi.

### 14-15. Que faire si un écran a changé après une mise à jour du bot ?

Appuyez-vous sur les noms actuels des sections et leur destination. Les éléments visuels peuvent changer, mais la logique des écrans doit rester compréhensible et cohérente.

### 14-16. Quelles règles de base aident à éviter les erreurs dans la WebApp ?

Il est utile d’effectuer une action uniquement dans la section appropriée, de lire attentivement le nom de l’écran et le bouton avant confirmation, et en cas de doute de vérifier d’abord les sections de profil au lieu d’appuyer sur des éléments aléatoires de l’interface.

### 14-17. Dans quels cas faut-il ouvrir le FAQ pendant l’utilisation de la WebApp ?

Le FAQ est utile lorsqu’il faut clarifier rapidement le sens d’un écran, d’un bouton, d’une action ou d’une règle d’une fonction précise. Cela permet de relier tout de suite la question à la bonne section et d’éviter des étapes inutiles dans la WebApp.

## 15. Publicité

### 15-1. Qu’est-ce que cette section ?

La section Ads est une sous-section de Tasks. Elle montre les actions publicitaires disponibles par lesquelles l’utilisateur peut obtenir des monnaies bonus supplémentaires.

### 15-2. Que m’apporte-t-elle ?

Elle donne uniquement des monnaies bonus pour les vues, si la publicité est actuellement disponible pour le compte de l’utilisateur.

### 15-3. Pourquoi n’y a-t-il rien ici ?

Si la section est vide, cela signifie qu’il n’y a actuellement aucune offre active pour ce compte utilisateur ou que la publicité est temporairement désactivée.

### 15-4. Où se trouve la section Ads ?

La section Ads se trouve comme sous-section à l’intérieur de Tasks. C’est l’une des possibilités supplémentaires du bloc des tâches.

### 15-5. Quel type de récompense donne Ads ?

Ads donne uniquement des monnaies bonus pour les vues. Ce n’est ni le solde principal ni un retrait direct, mais une manière interne supplémentaire de renforcer le parcours de jeu.

### 15-6. Pourquoi Ads est-il utile ?

Parce que c’est une source supplémentaire de monnaies bonus. Il ne remplace ni les panels ni la génération, mais peut aider à renforcer plus rapidement le cycle de jeu interne.

### 15-7. Pourquoi d’autres ont-ils de la publicité et pas moi ?

Parce que les offres peuvent être indisponibles pour un compte donné ou que la publicité est temporairement désactivée. Un Ads vide ne signifie pas que le compte est cassé.

### 15-8. Que faire si j’ai effectué une action dans Ads, mais qu’il n’y a aucun résultat ?

Vérifiez : actualiser Tasks/Ads → vérifier le solde bonus → vérifier l’historique des opérations.

### 15-9. Pourquoi les utilisateurs peuvent-ils avoir des offres différentes dans Ads ?

Parce que les offres dépendent de la disponibilité des campagnes publicitaires pour un compte donné. C’est normal : l’un peut avoir des offres, l’autre pas pour le moment.

### 15-10. Faut-il activer quelque chose pour utiliser Ads ?

Non. Ads est un moyen d’obtenir des EFHC bonus et ne requiert aucun action interne obligatoire.

## 16. Ranks

### 16-1. Pourquoi la progression dans le classement est-elle importante pour moi ?

La progression dans le classement montre à quoi ressemble votre avancée par rapport aux autres participants. Cela aide à comprendre votre place actuelle et à voir à quel point le compte se développe activement.

### 16-2. Quelle est la différence entre le niveau et le classement ?

Le niveau montre votre progression personnelle à l’intérieur du système, tandis que le classement montre votre place parmi les autres participants.

### 16-3. Comment le niveau et le classement sont-ils liés ?

Ils sont liés par une même logique de croissance via la génération de kWh par les panels et la barre de progression générale sur la page Energy.

### 16-4. Le classement, ce n’est qu’un joli chiffre ?

Non. Le classement aide à comprendre à quoi ressemble votre parcours par rapport aux autres participants.

### 16-5. Qu’est-ce qui influence la progression de ma position dans le classement ?

La progression de votre position dans le classement dépend du progrès global du compte : développement des panels, génération de kWh et mouvement général sur le parcours énergétique du projet.

### 16-6. Peut-on progresser en même temps en niveau et en classement ?

Oui. Quand l’utilisateur développe ses panels, sa génération et sa progression énergétique globale, il renforce généralement à la fois son niveau et sa position dans le classement.

### 16-7. Pourquoi ai-je un niveau élevé, mais pas la première place au classement ?

Parce que le classement correspond à votre place parmi tous les participants, et pas seulement à votre progression personnelle. Les autres joueurs progressent aussi, donc votre position peut changer même avec un bon niveau.

### 16-8. Pourquoi mon classement peut-il bouger sans nouvelles actions de ma part ?

Parce que le classement n’existe pas isolément ; il évolue par comparaison avec tous les participants. Pendant que vous ne changez rien, les autres utilisateurs continuent de progresser, et cela influence votre position.

### 16-9. Où puis-je voir ma place dans le classement ?

Dans la section Ranks — votre position parmi les autres participants y est affichée.

### 16-10. Pourquoi mon classement peut-il baisser même quand je progresse ?

Parce que le classement dépend non seulement de votre propre progression, mais aussi de la vitesse de progression des autres participants. Même si votre compte se renforce, votre place peut baisser lorsque d’autres vous dépassent plus vite.

## 17. Statut Activ

### 17-1. Que signifie le statut Activ ?

Activ est un statut actif permanent. Il signifie que le jeu a vraiment commencé, parce qu’au moins un panel a été activé.

### 17-2. Comment obtenir Activ ?

Pour obtenir Activ, il suffit d’activer un panel. Après cet action interne, le statut est attribué de façon permanente.

### 17-3. Activ est-il temporaire ou permanent ?

Activ est un statut permanent.

### 17-4. Activ est-il conservé si un panel passe plus tard dans Archive ?

Oui. Même si un panel passe plus tard dans Archive, le statut Activ est conservé.

### 17-5. Pourquoi Activ est-il important ?

Activ aide à distinguer les vrais joueurs des inscriptions aléatoires, des bots et des fermes à bots. Il confirme la participation réelle de l’utilisateur au projet.

### 17-6. Activ peut-il disparaître plus tard ?

Non. Activ est un statut permanent et il reste même si le premier panel passe plus tard dans Archive.

### 17-7. Pourquoi Activ est-il nécessaire pour se protéger des bots et des fermes à bots ?

Parce qu’Activ confirme une participation réelle, et non un compte vide créé pour gonfler artificiellement les chiffres. Cela rend le système de parrainage et l’économie plus honnêtes.

### 17-8. Qu’est-ce qui change dans le compte après l’obtention d’Activ ?

Le compte est considéré comme confirmé comme participant réel du projet. Cela influence le fonctionnement honnête des parrainages et la confiance accordée à l’activité.

### 17-9. Pourquoi Activ apparaît-il précisément après le premier panel ?

Parce que l’activation du premier panel est un signe clair de participation réelle. Le projet utilise cette étape comme filtre contre les comptes vides.

### 17-10. Peut-on perdre Activ à cause de l’inactivité ?

Non. Activ est un statut permanent et ne disparaît pas à cause de l’inactivité.

## 18. VIP NFT

### 18-1. Qu’est-ce qu’un EFHC VIP NFT ?

EFHC VIP NFT est une carte de club, une clé vers tout le futur écosystème EFHC, un signe numérique d’appartenance et une clé vers les futures possibilités du projet.

### 18-2. Que donne la possession d’un EFHC VIP NFT ?

La possession d’un EFHC VIP NFT donne une génération renforcée pour tous les panels du joueur.

### 18-3. Quels signes montrent que VIP est déjà pris en compte ?

Si le VIP NFT est déjà pris en compte par le système, l’interface affiche le statut VIP et les avantages liés au compte deviennent visibles.

### 18-4. Où verrai-je l’effet VIP ?

L’effet VIP est visible dans les sections où le projet prend en compte les avantages du VIP NFT, ainsi que dans la barre supérieure et dans Profil / Paramètres.

### 18-5. Faut-il activer le VIP manuellement ?

Non. La logique du projet est conçue pour vérifier automatiquement le wallet et mettre à jour automatiquement le statut VIP après la détection du NFT dans la collection requise.

### 18-6. Est-ce que 2 ou 3 VIP NFT donnent des privilèges supplémentaires au joueur ?

Non. Pour le joueur, posséder 2 ou 3 VIP NFT ne donne pas de privilèges supplémentaires au-delà d’un seul VIP NFT.

### 18-7. Pourquoi un deuxième VIP NFT ne renforce-t-il pas l’effet ?

Dans le projet, le VIP donne un bonus de génération comme un seul statut actif. Des VIP NFT supplémentaires ne donnent pas de bonus supplémentaire afin que l’effet ne s’emballe pas à l’infini.

### 18-8. Le VIP agit-il sur un seul panel ou sur tous ?

Le VIP agit sur la génération de tous les panels de l’utilisateur, et non sur un seul panel.

### 18-9. Comment vérifier que VIP influence réellement le compte ?

Vérifiez non seulement la présence du statut VIP, mais aussi les avantages associés dans la mécanique du compte, surtout là où l’effet VIP est pris en compte, y compris la génération.

### 18-10. Faut-il connecter le wallet pour que le bot voie mon VIP NFT ?

Oui. Pour que le bot voie le VIP NFT, il doit comprendre quel wallet appartient au compte. Le Wallet doit donc être connecté, puis vous vérifiez le statut VIP dans l’interface.

### 18-11. Puis-je disposer librement de mon VIP NFT ?

Oui. L’EFHC VIP NFT peut être transféré, offert et vendu sur les marketplaces.

### 18-12. Si je vends ou transfère mon VIP NFT vers un autre portefeuille, qu’arrivera-t-il à ma génération ?

Le bot scanne régulièrement la blockchain et vérifie la présence du NFT sur votre portefeuille lié. Si vous vendez, offrez ou déplacez votre VIP NFT vers une autre adresse, le système le détectera, désactivera votre statut VIP et la génération de tous vos panneaux reviendra automatiquement au taux de base.

## 19. Niveaux

### 19-1. Pourquoi devrais-je augmenter mon niveau ?

La progression du niveau montre l’avancement de l’utilisateur dans le projet et aide à voir comment le compte se développe. C’est un indicateur visuel et concret du mouvement vers l’avant.

### 19-2. Que comprend la section Niveaux ?

La section Niveaux montre toutes les échelles de progression du projet : 12 niveaux de progression énergétique, 6 niveaux du système de parrainage et d’autres lignes de progression du projet si elles sont ajoutées plus tard.

### 19-3. Combien y a-t-il de niveaux de progression énergétique dans le projet ?

Le projet prévoit 12 niveaux de progression énergétique.

### 19-4. Combien y a-t-il de niveaux dans le système de parrainage ?

Le projet prévoit 6 niveaux dans le système de parrainage : de 0 à 5.

### 19-5. En quoi les niveaux sont-ils utiles pour un joueur ordinaire ?

Les niveaux aident à comprendre où vous en êtes, ce qui a déjà été accompli, vers quoi avancer ensuite et quel prochain palier vous attend.

### 19-6. Comment les niveaux d’énergie, les niveaux de parrainage et la croissance globale du compte sont-ils liés ?

Ce sont des parties d’un même parcours global. La génération d’énergie fait avancer la progression principale, les filleuls actifs renforcent la ligne de parrainage, et ensemble ils montrent à quel point le compte se développe.

### 19-7. Eco Initiate (0 kWh)

**Sens pour le joueur :** Votre premier panel est installé et prêt à fonctionner. Vous faites le pas principal pour devenir un producteur indépendant d’énergie propre. C’est votre statut de départ — vous entrez seulement dans le parcours de génération.

**Règle exacte :** Le niveau Eco Initiate correspond au seuil de 0 kWh.

**Conséquence pratique :** L’étape suivante consiste à lancer la croissance de la génération grâce aux panels et à amener la progression à 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Sens pour le joueur :** Les premiers kilowatts sont là ! Vos panels génèrent avec succès de l’énergie verte, donnant à la nature l’espoir d’un avenir sans carbone. Vous voyez déjà les premiers résultats réels : l’énergie est lancée et la progression a bougé.

**Règle exacte :** Le niveau Hope Bringer commence à 100 kWh.

**Conséquence pratique :** L’objectif suivant est d’augmenter la stabilité et d’atteindre 300 kWh pour l’étape suivante.

### 19-9. Energy Seeker (300 kWh)

**Sens pour le joueur :** Le système fonctionne très bien, en alimentant de manière stable le réseau en électricité écologique. Chaque unité d’énergie produite par les panels remplace les combustibles fossiles. Le compte est entré en phase de croissance durable : vous n’êtes plus un « nouveau », mais un utilisateur avec une génération réelle.

**Règle exacte :** Le niveau Energy Seeker commence à 300 kWh.

**Conséquence pratique :** En pratique, c’est un signal : vous pouvez renforcer les panels et utiliser plus souvent Exchange pour transformer l’énergie en solde principal.

### 19-10. Nature's Voice (600 kWh)

**Sens pour le joueur :** Votre contribution devient visible. En générant de l’énergie à l’aide de technologies vertes, vous devenez la voix de la nature, en prouvant que le progrès peut être écologique. Votre contribution devient plus visible : la progression n’est plus perçue comme un hasard, mais comme une trajectoire.

**Règle exacte :** Le niveau Nature's Voice commence à 600 kWh.

**Conséquence pratique :** Le prochain repère est 1000 kWh (Earth Ally). Il est utile de vérifier le rythme dans Energy et le nombre de panels actifs.

### 19-11. Earth Ally (1000 kWh)

**Sens pour le joueur :** Le premier mégawattheure a été généré ! Vos panels ont produit un volume impressionnant d’énergie propre. Vous êtes maintenant un acteur important de la transition verte et un allié fidèle de la planète. Vous avez franchi un cap important : 1000 kWh, c’est déjà un volume sérieux de génération accumulée.

**Règle exacte :** Le niveau Earth Ally commence à 1000 kWh.

**Conséquence pratique :** En pratique, c’est le point où la croissance devient prévisible : renforcez votre parc de panels et maintenez un échange d’énergie régulier.

### 19-12. Climate Fighter (2000 kWh)

**Sens pour le joueur :** Votre génération porte un coup réel au changement climatique. Chaque kilowatt produit réduit directement le besoin de brûler du charbon et du gaz. Vous exercez déjà une pression systémique par votre croissance : la progression se voit à la fois sur le niveau et sur la dynamique générale du compte.

**Règle exacte :** Le niveau Climate Fighter commence à 2000 kWh.

**Conséquence pratique :** L’étape suivante consiste à consolider le rythme et à atteindre 3500 kWh. Surveillez la vitesse de génération et utilisez le VIP si nécessaire.

### 19-13. Green Sentinel (3500 kWh)

**Sens pour le joueur :** Le flux stable d’énergie provenant de vos panels veille sur un air propre. Vous apportez un bénéfice tangible à la société sans laisser d’empreinte carbone. Votre compte devient le « gardien » d’une génération stable : la progression avance avec assurance.

**Règle exacte :** Le niveau Green Sentinel commence à 3500 kWh.

**Conséquence pratique :** En pratique, cela signifie que les panels fonctionnent déjà comme un système — maintenez les panels actifs et planifiez la croissance jusqu’à 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Sens pour le joueur :** 5000 kWh de génération propre ! La puissance de vos panels agit comme un bouclier invisible, protégeant l’atmosphère contre des milliers de kilogrammes d’émissions de gaz à effet de serre. 5000 kWh est un grand signe d’ampleur : vous êtes déjà dans la zone des participants les plus forts en énergie.

**Règle exacte :** Le niveau Planet Defender commence à 5000 kWh.

**Conséquence pratique :** Le prochain repère est 7500 kWh. Souvent, à ce stade, les joueurs renforcent à la fois leurs panels et leur réseau de parrainage.

### 19-15. Eco Champion (7500 kWh)

**Sens pour le joueur :** Des volumes de production remarquables ! Vous êtes un véritable champion de l’énergie verte, dont la contribution modifie sensiblement l’équilibre énergétique mondial dans le bon sens. C’est le niveau de ceux qui maintiennent durablement un rythme de génération élevé.

**Règle exacte :** Le niveau Eco Champion commence à 7500 kWh.

**Conséquence pratique :** En pratique : gardez la discipline — panels actifs, Exchange régulier, contrôle de l’historique et des soldes.

### 19-16. Planet Saver (10000 kWh)

**Sens pour le joueur :** 10 mégawattheures ! Vous avez généré tant d’énergie propre que vous sauvez littéralement des écosystèmes entiers, en démontrant l’efficacité maximale de vos panels. 10 000 kWh, c’est déjà « dix mégawattheures » de génération, une étape très forte de progression.

**Règle exacte :** Le niveau Planet Saver commence à 10000 kWh.

**Conséquence pratique :** L’étape suivante est 15000 kWh. À ce stade, il est logique d’optimiser tout : panels, VIP, parrainages, action internes.

### 19-17. Green Commander (15000 kWh)

**Sens pour le joueur :** Vaisseau amiral de la génération écologique. Vos panels alimentent l’avenir, et des volumes de production impressionnants fixent de nouveaux standards élevés pour toute la communauté. Vous êtes proche du sommet : c’est un niveau de leadership sur le plan énergétique.

**Règle exacte :** Le niveau Green Commander commence à 15000 kWh.

**Conséquence pratique :** En pratique : gardez la stabilité et montez vers 20000+ kWh, en surveillant les panels actifs et le rythme dans Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Signification pour le joueur :** Le sommet de l’évolution. En générant plus de 20 MWh d’énergie totalement propre, tu es devenu un véritable Guardian of Earth. Tes panels puisent leur force dans la nature elle-même pour alimenter ce monde et le préserver pour les générations futures. C’est le sommet de l’échelle : tu as atteint le plus haut niveau de progression reconnu.

**Règle exacte :** Le niveau Guardian of Earth correspond à 20000+ kWh.

**Effet pratique :** En pratique, tu as sécurisé le statut le plus élevé. À partir de là, l’objectif est de maintenir le système, développer les panels et renforcer la participation à l’écosystème grâce aux panels, au VIP et à la croissance des parrainages.

### 19-19. Niveau de parrainage 0

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 0 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-20. Niveau de parrainage 1

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 1 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-21. Niveau de parrainage 2

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 10 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-22. Niveau de parrainage 3

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 100 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-23. Niveau de parrainage 4

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 300 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-24. Niveau de parrainage 5

**Sens pour le joueur :** C’est le marqueur de votre progression dans le système de parrainage — il montre l’ampleur des utilisateurs invités actifs.

**Règle exacte :** Un bonus unique est crédité à l’atteinte du niveau : 1000 EFHCb.

**Conséquence pratique :** En pratique : après avoir atteint le niveau, vérifiez le solde bonus et l’historique des opérations pour voir le crédit.

### 19-25. Comment comprendre la progression des niveaux sans erreur ?

**Signification pour le joueur :** Ce bloc aide à évaluer la progression avec lucidité et à regarder les niveaux à travers la génération réelle d’énergie.

**Règle exacte :** Les niveaux sont déterminés par la génération accumulée en kWh. Plus la génération totale est élevée, plus ton niveau est haut.

**Effet pratique :** En pratique, concentre-toi sur la croissance de l’énergie, le nombre de panels actifs et le rythme global de génération. C’est ce qui donne une vraie progression de niveau.

### 19-26. Pourquoi les noms des niveaux sont-ils liés à l’écologie et à la planète ?

Parce que l’idée même du jeu est liée à l’énergie verte virtuelle, à la motivation des personnes et à une contribution symbolique à la restauration de la planète Terre.

## 20. FAQ / Aide

### 20-1. Où ouvrir la FAQ ?

La FAQ s’ouvre depuis le profil comme section d’aide intégrée du bot, où sont rassemblées les réponses sur les actions principales, les écrans et les règles du projet.

### 20-2. À quoi sert la FAQ / Aide ?

Cette section sert à permettre à l’utilisateur de trouver rapidement des réponses claires, des chiffres exacts, les règles réelles du projet et le sens des actions principales, sans suppositions ni confusion.

### 20-3. Pourquoi la FAQ est-elle décrite de façon si détaillée ?

Parce que le projet est multicouche et qu’une aide courte et sèche ne couvre pas les vraies questions du joueur. Ici, le sens, la clarté, les chiffres exacts et les conséquences réelles des actions sont importants.

### 20-4. Peut-on comprendre tout le parcours du joueur dans le bot grâce à la FAQ ?

Oui. Une bonne FAQ doit expliquer non seulement des boutons séparés, mais aussi tout le parcours : du premier panel à l’énergie, à l’échange, aux soldes, aux niveaux, aux statuts et à la croissance du compte.

### 20-5. Que faire si je n’ai pas trouvé la réponse du premier coup ?

Il vaut mieux ouvrir une section proche par le sens et regarder les questions voisines. Dans un grand bot, beaucoup de réponses sont liées entre elles, et un bloc aide souvent à comprendre le suivant.

### 20-6. Comment utiliser correctement le FAQ ?

Le mieux est d’avancer section par section : comprendre d’abord la logique générale du projet, puis tes écrans et actions, et seulement ensuite consulter les règles précises sur les soldes, retraits, VIP, parrainages, niveaux et autres fonctions du bot.

### 20-7. Que vérifier si « tout semble cassé » ?

Vérifiez trois choses : 1) Wallet — le wallet est-il connecté et le principal est-il sélectionné, 2) les soldes et l’historique — y a-t-il la trace de votre opération, 3) la section concernée (Panels / Energy / Exchange / Withdraw). En général, la réponse se trouve dans l’un de ces endroits.

### 20-8. Quel est le moyen le plus rapide de comprendre ce qui est arrivé à mes EFHC ?

Ouvrez l’historique des soldes. L’historique montre exactement ce qui a modifié les soldes : récompense, action interne, échange ou retrait.

### 20-9. Par quoi commencer si j’ouvre le bot pour la première fois et que je ne comprends rien ?

Commencez par Energy (l’écran principal), puis ouvrez Panels, regardez les soldes et l’historique, et seulement ensuite décidez si vous avez besoin d’un wallet et d’un rechargement.

### 20-10. Comment trouver le plus vite possible la bonne question dans la FAQ ?

Le moyen le plus rapide est d’ouvrir la section correspondant au sujet (Wallet / Panels / Exchange / Withdraw, etc.) et de chercher la question là. Si vous n’êtes pas sûr, commencez par la section FAQ / Aide et repérez-vous grâce aux mots-clés.
