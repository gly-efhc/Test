# EFHC FAQ (TR)

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. Proje Hakkında

### 1-1. EFHC nedir?

EFHC, bot içindeki enerji, ilerleme ve hesap gelişimi üzerine kurulu bir oyun projesidir. Kullanıcı paneller aktive alır, enerji biriktirir, bunu EFHC'ye dönüştürür, bakiyelerini takip eder, seviyelerde yükselir, sıralamada ilerler ve projenin ek olanaklarını kullanır.

Açılımı:
— EFHC — Energy for Humanity Coin
— EFHCm — ana coin'ler
— EFHCb — bonus coin'ler
— EFHCj — harici EFHC jettonu
— EFHC — toplam bakiye (bonus + ana)

### 1-2. Burada her şey nasıl çalışıyor?

Projenin içinde her şey enerji ve hesabın büyümesi etrafında kuruludur. Kullanıcı panellerle çalışır, enerji biriktirir, bunu ana EFHC'ye dönüştürür, bakiyeleri takip eder, cüzdan bağlar, ilerlemesini güçlendirir ve projenin ek mekaniklerini kullanır.

### 1-3. Bu botta benim ne yapmam gerekiyor?

Temel görev, hesabınızı geliştirmektir. Bunun için panellerle çalışır, enerji üretimini takip eder, Exchange'i kullanır, bakiyelerinizi inceler, cüzdan bağlar, projenin ek mekaniklerine katılır ve ilerlemenizi adım adım güçlendirirsiniz.

### 1-4. Burada nasıl büyür ve ilerlerim?

Bot içindeki büyüme enerji ve aktivite etrafında kuruludur. Kullanıcının ne kadar çok paneli, enerjisi, faydalı aksiyonu ve ilerlemesi varsa, hesabı o kadar güçlü gelişir ve seviye ile rank sisteminde o kadar yukarı çıkar.

### 1-5. Projenin ana fikri nedir?

Projenin ana fikri, panel etkinleştirmeden enerji üretimine, oradan da EFHC sonucuna giden yolu göstermektir. Kullanıcı soyut rakamlar değil, birbirine bağlı bir yol görür: panel, enerji, değişim, bakiye, ilerleme, seviyeler ve diğer katılımcılar arasındaki yeri.

### 1-6. Bu sadece eğlence mi, yoksa burada bir gelişim mantığı da var mı?

Burada tam anlamıyla bir büyüme mantığı vardır. Kullanıcı sadece düğmelere basmaz; hesabını adım adım güçlendirir: panel alır, üretimi başlatır, aktif statü kazanır, ödüller toplar, referans sistemini geliştirir ve kendi yolculuğunun sonucunu görür.

### 1-7. İlk EFHC'lerim burada nasıl oluşuyor?

İlk EFHC iki ana kaynaktan gelir: ödüller (bonus coin EFHCb olarak) ve Exchange üzerinden enerji değişimi (ana coin EFHCm olarak). En güçlü yol şudur: paneller → enerji → değişim → ana bakiye.

### 1-8. Enerjim nereden geliyor?

Enerjiyi aktif panelleriniz sağlar. Paneller aktif olduğu sürece enerji üretirler ve bu enerji, değişim için kullanılabilir enerji olarak birikir.

### 1-9. Projede büyümemi en çok ne etkiler?

Büyümeyi en çok etkileyen şey, aktif panel sayısı ve onların toplam üretimidir. İkinci güçlendirici VIP'dir (eğer varsa), çünkü üretimi etkiler. Görevler, reklam ve referanslar faydalı eklerdir, ama temel değildir.

### 1-10. Doğru yönde ilerlediğimi nasıl anlarım?

Üç şey büyüyorsa doğru ilerliyorsunuz demektir: üretim, kullanılabilir enerji ve değişimden sonra ana bakiye. Bunu en hızlı şekilde Energy bölümü ve işlem geçmişi üzerinden kontrol edebilirsiniz.

## 2. Ana Ekran

### 2-1. Ana ekran neyi gösterir?

Ana ekran, Energy sayfasıdır. Hesabın mevcut durumuna ait temel unsurları bir araya getirir: hızlı aksiyonlar, ilerleme bilgileri ve botun önemli bölümlerine giriş noktaları.

### 2-2. Ana ekran neden gereklidir?

Kullanıcının hesabıyla ilgili en önemli şeyleri hemen görmesi ve mevcut durumu, ilerlemeyi ve bundan sonra ne yapılabileceğini hızlıca anlaması için gereklidir.

### 2-3. İlk olarak neye bakmalıyım?

Önce üst çubuğa, toplam bakiyeye, Energy ekranına ve kullanılabilir aksiyonlara bakmak gerekir. Bunlar hesabın mevcut durumunu ve sonrasında neler yapılabileceğini en hızlı şekilde gösterir.

### 2-4. Mevcut ilerlemem nerede görünür?

Mevcut ilerleme, enerji, paneller, seviyeler ve sıralama ile bağlantılı bot bölümlerinde görünür. Kullanıcının proje içinde nasıl ilerlediği buradan anlaşılır.

### 2-5. Ana ekran neden her gün önemlidir?

Çünkü hesabın nasıl değiştiği en hızlı burada görülür: şu anda ne kadar enerji olduğu, kaç aktif panel bulunduğu, ilerlemenin nasıl arttığı ve kullanıcının bir sonraki adıma ne kadar hazır olduğu.

### 2-6. Nereden başlamak daha iyi olur?

Önce üst çubuğa bakıp bakiyelerinizi anlamak, ardından Energy sayfasını açmak, Panels bölümüne bakmak ve sonra temel aksiyonlarla ilgili FAQ'yu incelemek daha doğrudur. Gerekli aksiyon için cüzdan gerekiyorsa, sonraki adım onu bağlamak olur.

### 2-7. Ana ekrandaki en önemli düğmeler hangileridir?

Ana işlemler Panels, Exchange, üst çubuktaki Doğrudan Yükleme ve Hub’dır. Hub yalnızca Yükle düğmesini gösterir.

### 2-8. Ana ekranda her gün neyi kontrol etmeliyim?

Üç şeyi: 1) kaç aktif paneliniz var, 2) üretim hızı nedir, 3) değişim için ne kadar kullanılabilir enerji birikmiş durumda.

### 2-9. Ana ekran neden zamanla değişiyor?

Çünkü hesap durumunun canlı yansımasıdır. Paneller, enerji ve işlemler ortaya çıktıkça ekran boş olmaktan çıkar ve daha fazla faydalı veri ile ilerleme göstermeye başlar.

### 2-10. Ana ekrana bakarak hesabın geliştiğini nasıl anlayabilirim?

Gerçek göstergelerde büyüme gördüğünüzde: üretim sıfır değildir, enerji birikir ve değişimden sonra ana bakiye artar. Bunlar gelişimin en dürüst işaretleridir.

## 3. Üst Panel

### 3-1. Üst panel nedir?

Üst panel, arayüzün ayrı bir unsurudur ve botun ana sayfalarında bulunan temel hızlı bilgi bloğudur.

### 3-2. Üst çubukta ne gösterilir?

Üst çubukta avatar, ad, enerji ilerleme seviyesi, VIP durumu, toplam bakiye, Top Up düğmesi ve Hub düğmesi gösterilir.

### 3-3. Üst panel neden önemlidir?

Çünkü gereksiz geçişler yapmadan hesabınızla ilgili en önemli şeyleri hemen görmenizi sağlar: kim olduğunuz, ilerlemeniz, VIP durumunuz, toplam kaç coin'iniz olduğu ve şu anda hangi hızlı işlemlerin açık olduğu.

### 3-4. Üst paneldeki toplam bakiye neyi gösterir?

Toplam bakiye, coin'lerin toplam sayısını gösterir. Bu, iç eylemlar için kaynakları elle toplamak zorunda kalmamanız ve oyundaki genel durumu hızlıca anlamanız için gerekir.

### 3-5. Toplam bakiye neden alışveriş için kullanışlıdır?

Çünkü oyuncunun oyun içindeki genel iç eylem gücünü gösterir ve iç işlemler için kaynağın yeterli olup olmadığını hızlıca anlamaya yardımcı olur.

### 3-6. Toplam bakiye neden şu anda doğrudan çekilebilecek tutarla aynı değildir?

Çünkü toplam bakiye hem ana coin'leri hem de bonus coin'leri içerir. Bonus coin'ler oyun içi süreç için gereklidir ve doğrudan çekilemez.

### 3-7. Üst paneldeki “Yatır” düğmesini ne zaman kullanmak gerekir?

Uygulamada bulunan ana bakiye yükleme akışına, ek bölümleri elle açmadan hızlıca geçmek istediğinizde bu düğmeyi kullanın.

### 3-8. Hub’ı üst çubuktan neden açmalıyım?

Projenin bağlantılı eylem kartlarını hızlıca açmak ve arayüz içinde gereksiz dolaşmadan gerekli dış akışa geçmek için.

### 3-9. Üst panel neden farklı sayfalarda görünür?

Çünkü bu, hesabın “gösterge panelidir”: başka bir bölümü açmış olsanız bile temel bilgileri (bakiye, durumlar ve hızlı işlemler) her zaman görmeniz gerekir.

### 3-10. Üst paneldeki veriler yanlış görünüyorsa ne yapmalıyım?

Önce sayfayı yenileyin ve bakiye geçmişini kontrol edin: işlem gerçeklerini o gösterir. Geçmiş ile bakiye uyuşuyorsa veriler doğrudur; muhtemelen yanlış bakiyeye bakmışsınızdır (örneğin ana bakiye yerine toplam bakiye).

## 4. Profil

### 4-1. Profil/Ayarlar bölümü nedir?

Profil/Ayarlar, profilin ve bot parametrelerinin yönetildiği bölümdür. Burada ana durumlar görünür ve kişisel arayüz ayarları kullanılabilir.

### 4-2. Profilden neler yapılabilir?

Profilde temel kullanıcı ayarları ve önemli bölümlere hızlı geçişler toplanır: Wallet, bakiye geçmişi, FAQ ve diğer yararlı yönetim noktaları.

### 4-3. Profil/Ayarlar bölümünün üst kısmında ne gösterilir?

Profil/Ayarlar bölümünün üst kısmında avatar, Telegram adı ve varsa Activ ile VIP durumları gösterilir.

### 4-4. Dil nereden değiştirilir?

Dil, Profil/Ayarlar bölümünden değiştirilir.

### 4-5. Profil neden gereklidir?

Profil, hesap için kişisel bir kontrol noktasıdır. Kullanıcı burada yalnızca durumları görmez; cüzdan, geçmiş, dil ve yardım ile ilgili önemli alt bölümleri de açar.

### 4-6. Profilden bakiye geçmişi nereden açılır?

Profil/Ayarlar bölümünde, girişler ve çıkışların görüldüğü bakiye geçmişine ayrı bir giriş vardır.

### 4-7. Profilden dil nereden değiştirilir?

Dil değiştirme seçeneği Profil/Ayarlar bölümündedir, çünkü bu hesapla ilgili kişisel bir ayardır.

### 4-8. Profil içinde cüzdanla çalışmak için Wallet nereden açılır?

Profil bölümünde ayrı bir Wallet girişi vardır. Cüzdan bağlamak, bağlantıyı kontrol etmek veya cüzdanla ilgili işlemlere geçmek gerektiğinde onu açın.

### 4-9. Bir cevaba ihtiyacım olduğunda Profil içinde FAQ hızlıca nereden açılır?

Profil bölümünde FAQ girişi vardır. Arayüz, balance, panels, energy, exchange, withdrawal veya diğer WebApp işlevleri hakkında hızlı bir cevap gerektiğinde onu açın.

### 4-10. “Destek ve bilgi” bölümünde ne bulunur?

Burada yardım öğeleri toplanır: FAQ, ipuçları/bilgiler ve kullanıcının projeyi karışıklık yaşamadan anlamasına yardımcı olan her şey.

### 4-11. Proje arayüzü kaç dilde kullanılabilir?

Bot arayüzü ve yardım sistemi (FAQ) 13 dile çevrilmiştir. Profil ayarlarından sizin için uygun dili seçebilirsiniz; sistem tüm metinleri ve arayüzü seçiminize anında uyarlar.

## 5. Wallet

### 5-1. Ana cüzdan ne için gereklidir?

Ana cüzdan, projenin dış işlemleriyle bağlantılı eylemler için kullanılır: çekim, bakiye yükleme, adres sahipliğini doğrulama ve bağlı cüzdan gerektiren diğer ilişkili işlemler.

### 5-2. Ana cüzdan değiştirilebilir mi?

Evet. Kullanıcı, daha önce bağlanmış cüzdanlar arasından başka bir ana cüzdan seçebilir.

### 5-3. Bağlı bir cüzdan silinebilir mi?

Evet. Cüzdana artık ihtiyaç yoksa bağlantısı kaldırılabilir.

### 5-4. Aynı cüzdan neden iki hesaba bağlanamaz?

Aynı cüzdan aynı anda iki farklı hesapta kullanılmamalıdır. Bir cüzdan zaten bir hesaba bağlıysa, başka bir hesaba bağlanmadan önce ilk hesaptan ayrılmalıdır. Bu, cüzdanla ilgili durumlarda, kontrollerde ve sonuçlarda karışıklığı önler.

### 5-5. Cüzdan gereken bir işleme basarsam ama cüzdanım yoksa ne olur?

Seçilen işlev için cüzdan gerekiyorsa bot önce cüzdan bağlama mantığını başlatır. Bundan sonra gerekli işleme geri dönüp onu normal şekilde tamamlayabilirsiniz.

### 5-6. Birden fazla cüzdan bağlanabilir mi ve bu neden gerekir?

Evet. Yedek bir adresiniz olması veya farklı kullanım senaryolarını ayırmanız için birden fazla cüzdan bağlayabilirsiniz. Bununla birlikte bir cüzdan ana cüzdan olarak seçilir — seçilmiş adresin gerektiği işlemlerde varsayılan olarak o kullanılır.

### 5-7. Cüzdanımı başka bir hesapta kullanmak istersem ne yapmalıyım?

Önce bu cüzdanın mevcut hesaptan bağlantısını kaldırmak gerekir. Ancak bundan sonra başka bir hesaba bağlanabilir. Aynı cüzdan aynı anda iki hesaba bağlı olmamalıdır.

### 5-8. Ana olmayan cüzdana çekim yapılabilir mi?

Varsayılan olarak sistem ana cüzdana göre çalışır. Başka bir adrese ihtiyacınız varsa önce onu Wallet içinde ana cüzdan yapın, ardından çekim talebi oluşturun.

### 5-9. Cüzdan bağlıysa ama çekim yine de kullanılamıyorsa ne yapmalıyım?

Üç şeyi kontrol edin: ana cüzdan seçilmiş mi, ana bakiye yeterli mi ve çekim tutarı 10 EFHC'nin altında değil mi.

### 5-10. Hesabıma şu anda hangi cüzdanın bağlı olduğunu nereden kontrol edebilirim?

Bunu Wallet bölümünde kontrol etmek gerekir. Kullanıcı, hesaba hangi cüzdanların bağlı olduğunu ve hesap içinde hangisinin kullanıldığını orada görür.

### 5-11. Ana TON cüzdanıma erişimi kaybedersem ne yapmalıyım?

Proje birden fazla cüzdan bağlamaya izin verdiği için Wallet bölümünden yeni bir cüzdan bağlayabilir, onu ana cüzdan yapabilir ve eski tehlikeye girmiş adresi bağlı cüzdanlar listesinden kalıcı olarak silebilirsiniz.

## 6. Bakiyeler ve Geçmiş

### 6-1. Neden üç farklı bakiyem var?

Çünkü bot içinde fonların farklı rolleri vardır. Toplam bakiye her şeyi birlikte gösterir, bonus bakiye iç oyun döngüsü için gerekir, ana bakiye ise artık temel işlemler ve çekim için kullanılabilecek sonucu gösterir.

### 6-2. Bonus bakiyesi nedir?

Bonus bakiyesi dahili bir oyun bakiyesidir. Bot içindeki gelişim için kullanılır; görevler, referanslar, hediyeler ve diğer dahili proje mekanikleriyle kredilendirilir, ancak doğrudan çekilmez.

### 6-3. Ana bakiye nedir?

Ana bakiye, ana EFHC bakiyesidir. Oyun döngüsünün sonucu tam olarak buna dönüşür ve çekim dahil temel işlemler de bu bakiyeden yapılır.

### 6-4. Neden tek bir iç eylem hem bonusu hem de ana bakiyeyi etkileyebilir?

Projede yapılan tüm iç harcamalarda tutar önce bonus bakiyeden düşülür. Bu yeterli olmazsa kalan kısım ana bakiyeden düşülür.

### 6-5. Neden geçmişte hemen birkaç kayıt görünüyor?

Tek bir işlem, fon hareketinin birkaç kısmını etkileyebilir. Bu yüzden bot, farklı değişiklikleri ayrı ayrı göstermek için bunu birkaç satır halinde gösterir.

### 6-6. EFHC’nin nereye geldiğini veya nereden çıktığını nerede görebilirim?

Bunun için bakiye geçmişi bölümü gerekir. Bu bölüm girişleri, çıkışları, takası, iç eylemları, çekimi ve fonlardaki diğer değişiklikleri gösterir.

### 6-7. Neden toplam bakiyem büyük görünüyor ama çekebildiğim miktar daha az?

Çünkü toplam bakiye ana ve bonus bakiyenin toplamıdır. Çekim yalnızca ana bakiyeden yapılabilir; bonus bakiye ise projenin iç döngüsü için tasarlanmıştır. Bu yüzden çekim için özellikle ana bakiyeye bakmanız gerekir.

### 6-8. Bakiyemi tam olarak hangi işlemin değiştirdiğini en hızlı nerede görebilirim?

Bakiye geçmişinde. Orada hangi işlemin giriş veya çıkış oluşturduğunu ve hangi bakiyenin etkilendiğini görebilirsiniz.

### 6-9. Bonus bakiyeyi neden doğrudan çekemiyorum?

Çünkü bonus coin’ler projenin iç döngüsünün bir parçasıdır. Çekime yalnızca ana bakiyeden izin verilir.

### 6-10. Çekim veya takastan sonra geçmiş neden her yerde aynı anda hemen değişmiyor?

Çünkü farklı ekranlar her zaman aynı anda güncellenmez. Şunu kontrol edin: bölümü yenile → bakiyeyi kontrol et → geçmişi kontrol et.

### 6-11. İnternet zayıfken iç eylem veya takas düğmesine yanlışlıkla art arda birkaç kez basarsam ne olur? Fazladan coin düşer mi?

Hayır. Fazladan coin düşmez. Sistem çekirdeğinde çift düşüm işlemlerine karşı sert koruma vardır. Ağ donduğu için düğmeye 10 kez bassanız bile işlem garantili olarak yalnızca bir kez gerçekleşir.

## 7. Panels

### 7-1. Bir paneli etkinleştirmek için kaç EFHC gerekir?

Bir paneli etkinleştirmek için 100 EFHC gerekir.

### 7-2. İlk paneli etkinleştirmek bana hemen ne kazandırır?

İlk panelin etkinleştirilmesi enerji üretimini hemen başlatır, ilerlemeye giden yolu açar, ana EFHC’ye giden yolu oluşturur ve kalıcı Activ statüsü verir.

### 7-3. Panel üretimi ne zaman başlar?

Üretim, panel etkinleştirildikten hemen sonra başlar.

### 7-4. Bir panelin ömrü ne kadardır?

Her panelin 180 günlük bir panel döngüsü vardır.

### 7-5. 180 günlük döngü bittiğinde panele ne olur?

180 günlük döngü tamamlandıktan sonra panel devre dışı kalır ve katılımcının enerji ilerlemesinin hafızası olarak Archive bölümüne gider.

### 7-6. Arayüzde panellerin hangi iki durumu vardır?

Arayüzde Activ ve Archive vardır. Activ, üretime katılan panellerdir. Archive ise aktif döngüsünü tamamlamış ve yolun geçmişini saklayan panellerdir.

### 7-7. Aynı anda birden fazla panel aktive edebilir miyim?

Evet. Panelleri art arda etkinleştirerek aktif panel sayınızı artırabilirsiniz. Ne kadar çok aktif panel varsa toplam enerji üretimi o kadar yüksek olur ve ilerlemeniz o kadar hızlı büyür.

### 7-8. Paneldeki “Kalan” zamanlayıcısı neyi gösterir?

Zamanlayıcı, panelin 180 günlük döngüsünün sonuna ne kadar süre kaldığını gösterir. Süre bitince panel otomatik olarak Archive bölümüne geçer ve aktif olmaktan çıkar.

### 7-9. İlk paneli aldıktan sonra neden Activ oldum?

Çünkü Activ, gerçek katılımın bir teyididir ve projeyi botlardan korur. Proje, bu statüyü ilk panel etkinleştirmesine bağlar; böylece statü yalnızca gerçek katılımcılara verilir.

### 7-10. Aktif paneller neden arşivdekilerden daha önemlidir?

Aktif paneller şu anda enerji üretir; mevcut büyüme hızınızı belirleyen asıl unsur onlardır. Arşiv panelleri ise tamamlanmış panellerdir; geçmişi saklarlar ama mevcut üretimi vermezler.

### 7-11. Neden etkinleştirdiğim panel sayısından daha az aktif panelim var?

Çünkü panellerin bir kısmı 180 günlük süresini tamamlayıp Archive bölümüne geçmiş olabilir. Aktif paneller şu anda çalışanlardır. Archive tamamlanmış panellerdir ve artık mevcut üretimi vermezler.

### 7-12. 1000 limiti yüzünden aktif paneller “kaybolabilir” mi?

Hayır. 1000 limiti, aynı anda 1000’den fazla aktif panele sahip olamayacağınız anlamına gelir. Aktive alınmış aktif paneller “kaybolmaz”: sürelerinin sonuna kadar aktif kalırlar ve sonra Archive bölümüne geçerler.

### 7-13. Panel aldım ama üretim hemen değişmedi; ne yapmalıyım?

Şunu kontrol edin:
— Panels bölümünü yenileyin
— Panelin Active listesinde görünüp görünmediğine bakın
— Energy bölümünü açıp üretim hızını kontrol edin
— Bakiye geçmişini kontrol edin (100 EFHC düşümü görünmelidir)

### 7-14. 100 EFHC’den az param varsa panel etkinleştirebilir miyim?

Hayır. Bir paneli etkinleştirmek için 100 EFHC gerekir. Bakiyeniz daha azsa etkinleştirme gerçekleşmez.

### 7-15. Archive paneller artık üretim yapmıyorsa neden yine de önemlidir?

Archive, panellerinizin ve tamamladığınız döngülerin geçmişini saklar. Bu sizin “büyüme biyografinizdir”, ancak mevcut üretimi yalnızca aktif paneller sağlar.

### 7-16. Panel etkinleştirip hemen aktif olduğunu görebilir miyim?

Evet. Etkinleştirilen panel Active listesinde görünmelidir ve etkinleştirme işlemi bakiye geçmişine yansır.

### 7-17. Bir panel 180 günde ne kadar enerji üretir?

Bir panel temel oranla 180 günde 107.61984000 kWh üretir. EFHC VIP NFT varsa üretim 115.24032000 kWh olur.

## 8. Energy

### 8-1. Energy sayfası neyi gösterir?

Energy sayfası enerji ilerlemesini, enerji üretimi ilerleme çubuğunu, aktif panel sayısını, panellerin saniye başına toplam üretimini ve mevcut durumun diğer temel göstergelerini gösterir.

### 8-2. Energy sayfasındaki ilerleme çubuğu neyi gösterir?

İlerleme çubuğu, oyuncunun 12 seviyelik ölçekte bir sonraki ilerleme seviyesine giden yolunu gösterir.

### 8-3. Panellerin saniye başına toplam üretimi ne anlama gelir?

Bu, temel ya da VIP üretim sabitinin aktif panel sayısıyla çarpılmış halidir.

### 8-4. Enerji neden bu kadar önemlidir?

Çünkü enerji, EFHC içindeki ilerlemenin merkezindeki temeldir. Kullanıcı panellerden bakiyeyi, seviyeleri, sıralamayı ve hesap gelişimini etkileyen sonuca enerji üzerinden ulaşır.

### 8-5. Energy sayfasından hesabın ne kadar güçlü olduğunu anlayabilir miyim?

Evet. Energy sayfası sistemin mevcut gücünü hızlıca gösterir: kaç panel çalışıyor, şu anda ne kadar üretim var, ne kadar enerji birikti ve kullanıcı bir sonraki seviyeye ne kadar yaklaşmış durumda.

### 8-6. Neden kullanılabilir enerji ile ana bakiye ayrı hesaplanır?

Çünkü bunlar iki farklı varlıktır. Kullanılabilir enerji biriken kWh miktarını gösterir, ana bakiye ise zaten alınmış ana EFHC miktarını gösterir. Bu değerler birbiriyle bağlantılıdır ama aynı şey değildir.

### 8-7. Enerji neden kendi kendine artıyor da ana bakiye neden otomatik olarak büyümüyor?

Çünkü enerji birikimi ile ana bakiyenin büyümesi farklı aşamalarda gerçekleşir. Önce paneller enerji üretir, ana bakiye ise yalnızca ayrı bir exchange işlemi veya ana EFHC kredilendiren başka bir senaryodan sonra artar.

### 8-8. Saniye başına üretim hızı neyi gösterir?

Bu, aktif panellerinizin şu anda ne kadar hızlı enerji ürettiğini, yani mevcut büyüme hızınızı gösterir.

### 8-9. Energy bölümünde her gün özellikle neyi takip etmek önemlidir?

Aktif panel sayısı, üretim hızı ve kullanılabilir enerji; bunlar hesabın durumunu gösteren üç ana göstergedir.

### 8-10. Energy’ye bakarak panellerimin gerçekten çalıştığını nasıl anlarım?

Energy bölümünde aktif paneller ve sıfır olmayan bir üretim görünüyorsa, ayrıca kullanılabilir enerji yavaş yavaş artıyorsa, paneller çalışıyordur. Üretim 0 ise ve enerji birikmiyorsa aktif panel yoktur ya da yanlış bloğa bakıyorsunuzdur.

### 8-11. Ekrandaki akan enerji rakamları neden bazen biraz düzeltiliyor veya sıçrıyor?

Kolaylık için biriken enerji rakamları ekranda gerçek zamanlı güncellenir ve sürekli üretim sürecini gösterir. Ancak asıl doğruluk kaynağı her zaman sunucudur. Uygulama belirli aralıklarla ve her işleminizden sonra mutlak matematiksel doğruluğu sağlamak için sunucuyla senkronize olur. O anda ekrandaki rakamlar tam sunucu değerine küçük bir düzeltme yapabilir.

## 9. Exchange

### 9-1. Exchange nedir?

Exchange, enerjinin ana EFHC’ye dönüştüğü bölümdür. Bu, kullanıcının proje içindeki yolculuğunun temel aşamalarından biridir.

### 9-2. Enerjinin EFHC’ye dönüşümü nasıl çalışır?

Takas, ilerlemenin ana EFHC’ye dönüştürülmesidir. Birikmiş enerji, projenin ana coin’lerine çevrilir.

### 9-3. 1 kWh = 1 EFHC kuralı ne anlama gelir?

Bu, projenin sabit iç kurudur. Her enerji birimi eşit miktarda EFHC’ye dönüştürülür.

### 9-4. Takas işleminden sonra ne olur?

Takas sonrasında enerji sonucu ana bakiyede ana EFHC olarak görünür. Bu artık sadece birikmiş enerji değil, projenin temel işlemlerine katılan bir sonuçtur.

### 9-5. Takas neden bu kadar önemlidir?

Çünkü kullanıcı birikmiş enerjisini asıl sonuç olan ana EFHC’ye tam olarak takas üzerinden çevirir. Enerji yolunun ana EFHC’ye dönüştüğü nokta burasıdır.

### 9-6. Bonus coin’leri enerji olmadan doğrudan takas edebilir miyim?

Hayır. Bonus coin’ler önce iç döngüye katılır: onlarla panel alınır, panel enerji üretir ve ancak daha sonra enerji ana EFHC’ye çevrilir.

### 9-7. Neden takas sonucu bonus bakiyeye değil de doğrudan ana bakiyeye gider?

Çünkü Exchange, enerjinin ana sonuca dönüşmesidir. Projede şu kural sabittir: 1 kWh = 1 EFHC ve takas sonucu her zaman ana bakiyeye yatırılır; temel işlemler ve çekim de bu bakiyeden yapılır.

### 9-8. Takas yaptım ama sonucu hemen göremiyorum; ne yapmalıyım?

Önce Exchange bölümünü yenileyin ve ana bakiyeyi kontrol edin. Sonra bakiye geçmişini açın: orada takas kaydı görünmelidir. Kayıt varsa, ekrandaki değişimi hemen fark etmeseniz bile takas tamamlanmıştır.

— Bölümü yenileyin
— Bakiyeyi kontrol edin
— Geçmişi kontrol edin

### 9-9. Enerjiyi takas edip hemen çekim talebi verebilir miyim?

Evet; takastan sonra ana bakiyede yeterli EFHC varsa, çekim tutarı 10 EFHC’den düşük değilse ve cüzdan bağlı olup ana cüzdan olarak seçildiyse.

### 9-10. Hangisi daha iyi: sık takas yapmak mı yoksa biriktirmek mi?

Bu, hedefinize bağlıdır. Sık takas kontrol ve işlemler için uygundur; biriktirmek ise daha seyrek ama büyük adımlar için uygundur. Kural tek: takas sonucu ana bakiyeye gider.

### 9-11. Takas yaptıktan sonra neden kullanılabilir enerji azalır?

Çünkü birikmiş enerjinizin bir kısmını Exchange üzerinden EFHC’ye çevirirsiniz. Enerji kaybolmaz; coin’e dönüşür.

Önemli: Energy ana ekranındaki enerji toplamı, genel ilerlemeniz olarak “azalmamalı” ve geriye dönük olarak sıralama ile seviyeyi etkilememelidir; o, büyüme yolunuzu ve toplam üretim sonucunuzu yansıtır.

### 9-12. Hangi enerjiyi artık takas edebilirim?

Birikip kullanılabilir hale gelmiş enerjiyi takas edebilirsiniz. Kullanılabilir enerji tam olarak budur: Exchange bölümünde işlem için hazır hacim.

### 9-13. Enerjiyi ana EFHC’ye çevirmek için minimum bir limit var mı?

Katı bir limit yoktur, ancak takas matematiği 1 kWh = 1 EFHC oranına bağlıdır. Sonucun ana bakiyede hemen görünmesi için 1 kWh ve üzerindeki tam enerji değerlerini biriktirip takas etmek daha uygundur.

## 10. Withdraw

### 10-1. Neden EFHC çekemiyorum?

Genellikle neden, ana bakiyede yeterli fon olmaması, cüzdanın bağlı olmaması ya da tutarın minimum çekim eşiğinin altında olmasıdır. Kontrole Wallet ve ana bakiyeden başlamalısınız.

### 10-2. Çekim nasıl gerçekleşir?

Bir çekim talebi oluşturulur ve ardından bu talep ilk uygun operatör tarafından mümkün olduğunca hızlı şekilde işlenir.

### 10-3. Çekim talebi verdikten sonra bakiye neden hemen değişti?

Çünkü bot bu işlemin başladığını sistemi içinde hemen hesaba katar. Bu, kullanıcının işlemin artık fonlarıyla ilişkili olduğunu ve sistem tarafından kabul edildiğini görmesi için gereklidir.

### 10-4. Withdrawal hangi balance üzerinden yapılabilir?

Withdrawal yalnızca ana balance üzerinden kullanılabilir.

### 10-5. Neden çekim sadece ana bakiyeden yapılabilir?

Çünkü ana bakiye, oyun sürecinin sonucu ya da aktive alınmış coin’ler olarak artık kullanıcıya ait olan kısımdır. Bonus coin’ler iç döngüye katılır ve doğrudan çekilemez.

### 10-6. Minimum çekim tutarı nedir?

Minimum çekim tutarı 10 EFHC’dir.

### 10-7. Çekim talebi genelde ne kadar sürede işlenir?

Çekim, talep ve operatör işleme sürecinden geçer. Sonucu hemen görmüyorsanız talep durumunu ve işlem geçmişini kontrol edin; gerçek durum orada yansır. Talep uzun süre değişmiyorsa bölümü yenilemek ve daha sonra tekrar kontrol etmek genelde yardımcı olur.

### 10-8. Çekim talebini iptal edebilir miyim?

Evet, eğer talep henüz işlenmemişse. İptal yalnızca bekleyen talepler için mümkündür. İptalden sonra ana bakiyeyi ve işlem geçmişini kontrol edin: fonlar tutulduysa geri iade edilir.

### 10-9. Çekim talebi neden “beklemede” kalabilir?

Çünkü çekim bir işleme sürecinden geçer. Talep değişmiyorsa talep durumunu ve işlem geçmişini kontrol edin, ardından bölümü daha sonra yeniden yenileyin.

### 10-10. Talebin iptal edildiğini nerede görürüm?

Bunu talep durumunda ve işlem geçmişindeki kayıtta görebilirsiniz. İptalden sonra ayrıca ana bakiyeyi de kontrol edin.

### 10-11. Minimum çekim neden tam olarak 10 EFHC?

Çünkü projede bunun altındaki taleplerin kabul edilmediği bir eşik belirlenmiştir. Minimum tutar 10 EFHC’dir.

Ayrıca çekim komisyonunu proje karşılar; bu yüzden 10 EFHC’den düşük tutarları çekmek mantıklı değildir.

### 10-12. Bende EFHC olsa bile withdrawal neden kullanılamıyor olabilir?

Çünkü withdrawal için yalnızca ana balance dikkate alınır. EFHC balance’ın bonus kısmındaysa bunlar için withdrawal gönderilemez.

### 10-13. Çekim talebi gönderdikten sonra ne yapmalıyım?

Talep durumunu ve işlem geçmişini kontrol edin; talebin gerçek durumu ve fon hareketleri orada görünür.

### 10-14. Çekim hangi token ile ve hangi ağda yapılır?

Çekim yalnızca EFHC tokenlarıyla ve sadece TON blokzincir ağı üzerinde yapılır (The Open Network). Projede başka hiçbir çekim seçeneği yoktur.

### 10-15. Operatör tarafından manuel çekim işlemi ne kadar sürer?

Çekim talepleri operatörler tarafından canlı sıra mantığıyla işlenir. Ağ yüküne ve talep sayısına bağlı olarak işlem genelde birkaç dakikadan 24 saate kadar sürer. İşlenmemiş bir talebi her zaman iptal edebilirsiniz; fonlar anında bakiyenize döner.

## 11. Görevler

### 11-1. Görevleri tamamlamak ne kazandırır?

Görevler yalnızca bonus coin'ler verir ve oyuncunun proje içindeki yaşama katılımını teşvik eder.

### 11-2. Bir görev için ödül nasıl alınır?

Görevin koşullarını yerine getirmek gerekir; ardından bot tamamlamayı otomatik olarak kaydeder ve öngörülen ödülü verir.

### 11-3. Görev neden tamamlanmadı?

Koşullar henüz tamamen yerine getirilmemişse, işlem tam bitmemişse veya sonuç sistemde henüz güncellenmemişse böyle olabilir.

### 11-4. Aynı görevi tekrar yapabilir miyim?

Bu, görevin türüne bağlıdır. Bazı görevler tek seferliktir, bazıları ise proje mantığına göre tekrarlanabilir.

### 11-5. Tüm görevler aynı ödülü mü verir?

Hayır. Ödül miktarı belirli göreve ve onun koşullarına bağlıdır. Ama burada ödül türü tektir — bonus coin'ler.

### 11-6. Zaten paneller varken görevlere neden ihtiyaç var?

Görevler ek bir büyüme yoludur. Panellerin yerini almaz; daha sonra oyun döngüsü içinde kullanabileceğiniz bonus coin'leri toplamanıza yardımcı olur.

### 11-7. Görev ödülü neden ana bakiyeye gelmiyor?

Çünkü görevler bonus EFHC verir. Bu, oyun döngüsü için iç ödüldür ve bonus bakiyeye yatırılır.

### 11-8. Görevler neden bazen bitiyor veya kayboluyor?

Çünkü görevler geçici olabilir veya bir limite sahip olabilir. Görev görünmüyorsa, ya sona ermiştir ya da şu anda aktif değildir.

### 11-9. Tüm mevcut görevleri nerede görebilirim?

Tasks bölümünde — mevcut görevlerin listesi ve koşulları orada gösterilir.

### 11-10. Görev ödülü neden hemen görünmedi?

Bazen sonucun güncellenmesi için zamana ihtiyaç olur. Şunları kontrol edin: Tasks'i yenile → bonus bakiyeyi kontrol et → işlem geçmişini kontrol et.

### 11-11. Görevde istenen kanala abone oldum ama görev tamamlanmıyor. Neden?

Bazen abonelik kontrolü Telegram sunucularındaki önbellekleme nedeniyle zaman alır. Bot aboneliği anında saymadıysa birkaç dakika sonra Tasks bölümüne dönün ve kontrol düğmesine tekrar basın.

## 12. Yönlendirmeler

### 12-1. Referrals sayfasındaki bölümlerin adı nedir?

Referrals sayfasında Aktif ve Aktif Olmayan bölümleri kullanılır.

### 12-2. Aktif ve aktif olmayan referral ne demektir?

Aktif referral, en az bir panel etkinleştirmiş ve Activ statüsü almış oyuncudur. Aktif olmayan referral ise henüz oyun döngüsüne girmemiştir ve şu anda bonus hakkı vermez.

### 12-3. Referral bonusları ne zaman yatırılır?

Referral bonusları bot tarafından otomatik olarak kontrol edilir. Oyuncu aktif hale gelir gelmez bonus da hemen otomatik olarak yatırılır.

### 12-4. Referral'lar için aktif statü ne sağlar?

Aktif statü referral mantığı için önemlidir; proje bunu gerçek katılımı filtrelemek ve botlar, bot çiftlikleri ile sahte aktiviteye karşı korunmak için kullanır.

### 12-5. Activ referral sistemiyle nasıl bağlantılı?

Activ, kullanıcının bir bot hesabı değil, projenin gerçek katılımcısı olduğunu gösterir. Bu, referral sisteminin adil çalışması ve bot çiftliklerine karşı koruma için önemlidir.

### 12-6. Her aktif referral için temel bonus nedir?

Her doğrudan referans için yalnızca bir kez 0.1 EFHCb bonus verilir — referans ilk panelini etkinleştirip Activ aldığında.

### 12-7. Referral'larım var ama neden bonus gelmedi?

Bonus yalnızca doğrudan referans ilk panelini etkinleştirdikten sonra verilir. O zamana kadar aktif değildir; sonraki paneller yeniden referans bonusu oluşturmaz.

### 12-8. Aktif referral için verilen 0.1 EFHCb nereye yatırılır?

Doğrudan referansın aktivasyonu için 0.1 EFHCb ödülü bonus bakiyeye bir kez yatırılır. Lvl ödülleri de aynı EFHCb bonus bakiyesine yatırılır. Tam döngü, 10.000 aktif doğrudan referans için 1.000 EFHCb artı 1.411 EFHCb Lvl ödülü, toplam 2.411 EFHCb’dir.

### 12-9. Davet ettiğim kişi listede var ama neden aktif sayılmıyor?

Çünkü aktif sayılması için önce ilk panelini etkinleştirmesi ve Activ alması gerekir. Bu olmadan listenin aktif olmayan bölümünde kalır.

### 12-10. Referral linkimi nereden alabilirim?

Referrals bölümünde — referral bağlantınız ve davet ettiğiniz kullanıcıların listesi orada gösterilir.

### 12-11. Kendi referral bağlantımla ek hesaplar oluşturmak serbest mi?

Evet. Proje kuralları bunu yasaklamaz. Ancak boş hesaplar oluşturmak size fayda sağlamaz. Sistem ekonomisi referral bonuslarının ve büyümenin yalnızca Activ statüsüne sahip bir katılımcı için yazılacağı şekilde kurulmuştur; yani davet edilen hesap gerçekten oyuna girip en az bir panel etkinleştirdikten sonra.

### 12-12. Kayıttan sonra beni davet eden kişiyi değiştirebilir miyim?

Hayır. Referral bağlantısı projeye davet linkiyle ilk giriş yaptığınız anda sabitlenir ve daha sonra değiştirilemez.

## 13. Hub

### 13-1. Hub içinde ne yapabilirim?

Hub iki işlem sunar: Bakiye Yükle ve EFHC VIP NFT. Harici yolların ayrıntıları yalnızca Hub’dan çıktıktan sonra görünür.

### 13-2. Hub ne için kullanılır?

Hub, projenin iki harici işlemi için kısa bir gezinme bölümüdür.

### 13-3. Hub içinde kaç işlem vardır?

Tam olarak iki: Bakiye Yükle ve EFHC VIP NFT. Her iki işlev de kanoniktir.

### 13-4. «Bakiye Yükle» düğmesi ne yapar?

Harici Web devam sayfasını açar. Ürünler, fiyatlar ve ödeme yöntemleri Hub’dan çıkmadan önce gösterilmez.

### 13-5. Onaydan sonra EFHC yüklemesi nereye yatar?

EFHCm yüklemesi ana bakiyeye yatırılır.

### 13-6. Yükleme sonucu neden hemen görünmeyebilir?

Önce işlemin dış aşaması onaylanmalıdır, ardından sonuç güncellenir. Hub’ı, ana bakiyeyi ve işlem geçmişini kontrol edin.

### 13-7. GetGems üzerinden bir VIP NFT aldıysam aktif olduğunu nerede görürüm?

Uygulamadaki VIP durumunu ve NFT’nin bağlı cüzdanda bulunup bulunmadığını kontrol edin.

### 13-8. Hub’dan dış akışı tamamladım ama sonuç yok. Ne yapmalıyım?

Hub’ı, ana bakiyeyi ve işlem geçmişini kontrol edin. Hâlâ sonuç yoksa işlem henüz sisteme alınmamış olabilir veya ayrı işlem gerektiriyordur.

### 13-9. Top Up ve Hub üzerinden yapılan yükleme hangi bakiyeye gider?

EFHCm yüklemesi ana bakiyeye yatırılır.

### 13-10. Hub eylemleri için bağlı bir cüzdan gerekir mi?

Dış wallet tabanlı eylemler için bağlı bir Wallet gerekir. Hub’ın kendisi ayrı bir iç eylem olmadan açılır ve geçiş noktası olarak çalışır.

### 13-11. EFHC yüklemesinin gerçekten yattığını nerede doğrulayabilirim?

Ana bakiyeyi ve işlem geçmişini kontrol edin: yüklemenin izi orada görünmelidir.

### 13-12. Hub’da skin var mı?

Skinler Hub kartları değildir.

### 13-13. Proje skinlerini nasıl alırım?

Skinler hesap ilerledikçe açılır ve 12 başarı seviyesine bağlıdır.

## 14. Navigasyon ve kurallar

### 14-1. “Navigasyon ve Kurallar” bölümünü ne zaman açmalıyım?

Ekranların mantığını hızlıca anlamak, WebApp içinde gerekli işlevi bulmak veya uygulama bölümleriyle çalışma kurallarını netleştirmek istediğinde bu bölümü aç.

### 14-2. WebApp’e ilk kez veya uzun bir aradan sonra giriyorsam önce hangi ekranları açmalıyım?

Ana ekran, üst çubuk ve profille başlamak en iyisidir. Bundan sonra mevcut görevinize göre Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History ve Hub’a geçmek daha kolay olur.

### 14-3. İhtiyacım olan işlevi hangi bölümde aramam gerektiğini nasıl anlarım?

Bölümü işleme göre seçin: Profile hesap için, Wallet cüzdan için, Panels paneller için, Energy üretim için, Exchange değişim için, Withdraw çekim için, Tasks görevler için, Referrals davetler için ve Hub Yükle geçişi için.

### 14-4. Profile girişi nerede?

Profile girişi arayüzün üst kısmında “Profile” düğmesi üzerinden bulunur.

### 14-5. Neden bazı işlemler ayrı onay gerektirir?

Ayrı onay hesabı korur ve önemli operasyonlarda yanlışlıkla işlem yapma riskini azaltır.

### 14-6. Neden bazı işlemler hemen kullanılabilirken bazıları hesap durumuna bağlıdır?

Bazı işlevler hesap durumuna, panel varlığına, bağlı cüzdana, etkinlik geçmişine veya diğer dahili proje koşullarına bağlıdır.

### 14-7. Profile, Wallet ve History arasındaki fark nasıl anlaşılır?

Profile, hesap verilerinin ve ilgili işlevlere giriş noktalarının bulunduğu bölümdür. Wallet, cüzdanı bağlamak ve kontrol etmek içindir. History, işlemler ve bakiye hareketleri geçmişidir.

### 14-8. Gerekli düğmeyi veya bölümü görmüyorsam ne yapmalıyım?

Önce ekranı yenileyin ve başka bir bölümün açık olup olmadığını kontrol edin. Ardından ana ekrana, üst panele veya Profile bölümüne dönün ve işlevin amacına göre tekrar ilgili yere gidin.

### 14-9. Ekrandaki veriler eski görünüyorsa veya beklediğimle uyuşmuyorsa ne yapmalıyım?

Önce ekranı yenileyin, ardından bu bilginin ait olduğu profil bölümünü açın. Bakiye ve hareketleri History’de, panelleri Panels’ta, üretimi Energy’de, cüzdan işlemlerini Wallet’ta ve çekim işlemlerini Withdraw’da kontrol etmek daha uygundur.

### 14-10. Şu anda yanlış bölümün açık olduğunu nasıl anlarım?

Bölümü işleme göre seçin: Profile hesap için, Wallet cüzdan için, Panels paneller için, Energy üretim için, Exchange değişim için, Withdraw çekim için, Tasks görevler için, Referrals davetler için ve Hub Yükle geçişi için.

### 14-11. WebApp’e günlük normal girişte ekranları hangi sırayla kontrol etmek uygundur?

Genellikle önce ana ekrana ve üst panele bakmak, ardından mevcut görevle ilgili bölümleri açmak uygundur: Panels, Energy, History, Tasks, Referrals, Hub, Exchange veya Withdraw. Bu sıra hesabın mevcut durumunu hızlıca anlamaya ve gereken işleme geçmeye yardımcı olur.

### 14-12. Acil bir görev olmasa bile hangi bölümler düzenli kontrol edilmeli?

Ana ekranı, üst paneli, Panels, Energy, History, Tasks, Referrals ve Hub bölümlerini düzenli kontrol etmek faydalıdır. Bu, bakiye değişikliklerini, panel etkinliğini ve mevcut işlemleri zamanında görmeye yardımcı olur.

### 14-13. İşlemleri her yerde aramak yerine kendi bölümünde yapmak neden önemlidir?

Bu, hataları ve yanlışlıkla yapılan işlemleri azaltır. Kullanıcı değişimi Exchange’de, çekimi Withdraw’da, panellerle çalışmayı Panels’ta yaptığında WebApp mantığı anlaşılır ve güvenli kalır.

### 14-14. Bir işlemin önemli olduğunu ve dikkat gerektirdiğini hangi işaretlerden anlarım?

Bir işlem bakiye, paneller, enerji, değişim, çekim, cüzdan bağlantısı, işlem geçmişi veya hesap durumunu etkiliyorsa daha fazla dikkat gerekir. Bu tür işlemleri onaylamadan önce ekranı ve seçilen düğmeyi tekrar kontrol etmek faydalıdır.

### 14-15. Bot güncellemesinden sonra bir ekran değiştiyse ne yapmalıyım?

Güncel bölüm adlarına ve amaçlarına göre hareket edin. Görsel öğeler değişebilir, ancak ekranların mantığı anlaşılır ve tutarlı kalmalıdır.

### 14-16. WebApp ile çalışırken hata yapmamak için hangi temel kurallar yardımcı olur?

İşlemi yalnızca uygun bölümde yapmak, onaylamadan önce ekran adını ve düğmeyi dikkatle okumak ve şüphe durumunda rastgele arayüz öğelerine basmak yerine önce profil bölümlerini kontrol etmek faydalıdır.

### 14-17. WebApp ile çalışırken FAQ hangi durumlarda açılmalıdır?

Belirli bir işlevin ekranı, düğmesi, işlemi veya kuralının anlamını hızlıca netleştirmeniz gerektiğinde FAQ açmak faydalıdır. Böylece soruyu doğru bölümle eşleştirmek ve WebApp içinde gereksiz adımlardan kaçınmak daha kolay olur.

## 15. Reklamlar

### 15-1. Bu ne bölümü?

Ads bölümü, Tasks içinde yer alan bir alt bölümdür. Kullanıcının ek bonus coin'ler alabileceği mevcut reklam eylemlerini gösterir.

### 15-2. Bana ne kazandırır?

Kullanıcının hesabı için reklam şu anda mevcutsa yalnızca görüntülemeler karşılığında bonus coin'ler verir.

### 15-3. Burada neden hiçbir şey yok?

Bölüm boşsa bu, kullanıcı hesabı için şu anda aktif teklif olmadığı veya reklamın geçici olarak kapatıldığı anlamına gelir.

### 15-4. Ads bölümü nerede bulunur?

Ads bölümü, Tasks içinde yer alan bir alt bölümdür. Bu, görevler bloğu içindeki ek olanaklardan biridir.

### 15-5. Ads hangi tür ödül verir?

Ads görüntülemeler için yalnızca bonus coin'ler verir. Bu, ana bakiye ya da doğrudan çekim değil; oyun yolunu güçlendirmenin ek iç yöntemidir.

### 15-6. Ads neden faydalıdır?

Çünkü bu, ek bir bonus coin kaynağıdır. Panellerin ve üretimin yerini almaz, ancak iç oyun döngüsünü daha hızlı güçlendirmeye yardımcı olabilir.

### 15-7. Başkalarında reklam var ama bende neden yok?

Çünkü teklifler belirli bir hesap için mevcut olmayabilir veya reklam geçici olarak kapatılmış olabilir. Boş bir Ads bölümü, hesabın bozuk olduğu anlamına gelmez.

### 15-8. Ads içinde bir eylemi yaptım ama sonuç yoksa ne yapmalıyım?

Kontrol edin: Tasks/Ads'i yenile → bonus bakiyeyi kontrol et → işlem geçmişini kontrol et.

### 15-9. Ads içinde farklı kullanıcılarda neden farklı teklifler olabilir?

Çünkü teklifler, belirli hesap için uygun reklam kampanyalarına bağlıdır. Bu normaldir: bir kullanıcıda teklif vardır, diğerinde geçici olarak olmayabilir.

### 15-10. Ads'i kullanmak için bir şey aktive etmek gerekir mi?

Hayır. Ads, bonus EFHC kazanma yoludur; zorunlu iç eylem gerektirmez.

## 16. Ranks

### 16-1. Ranking içinde yükselmem neden benim için önemlidir?

Ranking içinde yükselmek, ilerlemenizin diğer katılımcılara göre nasıl göründüğünü gösterir. Bu, mevcut yerinizi anlamanıza ve hesabın ne kadar aktif geliştiğini görmenize yardımcı olur.

### 16-2. Seviye ile sıralama arasındaki fark nedir?

Seviye, sistem içindeki kişisel ilerlemeyi gösterir; sıralama ise kullanıcının diğer katılımcılar arasındaki yerini gösterir.

### 16-3. Seviye ve sıralama birbiriyle nasıl bağlantılıdır?

İkisi, panellerin ürettiği kWh ve Energy sayfasındaki ortak ilerleme çubuğu üzerinden aynı genel büyüme mantığıyla birbirine bağlıdır.

### 16-4. Sıralama sadece güzel görünen bir sayı mı?

Hayır. Sıralama, yolunuzun diğer katılımcılara kıyasla nasıl göründüğünü anlamaya yardım eder.

### 16-5. Ranking içindeki pozisyonumun büyümesini ne etkiler?

Ranking içindeki pozisyonunuzun büyümesini hesabın genel ilerleyişi etkiler: panels gelişimi, kWh üretimi ve projenin enerji yolundaki genel ilerleme.

### 16-6. Seviyede ve sıralamada aynı anda yükselebilir miyim?

Evet. Kullanıcı panellerini, üretimini ve genel enerji ilerlemesini geliştirdiğinde, genellikle hem seviyesini hem de sıralamadaki yerini güçlendirir.

### 16-7. Neden seviyem yüksek ama sıralamadaki yerim birinci değil?

Çünkü sıralama, sadece kişisel ilerlemeniz değil, tüm katılımcılar arasındaki yerinizdir. Diğer oyuncular da büyüdüğü için, seviyeniz iyi olsa bile yeriniz değişebilir.

### 16-8. Yeni bir işlem yapmasam bile sıralamam neden yer değiştirebilir?

Çünkü sıralama tek başına var olmaz; tüm katılımcılarla karşılaştırmalı olarak değişir. Siz hiçbir şeyi değiştirmezken diğer kullanıcılar büyümeye devam eder ve bu da yerinizi etkiler.

### 16-9. Sıralamadaki yerimi nerede görürüm?

Ranks bölümünde — burada diğer katılımcılar arasındaki yeriniz gösterilir.

### 16-10. İlerleme kaydediyor olsam bile sıralamam neden düşebilir?

Çünkü sıralama için yalnızca sizin büyümeniz değil, diğer katılımcıların ne kadar hızlı büyüdüğü de önemlidir. Hesabınız güçlense bile, başkaları sizi daha hızlı geçerse yeriniz düşebilir.

## 17. Activ Durumu

### 17-1. Activ durumu ne anlama gelir?

Activ, kalıcı bir aktif durumdur. En az bir panel aktive alındığı için oyunun gerçekten başladığı anlamına gelir.

### 17-2. Activ nasıl alınır?

Activ almak için bir panel etkinleştirmek yeterlidir. Bu iç eylem işleminden sonra durum kalıcı olarak verilir.

### 17-3. Activ geçici mi yoksa kalıcı mı?

Activ kalıcı bir durumdur.

### 17-4. Panel daha sonra Archive durumuna geçerse Activ korunur mu?

Evet. Panel daha sonra Archive durumuna geçse bile Activ durumu korunur.

### 17-5. Activ neden önemlidir?

Activ, gerçek oyuncuları rastgele kayıtlardan, botlardan ve bot çiftliklerinden ayırmaya yardım eder. Kullanıcının projeye gerçek katılımını doğrular.

### 17-6. Activ daha sonra kaybolabilir mi?

Hayır. Activ kalıcı bir durumdur ve ilk panel daha sonra Archive durumuna geçse bile korunur.

### 17-7. Botlara ve bot çiftliklerine karşı koruma için Activ neden gereklidir?

Çünkü Activ, şişirme için kullanılan boş bir hesabı değil, gerçek katılımı doğrular. Bu da referans sistemini ve ekonomiyi daha adil hâle getirir.

### 17-8. Activ alındıktan sonra hesapta ne değişir?

Hesap, projenin doğrulanmış yaşayan bir katılımcısı olarak kabul edilir. Bu, referansların adil çalışmasını ve aktiviteye duyulan güveni etkiler.

### 17-9. Activ neden tam olarak ilk panelden sonra ortaya çıkar?

Çünkü ilk panelin etkinleştirilmesi, gerçek katılımın açık bir işaretidir. Proje bu adımı, boş hesapları filtrelemek için kullanır.

### 17-10. Hareketsizlik yüzünden Activ kaybedilebilir mi?

Hayır. Activ kalıcı bir durumdur ve hareketsizlik nedeniyle kaybolmaz.

## 18. VIP NFT

### 18-1. EFHC VIP NFT nedir?

EFHC VIP NFT, bir kulüp kartı, gelecekteki tüm EFHC ekosisteminin anahtarı, dijital bir aiyet işareti ve projenin gelecekteki fırsatlarına açılan bir anahtardır.

### 18-2. Bir adet EFHC VIP NFT sahibi olmak bana ne verir?

Bir adet EFHC VIP NFT sahibi olmak, oyuncunun tüm panelleri için artırılmış üretim sağlar.

### 18-3. VIP’in zaten hesaba katıldığını hangi işaretlerden anlayabilirim?

Sistem VIP NFT’yi zaten hesaba kattıysa arayüzde VIP durumu görünür ve hesaba bağlı avantajlar fark edilir hâle gelir.

### 18-4. VIP etkisini nerede görürüm?

VIP etkisi, projenin VIP NFT avantajlarını dikkate aldığı bölümlerde ve ayrıca üst panelde ve Profil/Ayarlar bölümünde görülür.

### 18-5. VIP’yi elle açmak gerekir mi?

Hayır. Proje mantığı, cüzdanın otomatik kontrolüne ve NFT gerekli koleksiyonda tespit edildikten sonra VIP durumunun otomatik güncellenmesine göre tasarlanmıştır.

### 18-6. 2 veya 3 VIP NFT oyuncuya ek ayrıcalık verir mi?

Hayır. Oyuncu için 2 veya 3 VIP NFT sahibi olmak, bir VIP NFT’nin sağladığının ötesinde ek ayrıcalık vermez.

### 18-7. İkinci bir VIP NFT neden etkiyi güçlendirmiyor?

Projede VIP, tek bir aktif durum olarak üretimi güçlendirir. İlave VIP NFT’ler ek güç vermez; böylece etki sonsuza kadar hızlanmaz.

### 18-8. VIP tek bir paneli mi etkiler yoksa hepsini mi?

VIP, tek bir paneli değil, kullanıcının tüm panellerinin üretimini etkiler.

### 18-9. VIP’in hesabı gerçekten etkilediğini nasıl kontrol edebilirim?

Sadece VIP durumunun varlığını değil, hesap mekaniğindeki ilgili avantajları da kontrol edin; özellikle generation dâhil VIP etkisinin dikkate alındığı yerlerde.

### 18-10. Botun VIP NFT’mi görebilmesi için bağlı bir cüzdan gerekir mi?

Evet. Botun VIP NFT’yi görebilmesi için hangi cüzdanın hesaba ait olduğunu bilmesi gerekir. Bu yüzden Wallet bağlı olmalı, ardından arayüzde VIP durumunu kontrol edersiniz.

### 18-11. VIP NFT’mi istediğim gibi kullanabilir miyim?

Evet. EFHC VIP NFT transfer edilebilir, hediye edilebilir ve pazaryerlerinde satılabilir.

### 18-12. VIP NFT’mi satarsam veya başka bir cüzdana taşırırsam üretimime ne olur?

Bot düzenli olarak blokzinciri tarar ve bağlı cüzdanınızda NFT olup olmadığını kontrol eder. VIP NFT’nizi satarsanız, hediye ederseniz veya başka bir adrese taşırsanız sistem bunu tespit eder, VIP statünüzü kapatır ve tüm panellerinizin üretimi otomatik olarak temel orana döner.

## 19. Seviyeler

### 19-1. Neden seviyemi yükseltmeliyim?

Seviye artışı, kullanıcının proje içindeki ilerlemesini gösterir ve hesabın nasıl geliştiğini görmeye yardımcı olur. Bu, ileriye hareketin hem görsel hem de anlamlı bir göstergesidir.

### 19-2. Seviyeler bölümü neleri içerir?

Seviyeler bölümü, projenin tüm büyüme ölçeklerini gösterir: enerji ilerlemesinin 12 seviyesi, referans sisteminin 6 seviyesi ve gelecekte eklenirse projenin diğer seviyeli hatları.

### 19-3. Projede enerji ilerlemesi için kaç seviye var?

Projede enerji ilerlemesi için 12 seviye öngörülmüştür.

### 19-4. Referans sisteminde kaç seviye var?

Projede referans sistemi için 0’dan 5’e kadar toplam 6 seviye öngörülmüştür.

### 19-5. Seviyeler sıradan bir oyuncu için neden faydalıdır?

Seviyeler, şu anda nerede olduğunuzu, ne kadar yol aldığınızı, bundan sonra nereye ilerlemeniz gerektiğini ve önünüzdeki bir sonraki eşiğin ne olduğunu anlamaya yardım eder.

### 19-6. Enerji seviyeleri, referans seviyeleri ve hesabın genel büyümesi nasıl bağlantılıdır?

Bunlar tek bir ortak yolun parçalarıdır. Enerji üretimi ana ilerlemeyi hareket ettirir, aktif referanslar referans çizgisini güçlendirir ve birlikte hesabın ne kadar güçlü geliştiğini gösterir.

### 19-7. Eco Initiate (0 kWh)

**Oyuncu için anlamı:** İlk paneliniz kuruldu ve çalışmaya hazır. Temiz enerjinin bağımsız bir üreticisi olma yolunda ana adımı atıyorsunuz. Bu sizin başlangıç durumunuzdur — üretim yoluna daha yeni girdiniz.

**Kesin kural:** Eco Initiate seviyesi 0 kWh işaretine karşılık gelir.

**Pratik sonuç:** Sonraki adım, paneller aracılığıyla üretimi büyütmek ve ilerlemeyi 100 kWh seviyesine çıkarmaktır.

### 19-8. Hope Bringer (100 kWh)

**Oyuncu için anlamı:** İlk kilovatlar gelmeye başladı! Panelleriniz yeşil enerjiyi başarıyla üretiyor ve doğaya karbonsuz bir gelecek için umut veriyor. İlk gerçek sonuçları artık görüyorsunuz: enerji akmaya başladı ve ilerleme yerinden oynadı.

**Kesin kural:** Hope Bringer seviyesi 100 kWh’den başlar.

**Pratik sonuç:** Sonraki hedef, istikrarı artırmak ve bir sonraki basamak için 300 kWh’ye ulaşmaktır.

### 19-9. Energy Seeker (300 kWh)

**Oyuncu için anlamı:** Sistem mükemmel çalışıyor ve ağı istikrarlı biçimde çevre dostu elektrikle besliyor. Panellerin ürettiği her enerji birimi fosil yakıtların yerini alır. Hesap istikrarlı büyüme moduna girdi: artık bir "acemi" değil, gerçek üretime sahip bir kullanıcısınız.

**Kesin kural:** Energy Seeker seviyesi 300 kWh’den başlar.

**Pratik sonuç:** Pratikte bu bir işarettir: panelleri güçlendirebilir ve enerjiyi ana bakiyeye dönüştürmek için Exchange’i daha sık kullanabilirsiniz.

### 19-10. Nature's Voice (600 kWh)

**Oyuncu için anlamı:** Katkınız görünür hâle geliyor. Yeşil teknolojilerle enerji üreterek, ilerlemenin çevre dostu olabileceğini kanıtlayan doğanın sesi oluyorsunuz. Katkınız daha fark edilir olur: ilerleme artık tesadüf gibi değil, bir rota gibi hissedilir.

**Kesin kural:** Nature's Voice seviyesi 600 kWh’den başlar.

**Pratik sonuç:** Sonraki hedef 1000 kWh (Earth Ally). Energy bölümündeki tempoyu ve aktif panel sayısını izlemek faydalıdır.

### 19-11. Earth Ally (1000 kWh)

**Oyuncu için anlamı:** İlk megavat-saat üretildi! Panelleriniz etkileyici miktarda temiz enerji üretti. Artık yeşil dönüşümün önemli bir katılımcısı ve gezegenin güvenilir bir müttefikisiniz. Önemli bir eşiği aştınız: 1000 kWh artık ciddi bir birikmiş üretim hacmidir.

**Kesin kural:** Earth Ally seviyesi 1000 kWh’den başlar.

**Pratik sonuç:** Pratikte bu, büyümenin öngörülebilir hâle geldiği noktadır: panel parkınızı güçlendirin ve düzenli enerji takasını sürdürün.

### 19-12. Climate Fighter (2000 kWh)

**Oyuncu için anlamı:** Üretiminiz iklim değişimine karşı gerçek bir darbe vuruyor. Üretilen her kilovat, kömür ve gaz yakma ihtiyacını doğrudan azaltır. Artık sistematik biçimde büyümeyi zorluyorsunuz: ilerleme hem seviyede hem de hesabın genel dinamiğinde görünür.

**Kesin kural:** Climate Fighter seviyesi 2000 kWh’den başlar.

**Pratik sonuç:** Sonraki adım tempoyu sabitlemek ve 3500 kWh’ye ulaşmaktır. Üretim hızına bakın ve gerekirse VIP kullanın.

### 19-13. Green Sentinel (3500 kWh)

**Oyuncu için anlamı:** Panellerinizden gelen istikrarlı enerji akışı temiz havayı korur. Karbon ayak izi bırakmadan topluma hissedilir fayda sağlıyorsunuz. Hesabınız istikrarlı üretimin bir "nöbetçisi" hâline gelir: büyüme güvenle devam eder.

**Kesin kural:** Green Sentinel seviyesi 3500 kWh’den başlar.

**Pratik sonuç:** Pratikte bunun anlamı şudur: paneller artık bir sistem gibi çalışıyor — aktif panelleri koruyun ve 5000 kWh’ye kadar büyümeyi planlayın.

### 19-14. Planet Defender (5000 kWh)

**Oyuncu için anlamı:** 5000 kWh temiz üretim! Panellerinizin gücü, atmosferi binlerce kilo sera gazı salımından koruyan görünmez bir kalkan gibi çalışıyor. 5000 kWh büyük ölçeğin bir işaretidir: enerji alanında artık güçlü katılımcılar bölgesindesiniz.

**Kesin kural:** Planet Defender seviyesi 5000 kWh’den başlar.

**Pratik sonuç:** Sonraki hedef 7500 kWh’dir. Oyuncular çoğu zaman bu noktada hem panellerini hem de referans ağını güçlendirir.

### 19-15. Eco Champion (7500 kWh)

**Oyuncu için anlamı:** Olağanüstü üretim hacimleri! Siz, katkısı küresel enerji dengesini daha iyi yönde hissedilir biçimde değiştiren gerçek bir yeşil enerji şampiyonusunuz. Bu, istikrarlı biçimde yüksek üretim temposunu koruyanların seviyesidir.

**Kesin kural:** Eco Champion seviyesi 7500 kWh’den başlar.

**Pratik sonuç:** Pratikte: disiplini koruyun — aktif paneller, düzenli Exchange, geçmişin ve bakiyelerin kontrolü.

### 19-16. Planet Saver (10000 kWh)

**Oyuncu için anlamı:** 10 megavat-saat! O kadar çok temiz enerji ürettiniz ki, tam anlamıyla bütün ekosistemleri kurtarıyorsunuz ve panellerinizin en yüksek verimini kanıtlıyorsunuz. 10000 kWh artık "on megavat-saat" üretimdir; bu, ilerlemenin çok güçlü bir aşamasıdır.

**Kesin kural:** Planet Saver seviyesi 10000 kWh’den başlar.

**Pratik sonuç:** Sonraki adım 15000 kWh’dir. Bu aşamada her şeyi optimize etmek mantıklıdır: paneller, VIP, referanslar, iç eylemlar.

### 19-17. Green Commander (15000 kWh)

**Oyuncu için anlamı:** Çevre dostu üretimin amiral gemisi. Panelleriniz geleceği besliyor ve etkileyici üretim hacimleri tüm topluluk için tamamen yeni, yüksek standartlar belirliyor. Zirveye yaklaştınız: bu, enerji açısından liderlik ölçeğindeki seviyedir.

**Kesin kural:** Green Commander seviyesi 15000 kWh’den başlar.

**Pratik sonuç:** Pratikte: istikrarı koruyun ve aktif panelleri ve Energy temposunu izleyerek 20000+ kWh’ye doğru büyütün.

### 19-18. Guardian of Earth (20000+ kWh)

**Oyuncu için anlamı:** Evrimin zirvesi. 20 MWh’den fazla tamamen temiz enerji üreterek gerçek bir Guardian of Earth oldun. Panellerin bu dünyayı beslemek ve gelecek nesiller için korumak üzere gücünü doğanın kendisinden alır. Bu merdivenin zirvesidir: en yüksek tanınmış ilerleme seviyesine ulaştın.

**Kesin kural:** Guardian of Earth seviyesi 20000+ kWh’ye karşılık gelir.

**Pratik etki:** Pratikte en yüksek statüyü güvenceye aldın. Bundan sonra odak sistemi korumak, panelleri büyütmek ve panels, VIP ve referans büyümesiyle ekosistem katılımını güçlendirmektir.

### 19-19. Referans seviyesi 0

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 0 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-20. Referans seviyesi 1

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 1 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-21. Referans seviyesi 2

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 10 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-22. Referans seviyesi 3

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 100 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-23. Referans seviyesi 4

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 300 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-24. Referans seviyesi 5

**Oyuncu için anlamı:** Bu, referans sistemindeki büyümenizin işaretidir — aktif davet edilen kullanıcıların ölçeğini gösterir.

**Kesin kural:** Bu seviyeye ulaşıldığında verilen tek seferlik bonus: 1000 EFHCb.

**Pratik sonuç:** Pratikte: seviyeye ulaştıktan sonra bonus bakiyenizi ve işlem geçmişinizi kontrol ederek tahakkuku görün.

### 19-25. Seviye ilerlemesini hatasız nasıl anlamalıyım?

**Oyuncu için anlamı:** Bu blok ilerlemeyi gerçekçi değerlendirmeye ve seviyelere fiili enerji üretimi üzerinden bakmaya yardımcı olur.

**Kesin kural:** Seviyeler kWh cinsinden birikmiş üretime göre belirlenir. Toplam üretim ne kadar büyükse seviyen o kadar yüksektir.

**Pratik etki:** Pratikte enerji büyümesine, aktif panel sayısına ve genel üretim hızına odaklan. Gerçek seviye ilerlemesini bunlar sağlar.

### 19-26. Seviye adları neden ekoloji ve gezegen ile bağlantılı?

Çünkü oyunun temel fikri sanal yeşil enerjiye, insanları motive etmeye ve Dünya gezegeninin iyileşmesine sembolik bir katkıya dayanır.

## 20. FAQ / Yardım

### 20-1. FAQ’yi nerede açabilirim?

FAQ, profil içinden açılan yerleşik bot yardım bölümüdür; burada projenin ana eylemleri, ekranları ve kurallarıyla ilgili cevaplar toplanır.

### 20-2. FAQ / Yardım ne için gereklidir?

Bu bölüm, kullanıcının tahminlere ve karışıklığa düşmeden açık cevapları, kesin rakamları, gerçek proje kurallarını ve ana eylemlerin anlamını hızlıca bulabilmesi için vardır.

### 20-3. FAQ neden bu kadar ayrıntılı yazılmıştır?

Çünkü proje çok katmanlıdır ve kısa, kuru bir yardım metni oyuncunun gerçek sorularını karşılamaz. Burada anlam, açıklık, kesin rakamlar ve eylemlerin gerçek sonuçları önemlidir.

### 20-4. FAQ’den bot içindeki tüm oyuncu yolunu anlayabilir miyim?

Evet. İyi bir FAQ yalnızca tek tek düğmeleri değil, tüm yolu da açıklamalıdır: ilk panelden enerjiye, değişime, bakiyelere, seviyelere, durumlara ve hesabın büyümesine kadar.

### 20-5. Cevabı ilk seferde bulamazsam ne yapmalıyım?

Anlam olarak yakın olan bölümü açıp komşu sorulara bakmak daha iyidir. Büyük bir botta birçok cevap birbiriyle bağlantılıdır ve bir blok çoğu zaman bir sonrakini anlamaya yardımcı olur.

### 20-6. FAQ’yu doğru şekilde nasıl kullanmalıyım?

En iyisi bölüm bölüm ilerlemektir: önce projenin genel mantığını, sonra ekranlarını ve işlemlerini anla; ancak bundan sonra bakiyeler, çekimler, VIP, referanslar, seviyeler ve diğer bot işlevleriyle ilgili özel kurallara bak.

### 20-7. “Her şey bozuk görünüyor” ise neyi kontrol etmeliyim?

Üç şeyi kontrol edin: 1) Wallet — cüzdan bağlı mı ve ana cüzdan seçili mi, 2) bakiyeler ve geçmiş — işlem iziniz orada görünüyor mu, 3) gerekli bölüm (Panels / Energy / Exchange / Withdraw). Çoğu zaman cevap bu yerlerden birinde bulunur.

### 20-8. EFHC’lerime ne olduğunu anlamanın en hızlı yolu nedir?

Bakiye geçmişini açın. Geçmiş, bakiyeleri tam olarak neyin değiştirdiğini gösterir: ödül, iç eylem, değişim veya çekim.

### 20-9. Botu ilk kez açtıysam ve hiçbir şey anlamıyorsam nereden başlamalıyım?

Energy’den (ana ekran) başlayın, ardından Panels bölümünü açın, bakiyeleri ve geçmişi inceleyin ve ancak ondan sonra cüzdan ya da bakiye yüklemesi gerekip gerekmediğine karar verin.

### 20-10. FAQ’de gerekli soruyu en hızlı nasıl bulurum?

En hızlı yol, konuya uygun bölümü açmak (Wallet / Panels / Exchange / Withdraw vb.) ve soruyu orada aramaktır. Emin değilseniz FAQ / Yardım bölümünden başlayın ve anahtar kelimelere göre ilerleyin.
