# EFHC FAQ (EN) — SSOT

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. About the Project

### 1-1. What is EFHC?

EFHC is a game project about energy, progress, and account growth inside the bot. The user activates panels, accumulates energy, exchanges it into EFHC, tracks balances, moves up through levels, climbs the ranking, and uses additional project features.

Definitions:
— EFHC — Energy for Humanity Coin
— EFHCm — main coins
— EFHCb — bonus coins
— EFHCj — external EFHC jetton
— EFHC — total balance (bonus + main)

### 1-2. How does everything work here?

Inside the project, everything is built around energy and account growth. The user works with panels, accumulates energy, exchanges it into main EFHC, tracks balances, connects a wallet, strengthens progress, and uses additional project mechanics.

### 1-3. What am I supposed to do in this bot?

Your main task is to grow your account. To do that, you work with panels, monitor energy generation, use Exchange, review your balances, connect a wallet, participate in additional project mechanics, and gradually strengthen your progress.

### 1-4. How do I grow and move forward here?

Growth inside the bot is built around energy and activity. The more panels, energy, useful actions, and progress the user has, the stronger the account becomes and the higher it rises in the level and rank system.

### 1-5. What is the main idea of the project?

The main idea of the project is to show the path from panel activation to producing energy and then to getting results in EFHC. The user sees not abstract numbers, but a connected path: panel, energy, exchange, balance, progress, levels, and a place among other participants.

### 1-6. Is this just entertainment or is there a development logic here?

There is a full growth logic here. The user does not just press buttons, but gradually strengthens the account: activates panels, starts generation, gets active status, collects bonuses, develops the referral system, and sees the result of that journey.

### 1-7. How do my first EFHC appear here?

The first EFHC come from two main sources: bonus accruals (into bonus coins EFHCb) and energy exchange through Exchange (into main coins EFHCm). The strongest path is panels → energy → exchange → main balance.

### 1-8. Where does my energy come from?

Your energy comes from active panels. While the panels are active, they generate energy, and it accumulates as available energy for exchange.

### 1-9. What affects my growth in the project the most?

What affects growth the most is the number of active panels and their total generation. The second booster is VIP (if you have it), because it affects generation. Tasks, ads, and referrals are useful additions, but not the foundation.

### 1-10. How do I know that I am moving in the right direction?

If three things are growing — generation, available energy, and the main balance after exchange — then you are moving correctly. The fastest way to check is through Energy and the operation history.

## 2. Main Screen

### 2-1. What does the main screen show?

The main screen is the Energy page. It brings together the key elements of the account’s current state: quick actions, progress information, and entry points to important bot sections.

### 2-2. Why do I need the main screen?

It exists so the user can immediately see the most important things about the account and quickly understand the current state, progress, and what can be done next.

### 2-3. What should I look at first?

Start with the top bar, the total balance, the Energy screen, and the available actions. These elements show the account’s current state and the next possible steps the fastest.

### 2-4. Where can I see my current progress?

Your current progress is reflected in the bot sections related to energy, panels, levels, and ranking. They show how the user is moving forward inside the project.

### 2-5. Why is the main screen important every day?

Because this is where you can see the fastest how the account has changed: how much energy you have now, how many active panels there are, how progress is growing, and what next step the user is already ready for.

### 2-6. What is the best way to begin?

First look at the top bar, understand what balances you have, open the Energy page, check the Panels section, and then review the FAQ for the main actions. If a wallet is required for the action you need, the next step is to connect it.

### 2-7. Which buttons on the main screen matter the most?

The main actions are Panels, Exchange, Direct Top Up in the top bar and Hub. Hub shows only the Top Up button.

### 2-8. What should I check on the main screen every day?

Three things: 1) how many active panels you have, 2) your generation speed, and 3) how much available energy has already accumulated for exchange.

### 2-9. Why does the main screen change over time?

Because it reflects the live state of the account. When panels, energy, and operations appear, the screen starts showing more useful data and progress.

### 2-10. How can I tell from the main screen that the account is developing?

When you see growth in hard facts: generation is not zero, energy is accumulating, and after exchange the main balance increases. These are the most honest signs of development.

## 3. Top Bar

### 3-1. What is the top bar?

The top bar is a separate interface element and the main quick information block available on the bot’s key pages.

### 3-2. What is shown in the top bar?

The top bar shows the avatar, name, energy progress level, VIP status, total balance, the Top Up button, and the Hub button.

### 3-3. Why is the top bar important?

Because it helps you instantly see the key facts about your account without unnecessary navigation: who you are, what progress you have, whether you have VIP, how many coins you have in total, and which quick actions are available right now.

### 3-4. What does the total balance in the top bar show?

The total balance shows how many coins you have overall. This is for convenience, so you do not have to add resources manually when planning internal actions and understanding your overall in-game condition.

### 3-5. Why is the total balance convenient for internal actions?

Because it shows the player’s total available internal resources inside the game and helps quickly understand whether there are enough resources for internal actions.

### 3-6. Why is the total balance not equal to what I can withdraw right now?

Because the total balance includes both main and bonus coins. Bonus coins are used for the internal game cycle and are not withdrawn directly.

### 3-7. When should I use the Top Up button in the top bar?

Use it when you want to quickly go to the main balance top-up flow available in the app without opening extra sections manually.

### 3-8. Why open Hub from the top bar?

To quickly open the project’s related action cards and move to the required external flow without extra navigation through the interface.

### 3-9. Why is the top bar visible on different pages?

Because it is the account’s dashboard: it is there so you can always see the most important things (balance, statuses, and quick actions), even when you open another section.

### 3-10. What should I do if the data in the top bar seems incorrect?

First refresh the page and check the balance history: it shows the facts of operations. If the history and the balance match, the data is correct — you may simply have been looking at the wrong balance (for example, total instead of main).

## 4. Profile

### 4-1. What is the Profile section?

Profile is the section where you manage your account and personal interface options. It shows the main statuses and provides access to important account sections.

### 4-2. What can I do in the profile?

The profile contains the main user settings and quick links to important sections: Wallet, balance history, FAQ, and other useful control points.

### 4-3. What is shown at the top of Profile?

The top of Profile shows the avatar, Telegram name, and Activ and VIP statuses if you already have them.

### 4-4. Where can I change the language?

The language is changed in Profile.

### 4-5. Why do I need a profile at all?

The profile is your personal account control point. Here the user not only sees statuses, but also opens important subsections related to the wallet, history, language, and help.

### 4-6. Where do I open the balance history in the profile?

In Profile there is a separate entry to the balance history, where you can see incoming and outgoing operations.

### 4-7. Where do I change the language in the profile?

The language switch is located in Profile because it is a personal account setting.

### 4-8. Where in Profile can I open Wallet to work with the wallet?

In Profile there is a separate Wallet entry. Open it when you need to connect a wallet, check the binding, or move to wallet-related actions.

### 4-9. Where in Profile can I quickly open FAQ if I need an answer?

In Profile there is an entry to FAQ. Open it when you need a quick answer about the interface, balance, panels, energy, exchange, withdrawal, or other WebApp functions.

### 4-10. What is inside the ‘Support and Information’ section?

That section contains help items: FAQ, tips/information, and everything that helps the user understand the project without confusion.

### 4-11. In how many languages is the project interface available?

The bot interface and the FAQ are translated into 13 languages. You can choose the most convenient language in your profile settings, and the system will instantly adapt all texts and interface elements to your choice.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions connected with the project’s external operations: withdrawals, top-ups, proof of address ownership, and other related actions where a linked wallet is required.

### 5-2. Can I change my primary wallet?

Yes. The user can choose another primary wallet from the wallets that are already connected.

### 5-3. Can I remove a linked wallet?

Yes. If the wallet is no longer needed, its link can be removed.

### 5-4. Why can’t the same wallet be linked to two accounts?

The same wallet must not be used in two different accounts at the same time. If a wallet is already linked to one account, it must first be unlinked from that account before it can be linked to another. This prevents confusion in statuses, checks, and wallet-related results.

### 5-5. What happens if I tap an action that requires a wallet and I do not have one?

If the selected function requires a wallet, the bot will first start the wallet connection flow. After that, you can return to the required action and complete it normally.

### 5-6. Can I connect multiple wallets, and why would I need that?

Yes. You can connect multiple wallets so you have a backup address or to separate different usage scenarios. At the same time, one wallet is chosen as primary — it is the one used by default for operations where a selected address is required.

### 5-7. What should I do if I want to use my wallet in another account?

First unlink this wallet from the current account. Only after that can it be linked to another account. The same wallet must not be linked to two accounts at the same time.

### 5-8. Can I withdraw to a non-primary wallet?

By default, the system uses the primary wallet. If you need another address, first make it primary in Wallet and only then submit a withdrawal request.

### 5-9. What should I do if the wallet is connected but withdrawal is still unavailable?

Check three things: whether a primary wallet is selected, whether the main balance is sufficient, and whether the withdrawal amount is at least 10 EFHC.

### 5-10. Where can I check which wallet is currently linked to my account?

Check this in the Wallet section. There the user can see which wallets are linked to the account and which one is currently used within the account.

### 5-11. What should I do if I lose access to my main TON wallet?

Since the project allows you to link multiple wallets, you can link a new wallet in the Wallet section, set it as the main one, and permanently remove the old compromised address from the linked-wallet list.

## 6. Balances and History

### 6-1. Why do I have three different balances?

Because funds inside the bot have different roles. The total balance shows everything together, the bonus balance is used for the internal game cycle, and the main balance shows the result that can already be used for key operations and withdrawals.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. What is the main balance?

The main balance is your main EFHC. This is where the result of the game cycle is converted, and this is the balance from which key operations, including withdrawals, are available.

### 6-4. Why can one internal action affect both the bonus and the main balance?

For all internal project spending, funds are deducted from the bonus balance first. If that is not enough, the remaining amount is deducted from the main balance.

### 6-5. Why are there several entries in the history at once?

One operation can affect several parts of the movement of funds, so the bot shows it in several lines in order to reflect the different changes separately.

### 6-6. Where can I see where EFHC came from or where it went?

For this, use the balance history section. It shows incoming funds, deductions, exchange, internal actions, withdrawals, and other changes in funds.

### 6-7. Why can my total balance be large, but I can withdraw less?

Because the total balance combines the main and bonus balances. Withdrawal is allowed only from the main balance, while the bonus balance is meant for the project’s internal cycle. That is why you need to look specifically at the main balance for withdrawals.

### 6-8. Where can I see fastest what exactly changed my balance?

In the balance history. There you can see which operation caused an incoming amount or a deduction, and which balance was affected.

### 6-9. Why can’t the bonus balance be withdrawn directly?

Because bonus coins are part of the project’s internal cycle. Withdrawal is allowed only from the main balance.

### 6-10. Why doesn’t the history update everywhere in the same way right after a withdrawal or exchange?

Because different screens do not always update at exactly the same moment. Check in this order: refresh the section → check the balance → check the history.

### 6-11. What happens if, with a weak internet connection, I accidentally press the activation or exchange button several times in a row? Will extra coins be deducted?

No. Extra coins will not be deducted. The core of the system has strict protection against double debits. Even if you press the button 10 times because the network is freezing, the operation is guaranteed to be executed exactly once.

## 7. Panels

### 7-1. How much EFHC is required to activate one panel?

100 EFHC is required to activate one panel.

### 7-2. What do I get immediately after activating my first panel?

Activating the first panel immediately starts energy generation, opens the path to progress, creates a path to main EFHC, and grants the permanent active status Activ.

### 7-3. When does panel generation start?

Generation starts immediately after the panel is activated.

### 7-4. What is the lifespan of a panel?

Each panel has a 180-day panel cycle.

### 7-5. What happens to a panel after the 180-day cycle ends?

After the 180-day cycle is completed, the panel is deactivated and moved to Archive as part of the participant’s energy progress history.

### 7-6. What two panel states exist in the interface?

The interface has Activ and Archive. Activ are panels that participate in generation. Archive are panels that have already completed their active cycle and preserve the history of your path.

### 7-7. Can I activate more than one panel at once?

Yes. You can activate panels one after another, increasing the number of active panels. The more active panels you have, the higher the total energy generation and the faster your progress grows.

### 7-8. What does the “Remaining” timer on a panel mean?

The timer shows how much time is left until the end of the panel’s 180-day cycle. When the time runs out, the panel automatically moves to Archive and stops being active.

### 7-9. Why did I become Activ after activating my first panel?

Because Activ confirms real participation and helps protect the project from bots. The project ties Activ to the activation of the first panel so that only real participants receive this status.

### 7-10. Why are active panels more important than archived ones?

Active panels generate energy right now — they determine your current growth pace. Archived panels are completed panels: they preserve history, but they do not provide current generation.

### 7-11. Why do I have fewer active panels than I activated?

Because some of your panels may have completed their 180-day period and moved to Archive. Active panels are the ones that are working now. Archive contains completed panels, and they do not provide current generation.

### 7-12. Can active panels “disappear” because of the 1000 limit?

No. The 1000 limit means that you cannot have more than 1000 active panels at the same time. Active panels you have already activated do not “disappear”: they remain active until the end of their term and then move to Archive.

### 7-13. What should I do if I activated a panel, but generation did not change immediately?

Check the following:
— Refresh the Panels section
— See whether the panel appeared in Active
— Open Energy and check the generation speed
— Check the balance history (there should be a deduction of 100 EFHC)

### 7-14. Can I activate a panel if I have less than 100 EFHC?

No. 100 EFHC is required to activate a panel. If you have less funds, the activation will not go through.

### 7-15. Why are Archive panels important if they no longer generate?

Archive preserves the history of your panels and completed cycles. It is your “growth biography,” but only active panels provide current generation.

### 7-16. Can I activate a panel and immediately see that it is active?

Yes. The activated panel should appear in the Active list, and the activation should also be reflected in the balance history.

### 7-17. How much energy does one panel generate over 180 days?

One panel at the base rate generates 107.61984000 kWh over 180 days. If you have an EFHC VIP NFT, generation is 115.24032000 kWh.

## 8. Energy

### 8-1. What does the Energy page show?

The Energy page shows your energy progress, the energy generation progress bar, the number of active panels, the total generation of panels per second, and other key indicators of the current state.

### 8-2. What does the progress bar on the Energy page show?

The progress bar shows the path to the next player progress level on the 12-level scale.

### 8-3. What does the total generation of panels per second mean?

It is the base or VIP generation constant multiplied by the number of active panels.

### 8-4. Why is energy so important?

Because energy is the central foundation of progress in EFHC. Through energy, the user moves from panels to a result that affects balance, levels, ranking, and overall account development.

### 8-5. Can I tell from Energy how strong my account is?

Yes. The Energy page quickly shows the current strength of the system: how many panels are working, what generation is happening right now, how much energy has already been accumulated, and how far the user has progressed to the next level.

### 8-6. Why are available energy and main balance counted separately?

Because they are two different entities. Available energy shows the accumulated kWh, while the main balance shows the main EFHC already received. These values are connected, but they are not the same thing.

### 8-7. Why does energy grow by itself while the main balance does not increase automatically?

Because energy accumulation and main balance growth happen at different stages. First the panels generate energy, and the main balance increases only after a separate exchange action or another scenario that credits main EFHC.

### 8-8. What does the generation speed per second show?

It shows how fast your active panels are creating energy right now — in other words, your current growth pace.

### 8-9. What is especially important to track in Energy every day?

The number of active panels, the generation speed, and the available energy — these are the three main indicators of your account state.

### 8-10. How can I tell from Energy that my panels are really working?

If Energy shows active panels and non-zero generation, and the available energy is gradually increasing, then the panels are working. If generation is 0 and energy is not accumulating, then there are no active panels or you are looking at the wrong block.

### 8-11. Why can the running energy numbers on the screen sometimes be corrected slightly or jump a little?

For your convenience, the accumulated energy figures are updated on the screen in real time, showing a continuous generation process. However, the server is always the main source of truth. Periodically, and also after each of your actions, the app syncs with the server to ensure absolute mathematical accuracy. At that moment, a micro-correction of the on-screen numbers to the exact server value may occur.

## 9. Exchange

### 9-1. What is Exchange?

Exchange is the section where energy is converted into main EFHC. It is one of the key stages of the user’s path inside the project.

### 9-2. How does energy exchange into EFHC work?

Exchange is the conversion of progress into main EFHC. The accumulated energy is turned into the project’s main coins.

### 9-3. What does the rule 1 kWh = 1 EFHC mean?

This is the project’s fixed internal rate. Each unit of energy is converted into an equal amount of EFHC.

### 9-4. What happens after the exchange?

After the exchange, the energy result appears in the main balance in the form of main EFHC. It is no longer just accumulated energy, but a result that participates in the project’s key operations.

### 9-5. Why is exchange so important?

Because it is through exchange that the user turns accumulated energy into the main result. This is the point where the energy path becomes main EFHC.

### 9-6. Can bonus coins be exchanged directly without energy?

No. Bonus coins first participate in the internal cycle: they are used to activate a panel, the panel generates energy, and only then is the energy exchanged into main EFHC.

### 9-7. Why does the exchange go to the main balance right away and not to the bonus balance?

Because Exchange is the transformation of energy into the main result. The project has a fixed rule: 1 kWh = 1 EFHC, and the exchange result is always credited to the main balance, from which key operations and withdrawals are available.

### 9-8. What should I do if I made an exchange, but I do not see the result right away?

First refresh the Exchange section and check the main balance. Then open the balance history: there should be an exchange record there. If the record is there, the exchange has been completed, even if you did not notice the screen change immediately.

— Refresh the section
— Check the balance
— Check the history

### 9-9. Can I exchange energy and immediately submit a withdrawal request?

Yes, if after the exchange there is enough EFHC in the main balance, the withdrawal amount is not less than 10 EFHC, and the wallet is connected and selected as the main one.

### 9-10. Which is better: exchange often or accumulate first?

That depends on your goal. Frequent exchange is convenient for control and operations, while accumulation is convenient for rare larger steps. The rule remains the same: the exchange result goes to the main balance.

### 9-11. Why does available energy decrease after the exchange?

Because you transfer part of the accumulated energy into EFHC through Exchange. The energy does not disappear — it turns into coins.

Important: the total energy shown on the main Energy screen should not “decrease” as your overall progress and does not reduce your rank or level backward — it reflects your growth path and the total generation result.

### 9-12. Which energy can I already exchange?

You can exchange the energy that has already accumulated and become available. This is what available energy is — the ready amount for action in the Exchange section.

### 9-13. Is there a minimum limit for exchanging energy into main EFHC?

There are no strict limits, but the exchange math follows the rate 1 kWh = 1 EFHC. It is practical to accumulate and exchange whole units of energy starting from 1 kWh so that the result is immediately visible on your main balance.

## 10. Withdraw

### 10-1. Why can’t I withdraw EFHC?

Usually the reason is that there are not enough funds in the main balance, the wallet is not connected, or the amount is below the minimum withdrawal threshold. Start checking with Wallet and the main balance.

### 10-2. How does withdrawal work?

A withdrawal request is created, after which it is processed as quickly as possible by the first available operator.

### 10-3. Why did my balance change immediately after the withdrawal request?

Because the bot immediately accounts for the start of this operation in the system. This is needed so the user can see that the action is already linked to their funds and has been accepted by the system.

### 10-4. Which balance can be used for withdrawal?

Withdrawal is available only from the main balance.

### 10-5. Why is withdrawal available only from the main balance?

Because the main balance is what already belongs to the user as the result of the game process or as internal actiond coins. Bonus coins participate in the internal cycle and are not withdrawn directly.

### 10-6. What is the minimum withdrawal?

The minimum withdrawal amount is 10 EFHC.

### 10-7. How long is a withdrawal request usually processed?

Withdrawal goes through a request and operator processing. If the result is not visible right away, check the request status and the operation history — they reflect the real state. If the request does not change for a long time, it usually helps to refresh the section and check again later.

### 10-8. Can I cancel a withdrawal request?

Yes, if the request has not yet been processed. Cancellation is available for a pending request. After cancellation, check the main balance and the operation history: if funds were held, they are returned back.

### 10-9. Why can a withdrawal request remain “pending”?

Because withdrawal goes through processing. If the request is not changing, check the request status and the operation history, and then refresh the section later.

### 10-10. Where can I see that the request was cancelled?

This is visible in the request status and in the operation history entry. After cancellation, also check the main balance.

### 10-11. Why is the minimum withdrawal exactly 10 EFHC?

Because the project has set a threshold below which requests are not accepted. The minimum is 10 EFHC.

Also, the withdrawal fee is paid by the project, and withdrawing amounts below 10 EFHC is not practical.

### 10-12. Why can withdrawal be unavailable even if I have EFHC?

Because only the main balance counts for withdrawal. If EFHC are in the bonus part of the balance, you cannot submit a withdrawal for them.

### 10-13. What should I do after submitting a withdrawal request?

Check the request status and the operation history — this is where you can see the real status of the request and the movement of funds.

### 10-14. In which token and on which network are withdrawals made?

Withdrawals are made only in EFHC tokens and only on the TON blockchain network (The Open Network). No other withdrawal options exist in the project.

### 10-15. How long does manual withdrawal processing by an operator take?

Withdrawal requests are processed by operators in a live queue. Processing usually takes from a few minutes up to 24 hours depending on network load and the number of requests. You can always cancel an unprocessed request, and the funds will instantly return to your balance.

## 11. Tasks

### 11-1. What do tasks give me?

Tasks give only bonus coins and encourage the player to take part in account activity.

### 11-2. How do I receive a task bonus?

You need to complete the task conditions, after which the bot automatically records the completion and credits the specified bonus.

### 11-3. Why was the task not completed?

This can happen if the conditions have not yet been fully met, the action was not finished all the way, or the result has not updated in the system yet.

### 11-4. Can I do the same task again?

That depends on the task type. Some tasks are one-time only, while others may repeat according to the project logic.

### 11-5. Do all tasks give the same bonus?

No. The bonus amount depends on the specific task and its conditions. But the bonus type here is the same: bonus coins.

### 11-6. Why do I need tasks if there are panels?

Tasks are an additional growth path. They do not replace panels, but help you collect bonus coins that can later be used inside the game cycle.

### 11-7. Why does the task bonus not go to the main balance?

Because tasks give bonus EFHC. This is an internal bonus for the game cycle, so it is credited to the bonus balance.

### 11-8. Why do tasks sometimes end or disappear?

Because tasks may be temporary or limited. If a task is gone, it means it has ended or is not active at the moment.

### 11-9. Where can I see all available tasks?

In the Tasks section. It shows the list of available tasks and their conditions.

### 11-10. Why did the task bonus not appear immediately?

Sometimes the result needs time to update. Check: refresh Tasks → check the bonus balance → check the operation history.

### 11-11. I subscribed to the channel required by a task, but the task is not completing. Why?

Sometimes subscription verification takes time because of caching on Telegram servers. If the bot did not count the subscription instantly, return to the Tasks section after a few minutes and press the check button again.

## 12. Referrals

### 12-1. What are the section names on the Referrals page?

The Referrals page uses the sections Active and Inactive.

### 12-2. What is an active and an inactive referral?

An active referral is a player who has already activated at least one panel and received Activ status. An inactive referral is someone who has not yet entered the game cycle and therefore does not yet qualify for the bonus.

### 12-3. When are referral bonuses credited?

Referral bonuses are checked automatically by the bot. As soon as a player becomes active, the bonus is credited automatically right away.

### 12-4. What does active status do for referrals?

Active status matters for referral logic because the project uses it as part of a real-participation filter and as protection against bots, bot farms, and artificial activity.

### 12-5. How is Activ connected to referrals?

Activ shows that a user is a real participant in the project rather than a bot account. This is important for fair referral-system work and protection against bot farms.

### 12-6. What basic bonus is credited for each active referral?

One bonus of 0.1 EFHCb is credited for each of your direct referrals — only once, when that referral activates their first panel and receives Activ.

### 12-7. Why do I have referrals, but no bonus was credited?

The bonus is credited only after a direct referral activates their first panel. Until then the invitee remains inactive; later panels do not create another referral bonus.

### 12-8. Where is the 0.1 EFHCb for an active referral credited?

The 0.1 EFHCb activation reward for a direct referral is credited once to the bonus balance. Lvl rewards are credited to the same EFHCb bonus balance. The full cycle is 1,000 EFHCb for 10,000 active direct referrals plus 1,411 EFHCb in Lvl rewards, totaling 2,411 EFHCb.

### 12-9. Why is an invited user on the list, but not counted as active?

Because a user becomes active only after activating the first panel and receiving Activ. Until then, that person remains in the inactive part of the list.

### 12-10. Where can I get my referral link?

In the Referrals section. Your referral link and the list of invited users are shown there.

### 12-11. Is it allowed to create additional accounts (multi-accounts) using your own referral link?

Yes. The project rules do not prohibit this. However, creating accounts without real activity will not benefit you. The system economy is designed so that referral bonuses and Ranks progress are credited only for a participant with Activ status — that is, after the invited account actually enters the game and activates at least one panel.

### 12-12. Can I change my inviter (referrer) after registration?

No. The referral link is fixed at the moment of your first entry into the project through an invite link and cannot be changed later.

## 13. Hub

### 13-1. What can I do in Hub?

Hub has two actions: Top Up and EFHC VIP NFT. Details of the external paths appear only after leaving Hub.

### 13-2. What is Hub for?

Hub is a short navigation section for two external project actions.

### 13-3. How many actions are available in Hub?

Exactly two: Top Up and EFHC VIP NFT. Both functions are canonical.

### 13-4. What does the Top Up button do?

It opens the external Web continuation. Products, prices and payment methods are not shown before leaving Hub.

### 13-5. Where is the EFHC top-up credited after confirmation?

An EFHCm top-up is credited to the main balance.

### 13-6. Why might the top-up result not appear instantly?

The external stage of the operation must be confirmed first, after which the result is updated. Check Hub, the main balance, and the operation history.

### 13-7. If I received a VIP NFT through GetGems, where can I see that it is active?

Check the VIP status in the app and the NFT’s presence in the linked wallet.

### 13-8. I completed the external flow from Hub, but there is no result. What should I do?

Check Hub, the main balance, and the operation history. If there is still no result, the operation has not been pulled in yet or requires separate processing.

### 13-9. Which balance receives a top-up through Top Up and Hub?

An EFHCm top-up is credited to the main balance.

### 13-10. Do I need a connected wallet for Hub actions?

A connected Wallet is required for external wallet-based actions. Hub itself opens without a separate internal action and serves as a transition point.

### 13-11. Where can I verify that the EFHC top-up was actually credited?

Check the main balance and the operation history: there should be a trace of the top-up there.

### 13-12. Are there skins in Hub?

Skins are not Hub cards.

### 13-13. How do I get project skins?

Skins unlock as the account progresses and are tied to the 12 achievement levels.

## 14. Navigation and Rules

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Which screens should I open first if I enter the WebApp for the first time or after a long break?

It is best to start with the main screen, the top bar, and the profile. After that, it is easier to move to Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History, and Hub depending on your current task.

### 14-3. How do I understand which section contains the function I need?

Choose the section by the action: Profile for account data, Wallet for wallets, Panels for panels, Energy for generation, Exchange for exchange, Withdraw for withdrawals, Tasks for tasks, Referrals for invitations and Hub for the Top Up transition.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile is the section with account data and entry points to related functions. Wallet is the section for connecting and checking a wallet. History is the record of operations and balance movements.

### 14-8. What should I do if I do not see the needed button or section?

First refresh the screen and check whether another section is open. Then return to the main screen, the top bar, or Profile, and go again to the function according to its purpose.

### 14-9. What should I do if the data on the screen looks outdated or does not match expectations?

First refresh the screen, then open the profile section related to that information. Balances and movements are easier to check in History, panels in Panels, generation in Energy, wallet operations in Wallet, and withdrawal actions in Withdraw.

### 14-10. How can I tell that I am in the wrong section?

Choose the section by the action: Profile for account data, Wallet for wallets, Panels for panels, Energy for generation, Exchange for exchange, Withdraw for withdrawals, Tasks for tasks, Referrals for invitations and Hub for the Top Up transition.

### 14-11. What screen-check order is convenient during a normal daily WebApp entry?

Usually it is convenient to first look at the main screen and the top bar, then open the sections related to the current task: Panels, Energy, History, Tasks, Referrals, Hub, Exchange, or Withdraw. This order helps you quickly understand the current account state and move to the needed action.

### 14-12. Which sections are useful to check regularly even without an urgent task?

It is useful to regularly check the main screen, the top bar, Panels, Energy, History, Tasks, Referrals, and Hub. This helps you notice balance changes, panel activity, and available actions in time.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This reduces mistakes and accidental actions. When a user makes an exchange in Exchange, a withdrawal in Withdraw, and works with panels in Panels, the WebApp logic remains clear and safe.

### 14-14. What signs show that an action is important and requires attention?

Extra attention is needed when an action affects the balance, panels, energy, exchange, withdrawal, wallet linking, operation history, or account status. Before confirming such actions, it is useful to check the screen and the selected button again.

### 14-15. What should I do if a screen changed after a bot update?

Rely on the current section names and their purpose. Visual elements can change, but the logic of the screens must remain understandable and consistent.

### 14-16. Which basic rules help avoid mistakes when working with the WebApp?

It is useful to perform actions only in the proper section, carefully read the screen name and button before confirmation, and when in doubt, first check the profile sections instead of pressing random interface elements.

### 14-17. When should I open the FAQ while working with the WebApp?

The FAQ is useful to open when you need to quickly clarify the meaning of a screen, button, action, or rule for a specific function. This makes it easier to match the question with the right section and avoid unnecessary steps inside the WebApp.

## 15. Ads

### 15-1. What is this section?

The Ads section is a subsection inside Tasks. It shows available advertising actions through which the user can receive additional bonus coins.

### 15-2. What does it give me?

It gives only bonus coins for views, provided advertising is currently available for the user account.

### 15-3. Why is there nothing here?

If the section has no offers yet, there are currently no active offers for the user account or advertising is temporarily disabled.

### 15-4. Where is the Ads section located?

The Ads section is located as a subsection inside Tasks. It is one of the additional options within the tasks block.

### 15-5. What bonus does Ads give?

Ads gives only bonus coins for views. This is not the main balance and not a direct withdrawal, but an additional internal way to strengthen the game path.

### 15-6. Why is Ads useful?

Because it is an additional source of bonus coins. It does not replace panels and generation, but it can help strengthen the internal game cycle faster.

### 15-7. Why do others have ads while I do not?

Because offers may be unavailable for a specific account or advertising may be temporarily disabled. An Ads section without offers does not mean the account is broken.

### 15-8. What should I do if I completed an action in Ads, but there is no result?

Check: refresh Tasks/Ads → check the bonus balance → check the operation history.

### 15-9. Why can different users have different offers in Ads?

Because offers depend on the availability of advertising campaigns for a specific account. This is normal: one user may have offers while another temporarily does not.

### 15-10. Do I need to make a mandatory top-up to use Ads?

No. Ads is a way to get bonus EFHC and does not require mandatory internal actions.

## 16. Ranks

### 16-1. Why does it matter for me to grow in the ranking?

Growth in the ranking shows how your progress looks compared with other participants. It helps you understand your current place and see how actively the account is developing.

### 16-2. How is a level different from a ranking?

A level shows personal progress inside the system, while the ranking shows the user's position among other participants.

### 16-3. How are level and ranking connected?

They are connected by one common growth logic through panel-based kWh generation and the shared progress bar on the Energy page.

### 16-4. Is the ranking just a pretty number?

No. The ranking helps you understand how your path looks compared with other participants.

### 16-5. What affects the growth of my position in the ranking?

The growth of your position in the ranking depends on the overall progress of the account: panel development, kWh generation, and the overall movement along the project’s energy path.

### 16-6. Can I grow in level and ranking at the same time?

Yes. When the user develops panels, generation, and overall energy progress, they usually strengthen both their level and their ranking position.

### 16-7. Why is my level high, but my ranking position is not first?

Because the ranking is your place among all participants, not only your personal progress. Other players are growing too, so your position can change even with a strong level.

### 16-8. Why can my ranking move even without any new actions from me?

Because ranking does not exist by itself; it changes in comparison with all participants. While you do not change anything, other users still keep growing, and that affects your position.

### 16-9. Where can I see my ranking position?

In the Ranks section — your position among other participants is shown there.

### 16-10. Why can my ranking go down even when I am making progress?

Because ranking depends not only on your own growth, but also on how fast other participants are growing. Even if your account is getting stronger, your place can go down when others overtake you faster.

## 17. Activ Status

### 17-1. What does Activ status mean?

Activ is a permanent active status. It means the game has truly begun because at least one panel has been internal actiond.

### 17-2. How do I get Activ?

To get Activ, it is enough to activate one panel. After this internal action, the status is assigned permanently.

### 17-3. Is Activ temporary or permanent?

Activ is a permanent status.

### 17-4. Does Activ remain if a panel later moves to Archive?

Yes. Even if a panel later moves to Archive, Activ status remains.

### 17-5. Why is Activ important?

Activ helps separate real players from random registrations, bots, and bot farms. It confirms the user's real participation in the project.

### 17-6. Can Activ disappear later?

No. Activ is a permanent status and remains even if the first panel later moves to Archive.

### 17-7. Why is Activ needed for protection against bots and bot farms?

Because Activ confirms real participation rather than an account without participation created for artificial boosting. This makes the referral system and the economy fairer.

### 17-8. What changes in the account after getting Activ?

The account is treated as a confirmed live participant of the project. This affects fair referral mechanics and trust in activity.

### 17-9. Why does Activ appear specifically after the first panel?

Because activating the first panel is a clear sign of real participation. The project uses this step as a filter against accounts without participation.

### 17-10. Can I lose Activ because of inactivity?

No. Activ is a permanent status and does not disappear because of inactivity.

## 18. VIP NFT

### 18-1. What is EFHC VIP NFT?

EFHC VIP NFT is a club card, a key to the entire future EFHC ecosystem, a digital sign of belonging, and a key to the project's future opportunities.

### 18-2. What does owning one EFHC VIP NFT give me?

Owning one EFHC VIP NFT gives increased generation for all of the player's panels.

### 18-3. By what signs can I tell that VIP is already taken into account?

If the VIP NFT has already been taken into account by the system, the interface shows VIP status and the related account advantages become noticeable.

### 18-4. Where will I see the VIP effect?

The VIP effect is visible in the sections where the project takes VIP NFT advantages into account, as well as in the top bar and in Profile.

### 18-5. Do I need to enable VIP manually?

No. The project logic is designed for automatic wallet checking and automatic VIP status updates after the NFT is detected in the required collection.

### 18-6. Do 2 or 3 VIP NFTs give extra privileges to the player?

No. For the player, having 2 or 3 VIP NFTs does not provide additional privileges beyond one VIP NFT.

### 18-7. Why doesn't a second VIP NFT increase the effect?

In the project, VIP gives a generation boost as a single active status. Additional VIP NFTs do not provide extra amplification so that the effect does not scale endlessly.

### 18-8. Does VIP affect one panel or all of them?

VIP affects the generation of all the user's panels, not just one specific panel.

### 18-9. How can I check that VIP really affects the account?

Check not only the presence of VIP status, but also the related advantages in the account mechanics, especially where the VIP effect is taken into account, including generation.

### 18-10. Do I need a connected wallet for the bot to see my VIP NFT?

Yes. For the bot to see the VIP NFT, it needs to understand which wallet belongs to the account. That is why Wallet must be connected first, and then you check VIP status in the interface.

### 18-11. Can I manage my VIP NFT at my own discretion?

Yes. EFHC VIP NFT can be transferred, gifted, and sold on marketplaces.

### 18-12. If I sell or transfer my VIP NFT to another wallet, what will happen to my generation?

The bot regularly scans the blockchain and checks for the NFT on your linked wallet. If you sell, gift, or move your VIP NFT to another address, the system will detect it, disable your VIP status, and the generation of all your panels will automatically return to the base rate.

## 19. Levels

### 19-1. Why should I increase my level?

Level growth shows the user's progress inside the project and helps you see how the account is developing. It is both a visual and a meaningful indicator of moving forward.

### 19-2. What does the Levels section include?

The Levels section shows all project growth scales: 12 levels of energy progress, 6 levels of the referral system, and other level-based lines of the project if they are added in the future.

### 19-3. How many energy progress levels are there in the project?

The project includes 12 levels of energy progress.

### 19-4. How many levels are there in the referral system?

The project includes 6 levels of the referral system: from 0 to 5.

### 19-5. How are levels useful for an ordinary player?

Levels help you understand where you are now, how much has already been done, what to move toward next, and what next milestone is waiting ahead.

### 19-6. How are energy levels, referral levels, and overall account growth connected?

They are parts of one common path. Energy generation drives the main progress, active referrals strengthen the referral line, and together they show how strongly the account is developing.

### 19-7. Eco Initiate (0 kWh)

**Meaning for the player:** Your first panel is installed and ready to work. You are taking the main step toward becoming an independent producer of clean energy. This is your starting status — you have just entered the generation path.

**Exact rule:** The Eco Initiate level corresponds to the 0 kWh mark.

**Practical consequence:** The next step is to start generation growth through panels and bring progress to 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Meaning for the player:** The first kilowatts are here. Your panels are successfully producing green energy, giving nature hope for a carbon-free future. You can already see the first real results: energy is flowing and progress has moved.

**Exact rule:** The Hope Bringer level starts at 100 kWh.

**Practical consequence:** The next goal is to build more stability and reach 300 kWh for the next stage.

### 19-9. Energy Seeker (300 kWh)

**Meaning for the player:** The system is working very well, steadily supplying the grid with environmentally clean electricity. Every unit of energy produced by your panels displaces fossil fuel use. The account has entered a mode of stable growth: you are no longer a beginner, but a user with real generation.

**Exact rule:** The Energy Seeker level starts at 300 kWh.

**Practical consequence:** In practice, this is a signal that you can strengthen your panels and use Exchange more often to turn energy into your main balance.

### 19-10. Nature's Voice (600 kWh)

**Meaning for the player:** Your contribution is becoming noticeable. By producing energy with green technologies, you become a voice of nature, proving that progress can be environmentally friendly. Your contribution is more visible now: progress is felt not as an accident, but as a trajectory.

**Exact rule:** The Nature's Voice level starts at 600 kWh.

**Practical consequence:** The next target is 1000 kWh (Earth Ally). It is useful to compare your pace in Energy and the number of active panels.

### 19-11. Earth Ally (1000 kWh)

**Meaning for the player:** The first megawatt-hour has been generated. Your panels have produced an impressive amount of clean energy. Now you are an important participant in the green transition and a true ally of the planet. You have crossed an important milestone: 1000 kWh is already a serious volume of accumulated generation.

**Exact rule:** The Earth Ally level starts at 1000 kWh.

**Practical consequence:** In practice, this is the point where growth becomes predictable: strengthen your panel fleet and keep energy exchange regular.

### 19-12. Climate Fighter (2000 kWh)

**Meaning for the player:** Your generation is making a real impact against climate change. Every kilowatt produced directly reduces the need to burn coal and gas. You are already pushing forward systematically: progress is visible both in your level and in the account's overall dynamics.

**Exact rule:** The Climate Fighter level starts at 2000 kWh.

**Practical consequence:** The next step is to lock in the pace and reach 3500 kWh. Watch generation speed and use VIP if needed.

### 19-13. Green Sentinel (3500 kWh)

**Meaning for the player:** The stable energy flow from your panels stands guard over clean air. You bring tangible benefit to society without leaving a carbon footprint. Your account becomes a sentinel of stable generation: growth is moving confidently.

**Exact rule:** The Green Sentinel level starts at 3500 kWh.

**Practical consequence:** In practice, this means your panels are already working as a system — keep active panels running and plan growth toward 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Meaning for the player:** 5000 kWh of clean generation. The power of your panels works like an invisible shield, protecting the atmosphere from thousands of kilograms of greenhouse gas emissions. 5000 kWh is a major sign of scale: you are already in the zone of strong energy participants.

**Exact rule:** The Planet Defender level starts at 5000 kWh.

**Practical consequence:** The next target is 7500 kWh. At this point, players often strengthen both their panels and their referral network.

### 19-15. Eco Champion (7500 kWh)

**Meaning for the player:** Outstanding production volumes. You are a true champion of green energy, and your contribution is noticeably changing the global energy balance for the better. This is the level of those who consistently maintain a high pace of generation.

**Exact rule:** The Eco Champion level starts at 7500 kWh.

**Practical consequence:** In practice: keep discipline — active panels, regular Exchange, and control over history and balances.

### 19-16. Planet Saver (10000 kWh)

**Meaning for the player:** 10 megawatt-hours. You have generated so much clean energy that you are literally helping save entire ecosystems, proving the maximum efficiency of your panels. 10,000 kWh is already ten megawatt-hours of generation — a very strong stage of progress.

**Exact rule:** The Planet Saver level starts at 10000 kWh.

**Practical consequence:** The next step is 15000 kWh. At this stage, it makes sense to optimize everything: panels, VIP, referrals, and internal actions.

### 19-17. Green Commander (15000 kWh)

**Meaning for the player:** The flagship of eco-friendly generation. Your panels power the future, and the impressive production volumes set completely new, high standards for the entire community. You are close to the top: this is a leadership-scale level in energy.

**Exact rule:** The Green Commander level starts at 15000 kWh.

**Practical consequence:** In practice: maintain stability and grow to 20000+ kWh while watching active panels and your pace in Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. After producing more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Referral level 0

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 0 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-20. Referral level 1

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 1 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-21. Referral level 2

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 10 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-22. Referral level 3

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 100 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-23. Referral level 4

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 300 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-24. Referral level 5

**Meaning for the player:** This is a marker of your growth in the referral system — it shows the scale of active invited users.

**Exact rule:** A one-time bonus is credited for reaching this level: 1000 EFHCb.

**Practical consequence:** In practice: after reaching the level, check your bonus balance and operation history to see the accrual.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Why are the level names connected with ecology and the planet?

Because the core idea of the game is tied to virtual green energy, motivating people, and making a symbolic contribution to the recovery of planet Earth.

## 20. FAQ / Help

### 20-1. Where can I open the FAQ?

The FAQ is opened from the profile as the bot's built-in help section, where answers about the main actions, screens, and project rules are collected.

### 20-2. What is FAQ / Help for?

This section exists so the user can quickly find clear answers, exact figures, real project rules, and the meaning of the main actions without guesswork or confusion.

### 20-3. Why is the FAQ written in such detail?

Because the project is multi-layered, and a short dry reference does not cover a player's real questions. Meaning, clarity, exact figures, and real consequences of actions matter here.

### 20-4. Can the FAQ help me understand the entire player journey inside the bot?

Yes. A good FAQ should explain not only separate buttons, but the whole path: from the first panel to energy, exchange, balances, levels, statuses, and account growth.

### 20-5. What should I do if I didn't find the answer the first time?

It is better to open a nearby section by meaning and look at neighboring questions. In a large bot, many answers are connected, and one block often helps you understand the next one.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. What should I check if everything looks broken?

Check three things: 1) Wallet — is the wallet connected and is the main wallet selected, 2) balances and history — is there a trace of your operation there, 3) the required section (Panels / Energy / Exchange / Withdraw). Usually the answer is in one of these places.

### 20-8. What is the fastest way to understand what happened to my EFHC?

Open the balance history. The history shows what exactly changed the balances: a bonus accrual, a internal action, an exchange, or a withdrawal.

### 20-9. Where should I start if I opened the bot for the first time and understand nothing?

Start with Energy (the main screen), then open Panels, look at balances and history, and only after that decide whether you need a wallet and a top-up.

### 20-10. What is the fastest way to find the needed question in the FAQ?

The fastest way is to open the relevant section by topic (Wallet / Panels / Exchange / Withdraw, and so on) and look for the question there. If you are not sure, start with the FAQ / Help section and navigate by keywords.
