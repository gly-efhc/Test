# EFHC FAQ (ES) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. Sobre el proyecto

### 1-1. ¿Qué es EFHC?

EFHC es un proyecto de juego sobre energía, progreso y desarrollo de la cuenta dentro del bot. El usuario compra paneles, acumula energía, la intercambia por EFHC, sigue sus saldos, sube de nivel, avanza en el ranking y utiliza funciones adicionales del proyecto.

Significado:
— EFHC — Energy for Humanity Coin
— EFHCm — monedas principales
— EFHCb — monedas de bonificación
— EFHCj — jetton externo de EFHC
— EFHC — saldo total (bonificación + principal)

### 1-2. ¿Cómo funciona esto aquí?

Dentro del proyecto, el conjunto el sistema se construye alrededor de la energía y del crecimiento de la cuenta. El usuario trabaja con paneles, acumula energía, la intercambia por EFHC principales, sigue sus saldos, conecta la wallet, refuerza su progreso y utiliza los mecanismos adicionales del sistema.

La lógica central es sencilla: paneles → generación de energía → intercambio → EFHC → crecimiento de la cuenta.

### 1-3. ¿Qué debo hacer en este bot?

La tarea principal es desarrollar tu cuenta. Para ello el usuario trabaja con paneles, sigue la generación de energía, usa el intercambio, revisa sus saldos, conecta la wallet, participa en los mecanismos adicionales del proyecto y fortalece gradualmente su progreso dentro del sistema.

### 1-4. ¿Cómo crecer y avanzar aquí?

El crecimiento dentro del bot se construye alrededor de la energía y la actividad. Cuantos más paneles, energía, acciones útiles y progreso tenga el usuario, más fuerte se desarrolla la cuenta y más arriba sube en el sistema de niveles y rangos.

### 1-5. ¿Cuál es el sentido principal del proyecto?

El sentido principal del proyecto es mostrar el camino desde la compra de un panel hasta la generación de energía, y luego hasta el resultado en EFHC. El usuario no ve cifras abstractas, sino una cadena conectada: panel, energía, intercambio, saldo, progreso, niveles y posición entre los demás participantes.

### 1-6. ¿Es solo entretenimiento o aquí hay una lógica de desarrollo?

Aquí hay una lógica real de crecimiento. El usuario no solo pulsa botones, sino que fortalece poco a poco su cuenta: compra paneles, lanza la generación, obtiene el estado Activ, recoge recompensas, desarrolla el sistema de referidos y ve el resultado de sus acciones.

### 1-7. ¿Cómo aparecen aquí mis primeros EFHC?

Los primeros EFHC aparecen desde dos fuentes principales: recompensas (en monedas bonus EFHCb) y el intercambio de energía a través de Exchange (en monedas principales EFHCm). La ruta más fuerte es: paneles → energía → intercambio → saldo principal.

### 1-8. ¿De dónde sale mi energía?

La energía la producen tus paneles activos. Mientras los paneles estén activos, generan energía, y esta se acumula como energía disponible para el intercambio.

### 1-9. ¿Qué influye más en mi crecimiento dentro del proyecto?

Lo que más influye en el crecimiento es la cantidad de paneles activos y su generación total. El segundo acelerador es el VIP, si lo tienes, porque afecta a la generación. Las tareas, la publicidad y los referidos son un complemento útil, pero no la base.

### 1-10. ¿Cómo entender que voy por el camino correcto?

Si crecen tres cosas — la generación, la energía disponible y el saldo principal después del intercambio — vas por el camino correcto. La forma más rápida de comprobarlo es en Energy y en el historial de operaciones.

## 2. Pantalla principal

### 2-1. ¿Qué muestra la pantalla principal?

La pantalla principal es la página Energy. Reúne los elementos básicos del estado actual de la cuenta: acciones rápidas, información sobre el progreso y puntos de entrada a las secciones importantes del bot.

### 2-2. ¿Para qué sirve la pantalla principal?

Sirve para que el usuario vea de inmediato lo más importante de su cuenta y entienda rápidamente el estado actual, el progreso y lo que puede hacer después.

### 2-3. ¿Qué debo mirar primero?

Primero conviene mirar la barra superior, el saldo total, la pantalla Energy y las acciones disponibles. Precisamente ellos muestran más rápido el estado actual de la cuenta y lo que se puede hacer a continuación.

### 2-4. ¿Dónde se ve mi progreso actual?

El progreso actual se refleja en las secciones del bot relacionadas con la energía, los paneles, los niveles y el ranking. Allí se ve cómo avanza el usuario dentro del proyecto.

### 2-5. ¿Por qué la pantalla principal es importante cada día?

Porque precisamente aquí se ve más rápido cómo ha cambiado la cuenta: cuánta energía hay ahora, cuántos paneles activos tienes, cómo crece el progreso y para qué siguiente paso ya estás preparado.

### 2-6. ¿Con qué es mejor empezar?

Primero conviene mirar la barra superior, entender cuáles son tus saldos, abrir la página Energy, revisar la sección Panels y luego estudiar el FAQ sobre las acciones principales. Si para la acción necesaria se requiere una wallet, el siguiente paso será conectarla.

### 2-7. ¿Qué botones de la pantalla principal son los más importantes?

Los más importantes son los que llevan a las acciones clave: Panels y Exchange, así como los botones rápidos de la barra superior — Top Up y Hub — si quiere abrir acciones relacionadas con EFHC y VIP.

### 2-8. ¿Qué debo comprobar cada día en la pantalla principal?

Tres cosas: 1) cuántos paneles activos hay, 2) la velocidad de generación,
3) cuánta energía disponible ya se ha acumulado para el intercambio.

### 2-9. ¿Por qué la pantalla principal cambia con el tiempo?

Porque refleja el estado vivo de la cuenta. Cuando aparecen paneles, energía y operaciones, la pantalla deja de estar vacía y empieza a mostrar más datos útiles y más progreso.

### 2-10. ¿Cómo entender por la pantalla principal que la cuenta se está desarrollando?

Cuando ves crecimiento en hechos: la generación no es cero, la energía se acumula y después del intercambio aumenta el saldo principal. Esas son las señales más honestas de desarrollo.

## 3. Barra superior

### 3-1. ¿Qué es la barra superior?

La barra superior es un elemento independiente de la interfaz y el principal bloque informativo rápido que está disponible en las páginas principales del bot.

### 3-2. ¿Qué se muestra en la barra superior?

En la barra superior se muestran el avatar, el nombre, el nivel de progreso energético, el estado VIP, el balance total, el botón Top Up y el botón Hub.

### 3-3. ¿Por qué es importante la barra superior?

Porque ayuda a ver de inmediato lo principal sobre la cuenta sin pasos innecesarios: quién eres, cuál es tu progreso, si tienes VIP, cuántas monedas tienes en total y qué acciones rápidas están disponibles ahora mismo.

### 3-4. ¿Qué muestra el saldo total en la barra superior?

El saldo total muestra cuántas monedas tienes en conjunto. Esto es cómodo para no tener que sumar manualmente los recursos para las compras y para entender el estado general dentro del juego.

### 3-5. ¿Por qué el saldo total es cómodo para las compras?

Porque muestra el poder de compra total del jugador dentro del juego y ayuda a entender rápidamente si los recursos alcanzan para las acciones internas.

### 3-6. ¿Por qué el saldo total no es igual a lo que puedo retirar ahora mismo?

Porque el saldo total incluye tanto las monedas principales como las de bonificación. Las monedas de bonificación se necesitan para la mecánica del juego y no se retiran directamente.

### 3-7. ¿Cuándo conviene usar el botón «Recargar» de la barra superior?

Úselo cuando quiera ir rápidamente al escenario de recarga del saldo principal disponible en la aplicación, sin abrir secciones extra manualmente.

### 3-8. ¿Por qué abrir Hub desde la barra superior?

Para abrir rápidamente las tarjetas de acciones relacionadas del proyecto y pasar al flujo externo necesario sin navegación extra por la interfaz.

### 3-9. ¿Por qué la barra superior se ve en distintas páginas?

Porque es el “panel de control” de la cuenta: permite ver siempre lo principal —saldo, estados y acciones rápidas— incluso cuando abres otra sección.

### 3-10. ¿Qué hacer si los datos de la barra superior parecen incorrectos?

Primero actualiza la página y revisa el historial de saldos: allí se muestran los hechos de las operaciones. Si el historial y el saldo coinciden, los datos son correctos; puede que simplemente hayas mirado el saldo equivocado, por ejemplo el total en lugar del principal.

## 4. Perfil

### 4-1. ¿Qué es la sección Perfil/Ajustes?

Perfil/Ajustes es la sección donde se gestiona el perfil y los parámetros del bot. Aquí se muestran los estados principales y están disponibles las configuraciones personales de la interfaz.

### 4-2. ¿Qué se puede hacer en el perfil?

En el perfil se reúnen los ajustes principales del usuario y los accesos rápidos a secciones importantes: Wallet, historial de saldos, FAQ y otros puntos útiles de control.

### 4-3. ¿Qué se muestra en la parte superior de Perfil/Ajustes?

En la parte superior de Perfil/Ajustes se muestran el avatar, el nombre de Telegram y los estados Activ y VIP, si ya están disponibles.

### 4-4. ¿Dónde cambiar el idioma?

El idioma se cambia en Perfil/Ajustes.

### 4-5. ¿Para qué sirve el perfil en general?

El perfil sirve como punto personal de control de la cuenta. Aquí el usuario no solo ve los estados, sino que también abre subsecciones importantes relacionadas con la wallet, el historial, el idioma y la ayuda.

### 4-6. ¿Dónde abrir el historial de saldos en el perfil?

En la sección Perfil/Ajustes hay un acceso separado al historial de saldos, donde se ven los ingresos y los cargos.

### 4-7. ¿Dónde cambiar el idioma en el perfil?

La opción para cambiar el idioma está en Perfil/Ajustes, porque es una configuración personal de la cuenta.

### 4-8. ¿Dónde abrir Wallet en Perfil para trabajar con la billetera?

En la sección Perfil hay una entrada independiente a Wallet. Ábrala cuando necesite conectar una billetera, comprobar la vinculación o pasar a acciones relacionadas con la billetera.

### 4-9. ¿Dónde abrir rápidamente FAQ en Perfil si necesito una respuesta?

En la sección Perfil hay acceso a FAQ. Ábralo cuando necesite una respuesta rápida sobre la interfaz, el balance, los paneles, la energía, el exchange, el withdrawal u otras funciones del WebApp.

### 4-10. ¿Qué hay en la sección «Soporte e información»?

Allí se reúnen los puntos de ayuda: FAQ, consejos/información y cada elemento que ayuda al usuario a entender el proyecto sin confusión.

### 4-11. ¿En cuántos idiomas está disponible la interfaz del proyecto?

La interfaz del bot y el sistema de ayuda (FAQ) están traducidos a 13 idiomas. Puedes elegir el idioma que te resulte más cómodo en la configuración del perfil, y el sistema adaptará al instante todos los textos y la interfaz a tu elección.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. ¿Se puede cambiar la wallet principal?

Sí. El usuario puede elegir otra wallet principal entre las ya vinculadas.

### 5-3. ¿Se puede eliminar una wallet vinculada?

Sí. Si la wallet ya no es necesaria, su vinculación se puede eliminar.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. ¿Qué pasará si pulso una acción que requiere wallet y no la tengo?

Si la función elegida requiere una wallet, el bot primero iniciará la lógica de conexión de la wallet. Después podrás volver a la acción necesaria y completarla normalmente.

### 5-6. ¿Se pueden conectar varias wallets y para qué sirve eso?

Sí. Se pueden conectar varias wallets para tener una dirección de respaldo o para separar distintos escenarios de uso. Al mismo tiempo, una wallet se elige como principal: precisamente ella se usa por defecto en las operaciones donde se necesita una dirección seleccionada.

### 5-7. ¿Qué pasará si cambio la wallet principal?

Podrás elegir otra wallet como principal. Después del cambio, el sistema usará la nueva dirección principal para las operaciones donde sea necesaria. Antes de retirar o comprar, conviene revisar una vez cuál wallet está marcada ahora como principal.

### 5-8. ¿Se puede retirar a una wallet que no sea la principal?

Por defecto, el sistema se orienta a la wallet principal. Si necesitas otra dirección, primero conviértela en principal en Wallet y solo después envía la solicitud de retiro.

### 5-9. ¿Qué hacer si la wallet está conectada pero el retiro sigue sin estar disponible?

Comprueba tres cosas: si la wallet principal está seleccionada, si hay saldo principal suficiente y si el importe del retiro no es inferior a 10 EFHC.

### 5-10. ¿Se puede jugar y desarrollarse si la wallet aún no está conectada?

Sí. La wallet es necesaria para algunas operaciones, por ejemplo el retiro, pero puedes desarrollar la cuenta, familiarizarte con la interfaz y acumular progreso incluso sin conectarla todavía.

### 5-11. ¿Qué debo hacer si pierdo el acceso a mi billetera principal de TON?

Como el proyecto permite vincular varias billeteras, puedes vincular una nueva en la sección Wallet, establecerla como principal y eliminar para siempre la dirección antigua comprometida de la lista de billeteras vinculadas.

## 6. Saldos e historial

### 6-1. ¿Por qué tengo tres saldos diferentes?

Porque dentro del bot los fondos cumplen funciones distintas. El saldo total muestra el conjunto completo, el saldo de bonificación se usa para el ciclo interno del juego y el saldo principal muestra el resultado que ya puede utilizarse para operaciones clave y retiros.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. ¿Qué es el saldo principal?

El saldo principal son los EFHC principales. Es ahí donde se convierte el resultado del ciclo del juego y es desde ahí desde donde están disponibles las operaciones clave, incluido el retiro.

### 6-4. ¿Por qué una sola compra puede afectar tanto al saldo de bonificación como al saldo principal?

En todos los gastos internos del proyecto, los fondos se descuentan primero del saldo de bonos. Si no alcanza, el resto se descuenta del saldo principal.

### 6-5. ¿Por qué en el historial aparecen varias entradas a la vez?

Una sola operación puede afectar a varias partes del movimiento de fondos, por eso el bot la muestra en varias líneas para reflejar por separado los distintos cambios.

### 6-6. ¿Dónde puedo ver a dónde llegaron o de dónde salieron los EFHC?

Para eso existe la sección del historial de saldo. Muestra ingresos, cargos, intercambios, compras, retiros y otros cambios en los fondos.

### 6-7. ¿Por qué mi saldo total puede ser grande, pero puedo retirar menos?

Porque el saldo total suma el saldo principal y el de bonificación. El retiro solo está permitido desde el saldo principal, mientras que el saldo de bonificación está destinado al ciclo interno del proyecto. Por eso, para retirar, debes mirar precisamente el saldo principal.

### 6-8. ¿Dónde se ve más rápido qué cambió exactamente mi saldo?

En el historial de saldo. Allí se ve qué operación generó un ingreso o un cargo y qué saldo resultó afectado.

### 6-9. ¿Por qué el saldo de bonificación no se puede retirar directamente?

Porque las monedas de bonificación forman parte del ciclo interno del proyecto. El retiro solo está permitido desde el saldo principal.

### 6-10. ¿Por qué después de un retiro o un intercambio el historial no cambia de inmediato igual en todas partes?

Porque las distintas pantallas no siempre se actualizan al mismo tiempo. Comprueba: actualizar la sección → revisar el saldo → revisar el historial.

### 6-11. ¿Qué pasará si, con mala conexión, pulso por accidente varias veces seguidas el botón de compra o intercambio? ¿Se descontarán monedas extra?

No. No se descontarán monedas extra. El núcleo del sistema tiene una protección estricta contra débitos duplicados. Incluso si pulsas el botón 10 veces por un bloqueo de la red, la operación se ejecutará exactamente una sola vez.

## 7. Panels

### 7-1. ¿Cuántos EFHC se necesitan para activar un panel?

Se necesitan 100 EFHC para activar un panel.

### 7-2. ¿Qué aporta inmediatamente la activación del primer panel?

La activación del primer panel inicia de inmediato la generación de energía, abre el camino al progreso, crea la ruta hacia los EFHC principales y otorga el estado activo permanente Activ.

### 7-3. ¿Cuándo empieza la generación del panel?

La generación comienza inmediatamente después de activar el panel.

### 7-4. ¿Cuál es la vida útil de un panel?

Cada panel tiene un ciclo de 180 días.

### 7-5. ¿Qué ocurre con el panel al finalizar el ciclo de 180 días?

Al finalizar el ciclo de 180 días, el panel se desactiva y pasa a Archive para conservar la memoria del progreso energético del participante.

### 7-6. ¿Qué dos estados de paneles existen en la interfaz?

En la interfaz existen Activ y Archive. Activ son los paneles que participan en la generación. Archive son los paneles que ya completaron su ciclo activo y conservan la historia del recorrido.

### 7-7. ¿Se puede activar más de un panel a la vez?

Sí. Puedes activar paneles de forma consecutiva, aumentando la cantidad de paneles activos. Cuantos más paneles activos haya, mayor será la generación total de energía y más rápido crecerá tu progreso.

### 7-8. ¿Qué significa el temporizador «Queda» en el panel?

El temporizador muestra cuánto tiempo queda hasta el final del ciclo de 180 días del panel. Cuando el tiempo termine, el panel pasará automáticamente a Archive y dejará de estar activo.

### 7-9. ¿Por qué después de activar el primer panel pasé a ser Activ?

Porque Activ es la confirmación de una participación real y la protección del proyecto frente a bots. El proyecto vincula Activ a la activación del primer panel para que solo los participantes reales obtengan este estado.

### 7-10. ¿Por qué los paneles activos son más importantes que los archivados?

Los paneles activos generan energía ahora mismo; precisamente ellos marcan tu ritmo de crecimiento actual. Los paneles archivados son paneles ya completados: conservan la historia, pero no aportan generación actual.

### 7-11. ¿Por qué tengo menos paneles activos de los que activé?

Porque una parte de los paneles pudo haber completado su periodo de 180 días y pasado a Archive. Los paneles activos son los que funcionan ahora. Archive contiene los paneles finalizados, y estos ya no aportan generación actual.

### 7-12. ¿Pueden los paneles activos «desaparecer» por el límite de 1000?

No. El límite de 1000 significa que no se pueden tener más de 1000 paneles activos al mismo tiempo. Los paneles activos ya activados no «desaparecen»: permanecen activos hasta el final de su plazo y luego pasan a Archive.

### 7-13. ¿Qué debo hacer si activé un panel pero la generación no cambió inmediatamente?

Comprueba:
— Actualizar la sección Panels
— Ver si el panel apareció en Active
— Abrir Energy y comprobar la velocidad de generación
— Revisar el historial de saldo (debe aparecer el cargo de 100 EFHC)

### 7-14. ¿Se puede activar un panel si tengo menos de 100 EFHC?

No. Se necesitan 100 EFHC para activar un panel. Si tienes menos fondos, la compra no se realizará.

### 7-15. ¿Por qué son importantes los paneles de Archive si ya no generan?

Archive conserva la historia de tus paneles y de los ciclos completados. Es tu «biografía de crecimiento», pero la generación actual solo la proporcionan los paneles activos.

### 7-16. ¿Se puede activar un panel y ver de inmediato que está activo?

Sí. El panel activado debe aparecer en la lista Active, y su compra se refleja en el historial de saldo.

### 7-17. ¿Cuánta energía genera un panel en 180 días?

Un panel a la tasa base genera 107.61984000 kWh en 180 días. Con EFHC VIP NFT, la generación es de 115.24032000 kWh.

## 8. Energy

### 8-1. ¿Qué muestra la página Energy?

La página Energy muestra el progreso energético, la barra de progreso de generación de energía, la cantidad de paneles activos, la generación total de los paneles por segundo y otros indicadores clave del estado actual.

### 8-2. ¿Qué muestra la barra de progreso en la página Energy?

La barra de progreso muestra el camino hacia el siguiente nivel de progreso del jugador dentro de la escala de 12 niveles.

### 8-3. ¿Qué significa la generación total de los paneles por segundo?

Es la constante base o VIP de generación multiplicada por la cantidad de paneles activos.

### 8-4. ¿Por qué la energía es tan importante?

Porque la energía es la base central del progreso en EFHC. A través de ella, el usuario pasa de los paneles al resultado que afecta al saldo, a los niveles, al ranking y al desarrollo de la cuenta.

### 8-5. ¿Se puede entender por Energy qué tan fuerte es una cuenta?

Sí. La página Energy muestra rápidamente la fuerza actual del sistema: cuántos paneles están trabajando, qué generación se produce ahora mismo, cuánta energía ya se ha acumulado y cuánto ha avanzado el usuario hacia el siguiente nivel.

### 8-6. ¿Por qué la energía disponible y el saldo principal se cuentan por separado?

Porque son dos entidades distintas. La energía disponible muestra los kWh acumulados, mientras que el saldo principal muestra los EFHC principales ya recibidos. Estos valores están relacionados, pero no son la misma magnitud.

### 8-7. ¿Por qué la energía crece sola, pero el saldo principal no aumenta automáticamente?

Porque la acumulación de energía y el aumento del saldo principal ocurren en etapas diferentes. Primero los paneles generan energía, y el saldo principal solo aumenta después de una acción de intercambio separada u otro escenario de acreditación de EFHC principales.

### 8-8. ¿Qué muestra la velocidad de generación por segundo?

Es el indicador de la rapidez con la que tus paneles activos crean energía ahora mismo, es decir, tu ritmo de crecimiento actual.

### 8-9. ¿Qué es especialmente importante vigilar en Energy cada día?

La cantidad de paneles activos, la velocidad de generación y la energía disponible: esos son los tres principales indicadores del estado de la cuenta.

### 8-10. ¿Cómo entender por Energy que mis paneles realmente funcionan?

Si en Energy se ven paneles activos y una generación distinta de cero, y la energía disponible crece poco a poco, los paneles están funcionando. Si la generación es 0 y la energía no se acumula, no hay paneles activos o estás mirando el bloque equivocado.

### 8-11. ¿Por qué las cifras de energía en movimiento de la pantalla a veces pueden corregirse un poco o dar un salto?

Para tu comodidad, las cifras de energía acumulada se actualizan en tiempo real en la pantalla, mostrando un proceso continuo de generación. Sin embargo, la fuente principal de verdad siempre es el servidor. Periódicamente, y también después de cada una de tus acciones, la aplicación se sincroniza con el servidor para garantizar una precisión matemática absoluta. En ese momento puede producirse una microcorrección de las cifras en pantalla al valor exacto del servidor.

## 9. Exchange

### 9-1. ¿Qué es Exchange?

Exchange es la sección donde la energía se convierte en EFHC principales. Es una de las etapas clave del recorrido del usuario dentro del proyecto.

### 9-2. ¿Cómo funciona el intercambio de energía por EFHC?

El intercambio es la conversión del progreso en EFHC principales. La energía acumulada se transforma en las monedas principales del proyecto.

### 9-3. ¿Qué significa la regla 1 kWh = 1 EFHC?

Es la tasa interna fija del proyecto. Cada unidad de energía se convierte en la misma cantidad de EFHC.

### 9-4. ¿Qué ocurre después del intercambio?

Después del intercambio, el resultado de la energía aparece en el saldo principal en forma de EFHC principales. Ya no es solo energía acumulada, sino un resultado que participa en las operaciones clave del proyecto.

### 9-5. ¿Por qué es tan importante el intercambio?

Porque precisamente a través del intercambio el usuario convierte la energía acumulada en resultado principal. Es el punto donde el recorrido energético se transforma en EFHC principales.

### 9-6. ¿Se pueden intercambiar directamente las monedas de bonificación sin energía?

No. Las monedas de bonificación primero participan en el ciclo interno: con ellas se compra un panel, el panel genera energía y solo después la energía se intercambia por EFHC principales.

### 9-7. ¿Por qué el intercambio entra directamente en el saldo principal y no en el de bonificación?

Porque Exchange es la transformación de la energía en el resultado principal. En el proyecto está fijada la regla 1 kWh = 1 EFHC, y el resultado del intercambio siempre se acredita al saldo principal, desde el cual están disponibles las operaciones clave y el retiro.

### 9-8. ¿Qué debo hacer si hice un intercambio pero no veo el resultado de inmediato?

Primero actualiza la sección Exchange y revisa el saldo principal. Luego abre el historial de saldo: allí debe aparecer una entrada sobre el intercambio. Si la entrada existe, el intercambio se ha realizado, aunque no hayas notado enseguida el cambio en la pantalla.

— Actualizar la sección
— Revisar el saldo
— Revisar el historial

### 9-9. ¿Se puede intercambiar energía y solicitar el retiro inmediatamente?

Sí, si después del intercambio hay suficientes EFHC en el saldo principal, la cantidad a retirar no es inferior a 10 EFHC y la wallet está conectada y seleccionada como principal.

### 9-10. ¿Qué es mejor: intercambiar con frecuencia o acumular?

Depende de tu objetivo. El intercambio frecuente es cómodo para el control y las operaciones; acumular es cómodo para pasos grandes y poco frecuentes. La regla es una: el resultado del intercambio va al saldo principal.

### 9-11. ¿Por qué después del intercambio disminuye la energía disponible?

Porque transfieres parte de la energía acumulada a EFHC a través de Exchange. La energía no desaparece: se convierte en monedas.

Importante: la cantidad de energía en la pantalla principal de Energy no debe «disminuir» como tu progreso general y no afecta hacia atrás al ranking ni al nivel; refleja tu camino de crecimiento y el resultado total de la generación.

### 9-12. ¿Qué energía ya puedo intercambiar?

Se puede intercambiar la energía que ya se ha acumulado y se ha vuelto disponible. Esa es precisamente la energía disponible: el volumen listo para actuar en la sección Exchange.

### 9-13. ¿Existe un límite mínimo para intercambiar energía por EFHC principales?

No hay límites estrictos, pero la lógica del intercambio sigue la tasa 1 kWh = 1 EFHC. Es razonable acumular e intercambiar valores enteros de energía desde 1 kWh para que el resultado se vea de inmediato en el saldo principal.

## 10. Withdraw

### 10-1. ¿Por qué no puedo retirar EFHC?

Normalmente la razón es que no hay suficientes fondos en el saldo principal, la wallet no está conectada o la cantidad es inferior al umbral mínimo de retiro. La comprobación debe comenzar por Wallet y por el saldo principal.

### 10-2. ¿Cómo se realiza el retiro?

Se crea una solicitud de retiro y después es procesada lo más rápido posible por el primer operador disponible.

### 10-3. ¿Por qué después de la solicitud de retiro el saldo cambió de inmediato?

Porque el bot registra inmediatamente el inicio de esta operación en el sistema. Esto es necesario para que el usuario vea que la acción ya está vinculada a sus fondos y ha sido aceptada por el sistema.

### 10-4. ¿Desde qué balance se puede hacer un withdrawal?

El withdrawal solo está disponible desde el balance principal.

### 10-5. ¿Por qué el retiro solo está disponible desde el saldo principal?

Porque el saldo principal es lo que ya pertenece al usuario como resultado del proceso del juego o como monedas compradas. Las monedas de bonificación participan en el ciclo interno y no se retiran directamente.

### 10-6. ¿Cuál es el retiro mínimo?

La cantidad mínima de retiro es de 10 EFHC.

### 10-7. ¿Cuánto tiempo suele tardar en procesarse una solicitud de retiro?

El retiro pasa por una solicitud y por el procesamiento de un operador. Si el resultado no se ve de inmediato, revisa el estado de la solicitud y el historial de operaciones: allí se refleja la situación real. Si la solicitud tarda mucho en cambiar, normalmente ayuda actualizar la sección y revisar de nuevo más tarde.

### 10-8. ¿Se puede cancelar una solicitud de retiro?

Sí, si la solicitud todavía no ha sido procesada. La cancelación está disponible para una solicitud pendiente. Después de cancelarla, revisa el saldo principal y el historial de operaciones: si los fondos fueron retenidos, se devuelven de nuevo.

### 10-9. ¿Por qué una solicitud de retiro puede quedarse «pendiente»?

Porque el retiro pasa por procesamiento. Si la solicitud no cambia, revisa el estado de la solicitud y el historial de operaciones, y después vuelve a actualizar la sección más tarde.

### 10-10. ¿Dónde veo que la solicitud fue cancelada?

Esto se ve por el estado de la solicitud y por la entrada en el historial de operaciones. Después de la cancelación, revisa también el saldo principal.

### 10-11. ¿Por qué el retiro mínimo es precisamente de 10 EFHC?

Porque en el proyecto está establecido un umbral por debajo del cual las solicitudes no se aceptan. El mínimo es de 10 EFHC.

Además, la comisión por retiro la paga el proyecto, y retirar cantidades inferiores a 10 EFHC no es razonable.

### 10-12. ¿Por qué el withdrawal puede no estar disponible aunque yo tenga EFHC?

Porque para el withdrawal solo se tiene en cuenta el balance principal. Si los EFHC están en la parte bonus del balance, no se puede enviar un withdrawal sobre ellos.

### 10-13. ¿Qué debo hacer después de enviar una solicitud de retiro?

Revisa el estado de la solicitud y el historial de operaciones: allí se ve el estado real de la solicitud y el movimiento de fondos.

### 10-14. ¿En qué token y en qué red se realizan los retiros?

Los retiros se realizan únicamente en tokens EFHC y exclusivamente en la red blockchain TON (The Open Network). No existe ninguna otra opción de retiro en el proyecto.

### 10-15. ¿Cuánto tiempo tarda el procesamiento manual de un retiro por parte de un operador?

Las solicitudes de retiro son procesadas por los operadores en cola viva. Normalmente el procesamiento tarda desde unos minutos hasta 24 horas, según la carga de la red y la cantidad de solicitudes. Siempre puedes cancelar una solicitud no procesada, y los fondos volverán instantáneamente a tu saldo.

## 11. Tasks

### 11-1. ¿Qué aporta completar tareas?

Las tareas solo dan monedas de bonificación y motivan a participar en la vida del jugador.

### 11-2. ¿Cómo obtengo la recompensa por una tarea?

Debes cumplir las condiciones de la tarea. Después, el bot registra automáticamente el cumplimiento y acredita la recompensa prevista.

### 11-3. ¿Por qué la tarea no se completó?

Esto puede pasar si las condiciones aún no se han cumplido por completo, la acción no se terminó por completo o el resultado todavía no se ha actualizado en el sistema.

### 11-4. ¿Se puede hacer la misma tarea otra vez?

Depende del tipo de tarea. Algunas tareas son de una sola vez y otras pueden repetirse según la lógica del proyecto.

### 11-5. ¿Todas las tareas dan la misma recompensa?

No. El tamaño de la recompensa depende de la tarea concreta y de sus condiciones. Pero aquí el tipo de recompensa es uno solo: monedas de bonificación.

### 11-6. ¿Para qué sirven las tareas si ya existen los paneles?

Las tareas son una vía adicional de crecimiento. No sustituyen a los paneles, sino que ayudan a reunir monedas de bonificación que luego pueden usarse dentro del ciclo de juego.

### 11-7. ¿Por qué la recompensa de las tareas no llega al saldo principal?

Porque las tareas entregan EFHC de bonificación. Es una recompensa interna del ciclo de juego y se acredita en el saldo bonus.

### 11-8. ¿Por qué a veces las tareas se terminan o desaparecen?

Porque las tareas pueden ser temporales o tener un límite. Si una tarea no está, significa que terminó o que ahora no está activa.

### 11-9. ¿Dónde puedo ver todas las tareas disponibles?

En la sección Tasks: allí se muestra la lista de tareas disponibles y sus condiciones.

### 11-10. ¿Por qué la recompensa de una tarea no apareció de inmediato?

A veces el resultado necesita tiempo para actualizarse. Comprueba: actualizar Tasks → revisar el saldo bonus → revisar el historial de operaciones.

### 11-11. Me suscribí al canal requerido en la tarea, pero la tarea no se completa. ¿Por qué?

A veces la verificación de la suscripción tarda por el almacenamiento en caché del lado de los servidores de Telegram. Si el bot no contó la suscripción al instante, vuelve a la sección Tasks después de unos minutos y pulsa de nuevo el botón de verificación.

## 12. Referrals

### 12-1. ¿Cómo se llaman las secciones en la página Referrals?

En la página Referrals se usan las secciones Activos e Inactivos.

### 12-2. ¿Qué significa un referido activo y uno inactivo?

Un referido activo es un jugador que ya activó al menos un panel y obtuvo el estado Activ. Un referido inactivo es quien todavía no entró en el ciclo de juego y por ahora no da derecho al bonus.

### 12-3. ¿Cuándo se acreditan los bonus de referidos?

El bot comprueba los bonus de referidos automáticamente. En cuanto el jugador se vuelve activo, el bonus se acredita de inmediato y de forma automática.

### 12-4. ¿Qué aporta el estado activo para los referidos?

El estado activo es importante para la lógica de referidos porque el proyecto lo usa como parte del filtro de participación real y de la protección contra bots, granjas de bots y actividad falsa.

### 12-5. ¿Cómo se relaciona Activ con los referidos?

Activ muestra que el usuario es un participante real del proyecto y no una cuenta bot. Esto es importante para el funcionamiento honesto del sistema de referidos y para la protección contra granjas de bots.

### 12-6. ¿Qué bonus básico se acredita por cada referido activo?

Por cada referido activo se acreditan 0.1 EFHC en el saldo bonus.

### 12-7. ¿Por qué tengo referidos, pero el bonus no se acreditó?

El bonus se acredita solo por referidos activos: quienes compraron al menos un panel y obtuvieron Activ. Revisa las pestañas «Activos» e «Inactivos»: la mayoría de las veces los invitados aún no pasaron al estado activo.

### 12-8. ¿A qué saldo se acreditan los 0.1 EFHC por un referido activo?

El bonus de 0.1 EFHC se acredita en el saldo bonus. Es una recompensa interna del sistema de referidos y se ve en el saldo bonus y en el historial de operaciones.

### 12-9. ¿Por qué el invitado está en la lista, pero no cuenta como activo?

Porque solo se vuelve activo después de activar el primer panel y obtener Activ. Mientras eso no ocurra, permanece en la parte inactiva de la lista.

### 12-10. ¿Dónde consigo mi enlace de referido?

En la sección Referrals: allí se muestra tu enlace de referido y la lista de invitados.

### 12-11. ¿Está permitido crear cuentas adicionales usando tu propio enlace de referidos?

Sí. Las reglas del proyecto no lo prohíben. Sin embargo, crear cuentas vacías no te dará beneficio. La economía del sistema está construida de modo que los bonos de referidos y el crecimiento del ranking solo se acreditan por un participante con estado Activ, es decir, después de que la cuenta invitada entre realmente al juego y compre al menos un panel.

### 12-12. ¿Puedo cambiar a mi invitador después del registro?

No. El vínculo de referido queda fijado en el momento de tu primera entrada al proyecto mediante un enlace de invitación y no puede cambiarse después.

## 13. Hub

### 13-1. ¿Qué puedo hacer en Hub?

En Hub hay tarjetas que llevan a acciones relacionadas del proyecto: el paso al flujo externo para obtener EFHC y el paso a la colección externa de VIP NFT.

### 13-2. ¿Para qué sirve Hub?

Hub funciona como navigation layer para transiciones rápidas hacia acciones relacionadas y flujos externos del proyecto.

### 13-3. ¿Qué tarjetas hay en Hub?

En la etapa actual, en Hub hay dos tarjetas: EFHC y VIP.

### 13-4. ¿Qué hace la tarjeta EFHC?

La tarjeta EFHC inicia el paso al flujo externo para obtener EFHC.

### 13-5. ¿En qué balance se acredita la recarga de EFHC después de la confirmación?

La recarga de EFHC jetton se acredita al balance principal.

### 13-6. ¿Por qué el resultado de la recarga puede no aparecer al instante?

Primero debe confirmarse la etapa externa de la operación y después se actualiza el resultado. Revise Hub, el balance principal y el historial de operaciones.

### 13-7. Si recibí un VIP NFT a través de GetGems, ¿dónde veo que está activo?

Revise el estado VIP en la aplicación y la presencia del NFT en la wallet vinculada.

### 13-8. Pasé por el flujo externo desde Hub, pero no hay resultado. ¿Qué debo hacer?

Revise Hub, el balance principal y el historial de operaciones. Si sigue sin haber resultado, la operación aún no se ha incorporado o requiere un procesamiento separado.

### 13-9. ¿A qué balance llega una recarga a través de Top Up y Hub?

La recarga de EFHC jetton se acredita al balance principal.

### 13-10. ¿Necesito una wallet conectada para las acciones de Hub?

Para las acciones externas basadas en wallet se necesita una Wallet conectada. Hub mismo se abre sin una compra aparte y funciona como punto de transición.

### 13-11. ¿Dónde puedo comprobar que la recarga de EFHC se acreditó realmente?

Revise el balance principal y el historial de operaciones: allí debe aparecer el rastro de la recarga.

### 13-12. ¿Hay skins en Hub?

Los skins no son tarjetas de Hub.

### 13-13. ¿Cómo obtengo los skins del proyecto?

Los skins se desbloquean a medida que progresa la cuenta y están vinculados a los 12 niveles de logros.

## 14. Navegación y reglas

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. ¿Qué pantallas debería abrir primero si entro en la WebApp por primera vez o después de una pausa larga?

Lo mejor es empezar por la pantalla principal, la barra superior y el perfil. Después será más fácil pasar a Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History y Hub según su tarea actual.

### 14-3. ¿Cómo entiendo en qué sección buscar la función que necesito?

Guíese por el sentido de la acción: Profile — para los datos de la cuenta y la información de referencia, Wallet — para la wallet, Panels — para los paneles, Energy — para la generación, Exchange — para el intercambio, Withdraw — para los retiros, Tasks — para las tareas, Referrals — para los usuarios invitados y Hub — para las transiciones a acciones relacionadas con EFHC y VIP.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Ads

### 15-1. ¿Qué es esta sección?

La sección Ads es una subsección dentro de Tasks. Muestra acciones publicitarias disponibles mediante las cuales el usuario puede obtener monedas bonus adicionales.

### 15-2. ¿Qué me da?

Da solo monedas bonus por visualizaciones, si en este momento la publicidad está disponible para la cuenta del usuario.

### 15-3. ¿Por qué aquí no hay nada?

Si la sección está vacía, significa que en este momento no hay ofertas activas para la cuenta del usuario o que la publicidad está temporalmente desactivada.

### 15-4. ¿Dónde está la sección Ads?

La sección Ads está como subsección dentro de Tasks. Es una de las posibilidades adicionales dentro del bloque de tareas.

### 15-5. ¿Qué tipo de recompensa da Ads?

Ads da solo monedas bonus por visualizaciones. No es saldo principal ni retiro directo, sino una forma interna adicional de reforzar el camino de juego.

### 15-6. ¿Por qué Ads es útil?

Porque es una fuente adicional de monedas bonus. No sustituye a los paneles ni a la generación, pero puede ayudar a reforzar más rápido el ciclo interno del juego.

### 15-7. ¿Por qué otros tienen publicidad y yo no?

Porque las ofertas pueden no estar disponibles para una cuenta concreta o la publicidad puede estar temporalmente desactivada. Un Ads vacío no significa que la cuenta esté rota.

### 15-8. ¿Qué hago si realicé una acción en Ads, pero no hay resultado?

Comprueba: actualizar Tasks / Ads → revisar el saldo bonus → revisar el historial de operaciones.

### 15-9. ¿Por qué en Ads puede haber distintas ofertas para distintos usuarios?

Porque las ofertas dependen de la disponibilidad de campañas publicitarias para una cuenta concreta. Esto es normal: uno tiene ofertas y otro temporalmente no.

### 15-10. ¿Hace falta comprar algo para usar Ads?

No. Ads es una forma de obtener EFHC bonus y no requiere compras obligatorias.

## 16. Ranks

### 16-1. ¿Por qué me importa crecer en el ranking?

Crecer en el ranking muestra cómo se ve su progreso frente a otros participantes. Esto ayuda a entender su posición actual y a ver qué tan activamente se desarrolla la cuenta.

### 16-2. ¿En qué se diferencia un nivel del ranking?

Un nivel muestra el progreso personal dentro del sistema, mientras que el ranking muestra la posición del usuario entre los demás participantes.

### 16-3. ¿Cómo se relacionan el nivel y el ranking?

Están conectados por una misma lógica de crecimiento a través de la generación de kWh con paneles y la barra de progreso compartida en la página de Ranks.

### 16-4. ¿El ranking es solo un número bonito?

No. El ranking ayuda a entender cómo se ve tu camino en comparación con el de otros participantes.

### 16-5. ¿Qué influye en el crecimiento de mi posición en el ranking?

En el crecimiento de su posición en el ranking influye el progreso general de la cuenta: desarrollo de paneles, generación de kWh y el movimiento general por la ruta energética del proyecto.

### 16-6. ¿Se puede crecer en nivel y en ranking al mismo tiempo?

Sí. Cuando el usuario desarrolla paneles, generación y progreso energético general, normalmente fortalece al mismo tiempo tanto su nivel como su posición en el ranking.

### 16-7. ¿Por qué tengo un nivel alto, pero mi puesto en el ranking no es el primero?

Porque el ranking es tu lugar entre todos los participantes, no solo tu progreso personal. Otros jugadores también pueden avanzar con mucha fuerza.

### 16-8. ¿Por qué mi ranking puede moverse aunque yo no haya hecho nuevas acciones?

Porque el ranking no existe por sí solo, sino en comparación con todos los participantes. Mientras usted no cambia nada, otros usuarios siguen creciendo, y eso influye en su posición.

### 16-9. ¿Dónde veo mi posición en el ranking?

En la sección Ranks: allí se muestra tu puesto entre los demás participantes.

### 16-10. ¿Por qué mi ranking puede bajar incluso cuando yo progreso?

Porque para el ranking importa no solo su propio crecimiento, sino también la velocidad de crecimiento de otros participantes. Aunque su cuenta se fortalezca, su puesto puede bajar cuando otros lo superan más rápido.

## 17. Estatus Activ

### 17-1. ¿Qué significa el estatus Activ?

Activ es un estatus activo permanente. Significa que el juego ha comenzado de verdad, porque se ha comprado al menos un panel.

### 17-2. ¿Cómo obtengo Activ?

Para obtener Activ basta con activar un panel. Después de esa compra, el estatus se asigna de forma permanente.

### 17-3. ¿Activ es temporal o permanente?

Activ es un estatus permanente.

### 17-4. ¿Activ se conserva si más tarde un panel pasa a Archive?

Sí. Incluso si más tarde un panel pasa a Archive, el estatus Activ se conserva.

### 17-5. ¿Por qué es importante Activ?

Activ ayuda a separar a los jugadores reales de los registros aleatorios, los bots y las granjas de bots. Confirma la participación real del usuario en el proyecto.

### 17-6. ¿Activ puede desaparecer más adelante?

No. Activ es un estatus permanente y se conserva incluso si el primer panel pasa después a Archive.

### 17-7. ¿Por qué Activ sirve para protegerse de bots y granjas de bots?

Porque Activ confirma una participación real y no una cuenta vacía creada para inflar métricas. Eso hace que la mecánica de referidos sea más justa.

### 17-8. ¿Qué cambia en la cuenta después de obtener Activ?

La cuenta se considera un participante real confirmado del proyecto. Esto influye en el funcionamiento justo de los referidos y en la lógica general del crecimiento del sistema.

### 17-9. ¿Por qué Activ aparece justamente después del primer panel?

Porque comprar el primer panel es una señal clara de participación real. El proyecto usa este paso como filtro contra cuentas vacías.

### 17-10. ¿Puedo perder Activ por inactividad?

No. Activ es un estatus permanente y no desaparece por inactividad.

## 18. VIP NFT

### 18-1. ¿Qué es EFHC VIP NFT?

EFHC VIP NFT es una tarjeta de club, una llave para el futuro ecosistema completo de EFHC, una señal digital de pertenencia y un estatus especial dentro del proyecto.

### 18-2. ¿Qué me da poseer un EFHC VIP NFT?

Poseer un EFHC VIP NFT da una generación aumentada para todos los paneles del jugador.

### 18-3. ¿Por qué señales se nota que VIP ya fue tenido en cuenta?

Si el sistema ya tuvo en cuenta el VIP NFT, en la interfaz se ve el estado VIP y se vuelven notables las ventajas relacionadas de la cuenta.

### 18-4. ¿Dónde veré el efecto VIP?

El efecto VIP se ve en las secciones donde el proyecto tiene en cuenta las ventajas del VIP NFT, así como en la barra superior y en la lógica de generación.

### 18-5. ¿Necesito activar manualmente el VIP?

No. La lógica del proyecto está diseñada para verificar automáticamente la wallet y actualizar automáticamente el estatus VIP cuando se detecta el NFT.

### 18-6. ¿Tener 2 o 3 VIP NFT da privilegios adicionales al jugador?

No. Para el jugador, tener 2 o 3 VIP NFT no da privilegios adicionales más allá de un solo VIP NFT.

### 18-7. ¿Por qué un segundo VIP NFT no aumenta el efecto?

En el proyecto, VIP da un refuerzo de generación como un único estatus activo. Los VIP NFT adicionales no dan un aumento extra de ese mismo efecto.

### 18-8. ¿El VIP afecta a un panel o a todos?

VIP afecta a la generación de todos los paneles del usuario, no solo a uno por separado.

### 18-9. ¿Cómo comprobar que VIP realmente influye en la cuenta?

Compruebe no solo la presencia del estado VIP, sino también las ventajas relacionadas dentro de la mecánica de la cuenta, en especial allí donde se tiene en cuenta el efecto VIP, incluida la generación.

### 18-10. ¿Necesito una wallet conectada para que el bot vea mi VIP NFT?

Sí. Para que el bot vea el VIP NFT, necesita entender qué wallet pertenece a la cuenta. Por eso Wallet es importante para el funcionamiento del VIP.

### 18-11. ¿Puedo disponer de mi VIP NFT como quiera?

Sí. El EFHC VIP NFT se puede transferir, regalar y vender en marketplaces.

### 18-12. Si vendo o transfiero mi VIP NFT a otra billetera, ¿qué pasará con mi generación?

El bot escanea regularmente la blockchain y comprueba la presencia del NFT en tu billetera vinculada. Si vendes, regalas o mueves tu VIP NFT a otra dirección, el sistema lo detectará, desactivará tu estado VIP y la generación de todos tus paneles volverá automáticamente a la tasa base.

## 19. Niveles

### 19-1. ¿Por qué debería subir de nivel?

El crecimiento de nivel muestra el progreso del usuario dentro del proyecto y ayuda a ver cómo se desarrolla la cuenta paso a paso.

### 19-2. ¿Qué incluye la sección Niveles?

La sección Niveles muestra todas las escalas de crecimiento del proyecto: 12 niveles de progreso energético, 6 niveles del sistema de referidos y un bloque aparte sobre cómo interpretar correctamente los umbrales y el avance por niveles.

### 19-3. ¿Cuántos niveles de progreso energético hay en el proyecto?

El proyecto incluye 12 niveles de progreso energético.

### 19-4. ¿Cuántos niveles hay en el sistema de referidos?

El proyecto incluye 6 niveles del sistema de referidos: del 0 al 5.

### 19-5. ¿Para qué sirven los niveles a un jugador común?

Los niveles ayudan a entender dónde estás ahora, cuánto ya se ha hecho, hacia qué avanzar después y cómo se ve tu desarrollo dentro del sistema.

### 19-6. ¿Cómo se relacionan los niveles de energía, los niveles de referidos y el crecimiento general de la cuenta?

Son partes de un mismo camino. La generación de energía impulsa el progreso principal, los referidos activos refuerzan el desarrollo del sistema y juntos muestran el crecimiento integral de la cuenta.

### 19-7. Eco Initiate (0 kWh)

**Significado para el jugador:** Tu primer panel está instalado y listo para trabajar. Das el paso principal hacia una energía limpia y comienzas tu camino dentro del proyecto.

### 19-8. Hope Bringer (100 kWh)

**Significado para el jugador:** ¡Han llegado los primeros kilovatios! Tus paneles ya generan energía verde con éxito, aportando esperanza al sistema y a tu crecimiento personal.

### 19-9. Energy Seeker (300 kWh)

**Significado para el jugador:** El sistema funciona muy bien y abastece de forma estable la red con electricidad ecológica. Tu progreso ya es visible y constante.

### 19-10. Nature's Voice (600 kWh)

**Significado para el jugador:** Tu aporte empieza a notarse. Al generar energía con tecnologías verdes, refuerzas el paso del proyecto hacia un futuro más limpio.

### 19-11. Earth Ally (1000 kWh)

**Significado para el jugador:** ¡Se ha generado el primer megavatio-hora! Tus paneles han producido un volumen importante de energía limpia, y eso confirma la solidez de tu avance.

### 19-12. Climate Fighter (2000 kWh)

**Significado para el jugador:** Tu generación produce un efecto real contra el cambio climático. Cada kWh generado reduce la dependencia de fuentes de energía menos limpias.

### 19-13. Green Sentinel (3500 kWh)

**Significado para el jugador:** El flujo estable de energía de tus paneles protege el aire limpio. Ya no solo participas: sostienes un resultado ecológico tangible.

### 19-14. Planet Defender (5000 kWh)

**Significado para el jugador:** ¡5000 kWh de generación limpia! La potencia de tus paneles funciona como un escudo invisible que refuerza la transición verde.

### 19-15. Eco Champion (7500 kWh)

**Significado para el jugador:** Volúmenes de producción extraordinarios. Eres un verdadero campeón de la energía verde y tu cuenta muestra un progreso muy fuerte.

### 19-16. Planet Saver (10000 kWh)

**Significado para el jugador:** ¡10 megavatios-hora! Has generado tanta energía limpia que ya se percibe como una contribución seria a la protección del planeta.

### 19-17. Green Commander (15000 kWh)

**Significado para el jugador:** Buque insignia de la generación ecológica. Tus paneles alimentan el futuro y las cifras impresionantes de producción confirman tu alto nivel.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Nivel de referidos 0

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: muestra la escala de la actividad de tu estructura y ayuda a ver el punto desde el que partes.

### 19-20. Nivel de referidos 1

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: muestra la escala de la actividad de tu estructura y confirma los primeros resultados del desarrollo.

### 19-21. Nivel de referidos 2

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: muestra que el sistema no solo existe, sino que empieza a fortalecer tu progreso general.

### 19-22. Nivel de referidos 3

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: indica una estructura más sólida y una participación más notable de los referidos en el avance.

### 19-23. Nivel de referidos 4

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: refleja un nivel fuerte de desarrollo y un peso serio de la red en tu progreso.

### 19-24. Nivel de referidos 5

**Significado para el jugador:** Esta es la marca de tu crecimiento dentro del sistema de referidos: muestra la máxima escala de actividad del sistema de referidos dentro del proyecto.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. ¿Por qué los nombres de los niveles están relacionados con la ecología y el planeta?

Porque la idea misma del juego está conectada con la energía verde virtual, la motivación de las personas y una contribución simbólica a la recuperación del planeta Tierra.

## 20. FAQ / Ayuda

### 20-1. ¿Dónde abrir el FAQ?

El FAQ se abre desde el perfil como la sección de ayuda integrada del bot, donde se reúnen las respuestas sobre las acciones y pantallas principales del proyecto.

### 20-2. ¿Para qué sirve FAQ / Ayuda?

Esta sección existe para que el usuario encuentre rápidamente respuestas claras, cifras exactas, reglas reales del proyecto y la lógica del funcionamiento del bot.

### 20-3. ¿Por qué el FAQ está explicado con tanto detalle?

Porque el proyecto es de varias capas y una referencia corta y seca no cubre las preguntas reales del jugador. Aquí la tarea no es solo dar una línea de respuesta, sino explicar el sentido.

### 20-4. ¿Se puede entender por el FAQ el recorrido completo del jugador dentro del bot?

Sí. Un buen FAQ debe explicar no solo botones sueltos, sino el recorrido completo: desde el primer panel hasta el intercambio de energía, la wallet, el retiro, el ranking y los niveles.

### 20-5. ¿Qué hacer si no encontré la respuesta a la primera?

Es mejor abrir una sección cercana por sentido y mirar las preguntas vecinas. En un bot grande, muchas respuestas están conectadas entre sí.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. ¿Qué revisar si “parece que hay fallos por todas partes”?

Revisa tres cosas: 1) Wallet: si la wallet está conectada y si la principal está seleccionada, 2) saldos e historial: si hubo operaciones recientes, 3) la sección correcta: si estás mirando exactamente la pantalla donde debe verse el cambio.

### 20-8. ¿Cuál es la forma más rápida de entender qué pasó con mis EFHC?

Abre el historial de saldo. El historial muestra qué fue exactamente lo que cambió los saldos: una recompensa, una compra, un intercambio u otra operación.

### 20-9. ¿Por dónde empezar si abrí el bot por primera vez y no entiendo nada?

Empieza por Energy (la pantalla principal), después abre Panels, mira los saldos y el historial, y solo después pasa a Exchange, Withdraw, Referrals y Ranks.

### 20-10. ¿Cómo encontrar más rápido la pregunta que necesito en el FAQ?

La forma más rápida es abrir la sección correspondiente por tema (Wallet / Panels / Exchange / Withdraw, etc.) y mirar primero las preguntas vecinas. Normalmente la respuesta deseada está muy cerca.
