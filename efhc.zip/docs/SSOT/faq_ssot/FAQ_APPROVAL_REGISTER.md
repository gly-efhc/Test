# FAQ Approval Register

Status: ACTIVE
Cycle introduced: 103

## Rules

Each FAQ rewrite wave must add a new approval record here before any
rewrite/rebuild step starts.

Required fields:

- Approval ID
- Date
- Source cycle
- Scope
- Draft document
- Approval basis
- Approved by user
- Rewrite allowed
- Runtime rebuild allowed
- Status
- Notes

---

## Approval entries

### FAQ-APPROVAL-0001

- Date: 2026-03-28
- Source cycle: 77
- Scope: RU section 13 (`Hub`)
- Draft document: `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md`
- Approval basis: historical draft package preserved in HEAD
- Approved by user: yes, recorded through the cycle series
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - This entry is recorded retroactively in cycle 103 to restore the
    missing governance trail for the already implemented section-13 wave.
  - It does not authorize any new FAQ rewrite outside the recorded scope.


### FAQ-APPROVAL-0002

- Date: 2026-03-29
- Source cycle: 107
- Scope: Multilingual Hub-related legal wording cleanup across the 13 FAQ languages
- Draft document: `docs/FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`
- Approval basis: cycle 107 direct audit of multilingual Hub wording residuals
- Approved by user: no
- Rewrite allowed: no
- Runtime rebuild allowed: no
- Status: draft
- Notes:
  - This entry prepares the multilingual wording cleanup package only.
  - It does not authorize SSOT rewrite or runtime rebuild until explicit user approval is recorded.


### FAQ-APPROVAL-0003

- Date: 2026-03-29
- Source cycle: manual archive update after cycle 107
- Scope: RU FAQ exact per-second panel rates wording sync
- Draft document: `docs/FAQ_PANELS_RATES_RU_DRAFT.md`
- Approval basis: explicit user instruction to add 0.00000692 and 0.00000741 as user-facing values in FAQ
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU FAQ wording in this step.


### FAQ-APPROVAL-0004

- Date: 2026-03-29
- Source cycle: 108
- Scope: RU Wallet FAQ replacement wave 1
- Draft document: `docs/FAQ_WALLET_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of W1, W2, W3 and replacement mapping
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU FAQ wording in this wave.


### FAQ-APPROVAL-0005

- Date: 2026-03-29
- Source cycle: 109
- Scope: RU VIP NFT FAQ replacement wave 1
- Draft document: `docs/FAQ_VIP_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of V1–V5 with final V5 wording correction
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU VIP NFT FAQ wording in this wave.


### FAQ-APPROVAL-0006

- Date: 2026-03-29
- Source cycle: 110
- Scope: RU Hub FAQ wording sync wave 1
- Draft document: `docs/FAQ_HUB_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of H1, H2, H3, H4
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Replaces a duplicate Hub wording slot with approved VIP card wording.


### FAQ-APPROVAL-0007

- Date: 2026-03-29
- Source cycle: 111
- Scope: RU Exchange FAQ replacement wave 1
- Draft document: `docs/FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of E1, E3, E4 with final wording corrections and rejection of E2
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU Exchange FAQ wording in this wave.


### FAQ-APPROVAL-0008

- Date: 2026-03-29
- Source cycle: 112-113
- Scope: RU Top bar FAQ replacement wave 1 + Hub duplicate correction
- Draft document: `docs/FAQ_TOPBAR_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of T1, T2, T3, T4 and user instruction to restore the Hub balance question and remove a weaker Hub question instead
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Restores the old Hub balance question.
  - Uses the weak Hub card-count question as the replacement slot.


### FAQ-APPROVAL-0009

- Date: 2026-03-29
- Source cycle: 114-115
- Scope: RU forbidden wording cleanup wave 1
- Draft document: `docs/FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of F1–F8
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU FAQ wording in this wave.


### FAQ-APPROVAL-0010

- Date: 2026-03-29
- Source cycle: 116-117
- Scope: RU panels FAQ wording wave 1
- Draft document: `docs/FAQ_PANELS_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of P1–P8 and direct correction banning the word `цена`
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to the RU panels FAQ wording in this wave.



### FAQ-APPROVAL-0011

- Date: 2026-03-29
- Source cycle: 119
- Scope: RU panels bot-help and UI wording wave 1
- Draft document: `docs/FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`
- Approval basis: explicit user approval of PB1, PB2, PB3, PB4, PB6; PB5 left pending
- Approved by user: yes
- Rewrite allowed: yes
- Runtime rebuild allowed: yes
- Status: implemented
- Notes:
  - Keeps FAQ count unchanged.
  - Applies only to approved RU panel user-facing strings in this wave.
  - PB5 remains unresolved and is not implemented in this wave.
