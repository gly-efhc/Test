# EFHC FAQ (DE) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. Über das Projekt

### 1-1. Was ist EFHC?

EFHC ist ein Spielprojekt rund um Energie, Fortschritt und die Entwicklung des Accounts innerhalb des Bots. Der Nutzer kauft Panels, sammelt Energie, tauscht sie in EFHC um, verfolgt seine Guthaben, steigt in den Levels auf, bewegt sich im Ranking nach oben und nutzt zusätzliche Projektfunktionen.

Begriffe:
— EFHC — Energy for Humanity Coin
— EFHCm — Hauptmünzen
— EFHCb — Bonusmünzen
— EFHCj — externer EFHC-Jetton
— EFHC — Gesamtguthaben (Bonus + Hauptguthaben)

### 1-2. Wie funktioniert hier alles?

Innerhalb des Projekts dreht sich alles um Energie und das Wachstum des Accounts. Der Nutzer arbeitet mit Panels, sammelt Energie, tauscht sie in EFHCm um, verfolgt seine Guthaben, verbindet eine Wallet, verstärkt seinen Fortschritt und nutzt zusätzliche Projektmechaniken.

### 1-3. Was soll ich in diesem Bot tun?

Die Hauptaufgabe besteht darin, den eigenen Account zu entwickeln. Dafür arbeitet der Nutzer mit Panels, verfolgt die Energieerzeugung, nutzt den Exchange, prüft seine Guthaben, verbindet eine Wallet, nimmt an zusätzlichen Projektmechaniken teil und verstärkt seinen Fortschritt Schritt für Schritt.

### 1-4. Wie kann ich hier wachsen und vorankommen?

Das Wachstum im Bot baut auf Energie und Aktivität auf. Je mehr Panels, Energie, nützliche Aktionen und Fortschritt der Nutzer hat, desto stärker entwickelt sich der Account und desto höher steigt er im Level- und Rangsystem.

### 1-5. Was ist der Hauptsinn des Projekts?

Der Hauptsinn des Projekts besteht darin, den Weg vom Kauf eines Panels über die Energieerzeugung bis zum Ergebnis in EFHC sichtbar zu machen. Der Nutzer sieht keine abstrakten Zahlen, sondern eine zusammenhängende Kette: Panel, Energie, Exchange, Guthaben, Fortschritt, Levels und Platz unter anderen Teilnehmern.

### 1-6. Ist das nur Unterhaltung oder gibt es hier eine Entwicklungslogik?

Hier gibt es eine vollwertige Wachstumslogik. Der Nutzer drückt nicht einfach nur Knöpfe, sondern stärkt seinen Account Schritt für Schritt: Er kauft Panels, startet die Erzeugung, erhält den Aktiv-Status, sammelt Belohnungen, entwickelt das Empfehlungssystem und sieht das Ergebnis seines Weges.

### 1-7. Wie bekomme ich hier meine ersten EFHC?

Die ersten EFHC stammen aus zwei Hauptquellen: Belohnungen (als Bonusmünzen EFHCb) und dem Energietausch über den Exchange (als Hauptmünzen EFHCm). Der stärkste Weg ist Panels → Energie → Exchange → Hauptguthaben.

### 1-8. Woher kommt meine Energie?

Energie liefern deine aktiven Panels. Solange die Panels aktiv sind, erzeugen sie Energie, und diese sammelt sich als verfügbare Energie für den Exchange an.

### 1-9. Was beeinflusst mein Wachstum im Projekt am stärksten?

Am stärksten beeinflussen die Anzahl aktiver Panels und ihre gesamte Erzeugung dein Wachstum. Der zweite Verstärker ist VIP (falls vorhanden), weil er die Erzeugung beeinflusst. Aufgaben, Werbung und Empfehlungen sind eine nützliche Ergänzung, aber nicht die Grundlage.

### 1-10. Wie erkenne ich, dass ich mich richtig bewege?

Wenn drei Dinge wachsen — Erzeugung, verfügbare Energie und das Hauptguthaben nach dem Exchange — dann bewegst du dich richtig. Schnell prüfen kannst du das über Energy und die Verlaufshistorie.

## 2. Hauptbildschirm

### 2-1. Was zeigt der Hauptbildschirm?

Der Hauptbildschirm ist die Energy-Seite. Sie bündelt die wichtigsten Elemente des aktuellen Account-Zustands: Schnellaktionen, Informationen über den Fortschritt und Einstiegspunkte zu wichtigen Bereichen des Bots.

### 2-2. Wozu dient der Hauptbildschirm?

Er dient dazu, dass der Nutzer sofort das Wichtigste über seinen Account sieht und den aktuellen Zustand, den Fortschritt und die nächsten möglichen Schritte schnell versteht.

### 2-3. Worauf sollte ich zuerst schauen?

Zuerst solltest du auf die obere Leiste, das Gesamtguthaben, den Energy-Bildschirm und die verfügbaren Aktionen schauen. Genau sie zeigen am schnellsten den aktuellen Zustand des Accounts und was du als Nächstes tun kannst.

### 2-4. Wo sehe ich meinen aktuellen Fortschritt?

Der aktuelle Fortschritt spiegelt sich in den Bereichen des Bots wider, die mit Energie, Panels, Levels und Ranking verbunden sind. An ihnen sieht man, wie sich der Nutzer innerhalb des Projekts weiterentwickelt.

### 2-5. Warum ist der Hauptbildschirm jeden Tag wichtig?

Weil man hier am schnellsten sieht, wie sich der Account verändert hat: wie viel Energie gerade vorhanden ist, wie viele Panels aktiv sind, wie der Fortschritt wächst und für welchen nächsten Schritt der Nutzer bereits bereit ist.

### 2-6. Womit sollte ich am besten anfangen?

Zuerst solltest du auf die obere Leiste schauen, verstehen, welche Guthaben du hast, die Energy-Seite öffnen, den Bereich Panels ansehen und anschließend das FAQ zu den wichtigsten Aktionen lesen. Wenn für die gewünschte Aktion eine Wallet erforderlich ist, ist der nächste Schritt ihre Verbindung.

### 2-7. Welche Buttons auf dem Hauptbildschirm sind am wichtigsten?

Am wichtigsten sind die Buttons, die zu den zentralen Aktionen führen: Panels und Exchange sowie die Schnellbuttons in der oberen Leiste — Top Up und Hub — wenn Sie zu den verbundenen EFHC- und VIP-Aktionen wechseln möchten.

### 2-8. Was sollte ich jeden Tag auf dem Hauptbildschirm prüfen?

Drei Dinge: 1) wie viele Panels aktiv sind, 2) die Erzeugungsrate, 3) wie viel verfügbare Energie sich bereits für den Exchange angesammelt hat.

### 2-9. Warum verändert sich der Hauptbildschirm im Laufe der Zeit?

Weil er den lebendigen Zustand des Accounts widerspiegelt. Wenn Panels, Energie und Transaktionen erscheinen, ist der Bildschirm nicht mehr leer und zeigt mehr nützliche Daten und Fortschritt an.

### 2-10. Wie kann ich am Hauptbildschirm erkennen, dass sich mein Account entwickelt?

Wenn du Wachstum anhand von Fakten siehst: Die Erzeugung ist nicht null, Energie sammelt sich an und nach dem Exchange wächst das Hauptguthaben. Das sind die ehrlichsten Anzeichen für Entwicklung.

## 3. Obere Leiste

### 3-1. Was ist die obere Leiste?

Die obere Leiste ist ein eigenständiges Interface-Element und der wichtigste schnelle Informationsblock, der auf den Hauptseiten des Bots verfügbar ist.

### 3-2. Was wird in der oberen Leiste angezeigt?

In der oberen Leiste werden Avatar, Name, Energie-Fortschrittsstufe, VIP-Status, Gesamtguthaben, der Button Top Up und der Button Hub angezeigt.

### 3-3. Warum ist die obere Leiste wichtig?

Weil sie hilft, die wichtigsten Informationen zum eigenen Account sofort ohne unnötige Wechsel zu sehen: wer du bist, wie dein Fortschritt aussieht, ob du VIP hast, wie viele Ressourcen du insgesamt besitzt und welche Schnellaktionen verfügbar sind.

### 3-4. Was zeigt das Gesamtguthaben in der oberen Leiste?

Das Gesamtguthaben zeigt, wie viele Münzen du insgesamt in Summe hast. Das ist bequem, damit du Ressourcen für Einkäufe und interne Aktionen nicht jedes Mal selbst zusammenrechnen musst.

### 3-5. Warum ist das Gesamtguthaben für Einkäufe praktisch?

Weil es die gesamte Kaufkraft des Spielers innerhalb des Spiels zeigt und schnell erkennen lässt, ob genug Ressourcen für interne Aktionen und Käufe vorhanden sind.

### 3-6. Warum entspricht das Gesamtguthaben nicht dem, was ich sofort auszahlen kann?

Weil das Gesamtguthaben sowohl Haupt- als auch Bonusmünzen umfasst. Bonusmünzen werden für den Spielprozess benötigt und können nicht direkt ausgezahlt werden.

### 3-7. Wann sollte ich die Schaltfläche „Aufladen“ in der oberen Leiste verwenden?

Verwenden Sie sie, wenn Sie schnell zum im Projekt verfügbaren Ablauf für das Aufladen des Hauptguthabens gelangen möchten, ohne zusätzliche Bereiche manuell zu öffnen.

### 3-8. Warum sollte man Hub über die obere Leiste öffnen?

Damit Sie die Karten mit verbundenen Projektaktionen schnell öffnen und ohne zusätzliche Navigation zur benötigten externen Strecke wechseln können.

### 3-9. Warum ist die obere Leiste auf verschiedenen Seiten sichtbar?

Weil sie das „Armaturenbrett“ des Accounts ist: Sie soll die wichtigsten Dinge immer sichtbar machen (Guthaben, Status und Schnellaktionen), auch wenn du andere Bereiche des Bots geöffnet hast.

### 3-10. Was soll ich tun, wenn mir die Daten in der oberen Leiste falsch vorkommen?

Aktualisiere zuerst die Seite und prüfe die Guthabenhistorie: Sie zeigt die Fakten der Operationen. Wenn Historie und Guthaben übereinstimmen, sind die Daten korrekt; wenn nicht, lohnt sich eine genauere Prüfung des betreffenden Vorgangs.

## 4. Profil

### 4-1. Was ist der Bereich Profil/Einstellungen?

Profil/Einstellungen ist der Bereich, in dem das Profil und die Bot-Parameter verwaltet werden. Hier sind die wichtigsten Status sichtbar und persönliche Interface-Einstellungen verfügbar.

### 4-2. Was kann ich im Profil tun?

Im Profil sind die wichtigsten Benutzereinstellungen und schnelle Zugänge zu wichtigen Bereichen gesammelt: Wallet, Guthabenhistorie, FAQ und andere nützliche Punkte.

### 4-3. Was wird im oberen Teil von Profil/Einstellungen angezeigt?

Im oberen Teil von Profil/Einstellungen werden Avatar, Telegram-Name sowie die Status Activ und VIP angezeigt, falls sie bereits vorhanden sind.

### 4-4. Wo kann ich die Sprache ändern?

Die Sprache wird in Profil/Einstellungen geändert.

### 4-5. Warum brauche ich das Profil überhaupt?

Das Profil ist der persönliche Steuerpunkt des Accounts. Hier sieht der Nutzer nicht nur seine Status, sondern öffnet auch wichtige Unterbereiche rund um Wallet, Historie, Sprache und Hilfe.

### 4-6. Wo kann ich im Profil die Guthabenhistorie öffnen?

Im Bereich Profil/Einstellungen gibt es einen eigenen Zugang zur Guthabenhistorie, in der Eingänge und Abbuchungen sichtbar sind.

### 4-7. Wo kann ich im Profil die Sprache wechseln?

Die Sprachumschaltung befindet sich in Profil/Einstellungen, weil es sich um eine persönliche Kontoeinstellung handelt.

### 4-8. Wo kann ich im Profil Wallet für die Arbeit mit der Wallet öffnen?

Im Bereich Profil gibt es einen eigenen Punkt Wallet. Öffnen Sie ihn, wenn Sie eine Wallet verbinden, die Verknüpfung prüfen oder zu Wallet-bezogenen Aktionen wechseln müssen.

### 4-9. Wo kann ich im Profil schnell FAQ öffnen, wenn ich eine Antwort brauche?

Im Bereich Profil gibt es einen Einstieg in FAQ. Öffnen Sie ihn, wenn Sie eine schnelle Antwort zur Oberfläche, zum Balance, zu Panels, Energy, Exchange, Withdrawal oder zu anderen WebApp-Funktionen brauchen.

### 4-10. Was befindet sich im Bereich „Support und Informationen“?

Dort sind die Hilfepunkte gesammelt: FAQ, Hinweise/Informationen und alles, was dem Nutzer hilft, das Projekt ohne Verwirrung zu verstehen.

### 4-11. In wie vielen Sprachen ist die Projektoberfläche verfügbar?

Die Bot-Oberfläche und das FAQ sind in 13 Sprachen übersetzt. Sie können in den Profileinstellungen eine passende Sprache auswählen, und das System passt alle Texte und die gesamte Oberfläche sofort an Ihre Wahl an.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. Kann ich die Haupt-Wallet ändern?

Ja. Der Nutzer kann eine andere Haupt-Wallet aus den bereits verbundenen Wallets auswählen.

### 5-3. Kann ich eine verbundene Wallet löschen?

Ja. Wenn eine Wallet nicht mehr benötigt wird, kann ihre Verknüpfung entfernt werden.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. Was passiert, wenn ich eine Funktion nutze, für die eine Wallet nötig ist, ich aber keine habe?

Wenn für die gewählte Funktion eine Wallet erforderlich ist, startet der Bot zunächst die Logik zum Verbinden einer Wallet. Danach kannst du zur gewünschten Aktion zurückkehren.

### 5-6. Kann ich mehrere Wallets verbinden und wozu ist das gut?

Ja. Du kannst mehrere Wallets verbinden, damit du eine Reserveadresse hast oder verschiedene Nutzungsszenarien trennen kannst. Dabei bleibt immer eine Wallet als Haupt-Wallet festgelegt.

### 5-7. Was passiert, wenn ich meine Haupt-Wallet ändere?

Du kannst eine andere Wallet als Haupt-Wallet festlegen. Nach dem Wechsel orientiert sich das System bei den Operationen, bei denen dies erforderlich ist, an der neuen Hauptadresse.

### 5-8. Kann ich auf eine Nicht-Haupt-Wallet auszahlen?

Standardmäßig orientiert sich das System an der Haupt-Wallet. Wenn du eine andere Adresse nutzen möchtest, mache sie zuerst in Wallet zur Haupt-Wallet und beantrage danach die Auszahlung.

### 5-9. Was soll ich tun, wenn die Wallet verbunden ist, die Auszahlung aber trotzdem nicht verfügbar ist?

Prüfe drei Dinge: Ist die Haupt-Wallet ausgewählt, reicht das Hauptguthaben aus und liegt der Auszahlungsbetrag nicht unter 10 EFHC.

### 5-10. Kann ich spielen und Fortschritte machen, wenn noch keine Wallet verbunden ist?

Ja. Die Wallet wird für einige Operationen benötigt (zum Beispiel für Auszahlungen), aber du kannst den Account auch ohne verbundene Wallet entwickeln, das Interface erkunden und Fortschritt aufbauen.

### 5-11. Was soll ich tun, wenn ich den Zugriff auf meine Haupt-TON-Wallet verliere?

Da das Projekt das Verknüpfen mehrerer Wallets erlaubt, können Sie im Bereich Wallet eine neue Wallet hinzufügen, sie als Haupt-Wallet festlegen und die alte kompromittierte Adresse dauerhaft aus der Liste der verknüpften Wallets entfernen.

## 6. Salden und Verlauf

### 6-1. Warum habe ich drei verschiedene Salden?

Weil das System den Gesamtsaldo, den Hauptsaldo und den Bonussaldo trennt. So sieht der Nutzer, welche Mittel wofür verfügbar sind und wie die Projektlogik funktioniert.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Warum ist es wichtig, Salden und Verlauf zu prüfen?

Weil der Nutzer so versteht, was genau mit den Mitteln passiert ist: Gutschrift, Umtausch, Kauf oder Auszahlung. Der Verlauf hilft, Bewegungen des Guthabens nachzuvollziehen statt zu raten.

### 6-4. Wo sehe ich, wofür mir EFHC gutgeschrieben oder abgezogen wurden?

Bei allen internen Ausgaben im Projekt werden Mittel zuerst vom Bonusguthaben abgezogen. Wenn das nicht reicht, wird der Rest vom Hauptguthaben abgezogen.

### 6-5. Warum kann sich der Gesamtsaldo ändern, auch wenn ich nur einen Teil des Systems genutzt habe?

Weil der Gesamtsaldo die Summe der Teile ist. Wenn sich Haupt- oder Bonussaldo ändern, ändert sich dadurch auch der Gesamtsaldo.

### 6-6. Kann man dem Verlauf entnehmen, was genau mit dem Guthaben passiert ist?

Ja. Der Verlauf ist gerade dafür da, damit der Nutzer sieht, was die Änderung ausgelöst hat: Bonus, Kauf, Umtausch oder Auszahlung.

### 6-7. Warum wurden Mittel dem Bonus- oder Hauptsaldo zugeordnet?

Weil das Projekt verschiedene Arten von EFHC logisch trennt. So wird klar, welches Guthaben zu Bonusmechaniken gehört und welches für zentrale Aktionen verfügbar ist.

### 6-8. Warum ist mein Verlauf wichtig und nicht nur die aktuelle Zahl?

Weil die aktuelle Zahl nur den Zustand im Moment zeigt, der Verlauf aber den Weg dorthin erklärt. So versteht man nicht nur wie viel da ist, sondern auch warum genau.

### 6-9. Kann ich aus dem Verlauf erkennen, ob die Aktion erfolgreich war?

In den meisten Fällen ja, denn der Verlauf zeigt die tatsächliche Änderung des Guthabens. Wenn ein entsprechender Eintrag erschienen ist, wurde die Aktion im System berücksichtigt.

### 6-10. Warum aktualisiert sich der Verlauf nach Auszahlung oder Umtausch nicht überall gleichzeitig?

Weil verschiedene Bereiche der Oberfläche nicht immer im exakt selben Moment aktualisiert werden. Das ist normal: derselbe Vorgang kann an einer Stelle etwas früher sichtbar sein als an einer anderen.

### 6-11. Was passiert, wenn ich bei schwacher Internetverbindung die Kauf- oder Austausch-Schaltfläche mehrmals hintereinander drücke? Werden zusätzliche Coins abgezogen?

Nein. Es werden keine zusätzlichen Coins abgezogen. Im Kern des Systems ist ein strenger Schutz vor Doppelabbuchungen eingebaut. Selbst wenn Sie wegen einer hängenden Verbindung zehnmal drücken, wird die Operation garantiert genau einmal ausgeführt.

## 7. Panels

### 7-1. Wie viel EFHC werden für die Aktivierung eines Panels benötigt?

Für die Aktivierung eines Panels werden 100 EFHC benötigt.

### 7-2. Wozu dienen Panels im Projekt?

Panels sind die Grundlage des gesamten Systems. Sie erzeugen Energie, bilden die Basis für Wachstum des Accounts und setzen die zentrale Projektmechanik in Gang.

### 7-3. Was bewirkt der Kauf eines Panels?

Der Kauf eines Panels startet oder verstärkt die Energieerzeugung im Account. Dadurch entsteht die Basis für weiteres Wachstum, Umtausch und Fortschritt im Projekt.

### 7-4. Warum sind Panels der Ausgangspunkt für Wachstum?

Weil ohne Panels keine Energie erzeugt wird und ohne Energie es keinen zentralen Fortschritt im Projekt gibt. Panels sind das Fundament der Spielökonomie.

### 7-5. Wo sehe ich meine aktiven Panels?

Aktive Panels werden im Bereich Panels angezeigt. Dort sieht der Nutzer, welche Panels derzeit arbeiten und am Wachstum des Accounts teilnehmen.

### 7-6. Was ist der Unterschied zwischen Active und Archive?

Active sind Panels, die derzeit arbeiten und Energie erzeugen. Archive sind Panels, die nicht mehr aktiv in der laufenden Erzeugung beteiligt sind.

### 7-7. Warum können Panels in den Archive-Bereich wechseln?

Weil die Oberfläche die Panels nach ihrem aktuellen Zustand trennt: aktive separat, archivierte separat. So ist es leichter zu verstehen, welche Panels gerade am Prozess teilnehmen.

### 7-8. Beeinflussen Panels direkt die Energieerzeugung?

Ja. Panels sind genau die Quelle, durch die im Projekt Energie entsteht.

### 7-9. Kann ich die Entwicklung meines Accounts über Panels verstehen?

Ja. Panels zeigen, wie weit der Nutzer den Kern des Projekts bereits aufgebaut hat, denn über sie beginnen Energie, Fortschritt und Wachstum.

### 7-10. Warum gilt das erste Panel als besonders wichtig?

Weil mit dem ersten Panel der echte Einstieg in die Projektlogik beginnt. Ab diesem Moment wird der Account nicht nur registriert, sondern nimmt tatsächlich an Erzeugung und Wachstum teil.

### 7-11. Kann ich ein Panel aktivieren und sofort sehen, dass es aktiv ist?

In der Regel ja. Nach einer erfolgreichen Aktivierung erscheint das Panel im entsprechenden Bereich, und der Account beginnt an der Projektlogik teilzunehmen.

### 7-12. Warum sind Panels das Fundament der ganzen Spielmechanik?

Weil Panels die Energieerzeugung starten, und auf Energie bauen Umtausch, Wachstum, Stufen und der weitere Weg des Nutzers auf.

### 7-13. Kann der Account ohne Panels wachsen?

Der grundlegende Fortschritt des Projekts ist an Panels gebunden. Ohne sie startet die zentrale Erzeugungskette nicht.

### 7-14. Woran erkenne ich, dass meine Panels wirklich arbeiten?

Das sieht man an der Energieanzeige, am allgemeinen Fortschritt des Accounts und an den Bereichen, in denen das System die Erzeugung berücksichtigt.

### 7-15. Warum sind Panels nicht einfach nur eine Aktivierung, sondern ein Wachstumswerkzeug?

Weil ihr Sinn nicht nur im Besitz liegt, sondern darin, Energie zu erzeugen und den Account im Projekt voranzubringen.

### 7-16. Wieso ist der Panel-Preis fest und nicht zufällig?

Weil das Projekt mit einer klaren festen Wirtschaftslogik arbeitet. Die feste Aktivierungsanforderung von 100 EFHC macht die Mechanik verständlich und vorhersehbar.

### 7-17. Wie viel Energie erzeugt ein Panel in 180 Tagen?

Ein Panel erzeugt zum Basistarif in 180 Tagen 107.61984000 kWh. Mit EFHC VIP NFT beträgt die Erzeugung 115.24032000 kWh.

## 8. Energie

### 8-1. Was zeigt die Seite Energy?

Die Seite Energy zeigt den energiebezogenen Fortschritt des Accounts: Erzeugung, Wachstumsdynamik und die wichtigsten Elemente, die mit der Energie des Nutzers verbunden sind.

### 8-2. Warum ist Energy der zentrale Bildschirm des Bots?

Weil sich die Hauptlogik des Projekts um Energie und das Wachstum des Accounts dreht. Diese Seite zeigt den Kern des Systems und den aktuellen Entwicklungsstand des Nutzers.

### 8-3. Was zeigt mir Energy über meinen Account?

Energy zeigt, wie sich der Account im zentralen Pfad des Projekts entwickelt: Energieerzeugung, Gesamtfortschritt und Verbindung zu den Panels.

### 8-4. Kann ich auf Energy verstehen, dass meine Panels wirklich arbeiten?

Ja. Genau dort wird sichtbar, dass die Erzeugungslogik mit dem Account verbunden ist und die Panels den Fortschritt beeinflussen.

### 8-5. Warum ist Energy mit dem Wachstum des Accounts verbunden?

Weil Energie die Grundlage für den Fortschritt im Projekt ist. Durch sie entwickelt sich der Nutzer entlang der zentralen Mechanik.

### 8-6. Warum werden verfügbare Energy und Hauptsaldo getrennt gezählt?

Weil es sich um zwei verschiedene Größen handelt. Verfügbare Energy zeigt die angesammelten kWh, während der Hauptsaldo die bereits gutgeschriebenen Haupt-EFHC zeigt. Diese Werte hängen zusammen, sind aber nicht dasselbe.

### 8-7. Warum wächst Energy von selbst, während der Hauptsaldo nicht automatisch steigt?

Weil die Ansammlung von Energy und das Wachstum des Hauptsaldos in verschiedenen Phasen stattfinden. Zuerst erzeugen die Panels Energy, und der Hauptsaldo steigt erst nach einer separaten Austauschaktion oder einem anderen Szenario zur Gutschrift von Haupt-EFHC.

### 8-8. Wie hängen Energy, Panels und Wachstum zusammen?

Panels erzeugen Energie, und Energie treibt den Fortschritt des Accounts an. Zusammen bilden sie die Hauptentwicklungslinie des Nutzers im Projekt.

### 8-9. Warum kann man gerade über Energy den Zustand des Accounts gut verstehen?

Weil Energy zeigt, ob die zentrale Projektlogik wirklich läuft. Dort sieht man den inneren Zusammenhang zwischen Panels, Erzeugung und Wachstum.

### 8-10. Wie erkenne ich an Energy, dass sich mein Account entwickelt?

Am Fortschritt, an der Energieanzeige und am allgemeinen Gefühl, dass die Erzeugung Teil des laufenden Wachstums geworden ist. Energy zeigt, dass der Account nicht stillsteht, sondern sich bewegt.

### 8-11. Warum können die laufenden Energiezahlen auf dem Bildschirm manchmal leicht korrigiert werden oder springen?

Zu Ihrer Bequemlichkeit werden die angesammelten Energiewerte in Echtzeit auf dem Bildschirm aktualisiert und zeigen einen kontinuierlichen Erzeugungsprozess. Die Hauptquelle der Wahrheit ist jedoch immer der Server. In regelmäßigen Abständen und auch nach jeder Ihrer Aktionen synchronisiert sich die App mit dem Server, um absolute mathematische Genauigkeit sicherzustellen. In diesem Moment kann es zu einer kleinen Korrektur der Bildschirmwerte auf den exakten Serverwert kommen.

## 9. Umtausch

### 9-1. Was ist Exchange?

Exchange ist der Bereich, in dem der Nutzer die bereits erzeugte Energie in EFHC umtauschen kann. Das ist ein zentrales Bindeglied zwischen Erzeugung und Guthaben.

### 9-2. Wozu dient Exchange im Projekt?

Exchange wird benötigt, damit die angesammelte Energie in EFHC umgewandelt werden kann und sich auf den Salden des Nutzers widerspiegelt.

### 9-3. Warum ist Exchange mit Energy verbunden?

Weil der Umtausch genau auf der bereits erzeugten Energie basiert. Erst Energie, dann Exchange, dann die Veränderung des Guthabens.

### 9-4. Kann man sagen, dass Exchange die Energie in Guthaben verwandelt?

Ja. Genau darin liegt der Sinn dieses Bereichs: die erzeugte Energie in EFHC des Accounts umzuwandeln.

### 9-5. Warum ist Exchange einer der Schlüsselbereiche im Bot?

Weil er die Verbindung zwischen der Energieerzeugung und dem finanziellen Ergebnis des Nutzers herstellt. Ohne ihn bliebe die Energie im System, ohne als EFHC wirksam zu werden.

### 9-6. Was muss ich verstehen, bevor ich Exchange nutze?

Dass Exchange auf der bereits verfügbaren Energie basiert. Zuerst wird Energie erzeugt, danach kann sie im entsprechenden Bereich umgetauscht werden.

### 9-7. Zeigt Exchange den Zusammenhang zwischen Erzeugung und Salden?

Ja. Gerade Exchange macht sichtbar, wie aus erzeugter Energie Guthaben des Nutzers wird.

### 9-8. Warum ist Exchange nicht vom restlichen System getrennt?

Weil er Teil einer gemeinsamen Logik ist: Panels → Energy → Exchange → Salden. Alles hängt in einer Kette zusammen.

### 9-9. Welche Energie kann ich bereits umtauschen?

Umtauschen kann man nur den Teil der Energie, der bereits vom System für den Exchange verfügbar gemacht wurde. Nicht jede erzeugte Energie erscheint sofort als sofort tauschbar.

### 9-10. Warum kann nicht die gesamte erzeugte Energie sofort in Exchange erscheinen?

Weil das Projekt zwischen insgesamt erzeugter Energie und bereits für den Umtausch verfügbaren Energievolumen trennt. Das ist ein normaler Teil der internen Logik.

### 9-11. Wie verstehe ich, welche Energie schon bereit für den Umtausch ist?

Man sollte auf die Werte achten, die direkt im Bereich Exchange angezeigt werden. Dort ist sichtbar, welcher Teil bereits für die Aktion verfügbar ist.

### 9-12. Warum ist Exchange ohne Panels und Energy sinnlos?

Weil Exchange keine Energie aus dem Nichts erzeugt. Er arbeitet nur mit dem, was zuvor durch Panels erzeugt und im System als verfügbar erfasst wurde.

### 9-13. Gibt es ein Mindestlimit für den Tausch von Energie in Haupt-EFHC?

Es gibt keine strengen Limits, aber die Tauschlogik folgt dem Kurs 1 kWh = 1 EFHC. Es ist sinnvoll, ganze Energiemengen ab 1 kWh zu sammeln und zu tauschen, damit das Ergebnis sofort auf dem Hauptguthaben sichtbar ist.

## 10. Auszahlung

### 10-1. Warum kann ich EFHC nicht auszahlen?

In der Regel ist eine Auszahlung nicht möglich, wenn die Bedingungen des Projekts noch nicht erfüllt sind: zum Beispiel fehlt eine verbundene Wallet, es gibt nicht genügend geeignetes Guthaben oder der Nutzer hat die erforderliche Aktion im System noch nicht abgeschlossen.

### 10-2. Wofür dient der Bereich Withdraw?

Withdraw ist der Bereich, in dem der Nutzer eine Auszahlung beantragt und den Auszahlungsprozess im Rahmen der Projektregeln durchläuft.

### 10-3. Warum hängt Withdraw von Wallet und dem Guthaben ab?

Weil für eine Auszahlung klar sein muss, wohin die Mittel gehen und aus welchem geeigneten Guthaben sie bezahlt werden. Darum ist Withdraw direkt mit Wallet und den Salden verbunden.

### 10-4. Aus welchem Balance kann man eine Withdrawal machen?

Withdrawal ist nur aus dem Hauptsaldo verfügbar.

### 10-5. Warum ist eine Auszahlung kein Sofort-Knopf?

Weil eine Auszahlung ein eigenständiger Prozess mit Prüfung und Bearbeitung ist und nicht nur eine optische Aktion auf dem Bildschirm.

### 10-6. Was sollte ich prüfen, bevor ich eine Auszahlung beantrage?

Ob die Wallet verbunden ist, ob der richtige Bereich ausgewählt wurde und ob das Guthaben sowie die Projektbedingungen die Beantragung zulassen.

### 10-7. Was passiert nach dem Absenden eines Auszahlungsantrags?

Danach gelangt der Antrag in den Bearbeitungsprozess des Projekts. Der Nutzer sollte den Status verfolgen und die zugehörigen Bereiche des Bots prüfen.

### 10-8. Wo kann ich verstehen, was mit meinem Auszahlungsantrag geschieht?

Das erkennt man über den Status des Antrags, die Saldenhistorie und die Bereiche, in denen das System den Fortschritt solcher Vorgänge anzeigt.

### 10-9. Warum wird die Auszahlung nicht immer sofort abgeschlossen?

Weil Auszahlungen Zeit für Prüfung, Bearbeitung und die Aktualisierung des Status im System benötigen können.

### 10-10. Kann ich den aktuellen Status einer Auszahlung sehen?

Ja. Das Projekt zeigt den Zustand des Antrags in den entsprechenden Bereichen der Oberfläche an, damit der Nutzer versteht, in welcher Phase sich der Vorgang befindet.

### 10-11. Warum ist Withdraw ein eigenständiger Bereich und nicht nur ein Teil von Wallet?

Weil Auszahlung eine separate Nutzerhandlung mit eigener Logik, Bedingungen und Statusdarstellung ist. Deshalb ist sie in einen eigenen Abschnitt ausgelagert.

### 10-12. Warum kann Withdrawal nicht verfügbar sein, obwohl ich EFHC habe?

Weil für Withdrawal nur der Hauptsaldo zählt. Wenn sich EFHC im Bonus-Teil des Saldos befinden, kann dafür keine Withdrawal eingereicht werden.

### 10-13. Wie erkenne ich, dass das System meinen Auszahlungsantrag akzeptiert hat?

Das sieht man daran, dass ein Antrag im System erscheint und sein Status angezeigt wird. Danach ist der Vorgang bereits in die Bearbeitung übernommen.

### 10-14. In welchen Token und in welchem Netzwerk werden Auszahlungen durchgeführt?

Auszahlungen erfolgen ausschließlich in EFHC-Token und nur im TON-Blockchain-Netzwerk (The Open Network). Andere Auszahlungsvarianten gibt es im Projekt nicht.

### 10-15. Wie lange dauert die manuelle Bearbeitung einer Auszahlung durch einen Operator?

Auszahlungsanträge werden von den Operatoren in einer Live-Warteschlange bearbeitet. Die Bearbeitung dauert gewöhnlich von einigen Minuten bis zu 24 Stunden, abhängig von der Netzwerkauslastung und der Anzahl der Anträge. Sie können einen noch nicht bearbeiteten Antrag jederzeit stornieren, und die Mittel kehren sofort auf Ihr Guthaben zurück.

## 11. Aufgaben

### 11-1. Was bringt das Erfüllen von Aufgaben?

Aufgaben geben nur Bonusmünzen und motivieren zur aktiven Teilnahme am Projektleben.

### 11-2. Wie erhalte ich die Belohnung für eine Aufgabe?

Sie müssen die Bedingungen der Aufgabe erfüllen. Danach erkennt der Bot die Erfüllung automatisch und schreibt die vorgesehene Belohnung gut.

### 11-3. Warum wurde die Aufgabe nicht angerechnet?

Das kann passieren, wenn die Bedingungen noch nicht vollständig erfüllt sind, die Aktion nicht vollständig abgeschlossen wurde oder das Ergebnis im System noch nicht aktualisiert wurde.

### 11-4. Kann ich dieselbe Aufgabe noch einmal machen?

Das hängt vom Aufgabentyp ab. Manche Aufgaben sind einmalig, andere können sich gemäß der Projektlogik wiederholen.

### 11-5. Geben alle Aufgaben die gleiche Belohnung?

Nein. Die Höhe der Belohnung hängt von der konkreten Aufgabe und ihren Bedingungen ab. Der Belohnungstyp ist hier jedoch immer derselbe: Bonusmünzen.

### 11-6. Warum brauche ich Aufgaben überhaupt, wenn es Panels gibt?

Aufgaben sind ein zusätzlicher Wachstumsweg. Sie ersetzen die Panels nicht, sondern helfen dabei, Bonusmünzen zu sammeln, die später innerhalb des Spielzyklus genutzt werden können.

### 11-7. Warum kommt die Aufgabenbelohnung nicht auf das Hauptguthaben?

Weil Aufgaben Bonus-EFHC geben. Das ist eine interne Belohnung für den Spielzyklus, daher wird sie dem Bonusguthaben gutgeschrieben.

### 11-8. Warum enden oder verschwinden Aufgaben manchmal?

Weil Aufgaben zeitlich befristet sein oder ein Limit haben können. Wenn eine Aufgabe nicht da ist, wurde sie beendet oder ist derzeit nicht aktiv.

### 11-9. Wo sehe ich alle verfügbaren Aufgaben?

Im Bereich Tasks. Dort werden die Liste der verfügbaren Aufgaben und ihre Bedingungen angezeigt.

### 11-10. Warum erschien die Belohnung für die Aufgabe nicht sofort?

Manchmal braucht das Ergebnis etwas Zeit für die Aktualisierung. Prüfen Sie: Tasks aktualisieren → Bonusguthaben prüfen → Verlauf der Operationen prüfen.

### 11-11. Ich habe den im Task geforderten Kanal abonniert, aber der Task wird nicht abgeschlossen. Warum?

Manchmal braucht die Abo-Prüfung wegen des Cachings auf den Telegram-Servern etwas Zeit. Wenn der Bot das Abo nicht sofort gezählt hat, kehren Sie nach einigen Minuten in den Bereich Tasks zurück und drücken Sie die Prüftaste erneut.

## 12. Empfehlungen

### 12-1. Wie heißen die Bereiche auf der Referrals-Seite?

Auf der Referrals-Seite werden die Bereiche Aktiv und Inaktiv verwendet.

### 12-2. Was bedeutet aktiver und inaktiver Referral?

Ein aktiver Referral ist ein Spieler, der bereits mindestens ein Panel gekauft und den Status Activ erhalten hat. Ein inaktiver Referral ist jemand, der noch nicht in den Spielzyklus eingestiegen ist und daher noch keinen Bonus auslöst.

### 12-3. Wann werden Referral-Boni gutgeschrieben?

Referral-Boni werden vom Bot automatisch geprüft. Sobald ein Spieler aktiv wird, wird der Bonus sofort automatisch gutgeschrieben.

### 12-4. Was bringt der aktive Status für Referrals?

Der aktive Status ist für die Referral-Logik wichtig, weil das Projekt ihn als Teil des Filters für echte Teilnahme und als Schutz vor Bots, Bot-Farmen und künstlicher Aktivität verwendet.

### 12-5. Wie hängt Activ mit Referrals zusammen?

Activ zeigt, dass der Nutzer ein echter Projektteilnehmer und kein Bot-Account ist. Das ist wichtig für den fairen Betrieb des Referral-Systems und den Schutz vor Bot-Farmen.

### 12-6. Welcher Basisbonus wird für jeden aktiven Referral gutgeschrieben?

Für jeden aktiven Referral werden 0.1 EFHC dem Bonusguthaben gutgeschrieben.

### 12-7. Warum sind meine Referrals da, aber der Bonus wurde nicht gutgeschrieben?

Der Bonus wird nur für aktive Referrals gutgeschrieben — also für Nutzer, die mindestens ein Panel gekauft und Activ erhalten haben. Prüfen Sie die Tabs „Aktiv“ und „Inaktiv“: meistens sind die Eingeladenen noch nicht in den aktiven Status gewechselt.

### 12-8. Wohin werden 0.1 EFHC für einen aktiven Referral gutgeschrieben?

Der Bonus von 0.1 EFHC wird dem Bonusguthaben gutgeschrieben. Es ist eine interne Belohnung des Referral-Systems und im Bonusguthaben sowie im Verlauf der Operationen sichtbar.

### 12-9. Warum ist der Eingeladene in der Liste, wird aber nicht als aktiv gezählt?

Weil er erst nach dem Kauf des ersten Panels und dem Erhalt von Activ als aktiv gilt. Solange das nicht passiert ist, bleibt er im inaktiven Teil der Liste.

### 12-10. Wo finde ich meinen Referral-Link?

Im Bereich Referrals. Dort werden Ihr Referral-Link und die Liste der eingeladenen Nutzer angezeigt.

### 12-11. Ist es erlaubt, zusätzliche Konten über den eigenen Referral-Link zu erstellen?

Ja. Das ist durch die Projektregeln nicht verboten. Leere Konten bringen Ihnen jedoch keinen Vorteil. Die Systemökonomie ist so aufgebaut, dass Referral-Boni und Ranking-Wachstum nur für einen Teilnehmer mit Activ-Status gutgeschrieben werden — also nachdem das eingeladene Konto tatsächlich ins Spiel eintritt und mindestens ein Panel kauft.

### 12-12. Kann ich meinen Einlader nach der Registrierung ändern?

Nein. Die Referral-Verbindung wird beim ersten Eintritt in das Projekt über einen Einladungslink festgelegt und kann später nicht mehr geändert werden.

## 13. Hub

### 13-1. Was kann ich im Hub tun?

Im Hub sind Karten verfügbar, die zu verbundenen Projektaktionen führen: der Übergang zum externen Ablauf für den Erhalt von EFHC und der Übergang zur externen VIP-NFT-Kollektion.

### 13-2. Wofür dient der Hub?

Der Hub dient als Navigation Layer für schnelle Übergänge zu verbundenen Aktionen und externen Projektabläufen.

### 13-3. Welche Karten gibt es im Hub?

Im aktuellen Stadium sind im Hub zwei Karten verfügbar: EFHC und VIP.

### 13-4. Was macht die EFHC-Karte?

Die EFHC-Karte startet den Übergang zum externen Ablauf für den Erhalt von EFHC.

### 13-5. Wohin wird die EFHC-Aufladung nach der Bestätigung gutgeschrieben?

Eine EFHC-Jetton-Aufladung wird dem Hauptguthaben gutgeschrieben.

### 13-6. Warum erscheint das Ergebnis der Aufladung möglicherweise nicht sofort?

Zuerst muss die externe Phase der Operation bestätigt werden, danach wird das Ergebnis aktualisiert. Prüfen Sie Hub, das Hauptguthaben und den Verlauf der Operationen.

### 13-7. Wenn ich ein VIP NFT über GetGems erhalten habe, wo sehe ich, dass es aktiv ist?

Prüfen Sie den VIP-Status in der App und das Vorhandensein des NFT in der verbundenen Wallet.

### 13-8. Ich habe den externen Ablauf aus dem Hub durchlaufen, aber es gibt kein Ergebnis. Was soll ich tun?

Prüfen Sie Hub, das Hauptguthaben und den Verlauf der Operationen. Wenn es noch immer kein Ergebnis gibt, wurde die Operation noch nicht übernommen oder erfordert eine separate Verarbeitung.

### 13-9. Auf welches Guthaben wird die Aufladung über Top Up und Hub gebucht?

Eine EFHC-Jetton-Aufladung wird dem Hauptguthaben gutgeschrieben.

### 13-10. Brauche ich für Aktionen aus dem Hub eine verbundene Wallet?

Für externe wallet-basierte Aktionen ist eine verbundene Wallet erforderlich. Der Hub selbst wird ohne separaten Kauf geöffnet und dient als Übergangspunkt.

### 13-11. Wo kann ich prüfen, dass die EFHC-Aufladung tatsächlich gutgeschrieben wurde?

Prüfen Sie das Hauptguthaben und den Verlauf der Operationen: Dort sollte eine Spur der Aufladung erscheinen.

### 13-12. Gibt es Skins im Hub?

Skins sind keine Hub-Karten.

### 13-13. Wie bekomme ich Projekt-Skins?

Skins werden mit dem Fortschritt des Accounts freigeschaltet und sind an die 12 Erfolgsstufen gebunden.

## 14. Navigation und Regeln

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Welche Bildschirme sollte ich zuerst öffnen, wenn ich das WebApp zum ersten Mal oder nach einer langen Pause betrete?

Am besten beginnen Sie mit dem Hauptbildschirm, der oberen Leiste und dem Profil. Danach ist es leichter, je nach aktueller Aufgabe zu Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History und Hub zu wechseln.

### 14-3. Wie erkenne ich, in welchem Bereich ich die benötigte Funktion finde?

Orientieren Sie sich an der Bedeutung der Aktion: Profile — für Accountdaten und Referenzinformationen, Wallet — für die Wallet, Panels — für Panels, Energy — für Erzeugung, Exchange — für Austausch, Withdraw — für Auszahlungen, Tasks — für Aufgaben, Referrals — für eingeladene Nutzer und Hub — für Übergänge zu verbundenen EFHC- und VIP-Aktionen.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Werbung

### 15-1. Was ist das für ein Bereich?

Der Bereich Ads ist ein Unterbereich im Bereich Tasks. Er zeigt verfügbare Werbeaktionen, durch die der Nutzer zusätzliche Bonusmünzen erhalten kann.

### 15-2. Was bringt er mir?

Er gibt nur Bonusmünzen für Aufrufe, wenn Werbung für den Account des Nutzers derzeit verfügbar ist.

### 15-3. Warum ist hier nichts?

Wenn der Bereich leer ist, bedeutet das, dass für den Nutzeraccount derzeit keine aktiven Angebote vorhanden sind oder die Werbung vorübergehend deaktiviert ist.

### 15-4. Wo befindet sich der Bereich Ads?

Der Bereich Ads befindet sich als Unterbereich innerhalb von Tasks. Es ist eine der zusätzlichen Möglichkeiten innerhalb des Aufgabenblocks.

### 15-5. Welche Art von Belohnung gibt Ads?

Ads gibt nur Bonusmünzen für Aufrufe. Das ist kein Hauptguthaben und keine direkte Auszahlung, sondern eine zusätzliche interne Möglichkeit, den Spielweg zu verstärken.

### 15-6. Warum ist Ads nützlich?

Weil es eine zusätzliche Quelle von Bonusmünzen ist. Es ersetzt weder Panels noch Generierung, kann aber helfen, den internen Spielzyklus schneller zu verstärken.

### 15-7. Warum gibt es Werbung bei anderen, aber nicht bei mir?

Weil Angebote für einen bestimmten Account nicht verfügbar sein können oder Werbung vorübergehend deaktiviert ist. Ein leerer Ads-Bereich bedeutet nicht, dass der Account defekt ist.

### 15-8. Was tun, wenn ich eine Aktion in Ads ausgeführt habe, aber es kein Ergebnis gibt?

Prüfen Sie: Tasks/Ads aktualisieren → Bonusguthaben prüfen → Verlauf der Operationen prüfen.

### 15-9. Warum können verschiedene Nutzer in Ads unterschiedliche Angebote sehen?

Weil die Angebote von der Verfügbarkeit von Werbekampagnen für den jeweiligen Account abhängen. Das ist normal: der eine hat Angebote, der andere vorübergehend nicht.

### 15-10. Muss ich etwas kaufen, um Ads zu nutzen?

Nein. Ads ist eine Möglichkeit, Bonus-EFHC zu erhalten, und erfordert keine verpflichtenden Käufe.

## 16. Ranks

### 16-1. Warum ist Wachstum im Ranking für mich wichtig?

Wachstum im Ranking zeigt, wie Ihr Fortschritt im Vergleich zu anderen Teilnehmern aussieht. Das hilft Ihnen, Ihren aktuellen Platz zu verstehen und zu sehen, wie aktiv sich der Account entwickelt.

### 16-2. Worin unterscheidet sich ein Level vom Ranking?

Das Level zeigt den persönlichen Fortschritt innerhalb des Systems, das Ranking dagegen den Platz des Nutzers unter anderen Teilnehmern.

### 16-3. Wie hängen Level und Ranking zusammen?

Sie sind durch dieselbe allgemeine Wachstumslogik verbunden: durch die Erzeugung von kWh mit Panels und durch den gemeinsamen Fortschrittsbalken auf der Seite Energy.

### 16-4. Ist das Ranking nur eine hübsche Zahl?

Nein. Das Ranking hilft zu verstehen, wie Ihr Weg im Vergleich zu anderen Teilnehmern aussieht.

### 16-5. Was beeinflusst das Wachstum meiner Position im Ranking?

Das Wachstum Ihrer Position im Ranking hängt vom gesamten Fortschritt des Accounts ab: Entwicklung der Panels, Generierung von kWh und die gesamte Bewegung auf dem Energiepfad des Projekts.

### 16-6. Kann man gleichzeitig im Level und im Ranking steigen?

Ja. Wenn ein Nutzer seine Panels, die Erzeugung und den allgemeinen Energie-Fortschritt ausbaut, stärkt er in der Regel sowohl sein Level als auch seine Position im Ranking.

### 16-7. Warum habe ich ein hohes Level, aber nicht den ersten Platz im Ranking?

Weil das Ranking den Platz unter allen Teilnehmern zeigt und nicht nur Ihren persönlichen Fortschritt. Andere Spieler wachsen ebenfalls, deshalb kann sich Ihr Platz auch bei einem guten Level verändern.

### 16-8. Warum kann sich mein Ranking verschieben, auch wenn ich keine neuen Aktionen ausgeführt habe?

Weil das Ranking nicht für sich allein existiert, sondern im Vergleich mit allen Teilnehmern. Während Sie nichts ändern, wachsen andere Nutzer weiter, und das beeinflusst Ihre Position.

### 16-9. Wo sehe ich meinen Platz im Ranking?

Im Bereich Ranks — dort wird Ihr Platz unter den anderen Teilnehmern angezeigt.

### 16-10. Warum kann mein Ranking sinken, obwohl ich selbst Fortschritte mache?

Weil für das Ranking nicht nur Ihr eigenes Wachstum wichtig ist, sondern auch die Wachstumsgeschwindigkeit anderer Teilnehmer. Selbst wenn Ihr Konto stärker wird, kann Ihr Platz sinken, wenn andere Sie schneller überholen.

## 17. Activ-Status

### 17-1. Was bedeutet der Status Activ?

Activ ist ein dauerhafter aktiver Status. Er bedeutet, dass das Spiel wirklich begonnen hat, weil mindestens ein Panel gekauft wurde.

### 17-2. Wie erhält man Activ?

Um Activ zu erhalten, reicht es aus, ein Panel zu aktivieren. Danach wird der Status dauerhaft vergeben.

### 17-3. Ist Activ vorübergehend oder dauerhaft?

Activ ist ein dauerhafter Status.

### 17-4. Bleibt Activ erhalten, wenn ein Panel später ins Archive geht?

Ja. Auch wenn ein Panel später ins Archive geht, bleibt der Status Activ erhalten.

### 17-5. Warum ist Activ wichtig?

Activ hilft, echte Spieler von zufälligen Registrierungen, Bots und Bot-Farmen zu unterscheiden. Es bestätigt die echte Teilnahme des Nutzers am Projekt.

### 17-6. Kann Activ später verschwinden?

Nein. Activ ist ein dauerhafter Status und bleibt erhalten, auch wenn das erste Panel später ins Archive geht.

### 17-7. Warum wird Activ zum Schutz vor Bots und Bot-Farmen verwendet?

Weil Activ eine echte Teilnahme bestätigt und keinen leeren Account für künstliches Aufblähen. Dadurch werden das Empfehlungssystem und die Ökonomie fairer.

### 17-8. Was ändert sich im Account nach dem Erhalt von Activ?

Der Account gilt als bestätigter, realer Teilnehmer des Projekts. Das beeinflusst die faire Arbeit der Empfehlungen und das Vertrauen in die Aktivität.

### 17-9. Warum erscheint Activ gerade nach dem ersten Panel?

Weil der Kauf des ersten Panels ein klares Zeichen für echte Beteiligung ist. Das Projekt nutzt diesen Schritt als Filter gegen leere Accounts.

### 17-10. Kann man Activ durch Inaktivität verlieren?

Nein. Activ ist ein dauerhafter Status und verschwindet nicht wegen Inaktivität.

## 18. VIP NFT

### 18-1. Was ist EFHC VIP NFT?

EFHC VIP NFT ist eine Clubkarte, ein Schlüssel zum gesamten zukünftigen EFHC-Ökosystem, ein digitales Zeichen der Zugehörigkeit und ein Schlüssel zu den künftigen Möglichkeiten des Projekts.

### 18-2. Was bringt der Besitz eines EFHC VIP NFT?

Der Besitz eines EFHC VIP NFT erhöht die Erzeugung für alle Panels des Spielers.

### 18-3. Woran sieht man, dass VIP bereits berücksichtigt wird?

Wenn das VIP NFT bereits vom System berücksichtigt wird, ist im Interface der VIP-Status sichtbar und die dazugehörigen Account-Vorteile werden bemerkbar.

### 18-4. Wo sehe ich den VIP-Effekt?

Der VIP-Effekt ist in den Bereichen sichtbar, in denen das Projekt die Vorteile des VIP NFT berücksichtigt, sowie in der oberen Leiste und im Profil/in den Einstellungen.

### 18-5. Muss man VIP manuell einschalten?

Nein. Die Logik des Projekts ist auf eine automatische Prüfung der Wallet und eine automatische Aktualisierung des VIP-Status ausgelegt, nachdem das NFT in der richtigen Kollektion erkannt wurde.

### 18-6. Bringen 2 oder 3 VIP NFT dem Spieler zusätzliche Privilegien?

Nein. Für den Spieler bringt der Besitz von 2 oder 3 VIP NFT keine zusätzlichen Privilegien über ein einziges VIP NFT hinaus.

### 18-7. Warum verstärkt ein zweites VIP NFT den Effekt nicht?

Im Projekt verleiht VIP einen Generierungsbonus als ein einziger aktiver Status. Zusätzliche VIP NFT geben keine zusätzliche Verstärkung, damit der Effekt nicht endlos skaliert.

### 18-8. Wirkt VIP auf ein einzelnes Panel oder auf alle?

VIP wirkt auf die Generierung aller Panels des Nutzers und nicht nur auf ein einzelnes Panel.

### 18-9. Wie kann ich prüfen, dass VIP den Account wirklich beeinflusst?

Prüfen Sie nicht nur das Vorhandensein des VIP-Status, sondern auch die damit verbundenen Vorteile in der Account-Mechanik, besonders dort, wo der VIP-Effekt berücksichtigt wird, einschließlich der Generierung.

### 18-10. Braucht man eine verbundene Wallet, damit der Bot mein VIP NFT sieht?

Ja. Damit der Bot das VIP NFT sieht, muss er wissen, welche Wallet zum Account gehört. Deshalb muss Wallet verbunden sein, und danach prüfen Sie den VIP-Status im Interface.

### 18-11. Kann ich frei über mein VIP NFT verfügen?

Ja. EFHC VIP NFT kann übertragen, verschenkt und auf Marktplätzen verkauft werden.

### 18-12. Was passiert mit meiner Generierung, wenn ich mein VIP NFT verkaufe oder auf eine andere Wallet übertrage?

Der Bot scannt regelmäßig die Blockchain und prüft, ob sich das NFT auf Ihrer verknüpften Wallet befindet. Wenn Sie Ihr VIP NFT verkaufen, verschenken oder auf eine andere Adresse verschieben, erkennt das System dies, deaktiviert Ihren VIP-Status und die Generierung all Ihrer Panels kehrt automatisch zum Basistarif zurück.

## 19. Stufen

### 19-1. Warum sollte ich mein Level erhöhen?

Ein höheres Level zeigt den Fortschritt des Nutzers innerhalb des Projekts und hilft zu sehen, wie sich der Account entwickelt. Es ist ein visueller und inhaltlicher Indikator für die Bewegung nach vorn.

### 19-2. Was umfasst der Bereich Stufen?

Der Bereich Stufen zeigt alle Wachstumsskalen des Projekts: 12 Stufen des Energie-Fortschritts, 6 Stufen des Empfehlungssystems und andere Stufenlinien des Projekts, falls sie hinzugefügt werden.

### 19-3. Wie viele Stufen des Energie-Fortschritts gibt es im Projekt?

Im Projekt sind 12 Stufen des Energie-Fortschritts vorgesehen.

### 19-4. Wie viele Stufen gibt es im Empfehlungssystem?

Im Projekt sind 6 Stufen des Empfehlungssystems vorgesehen: von 0 bis 5.

### 19-5. Worin sind Stufen für einen normalen Spieler nützlich?

Stufen helfen zu verstehen, wo Sie jetzt stehen, wie viel bereits getan wurde, wohin es als Nächstes geht und welche nächste Marke vor Ihnen liegt.

### 19-6. Wie hängen Energiestufen, Empfehlungsstufen und das allgemeine Wachstum des Accounts zusammen?

Das sind Teile eines gemeinsamen Weges. Die Energieerzeugung treibt den Hauptfortschritt voran, aktive Empfehlungen stärken die Empfehlungslinie, und zusammen zeigen sie, wie stark sich der Account entwickelt.

### 19-7. Eco Initiate (0 kWh)

**Bedeutung für den Spieler:** Ihr erstes Panel ist installiert und bereit für den Betrieb. Sie machen den wichtigsten Schritt, um ein unabhängiger Erzeuger sauberer Energie zu werden. Das ist Ihr Startstatus — Sie sind gerade erst in den Weg der Erzeugung eingetreten.

**Genaue Regel:** Die Stufe Eco Initiate entspricht der Marke von 0 kWh.

**Praktische Folge:** Der nächste Schritt ist, das Wachstum der Erzeugung über Panels zu starten und den Fortschritt auf 100 kWh zu bringen.

### 19-8. Hope Bringer (100 kWh)

**Bedeutung für den Spieler:** Die ersten Kilowatt sind da! Ihre Panels erzeugen erfolgreich grüne Energie und geben der Natur Hoffnung auf eine kohlenstofffreie Zukunft. Sie sehen bereits die ersten echten Ergebnisse: Die Energie fließt und der Fortschritt hat sich bewegt.

**Genaue Regel:** Die Stufe Hope Bringer beginnt bei 100 kWh.

**Praktische Folge:** Das nächste Ziel ist, die Stabilität auszubauen und 300 kWh für die nächste Stufe zu erreichen.

### 19-9. Energy Seeker (300 kWh)

**Bedeutung für den Spieler:** Das System arbeitet ausgezeichnet und speist das Netz stabil mit ökologisch sauberem Strom. Jede von Panels erzeugte Einheit Energie verdrängt fossile Brennstoffe. Der Account ist in den Modus stabilen Wachstums eingetreten: Sie sind kein „Neuling“ mehr, sondern ein Nutzer mit echter Erzeugung.

**Genaue Regel:** Die Stufe Energy Seeker beginnt bei 300 kWh.

**Praktische Folge:** Praktisch ist das ein Signal: Sie können die Panels stärken und Exchange häufiger nutzen, um Energie in das Hauptguthaben umzuwandeln.

### 19-10. Nature's Voice (600 kWh)

**Bedeutung für den Spieler:** Ihr Beitrag wird sichtbar. Indem Sie mit grünen Technologien Energie erzeugen, werden Sie zur Stimme der Natur und beweisen, dass Fortschritt umweltfreundlich sein kann. Ihr Beitrag wird deutlicher: Der Fortschritt fühlt sich nicht mehr wie Zufall an, sondern wie eine klare Entwicklungslinie.

**Genaue Regel:** Die Stufe Nature's Voice beginnt bei 600 kWh.

**Praktische Folge:** Die nächste Orientierung ist 1000 kWh (Earth Ally). Es ist sinnvoll, das Tempo in Energy und die Zahl aktiver Panels zu prüfen.

### 19-11. Earth Ally (1000 kWh)

**Bedeutung für den Spieler:** Die erste Megawattstunde ist erzeugt! Ihre Panels haben ein beeindruckendes Volumen sauberer Energie produziert. Jetzt sind Sie ein wichtiger Teilnehmer des grünen Übergangs und ein verlässlicher Verbündeter des Planeten. Sie haben eine wichtige Marke überschritten: 1000 kWh ist bereits ein ernstzunehmendes Volumen angesammelter Erzeugung.

**Genaue Regel:** Die Stufe Earth Ally beginnt bei 1000 kWh.

**Praktische Folge:** Praktisch ist das der Punkt, an dem Wachstum vorhersehbar wird: Bauen Sie Ihren Panel-Park aus und halten Sie den regelmäßigen Energieaustausch aufrecht.

### 19-12. Climate Fighter (2000 kWh)

**Bedeutung für den Spieler:** Ihre Erzeugung versetzt dem Klimawandel einen realen Schlag. Jedes erzeugte Kilowatt senkt direkt den Bedarf, Kohle und Gas zu verbrennen. Sie üben bereits systematisch Druck durch Wachstum aus: Der Fortschritt ist sowohl auf dem Level als auch in der Gesamtdynamik des Accounts sichtbar.

**Genaue Regel:** Die Stufe Climate Fighter beginnt bei 2000 kWh.

**Praktische Folge:** Der nächste Schritt ist, das Tempo zu stabilisieren und 3500 kWh zu erreichen. Achten Sie auf die Generierungsgeschwindigkeit und nutzen Sie bei Bedarf VIP.

### 19-13. Green Sentinel (3500 kWh)

**Bedeutung für den Spieler:** Der stabile Energiestrom Ihrer Panels wacht über saubere Luft. Sie bringen der Gesellschaft spürbaren Nutzen, ohne dabei einen CO₂-Fußabdruck zu hinterlassen. Ihr Account wird zum „Wächter“ stabiler Erzeugung: Das Wachstum läuft sicher.

**Genaue Regel:** Die Stufe Green Sentinel beginnt bei 3500 kWh.

**Praktische Folge:** Praktisch bedeutet das: Die Panels arbeiten bereits als System — halten Sie aktive Panels aufrecht und planen Sie das Wachstum bis 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Bedeutung für den Spieler:** 5000 kWh saubere Erzeugung! Die Leistung Ihrer Panels wirkt wie ein unsichtbarer Schild, der die Atmosphäre vor Tausenden Kilogramm Treibhausgasemissionen schützt. 5000 kWh sind ein starkes Zeichen für Größe: Sie befinden sich bereits in der Zone starker Energie-Teilnehmer.

**Genaue Regel:** Die Stufe Planet Defender beginnt bei 5000 kWh.

**Praktische Folge:** Die nächste Orientierung ist 7500 kWh. Oft stärken Spieler in diesem Moment sowohl ihre Panels als auch ihr Empfehlungsnetz.

### 19-15. Eco Champion (7500 kWh)

**Bedeutung für den Spieler:** Herausragende Produktionsmengen! Sie sind ein echter Champion der grünen Energie, dessen Beitrag das globale Energiegleichgewicht spürbar zum Besseren verändert. Das ist die Stufe derer, die konstant ein hohes Erzeugungstempo halten.

**Genaue Regel:** Die Stufe Eco Champion beginnt bei 7500 kWh.

**Praktische Folge:** Praktisch: Halten Sie Disziplin — aktive Panels, regelmäßiger Exchange, Kontrolle von Verlauf und Guthaben.

### 19-16. Planet Saver (10000 kWh)

**Bedeutung für den Spieler:** 10 Megawattstunden! Sie haben so viel saubere Energie erzeugt, dass Sie buchstäblich ganze Ökosysteme retten und die maximale Effizienz Ihrer Panels beweisen. 10.000 kWh sind bereits „zehn Megawattstunden“ Erzeugung — eine sehr starke Etappe des Fortschritts.

**Genaue Regel:** Die Stufe Planet Saver beginnt bei 10000 kWh.

**Praktische Folge:** Der nächste Schritt ist 15000 kWh. In dieser Phase lohnt es sich, alles zu optimieren: Panels, VIP, Empfehlungen, Käufe.

### 19-17. Green Commander (15000 kWh)

**Bedeutung für den Spieler:** Flaggschiff der ökologischen Erzeugung. Ihre Panels versorgen die Zukunft, und die beeindruckenden Produktionsmengen setzen für die gesamte Community neue, hohe Standards. Sie sind nahe am Gipfel: Das ist eine Stufe von Führungsgröße in der Energie.

**Genaue Regel:** Die Stufe Green Commander beginnt bei 15000 kWh.

**Praktische Folge:** Praktisch: Halten Sie die Stabilität und steigern Sie bis 20000+ kWh, wobei Sie aktive Panels und das Tempo in Energy im Blick behalten.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Empfehlungsstufe 0

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 0 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-20. Empfehlungsstufe 1

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 1 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-21. Empfehlungsstufe 2

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 10 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-22. Empfehlungsstufe 3

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 100 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-23. Empfehlungsstufe 4

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 300 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-24. Empfehlungsstufe 5

**Bedeutung für den Spieler:** Dies ist die Marke Ihres Wachstums im Empfehlungssystem — sie zeigt das Ausmaß aktiver eingeladener Nutzer.

**Genaue Regel:** Für das Erreichen der Stufe wird ein einmaliger Bonus gutgeschrieben: 1000 EFHC.

**Praktische Folge:** Praktisch: Prüfen Sie nach Erreichen der Stufe das Bonusguthaben und den Operationsverlauf, um die Gutschrift zu sehen.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Warum sind die Namen der Levels mit Ökologie und dem Planeten verbunden?

Weil die Grundidee des Spiels mit virtueller grüner Energie, der Motivation von Menschen und einem symbolischen Beitrag zur Gesundung des Planeten Erde verbunden ist.

## 20. FAQ / Hilfe

### 20-1. Wo öffnet man das FAQ?

Das FAQ wird aus dem Profil als integrierter Hilfebereich des Bots geöffnet, in dem Antworten zu den wichtigsten Aktionen, Bildschirmen und Projektregeln gesammelt sind.

### 20-2. Wozu dient FAQ / Hilfe?

Dieser Bereich ist dazu da, damit der Nutzer schnell verständliche Antworten, genaue Zahlen, echte Projektregeln und den Sinn der wichtigsten Aktionen ohne Rätselraten und Verwirrung findet.

### 20-3. Warum ist das FAQ so ausführlich beschrieben?

Weil das Projekt vielschichtig ist und eine kurze, trockene Hilfe die echten Fragen des Spielers nicht abdeckt. Hier sind Sinn, Verständlichkeit, genaue Zahlen und die realen Folgen von Handlungen wichtig.

### 20-4. Kann man anhand des FAQ den gesamten Weg des Spielers im Bot verstehen?

Ja. Ein gutes FAQ sollte nicht nur einzelne Buttons erklären, sondern den ganzen Weg: vom ersten Panel über Energie, Umtausch, Guthaben, Stufen, Status und das Wachstum des Accounts.

### 20-5. Was tun, wenn ich die Antwort beim ersten Mal nicht gefunden habe?

Am besten öffnen Sie einen thematisch nahen Bereich und sehen sich die benachbarten Fragen an. In einem großen Bot hängen viele Antworten zusammen, und ein Block hilft oft, den nächsten zu verstehen.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. Was sollte ich prüfen, wenn „alles kaputt aussieht“?

Prüfen Sie drei Dinge: 1) Wallet — ist die Wallet verbunden und ist die Haupt-Wallet ausgewählt, 2) Guthaben und Verlauf — gibt es dort eine Spur Ihrer Operation, 3) den richtigen Bereich (Panels / Energy / Exchange / Withdraw). Meistens liegt die Antwort an einem dieser Orte.

### 20-8. Wie finde ich am schnellsten heraus, was mit meinen EFHC passiert ist?

Öffnen Sie den Guthabenverlauf. Der Verlauf zeigt, was genau die Guthaben verändert hat: Belohnung, Kauf, Umtausch oder Auszahlung.

### 20-9. Womit beginne ich, wenn ich den Bot zum ersten Mal geöffnet habe und nichts verstehe?

Beginnen Sie mit Energy (dem Hauptbildschirm), öffnen Sie dann Panels, sehen Sie sich Guthaben und Verlauf an und entscheiden Sie erst danach, ob Sie eine Wallet und eine Aufladung brauchen.

### 20-10. Wie finde ich die gewünschte Frage im FAQ am schnellsten?

Der schnellste Weg ist, den passenden Themenbereich zu öffnen (Wallet / Panels / Exchange / Withdraw usw.) und dort nach der Frage zu suchen. Wenn Sie unsicher sind, beginnen Sie mit dem Bereich FAQ / Hilfe und orientieren Sie sich an den Schlüsselwörtern.
