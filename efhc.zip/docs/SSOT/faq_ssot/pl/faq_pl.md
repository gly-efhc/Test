# EFHC FAQ (PL)

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. O projekcie

### 1-1. Czym jest EFHC?

EFHC to projekt gry o energii, postępie i rozwoju konta wewnątrz bota. Użytkownik kupuje panele, gromadzi energię, wymienia ją na EFHC, śledzi swoje salda, rośnie poziomami, przesuwa się w rankingu i korzysta z dodatkowych możliwości projektu.

Znaczenie:
— EFHC — Energy for Humanity Coin
— EFHCm — monety główne
— EFHCb — monety bonusowe
— EFHCj — zewnętrzny jetton EFHC
— EFHC — saldo łączne (bonusowe + główne)

### 1-2. Jak to tutaj działa?

W projekcie wszystko opiera się na energii i wzroście konta. Użytkownik pracuje z panelami, gromadzi energię, wymienia ją na główne EFHC, śledzi salda, podłącza portfel, wzmacnia swój postęp i korzysta z dodatkowych mechanik systemu.

Główna logika jest prosta: panele → generacja energii → wymiana → EFHC → rozwój konta.

### 1-3. Co mam robić w tym bocie?

Główne zadanie to rozwijać konto. W tym celu użytkownik pracuje z panelami, śledzi generację energii, korzysta z Exchange, analizuje swoje salda, podłącza portfel, bierze udział w dodatkowych mechanikach projektu i stopniowo wzmacnia swój postęp.

### 1-4. Jak tutaj rosnąć i iść do przodu?

Wzrost w bocie opiera się na energii i aktywności. Im więcej użytkownik ma paneli, energii, użytecznych działań i realnego postępu, tym silniej rozwija się konto i tym wyżej wspina się w systemie poziomów oraz rangi.

### 1-5. Jaki jest główny sens projektu?

Główny sens projektu polega na pokazaniu drogi od aktywacji panelu do generowania energii, a następnie do wyniku w EFHC. Użytkownik widzi nie abstrakcyjne liczby, lecz spójny łańcuch: panel, energia, wymiana, saldo, postęp, poziomy i miejsce wśród innych uczestników.

### 1-6. Czy to tylko rozrywka, czy jest tu logika rozwoju?

Jest tu pełna logika wzrostu. Użytkownik nie tylko klika przyciski, lecz stopniowo wzmacnia swoje konto: kupuje panele, uruchamia generację, otrzymuje status aktywny, zbiera nagrody, rozwija system poleceń i widzi rezultat swojego postępu.

### 1-7. Skąd biorą się moje pierwsze EFHC?

Pierwsze EFHC pochodzą z dwóch głównych źródeł: nagród (w bonusowych monetach EFHCb) oraz wymiany energii przez Exchange (w głównych monetach EFHCm). Najmocniejsza ścieżka to: panele → energia → wymiana → saldo główne.

### 1-8. Skąd bierze się moja energia?

Energię dają aktywne panele. Dopóki panele są aktywne, generują energię, a ona gromadzi się jako energia dostępna do wymiany.

### 1-9. Co najsilniej wpływa na mój wzrost w projekcie?

Najmocniej na wzrost wpływa liczba aktywnych paneli i ich łączna generacja. Drugim wzmacniaczem jest VIP, jeśli jest aktywny, ponieważ wpływa na generację. Zadania, reklama i polecenia są przydatnym dodatkiem, ale nie stanowią podstawy.

### 1-10. Jak zrozumieć, że poruszam się we właściwym kierunku?

Jeśli rosną trzy rzeczy: generacja, dostępna energia i saldo główne po wymianie — poruszasz się właściwie. Najszybciej sprawdzisz to przez Energy i historię operacji.

## 2. Ekran główny

### 2-1. Co pokazuje ekran główny?

Ekran główny to strona Energy. Zbiera główne elementy bieżącego stanu konta: szybkie działania, informacje o postępie oraz punkty wejścia do ważnych sekcji bota.

### 2-2. Po co jest ekran główny?

Jest potrzebny po to, aby użytkownik od razu widział najważniejsze rzeczy dotyczące konta i szybko rozumiał bieżący stan, postęp oraz to, co można zrobić dalej.

### 2-3. Na co patrzeć w pierwszej kolejności?

Najpierw warto spojrzeć na górny panel, saldo łączne, ekran Energy i dostępne działania. To właśnie one najszybciej pokazują bieżący stan konta oraz to, co można zrobić dalej.

### 2-4. Gdzie widać mój obecny postęp?

Obecny postęp odzwierciedlają sekcje związane z energią, panelami, poziomami i rankingiem. To po nich widać, jak użytkownik posuwa się naprzód w projekcie.

### 2-5. Dlaczego ekran główny jest ważny każdego dnia?

Ponieważ właśnie tutaj najszybciej widać, jak zmieniło się konto: ile masz teraz energii, ile aktywnych paneli, jak rośnie postęp i do jakiego kolejnego kroku użytkownik jest już gotowy.

### 2-6. Od czego najlepiej zacząć?

Najpierw warto spojrzeć na górny panel, zrozumieć swoje salda, otworzyć stronę Energy, zajrzeć do sekcji Panels, a następnie przeczytać FAQ o podstawowych działaniach. Jeśli dla potrzebnej operacji wymagany jest portfel, kolejnym krokiem będzie jego podłączenie.

### 2-7. Które przyciski na ekranie głównym są najważniejsze?

Główne działania to Panels, Exchange, Bezpośrednie doładowanie na górnym pasku oraz Hub. Hub pokazuje tylko przycisk Doładuj.

### 2-8. Co powinienem sprawdzać na ekranie głównym każdego dnia?

Trzy rzeczy: 1) ile masz aktywnych paneli, 2) jaka jest prędkość generacji, 3) ile dostępnej energii zdążyło już się zgromadzić do wymiany.

### 2-9. Dlaczego ekran główny zmienia się z czasem?

Ponieważ odzwierciedla żywy stan konta. Gdy pojawiają się panele, energia i operacje, ekran przestaje być pusty i zaczyna pokazywać więcej użytecznych danych oraz postępu.

### 2-10. Jak po ekranie głównym zrozumieć, że konto się rozwija?

Gdy widzisz wzrost oparty na faktach: generacja nie jest zerowa, energia się gromadzi, a po wymianie zwiększa się saldo główne. To najbardziej uczciwe oznaki rozwoju.

## 3. Górny panel

### 3-1. Czym jest górny panel?

Górny panel to osobny element interfejsu i główny szybki blok informacyjny dostępny na głównych stronach bota.

### 3-2. Co jest wyświetlane na górnym pasku?

Na górnym pasku wyświetlane są awatar, nazwa, poziom postępu energetycznego, status VIP, całkowity balans, przycisk Top Up i przycisk Hub.

### 3-3. Dlaczego górny panel jest ważny?

Ponieważ pozwala od razu zobaczyć najważniejsze informacje o koncie bez zbędnych przejść: kim jesteś, jaki masz postęp, czy masz VIP, ile łącznie masz monet i gdzie szybko przejść dalej.

### 3-4. Co pokazuje łączny balans w górnym panelu?

Łączny balans pokazuje, ile masz monet razem. To wygodne, bo nie trzeba samodzielnie sumować zasobów do działań wewnętrznych i ogólnego zrozumienia stanu konta.

### 3-5. Dlaczego łączny balans jest wygodny przy działaniach wewnętrznych?

Ponieważ pokazuje całkowitą siłę zasobową gracza w grze i pomaga szybko zrozumieć, czy zasobów wystarczy na działania wewnętrzne.

### 3-6. Dlaczego łączny balans nie jest równy temu, co można wypłacić od razu?

Ponieważ łączny balans obejmuje zarówno monety główne, jak i bonusowe. Monety bonusowe są potrzebne do rozgrywki i nie podlegają bezpośredniej wypłacie.

### 3-7. Kiedy warto używać przycisku „Doładuj” w górnym panelu?

Warto go użyć, gdy chcesz szybko przejść do dostępnego w aplikacji scenariusza doładowania głównego salda, bez ręcznego otwierania dodatkowych sekcji.

### 3-8. Po co otwierać Hub z górnego paska?

Aby szybko otworzyć karty powiązanych działań projektu i przejść do potrzebnego zewnętrznego przepływu bez zbędnej nawigacji po interfejsie.

### 3-9. Dlaczego górny panel jest widoczny na różnych stronach?

Ponieważ to „tablica przyrządów” konta: ma stale pokazywać to, co najważniejsze — balans, statusy i szybkie działania — nawet gdy otworzysz inną sekcję.

### 3-10. Co zrobić, jeśli dane w górnym panelu wydają się nieprawidłowe?

Najpierw odśwież stronę i sprawdź historię salda: pokazuje faktyczne operacje. Jeśli historia i balans się zgadzają, dane są poprawne — mogłeś po prostu patrzeć przed aktualizacją.

## 4. Profil

### 4-1. Czym jest sekcja Profil/Ustawienia?

Profil/Ustawienia to sekcja, w której zarządza się profilem i parametrami bota. Widać tu główne statusy i dostępne są osobiste ustawienia interfejsu.

### 4-2. Co można robić w profilu?

W profilu zebrano główne ustawienia użytkownika oraz szybkie przejścia do ważnych sekcji: Wallet, historii salda, FAQ i innych przydatnych miejsc sterowania.

### 4-3. Co jest wyświetlane w górnej części Profilu/Ustawień?

W górnej części Profilu/Ustawień wyświetlane są avatar, nazwa Telegram oraz statusy Activ i VIP, jeśli są już dostępne.

### 4-4. Gdzie zmienić język?

Język zmienia się w Profilu/Ustawieniach.

### 4-5. Po co w ogóle potrzebny jest profil?

Profil jest osobistym punktem zarządzania kontem. Tutaj użytkownik nie tylko widzi statusy, ale też otwiera ważne podsekcje związane z portfelem, historią i innymi elementami sterowania.

### 4-6. Gdzie w profilu otworzyć historię salda?

W sekcji Profil/Ustawienia jest osobne wejście do historii salda, gdzie widać wpływy i obciążenia.

### 4-7. Gdzie w profilu zmienić język?

Zmiana języka znajduje się w Profilu/Ustawieniach, ponieważ jest to osobiste ustawienie konta.

### 4-8. Gdzie w Profilu otworzyć Wallet do pracy z portfelem?

W sekcji Profil znajduje się osobna pozycja Wallet. Otwieraj ją, gdy trzeba podłączyć portfel, sprawdzić powiązanie albo przejść do działań związanych z portfelem.

### 4-9. Gdzie w Profilu szybko otworzyć FAQ, jeśli potrzebuję odpowiedzi?

W sekcji Profil jest wejście do FAQ. Otwieraj je, gdy potrzebujesz szybkiej odpowiedzi dotyczącej interfejsu, balance, panels, energy, exchange, withdrawal albo innych funkcji WebApp.

### 4-10. Co znajduje się w sekcji „Wsparcie i informacje”?

Zebrano tam elementy pomocy: FAQ, wskazówki/informacje i wszystko, co pomaga użytkownikowi zrozumieć projekt bez chaosu.

### 4-11. W ilu językach dostępny jest interfejs projektu?

Interfejs bota i system pomocy (FAQ) zostały przetłumaczone na 13 języków. Możesz wybrać wygodny język w ustawieniach profilu, a system natychmiast dostosuje wszystkie teksty i interfejs do Twojego wyboru.

## 5. Wallet

### 5-1. Do czego potrzebny jest główny portfel?

Główny portfel służy do działań związanych z zewnętrznymi operacjami projektu: wypłatami, doładowaniami, potwierdzeniem posiadania adresu oraz innymi powiązanymi działaniami, w których potrzebny jest podłączony portfel.

### 5-2. Czy można zmienić główny portfel?

Tak. Użytkownik może wybrać inny główny portfel spośród już podłączonych.

### 5-3. Czy można usunąć podłączony portfel?

Tak. Jeśli portfel nie jest już potrzebny, jego powiązanie można usunąć.

### 5-4. Dlaczego tego samego portfela nie można podłączyć do dwóch kont?

Ten sam portfel nie powinien być używany jednocześnie na dwóch różnych kontach. Jeśli portfel jest już podłączony do jednego konta, przed podłączeniem do innego trzeba go najpierw odłączyć od pierwszego. To eliminuje pomyłki w statusach, kontrolach i wynikach związanych z portfelem.

### 5-5. Co się stanie, jeśli kliknę działanie wymagające portfela, a go nie mam?

Jeśli wybrana funkcja wymaga portfela, bot najpierw uruchomi logikę jego podłączenia. Po tym będzie można wrócić do potrzebnego działania i je wykonać.

### 5-6. Czy można podłączyć kilka portfeli i po co to jest potrzebne?

Tak. Można podłączyć kilka portfeli, aby mieć zapasowy adres albo rozdzielić różne scenariusze użycia. Jednocześnie jeden portfel jest wybierany jako główny.

### 5-7. Co zrobić, jeśli chcę użyć swojego portfela na innym koncie?

Najpierw trzeba odłączyć ten portfel od bieżącego konta. Dopiero potem można go połączyć z innym kontem. Ten sam portfel nie powinien być jednocześnie przypisany do dwóch kont.

### 5-8. Czy można wypłacać na portfel niegłówny?

Domyślnie system opiera się na głównym portfelu. Jeśli potrzebujesz innego adresu, najpierw ustaw go jako główny w Wallet, a dopiero potem złóż wniosek o wypłatę.

### 5-9. Co zrobić, jeśli portfel jest podłączony, ale wypłata nadal jest niedostępna?

Sprawdź trzy rzeczy: czy wybrano główny portfel, czy wystarcza głównego salda oraz czy kwota wypłaty nie jest niższa niż 10 EFHC.

### 5-10. Gdzie sprawdzić, który portfel jest teraz połączony z moim kontem?

Należy sprawdzić to w sekcji Wallet. To tam użytkownik widzi, które portfele są połączone z kontem i który z nich jest używany w ramach konta.

### 5-11. Co mam zrobić, jeśli stracę dostęp do swojego głównego portfela TON?

Ponieważ projekt pozwala podłączyć kilka portfeli, możesz dodać nowy portfel w sekcji Wallet, ustawić go jako główny, a stary skompromitowany adres na stałe usunąć z listy podłączonych portfeli.

## 6. Salda i historia

### 6-1. Dlaczego mam trzy różne salda?

Ponieważ środki w bocie pełnią różne role. Saldo całkowite pokazuje wszystko razem, saldo bonusowe służy do wewnętrznego cyklu gry, a saldo główne pokazuje wynik, który można już wykorzystać w kluczowych operacjach projektu.

### 6-2. Czym jest saldo bonusowe?

Saldo bonusowe to wewnętrzne saldo gry. Jest używane do rozwoju w bocie, naliczane za zadania, polecenia, prezenty i inne wewnętrzne mechaniki projektu, ale nie jest wypłacane bezpośrednio.

### 6-3. Czym jest saldo główne?

Saldo główne to główne EFHC. To właśnie na nie zamienia się wynik cyklu gry i właśnie z niego dostępne są kluczowe operacje, w tym wypłata.

### 6-4. Dlaczego jeden działanie wewnętrzne może dotknąć zarówno salda bonusowego, jak i głównego?

Przy wszystkich wewnętrznych wydatkach projektu środki są najpierw pobierane z salda bonusowego. Jeśli to nie wystarczy, pozostała część jest pobierana z salda głównego.

### 6-5. Dlaczego w historii od razu jest kilka wpisów?

Jedna operacja może obejmować kilka części ruchu środków, dlatego bot pokazuje ją w kilku wierszach, aby osobno odzwierciedlić różne zmiany.

### 6-6. Gdzie mogę sprawdzić, dokąd przyszły lub skąd zeszły EFHC?

Do tego służy sekcja historii salda. Pokazuje wpływy, obciążenia, wymianę, działania wewnętrzne, wypłaty i inne zmiany środków.

### 6-7. Dlaczego saldo całkowite może być duże, a wypłacić mogę mniej?

Ponieważ saldo całkowite sumuje saldo główne i bonusowe. Wypłata jest dozwolona tylko z salda głównego, a saldo bonusowe jest przeznaczone dla wewnętrznego cyklu projektu. Dlatego do wypłaty potrzebne są środki właśnie na saldzie głównym.

### 6-8. Gdzie najszybciej zobaczę, co dokładnie zmieniło moje saldo?

W historii salda. Widać tam, która operacja dała wpływ lub obciążenie i którego salda dotknęła.

### 6-9. Dlaczego salda bonusowego nie można wypłacić bezpośrednio?

Ponieważ bonusowe monety są częścią wewnętrznego cyklu projektu. Wypłata jest dozwolona tylko z salda głównego.

### 6-10. Dlaczego po wypłacie albo wymianie historia nie aktualizuje się od razu jednakowo wszędzie?

Ponieważ różne ekrany nie zawsze odświeżają się jednocześnie. Sprawdź kolejno: odśwież sekcję → sprawdź saldo → sprawdź historię.

### 6-11. Co się stanie, jeśli przy słabym internecie przypadkowo nacisnę przycisk aktywacji lub wymiany kilka razy z rzędu? Czy zostaną pobrane dodatkowe monety?

Nie. Dodatkowe monety nie zostaną pobrane. W rdzeniu systemu działa ścisła ochrona przed podwójnymi obciążeniami. Nawet jeśli naciśniesz przycisk 10 razy z powodu zawieszającej się sieci, operacja zostanie wykonana dokładnie jeden raz.

## 7. Panels

### 7-1. Ile EFHC potrzeba do aktywacji jednego panelu?

Do aktywacji jednego panelu potrzeba 100 EFHC.

### 7-2. Co daje od razu aktywacja pierwszego panelu?

Aktywacja pierwszego panelu od razu uruchamia generację energii, otwiera drogę do postępu, tworzy ścieżkę do głównych EFHC i nadaje stały aktywny status Activ.

### 7-3. Kiedy zaczyna się generacja panelu?

Generacja zaczyna się natychmiast po aktywacji panelu.

### 7-4. Jaki jest czas życia panelu?

Każdy panel ma 180-dniowy cykl działania.

### 7-5. Co dzieje się z panelem po zakończeniu 180-dniowego cyklu?

Po zakończeniu 180-dniowego cyklu panel dezaktywuje się i przechodzi do Archive jako pamięć o energetycznym postępie uczestnika.

### 7-6. Jakie dwa stany paneli są w interfejsie?

W interfejsie są Activ i Archive. Activ to panele, które biorą udział w generacji. Archive to panele, które zakończyły już aktywny cykl i zachowują historię drogi.

### 7-7. Czy można aktywować więcej niż jeden panel od razu?

Tak. Możesz aktywować panele kolejno, zwiększając liczbę aktywnych paneli. Im więcej aktywnych paneli, tym wyższa łączna generacja energii i tym szybciej rośnie twój postęp.

### 7-8. Co oznacza licznik „Pozostało” przy panelu?

Licznik pokazuje, ile czasu zostało do końca 180-dniowego cyklu panelu. Gdy czas się skończy, panel automatycznie przejdzie do Archive i przestanie być aktywny.

### 7-9. Dlaczego po aktywacji pierwszego panelu stałem się Activ?

Ponieważ Activ jest potwierdzeniem realnego udziału i ochroną projektu przed botami. Projekt wiąże status Activ z aktywacją pierwszego panelu, aby otrzymywali go tylko prawdziwi uczestnicy.

### 7-10. Dlaczego aktywne panele są ważniejsze niż archiwalne?

Aktywne panele generują energię teraz — to one nadają twoje obecne tempo wzrostu. Panele archiwalne to zakończone panele: zachowują historię, ale nie dają bieżącej generacji.

### 7-11. Dlaczego mam mniej aktywnych paneli, niż kupiłem?

Ponieważ część paneli mogła zakończyć 180-dniowy okres i przejść do Archive. Aktywne panele to te, które działają teraz. Archive to panele zakończone, które nie dają już bieżącej generacji.

### 7-12. Czy aktywne panele mogą „zniknąć” z powodu limitu 1000?

Nie. Limit 1000 oznacza, że jednocześnie nie można mieć więcej niż 1000 aktywnych paneli. Już aktywowane aktywne panele nie „znikają”: pozostają aktywne do końca swojego okresu, a potem przechodzą do Archive.

### 7-13. Co zrobić, jeśli aktywowałem panel, a generacja nie zmieniła się od razu?

Sprawdź: odśwież sekcję Panels → zobacz, czy panel pojawił się w Active → otwórz Energy i sprawdź prędkość generacji → sprawdź historię salda, gdzie powinno być obciążenie 100 EFHC.

### 7-14. Czy można aktywować panel, jeśli mam mniej niż 100 EFHC?

Nie. Do aktywacji panelu potrzeba 100 EFHC. Jeśli środków jest mniej, aktywacja nie przejdzie.

### 7-15. Dlaczego panele w Archive są ważne, skoro już nie generują?

Archive przechowuje historię twoich paneli i ukończonych cykli. To twoja „biografia wzrostu”, ale bieżącą generację dają tylko aktywne panele.

### 7-16. Czy można aktywować panel i od razu zobaczyć, że jest aktywny?

Tak. Aktywowany panel powinien pojawić się na liście Active, a jego działanie wewnętrzne powinien być widoczny w historii salda.

### 7-17. Ile energii daje jeden panel w ciągu 180 dni?

Jeden panel przy stawce bazowej daje 107.61984000 kWh w ciągu 180 dni. Przy posiadaniu EFHC VIP NFT generacja wynosi 115.24032000 kWh.

## 8. Energy

### 8-1. Co pokazuje strona Energy?

Na stronie Energy widać postęp energetyczny, pasek postępu generacji energii, liczbę aktywnych paneli, łączną generację paneli na sekundę oraz inne kluczowe wskaźniki systemu.

### 8-2. Co pokazuje pasek postępu na stronie Energy?

Pasek postępu pokazuje drogę do następnego poziomu postępu gracza w skali 12 poziomów.

### 8-3. Co oznacza łączna generacja paneli na sekundę?

To podstawowa albo VIP-stała generacji pomnożona przez liczbę aktywnych paneli.

### 8-4. Dlaczego energia jest tak ważna?

Ponieważ energia jest centralnym fundamentem postępu w EFHC. To przez nią użytkownik przechodzi od paneli do wyniku, który wpływa na saldo, poziomy, ranking i rozwój konta.

### 8-5. Czy po stronie Energy da się zrozumieć, jak silne jest konto?

Tak. Strona Energy szybko pokazuje bieżącą siłę systemu: ile paneli pracuje, jaka generacja trwa teraz, ile energii już zgromadzono i jak daleko użytkownik przeszedł.

### 8-6. Dlaczego dostępna energia i saldo główne są liczone osobno?

Ponieważ są to dwie różne wielkości. Dostępna energia pokazuje zgromadzone kWh, a saldo główne pokazuje już otrzymane główne EFHC. Te wartości są ze sobą powiązane, ale nie są tym samym.

### 8-7. Dlaczego energia rośnie sama, a saldo główne nie zwiększa się automatycznie?

Ponieważ gromadzenie energii i wzrost salda głównego zachodzą na różnych etapach. Najpierw panele wytwarzają energię, a saldo główne rośnie dopiero po osobnej akcji wymiany lub innym scenariuszu naliczenia głównych EFHC.

### 8-8. Co pokazuje prędkość generacji na sekundę?

To wskaźnik, jak szybko twoje aktywne panele tworzą energię teraz, czyli twoje bieżące tempo wzrostu.

### 8-9. Co szczególnie ważne śledzić w Energy każdego dnia?

Liczbę aktywnych paneli, prędkość generacji i dostępną energię — to trzy główne orientacyjne wskaźniki stanu konta.

### 8-10. Jak po Energy zrozumieć, że moje panele naprawdę działają?

Jeśli w Energy widać aktywne panele i niezerową generację, a dostępna energia stopniowo rośnie — panele działają. Jeśli generacja wynosi 0 i energia się nie gromadzi, aktywnych paneli nie ma.

### 8-11. Dlaczego biegnące liczby energii na ekranie czasem mogą się lekko korygować lub przeskakiwać?

Dla Twojej wygody wartości zgromadzonej energii są aktualizowane na ekranie w czasie rzeczywistym, pokazując ciągły proces generacji. Jednak głównym źródłem prawdy zawsze jest serwer. Okresowo, a także po każdej Twojej akcji, aplikacja synchronizuje się z serwerem, aby zapewnić absolutną dokładność matematyczną. W tym momencie może nastąpić mikro-korekta liczb na ekranie do dokładnej wartości serwerowej.

## 9. Exchange

### 9-1. Czym jest Exchange?

Exchange to sekcja, w której energia zamienia się w główne EFHC. To jeden z kluczowych etapów drogi użytkownika w projekcie.

### 9-2. Jak działa wymiana energii na EFHC?

Wymiana to konwersja postępu na główne EFHC. Zgromadzona energia zamienia się w główne monety projektu.

### 9-3. Co oznacza zasada 1 kWh = 1 EFHC?

To stały wewnętrzny kurs projektu. Każda jednostka energii przelicza się na równą liczbę EFHC.

### 9-4. Co dzieje się po wymianie?

Po wymianie wynik energii pojawia się na saldzie głównym w postaci głównych EFHC. To już nie tylko zgromadzona energia, lecz wynik, który uczestniczy w kluczowych operacjach projektu.

### 9-5. Dlaczego wymiana jest tak ważna?

Ponieważ właśnie przez wymianę użytkownik przenosi zgromadzoną energię do głównego wyniku. To punkt, w którym ścieżka energetyczna staje się głównymi EFHC.

### 9-6. Czy można wymienić bonusowe monety bezpośrednio bez energii?

Nie. Bonusowe monety najpierw uczestniczą w wewnętrznym cyklu: za nie kupuje się panel, panel generuje energię, a dopiero potem energia jest wymieniana na główne EFHC.

### 9-7. Dlaczego wymiana trafia od razu na saldo główne, a nie bonusowe?

Ponieważ Exchange to zamiana energii w główny wynik. W projekcie obowiązuje zasada 1 kWh = 1 EFHC, a wynik wymiany zawsze trafia na saldo główne, z którego dostępne są kluczowe działania.

### 9-8. Co zrobić, jeśli wykonałem wymianę, ale nie widzę wyniku od razu?

Najpierw odśwież sekcję Exchange i sprawdź saldo główne. Następnie otwórz historię salda: powinna tam być pozycja dotycząca wymiany. Jeśli wpis jest, wymiana została wykonana, nawet jeśli nie wszystko odświeżyło się jednocześnie.

### 9-9. Czy można wymienić energię i od razu złożyć wniosek o wypłatę?

Tak, jeśli po wymianie na saldzie głównym jest wystarczająco dużo EFHC, kwota wypłaty nie jest niższa niż 10 EFHC, a portfel jest podłączony i wybrany jako główny.

### 9-10. Co lepsze: wymieniać często czy gromadzić?

To zależy od twojego celu. Częsta wymiana jest wygodna do kontroli i operacji, gromadzenie jest wygodne przy rzadszych większych krokach. Jedna zasada jest stała: wynik wymiany trafia na saldo główne.

### 9-11. Dlaczego po wymianie zmniejsza się dostępna energia?

Ponieważ przez Exchange przenosisz część zgromadzonej energii do EFHC. Energia nie znika — zamienia się w monety. Ważne: suma energii na głównym ekranie Energy nie powinna być mylona z tym, co już zostało wymienione.

### 9-12. Którą energię mogę już wymienić?

Wymienić można tę energię, która już się zgromadziła i stała się dostępna. To właśnie dostępna energia — gotowa objętość do działania w sekcji Exchange.

### 9-13. Czy istnieje minimalny limit wymiany energii na główne EFHC?

Nie ma sztywnych ograniczeń, jednak matematyka wymiany opiera się na kursie 1 kWh = 1 EFHC. Warto gromadzić i wymieniać całe wartości energii od 1 kWh, aby wynik wymiany był od razu widoczny na saldzie głównym.

## 10. Withdraw

### 10-1. Dlaczego nie mogę wypłacić EFHC?

Najczęściej powodem jest to, że na saldzie głównym brakuje środków, portfel nie jest podłączony albo kwota jest niższa od minimalnego progu wypłaty. Sprawdzanie warto zacząć od Wallet i salda głównego.

### 10-2. Jak przebiega wypłata?

Tworzony jest wniosek o wypłatę, po czym jest on możliwie szybko przetwarzany przez pierwszego wolnego operatora.

### 10-3. Dlaczego po złożeniu wniosku o wypłatę saldo zmieniło się od razu?

Ponieważ bot od razu uwzględnia rozpoczęcie tej operacji w systemie. To potrzebne, aby użytkownik widział, że działanie zostało już powiązane z jego środkami i przyjęte przez system.

### 10-4. Z którego balance można zrobić withdrawal?

Withdrawal jest dostępny tylko z głównego balance.

### 10-5. Dlaczego wypłata jest dostępna tylko z salda głównego?

Ponieważ saldo główne to to, co już należy do użytkownika jako wynik procesu gry albo jako aktywowane monety. Monety bonusowe uczestniczą wewnątrz cyklu projektu i nie są wypłacane bezpośrednio.

### 10-6. Jaka jest minimalna wypłata?

Minimalna kwota wypłaty wynosi 10 EFHC.

### 10-7. Jak długo zwykle przetwarzany jest wniosek o wypłatę?

Wypłata przechodzi przez wniosek i obsługę operatora. Jeśli wynik nie jest od razu widoczny, sprawdź status wniosku i historię operacji — tam widać rzeczywisty stan. Jeśli wniosek długo się nie zmienia, warto odświeżyć sekcję później.

### 10-8. Czy można anulować wniosek o wypłatę?

Tak, jeśli wniosek nie został jeszcze przetworzony. Anulowanie jest dostępne dla wniosku oczekującego. Po anulowaniu sprawdź saldo główne i historię operacji: jeśli środki były zablokowane, wracają zgodnie ze stanem systemu.

### 10-9. Dlaczego wniosek o wypłatę może „wisieć” w oczekiwaniu?

Ponieważ wypłata przechodzi przez przetwarzanie. Jeśli wniosek się nie zmienia, sprawdź jego status i historię operacji, a następnie odśwież sekcję później.

### 10-10. Gdzie widzę, że wniosek został anulowany?

Widać to po statusie wniosku i po wpisie w historii operacji. Po anulowaniu sprawdź również saldo główne.

### 10-11. Dlaczego minimalna wypłata to właśnie 10 EFHC?

Ponieważ w projekcie ustawiono próg, poniżej którego wnioski nie są przyjmowane. Minimum to 10 EFHC. Dodatkowo: opłatę za wypłatę pokrywa projekt, a wypłacanie kwot niższych niż 10 EFHC jest niecelowe.

### 10-12. Dlaczego withdrawal może być niedostępny, nawet jeśli mam EFHC?

Ponieważ do withdrawal liczy się tylko główny balance. Jeśli EFHC znajdują się w bonusowej części balance, nie można złożyć withdrawal na te środki.

### 10-13. Co zrobić po złożeniu wniosku o wypłatę?

Sprawdź status wniosku i historię operacji — tam widać rzeczywisty stan wniosku i ruch środków.

### 10-14. W jakim tokenie i w jakiej sieci odbywa się wypłata środków?

Wypłata odbywa się wyłącznie w tokenach EFHC i tylko w sieci blockchain TON (The Open Network). W projekcie nie istnieją żadne inne opcje wypłaty.

### 10-15. Ile czasu zajmuje ręczne przetworzenie wypłaty przez operatora?

Wnioski o wypłatę są przetwarzane przez operatorów w żywej kolejce. Zazwyczaj trwa to od kilku minut do 24 godzin, w zależności od obciążenia sieci i liczby zgłoszeń. Zawsze możesz anulować nieprzetworzony wniosek, a środki natychmiast wrócą na saldo.

## 11. Zadania

### 11-1. Co daje wykonywanie zadań?

Zadania dają wyłącznie monety bonusowe i motywują do aktywnego udziału w życiu gracza.

### 11-2. Jak otrzymać nagrodę za zadanie?

Trzeba spełnić warunki zadania. Po ich wykonaniu bot automatycznie zalicza wynik i nalicza przewidzianą nagrodę.

### 11-3. Dlaczego zadanie nie zostało zaliczone?

Tak bywa, gdy warunki nie są jeszcze w pełni spełnione, działanie nie zostało dokończone albo wynik nie zdążył się jeszcze odświeżyć w systemie.

### 11-4. Czy można wykonać to samo zadanie jeszcze raz?

To zależy od typu zadania. Niektóre są jednorazowe, a niektóre mogą się powtarzać zgodnie z logiką projektu.

### 11-5. Czy wszystkie zadania dają taką samą nagrodę?

Nie. Wielkość nagrody zależy od konkretnego zadania i jego warunków. Typ nagrody jest jednak jeden — monety bonusowe.

### 11-6. Po co w ogóle są zadania, skoro są panele?

Zadania to dodatkowa ścieżka wzrostu. Nie zastępują paneli, lecz pomagają zbierać monety bonusowe, które potem można wykorzystać wewnątrz cyklu gry.

### 11-7. Dlaczego nagroda za zadania nie trafia na saldo główne?

Ponieważ zadania dają bonusowe EFHC. To wewnętrzna nagroda dla cyklu gry, dlatego jest księgowana na saldzie bonusowym.

### 11-8. Dlaczego zadania czasami się kończą albo znikają?

Ponieważ zadania mogą być czasowe albo mieć limit. Jeśli zadania nie ma, to znaczy, że zostało zakończone albo obecnie nie jest aktywne.

### 11-9. Gdzie zobaczyć wszystkie dostępne zadania?

W sekcji Tasks — tam wyświetla się lista dostępnych zadań oraz ich warunki.

### 11-10. Dlaczego nagroda za zadanie nie pojawiła się od razu?

Czasem system potrzebuje chwili na odświeżenie wyniku. Sprawdź: odśwież Tasks → sprawdź saldo bonusowe → sprawdź historię operacji.

### 11-11. Zapisałem się na kanał wymagany w zadaniu, ale zadanie się nie zalicza. Dlaczego?

Czasami weryfikacja subskrypcji trwa dłużej z powodu cache po stronie serwerów Telegrama. Jeśli bot nie zaliczył subskrypcji od razu, wróć do sekcji Tasks po kilku minutach i naciśnij przycisk sprawdzenia jeszcze raz.

## 12. Polecenia

### 12-1. Jak nazywają się sekcje na stronie Referrals?

Na stronie Referrals używane są sekcje Aktywne i Nieaktywne.

### 12-2. Co oznacza aktywny i nieaktywny polecony?

Aktywny polecony to gracz, który aktywował już co najmniej jeden panel i otrzymał status Activ. Nieaktywny polecony to ktoś, kto jeszcze nie wszedł w cykl gry i na razie nie daje prawa do bonusu.

### 12-3. Kiedy naliczane są bonusy za polecenia?

Bonusy za polecenia są sprawdzane przez bota automatycznie. Gdy tylko gracz staje się aktywny, bonus jest naliczany od razu.

### 12-4. Co daje aktywny status w logice poleceń?

Status aktywny jest ważny dla logiki poleceń, ponieważ projekt używa go jako części filtra realnego udziału i ochrony przed sztucznym nabijaniem przez boty, farmy botów i fałszywą aktywność.

### 12-5. Jak Activ jest powiązany z poleceniami?

Activ pokazuje, że użytkownik jest realnym uczestnikiem projektu, a nie kontem-botem. To ważne dla uczciwego działania systemu poleceń i ochrony przed farmami botów.

### 12-6. Jaki podstawowy bonus jest naliczany za każdego aktywnego poleconego?

Za każdego bezpośrednio poleconego naliczany jest jeden bonus 0.1 EFHCb — tylko raz, gdy aktywuje swój pierwszy panel i otrzyma Activ.

### 12-7. Dlaczego mam poleconych, ale bonus nie został naliczony?

Bonus jest naliczany dopiero po aktywacji pierwszego panelu przez bezpośrednio poleconą osobę. Do tego czasu pozostaje ona nieaktywna; kolejne panele nie tworzą ponownego bonusu za polecenie.

### 12-8. Gdzie trafia 0.1 EFHCb za aktywnego poleconego?

Nagroda aktywacyjna 0.1 EFHCb za bezpośrednio poleconą osobę trafia jednorazowo na saldo bonusowe. Nagrody Lvl również trafiają na to samo saldo EFHCb. Pełny cykl to 1 000 EFHCb za 10 000 aktywnych bezpośrednich poleconych plus 1 411 EFHCb nagród Lvl, łącznie 2 411 EFHCb.

### 12-9. Dlaczego zaproszona osoba jest na liście, ale nie jest uznawana za aktywną?

Ponieważ staje się aktywna dopiero po aktywacji pierwszego panelu i otrzymaniu Activ. Dopóki to nie nastąpi, pozostaje w nieaktywnej części listy.

### 12-10. Gdzie wziąć swój link polecający?

W sekcji Referrals — tam wyświetla się Twój link polecający oraz lista zaproszonych osób.

### 12-11. Czy wolno tworzyć dodatkowe konta przez własny link polecający?

Tak. Regulamin projektu tego nie zabrania. Jednak tworzenie pustych kont nie da Ci korzyści. Ekonomia systemu jest zbudowana tak, że bonusy referralowe i wzrost rankingu są naliczane tylko za uczestnika ze statusem Activ — czyli dopiero po tym, jak zaproszone konto rzeczywiście wejdzie do gry i aktywuje co najmniej jeden panel.

### 12-12. Czy mogę zmienić swojego polecającego po rejestracji?

Nie. Powiązanie referralowe jest ustalane w momencie pierwszego wejścia do projektu przez link zaproszeniowy i nie może zostać później zmienione.

## 13. Hub

### 13-1. Co mogę zrobić w Hub?

W Hub dostępne są dwie akcje: Doładuj i EFHC VIP NFT. Szczegóły zewnętrznych ścieżek pojawiają się dopiero po opuszczeniu Hub.

### 13-2. Do czego służy Hub?

Hub to krótka sekcja nawigacyjna prowadząca do dwóch zewnętrznych działań projektu.

### 13-3. Ile działań jest dostępnych w Hub?

Dokładnie dwa: Doładuj i EFHC VIP NFT. Obie funkcje są kanoniczne.

### 13-4. Co robi przycisk „Doładuj”?

Otwiera dalszy etap na zewnętrznej stronie Web. Produkty, ceny i metody płatności nie są pokazywane przed opuszczeniem Hub.

### 13-5. Na jaki balans trafia doładowanie EFHC po potwierdzeniu?

Doładowanie EFHCm jest księgowane na balans główny.

### 13-6. Dlaczego wynik doładowania może nie pojawić się od razu?

Najpierw musi zostać potwierdzony zewnętrzny etap operacji, a dopiero potem wynik jest aktualizowany. Sprawdź Hub, balans główny i historię operacji.

### 13-7. Jeśli otrzymałem VIP NFT przez GetGems, gdzie zobaczę, że jest aktywny?

Sprawdź status VIP w aplikacji oraz obecność NFT w podłączonym portfelu.

### 13-8. Przeszedłem zewnętrzny przepływ z Hub, ale nie ma wyniku. Co robić?

Sprawdź Hub, balans główny i historię operacji. Jeśli nadal nie ma wyniku, operacja jeszcze nie została pobrana albo wymaga osobnego przetworzenia.

### 13-9. Na który balans trafia doładowanie przez Top Up i Hub?

Doładowanie EFHCm jest księgowane na balans główny.

### 13-10. Czy do działań z Hub potrzebny jest podłączony portfel?

Do zewnętrznych działań opartych na wallet potrzebny jest podłączony Wallet. Sam Hub otwiera się bez osobnego aktywacji i służy jako punkt przejścia.

### 13-11. Gdzie mogę sprawdzić, że doładowanie EFHC zostało naprawdę zaksięgowane?

Sprawdź balans główny i historię operacji: powinien się tam pojawić ślad doładowania.

### 13-12. Czy w Hub są skiny?

Skiny nie są kartami Hub.

### 13-13. Jak zdobyć skiny projektu?

Skiny odblokowują się wraz z postępem konta i są powiązane z 12 poziomami osiągnięć.

## 14. Nawigacja i zasady

### 14-1. Kiedy należy otworzyć sekcję „Nawigacja i zasady”?

Otwórz tę sekcję, gdy chcesz szybko zrozumieć logikę ekranów, znaleźć potrzebną funkcję w WebApp albo wyjaśnić podstawowe zasady pracy z sekcjami aplikacji.

### 14-2. Które ekrany warto otworzyć najpierw, jeśli wchodzę do WebApp po raz pierwszy albo po długiej przerwie?

Najlepiej zacząć od ekranu głównego, górnego paska i profilu. Potem łatwiej przejść do Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History i Hub zgodnie z aktualnym zadaniem.

### 14-3. Jak zrozumieć, w której sekcji szukać potrzebnej funkcji?

Wybierz sekcję według działania: Profile dla konta, Wallet dla portfela, Panels dla paneli, Energy dla generacji, Exchange dla wymiany, Withdraw dla wypłat, Tasks dla zadań, Referrals dla zaproszeń, a Hub dla przejścia Doładuj.

### 14-4. Gdzie znajduje się wejście do Profile?

Wejście do Profile znajduje się w górnej części interfejsu przez przycisk „Profile”.

### 14-5. Dlaczego niektóre działania wymagają osobnego potwierdzenia?

Osobne potwierdzenie chroni konto i zmniejsza ryzyko przypadkowych działań przy ważnych operacjach.

### 14-6. Dlaczego niektóre działania są dostępne od razu, a inne zależą od stanu konta?

Część funkcji zależy od stanu konta, obecności panelu, podłączonego portfela, historii aktywności lub innych wewnętrznych warunków projektu.

### 14-7. Jak rozumieć różnicę między Profile, Wallet i History?

Profile to sekcja z danymi konta i wejściami do powiązanych funkcji. Wallet służy do podłączania i sprawdzania portfela. History to historia operacji i ruchów salda.

### 14-8. Co zrobić, jeśli nie widzę potrzebnego przycisku albo sekcji?

Najpierw odśwież ekran i sprawdź, czy nie jest otwarta inna sekcja. Następnie wróć do ekranu głównego, górnego panelu albo Profile i ponownie przejdź do funkcji zgodnie z jej przeznaczeniem.

### 14-9. Co zrobić, jeśli dane na ekranie wyglądają na nieaktualne albo nie zgadzają się z oczekiwaniami?

Najpierw odśwież ekran, a potem otwórz sekcję profilu, której dotyczy ta informacja. Saldo i ruchy najłatwiej sprawdzać w History, panele w Panels, generację w Energy, operacje portfela w Wallet, a działania wypłat w Withdraw.

### 14-10. Po czym poznać, że otwarta jest niewłaściwa sekcja?

Wybierz sekcję według działania: Profile dla konta, Wallet dla portfela, Panels dla paneli, Energy dla generacji, Exchange dla wymiany, Withdraw dla wypłat, Tasks dla zadań, Referrals dla zaproszeń, a Hub dla przejścia Doładuj.

### 14-11. Jaka kolejność sprawdzania ekranów jest wygodna przy zwykłym codziennym wejściu do WebApp?

Zwykle wygodnie jest najpierw sprawdzić ekran główny i górny panel, a potem otworzyć sekcje związane z bieżącym zadaniem: Panels, Energy, History, Tasks, Referrals, Hub, Exchange albo Withdraw. Taka kolejność pomaga szybko zrozumieć aktualny stan konta i przejść do potrzebnego działania.

### 14-12. Które sekcje warto regularnie sprawdzać nawet bez pilnego zadania?

Warto regularnie sprawdzać ekran główny, górny panel, Panels, Energy, History, Tasks, Referrals i Hub. Pomaga to na czas zauważać zmiany salda, aktywność paneli i dostępne działania.

### 14-13. Dlaczego ważne jest wykonywanie działań w ich własnej sekcji, a nie szukanie ich wszędzie?

Dzięki temu jest mniej błędów i przypadkowych działań. Gdy użytkownik wykonuje wymianę w Exchange, wypłatę w Withdraw, a pracę z panelami w Panels, logika WebApp pozostaje jasna i bezpieczna.

### 14-14. Po czym poznać, że działanie jest ważne i wymaga uwagi?

Większa uwaga jest potrzebna, gdy działanie wpływa na saldo, panele, energię, wymianę, wypłatę, podłączenie portfela, historię operacji albo status konta. Przed potwierdzeniem takich działań warto jeszcze raz sprawdzić ekran i wybrany przycisk.

### 14-15. Co zrobić, jeśli ekran zmienił się po aktualizacji bota?

Kieruj się aktualnymi nazwami sekcji i ich przeznaczeniem. Elementy wizualne mogą się zmieniać, ale logika ekranów powinna pozostawać zrozumiała i spójna.

### 14-16. Jakie podstawowe zasady pomagają nie popełniać błędów w WebApp?

Warto wykonywać działania tylko w odpowiedniej sekcji, uważnie czytać nazwę ekranu i przycisku przed potwierdzeniem, a w razie wątpliwości najpierw sprawdzać sekcje profilu zamiast naciskać przypadkowe elementy interfejsu.

### 14-17. W jakich przypadkach warto otworzyć FAQ podczas pracy z WebApp?

FAQ warto otworzyć wtedy, gdy trzeba szybko wyjaśnić znaczenie ekranu, przycisku, działania albo reguły konkretnej funkcji. Dzięki temu łatwiej od razu powiązać pytanie z właściwą sekcją i nie wykonywać zbędnych kroków w WebApp.

## 15. Reklamy

### 15-1. Co to za sekcja?

Sekcja Ads to podsekcja w części Tasks. Pokazuje dostępne działania reklamowe, dzięki którym użytkownik może otrzymać dodatkowe monety bonusowe.

### 15-2. Co mi to daje?

Daje wyłącznie monety bonusowe za wyświetlenia, jeśli reklama jest obecnie dostępna dla konta użytkownika.

### 15-3. Dlaczego nic tutaj nie ma?

Jeśli sekcja jest pusta, oznacza to, że dla konta użytkownika nie ma teraz aktywnych ofert albo reklama jest tymczasowo wyłączona.

### 15-4. Gdzie znajduje się sekcja Ads?

Sekcja Ads znajduje się jako podsekcja wewnątrz Tasks. To jedna z dodatkowych możliwości w bloku zadań.

### 15-5. Jaki typ nagrody daje Ads?

Ads daje tylko monety bonusowe za wyświetlenia. To nie jest saldo główne ani bezpośrednia wypłata, lecz dodatkowy wewnętrzny sposób na wzmocnienie ścieżki gry.

### 15-6. Dlaczego Ads jest przydatne?

Ponieważ to dodatkowe źródło monet bonusowych. Nie zastępuje paneli ani generacji, ale może pomóc szybciej wzmocnić wewnętrzny cykl gry.

### 15-7. Dlaczego inni mają reklamy, a ja nie?

Ponieważ oferty mogą być niedostępne dla konkretnego konta albo reklama jest tymczasowo wyłączona. Puste Ads nie oznacza, że konto jest uszkodzone.

### 15-8. Co zrobić, jeśli wykonałem działanie w Ads, ale nie ma rezultatu?

Sprawdź: odśwież Tasks / Ads → sprawdź saldo bonusowe → sprawdź historię operacji.

### 15-9. Dlaczego w Ads różni użytkownicy mogą mieć różne oferty?

Ponieważ oferty zależą od dostępności kampanii reklamowych dla konkretnego konta. To normalne: jeden użytkownik ma oferty, a inny chwilowo nie.

### 15-10. Czy trzeba coś kupować, żeby korzystać z Ads?

Nie. Ads to sposób na otrzymywanie bonusowych EFHC i nie wymaga obowiązkowych działań wewnętrznych.

## 16. Ranks

### 16-1. Dlaczego wzrost w rankingu jest dla mnie ważny?

Wzrost w rankingu pokazuje, jak wygląda Twój postęp na tle innych uczestników. Pomaga to rozumieć swoje obecne miejsce i widzieć, jak aktywnie rozwija się konto.

### 16-2. Czym poziom różni się od rankingu?

Poziom pokazuje osobisty postęp wewnątrz systemu, a ranking — miejsce użytkownika wśród innych uczestników.

### 16-3. Jak poziom i ranking są ze sobą powiązane?

Są powiązane wspólną logiką wzrostu poprzez generację kWh przez panele oraz wspólny pasek postępu na stronie Energy.

### 16-4. Czy ranking to tylko ładna liczba?

Nie. Ranking pomaga zrozumieć, jak twoja droga wygląda na tle innych uczestników.

### 16-5. Co wpływa na wzrost mojej pozycji w rankingu?

Na wzrost Twojej pozycji w rankingu wpływa ogólny postęp konta: rozwój panels, generacja kWh i ogólny ruch po energetycznej ścieżce projektu.

### 16-6. Czy można rosnąć jednocześnie na poziomie i w rankingu?

Tak. Gdy użytkownik rozwija panele, generację i ogólny postęp energetyczny, zwykle wzmacnia zarówno swój poziom, jak i pozycję w rankingu.

### 16-7. Dlaczego mam wysoki poziom, ale moje miejsce w rankingu nie jest pierwsze?

Ponieważ ranking to miejsce wśród wszystkich uczestników, a nie tylko twój osobisty postęp. Inni gracze też rosną, więc twoja pozycja może się zmieniać nawet przy dobrym poziomie.

### 16-8. Dlaczego mój ranking może się przesuwać bez moich nowych działań?

Ponieważ ranking nie istnieje sam z siebie, tylko w porównaniu ze wszystkimi uczestnikami. Gdy ty niczego nie zmieniasz, inni użytkownicy nadal rosną, a to wpływa na twoją pozycję.

### 16-9. Gdzie widzę swoje miejsce w rankingu?

W sekcji Ranks — tam wyświetla się twoje miejsce wśród innych uczestników.

### 16-10. Dlaczego mój ranking może spadać nawet wtedy, gdy robię postępy?

Ponieważ dla rankingu liczy się nie tylko twój własny wzrost, ale także tempo wzrostu innych uczestników. Nawet jeśli konto się wzmacnia, miejsce może spadać, gdy inni wyprzedzają cię szybciej.

## 17. Status Activ

### 17-1. Co oznacza status Activ?

Activ to stały aktywny status. Oznacza, że gra zaczęła się naprawdę, ponieważ został aktywowany co najmniej jeden panel.

### 17-2. Jak zdobyć Activ?

Aby zdobyć Activ, wystarczy aktywować jeden panel. Po tym aktywacji status jest nadawany na stałe.

### 17-3. Czy Activ jest tymczasowy czy stały?

Activ to status stały.

### 17-4. Czy Activ zostaje zachowany, jeśli panel później trafi do Archive?

Tak. Nawet jeśli panel później trafi do Archive, status Activ pozostaje.

### 17-5. Dlaczego Activ jest ważny?

Activ pomaga oddzielić prawdziwych graczy od przypadkowych rejestracji, botów i farm botów. Potwierdza realny udział użytkownika w projekcie.

### 17-6. Czy Activ może zniknąć później?

Nie. Activ to status stały i pozostaje nawet wtedy, gdy pierwszy panel później trafi do Archive.

### 17-7. Dlaczego Activ jest potrzebny do ochrony przed botami i farmami botów?

Ponieważ Activ potwierdza realne uczestnictwo, a nie pusty konto do sztucznego nabijania wyników. Dzięki temu system poleceń i ekonomia są uczciwsze.

### 17-8. Co zmienia się na koncie po otrzymaniu Activ?

Konto jest traktowane jako potwierdzony żywy uczestnik projektu. Wpływa to na uczciwe działanie poleceń i na zaufanie do aktywności.

### 17-9. Dlaczego Activ pojawia się właśnie po pierwszym panelu?

Ponieważ aktywacja pierwszego panelu jest wyraźnym znakiem realnego udziału. Projekt używa tego kroku jako filtru przeciwko pustym kontom.

### 17-10. Czy można stracić Activ z powodu braku aktywności?

Nie. Activ to stały status i nie znika z powodu bezczynności.

## 18. VIP NFT

### 18-1. Czym jest EFHC VIP NFT?

EFHC VIP NFT to karta klubowa, klucz do całego przyszłego ekosystemu EFHC, cyfrowy znak przynależności i klucz do przyszłych możliwości projektu.

### 18-2. Co daje posiadanie jednego EFHC VIP NFT?

Posiadanie jednego EFHC VIP NFT daje podwyższoną generację dla wszystkich paneli gracza.

### 18-3. Po jakich oznakach widać, że VIP jest już uwzględniony?

Jeśli system uwzględnił już VIP NFT, w interfejsie widać status VIP, a związane z nim korzyści konta stają się zauważalne.

### 18-4. Gdzie zobaczę efekt VIP?

Efekt VIP jest widoczny w tych sekcjach, w których projekt uwzględnia korzyści VIP NFT, a także w górnym panelu oraz w Profilu/Ustawieniach.

### 18-5. Czy trzeba ręcznie włączać VIP?

Nie. Logika projektu jest zaprojektowana do automatycznego sprawdzania portfela i automatycznej aktualizacji statusu VIP po wykryciu NFT w odpowiedniej kolekcji.

### 18-6. Czy 2 albo 3 VIP NFT dają graczowi dodatkowe przywileje?

Nie. Dla gracza posiadanie 2 albo 3 VIP NFT nie daje dodatkowych przywilejów ponad jedną VIP NFT.

### 18-7. Dlaczego drugi VIP NFT nie wzmacnia efektu?

W projekcie VIP daje wzmocnienie generacji jako jeden aktywny status. Dodatkowe VIP NFT nie dają dodatkowego wzmocnienia, aby efekt nie rozpędzał się bez końca.

### 18-8. Czy VIP wpływa na jeden panel czy na wszystkie?

VIP wpływa na generację wszystkich paneli użytkownika, a nie tylko jednego konkretnego.

### 18-9. Jak sprawdzić, że VIP naprawdę wpływa na konto?

Sprawdzaj nie tylko obecność statusu VIP, ale również powiązane korzyści w mechanice konta, przede wszystkim tam, gdzie uwzględniany jest efekt VIP, w tym generacja.

### 18-10. Czy potrzebny jest podłączony portfel, żeby bot zobaczył moje VIP NFT?

Tak. Aby bot zobaczył VIP NFT, musi wiedzieć, który portfel należy do konta. Dlatego Wallet musi być podłączony, a potem należy sprawdzić status VIP w interfejsie.

### 18-11. Czy mogę dysponować swoim VIP NFT według własnego uznania?

Tak. EFHC VIP NFT można przekazywać, podarować i sprzedawać na marketplace’ach.

### 18-12. Jeśli sprzedam lub przeniosę swój VIP NFT na inny portfel, co stanie się z moją generacją?

Bot regularnie skanuje blockchain i sprawdza obecność NFT na Twoim podłączonym portfelu. Jeśli sprzedasz, podarujesz lub przeniesiesz swój VIP NFT na inny adres, system to wykryje, wyłączy Twój status VIP, a generacja wszystkich Twoich paneli automatycznie wróci do stawki bazowej.

## 19. Poziomy

### 19-1. Dlaczego warto podnosić poziom?

Wzrost poziomu pokazuje postęp użytkownika wewnątrz projektu i pomaga zobaczyć, jak rozwija się konto. To wizualny i znaczeniowy wskaźnik ruchu do przodu.

### 19-2. Co obejmuje sekcja Poziomy?

Sekcja Poziomy pokazuje wszystkie skale wzrostu projektu: 12 poziomów postępu energetycznego, 6 poziomów systemu poleceń i inne linie poziomów projektu, jeśli zostaną dodane.

### 19-3. Ile poziomów postępu energetycznego jest w projekcie?

W projekcie przewidziano 12 poziomów postępu energetycznego.

### 19-4. Ile poziomów jest w systemie poleceń?

W projekcie przewidziano 6 poziomów systemu poleceń: od 0 do 5.

### 19-5. Dlaczego poziomy są przydatne zwykłemu graczowi?

Poziomy pomagają zrozumieć, gdzie jesteś teraz, ile już zostało zrobione, dokąd iść dalej i jaki kolejny próg czeka przed tobą.

### 19-6. Jak są powiązane poziomy energii, poziomy poleceń i ogólny wzrost konta?

To części jednej wspólnej drogi. Generacja energii porusza główny postęp, aktywne polecenia wzmacniają linię poleceń, a razem pokazują, jak mocno rozwija się konto.

### 19-7. Eco Initiate (0 kWh)

**Znaczenie dla gracza:** Twój pierwszy panel jest zainstalowany i gotowy do pracy. Robisz główny krok, aby stać się niezależnym producentem czystej energii. To twój status startowy — dopiero wchodzisz na ścieżkę generacji.

**Dokładna zasada:** Poziom Eco Initiate odpowiada wartości 0 kWh.

**Praktyczny skutek:** Następny krok to uruchomić wzrost generacji przez panele i doprowadzić postęp do 100 kWh.

### 19-8. Hope Bringer (100 kWh)

**Znaczenie dla gracza:** Pierwsze kilowaty już płyną! Twoje panele skutecznie generują zieloną energię, dając naturze nadzieję na bezemisyjną przyszłość. Widzisz już pierwsze realne wyniki: energia ruszyła i postęp się przesunął.

**Dokładna zasada:** Poziom Hope Bringer zaczyna się od 100 kWh.

**Praktyczny skutek:** Kolejny cel to zwiększyć stabilność i dojść do 300 kWh, aby wejść na następny stopień.

### 19-9. Energy Seeker (300 kWh)

**Znaczenie dla gracza:** System działa świetnie, stale zasilając sieć czystą energią elektryczną. Każda jednostka energii wyprodukowana przez panele wypiera paliwa kopalne. Konto weszło w tryb stabilnego wzrostu: nie jesteś już „nowicjuszem”, lecz użytkownikiem z realną generacją.

**Dokładna zasada:** Poziom Energy Seeker zaczyna się od 300 kWh.

**Praktyczny skutek:** W praktyce to sygnał, że można wzmacniać panele i częściej korzystać z Exchange, aby zamieniać energię na saldo główne.

### 19-10. Nature's Voice (600 kWh)

**Znaczenie dla gracza:** Twój wkład staje się zauważalny. Generując energię przy pomocy zielonych technologii, stajesz się głosem natury i pokazujesz, że postęp może być ekologiczny. Twój wkład staje się bardziej widoczny: postęp jest już odczuwany nie jako przypadek, lecz jako trajektoria.

**Dokładna zasada:** Poziom Nature's Voice zaczyna się od 600 kWh.

**Praktyczny skutek:** Następny punkt orientacyjny to 1000 kWh (Earth Ally). Warto porównywać tempo w Energy i liczbę aktywnych paneli.

### 19-11. Earth Ally (1000 kWh)

**Znaczenie dla gracza:** Pierwsza megawatogodzina została wygenerowana! Twoje panele wyprodukowały imponującą ilość czystej energii. Teraz jesteś ważnym uczestnikiem zielonej transformacji i prawdziwym sojusznikiem planety. Przekroczyłeś ważny próg: 1000 kWh to już poważny wolumen zgromadzonej generacji.

**Dokładna zasada:** Poziom Earth Ally zaczyna się od 1000 kWh.

**Praktyczny skutek:** W praktyce to punkt, w którym wzrost staje się przewidywalny: wzmacniaj park paneli i utrzymuj regularną wymianę energii.

### 19-12. Climate Fighter (2000 kWh)

**Znaczenie dla gracza:** Twoja generacja realnie uderza w zmianę klimatu. Każdy wyprodukowany kilowat bezpośrednio zmniejsza potrzebę spalania węgla i gazu. Rośniesz już systemowo: postęp jest widoczny zarówno na poziomie, jak i w ogólnej dynamice konta.

**Dokładna zasada:** Poziom Climate Fighter zaczyna się od 2000 kWh.

**Praktyczny skutek:** Następny krok to utrzymać tempo i dojść do 3500 kWh. Patrz na szybkość generacji i korzystaj z VIP w razie potrzeby.

### 19-13. Green Sentinel (3500 kWh)

**Znaczenie dla gracza:** Stabilny strumień energii z twoich paneli stoi na straży czystego powietrza. Przynosisz społeczeństwu odczuwalną korzyść, nie zostawiając śladu węglowego. Twoje konto staje się „strażnikiem” stabilnej generacji: wzrost idzie pewnie.

**Dokładna zasada:** Poziom Green Sentinel zaczyna się od 3500 kWh.

**Praktyczny skutek:** W praktyce oznacza to, że panele działają już jak system — utrzymuj aktywne panele i planuj wzrost do 5000 kWh.

### 19-14. Planet Defender (5000 kWh)

**Znaczenie dla gracza:** 5000 kWh czystej generacji! Moc twoich paneli działa jak niewidzialna tarcza, chroniąca atmosferę przed tysiącami kilogramów emisji gazów cieplarnianych. 5000 kWh to duży znak skali: jesteś już w strefie silnych uczestników pod względem energii.

**Dokładna zasada:** Poziom Planet Defender zaczyna się od 5000 kWh.

**Praktyczny skutek:** Następny punkt orientacyjny to 7500 kWh. Często w tym momencie gracze wzmacniają zarówno panele, jak i sieć poleceń.

### 19-15. Eco Champion (7500 kWh)

**Znaczenie dla gracza:** Wybitny wolumen produkcji! Jesteś prawdziwym czempionem zielonej energetyki, którego wkład wyraźnie zmienia globalny bilans energetyczny na lepsze. To poziom tych, którzy stabilnie utrzymują wysokie tempo generacji.

**Dokładna zasada:** Poziom Eco Champion zaczyna się od 7500 kWh.

**Praktyczny skutek:** W praktyce: trzymaj dyscyplinę — aktywne panele, regularny Exchange, kontrola historii i sald.

### 19-16. Planet Saver (10000 kWh)

**Znaczenie dla gracza:** 10 megawatogodzin! Wygenerowałeś tyle czystej energii, że dosłownie ratujesz całe ekosystemy, udowadniając maksymalną skuteczność swoich paneli. 10 000 kWh to już „dziesięć megawatogodzin” generacji, bardzo mocny etap postępu.

**Dokładna zasada:** Poziom Planet Saver zaczyna się od 10000 kWh.

**Praktyczny skutek:** Następny krok to 15000 kWh. Na tym etapie warto optymalizować wszystko: panele, VIP, polecenia i działania wewnętrzne.

### 19-17. Green Commander (15000 kWh)

**Znaczenie dla gracza:** Okręt flagowy ekologicznej generacji. Twoje panele zasilają przyszłość, a imponujące wolumeny produkcji wyznaczają zupełnie nowe, wysokie standardy dla całej społeczności. Jesteś blisko szczytu: to poziom przywódczego formatu w energii.

**Dokładna zasada:** Poziom Green Commander zaczyna się od 15000 kWh.

**Praktyczny skutek:** W praktyce: utrzymuj stabilność i rośnij do 20000+ kWh, obserwując aktywne panele i tempo w Energy.

### 19-18. Guardian of Earth (20000+ kWh)

**Znaczenie dla gracza:** Szczyt rozwoju. Generując ponad 20 MWh całkowicie czystej energii, stałeś się prawdziwym Guardian of Earth. Twoje panele czerpią siłę z samej natury, aby zasilać ten świat i chronić go dla przyszłych pokoleń. To najwyższy stopień drabiny: osiągnąłeś najwyższy uznany poziom postępu.

**Dokładna zasada:** Poziom Guardian of Earth odpowiada 20000+ kWh.

**Praktyczny efekt:** W praktyce masz zabezpieczony najwyższy status. Od tego momentu nacisk kładziony jest na utrzymanie systemu, skalowanie paneli i wzmacnianie udziału w ekosystemie poprzez panele, VIP i rozwój poleceń.

### 19-19. Poziom poleceń 0

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 0 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-20. Poziom poleceń 1

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 1 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-21. Poziom poleceń 2

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 10 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-22. Poziom poleceń 3

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 100 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-23. Poziom poleceń 4

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 300 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-24. Poziom poleceń 5

**Znaczenie dla gracza:** To oznaczenie twojego wzrostu w systemie poleceń — pokazuje skalę aktywnych zaproszonych użytkowników.

**Dokładna zasada:** Za osiągnięcie poziomu naliczany jest jednorazowy bonus: 1000 EFHCb.

**Praktyczny skutek:** W praktyce: po osiągnięciu poziomu sprawdź saldo bonusowe i historię operacji, aby zobaczyć naliczenie.

### 19-25. Jak rozumieć postęp poziomów bez błędów?

**Znaczenie dla gracza:** Ten blok pomaga trzeźwo ocenić postęp i patrzeć na poziomy przez pryzmat realnej generacji energii.

**Dokładna zasada:** Poziomy są określane przez skumulowaną generację w kWh. Im większa łączna generacja, tym wyższy poziom.

**Praktyczny efekt:** W praktyce skupiaj się na wzroście energii, liczbie aktywnych paneli i ogólnym tempie generacji. To one dają realny postęp poziomu.

### 19-26. Dlaczego nazwy poziomów są związane z ekologią i planetą?

Ponieważ sama idea gry jest związana z wirtualną zieloną energią, motywacją ludzi i symbolicznym wkładem w uzdrawianie planety Ziemia.

## 20. FAQ / Pomoc

### 20-1. Gdzie otworzyć FAQ?

FAQ otwiera się z profilu jako wbudowana sekcja pomocy bota, w której zebrane są odpowiedzi dotyczące głównych działań, ekranów i zasad projektu.

### 20-2. Do czego służy FAQ / Pomoc?

Ta sekcja jest potrzebna po to, aby użytkownik szybko znajdował zrozumiałe odpowiedzi, dokładne liczby, realne zasady projektu i sens głównych działań bez domysłów i chaosu.

### 20-3. Dlaczego FAQ jest tak szczegółowo rozpisane?

Ponieważ projekt jest wielowarstwowy i krótka, sucha pomoc nie obejmuje realnych pytań gracza. Tutaj ważne są sens, zrozumiałość, dokładne liczby i realne konsekwencje działań.

### 20-4. Czy z FAQ można zrozumieć całą drogę gracza wewnątrz bota?

Tak. Dobre FAQ powinno wyjaśniać nie tylko pojedyncze przyciski, ale całą drogę: od pierwszego panelu po energię, wymianę, salda, poziomy, statusy i wzrost konta.

### 20-5. Co zrobić, jeśli nie znalazłem odpowiedzi za pierwszym razem?

Najlepiej otworzyć sekcję bliską znaczeniowo i przejrzeć sąsiednie pytania. W dużym bocie wiele odpowiedzi jest ze sobą powiązanych i jeden blok często pomaga zrozumieć kolejny.

### 20-6. Jak poprawnie korzystać z FAQ?

Najlepiej iść sekcja po sekcji: najpierw zrozumieć ogólną logikę projektu, potem swoje ekrany i działania, a dopiero potem sprawdzać konkretne zasady dotyczące sald, wypłat, VIP, poleceń, poziomów i innych funkcji bota.

### 20-7. Co sprawdzić, jeśli „wszystko wygląda na zepsute”?

Sprawdź trzy rzeczy: 1) Wallet — czy portfel jest podłączony i czy wybrano główny, 2) salda i historię — czy widać tam ślad twojej operacji, 3) właściwą sekcję (Panels / Energy / Exchange / Withdraw). Zwykle odpowiedź znajduje się w jednym z tych miejsc.

### 20-8. Jaki jest najszybszy sposób, aby zrozumieć, co stało się z moimi EFHC?

Otwórz historię salda. Historia pokazuje, co dokładnie zmieniło salda: nagroda, działanie wewnętrzne, wymiana czy wypłata.

### 20-9. Od czego zacząć, jeśli pierwszy raz otworzyłem bota i nic nie rozumiem?

Zacznij od Energy (główny ekran), potem otwórz Panels, sprawdź salda i historię, a dopiero później decyduj, czy potrzebny jest portfel i doładowanie.

### 20-10. Jak najszybciej znaleźć potrzebne pytanie w FAQ?

Najszybszy sposób to otworzyć potrzebną sekcję tematyczną (Wallet / Panels / Exchange / Withdraw itd.) i szukać pytania tam. Jeśli nie masz pewności, zacznij od sekcji FAQ / Pomoc i kieruj się słowami kluczowymi.
