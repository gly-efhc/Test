# EFHC FAQ (SW)

Structure: {'sections': 20, 'levels_section_id': 19, 'help_section_id': 20, 'depth': 2}.

## 1. Kuhusu Mradi

### 1-1. EFHC ni nini?

EFHC ni mradi wa mchezo kuhusu nishati, maendeleo, na ukuaji wa akaunti ndani ya bot. Mtumiaji hununua Panels, hukusanya nishati, huibadilisha kuwa EFHC, hufuatilia salio, hupanda viwango, husogea kwenye rank, na hutumia vipengele vya ziada vya mradi.

Maana ya vifupisho:
— EFHC — Energy for Humanity Coin
— EFHCm — sarafu kuu
— EFHCb — sarafu za bonasi
— EFHCj — jetton ya nje ya EFHC
— EFHC — salio la jumla (bonasi + kuu)

### 1-2. Kila kitu kinafanyaje kazi hapa?

Ndani ya mradi huu, kila kitu kinajengwa juu ya nishati na ukuaji wa akaunti. Mtumiaji hufanya kazi na Panels, hukusanya nishati, huibadilisha kuwa EFHC kuu, hufuatilia salio, huunganisha Wallet, huimarisha maendeleo yake, na hutumia mifumo ya ziada ya mradi.

### 1-3. Nifanye nini ndani ya bot hii?

Lengo kuu ni kukuza akaunti yako. Kwa hilo, mtumiaji hufanya kazi na Panels, hufuatilia uzalishaji wa nishati, hutumia Exchange, huangalia salio zake, huunganisha Wallet, hushiriki katika mifumo ya ziada ya mradi, na hatua kwa hatua huimarisha maendeleo yake.

### 1-4. Ninawezaje kukua na kusonga mbele hapa?

Ukuaji ndani ya bot unajengwa juu ya nishati na shughuli. Kadiri mtumiaji anavyokuwa na Panels nyingi zaidi, nishati zaidi, vitendo vya manufaa, na maendeleo zaidi, ndivyo akaunti yake inavyokua kuwa imara zaidi na kupanda juu zaidi ndani ya mfumo wa levels na rank.

### 1-5. Maana kuu ya mradi huu ni ipi?

Maana kuu ya mradi huu ni kuonyesha njia kutoka kuanzisha Panel hadi kuzalisha nishati, kisha kufikia matokeo katika EFHC. Mtumiaji haoni tu namba za kubahatisha, bali njia iliyounganishwa: Panel, nishati, Exchange, salio, maendeleo, levels, na nafasi kati ya washiriki wengine.

### 1-6. Je, huu ni mchezo wa burudani tu au kuna mantiki ya maendeleo?

Hapa kuna mantiki kamili ya ukuaji. Mtumiaji habofyi tu vitufe, bali hatua kwa hatua huimarisha akaunti yake: hununua Panels, huanza uzalishaji, hupata Activ status, hukusanya bonasi, huendeleza mfumo wa Referrals, na huona matokeo ya safari yake.

### 1-7. EFHC zangu za kwanza zinatoka wapi?

EFHC za kwanza hutoka kwenye vyanzo viwili vikuu: bonus accruals (kwenda kwenye sarafu za bonasi EFHCb) na kubadilisha nishati kupitia Exchange (kwenda kwenye sarafu kuu EFHCm). Njia yenye nguvu zaidi ni Panels → nishati → Exchange → salio kuu.

### 1-8. Nishati yangu inatoka wapi?

Nishati hutolewa na Panels zako zilizo active. Wakati Panels ziko active, huzalisha nishati, na nishati hiyo hukusanyika kama nishati inayopatikana kwa Exchange.

### 1-9. Ni nini kinaathiri zaidi ukuaji wangu ndani ya mradi?

Kitu kinachoathiri zaidi ukuaji ni idadi ya Panels active na uzalishaji wao wa jumla. Kichocheo cha pili ni VIP NFT (ikiwa unayo), kwa sababu inaathiri uzalishaji. Tasks, Ads, na Referrals ni nyongeza ya manufaa, lakini si msingi mkuu.

### 1-10. Ninawezaje kujua kwamba nasonga kwa njia sahihi?

Kama vitu vitatu vinaongezeka — uzalishaji, nishati inayopatikana, na salio kuu baada ya Exchange — basi unasonga kwa njia sahihi. Njia ya haraka ya kukagua hili ni kupitia Energy na historia ya shughuli.

## 2. Skrini Kuu

### 2-1. Skrini kuu inaonyesha nini?

Skrini kuu ni ukurasa wa Energy. Huu hukusanya vipengele muhimu vya hali ya sasa ya akaunti: vitendo vya haraka, taarifa kuhusu maendeleo, na sehemu za kuingia kwenye maeneo muhimu ya bot.

### 2-2. Kwa nini skrini kuu ni muhimu?

Inahitajika ili mtumiaji aweze kuona mara moja mambo muhimu kuhusu akaunti yake na kuelewa kwa haraka hali ya sasa, maendeleo, na kile kinachoweza kufanywa kinachofuata.

### 2-3. Niangalie nini kwanza?

Kwanza inafaa kuangalia paneli ya juu, salio la jumla, skrini ya Energy, na vitendo vinavyopatikana. Hivi ndivyo vinavyoonyesha kwa kasi zaidi hali ya sasa ya akaunti na kile kinachoweza kufanywa baadaye.

### 2-4. Maendeleo yangu ya sasa yanaonekana wapi?

Maendeleo ya sasa yanaonyeshwa katika sehemu zinazohusiana na nishati, Panels, levels, na rank za bot. Humo ndipo unaona jinsi mtumiaji anavyosonga mbele ndani ya mradi.

### 2-5. Kwa nini skrini kuu ni muhimu kila siku?

Kwa sababu hapa ndipo unaona kwa haraka zaidi jinsi akaunti imebadilika: kuna nishati kiasi gani sasa, kuna Panels ngapi active, maendeleo yanakua vipi, na ni hatua gani inayofuata ambayo mtumiaji tayari yuko tayari kuichukua.

### 2-6. Ni wapi ni bora kuanza?

Kwanza angalia paneli ya juu, elewa salio zako ni zipi, fungua ukurasa wa Energy, angalia sehemu ya Panels, kisha soma FAQ kuhusu vitendo vya msingi. Ikiwa hatua unayotaka kufanya inahitaji Wallet, hatua inayofuata itakuwa kuiunganisha.

### 2-7. Ni vitufe gani vya skrini kuu ni muhimu zaidi?

Vitendo vikuu ni Panels, Exchange, Ujazaji wa moja kwa moja kwenye upau wa juu na Hub. Hub huonyesha kitufe cha Jaza pekee.

### 2-8. Ninapaswa kukagua nini kwenye skrini kuu kila siku?

Vitu vitatu: 1) kuna Panels ngapi active, 2) kasi ya uzalishaji ni ipi, 3) ni kiasi gani cha nishati inayopatikana tayari kimekusanyika kwa ajili ya Exchange.

### 2-9. Kwa nini skrini kuu hubadilika kadiri muda unavyopita?

Kwa sababu inaakisi hali hai ya akaunti. Panels, nishati, na shughuli zinapoonekana, skrini huacha kuwa tupu na huanza kuonyesha data zaidi ya manufaa pamoja na maendeleo.

### 2-10. Ninawezaje kuelewa kutoka kwenye skrini kuu kwamba akaunti inakua?

Unapoona ukuaji kwa mambo ya kweli: uzalishaji si sifuri, nishati inakusanyika, na baada ya Exchange salio kuu linaongezeka. Hizi ndizo ishara za uaminifu zaidi za maendeleo.

## 3. Paneli ya Juu

### 3-1. Paneli ya juu ni nini?

Paneli ya juu ni kipengele tofauti cha kiolesura na kizuizi kikuu cha taarifa za haraka kinachopatikana kwenye kurasa kuu za bot.

### 3-2. Ni nini huonyeshwa kwenye upau wa juu?

Kwenye upau wa juu huonyeshwa avatar, jina, kiwango cha maendeleo ya nishati, hadhi ya VIP, salio la jumla, kitufe cha Top Up, na kitufe cha Hub.

### 3-3. Kwa nini paneli ya juu ni muhimu?

Kwa sababu hukusaidia kuona mara moja mambo muhimu kuhusu akaunti yako bila kupitia sehemu nyingi zisizohitajika: wewe ni nani, maendeleo yako yako wapi, kama una VIP, una sarafu ngapi kwa jumla, na ni vitendo gani vya haraka vinapatikana sasa hivi.

### 3-4. Salio la jumla kwenye paneli ya juu linaonyesha nini?

Salio la jumla linaonyesha jumla ya sarafu zote ulizonazo. Hii ni rahisi kwa sababu huhitaji kujumlisha rasilimali mwenyewe ili kuelewa uwezo wako wa kuanzisha na hali ya akaunti kwenye mchezo.

### 3-5. Kwa nini salio la jumla ni rahisi kwa kitendo cha ndani?

Kwa sababu linaonyesha uwezo wa jumla wa kuanzisha wa mchezaji ndani ya mchezo na hukusaidia kuelewa haraka kama rasilimali zinatosha kwa vitendo vya ndani.

### 3-6. Kwa nini salio la jumla halilingani na kiasi ninachoweza kutoa sasa hivi?

Kwa sababu salio la jumla linajumuisha sarafu kuu na sarafu za bonasi. Sarafu za bonasi zinahitajika kwa michakato ya mchezo na hazitolewi moja kwa moja.

### 3-7. Ni wakati gani nifae kutumia kitufe cha “Top up” kwenye paneli ya juu?

Kitumie unapohitaji kwenda haraka kwenye mchakato wa kuongeza salio kuu uliopo ndani ya programu bila kufungua sehemu nyingine kwa mkono.

### 3-8. Kwa nini kufungua Hub kutoka kwenye upau wa juu?

Ili kufungua haraka kadi za vitendo vinavyohusiana na mradi na kwenda kwenye mtiririko wa nje unaohitajika bila urambazaji wa ziada kwenye kiolesura.

### 3-9. Kwa nini paneli ya juu inaonekana kwenye kurasa tofauti?

Kwa sababu hii ni kama “dashibodi” ya akaunti: inahitajika ili kila mara uone mambo ya msingi — salio, hadhi, na vitendo vya haraka — hata ukiwa umefungua sehemu nyingine.

### 3-10. Nifanye nini kama data kwenye paneli ya juu inaonekana si sahihi?

Kwanza sasisha ukurasa na uangalie historia ya salio: hapo ndipo ukweli wa miamala unaonekana. Ikiwa historia na salio vinafanana, basi data iko sahihi; huenda ulikuwa unaangalia salio tofauti, kwa mfano la jumla badala ya salio kuu.

## 4. Wasifu / Mipangilio

### 4-1. Sehemu ya Wasifu / Mipangilio ni nini?

Wasifu / Mipangilio ni sehemu ambako usimamizi wa wasifu na vigezo vya bot unafanyika. Hapa ndipo hadhi kuu zinaonekana na mipangilio ya kibinafsi ya kiolesura inapatikana.

### 4-2. Ninaweza kufanya nini ndani ya wasifu?

Ndani ya wasifu kuna mipangilio ya msingi ya mtumiaji na njia za haraka za kwenda kwenye sehemu muhimu: Wallet, historia ya salio, FAQ, na maeneo mengine muhimu ya usimamizi.

### 4-3. Ni nini kinaonyeshwa kwenye sehemu ya juu ya Wasifu / Mipangilio?

Sehemu ya juu ya Wasifu / Mipangilio inaonyesha avatar, jina la Telegram, na hadhi za Activ na VIP ikiwa tayari zipo.

### 4-4. Ninaweza kubadilisha lugha wapi?

Lugha hubadilishwa ndani ya Wasifu / Mipangilio.

### 4-5. Kwa nini wasifu unahitajika kwa ujumla?

Wasifu ni kituo cha binafsi cha kusimamia akaunti. Hapa mtumiaji haoni tu hadhi zake, bali pia hufungua sehemu muhimu zinazohusiana na Wallet, historia, lugha, na msaada.

### 4-6. Historia ya salio inafunguliwa wapi ndani ya wasifu?

Ndani ya sehemu ya Wasifu / Mipangilio kuna ingizo maalum la historia ya salio, ambako mapato na matumizi yanaonekana.

### 4-7. Lugha inabadilishwa wapi ndani ya wasifu?

Mabadiliko ya lugha yako ndani ya Wasifu / Mipangilio, kwa sababu huu ni mpangilio wa kibinafsi wa akaunti.

### 4-8. Ni wapi katika Profile nifungue Wallet kwa ajili ya kufanya kazi na wallet?

Katika sehemu ya Profile kuna kipengele tofauti cha Wallet. Kifungue unapohitaji kuunganisha wallet, kuangalia binding au kwenda kwenye hatua zinazohusiana na wallet.

### 4-9. Ni wapi katika Profile nifungue FAQ haraka nikihitaji jibu?

Katika sehemu ya Profile kuna njia ya kuingia kwenye FAQ. Ifungue unapohitaji jibu la haraka kuhusu interface, balance, panels, energy, exchange, withdrawal au kazi nyingine za WebApp.

### 4-10. Ni nini kilichomo kwenye sehemu ya “Msaada na Taarifa”?

Humo hukusanywa vipengele vya msaada: FAQ, vidokezo/taarifa, na kila kitu kinachomsaidia mtumiaji kuelewa mradi bila kuchanganyikiwa.

### 4-11. Kiolesura cha mradi kinapatikana kwa lugha ngapi?

Kiolesura cha bot na mfumo wa msaada (FAQ) vimetafsiriwa katika lugha 13. Unaweza kuchagua lugha inayokufaa katika mipangilio ya wasifu, na mfumo utabadilisha mara moja maandishi yote na kiolesura kulingana na chaguo lako.

## 5. Wallet

### 5-1. Kwa nini pochi kuu inahitajika?

Pochi kuu hutumika kwa vitendo vinavyohusiana na shughuli za nje za mradi: kutoa fedha, kujaza salio, kuthibitisha umiliki wa anwani na vitendo vingine vinavyohitaji pochi iliyounganishwa.

### 5-2. Inawezekana kubadilisha Wallet kuu?

Ndiyo. Mtumiaji anaweza kuchagua Wallet nyingine kuu kutoka kwenye wallets ambazo tayari zimeunganishwa.

### 5-3. Inawezekana kufuta Wallet iliyounganishwa?

Ndiyo. Ikiwa Wallet haitumiki tena, uunganisho wake unaweza kuondolewa.

### 5-4. Kwa nini pochi ile ile haiwezi kuunganishwa na akaunti mbili?

Pochi ile ile haipaswi kutumika kwa akaunti mbili tofauti kwa wakati mmoja. Ikiwa pochi tayari imeunganishwa na akaunti moja, lazima iondolewe kwanza kwenye akaunti hiyo kabla ya kuunganishwa na nyingine. Hii huondoa mkanganyiko kwenye hadhi, ukaguzi na matokeo yanayohusiana na pochi.

### 5-5. Nini kitatokea nikibonyeza kitendo ambacho kinahitaji Wallet lakini sina Wallet?

Ikiwa kazi uliyochagua inahitaji Wallet, bot kwanza itazindua mantiki ya kuunganisha Wallet. Baada ya hapo utaweza kurudi kwenye kitendo hicho na kukikamilisha kawaida.

### 5-6. Naweza kuunganisha Wallet nyingi, na kwa nini hilo linahitajika?

Ndiyo. Unaweza kuunganisha Wallet nyingi ili uwe na anwani ya akiba au kutenganisha matumizi tofauti. Hata hivyo, Wallet moja huchaguliwa kuwa kuu — ndiyo inayotumiwa kwa chaguo-msingi katika shughuli zinazohitaji anwani iliyochaguliwa.

### 5-7. Nifanye nini ikiwa ninataka kutumia Wallet yangu kwenye akaunti nyingine?

Kwanza Wallet hii lazima iondolewe kwenye akaunti ya sasa. Baada ya hapo tu ndipo inaweza kuunganishwa na akaunti nyingine. Wallet ileile haipaswi kuunganishwa na akaunti mbili kwa wakati mmoja.

### 5-8. Inawezekana kutoa kwenda kwenye Wallet ambayo si kuu?

Kwa chaguo-msingi mfumo hutegemea Wallet kuu. Ikiwa unahitaji anwani nyingine, kwanza iweke kama Wallet kuu ndani ya Wallet, kisha ndipo utume ombi la Withdraw.

### 5-9. Nifanye nini kama Wallet imeunganishwa lakini Withdraw bado haipatikani?

Angalia mambo matatu: je, Wallet kuu imechaguliwa, je, salio kuu linatosha, na je, kiasi cha Withdraw hakipo chini ya 10 EFHC.

### 5-10. Ninaweza kuangalia wapi Wallet gani imeunganishwa na akaunti yangu kwa sasa?

Hili linapaswa kuangaliwa kwenye sehemu ya Wallet. Hapo mtumiaji huona Wallet zipi zimeunganishwa na akaunti na ni ipi inayotumika ndani ya akaunti.

### 5-11. Nifanye nini ikiwa nimepoteza ufikiaji wa wallet yangu kuu ya TON?

Kwa kuwa mradi unaruhusu kuunganisha wallet zaidi ya moja, unaweza kuunganisha wallet mpya katika sehemu ya Wallet, kuiweka kuwa wallet kuu, na kuondoa kabisa anwani ya zamani iliyohatarishwa kutoka kwenye orodha ya wallet zilizounganishwa.

## 6. Mizani na Historia

### 6-1. Kwa nini nina mizani mitatu tofauti?

Kwa sababu ndani ya bot fedha zina majukumu tofauti. Salio la jumla linaonyesha kila kitu pamoja, salio la bonasi linahitajika kwa mzunguko wa ndani wa mchezo, na salio kuu linaonyesha matokeo ambayo tayari yanaweza kutumika kwa hatua muhimu, ikiwemo Withdraw.

### 6-2. Bonus balance ni nini?

Bonus balance ni salio la ndani la mchezo. Hutumika kwa maendeleo ndani ya bot, huongezwa kupitia tasks, referrals, gifts na mechanics nyingine za ndani za mradi, lakini haitolewi moja kwa moja.

### 6-3. Salio kuu ni nini?

Salio kuu ni EFHC kuu. Hapa ndipo matokeo ya mzunguko wa mchezo hubadilika kuwa sarafu halisi za ndani ya mfumo, na kutoka hapa ndiko shughuli kuu, pamoja na Withdraw, zinapatikana.

### 6-4. Kwa nini kitendo cha ndani mmoja unaweza kugusa salio la bonasi na salio kuu kwa wakati mmoja?

Katika matumizi yote ya ndani ya mradi, fedha hukatwa kwanza kutoka kwenye salio la bonus. Ikiwa hilo halitoshi, kiasi kilichobaki hukatwa kutoka kwenye salio kuu.

### 6-5. Kwa nini kwenye historia kuna rekodi kadhaa mara moja?

Operesheni moja inaweza kugusa sehemu kadhaa za mtiririko wa fedha, kwa hiyo bot huiweka kwa mistari kadhaa ili kuonyesha kila mabadiliko kivyake.

### 6-6. Ni wapi naweza kuona EFHC zimeingia wapi au zimetoka wapi?

Kwa hili unahitaji sehemu ya historia ya salio. Inaonyesha mapato, matumizi, Exchange, kitendo cha ndani, Withdraw, na mabadiliko mengine ya fedha.

### 6-7. Kwa nini salio la jumla linaweza kuwa kubwa, lakini kiasi ninachoweza kutoa ni kidogo?

Kwa sababu salio la jumla hujumlisha salio kuu na la bonasi. Withdraw inaruhusiwa tu kutoka kwenye salio kuu, na salio la bonasi limekusudiwa kwa mzunguko wa ndani wa mradi. Ndiyo maana kwa Withdraw unapaswa kuangalia hasa salio kuu.

### 6-8. Ni wapi naweza kuona kwa haraka zaidi ni nini hasa kilibadilisha salio langu?

Katika historia ya salio. Hapo unaona ni operesheni gani ilileta mapato au matumizi, na ni salio gani lililoguswa.

### 6-9. Kwa nini salio la bonasi haliwezi kutolewa moja kwa moja?

Kwa sababu sarafu za bonasi ni sehemu ya mzunguko wa ndani wa mradi. Withdraw inaruhusiwa tu kutoka kwenye salio kuu.

### 6-10. Kwa nini baada ya Withdraw au Exchange historia haibadiliki mara moja sawasawa kila mahali?

Kwa sababu skrini tofauti hazisasishwi kila wakati kwa wakati mmoja. Kagua hivi: sasisha sehemu → angalia salio → angalia historia.

### 6-11. Nini kitatokea ikiwa, kwa intaneti dhaifu, nitabonyeza kwa bahati mbaya kitufe cha kuanzisha au exchange mara kadhaa mfululizo? Je, sarafu za ziada zitakatwa?

Hapana. Sarafu za ziada hazitakatwa. Kiini cha mfumo kina ulinzi mkali dhidi ya ukataji wa mara mbili. Hata ukibonyeza kitufe mara 10 kwa sababu mtandao umekwama, operesheni itatekelezwa mara moja tu.

## 7. Panels

### 7-1. Ni EFHC ngapi zinahitajika kuanzisha Panel moja?

EFHC 100 zinahitajika kuanzisha Panel moja.

### 7-2. Kuanzisha Panel ya kwanza kunatoa nini mara moja?

Kuanzisha Panel ya kwanza huanza uzalishaji wa nishati mara moja, hufungua njia ya maendeleo, huunda njia ya kupata EFHC kuu, na hukupa Activ status ya kudumu.

### 7-3. Uzalishaji wa Panel huanza lini?

Uzalishaji huanza mara moja baada ya kuanzisha Panel.

### 7-4. Muda wa maisha wa Panel ni upi?

Kila Panel ina mzunguko wa siku 180.

### 7-5. Nini hutokea kwa Panel baada ya mzunguko wa siku 180 kumalizika?

Baada ya mzunguko wa siku 180 kumalizika, Panel inazimwa na kuhamia Archive kama kumbukumbu ya maendeleo ya nishati ya mshiriki.

### 7-6. Ni hali zipi mbili za Panels zipo kwenye kiolesura?

Kwenye kiolesura kuna Activ na Archive. Activ ni Panels zinazoshiriki katika uzalishaji. Archive ni Panels ambazo tayari zimemaliza mzunguko wao wa active na huhifadhi historia ya safari yako.

### 7-7. Je, ninaweza kuanzisha zaidi ya Panel moja mara moja?

Ndiyo. Unaweza kuanzisha Panels mfululizo na kuongeza idadi ya Panels active. Kadiri Panels active zinavyoongezeka, ndivyo uzalishaji wa jumla wa nishati unavyoongezeka na maendeleo yako kuwa ya haraka zaidi.

### 7-8. Kipima muda cha “Imebaki” kwenye Panel kinamaanisha nini?

Kipima muda kinaonyesha muda uliobaki hadi mwisho wa mzunguko wa siku 180 wa Panel. Muda ukimalizika, Panel itahamia Archive kiotomatiki na haitakuwa active tena.

### 7-9. Kwa nini baada ya kuanzisha Panel ya kwanza nikawa Activ?

Kwa sababu Activ ni uthibitisho wa ushiriki wa kweli na ulinzi wa mradi dhidi ya bots. Mradi unaunganisha Activ na uanzishaji wa Panel ya kwanza ili hadhi hiyo ipatikane tu kwa washiriki halisi.

### 7-10. Kwa nini Panels active ni muhimu zaidi kuliko Archive?

Panels active huzalisha nishati sasa hivi — ndizo zinazotoa kasi yako ya sasa ya ukuaji. Panels za Archive ni Panels zilizokamilika; zinahifadhi historia, lakini hazitoi uzalishaji wa sasa.

### 7-11. Kwa nini nina Panels active chache kuliko nilizoanzisha?

Kwa sababu sehemu ya Panels huenda ilikamilisha muda wa siku 180 na kuhamia Archive. Panels active ni zile zinazofanya kazi sasa. Archive ni Panels zilizokamilika, na hazitoi uzalishaji wa sasa.

### 7-12. Je, Panels active zinaweza “kutoweka” kwa sababu ya kikomo cha 1000?

Hapana. Kikomo cha 1000 kinamaanisha kwamba kwa wakati mmoja huwezi kuwa na zaidi ya Panels active 1000. Panels active ambazo tayari zimeanzishwa hazipotei: zinabaki active hadi mwisho wa muda wao, kisha huhamia Archive.

### 7-13. Nifanye nini ikiwa nimeanzisha Panel lakini uzalishaji haukubadilika mara moja?

Angalia hivi:
— Sasisha sehemu ya Panels
— Hakikisha Panel imeonekana kwenye Active
— Fungua Energy na uangalie kasi ya uzalishaji
— Angalia historia ya salio (inapaswa kuwa na matumizi ya 100 EFHC)

### 7-14. Je, ninaweza kuanzisha Panel ikiwa nina chini ya 100 EFHC?

Hapana. EFHC 100 zinahitajika kuanzisha Panel. Fedha zikiwa chini ya hapo, uanzishaji hautapita.

### 7-15. Kwa nini Panels za Archive ni muhimu ikiwa hazizalishi tena?

Archive huhifadhi historia ya Panels zako na mizunguko uliyokamilisha. Hii ni “wasifu wa ukuaji” wako, lakini uzalishaji wa sasa unatolewa tu na Panels active.

### 7-16. Je, ninaweza kuanzisha Panel na kuona mara moja kwamba imekuwa active?

Ndiyo. Panel iliyoanzishwa inapaswa kuonekana kwenye orodha ya Active, na uanzishaji wake utaonekana pia katika historia ya salio.

### 7-17. Panel moja huzalisha energy kiasi gani katika siku 180?

Panel moja kwa kiwango cha msingi huzalisha 107.61984000 kWh katika siku 180. Ukiwa na EFHC VIP NFT, generation huwa 115.24032000 kWh.

## 8. Energy

### 8-1. Ukurasa wa Energy unaonyesha nini?

Ukurasa wa Energy unaonyesha maendeleo ya nishati, progress bar ya uzalishaji wa nishati, idadi ya Panels active, uzalishaji wa jumla wa Panels kwa sekunde, na viashiria vingine muhimu vya hali ya sasa.

### 8-2. Progress bar kwenye ukurasa wa Energy inaonyesha nini?

Progress bar inaonyesha njia kuelekea level inayofuata ya maendeleo ya mchezaji kwenye mfumo wa levels 12.

### 8-3. Uzalishaji wa jumla wa Panels kwa sekunde unamaanisha nini?

Huu ni msingi wa uzalishaji au konstanti ya VIP, uliokuzwa kwa idadi ya Panels active.

### 8-4. Kwa nini nishati ni muhimu sana?

Kwa sababu nishati ndiyo msingi wa kati wa maendeleo katika EFHC. Kupitia nishati, mtumiaji hutoka kutoka Panels hadi kwenye matokeo yanayoathiri salio, levels, rank, na ukuaji wa akaunti.

### 8-5. Je, ninaweza kuelewa kupitia Energy akaunti yangu ina nguvu kiasi gani?

Ndiyo. Ukurasa wa Energy unaonyesha haraka nguvu ya sasa ya mfumo: Panels ngapi zinafanya kazi, uzalishaji unaenda kwa kasi gani sasa, nishati kiasi gani tayari imekusanyika, na mtumiaji amesonga umbali gani hadi hatua inayofuata.

### 8-6. Kwa nini nishati inayopatikana na salio kuu huhesabiwa tofauti?

Kwa sababu ni vitu viwili tofauti. Nishati inayopatikana inaonyesha kWh zilizokusanywa, huku salio kuu likionyesha EFHC kuu ambazo tayari zimepatikana. Thamani hizi zina uhusiano, lakini si kitu kilekile.

### 8-7. Kwa nini nishati inaongezeka yenyewe lakini salio kuu haliongezeki moja kwa moja?

Kwa sababu mkusanyiko wa nishati na ukuaji wa salio kuu hutokea katika hatua tofauti. Kwanza paneli huzalisha nishati, na salio kuu huongezeka tu baada ya hatua tofauti ya exchange au hali nyingine ya kuongeza EFHC kuu.

### 8-8. Kasi ya uzalishaji kwa sekunde inaonyesha nini?

Hiki ni kipimo cha jinsi Panels zako active zinavyozalisha nishati kwa haraka sasa hivi, yaani kasi yako ya sasa ya ukuaji.

### 8-9. Ni nini muhimu zaidi kufuatilia katika Energy kila siku?

Idadi ya Panels active, kasi ya uzalishaji, na nishati inayopatikana — hivi ni viashiria vitatu muhimu zaidi vya hali ya akaunti.

### 8-10. Ninawezaje kuelewa kupitia Energy kwamba Panels zangu zinafanya kazi kweli?

Ikiwa kwenye Energy unaona Panels active na uzalishaji usio sifuri, na nishati inayopatikana inaongezeka taratibu — Panels zinafanya kazi. Ikiwa uzalishaji ni 0 na nishati haikusanyiki, basi hakuna Panels active au unaangalia baada ya mzunguko kumalizika.

### 8-11. Kwa nini nambari za energy zinazoenda kwenye skrini wakati mwingine zinaweza kurekebishwa kidogo au kuruka?

Kwa urahisi wako, nambari za energy iliyokusanywa husasishwa kwenye skrini kwa wakati halisi na kuonyesha mchakato endelevu wa generation. Hata hivyo, chanzo kikuu cha ukweli huwa ni server. Mara kwa mara, na pia baada ya kila hatua yako, app hufanya sync na server ili kuhakikisha usahihi wa kihesabu kabisa. Wakati huo, marekebisho madogo ya nambari za skrini hadi thamani sahihi ya server yanaweza kutokea.

## 9. Exchange

### 9-1. Exchange ni nini?

Exchange ni sehemu ambapo nishati hubadilishwa kuwa EFHC kuu. Hii ni moja ya hatua muhimu zaidi za safari ya mtumiaji ndani ya mradi.

### 9-2. Kubadilisha nishati kuwa EFHC hufanyaje kazi?

Exchange ni ubadilishaji wa maendeleo kuwa EFHC kuu. Nishati iliyokusanyika hubadilishwa kuwa sarafu kuu za mradi.

### 9-3. Sheria ya 1 kWh = 1 EFHC inamaanisha nini?

Huu ni kiwango cha ndani cha mradi kilichowekwa. Kila kitengo cha nishati hubadilishwa kuwa kiasi sawa cha EFHC.

### 9-4. Nini hutokea baada ya Exchange?

Baada ya Exchange, matokeo ya nishati huonekana kwenye salio kuu kama EFHC kuu. Hii si nishati iliyokusanyika tu tena, bali ni matokeo ambayo tayari yanashiriki katika shughuli kuu za mradi.

### 9-5. Kwa nini Exchange ni muhimu sana?

Kwa sababu ni kupitia Exchange ambapo mtumiaji hubadilisha nishati iliyokusanyika kuwa matokeo ya msingi. Hapa ndipo safari ya nishati inakuwa EFHC kuu.

### 9-6. Je, ninaweza kubadilisha sarafu za bonasi moja kwa moja bila nishati?

Hapana. Sarafu za bonasi kwanza hushiriki katika mzunguko wa ndani: kupitia hizo Panel hununuliwa, Panel huzalisha nishati, na ndipo baadaye nishati hubadilishwa kuwa EFHC kuu.

### 9-7. Kwa nini Exchange huingia moja kwa moja kwenye salio kuu, si la bonasi?

Kwa sababu Exchange ni kubadilisha nishati kuwa matokeo ya msingi. Ndani ya mradi kuna sheria iliyowekwa: 1 kWh = 1 EFHC, na matokeo ya Exchange huingia kila wakati kwenye salio kuu, ambalo ndilo linaloruhusu shughuli muhimu.

### 9-8. Nifanye nini ikiwa nimefanya Exchange lakini sioni matokeo mara moja?

Kwanza sasisha sehemu ya Exchange na angalia salio kuu. Kisha fungua historia ya salio: hapo kunapaswa kuwa na rekodi ya Exchange. Ikiwa rekodi ipo, Exchange imefanyika hata kama hukugundua mabadiliko mara moja.

### 9-9. Je, ninaweza kubadilisha nishati na mara moja kutuma ombi la Withdraw?

Ndiyo, ikiwa baada ya Exchange salio kuu lina EFHC za kutosha, kiasi cha Withdraw si chini ya 10 EFHC, na Wallet imeunganishwa na kuchaguliwa kama kuu.

### 9-10. Ni bora kufanya Exchange mara nyingi au kukusanya kwanza?

Hii inategemea lengo lako. Exchange ya mara kwa mara ni rahisi kwa udhibiti na operesheni, huku kukusanya ni rahisi kwa hatua kubwa zisizo za mara kwa mara. Sheria ni moja: matokeo ya Exchange huenda kwenye salio kuu.

### 9-11. Kwa nini baada ya Exchange nishati inayopatikana inapungua?

Kwa sababu unahamisha sehemu ya nishati iliyokusanyika kuwa EFHC kupitia Exchange. Nishati haitoweki — inabadilika kuwa sarafu.

Muhimu: kiasi cha nishati kwenye ukurasa wa Energy hakipaswi “kupungua” kama kosa la kuona; hupungua tu kwa sehemu iliyobadilishwa.

### 9-12. Ni nishati gani ambayo tayari ninaweza kubadilisha?

Unaweza kubadilisha nishati ambayo tayari imekusanyika na kuwa inayopatikana. Hiyo ndiyo nishati inayopatikana — kiasi kilicho tayari kwa hatua ndani ya Exchange.

### 9-13. Je, kuna kiwango cha chini cha kubadilisha energy kuwa main EFHC?

Hakuna mipaka mikali, lakini hesabu ya exchange imefungwa kwenye kiwango cha 1 kWh = 1 EFHC. Ni bora kukusanya na kubadilisha thamani kamili za energy kuanzia 1 kWh ili matokeo yaonekane mara moja kwenye salio kuu.

## 10. Withdraw

### 10-1. Kwa nini siwezi kutoa EFHC?

Kwa kawaida sababu ni kwamba hakuna fedha za kutosha kwenye salio kuu, Wallet haijaunganishwa, au kiasi kiko chini ya kiwango cha chini cha Withdraw. Ukaguzi unapaswa kuanza na Wallet na salio kuu.

### 10-2. Withdraw hufanyikaje?

Ombi la Withdraw huundwa, kisha huchakatwa haraka iwezekanavyo na operator wa kwanza aliye huru.

### 10-3. Kwa nini baada ya ombi la Withdraw salio lilibadilika mara moja?

Kwa sababu bot huanza kuhesabu operesheni hii mara moja ndani ya mfumo. Hii ni ili mtumiaji aone kuwa hatua hiyo tayari imefungwa na fedha zake na imekubaliwa na mfumo.

### 10-4. Ni balance gani inaweza kutumika kwa withdrawal?

Withdrawal inapatikana tu kutoka kwenye balance kuu.

### 10-5. Kwa nini Withdraw inapatikana tu kutoka kwenye salio kuu?

Kwa sababu salio kuu ndilo tayari ni matokeo ya mchakato wa mchezo au sarafu zilizonunuliwa. Sarafu za bonasi hushiriki katika mzunguko wa ndani na haziwezi kutolewa moja kwa moja.

### 10-6. Kiasi cha chini cha Withdraw ni kipi?

Kiasi cha chini cha Withdraw ni 10 EFHC.

### 10-7. Kwa kawaida ombi la Withdraw huchakatwa kwa muda gani?

Withdraw hupitia ombi na usindikaji wa operator. Ikiwa matokeo hayaonekani mara moja, angalia hali ya ombi na historia ya operesheni — hapo ndipo hali halisi inaonyeshwa. Ikiwa ombi halibadiliki kwa muda mrefu, kwa kawaida inahitaji tu muda zaidi wa usindikaji.

### 10-8. Je, ninaweza kughairi ombi la Withdraw?

Ndiyo, ikiwa ombi bado halijachakatwa. Ughairi unapatikana kwa ombi lililo pending. Baada ya kughairi, angalia salio kuu na historia ya operesheni: ikiwa fedha zilikuwa zimezuiwa, zinarejeshwa.

### 10-9. Kwa nini ombi la Withdraw linaweza “kubaki” kwenye pending?

Kwa sababu Withdraw hupitia uchakataji. Ikiwa ombi halibadiliki, angalia hali ya ombi na historia ya operesheni, kisha sasisha sehemu hiyo baadaye.

### 10-10. Ni wapi nitaona kwamba ombi limeghairiwa?

Hili linaonekana kupitia hali ya ombi na pia kupitia rekodi katika historia ya operesheni. Baada ya kughairi, angalia pia salio kuu.

### 10-11. Kwa nini kiwango cha chini cha Withdraw ni 10 EFHC?

Kwa sababu ndani ya mradi kizingiti kimewekwa na maombi chini ya hapo hayakubaliwi. Kiwango cha chini ni 10 EFHC.

Pia: ada ya Withdraw inalipwa na mradi, kwa hiyo kutoa kiasi chini ya 10 EFHC si cha maana.

### 10-12. Kwa nini withdrawal inaweza kutopatikana hata kama nina EFHC?

Kwa sababu kwa withdrawal ni balance kuu pekee inayohesabiwa. Ikiwa EFHC ziko kwenye sehemu ya bonus ya balance, huwezi kuwasilisha withdrawal kwa hizo.

### 10-13. Nifanye nini baada ya kutuma ombi la Withdraw?

Angalia hali ya ombi na historia ya operesheni — hapo unaona hali halisi ya ombi na mwendo wa fedha.

### 10-14. Uondoaji unafanywa kwa token gani na kwenye mtandao gani?

Uondoaji unafanywa tu katika token za EFHC na tu kwenye mtandao wa blockchain wa TON (The Open Network). Hakuna chaguo jingine lolote la uondoaji ndani ya mradi.

### 10-15. Inachukua muda gani operator kushughulikia withdrawal kwa mkono?

Maombi ya withdrawal hushughulikiwa na operator kwa mpangilio wa foleni hai. Kwa kawaida usindikaji huchukua kutoka dakika chache hadi saa 24 kulingana na mzigo wa mtandao na idadi ya maombi. Unaweza kila wakati kughairi ombi ambalo halijashughulikiwa, na fedha zitarudi mara moja kwenye salio lako.

## 11. Tasks

### 11-1. Kukamilisha tasks kunatoa nini?

Tasks hutoa tu bonus coins na humhamasisha mchezaji kushiriki zaidi katika maisha ya mradi.

### 11-2. Ninapataje bonasi ya task?

Unahitaji kutimiza masharti ya task. Baada ya hapo bot hukagua matokeo kiotomatiki, huhesabu task kuwa imekamilika, na huweka bonasi iliyopangwa.

### 11-3. Kwa nini task haijahesabiwa kuwa imekamilika?

Hali hii hutokea kama masharti bado hayajakamilika kikamilifu, action haijafanywa hadi mwisho, au matokeo bado hayajasasishwa kwenye mfumo.

### 11-4. Naweza kufanya task ileile tena?

Hilo linategemea aina ya task. Baadhi ya tasks ni za mara moja, na baadhi zinaweza kurudiwa kulingana na mantiki ya mradi.

### 11-5. Tasks zote zinatoa bonasi sawa?

Hapana. Kiasi cha bonasi hutegemea task husika na masharti yake. Lakini aina ya bonasi hapa ni moja — bonus coins.

### 11-6. Kwa nini tasks zinahitajika ikiwa tayari kuna panels?

Tasks ni njia ya ziada ya ukuaji. Hazibadilishi panels, bali husaidia kukusanya bonus coins ambazo baadaye zinaweza kutumika ndani ya mzunguko wa mchezo.

### 11-7. Kwa nini bonasi ya tasks haiingii kwenye main balance?

Kwa sababu tasks hutoa bonus EFHC. Hii ni bonasi ya ndani ya mzunguko wa mchezo, na huongezwa kwenye bonus balance.

### 11-8. Kwa nini tasks wakati mwingine huisha au kutoweka?

Kwa sababu tasks zinaweza kuwa za muda au kuwa na kikomo. Ikiwa task haipo, inamaanisha imekamilika au sasa haiko active.

### 11-9. Ni wapi ninaweza kuona tasks zote zinazopatikana?

Katika sehemu ya Tasks — hapo ndipo orodha ya tasks zinazopatikana na masharti yake huonyeshwa.

### 11-10. Kwa nini bonasi ya task haikuonekana mara moja?

Wakati mwingine mfumo unahitaji muda kusasisha matokeo. Angalia: sasisha Tasks → kagua bonus balance → kagua history ya operations.

### 11-11. Nimejiunga na channel inayotakiwa kwenye task, lakini task haikamiliki. Kwa nini?

Wakati mwingine uthibitishaji wa subscription huchukua muda kwa sababu ya caching kwenye upande wa server za Telegram. Ikiwa bot haikuhesabu subscription mara moja, rudi kwenye sehemu ya Tasks baada ya dakika chache na ubonyeze kitufe cha ukaguzi tena.

## 12. Referrals

### 12-1. Sehemu kwenye ukurasa wa Referrals zinaitwaje?

Kwenye ukurasa wa Referrals hutumika sehemu mbili: Active na Inactive.

### 12-2. Referral active na inactive inamaanisha nini?

Referral active ni mchezaji ambaye tayari ameanzisha angalau panel moja na amepata Activ status. Referral inactive ni yule ambaye bado hajaingia kwenye mzunguko wa mchezo na kwa sasa hatoi haki ya bonus.

### 12-3. Referral bonuses huongezwa lini?

Referral bonuses hukaguliwa na bot kiotomatiki. Mara tu mchezaji anapokuwa active, bonus huongezwa moja kwa moja.

### 12-4. Activ status inatoa nini kwa referrals?

Activ status ni muhimu kwa mantiki ya referrals, kwa sababu mradi huitumia kama sehemu ya kuchuja ushiriki halisi na kulinda dhidi ya boosting kutoka kwa bots, bot farms, na activity ya uongo.

### 12-5. Activ inaunganishwaje na referrals?

Activ huonyesha kuwa mtumiaji ni mshiriki halisi wa mradi, si bot-account. Hilo ni muhimu kwa kazi ya haki ya mfumo wa referrals na ulinzi dhidi ya bot farms.

### 12-6. Ni bonus gani ya msingi huongezwa kwa kila referral active?

Kwa kila referral wako wa moja kwa moja, bonus moja ya 0.1 EFHCb huongezwa mara moja tu — anapoactivate panel yake ya kwanza na kupata Activ.

### 12-7. Kwa nini nina referrals, lakini bonus haijaongezwa?

Bonus huongezwa tu baada ya referral wa moja kwa moja kuactivate panel yake ya kwanza. Kabla ya hapo hubaki inactive; panels zinazofuata hazitoi referral bonus nyingine.

### 12-8. 0.1 EFHCb ya referral active huenda wapi?

Zawadi ya activation ya 0.1 EFHCb kwa referral wa moja kwa moja huongezwa mara moja kwenye bonus balance. Zawadi za Lvl pia huongezwa kwenye bonus balance hiyo hiyo ya EFHCb. Mzunguko kamili ni 1,000 EFHCb kwa referrals 10,000 wa moja kwa moja walio active pamoja na 1,411 EFHCb za zawadi za Lvl, jumla 2,411 EFHCb.

### 12-9. Kwa nini mtu niliyemwalika yuko kwenye orodha, lakini hahesabiwi active?

Kwa sababu anakuwa active tu baada ya kuanzisha panel yake ya kwanza na kupata Activ. Kabla ya hapo, hubaki kwenye sehemu ya inactive ya orodha.

### 12-10. Ni wapi ninaweza kupata referral link yangu?

Katika sehemu ya Referrals — hapo ndipo referral link yako na orodha ya walioalikwa huonyeshwa.

### 12-11. Je, inaruhusiwa kuunda akaunti za ziada kwa kutumia referral link yako mwenyewe?

Ndiyo. Sheria za mradi hazikatazi hilo. Hata hivyo, kuunda akaunti tupu hakutakuletea faida. Uchumi wa mfumo umejengwa kwa namna ambayo referral bonuses na ukuaji wa ranking huongezwa tu kwa mshiriki mwenye Activ status — yaani baada ya akaunti iliyoalikwa kuingia kweli kwenye mchezo na kuanzisha angalau panel moja.

### 12-12. Je, ninaweza kubadilisha aliyenialika baada ya kujisajili?

Hapana. Uhusiano wa referral hufungwa wakati wa kuingia kwako kwa mara ya kwanza kwenye mradi kupitia referral link na hauwezi kubadilishwa baadaye.

## 13. Hub

### 13-1. Ninaweza kufanya nini katika Hub?

Hub ina vitendo viwili: Ongeza Salio na EFHC VIP NFT. Maelezo ya njia za nje huonekana baada ya kutoka Hub.

### 13-2. Hub inatumika kwa nini?

Hub ni sehemu fupi ya urambazaji kwa vitendo viwili vya nje vya mradi.

### 13-3. Ni vitendo vingapi vinavyopatikana katika Hub?

Vitendo viwili hasa: Ongeza Salio na EFHC VIP NFT. Vyote ni kazi za kanoni.

### 13-4. Kitufe cha «Ongeza Salio» kinafanya nini?

Kinafungua mwendelezo kwenye ukurasa wa Web wa nje. Bidhaa, bei na njia za malipo hazionyeshwi kabla ya kutoka Hub.

### 13-5. Top-up ya EFHC huingia kwenye salio gani baada ya uthibitisho?

Top-up ya EFHCm huwekwa kwenye salio kuu.

### 13-6. Kwa nini matokeo ya top-up yanaweza yasitokee mara moja?

Kwanza hatua ya nje ya operesheni lazima ithibitishwe, kisha matokeo husasishwa. Angalia Hub, salio kuu, na historia ya operesheni.

### 13-7. Nikikipata VIP NFT kupitia GetGems, nitaona wapi kuwa kiko hai?

Angalia hadhi ya VIP ndani ya programu na uwepo wa NFT kwenye wallet iliyounganishwa.

### 13-8. Nimekamilisha mtiririko wa nje kutoka Hub lakini hakuna matokeo. Nifanye nini?

Angalia Hub, salio kuu, na historia ya operesheni. Kama bado hakuna matokeo, operesheni bado haijaingizwa au inahitaji uchakataji wa pekee.

### 13-9. Ni salio gani hupokea top-up kupitia Top Up na Hub?

Top-up ya EFHCm huwekwa kwenye salio kuu.

### 13-10. Je, ninahitaji wallet iliyounganishwa kwa vitendo vya Hub?

Kwa vitendo vya nje vinavyotegemea wallet, unahitaji Wallet iliyounganishwa. Hub yenyewe hufunguka bila kitendo cha ndani wa ziada na hutumika kama sehemu ya mpito.

### 13-11. Ninaweza kuthibitisha wapi kwamba top-up ya EFHC imeingia kweli?

Angalia salio kuu na historia ya operesheni: alama ya top-up inapaswa kuonekana hapo.

### 13-12. Je, kuna skins kwenye Hub?

Skins si kadi za Hub.

### 13-13. Ninapataje skins za mradi?

Skins hufunguka kadri akaunti inavyopiga hatua na zimefungwa kwenye viwango 12 vya mafanikio.

## 14. Urambazaji na sheria

### 14-1. Nifungue sehemu ya “Navigation and Rules” lini?

Fungua sehemu hii unapohitaji kuelewa haraka mantiki ya skrini, kupata function inayohitajika kwenye WebApp au kufafanua kanuni za msingi za kutumia sehemu za app.

### 14-2. Ni skrini zipi ninapaswa kufungua kwanza ikiwa naingia kwenye WebApp kwa mara ya kwanza au baada ya mapumziko marefu?

Ni bora kuanza na skrini kuu, upau wa juu, na wasifu. Baada ya hapo itakuwa rahisi kwenda kwenye Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History, na Hub kulingana na kazi yako ya sasa.

### 14-3. Ninawezaje kuelewa ni sehemu gani ina kazi ninayohitaji?

Chagua sehemu kulingana na kitendo: Profile kwa akaunti, Wallet kwa pochi, Panels kwa paneli, Energy kwa uzalishaji, Exchange kwa ubadilishaji, Withdraw kwa utoaji, Tasks kwa kazi, Referrals kwa mialiko na Hub kwa mpito wa Jaza.

### 14-4. Kuingia Profile kiko wapi?

Kuingia Profile kiko sehemu ya juu ya interface kupitia kitufe cha “Profile”.

### 14-5. Kwa nini baadhi ya actions zinahitaji confirmation tofauti?

Confirmation tofauti hulinda account na kupunguza hatari ya actions za bahati mbaya katika operations muhimu.

### 14-6. Kwa nini baadhi ya actions zinapatikana mara moja huku nyingine zikitegemea hali ya account?

Baadhi ya functions hutegemea hali ya account, kuwepo kwa panel, wallet iliyounganishwa, historia ya activity au conditions nyingine za ndani za mradi.

### 14-7. Ninaelewaje tofauti kati ya Profile, Wallet na History?

Profile ni sehemu yenye data ya akaunti na sehemu za kuingia kwenye kazi zinazohusiana. Wallet ni sehemu ya kuunganisha na kukagua pochi. History ni rekodi ya operesheni na mienendo ya salio.

### 14-8. Nifanye nini ikiwa sioni kitufe au sehemu ninayohitaji?

Kwanza sasisha skrini na angalia kama sehemu nyingine imefunguliwa. Kisha rudi kwenye skrini kuu, upau wa juu au Profile, halafu nenda tena kwenye kazi hiyo kulingana na madhumuni yake.

### 14-9. Nifanye nini ikiwa data kwenye skrini inaonekana ya zamani au hailingani na matarajio?

Kwanza sasisha skrini, kisha fungua sehemu ya wasifu inayohusiana na taarifa hiyo. Salio na mienendo ni rahisi kukagua kwenye History, paneli kwenye Panels, uzalishaji kwenye Energy, shughuli za pochi kwenye Wallet, na hatua za kutoa fedha kwenye Withdraw.

### 14-10. Nitatambuaje kuwa sehemu iliyofunguliwa si sahihi?

Chagua sehemu kulingana na kitendo: Profile kwa akaunti, Wallet kwa pochi, Panels kwa paneli, Energy kwa uzalishaji, Exchange kwa ubadilishaji, Withdraw kwa utoaji, Tasks kwa kazi, Referrals kwa mialiko na Hub kwa mpito wa Jaza.

### 14-11. Mpangilio gani wa kukagua skrini ni rahisi wakati wa kuingia WebApp kila siku?

Kwa kawaida ni rahisi kuangalia kwanza skrini kuu na upau wa juu, kisha kufungua sehemu zinazohusiana na kazi ya sasa: Panels, Energy, History, Tasks, Referrals, Hub, Exchange au Withdraw. Mpangilio huu husaidia kuelewa haraka hali ya sasa ya akaunti na kwenda kwenye hatua inayohitajika.

### 14-12. Ni sehemu zipi zinafaa kukaguliwa mara kwa mara hata bila kazi ya haraka?

Ni muhimu kukagua mara kwa mara skrini kuu, upau wa juu, Panels, Energy, History, Tasks, Referrals na Hub. Hii husaidia kuona mapema mabadiliko ya salio, shughuli za paneli na hatua zinazopatikana.

### 14-13. Kwa nini ni muhimu kufanya vitendo katika sehemu yake badala ya kuvitafuta kila mahali?

Hii hupunguza makosa na vitendo vya bahati mbaya. Mtumiaji akifanya kubadilisha kwenye Exchange, kutoa fedha kwenye Withdraw, na kazi za paneli kwenye Panels, mantiki ya WebApp hubaki wazi na salama.

### 14-14. Ni dalili gani zinaonyesha kuwa kitendo ni muhimu na kinahitaji umakini?

Umakini zaidi unahitajika pale kitendo kinapoathiri salio, paneli, nishati, kubadilisha, kutoa fedha, kuunganisha pochi, historia ya operesheni au hadhi ya akaunti. Kabla ya kuthibitisha vitendo hivyo, ni vizuri kukagua tena skrini na kitufe kilichochaguliwa.

### 14-15. Nifanye nini ikiwa skrini imebadilika baada ya sasisho la bot?

Tegemea majina ya sasa ya sehemu na madhumuni yake. Vipengele vya kuona vinaweza kubadilika, lakini mantiki ya skrini lazima ibaki inaeleweka na thabiti.

### 14-16. Ni kanuni gani za msingi husaidia kuepuka makosa unapofanya kazi na WebApp?

Ni muhimu kufanya kitendo kwenye sehemu sahihi tu, kusoma kwa makini jina la skrini na kitufe kabla ya kuthibitisha, na ukiwa na shaka kukagua kwanza sehemu za wasifu badala ya kubonyeza vipengele vya kiolesura bila mpangilio.

### 14-17. Ni wakati gani nifungue FAQ wakati wa kutumia WebApp?

FAQ ni muhimu kufunguliwa unapohitaji kuelewa haraka maana ya skrini, kitufe, hatua au kanuni ya kazi fulani. Hii husaidia kulinganisha swali na sehemu sahihi na kuepuka hatua zisizo za lazima ndani ya WebApp.

## 15. Ads

### 15-1. Hii ni sehemu gani?

Sehemu ya Ads ni subsection ndani ya sehemu ya Tasks. Inaonyesha advertising actions zinazopatikana, ambazo mtumiaji anaweza kutumia kupata bonus coins za ziada.

### 15-2. Inanipa nini?

Inatoa tu bonus coins kwa views, ikiwa advertising kwa sasa inapatikana kwa akaunti ya mtumiaji.

### 15-3. Kwa nini hapa hakuna kitu?

Ikiwa sehemu iko tupu, ina maana kwa sasa hakuna offers active kwa akaunti ya mtumiaji au advertising imezimwa kwa muda.

### 15-4. Sehemu ya Ads iko wapi?

Sehemu ya Ads iko kama subsection ndani ya Tasks. Hii ni moja ya uwezo wa ziada ndani ya block ya tasks.

### 15-5. Ads hutoa bonasi ya aina gani?

Ads hutoa tu bonus coins kwa views. Hii si main balance wala direct withdraw, bali ni njia ya ziada ya ndani ya kuimarisha njia ya mchezo.

### 15-6. Kwa nini Ads ni ya manufaa?

Kwa sababu hii ni source ya ziada ya bonus coins. Haibadilishi panels na generation, lakini inaweza kusaidia kuimarisha internal game cycle kwa kasi zaidi.

### 15-7. Kwa nini wengine wana advertising, lakini mimi sina?

Kwa sababu offers zinaweza zisipatikane kwa akaunti fulani au advertising imezimwa kwa muda. Ads tupu haimaanishi kuwa akaunti imeharibika.

### 15-8. Nifanye nini ikiwa nimekamilisha action ndani ya Ads, lakini hakuna matokeo?

Angalia: sasisha Tasks/Ads → kagua bonus balance → kagua history ya operations.

### 15-9. Kwa nini ndani ya Ads kunaweza kuwa na offers tofauti kwa watumiaji tofauti?

Kwa sababu offers hutegemea upatikanaji wa advertising campaigns kwa akaunti husika. Hili ni jambo la kawaida: mtu mmoja ana offers, mwingine kwa muda hana.

### 15-10. Je, nahitaji kuanzisha kitu ili kutumia Ads?

Hapana. Ads ni njia ya kupata bonus EFHC, na haihitaji kitendo cha ndani wa lazima.

## 16. Ranks

### 16-1. Kwa nini ni muhimu kwangu kukua katika ranking?

Ukuaji katika ranking unaonyesha jinsi maendeleo yako yanavyoonekana ukilinganishwa na washiriki wengine. Hilo hukusaidia kuelewa nafasi yako ya sasa na kuona akaunti inavyoendelea kwa nguvu.

### 16-2. Level inatofautianaje na rank?

Level inaonyesha maendeleo yako binafsi ndani ya mfumo, wakati rank inaonyesha nafasi yako kati ya washiriki wengine.

### 16-3. Level na rank vinaunganishwaje?

Vinaunganishwa na mantiki moja ya ukuaji kupitia uzalishaji wa kWh kwa Panels na progress bar ya jumla kwenye ukurasa wa Energy.

### 16-4. Rank ni namba nzuri tu ya kuangalia?

Hapana. Rank husaidia kuelewa jinsi safari yako inavyoonekana ukilinganisha na washiriki wengine.

### 16-5. Ni nini kinaathiri ukuaji wa nafasi yangu katika ranking?

Ukuaji wa nafasi yako katika ranking unategemea maendeleo ya jumla ya akaunti: maendeleo ya panels, uzalishaji wa kWh na mwendo wa jumla kwenye njia ya nishati ya mradi.

### 16-6. Naweza kupanda level na rank kwa wakati mmoja?

Ndiyo. Mtumiaji anapoendeleza Panels, uzalishaji, na maendeleo ya jumla ya nishati, kwa kawaida huimarisha level yake na pia nafasi yake kwenye rank.

### 16-7. Kwa nini nina level ya juu, lakini nafasi yangu kwenye rank si ya kwanza?

Kwa sababu rank ni nafasi yako kati ya washiriki wote, si maendeleo yako binafsi pekee. Wachezaji wengine pia hukua, hivyo nafasi yako inaweza kubadilika hata ukiwa na level nzuri.

### 16-8. Kwa nini rank yangu inaweza kusogea bila mimi kufanya hatua mpya?

Kwa sababu rank haiishi peke yake; hubadilika kwa kulinganisha na washiriki wote. Wakati wewe hubadilishi chochote, watumiaji wengine wanaendelea kukua, na hilo huathiri nafasi yako.

### 16-9. Naona wapi nafasi yangu kwenye rank?

Katika sehemu ya Ranks — hapo ndiyo nafasi yako kati ya washiriki wengine huonyeshwa.

### 16-10. Kwa nini rank yangu inaweza kushuka hata kama ninaendelea kupiga hatua?

Kwa sababu rank hutegemea si ukuaji wako tu, bali pia kasi ambayo washiriki wengine wanakua. Hata kama akaunti yako inaendelea kuwa imara, nafasi yako inaweza kushuka wakati wengine wanakupita kwa kasi zaidi.

## 17. Activ-status

### 17-1. Activ status ina maana gani?

Activ ni hadhi ya kudumu ya kuwa active. Ina maana mchezo umeanza kwa kweli, kwa sababu angalau Panel moja imenunuliwa.

### 17-2. Ninawezaje kupata Activ?

Ili kupata Activ, inatosha kuanzisha Panel moja. Baada ya uanzishaji huu, hadhi hutolewa kwa msingi wa kudumu.

### 17-3. Activ ni ya muda au ya kudumu?

Activ ni hadhi ya kudumu.

### 17-4. Je, Activ inabaki ikiwa baadaye Panel inaenda kwenye Archive?

Ndiyo. Hata kama baadaye Panel itaenda kwenye Archive, Activ status hubaki.

### 17-5. Kwa nini Activ ni muhimu?

Activ husaidia kutenganisha wachezaji halisi na usajili wa bahati nasibu, bots, na mashamba ya bots. Inathibitisha ushiriki halisi wa mtumiaji ndani ya mradi.

### 17-6. Activ inaweza kutoweka baadaye?

Hapana. Activ ni hadhi ya kudumu na hubaki hata kama Panel ya kwanza baadaye itaenda kwenye Archive.

### 17-7. Kwa nini Activ inahitajika kwa ulinzi dhidi ya bots na mashamba ya bots?

Kwa sababu Activ inathibitisha ushiriki halisi, si akaunti tupu ya kuongeza namba. Hii hufanya mfumo wa Referrals na uchumi wa mradi kuwa wa haki zaidi.

### 17-8. Ni nini hubadilika kwenye akaunti baada ya kupata Activ?

Akaunti huchukuliwa kuwa imethibitishwa kama mshiriki hai wa mradi. Hii huathiri kazi ya haki ya referrals na kuaminika kwa activity.

### 17-9. Kwa nini Activ huonekana hasa baada ya Panel ya kwanza?

Kwa sababu kitendo cha ndani wa Panel ya kwanza ni ishara wazi ya ushiriki halisi. Mradi hutumia hatua hii kama kichujio dhidi ya akaunti tupu.

### 17-10. Naweza kupoteza Activ kwa sababu ya kutokuwa active?

Hapana. Activ ni hadhi ya kudumu na haitoweki kwa sababu ya kutokuwa active.

## 18. VIP NFT

### 18-1. EFHC VIP NFT ni nini?

EFHC VIP NFT ni kadi ya klabu, ufunguo wa ecosystem ya baadaye ya EFHC, alama ya kidijitali ya kuwa sehemu ya mradi, na ufunguo wa fursa za baadaye.

### 18-2. Kumiliki EFHC VIP NFT moja kunanipa nini?

Kumiliki EFHC VIP NFT moja kunatoa uzalishaji ulioongezwa kwa Panels zote za mchezaji.

### 18-3. Ni kwa dalili gani inaweza kuonekana kuwa VIP tayari imezingatiwa?

Ikiwa VIP NFT tayari imezingatiwa na mfumo, interface inaonyesha status ya VIP na faida zinazohusiana na akaunti zinaanza kuonekana.

### 18-4. Nitaona wapi athari ya VIP?

Athari ya VIP inaonekana katika sehemu ambako mradi huzingatia faida za VIP NFT, pamoja na paneli ya juu na sehemu ya Wasifu / Mipangilio.

### 18-5. Nahitaji kuwasha VIP kwa mkono?

Hapana. Mantiki ya mradi imeundwa kwa ukaguzi wa kiotomatiki wa Wallet na usasishaji wa kiotomatiki wa VIP status baada ya NFT kugunduliwa kwenye collection inayotakiwa.

### 18-6. Je, VIP NFT 2 au 3 zinatoa faida za ziada kwa mchezaji?

Hapana. Kwa mchezaji, kuwa na VIP NFT 2 au 3 hakutoi faida za ziada zaidi ya VIP NFT moja.

### 18-7. Kwa nini VIP NFT ya pili haiongezi athari?

Ndani ya mradi, VIP hutoa boost ya uzalishaji kama hadhi moja active. VIP NFT za ziada hazitoi boost ya ziada ili athari isikue bila kikomo.

### 18-8. VIP huathiri Panel moja au zote?

VIP huathiri uzalishaji wa Panels zote za mtumiaji, si Panel moja pekee.

### 18-9. Ninawezaje kukagua kwamba VIP kweli inaathiri akaunti?

Angalia si uwepo wa status ya VIP pekee, bali pia faida zinazohusiana katika mechanics za akaunti, hasa pale ambapo athari ya VIP inazingatiwa, ikiwa ni pamoja na generation.

### 18-10. Je, Wallet iliyounganishwa inahitajika ili bot iweze kuona VIP NFT yangu?

Ndiyo. Ili bot iweze kuona VIP NFT, inahitaji kujua Wallet gani ni ya akaunti hiyo. Kwa hiyo Wallet lazima iunganishwe, kisha unaangalia VIP status kwenye interface.

### 18-11. Je, ninaweza kuitumia VIP NFT yangu jinsi ninavyotaka?

Ndiyo. EFHC VIP NFT inaweza kuhamishwa, kutolewa kama zawadi na kuuzwa kwenye marketplace.

### 18-12. Nikiiuza au kuihamisha VIP NFT yangu kwenda wallet nyingine, generation yangu itakuwaje?

Bot huchanganua blockchain mara kwa mara na kukagua uwepo wa NFT kwenye wallet yako iliyounganishwa. Ukiuza, ukitoa au ukihamisha VIP NFT yako kwenda anwani nyingine, mfumo utagundua hilo, utazima VIP status yako, na generation ya panel zako zote itarudi kiotomatiki kwenye kiwango cha msingi.

## 19. Levels

### 19-1. Kwa nini ninapaswa kuongeza level yangu?

Ukuaji wa level unaonyesha maendeleo ya mtumiaji ndani ya mradi na husaidia kuona jinsi akaunti inavyokua. Hii ni ishara ya kuona na ya maana ya kusonga mbele.

### 19-2. Sehemu ya Levels inajumuisha nini?

Sehemu ya Levels inaonyesha mizani yote ya ukuaji wa mradi: levels 12 za maendeleo ya nishati, levels 6 za mfumo wa referrals, na mistari mingine ya levels ya mradi ikiwa itaongezwa.

### 19-3. Kuna levels ngapi za maendeleo ya nishati ndani ya mradi?

Ndani ya mradi kuna levels 12 za maendeleo ya nishati.

### 19-4. Kuna levels ngapi katika mfumo wa referrals?

Ndani ya mradi kuna levels 6 za mfumo wa referrals: kutoka 0 hadi 5.

### 19-5. Levels zina faida gani kwa mchezaji wa kawaida?

Levels husaidia kuelewa uko wapi sasa, ni kiasi gani tayari kimefanywa, ni wapi unapaswa kusonga baadaye, na mpaka gani unaofuata mbele yako.

### 19-6. Levels za nishati, referral levels, na ukuaji wa jumla wa akaunti vinaunganishwaje?

Hizi ni sehemu za njia moja ya pamoja. Uzalishaji wa nishati unasukuma maendeleo makuu, referrals active zinaimarisha mstari wa referrals, na kwa pamoja zinaonyesha jinsi akaunti inavyokua kwa nguvu.

### 19-7. Eco Initiate (0 kWh)

**Maana kwa mchezaji:** Panel yako ya kwanza imewekwa na iko tayari kufanya kazi. Unachukua hatua kuu kuelekea kuwa mzalishaji huru wa nishati safi. Hii ni hadhi yako ya kuanzia — umeingia tu kwenye njia ya ukuaji wa nishati.

### 19-8. Hope Bringer (100 kWh)

**Maana kwa mchezaji:** Kilowati za kwanza tayari zimeanza! Panels zako zinazalisha nishati ya kijani kwa mafanikio, zikileta tumaini la mustakabali usio na kaboni. Tayari unaona matokeo ya kwanza halisi: nishati imeanza na maendeleo yanakwenda mbele.

### 19-9. Energy Seeker (300 kWh)

**Maana kwa mchezaji:** Mfumo unafanya kazi vizuri, ukiendelea kulijaza mtandao kwa umeme safi wa kiikolojia. Kila kitengo cha nishati kinachozalishwa na Panels kinapunguza utegemezi wa mafuta ya visukuku. Akaunti yako imeingia kwenye hali ya ukuaji thabiti.

### 19-10. Nature's Voice (600 kWh)

**Maana kwa mchezaji:** Mchango wako unaanza kuonekana. Kwa kuzalisha nishati kupitia teknolojia za kijani, unakuwa sauti ya asili na kuonyesha kuwa maendeleo yanaweza kuwa ya kirafiki kwa mazingira. Mchango wako sasa unaonekana wazi zaidi.

### 19-11. Earth Ally (1000 kWh)

**Maana kwa mchezaji:** MWh yako ya kwanza imezalishwa! Panels zako zimezalisha kiasi kikubwa cha nishati safi. Sasa wewe ni mshiriki muhimu wa mabadiliko ya kijani na mshirika wa kweli wa sayari. Umevuka mpaka muhimu: 1000 kWh.

### 19-12. Climate Fighter (2000 kWh)

**Maana kwa mchezaji:** Uzalishaji wako sasa unaathiri kweli mapambano dhidi ya mabadiliko ya tabianchi. Kila kilowati inayozalishwa inapunguza moja kwa moja hitaji la kuchoma makaa ya mawe na gesi. Tayari unasukuma ukuaji kwa utaratibu, na maendeleo yako yanaonekana kwa uwazi.

### 19-13. Green Sentinel (3500 kWh)

**Maana kwa mchezaji:** Mtiririko thabiti wa nishati kutoka Panels zako unasimama kulinda hewa safi. Unaleta faida inayoonekana kwa jamii bila kuacha alama ya kaboni. Akaunti yako inakuwa “mlinzi” wa nafasi ya kijani.

### 19-14. Planet Defender (5000 kWh)

**Maana kwa mchezaji:** 5000 kWh za uzalishaji safi! Uwezo wa Panels zako unafanya kazi kama ngao isiyoonekana, ukilinda anga dhidi ya maelfu ya kilo za uzalishaji wa gesi za chafu. 5000 kWh ni ishara kubwa ya kiwango: tayari uko kwenye hatua kubwa.

### 19-15. Eco Champion (7500 kWh)

**Maana kwa mchezaji:** Kiasi bora sana cha uzalishaji! Wewe ni bingwa wa kweli wa nishati ya kijani, na mchango wako unaathiri kwa namna inayoonekana mizani ya nishati ya dunia kuelekea bora. Hii ni level ya wale wanaoshikilia kasi kwa uthabiti.

### 19-16. Planet Saver (10000 kWh)

**Maana kwa mchezaji:** MWh 10! Umezalisha nishati safi kiasi kwamba kwa kweli unaokoa ecosystems nzima, ukithibitisha ufanisi wa juu wa Panels zako. 10 000 kWh tayari ni “hatua ya kumi elfu” — kiwango kikubwa sana cha maendeleo.

### 19-17. Green Commander (15000 kWh)

**Maana kwa mchezaji:** Kiongozi wa uzalishaji wa kiikolojia. Panels zako zinaipa mustakabali nguvu, na kiwango chako kikubwa cha uzalishaji kinaweka viwango vipya vya juu kwa jamii nzima. Uko karibu na kilele: hii ni level ya nguvu na uthabiti.

### 19-18. Guardian of Earth (20000+ kWh)

**Maana kwa mchezaji:** Kilele cha maendeleo. Kwa kuzalisha zaidi ya 20 MWh za energy safi kabisa, umekuwa Guardian of Earth wa kweli. Panels zako huchukua nguvu kutoka kwa asili yenyewe ili kuipa dunia hii nguvu na kuihifadhi kwa vizazi vijavyo. Hiki ni kilele cha ngazi: umefikia level ya juu zaidi inayotambuliwa ya progress.

**Rule halisi:** Level ya Guardian of Earth inalingana na 20000+ kWh.

**Athari ya vitendo:** Kwa vitendo, umehakikisha status ya juu zaidi. Kuanzia hapa, focus ni kudumisha system, kuongeza panels na kuimarisha participation kwenye ecosystem kupitia panels, VIP na referral growth.

### 19-19. Kiwango cha referral 0

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 0 EFHCb. Level hii ni hatua ya kuingia.

### 19-20. Kiwango cha referral 1

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 1 EFHCb. Hii ni hatua ya kwanza ya ukuaji wa referral.

### 19-21. Kiwango cha referral 2

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 10 EFHCb. Hapa mfumo wa referrals tayari unaanza kuonekana kwa nguvu.

### 19-22. Kiwango cha referral 3

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 100 EFHCb. Hii ni hatua ya ukuaji mkubwa wa referral.

### 19-23. Kiwango cha referral 4

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 300 EFHCb. Hii tayari ni matokeo makubwa kwa mstari wa referrals.

### 19-24. Kiwango cha referral 5

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 1000 EFHCb. Hii ni kiwango cha juu zaidi cha mfumo wa referrals katika usanidi wa sasa.

### 19-25. Ninawezaje kuelewa level progress bila makosa?

**Maana kwa mchezaji:** Block hii husaidia kutathmini progress kwa uhalisia na kuangalia levels kupitia energy generation halisi.

**Rule halisi:** Levels huamuliwa na generation iliyokusanywa kwa kWh. Kadiri total generation inavyokuwa kubwa, ndivyo level yako inavyokuwa juu.

**Athari ya vitendo:** Kwa vitendo, zingatia growth ya energy, idadi ya active panels na overall generation pace. Hivi ndivyo vinavyotoa level progress ya kweli.

### 19-26. Kwa nini majina ya levels yanahusiana na ikolojia na sayari?

Kwa sababu wazo kuu la mchezo linahusiana na green energy ya kidijitali, motisha ya watu, na mchango wa mfano katika kuponya sayari ya Dunia.

## 20. FAQ / Msaada

### 20-1. Ni wapi ninaweza kufungua FAQ?

FAQ hufunguliwa kutoka kwenye Wasifu kama sehemu ya msaada iliyojengwa ndani ya bot, ambapo majibu ya vitendo vya msingi, skrini, na sheria za mradi yamekusanywa.

### 20-2. FAQ / Msaada inahitajika kwa nini?

Sehemu hii inahitajika ili mtumiaji apate haraka majibu yanayoeleweka, namba sahihi, sheria halisi za mradi, na maana ya vitendo vya msingi bila kubahatisha wala kuchanganyikiwa.

### 20-3. Kwa nini FAQ imeandikwa kwa undani sana?

Kwa sababu mradi ni wa tabaka nyingi, na maelezo mafupi makavu hayatoshi kwa maswali halisi ya mchezaji. Hapa maana, uelewekevu, namba sahihi, na matokeo halisi ya vitendo ni muhimu.

### 20-4. Je, FAQ inaweza kunisaidia kuelewa njia yote ya mchezaji ndani ya bot?

Ndiyo. FAQ nzuri haipaswi kueleza vitufe vya pekee tu, bali safari yote: kutoka Panel ya kwanza hadi nishati, Exchange, mizani, levels, hadhi, na ukuaji wa akaunti.

### 20-5. Nifanye nini ikiwa sikupata jibu mara ya kwanza?

Ni bora kufungua sehemu iliyo karibu kwa maana na kuangalia maswali ya jirani. Ndani ya bot kubwa, majibu mengi yanaunganishwa, na block moja mara nyingi husaidia kuelewa inayofuata.

### 20-6. Nitumieje FAQ kwa usahihi?

Ni bora kwenda section kwa section: kwanza elewa logic ya jumla ya mradi, kisha screens na actions zako, halafu ndipo uangalie rules maalum za balances, withdrawals, VIP, referrals, levels na functions nyingine za bot.

### 20-7. Nikague nini ikiwa “kila kitu kinaonekana kimevunjika”?

Kagua vitu vitatu: 1) Wallet — je, imeunganishwa na main wallet imechaguliwa, 2) mizani na history — je, kuna alama ya operation yako humo, 3) sehemu unayohitaji (Panels / Energy / Exchange / Withdraw). Kwa kawaida jibu hupatikana katika moja ya sehemu hizi.

### 20-8. Njia ya haraka zaidi ya kuelewa kilichotokea kwa EFHC zangu ni ipi?

Fungua history ya balance. History huonyesha ni nini hasa kilibadilisha mizani: bonus accrual, internal action, exchange, au withdraw.

### 20-9. Nianzie wapi ikiwa nimefungua bot kwa mara ya kwanza na sielewi chochote?

Anza na Energy (skrini kuu), kisha fungua Panels, angalia mizani na history, halafu ndiyo uamue kama unahitaji Wallet na top up.

### 20-10. Ni njia gani ya haraka zaidi ya kupata swali ninachohitaji ndani ya FAQ?

Njia ya haraka zaidi ni kufungua sehemu inayohusiana na mada (Wallet / Panels / Exchange / Withdraw n.k.) na kutafuta swali humo. Usipokuwa na uhakika, anza na sehemu ya FAQ / Msaada na ujielekeze kwa maneno muhimu.
