# EFHC FAQ (SW) — SSOT

Structure: 20 sections, 2 levels (section -> questions/answers).

## 1. Kuhusu Mradi

### 1-1. EFHC ni nini?

EFHC ni mradi wa mchezo kuhusu nishati, maendeleo, na ukuaji wa akaunti ndani ya bot. Mtumiaji hununua Panels, hukusanya nishati, huibadilisha kuwa EFHC, hufuatilia salio, hupanda viwango, husogea kwenye rank, na hutumia vipengele vya ziada vya mradi.

Maana ya vifupisho:
— EFHC — Energy for Humanity Coin
— EFHCm — sarafu kuu
— EFHCb — sarafu za bonasi
— EFHCj — jetton ya nje ya EFHC
— EFHC — salio la jumla (bonasi + kuu)

### 1-2. Kila kitu kinafanyaje kazi hapa?

Ndani ya mradi huu, kila kitu kinajengwa juu ya nishati na ukuaji wa akaunti. Mtumiaji hufanya kazi na Panels, hukusanya nishati, huibadilisha kuwa EFHC kuu, hufuatilia salio, huunganisha Wallet, huimarisha maendeleo yake, na hutumia mifumo ya ziada ya mradi.

### 1-3. Nifanye nini ndani ya bot hii?

Lengo kuu ni kukuza akaunti yako. Kwa hilo, mtumiaji hufanya kazi na Panels, hufuatilia uzalishaji wa nishati, hutumia Exchange, huangalia salio zake, huunganisha Wallet, hushiriki katika mifumo ya ziada ya mradi, na hatua kwa hatua huimarisha maendeleo yake.

### 1-4. Ninawezaje kukua na kusonga mbele hapa?

Ukuaji ndani ya bot unajengwa juu ya nishati na shughuli. Kadiri mtumiaji anavyokuwa na Panels nyingi zaidi, nishati zaidi, vitendo vya manufaa, na maendeleo zaidi, ndivyo akaunti yake inavyokua kuwa imara zaidi na kupanda juu zaidi ndani ya mfumo wa levels na rank.

### 1-5. Maana kuu ya mradi huu ni ipi?

Maana kuu ya mradi huu ni kuonyesha njia kutoka kuanzisha Panel hadi kuzalisha nishati, kisha kufikia matokeo katika EFHC. Mtumiaji haoni tu namba za kubahatisha, bali njia iliyounganishwa: Panel, nishati, Exchange, salio, maendeleo, levels, na nafasi kati ya washiriki wengine.

### 1-6. Je, huu ni mchezo wa burudani tu au kuna mantiki ya maendeleo?

Hapa kuna mantiki kamili ya ukuaji. Mtumiaji habofyi tu vitufe, bali hatua kwa hatua huimarisha akaunti yake: hununua Panels, huanza uzalishaji, hupata Activ status, hukusanya reward, huendeleza mfumo wa Referrals, na huona matokeo ya safari yake.

### 1-7. EFHC zangu za kwanza zinatoka wapi?

EFHC za kwanza hutoka kwenye vyanzo viwili vikuu: reward (kwenda kwenye sarafu za bonasi EFHCb) na kubadilisha nishati kupitia Exchange (kwenda kwenye sarafu kuu EFHCm). Njia yenye nguvu zaidi ni Panels → nishati → Exchange → salio kuu.

### 1-8. Nishati yangu inatoka wapi?

Nishati hutolewa na Panels zako zilizo active. Wakati Panels ziko active, huzalisha nishati, na nishati hiyo hukusanyika kama nishati inayopatikana kwa Exchange.

### 1-9. Ni nini kinaathiri zaidi ukuaji wangu ndani ya mradi?

Kitu kinachoathiri zaidi ukuaji ni idadi ya Panels active na uzalishaji wao wa jumla. Kichocheo cha pili ni VIP NFT (ikiwa unayo), kwa sababu inaathiri uzalishaji. Tasks, Ads, na Referrals ni nyongeza ya manufaa, lakini si msingi mkuu.

### 1-10. Ninawezaje kujua kwamba nasonga kwa njia sahihi?

Kama vitu vitatu vinaongezeka — uzalishaji, nishati inayopatikana, na salio kuu baada ya Exchange — basi unasonga kwa njia sahihi. Njia ya haraka ya kukagua hili ni kupitia Energy na historia ya shughuli.

## 2. Skrini Kuu

### 2-1. Skrini kuu inaonyesha nini?

Skrini kuu ni ukurasa wa Energy. Huu hukusanya vipengele muhimu vya hali ya sasa ya akaunti: vitendo vya haraka, taarifa kuhusu maendeleo, na sehemu za kuingia kwenye maeneo muhimu ya bot.

### 2-2. Kwa nini skrini kuu ni muhimu?

Inahitajika ili mtumiaji aweze kuona mara moja mambo muhimu kuhusu akaunti yake na kuelewa kwa haraka hali ya sasa, maendeleo, na kile kinachoweza kufanywa kinachofuata.

### 2-3. Niangalie nini kwanza?

Kwanza inafaa kuangalia paneli ya juu, salio la jumla, skrini ya Energy, na vitendo vinavyopatikana. Hivi ndivyo vinavyoonyesha kwa kasi zaidi hali ya sasa ya akaunti na kile kinachoweza kufanywa baadaye.

### 2-4. Maendeleo yangu ya sasa yanaonekana wapi?

Maendeleo ya sasa yanaonyeshwa katika sehemu zinazohusiana na nishati, Panels, levels, na rank za bot. Humo ndipo unaona jinsi mtumiaji anavyosonga mbele ndani ya mradi.

### 2-5. Kwa nini skrini kuu ni muhimu kila siku?

Kwa sababu hapa ndipo unaona kwa haraka zaidi jinsi akaunti imebadilika: kuna nishati kiasi gani sasa, kuna Panels ngapi active, maendeleo yanakua vipi, na ni hatua gani inayofuata ambayo mtumiaji tayari yuko tayari kuichukua.

### 2-6. Ni wapi ni bora kuanza?

Kwanza angalia paneli ya juu, elewa salio zako ni zipi, fungua ukurasa wa Energy, angalia sehemu ya Panels, kisha soma FAQ kuhusu vitendo vya msingi. Ikiwa hatua unayotaka kufanya inahitaji Wallet, hatua inayofuata itakuwa kuiunganisha.

### 2-7. Ni vitufe gani vya skrini kuu ni muhimu zaidi?

Vilivyo muhimu zaidi ni vile vinavyopeleka kwenye vitendo vya msingi: Panels na Exchange, pamoja na vitufe vya haraka vya upau wa juu — Top Up na Hub — ikiwa unataka kufungua vitendo vinavyohusiana na EFHC na VIP.

### 2-8. Ninapaswa kukagua nini kwenye skrini kuu kila siku?

Vitu vitatu: 1) kuna Panels ngapi active, 2) kasi ya uzalishaji ni ipi, 3) ni kiasi gani cha nishati inayopatikana tayari kimekusanyika kwa ajili ya Exchange.

### 2-9. Kwa nini skrini kuu hubadilika kadiri muda unavyopita?

Kwa sababu inaakisi hali hai ya akaunti. Panels, nishati, na shughuli zinapoonekana, skrini huacha kuwa tupu na huanza kuonyesha data zaidi ya manufaa pamoja na maendeleo.

### 2-10. Ninawezaje kuelewa kutoka kwenye skrini kuu kwamba akaunti inakua?

Unapoona ukuaji kwa mambo ya kweli: uzalishaji si sifuri, nishati inakusanyika, na baada ya Exchange salio kuu linaongezeka. Hizi ndizo ishara za uaminifu zaidi za maendeleo.

## 3. Paneli ya Juu

### 3-1. Paneli ya juu ni nini?

Paneli ya juu ni kipengele tofauti cha kiolesura na kizuizi kikuu cha taarifa za haraka kinachopatikana kwenye kurasa kuu za bot.

### 3-2. Ni nini huonyeshwa kwenye upau wa juu?

Kwenye upau wa juu huonyeshwa avatar, jina, kiwango cha maendeleo ya nishati, hadhi ya VIP, salio la jumla, kitufe cha Top Up, na kitufe cha Hub.

### 3-3. Kwa nini paneli ya juu ni muhimu?

Kwa sababu hukusaidia kuona mara moja mambo muhimu kuhusu akaunti yako bila kupitia sehemu nyingi zisizohitajika: wewe ni nani, maendeleo yako yako wapi, kama una VIP, una sarafu ngapi kwa jumla, na ni vitendo gani vya haraka vinapatikana sasa hivi.

### 3-4. Salio la jumla kwenye paneli ya juu linaonyesha nini?

Salio la jumla linaonyesha jumla ya sarafu zote ulizonazo. Hii ni rahisi kwa sababu huhitaji kujumlisha rasilimali mwenyewe ili kuelewa uwezo wako wa kununua na hali ya akaunti kwenye mchezo.

### 3-5. Kwa nini salio la jumla ni rahisi kwa ununuzi?

Kwa sababu linaonyesha uwezo wa jumla wa kununua wa mchezaji ndani ya mchezo na hukusaidia kuelewa haraka kama rasilimali zinatosha kwa vitendo vya ndani.

### 3-6. Kwa nini salio la jumla halilingani na kiasi ninachoweza kutoa sasa hivi?

Kwa sababu salio la jumla linajumuisha sarafu kuu na sarafu za bonasi. Sarafu za bonasi zinahitajika kwa michakato ya mchezo na hazitolewi moja kwa moja.

### 3-7. Ni wakati gani nifae kutumia kitufe cha “Top up” kwenye paneli ya juu?

Kitumie unapohitaji kwenda haraka kwenye mchakato wa kuongeza salio kuu uliopo ndani ya programu bila kufungua sehemu nyingine kwa mkono.

### 3-8. Kwa nini kufungua Hub kutoka kwenye upau wa juu?

Ili kufungua haraka kadi za vitendo vinavyohusiana na mradi na kwenda kwenye mtiririko wa nje unaohitajika bila urambazaji wa ziada kwenye kiolesura.

### 3-9. Kwa nini paneli ya juu inaonekana kwenye kurasa tofauti?

Kwa sababu hii ni kama “dashibodi” ya akaunti: inahitajika ili kila mara uone mambo ya msingi — salio, hadhi, na vitendo vya haraka — hata ukiwa umefungua sehemu nyingine.

### 3-10. Nifanye nini kama data kwenye paneli ya juu inaonekana si sahihi?

Kwanza sasisha ukurasa na uangalie historia ya salio: hapo ndipo ukweli wa miamala unaonekana. Ikiwa historia na salio vinafanana, basi data iko sahihi; huenda ulikuwa unaangalia salio tofauti, kwa mfano la jumla badala ya salio kuu.

## 4. Wasifu / Mipangilio

### 4-1. Sehemu ya Wasifu / Mipangilio ni nini?

Wasifu / Mipangilio ni sehemu ambako usimamizi wa wasifu na vigezo vya bot unafanyika. Hapa ndipo hadhi kuu zinaonekana na mipangilio ya kibinafsi ya kiolesura inapatikana.

### 4-2. Ninaweza kufanya nini ndani ya wasifu?

Ndani ya wasifu kuna mipangilio ya msingi ya mtumiaji na njia za haraka za kwenda kwenye sehemu muhimu: Wallet, historia ya salio, FAQ, na maeneo mengine muhimu ya usimamizi.

### 4-3. Ni nini kinaonyeshwa kwenye sehemu ya juu ya Wasifu / Mipangilio?

Sehemu ya juu ya Wasifu / Mipangilio inaonyesha avatar, jina la Telegram, na hadhi za Activ na VIP ikiwa tayari zipo.

### 4-4. Ninaweza kubadilisha lugha wapi?

Lugha hubadilishwa ndani ya Wasifu / Mipangilio.

### 4-5. Kwa nini wasifu unahitajika kwa ujumla?

Wasifu ni kituo cha binafsi cha kusimamia akaunti. Hapa mtumiaji haoni tu hadhi zake, bali pia hufungua sehemu muhimu zinazohusiana na Wallet, historia, lugha, na msaada.

### 4-6. Historia ya salio inafunguliwa wapi ndani ya wasifu?

Ndani ya sehemu ya Wasifu / Mipangilio kuna ingizo maalum la historia ya salio, ambako mapato na matumizi yanaonekana.

### 4-7. Lugha inabadilishwa wapi ndani ya wasifu?

Mabadiliko ya lugha yako ndani ya Wasifu / Mipangilio, kwa sababu huu ni mpangilio wa kibinafsi wa akaunti.

### 4-8. Ni wapi katika Profile nifungue Wallet kwa ajili ya kufanya kazi na wallet?

Katika sehemu ya Profile kuna kipengele tofauti cha Wallet. Kifungue unapohitaji kuunganisha wallet, kuangalia binding au kwenda kwenye hatua zinazohusiana na wallet.

### 4-9. Ni wapi katika Profile nifungue FAQ haraka nikihitaji jibu?

Katika sehemu ya Profile kuna njia ya kuingia kwenye FAQ. Ifungue unapohitaji jibu la haraka kuhusu interface, balance, panels, energy, exchange, withdrawal au kazi nyingine za WebApp.

### 4-10. Ni nini kilichomo kwenye sehemu ya “Msaada na Taarifa”?

Humo hukusanywa vipengele vya msaada: FAQ, vidokezo/taarifa, na kila kitu kinachomsaidia mtumiaji kuelewa mradi bila kuchanganyikiwa.

### 4-11. Kiolesura cha mradi kinapatikana kwa lugha ngapi?

Kiolesura cha bot na mfumo wa msaada (FAQ) vimetafsiriwa katika lugha 13. Unaweza kuchagua lugha inayokufaa katika mipangilio ya wasifu, na mfumo utabadilisha mara moja maandishi yote na kiolesura kulingana na chaguo lako.

## 5. Wallet

### 5-1. Why is the main wallet needed?

The main wallet is used for actions related to the project’s external operations: withdrawals, deposits, proof of address ownership, and other linked actions where a connected wallet is required.

### 5-2. Inawezekana kubadilisha Wallet kuu?

Ndiyo. Mtumiaji anaweza kuchagua Wallet nyingine kuu kutoka kwenye wallets ambazo tayari zimeunganishwa.

### 5-3. Inawezekana kufuta Wallet iliyounganishwa?

Ndiyo. Ikiwa Wallet haitumiki tena, uunganisho wake unaweza kuondolewa.

### 5-4. What else is the wallet needed for besides withdrawals?

The wallet is needed not only for withdrawals. It is also used for deposits, address confirmation in related external project actions, and operations that require a connected wallet.

### 5-5. Nini kitatokea nikibonyeza kitendo ambacho kinahitaji Wallet lakini sina Wallet?

Ikiwa kazi uliyochagua inahitaji Wallet, bot kwanza itazindua mantiki ya kuunganisha Wallet. Baada ya hapo utaweza kurudi kwenye kitendo hicho na kukikamilisha kawaida.

### 5-6. Naweza kuunganisha Wallet nyingi, na kwa nini hilo linahitajika?

Ndiyo. Unaweza kuunganisha Wallet nyingi ili uwe na anwani ya akiba au kutenganisha matumizi tofauti. Hata hivyo, Wallet moja huchaguliwa kuwa kuu — ndiyo inayotumiwa kwa chaguo-msingi katika shughuli zinazohitaji anwani iliyochaguliwa.

### 5-7. Nini kitatokea nikibadilisha Wallet kuu?

Utaweza kuchagua Wallet nyingine kama kuu. Baada ya kubadilisha, mfumo utaanza kutumia anwani mpya ya msingi kwa shughuli zinazohitaji hilo. Kabla ya Withdraw au ununuzi, ni vizuri kuthibitisha mara moja ni Wallet gani iliyowekwa kama kuu kwa sasa.

### 5-8. Inawezekana kutoa kwenda kwenye Wallet ambayo si kuu?

Kwa chaguo-msingi mfumo hutegemea Wallet kuu. Ikiwa unahitaji anwani nyingine, kwanza iweke kama Wallet kuu ndani ya Wallet, kisha ndipo utume ombi la Withdraw.

### 5-9. Nifanye nini kama Wallet imeunganishwa lakini Withdraw bado haipatikani?

Angalia mambo matatu: je, Wallet kuu imechaguliwa, je, salio kuu linatosha, na je, kiasi cha Withdraw hakipo chini ya 10 EFHC.

### 5-10. Inawezekana kucheza na kuendelea kukua ikiwa Wallet bado haijaunganishwa?

Ndiyo. Wallet inahitajika kwa baadhi ya shughuli, kwa mfano Withdraw, lakini unaweza kukuza akaunti, kuelewa kiolesura, na kukusanya maendeleo hata bila kuiunganisha bado.

### 5-11. Nifanye nini ikiwa nimepoteza ufikiaji wa wallet yangu kuu ya TON?

Kwa kuwa mradi unaruhusu kuunganisha wallet zaidi ya moja, unaweza kuunganisha wallet mpya katika sehemu ya Wallet, kuiweka kuwa wallet kuu, na kuondoa kabisa anwani ya zamani iliyohatarishwa kutoka kwenye orodha ya wallet zilizounganishwa.

## 6. Mizani na Historia

### 6-1. Kwa nini nina mizani mitatu tofauti?

Kwa sababu ndani ya bot fedha zina majukumu tofauti. Salio la jumla linaonyesha kila kitu pamoja, salio la bonasi linahitajika kwa mzunguko wa ndani wa mchezo, na salio kuu linaonyesha matokeo ambayo tayari yanaweza kutumika kwa hatua muhimu, ikiwemo Withdraw.

### 6-2. What is the bonus balance?

The bonus balance is an internal game balance. It is used for development inside the bot, is credited for tasks, referrals, gifts, and other internal project mechanics, but is not withdrawn directly.

### 6-3. Salio kuu ni nini?

Salio kuu ni EFHC kuu. Hapa ndipo matokeo ya mzunguko wa mchezo hubadilika kuwa sarafu halisi za ndani ya mfumo, na kutoka hapa ndiko shughuli kuu, pamoja na Withdraw, zinapatikana.

### 6-4. Kwa nini ununuzi mmoja unaweza kugusa salio la bonasi na salio kuu kwa wakati mmoja?

Katika matumizi yote ya ndani ya mradi, fedha hukatwa kwanza kutoka kwenye salio la bonus. Ikiwa hilo halitoshi, kiasi kilichobaki hukatwa kutoka kwenye salio kuu.

### 6-5. Kwa nini kwenye historia kuna rekodi kadhaa mara moja?

Operesheni moja inaweza kugusa sehemu kadhaa za mtiririko wa fedha, kwa hiyo bot huiweka kwa mistari kadhaa ili kuonyesha kila mabadiliko kivyake.

### 6-6. Ni wapi naweza kuona EFHC zimeingia wapi au zimetoka wapi?

Kwa hili unahitaji sehemu ya historia ya salio. Inaonyesha mapato, matumizi, Exchange, ununuzi, Withdraw, na mabadiliko mengine ya fedha.

### 6-7. Kwa nini salio la jumla linaweza kuwa kubwa, lakini kiasi ninachoweza kutoa ni kidogo?

Kwa sababu salio la jumla hujumlisha salio kuu na la bonasi. Withdraw inaruhusiwa tu kutoka kwenye salio kuu, na salio la bonasi limekusudiwa kwa mzunguko wa ndani wa mradi. Ndiyo maana kwa Withdraw unapaswa kuangalia hasa salio kuu.

### 6-8. Ni wapi naweza kuona kwa haraka zaidi ni nini hasa kilibadilisha salio langu?

Katika historia ya salio. Hapo unaona ni operesheni gani ilileta mapato au matumizi, na ni salio gani lililoguswa.

### 6-9. Kwa nini salio la bonasi haliwezi kutolewa moja kwa moja?

Kwa sababu sarafu za bonasi ni sehemu ya mzunguko wa ndani wa mradi. Withdraw inaruhusiwa tu kutoka kwenye salio kuu.

### 6-10. Kwa nini baada ya Withdraw au Exchange historia haibadiliki mara moja sawasawa kila mahali?

Kwa sababu skrini tofauti hazisasishwi kila wakati kwa wakati mmoja. Kagua hivi: sasisha sehemu → angalia salio → angalia historia.

### 6-11. Nini kitatokea ikiwa, kwa intaneti dhaifu, nitabonyeza kwa bahati mbaya kitufe cha kununua au exchange mara kadhaa mfululizo? Je, sarafu za ziada zitakatwa?

Hapana. Sarafu za ziada hazitakatwa. Kiini cha mfumo kina ulinzi mkali dhidi ya ukataji wa mara mbili. Hata ukibonyeza kitufe mara 10 kwa sababu mtandao umekwama, operesheni itatekelezwa mara moja tu.

## 7. Panels

### 7-1. Ni EFHC ngapi zinahitajika kuanzisha Panel moja?

EFHC 100 zinahitajika kuanzisha Panel moja.

### 7-2. Kuanzisha Panel ya kwanza kunatoa nini mara moja?

Kuanzisha Panel ya kwanza huanza uzalishaji wa nishati mara moja, hufungua njia ya maendeleo, huunda njia ya kupata EFHC kuu, na hukupa Activ status ya kudumu.

### 7-3. Uzalishaji wa Panel huanza lini?

Uzalishaji huanza mara moja baada ya kuanzisha Panel.

### 7-4. Muda wa maisha wa Panel ni upi?

Kila Panel ina mzunguko wa siku 180.

### 7-5. Nini hutokea kwa Panel baada ya mzunguko wa siku 180 kumalizika?

Baada ya mzunguko wa siku 180 kumalizika, Panel inazimwa na kuhamia Archive kama kumbukumbu ya maendeleo ya nishati ya mshiriki.

### 7-6. Ni hali zipi mbili za Panels zipo kwenye kiolesura?

Kwenye kiolesura kuna Activ na Archive. Activ ni Panels zinazoshiriki katika uzalishaji. Archive ni Panels ambazo tayari zimemaliza mzunguko wao wa active na huhifadhi historia ya safari yako.

### 7-7. Je, ninaweza kuanzisha zaidi ya Panel moja mara moja?

Ndiyo. Unaweza kuanzisha Panels mfululizo na kuongeza idadi ya Panels active. Kadiri Panels active zinavyoongezeka, ndivyo uzalishaji wa jumla wa nishati unavyoongezeka na maendeleo yako kuwa ya haraka zaidi.

### 7-8. Kipima muda cha “Imebaki” kwenye Panel kinamaanisha nini?

Kipima muda kinaonyesha muda uliobaki hadi mwisho wa mzunguko wa siku 180 wa Panel. Muda ukimalizika, Panel itahamia Archive kiotomatiki na haitakuwa active tena.

### 7-9. Kwa nini baada ya kuanzisha Panel ya kwanza nikawa Activ?

Kwa sababu Activ ni uthibitisho wa ushiriki wa kweli na ulinzi wa mradi dhidi ya bots. Mradi unaunganisha Activ na uanzishaji wa Panel ya kwanza ili hadhi hiyo ipatikane tu kwa washiriki halisi.

### 7-10. Kwa nini Panels active ni muhimu zaidi kuliko Archive?

Panels active huzalisha nishati sasa hivi — ndizo zinazotoa kasi yako ya sasa ya ukuaji. Panels za Archive ni Panels zilizokamilika; zinahifadhi historia, lakini hazitoi uzalishaji wa sasa.

### 7-11. Kwa nini nina Panels active chache kuliko nilizoanzisha?

Kwa sababu sehemu ya Panels huenda ilikamilisha muda wa siku 180 na kuhamia Archive. Panels active ni zile zinazofanya kazi sasa. Archive ni Panels zilizokamilika, na hazitoi uzalishaji wa sasa.

### 7-12. Je, Panels active zinaweza “kutoweka” kwa sababu ya kikomo cha 1000?

Hapana. Kikomo cha 1000 kinamaanisha kwamba kwa wakati mmoja huwezi kuwa na zaidi ya Panels active 1000. Panels active ambazo tayari zimeanzishwa hazipotei: zinabaki active hadi mwisho wa muda wao, kisha huhamia Archive.

### 7-13. Nifanye nini ikiwa nimeanzisha Panel lakini uzalishaji haukubadilika mara moja?

Angalia hivi:
— Sasisha sehemu ya Panels
— Hakikisha Panel imeonekana kwenye Active
— Fungua Energy na uangalie kasi ya uzalishaji
— Angalia historia ya salio (inapaswa kuwa na matumizi ya 100 EFHC)

### 7-14. Je, ninaweza kuanzisha Panel ikiwa nina chini ya 100 EFHC?

Hapana. EFHC 100 zinahitajika kuanzisha Panel. Fedha zikiwa chini ya hapo, uanzishaji hautapita.

### 7-15. Kwa nini Panels za Archive ni muhimu ikiwa hazizalishi tena?

Archive huhifadhi historia ya Panels zako na mizunguko uliyokamilisha. Hii ni “wasifu wa ukuaji” wako, lakini uzalishaji wa sasa unatolewa tu na Panels active.

### 7-16. Je, ninaweza kuanzisha Panel na kuona mara moja kwamba imekuwa active?

Ndiyo. Panel iliyoanzishwa inapaswa kuonekana kwenye orodha ya Active, na uanzishaji wake utaonekana pia katika historia ya salio.

### 7-17. Panel moja huzalisha energy kiasi gani katika siku 180?

Panel moja kwa kiwango cha msingi huzalisha 107.61984000 kWh katika siku 180. Ukiwa na EFHC VIP NFT, generation huwa 115.24032000 kWh.

## 8. Energy

### 8-1. Ukurasa wa Energy unaonyesha nini?

Ukurasa wa Energy unaonyesha maendeleo ya nishati, progress bar ya uzalishaji wa nishati, idadi ya Panels active, uzalishaji wa jumla wa Panels kwa sekunde, na viashiria vingine muhimu vya hali ya sasa.

### 8-2. Progress bar kwenye ukurasa wa Energy inaonyesha nini?

Progress bar inaonyesha njia kuelekea level inayofuata ya maendeleo ya mchezaji kwenye mfumo wa levels 12.

### 8-3. Uzalishaji wa jumla wa Panels kwa sekunde unamaanisha nini?

Huu ni msingi wa uzalishaji au konstanti ya VIP, uliokuzwa kwa idadi ya Panels active.

### 8-4. Kwa nini nishati ni muhimu sana?

Kwa sababu nishati ndiyo msingi wa kati wa maendeleo katika EFHC. Kupitia nishati, mtumiaji hutoka kutoka Panels hadi kwenye matokeo yanayoathiri salio, levels, rank, na ukuaji wa akaunti.

### 8-5. Je, ninaweza kuelewa kupitia Energy akaunti yangu ina nguvu kiasi gani?

Ndiyo. Ukurasa wa Energy unaonyesha haraka nguvu ya sasa ya mfumo: Panels ngapi zinafanya kazi, uzalishaji unaenda kwa kasi gani sasa, nishati kiasi gani tayari imekusanyika, na mtumiaji amesonga umbali gani hadi hatua inayofuata.

### 8-6. Kwa nini nishati inayopatikana na salio kuu huhesabiwa tofauti?

Kwa sababu ni vitu viwili tofauti. Nishati inayopatikana inaonyesha kWh zilizokusanywa, huku salio kuu likionyesha EFHC kuu ambazo tayari zimepatikana. Thamani hizi zina uhusiano, lakini si kitu kilekile.

### 8-7. Kwa nini nishati inaongezeka yenyewe lakini salio kuu haliongezeki moja kwa moja?

Kwa sababu mkusanyiko wa nishati na ukuaji wa salio kuu hutokea katika hatua tofauti. Kwanza paneli huzalisha nishati, na salio kuu huongezeka tu baada ya hatua tofauti ya exchange au hali nyingine ya kuongeza EFHC kuu.

### 8-8. Kasi ya uzalishaji kwa sekunde inaonyesha nini?

Hiki ni kipimo cha jinsi Panels zako active zinavyozalisha nishati kwa haraka sasa hivi, yaani kasi yako ya sasa ya ukuaji.

### 8-9. Ni nini muhimu zaidi kufuatilia katika Energy kila siku?

Idadi ya Panels active, kasi ya uzalishaji, na nishati inayopatikana — hivi ni viashiria vitatu muhimu zaidi vya hali ya akaunti.

### 8-10. Ninawezaje kuelewa kupitia Energy kwamba Panels zangu zinafanya kazi kweli?

Ikiwa kwenye Energy unaona Panels active na uzalishaji usio sifuri, na nishati inayopatikana inaongezeka taratibu — Panels zinafanya kazi. Ikiwa uzalishaji ni 0 na nishati haikusanyiki, basi hakuna Panels active au unaangalia baada ya mzunguko kumalizika.

### 8-11. Kwa nini nambari za energy zinazoenda kwenye skrini wakati mwingine zinaweza kurekebishwa kidogo au kuruka?

Kwa urahisi wako, nambari za energy iliyokusanywa husasishwa kwenye skrini kwa wakati halisi na kuonyesha mchakato endelevu wa generation. Hata hivyo, chanzo kikuu cha ukweli huwa ni server. Mara kwa mara, na pia baada ya kila hatua yako, app hufanya sync na server ili kuhakikisha usahihi wa kihesabu kabisa. Wakati huo, marekebisho madogo ya nambari za skrini hadi thamani sahihi ya server yanaweza kutokea.

## 9. Exchange

### 9-1. Exchange ni nini?

Exchange ni sehemu ambapo nishati hubadilishwa kuwa EFHC kuu. Hii ni moja ya hatua muhimu zaidi za safari ya mtumiaji ndani ya mradi.

### 9-2. Kubadilisha nishati kuwa EFHC hufanyaje kazi?

Exchange ni ubadilishaji wa maendeleo kuwa EFHC kuu. Nishati iliyokusanyika hubadilishwa kuwa sarafu kuu za mradi.

### 9-3. Sheria ya 1 kWh = 1 EFHC inamaanisha nini?

Huu ni kiwango cha ndani cha mradi kilichowekwa. Kila kitengo cha nishati hubadilishwa kuwa kiasi sawa cha EFHC.

### 9-4. Nini hutokea baada ya Exchange?

Baada ya Exchange, matokeo ya nishati huonekana kwenye salio kuu kama EFHC kuu. Hii si nishati iliyokusanyika tu tena, bali ni matokeo ambayo tayari yanashiriki katika shughuli kuu za mradi.

### 9-5. Kwa nini Exchange ni muhimu sana?

Kwa sababu ni kupitia Exchange ambapo mtumiaji hubadilisha nishati iliyokusanyika kuwa matokeo ya msingi. Hapa ndipo safari ya nishati inakuwa EFHC kuu.

### 9-6. Je, ninaweza kubadilisha sarafu za bonasi moja kwa moja bila nishati?

Hapana. Sarafu za bonasi kwanza hushiriki katika mzunguko wa ndani: kupitia hizo Panel hununuliwa, Panel huzalisha nishati, na ndipo baadaye nishati hubadilishwa kuwa EFHC kuu.

### 9-7. Kwa nini Exchange huingia moja kwa moja kwenye salio kuu, si la bonasi?

Kwa sababu Exchange ni kubadilisha nishati kuwa matokeo ya msingi. Ndani ya mradi kuna sheria iliyowekwa: 1 kWh = 1 EFHC, na matokeo ya Exchange huingia kila wakati kwenye salio kuu, ambalo ndilo linaloruhusu shughuli muhimu.

### 9-8. Nifanye nini ikiwa nimefanya Exchange lakini sioni matokeo mara moja?

Kwanza sasisha sehemu ya Exchange na angalia salio kuu. Kisha fungua historia ya salio: hapo kunapaswa kuwa na rekodi ya Exchange. Ikiwa rekodi ipo, Exchange imefanyika hata kama hukugundua mabadiliko mara moja.

### 9-9. Je, ninaweza kubadilisha nishati na mara moja kutuma ombi la Withdraw?

Ndiyo, ikiwa baada ya Exchange salio kuu lina EFHC za kutosha, kiasi cha Withdraw si chini ya 10 EFHC, na Wallet imeunganishwa na kuchaguliwa kama kuu.

### 9-10. Ni bora kufanya Exchange mara nyingi au kukusanya kwanza?

Hii inategemea lengo lako. Exchange ya mara kwa mara ni rahisi kwa udhibiti na operesheni, huku kukusanya ni rahisi kwa hatua kubwa zisizo za mara kwa mara. Sheria ni moja: matokeo ya Exchange huenda kwenye salio kuu.

### 9-11. Kwa nini baada ya Exchange nishati inayopatikana inapungua?

Kwa sababu unahamisha sehemu ya nishati iliyokusanyika kuwa EFHC kupitia Exchange. Nishati haitoweki — inabadilika kuwa sarafu.

Muhimu: kiasi cha nishati kwenye ukurasa wa Energy hakipaswi “kupungua” kama kosa la kuona; hupungua tu kwa sehemu iliyobadilishwa.

### 9-12. Ni nishati gani ambayo tayari ninaweza kubadilisha?

Unaweza kubadilisha nishati ambayo tayari imekusanyika na kuwa inayopatikana. Hiyo ndiyo nishati inayopatikana — kiasi kilicho tayari kwa hatua ndani ya Exchange.

### 9-13. Je, kuna kiwango cha chini cha kubadilisha energy kuwa main EFHC?

Hakuna mipaka mikali, lakini hesabu ya exchange imefungwa kwenye kiwango cha 1 kWh = 1 EFHC. Ni bora kukusanya na kubadilisha thamani kamili za energy kuanzia 1 kWh ili matokeo yaonekane mara moja kwenye salio kuu.

## 10. Withdraw

### 10-1. Kwa nini siwezi kutoa EFHC?

Kwa kawaida sababu ni kwamba hakuna fedha za kutosha kwenye salio kuu, Wallet haijaunganishwa, au kiasi kiko chini ya kiwango cha chini cha Withdraw. Ukaguzi unapaswa kuanza na Wallet na salio kuu.

### 10-2. Withdraw hufanyikaje?

Ombi la Withdraw huundwa, kisha huchakatwa haraka iwezekanavyo na operator wa kwanza aliye huru.

### 10-3. Kwa nini baada ya ombi la Withdraw salio lilibadilika mara moja?

Kwa sababu bot huanza kuhesabu operesheni hii mara moja ndani ya mfumo. Hii ni ili mtumiaji aone kuwa hatua hiyo tayari imefungwa na fedha zake na imekubaliwa na mfumo.

### 10-4. Ni balance gani inaweza kutumika kwa withdrawal?

Withdrawal inapatikana tu kutoka kwenye balance kuu.

### 10-5. Kwa nini Withdraw inapatikana tu kutoka kwenye salio kuu?

Kwa sababu salio kuu ndilo tayari ni matokeo ya mchakato wa mchezo au sarafu zilizonunuliwa. Sarafu za bonasi hushiriki katika mzunguko wa ndani na haziwezi kutolewa moja kwa moja.

### 10-6. Kiasi cha chini cha Withdraw ni kipi?

Kiasi cha chini cha Withdraw ni 10 EFHC.

### 10-7. Kwa kawaida ombi la Withdraw huchakatwa kwa muda gani?

Withdraw hupitia ombi na usindikaji wa operator. Ikiwa matokeo hayaonekani mara moja, angalia hali ya ombi na historia ya operesheni — hapo ndipo hali halisi inaonyeshwa. Ikiwa ombi halibadiliki kwa muda mrefu, kwa kawaida inahitaji tu muda zaidi wa usindikaji.

### 10-8. Je, ninaweza kughairi ombi la Withdraw?

Ndiyo, ikiwa ombi bado halijachakatwa. Ughairi unapatikana kwa ombi lililo pending. Baada ya kughairi, angalia salio kuu na historia ya operesheni: ikiwa fedha zilikuwa zimezuiwa, zinarejeshwa.

### 10-9. Kwa nini ombi la Withdraw linaweza “kubaki” kwenye pending?

Kwa sababu Withdraw hupitia uchakataji. Ikiwa ombi halibadiliki, angalia hali ya ombi na historia ya operesheni, kisha sasisha sehemu hiyo baadaye.

### 10-10. Ni wapi nitaona kwamba ombi limeghairiwa?

Hili linaonekana kupitia hali ya ombi na pia kupitia rekodi katika historia ya operesheni. Baada ya kughairi, angalia pia salio kuu.

### 10-11. Kwa nini kiwango cha chini cha Withdraw ni 10 EFHC?

Kwa sababu ndani ya mradi kizingiti kimewekwa na maombi chini ya hapo hayakubaliwi. Kiwango cha chini ni 10 EFHC.

Pia: ada ya Withdraw inalipwa na mradi, kwa hiyo kutoa kiasi chini ya 10 EFHC si cha maana.

### 10-12. Kwa nini withdrawal inaweza kutopatikana hata kama nina EFHC?

Kwa sababu kwa withdrawal ni balance kuu pekee inayohesabiwa. Ikiwa EFHC ziko kwenye sehemu ya bonus ya balance, huwezi kuwasilisha withdrawal kwa hizo.

### 10-13. Nifanye nini baada ya kutuma ombi la Withdraw?

Angalia hali ya ombi na historia ya operesheni — hapo unaona hali halisi ya ombi na mwendo wa fedha.

### 10-14. Uondoaji unafanywa kwa token gani na kwenye mtandao gani?

Uondoaji unafanywa tu katika token za EFHC na tu kwenye mtandao wa blockchain wa TON (The Open Network). Hakuna chaguo jingine lolote la uondoaji ndani ya mradi.

### 10-15. Inachukua muda gani operator kushughulikia withdrawal kwa mkono?

Maombi ya withdrawal hushughulikiwa na operator kwa mpangilio wa foleni hai. Kwa kawaida usindikaji huchukua kutoka dakika chache hadi saa 24 kulingana na mzigo wa mtandao na idadi ya maombi. Unaweza kila wakati kughairi ombi ambalo halijashughulikiwa, na fedha zitarudi mara moja kwenye salio lako.

## 11. Tasks

### 11-1. Kukamilisha tasks kunatoa nini?

Tasks hutoa tu bonus coins na humhamasisha mchezaji kushiriki zaidi katika maisha ya mradi.

### 11-2. Ninapataje reward ya task?

Unahitaji kutimiza masharti ya task. Baada ya hapo bot hukagua matokeo kiotomatiki, huhesabu task kuwa imekamilika, na huweka reward iliyopangwa.

### 11-3. Kwa nini task haijahesabiwa kuwa imekamilika?

Hali hii hutokea kama masharti bado hayajakamilika kikamilifu, action haijafanywa hadi mwisho, au matokeo bado hayajasasishwa kwenye mfumo.

### 11-4. Naweza kufanya task ileile tena?

Hilo linategemea aina ya task. Baadhi ya tasks ni za mara moja, na baadhi zinaweza kurudiwa kulingana na mantiki ya mradi.

### 11-5. Tasks zote zinatoa reward sawa?

Hapana. Kiasi cha reward hutegemea task husika na masharti yake. Lakini aina ya reward hapa ni moja — bonus coins.

### 11-6. Kwa nini tasks zinahitajika ikiwa tayari kuna panels?

Tasks ni njia ya ziada ya ukuaji. Hazibadilishi panels, bali husaidia kukusanya bonus coins ambazo baadaye zinaweza kutumika ndani ya mzunguko wa mchezo.

### 11-7. Kwa nini reward ya tasks haiingii kwenye main balance?

Kwa sababu tasks hutoa bonus EFHC. Hii ni reward ya ndani ya mzunguko wa mchezo, na huongezwa kwenye bonus balance.

### 11-8. Kwa nini tasks wakati mwingine huisha au kutoweka?

Kwa sababu tasks zinaweza kuwa za muda au kuwa na kikomo. Ikiwa task haipo, inamaanisha imekamilika au sasa haiko active.

### 11-9. Ni wapi ninaweza kuona tasks zote zinazopatikana?

Katika sehemu ya Tasks — hapo ndipo orodha ya tasks zinazopatikana na masharti yake huonyeshwa.

### 11-10. Kwa nini reward ya task haikuonekana mara moja?

Wakati mwingine mfumo unahitaji muda kusasisha matokeo. Angalia: sasisha Tasks → kagua bonus balance → kagua history ya operations.

### 11-11. Nimejiunga na channel inayotakiwa kwenye task, lakini task haikamiliki. Kwa nini?

Wakati mwingine uthibitishaji wa subscription huchukua muda kwa sababu ya caching kwenye upande wa server za Telegram. Ikiwa bot haikuhesabu subscription mara moja, rudi kwenye sehemu ya Tasks baada ya dakika chache na ubonyeze kitufe cha ukaguzi tena.

## 12. Referrals

### 12-1. Sehemu kwenye ukurasa wa Referrals zinaitwaje?

Kwenye ukurasa wa Referrals hutumika sehemu mbili: Active na Inactive.

### 12-2. Referral active na inactive inamaanisha nini?

Referral active ni mchezaji ambaye tayari ameanzisha angalau panel moja na amepata Activ status. Referral inactive ni yule ambaye bado hajaingia kwenye mzunguko wa mchezo na kwa sasa hatoi haki ya bonus.

### 12-3. Referral bonuses huongezwa lini?

Referral bonuses hukaguliwa na bot kiotomatiki. Mara tu mchezaji anapokuwa active, bonus huongezwa moja kwa moja.

### 12-4. Activ status inatoa nini kwa referrals?

Activ status ni muhimu kwa mantiki ya referrals, kwa sababu mradi huitumia kama sehemu ya kuchuja ushiriki halisi na kulinda dhidi ya boosting kutoka kwa bots, bot farms, na activity ya uongo.

### 12-5. Activ inaunganishwaje na referrals?

Activ huonyesha kuwa mtumiaji ni mshiriki halisi wa mradi, si bot-account. Hilo ni muhimu kwa kazi ya haki ya mfumo wa referrals na ulinzi dhidi ya bot farms.

### 12-6. Ni bonus gani ya msingi huongezwa kwa kila referral active?

Kwa kila referral active, 0.1 EFHC huongezwa kwenye bonus balance.

### 12-7. Kwa nini nina referrals, lakini bonus haijaongezwa?

Bonus huongezwa tu kwa referrals active — yaani wale walioanzisha angalau panel moja na wakapata Activ. Angalia tab za “Active” na “Inactive”: mara nyingi walioalikwa bado hawajafika kwenye active status.

### 12-8. 0.1 EFHC ya referral active huenda wapi?

Bonus ya 0.1 EFHC huongezwa kwenye bonus balance. Hii ni reward ya ndani ya mfumo wa referrals na inaonekana kwenye bonus balance pamoja na history ya operations.

### 12-9. Kwa nini mtu niliyemwalika yuko kwenye orodha, lakini hahesabiwi active?

Kwa sababu anakuwa active tu baada ya kuanzisha panel yake ya kwanza na kupata Activ. Kabla ya hapo, hubaki kwenye sehemu ya inactive ya orodha.

### 12-10. Ni wapi ninaweza kupata referral link yangu?

Katika sehemu ya Referrals — hapo ndipo referral link yako na orodha ya walioalikwa huonyeshwa.

### 12-11. Je, inaruhusiwa kuunda akaunti za ziada kwa kutumia referral link yako mwenyewe?

Ndiyo. Sheria za mradi hazikatazi hilo. Hata hivyo, kuunda akaunti tupu hakutakuletea faida. Uchumi wa mfumo umejengwa kwa namna ambayo referral bonuses na ukuaji wa ranking huongezwa tu kwa mshiriki mwenye Activ status — yaani baada ya akaunti iliyoalikwa kuingia kweli kwenye mchezo na kuanzisha angalau panel moja.

### 12-12. Je, ninaweza kubadilisha aliyenialika baada ya kujisajili?

Hapana. Uhusiano wa referral hufungwa wakati wa kuingia kwako kwa mara ya kwanza kwenye mradi kupitia referral link na hauwezi kubadilishwa baadaye.

## 13. Hub

### 13-1. Naweza kufanya nini kwenye Hub?

Kwenye Hub kuna kadi zinazopeleka kwenye vitendo vinavyohusiana na mradi: kwenda kwenye mtiririko wa nje wa kupata EFHC na kwenda kwenye mkusanyiko wa nje wa VIP NFT.

### 13-2. Hub ni ya nini?

Hub hufanya kazi kama navigation layer kwa mpito wa haraka kwenda kwenye vitendo vinavyohusiana na mitiririko ya nje ya mradi.

### 13-3. Ni kadi gani zipo kwenye Hub?

Kwa hatua ya sasa, kwenye Hub kuna kadi mbili: EFHC na VIP.

### 13-4. Kadi ya EFHC hufanya nini?

Kadi ya EFHC huanzisha mpito kwenda kwenye mtiririko wa nje wa kupata EFHC.

### 13-5. Top-up ya EFHC huingia kwenye salio gani baada ya uthibitisho?

Top-up ya EFHC jetton huwekwa kwenye salio kuu.

### 13-6. Kwa nini matokeo ya top-up yanaweza yasitokee mara moja?

Kwanza hatua ya nje ya operesheni lazima ithibitishwe, kisha matokeo husasishwa. Angalia Hub, salio kuu, na historia ya operesheni.

### 13-7. Nikikipata VIP NFT kupitia GetGems, nitaona wapi kuwa kiko hai?

Angalia hadhi ya VIP ndani ya programu na uwepo wa NFT kwenye wallet iliyounganishwa.

### 13-8. Nimekamilisha mtiririko wa nje kutoka Hub lakini hakuna matokeo. Nifanye nini?

Angalia Hub, salio kuu, na historia ya operesheni. Kama bado hakuna matokeo, operesheni bado haijaingizwa au inahitaji uchakataji wa pekee.

### 13-9. Ni salio gani hupokea top-up kupitia Top Up na Hub?

Top-up ya EFHC jetton huwekwa kwenye salio kuu.

### 13-10. Je, ninahitaji wallet iliyounganishwa kwa vitendo vya Hub?

Kwa vitendo vya nje vinavyotegemea wallet, unahitaji Wallet iliyounganishwa. Hub yenyewe hufunguka bila ununuzi wa ziada na hutumika kama sehemu ya mpito.

### 13-11. Ninaweza kuthibitisha wapi kwamba top-up ya EFHC imeingia kweli?

Angalia salio kuu na historia ya operesheni: alama ya top-up inapaswa kuonekana hapo.

### 13-12. Je, kuna skins kwenye Hub?

Skins si kadi za Hub.

### 13-13. Ninapataje skins za mradi?

Skins hufunguka kadri akaunti inavyopiga hatua na zimefungwa kwenye viwango 12 vya mafanikio.

## 14. Urambazaji na sheria

### 14-1. When should I open the “Navigation and Rules” section?

Open this section when you need to quickly understand the logic of the screens, find the needed function in the WebApp, or clarify the basic rules for working with the app sections.

### 14-2. Ni skrini zipi ninapaswa kufungua kwanza ikiwa naingia kwenye WebApp kwa mara ya kwanza au baada ya mapumziko marefu?

Ni bora kuanza na skrini kuu, upau wa juu, na wasifu. Baada ya hapo itakuwa rahisi kwenda kwenye Wallet, Panels, Energy, Exchange, Withdraw, Tasks, Referrals, History, na Hub kulingana na kazi yako ya sasa.

### 14-3. Ninawezaje kuelewa ni sehemu gani ina kazi ninayohitaji?

Chagua sehemu kulingana na maana ya tendo: Profile — kwa data ya akaunti na taarifa za rejea, Wallet — kwa wallet, Panels — kwa paneli, Energy — kwa uzalishaji, Exchange — kwa ubadilishaji, Withdraw — kwa utoaji, Tasks — kwa kazi, Referrals — kwa watumiaji walioalikwa, na Hub — kwa mipito kwenda kwenye vitendo vinavyohusiana na EFHC na VIP.

### 14-4. Where is the entry to Profile?

The entry to Profile is in the upper part of the interface through the “Profile” button.

### 14-5. Why do some actions require a separate confirmation?

A separate confirmation protects the account and reduces the risk of accidental actions in important operations.

### 14-6. Why are some actions available immediately while others depend on the account state?

Some functions depend on the account state, the presence of a panel, a linked wallet, activity history, or other internal project conditions.

### 14-7. How do I understand the difference between Profile, Wallet, and History?

Profile contains personal and reference sections, Wallet is for linked-wallet actions, and History helps you track operations and changes.

### 14-8. What should I do if I do not see the button or section I need?

First refresh the screen and make sure you are on the correct page. Then check whether the function depends on the account state, a linked wallet, an active panel, or another condition.

### 14-9. What should I do if the data on the screen looks outdated?

Refresh the screen, reopen the needed section, and compare the data with the related page. It is important to check balances in balance-related sections, energy in Energy, and operations in History.

### 14-10. How do I understand that I opened the wrong section?

If the screen does not match the action you want, does not show the expected data, or does not contain the needed control, you most likely opened the wrong section.

### 14-11. What order of actions is the most convenient after entering the WebApp?

A convenient order is to check the main screen, balances, active panels, available energy, needed tasks, and then move to wallet, exchange, or withdrawal actions if necessary.

### 14-12. Which sections should I check regularly?

It is useful to regularly check the main screen, balances and history, Panels, Energy, Tasks, and the sections you use for exchange, withdrawals, or wallet actions.

### 14-13. Why is it important to perform actions in their own section instead of searching everywhere?

This keeps the app clear and predictable: each section is responsible for its own logic, data, and controls.

### 14-14. What signs show that an action is important and requires attention?

An action requires more attention if it changes balances, affects energy, uses a linked wallet, confirms an operation, or launches an external or irreversible step.

### 14-15. What should I do if a screen changed after a bot update?

Use the current interface structure and the updated FAQ. The visual layout may change, but the meaning of the sections should remain consistent.

### 14-16. Which rules are important to remember when working with the WebApp?

It is important to follow the logic of the sections, not mix unrelated actions, check confirmations carefully, and rely on the actual state of balances, panels, energy, and wallet actions.

### 14-17. How should I use the FAQ together with the WebApp?

Use the FAQ as a practical guide: first find the section you need in the WebApp, then open the matching FAQ block to clarify the meaning, conditions, and sequence of actions.

## 15. Ads

### 15-1. Hii ni sehemu gani?

Sehemu ya Ads ni subsection ndani ya sehemu ya Tasks. Inaonyesha advertising actions zinazopatikana, ambazo mtumiaji anaweza kutumia kupata bonus coins za ziada.

### 15-2. Inanipa nini?

Inatoa tu bonus coins kwa views, ikiwa advertising kwa sasa inapatikana kwa akaunti ya mtumiaji.

### 15-3. Kwa nini hapa hakuna kitu?

Ikiwa sehemu iko tupu, ina maana kwa sasa hakuna offers active kwa akaunti ya mtumiaji au advertising imezimwa kwa muda.

### 15-4. Sehemu ya Ads iko wapi?

Sehemu ya Ads iko kama subsection ndani ya Tasks. Hii ni moja ya uwezo wa ziada ndani ya block ya tasks.

### 15-5. Ads hutoa reward ya aina gani?

Ads hutoa tu bonus coins kwa views. Hii si main balance wala direct withdraw, bali ni njia ya ziada ya ndani ya kuimarisha njia ya mchezo.

### 15-6. Kwa nini Ads ni ya manufaa?

Kwa sababu hii ni source ya ziada ya bonus coins. Haibadilishi panels na generation, lakini inaweza kusaidia kuimarisha internal game cycle kwa kasi zaidi.

### 15-7. Kwa nini wengine wana advertising, lakini mimi sina?

Kwa sababu offers zinaweza zisipatikane kwa akaunti fulani au advertising imezimwa kwa muda. Ads tupu haimaanishi kuwa akaunti imeharibika.

### 15-8. Nifanye nini ikiwa nimekamilisha action ndani ya Ads, lakini hakuna matokeo?

Angalia: sasisha Tasks/Ads → kagua bonus balance → kagua history ya operations.

### 15-9. Kwa nini ndani ya Ads kunaweza kuwa na offers tofauti kwa watumiaji tofauti?

Kwa sababu offers hutegemea upatikanaji wa advertising campaigns kwa akaunti husika. Hili ni jambo la kawaida: mtu mmoja ana offers, mwingine kwa muda hana.

### 15-10. Je, nahitaji kununua kitu ili kutumia Ads?

Hapana. Ads ni njia ya kupata bonus EFHC, na haihitaji ununuzi wa lazima.

## 16. Ranks

### 16-1. Kwa nini ni muhimu kwangu kukua katika ranking?

Ukuaji katika ranking unaonyesha jinsi maendeleo yako yanavyoonekana ukilinganishwa na washiriki wengine. Hilo hukusaidia kuelewa nafasi yako ya sasa na kuona akaunti inavyoendelea kwa nguvu.

### 16-2. Level inatofautianaje na rank?

Level inaonyesha maendeleo yako binafsi ndani ya mfumo, wakati rank inaonyesha nafasi yako kati ya washiriki wengine.

### 16-3. Level na rank vinaunganishwaje?

Vinaunganishwa na mantiki moja ya ukuaji kupitia uzalishaji wa kWh kwa Panels na progress bar ya jumla kwenye ukurasa wa Energy.

### 16-4. Rank ni namba nzuri tu ya kuangalia?

Hapana. Rank husaidia kuelewa jinsi safari yako inavyoonekana ukilinganisha na washiriki wengine.

### 16-5. Ni nini kinaathiri ukuaji wa nafasi yangu katika ranking?

Ukuaji wa nafasi yako katika ranking unategemea maendeleo ya jumla ya akaunti: maendeleo ya panels, uzalishaji wa kWh na mwendo wa jumla kwenye njia ya nishati ya mradi.

### 16-6. Naweza kupanda level na rank kwa wakati mmoja?

Ndiyo. Mtumiaji anapoendeleza Panels, uzalishaji, na maendeleo ya jumla ya nishati, kwa kawaida huimarisha level yake na pia nafasi yake kwenye rank.

### 16-7. Kwa nini nina level ya juu, lakini nafasi yangu kwenye rank si ya kwanza?

Kwa sababu rank ni nafasi yako kati ya washiriki wote, si maendeleo yako binafsi pekee. Wachezaji wengine pia hukua, hivyo nafasi yako inaweza kubadilika hata ukiwa na level nzuri.

### 16-8. Kwa nini rank yangu inaweza kusogea bila mimi kufanya hatua mpya?

Kwa sababu rank haiishi peke yake; hubadilika kwa kulinganisha na washiriki wote. Wakati wewe hubadilishi chochote, watumiaji wengine wanaendelea kukua, na hilo huathiri nafasi yako.

### 16-9. Naona wapi nafasi yangu kwenye rank?

Katika sehemu ya Ranks — hapo ndiyo nafasi yako kati ya washiriki wengine huonyeshwa.

### 16-10. Kwa nini rank yangu inaweza kushuka hata kama ninaendelea kupiga hatua?

Kwa sababu rank hutegemea si ukuaji wako tu, bali pia kasi ambayo washiriki wengine wanakua. Hata kama akaunti yako inaendelea kuwa imara, nafasi yako inaweza kushuka wakati wengine wanakupita kwa kasi zaidi.

## 17. Activ-status

### 17-1. Activ status ina maana gani?

Activ ni hadhi ya kudumu ya kuwa active. Ina maana mchezo umeanza kwa kweli, kwa sababu angalau Panel moja imenunuliwa.

### 17-2. Ninawezaje kupata Activ?

Ili kupata Activ, inatosha kuanzisha Panel moja. Baada ya uanzishaji huu, hadhi hutolewa kwa msingi wa kudumu.

### 17-3. Activ ni ya muda au ya kudumu?

Activ ni hadhi ya kudumu.

### 17-4. Je, Activ inabaki ikiwa baadaye Panel inaenda kwenye Archive?

Ndiyo. Hata kama baadaye Panel itaenda kwenye Archive, Activ status hubaki.

### 17-5. Kwa nini Activ ni muhimu?

Activ husaidia kutenganisha wachezaji halisi na usajili wa bahati nasibu, bots, na mashamba ya bots. Inathibitisha ushiriki halisi wa mtumiaji ndani ya mradi.

### 17-6. Activ inaweza kutoweka baadaye?

Hapana. Activ ni hadhi ya kudumu na hubaki hata kama Panel ya kwanza baadaye itaenda kwenye Archive.

### 17-7. Kwa nini Activ inahitajika kwa ulinzi dhidi ya bots na mashamba ya bots?

Kwa sababu Activ inathibitisha ushiriki halisi, si akaunti tupu ya kuongeza namba. Hii hufanya mfumo wa Referrals na uchumi wa mradi kuwa wa haki zaidi.

### 17-8. Ni nini hubadilika kwenye akaunti baada ya kupata Activ?

Akaunti huchukuliwa kuwa imethibitishwa kama mshiriki hai wa mradi. Hii huathiri kazi ya haki ya referrals na kuaminika kwa activity.

### 17-9. Kwa nini Activ huonekana hasa baada ya Panel ya kwanza?

Kwa sababu ununuzi wa Panel ya kwanza ni ishara wazi ya ushiriki halisi. Mradi hutumia hatua hii kama kichujio dhidi ya akaunti tupu.

### 17-10. Naweza kupoteza Activ kwa sababu ya kutokuwa active?

Hapana. Activ ni hadhi ya kudumu na haitoweki kwa sababu ya kutokuwa active.

## 18. VIP NFT

### 18-1. EFHC VIP NFT ni nini?

EFHC VIP NFT ni kadi ya klabu, ufunguo wa ecosystem ya baadaye ya EFHC, alama ya kidijitali ya kuwa sehemu ya mradi, na ufunguo wa fursa za baadaye.

### 18-2. Kumiliki EFHC VIP NFT moja kunanipa nini?

Kumiliki EFHC VIP NFT moja kunatoa uzalishaji ulioongezwa kwa Panels zote za mchezaji.

### 18-3. Ni kwa dalili gani inaweza kuonekana kuwa VIP tayari imezingatiwa?

Ikiwa VIP NFT tayari imezingatiwa na mfumo, interface inaonyesha status ya VIP na faida zinazohusiana na akaunti zinaanza kuonekana.

### 18-4. Nitaona wapi athari ya VIP?

Athari ya VIP inaonekana katika sehemu ambako mradi huzingatia faida za VIP NFT, pamoja na paneli ya juu na sehemu ya Wasifu / Mipangilio.

### 18-5. Nahitaji kuwasha VIP kwa mkono?

Hapana. Mantiki ya mradi imeundwa kwa ukaguzi wa kiotomatiki wa Wallet na usasishaji wa kiotomatiki wa VIP status baada ya NFT kugunduliwa kwenye collection inayotakiwa.

### 18-6. Je, VIP NFT 2 au 3 zinatoa faida za ziada kwa mchezaji?

Hapana. Kwa mchezaji, kuwa na VIP NFT 2 au 3 hakutoi faida za ziada zaidi ya VIP NFT moja.

### 18-7. Kwa nini VIP NFT ya pili haiongezi athari?

Ndani ya mradi, VIP hutoa boost ya uzalishaji kama hadhi moja active. VIP NFT za ziada hazitoi boost ya ziada ili athari isikue bila kikomo.

### 18-8. VIP huathiri Panel moja au zote?

VIP huathiri uzalishaji wa Panels zote za mtumiaji, si Panel moja pekee.

### 18-9. Ninawezaje kukagua kwamba VIP kweli inaathiri akaunti?

Angalia si uwepo wa status ya VIP pekee, bali pia faida zinazohusiana katika mechanics za akaunti, hasa pale ambapo athari ya VIP inazingatiwa, ikiwa ni pamoja na generation.

### 18-10. Je, Wallet iliyounganishwa inahitajika ili bot iweze kuona VIP NFT yangu?

Ndiyo. Ili bot iweze kuona VIP NFT, inahitaji kujua Wallet gani ni ya akaunti hiyo. Kwa hiyo Wallet lazima iunganishwe, kisha unaangalia VIP status kwenye interface.

### 18-11. Je, ninaweza kuitumia VIP NFT yangu jinsi ninavyotaka?

Ndiyo. EFHC VIP NFT inaweza kuhamishwa, kutolewa kama zawadi na kuuzwa kwenye marketplace.

### 18-12. Nikiiuza au kuihamisha VIP NFT yangu kwenda wallet nyingine, generation yangu itakuwaje?

Bot huchanganua blockchain mara kwa mara na kukagua uwepo wa NFT kwenye wallet yako iliyounganishwa. Ukiuza, ukitoa au ukihamisha VIP NFT yako kwenda anwani nyingine, mfumo utagundua hilo, utazima VIP status yako, na generation ya panel zako zote itarudi kiotomatiki kwenye kiwango cha msingi.

## 19. Levels

### 19-1. Kwa nini ninapaswa kuongeza level yangu?

Ukuaji wa level unaonyesha maendeleo ya mtumiaji ndani ya mradi na husaidia kuona jinsi akaunti inavyokua. Hii ni ishara ya kuona na ya maana ya kusonga mbele.

### 19-2. Sehemu ya Levels inajumuisha nini?

Sehemu ya Levels inaonyesha mizani yote ya ukuaji wa mradi: levels 12 za maendeleo ya nishati, levels 6 za mfumo wa referrals, na mistari mingine ya levels ya mradi ikiwa itaongezwa.

### 19-3. Kuna levels ngapi za maendeleo ya nishati ndani ya mradi?

Ndani ya mradi kuna levels 12 za maendeleo ya nishati.

### 19-4. Kuna levels ngapi katika mfumo wa referrals?

Ndani ya mradi kuna levels 6 za mfumo wa referrals: kutoka 0 hadi 5.

### 19-5. Levels zina faida gani kwa mchezaji wa kawaida?

Levels husaidia kuelewa uko wapi sasa, ni kiasi gani tayari kimefanywa, ni wapi unapaswa kusonga baadaye, na mpaka gani unaofuata mbele yako.

### 19-6. Levels za nishati, referral levels, na ukuaji wa jumla wa akaunti vinaunganishwaje?

Hizi ni sehemu za njia moja ya pamoja. Uzalishaji wa nishati unasukuma maendeleo makuu, referrals active zinaimarisha mstari wa referrals, na kwa pamoja zinaonyesha jinsi akaunti inavyokua kwa nguvu.

### 19-7. Eco Initiate (0 kWh)

**Maana kwa mchezaji:** Panel yako ya kwanza imewekwa na iko tayari kufanya kazi. Unachukua hatua kuu kuelekea kuwa mzalishaji huru wa nishati safi. Hii ni hadhi yako ya kuanzia — umeingia tu kwenye njia ya ukuaji wa nishati.

### 19-8. Hope Bringer (100 kWh)

**Maana kwa mchezaji:** Kilowati za kwanza tayari zimeanza! Panels zako zinazalisha nishati ya kijani kwa mafanikio, zikileta tumaini la mustakabali usio na kaboni. Tayari unaona matokeo ya kwanza halisi: nishati imeanza na maendeleo yanakwenda mbele.

### 19-9. Energy Seeker (300 kWh)

**Maana kwa mchezaji:** Mfumo unafanya kazi vizuri, ukiendelea kulijaza mtandao kwa umeme safi wa kiikolojia. Kila kitengo cha nishati kinachozalishwa na Panels kinapunguza utegemezi wa mafuta ya visukuku. Akaunti yako imeingia kwenye hali ya ukuaji thabiti.

### 19-10. Nature's Voice (600 kWh)

**Maana kwa mchezaji:** Mchango wako unaanza kuonekana. Kwa kuzalisha nishati kupitia teknolojia za kijani, unakuwa sauti ya asili na kuonyesha kuwa maendeleo yanaweza kuwa ya kirafiki kwa mazingira. Mchango wako sasa unaonekana wazi zaidi.

### 19-11. Earth Ally (1000 kWh)

**Maana kwa mchezaji:** MWh yako ya kwanza imezalishwa! Panels zako zimezalisha kiasi kikubwa cha nishati safi. Sasa wewe ni mshiriki muhimu wa mabadiliko ya kijani na mshirika wa kweli wa sayari. Umevuka mpaka muhimu: 1000 kWh.

### 19-12. Climate Fighter (2000 kWh)

**Maana kwa mchezaji:** Uzalishaji wako sasa unaathiri kweli mapambano dhidi ya mabadiliko ya tabianchi. Kila kilowati inayozalishwa inapunguza moja kwa moja hitaji la kuchoma makaa ya mawe na gesi. Tayari unasukuma ukuaji kwa utaratibu, na maendeleo yako yanaonekana kwa uwazi.

### 19-13. Green Sentinel (3500 kWh)

**Maana kwa mchezaji:** Mtiririko thabiti wa nishati kutoka Panels zako unasimama kulinda hewa safi. Unaleta faida inayoonekana kwa jamii bila kuacha alama ya kaboni. Akaunti yako inakuwa “mlinzi” wa nafasi ya kijani.

### 19-14. Planet Defender (5000 kWh)

**Maana kwa mchezaji:** 5000 kWh za uzalishaji safi! Uwezo wa Panels zako unafanya kazi kama ngao isiyoonekana, ukilinda anga dhidi ya maelfu ya kilo za uzalishaji wa gesi za chafu. 5000 kWh ni ishara kubwa ya kiwango: tayari uko kwenye hatua kubwa.

### 19-15. Eco Champion (7500 kWh)

**Maana kwa mchezaji:** Kiasi bora sana cha uzalishaji! Wewe ni bingwa wa kweli wa nishati ya kijani, na mchango wako unaathiri kwa namna inayoonekana mizani ya nishati ya dunia kuelekea bora. Hii ni level ya wale wanaoshikilia kasi kwa uthabiti.

### 19-16. Planet Saver (10000 kWh)

**Maana kwa mchezaji:** MWh 10! Umezalisha nishati safi kiasi kwamba kwa kweli unaokoa ecosystems nzima, ukithibitisha ufanisi wa juu wa Panels zako. 10 000 kWh tayari ni “hatua ya kumi elfu” — kiwango kikubwa sana cha maendeleo.

### 19-17. Green Commander (15000 kWh)

**Maana kwa mchezaji:** Kiongozi wa uzalishaji wa kiikolojia. Panels zako zinaipa mustakabali nguvu, na kiwango chako kikubwa cha uzalishaji kinaweka viwango vipya vya juu kwa jamii nzima. Uko karibu na kilele: hii ni level ya nguvu na uthabiti.

### 19-18. Guardian of Earth (20000+ kWh)

**Meaning for the player:** The peak of evolution. By generating more than 20 MWh of completely clean energy, you have become a true Guardian of Earth. Your panels draw strength from nature itself to power this world and preserve it for future generations. This is the top of the ladder: you have reached the highest recognized level of progress.

**Exact rule:** The Guardian of Earth level corresponds to 20000+ kWh.

**Practical effect:** In practice, you have secured the highest status. From here, the focus is on maintaining the system, scaling panels, and strengthening ecosystem participation through panels, VIP, and referral growth.

### 19-19. Referral level 0

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 0 EFHC. Level hii ni hatua ya kuingia.

### 19-20. Referral level 1

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 1 EFHC. Hii ni hatua ya kwanza ya ukuaji wa referral.

### 19-21. Referral level 2

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 10 EFHC. Hapa mfumo wa referrals tayari unaanza kuonekana kwa nguvu.

### 19-22. Referral level 3

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 100 EFHC. Hii ni hatua ya ukuaji mkubwa wa referral.

### 19-23. Referral level 4

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 300 EFHC. Hii tayari ni matokeo makubwa kwa mstari wa referrals.

### 19-24. Referral level 5

**Maana kwa mchezaji:** Hiki ni kipimo cha ukuaji wako ndani ya mfumo wa referrals — kinaonyesha kiwango cha invited users active. **Sheria kamili:** Ukifikia level hii, unapata bonus ya mara moja ya 1000 EFHC. Hii ni kiwango cha juu zaidi cha mfumo wa referrals katika usanidi wa sasa.

### 19-25. How should I understand level progress without mistakes?

**Meaning for the player:** This block helps you assess progress soberly and look at levels through actual energy generation.

**Exact rule:** Levels are determined by accumulated generation in kWh. The greater the total generation, the higher your level.

**Practical effect:** In practice, focus on the growth of energy, the number of active panels, and the overall generation pace. These are what give real level progress.

### 19-26. Kwa nini majina ya levels yanahusiana na ikolojia na sayari?

Kwa sababu wazo kuu la mchezo linahusiana na green energy ya kidijitali, motisha ya watu, na mchango wa mfano katika kuponya sayari ya Dunia.

## 20. FAQ / Msaada

### 20-1. Ni wapi ninaweza kufungua FAQ?

FAQ hufunguliwa kutoka kwenye Wasifu kama sehemu ya msaada iliyojengwa ndani ya bot, ambapo majibu ya vitendo vya msingi, skrini, na sheria za mradi yamekusanywa.

### 20-2. FAQ / Msaada inahitajika kwa nini?

Sehemu hii inahitajika ili mtumiaji apate haraka majibu yanayoeleweka, namba sahihi, sheria halisi za mradi, na maana ya vitendo vya msingi bila kubahatisha wala kuchanganyikiwa.

### 20-3. Kwa nini FAQ imeandikwa kwa undani sana?

Kwa sababu mradi ni wa tabaka nyingi, na maelezo mafupi makavu hayatoshi kwa maswali halisi ya mchezaji. Hapa maana, uelewekevu, namba sahihi, na matokeo halisi ya vitendo ni muhimu.

### 20-4. Je, FAQ inaweza kunisaidia kuelewa njia yote ya mchezaji ndani ya bot?

Ndiyo. FAQ nzuri haipaswi kueleza vitufe vya pekee tu, bali safari yote: kutoka Panel ya kwanza hadi nishati, Exchange, mizani, levels, hadhi, na ukuaji wa akaunti.

### 20-5. Nifanye nini ikiwa sikupata jibu mara ya kwanza?

Ni bora kufungua sehemu iliyo karibu kwa maana na kuangalia maswali ya jirani. Ndani ya bot kubwa, majibu mengi yanaunganishwa, na block moja mara nyingi husaidia kuelewa inayofuata.

### 20-6. How should I use the FAQ correctly?

It is best to move section by section: first understand the general logic of the project, then your screens and actions, and only after that look at specific rules for balances, withdrawals, VIP, referrals, levels, and other bot functions.

### 20-7. Nikague nini ikiwa “kila kitu kinaonekana kimevunjika”?

Kagua vitu vitatu: 1) Wallet — je, imeunganishwa na main wallet imechaguliwa, 2) mizani na history — je, kuna alama ya operation yako humo, 3) sehemu unayohitaji (Panels / Energy / Exchange / Withdraw). Kwa kawaida jibu hupatikana katika moja ya sehemu hizi.

### 20-8. Njia ya haraka zaidi ya kuelewa kilichotokea kwa EFHC zangu ni ipi?

Fungua history ya balance. History huonyesha ni nini hasa kilibadilisha mizani: reward, purchase, exchange, au withdraw.

### 20-9. Nianzie wapi ikiwa nimefungua bot kwa mara ya kwanza na sielewi chochote?

Anza na Energy (skrini kuu), kisha fungua Panels, angalia mizani na history, halafu ndiyo uamue kama unahitaji Wallet na top up.

### 20-10. Ni njia gani ya haraka zaidi ya kupata swali ninachohitaji ndani ya FAQ?

Njia ya haraka zaidi ni kufungua sehemu inayohusiana na mada (Wallet / Panels / Exchange / Withdraw n.k.) na kutafuta swali humo. Usipokuwa na uhakika, anza na sehemu ya FAQ / Msaada na ujielekeze kwa maneno muhimu.
