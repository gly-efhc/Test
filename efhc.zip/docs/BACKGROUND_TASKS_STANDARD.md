# BACKGROUND TASKS STANDARD

Единый стандарт для `asyncio.create_task()` и фоновых циклов.

## MUST

- каждая задача получает понятное имя;
- каждая задача логирует исключение через done-callback;
- `CancelledError` считается нормальным завершением;
- follow-up после фоновой ошибки должен быть виден в логах;
- запрещена тихая смерть фоновой задачи.

## Технический канон

Использовать `app.core.async_tasks.create_logged_task()`.

## Контуры применения

- `backend/run.py`
- `backend/app/bot/states.py`
- scheduler / sync / background rebuild paths
