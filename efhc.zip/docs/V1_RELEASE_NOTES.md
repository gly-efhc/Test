# EFHC v171.69 release candidate notes

Status: local release candidate; live deployment is not yet proven.

## Included

- production FastAPI backend and Next.js frontend;
- centralized SchedulerService with eight canonical jobs;
- WalletProvider adapter architecture;
- standard PostgreSQL and Alembic migrations;
- provider-independent Docker Compose deployment;
- Caddy HTTPS proxy;
- backup, restore, restore drill and off-site synchronization;
- fail-closed database restore;
- versioned image rollback script;
- bounded Docker log rotation;
- Telegram webhook and domain-change tooling.

## Required after deployment

- real Docker build and container startup;
- public DNS and HTTPS;
- scheduler registration and execution evidence;
- real Telegram Mini App execution;
- TonConnect/TonProof or another approved WalletProvider adapter;
- controlled deposit, Browser Shop and withdrawal settlement;
- cross-provider restoration drill.
