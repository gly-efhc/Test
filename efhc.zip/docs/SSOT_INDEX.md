# SSOT_INDEX (EFHC) — индекс источников истины

## NORM: Абсолютный запрет удаления из артефакта

- MUST NOT: ИИ или разработчик не имеет права удалять/исключать какие-либо файлы или каталоги из артефакта проекта (ZIP `EFHC_Bot_v*.zip`) без явного письменного разрешения пользователя.
- MUST: Любое изменение состава артефакта фиксируется в `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` (что удалено/добавлено и зачем).
- MUST: Артефакт обязан содержать SSOT-документацию и реестр ошибок; отсутствие ловится guard-проверкой якорей (`ops/canon_guard.py` + `ops/canon_rules.yaml`: `artifact_anchors.required_paths`).


Статус: NORM.

Цель: сделать проект самодостаточным по смыслу и правилам без
зависимости от чатов.

SSOT = single source of truth.

---


## NORM: Артефакт проекта и имя ZIP (CI-истина)

- Рекомендуемый workflow-файл (шаблон): `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml`.

- SSOT: Источником истины в CI является **архив проекта** — файл `efhc.zip` в корне репозитория.
- MUST: В корне репозитория должен находиться **ровно один** `efhc.zip`.
- NOTE: Версионные сборки ИИ имеют имя `EFHC_Bot_v*.zip`, но в репозиторий они кладутся переименованными в `efhc.zip`.
- MUST: CI распаковывает `efhc.zip` в `extracted/` и проверяет только его содержимое (backend/frontend/tests/ops/docs/реестр).

## 1. Правило приоритета

Если два документа или код противоречат друг другу, применяется
следующий порядок (от более сильного к более слабому):

1) Этот индекс (SSOT_INDEX).
2) NORM-документы.
3) Runtime-код (backend/app, ops, frontend) и тесты.
4) DERIVED-документы.

Если конфликт не разрешается, запрещено "угадывать". Нужно:
- зафиксировать конфликт в ADR (docs/ADR/)
- обновить NORM и/или код так, чтобы конфликт исчез

---

## 2. Список документов и статус

### 2.1 NORM (нормативные)

1) docs/SSOT_INDEX.md
   - определяет приоритет и статусы документов

2) docs/EFHC_CANON.md
   - канон продукта: tg_id, экономика, банк, транзакции, выводы,
     TON/memo, события, запреты

3) docs/TERMS_GLOSSARY.md

- docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md (SSOT: Exchange/Withdraw)
   - каноничные термины и список запрещённых слов
   - включает next_cursor/encode_cursor/decode_cursor/CursorPage
   - единственное разрешённое место, где запрещённые слова могут
     встречаться в явном виде (как словарь)
   - это исключение фиксируется в ops/canon_rules.yaml


- docs/PANELS_SSOT.md (SSOT: Panels)
   - каноничная модель панелей: global public_id
   - срок 180 дней (UTC), Active/Archive, idempotency, audit
   - server_now_utc для таймера
4) docs/ARCHITECTURAL_LOCKS.md
   - норматив для разработки: архитектурные ограничения и инварианты

5) backend/app/core/system_locks.py
6) docs/TELEGRAM_WEBAPP_INTEGRATION.md
   - канон интеграции Telegram WebApp: ready/theme/buttons
   - Telegram Theme Tokens (канон): --tg-* vars и маппинг
   - запрет CloudStorage для финансов/статусов, guard-требования
   - исполняемые инварианты системы (runtime locks)

7) docs/TESTS_CATALOG.md
   - каталог всех тестов проекта (общая нумерация, группы)
   - для каждого теста: описание в 3 строки
   - MUST: любой новый тест добавляется в этот документ

8) docs/WALLETS_TONCONNECT_SSOT.md
   - канон привязки TON-кошельков к tg_id через TonConnect
   - WalletGate для deposit/shop external/withdraw/lotteries
   - запрет CloudStorage для wallet state

### 2.2 DERIVED (производные)

1) docs/architecture.md
   - объяснения и примеры архитектуры
   - не вводит новых правил

2) docs/specification.md
   - примеры API/поведения
   - не вводит новых правил

3) docs/API_REFERENCE.md
   - гид по API
   - не вводит новых правил

4) docs/DB_SCHEMA.md
   - обзор схемы
   - не вводит новых правил

Другие документы без явной пометки статуса считаются DERIVED.

---

## 3. Якоря смысла

- Канон идентификатора пользователя: docs/EFHC_CANON.md
- Термины и запретные слова: docs/TERMS_GLOSSARY.md

- docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md (SSOT: Exchange/Withdraw)
- Архитектурные ограничения разработки: docs/ARCHITECTURAL_LOCKS.md
- Исполняемые инварианты runtime: backend/app/core/system_locks.py
- Telegram WebApp theme tokens:
  docs/TELEGRAM_WEBAPP_INTEGRATION.md

---

## 4. Правило изменений

- Любая новая норма добавляется только в NORM-документ.
- DERIVED-документы могут содержать только пояснения и примеры.
- Любая правка NORM должна сопровождаться обновлением guard/тестов,
  если они должны это фиксировать.

- **FULL‑ARTIFACT GUARD (MUST):** артефакт efhc.zip обязан содержать `docs/` и `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`; это проверяется тестом (удалённый тест артефакта).

## NORM: Общие логи изменений (reports/)

- MUST: Все подробные отчёты циклов хранятся в `reports/`.
- MUST: Каждый цикл создаёт новый отчёт в `reports/`.
- MUST: `docs/TESTS_CATALOG.md` поддерживается актуальным.

## Канон сборки efhc.zip (clean → guard → zip)

- Скрипт сборки: `ops/build_efhc_zip.sh` (запуск из корня репозитория).
- Порядок: clean → `python ops/canon_guard.py` → сборка FLAT `efhc.zip` → post-pack проверки.
