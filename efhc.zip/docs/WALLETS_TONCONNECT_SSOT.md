# WALLETS + TONCONNECT SSOT

## Термины

- **tg_id** — единственный идентификатор пользователя.
  Источник: только Telegram initData (server-validated).

- **wallet_connected** — у tg_id есть минимум 1 активная привязка
  TON-кошелька.

- **Deposit (Пополнить EFHC, on-chain)** — операция, требующая
  TonConnect и WalletGate. Каноничный endpoint:
  `POST /deposit/efhc`.

- **Shop external (TON/USDT)** — внешняя покупка через TON сеть,
  требует TonConnect и WalletGate. Endpoint:
  `POST /shop/order-external`.

- **Shop internal (за EFHC, off-chain)** — внутренние списания EFHC.
  TonConnect не обязателен, если отдельно не закреплено иначе.
  Каноничный endpoint: `POST /shop/purchase-efhc`.

## Источник истины

- UI не решает, подключён ли кошелёк.
- UI запрашивает статус через `GET /wallets/me`.

## WalletGate (server-side MUST)

До TonConnect запрещены операции:

1. `POST /deposit/efhc`
2. `POST /shop/order-external`
3. `POST /withdraw/request`
4. `POST /lotteries/{id}/buy`

При запрете сервер возвращает:

- HTTP 403
- `code = WALLET_REQUIRED`
- `details.feature` = имя фичи

Важно:

- `POST /shop/purchase-efhc` — shop_internal (off-chain) и не
  должен возвращать `WALLET_REQUIRED` по умолчанию.

## Семантика endpoints и details.feature

Норма: `details.feature` используется **только** в ответе
`403 WALLET_REQUIRED` и не должен подменять семантику endpoint.

- `POST /deposit/efhc`
  - семантика: Deposit EFHC (on-chain покупка EFHC)
  - WalletGate: да
  - details.feature: `deposit`

- `POST /shop/order-external`
  - семантика: Shop external (TON/USDT on-chain)
  - WalletGate: да
  - details.feature: `shop_external`

- `POST /withdraw/request`
  - семантика: Withdraw (только MAIN)
  - WalletGate: да
  - details.feature: `withdraw`

- `POST /lotteries/{id}/buy`
  - семантика: Lotteries buy/join (on-chain)
  - WalletGate: да
  - details.feature: `lotteries`

- `POST /shop/purchase-efhc`
  - семантика: Shop internal (за EFHC, off-chain списание)
  - WalletGate: нет
  - details.feature: не применяется
`403 WALLET_REQUIRED` и не должен подменять семантику endpoint.

## A+B контур on-chain оплаты (Payment Intents)

Источник истины — сервер.

1) WebApp делает запрос на создание intent (Idempotency-Key обязателен):

- Deposit: `POST /deposit/efhc` (body: package_id)
- Shop external: `POST /shop/order-external`

2) Сервер создаёт/возвращает `payment_intent` и отдаёт TonConnect tx.

### Assets: TON и USDT (TON jetton)

Поддерживаются assets:

- `TON` — обычный перевод TON на адрес получателя.
- `USDT` — jetton transfer в TON сети.

Каноничные настройки (ENV / Settings):

- `PAYMENTS_RECEIVER_ADDRESS` — адрес получателя on-chain оплат.
- `USDT_JETTON_MASTER_ADDRESS` — master address USDT jetton.
- `JETTON_TRANSFER_FEE_NANO` — TON fee для jetton transfer сообщения.

Для `USDT` каноничный payload передаётся как **forward payload** в
jetton-transfer. Watcher допускает payload как отдельную строку
`EFHC:...` или как подстроку (например `FORWARD_PAYLOAD=EFHC:...`).

Watcher матчится на **каноничный payload** `EFHC:...` и проверяет asset,
адрес назначения и сумму.

3) WebApp вызывает `tonconnect.sendTransaction(tx)`.

4) Watcher подтверждает оплату по входящей транзакции TON:

- извлекает memo/comment
- матчится на `payment_intents.payload`
- атомарно переводит intent в CONFIRMED
- выполняет side-effects:
  - deposit_efhc: кредит MAIN (main_balance)
  - shop_external: заказ PAID_AUTO (+ EFHC_PACKAGE → кредит MAIN)

Инварианты подтверждения:

- Один `external_tx_hash` не может подтверждать два разных intent.
- Повторный confirm для одного и того же intent — no-op (без повторного
  начисления).

### Unmatched incoming (без payload) — без автоначисления

Если входящая on-chain транзакция пришла на адрес получателя проекта, но её
memo/comment **не содержит** каноничный payload `EFHC:<purpose>:<intent_id>:<tg_id>`
или payload не матчится ни на один существующий intent, то автоначисление
запрещено.

Watcher обязан:

- записать строку в `unmatched_incoming` (idempotent по `tx_hash`)
- финализировать обработку как `pending_manual`

Это гарантирует, что "непонятные" переводы не начисляются пользователю
автоматически.

### Статусы и UX "ожидание подтверждения"

Статусы intent:

- `SENT` — сервер выдал TonConnect tx (готово к оплате).
- `CONFIRMED` — watcher подтвердил оплату.

Для UX polling истины используется owner-only endpoint:

- `GET /payment-intents/{intent_id}`

Ответ включает `status`, `asset`, суммы, `created_at`, `expires_at` и
`external_tx_hash` (после CONFIRMED).

### Каноничный payload

Формат фиксирован (обязателен для watcher match):

`EFHC:<purpose>:<intent_id>:<tg_id>`

Пример:

`EFHC:deposit_efhc:12345:99887766`

Норма: payload задаётся **сразу финальным при создании intent**. Запрещены
временные placeholder вида `EFHC:<purpose>:0:<tg_id>` — они ломают
`UNIQUE(payload)` и делают невозможным сценарий "2 платежа = 2 пополнения".

## API: /wallets/*

### GET /wallets/me

Возвращает список привязок и `is_connected`.

### POST /wallets/connect

- Требует `Idempotency-Key`.
- Привязывает `address` к tg_id.
- Идемпотентность: сервер фиксирует `Idempotency-Key` и повтор
  возвращает тот же результат (wallet_id).
- Глобальная уникальность: один address не может принадлежать
  двум tg_id.
- Конфликт (адрес у другого tg_id): `WALLET_CONFLICT`.

### POST /wallets/{wallet_id}/make-primary

Делает кошелёк primary для tg_id.

### DELETE /wallets/{wallet_id}

Деактивирует привязку.

## CloudStorage (MUST NOT)

Запрещено хранить как "истину":

- wallet, wallets, address, connected, tonconnect

CloudStorage допускается только для UI-настроек.

## TonProof

TonProof предусмотрен архитектурно, но включается отдельным циклом.
