<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# RECONCILIATION RUNBOOK

## Назначение
Реконсиляция (сверка) — это **контролируемая** процедура проверки
расхождений между:
- учётом EFHC в базе (балансы/логи),
- поступлениями/списаниями по провайдерам (TON/USDT),
- внутренними транзакциями (hold/refund/commit).

Этот документ — запуск без догадок: симптомы → проверки → действия →
откат → постмортем.

---

## Symptoms (что видит оператор)
1) **Баланс банка EFHC** не сходится с суммой операций.
2) **Покупка/списание** прошла у провайдера, но в EFHC не зафиксирована
(или наоборот).
3) **Заявки на вывод** зависают в статусе/не переходят в paid.
4) В админке/дашборде появляются **отрицательные/аномальные** суммы.

---

## Checks (проверки)

### 1) Проверить здоровье схемы и инвариантов
HTTP:
- `GET /api/health` (должно вернуть ok)
- `GET /api/health/db` (проверка PostgreSQL + canonical schema status)
- `GET /api/health/runtime` (runtime/scheduler status)

### 2) Сверка баланса банка EFHC
SQL (PostgreSQL):
```sql
-Каноничный источник: efhc_core.bank_balances
SELECT *
FROM efhc_core.bank_balances
WHERE bank_key = 'EFHC_MAIN'
LIMIT 1;

-Логи операций банка (проверить последние N)
SELECT id, created_at, op_type, amount, balance_after, details
FROM efhc_core.efhc_transfers_log
ORDER BY id DESC
LIMIT 200;
```
Инварианты:
- `amount` в d8 (Decimal(30,8), ROUND_DOWN)
- `balance_after` = предыдущий баланс + amount

### 3) Сверка пользовательских балансов
```sql
-Балансы пользователей
SELECT global_id, balance_main, balance_bonus, updated_at
FROM efhc_core.user_balance
ORDER BY updated_at DESC
LIMIT 200;

-Логи пользовательских операций
SELECT id, global_id, op_type, amount, balance_after, details, created_at
FROM efhc_core.efhc_transfers_log
WHERE global_id = :global_id
ORDER BY id DESC
LIMIT 200;
```

### 4) Сверка withdraw (единый контур)
```sql
SELECT id, global_id, amount, status, hold_tx_id, refund_tx_id,
paid_tx_hash, created_at
FROM efhc_core.withdraw_requests
WHERE status IN ('pending','approved','paid','rejected')
ORDER BY id DESC
LIMIT 200;
```
Инварианты:
- Минимум вывода: **10 EFHC** enforced на бэке.
- hold/refund/commit выполняются только через каноничный сервисный контур денежных операций.

### 5) Проверка идемпотентности
Для денежно-опасных POST должен быть Idempotency-Key.
- MUST список путей: `active canon / guards / tests layer ->
- idempotency.must__path__patterns`
- Guard обязан валить сборку при нарушении.

---

## Actions (действия)

### A) «Пропала» операция провайдера (TON/USDT)
1) Найти событие у провайдера (tx_hash / event_id / delivery_id /
update_id).
2) Проверить, не было ли уже обработано:
   - таблица processed external events (dedupe)
3) Если не обработано — выполнить **контролируемый replay**:
   - через админ-ручку/скрипт, который:
     - создаёт внутреннюю запись события,
     - проводит транзакцию в едином контуре,
     - пишет admin log.

### B) Баланс банка не сходится
1) Определить диапазон расхождения по `bank_logs`.
2) Найти операцию-источник (withdraw/purchase/referral/etc.) по
`details`.
3) Исправлять **не вручную в таблицах**, а через каноничную команду:
   - либо корректирующая транзакция банка,
   - либо корректирующая транзакция пользователя,
   - с обязательным логированием.

### C) withdraw завис в статусе
1) Проверить `withdraw_requests` и связанные `hold_tx_id/refund_tx_id`.
2) Если hold отсутствует — это баг транзакционного контура, не трогать
руками:
   - выполнять repair через transactions_service (commit/rollback)
3) Если оплата фактически выполнена — поставить paid только через
админ-операцию
   (она пишет tx_hash и admin log).

---

## Rollback (откат)
Откаты делаем **через транзакционный контур**, а не SQL руками:
- Refund/rollback: только через transactions_service (создаёт
- refund_tx).
- Повторная обработка внешних событий: только если dedupe отсутствует.

---

## Postmortem (после инцидента)
1) Зафиксировать первопричину (контракт/SSOT/guard/test).
2) Добавить:
   - правило в `active canon / guards / tests layer`
   - проверку в `active guard layer`
   - регрессионный тест в `tests/`
3) Обновить этот runbook: что обнаружили, что улучшили.


## Exchange / Withdraw: сверка по audit

Источник нормы:
- docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

### EXCHANGE_ALL

Проверяйте audit.extra_info:

before:
- total_generated_kwh_before
- exchanged_kwh_total_before
- available_kwh_before (derived)
- main_balance_before
- total_equivalent_before

after:
- total_generated_kwh_after
- exchanged_kwh_total_after
- available_kwh_after (derived)
- main_balance_after
- total_equivalent_after

Инвариант:
- invariant_ok == true
- total_generated_kwh_after == total_generated_kwh_before
- total_equivalent_after == total_equivalent_before

### WITHDRAW

Проверяйте audit.extra_info:

- amount
- min_amount = 10.00000000
- main_balance_before / main_balance_after
- статус операции (success/rejected/error/replay)

Важно:
- lifetime total_generated_kwh не участвует и не меняется.


## Operational health boundaries

- `/api/health` — общий application health.
- `/api/health/db` — составной DB + schema status, HTTP transport может оставаться 200 при `ok=false`.
- `/api/health/db-schema` — отдельная DevOps-проверка схемы БД.
- `/meta/health_db` — строгий DB readiness probe: при недоступной PostgreSQL возвращает HTTP 503.
