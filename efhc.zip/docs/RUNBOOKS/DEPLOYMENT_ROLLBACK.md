# EFHC Docker Compose deployment and rollback

Status: active VPS runbook for release v171.69.

## Deployment model

The release uses standard Docker Compose services:

`PostgreSQL → backend → frontend → Caddy`.

There is no rolling-update or orchestration-cluster claim. Compose
updates one service at a time and the proxy is updated last.

## Before deployment

1. Verify the release ZIP and `SHA256SUMS`.
2. Create `.env` from `.env.example`, remove placeholders and use mode
   `600`.
3. Confirm Docker access with `docker info`.
4. Confirm versioned values for `EFHC_BACKEND_IMAGE` and
   `EFHC_FRONTEND_IMAGE`.
5. Confirm sufficient disk space for the current images, previous images
   and a new PostgreSQL backup.

## Safe deployment sequence

Run `./scripts/release/deploy.sh`.

The script performs:

1. release layout and `.env` validation;
2. Docker Compose validation;
3. build of new versioned backend and frontend images;
4. mandatory pre-update PostgreSQL backup when a database container
   already exists;
5. PostgreSQL health verification;
6. one-shot Alembic migration;
7. backend update and health verification;
8. frontend update and health verification;
9. proxy update and verification;
10. local smoke checks.

The script stops immediately on the first failed stage.

## Application image rollback

Use only when the previous database schema remains compatible:

```text
./scripts/release/rollback_images.sh \
  efhc-backend:PREVIOUS \
  efhc-frontend:PREVIOUS \
  --confirm
```

The previous images must exist on the host. The script updates backend,
then frontend, then proxy, with health verification after each service.

## Database restore

Use the pre-update dump only with explicit approval:

```text
./scripts/release/restore_postgres.sh BACKUP.dump --confirm
```

The restore script:

- verifies the dump checksum;
- stops backend, frontend and proxy;
- recreates the target database;
- restores with `pg_restore --exit-on-error`;
- applies Alembic migrations;
- starts services only after successful restoration.

On any restore failure, application services remain stopped. Inspect the
error and database state before another attempt. The script never starts
traffic on an empty or partially restored database.

## Rollback decision

Rollback or freeze traffic when:

- readiness does not recover within the deployment timeout;
- migration fails;
- scheduler startup fails or required jobs are missing;
- settlement truth differs from on-chain evidence;
- duplicate-credit protection fails;
- restore or backup integrity cannot be established.
