# EFHC observability incident response

## First screen

Use Admin Diagnostics. Review the sticky security and runtime posture:

- readiness;
- dependency audit;
- security headers;
- log redaction;
- rate limits;
- legal copy;
- request count and p95 latency;
- immutable image status;
- critical finding IDs.

## High 5xx ratio

1. Stop deployment changes.
2. Check readiness and PostgreSQL.
3. Review only redacted log summaries.
4. Compare build SHA and image digest with provenance.
5. Start rollback preflight when the release is implicated.

## High latency

1. Compare p95 and p99.
2. Check PostgreSQL locks and connection saturation.
3. Check watcher workload and external RPC latency.
4. Avoid repeated user monetary mutations.
5. Scale only after identifying the constrained resource.

## Stale watcher

1. Treat new automatic money reconciliation as unsafe.
2. Confirm scheduler configuration and heartbeat age.
3. Inspect the last successful reconciliation marker.
4. Use an operator action only through the guarded Admin flow.
5. Do not manually edit ledgers or database rows.

## Privacy

Incident evidence must not contain raw InitData, wallet proofs,
signatures, private keys, seed phrases, authorization headers, cookies
or unnormalized identifiers.
