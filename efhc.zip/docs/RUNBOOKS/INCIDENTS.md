# INCIDENTS RUNBOOK

Status: active operational runbook.

## Minimal first response

1) Проверить `/system/health` и связанные health endpoints.
2) Проверить application/runtime logs и последний change report.
3) Проверить advisory locks и фоновые контуры.
4) Для внешних TON событий запускать controlled replay/reconciliation только
   через каноничные инструменты и скрипты, а не ручным SQL.
5) Любое отклонение фиксировать в Healer / reports / change report.

## Current canon note

Этот runbook должен читаться вместе с:
- `docs/NORM/TASKS_STANDARD.md`
- `docs/NORM/SECURITY_EXCEPTIONS_REGISTER.md`
- `docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`
- `docs/SSOT/BANK_CANON.md`
