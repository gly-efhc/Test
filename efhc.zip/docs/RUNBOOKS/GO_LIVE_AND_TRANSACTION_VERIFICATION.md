# Go-live and controlled transaction verification

Status: active post-deployment checklist.

## Technical deployment gate

Require all of the following:

- release ZIP and checksums verified;
- `.env` mode is `600`;
- PostgreSQL backup completed;
- backend and frontend images built from the exact release;
- Alembic migration succeeded;
- backend, frontend and proxy healthchecks are healthy;
- scheduler log confirms all eight canonical jobs registered;
- public application and API URLs respond through HTTPS;
- Telegram webhook status is correct.

## Controlled Telegram and wallet gate

Use an authorized test account and minimal values:

1. validate Telegram `initData` on backend;
2. connect through the selected `WalletProvider` adapter;
3. complete a unique and time-limited TonProof;
4. reconcile one minimal deposit exactly once;
5. complete one Browser Shop payment;
6. complete one minimal withdrawal;
7. retry requests and events to prove no double credit;
8. compare public transaction hash, backend operation identity, history
   and Admin settlement state.

Never record a seed phrase, private key, bot token or complete proof
payload in an operator report.

## Public release gate

Public GO requires technical deployment, backup, scheduler, Telegram,
wallet, transaction and rollback checks to pass. Otherwise keep access
restricted, repair the failed contour and repeat only that verification.
