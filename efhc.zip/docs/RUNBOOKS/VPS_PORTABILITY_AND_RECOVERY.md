# VPS portability and disaster recovery

Status: **ACTIVE / current pre-release recovery runbook**.

## Recovery objective

EFHC должен восстанавливаться на чистой Ubuntu 24.04 VPS без зависимости от
панели или managed database конкретного провайдера. Production topology:
PostgreSQL + backend + scheduler + frontend + proxy на одной VPS.

## Обязательный off-provider recovery set

Вне активного hosting account владелец хранит:

1. точный канонический release archive `EFHC_Bot_vNNN_NN.zip` и его `.sha256`;
2. выбранный canonical encrypted recovery artifact `*.tar.gz.enc` и его
   `.enc.sha256`;
3. backup passphrase отдельно от encrypted artifact;
4. доступ владельца к DNS и Telegram/BotFather.

Raw PostgreSQL dump, plaintext `.env` и незашифрованный recovery bundle не
являются retained owner backups: это только staging material внутри backup
процедуры.

## Создание и экспорт recovery backup

Production создаёт один encrypted recovery artifact на generation через
`scripts/release/create_encrypted_backup.sh`. На VPS сохраняются только 10
последних canonical encrypted generations в `/opt/efhc/backups/encrypted`.

Для off-VPS хранения владелец скачивает выбранные `.tar.gz.enc` и
`.tar.gz.enc.sha256` по SSH/SFTP на ПК или смартфон. Database backup через
Telegram не используется. Backup passphrase хранится отдельно и после initial
installation автоматически не регенерируется.

## New-server recovery sequence

1. Загрузить `EFHC_Bot_vNNN_NN.zip` и одноимённый `.sha256`; проверить внешний
   SHA-256 до распаковки.
2. Развернуть release tree штатной clean-install процедурой, но не запускать
   финансовый runtime до восстановления production state.
3. Загрузить выбранный `.tar.gz.enc`, его `.enc.sha256` и отдельно owner-held
   backup passphrase.
4. Выполнить `recover_encrypted_backup.sh` с `--confirm`. Recovery обязан
   fail-closed проверить ciphertext checksum, расшифровать bundle, проверить
   `MANIFEST.sha256`, единственный PostgreSQL dump и `pg_restore --list`.
5. Проверить подготовленный `.env.recovered`; установить production env с mode
   `600`. `recover_encrypted_backup.sh` сам production database не восстанавливает.
6. Выполнить отдельный `restore_postgres.sh <validated.dump> --confirm`.
7. Убедиться, что release database validation подтверждает current Alembic head
   `0001`, schemas `efhc_core`/`efhc_admin` и current ORM surface.
8. Выполнить local deployment verification; затем переключить DNS.
9. После DNS выполнить public verification и установить Telegram webhook.
10. Проверить backend, scheduler, watcher/settlement и encrypted-backup timer.

## Restore drill

Не реже одного раза в месяц `restore_drill.sh` должен использовать canonical
`.enc` и восстанавливать dump только в отдельные temporary PostgreSQL
container/network/volume. Production PostgreSQL cluster/volume не является
restore target для drill.

## Domain change

Если домены не меняются, меняется только DNS. При смене доменов:

```text
./scripts/release/change_domain.sh APP_DOMAIN API_DOMAIN
./scripts/release/deploy.sh
./scripts/release/set_telegram_webhook.sh
./scripts/release/post_move_verify.sh
```

После смены домена также повторяется TonProof domain verification и при
необходимости обновляются настройки BotFather.

## Sequential production update

Production update принимает только канонический archive name без описательных
суффиксов:

```text
./scripts/release/update.sh EFHC_Bot_vNNN_NN.zip EFHC_Bot_vNNN_NN.zip.sha256
```

Перед database-changing update `update.sh` обязан создать и проверить canonical
encrypted pre-update recovery artifact. `current` переключается только после
успешного deployment. Rollback приложения допускается только по manifest
compatibility; database restore никогда не выполняется автоматически.

## Cross-provider proof

Portability считается operationally подтверждённой только после отдельного
восстановления на replacement VPS из release archive + encrypted recovery
artifact + owner-held passphrase, успешной проверки PostgreSQL, HTTPS,
Telegram/WebApp, wallet proof и controlled transaction. Измеренное recovery time
фиксируется как evidence, а не предполагается заранее.
