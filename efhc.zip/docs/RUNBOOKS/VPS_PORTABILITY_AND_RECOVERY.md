# VPS portability and disaster recovery

Status: active release v171.90 runbook.

## Recovery objective

Restore EFHC on a clean Ubuntu 24.04 VPS from the release archive,
encrypted production configuration and PostgreSQL dump. The engineering
target for a small database is 30–90 minutes, excluding DNS propagation
and third-party outages.

## Required off-provider recovery set

Keep outside the active hosting account:

1. exact release ZIP and SHA-256 sidecar;
2. latest PostgreSQL custom-format dump and checksum;
3. encrypted production configuration bundle;
4. several recent generations;
5. documented DNS and Telegram ownership access.

## New-server sequence

1. Upload and verify the release archive.
2. Run `sudo ./scripts/release/install_server.sh`.
3. Reconnect SSH or run `newgrp docker`.
4. Restore `.env`, verify values and set mode `600`.
5. Run `docker compose up -d db`.
6. Restore PostgreSQL with
   `./scripts/release/restore_postgres.sh BACKUP.dump --confirm`.
7. Run `./scripts/release/post_move_verify.sh --local-only`.
8. Change DNS A/AAAA records.
9. Run public verification and register the Telegram webhook.
10. Observe scheduler, Telegram and settlement logs.

## Domain change

When domain names remain the same, change only DNS. When project domains
change, run:

```text
./scripts/release/change_domain.sh APP_DOMAIN API_DOMAIN
./scripts/release/deploy.sh
./scripts/release/set_telegram_webhook.sh
./scripts/release/post_move_verify.sh
```

Update BotFather settings and repeat TonProof domain verification.

## Cross-provider proof

Portability becomes operationally confirmed only after deployment on a
second provider using only the release and recovery set, successful
PostgreSQL restoration, HTTPS checks, Telegram launch, wallet proof and a
controlled transaction. Record the measured recovery time.


## Sequential production update

Upload the complete next release ZIP and its sidecar to `/opt/efhc/incoming`,
then run from the active release:

```text
./scripts/release/update.sh NEXT_RELEASE.zip NEXT_RELEASE.zip.sha256
```

The exact archive is retained under `/opt/efhc/archives`, the new tree under
`/opt/efhc/releases/VERSION`, and the active link changes only after a
successful deployment. Use `rollback.sh --confirm` only when the recorded
migration class is backward-compatible.
