# DTO INPUT CANON

Единый канон входящих DTO EFHC Bot.

## MUST

- входящие DTO должны наследоваться от `StrictIn` либо явно ставить
  `extra="forbid"`;
- неизвестные поля на входе запрещены;
- permissive DTO допустимы только для выходных схем и внутренних
  адаптеров.

## Источник

- `backend/app/schemas/common_schemas.py:StrictIn`

## Зачем

Это снижает риск mass assignment и скрытого мусора во входных данных.
