# P0 Security Repair Canon

Status: active security repair canon.

This document records the resolved security decisions after the P0 security
audit. It is a canon/planning layer. It does not claim that runtime repair is
complete.

## Current verdict

The active security verdict is `P0_RELEASE_BLOCKED` until the wallet proof and
cron secret blockers are repaired and re-audited.

The economic repair lane remains closed locally. The new blockers are security
blockers, not economic accounting regressions.

## Truth reconciliation

The latest archive in the working line is the CI-repaired HEAD after the
panel-dead-context cleanup. The audit title mentions the previous archive name,
but the audit body states that the actually inspected archive was the newer
HEAD. Therefore this canon treats the security audit as applicable to the
actual latest HEAD in the working line.

No release-ready claim may be made from this reconciliation alone.

## Answer Q1: canonical wallet binding

Production wallet binding must be TonConnect proof based.

Canonical production path:

- `backend/app/routes/wallets_routes.py`;
- `backend/app/services/wallets_service.py`;
- `backend/app/services/tonconnect_proof_service.py`.

A naked address-only bind is not a production security boundary. A wallet may
be treated as connected for wallet-gated money routes only after verified proof
of control has been accepted for the current authenticated `global_id`.

Legacy or memo-style wallet binding code is not allowed to unlock wallet-gated
money routes unless it is upgraded to the same verified-proof invariant or is
explicitly marked non-production/deprecated.

## Answer Q2: production entrypoint

Both application entrypoints must converge to the same security behavior.

The project must not rely on the statement that only one entrypoint is used in
production in order to leave the other entrypoint weaker. `backend/app/main.py`
and `backend/app/__init__.py:create_app` must not diverge on CORS, auth header,
admin header, docs exposure, cron, webhook, or production fail-fast behavior.

## Answer Q3: archive version truth

The security repair line continues from the latest actual HEAD. The audit file
is archived as audit evidence, but the working truth is the actual HEAD in this
archive line. If an older archive name appears in a prompt or audit title, it
is treated as a label mismatch unless a fresh diff proves a runtime difference.

## P0 blockers

### Wallet proof boundary

`/wallets/connect` must reject production binding without verified TonConnect
proof. The proof must be:

- bound to the authenticated `global_id`;
- bound to domain/host;
- TTL-bound;
- nonce/payload-token-bound;
- single-use or replay-safe;
- tied to the same address being bound.

Wallet-gated money routes must check verified binding, not naked address-only
binding.

### Cron control plane

`/cron/tick` must not be protected by a repository-known default secret.

Production/stage startup must fail fast if `CRON_SECRET` is empty, placeholder,
default, or too short. `env.prod.example` must contain a placeholder, not a
working secret.

## P2 security cleanup

After the P0 blockers:

- Telegram initData must fail closed when `auth_date` is missing;
- Telegram initData must fail closed when `auth_date` is non-numeric;
- the redactor must cover all production secret aliases;
- frontend runtime must stop emitting legacy security headers;
- compat CORS/header layers must not keep obsolete auth/admin headers as an
  active security model.

## Regression hardening

Before release, the archive needs active tests/guards for:

- all admin backend routes requiring `require_admin`;
- ownership on wallet/order/withdraw/payment intent routes;
- cron secret fail-fast and reject behavior;
- Telegram initData strict freshness;
- no legacy frontend auth/admin headers;
- redaction of production secret aliases;
- production docs/CORS safety;
- callback/webhook secret-before-dedupe behavior.


## Security P0 repair pass local repair status

Security P0 repair pass applied runtime repair for the two P0 blockers locally. This changes
runtime code, but it does not by itself create a release-ready verdict.

Current status after the security P0 repair pass:

- wallet proof boundary: locally repaired, repeat security audit pending;
- cron control plane: locally repaired, repeat security audit pending;
- active release status: not release-ready until re-audit confirms.

### Wallet proof boundary after repair

Production `/wallets/connect` must include TonConnect proof data and the backend
must call `tonconnect_proof_service.check_proof()` before any wallet binding is
created or reactivated.

A wallet binding is wallet-gate eligible only when:

- `is_active = true`;
- `proof_verified = true`;
- the proof was checked against the authenticated `global_id`;
- the proof was checked against the same address being bound;
- the proof payload token has not been consumed with a different idempotency
  key.

Old active naked address rows are not sufficient for wallet-gated money routes.
They must be re-verified through the TonConnect proof flow.

### Cron control plane after repair

`CRON_SECRET` has no working default in code. In prod/stage, startup must fail
when the secret is empty, placeholder-like, shorter than 32 characters or equal
to the legacy repository-known default secret hash.

In local/dev/ci an empty cron secret may remain allowed for development and
unit tests, but prod/stage must fail closed.

## Security P2 replay / OPSEC / legacy-header pass local repair status

Security P2 repair pass applied local runtime repair for the remaining P2
findings from the active security audit. This changes runtime code and guards,
but it still does not create a release-ready verdict without repeat security
audit and CI evidence.

Current status after the security P2 repair pass:

- Telegram initData freshness: locally repaired;
- secrets redaction aliases: locally repaired;
- legacy frontend/admin headers: locally removed from production client and
  CORS compatibility layers;
- active release status: not release-ready until repeat audit confirms.

### Telegram initData freshness after repair

`auth_date` is mandatory. Missing, empty, non-numeric or expired `auth_date`
must fail closed before backend accepts Telegram WebApp identity.

### Secrets redaction after repair

The redactor must cover the production secret aliases used by EFHC Bot,
including bot token, JWT secret, admin API key, Telegram webhook secret, cron
secret and TON provider keys. Assignment-style secret fragments in logs must be
masked even when the exact value was not loaded into settings.

### Legacy headers after repair

Frontend runtime must not emit:

- `X-Telegram-User-Id`;
- `X-Admin-Id`;
- `X-Admin-Token`.

Backend CORS compatibility layers must not advertise those headers as active
security inputs. The only Telegram client identity source is
`X-Telegram-Init-Data`; admin access is enforced by backend `require_admin`.


## Security regression hardening status after the security regression pass

The security regression pass adds the guard layer required before repeat security audit. It does
not create a release-ready verdict by itself.

Active protected meanings:

- every backend `/admin/*` route must have backend `require_admin`;
- owner-scoped money routes must use authenticated Telegram identity and
  ownership-scoped service calls;
- production docs/OpenAPI/Redoc must be nullable/disabled through config;
- prod CORS with credentials must reject wildcard origin;
- Telegram webhook dedupe must run after `X-Telegram-Bot-Api-Secret-Token`
  validation, not before it.

Secret-protected webhook/callback routes must use
`register_external_event_after_secret()` only after source authentication.


## CI log repair note after security hardening

Security repair remains based on verified wallet binding and high-entropy cron
secret canon. The CI repair only synchronized guards/docs with the security
runtime changes and did not re-enable address-only wallet binding or default
cron secrets.


## Security minor findings after v170.08 repeat audit

The v170.08 repeat audit returned `SECURITY_SAFE_WITH_MINOR_FINDINGS`: no P0
findings, two P1 findings and one P2 finding. This local repair closes those findings.

### Ads callback test mode

`ADS_TEST_MODE` is a dev/test-only bypass. It must be false in prod/stage.
Settings must fail fast if prod/stage starts with `ADS_TEST_MODE=true`.

### Monetary rate-limit coverage

Monetary middleware default prefixes must cover:

- `/deposit`;
- `/payment-intents`;
- `/exchange`;
- `/panels`;
- `/shop`;
- `/withdraw`;
- `/admin`.

### Production env template OPSEC

`env.prod.example` must not contain real operational TON wallet addresses or NFT
collection addresses. It must use placeholders so operators inject real values
only through deployment environment secrets/configuration.
