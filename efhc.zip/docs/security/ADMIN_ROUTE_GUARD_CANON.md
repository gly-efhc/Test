# ADMIN_ROUTE_GUARD_CANON

Дата актуализации: 2026-08-08  
Цикл: 1705  
Статус: **ACTIVE SECURITY CANON**

## 1. Канонический принцип

Права администратора принадлежат EFHC-аккаунту с canonical `global_id`, а не
Telegram/TON/другому provider subject. Способ входа только аутентифицирует
пользователя и разрешается в существующий `global_id`.

Backend является единственным security-enforcement layer для admin-доступа.
Frontend не содержит публичного allowlist администраторов и не назначает роли.

## 2. Server-side admin access

Цепочка доступа:

`provider login -> server-side auth session -> global_id -> admin_whitelist.global_id -> explicit admin_role -> /admin/access`

`backend/app/deps.py::require_admin` обязан:

- требовать server-side auth session;
- брать canonical owner из session `global_id`;
- разрешать администратора через RBAC по `global_id`;
- отказать, если whitelist entry отсутствует/отключён;
- отказать, если явная RBAC-роль не назначена;
- не повышать роль автоматически до SuperAdmin.

## 3. Frontend admin button

`frontend/src/pages/_app.tsx` после обычной пользовательской auth-session вызывает
защищённый `GET /admin/access`.

- `200` -> admin button разрешена и `/admin/*` доступен;
- `401/403` -> admin button скрыта, прямой `/admin/*` блокируется и выполняется redirect;
- provider subject не участвует в решении о правах.

Legacy environment `NEXT_PUBLIC_ADMIN_TG_IDS` больше не является источником
admin rights и не используется runtime frontend для показа кнопки. Его остаточные
CI/Docker compatibility references подлежат отдельной чистке в утверждённых
циклах 1708–1709; canonical CI в цикле 1705 не перепроектируется.

## 4. RBAC

`admin_whitelist.global_id` определяет admin account, а `admin_role` хранит явную
роль. Whitelist без роли не предоставляет привилегий.

Допустимые DB roles: `superadmin`, `admin`, `support`, `auditor`; service layer
нормализует их в действующие уровни RBAC без изменения owner identity.

## 5. Первичное создание первого SuperAdmin

В текущем HEAD публичный bootstrap endpoint для создания первого SuperAdmin не
является утверждённой частью канона. Рекомендуемая операционная схема для
отдельного согласования — одноразовая server-side CLI-команда по SSH, которая
идемпотентно назначает конкретному `global_id` active whitelist entry и явную
роль `superadmin`, записывает audit evidence и не создаёт публичный bootstrap API.

До отдельного решения пользователя этот CLI считается **предложением, а не
реализованной функцией**.

## 6. Security invariants

- provider subject не является admin owner;
- `global_id` — единственный privileged owner;
- admin role всегда server-side и явная;
- frontend guard — UX boundary, не замена backend enforcement;
- withdrawal/admin routes не имеют fallback, искусственно назначающего SuperAdmin.
