# ADMIN_ROUTE_GUARD_CANON

Дата: 2026-05-27  
Цикл: 1329  
Статус: active security/frontend canon

## 1. Назначение

Admin pages не должны рендерить operator UI для не-admin пользователя даже если backend API защищён отдельно.

Backend остаётся главным security enforcement layer, но frontend обязан иметь UX/security boundary:

- не показывать структуру admin-панели обычному пользователю;
- не рендерить admin-компоненты на прямом URL `/admin/*`;
- выполнять безопасный redirect на `/`.

## 2. Реализация

Глобальный guard находится в:

`frontend/src/pages/app.tsx`

Проверяемые маркеры:

- `router.pathname === "/admin" || router.pathname.startsWith("/admin/")`;
- `data-admin-client-route-guard="1329"`;
- `router.replace("/")`.

## 3. Почему глобальный guard

В проекте 17 admin pages. Ручной guard в каждой странице создаёт риск пропуска при добавлении нового маршрута. Глобальный guard покрывает весь namespace `/admin` и `/admin/*`.

## 4. Граница безопасности

Frontend guard — не замена backend whitelist. Все admin API routes обязаны продолжать использовать `require_admin`.

`NEXT_PUBLIC_ADMIN_TG_IDS` остаётся только UI visibility allowlist. Оно публично по природе Next.js public env и не является секретом.
