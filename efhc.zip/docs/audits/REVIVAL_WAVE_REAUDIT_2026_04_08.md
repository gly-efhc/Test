# Revival wave re-audit — 2026-04-08

## What was connected
- `ExchangePanel.tsx` -> `pages/exchange.tsx` as partial exchange UI
- `ReferralsTabs.tsx` -> `pages/referrals.tsx` as shared navigation
- `AdsBanner.tsx` -> `pages/tasks.tsx` as active ads/tasks entry block
- `RanksTable.tsx` -> `pages/ranks.tsx` as top-preview widget
- `AdminCharts.tsx` -> `pages/admin/index.tsx`, `pages/admin/tasks.tsx`
- `AdminTable.tsx` -> `pages/admin/index.tsx`
- `admin_tasks_service.py` -> `POST /admin/tasks/refresh-statuses`

## Residuals after the wave
1. `efhc_deposits_service.py` still needs explicit runtime integration or a
   conscious operational entry point.
2. `orders_service.py` still sits in an overlap zone with the active shop
   runtime and requires a compare/transfer proposal.
3. The exchange page now has both all-exchange and partial-exchange controls;
   this is intentional for now, but future simplification can be proposed.

## Result
The files previously marked as semantically dead are no longer all detached.
The wave converted a major part of the frontend/admin layer from dormant
components into connected runtime surfaces without deleting any user-required
file.
