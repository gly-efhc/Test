# FAQ semantic approval gate audit — v169_51

Date: 2026-06-02
Mode: static semantic/document/code audit

## Verdict

PASS_WITH_LIMITATION.

The corrective v169_51 gate confirms that FAQ work must follow Q/A-first
semantic governance. It also repairs two residual Wallet FAQ drift items that
remained after v169_50.

## Confirmed user rule

- Q/A register and direct user decisions have priority.
- Russian FAQ/SSOT is the canon when it matches Q/A.
- SSOT may regress, so it must be checked against Q/A before being trusted.
- English and all other languages translate from the approved Russian meaning.

## Repaired residual issues

- Item 48 / section 5-7: non-RU layers were still about changing the primary
  wallet; repaired to the RU/Q&A meaning about using the wallet in another
  account.
- Item 51 / section 5-10: non-RU layers were still about playing without a
  wallet; repaired to the RU/Q&A meaning about checking which wallet is linked.

## Non-claims

- No GitHub CI green claim.
- No full human linguistic certification.
- No browser screenshot claim.
- No unrelated FAQ rewrite authorization.
