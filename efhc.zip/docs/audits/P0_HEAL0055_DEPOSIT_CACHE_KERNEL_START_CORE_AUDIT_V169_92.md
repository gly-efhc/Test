# P0 HEAL-0055 deposit-cache DB idempotency + Kernel Start Core audit

Archive: `v169.92`
Cycles: `1411-1412`
Status: DONE / targeted repair
Date: 2026-06-04

## Scope

This cycle continues from `v169.91` and covers:

- `HEAL-0055` deposit duplicate protection;
- Operator Kernel mandatory Start Core preload;
- Kernel cache freshness warning;
- root `KERNEL.md` marker.

## HEAL-0055 verdict

Deposit duplicate protection now has a durable DB-backed layer:

- service: `backend/app/services/efhc_deposits_service.py`;
- table/model: `efhc_admin.idempotency_key` / `IdempotencyKey`;
- scope: `deposit:efhc`;
- key: canonical `deposit:efhc:<tx_hash>` or sha256 digest fallback when the raw key would exceed 128 chars;
- retention: `expires_at = NULL` for long-retention deposit records;
- response read-through: cached `response_payload_json` is returned on replay after the first completed processing.

The old risk was process-local duplicate protection such as `_ttl_seen`. Current targeted runtime files do not use `_ttl_seen` as a monetary/deposit source of truth.

## Runtime repair

Changed files:

- `backend/app/services/efhc_deposits_service.py`
- `backend/app/services/transactions_service.py`
- `ops/operator_kernel/file_map.py`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`

Added root marker:

- `KERNEL.md`

Added guard:

- `tests/architecture/test_heal0055_deposit_idempotency_kernel_start_core.py`

## Kernel verdict

Operator Kernel is now mandatory in Start Core navigation:

- Start Core includes Kernel preload;
- topic routes and synaptic links define Kernel as mandatory navigation;
- root `KERNEL.md` explains how to preload file map and routes;
- `file_map.py` supports `--refresh` and warns when `file_map.json` is missing or older than 7 days.

## Boundaries

Not changed:

- EFHC economics;
- frontend UI;
- wallet/TonConnect logic;
- CI/workflow files;
- package/lock files;
- AI Archive Laws.

Sandbox was used only as reference/navigation layer. Runtime code was not imported from sandbox.
