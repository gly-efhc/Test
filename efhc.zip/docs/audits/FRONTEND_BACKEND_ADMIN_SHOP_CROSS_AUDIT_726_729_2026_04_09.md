# FRONTEND / BACKEND / ADMIN / SHOP CROSS AUDIT
## Cycles 726-729 · 2026-04-09

## Scope
- backend routes ↔ frontend pages
- backend routes ↔ admin panel
- backend routes ↔ shop surfaces
- table coverage vs implemented functions
- visual and functional white spots across frontend pages
- donor review: `ui-main`, `refine-main`, `horizon-ui-chakra-nextjs-main`, `Песочница.zip`

## Confirmed fixed mismatch in this wave
### Admin referrals page
A real route/payload drift was present in `frontend/src/pages/admin/referrals.tsx`:
- frontend used `/api/admin/referrals/...`
- backend route prefix is `/admin/referrals/...`
- frontend payload keys did not match backend schemas:
  - `amount_efhc` was sent instead of `amount`
  - `child_global_id` / `new_parent_global_id` did not match
    `invitee_global_id` / `new_inviter_global_id`
  - `note`/`reason` semantics were mixed

Fixed in this wave:
- route prefix aligned to `/admin/referrals/...`
- payload names aligned to backend schemas
- summary rendering switched from raw object dump to explicit
  inviter rows and operator totals

## Backend routes ↔ frontend pages
### Verified working route groups
- public user-facing pages:
  - `/hub/efhc-handoff`
  - `/shopfront/catalog`
  - `/shopfront/create-intent`
  - `/shopfront/intent-status`
  - `/shopfront/access-key`
  - `/withdraw/request`
  - `/deposit/efhc`
  - `/deposit/packages`
  - `/wallets/me`
- admin pages:
  - `/admin/reports/overview`
  - `/admin/ton/reconcile`
  - `/admin/shop/items`
  - `/admin/shop/orders`
  - `/admin/tasks/refresh-statuses`
  - `/admin/ads/providers`
  - `/admin/efhc-deposits/process`
  - `/admin/hub/links`
  - `/admin/hub/links/reorder`
  - `/admin/sale-packages/`
  - `/admin/referrals/summary`
  - `/admin/referrals/manual-bonus`
  - `/admin/referrals/reassign`

### Honest remaining route-level white spots
- there is still no single route-audit matrix document that maps every
  page to every backing route and marks production / helper / draft
  status explicitly
- several admin pages are visually stronger than before, but route health
  is still distributed across page code instead of one shared operator
  registry surface

## Backend routes ↔ admin panel
### Current strengths
- admin entry surface is no longer decorative
- `/admin/index` already reflects grouped modules and report counters
- admin shop now has real operator controls
- admin referrals is now route/schema-compatible

### White spots
- no unified admin route diagnostics page
- no explicit page-level route health badges for degraded/helper modules
- admin pages still rely on local knowledge of route semantics instead of
  one reusable diagnostics grammar

## Backend routes ↔ shop
### Current strengths
- shopfront catalog, access-key, create-intent and intent-status are in
  place
- watcher/payment-intent chain is hardened
- browser shop payment terminal slice is stronger
- admin shop operator flow is now materially stronger

### White spots
- no dedicated admin-visible route monitor for `shopfront` and watcher
  state in one screen
- NFT manual issue contour still depends on mixed order/admin flow rather
  than a dedicated operator work queue page

## Table coverage vs functions
### Good coverage already present
- `shop_items` covers catalog records
- `shop_orders` covers EFHC package and NFT order lifecycle
- `payment_intents` covers external intent tracking
- `ton_inbox_logs` and `unmatched_incoming` cover incoming chain events
- `wallet_bindings` covers wallet ownership binding
- `bank_balance`, `efhc_transfers_log`, `withdraw_requests`, `referral_*`
  tables cover the main economy and referral flows

### Honest schema white spots
- no dedicated persistent `shop_item_history` table:
  current field-level history in admin shop is UI/session-side, not DB
  audit history
- no dedicated media storage / upload asset table:
  current image upload flow is editor-side and content-side, not storage
  infrastructure
- no dedicated admin work queue table for manual NFT issue requests:
  current manual NFT flow is carried by `shop_orders` status semantics
- no unified page diagnostics table / snapshot for frontend↔backend route
  compatibility

## Visual and functional frontend white spots
### Public pages
- browser shop is much stronger, but explanatory microcopy and locale
  consistency can still be deepened
- hub/profile/storefront surfaces would benefit from a shared
  "facts + next step + state" grammar across all pages

### Admin pages
- referrals page is now functional, but still lightweight compared to
  bank/shop/reports surfaces
- admin pages still vary in density and component grammar
- a reusable admin diagnostics strip would improve confidence and reduce
  hidden route drift

## Donor-inspired expansion ideas (safe, EFHC-native)
- add a reusable route health strip for admin pages
- add per-page operator summary headers with route/data freshness facts
- add a dedicated manual NFT issue work queue page inside admin contour
- add persistent backend audit history for catalog item changes
- add a shared diagnostics/facts/footer grammar across hub, shop and
  profile

## Next strongest no-question extension candidates
1. admin referrals operator surface upgrade
2. shared admin route diagnostics strip
3. persistent backend-side shop item history model
