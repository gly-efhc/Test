# IDEMPOTENCY_CONCURRENCY_PROOF_2026_04_06

Статус: AUDIT / PROOF

## Назначение

Документ фиксирует доказательную базу для цикла 425/429:
concurrency/idempotency proof по денежным операциям после лечения
bank SSOT и conflict -> rollback -> read-through.

## Канон

- Единственное SSOT банка: `efhc_core.bank_balance`.
- `BANK_EFHC` допускается только как логический alias для mirror-log.
- Повторный вызов с тем же `idempotency_key` не должен менять балансы второй раз.
- Конфликт по `idempotency_key` должен вести к `rollback`, затем к `read-through`.

## Доказательные точки

### 1. Spend idempotency
- `tests/test_economics_transactions.py`
- `spend_user_to_bank_bonus_then_main`
- проверяется, что повтор с тем же `idempotency_key` оставляет
  user balances и `efhc_core.bank_balance` без повторного изменения.

### 2. Exchange all concurrency
- `tests/test_concurrency_exchange_all.py`
- проверяется, что два конкурентных вызова с одним ключом не дают
  двойного кредита и не ломают `available_kwh` / `exchanged_kwh_total`.

### 3. Exchange + withdraw concurrency
- `tests/test_concurrency_exchange_withdraw.py`
- проверяется, что exchange и withdraw при гонке не уводят систему
  в отрицательные пользовательские балансы и сохраняют инварианты.

### 4. Runtime bank invariants
- `tests/architecture/test_bank_runtime_invariants.py`
- проверяется, что дефицит банка отражается в `efhc_core.bank_balance`,
  а не в пользователе-банке.

## Что должен доказывать тестовый слой

- `efhc_core.bank_balance` меняется как единственная реальная система банка.
- повторный `idempotency_key` даёт `detail="idempotent"` без второго движения.
- mirror-log допускается, но не является реальным изменением bank-user balances.
- concurrency proof привязан к runtime-тестам, а не только к source-guards.
