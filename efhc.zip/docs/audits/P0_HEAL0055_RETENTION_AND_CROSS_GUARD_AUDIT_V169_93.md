# P0 HEAL-0055 retention + P0 cross-guard audit

Archive: `v169.93`
Cycles: `1413-1414`
Status: DONE / targeted repair
Date: 2026-06-04

## Scope

This pass continues from `v169.92` and covers:

- cycle 1413: `HEAL-0055` long-retention deposit idempotency policy;
- cycle 1414: P0 cross-guard consolidation across the repaired Red Zone lines;
- documentation and Healer/Atlas/Q&A alignment;
- Operator Kernel navigation refresh.

## Cycle 1413 verdict

Deposit idempotency is now explicitly marked as non-expiring at code and docs
level:

- `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"`;
- `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`;
- reserve/store paths use `expires_at=DEPOSIT_IDEMPOTENCY_EXPIRES_AT`;
- duplicate same-key/different-payload replay raises
  `idempotency_fingerprint_mismatch`.

This hardens `HEAL-0055` beyond the previous DB proof by making retention and
fingerprint conflict behaviour explicit.

## Cycle 1414 verdict

Added additive cross-guard:

- `tests/architecture/test_p0_cross_guard_consolidation.py`.

The guard checks identity, payment contract, schema width, idempotency conflict,
transaction-boundary, withdraw atomicity and deposit retention invariants in one
source-level regression layer. No previous guard was deleted or weakened.

## Boundaries

Not changed:

- EFHC economy;
- frontend UI;
- wallet/TonConnect logic;
- CI/workflow files;
- package/lock files;
- AI Archive Laws.

Sandbox was used only as reference/navigation layer. Runtime code was not
imported from sandbox.
