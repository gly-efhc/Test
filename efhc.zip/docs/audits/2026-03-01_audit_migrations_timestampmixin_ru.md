# Аудит: поломки миграций Alembic из‑за TimestampMixin и импортов (RU)

Status: INFORMATIONAL

## Исполнительное резюме
Основной класс поломок миграций — **ошибки импорта ORM-моделей** на этапе выполнения `0001_init.py`.
`0001` импортирует все `*_models.py`, и любая ошибка импорта валит `alembic upgrade head` ещё до `Base.metadata.create_all()`.

Критический кейс из CI-логов: **`ImportError: cannot import name 'TimestampMixin' from app.models`**.
Причина: `TimestampMixin` был определён в одном модуле (например, `tasks_models.py`), а импортировался из корневого пакета моделей (`app.models`), где его не было.

## Что должно быть по канону
1) Все импорты внутри `backend/app/**` должны работать при запуске из `cd backend` (верхний пакет = `app`, пакета `backend` нет).
2) Общие миксины (в т.ч. `TimestampMixin`) должны быть доступны из `app.models` (`backend/app/models/__init__.py`) — это делает импорт моделей в `0001` стабильным.
3) Запрещено `schema=` внутри `Index(...)` и `Column(...)`. Схема задаётся только на уровне таблицы (`__table_args__`).

## Рекомендованные исправления (канонично)
- Добавить/экспортировать `TimestampMixin` в `backend/app/models/__init__.py`.
- В моделях, где нужен миксин, импортировать его из `app.models`:
  `from . import Base, TimestampMixin`
- Удалить `schema=` из всех вызовов `Index(...)`.
- Зафиксировать класс ошибки в `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` (только по `logs_*.zip`).

