<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
# AUDITS — ACTIVE SURFACE

Статус: **ACTIVE INDEX**

Текущие аудиты создаются только на время незакрытого цикла. После
закрытия они перемещаются в
`docs/history/legacy_artifacts/docs/audits/`.

Исторический audit является evidence, но не CANON, SSOT или NORM.
