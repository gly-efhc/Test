# EFHC Audits — active surface

Активный раздел `docs/audits/` очищен 2026-04-08.

## Что оставлено

Оставлены только важные active-truth документы:
- strict head / re-audit / release-truth
- bank/idempotency/self-healing proof
- watcher/reporting residuals
- frontend sandbox / visual map docs kept for guard-layer continuity;
- CI-log to Healer transfer docs
- control-docs по audit-of-audits и reports retention
- imported external total audit compare docs.

## Что убрано

- старые superseded и wave-level audits удалены из HEAD-архива
  после переноса полезной памяти в Healer и после сохранения
  обязательных high-impact docs в активном слое;
- весь `_raw` evidence-слой удалён из HEAD-архива после
  переноса активной памяти в Healer и control-layer;
- уникальная память должна жить в Healer, а не только в архиве аудитов.

- 2026-04-17 corrective transfer: several obvious
  audit/release-evaluation documents were moved here from
  `docs/GENERAL/*` after document-layer cleanup.

## 2026-05-16 visual frontend audit v002

Added active visual frontend audit-of-audit and imported visual TZ / QA
memory for cycles 1195-1230.  The active repair scope is Direct Deposit,
HUB, Browser Shop layout and public diagnostics leakage.
