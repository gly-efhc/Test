# EFHC UserId / global_id audit — v171.94

The nullable physical `users.user_id BIGINT` column is present through
linear Alembic revision `0002`. Existing users are not backfilled and the
legacy runtime owner remains `global_id` until later migration stages.

Final semantic inventory:

- classified usage rows: `5272`;
- files with tracked usage: `665`;
- domain owner/actor rows: `2054`;
- ORM fields in the `global_id` family: `32`;
- service/function signatures: `336`;
- FastAPI routes: `143`; routes using `global_id`: `65`;
- semantic provider/system identity mix offenders: `0`.

TON Proof policy supports both existing-account resolution and creation of
a new `user_id`. Wallet connection alone is insufficient, conflicts fail
closed, and automatic merging of existing accounts is forbidden.
