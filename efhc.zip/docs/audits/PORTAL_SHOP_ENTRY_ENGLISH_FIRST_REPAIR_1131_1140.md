# Portal shop entry English-first repair — cycles 1131-1140

Date: 2026-04-27
Status: AUDIT / player-facing UX repair

## Finding

`frontend/src/features/shop/ShopEntryPage.tsx` still contained hardcoded
Russian explanatory strings in an active player-facing portal surface.
That contradicted the EFHC player-facing English-first canon.

## Treatment

- replaced the hardcoded Russian block with locale keys;
- added a compact flow block:
  - `portal.shop_entry.flow_title`
  - `portal.shop_entry.flow_description`
  - `portal.shop_entry.flow_step_access`
  - `portal.shop_entry.flow_step_shop`
  - `portal.shop_entry.flow_step_intent`
- fixed an incomplete continuity sentence for `pay_or_wait` so the player sees
  a clear next-action message.

## Песочница usage

`Песочница_full.zip` remained a separate donor source. Its usage map confirmed
that portal/shop surfaces should keep a clear handoff -> storefront -> payment
intent sequence. No donor code was copied.

## Release meaning

This is a real user-facing cleanup, not only a technical alias pass. The shop
entry surface is now closer to the release canon and better aligned with the
portal continuity model.
