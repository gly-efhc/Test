# Cycle 976 — panel activation edge-case audit

## Scope
- not enough balance;
- repeated activation attempts;
- latest state reflection after activation.

## Findings
- The panel page already reflected the activation canon and linked the user back to history and wallet.
- The surface still lacked a strict local pending guard for repeated activation clicks.
- The user-facing page did not clearly state the minimum EFHCm requirement at the point of action.

## Treatment
- Added bounded `activating` guard to the panel activation action.
- Disabled activation while processing.
- Added explicit player-facing note that panel activation needs at least `100 EFHCm`.

## Verdict
- The edge-case audit is absorbed without expanding panel functionality.
- This is a bounded runtime safety and clarity pass.
