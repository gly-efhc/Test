# SHOP PAYMENT TRUTH REPAIR 1191

## Finding

The road audit marked shop and payment roads as sensitive economic
roads.  A screen may show a completed action while the backend outcome,
status or payment truth is incomplete.

## Repair

The in-app shop order route now fails loudly when the service returns an
incomplete external order payload or a missing order id.  It no longer
returns a weak success response in those cases.

The Browser-Shop intent road now applies the same order-id guard before
linking the payment intent to the shop order.

The Browser-Shop intent status road now treats missing or non-owned
intent rows as 404 and removes the internal `ok` marker before building
the public response model.

## Proof anchors

- shop order is linked to `intent_payload` and `intent_id`;
- payment owner is stored as `payment_owner_global_id`;
- payment intent status is owner-only;
- shop external reconciliation uses tx hash lock;
- paid shop orders move to `PAID_AUTO` through the confirm path;
- flow truth is returned to the user surface.

## Guard

`ops/routes/check_shop_payment_truth.py` generated
`reports/generated/shop_payment_truth_1191.json` with status `ok`.

## Boundary

This cycle repairs the shop/payment truth road.  It does not claim
release readiness for every shop/admin/payment route in the project.
