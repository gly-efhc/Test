# FRONTEND CYCLES 1246-1250 LOG REPAIR — v168_43

Date: 2026-05-18
Source HEAD: v168_42
Fresh log: logs_69510727201.zip

## Scope

This pass continues the Dragon-style EFHC frontend repair range and
focuses on cycles 1246-1250:

- 1246: EFHC balance chip on the first Energy screen.
- 1247: HUB card as a clean bridge action.
- 1248: Profile/Wallet compact entry.
- 1249: Bottom menu remains canonical and unchanged.
- 1250: Guard for compact first-screen public action count.

## Confirmed log failures

The fresh CI log had one failing gate:

- pytest gate failed: 3 failed, 532 passed.

The failing checks were:

1. `test_shop_hub_truth_layer_sync_present` expected the WebProfile
   source to expose the active payment path surface marker.
2. `test_exported_openapi_matches_ssot_route_surface` showed drift
   between exported OpenAPI and `SSOT_ROUTES.csv`.
3. `test_web_profile_latest_outcome_surface_exists` expected the
   latest withdraw outcome surface marker in WebProfile.

Ruff, flake8, mypy, bandit, compileall, Alembic and npm build were green
in the supplied CI log.

## Repairs

### WebProfile payment and withdraw outcome surface

`frontend/src/features/profile/WebProfilePage.tsx` now keeps explicit
screen-reader surface markers for:

- active payment path;
- latest withdraw outcome.

The visible UI still uses locale keys, but the source surface is stable
for the architecture guards.

### OpenAPI / SSOT split

`SSOT_ROUTES.csv` is aligned with exported public OpenAPI routes.
Internal helper routes are moved to a separate registry:

- `docs/SSOT/ssot_pack/SSOT_INTERNAL_ROUTES.csv`

This preserves the important canon:

- `/cron/tick` and `/tg/webhook` are runtime internal/helper routes;
- they remain hidden from OpenAPI;
- they are still tracked in an internal SSOT registry.

The helper/internal guard was updated to verify the internal registry
instead of forcing internal routes into the public OpenAPI route surface.

### Energy first-screen polish

Energy now has four compact first-screen actions:

1. Panels activation.
2. Exchange kWh.
3. HUB.
4. Wallet/Profile.

Energy also has compact chips for:

- active panels;
- generation rate;
- EFHC balance;
- available kWh.

This closes the 1246-1250 visual foundation without changing the six
canonical bottom navigation buttons.

## Verification

Executed locally:

- failing log pytest pack: passed;
- route inventory/openapi/helper boundary pack: passed;
- full `tests/architecture` with `PYTHONPATH=backend`: 407 passed,
  7 skipped;
- new cycle 1246-1250 guard: 3 passed;
- `python3 -m compileall -q backend/app ops/routes tests/architecture`:
  passed;
- `python3 -m ruff check backend api ops tests`: passed;
- `npx tsc --noEmit --pretty false`: passed.

`npm run build` was attempted locally after `npm ci`, but timed out in
this environment during production build.  The supplied GitHub log for
v168_42 already showed npm build success, so this pass does not claim a
new full local build success.

## Release claim boundary

This archive is not declared final frontend 99% readiness.  It is a
log-driven repair and cycle 1246-1250 frontend polish step.
