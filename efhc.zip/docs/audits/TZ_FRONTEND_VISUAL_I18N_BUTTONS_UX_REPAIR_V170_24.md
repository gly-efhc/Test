# ТЗ на исправления Frontend Visual / I18N / Buttons / UX — EFHC Bot v170.24

**Основание:** аудит `P0_FRONTEND_VISUAL_I18N_BUTTONS_UX_AUDIT_V170_24.md`  
**Архив:** `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`  
**Режим ТЗ:** безопасное исправление выявленных визуальных/UX/i18n/button issues без изменения экономики и бизнес-логики.

---

## 0. Главные ограничения

Запрещено:

1. Менять экономику EFHC.
2. Менять бизнес-логику Panels, Exchange, Tasks, Referrals, Ranks, Withdraw, Shop без отдельного разрешения.
3. Менять backend contracts без отдельного разрешения.
4. Удалять кнопки вместо исправления их поведения/текста.
5. Удалять переводы вместо нормализации i18n.
6. Удалять тесты.
7. Менять CI/workflows/lock files без отдельного разрешения.
8. Скрывать P1/P2 проблемы как minor.
9. Оставлять raw enum/status/reason в runtime UI.
10. Оставлять debug/internal/helper/deferred/draft/read-only тексты в пользовательском UI.
11. Смешивать EFHC Site и EFHC Bot.
12. Использовать technical enum/status как пользовательский или операторский текст.

---

## 1. Цель ремонта

Довести EFHC Bot v170.24 до состояния, где:

```text
документы архива → канон UI → frontend route/page → component → button/action → backend/API call → translation key → rendered text → visual state → test/screenshot
```

не содержит подтверждённых P1/P2 visual/i18n/button drifts.

Главная цель — не переписать продукт, а **убрать технический вид из runtime UI**, исправить очевидные визуально-семантические ошибки и закрепить результат тестами.

---

## 2. Приоритеты ремонта

| Priority | Finding | Area | Expected outcome |
|---|---|---|---|
| 1 | F-01 | Panels countdown | Срок панели отображается математически корректно |
| 2 | F-02 | Tasks statuses | Пользователь не видит raw enum/status |
| 3 | F-05 | Withdraw history/outcome | Withdraw выглядит как финансовый экран, а не technical log |
| 4 | F-06 | Withdraw return target | После заявки пользователь попадает в history/account center |
| 5 | F-04 | Web Profile history | История баланса показывает human reason labels |
| 6 | F-07/F-08 | Admin Shop/Admin Withdrawals | Операторский UI русскоязычный и понятный |
| 7 | F-03 | Ranks fallback | Убран `browser-player` |
| 8 | F-09 | `/energy` docs drift | Docs/routes согласованы |
| 9 | F-10 | Screenshot proof | Есть реальный visual regression bundle |

---

## 3. Cycle A — Recheck critical buttons / routes

### Цель

Перед началом визуальных правок повторно подтвердить, что критические кнопки не являются fake UI и имеют связку:

```text
button → handler → API call → backend route → visual result
```

### Проверить кнопки

1. Panels: activate panel.
2. Exchange: convert kWh → EFHC.
3. Tasks: claim reward / complete action.
4. Withdraw: create request.
5. Withdraw: cancel request.
6. Shop: create payment/order intent.
7. HUB: Пополнить EFHC.
8. HUB: EFHC VIP NFT.
9. Admin Shop: archive/delete/bulk actions.
10. Admin Withdrawals: approve/reject/paid/cancel preview/actions.

### Что исправлять

Только если обнаружен drift после правок:

- broken import;
- missing handler;
- missing generated seam;
- wrong route path;
- button active without action;
- money button without loading/disabled repeat guard.

### Acceptance criteria

- Все критические buttons имеют handler.
- Все frontend API calls имеют backend route/openapi match.
- Денежные кнопки показывают loading/disabled при операции.
- Повторный клик не создаёт двойное действие.

### Required tests

- `test_all_visible_buttons_have_handlers`
- `test_all_frontend_api_calls_have_backend_routes`
- `test_no_dead_buttons_on_user_screens`
- `test_no_dead_buttons_on_admin_screens`
- `test_double_click_money_buttons_disabled`

---

## 4. Cycle B — I18N / raw enum / mixed language cleanup

### Цель

Убрать из runtime UI все raw enum/status/reason и смешанный RU/EN текст.

### B1. Tasks statuses

**Файл:** `frontend/src/pages/tasks.tsx`  
**Проблема:** `status` возвращается как есть.  
**Исправить:** создать human-readable mapping для всех task states.

Минимальные состояния для покрытия:

- `not_started`
- `pending_check`
- `approved`
- `auto_paid`
- `rejected`
- `claimed`
- `completed`
- `available`
- любые backend aliases, которые реально возвращает service

**Требование:** пользователь не должен видеть raw enum ни на одном языке.

### B2. Web Profile history reasons

**Файл:** `frontend/src/features/profile/WebProfilePage.tsx`  
**Проблема:** `reasonLabel` покрывает узкий список reasons.  
**Исправить:** вынести единый normalizer для history reasons.

Покрыть минимум:

- `task_bonus:*`
- panel activation related reasons;
- exchange related reasons;
- referral related reasons;
- withdraw related reasons;
- deposit/payment/order related reasons;
- unknown safe fallback без raw leak.

### B3. Withdraw labels

**Файл:** `frontend/src/pages/withdraw.tsx`  
**Проблема:** raw reason, balance_type, outcome_kind, `Request #...`.  
**Исправить:** нормализовать:

- `status`
- `outcome_kind`
- `reason`
- `balance_type`
- request title/id display
- success/error/empty texts

**Особое правило:** `bonus` не должен выглядеть как withdrawable balance. Только MAIN доступен для вывода, если это соответствует канону.

### B4. Ranks fallback

**Файл:** `frontend/src/pages/ranks.tsx`  
**Проблема:** `browser-player`.  
**Исправить:** заменить на human/i18n fallback:

- RU: `Игрок браузера` или другой утверждённый канонический текст;
- EN: `Browser user`;
- другие языки через locale keys.

### B5. Admin Shop Russian-first

**Файл:** `frontend/src/pages/admin/shop.tsx`  
**Проблемные runtime labels:**

- `bulk`
- `delete queue`
- `Archive`
- `Delete`
- `facts`

**Исправить:** заменить на русские операторские labels.

Рекомендуемые смыслы:

- `bulk` → `Массовое действие`
- `delete queue` → `Очередь удаления`
- `Archive` → `Архивировать`
- `Delete` → `Удалить`
- `facts` → `Факты` / `Служебные факты`, если это diagnostics-only

### B6. Admin Withdrawals Russian-first

**Файл:** `frontend/src/pages/admin/withdrawals.tsx`  
**Проблемные runtime labels:**

- `PENDING`
- `PAID`
- `success`
- `request #`
- `user`
- `wallet`
- `status`

**Исправить:** ввести operator label map:

- `pending` → `Ожидает обработки`
- `approved` → `Одобрено`
- `rejected` → `Отклонено`
- `canceled` → `Отменено`
- `paid` → `Выплачено`
- `failed` → `Ошибка выплаты`

### Acceptance criteria

- На public screens нет raw enum/status/reason.
- В admin runtime нет смешения русского и английского, кроме технических diagnostics-only зон, если они явно маркированы как internal.
- Все новые labels проходят через i18n/label map.
- Unknown fallback не печатает raw backend value пользователю.

### Required tests

- `test_tasks_public_status_labels_no_raw_enum`
- `test_balance_history_reason_humanization`
- `test_withdraw_history_and_outcome_labels_human_readable`
- `test_ranks_no_browser_player_fallback`
- `test_admin_shop_russian_only_runtime_labels`
- `test_admin_withdrawals_statuses_human_readable`
- `test_status_labels_are_human_readable`
- `test_no_missing_translation_keys_rendered`
- `test_no_undefined_null_object_object_in_ui`

---

## 5. Cycle C — Panels countdown repair

### Цель

Исправить неверное отображение оставшегося времени панели.

### Файл

`frontend/src/pages/panels.tsx`

### Проблема

Форматтер времени использует некорректные делители:

```text
86 / 3 / 60
```

Вместо нормальной логики:

```text
days = seconds / 86400
hours = remainder / 3600
minutes = remainder / 60
```

### Что исправить

1. Изолировать countdown formatter в чистую функцию.
2. Использовать корректную секундную математику.
3. Обработать отрицательные/нулевые значения.
4. Сделать нормальный text fallback для archived/expired panels.
5. Не менять срок панели 180 дней.
6. Не менять стоимость активации 100 EFHC.
7. Не менять backend.

### Acceptance criteria

- 180 дней отображаются как 180 дней, а не как искажённое значение.
- 1 день = 24 часа.
- 1 час = 60 минут.
- Expired panel не показывает абсурдный countdown.
- UI не ломается на длинных языках.

### Required tests

- `test_panels_countdown_math_uses_86400_3600_60`
- `test_panels_expired_state_no_negative_countdown`
- `test_panels_long_translation_layout_de_fr_es`

---

## 6. Cycle D — Withdraw flow repair

### Цель

Сделать Withdraw понятным, доверительным и согласованным с Web Profile / Money-Center.

### Файл

`frontend/src/pages/withdraw.tsx`

### D1. Исправить return target

**Проблема:** кнопка/flow обещает Money-Center, но делает `router.push("/")`.

**Исправить:** выбрать и закрепить один target:

```text
/web-profile?section=history
```

Рекомендация: после успешного создания заявки вести пользователя в history section, где он видит статус заявки.

### D2. Исправить history labels

Все history items должны показывать:

- человеческое название операции;
- human status;
- сумму;
- дату;
- понятный статус обработки;
- понятное действие, если можно отменить.

Запрещено показывать:

- raw `reason`;
- raw `balance_type`;
- raw `outcome_kind`;
- raw `Request #...` как единственный заголовок;
- `undefined`, `null`, `[object Object]`.

### D3. MAIN/BONUS clarity

Если по канону вывод доступен только с MAIN:

- BONUS не должен визуально выглядеть как withdrawable;
- подписи должны прямо объяснять, какой баланс доступен для вывода;
- disabled state должен быть понятным.

### D4. Success/error/loading

Добавить или проверить:

- loading на create request;
- disabled repeat guard;
- success message;
- error message без raw exception;
- cancel request state;
- empty state для отсутствия заявок.

### Acceptance criteria

- После заявки пользователь попадает в `/web-profile?section=history` или другой утверждённый Money-Center target.
- Withdraw page не показывает raw technical strings.
- MAIN/BONUS logic визуально не вводит в заблуждение.
- Денежные кнопки защищены от двойного клика.

### Required tests

- `test_withdraw_return_goes_to_web_profile_history`
- `test_withdraw_history_and_outcome_labels_human_readable`
- `test_withdraw_bonus_not_displayed_as_withdrawable`
- `test_double_click_money_buttons_disabled`
- `test_modals_close_correctly`

---

## 7. Cycle E — Admin operator UX repair

### Цель

Сделать admin screens операторским продуктом на русском языке, а не технической dev-панелью.

### E1. Admin Shop

**Файл:** `frontend/src/pages/admin/shop.tsx`

Исправить:

- RU/EN mixed labels;
- непонятные bulk/delete controls;
- action labels;
- confirmation wording;
- status labels;
- empty/error states;
- long product/order rows.

Не менять:

- backend routes;
- product/order business logic;
- shop economics;
- CI.

### E2. Admin Withdrawals

**Файл:** `frontend/src/pages/admin/withdrawals.tsx`

Исправить:

- raw statuses;
- raw outcome_kind;
- English summary words;
- request/user/wallet/status labels;
- status preview;
- danger confirmations.

### Acceptance criteria

- Оператор видит русские понятные действия.
- Опасные действия имеют confirmation.
- Таблицы не ломаются на длинных wallet/order ids.
- Raw enum/status visible only in diagnostics/internal, если это вообще нужно.

### Required tests

- `test_admin_shop_russian_only_runtime_labels`
- `test_admin_withdrawals_statuses_human_readable`
- `test_admin_tables_do_not_overflow_desktop`
- `test_no_internal_helper_text_in_runtime_ui`
- `test_no_debug_json_in_runtime_ui`

---

## 8. Cycle F — Docs / route drift repair

### Цель

Согласовать route docs с actual frontend.

### Проблема `/energy`

Документы продолжают упоминать `/energy`, но actual route file отсутствует. Energy фактически живёт на `/`.

### Варианты исправления

#### Вариант 1 — оставить только `/`

- убрать `/energy` из активных route docs;
- отметить `/` как единственный canonical Energy route;
- если `/energy` был legacy alias, перенести в superseded note.

#### Вариант 2 — вернуть `/energy` alias

- добавить route alias;
- убедиться, что он не ломает bottom nav/canonical docs;
- добавить test на alias.

### Рекомендация

Оставить только `/`, если нет старых внешних ссылок, требующих `/energy`.

### Acceptance criteria

- Docs route map совпадает с actual frontend route files.
- Следующий агент не ищет несуществующий route.

### Required tests

- `test_energy_route_docs_match_actual_routes`

---

## 9. Cycle G — Screenshot / visual regression proof

### Цель

Закрыть главный пробел аудита: отсутствие runtime screenshot proof.

### Что создать

1. Screenshot manifest.
2. Public UI screenshots.
3. Admin UI screenshots.
4. 10 viewport smoke.
5. 13 language smoke for critical screens.
6. Telegram WebApp safe-area smoke.
7. Browser/PWA smoke.

### Минимальные public screens

- `/`
- `/panels`
- `/exchange`
- `/tasks`
- `/referrals`
- `/ranks`
- `/web-profile`
- `/withdraw`
- `/faq`
- `/hub`
- `/browser-shop`

### Минимальные admin screens

- `/admin/hub/*`
- `/admin/users`
- `/admin/bank`
- `/admin/withdrawals`
- `/admin/shop`
- `/admin/tasks`
- `/admin/reports`
- `/admin/diagnostics`
- `/admin/system`
- `/admin/panels`
- `/admin/logs`

### Viewports

- `320×568`
- `360×640`
- `375×667`
- `390×844`
- `414×896`
- `430×932`
- `768×1024`
- `1024×768`
- `1366×768`
- `1920×1080`

### Acceptance criteria

- Нет горизонтального scroll на mobile.
- Text не вылезает за кнопки.
- Bottom nav не перекрывает контент.
- Modal закрывается и не выходит за экран.
- Long usernames/wallet/order ids не ломают layout.
- de/fr/es длинные строки не ломают карточки.
- hi/sw/id не ломают шрифты и переносы.

### Required tests

- `test_visual_routes_smoke_all_languages`
- `test_mobile_320_no_horizontal_scroll`
- `test_mobile_390_no_text_overflow`
- `test_long_translation_layout_de_fr_es`
- `test_long_username_layout`
- `test_wallet_address_truncation`
- `test_admin_tables_do_not_overflow_desktop`

---

## 10. Definition of Done

Ремонт можно считать завершённым только если:

1. Все F-01…F-10 закрыты или явно перенесены с обоснованием.
2. P1 count стал `0`.
3. Нет raw enum/status/reason в public runtime UI.
4. Admin runtime русскоязычный и операторски понятный.
5. Withdraw возвращает в утверждённый Money-Center/history target.
6. Panels countdown математически корректен.
7. Ranks не использует `browser-player`.
8. Docs route map совпадает с actual frontend routes.
9. Есть screenshot evidence bundle.
10. Все обязательные tests зелёные.
11. Не изменены экономика, бизнес-логика, backend contracts, CI/workflows/lock files без отдельного разрешения.

---

## 11. Итоговая команда для следующего агента

Работать строго циклами A–G. Сначала закрыть P1-семантику и raw text leaks, затем responsive/screenshot proof, затем beauty pass. Не начинать с косметики, пока пользователь видит raw enum/status/reason и пока Withdraw возвращает не туда, куда обещает.

Главная формула ремонта:

```text
сначала смысл и доверие → потом адаптивность → потом красота → потом screenshot regression
```
