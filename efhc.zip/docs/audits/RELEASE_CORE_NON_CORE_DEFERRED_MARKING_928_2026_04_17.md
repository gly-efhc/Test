# Cycle 928 — release-core / non-core / deferred marking

Дата: 2026-04-17
Архивная итерация: `EFHC_Bot_v167_19_cycles_928_930_release_gate_verdict.zip`

## Назначение

Этот документ фиксирует честную маркировку модулей перед финальным
release-gate re-audit. Его задача — убрать ложную зрелость периферии
и явно отделить:
- release core;
- non-core;
- deferred.

## Release core

В release core входят контуры, по которым и должен выноситься release
verdict:
- Telegram-first shell;
- Hub как handoff layer;
- Browser-Shop как внешний execution path;
- Web-Profile как canonical account center;
- withdraw runtime + outcome delivery;
- exchange user path;
- panels user path;
- admin withdrawals;
- admin bank;
- admin reports/overview;
- admin shop;
- templates как supporting release-core layer;
- admin logs как supporting operator layer.

## Non-core

Модули ниже полезны, но не должны создавать ложное ощущение, что они
входят в release core:
- `admin/diagnostics` — helper обзор маршрутов и связок;
- `admin/ads` — provider/helper surface;
- `admin/efhc-deposits` — manual operator-assisted contour в
  `controlled mode` до релиза.

Эти модули могут быть видимы оператору, но не используются как главный
аргумент готовности публичного релиза.

## Deferred

Ниже — deferred / draft contour, который должен быть явно отделён от
release core:
- `admin/sale-packages` — draft/read-only snapshot layer.

## Что изменено в runtime/UI

В admin surfaces введена более явная маркировка:
- release core;
- non-core;
- deferred.

Цель — чтобы оператор видел не просто `helper/draft`, а ещё и
release-статус модуля.

## Вывод цикла 928

Маркировка выполнена честно:
- release core оценивается отдельно;
- non-core не маскируется под боевой контур;
- deferred остаётся вне release-core verdict.
