# APPLICATION FUNCTION / ROUTE / TABLE AUDIT — цикл 1741

Статус: **STATIC AUDIT / ACTIVE EVIDENCE**

Входной HEAD: `EFHC_Bot_v173_66.zip`, SHA-256 `b93479b92ba84c288168f825e40bc1f42707f8cde8c1adb2749c25128d7088a6`.

GitHub CI `85400569189`, checkout `78f0c2aa96101b95161754a4c8eaa0e0bbe31c76`, проверил `efhc.zip` размером `12353514` bytes. Gate summary: все gates `exit=0`; pytest: `1534 passed / 22 skipped / 1 warning`. SHA-256 CI payload в логах не опубликован.

## 1. Функции

- Production Python files под `backend/app`: **345**; AST parse errors: **0**.
- Найдено **1815** определений функций/методов/вложенных функций и **648** class definitions. Это полный статический inventory source, а не новый delete-whitelist.
- Fail-closed registered floor: **339/339 symbols**, **62 modules**, **77/77 required files**; missing: **0**.
- `no caller != delete proof`: незарегистрированные private helpers не становятся удаляемыми из-за отсутствия в protected floor.

## 2. HTTP routes

- Required route modules: **37/37**, missing router modules: **0**.
- Реальные FastAPI route decorators в production source: **169**.
- Checked-in OpenAPI: **155 paths / 161 operations**.
- Active `SSOT_ROUTES.csv`: **161 operations**; exact mismatch OpenAPI↔SSOT: **0**.
- Дополнительно source содержит **8** mounted `include_in_schema=False` operations. Это не OpenAPI drift: они намеренно скрыты из публичной схемы, но должны иметь отдельный internal/compatibility inventory.
- Из этих 8: четыре `/hub/browser-shop-*` — compatibility aliases к canonical `/shopfront/*`; `/meta/metrics` и `/meta/deployment` — token-guarded operator diagnostics; `/cron/tick` и `/tg/webhook` — internal infrastructure boundaries.

## 3. Таблицы

- Source ORM declarations: **55**.
- `SSOT_TABLES_ORM.csv`: **55** = **48 `efhc_core` + 7 `efhc_admin`**.
- Source↔ORM SSOT mismatch: **0**.
- ORM↔`SSOT_TABLES_MIGRATIONS.csv` mismatch: **0**.
- GitHub CI Alembic для exact input HEAD: `metadata_tables=55`, `tables_in_schemas=56`, `0001: ok`; дополнительная DB table — Alembic version table, не ORM business table.
- Single-head migration CANON сохранён: только `0001_initial_release_schema.py`.

## 4. Подтверждённый drift и решение цикла 1741

1. `SSOT_DB_SCHEMAS_TABLES.md` оставался на старом количестве 48 таблиц — обновляется до 55 (48 core + 7 admin).
2. `SSOT_INTERNAL_ROUTES.csv` регистрировал только cron/webhook — обновляется до всех 8 скрытых mounted operations.
3. Runtime/backend/frontend/schema не изменяются: это audit/SSOT/guard patch.

Подробный машинный inventory всех функций, route decorators и ORM tables: `docs/audits/APPLICATION_FUNCTION_ROUTE_TABLE_AUDIT_1741.json`.
