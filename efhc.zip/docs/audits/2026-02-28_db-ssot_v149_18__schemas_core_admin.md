Audit-Id: AUD-2026-02-28-DB-SSOT-001
Date: 2026-02-28
Version: EFHC_Bot_v149_18
Topic: db-ssot
Status: ACTIVE
Superseded-By: null
Scope: SSOT-канон схем и размещения таблиц (core/admin).
Sources: - DOC:docs/audits/_raw/AUD-2026-02-28-DB-SSOT-001.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Аудит фиксирует канон: бизнес-данные хранятся только в схемах
`efhc_core` и `efhc_admin`, а таблицы в `public` и иных схемах считаются
отсутствующими/запрещёнными. Канон таблиц выводится из ORM-моделей и
маршрутов.

## Findings (FACTS)
- Истинные схемы: `efhc_core` и `efhc_admin`. [[EV-001]]
- Таблицы в `public` или иных схемах запрещены (считаются
отсутствующими). [[EV-002]]
- Канон таблиц определяется по ORM и маршрутам (структура:
purpose/PK/writers/readers). [[EV-003]]

## Evidence Index
EV-001 | DOC | docs/audits/_raw/AUD-2026-02-28-DB-SSOT-001.pdf | - |
True Schemas: efhc_core, efhc_admin | Источник задаёт единственные схемы
бизнеса.
EV-002 | DOC | docs/audits/_raw/AUD-2026-02-28-DB-SSOT-001.pdf | - |
Forbidden: public/other schemas absent | Источник запрещает
public/прочие схемы.
EV-003 | DOC | docs/audits/_raw/AUD-2026-02-28-DB-SSOT-001.pdf | - |
Tables canon derived from ORM/routes | Источник описывает вывод истинных
таблиц из ORM/роутов.

## Decisions (SSOT)
- Зафиксировать схемы как ядровые константы
(DB_SCHEMA_CORE/DB_SCHEMA_ADMIN) и запретить строковые хардкоды.
[[EV-001]]
- Ввести CI/guard-проверку: отсутствие таблиц вне core/admin (включая
`public`). [[EV-002]]
- Вести реестр таблиц/владельцев (writers/readers) как SSOT-актив на
основе ORM/роутов. [[EV-003]]

## Actions (P0/P1/P2)
### P0
- Добавить/канонизировать DB_SCHEMA_ADMIN в Settings и заменить
fallback. [[EV-001]]
- Добавить guard на `public.*` объекты в sanity-step
(to_regclass/pg_class). [[EV-002]]

### P1
- Сгенерировать таблицу owners: table -> writers/readers по ORM+routes.
[[EV-003]]

### P2
- Автоматизировать сверку ORM vs migrations vs raw SQL refs. [[EV-003]]

## Impact & Risks
Риск несоблюдения канона: таблицы могут оказаться в `public`, что
приведёт к невидимости для проверок и рассинхрону данных. Канонизация
схем снижает риск 'плавающих' обращений и ложных падений sanity.

## Verification
Проверка: to_regclass('efhc_core.*')/to_regclass('efhc_admin.*') должны
находить объекты, а pg_namespace/pg_class не должны содержать
бизнес-таблиц в `public`.

## Appendix: Raw Extract (optional)
True Schemas: `efhc_core`, `efhc_admin`; Forbidden: `public`/other
schemas.
