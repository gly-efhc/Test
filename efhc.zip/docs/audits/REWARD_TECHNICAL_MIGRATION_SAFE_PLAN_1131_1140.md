# Reward technical migration-safe plan — cycles 1131-1140

Date: 2026-04-27
Status: AUDIT / migration-safe transition plan

## Purpose

Close the technical planning phase for remaining `reward*` names without
breaking schema/runtime compatibility or rewriting migration history.

## Compatibility decision

Safe in this pass:

- switch tasks routes to the canonical service entrypoint name
  `claim_task_bonus()` while keeping `claim_task_reward()` as a compatibility
  wrapper;
- stop injecting `reward_efhc` from admin routes when the service already
  accepts `bonus_efhc`;
- switch moderation route call-site to `bonus_override_efhc` while keeping the
  service fallback on `reward_override_efhc`;
- prefer `bonus_efhc` first in admin task create/update payload handling.

Not safe in this pass:

- DB column names `reward_bonus_efhc` and `reward_amount_efhc`;
- table name `task_rewards_log`;
- model field names and migration history tied to `0001_init.py`.

## Result

This pass finishes the technical rename plan at the service/route boundary:
bonus-first names are now the primary path in active code, while legacy reward
names remain bounded wrappers or schema/runtime contracts.

## Release meaning

The project moves closer to release because further work no longer needs a
blind search-and-replace wave. Remaining `reward*` names are now a contained
migration topic rather than a broad active-code blocker.
