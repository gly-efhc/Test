# ADMIN SHOP EDITOR AUDIT 671-675 — 2026-04-08

## Scope
Первый короткий блок под shop product-card management через админ-панель.

## Confirmed backend anchors
- `/admin/shop/items/set-price` уже сохраняет TON / USDT / is_active
- catalog читается из canonical storefront source
- stats base в backend существует отдельно и подтверждена кодом

## Donor use from sandbox
- Refine: editor/resource thinking
- Horizon: summary / density / dashboard framing
- ui-main: preview-card shell and form layout patterns
