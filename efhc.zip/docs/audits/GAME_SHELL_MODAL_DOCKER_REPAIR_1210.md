# Game shell, modal and Docker repair — cycle 1210

## Purpose

Cycle 1210 applies the user's targeted remarks without broad refactors.
The work is limited to Docker health, docs copy, Telegram SDK bootstrap,
common Modal bottom-sheet, GlobalHeader shell classes and Layout
navigation shell classes.

## Code changes

- `ops/docker/Dockerfile.backend` now copies `docs` into `/app/docs`.
- `docker-compose.yml` healthcheck now uses `/api/health`.
- `ops/docker/docker-compose.yml` was aligned to `/api/health` too.
- `frontend/src/pages/document.tsx` adds Telegram WebApp SDK script.
- `frontend/src/components/ui/Modal.tsx` is now a bottom-sheet shell.
- `frontend/src/components/GlobalHeader.tsx` uses game-header structure.
- `frontend/src/components/Layout.tsx` keeps canonical bottom navigation
  and adds game-shell navigation classes.

## Modal call-site review

The shared `Modal` is called from `DepositModal`, `ProfileModal`,
`AdminPromptModal`, `HubPage` and `tasks.tsx`.  All call sites keep the
same props: `open`, `onClose`, `title` and children.

## Protected actions

GlobalHeader actions remain wired as before: Profile, Wallet, Direct
Deposit and HUB.  Bottom navigation remains Energy, Panels, Exchange,
Tasks, Referrals and Ranks.

## Browser install answer

No separate EFHC install button is added.  Browser/PWA installation is
left to the system browser prompt, matching the user's answer and the
Dragon reference behavior.
