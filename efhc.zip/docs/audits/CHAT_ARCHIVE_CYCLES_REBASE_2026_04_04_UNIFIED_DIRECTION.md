# Chat / archive / cycles audit — unified direction rebase

## Scope of the audit
This audit re-reads the latest active chat decisions, the current HEAD
archive state and the unfinished cycle queue.

## Confirmed chat truths
1. WebApp and browser flow are one whole.
2. Storefront must open outside the Telegram app.
3. Telegram is a handoff/context layer, not the storefront itself.
4. The external storefront may live in the same backend/admin repo.
5. VIP NFT is an external asset.
6. The bot only verifies VIP ownership and derives status.
7. EFHC balance top-up flow and VIP verification flow must stay split.

## Archive truth after audit
1. Frontend already has a separate `browser-shop` page and Hub handoff.
2. Frontend runtime path has been shifted to published TON packages,
   but install/build proof is still not closed.
3. Telegram-side wording guards now exist for EFHC top-up neutrality and
   VIP external verification wording.
4. The repo currently contains historical cycle blocks that predate the
   unified-shell direction and therefore describe an outdated attack map.

## Main drift found
The unfinished cycles still over-focus on donor/runtime combat and do
not fully reflect the now-approved common direction:
- one external storefront,
- one frontend shell,
- one TON/TonConnect runtime path,
- one shared checkout state model,
- one explicit split between EFHC top-up and VIP verification.

## Rebased unfinished queue
The cycle numbers are preserved, but their target meaning is refactored.

### 358 — common-shell install/build proof
Obtain honest install/build proof for the common frontend shell under the
published TON/TonConnect path.

### 359 — common TonConnect session path
Stabilize one TonConnect/TMA/browser session path for the common shell.

### 360 — external storefront bootstrap contract
Freeze bootstrap contract for the external storefront launched from the
Telegram handoff.

### 361 — shared checkout state model
Unify one checkout state model for the external storefront. EFHC top-up
is the primary active checkout line.

### 362 — shared runtime env and polyfill proof
Close common runtime-env/polylfill proof for the shared shell.

### 363 — storefront integration in repo-admin topology
Document and stabilize the rule that the external storefront may live in
backend/admin repo topology while remaining external to Telegram.

### 364 — shared USDT builder path under gates
Keep USDT builder on the common shell path, but only behind readiness and
live gates until proof is complete.

### 365 — VIP external verification split
Freeze the split between external VIP acquisition and bot-side status
verification.

### 366 — watcher / confirm contract for common storefront
Align watcher/confirm logic with the common external storefront and
handoff model.

### 367 — common-shell regression guards
Expand architecture guards for one shell, neutral handoff and VIP split.

### 368 — integrated proof package
Collect integrated install/build/runtime/test proof for the common shell.

### 369 — controlled staging enable
Enable staging only after cycles 358-368 provide real proof.

### 370 — final release-gate audit
Final release-gate for the unified direction only after 358-369 close.

## Honest status after rebase
- Done stays done for 336-357.
- Partial stays partial for 358-368.
- Pending stays pending for 369-370.
- The queue meaning changed; the proof status did not.
