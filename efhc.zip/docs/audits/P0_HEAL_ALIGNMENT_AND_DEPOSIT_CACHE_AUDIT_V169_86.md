# P0 HEAL alignment and deposit cache audit — v169_86

Date: `2026-06-04`.  
Cycle: `1404`.  
Base HEAD: `v169_85 / cycle 1403`.  
Mode: documentation / plan / alignment only; no runtime code repair.

## User decisions recorded

The user confirmed all three iteration questions from cycle 1403:

1. `HEAL-0040`: `payment_intents.package_id` may be nullable for custom/package-less deposit intents. Package-based intents still require package semantics.
2. `HEAL-0024` / `HEAL-0018`: service/route transaction-boundary repair is allowed where required for atomicity, one HEAL cycle at a time.
3. FSM split: `backend/app/bot/states.py` must remain a compatibility facade during migration.

## Deposit cache finding

The user added a new deposit-cache concern: duplicate-deposit protection must not rely on a process-local TTL memory cache such as `_ttl_seen`; in a serverless/multi-instance environment it must use durable DB-backed idempotency through `efhc_admin.idempotency_key` and long-retention records.

### Current code check

Static check of current HEAD found:

- `backend/app/core/system_locks.py` does not contain `self._ttl_seen` or `_ttl_seen` as active runtime state.
- `MonetaryIdempotencyMiddleware` calls `_acquire_idempotency_ttl_lock(...)`.
- `_acquire_idempotency_ttl_lock(...)` writes to `IdempotencyKey` from `backend/app/models/admin_models.py`.
- The target table is `efhc_admin.idempotency_key`.

Therefore the old exact process-local `_ttl_seen` implementation is **not confirmed as active runtime code** in this HEAD. The remaining problem is a P0 regression/proof gap: deposit duplicate protection and long-retention policy must be guarded explicitly so the archive cannot drift back to memory-only duplicate detection.

## Atlas / Q&A check

Checked:

- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- root `HEALER_ATLAS.md`;
- `docs/healer/HEALER_ATLAS.md`;
- `atlas.json`;
- `docs/healer/HEALER_CASEBOOK.md`;
- `casebook.json`.

Verdict:

- `HEAL-0018`, `HEAL-0023`, `HEAL-0024`, `HEAL-0040`, `HEAL-0044`, `HEAL-0045` exist in Atlas.
- `HEAL-0055` exists and already names `_ttl_seen` / in-memory TTL cache and `efhc_admin.idempotency_key` as the treatment path.
- Q&A had historical payment-intent TTL/memo decisions and old HEAL-0018 notes, but it did **not** explicitly record the new user decisions from cycle 1404 and the deposit-cache serverless requirement.

Action taken in this cycle: Q&A and plans were updated. Atlas was not declared broken, but it was updated with a cycle-1404 alignment note and elevated P0 priority for the deposit-cache regression/proof lane.

## Updated cycle order

The planned P0/FSM lane is now `1404-1420`:

- 1404: user-decision alignment, Q&A/Atlas deposit-cache plan update — done.
- 1405-1416: P0 backend repair / proof lane.
- 1417-1420: FSM `states.py` split lane.

## Non-claims

This cycle does not claim GitHub CI green, full local pytest green, frontend build, release readiness, screenshots, live Telegram proof or real TonConnect/wallet proof.
