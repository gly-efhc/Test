# EFHC user_id / global_id independent audit — v171.90

Cycle: `1593`.
Input: `EFHC_Bot_v171_89.zip`.
Input SHA-256:
`21babdb44702b76afd81ddb3664a4dc0637fd478a33b5874259225773cba71dd`.
Input ZIP entries: `4808`.

## 1. Audit boundary

The audit scanned the exact extracted input tree before runtime or schema
changes. It covered backend, frontend source, tests, operations,
documentation, migration sources and release packaging.

Tracked terms included:

```text
global_id
current_global_id
get_current_global_id
request.state.global_id
telegram_id
inviter_global_id
invitee_global_id
moderator_global_id
added_by_global_id
granted_by_global_id
parsed_global_id
TG:
```

## 2. Reproduced preliminary figures

| Scope | Exact result |
|---|---:|
| `global_id` occurrences in `backend/app` | 2448 |
| backend files | 133 |
| services occurrences | 1498 |
| routes occurrences | 398 |
| CRUD occurrences | 134 |
| bot occurrences | 116 |
| model occurrences | 89 |
| integration occurrences | 71 |
| core occurrences | 53 |
| schema occurrences | 34 |
| `deps.py` occurrences | 26 |
| middleware occurrences | 13 |
| ORM tracked fields | 32 |
| ORM tables | 29 |
| Python functions with tracked parameters | 336 |
| executable `Depends(get_current_global_id)` | 54 |
| `frontend/src` occurrences | 375 |
| `frontend/src` files | 62 |
| test occurrences | 712 |
| test files | 107 |
| documentation occurrences | 1105 |
| documentation files | 267 |

The preliminary figures are therefore materially accurate when the
original scopes are preserved.

## 3. New machine inventory

The cycle-1593 generator produced:

- `4672` classified line/token rows in the untouched v171.89 input;
- `628` files containing at least one tracked term;
- `143` FastAPI route handlers in the AST inventory;
- `65` route handlers with a tracked Telegram identity dependency or
  parameter;
- `2054` classified domain owner or actor rows.

The last value is a migration workload indicator. It is not a table
count and must not be interpreted as `2054` independent database
relationships.

## 4. ORM result

The preliminary ORM list is confirmed:

- `32` tracked fields;
- `29` tables;
- `parsed_global_id` in `ton_inbox_logs` remains source-event data;
- the other owner and actor fields require staged migration.

Current physical user identity remains:

```text
users.id INTEGER primary key
users.global_id BIGINT unique not null
```

The target `users.user_id BIGINT` does not exist in cycle 1593.

## 5. Preliminary material corrections

### 5.1. Cycle numbering

The local sequence `0-15` is invalid as project cycle numbering.
It is retained only as a list of macro architecture phases.

The authoritative sequence is:

```text
1593-1600 — foundation and entry gates
1601-1700 — detailed implementation roadmap
```

There is no mechanical one-to-one mapping `0 → 1593` through
`15 → 1608`.

### 5.2. Dependency count wording

There are `56` literal text matches for
`Depends(get_current_global_id)` in `backend/app`.
Two are comments or documentation strings.
There are `54` executable dependency applications.

### 5.3. Scope wording

The frontend value `375 / 62` applies to `frontend/src`.
The documentation value `1105 / 267` applies to the full `docs` tree,
not Markdown files only.

### 5.4. Target versus runtime

Preliminary target diagrams are architectural requirements.
They must not be reported as current runtime implementation.
Auth tables, canonical `users.user_id`, `AuthContext` and independent
TON login are not yet present in cycle 1593.

## 6. Classification policy

Every machine row contains:

```text
file
line_or_object
layer
current_field
semantics
target_field
decision
cycle
risk
source_excerpt
```

Semantics:

- `DOMAIN_OWNER`;
- `DOMAIN_ACTOR`;
- `AUTH_IDENTITY`;
- `TELEGRAM_SPECIFIC`;
- `SOURCE_EVENT`;
- `LEGACY_COMPATIBILITY`;
- `TEST_ONLY`;
- `DOCUMENTATION`.

Actions:

- `MIGRATE_TO_USER_ID`;
- `ADD_RESOLVED_USER_ID`;
- `KEEP_TG_ID`;
- `DUAL_WRITE_TEMPORARILY`;
- `UPDATE_TEST`;
- `UPDATE_DOCUMENTATION`.

The classification is a migration routing aid. Exact code semantics
must be rechecked before each file is patched.

## 7. Telegram-specific allowlist

Cycle 1593 explicitly allows `21` Telegram boundary files.
They cover Telegram bot handlers, Telegram Bot API and WebApp HMAC
middleware.

All other current runtime files are legacy baseline entries.
Their tracked identifier count may decrease but may not increase.

## 8. Risks

Critical risks remain:

- duplicate TON and Telegram accounts;
- financial ownership drift during backfill;
- false `global_id = user_id` aliases;
- TON-only users blocked by legacy non-null `global_id`;
- idempotency or transaction locks moved inconsistently;
- admin roles lost during provider migration;
- source-event Telegram IDs mistaken for domain ownership.

Cycle 1593 changes no owner or financial value and therefore does not
attempt to close these later-cycle risks.

## 9. Reconciliation result

A read-only query inventory was created for all required financial and
identity metrics.

No PostgreSQL URL was available locally. Result:

```text
NOT_RUN_DB_UNAVAILABLE
```

No balance, kWh, panel, transaction or role value is claimed as read or
compared in this environment.

## 10. Conclusion

The migration is large but controlled. The correct next step is cycle
1594: create the canonical `user_id` type and compatible user-table
expand without changing domain ownership reads.
