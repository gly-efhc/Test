Audit-Id: AUD-2026-02-28-ROUTES-INVENTORY-003
Date: 2026-02-28
Version: EFHC_Bot_v149_17
Topic: routes-inventory
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; факты и решения с evidence.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-ROUTES-INVENTORY-003.pdf
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Route→Table Map (маршруты ↔ таблицы)

## Findings (FACTS)

- /ranks (GET/PATCH/DELETE) используют DYNAMIC_SQL на таблицу ranks
через форматирование schema. [[EV-002]] [[EV-003]]
- /withdraw/* и /shop/* используют ORM доступ к
WithdrawRequest/ShopOrder/ShopItem. [[EV-001]]
- В отчёте отмечены P0 нарушения только для /ranks (DYNAMIC_SQL).
[[EV-001]]

## Evidence Index

EV-001 | DOC |
docs/audits/_raw/
    2026-02-28_routes-inventory_v149_17__route_table_map.pdf
| - | Route→Table Map registry (PDF), extracted mapping. | Содержит
привязку routes→services→tables и флаги.
EV-002 | CODE | backend/app/services/ranks_service.py | L100-L150 |
DYNAMIC_SQL uses {schema}.ranks in text(f"..."). | Доказывает
динамический SQL в /ranks.
EV-003 | CODE | backend/app/routes/ranks_routes.py | L20-L50 |
GET/PATCH/DELETE /ranks handlers map to ranks_service.*. | Доказывает
поверхность маршрутов /ranks.

## Decisions (SSOT)

- DYNAMIC_SQL в ranks_service считать P0 и заменить на параметризованный
SQL без форматирования схемы, либо на ORM. [[EV-002]]
- Ввести guard: запрет `{SCHEMA}`/`f"...{schema}"` в SQL строках вне
строго типизированного слоя. [[EV-002]]

## Actions (P0/P1/P2)

- P0: переписать ranks_service на безопасный запрос без строкового
schema.
- P1: добавить тест, что ranks_service не использует форматирование
schema в SQL.
- P2: расширить Route→Table map генератором из кода.

## Impact & Risks

Риск рассинхрона маршрутов и таблиц при изменениях; динамический SQL
увеличивает риск ошибок и уязвимостей.

## Verification

Проверить линтерами аудитов и сверить evidence по указанным путям.

## Appendix: Raw Extract (optional)

##
Route→Table
Map
**GET
/ranks**
HANDLER:
get_ranks
|
backend/app/routes/ranks_routes.py:22
CALL_CHAIN:
