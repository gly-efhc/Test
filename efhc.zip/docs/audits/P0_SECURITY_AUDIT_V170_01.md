# P0 Security Audit — EFHC Bot v170.01

## 1. Verdict

**Статус: `P0_RELEASE_BLOCKED`.**

Аудит выявил **2 подтверждённых P0**, которые затрагивают:

1. **wallet binding / TonConnect proof boundary**;
2. **production control-plane endpoint `/cron/tick`**.

Оба дефекта являются release blocker до исправления и повторной security-проверки.

> Важно: в исходной задаче указан архив `EFHC_Bot_v170_01_cycle_1426_panel_dead_tx_context_cleanup.zip`, но фактически в текущей сессии был доступен и проверялся загруженный архив `EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`. Если v170.01 и v170.02 отличаются, этот отчёт нужно считать вердиктом по фактически проверенному архиву v170.02, а не по имени из задания.

| Метрика | Результат |
|---|---:|
| Проверено целевых файлов / артефактов | 31 |
| Инвентаризировано backend HTTP routes | 133 |
| Инвентаризировано `/admin/*` routes | 55 |
| P0 | 2 |
| P1 | 0 |
| P2 | 3 |
| P3 | 0 |
| Release blocker | Да |
| Минимум repair-циклов | 3 |

## 2. Scope

Проверялись основные security-зоны из задания:

- Telegram WebApp initData authentication;
- JWT / auth boundary;
- admin authorization;
- admin frontend route guard;
- X-Admin-Api-Key / ADMIN_API_KEY;
- Telegram webhook secret;
- cron secret;
- CORS;
- OpenAPI/docs exposure;
- payment/deposit/withdraw routes;
- wallet binding / TonConnect proof;
- external callbacks / ads callbacks;
- rate limiting;
- idempotency abuse;
- IDOR / ownership bypass;
- SSRF / unsafe external calls;
- SQL injection;
- XSS;
- CSRF-like risks для Telegram WebApp / browser / PWA;
- secrets leakage;
- logging of sensitive data;
- privilege escalation;
- replay attacks;
- weak production configuration.

Основной набор файлов:

- `backend/app/core/security_core.py`
- `backend/app/deps.py`
- `backend/app/middleware/telegram_webapp_auth.py`
- `backend/app/main.py`
- `backend/app/routes/admin_*.py`
- `backend/app/routes/system_routes.py`
- `backend/app/routes/deposit_routes.py`
- `backend/app/routes/payment_intents_routes.py`
- `backend/app/routes/withdraw_routes.py`
- `backend/app/routes/shop_routes.py`
- `backend/app/routes/hub_routes.py`
- `backend/app/routes/wallets_routes.py`
- `backend/app/services/tonconnect_proof_service.py`
- `backend/app/services/wallet_binding_service.py`
- `backend/app/services/wallets_service.py`
- `backend/app/services/watcher_service.py`
- `backend/app/integrations/ads_providers.py`
- `frontend/src/pages/_app.tsx`
- `frontend/src/lib/auth.ts`
- `frontend/src/lib/telegram.ts`
- `frontend/src/lib/api.ts`
- `SECURITY.md`
- `env.example`
- `env.prod.example`
- `env.local.example`
- `backend/openapi/openapi.json`
- `docs/security/ADMIN_ROUTE_GUARD_CANON.md`
- security-релевантные тесты из задания.

Дополнительно для проверки production safety и OPSEC просмотрены смежные файлы:

- `backend/app/core/config_core.py`
- `backend/app/core/logging_core.py`
- `backend/app/__init__.py`
- `backend/app/services/scheduler_service.py`

## 3. Security model used

### Auth source

Источник личности пользователя в Telegram WebApp должен быть только валидный Telegram `initData`, проверенный через HMAC. Backend не должен доверять `tg_id` из body, query, localStorage, `X-Telegram-User-Id` или frontend-only state.

Проверенная модель в коде:

- `get_current_tg_id` берёт пользователя из `request.state.tg_id` или валидирует `X-Telegram-Init-Data`;
- middleware кладёт `request.state.tg_id` только после проверки `initData`;
- `X-Telegram-User-Id` не должен быть production security source.

### Admin source

Admin identity должна определяться только backend-зависимостью `require_admin`, которая сверяет authenticated Telegram identity с backend whitelist / admin storage. Frontend admin guard — только UX-слой и не является security boundary.

### Webhook source

Telegram webhook в production должен проверять `X-Telegram-Bot-Api-Secret-Token`. Любой внешний webhook/callback должен иметь secret/signature/dedupe и fail-closed поведение.

### Cron source

`/cron/tick` является control-plane endpoint. В production он должен быть защищён непредсказуемым `X-Cron-Secret`, заданным только через ENV. Repo-known default secret недопустим.

### Payment / deposit / withdraw trust boundary

Любой route, связанный с deposit, withdraw, payment intent, order, wallet, должен:

- требовать authenticated user;
- проверять ownership объекта;
- иметь idempotency protection для денежных POST;
- не доверять внешнему tx/hash/callback без проверки границы доверия;
- не давать повторную обработку replay-событий.

### Frontend/backend boundary

Frontend admin guard, localStorage, `NEXT_PUBLIC_ADMIN_TG_IDS`, browser headers и Telegram `initDataUnsafe` не считаются security boundary. Все критические решения обязаны приниматься backend-guard’ами.

### Production config assumptions

Production startup должен fail-fast при:

- пустом или default `SECRET_KEY`;
- пустом или default `CRON_SECRET`;
- пустом webhook secret при включённом Telegram webhook;
- опасном CORS `*` с credentials;
- включённых docs/openapi/redoc без явной защиты;
- включённых insecure user headers.

## 4. Attack surface map

| Surface | Route/file | Auth required | Owner check required | Mutation | Money impact | Current protection | Suspected risk |
|---|---|---:|---:|---:|---:|---|---|
| Telegram WebApp auth | `backend/app/deps.py`, `backend/app/middleware/telegram_webapp_auth.py`, `backend/app/core/security_core.py` | Да | Да | Нет | Да, косвенно | HMAC initData + `request.state.tg_id` | P2: `auth_date` не строго обязателен |
| Wallet binding | `/api/wallets/connect`, `wallets_routes.py`, `wallets_service.py` | Да | Да | Да | Да | address normalization + idempotency | **P0: нет обязательного TonConnect proof** |
| TonConnect proof endpoints | `/api/wallets/tonconnect/proof-payload`, `/api/wallets/tonconnect/check-proof` | Да | Да | Да | Да | Отдельный proof API существует | Разрыв интеграции с `/wallets/connect` |
| Cron control plane | `/cron/tick`, `system_routes.py`, `config_core.py` | Secret | Нет | Да | Да, косвенно | `X-Cron-Secret` | **P0: repo-known default secret** |
| Telegram webhook | `/tg/webhook`, `system_routes.py`, `config_core.py` | Secret in prod | Нет | Да | Да, косвенно | `X-Telegram-Bot-Api-Secret-Token` + dedupe | Требуется дополнительная sequence-проверка dedupe после secret |
| Deposit | `/deposit/efhc` | Да | Да | Да | Да | current global_id + wallet requirement + idempotency | Существенного bypass в просмотренном path не подтверждено |
| Withdraw | `/withdraw/request`, `/withdraw/{id}/cancel`, detail/list | Да | Да | Да | Да | current global_id + owner checks | Существенного IDOR в просмотренном path не подтверждено |
| Shop | `/shop/order-external`, `/shop/purchase-efhc` | Да | Да | Да | Да | current global_id + idempotency | Существенного bypass в просмотренном path не подтверждено |
| Payment intents | `/payment-intents/{intent_id}` | Да | Да | Нет | Да | owner-scoped service call | Низкий риск по inspected path |
| Admin backend | `/admin/*` | Да | Да | Да | Да | `Depends(require_admin)` | Обход admin не подтверждён, но нужен AST-test на все routes |
| Frontend admin guard | `_app.tsx`, `ADMIN_ROUTE_GUARD_CANON.md` | Нет | Нет | UX only | Нет | redirect для non-admin | Не security boundary |
| Legacy browser headers | `frontend/src/lib/api.ts`, `backend/app/__init__.py` | Нет | Нет | Клиентская отправка | Косвенно | initData preferred | P2: legacy header debt |
| Logging / OPSEC | `logging_core.py` | N/A | N/A | Нет | Косвенно | RedactingFilter | P2: неполное покрытие secret aliases |

## 5. Confirmed findings

### P0-01 — Wallet binding можно выполнить без TonConnect proof

| Поле | Значение |
|---|---|
| Severity | P0 |
| Title | Address-only wallet binding bypass |
| Files | `backend/app/routes/wallets_routes.py`, `backend/app/services/wallets_service.py`, `backend/app/services/tonconnect_proof_service.py` |
| Route/function | `/api/wallets/connect`, `wallets_service.connect_wallet` |

#### Evidence

`/wallets/connect` принимает `address`, `wallet_app`, `Idempotency-Key` и вызывает `wallets_service.connect_wallet` без обязательного proof-потока.

Отдельные TonConnect proof endpoints существуют:

- `/api/wallets/tonconnect/proof-payload`;
- `/api/wallets/tonconnect/check-proof`.

Но они не являются обязательным условием для production bind в `/wallets/connect`.

#### Impact

Пользователь может привязать любой валидный TON address без доказательства контроля приватного ключа. После этого система может считать кошелёк “connected” и пропускать wallet-gated денежные сценарии.

Это нарушает trust boundary wallet binding и делает криптографический proof-контур необязательным там, где он должен быть обязательным.

#### Reproduction idea only in local/test mode

В локальном окружении:

1. авторизоваться через валидный Telegram initData;
2. вызвать `/wallets/connect` с валидным TON address, который пользователь не контролирует;
3. передать новый `Idempotency-Key`;
4. убедиться, что binding проходит без вызова TonConnect proof flow.

#### Why it matters

Wallet binding — это security boundary для кошелёк-зависимых денежных операций. Если backend принимает address-only bind, то wallet ownership становится декларацией пользователя, а не криптографически доказанным фактом.

#### Repair direction

Без изменения экономики:

1. запретить production bind по одному адресу;
2. сделать TonConnect proof обязательным для `/wallets/connect` или объединить connect с `check-proof`;
3. proof должен быть связан с текущим `tg_id`, доменом, TTL и single-use nonce;
4. повторное использование proof должно отвергаться;
5. wallet-gated денежные routes должны проверять только verified binding, а не naked address binding.

#### Required test

- `/wallets/connect` rejects request without verified TonConnect proof;
- wallet binding proof cannot be replayed;
- user cannot unlock wallet-gated money routes by naked address bind.

---

### P0-02 — `/cron/tick` защищён предсказуемым hardcoded default secret

| Поле | Значение |
|---|---|
| Severity | P0 |
| Title | Repo-known default CRON_SECRET protects production control-plane endpoint |
| Files | `backend/app/core/config_core.py`, `backend/app/routes/system_routes.py`, `env.prod.example`, `backend/app/main.py`, `backend/app/services/scheduler_service.py` |
| Route/function | `/cron/tick` |

#### Evidence

`CRON_SECRET` имеет конкретный default в коде. `/cron/tick` принимает запрос при совпадении `X-Cron-Secret` с этим значением. `env.prod.example` не заставляет явно переопределить секрет. Startup fail-fast не проверяет, что production secret был заменён на high-entropy ENV value.

#### Impact

Если deployer не переопределил `CRON_SECRET`, control-plane endpoint становится доступен любому, кто знает код/репозиторий. `/cron/tick` запускает scheduler tick, а scheduler может запускать stateful jobs, включая watcher и эксплуатационные сервисы.

#### Reproduction idea only in local/test mode

В локальном/тестовом окружении без явного `CRON_SECRET`:

1. отправить GET `/cron/tick`;
2. добавить header `X-Cron-Secret` со значением default из repo;
3. проверить, что endpoint отвечает 200 и запускает tick.

#### Why it matters

`/cron/tick` — не обычный read-only endpoint. Это управляющая ручка фоновых процессов. Repo-known default secret равен отсутствию настоящего секрета при production-деплое с дефолтами.

#### Repair direction

Без изменения бизнес-логики:

1. убрать hardcoded default;
2. в production/stage требовать non-empty high-entropy `CRON_SECRET` из ENV;
3. fail-fast при пустом/default/слишком коротком значении;
4. обновить `env.prod.example`, чтобы там был placeholder, а не рабочее значение;
5. добавить тесты на reject missing/wrong/default secret.

#### Required test

- `/cron/tick` rejects missing/wrong/default secret in prod;
- prod startup fails on empty/default `CRON_SECRET`.

---

### P2-01 — Telegram initData не требует обязательного `auth_date`

| Поле | Значение |
|---|---|
| Severity | P2 |
| Title | Missing or malformed `auth_date` does not fail closed |
| File | `backend/app/core/security_core.py`, `tests/efhc_backend/unit/test_telegram_init_data.py` |
| Function | Telegram initData validation |

#### Evidence

TTL проверяется только если `auth_date` существует и является числом. Если `auth_date` отсутствует или имеет нечисловой формат, fail-closed поведение не подтверждено. Текущие тесты покрывают valid / invalid hash / expired TTL, но не missing/non-numeric `auth_date`.

#### Impact

Anti-replay модель неполная. Для Telegram WebApp `auth_date` должен быть обязательным полем свежести. Отсутствие strict reject увеличивает replay-risk и риск будущего обхода при malformed payload.

#### Repair direction

- сделать `auth_date` обязательным;
- требовать строго числовой формат;
- missing/non-numeric/expired `auth_date` должен возвращать 401;
- добавить unit/integration tests.

#### Required test

- missing `auth_date` returns 401;
- non-numeric `auth_date` returns 401;
- expired `auth_date` returns 401.

---

### P2-02 — Secrets redactor не покрывает часть production secret aliases

| Поле | Значение |
|---|---|
| Severity | P2 |
| Title | Incomplete redaction coverage for production secrets |
| File | `backend/app/core/logging_core.py` |
| Function | `RedactingFilter.SECRET_KEYS` |

#### Evidence

Redaction покрывает часть ключей, но не все реальные aliases из production-контура. Отсутствуют или требуют проверки:

- `ADMIN_API_KEY`;
- `TELEGRAM_WEBHOOK_SECRET`;
- `CRON_SECRET`;
- `BOT_TOKEN` alias;
- возможные TonAPI/TonCenter aliases.

#### Impact

При exception, debug, diagnostics или accidental config logging часть секретов может попасть в логи без маскировки. В найденных sample logs утечка не подтверждена, но покрытие фильтра неполное.

#### Repair direction

- расширить список secret aliases;
- маскировать значения и ключи в structured/unstructured logs;
- добавить тест, который прогоняет все production secret names через redactor.

#### Required test

- secrets redactor masks `BOT_TOKEN`, `SECRET_KEY`, `ADMIN_API_KEY`, `TELEGRAM_WEBHOOK_SECRET`, `CRON_SECRET`.

---

### P2-03 — Frontend и legacy compatibility code продолжают отправлять deprecated security headers

| Поле | Значение |
|---|---|
| Severity | P2 |
| Title | Legacy auth/admin headers still emitted by frontend / compatibility layer |
| Files | `frontend/src/lib/api.ts`, `backend/app/__init__.py`, locale strings |
| Headers | `X-Telegram-User-Id`, `X-Admin-Id`, `X-Admin-Token` |

#### Evidence

Frontend всё ещё имеет path, который отправляет `X-Telegram-User-Id` из Telegram `initDataUnsafe.user.id`, если нет initData. Также frontend отправляет legacy `X-Admin-Id` и `X-Admin-Token` из localStorage. Совместимый CORS helper также перечисляет эти headers.

Backend canonical path сейчас не должен доверять этим заголовкам, но их наличие создаёт ложную security-модель и риск будущего регресса.

#### Impact

Немедленный backend bypass не подтверждён, но сохранение legacy headers противоречит канону:

- нельзя доверять `global_id` из frontend/localStorage;
- frontend guard не является security boundary;
- старые admin headers не должны быть частью runtime-модели.

#### Repair direction

- убрать emission `X-Telegram-User-Id` из frontend production path;
- убрать `X-Admin-Id` / `X-Admin-Token` из frontend;
- убрать user-facing тексты, описывающие старую модель admin access;
- оставить только `X-Telegram-Init-Data` как client auth source;
- добавить regression tests.

#### Required test

- no legacy `X-Admin-Id` / `X-Admin-Token` in frontend runtime;
- frontend never sends `X-Telegram-User-Id` in production build.

## 6. Non-findings

### NF-01 — Backend canonical auth не доверяет `X-Telegram-User-Id`

В inspected canonical path `get_current_tg_id` использует `request.state.tg_id` или HMAC-проверенный `X-Telegram-Init-Data`. Прямое доверие к `X-Telegram-User-Id` как production identity source в проверенном path не подтверждено.

### NF-02 — Withdraw detail/list имеют owner-check в просмотренном коде

В просмотренных withdraw routes:

- list запрещает чтение чужого `global_id`;
- detail проверяет соответствие request owner текущему authenticated `global_id`.

Подтверждённого IDOR для withdraw detail/list в inspected path не найдено.

### NF-03 — Payment intent status имеет owner-scoped service call

`/payment-intents/{intent_id}` использует current authenticated global_id и owner-scoped lookup. Подтверждённого IDOR в inspected path не найдено.

### NF-04 — Representative `/admin/*` routes используют `Depends(require_admin)`

В проверенных admin route files representative routes используют `Depends(require_admin)`. Подтверждённого admin bypass в inspected inventory не найдено. Однако нужен отдельный AST-test, который автоматически гарантирует это для всех `/admin/*` routes.

### NF-05 — Telegram webhook secret в production имеет validator

В production конфигурации Telegram webhook secret требуется validator’ом, а endpoint сравнивает header через constant-time сравнение. Прямой production fail-open по отсутствующему webhook secret в просмотренном path не подтверждён.

### NF-06 — Frontend admin guard корректно трактуется как UX-only слой

Документация и архитектурная модель правильно фиксируют, что frontend admin guard не является security boundary. Это не заменяет backend guard, но как UX-layer не является проблемой само по себе.

## 7. Invariants

Следующие security-инварианты должны быть истинны всегда:

1. Backend никогда не доверяет `tg_id` из body/query/localStorage/frontend headers.
2. Единственный production source личности WebApp-пользователя — валидный Telegram `initData` через HMAC.
3. `X-Telegram-User-Id` не даёт доступ к деньгам или профилю.
4. Все `/admin/*` backend routes имеют `Depends(require_admin)`.
5. Frontend admin guard — только UX-слой, не security boundary.
6. `NEXT_PUBLIC_ADMIN_TG_IDS` не является секретом и не даёт backend-доступ.
7. OpenAPI/docs/redoc в production отключены или явно защищены.
8. Telegram webhook в production проверяет `X-Telegram-Bot-Api-Secret-Token`.
9. `/cron/tick` в production защищён high-entropy `X-Cron-Secret` из ENV.
10. Денежные POST имеют idempotency protection.
11. Rate limit покрывает monetary и auth-sensitive endpoints.
12. Секреты не логируются и маскируются при ошибках.
13. В репозитории нет реальных production tokens/private keys/admin secrets.
14. Auth/security ошибки не раскрывают внутренние детали.
15. Внешние callbacks/webhooks имеют secret/signature/dedupe.
16. Любая ручка с `global_id` проверяет ownership.
17. Любая ручка с withdraw/payment/deposit/order/wallet проверяет принадлежность объекта текущему user.
18. Admin API не зависит от CORS/frontend-only guard.
19. Production startup fail-fast при опасной конфигурации.
20. Любой bypass auth/admin/ownership считается P0.
21. Wallet binding в production возможен только после криптографического proof владения адресом.
22. TonConnect proof single-use, TTL-bound, domain-bound и tg_id-bound.
23. `auth_date` в Telegram initData обязателен и проверяется fail-closed.
24. Repo-known default secret не считается секретом.

## 8. Missing tests

Обязательный test-pack перед production:

1. Every `/admin/*` route has `Depends(require_admin)`.
2. No route trusts `global_id` from body/query for ownership.
3. Invalid Telegram initData returns 401.
4. Expired Telegram initData returns 401.
5. Missing `auth_date` returns 401.
6. Non-numeric `auth_date` returns 401.
7. Missing auth on monetary route returns 401.
8. User cannot read another user's wallet/order/withdraw/payment intent.
9. Duplicate webhook event does not double process.
10. `/cron/tick` rejects wrong/missing/default secret in prod.
11. Production startup fails on empty/default `CRON_SECRET`.
12. Telegram webhook rejects wrong/missing secret in prod.
13. CORS `*` forbidden in prod with credentials.
14. OpenAPI/docs disabled in prod env template.
15. Secrets redactor masks `BOT_TOKEN`, `SECRET_KEY`, `ADMIN_API_KEY`, `TELEGRAM_WEBHOOK_SECRET`, `CRON_SECRET`.
16. No hardcoded real admin global_id in repository.
17. No legacy `X-Admin-Id` / `X-Admin-Token` in frontend runtime.
18. No direct SQL f-string with user input.
19. No `dangerouslySetInnerHTML` without explicit sanitizer.
20. No frontend admin page renders admin UI for non-admin.
21. Monetary rate limit covers withdraw/exchange/deposit/payment-intents.
22. Payment intent ownership enforced.
23. Wallet binding proof cannot be replayed.
24. `/wallets/connect` rejects request without verified TonConnect proof.
25. Wallet-gated money routes reject naked address-only binding.
26. External callbacks reject missing/invalid signature/secret.
27. Duplicate callback/webhook cannot poison dedupe before secret validation.

## 9. Repair plan

### Cycle 1 — Close P0 release blockers

1. Закрыть wallet binding bypass:
   - запретить production address-only bind;
   - сделать TonConnect proof обязательным;
   - связать proof с текущим `global_id`, domain, TTL и nonce;
   - запретить replay proof;
   - обновить wallet-gated checks, чтобы они принимали только verified binding.

2. Закрыть cron secret bypass:
   - убрать hardcoded default `CRON_SECRET`;
   - сделать secret обязательным в production/stage;
   - добавить fail-fast при пустом/default/коротком значении;
   - обновить `env.prod.example`;
   - добавить тесты на reject missing/wrong/default secret.

### Cycle 2 — Replay / OPSEC / legacy headers

1. Сделать `auth_date` обязательным в Telegram initData.
2. Добавить fail-closed на missing/non-numeric/expired `auth_date`.
3. Расширить secrets redaction на все production aliases.
4. Убрать frontend emission legacy headers:
   - `X-Telegram-User-Id`;
   - `X-Admin-Id`;
   - `X-Admin-Token`.
5. Убрать устаревшие user-facing тексты про legacy admin access.

### Cycle 3 — Regression hardening

1. Добавить AST/integration tests на все `/admin/*` routes.
2. Добавить ownership tests по wallet/order/withdraw/payment intent.
3. Добавить OpenAPI/docs production disabled tests.
4. Добавить CORS production safety tests.
5. Добавить monetary rate-limit coverage tests.
6. Добавить callback/webhook dedupe-after-secret tests.
7. Провести повторный security-аудит на новом архиве.

## 10. Questions for user

### Q1 — Какой wallet binding контур является каноническим?

**Проблема:** в архиве сосуществуют новый `wallets_routes.py` / `wallets_service.py` и старый `wallet_binding_service.py` с другим подходом к bind.

**Почему без ответа нельзя безопасно чинить:** если исправить не тот контур, можно оставить активный production route с bypass или сломать правильный flow.

**Варианты решения:**

1. Канонический путь — только TonConnect proof через `wallets_routes.py`.
2. Канонический путь — старый memo-based bind через `wallet_binding_service.py`.
3. Оставить оба, но оба обязаны иметь криптографический proof / external proof и одинаковые security-инварианты.

### Q2 — Какой production entrypoint используется при деплое?

**Проблема:** в архиве есть прямой `app.main:app` и compat-wrapper через `backend/app/__init__.py:create_app`.

**Почему без ответа нельзя безопасно чинить:** legacy CORS/header debt может жить в compat-wrapper и не проявляться в основном entrypoint, либо наоборот.

**Варианты решения:**

1. Production использует только `backend/app/main.py`.
2. Production использует `backend/app/__init__.py:create_app`.
3. Оба entrypoint должны быть приведены к одному security behavior.

### Q3 — Подтвердить версию архива для финального вердикта

**Проблема:** пользователь запросил v170.01, но в сессии был доступен v170.02.

**Почему без ответа нельзя безопасно чинить:** если v170.01 и v170.02 отличаются, выводы по файлам и строкам могут не совпасть.

**Варианты решения:**

1. Считать v170.02 фактическим HEAD и чинить его.
2. Повторно загрузить v170.01 и провести отдельный аудит именно v170.01.
3. Сравнить v170.01 и v170.02 diff’ом, если оба архива будут доступны.

## Final auditor summary

1. **Verdict:** `P0_RELEASE_BLOCKED`.
2. **Проверено:** 31 файл/артефакт и 133 backend routes, включая 55 `/admin/*` routes.
3. **Найдено:** P0 — 2, P1 — 0, P2 — 3, P3 — 0.
4. **Самые опасные surfaces:** wallet binding / TonConnect proof, `/cron/tick`, Telegram WebApp initData freshness.
5. **Release blocker:** да.
6. **Обязательные тесты перед production:** wallet proof enforcement, cron secret fail-fast, Telegram initData strict `auth_date`, admin route guard AST-test, ownership tests, redaction tests, no legacy headers.
7. **Repair cycles:** минимум 3.

