# MIGRATION ZERO UPGRADE PROOF BUNDLE — 2026-04-08

## Цель
Собрать в одном месте proof bundle по migration-layer current HEAD.

## Что проверено по коду

### 1. Active migration canon
Текущий active migration layer остаётся только:
- `backend/migrations/versions/0001_init.py`

Это соответствует текущему канону pre-release линии.

### 2. env.py exists and is active
- `backend/migrations/env.py` присутствует и участвует в migration path.

### 3. 0001_init.py contains real schema bootstrap logic
По коду `0001_init.py` подтверждается:
- импорт ORM metadata
- `SET search_path TO efhc_core, efhc_admin`
- `schema_translate_map={None: "efhc_core"}`
- sanity-check against required tables
- idempotent `Base.metadata.create_all(..., checkfirst=True)`

### 4. two-schema posture remains explicit
В migration code явно фигурируют:
- `efhc_core`
- `efhc_admin`

## Что подтверждено
- Migration layer current HEAD не разросся до pre-release `0002+` ветки.
- В 0001 есть не только create_all, но и sanity-guard слой.
- two-schema posture по current HEAD поддерживается кодом migration layer.

## Residual / что остаётся живым

### Residual 1: proof bundle не равен fresh CI proof
Этот документ не заменяет пользовательский GitHub CI upgrade proof.
Он только собирает code evidence в одном месте.

### Residual 2: нужен consolidated ORM↔DDL matrix
Нужна отдельная matrix-сводка:
- ключевые таблицы
- ключевые constraints
- required schemas
- guard tests

## Вывод
Migration-layer current HEAD выглядит дисциплинированно и согласован с
pre-release canon `0001 only`, но final proof of `upgrade from zero` всё равно
остаётся за пользовательским GitHub CI и его логами.
