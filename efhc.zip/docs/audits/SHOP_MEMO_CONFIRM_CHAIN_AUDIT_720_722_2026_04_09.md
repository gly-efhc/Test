# SHOP MEMO CONFIRM CHAIN AUDIT 720-722 (2026-04-09)

## Question checked
1. Are shop item cards hard-bound to canonical memo?
2. Do watcher/scheduler-confirm flows really bind incoming transaction,
   wallet, amount and memo before crediting EFHC from bank to user?

## Findings before fix
- external shop orders were already protected by PaymentIntent payload
  `EFHC:shop_external:<intent_id>:<tg_id>`
- watcher confirmed the intent by payload, amount, asset and destination
  wallet
- the order still kept `extra.sku` and `extra.item_type`, but the
  canonical item memo snapshot was not preserved explicitly in the order
  snapshot before the order memo was overwritten by the intent payload

## Real chain after fix
- product card -> `extra.sku`
- canonical item memo snapshot -> `extra.canonical_memo`
- chosen pay method -> `extra.payment_method`
- external order memo -> PaymentIntent payload
- incoming tx memo -> exact intent payload
- watcher confirm -> checks payment_intent + order memo payload +
  canonical memo snapshot + order extra payment method + amount + wallet

## Result
The chain is now stricter and auditable:
item -> canonical memo snapshot -> order -> intent payload -> incoming tx
-> watcher confirm -> bank credit / manual NFT request.
