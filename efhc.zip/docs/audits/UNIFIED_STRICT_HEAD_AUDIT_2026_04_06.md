# Unified strict HEAD audit (imported from uploaded PDF)

This document fixes the uploaded full strict audit in the active `docs/audits` layer.

## Imported critical findings
- ECO-001 — bank SSOT split-brain (`bank_balance` vs `BANK_EFHC` as real bank-user).
- ECO-002 — wrong mirror ledger direction for bank in spend flows.
- ECO-003 — idempotency hole due to `ON CONFLICT DO NOTHING` without mandatory read-through handling.
- ECO-004 — autobegin violation in exchange flow.
- ECO-005 — recursive `_begin_tx` bug in `energy_service`.
- ECO-006 — broken SQL in `_enqueue_resync_energy`.
- ECO-007 — invalid SQL in `shop_service` order inserts.
- ECO-008 — `shop_models ↔ services ↔ migrations` mismatch.

## Scope of the imported audit
Economy, ledger, UI/UX, architectural consistency, blind spots, release purity.

## Status
Imported as audit input. Must be re-checked against live code before claiming any item fixed.
