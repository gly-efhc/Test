# FRONTEND CYCLE 1289 AUDIT — Exchange route contract

Version: v168_87  
Cycle: 1289  
Date: 2026-05-22

## Scope

This audit protects the Exchange screen after the kWh-only cleanup.
The goal is to prevent route drift and public UI drift.

## Required contract

- frontend uses generated current-user economic seams;
- Exchange preview path is `/exchange/preview`;
- Exchange convert path is `/exchange/convert`;
- backend routes use `get_current_global_id`;
- frontend does not build `global_id` or `user_id` query/path roads;
- no user-to-user transfer path is exposed from Exchange;
- Wallet, Withdraw and heavy History remain outside `/exchange`.

## Verified by guard

`tests/architecture/test_exchange_route_contract.py`

The guard checks:

1. route-contract markers on `/exchange`;
2. absence of `global_id`/`user_id` path building in Exchange UI;
3. generated Exchange paths without user path params;
4. backend route dependence on current-user context;
5. docs and sandbox-reference presence.

## Sandbox note

The uploaded `Песочница.xz` is accepted as a visual donor only.
It does not override EFHC canon and is not embedded into the release.

## Remaining work

Next cycle should be 1290: compact visual proof for Exchange.
That cycle can use the sandbox reference for button/card rhythm, but
must keep the route and function boundary from cycles 1286-1289.
