# PAGE AUDIT · REFERRALS + PANELS + TASKS + RANKS
## Cycles 753-758 · 2026-04-09

## Scope
Third page-by-page audit package:
- target pages: `referrals`, `panels`, `tasks`, `ranks`
- method: page → functions → routes → tables/data shape

## Tasks page audit
### Found issue
The page called `POST /tasks/claim/{global_id}` with `code`, while the route
expects `task_id`.

### Fix
- claim payload now sends `task_id`
- page-side task status binding now follows `task_id`
- page logic now respects backend `can_claim`

## Panels page audit
### Found issues
- cursor query string in the page contained a malformed multiline `?cursor`
  fragment
- the page did not use the already existing summary route
  `GET /panels/{global_id}/summary`

### Fix
- fixed cursor query construction
- added summary fetch through `/panels/{global_id}/summary`
- page can now display stronger panel summary data from the backend route

## Referrals page audit
### Found issue
The active/inactive referral list pages did not use richer fields already
returned by the backend (`total_generated_kwh`, `panels_count`).

### Fix
- frontend referral item type was expanded
- referral row rendering now shows extra activity facts from the backend

## Ranks page audit
### Found issue
`/ranks/top` already supports `exclude_global_id`, but the page did not use
it and relied on UI deduplication only.

### Fix
- rank page now forwards `exclude_global_id=global_id` when loading more rows
- reduces duplicate transport and keeps page behavior closer to route
  semantics

## Honest remaining note after this package
- this is the third page package, not the end of the whole page audit
- the same page-by-page method should continue through the remaining
  secondary surfaces
