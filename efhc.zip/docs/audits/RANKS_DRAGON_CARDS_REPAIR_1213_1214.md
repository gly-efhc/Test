# Ranks Dragon-style cards repair — cycles 1213-1214

## Finding

After cycle 1211-1212, Ranks had the correct meaning: it was no longer
an Energy level ladder.  The page was still visually plain and
table-like.
The user approved immediate Dragon-style compact leader cards.

## Repair

Ranks now keeps the leaderboard meaning and adds compact card display:

- medal/position chip for each leader;
- compact name and generated kWh;
- VIP chip where relevant;
- current user chip;
- top three compact cards above the existing table.

The existing `RanksTable` remains as a safe readable fallback.  No
route, backend contract, ranking algorithm or bottom navigation name was
changed.

## Boundary preserved

The repair is visual only.  It does not reintroduce Energy 12-level
names into Ranks.  Ranks remains a social leaderboard surface.
