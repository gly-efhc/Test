# EFHC_Bot_v165_final_product_runtime_audit

Источник: EFHC_Bot_v165_final_product_runtime_audit.pdf

Автоконверсия PDF -> Markdown для соблюдения archive canon .md-only.

EFHC Bot v165 - Финальный аудит

EFHC Bot v165 HEAD
Финальный product-runtime аудит живых сценариев бота и админки перед релизом
Источник

HEAD-архив
EFHC_Bot_v165_52_cycles_501_505_audit_tails_wave.zip

Формат

Релизный product/runtime аудит

Страница 1


EFHC Bot v165 - Финальный аудит

Содержание
ЧАСТЬ 1. EXECUTIVE SUMMARY
ЧАСТЬ 2. АУДИТ ПОЛЬЗОВАТЕЛЬСКОГО ПУТИ
ЧАСТЬ 3. АУДИТ АДМИНСКОГО ПУТИ
ЧАСТЬ 4. ЭКОНОМИЧЕСКИЙ TRUTH-LAYER В ЖИВОМ USE CASE
ЧАСТЬ 5. ФИНАЛЬНЫЙ UI/UX АУДИТ БОЕВЫХ ЭКРАНОВ
ЧАСТЬ 6. БЕЛЫЕ ПЯТНА
ЧАСТЬ 7. НЕЗАКРЫТЫЕ ДЕТАЛИ
ЧАСТЬ 8. ТОП-15 ДОРАБОТОК ДО РЕЛИЗА
ЧАСТЬ 9. ИТОГОВЫЙ ВЕРДИКТ
Объект аудита и что реально открыто и прочитано
HEAD-архив:
EFHC_Bot_v165_52_cycles_501_505_audit_tails_wave.zip
локально; анализ выполнен строго по содержимому HEAD).

(распакован

Фактически прочитано и сопоставлено по коду

















Frontend (Next.js)
frontend/src/pages/* (все реальные user/admin страницы)
ключевые оболочки и точки входа UI: frontend/src/pages/app.tsx,
frontend/src/components/Layout.tsx, frontend/src/components/GlobalHeader.tsx,
frontend/src/components/ProfileModal.tsx, frontend/src/components/DepositModal.tsx
боевые фичи: frontend/src/pages/exchange.tsx, frontend/src/pages/panels.tsx,
frontend/src/pages/tasks.tsx, frontend/src/pages/referrals*.tsx,
frontend/src/pages/ranks.tsx, frontend/src/features/hub/HubPage.tsx,
frontend/src/features/browser-shop/BrowserShopPage.tsx
admin UI: frontend/src/pages/admin/* и frontend/src/features/admin/*
Backend (FastAPI)
backend/app/main.py (middleware, CORS, security gates, регистрация роутов)
backend/app/deps.py (global_id auth, admin gate, idempotency)
backend/app/middleware/telegram_webapp_auth.py (initData validation →
request.state.global_id)
backend/app/core/security_core.py (алгоритм валидации Telegram initData)
все роут-модули backend/app/routes/*.py (user/admin/economy/runtime)
сервисный слой backend/app/services/* (withdraw, exchange, panels, payment_intents,
wallets, tonconnect proof, watcher и т.д.)
модели и миграции (в части, относящейся к экономике и админке):
backend/app/models/*, backend/migrations/*
тестовый контур и архитектурные guard-тесты: tests/* (как фактический индикатор
намерений/канона и ожидаемых контрактов)

Страница 2


EFHC Bot v165 - Финальный аудит

Ключевая внешняя нормативная база, относительно которой проверялись решения (для
security/runtime truth-layer)





Telegram Mini Apps: требование доверять только initData после валидации, и не
доверять initDataUnsafe; описание алгоритма подписи (HMAC-SHA-256) и TTL по
auth_date.
TON Connect ton_proof: шаги серверной проверки
домена/пейлоада/таймстампа/подписи и публичного ключа.
OWASP API Security Top 10 (особенно риски вокруг авторизации и “sensitive
business flows”) и OWASP Business Logic Abuse (replay/idempotency).

Executive summary и релизный вердикт

Страница 3


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 1. EXECUTIVE SUMMARY
Готов ли живой продукт к релизу
Полный релиз в текущем HEAD — нет.
Причина не в отсутствии контуров: продукт уже имеет широкий набор живых
пользовательских и админских сценариев. Причина — критические разрывы “UI → API
→ service” в отдельных боевых действиях, а также несколько переходных/ложноживых админ-слоёв, которые вводят в заблуждение и могут привести к неправильным
операционным действиям.
Отдельно важно: продукт опирается на sensitive business flows (withdraw, bank
mint/burn, deposit processing, manual referral bonus). Для таких потоков требования к
“безошибочности” и replay/идемпотентности значительно выше, чем для обычного UI.
Это прямо соответствует OWASP тезису о риске “Unrestricted Access to Sensitive
Business Flows” и классу “replays of idempotency operations”.
5 главных продуктовых рисков
1. Withdraw (пользовательский путь) не собран как самостоятельный завершённый
продуктовый сценарий: в UI он распределён между exchange и профилем,
отдельной страницы /withdraw в frontend/src/pages нет (при этом backend имеет
полноценный /withdraw/* API). Это создаёт user expectation gap: пользователь
ожидает отдельный контур “вывод”, а видит его как вторичный блок на экране
обмена.
2. Cancel withdraw фактически нерелизен из-за прямого разрыва между route и
service (см. ниже в runtime рисках): пользователь не должен получать “полуживой”
сценарий, где отмена заявки существует в API и в UI-ожидании, но ломается при
вызове.
3. Пакеты продаж (sale packages) в админке выглядят как боевой операторский
контур, но не доказаны как реально используемая экономическая поверхность:
они живут в отдельной таблице/сервисах и не являются SSOT для user-facing
deposit packages и shop catalog (в текущей архитектуре SSOT —
efhc_core.shop_items).
4. Два параллельных операционных слоя shop (новый vs legacy read paths) повышают
риск ошибочных операторских интерпретаций: экран “есть”, но что именно
является боевым источником истины — не всегда прозрачно.
5. Deposit UX (TonConnect) закрывает отправку транзакции, но слабо закрывает
подтверждение/ожидание/результат: пользователь отправил оплату и “закрыл
модалку”, но продуктово не получает понятного подтверждения (кроме косвенного
изменения баланса/истории).
5 главных runtime рисков
6. Критический разрыв withdraw cancel: route вызывает service с параметром,
которого service не принимает.



Route: backend/app/routes/withdraw_routes.py → post_withdraw_cancel(...) передаёт
idempotency_key=... в cancel_withdraw(...).
Service: backend/app/services/withdraw_service.py → async def cancel_withdraw(...,
global_id: int, request_id: int), без idempotency_key.
Страница 4


EFHC Bot v165 - Финальный аудит
Итог: при реальном вызове отмены — гарантированный runtime TypeError (release
blocker).
7. Admin sale-packages toggle/update не используют Idempotency-Key по смыслу:
заголовок обязателен на уровне route, но не влияет на фактическое действие
(toggle — неидемпотентен по природе). Это создаёт риск “двойного флипа” при
ретраях сети/клиента — типовой business-logic replay класс.
8. Переходные модули/алиасы повышают риск расхождения карты продукта: пример
— frontend/src/pages/ads.tsx официально заявляет, что отдельной страницы Ads нет,
это только backward-compat redirect в /tasks. Это нужно “закрепить” в
навигации/лексике продукта, иначе будут фантомные ожидания.
9. Admin auth зависит от Telegram initData и whitelist: подход корректен по Telegram
канону (не доверять initDataUnsafe, валидировать initData).
Но
в
HEAD
присутствуют
параллельные
заготовки
RBAC
(разные
таблицы/модели/сервисы), что повышает риск неверной настройки в проде и
непредсказуемого поведения прав.
10. Handoff/JWT browser-shop выглядит правильно как концепция, но остается
зависимость от корректности доменов/TTL и консистентности wallet binding.
Любая ошибка тут даёт “живой экран без возможности завершить оплату”.
5 главных UI/UX рисков
11. Withdraw не имеет “ощущения отдельного боевого сценария”: пользователь видит
вывод как вторичный блок на exchange, без маршрута и без явного “последующего
шага” (отслеживание заявки/отмена/статусы).
12. Deposit модалка ограничена “оплата отправлена/не отправлена”, без явного
статуса intent / ожидания подтверждения.
13. Operator touchpoints (withdraw approve/reject, bank mint/burn, referral manual bonus,
deposits processing) требуют “anti-error UX”: подтверждения, ясной финальности,
предупреждений. Сейчас часть экранов функциональна, но недостаточно
защищает оператора от ошибки.
14. Сосуществование admin shop legacy и нового слоя выглядит как один продуктовый
модуль, но на деле это переходный набор ручек, что UX-ом создаёт ложное
ощущение “единого источника истины”.
15. Наличие экранов-алиасов (например, Ads-redirect) создаёт риск, что продукт будет
восприниматься как “недоделанный”, если это не закреплено явно в UI и
документации.
Аудит пользовательского пути

Страница 5


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 2. АУДИТ ПОЛЬЗОВАТЕЛЬСКОГО ПУТИ
Ниже — не “code review”, а проверка завершённости боевых пользовательских
сценариев: наличие входа, UI entrypoint, навигации, связки frontend ↔ backend ↔
service ↔ data и отсутствие заглушек.
Старт





UI entry point: frontend/src/pages/index.tsx (экран энергии/главная), нижняя
навигация ведёт на /.
Backend link: снапшот формируется через POST /sync/user/{tg_id} (используется
frontend/src/hooks/useSnapshot.ts), backend backend/app/routes/sync_routes.py.
Статус: живой, сценарий закрыт как “dashboard + SSOT snapshot”.
Белые пятна: старт не всегда является orchestration-экраном всех критических
действий (withdraw/deposit/shop живут отдельно), но это не блокирует.

Релизный вердикт: условно готов.
Профиль


UI entry point: профиль — это modal (frontend/src/components/ProfileModal.tsx)
через GlobalHeader/аватар.

* Backend link





кошельки: GET /wallets/me
история балансов: GET /wallets/balance-history
история выводов: GET /withdraw/list?global_id=...
Статус: живой, но “слишком много критических функций в modal”.

* Белые пятна



withdraw-история есть, но “управление заявкой” (например, отмена) не доказано
как полностью рабочий путь на уровне runtime (см. cancel issue).
для продукта уровня полного релиза “modal перегруженность” увеличивает риск
UX-ошибки.

Релизный вердикт: частично готов, требуется hardening critical-actions,
особенно вокруг withdraw.
Панели


UI entry point: frontend/src/pages/panels.tsx, нижняя навигация /panels.

* Backend link






списки: GET /panels/{global_id}/active, GET /panels/{global_id}/archive
активация: POST /panels/activate/{global_id} (есть compat POST /panels/buy/{global_id})
Service/data слой: backend/app/services/panels_service.py, таблицы EFHC core
(панели/профиль/генерация).
Статус: живой, сценарий замкнут (активация → обновление снапшота → списки).
Белые пятна: критических “пустых заглушек” по коду не видно.

Релизный вердикт: готов.
Задачи
Страница 6


EFHC Bot v165 - Финальный аудит





UI entry point: frontend/src/pages/tasks.tsx, нижняя навигация /tasks.
Backend link: GET /tasks/catalog, GET /tasks/my/{global_id}, POST /tasks/claim/{global_id}.
Ads: отдельной страницы Ads нет; frontend/src/pages/ads.tsx — это redirect в /tasks и
прямо описан как backward-comp слой.
Статус: живой, но требует чёткого продуктового закрепления “Ads внутри Tasks”
(и в UI, и в коммуникации).

Релизный вердикт: готов с условием (снять двусмысленность про Ads как
отдельный раздел).
Рефералы





UI entry point: frontend/src/pages/referrals.tsx и подстраницы referrals/active.tsx,
referrals/inactive.tsx.
Backend link: /referrals/stats, /referrals/counters, /referrals/active, /referrals/inactive.
Статус: живой, последовательность “сводка → детали” закрыта.
Белые пятна: существенных не выявлено на уровне сценарного покрытия.

Релизный вердикт: готов.
Ранги




UI entry point: frontend/src/pages/ranks.tsx.
Backend link: /ranks/my-plus-top, /ranks/top.
Статус: живой, сценарий “моя позиция + топ + подгрузка” закрыт.

Релизный вердикт: готов.
Вывод


UI entry point: отдельной page-вертикали “withdraw” нет; “создать заявку”
находится внутри frontend/src/pages/exchange.tsx, а история — в профиле
(ProfileModal).

* Backend link






создание: POST /withdraw/request (wallet gate + idempotency)
список/детали: GET /withdraw/list, GET /withdraw/{request_id}
отмена: POST /withdraw/{request_id}/cancel (но см. runtime break)
Критическая проблема (релизный блокер): отмена заявки на уровне API сломана
разрывом route ↔ service (см. Executive summary).
Product gap: нет единого “withdraw journey”: заявка создана → где статус? где
понятная “моя заявка” в отдельных шагах? what next?

Релизный вердикт: нерелизно до исправления cancel и сборки цельного
пользовательского пути.
Обмен


UI entry point: frontend/src/pages/exchange.tsx, нижняя навигация /exchange.

* Backend link




превью/история: /exchange/preview/{global_id}, /exchange/history/{global_id}
конверсия: POST /exchange/convert/{global_id} (idempotency)
Статус: exchange как конверсия — живой и замкнутый, но экран перегружен тем,
что одновременно несёт withdraw.
Страница 7


EFHC Bot v165 - Финальный аудит


Белые пятна: UX-смешение двух критических сценариев (обмен и вывод) в одном
экране повышает вероятность ошибок и непонимания.

Релизный вердикт: exchange готов, но экран требует разгрузки (withdraw
вынести в отдельный контур).
Wallet / deposit

* UI entry point



wallet: профиль (wallet section) + TonConnect runtime в Layout
deposit: DepositModal через кнопку “Пополнить” в GlobalHeader

* Backend link




TonConnect proof payload и проверка: /wallets/tonconnect/proof-payload,
/wallets/tonconnect/check-proof
binding: POST /wallets/connect (idempotency header-only)
deposit packages + создание deposit-intent: GET /deposit/packages, POST
/deposit/efhc (wallet gate + idempotency)

* Security correctness



Telegram идентичность: продукт опирается на initData/валидацию и прямо следует
канону “не доверять initDataUnsafe”.
TON wallet ownership: реализована проверка ton_proof с контролем
домена/payload/timestamp/signature, что соответствует гайдам TON.

* Белые пятна



deposit UX не закрывает “ожидание подтверждения/финальность”: нет встроенного
intent status flow (в отличие от browser-shop, где статус опрашивается).
сценарий полагается на то, что пользователь увидит изменения в балансе позже
(через watcher).

Релизный вердикт: частично готов (runtime ядро хорошее, но нужен UX
hardening результата и статусов).
Hub





UI entry point: /hub (кнопка “Hub” в GlobalHeader).
Backend link: POST /hub/efhc-handoff создаёт signed token и отдаёт redirect_url.
Статус: живой, закрывает “gateway” в внешний buy-flow.
Белые пятна: критических не видно, но качество зависит от корректной настройки
HUB_EFHC_BUY_URL и TTL.

Релизный вердикт: готов, при условии корректной конфигурации окружения.
Browser shop




UI entry point: /browser-shop (прямой URL; фактически предполагается запуск из
Hub через token).
Backend link: /hub/browser-shop-bootstrap, /hub/browser-shop-catalog, /hub/browsershop-create-intent, /hub/browser-shop-intent-status
Статус: живой MVP storefront с handoff token и polling status.
Страница 8


EFHC Bot v165 - Финальный аудит

* Белые пятна



продукт прямо заявляет “контур только TON, USDT вырезан” (это хорошо как
честная рамка, но должно быть синхронизировано с админкой и документацией).
пользовательские инструкции “что делать дальше” (после выдачи memo/to_wallet)
требуют очень чёткой UX/копирайтинговой доводки.

Релизный вердикт: готов как MVP, но не как “полный магазинный релиз”.

FAQ



UI entry point: frontend/src/pages/faq.tsx
Статус: живой статический контур, продуктово полезен.

Релизный вердикт: готов.
Skins / auxiliary flows



Факт сценария: skins работают как “theme layer”: app.tsx подгружает
fetchMySkins() и использует активный skin для фона; backend имеет /skins/* API.
Белые пятна: отсутствует очевидный user-facing экран управления скинами (есть
library-методы, но нет явной page).

Релизный вердикт: не блокирует core релиз, но это не “зрелая вертикаль” в
UI.
Аудит админского пути

Страница 9


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 3. АУДИТ АДМИНСКОГО ПУТИ
Админский слой проверялся как operator-консоль: можно ли выполнить задачу до
конца, есть ли операционная ценность, нет ли “визуально есть, а по факту не
работает”.
Пользователи





UI: frontend/src/pages/admin/users.tsx
API: backend/app/routes/admin_users_routes.py (/admin/users/search,
/admin/users/{global_id}, VIP/active toggles, wallet reset)
Operator readiness: функционально хороший минимум.
Риски: действия high-impact (VIP/active/wallet reset) выполняются без сильных UX
guardrails (confirmations/описания эффекта/последствий).

Релизный вердикт: готов условно, но рекомендован hardening операторской
защиты.
Панели




UI: frontend/src/pages/admin/panels.tsx
API: /admin/panels/*
Operator readiness: боевой, сценарии активации/деактивации понятны.

Релизный вердикт: готов.
Выводы







UI: frontend/src/pages/admin/withdrawals.tsx
API: backend/app/routes/admin_withdrawals_routes.py (/admin/withdrawals list,
approve/reject, repair-consistency)
Operator readiness: основной цикл “список → решение” есть.
Риски: approve/reject — критический экономический touchpoint. Нужен
максимально ясный UX: подтверждение, явное отображение
суммы/пользователя/кошелька/истории, защита от мисклика.
Особая зависимость: пользовательский withdraw cancel сейчас сломан; это влияет
на весь lifecycle (оператор может видеть заявки, которые пользователь не может
отменить корректно).

Релизный вердикт: нерелизно до исправления cancel и усиления anti-error
UX.
Задачи




UI: frontend/src/pages/admin/tasks.tsx
API: backend/app/routes/admin_tasks_routes.py (CRUD/refresh/moderation)
Operator readiness: рабочий MVP, но риск “операторской ошибки” выше обычного.

Релизный вердикт: готов как MVP, лучше усилить ясность.
Shop


UI: frontend/src/pages/admin/shop.tsx

* API:


/admin/shop/orders (новая выдача)
Страница 10


EFHC Bot v165 - Финальный аудит



legacy чтение /admin/shop/order/legacy/{id} и /admin/shop/orders/user/legacy/{tg_id}
/admin/shop/items/set-price

* Риски



coexistence “нового” и “legacy” в одном модуле создаёт риск неправильной
интерпретации источника истины.
критично закрепить: что SSOT, что legacy read-only, что выведено из боевого
контура.

Релизный вердикт: частично готов, нуждается в декомпозиции/ясном
маркировании.
EFHC deposit processing




UI: админ-индекс и/или связанные экраны (зависит от реализации страницы
/admin/index.tsx)
API: /admin/efhc-deposits/process, /admin/ton/reconcile, плюс watcher/cron
инфраструктура
Operator readiness: это высокорисковый финансовый контур; в текущем виде он
больше похож на “операторский инструмент”, чем на “безошибочный workflow”.

Релизный вердикт: условно, требуется операционная доводка и safeguards.
Логи / банк / статистика




Logs: /admin/logs/transfers — полезно и боево для расследований.
Bank: /admin/bank/balance, /admin/bank/mint, /admin/bank/burn — критические
операции.
Reports: /admin/reports/overview — обзорный контур.

Релизный вердикт: функционально живые, но bank-операции требуют
усиления UX-защиты, потому что это “sensitive business flow”.
Referrals / reports / hub-admin links / sale packages / ads



Admin referrals: есть сводка + manual bonus + reassign. Это экономически
чувствительно; нужна повышенная ясность “что будет в балансе и почему”.
Admin hub links: реализовано, но backend-расположено внутри
admin_shop_routes.py (переходная архитектура).

* Admin sale packages








UI: frontend/src/features/admin/AdminSalePackagesPage.tsx
API: backend/app/routes/admin_sale_packages_routes.py +
backend/app/services/admin/admin_sale_packages_service.py
Главный факт: в HEAD пакеты продаж живут в efhc_admin.efhc_sale_packages, в то
время как user-facing deposit packages и shop catalog опираются на
efhc_core.shop_items. Это делает sale packages подозрительной зоной: оператор
может менять “пакеты”, которые не являются SSOT для пользовательского
storefront/deposit.
Дополнительно: toggle/update требуют Idempotency-Key на входе route, но
idempotency не используется как защита от двойного действия в самом сценарии
(toggle по природе неидемпотентен) — классический replay-риск.
Admin ads: лёгкий модуль (“providers”), не полный ads-console.
Страница 11


EFHC Bot v165 - Финальный аудит
Релизный вердикт: sale packages — нерелизно в текущем виде как “боевой
операторский модуль”; остальное — живое, но требует hardening.
Economic truth-layer в живом использовании

Страница 12


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 4. ЭКОНОМИЧЕСКИЙ TRUTH-LAYER В ЖИВОМ USE CASE
Оценка ниже — не “теория экономики”, а проверка: может ли живой
пользователь/админ сценарий ломать состояние, возможны ли обходы, есть ли
рассинхрон.
Balances





Вход пользователя: стартовый снапшот /sync/user/{global_id}, профиль (balancehistory), exchange экран.
Truth-layer: транзакции должны проходить через банковский слой (в коде это
закреплено как канон; для API-layer ключевы idempotency-заголовки и банковские
сервисы).
Риски: основной риск не в расчётах, а в “операторских корректировках” и
отсутствии достаточных guardrails на экранах.

Вывод: балансовый truth-layer в целом выглядит канонично, но release
зависит от hardening sensitive действий.
Panel activation




Вход пользователя: /panels → “Activate panel” (MainButton или кнопка).
API/service: POST /panels/activate/{global_id} + идемпотентность.
Риски: низкие; сценарий замкнут.

Вывод: economic flow доказан и близок к релизу.
Exchange




Вход пользователя: /exchange → convert.
API/service: POST /exchange/convert/{global_id} (Idempotency-Key).
Риски: низкие по экономике; основные риски — UX смешение с withdraw.

Вывод: exchange truth-layer выглядит релизно.
Withdraw






Вход пользователя: /exchange → withdraw request (wallet gate); история — профиль.
API: /withdraw/request, /withdraw/list, /withdraw/{id}, /withdraw/{id}/cancel.
Admin вмешательство: /admin/withdrawals list + approve/reject + repair-consistency.
Критический runtime gap: отмена заявки фактически сломана разрывом route ↔
service; это разрушает завершённость экономического lifecycle.
Риск рассинхрона: если пользователь не может корректно отменить, админ видит
“висящие” заявки; repair-consistency может “лечить” часть, но это не должно
заменять базовую работоспособность.

Вывод: withdraw truth-layer нерелизен до исправления cancel и доводки
lifecycle UX.
Payment/deposit flows

Существует два разных боевых контура
* Deposit через Mini App (TonConnect)


пользователь: DepositModal → POST /deposit/efhc → TonConnect sendTransaction
Страница 13


EFHC Bot v165 - Финальный аудит



экономический слой: создаётся payment intent, далее watcher/cron должен
подтвердить и начислить
gap: нет явного “ожидания подтверждения” в UX

* Browser-shop intent flow



пользователь: /browser-shop (handoff token) → create intent → показ реквизитов
(memo/to_wallet) → polling status
в UX встроено ожидание статуса (периодический опрос /hub/browser-shop-intentstatus)

Truth-layer риски


Требуется жёсткая идемпотентность там, где возможны ретраи и повторные
нажатия. OWASP прямо описывает, что отсутствие защиты от повторов в sensitive
flows приводит к финансовым ошибкам.

* Security-основание идентичности



Telegram initData must be validated, initDataUnsafe не доверять (в HEAD это
соблюдается концептуально).
TonConnect ton_proof должен проверяться сервером по
домену/payload/timestamp/signature (в HEAD реализовано в tonconnect_proof_service
по сути этого алгоритма).

Вывод: deposit/payment truth-layer по структуре сильный, но релиз зависит от
UX-закрытия результата и от устранения “ложно-боевых” admin модулей
(sale packages) и идемпотентности в операционных командах.
UI/UX release gate, белые пятна, незакрытые детали и do-to-release

Страница 14


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 5. ФИНАЛЬНЫЙ UI/UX АУДИТ БОЕВЫХ ЭКРАНОВ
Пользовательские экраны











Start (/): визуально завершён, боевой. Основная функция — живой snapshot.
Panels (/panels): боевой, много состояний (active/archive), сценарий закрыт.
Tasks (/tasks): боевой; нужно убрать любые ожидания отдельного Ads-экрана,
потому что ads.tsx — redirect, “Ads внутри Tasks” — канон.
Referrals (/referrals): боевой, зрелый.
Ranks (/ranks): боевой, зрелый.
Exchange (/exchange): боевой, но перегружен двумя критическими сценариями.
Withdraw touchpoints: критическая зона. Нет отдельного экрана и есть runtime
разрыв cancel — это ломает ощущение готового продукта.
Wallet/deposit: визуально нормальный, но “результат пополнения” в UX
недостаточно закрыт.
Hub (/hub): боевой gateway.
Browser shop (/browser-shop): боевой MVP storefront; нужен polish текстов и
следующих шагов.

Админские экраны







Admin index (/admin): контрольная точка; важно, чтобы оттуда велись реальные
operator paths и чтобы ошибки авторизации/конфигурации были понятны.
Users: боевой, но требует confirmations/guardrails.
Withdrawals: боевой, но требует сильного anti-error UX и устранения cancel break в
user-path.
Bank: боевой, но опасен без “двухшаговых подтверждений” и явных
предупреждений.
Shop: боевой переходный; требуются явные маркеры SSOT vs legacy.
Sale packages: в текущем виде выглядит как боевой экран, но экономически не
доказан как SSOT → риск “оператор делает работу, которая не влияет на продукт”.

Страница 15


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 6. БЕЛЫЕ ПЯТНА
16. backend/app/routes/withdraw_routes.py ↔ backend/app/services/withdraw_service.py:
cancel path broken





Тип: runtime white spot / broken touchpoint
Опасность: пользователь не может завершить жизненный цикл заявки;
потенциально растущие “висящие” заявки + нагрузка на оператора
Критичность: высокая
Срок: до релиза

17. Отсутствие отдельного /withdraw экрана в frontend/src/pages





Тип: product/UI navigation gap
Опасность: ожидание пользователя “Вывод” как отдельной функции не закрыто;
повышает ошибки и обращения в поддержку
Критичность: высокая
Срок: до релиза (минимум — выделить путь, даже если UI будет простым)

18. admin sale-packages контур не доказан как SSOT для пользовательских пакетов





Тип: operator misdirection / false-live module
Опасность: оператор управляет “пакетами”, которые могут не влиять на реальный
storefront/deposit; высокая цена ошибки и потери доверия
Критичность: высокая
Срок: до релиза (либо подключить к SSOT, либо убрать/пометить как legacy)

19. Идемпотентность для toggle/update в sale packages не используется по смыслу





Тип: business-flow replay риск
Опасность: двойные ретраи → двойные изменения состояния (особенно toggle)
Критичность: средняя/высокая
Срок: до релиза

20. Deposit UX не закрывает “result proof”





Тип: UX gap в sensitive money flow
Опасность: пользователь не понимает, завершилось ли пополнение; может
повторять оплату/создавать intents
Критичность: средняя
Срок: should-fix до релиза (или must-fix при ожидаемых больших объёмах)

Страница 16


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 7. НЕЗАКРЫТЫЕ ДЕТАЛИ






Withdraw cancel: требуется привести route/service к единому контракту и
обеспечить идемпотентное поведение “повторной отмены”.
Withdraw journey: выделить отдельный экран/маршрут или минимум — отдельный
UI блок “Мои заявки на вывод” с управлением статусом/отменой.
Sale packages: определить SSOT и устранить “операторскую фикцию” (модуль
выглядит живым, но не управляет реальными user-facing пакетами).
Admin shop: явно отделить legacy read-only от текущего боевого слоя.
Bank/withdrawals/referrals admin: добавить UX safeguards (подтверждения,
предупреждения, “покажи последствия”, лог действий на экране).

Страница 17


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 8. ТОП-15 ДОРАБОТОК ДО РЕЛИЗА
Must fix (релиз-блокеры)
21. Починить POST /withdraw/{id}/cancel: устранить разрыв route ↔ service и сделать
поведение идемпотентным.
22. Собрать самостоятельный пользовательский withdraw-path: отдельная page
(/withdraw) или явно выстроенный путь внутри UI с “следующим шагом”.
23. Устранить/перепривязать admin sale-packages к реальному SSOT (или убрать из
релизного набора).
24. Для всех “toggle”/неидемпотентных admin действий: сделать реальную
идемпотентную защиту от повторов (как минимум на уровне логики, не только
заголовка).
25. Усилить operator UX для approve/reject withdrawals (подтверждение, контекст,
защита от мисклика).
Should fix (до релиза желательно)
26. Разгрузить /exchange: отделить обмен и вывод (две разные критические функции).
27. Добавить “deposit result UX”: хотя бы intent-status/ожидание и подсказку
“проверяйте историю/баланс”.
28. Админ shop: визуально маркировать legacy-path как read-only и не SSOT.
29. Admin bank: двухшаговые подтверждения для mint/burn + ясное объяснение
эффекта.
30. Admin referrals: guardrails для manual bonus/reassign (контекст + подтверждение).
Polish (можно после релиза, если must/should закрыты)
31. Улучшить старт как orchestration-экран (быстрые ссылки на
withdraw/deposit/status).
32. Улучшить тексты/инструкции browser shop для минимизации ошибок оплаты.
33. Убрать остаточные “compat” хвосты или явно подписать их как “alias/redirect”.
34. Вынести admin hub links из admin_shop_routes.py в отдельный модуль
(архитектурная чистота и снижение рисков регрессий).
35. Превратить skins в полноценный user-facing контур (если это часть продуктового
обещания), либо честно оставить как фоновые rewards.

Страница 18


EFHC Bot v165 - Финальный аудит

ЧАСТЬ 9. ИТОГОВЫЙ ВЕРДИКТ






user path ready: Нет
admin path ready: Нет
economic runtime ready: Нет (из-за withdraw cancel + operator-дезориентации в
sale-packages)
combat UI/UX ready: Нет
full product release ready: Нет

Причины “Нет” — конкретные и исправимые: один критический runtime разрыв в
withdraw lifecycle, отсутствие цельного withdraw journey в UI, и ложная “боевитость”
части админского economic-контура (sale packages), плюс необходимость hardening
операторских sensitive действий.
Если продукт позиционируется как финансово-экономический runtime с реальными
балансами и выводом, то требование к “закрытости сценария” и защите sensitive flows
является обязательным (и это напрямую коррелирует с OWASP рисками для API и
business-logic flows).

Страница 19


