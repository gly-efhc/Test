Audit-Id: AUD-2026-02-28-ROUTES-INVENTORY-002
Date: 2026-02-28
Version: EFHC_Bot_v149_16_add_registry_audits
Topic: routes-inventory
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация backend routes (method/path/handler/file:line).
Sources: PDF: _raw/2026-02-28_routes-inventory_v149_16__routes_reg.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Реестр маршрутов: method, path, handler, file:line.

## Findings (FACTS)
- Всего endpoint'ов: 91 (по PDF). [[EV-001]]
- Каждая запись содержит backend/app/routes/*.py:line. [[EV-001]]

## Evidence Index
EV-001 | DOC | see files.raw | - | see Appendix | PDF

## Decisions (SSOT)
- Использовать реестр маршрутов как базу матрицы API и контроля
- регрессий. [[EV-001]]

## Actions (P0/P1/P2)
### P0
- Сверить расхождение count маршрутов с текущей базой. [[EV-001]]

### P1
- Привязать критичные маршруты к таблицам/контрактам. [[EV-001]]

### P2
- Автогенерировать routes registry в CI. [[EV-001]]

## Impact & Risks
- Реестр нужен для воспроизводимости аудита и привязки фактов к
доказательствам. [[EV-001]]

## Verification
- Сверить указанные file:line/сводные показатели с PDF и репозиторием.
  [[EV-001]]

## Appendix: Raw Extract (optional)
```text
Counts:
-
Всего
endpoint’
ов:
91
-
GET:
52
-
```
