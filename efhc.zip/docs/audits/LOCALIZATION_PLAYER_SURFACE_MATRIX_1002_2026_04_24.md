# Localization player-facing surface matrix — cycle 1002

Date: 2026-04-24
Version: v167_71 draft

## Scope

Cycle 1002 verifies the player-facing screen layer after locale bundle
repair cycles 987-999, the admin/operator matrix in cycle 1000, and the
cycle 1001 CI log repair gate.

Checked surfaces:

- Hub
- Browser-Shop
- Web-Profile
- ProfileModal
- Wallet/Profile wallet blocks
- Exchange
- Panels
- Tasks
- Referrals
- Ranks
- Withdraw
- FAQ entry points
- shared Telegram UI blocks used by player surfaces

## Fresh CI-log blocker handled inside this cycle

The user supplied `logs_66117671778.zip`. The logs showed that the next
planned localization cycle could not continue safely until two confirmed
failures were treated:

1. `pytest` failed because `docs/cycles/WORK_CYCLES_1001-1100.md`
   contained a banned legacy rank substring inside the word `operating`.
2. `npm run build` failed because admin pages imported
   `TelegramСтатусBadge` instead of the real
   `TelegramStatusBadge` component.

Both failures were repaired before player-surface localization checks were
closed.

## Player-facing corrections

The cycle removed visible Cyrillic copy from English-first player surfaces
where it was hardcoded in TSX rather than coming from locale bundles.

Corrected areas:

- FAQ quick section labels and descriptions.
- Ranks quick action button.
- Ads banner empty state.
- Global header top-up action.
- Shared Ranks table note.
- Referral tabs helper links.
- FAQ accordion quick links.
- Profile history withdraw button.
- Shared player UI defaults in `SurfaceFactsStrip` and
  `TelegramProductCard`.

## Guard

Added:

- `ops/i18n/audit_player_surface_matrix.py`

The guard checks selected player-facing pages, features and shared player
components for non-comment Cyrillic tails. It does not claim full i18n
migration of every hardcoded English string; that remains assigned to
cycles 1007-1009.

## Verification

Local targeted checks:

```text
python3 -S ops/i18n/audit_player_surface_matrix.py
OK: checked player-facing surface matrix.
Files checked: 26
```

Also rechecked:

- all-locale key and placeholder parity;
- admin/operator surface guard;
- all locale JSON parsing;
- selected value-quality guards;
- migration filename canon;
- release ZIP hygiene.

## Honest boundary

Cycle 1002 does not close backend/bot texts, FAQ data semantics,
notifications/templates, or full hardcoded string migration. Those remain
planned for cycles 1003-1021+.
