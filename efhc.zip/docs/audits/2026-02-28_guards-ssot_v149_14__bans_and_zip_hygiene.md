Audit-Id: AUD-2026-02-28-GUARDS-SSOT-001
Date: 2026-02-28
Version: EFHC_Bot_v149_14
Topic: guards-ssot
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; фиксация фактов и решений.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-GUARDS-SSOT-001.raw.md
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Свод: запреты telegram_id/rating/tgId/uid; контроль мусора в ZIP.

## Findings (FACTS)

- В проекте действует запрет на telegram_id (слитно), rating* и uid/tgId
  [[EV-001]].

## Evidence Index

EV-001 | DOC | docs/SSOT_INDEX.md | - | Перечень репо-wide bans и
обязательных проверок цикла. | Баны и проверки должны соблюдаться.

## Decisions (SSOT)

- Любой guard должен валить сборку при нарушении bans [[EV-001]].

## Actions (P0/P1/P2)

- P0: поддерживать scripts/guards так, чтобы они ловили мусор в ZIP
  (__pycache__/pyc) и banned tokens [[EV-001]].

## Impact & Risks

- Риск: нарушение канона приводит к регрессиям и отклонению PR.

## Verification

- Проверить: линтер аудитов и canon_guard проходят локально и в CI.

## Appendix: Raw Extract (optional)

See: /tmp/efhc_v149_14_1jfqo2i_/docs/audits/_raw/AUD-2026-02-28-GUARDS-
SSOT-001.raw.md
