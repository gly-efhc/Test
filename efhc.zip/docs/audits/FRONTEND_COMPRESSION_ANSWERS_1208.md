# Frontend compression answers — cycle 1208

## User answers: compression model

1. The first screen is not an action screen.  It shows general progress,
   generation and account state.
2. The bottom menu has six untouchable canonical buttons.  Subsections
   must be harmonized under them.  Visible functions need an audit and
   approval path: keep, remove, or move to admin.
3. A beautiful Wallet subsection is required, but details need a
   separate approval pass.
4. Panels, Exchange, Tasks, Referrals and Ranks are canonical pages.
   They must not be collapsed into another button.
5. Admin functions are available only through the Admin button.  Game
   pages must look the same for every user.

## User answers: Dragon-like model

1. Energy is canonical.  Names and functions stay unchanged.
   Dragon-like visual language is added only as a style layer.
2. The six existing first navigation buttons remain canonical.
3. All current first-level functions remain.
4. Exchange stays as its own canonical button.
5. Panels stays as its own canonical button.
6. Tasks and Referrals may adopt Dragon-like compact visual mechanics.
7. Ranks may become progress-card oriented if the reference does that.
8. Browser-Shop remains Web3-like through HUB.
9. Desktop browser shell is required as a future route.
10. Drawers/modals need a separate explanation and approval pass.

## Operational conclusion

Do not remove or rename canonical first-level pages.

The correct direction is:

- keep six bottom buttons;
- compress subsections inside the pages;
- remove artifact functions not used by the game process;
- move operator/debug/admin functions to admin;
- use Q/A approval before deleting visible user functions.

## Immediate impact

Cycle 1208 applied this principle to FAQ only:

- FAQ UI controls became localized;
- FAQ got compact bot-width shell;
- no canonical page was renamed or removed.
