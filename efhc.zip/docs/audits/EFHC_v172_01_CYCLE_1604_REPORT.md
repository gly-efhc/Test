# Отчёт цикла 1604 — Backend GlobalId type finalization

## Архитектурный результат

Канонический backend import surface больше не содержит `UserId`,
`PydanticUserId`, `UserIdRequest`, `UserIdResponse` и legacy helpers.
Они сохранены только в `app.identity.legacy_user_id` для исторической
совместимости и будущего cleanup-stage.

`GlobalId` и `TelegramId` остаются номинально разными типами. Их
database/provider boundaries не принимают друг друга, `bool`, `float`
или невалидный диапазон. Ошибки имеют стабильные машинные коды и
русские сообщения.

## Миграционное состояние

- Alembic: `0001 → 0002`;
- physical storage: `users.user_id BIGINT NULL`;
- `User.global_id`: synonym физического `user_id`;
- historical backfill: false;
- runtime read switch: false;
- financial ownership switch: false.

## PostgreSQL

Реальная reconciliation остаётся недоказанной. Цикл 1604 не изменяет
статус gate цикла 1603 и не разрешает backfill.

## Финальный regression

Точная collection: `2870` тестов.

- `PASSED`: `2698`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Причины пропусков:

- 95 browser E2E без `EFHC_RUN_E2E=1`;
- 72 real PostgreSQL integration без URL;
- 4 Postgres-only CI без URL;
- 1 проверка без `DATABASE_URL`.

Skip не считается выполнением PostgreSQL или Chromium-проверки.

## Что осталось

- цикл 1605: frontend branded string `GlobalId`;
- реальный PostgreSQL proof цикла 1603;
- будущие API DTO, IdentityResolver и AuthContext;
- TON Proof и Telegram provider adapters;
- fresh exact-HEAD GitHub CI после интегрированного auth-пакета.

Следующий цикл: `1605 — Frontend GlobalId string system`.
