Audit-Id: AUD-2026-02-28-CI-FAILURES-001
Date: 2026-02-28
Version: EFHC_Bot_v149_14
Topic: ci-failures
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; фиксация фактов и решений.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-CI-FAILURES-001.raw.md
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Свод: ModuleNotFoundError 'backend' при запуске из extracted/backend.

## Findings (FACTS)

- Alembic падает из-за импорта 'backend.*' в 0001 [[EV-001]].

## Evidence Index

EV-001 | LOG | logs_58890615032.zip | - | ModuleNotFoundError: No module
named 'backend' в 0001_init.py. | Импорты миграции несовместимы с
запуском из extracted/backend.
EV-002 | MIGRATION | backend/migrations/versions/0001_init.py | - |
Импорт backend.migrations.lib.safe использован в миграции. | Причина
ModuleNotFoundError в CI.

## Decisions (SSOT)

- Импорты миграций должны быть совместимы с запуском из
  extracted/backend (использовать migrations.*) [[EV-001]] [[EV-002]].

## Actions (P0/P1/P2)

- P0: заменить backend.migrations.* на migrations.* в 0001 и проверить
  alembic upgrade head [[EV-001]] [[EV-002]].

## Impact & Risks

- Риск: миграции не выполняются → CI/развёртывание блокируется
  [[EV-001]].

## Verification

- Проверить: шаг CI 'alembic upgrade head' проходит [[EV-001]].

## Appendix: Raw Extract (optional)

See: /tmp/efhc_v149_14_1jfqo2i_/docs/audits/_raw/AUD-2026-02-28-CI-
FAILURES-001.raw.md
