# AUD-2026-03-03 BANK_EFHC routes/tables audit

## Цель

Привести систему к канону центрального банка BANK_EFHC:
- истина баланса банка: efhc_core.bank_balance (EFHC_MAIN)
- банк может быть отрицательным
- user имеет main+bonus; банк хранит только main
- зеркальные логи банка используют tg_id=BANK_EFHC (алиас)

## Таблицы

- efhc_core.bank_balance
  - key: EFHC_MAIN
  - balance: numeric d8 (может быть < 0)

Исторические таблицы админки (сохранены для совместимости):
- efhc_admin.bank_balances (legacy витрина)
  - источник истины перенесён в efhc_core.bank_balance

## Маршруты

- /admin/*
  - обязателен require_admin + whitelist
  - денежные commit дополнительно проверяют whitelist в сервисах

## Найденные корректировки

1) admin_bank_service ранее использовал efhc_admin.bank_balances как истину.
   Исправлено: чтение/запись перенесены на efhc_core.bank_balance.

2) bankstate_recalc ранее пересчитывал баланс банка по tg_id в логах.
   Исправлено: main берётся из efhc_core.bank_balance.

## Дальнейшие шаги

- После стабилизации объединить миграции (0002/0003) в 0001_init.
- Удалить legacy витрины и алиасы только после полного PASS CI.
