# WATCHER / REPORTING ALIGNMENT — 2026-04-07

## Что было
- `_find_pending_order` опирался на legacy join `shop_orders.item_id -> shop_items`.
- `_create_nft_manual_request` создавал NFT-заявку через `item_id` из `shop_items`.

## Что вылечено
- `_find_pending_order` переведён на `shop_orders.type + quantity_efhc`.
- `_create_nft_manual_request` создаёт NFT-заказ через каноничные поля `type`, `status`, `tx_hash`, `extra`.

## Что ещё живо
- `_resolve_simple_deposit_qty` и другие вспомогательные shop-read helpers остаются в зоне следующей ревизии.
