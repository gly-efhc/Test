# ADMIN SHOP CRUD RE-AUDIT SLICE 681-685 (2026-04-08)

## Improved
- Admin shop is no longer limited to active storefront items.
- Card editor is no longer preview-only for core content fields.
- New item creation exists in admin flow.
- Status model `live/hidden/draft` is now persisted in admin path.

## Still open
- Delete/archive semantics.
- Dedicated image upload storage path.
- Richer mobile/desktop preview split.
- Full list/table bulk management layer.
