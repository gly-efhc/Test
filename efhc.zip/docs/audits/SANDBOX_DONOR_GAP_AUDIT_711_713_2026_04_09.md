# SANDBOX DONOR GAP AUDIT 711-713 (2026-04-09)

## Scope
Compare current EFHC full HEAD against donor sandboxes:
- horizon-ui-chakra-nextjs-main
- refine-main
- ui-main

This audit records only real EFHC-native gaps and safe adoption paths.
No direct donor copy is treated as done.

## Donor patterns already adopted
- dashboard rhythm and denser KPI/stat grouping
- grouped admin surface composition
- list/detail operator grammar for admin pages
- richer admin shop search/filter/status flow
- selected-card editor shell
- preview-first storefront thinking

## What was still not done at the time of 711-713
1. real image upload flow for admin shop cards
2. archive/delete semantics split
3. bulk actions for catalog management
4. separate VIP NFT section inside admin/shop contour
5. richer mobile/desktop preview split
6. deeper workflow toolbar and operator summary
7. field-level history trail per card

## What was safely added in 711-713
- EFHC-native `Selected item facts` panel in admin shop
- donor-gap audit captured in the full archive
- cycle/report control sync for restored 711-713 state

## Why these items were not auto-closed
The then-current partial archive was frontend-only, so server-side
upload/delete semantics could not be implemented honestly there.
The correct restoration path is to return to the last full archive and
continue only from the full scope.

## Current recommendation after restoration
Use the last full stable archive as the only recovery base.
Treat frontend-only ZIPs as partial artifacts, never as the main HEAD,
unless the user explicitly confirms that scope reduction.
