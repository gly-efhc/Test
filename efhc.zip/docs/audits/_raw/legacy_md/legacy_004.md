# Аудит кода 4

Source: Аудит кода 4.pdf
Scope: Код EFHC Bot: миграции/CI/схемы/идентификаторы
Date: unknown
Status: ACTIVE
Superseded by: -

## Findings (FACTS)

- Миграции Alembic: корректный `alembic.ini`, deterministic-check
  существования таблиц/схем, порядок шагов CI.
- Pytest/pytest-asyncio: корректная конфигурация `pytest.ini`, фикстуры
  уровня session, стабильность CI.
- Схемы БД (DB_SCHEMA/search_path/multi-schema) и риски
  рассинхронизации.
- Канон идентификатора пользователя `tg_id` (единый идентификатор).

## Actions (DECISIONS)

- P0: Привести 0001 и Alembic-конфиг к детерминированной схеме: schema
  на уровне таблиц, проверки to_regclass.
- P1: Стабилизировать pytest/pytest-asyncio: фикстуры уровня session,
  Postgres-only, без pip -U.
- P0: Зафиксировать tg_id как единственный идентификатор во всех слоях
  (routes/services/models/docs).
- P0: Централизовать имена схем в Settings (DB_SCHEMA_CORE,
  DB_SCHEMA_ADMIN) и запретить хардкоды.

## Appendix: Raw Extract (optional)

- > Ниже — короткие фрагменты из извлечённого текста PDF вокруг ключевых
  терминов (могут содержать артефакты PDF-экстракции).
- - CI: запрет “самовольных апгрейдов” pytest- стека ```diff diff --git
  a/docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml
  b/docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml @@ - pip install -r
  extracted/backend/requirements.txt - pip install -U pytest
  pytest-asyncio alembic "psycopg[binary]" PyJW...
- - .mark.asyncio` на все async тесты без маркера.  Ожидаемый эффект:
  исчезают “async def not natively supported” и снижается риск
  teardown-loop. ### Цикл P0-2: «Миграции и DB- объекты, которые требуют
  тесты» Команды: ```bash # чистая БД alembic -c backend/alembic.ini...
- - 026-02-27** по предоставленным логам CI фиксируется: **17 падений
  тестов + 1 ошибка teardown**, которые блокируют «зелёный» прогон.
  Корневые причины группируются в 4 P0- блока: 1) **Pytest asyncio
  strict**: часть `async def` тестов **не помечена**
  `@pytest.mark.asyncio`, из ‑ за ...
- - м CI фиксируется: **17 падений тестов + 1 ошибка teardown**, которые
  блокируют «зелёный» прогон. Корневые причины группируются в 4 P0-
  блока: 1) **Pytest asyncio strict**: часть `async def` тестов **не
  помечена** `@pytest.mark.asyncio`, из ‑ за чего pytest-asyncio в
  **strict mode...
- - В CI используется `pip install -U pytest pytest-asyncio ...` →
  рассогласование с requirements, нестабильный teardown/event loop |
  Непредсказуемые падения CI, “different loop” | Убрать `-U` для pytest-
  стека, ставить из `requirements*.txt` | | P0 | `pytest.ini` + тесты |
  `asyncio_...
- - | `tests/test_total_generated_kwh_append_only.py` | есть | |
  EXCHANGE_ALL (только всё доступное) |
  `tests/test_concurrency_exchange_all.py` + unit обмена | есть, усилить
  отрицательные случаи | | Идемпотентность денег |
  `tests/efhc_backend/unit/test_ssot_idempotency.py`, concurren...
- - **Alembic init- модель не закрывает SSOT/DB_SCHEMA и нужды тестов**:
  критично — `payment_intents.id` без автогенерации → **нет
  `payment_intents_id_seq`**; sanity-check в миграции проверяет слишком
  мало таблиц; часть FK без явных схем. Для FK в multi-schema нужно
  задавать `source_...
- - ывает SSOT/DB_SCHEMA и нужды тестов**: критично —
  `payment_intents.id` без автогенерации → **нет
  `payment_intents_id_seq`**; sanity-check в миграции проверяет слишком
  мало таблиц; часть FK без явных схем. Для FK в multi-schema нужно
  задавать `source_schema/referent_schema`. citet...
- ## Рекомендации (обобщённо)
