# Аудит кода 2

Source: Аудит кода 2.pdf
Scope: Код EFHC Bot: углубление по модулям/рискам
Date: unknown
Status: SUPERSEDED
Superseded by: Аудит кода 3_.md

## Findings (FACTS)

- Усиление `ops/canon_guard.py` (SSOT/запреты/пакетность/проверки перед
  сборкой).
- Миграции Alembic: корректный `alembic.ini`, deterministic-check
  существования таблиц/схем, порядок шагов CI.
- Pytest/pytest-asyncio: корректная конфигурация `pytest.ini`, фикстуры
  уровня session, стабильность CI.
- Канон идентификатора пользователя `tg_id` (единый идентификатор).

## Actions (DECISIONS)

- P0: Привести 0001 и Alembic-конфиг к детерминированной схеме: schema
  на уровне таблиц, проверки to_regclass.
- P1: Стабилизировать pytest/pytest-asyncio: фикстуры уровня session,
  Postgres-only, без pip -U.
- P0: Зафиксировать tg_id как единственный идентификатор во всех слоях
  (routes/services/models/docs).
- P0: Централизовать имена схем в Settings (DB_SCHEMA_CORE,
  DB_SCHEMA_ADMIN) и запретить хардкоды.

## Appendix: Raw Extract (optional)

- > Ниже — короткие фрагменты из извлечённого текста PDF вокруг ключевых
  терминов (могут содержать артефакты PDF-экстракции).
- - afe` на фронтенде** и валидировать `initData` на бэкенде.  ##
  Область анализа и артефакты Проанализировано (из ZIP): - Backend:
  Python (FastAPI/ASGI), Alembic, SQLAlchemy async, aiogram. - Frontend:
  Next.js/TypeScript. - CI/guard: `ops/canon_guard.py`, архитектурные...
- - `SYNC_DATABASE_URL`. ```bash docker compose up -d db export
  DATABASE_URL="postgresql+asyncpg://efhc:efhc@localhost:5432/efhc"
  export ASYNC_DATABASE_URL="$DATABASE_URL" export
  SYNC_DATABASE_URL="postgresql://efhc:efhc@localhost:5432/efhc" cd
  backend alembic -c alembic.ini upgrade ...
- - BASE_URL`. ```bash docker compose up -d db export
  DATABASE_URL="postgresql+asyncpg://efhc:efhc@localhost:5432/efhc"
  export ASYNC_DATABASE_URL="$DATABASE_URL" export
  SYNC_DATABASE_URL="postgresql://efhc:efhc@localhost:5432/efhc" cd
  backend alembic -c alembic.ini upgrade head cd .....
- - DataUnsafe.user` для UI | Риск, если кто ‑ то начнет использовать
  это как источник истины | Явно закрепить “только UI”; бэкенд принимает
  только `initData` и валидирует  | | Q1 | **Средне** |
  Конфигурация/поддержка | `pyproject.toml` + `pytest.ini` |
  Дублирование кон...
- - кто ‑ то начнет использовать это как источник истины | Явно
  закрепить “только UI”; бэкенд принимает только `initData` и валидирует
  | | Q1 | **Средне** | Конфигурация/поддержка | `pyproject.toml` +
  `pytest.ini` | Дублирование конфигов pytest в 2 местах | Риск
  рассин...
- - ко UI”; бэкенд принимает только `initData` и валидирует  | | Q1 |
  **Средне** | Конфигурация/поддержка | `pyproject.toml` + `pytest.ini`
  | Дублирование конфигов pytest в 2 местах | Риск рассинхронизации |
  Оставить один SSOT (рекомендую `pytest.ini`) | | P1 | **Низко/...
- - к | Что исправить | |---|---|---|---|---|---|---| | C1 |
  **Критично** | Тесты/ CI | `tests/test_concurrency_exchange_all.py` |
  `IndentationError` из ‑ за строки без отступа внутри `async def` | CI
  не запускает тесты вообще | Исправить отступ у `bank_tg_id = ...` | |
  C2 | **Критич...
- - обще | Исправить отступ у `bank_tg_id = ...` | | C2 | **Критично** |
  Тесты/ CI | `tests/test_concurrency_withdraw_double.py` |
  `IndentationError` из ‑ за строки без отступа внутри `async def` | CI
  не запускает тесты вообще | Исправить отступ у `user_tg_id = ...` | |
  L1 | **Высоко...
- ## Рекомендации (обобщённо)
