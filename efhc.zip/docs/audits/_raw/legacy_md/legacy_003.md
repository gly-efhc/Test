# Аудит кода 3_

Source: Аудит кода 3_.pdf
Scope: Код EFHC Bot: расширенный аудит и CI
Date: unknown
Status: SUPERSEDED
Superseded by: Аудит кода 4.md

## Findings (FACTS)

- Миграции Alembic: корректный `alembic.ini`, deterministic-check
  существования таблиц/схем, порядок шагов CI.
- Pytest/pytest-asyncio: корректная конфигурация `pytest.ini`, фикстуры
  уровня session, стабильность CI.
- Схемы БД (DB_SCHEMA/search_path/multi-schema) и риски
  рассинхронизации.
- Канон идентификатора пользователя `tg_id` (единый идентификатор).

## Actions (DECISIONS)

- P0: Привести 0001 и Alembic-конфиг к детерминированной схеме: schema
  на уровне таблиц, проверки to_regclass.
- P1: Стабилизировать pytest/pytest-asyncio: фикстуры уровня session,
  Postgres-only, без pip -U.
- P0: Зафиксировать tg_id как единственный идентификатор во всех слоях
  (routes/services/models/docs).
- P0: Централизовать имена схем в Settings (DB_SCHEMA_CORE,
  DB_SCHEMA_ADMIN) и запретить хардкоды.

## Appendix: Raw Extract (optional)

- > Ниже — короткие фрагменты из извлечённого текста PDF вокруг ключевых
  терминов (могут содержать артефакты PDF-экстракции).
- - r-compose): ```bash docker compose up -d db export
  DATABASE_URL="postgresql+asyncpg://efhc:efhc@localhost:5432/efhc_test"
  export ASYNC_DATABASE_URL="$DATABASE_URL" export
  SYNC_DATABASE_URL="postgresql://efhc:efhc@localhost:5432/efhc_test" cd
  backend alembic -c alembic.ini upgrade...
- - ```bash docker compose up -d db export
  DATABASE_URL="postgresql+asyncpg://efhc:efhc@localhost:5432/efhc_test"
  export ASYNC_DATABASE_URL="$DATABASE_URL" export
  SYNC_DATABASE_URL="postgresql://efhc:efhc@localhost:5432/efhc_test" cd
  backend alembic -c alembic.ini upgrade head cd .. ...
- - # Полный аудит кода 3 ## Executive summary В предоставленном проекте
  выявлены дефекты, которые **прямо ломают безопасность
  аутентификации**, **фоновые задачи**, а также **CI/pytest ‑ прогон**.
  Ключевые проблемы (самые “несущие”): - **Критично (Security/Auth):** в
  `validate_telegr...
- - nitDataUnsafe`. В проде это надо жёстко выключить (даже если бэкенд
  защищён), поскольку `initDataUnsafe` официально **не доверенный
  источник**.  ## Область анализа и артефакты Проанализированы файлы
  проекта (архив v148_36) и CI ‑ логи (pytest прогон на PostgreSQL). ...
- - льтр due_jobs; сбрасывать `next_allowed_at` на успехе | | TST ‑
  DBMIG ‑ REC | **Критично** | CI/Tests | `tests/conftest.py` |
  `recursive dependency involving fixture 'db_migrated'` → массовые
  setup errors | Исправить сигнатуру фикстуры, привязать к
  `schemas_ready` | | TST ‑ PRAGM...
- - jobs; после успешного выполнения — метка backoff должна очищаться.
  ### Исправление рекурсивной фикстуры `db_migrated` ```diff ---
  a/tests/conftest.py +++ b/tests/conftest.py @@
  @pytest.fixture(scope="session") async def db_migrated( - db_migrated,
  + schemas_ready, ) -> None: ``` ...
- - Mini App): ```mermaid flowchart TD FE[Frontend (Next.js)]
  -->|X-Telegram-Init-Data: initData| API[Backend (FastAPI)] API -->
  MW[TelegramWebAppAuthMiddleware] MW -->|validate initData signature|
  SEC[validate_telegram_init_data] SEC -->|request.state.tg_id|
  ROUTES[Protected routes/...
- - fe` не является доверенным источником, доверять можно только
  `initData` после server ‑ валидации.  ```diff ---
  a/frontend/src/lib/api.ts +++ b/frontend/src/lib/api.ts @@ - } else {
  - // Dev fallback: if initData is missing, try to pass tg_id header. -
  // Backend mus...
- ## Рекомендации (обобщённо)
