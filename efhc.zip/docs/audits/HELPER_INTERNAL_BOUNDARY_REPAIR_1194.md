# HELPER INTERNAL BOUNDARY REPAIR 1194

Date: 2026-05-16
Cycle: 1194

## Finding

Infrastructure roads can look like normal public roads if they remain in
OpenAPI without an explicit boundary.  The audit class was
helper/internal route drift.

## Repair

`GET /cron/tick` and `POST /tg/webhook` remain active runtime routes,
but are hidden from OpenAPI through `include_in_schema=False`.  They are
also marked as internal in route SSOT maps.  Secret checks remain in
active code.

## Scope boundary

This cycle does not remove cron or webhook runtime behavior.  It only
prevents helper/internal roads from looking like public release roads.

## Evidence

- `ops/routes/check_helper_internal_boundary.py`
- `tests/architecture/test_helper_internal_boundary_guard.py`
- `reports/generated/helper_internal_1194.json`
