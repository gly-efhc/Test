# LANGUAGE DROPDOWN AND PAY WALLET REPAIR 1206

Status: fixed finding, not full release readiness.
HEAD: v168_22 browser shop cleanup.
Result archive: v168_23 language dropdown and pay wallet.

## Incoming user task

The user asked to re-check the profile language switcher and to make it
one button with the current language.  After tapping that button the
user
must choose another bot language from a dropdown list.

The user also uploaded two reference RAR sandboxes and asked how EFHC
can
be rebuilt visually in the same spirit while keeping all EFHC functions.

Cycle 1206 also continues the visual repair plan after browser shop
cleanup: the store pay button must use the backend `tonconnect_tx`
inside the code and open the wallet transaction flow without rendering
technical payloads to the user.

## What was found

The previous profile implementation used a horizontal language rail with
all languages visible at once.  That was useful as a first repair,
but it
did not match the new user decision: one active-language button and a
choice list after tap.

The runtime language route itself was already repaired in v168_18:

- selected settings language controls `loadDict(lang)`;
- `settingsHydrated` prevents early default settings from overwriting
  the
  stored language;
- bottom navigation labels remain locked in English by canon.

The browser shop public page created an intent, but did not send the
returned TonConnect transaction to the wallet.  This left the public
payment road visually clean, but not yet aligned with the required
`Оплатить` -> wallet transaction behavior.

## Code changes

Changed files:

- `frontend/src/components/ProfileModal.tsx`
- `frontend/src/styles/globals.css`
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`

Profile language selector:

- replaced the all-language rail with one current-language button;
- added dropdown state `languageMenuOpen`;
- added `selectLanguage(lang)` to update settings and close the menu;
- kept all languages from `SUPPORTED_LANGS`;
- kept language labels translated through `profile.lang.*` keys.

Browser shop pay button:

- imports `useTonConnectUI`;
- parses create-intent response;
- normalizes `parsed.tonconnect_tx` with `normalizeTonConnectTx`;
- calls `tonConnectUI.sendTransaction(tx as any)`;
- shows only human status messages;
- never renders raw `tonconnect_tx`, wallet, memo or copy blocks.

## Guards

Added:

- `tests/architecture/test_browser_shop_pay_wallet_guard.py`

Updated:

- `tests/architecture/test_profile_language_switch_guard.py`

The guards check:

- runtime UI dictionary is still controlled by `loadDict(lang)`;
- default settings are not saved before hydration;
- profile language selector is a single dropdown button;
- browser shop payment uses TonConnect transaction internally;
- raw transaction payload is not rendered in public storefront JSX.

## Checks

Executed locally:

- `python3 -m pytest` on the profile and browser-shop visual guards;
- `python3 -m py_compile` for the new guard;
- `npm ci --ignore-scripts`;
- `npx tsc --noEmit`;
- `npm run build` started and compiled successfully, but timed out at
  `Collecting page data`, so build success is not claimed.

GitHub CI was not run.

## Not claimed

This cycle does not claim full visual release readiness.

Open items remain:

- browser screenshot proof;
- full desktop browser shell implementation;
- full Dragon/Web3 visual skin system;
- complete public payment status polling proof;
- GitHub CI proof.
