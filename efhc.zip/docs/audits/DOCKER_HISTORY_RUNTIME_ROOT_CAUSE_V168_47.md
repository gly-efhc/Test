# Docker history runtime root cause — v168_47

## Source

User provided `Докер история.txt` after the v168_46 rollback.
The file shows that the earlier diagnosis was incomplete.

## Actual finding

The Docker build did not prove a permanent frontend npm failure.
The history shows `npm ci` continuing while the backend image is
exported, and later the containers reach runtime and backend health
checks return
`200 OK`.

The real runtime blocker is backend database connection creation:

```text
TypeError: connect() got an unexpected keyword argument 'sslmode'
```

This happens when a PostgreSQL asyncpg URL contains the psycopg-style
query parameter `sslmode`. SQLAlchemy passes the parameter to asyncpg,
but asyncpg does not accept it as a connection keyword.

## Secondary findings

The history also shows repeated:

```text
BOT_TOKEN is not configured
Telegram initData validation failed: 500: Server is not configured
```

This is a configuration warning and explains Telegram-authenticated
requests returning controlled 422/validation responses. It is not the
root cause of the database crash.

## Repair

- Added asyncpg DSN normalisation in
  `backend/app/core/database_core.py`.
- Removed local Docker `?sslmode=disable` from Docker compose defaults.
- Kept support for external SSL-required URLs by mapping
  `sslmode=require|verify-ca|verify-full` to asyncpg `ssl=True`.
- Kept the v168_37 frontend dependency baseline restored in v168_46.

## Release note

This is a backend runtime/Docker environment repair, not a visual UI
change. The browser frontend can still show safe fallback UI while
Telegram token or user identity are absent, but backend database
connection must not crash on local Docker startup.
