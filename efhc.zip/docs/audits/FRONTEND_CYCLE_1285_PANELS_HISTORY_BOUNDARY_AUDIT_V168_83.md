# FRONTEND CYCLE 1285 PANELS HISTORY BOUNDARY AUDIT

Date: 2026-05-21
Archive: EFHC_Bot_v168_83_cycle_1285_panels_history_boundary.zip
Cycle: 1285

## Purpose

Cycle 1285 protects the boundary between the Panels screen and the
account History surface.

Panels is not a wallet dashboard and not a financial history page.
Panels must show panel activation, active panels, archive panels and
panel timers.

History is the common account history for all financial movements.

## Canon

- Panels keeps panel activation and panel lists.
- Panels may provide a small secondary link to account History.
- Panels must not show Wallet as a panel action.
- Wallet is only the connected-wallet list surface.
- History is account-level and not wallet-level.

## Code changes

Updated `frontend/src/pages/panels.tsx`:

- added an explicit account-history boundary marker;
- kept a small History link inside activation context;
- removed the Wallet button from the Panels context;
- kept panel activation, active/archive tabs and countdowns intact.

Updated `frontend/src/styles/globals.css`:

- added compact style for the history boundary note;
- kept the History action secondary and non-dominant.

Updated locale JSON files:

- added `panels.history_boundary_note`.

## Guard

Added:

`tests/architecture/test_panels_history_boundary.py`

The guard checks that Panels has an account-history boundary, that Panels
no longer opens Wallet from the panel context, and that the new locale key
exists in all active locale files.

## Not changed

- backend;
- database;
- migrations;
- panel economy;
- payment logic;
- bottom navigation;
- admin routes.

## Result

Panels now keeps the panel work surface separate from Wallet and History.
History remains reachable but does not overload the panel page.
