# Duplicate overlap proposal — 2026-04-08

## Scope
This document records overlap zones found during the revival wave. By user rule,
no file from this list is deleted automatically. The workflow is: compare ->
transfer useful content -> show duplicate to the user -> delete only after
explicit agreement.

## Overlap zones

### 1. Shop runtime overlap
- `backend/app/services/orders_service.py`
- `backend/app/services/shop_service.py`
- `backend/app/services/watcher_service.py`
- `backend/app/services/payment_intents_service.py`

Action: compare domain boundaries and move any still-useful read/write logic
from `orders_service.py` into the active shop runtime before any removal is even
proposed.

### 2. Exchange UI overlap
- `frontend/src/components/ExchangePanel.tsx`
- `frontend/src/pages/exchange.tsx`

Action: panel is now connected as the partial-exchange widget. Next step is to
review whether the card summary in `pages/exchange.tsx` duplicates too much of
the same interaction and should be reduced.

### 3. Referrals UI overlap
- `frontend/src/components/ReferralsTabs.tsx`
- `frontend/src/pages/referrals.tsx`
- `frontend/src/pages/referrals/active.tsx`
- `frontend/src/pages/referrals/inactive.tsx`

Action: tabs are now connected as shared navigation. Next step is only visual
and wording unification, not deletion.
