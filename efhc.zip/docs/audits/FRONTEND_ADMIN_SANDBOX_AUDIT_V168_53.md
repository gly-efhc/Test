# FRONTEND / ADMIN SANDBOX AUDIT V168.53

## HEAD

- Accepted HEAD: `EFHC_Bot_v168_52_visual_gap_audit.zip`.
- Additional visual donor: `Песочница.xz`.
- `Песочница.xz` was decoded as XZ and extracted as a POSIX tar archive.
- Sandbox root: `EFHC_SANDBOX_COMPACT_v002`.

## User answers applied

1. Energy question was not a request to remove data. It means placement of
   secondary mini-cards: visible under the hero or moved into a compact
   details block. Energy was not changed in this pass.
2. FAQ must be useful, compact, and fit a smartphone screen. It must show
   the whole list immediately, without heavy category-pill visualization.
3. Profile Wallet must use real wallet/history components instead of the
   demonstration wallet state map.
4. Admin Panel is only about 35 percent visually acceptable. It must become
   a real operator console with understandable modules, graphical overview,
   and separate full subsections.
5. Browser-Shop payment states must be human-readable for all locale files.

## Sandbox principles used

From `EFHC_SANDBOX_COMPACT_v002` and the included UI/admin references, the
useful transfer principles are:

- dashboard first, not debug dump;
- large app buttons for subsections;
- clear KPI cards above secondary details;
- graphical bars/charts near the top;
- diagnostics hidden behind a service section;
- strong card hierarchy and clear action hierarchy;
- mobile-first grid: one column on narrow screens;
- no brand copying from donors.

## What was wrong in current Admin

- Main admin screen mixed diagnostics, raw counters, module tabs, quick
  buttons, transfer shortcuts, facts and charts in one flow.
- Route diagnostics occupied primary visual space.
- Section grouping used a technical wording layer.
- Main module grid was present but still felt secondary.
- User needed a real section launcher, not scattered buttons.

## Admin layout applied in this pass

New order:

1. Operator hero.
2. Four KPI cards.
3. Large core module grid:
   - Пользователи
   - Банк
   - Выводы
   - Магазин
   - Задания
   - Отчёты
   - Рефералы
   - Панели
4. Graphical key indicators.
5. Quick facts table.
6. Operator tools:
   - HUB
   - Шаблоны
   - Депозиты EFHC
7. Collapsed service area:
   - Диагностика
   - Логи
   - Реклама
   - Sale packages
   - route health strip

## FAQ change applied

- `/faq` now passes `openAll` to `FaqVerticalTree`.
- Sections and subsections open by default so the full question list is
  visible immediately.
- Questions remain collapsible to keep the smartphone screen compact.
- FAQ CSS was compressed: smaller spacing, smaller summaries, softer
  borders, vertical left rails, less card bulk.

## Profile / Wallet change applied

- Removed demonstration wallet state-map from `/web-profile?section=wallet`.
- Reused `ProfileWalletSection` for real linked wallets.
- Web Profile now reads `/wallets/me` through `useWalletsMe`.
- Make primary/remove actions invalidate the wallet query.
- Real history section now reuses `ProfileHistorySection`.
- History loads `/wallets/balance-history`.
- Withdraw history loads `/withdraw/list?global_id=...`.
- Layout context now exposes `disconnectWalletSession` so Web Profile can
  disconnect TonConnect session through the same runtime path.

## Browser-Shop change applied

- Raw payment state badge labels are no longer `pending/checking/done/error`.
- Badge now uses `portal.browser_shop.payment_state_*` keys.
- Added human-readable payment status labels to all 13 locale files:
  - `idle`
  - `pending`
  - `checking`
  - `done`
  - `error`

## Not changed

- No backend economic logic changed.
- No database migrations changed.
- No canonical bottom menu changed.
- No routes removed.
- No Energy composition change made yet.
- No Telegram-only dependency introduced.

## Validation

- `python3 ops/local/check_frontend_routes.py` -> OK, 13 discovered link/push routes.
- `python3 -m compileall -q ops/local tests/architecture` -> OK.
- `npm ci --ignore-scripts --no-audit --no-fund` was used only for local build validation.
- `./node_modules/.bin/tsc --noEmit --pretty false` -> OK.
- `NEXT_TELEMETRY_DISABLED=1 npm --prefix frontend run build -- --no-lint` -> OK:
  pages compiled, static pages generated, route table emitted.
- `frontend/node_modules` and `frontend/.next` were removed before packaging.
