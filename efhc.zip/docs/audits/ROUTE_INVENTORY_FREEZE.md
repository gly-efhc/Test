# ROUTE INVENTORY FREEZE

> Status note (2026-04-04 later wave): this freeze remains historical inventory context. Current runtime/API prefix alignment is now governed by `backend/app/main.py`, `frontend/src/lib/api.ts` and the post-fix hard-fix wave.


Дата freeze: 2026-03-31

- Active routes in freeze: 89
- Источник истины: `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`
- Сервисные ссылки извлекаются из `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv` (`evidence_refs`).
- `ROUTE_ONLY_OR_INLINE` означает: отдельный service-файл прямым доказательством не подтверждён, либо логика inline/route-only.

## Колонки freeze

- `method`
- `path`
- `file`
- `router_module`
- `prefix`
- `service_refs`
- `auth_type`

## Inventory

| # | method | path | file | prefix | service_refs | auth_type |
|---|---|---|---|---|---|---|
| 1 | GET | `/admin/ads/providers` | `backend/app/routes/admin_ads_routes.py` | `admin:ads` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 2 | GET | `/admin/bank/balance` | `backend/app/routes/admin_routes.py` | `admin` | `backend/app/services/admin/admin_bank_service.py` | `admin` |
| 3 | POST | `/admin/bank/burn` | `backend/app/routes/admin_routes.py` | `admin` | `backend/app/services/admin/admin_bank_service.py; backend/app/services/admin/admin_logging.py` | `admin` |
| 4 | POST | `/admin/bank/mint` | `backend/app/routes/admin_routes.py` | `admin` | `backend/app/services/admin/admin_bank_service.py; backend/app/services/admin/admin_logging.py` | `admin` |
| 5 | GET | `/admin/hub/links` | `backend/app/routes/admin_shop_routes.py` | `admin:hub` | `backend/app/services/admin/admin_hub_links_service.py` | `admin` |
| 6 | POST | `/admin/hub/links` | `backend/app/routes/admin_shop_routes.py` | `admin:hub` | `backend/app/services/admin/admin_hub_links_service.py` | `admin` |
| 7 | POST | `/admin/hub/links/reorder` | `backend/app/routes/admin_shop_routes.py` | `admin:hub` | `backend/app/services/admin/admin_hub_links_service.py` | `admin` |
| 8 | PUT | `/admin/hub/links/{link_id}` | `backend/app/routes/admin_shop_routes.py` | `admin:hub` | `backend/app/services/admin/admin_hub_links_service.py` | `admin` |
| 9 | POST | `/admin/hub/links/{link_id}/toggle` | `backend/app/routes/admin_shop_routes.py` | `admin:hub` | `backend/app/services/admin/admin_hub_links_service.py` | `admin` |
| 10 | GET | `/admin/logs/transfers` | `backend/app/routes/admin_logs_routes.py` | `admin-logs` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 11 | GET | `/admin/panels/` | `backend/app/routes/admin_panels_routes.py` | `admin-panels` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 12 | PATCH | `/admin/panels/{panel_id}/activate` | `backend/app/routes/admin_panels_routes.py` | `admin-panels` | `backend/app/services/admin/admin_logging.py` | `admin` |
| 13 | PATCH | `/admin/panels/{panel_id}/deactivate` | `backend/app/routes/admin_panels_routes.py` | `admin-panels` | `backend/app/services/admin/admin_logging.py` | `admin` |
| 14 | POST | `/admin/referrals/reassign` | `backend/app/routes/admin_referral_routes.py` | `admin:referrals` | `backend/app/services/referral_service.py` | `admin` |
| 15 | GET | `/admin/reports/overview` | `backend/app/routes/admin_routes.py` | `admin` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 16 | GET | `/admin/sale-packages/` | `backend/app/routes/admin_sale_packages_routes.py` | `admin` | `backend/app/services/admin/admin_sale_packages_service.py` | `admin` |
| 17 | POST | `/admin/sale-packages/` | `backend/app/routes/admin_sale_packages_routes.py` | `admin` | `backend/app/services/admin/admin_sale_packages_service.py` | `admin` |
| 18 | POST | `/admin/sale-packages/{package_id}/toggle` | `backend/app/routes/admin_sale_packages_routes.py` | `admin` | `backend/app/services/admin/admin_sale_packages_service.py` | `admin` |
| 19 | POST | `/admin/shop/items/set-price` | `backend/app/routes/admin_shop_routes.py` | `admin:shop` | `backend/app/services/shop_service.py` | `admin` |
| 20 | GET | `/admin/shop/orders` | `backend/app/routes/admin_shop_routes.py` | `admin:shop` | `backend/app/services/shop_service.py` | `admin` |
| 21 | POST | `/admin/ton/reconcile` | `backend/app/routes/admin_routes.py` | `admin` | `backend/app/services/transactions_service.py; backend/app/services/watcher_service.py` | `admin` |
| 22 | POST | `/admin/transfer` | `backend/app/routes/admin_routes.py` | `admin` | `backend/app/services/transactions_service.py` | `admin` |
| 23 | GET | `/admin/users/search` | `backend/app/routes/admin_users_routes.py` | `admin-users` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 24 | GET | `/admin/users/{tg_id}` | `backend/app/routes/admin_users_routes.py` | `admin-users` | `ROUTE_ONLY_OR_INLINE` | `admin` |
| 25 | PATCH | `/admin/users/{tg_id}/active` | `backend/app/routes/admin_users_routes.py` | `admin-users` | `backend/app/services/admin/admin_logging.py` | `admin` |
| 26 | PATCH | `/admin/users/{tg_id}/vip` | `backend/app/routes/admin_users_routes.py` | `admin-users` | `backend/app/services/admin/admin_logging.py` | `admin` |
| 27 | POST | `/admin/users/{tg_id}/wallet/reset` | `backend/app/routes/admin_users_routes.py` | `admin-users` | `backend/app/services/admin/admin_logging.py` | `admin` |
| 28 | GET | `/admin/withdrawals` | `backend/app/routes/admin_withdrawals_routes.py` | `admin:withdrawals` | `backend/app/services/admin/admin_withdrawals_service.py` | `admin` |
| 29 | POST | `/admin/withdrawals/{request_id}/approve` | `backend/app/routes/admin_withdrawals_routes.py` | `admin:withdrawals` | `backend/app/services/admin/admin_withdrawals_service.py; backend/app/services/transactions_service.py` | `admin` |
| 30 | POST | `/admin/withdrawals/{request_id}/reject` | `backend/app/routes/admin_withdrawals_routes.py` | `admin:withdrawals` | `backend/app/services/admin/admin_withdrawals_service.py; backend/app/services/transactions_service.py` | `admin` |
| 31 | POST | `/ads/callback/{provider}` | `backend/app/routes/ads_routes.py` | `ads` | `backend/app/services/tasks_service.py` | `user` |
| 32 | GET | `/ads/slot` | `backend/app/routes/ads_routes.py` | `ads` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 33 | POST | `/api/admin/referrals/manual-bonus` | `backend/app/routes/admin_referral_routes.py` | `admin:referrals` | `backend/app/services/referral_service.py; backend/app/services/transactions_service.py` | `admin` |
| 34 | GET | `/api/admin/referrals/summary` | `backend/app/routes/admin_referral_routes.py` | `admin:referrals` | `backend/app/services/referral_service.py` | `admin` |
| 35 | POST | `/api/admin/submissions/{submission_id}/moderate` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py; backend/app/services/transactions_service.py` | `admin` |
| 36 | GET | `/api/admin/tasks` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 37 | POST | `/api/admin/tasks` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 38 | DELETE | `/api/admin/tasks/{task_id}` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 39 | GET | `/api/admin/tasks/{task_id}` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 40 | PATCH | `/api/admin/tasks/{task_id}` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 41 | GET | `/api/admin/tasks/{task_id}/subs` | `backend/app/routes/admin_tasks_routes.py` | `admin:tasks` | `backend/app/services/tasks_service.py` | `admin` |
| 42 | GET | `/api/v1/me` | `backend/app/routes/me_routes.py` | `me` | `backend/app/services/nft_check_service.py` | `user` |
| 43 | GET | `/cron/tick` | `backend/app/routes/system_routes.py` | `system` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 44 | POST | `/deposit/efhc` | `backend/app/routes/deposit_routes.py` | `deposit` | `backend/app/services/payment_intents_service.py` | `user` |
| 45 | GET | `/deposit/packages` | `backend/app/routes/deposit_routes.py` | `deposit` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 46 | POST | `/exchange/convert/{tg_id}` | `backend/app/routes/exchange_routes.py` | `exchange` | `backend/app/services/exchange_service.py; backend/app/services/transactions_service.py` | `user` |
| 47 | GET | `/exchange/history/{tg_id}` | `backend/app/routes/exchange_routes.py` | `exchange` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 48 | GET | `/exchange/preview/{tg_id}` | `backend/app/routes/exchange_routes.py` | `exchange` | `backend/app/services/energy_service.py; backend/app/services/exchange_service.py` | `user` |
| 49 | GET | `/health` | `backend/app/routes/system_routes.py` | `system` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 50 | GET | `/health/db` | `backend/app/routes/system_routes.py` | `system` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 51 | GET | `/health/db-schema` | `backend/app/routes/system_routes.py` | `system` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 52 | POST | `/hub/efhc-handoff` | `backend/app/routes/hub_routes.py` | `hub` | `backend/app/routes/hub_routes.py` | `user` |
| 53 | GET | `/nft/has_vip` | `backend/app/routes/nft_routes.py` | `nft` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 54 | POST | `/panels/buy/{tg_id}` | `backend/app/routes/panels_routes.py` | `panels` | `backend/app/services/panels_service.py; backend/app/services/transactions_service.py` | `user` |
| 55 | POST | `/panels/activate/{tg_id}` | `backend/app/routes/panels_routes.py` | `panels` | `backend/app/services/panels_service.py; backend/app/services/transactions_service.py` | `user` |
| 56 | GET | `/panels/{tg_id}/active` | `backend/app/routes/panels_routes.py` | `panels` | `backend/app/services/energy_service.py; backend/app/services/panels_service.py` | `user` |
| 57 | GET | `/panels/{tg_id}/archive` | `backend/app/routes/panels_routes.py` | `panels` | `backend/app/services/energy_service.py; backend/app/services/panels_service.py` | `user` |
| 58 | GET | `/panels/{tg_id}/summary` | `backend/app/routes/panels_routes.py` | `panels` | `backend/app/services/panels_service.py` | `user` |
| 59 | GET | `/payment-intents/{intent_id}` | `backend/app/routes/payment_intents_routes.py` | `payment_intents` | `backend/app/services/payment_intents_service.py` | `user` |
| 60 | GET | `/ranks/my-plus-top` | `backend/app/routes/ranks_routes.py` | `ranks` | `backend/app/services/ranks_service.py` | `user` |
| 61 | GET | `/ranks/top` | `backend/app/routes/ranks_routes.py` | `ranks` | `backend/app/services/ranks_service.py` | `user` |
| 62 | GET | `/referrals/active` | `backend/app/routes/referrals_routes.py` | `referrals` | `backend/app/services/referral_service.py` | `user` |
| 63 | GET | `/referrals/counters` | `backend/app/routes/referrals_routes.py` | `referrals` | `backend/app/services/referral_service.py` | `user` |
| 64 | GET | `/referrals/inactive` | `backend/app/routes/referrals_routes.py` | `referrals` | `backend/app/services/referral_service.py` | `user` |
| 65 | GET | `/shop/catalog` | `backend/app/routes/shop_routes.py` | `shop` | `backend/app/services/shop_service.py` | `user` |
| 66 | POST | `/shop/order-external` | `backend/app/routes/shop_routes.py` | `shop` | `backend/app/services/payment_intents_service.py; backend/app/services/shop_service.py; backend/app/services/wallets_service.py` | `user` |
| 67 | GET | `/shop/orders` | `backend/app/routes/shop_routes.py` | `shop` | `backend/app/services/shop_service.py` | `user` |
| 68 | POST | `/shop/purchase-efhc` | `backend/app/routes/shop_routes.py` | `shop` | `backend/app/services/shop_service.py; backend/app/services/transactions_service.py` | `user` |
| 69 | POST | `/skins/activate/{skin_id}` | `backend/app/routes/skins_routes.py` | `skins` | `backend/app/services/skins_service.py` | `user` |
| 70 | POST | `/skins/buy/{skin_id}` | `backend/app/routes/skins_routes.py` | `skins` | `backend/app/services/skins_service.py; backend/app/services/transactions_service.py` | `user` |
| 71 | GET | `/skins/catalog` | `backend/app/routes/skins_routes.py` | `skins` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 72 | GET | `/skins/my` | `backend/app/routes/skins_routes.py` | `skins` | `backend/app/services/skins_service.py` | `user` |
| 73 | POST | `/sync/user/{tg_id}` | `backend/app/routes/sync_routes.py` | `sync` | `backend/app/services/energy_service.py; backend/app/services/exchange_service.py; backend/app/services/panels_service.py` | `user` |
| 74 | GET | `/tasks/catalog` | `backend/app/routes/tasks_routes.py` | `tasks` | `backend/app/services/tasks_service.py` | `user` |
| 75 | POST | `/tasks/claim/{tg_id}` | `backend/app/routes/tasks_routes.py` | `tasks` | `backend/app/services/tasks_service.py; backend/app/services/transactions_service.py` | `user` |
| 76 | GET | `/tasks/my/{tg_id}` | `backend/app/routes/tasks_routes.py` | `tasks` | `backend/app/services/tasks_service.py` | `user` |
| 77 | POST | `/tg/webhook` | `backend/app/routes/system_routes.py` | `system` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 78 | GET | `/user/me` | `backend/app/routes/user_routes.py` | `user` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 79 | GET | `/user/{tg_id}/exchange/preview` | `backend/app/routes/user_routes.py` | `user` | `backend/app/services/exchange_service.py` | `user` |
| 80 | GET | `/user/{tg_id}/me` | `backend/app/routes/user_routes.py` | `user` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 81 | GET | `/user/{tg_id}/panels-summary` | `backend/app/routes/user_routes.py` | `user` | `backend/app/services/panels_service.py` | `user` |
| 82 | POST | `/wallets/connect` | `backend/app/routes/wallets_routes.py` | `wallets` | `backend/app/services/wallets_service.py` | `user` |
| 83 | GET | `/wallets/me` | `backend/app/routes/wallets_routes.py` | `wallets` | `backend/app/services/wallets_service.py` | `user` |
| 84 | DELETE | `/wallets/{wallet_id}` | `backend/app/routes/wallets_routes.py` | `wallets` | `backend/app/services/wallets_service.py` | `user` |
| 85 | POST | `/wallets/{wallet_id}/make-primary` | `backend/app/routes/wallets_routes.py` | `wallets` | `backend/app/services/wallets_service.py` | `user` |
| 86 | GET | `/withdraw/list` | `backend/app/routes/withdraw_routes.py` | `withdraw` | `backend/app/services/withdraw_service.py` | `user` |
| 87 | POST | `/withdraw/request` | `backend/app/routes/withdraw_routes.py` | `withdraw` | `backend/app/services/withdraw_service.py` | `user` |
| 88 | GET | `/withdraw/{request_id}` | `backend/app/routes/withdraw_routes.py` | `withdraw` | `ROUTE_ONLY_OR_INLINE` | `user` |
| 89 | POST | `/withdraw/{request_id}/cancel` | `backend/app/routes/withdraw_routes.py` | `withdraw` | `backend/app/services/withdraw_service.py` | `user` |
