# RESIDUAL SHOP READ/REPORTING AUDIT — 2026-04-07

## Живые legacy assumptions
- `shop_service.admin_list_orders` ранее читал `shop_orders.item_id`, `shop_items.code`, `shop_items.title`, `shop_items.item_type`, `shop_orders.payment_method`.
- Каноничная схема заказа уже живёт через `shop_orders.type`, `quantity_efhc`, `expected_amount`, `extra`, `idempotency_key`.

## Что вылечено
- admin/reporting order reader переведён на `shop_orders` как основной источник истины; `extra` используется для `sku` и `payment_method`, а не прямой legacy join по `item_id`.

## Что ещё живо
- другие legacy read/reporting paths ещё требуют отдельной ревизии в следующих циклах.
