# ADMIN SHOP STATUS / INVENTORY WAVE 696-700 (2026-04-09)

## Goal
Close the next admin shop operator tail after wave 28 without pretending that full CRUD is finished.

## Delivered in this wave
- dedicated `/admin/shop/items/status` route for точечное переключение `live/hidden/draft`;
- backend archive semantics mapped to `draft` status instead of fake deletion;
- admin shop dashboard now shows status inventory (`live/hidden/draft`);
- admin shop catalog now supports status filter and sort modes (`updated/newest/oldest/title`);
- selected product card got quick actions for `live`, `hidden` and archive-to-`draft`.

## Not claimed yet
- file/image upload persistence;
- hard delete flow;
- bulk actions;
- separate mobile/desktop preview split;
- VIP NFT dedicated section inside admin shop.
