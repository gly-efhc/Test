# Очистка активных хвостов v172.46

Удалённая цепочка migrations `0002–0013` больше не определяет runtime.
В `v172.46`:

- active SSOT/JSON/CSV переведены на `0001_initial_release_schema.py`;
- audit-скрипты больше не открывают удалённые migration files;
- `app.identity` не экспортирует pre-release backfill/expand harnesses;
- release archive не включает `legacy_user_id.py`,
  `user_id_backfill.py` и `user_id_expand.py`;
- исторические документы сохранены как история и не меняют current
  schema;
- временные ORM synonyms остаются только для rollback/reconciliation
  совместимости и не являются owner API.
