# I18N reaudit low-signal repair audit — v169.83

Date: 2026-06-03.
Cycle: 1401.
Mode: audit-driven repair.
Base archive: `EFHC_Bot_v169_82_cycle_1400_range_closure_ci_ruff_repair.zip`.
Input audit: `docs/audits/I18N_REAUDIT_REPORT_V169_82_2026_06_03.md`.

## Verdict

The three LOW signals from the repeat i18n audit were repaired as false-positive
control defects. No runtime economics, translations, Telegram shell, wallet
logic, admin/public boundary or CI workflow was changed.

## Findings repaired

| Finding | Root cause | Repair | Status |
|---|---|---|---|
| O1: `FAQ` not allowlisted | International acronym not recorded in exact-value allowlist | Added `FAQ` to `identical_to_english_allowlist.json` | DONE |
| O2: panels-service comment hit | Guard pattern matched canonical comment `Цена панели фиксирована` | Added exact false-positive phrase to `FALSE_POSITIVE_RE` | DONE |
| O3: quality scripts ignore allowlist | Wave-3 quality scripts only used local key allowlists | Added shared helper and wired 10 scripts to exact-value/key-prefix allowlist | DONE |

## Test-control statement

Tests were not deleted, archived, skipped, xfailed or hidden. A new active
architecture guard was added to lock the low-signal repair.

## Non-claims

This audit does not claim GitHub CI green, full local pytest green, frontend
build green, screenshot evidence, live Telegram proof, real wallet proof or
release readiness.
