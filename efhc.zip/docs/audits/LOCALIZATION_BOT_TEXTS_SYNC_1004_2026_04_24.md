# Localization bot texts sync — cycle 1004

Date: 2026-04-24
Archive iteration: v167_73
Cycle: 1004

## Scope

Cycle 1004 closes the backend Telegram bot text-source readiness
layer.

The cycle is based on the imported localization audit and on the
active manual localization range `983-1022+`.

## What was changed

- `backend/app/bot/texts.py` was converted from a two-language text
  dictionary into an explicit 13-language bot text source.
- The supported language list now matches the active frontend locale
  set:
  `en`, `ru`, `uk`, `de`, `fr`, `es`, `it`, `pl`, `tr`, `da`,
  `hi`, `id`, `sw`.
- Every bot language has the same text keys.
- Placeholders are kept stable across languages.
- `t()` keeps backward-compatible default Russian behavior for the
  existing Telegram bot runtime calls.
- English remains available through `t("en", key, ...)`.

## Guard added

Added:

- `ops/i18n/audit_bot_texts_parity.py`

The guard checks:

- supported language coverage;
- key parity;
- placeholder parity;
- empty values.

## Runtime boundary

This cycle closes text-source readiness. It does not claim that the
Telegram bot already selects every user language automatically at
runtime. Runtime language selection remains a later path if required by
product flow.

## Verification

Executed locally:

```text
python3 -S -m py_compile backend/app/bot/texts.py
python3 -S -m py_compile ops/i18n/audit_bot_texts_parity.py
python3 -S ops/i18n/audit_bot_texts_parity.py
```

Result:

```text
OK: checked backend bot text parity.
Languages: 13
Keys: 19
```

## Verdict

Cycle 1004 is closed.

The backend/bot text source is now structurally aligned with the active
manual localization contour. Full multilingual release readiness is not
claimed because FAQ, notifications/templates, hardcoded strings and
final proof layers remain open.
