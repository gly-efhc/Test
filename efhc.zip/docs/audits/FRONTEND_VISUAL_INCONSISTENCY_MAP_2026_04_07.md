# FRONTEND VISUAL INCONSISTENCY MAP — 2026-04-07

## Источник визуальных элементов
- пользовательская песочница `Песочница.zip`
- активные Telegram-like UI primitives проекта

## Карта несоответствий
1. Сырые/англоязычные состояния в BrowserShopPage
2. Разный тон informational blocks и empty states
3. Остаточный wording drift между storefront и bot-layer

## Приоритет
- first: BrowserShopPage
- second: residual i18n cleanup
- third: proof via TypeScript/build cycle 446/451
