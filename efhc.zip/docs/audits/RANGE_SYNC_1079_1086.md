# RANGE SYNC 1079-1086

- Закрыт пакет канонизации `reward -> bonus/accrual` в active FAQ и locale bundles.
- Исторические документы и Healer не переписывались.
