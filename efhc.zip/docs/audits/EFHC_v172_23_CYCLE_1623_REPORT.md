# EFHC v172.23 — отчёт цикла 1623

## Статус

Цикл `1623` реализован как пакет historical backfill, orphan/conflict
closure, sequence reconciliation и full reconciliation.

Статус пакета:

`CYCLE_1623_HISTORICAL_BACKFILL_RECONCILIATION_PACKAGE_READY`

Это не означает `CYCLE_1623_PASS`: реальный PostgreSQL для `0008`
обязан пройти exact-HEAD GitHub CI.

Цикл `1624` не начат.

## Fresh CI исходного HEAD

Fresh run `83038159093` относится к `EFHC_Bot_v172_22.zip` размером
`12022644` байт. Реальный PostgreSQL успешно применил миграции через
`0007`; Ruff, Mypy, Bandit и frontend production build прошли.

Остались шесть pytest findings, все классифицированы как
`SIMPLE_CORRECTIVE_SCOPE`. Они исправлены точечно; причинный набор
прошёл `6/6`.

## Migration 0008

Новая migration `0008_historical_global_id_backfill.py` имеет parent
`0007` и выполняет только фазу `BACKFILL`.

Основные правила:

- `users.user_id` заполняется из `users.id` только после range,
  duplicate и deterministic-collision guards;
- 27 legacy mappings переводятся только через доказанные источники;
- orphan и conflict завершают migration fail closed;
- owner не выводится из memo, address, email или иных догадок;
- `unmatched_incoming.resolved_global_id` и generic
  `processed_external_events.resolved_global_id` не заполняются без
  доказанного owner-source;
- sequence `users_user_id_seq` синхронизируется после backfill;
- backfill проходит под блокировками, исключающими concurrent write;
- monetary и количественные снимки сравниваются до/после без
  округления;
- финансовые значения, precision и idempotency semantics не меняются;
- legacy ownership остаётся authoritative;
- dual-write, shadow-read и read switch отсутствуют.

## Exit gate

Real PostgreSQL gate для exact `v172.23` обязан доказать одновременно:

- unresolved proven mappings = `0`;
- sequence находится выше максимального существующего owner id;
- orphan/conflict = `0` после успешной migration;
- monetary ownership discrepancy = `0.00000000` точно, без округления;
- monetary snapshot до/после migration неизменен.

До получения этого evidence `CYCLE_1623_PASS` запрещён.

## Локальные проверки

Выполнены только причинные проверки изменённого scope:

- `py_compile` новой migration, gate и tests — PASS;
- static backfill/reconciliation guard — PASS;
- PostgreSQL offline Alembic render через `0008` — PASS;
- fresh-CI corrective tests — `6/6 PASS`;
- прямые current-head architecture/release dependencies — PASS;
- 72-column policy — PASS;
- русскоязычная engineering policy — PASS.

Реальный PostgreSQL, полный regression, Docker, frontend production
build и Chromium локально не запускались.

## Запрет следующего цикла

Цикл `1624` — dual-write, shadow-read telemetry, idempotency и rollback
guards — не начат и не должен начинаться до exact-HEAD qualification
`v172.23`.
