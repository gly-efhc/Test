# Frontend visual white spots audit — 2026-04-04

> Status note: this white-spots audit is historical baseline for `v164_25`; visual closure and premium Telegram waves are tracked in later audits.


## Scope
Audit of visible frontend gaps in the current `v164_25` archive.
Focus: pages and components that are visually unfinished, disabled,
placeholder-driven, or missing branded empty/loading/error states.

## Critical white spots

### 1) Browser storefront is still a technical MVP shell
Files:
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`

Observed:
- raw titles: `EFHC Storefront MVP`, `Custom EFHC top-up (TON only)`
- raw loading/error renderers
- raw payment instructions block
- raw status block
- no branded cards for success / pending / fail / expired
- no visual empty state if catalog is empty

Impact:
- storefront works as a technical contour, but visually looks unfinished
- user sees an engineering page, not a release storefront

### 2) Hub EFHC path still exposes a fallback/incomplete state
Files:
- `frontend/src/features/hub/HubPage.tsx`
- `frontend/public/locale/*.json`

Observed:
- EFHC card opens modal fallback on handoff failure
- locale key `hub.efhc_modal_body` says external page is not connected yet

Impact:
- Hub visually still contains an explicit incompleteness marker
- this is a direct visible white spot in the main handoff contour

## High priority white spots

### 3) Admin Tasks page is a direct disabled placeholder
Files:
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/public/locale/*.json`

Observed:
- page body only says admin page is temporarily disabled
- locale layer contains `admin.temporarily_disabled`

Impact:
- visible dead-end in admin contour

### 4) Admin locale layer still contains many placeholder texts
Files:
- `frontend/public/locale/*.json`

Observed keys:
- `admin.placeholder_ads`
- `admin.placeholder_panels`
- `admin.placeholder_referrals`
- `admin.placeholder_reports`
- `admin.placeholder_tasks`
- `admin.placeholder_users`
- `admin.placeholder_withdrawals`
- `admin.placeholder_detail_note`

Impact:
- even where pages exist, translation/catalog still exposes unfinished
  semantics and placeholder naming

### 5) Several admin pages are technically functional but visually raw
Files:
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/bank.tsx`

Observed:
- raw tables without branded empty states
- raw text loading blocks
- raw error blocks
- raw JSON `<pre>` dumps shown directly to the user
- action copy partially technical (`Toggle`, raw IDs, raw JSON)

Impact:
- admin contour is present, but visual finish is incomplete

## Medium priority white spots

### 6) FAQ still has explicit “next cycle” wording in locale layer
Files:
- `frontend/public/locale/*.json`

Observed key:
- `desc.faq.soon`

Impact:
- visible unfinished promise marker in content layer

### 7) Skin preview fallback remains visible
Files:
- `frontend/public/locale/*.json`

Observed keys:
- `shop_ui.preview_unavailable`
- `shop_ui.preview_unavailable_hint`

Impact:
- stable layout exists, but preview experience is still visibly partial

### 8) Mixed-language visual copy remains in non-RU locales
Files:
- `frontend/public/locale/*.json`

Observed:
- many non-RU locale values still contain English fallback copy such as:
  `This admin module is present but not fully enabled in this build.`
  and `Admin page is temporarily disabled in this build.`

Impact:
- UI looks inconsistent and unfinished in multilingual mode

## Structural visual gaps

### 9) Loading / error / empty states are not unified
Files:
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
- multiple admin pages

Observed:
- loading shown as plain text
- errors shown as plain red text blocks
- missing shared release-grade empty-state pattern

Impact:
- fragmented visual language across the app

### 10) Release copy still exposes implementation language
Files:
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
- `frontend/src/features/admin/AdminSalePackagesPage.tsx`

Observed:
- visible `MVP` wording in page titles/subtitles
- visible implementation framing instead of product framing

Impact:
- release UX still leaks internal project state

## Practical conclusion
The main visible white spots are concentrated in three contours:
1. `browser-shop` storefront
2. `hub` EFHC fallback state
3. admin pages and locale placeholder layer

## Fastest closure order
1. Remove visible fallback/incomplete wording from Hub EFHC flow.
2. Turn browser-shop from technical MVP page into branded release storefront.
3. Replace admin placeholder copy and disabled pages with neutral release text
   or hide them from navigation.
4. Replace raw loading/error/JSON states with unified visual components.
5. Clean mixed-language locale leftovers.
