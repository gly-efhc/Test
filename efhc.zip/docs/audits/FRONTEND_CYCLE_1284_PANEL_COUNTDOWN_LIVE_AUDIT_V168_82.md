# FRONTEND CYCLE 1284 PANEL COUNTDOWN LIVE AUDIT

Date: 2026-05-21
Version: v168_82
Cycle: 1284
Scope: Panels countdown live display proof

## Purpose

Cycle 1284 protects the recovered panel countdown as a live user
function.  The panel card must not regress to a static date field or
a vague age label.

## Canon

A panel card must show:

- panel ID;
- activation date;
- deactivation date;
- generated kWh;
- live countdown to deactivation.

The countdown is based on backend `server_now_utc` and panel
`expires_at`.  Local client time is allowed only as a display stopwatch
after the backend anchor has been received.

## Changes

Frontend `panels.tsx` now marks the countdown field with:

- `data-panel-countdown-live="client-stopwatch"`;
- `data-panel-countdown-tick={tick}`;
- `aria-live="polite"`.

CSS adds a small live indicator for the countdown value.

## Non-goals

The cycle did not change:

- backend economy;
- database schema;
- migrations;
- payment logic;
- activation price;
- debit order;
- admin routes.

## Result

The frontend now has a static guard against losing the live countdown
contract again.
