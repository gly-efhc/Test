# ADMIN SHOP EDITOR RE-AUDIT SLICE 661-670 — 2026-04-08

## What improved
- Shop card management now exists as a real admin surface, not just as order reading.
- External shop cards are easier to compare thanks to search, category/package filters and dual-price display.
- Preview discipline is in place before full image/content persistence is added.

## What remains next
- persist title / description / image via backend route(s);
- add dedicated image upload flow if needed;
- richer product management table/editor workflows;
- shop card state model finalized (live/hidden or live/hidden/draft).
