# P0 HEAL-0040 / HEAL-0044 payment schema repair audit — v169.88 / cycles 1406–1407

Status: DONE.  
Date: 2026-06-04.  
Base HEAD: `EFHC_Bot_v169_87_cycle_1405_heal0045_tg_id_identity_repair.zip`.  
Output HEAD: `EFHC_Bot_v169_88_cycles_1406_1407_heal0040_payment_contract_heal0044_schema_proof.zip`.

## Scope

Cycles 1406–1407 repair two confirmed P0 backend/schema issues:

- `HEAL-0040`: `payment_intents.package_id` contract drift between ORM and custom/package-less SQL insert paths.
- `HEAL-0044`: existing DB proof for `efhc_transfers_log.direction` width after the model already used `String(24)`.

## User decisions applied

The user confirmed in cycle 1404 that `payment_intents.package_id` may be `NULL` for custom/package-less intents. Package-based intents keep their explicit package contract.

## HEAL-0040 root cause

`backend/app/models/payment_intents_models.py` required:

```text
package_id nullable=False
```

but `backend/app/services/payment_intents_service.py::create_intent_deposit_custom()` inserted `NULL` for `package_id`. That made the service SQL path incompatible with the ORM/schema contract.

A second package-less path, `create_intent_shop_external()`, used fake package sentinel `0`. That was also a contract smell after the user-approved nullable package-less model.

## HEAL-0040 repair

- `PaymentIntent.package_id` changed to `Mapped[int | None]` with `nullable=True`.
- `create_intent_deposit_by_package()` still inserts `:pid` and therefore preserves the package-based contract.
- `create_intent_deposit_custom()` inserts `NULL` by contract.
- `create_intent_shop_external()` now also inserts `NULL` instead of fake `0` because it is package-less.
- `backend/migrations/versions/0001_initial_release_schema.py` now repairs existing DBs by dropping `NOT NULL` from `efhc_core.payment_intents.package_id` before sanity checks.

## HEAL-0044 root cause

The model already had `EfhcTransferLog.direction = String(24)`, but an existing DB created before the repair could still have `varchar(8)`. `Base.metadata.create_all(checkfirst=True)` does not alter old columns, so a migration/schema proof was required.

## HEAL-0044 repair

`backend/migrations/versions/0001_initial_release_schema.py` now checks existing `efhc_core.efhc_transfers_log.direction`. If the live column width is below 24, it applies:

```sql
ALTER TABLE efhc_core.efhc_transfers_log
ALTER COLUMN direction TYPE varchar(24)
```

Sanity checks now fail if:

- `payment_intents.package_id` is still not nullable;
- `efhc_transfers_log.direction` is missing or shorter than `varchar(24)`.

## New active guard

`tests/architecture/test_heal0040_0044_payment_schema_contract.py`

The guard verifies:

- ORM nullable package_id contract;
- package-based SQL still uses `:pid`;
- package-less SQL uses `NULL` and no longer uses sentinel `0`;
- migration drops `NOT NULL` for existing DBs;
- model and migration lock `direction varchar(24)`.

## Sandbox use

Песочница использована только как reference/navigation layer through `map_element.md`. Runtime-код, donor wallet/payment logic, CI files, lock files and translations were not imported.

## Checks performed

- ZIP integrity before work: base archive readable and `testzip=None`.
- Sandbox archives checked: five template ZIPs `testzip=None`; `Песочница(1).xz` passed `xz -t`.
- `py_compile` for modified backend files and new guard: passed.
- Targeted pytest for the new guard and recent P0 guards: passed locally.
- Static grep: no `vals.tg, vals.purpose, 0, :asset` remains in `payment_intents_service.py`.

## Non-claims

This audit does not claim GitHub CI green, full local pytest green, frontend build green, browser screenshots, live Telegram proof, real TonConnect/wallet proof or release readiness.

## Remaining P0 line

Next planned cycle: `1408 — HEAL-0023 idempotency read-through conflict hardening`.
