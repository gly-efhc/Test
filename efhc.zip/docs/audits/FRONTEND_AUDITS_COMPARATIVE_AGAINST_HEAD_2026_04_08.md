# Frontend audits comparative against current HEAD (2026-04-08)

## Источники
- EFHC frontend main audit PDF
- EFHC chat archive full audit PDF
- current HEAD after web portal / profile / visual waves

## Что из новых аудитов уже частично снято текущим HEAD

1. **Скрытый web-profile route**
   Раньше `WebProfilePage` был почти скрытым маршрутом. В текущем HEAD он уже
   выведен в отдельную страницу `/web-profile` и связан с portal через кнопку
   открытия профиля.

2. **Portal зависел от Telegram handoff, но почти не показывал account context**
   В текущем HEAD это смягчено: bootstrap уже несёт wallet preload, а portal
   показывает связанные кошельки и отдельный web profile.

3. **Внешний portal выглядел как thin MVP-storefront**
   Это всё ещё частично верно, но текущий HEAD уже перевёл framing в `EFHC Web
   Portal`, добавил module summary, visual hero blocks и access model.

## Что по новым аудитам остаётся живым

1. **Расщеплённость user-flow**
   Профиль, wallet, shop, browser portal и withdraw всё ещё живут в нескольких
   контекстах.

2. **Admin auth/localStorage token model**
   Это подтверждённый живой residual. Текущими web-portal wave он не лечился.

3. **Systemic localization drift**
   Mix hardcoded strings и неравномерный i18n всё ещё остаются проблемой.

4. **Тонкие/ложно-готовые модули**
   Ads, Admin Tasks, Admin Sale Packages и часть browser-shop semantics всё ещё
   требуют либо честного маркирования, либо дальнейшей доводки.

5. **Несшитая навигация между внешними surfaces**
   Стало лучше, но user-flow всё ещё не выглядит как одна непрерывная цепочка.

## Что нельзя переоценивать

Новые PDF-аудиты частично описывают HEAD до последних web/profile/visual wave.
Поэтому их нужно читать не буквально как frozen truth, а как базовый список
blockers/residuals, часть которых уже ослаблена последними циклами.

## Практический вывод

Следующий блок 581-610 должен идти не по broad refactor, а по трём фронтам:
1. user-flow stitching / discoverability / route clarity;
2. localization discipline and direct-string cleanup;
3. admin operator UX / auth hardening plan.
