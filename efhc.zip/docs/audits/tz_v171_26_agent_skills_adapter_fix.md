# ТЗ v171_26 — Agent Skills Adapter Fix

## Назначение

Исправить foundation-внедрение Agent Skills Adapter в
`EFHC_Bot_v171_25_cycle_1550_agent_skills_adapter_foundation.zip` без
расширения runtime-функциональности и без изменения бизнес-логики EFHC.

Цель цикла: довести Adapter foundation до валидного, проверяемого и
подчинённого EFHC Kernel / SSOT / NORM / Gate-правилам состояния.

## Обязательные исправления

- Сделать валидными `commands/ship.toml` и `.gemini/commands/ship.toml`:
  строки `Never claim release-ready...` и `Never claim production-ready...`
  должны находиться внутри `prompt = """..."""`.
- Исправить `hooks/session-start-test.sh` под EFHC-заголовок
  `# Using EFHC Agent Skills` или EFHC threshold model.
- Заменить битые ссылки `../docs/agents.md` в agent-personas на
  `../docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md`.
- Усилить `ops/ci_checks/check_agent_skills_adapter.py`:
  TOML validation через `tomllib`, проверка битой ссылки agent-personas,
  проверка наличия EFHC adapter reference.
- Расширить `ops/ci_checks/check_no_direct_api_in_public_ui.py` на запрет
  `EventSource(` и `WebSocket(` в public UI zones.
- Исправить fallback path в `hooks/hooks.json`, чтобы hook работал как
  plugin hook и как project-local hook.
- Адаптировать `plugin.json` под EFHC:
  `efhc-agent-skills-adapter`, `171.26.0`, subordinate to AI Archive Laws,
  SSOT and NORM.

## Запреты

В цикле запрещено менять money logic, TON logic, withdraw logic, auth logic,
database migrations, runtime behavior, production configuration, финансовые
формулы EFHC, staking logic, NFT logic и React business components без
необходимости.

## Обязательные проверки

- `python ops/ci_checks/check_agent_skills_adapter.py`
- `python ops/ci_checks/check_no_direct_api_in_public_ui.py`
- `bash hooks/session-start-test.sh`
- `make agent-skills-gate`
- `make public-api-gate`
- `make frontend-architecture`
- `pytest tests/architecture/test_agent_skills_adapter_contract.py -q`
- `pytest tests/architecture/frontend/case_no_direct_api_in_public_ui.py -q`
- `npm run typecheck` from `frontend/`

## Критерии приёмки

- `commands/ship.toml` валиден как TOML.
- `.gemini/commands/ship.toml` валиден как TOML.
- `hooks/session-start-test.sh` проходит.
- В `agents/*.md` нет ссылки `../docs/agents.md`.
- Adapter guard проверяет TOML-файлы и битые persona links.
- Public API gate остаётся зелёным.
- Frontend architecture gate остаётся зелёным.
- Typecheck проходит.
- Бизнес-логика EFHC не изменена.
