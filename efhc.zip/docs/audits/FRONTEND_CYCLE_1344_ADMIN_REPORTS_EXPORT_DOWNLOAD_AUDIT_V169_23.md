# Frontend audit — cycle 1344 Admin Reports export/download

## Verdict

PASS for the intended cycle scope.

## Scope

Cycle 1344 adds a read-only export/download boundary to `/admin/reports`.
It builds on the visual dashboard introduced in cycle 1343.

## Confirmed implementation

- `AdminReportsExportDownloadPanel` exists.
- `/admin/reports` renders the export panel below the visual dashboard.
- Export formats are JSON, CSV and TXT.
- Export scope is sanitized to meta, counters, facts and optional notes.
- Download is client-side through browser Blob.
- No backend route was added.
- No new dependency was added.
- `ci.yml` was not changed.

## Sandbox use

The uploaded `Песочница.xz` archive was opened. The cycle adapted export
patterns from Refine `useExport`, Refine `ExportButton`, TMA download
references and previous data-table/list-detail dashboard patterns.

## Boundaries

The implementation does not expose raw SQL, raw cursor payload, raw
internal diagnostics, ledger mutation, withdrawal mutation, task reward
mutation or workflow modification.

## Risks

Browser download behaviour can vary inside mobile Telegram WebView. The
current implementation uses a standard anchor download fallback and does
not rely on Telegram-specific APIs.

## Local auxiliary checks

- frontend typecheck;
- frontend lint;
- targeted architecture guard;
- backend and Operator Kernel compileall;
- canon guard;
- ZIP integrity.

Full GitHub CI remains a user-run gate.
