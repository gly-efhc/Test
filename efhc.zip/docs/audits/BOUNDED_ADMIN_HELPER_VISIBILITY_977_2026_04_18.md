# Cycle 977 — bounded admin helper visibility pass

## Goal
Keep helper/internal/deferred surfaces visible enough for operators without letting them impersonate release-core maturity.

## Treatment
- Diagnostics stays helper/non-core and is now also explicitly marked as beta.
- Ads helper wording was kept bounded.
- Sale packages stays deferred/read-only and is now also explicitly marked as beta.

## Verdict
Helper and deferred surfaces remain visible but harder to misread as release-core evidence.
