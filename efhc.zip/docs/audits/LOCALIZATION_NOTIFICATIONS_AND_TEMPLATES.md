# Localization notifications and templates inventory — current work pass

Status: AUDIT SCAFFOLD / runnable precondition restored.
Date: 2026-06-03
Scope: cycle 1376 i18n reaudit intake.

This document exists so `ops/i18n/audit_notifications_templates_inventory.py`
can run without failing on a missing work pass inventory report. It is an
inventory scaffold, not a final linguistic certification.

## Required inventory paths

- `backend/app/services/admin/admin_notifications.py`
- `backend/app/services/shop_order_notifications_service.py`
- `backend/app/models/system_templates_models.py`
- `backend/app/routes/admin_templates_routes.py`
- `backend/app/services/admin/admin_templates_service.py`
- `backend/app/services/outcome_service.py`
- `backend/app/services/tasks_service.py`
- `frontend/src/pages/admin/templates.tsx`

## Notes

Notification, bot and template localization must keep admin/operator and player-facing surfaces separated. Future text changes remain manual and source from verified Russian meaning, not from sandbox English labels.
