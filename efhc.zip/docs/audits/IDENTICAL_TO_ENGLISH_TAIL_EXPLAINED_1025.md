# Cycle 1025 — identical-to-English tail explained

## User-facing explanation

`identical-to-English tail` means the measured remainder of non-English
locale values that are still exactly the same as the English baseline.

Example:

- English key: `withdraw.title = "Withdraw"`
- Danish key: `withdraw.title = "Withdraw"`

The key exists in the Danish file, so this is not a missing key. But the
value is still English. That is why it is a tail, not a simple absence.

## Why this matters

The risk is hidden fallback. A screen can look structurally localized
because every key exists, but the player or operator still sees English
phrases inside a non-English locale.

This is dangerous for:

- money-path screens;
- withdraw statuses and next steps;
- admin/operator actions;
- trust-sensitive outcomes;
- long help and FAQ text.

## What is not automatically a problem

Some identical values are allowed because they are technical or
canonical:

- `EFHC`, `TON`, `USDT`, `NFT`;
- `global_id`;
- `kWh/s`;
- protocol or brand names such as `Telegram` or `TonConnect`.

These values must be explicitly approved. They must not be used as a
blanket excuse to keep normal English sentences inside other locales.

## Current measured state

The current guard reports `1243` findings after approved technical
tokens are ignored.

Top prefixes:

- `withdraw`: 826;
- `admin`: 106;
- `panels`: 58;
- `portal`: 57;
- `exchange`: 56.

Top languages:

- `hi`: 177;
- `fr`: 125;
- `id`: 120;
- `de`: 119;
- `it`: 112.

## Decision

The tail is real and must stay visible. It is routed into cycles
`1025-1040`, not hidden under a release-ready claim.
