# Cycle 1046 — active forbidden contour inventory

Status: done.

## Purpose

Провести активную инвентаризацию старого игрового / лотерейного /
турнирного хвоста без переписывания истории и без физического удаления
до утверждения пользователя.

## Active scope checked

Проверялся активный release-контур:

- `frontend/src/`
- `frontend/public/locale/`
- `backend/app/`
- `tests/`
- `docs/SSOT/faq_ssot/`
- `frontend/src/data/faq/`
- `ops/i18n/`

Исторические слои `reports/`, `docs/audits/`, `docs/healer/`, логи и
архивные корзины не чистятся и не считаются blocker только из-за
исторического упоминания старой ошибки.

## Confirmed active candidate requiring user approval

### `backend/app/core/errors_core.py`

Found object:

- class: `ParticipationClosedError`
- current Russian docstring: `Попытка выполнить действие в закрытом раунде участия.`
- current default message: `Round is closed.`
- current code: `participation_closed`

## What it does

Это доменное исключение backend. Оно возвращает ошибку, когда пользователь
пытается выполнить действие участия после закрытия соответствующего
состояния участия.

## Why it should be changed

Слова `round` / `раунд` теперь находятся под строгим запретом в активном
release-контуре EFHC Bot, потому что они связаны со старым игровым /
лотерейным / турнирным шлейфом. Даже если конкретный класс сейчас не
является лотереей, формулировка может вернуть запрещённый смысл в UI,
backend-сообщения или будущие тесты.

## Proposed point replacement, not applied yet

Не применено без утверждения пользователя.

Recommended neutral wording:

- docstring: `Попытка выполнить действие после закрытия участия.`
- default message: `Participation is closed.`
- code: keep `participation_closed` to avoid API breakage.

## Risk map

- Risk of changing message: low.
- Risk of changing docstring: low.
- Risk of changing error code: medium/high, because clients/tests may depend
  on `participation_closed`.
- Recommended treatment: change message and docstring only; keep code.

## User approval needed

Before applying the replacement, ask the user in Russian:

Разрешаете заменить `Round is closed.` на `Participation is closed.` и
русское описание про `раунд участия` на нейтральное описание без слова
`раунд`, сохранив код ошибки `participation_closed`?

## Additional active technical comments found by smart guard

The guard also found `раунд` in `backend/app/services/energy_service.py`
comments/docstring around the energy catch-up loop:

- `предел раундов`
- `Каждый раунд идемпотентен`
- `в этом раунде`
- `между раундами`

Meaning:

These are technical loop comments, not loto/tournament UI. However the word
`раунд` is forbidden in active release contour by the new language canon.

Proposed safe replacement, not applied yet:

- `раунд` -> `проход`
- `предел раундов` -> `предел проходов`
- `между раундами` -> `между проходами`

Risk: low for comments/docstring only. Runtime variable names like `rounds`
would require separate approval if changed because they may be returned in
service dictionaries.

## Suspicious contextual words found

The guard found many suspicious contexts for `reward / награда / ставка`.
These are not automatic blockers. They require Russian iteration because:

- `Tasks / Задания` are allowed as work;
- reward for work can be acceptable;
- generation rate wording like `ставка генерации` is not a bet;
- financial/game wording must still be cleaned if it creates loto-like
  meaning.

Next recommended cycle:

- create a suspicious reward/rate review map before changing user-facing FAQ or
  locale wording.
