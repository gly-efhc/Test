# Cycle 964 — White spots registry normalization

## Purpose
Normalize white spots from the imported external audit, existing audit layer,
and the current HEAD.

## Release-core white spots
- TonConnect timeout/cancel user feedback.
- Deposit waiting/progress feedback in Browser-Shop.
- Return-path clarity between Telegram, Hub, Browser-Shop, and Web-Profile.
- Latest transaction visibility in Web-Profile/ProfileModal.

## Helper / deferred white spots
- ADS route truth and alias clarity.
- NFT surface truth and release-core separation.
- Sale-packages and diagnostics remain outside release-core evidence.

## Polish-only white spots
- Additional FAQ/help discoverability.
- More explicit progress language around long-running payment verification.

## Verdict
This registry becomes the bounded white-spots source for cycles 965-974.
