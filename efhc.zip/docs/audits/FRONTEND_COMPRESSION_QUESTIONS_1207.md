# Frontend compression questions — cycle 1207

## 5 questions for topic 2.5

1. Which three first-screen actions must remain visible everywhere:
   Energy, HUB, Profile or another set?
2. Should Panels, Exchange, Tasks, Referrals and Ranks stay in bottom
   navigation, or move into one expandable Game/Progress surface later?
3. Should financial actions be grouped under one Wallet/Profile surface,
   while the game screen shows only energy progress and active panels?
4. Should admin/debug links disappear completely from all non-admin
   first-level surfaces, even for admin users, unless the admin panel is
   opened deliberately?
5. Should every long page be compressed into cards that expand on tap,
   with only one primary action visible per card?

## 10 questions for topic 2.7

1. What is the first screen in EFHC after launch: Energy dashboard or
   Dragon-style game home?
2. What are the maximum first-level buttons on that screen: three, four
   or five?
3. Should the main first-level actions be Play/Energy, Wallet, HUB and
   Profile?
4. Should Exchange be hidden inside Wallet after the compression wave?
5. Should Panels be hidden inside Energy/Power after the compression
   wave?
6. Should Tasks and Referrals become expandable earning modules instead
   of permanent bottom-level pages?
7. Should Ranks become a progress popup/card instead of a permanent
   bottom-level page?
8. Should Browser-Shop remain fully separate, opening from HUB only?
9. Should desktop browser mode use the same compact home, but centered
   in a PC-width game frame?
10. Should every secondary action open a drawer/modal rather than a new
    full page, where safe and technically possible?

## Working interpretation before answers

Until the user answers, the safe default is conservative compression:
keep current routes and functions, but progressively hide secondary
controls behind expandable cards, dropdowns and drawers.  Do not remove
features.  Do not break the existing bottom navigation until a separate
navigation migration is approved.
