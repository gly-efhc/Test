# GITHUB CI LOGS HEALER TRANSFER — 2026-04-07

## Переносимые хронические ошибки из старых log-audits
- drift между active migration canon и старой log-memory о `0002`
- повторяющиеся `ruff I001`
- stale frontend typing/build drifts
- old CI log docs как ложный active surface вместо Healer

## Источники
- `LOG_AUDIT_62449907231.md`
- `LOG_AUDIT_62451337893.md`
