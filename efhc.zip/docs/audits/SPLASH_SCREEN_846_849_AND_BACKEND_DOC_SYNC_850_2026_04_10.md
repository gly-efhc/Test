# Splash Screen 846-849 + backend/doc-sync 850

Date: 2026-04-10
Status: partial execution report

## 846-849
- Added canonical full-screen Splash Screen over the whole app.
- Background is deep black for max contrast with the EFHC yellow coin.
- Embedded canonical EFHC SVG without changing viewBox.
- Added breathe animation via CSS keyframes.
- Bound splash visibility to app initialization lifecycle.
- Fade-out is handled by opacity transition before unmount.

## 850
Confirmed and fixed in this pass:
- migration/NORM docs counts updated to current SSOT values:
  - tables: 36
  - routes: 95
  - paths: 90
  - schema split: 31 core / 5 admin
- watcher compatibility layer restored for payload parsing and mixed
  confirm-result shapes
- `shop_models.py` imports `Text`
- `ShopItem` metadata made tolerant to duplicate import shape through
  `extend_existing=True`

Still requires fresh GitHub CI confirmation after this archive.
