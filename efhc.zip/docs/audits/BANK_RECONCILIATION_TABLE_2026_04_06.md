# BANK RECONCILIATION TABLE 2026-04-06

Статус: working audit table for cycle 424/429.

## Назначение

Таблица фиксирует каноничную сверку между движением пользователя,
движением банка (`efhc_core.bank_balance`) и зеркальными ledger-записями.

## Канон

- Единственное SSOT банка: `efhc_core.bank_balance`.
- `BANK_EFHC` допустим только как логический alias для mirror-log.
- Пользовательские денежные эффекты не должны требовать реального
  апдейта `users` для `BANK_EFHC`.

## Таблица reconciliation

| Operation | User effect | Bank SSOT effect | Ledger user | Ledger bank mirror | Notes |
|---|---|---|---|---|---|
| `credit_user_from_bank` | `main_balance +` | `bank_balance -` | `credit/main` | `debit/main` | банк может уйти в дефицит |
| `debit_user_to_bank` | `main_balance -` | `bank_balance +` | `debit/main` | `credit/main` | withdraw uses main only |
| `spend_user_to_bank_bonus_then_main` | `bonus/main -` | `bank_balance +` | `debit/bonus` + `debit/main` | `credit/main` | split bonus then main |
| `exchange_partial_available_kwh_to_main` | `main_balance +` | `bank_balance -` | `credit/main` | `debit/main` | `exchanged_kwh_total +` |
| `exchange_all_available_kwh_to_main` | `main_balance +` | `bank_balance -` | `credit/main` | `debit/main` | full available_kwh mirror |
| `shop_external confirm EFHC` | `main_balance +` | `bank_balance -` | `credit/main` | `debit/main` | только после доказанного `shop_order` side-effect |

## Что должен доказывать тестовый слой

1. Exchange и spend paths используют `_ensure_bank_locked` и
   `_update_bank_balances`.
2. В `transactions_service` нет реальных bank-user update paths через
   `BANK_EFHC`.
3. Mirror direction согласован с пользовательским направлением:
   user debit -> bank credit, user credit -> bank debit.
4. `shop_external` не подтверждает intent без доказанного обновления
   `shop_orders`.
