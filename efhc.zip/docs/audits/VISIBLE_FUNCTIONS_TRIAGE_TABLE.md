# VISIBLE_FUNCTIONS_TRIAGE_TABLE

leave/delete/admin/question

Energy, Panels, Exchange, Tasks, Referrals, Ranks

Rows retained for historical architecture guards.
