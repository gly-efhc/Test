# RESIDUAL FRONTEND INTEGRATION AUDIT — 2026-04-08

Цель: после resurrection wave проверить, остались ли frontend-компоненты,
которые формально подключены, но не имеют понятной продуктовой роли.

## Проверенные touchpoints
- `ExchangePanel.tsx` → live exchange page touchpoint есть;
- `ReferralsTabs.tsx` → live referrals navigation touchpoint есть;
- `AdsBanner.tsx` → tasks page touchpoint есть;
- `RanksTable.tsx` → ranks page touchpoint есть;
- `AdminCharts.tsx` / `AdminTable.tsx` → admin UI touchpoints есть;
- `admin/shop.tsx` → legacy order admin UI touchpoint есть.

## Residuals
### 1. Legacy/admin density
Несколько revived UI blocks живут в admin/supporting surface, а не в пользовательском
core flow. Это не мёртвый слой, но часть из них остаётся operator-facing UI.

### 2. Frontend dependency warning
Новый GitHub CI log green, но `npm ci` выводит warning о критической
уязвимости `next@14.2.5`. Это не сломанный build, но это реальный residual gap,
который нельзя игнорировать в truth summary.

## Итог
Frontend residual layer после cycles 471-492 не содержит новых semantically-dead
компонентов, но сохраняет dependency-security residual outside the current code-heal
scope.
