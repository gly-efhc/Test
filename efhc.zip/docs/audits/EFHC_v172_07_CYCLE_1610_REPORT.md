# Аудиторский отчёт EFHC v172.07 по циклу 1610

Статус: `LOCAL_AUTH_CONTEXT_CONTRACTS_READY`.
Production status: `NOT_PRODUCTION_RELEASE_READY`.

## 1. Исходная точка

Единственным development Current HEAD принят `EFHC_Bot_v172_06.zip`.
Release и matrix/technical архивы распакованы отдельно. SHA-256, CRC,
ZIP entries, path traversal, symlink и special-file проверки пройдены.

## 2. Обнаруженная несогласованность

Operator Kernel классифицировал цикл 1610 как старый широкий
`user_id_identity_migration`, потому что точный route отсутствовал.
Добавлены отдельный classifier rule, primary YAML route и causal guard.

## 3. Реальные изменения

Созданы `AuthContext`, `AuthContextResponse`, fail-closed resolver
interfaces и recursive auth redaction skeleton. Добавлены machine JSON
contract, exporter, guard, mock resolver и причинные tests. Общий logging
filter расширен auth-sensitive именами полей.

## 4. Runtime boundary

Legacy `backend/app/deps.py::AuthContext(tg_id, is_admin)` и все active
routes остались неизменными. Новый endpoint response пока не подключён к
FastAPI route. Реального IdentityResolver implementation нет.

## 5. Database и экономика

Alembic head остаётся `0002`; новых migrations нет. PostgreSQL DDL/data,
backfill, locks, account/session creation и ownership switch не
выполнялись. Модели, migration и financial files сверяются по SHA-256.

## 6. Test evidence

Fresh exact-HEAD collection: `2987` уникальных node ID. Полный прогон
разделён на 12 JUnit-чанков без дублей: `2815 PASSED`, `172 SKIPPED`,
`0 FAILED`, `0 ERROR`. Причины skips: browser E2E без `EFHC_RUN_E2E=1`
— 95; PostgreSQL integration без URL — 72; Postgres-only CI без URL —
4; общий `DATABASE_URL` отсутствует — 1. Skips не считаются proof.
Защищённые 38 migration/model/financial файлов совпали с исходным HEAD
по SHA-256; identity boundary и русская инженерная норма прошли без
расширения baseline.

## 7. Итог

Exit gate выполнен локально: endpoint contract не содержит `tg_id`, а
provider subject, session reference, proof, token, initData и nonce
редактируются в diagnostics. Следующий цикл — 1611; реальный PG-0
остаётся обязательным blocker.
