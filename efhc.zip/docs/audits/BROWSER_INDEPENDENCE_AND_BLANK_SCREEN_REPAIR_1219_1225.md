# Browser independence and blank-screen repair 1219-1225

Status: corrective pass.

## User signal

The user reported that the frontend opened as a white or empty screen:
no dark visual layer, no first-page content and no progress bars.  The
user also clarified a hard product rule:

- the application must be fully usable as the same app in Telegram and
  in the browser;
- the app must not depend on `global_id` to render the game interface;
- Telegram data may personalize the app, but missing Telegram data must
  not blank the app;
- all agreements are made in chat, not inside the archive.

## Root cause found in code

Several user-facing pages treated missing Telegram `tg_id` as a loading
state and returned a small loading card instead of rendering the page.

Confirmed examples before repair:

- `frontend/src/pages/index.tsx` returned loading when `!props.tg_id`;
- `frontend/src/pages/panels.tsx` returned loading when `!global_id`;
- `frontend/src/pages/tasks.tsx` returned loading when `!global_id`;
- `frontend/src/pages/ranks.tsx` returned loading when `!global_id`;
- `frontend/src/pages/exchange.tsx` returned loading when `!global_id`;
- `frontend/src/pages/withdraw.tsx` returned loading when `!global_id`.

This was wrong for the EFHC browser/PWA target.  A WebApp/PWA must
render the same application shell even when Telegram identity is not
present yet.

## Code repair

Added:

- `frontend/src/lib/browserFallback.ts`

This file creates a safe zero-state browser snapshot for the game UI.
It is not a fake payment proof and not a fake user account.  It is a
visual/runtime fallback so the app can render Energy, progress bars,
Panels, Exchange, Tasks, Ranks and related surfaces outside Telegram.

Updated:

- `frontend/src/pages/app.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/exchange.tsx`
- `frontend/src/pages/tasks.tsx`
- `frontend/src/pages/ranks.tsx`
- `frontend/src/pages/withdraw.tsx`
- `frontend/public/locale/*.json`

## Result

The app no longer replaces the core game pages with a loading-only card
when `global_id` is absent.

Browser/PWA mode now receives a visible fallback snapshot.  Energy can
render the game surface and progress bar.  Other pages can render their
visual modules instead of becoming blank.

Actions that need a real backend identity still cannot honestly create
real economic transactions without identity.  They now keep the visual
surface alive and use local/demo behavior only where safe, such as the
browser Tasks demo timer.

## Not claimed

- Full live browser click-proof is not claimed.
- GitHub CI green is not claimed.
- Full Dragon-style frontend completion is not claimed.
- Real financial transactions without a real user identity are not
  claimed.

