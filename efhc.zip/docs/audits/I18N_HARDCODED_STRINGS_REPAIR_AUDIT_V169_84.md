# I18N hardcoded strings repair audit — v169.84

Date: 2026-06-03  
Cycle: 1402  
Input HEAD: `EFHC_Bot_v169_83_cycle_1401_i18n_reaudit_low_signal_repair.zip`  
Input audit/TZ: `docs/audits/I18N_HARDCODED_AUDIT_AND_TZ_V169_83_2026_06_03.md`

## Status

DONE / SOURCE-LEVEL REPAIR.

This cycle repairs the user-visible hardcoded string findings from the v169.83
i18n hardcoded audit. It does not change EFHC economics, wallet/TonConnect
logic, public/admin route boundaries, CI workflow, package locks or sandbox
runtime code.

## Repaired required group A findings

| Area | File | Repair |
|---|---|---|
| Error boundary crash copy | `frontend/src/components/ErrorBoundary.tsx` | added optional `t` prop for the class component and replaced fallback title/detail/reload copy with i18n keys |
| Admin route guard public copy | `frontend/src/pages/_app.tsx` | added `tFromDicts` translator in `AppInner`, passed it to `ErrorBoundary` and `AdminRouteGuardState`, replaced guard copy with `admin_guard.*` keys |
| Ads banner copy | `frontend/src/components/AdsBanner.tsx` | wired `useT()` and replaced visible `/ads`/tasks banner copy with `ads.*` keys |
| Energy gauge labels | `frontend/src/components/EnergyGauge.tsx` | wired `useT()` and replaced card title/label with `energy.*` keys |
| Surface facts default | `frontend/src/components/ui/SurfaceFactsStrip.tsx` | removed the default `Page overview` fallback after source use-case check confirmed all call sites pass a title |
| Modal close aria | `frontend/src/components/ui/Modal.tsx` | wired `useT()` and replaced close-button aria label with `common.close` |
| Product image placeholder | `frontend/src/components/ui/telegram/TelegramProductCard.tsx` | wired `useT()` and replaced image placeholder text with `common.image_placeholder` |

## Additional optional cleanup

The audit marked these as borderline/optional. They were repaired because they
are low-risk accessibility/component text fixes:

- `frontend/src/components/GlobalHeader.tsx`: `aria-label` now uses
  `common.efhc_balance_aria`.
- `frontend/src/components/ShopLayout.tsx`: avatar `alt` now uses
  `common.avatar_alt`.
- `TelegramProductCard.tsx`: optional secondary `Details` action now uses
  `common.details`.

The following strings remain intentionally documented exceptions:

- `EFHC Storefront` and `EFHC Mini App` in `_app.tsx` ErrorBoundary titles:
  app-level brand titles on rare crash paths.
- `0.00000000` numeric placeholder: universal numeric precision format.
- `USDT runtime *` internal statuses: not user-facing copy.
- EFHC brand spans/badges.

## Locale coverage

18 new flat i18n keys were added to all 13 locale bundles:

- 15 required group-A keys;
- 3 optional accessibility/component keys: `common.details`,
  `common.efhc_balance_aria`, `common.avatar_alt`.

`common.page_overview` was not added because the default fallback was removed
instead.

## Guard added

`tests/architecture/test_i18n_hardcoded_strings_guard.py`

The guard verifies:

- required keys exist in all 13 locale bundles;
- AdsBanner no longer contains the audited hardcoded user text;
- AdminRouteGuardState no longer contains audited hardcoded English copy;
- ErrorBoundary no longer contains audited fallback strings;
- EnergyGauge no longer contains audited public labels;
- SurfaceFactsStrip/Modal/TelegramProductCard no longer contain the audited
  hardcoded fallback strings.

## Checks performed

- `python ops/i18n/audit_all_locale_parity.py` — PASS.
- `python ops/i18n/audit_locale_inventory.py` — PASS.
- `python ops/i18n/audit_no_admin_leak.py` — PASS.
- `python ops/i18n/audit_forbidden_gambling_chance_contour.py` —
  `forbidden_findings: 0`.
- `python ops/i18n/audit_frontend_hardcoded_strings.py` — executes and the
  repaired target files are no longer in the first candidate target set for the
  audited strings.
- All 12 locale value-quality scripts — PASS / `0 unexpected` where reported
  by the scripts.
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q tests/architecture/test_i18n_hardcoded_strings_guard.py` — `6 passed, 3 warnings`.

The warnings are local pytest config warnings caused by plugin autoload being
disabled in this execution environment.

## Non-claims

This audit does not claim:

- GitHub CI green;
- full pytest green;
- full frontend build green;
- browser screenshots;
- live Telegram client proof;
- real TonConnect/wallet proof;
- release-ready status.
