# Frontend Cycle 1283 — Panel Card Date Display Audit

Date: 2026-05-21  
Archive: `EFHC_Bot_v168_81_cycle_1283_panel_card_dates.zip`  
Cycle: 1283

## Purpose

Restore the canonical Panels card display.

The card must not show only a vague age or a hidden technical date.
It must clearly show:

- panel ID;
- activation date;
- deactivation date;
- generated kWh;
- remaining countdown.

## Findings

The backend/source contract was repaired in cycles 1281-1282.
The frontend card still needed a stricter visible layout: activation and
expiration dates existed but the activation date was not labelled and the
expiration date was hidden inside the details block.

## Changes

- added visible `activated_at` field on each panel card;
- added visible `deactivated_at` field on each panel card;
- kept generated kWh visible;
- kept remaining countdown visible;
- left base generation rate inside details;
- added guard markers for date/countdown fields;
- added a targeted architecture guard.

## Not changed

- backend logic;
- database schema;
- migrations;
- activation price;
- debit order;
- panel lifetime.

## Result

Cycle 1283 closes the frontend card display gap after the backend/source
countdown repair of cycles 1281-1282.
