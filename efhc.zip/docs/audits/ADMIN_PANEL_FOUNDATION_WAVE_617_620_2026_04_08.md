# Admin panel foundation wave 617-620

## Scope
Continue cycle 616 foundation work with a stronger admin-home structure inspired by
Horizon dashboard composition and Refine resource grouping.

## Implemented in this wave
- Added `AdminSectionCard` as a reusable shell primitive for grouped admin sections.
- Split admin modules into finance / people / system groups.
- Added quick action block for high-frequency operator entrypoints.
- Elevated top overview facts into KPI-like stat cards.

## Result
Admin home now behaves less like a flat list of modules and more like the first
layer of a future data-heavy admin dashboard.
