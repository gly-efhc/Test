# AUDIT TAILS — 5 CYCLES PLAN — 2026-04-08

## Блок 501-505

### 501/505 — audit tails inventory
- собрать все текущие хвосты из active audit-layer;
- отделить закрытые зоны от реальных residuals;
- оформить единый документ `AUDIT_TAILS_ANALYSIS_2026_04_08.md`.

### 502/505 — clarification protocol actualization
- записать в AI-layer явный формат `Уточняющая итерация:`;
- закрепить, что при сложности/неясности вопросы задаются после краткого отчёта,
  а не заменяются догадками.

### 503/505 — orders overlap compare matrix
- сделать отдельную матрицу по `orders_service.py` vs active shop runtime;
- разделить legacy-read, active-read и duplication zones.

### 504/505 — frontend dependency wave preparation
- подготовить dependency-impact note по `next@14.2.5`;
- зафиксировать, что это отдельная controlled upgrade wave, а не тихая замена
  внутри произвольного цикла.

### 505/505 — CI residual handling note
- отделить chat-only CI residual (`Node 20 deprecation`) от code/archive residuals;
- зафиксировать, что внутри архива он не лечится без прямой команды на workflow
  update в чате.
