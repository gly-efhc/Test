Audit-Id: AUD-2026-02-28-DB-INVENTORY-002
Date: 2026-02-28
Version: EFHC_Bot_v149_15
Topic: db-inventory
Status: ACTIVE
Superseded-By: null
Scope: Ревизия БД/ORM/0001 по аудиту 'Таблицы 2'.
Sources:
  - DOC: 2026-02-28_db-inventory_v149_15__table_audit_2.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Зафиксирован и устранён набор P0-дефектов в домене рефералов и
админ-таблицах: несоответствие имён колонок ORM↔CRUD, отсутствующая ORM
модель ReferralBonusLedger, некорректный schema kw внутри sa.Column в
0001 для efhc_sale_packages, отсутствие таблицы
efhc_admin.bank_balances,
а также отсутствие таблиц referral_links/referral_bonus_ledger в 0001.
## Findings (FACTS)
- ReferralLink ORM использовал имена колонок, несовместимые с CRUD
  (ожидались inviter_tg_id/invitee_tg_id). Исправлено в модели.
[[EV-001]]
- В CRUD используется ReferralBonusLedger, но модели не существовало.
  Добавлена ORM-модель и экспорт. [[EV-002]]
- В 0001 для efhc_sale_packages был schema kw внутри sa.Column(id),
  что ломает SQLAlchemy/Alembic. Устранено. [[EV-003]]
- Админ-сервисы используют efhc_admin.bank_balances, но таблица не
  создавалась в 0001. Добавлена. [[EV-003]]
- 0001 не создавал referral_links/referral_bonus_ledger и/или создавал
  несовместимые FK. Исправлено: создано и привязано к users.tg_id.
[[EV-004]]
- DB_SCHEMA_ADMIN закреплён в ядре конфигурации. [[EV-005]]
## Evidence Index
EV-001 | CODE | backend/app/models/referral_models.py | L44-L75 |\
```text
    __tablename__ = "referral_links"
    __table_args__ = (
        UniqueConstraint(
            "invitee_tg_id",
            name="uq_referral_links_invitee",
        ),
        CheckConstraint(
            "inviter_tg_id <> invitee_tg_id",
            name="ck_referral_links_not_self",
        ),
```
| ReferralLink uses inviter_tg_id/invitee_tg_id in ORM
EV-002 | CODE | backend/app/models/referral_models.py | L125-L175 |\
```text
class ReferralBonusLedger(Base):
    """Журнал реферальных бонусов (не баланс, не банк).
    Назначение:
      • хранит факт начисления бонуса/награды за реферальные действия,
        чтобы отчёты и лимиты не зависели от пересчётов.
    Канон:
      • сумма хранится как Numeric(20, 8), ROUND_DOWN на уровне сервиса.
      • meta — текстовое поле (нужен ilike в CRUD).
```
| ReferralBonusLedger defined and importable
EV-003 | MIGRATION | backend/migrations/versions/0001_init.py |
L147-L222 |\
```text
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "efhc_sale_packages",
        cols=[
            sa.Column(
                "id",
                sa.BigInteger,
                primary_key=True,
                autoincrement=True,
            ),
```
| efhc_admin tables created without schema kw inside Column; bank_balan…
EV-004 | MIGRATION | backend/migrations/versions/0001_init.py |
L870-L980 |\
```text
        ondelete="CASCADE",
            source_schema="efhc_core",
        referent_schema="efhc_core",
    )
    # -----------------------------------------------------------------
    # referrals — рефералы
    # -----------------------------------------------------------------
    ensure_table_with_basics(
        "referral_links",
        cols=[
```
| referral_links + referral_bonus_ledger created with correct FKs
EV-005 | CODE | backend/app/core/config_core.py | L115-L140 |\
```text
        ),
        description="Sync URL (alembic)",
    )
    DB_SCHEMA_CORE: str = Field(
        default="efhc_core",
        description="Главная схема данных",
    )
    DB_SCHEMA_ADMIN: str = Field(
        default="efhc_admin",
```
| DB_SCHEMA_ADMIN is a first-class setting
## Decisions (SSOT)
- Имена колонок ReferralLink считаются каноничными как inviter_tg_id и
  invitee_tg_id во всём коде. [[EV-001]]
- ReferralBonusLedger считается обязательной таблицей домена рефералов;
  код CRUD опирается на неё. [[EV-002]] [[EV-004]]
- В миграциях запрещено использовать schema kw внутри sa.Column; schema
  задаётся только на уровне таблицы. [[EV-003]]
## Actions (P0/P1/P2)
P0
- Применить изменения модели/миграции из этого аудита в HEAD. [[EV-001]]
  [[EV-004]]
P1
- Проверить все admin SQL обращения к efhc_admin.* и обеспечить создание
  таблиц миграцией 0001 либо документировать их как planned. [[EV-003]]
P2
- Провести полную синхронизацию набора ORM таблиц (30) и 0001 (20) с
  отдельным audit topic=db-ssot. [[EV-005]]
## Impact & Risks
- Риск миграционного рассинхрона снижен: устранены P0 ошибки, которые
  приводят к падениям Alembic и runtime-импортов.
- Остаётся системный риск: полный список ORM таблиц всё ещё шире, чем
  создаёт 0001; требуется отдельная SSOT-работа по db-ssot.
## Verification
- python -m compileall backend -q
- Alembic upgrade head в CI должен проходить до sanity шага.
## Appendix: Raw Extract (optional)
См. исходник PDF в docs/audits/_raw/ (хранится как первичный артефакт).
