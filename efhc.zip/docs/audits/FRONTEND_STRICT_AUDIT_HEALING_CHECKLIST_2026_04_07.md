# FRONTEND STRICT AUDIT HEALING CHECKLIST — 2026-04-07

Источник: последний единый жёсткий аудит HEAD-архива.

## Зафиксированные активные фронтенд-зоны
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/components/AdsBanner.tsx`
- `frontend/src/components/ReferralsTabs.tsx`
- `frontend/src/components/DepositModal.tsx`
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`

## Статус лечения
- admin/tasks — actualized
- AdsBanner — actualized
- ReferralsTabs — actualized
- DepositModal — actualized
- BrowserShopPage — in active healing

## Что проверять дальше
- loading/error/empty states
- русификацию user-facing wording
- визуальную целостность Telegram-like blocks
- отсутствие placeholder drift
