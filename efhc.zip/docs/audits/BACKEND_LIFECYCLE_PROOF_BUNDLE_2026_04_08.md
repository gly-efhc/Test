# BACKEND LIFECYCLE PROOF BUNDLE — 2026-04-08

## Цель
Собрать в одном месте доказательный bundle по backend lifecycle для
current HEAD без выдумок и без подмены пользовательского GitHub CI.

## Что проверено по коду

### 1. Primary runtime entrypoint
- `api/index.py` импортирует `app` из `app.main`.
- В `backend/app/main.py` приложение создаётся как `FastAPI(...,
  lifespan=lifespan)`.
- Значит для server/runtime entrypoint текущего HEAD primary lifecycle
  управляется через `app.main:lifecycle`.

### 2. Lifespan path
В `backend/app/main.py` внутри `lifespan` зафиксированы:
- startup validation через `validate_on_start()` из `system_locks`
- branch по `settings.SERVERLESS`
- start/stop `check_ton_inbox_agent` только вне serverless
- явный shutdown path для stop агента

### 3. Security/startup guards до app creation
До создания `FastAPI` в `backend/app/main.py` есть ранние safety guards:
- запрет `ALLOW_INSECURE_USER_HEADERS=true` при `ENV=prod`
- запрет `ALLOW_REAL_FUNDS=true` при `ENV=stage/staging`

Это усиливает startup discipline и снижает риск молчаливого unsafe boot.

## Что подтверждено
- Current primary runtime path использует `lifespan`, а не набор разрозненных
  `@app.on_event("startup")`/`shutdown` в primary entrypoint.
- Startup discipline не спрятан в документах, а реально присутствует в коде.
- Background-agent start/stop завязан на serverless flag и не должен молча
  работать в serverless mode.

## Residual / что остаётся живым

### Residual 1: dual-entrypoint surface
В репозитории существует и `backend/app/init.py` с `create_app()` и
собственным lifespan-helper слоем.
Это не доказанная поломка, но это отдельная dual-entrypoint зона,
которую нужно держать под контролем как traceability risk.

### Residual 2: нужен явный contract-doc
Нужен отдельный документ, который прямо фиксирует:
- какой entrypoint primary,
- какой secondary/helper,
- кто используется в `api/index.py`, `run.py` и deploy surfaces.

## Вывод
Backend lifecycle по current HEAD выглядит существенно лучше, чем
внешний audit-risk baseline, но до fully packaged proof layer ещё нужен
отдельный entrypoint/traceability closure.
