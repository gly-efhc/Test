# FRONTEND_CYCLE_1328_WITHDRAWALS_MOBILE_DECISION_AUDIT_V169_07

Дата: 2026-05-27  
Архив: `EFHC_Bot_v169_07_cycle_1328_withdrawals_mobile_decision_panel.zip`  
Цикл: 1328

## 1. Цель

Сделать `/admin/withdrawals` mobile-first интерактивной операторской панелью
решений на базе Admin UI Kit и sandbox donor-паттернов.

## 2. Подтверждённое чтение

Прочитаны:

- HEAD `v169_06`;
- AI Start Core;
- Admin/Frontend документы;
- cycle 1326/1327 документы;
- withdraw SSOT documents;
- `frontend/src/pages/admin/withdrawals.tsx`;
- `Песочница.xz`.

## 3. Sandbox intake

Физически открыт `EFHC_SANDBOX_COMPACT_v002`.

Использованы sandbox-файлы:

- `chart-area-interactive.tsx`;
- `section-cards.tsx`;
- `data-table.tsx`;
- MaterialM dashboard cards;
- Telegram WebApp admin/shop examples.

## 4. Изменения кода

Добавлен:

- `frontend/src/components/admin/AdminWithdrawalsMobileDecisionPanel.tsx`

Изменён:

- `frontend/src/pages/admin/withdrawals.tsx`
- `frontend/src/styles/globals.css`

## 5. Проверка канона

Сохранено:

- withdraw из MAIN only;
- TonConnect payout path;
- approve/reject confirm-flow;
- outcome preview внутри `/admin/withdrawals`;
- repair consistency action;
- финальные статусы как защищённые зоны.

Не менялось:

- backend;
- экономическая логика;
- DB schema;
- generated seam files;
- dependency versions.

## 6. Риск-контроль

Риски:

- `CANCELED` добавлен как state-machine lane UI уровня; если backend не отдаёт
  такие заявки, lane будет пустой.
- Full build нужно проверять в CI, потому что локальный frontend build в прошлых
  циклах мог упираться в page-data finalization.

## 7. Итог

Cycle 1328 принят как mobile-first admin withdrawals decision layer.

## 8. Local checks actually run

- `python -m compileall -q backend` — passed.
- `python -m pytest -q tests/architecture/test_admin_sandbox_ui_kit.py tests/architecture/test_admin_operator_interactive_section.py tests/architecture/test_admin_withdrawals_mobile_decision.py` — passed, 15 tests.
- `npm ci --no-audit --no-fund --progress=false` — passed.
- `npx tsc --noEmit` — passed.
- `npm run build` — successful compile, then local `EPIPE` at `Collecting page data`; not claimed as full-green build.
