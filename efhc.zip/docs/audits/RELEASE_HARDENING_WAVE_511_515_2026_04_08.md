# RELEASE HARDENING WAVE 511-515 — 2026-04-08

## Что сделано в этой волне

1. `sale-packages` доведены до бинарного решения "not SSOT / non-release":
   - PDF-аудиты добавлены в `docs/audits/`;
   - frontend уже был de-lived в wave 506-510;
   - теперь и backend mutating routes возвращают `409 conflict` вместо ложной
     writable surface.

2. AI-layer усилен правилом, что cycle docs обязаны быть подробными, потому что
   это память, направление и внечатовое хранилище пути проекта.

3. Admin withdrawals получили confirm step с context block перед approve/reject.

4. Admin bank получил confirm step с preview текущего и ожидаемого баланса до
   mint/burn.

## Что ещё не закрыто
- replay-safe semantics для остальных sensitive admin actions как отдельный
  системный слой;
- deposit processing workflow;
- Mini App deposit result/status UX;
- повторный product/runtime re-audit после следующих волн.
