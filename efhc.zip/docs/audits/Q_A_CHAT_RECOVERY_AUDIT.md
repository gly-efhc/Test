# Q/A CHAT RECOVERY AUDIT — v174.34 / цикл 1787

Статус: **ARCHIVE RECOVERY AUDIT / NON-RUNTIME**

- Проверены все доступные numbered transcripts: **35**.
- Явные Q/A-маркеры найдены в **9** чатах.
- Всего явных Q/A-маркеров: **58**.
- Источник истины для ответа — только текст соответствующего transcript; generic `Да/Нет` без восстановимого исходного вопроса не превращается в owner CANON.
- Полный machine inventory: `reports/generated/Q_A_CHAT_RECOVERY_AUDIT_v174_34.json`.

## Покрытие по чатам

| Chat | Markers | Disposition summary |
|---:|---:|---|
| 10 | 15 | CONTEXT_INCOMPLETE_GENERIC_ANSWER_BLOCK=9; RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=6 |
| 13 | 24 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=24 |
| 18 | 0 | NO_EXPLICIT_QA_MARKERS |
| 19 | 2 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=2 |
| 20 | 1 | INSTRUCTION_TO_ASK_QUESTIONS_NO_ANSWER_BLOCK_IN_SAME_CHAT=1 |
| 21 | 1 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=1 |
| 22 | 0 | NO_EXPLICIT_QA_MARKERS |
| 24 | 0 | NO_EXPLICIT_QA_MARKERS |
| 25 | 0 | NO_EXPLICIT_QA_MARKERS |
| 26 | 8 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=8 |
| 27 | 0 | NO_EXPLICIT_QA_MARKERS |
| 28 | 0 | NO_EXPLICIT_QA_MARKERS |
| 30 | 1 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=1 |
| 31 | 0 | NO_EXPLICIT_QA_MARKERS |
| 32 | 0 | NO_EXPLICIT_QA_MARKERS |
| 33 | 0 | NO_EXPLICIT_QA_MARKERS |
| 34 | 0 | NO_EXPLICIT_QA_MARKERS |
| 35 | 0 | NO_EXPLICIT_QA_MARKERS |
| 36 | 0 | NO_EXPLICIT_QA_MARKERS |
| 40 | 0 | NO_EXPLICIT_QA_MARKERS |
| 41 | 0 | NO_EXPLICIT_QA_MARKERS |
| 43 | 0 | NO_EXPLICIT_QA_MARKERS |
| 44 | 5 | RECOVERED_HISTORICAL_OWNER_QA_EVIDENCE=5 |
| 45 | 1 | UNRESOLVED_NO_EXPLICIT_OWNER_ANSWER_FOUND=1 |
| 47 | 0 | NO_EXPLICIT_QA_MARKERS |
| 49 | 0 | NO_EXPLICIT_QA_MARKERS |
| 50 | 0 | NO_EXPLICIT_QA_MARKERS |
| 51 | 0 | NO_EXPLICIT_QA_MARKERS |
| 52 | 0 | NO_EXPLICIT_QA_MARKERS |
| 53 | 0 | NO_EXPLICIT_QA_MARKERS |
| 54 | 0 | NO_EXPLICIT_QA_MARKERS |
| 55 | 0 | NO_EXPLICIT_QA_MARKERS |
| 56 | 0 | NO_EXPLICIT_QA_MARKERS |
| 57 | 0 | NO_EXPLICIT_QA_MARKERS |
| 58 | 0 | NO_EXPLICIT_QA_MARKERS |

## Восстановленные устойчивые owner decisions

1. `chat 10`: удаление/исключение файлов без отдельного согласования запрещено; test-policy уточнена — технический repair setup/data допустим при сохранении цели теста, а изменение сути/логики требует отдельной итерации и уточняющих вопросов.
2. `chat 13`: SSOT нельзя использовать как склад временных/операционных документов; GENERAL/AUDIT/REPORT/CYCLE слои имеют отдельные назначения; glossary-first и Q/A-register обязательны; cycle-scope 937–950 и document-cleanup decisions сохранены как historical owner evidence.
3. `chat 19`: согласование вопросов и ответов происходит в чате; архив — внутренняя рабочая память/доказательство, но не канал согласования.
4. `chat 21`: восстановлены frontend product decisions, включая FAQ compact vertical disclosure, реальные Wallet/History surfaces, human-readable Browser-Shop statuses, Admin с понятными разделами/графиками и отдельной Diagnostics.
5. `chat 26`: owner потребовал формулировать вопросы простыми словами; `игра/game` само по себе не запрещено — запрет относится к азартным играм, лотереям и chance-reward-risk contour; test consolidation сначала был audit-only, затем отдельно разрешено объединение подготовленных групп.
6. `chat 30`: genesis/bootstrap mint `5,000,000.00000000 EFHC` разрешён только стартовой `0001`; будущий тихий mint/rewrite через migrations запрещён, runtime Mint/Burn только через AdminBankService → transactions service.
7. `chat 35`: invalid archive numbering `v170_100` owner-approved repair → `v171_00` с усиленным guard против `vN_100+`.
8. `chat 44`: referral binding только при первом создании пользователя; существующего пользователя поздно привязать нельзя; `0 user` постоянный; direct referral only; referral bonus только за первую panel activation; manual bind/attach не разрешены.
9. `chat 45`: вопрос о literal 10,000 sequential referral credits против representative real PostgreSQL E2E не имеет найденного явного owner answer в доступном transcript и сохранён как `UNRESOLVED`, а не реконструирован.

## Контекстно неполные ответы

В `chat 10` есть несколько блоков `Да/Да` без сохранённого текста исходных вопросов. Они зарегистрированы в machine inventory как `CONTEXT_INCOMPLETE_GENERIC_ANSWER_BLOCK`; owner decision из них не выводится.

## Вывод

Реестр дополнен только доказуемыми решениями. Старые transcripts остаются immutable evidence; их содержимое не переписывается.
