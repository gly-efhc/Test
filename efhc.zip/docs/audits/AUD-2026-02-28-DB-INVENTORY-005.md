Audit-Id: AUD-2026-02-28-DB-INVENTORY-005
Date: 2026-02-28
Version: EFHC_Bot_v149_17
Topic: db-inventory
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; факты и решения с evidence.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-DB-INVENTORY-005.pdf
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Паспортизация дублей и внешних таблиц

## Findings (FACTS)

- Физических ORM-дубликатов schema.table не обнаружено. [[EV-001]]
- Логических дублей таблиц (archive/cache/history) не выявлено.
[[EV-001]]
- Админ-часть использует таблицы только в efhc_core/efhc_admin.
[[EV-001]]

## Evidence Index

EV-001 | DOC |
docs/audits/_raw/
    2026-02-28_db-inventory_v149_17__duplicates_passport.pdf
| - | Паспортизация дублей (PDF), выводы A–E. | Доказывает отсутствие
физ./лог. дублей и внешних таблиц.

## Decisions (SSOT)

- Не выполнять слияний/удалений таблиц на основе этого аудита:
конфликтов не найдено. [[EV-001]]

## Actions (P0/P1/P2)

- P0: нет.
- P1: при новых таблицах требовать паспорт (назначение, владелец,
маршруты).
- P2: периодически повторять проверку дублей при росте моделей.

## Impact & Risks

Риск низкий: аудит не выявил дублей; риск появления дублей при росте
моделей остаётся.

## Verification

Проверить линтерами аудитов и сверить evidence по указанным путям.

## Appendix: Raw Extract (optional)

1.
**A)
ORM
Physical
Duplicates:**
Нет
обнаруженных
физических
дубликатов
моделей
