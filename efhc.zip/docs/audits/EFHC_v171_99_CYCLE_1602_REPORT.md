# Отчёт цикла 1602 — канонизация Global ID

## Статус

`GLOBAL_ID_CANON_ACTIVE / LOCAL_RELEASE_CANDIDATE /
POSTGRESQL_PROOF_REQUIRED / NOT_PRODUCTION_RELEASE_READY`.

## Архитектурный результат

`global_id` закреплён как единственный главный идентификатор аккаунта.
`id` остаётся локальным PK. `global_id`, wallet address, email и другие
provider subjects не могут формировать либо заменять `global_id`.

Физическое состояние БД не изменено:

- Alembic: `<base> → 0001 → 0002`;
- `users.id`: primary key;
- `users.user_id`: nullable BIGINT EXPAND;
- `users.global_id`: legacy NOT NULL;
- отдельная `users.global_id`: отсутствует.

## Compatibility layer

- `User.global_id → User.user_id`;
- `User.legacy_pk → User.id`;
- `User.telegram_id → User.tg_id`;
- `User.legacy_runtime_id → User.id`;
- `UserId` и DTO `user_id` остаются bounded LEGACY до cleanup.

## Guards

Guard отклоняет:

- provider ID либо локальный `id` как `global_id`;
- отдельную физическую колонку `global_id` рядом с `user_id`;
- новый DTO/field `user_id` вне compatibility allowlist;
- новый FK на локальный `users.id`;
- удаление обязательных aliases;
- Alembic drift относительно `0001 → 0002`;
- преждевременный backfill/read/financial switch.

## PostgreSQL

Реальная PostgreSQL reconciliation не выполнена и заблокирована
окружением. Денежное расхождение `0.00000000` на фактической БД в этом
цикле не доказано.

## Auth

TON Proof login, Telegram IdentityResolver, sessions, challenges,
roles и AuthContext не реализовывались. Автоматический merge остаётся
запрещённым.

## Следующий цикл

`1603 — Global ID PostgreSQL reconciliation baseline`.

## Финальный локальный regression

Точная collection: `2854` теста.

- `PASSED`: `2679`;
- `SKIPPED`: `175`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Причины пропусков: 95 browser E2E без `EFHC_RUN_E2E=1`; 72 real
PostgreSQL integration без URL; 4 Postgres-only CI; 1 проверка без
`DATABASE_URL`; 3 optional/environment collection gates. Skip не
считается выполнением PostgreSQL или Chromium-проверки.

Frontend release-assets: `PASS`, 29 файлов. Полный Next.js build,
TypeScript typecheck и performance budgets не выполнены: отсутствуют
`frontend/node_modules` и `.next/build-manifest.json`.
