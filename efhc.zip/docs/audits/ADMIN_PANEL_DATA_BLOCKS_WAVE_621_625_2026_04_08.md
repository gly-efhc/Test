# Admin panel data blocks wave 621-625

## Scope
Continue the admin foundation stage by pushing the new shell into the most
important financial operator pages.

## Implemented in this wave
- `AdminBankPage` now uses admin stat cards and section cards for balance and
  emission blocks.
- `AdminWithdrawalsPage` now exposes summary stat cards, filter section shell,
  and a clearer request-list section.
- Added locale keys for operator-contour wording and data-block hints.

## Result
The future admin panel no longer grows only from `admin/index`. The same shell
logic now starts spreading into the financial operator surfaces.
