# Cycle 873 — Manual Review Governance

Date: 2026-04-16
Status: canonical governance table for `manual_review`

## Purpose

`manual_review` is allowed only as a controlled state.
It must not become a gray zone between `network_seen`
and `credited` / `failed` / `canceled`.

## Owner of the state

Primary owner: admin operator.

The state belongs to the operator contour because the user
cannot resolve `manual_review` alone inside the storefront.
The user may only provide extra proof or wait for a manual
resolution.

## Entry rules

A payment intent may enter `manual_review` only when at
least one of these conditions is true:

1. The watcher saw a transaction signal, but cannot prove
   final crediting automatically.
2. The inbox / order / watcher signals disagree.
3. The transaction needs an operator proof check.
4. The payment path needs a fraud or mismatch review.
5. A normal automatic path cannot classify the intent as
   `credited`, `failed`, `expired`, or `canceled` safely.

## Truth table

| status source | lifecycle_stage | terminal | owner | allowed operator actions | exit conditions | user-facing wording |
|---|---|---:|---|---|---|---|
| watcher saw signal, proof incomplete | manual_review | no | operator | inspect tx data; inspect proof; inspect order; wait; mark credited; mark failed; cancel if invalid | enough evidence for credit; enough evidence for fail; explicit cancellation | We found your payment signal. Manual review is in progress. |
| order / watcher mismatch | manual_review | no | operator | compare order and watcher state; inspect logs; inspect proof; mark credited; mark failed | mismatch resolved into one proven outcome | We are checking a payment mismatch. No action is required right now. |
| user proof required | manual_review | no | operator | request proof; inspect proof; keep waiting; mark failed if proof absent and path expires | proof accepted; proof rejected; review timeout resolved by policy | We need extra proof to continue checking this payment. |
| fraud or anomaly review | manual_review | no | operator | inspect anomaly; compare hashes; inspect logs; mark failed; escalate for safe handling | anomaly cleared; anomaly confirmed as invalid | Your payment needs an additional safety check. |

## Allowed operator actions

The operator may:

- inspect tx hash, watcher facts, inbox rows, and order state;
- inspect user proof and moderator-style notes;
- keep the intent in review while evidence is incomplete;
- resolve to `credited` only with enough positive proof;
- resolve to `failed` only with enough negative proof;
- resolve to `canceled` only when cancellation is valid by
  policy and product semantics.

The operator may not:

- leave the state forever without review intent;
- treat `manual_review` as a silent sink;
- present `manual_review` to the user as a final success;
- mark the intent terminal without a clear reason.

## Exit rules

`manual_review` must exit only into a terminal or clearly
proven next state:

- `credited`
- `failed`
- `canceled`

Return to `network_seen` is not canonical. Once an operator
owns the state, the state must resolve forward, not blur
backward.

## User wording rules

Allowed wording must stay truthful:

- payment signal found;
- manual review in progress;
- extra proof needed;
- no action required right now;
- we will update the status after review.

Forbidden wording:

- success implied before proof;
- failure implied before proof;
- vague phrases that hide ownership or next step.

## High-risk notes

`manual_review` and `network_seen` remain the two highest-risk
money-path states because both can look stronger in UI than in
proven runtime evidence.

This cycle locks `manual_review` as an operator-owned,
non-terminal, forward-resolving governance state.
