# AUDIT OF AUDITS AND HEALER TRANSFER PLAN — 2026-04-08

## Назначение

Документ фиксирует:
1. какие аудиты ещё нужны как active truth;
2. какие аудиты уже можно считать историческим слоем;
3. какие ошибки из аудитов обязаны быть перенесены в Healer до удаления
   старых audit-файлов;
4. какой лечебный план открыть на циклы 452-470.

## Короткий вывод

Текущий раздел `docs/audits/` слишком широк для активного truth-layer.
В нём смешаны:
- действующие re-audit / hardening / release-truth документы;
- промежуточные wave-планы и code-start документы;
- старые инвентаризации и локальные срезы, уже перекрытые более свежими
  аудитами или кодом;
- сырой evidence-слой `_raw`.

Главная проблема не в самом объёме, а в том, что часть ошибок до сих пор
живёт только в старых аудитах, а не в Healer. Это создаёт риск потери
памяти проекта при будущей зачистке раздела `docs/audits/`.

## Что оставить в active audit-surface

Оставить как активный truth-layer:
- `UNIFIED_STRICT_HEAD_AUDIT_2026_04_06.md`
- `AUDIT_OF_AUDIT_2026_04_06.md`
- `BANK_RECONCILIATION_TABLE_2026_04_06.md`
- `IDEMPOTENCY_CONCURRENCY_PROOF_2026_04_06.md`
- `SELF_HEALING_PATH_AUDIT_2026_04_06.md`
- `AUDIT_ARCHIVE_TRIAGE_2026_04_07.md`
- `REAUDIT_AFTER_HEALING_BLOCK_410_429_2026_04_07.md`
- `REAUDIT_AFTER_SANDBOX_428_429_2026_04_07.md`
- `WATCHER_REPORTING_ALIGNMENT_2026_04_07.md`
- `RESIDUAL_SHOP_READ_REPORTING_AUDIT_2026_04_07.md`
- `GITHUB_CI_LOGS_HEALER_TRANSFER_2026_04_07.md`
- `GITHUB_CI_LOGS_DELETION_CANDIDATES_2026_04_07.md`
- этот документ как новый control-layer для зачистки и переноса в Healer.

## Что перевести в historical / removable-after-transfer слой

После переноса ошибок в Healer можно убирать из active surface
(переносить в `artifacts/` либо удалять после согласования):
- старые `AUD-2026-02-28-*` и `AUD-2026-03-01-*` инвентаризации;
- старые route/db/admin inventory audits, если их выводы уже закреплены
  в SSOT, guards и Healer;
- `*_CODE_START_*`, `*_PLAN_*`, `*_PROTOCOL_*` по старым волнам,
  если они не являются текущим truth-layer и уже перекрыты реализацией;
- промежуточные frontend/browser-shop progress batches,
  если итог зафиксирован в более поздних re-audits;
- старые historical-doc audits, если из них уже извлечены ошибки
  document-control слоя.

## Обязательные ошибки, которые должны жить в Healer

Ниже — минимальный backbone, который обязан быть в Healer
до зачистки старых аудитов.

### 1. Economy / bank / ledger
- bank split-brain и запрет реального банка через `BANK_EFHC user`;
- mirror-direction drift;
- idempotency conflict drift;
- exchange autobegin drift;
- energy `_begin_tx` recursion pattern;
- self-healing queue / broken SQL;
- shop schema drift и reporting residuals.

### 2. Release purity
- transient junk in ZIP;
- nested release zip relapse;
- build-script drift;
- путаница между transient junk и `artifacts/`.

### 3. Cycle / AI / control
- ложное закрытие циклов;
- подмена GitHub CI локальными прогонами;
- stale cycle-control panel;
- отсутствие dependency precheck;
- вынос ошибок в старые аудиты без переноса в Healer.

### 4. Frontend / UX residuals
- visual white spots;
- inconsistent empty/loading/error states;
- wording drift after canon updates;
- browser shop / hub residual mismatches.

## Для чего нужен `_raw`

`docs/audits/_raw` нужен как слой первичных evidence-источников:
- исходные markdown/pdf-аудиты;
- старые первичные выгрузки;
- документы, из которых были собраны нормализованные audit-md файлы
  и `audits_index.json`.

Его смысл:
- хранить первичный источник, если нужно доказать происхождение вывода;
- давать трассировку `audit -> raw source`;
- не смешивать сырой источник с нормализованным active audit-text.

Но `_raw` **не должен** быть бесконечной активной свалкой.
После переноса ошибок в Healer и фиксации активного truth-layer
он должен стать:
- либо чистым архивом первичных источников;
- либо кандидатом на перенос в `artifacts/` после согласования;
- но не основным рабочим слоем для повседневной навигации.

## План циклов 452-470 — перенос audit-debt в Healer

### Блок 452-455 — economy / release backbone
- 452 — перенести economy defects backbone из жёстких audit-docs в Healer.
- 453 — перенести release/build/archive hygiene defects в Healer.
- 454 — перенести shop/watcher/reporting residuals в Healer.
- 455 — перенести self-healing / sync / scheduler residuals в Healer.

### Блок 456-460 — frontend / UX / wording
- 456 — frontend visual white spots -> Healer.
- 457 — browser shop / hub residual UX mismatches -> Healer.
- 458 — wording / i18n / locale drift -> Healer.
- 459 — admin/premium visual residuals -> Healer.
- 460 — consolidate frontend Healer map and remove stale duplicate audits.

### Блок 461-465 — AI / cycle / process memory
- 461 — AI continuity / chat drift / prompt-layer defects -> Healer.
- 462 — cycle-control and false-closure defects -> Healer.
- 463 — GitHub CI ownership / proof honesty defects -> Healer.
- 464 — reports / audit-surface process defects -> Healer.
- 465 — verify that old log-audits no longer carry unique errors outside Healer.

### Блок 466-470 — retention / deletion readiness
- 466 — mark active vs historical audits file-by-file.
- 467 — prepare agreed transfer to `artifacts/` for stale audit docs.
- 468 — prepare deletion-after-agreement list for obsolete audit docs.
- 469 — final Healer cross-check against old audits.
- 470 — truth-summary and closure of the audit-transfer wave.
