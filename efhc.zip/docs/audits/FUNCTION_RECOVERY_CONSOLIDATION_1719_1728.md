# КОНСОЛИДАЦИЯ РЕШЕНИЙ 1719–1728 — ЦИКЛ 1729

Статус: **ACTIVE DECISION MATRIX**  
Цикл консолидации: `1729`  
Кандидат HEAD: `v173.54`

## 1. Назначение

Этот документ сводит десять согласованных волн 1719–1728 в одну матрицу.
Он не открывает новый cleanup. Решения ниже считаются действующими вместе с
их профильными CANON/SSOT. Если профильный CANON содержит более подробное
правило, действует более узкое профильное правило.

Статусы:

- `KEEP` — сохранить как действующую capability/contract;
- `CONNECT_UI` — capability подключена к пользовательскому/Admin UI;
- `RESTORE_FACADE` — сохранить тонкий compatibility facade без второй логики;
- `REPLACE` — историческая функция заменена каноническим механизмом;
- `REMOVE_APPROVED` — удаление разрешено только при полном delete-proof.

## 2. Десять решений

| Цикл | Область | Итоговое решение | Статус | Active evidence |
|---|---|---|---|---|
| 1719 | Admin Reports / Observability | Пять domain reports подключены к `/admin/reports`; duplicate `/admin/observability/events` сохранён как отключённый compatibility route, replacement — `/admin/logs/transfers`. | `KEEP + CONNECT_UI + REPLACE` | `docs/admin/ADMIN_REPORTS_AND_OBSERVABILITY_CANON.md` |
| 1720 | Admin Tasks / ADS | Полный Tasks Editor сохранён; safe-delete fail-closed; task maintenance отделён от TON watcher; ADS остаётся отдельным provider contour. | `KEEP + CONNECT_UI` | `docs/admin/ADMIN_TASKS_EDITOR_CANON.md` |
| 1721 | Shop Management | Admin Shop, внешний Browser Shop, profile handoff и Order Control являются одной capability; item/order history не удаляется; recovery credit только через BANK. | `KEEP + CONNECT_UI` | `docs/admin/ADMIN_SHOP_MANAGEMENT_CANON.md` |
| 1722 | Referrals / Ranks | Четыре frontend-страницы подключены к существующим backend routes; `kwh` и `referrals` разделены; mock/offline runtime запрещён. | `KEEP + CONNECT_UI` | `docs/frontend/REFERRALS_RANKS_FRONTEND_CANON.md` |
| 1723 | Admin financial/status utilities | Legacy counters/config helpers не возвращаются по старым именам; полезная семантика встроена в Bank/Withdraw reports. | `REPLACE + CONNECT_UI` | `docs/admin/ADMIN_FINANCIAL_STATUS_UTILITIES_CANON.md` |
| 1724 | TON inbox / deposits / recovery | Единый понятный Admin Deposits workflow: inbox, unmatched, replay, reconciliation; произвольная ручная смена финансового статуса запрещена. | `KEEP + CONNECT_UI + REPLACE` | `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md` |
| 1725 | VIP / NFT / manual claim | VIP определяется NFT checker; Admin NFT — отдельный credential; historical duplicate manual claim не возвращается; оплаченный NFT ShopOrder является единственной заявкой на ручную выдачу. | `KEEP + CONNECT_UI + REPLACE` | `docs/admin/ADMIN_VIP_NFT_MANAGEMENT_CANON.md` |
| 1726 | Bonus / Withdraw / manual credits | Ручные деньги идут только через `/admin/transfer -> BankService`; Bonus построен на active ledgers, dead `bonus_awards` не возвращается; Withdraw остаётся только EFHCm. | `KEEP + CONNECT_UI + RESTORE_FACADE + REPLACE` | `docs/admin/ADMIN_BONUSES_AND_MANUAL_CREDITS_CANON.md` |
| 1727 | Wallets / Payment Intents / Watcher / Reconciliation | `confirm_payment_intent` — единственная canonical confirmation point; payment owner — строковый 10-значный `global_id`; backend отдаёт message keys, UI локализует 13 языков; старые wallet/watcher seams остаются thin compatibility. | `KEEP + RESTORE_FACADE + REPLACE` | `docs/payments/WALLET_PAYMENT_RECONCILIATION_CANON.md` |
| 1728 | Runtime compatibility | Startup/DB/decimal/ORM facades и FSM public facade защищены; Admin/scheduler maintenance compatibility не удаляется по отсутствию caller; `RBAC.is_superadmin` не является auth-path. | `KEEP + RESTORE_FACADE` | `docs/backend/RUNTIME_COMPATIBILITY_CANON.md` |

## 3. Общие правила после консолидации

1. Business owner — только `global_id`; provider subject остаётся только на
   соответствующей provider/delivery boundary.
2. BANK — `BANK_EFHC`, а не пользователь; P2P запрещён.
3. Один бизнес-механизм не дублируется compatibility facade-ами: facade только
   делегирует current CANON.
4. Видимый Admin UI использует человеческие понятия; технические коды остаются
   внутри API/logs или диагностического слоя.
5. `no caller != delete proof`.
6. Historical document не может сам вернуть superseded runtime semantics.
7. Любое удаление требует отдельного решения пользователя и полного
   route/import/scheduler/dynamic/external/history delete-proof.

## 4. Аудит устаревших алиасов цикла 1729

### 4.1. Удалено — `REMOVE_APPROVED`

Удалён приватный transitional alias-layer из
`backend/app/core/sql_aliases_core.py`:

- `core -> efhc_core`;
- `efhc -> efhc_core`;
- `efhc-core -> efhc_core`;
- `admin -> efhc_admin`;
- `efhc-admin -> efhc_admin`;
- `vip_log -> vip_status_log`;
- `vip_status -> vip_status_log`.

Delete-proof для этих семи записей:

- alias maps были приватными и не входили в public export/HTTP contract;
- current runtime callers `canon_schema()` передают canonical
  `efhc_core/efhc_admin`;
- Alembic `env.py` отдельно допускает только `efhc_core/efhc_admin`;
- active NFT/VIP runtime использует canonical `vip_status_log`;
- literals `vip_log`/`vip_status` не используются current callers;
- active function-preservation manifest не защищает эти private alias maps;
- внешний ENV compatibility не удалён: его отдельная нормализация остаётся в
  `config_core`, поэтому это удаление не является скрытым изменением deployment
  environment contract.

После удаления `sql_aliases_core` является strict canonical validator, а не
transitional alias resolver.

### 4.2. Проверено и сознательно сохранено

Не удалены как «алиасы» следующие классы совместимости:

- ENV `AliasChoices` в `config_core`: внешний deployment ingress, отсутствие
  internal caller не доказывает отсутствие действующей конфигурации;
- provider-name normalization в provider registry: внешний ingress;
- Pydantic validation/serialization aliases: wire/API compatibility;
- TON legacy memo и idempotency historical read-through: обработка уже
  существующих внешних/исторических данных;
- Admin/Bonus/Withdraw compatibility facades, явно сохранённые пользователем в
  1726;
- wallet/watcher payment compatibility seams, явно сохранённые в 1727;
- startup/DB/ORM/FSM/Admin/scheduler compatibility surfaces, бессрочно
  сохранённые решением 1728.

Их удаление в 1729 запрещено: для них нет полного delete-proof либо существует
прямое решение пользователя о сохранении.

## 5. Что цикл 1729 не меняет

- не создаёт новые экономические правила;
- не меняет Alembic one-head policy;
- не возвращает `tg_id` business ownership;
- не удаляет protected runtime facade по одному только static no-caller;
- не выполняет локальную CI qualification.

## 6. Следующий этап

`1730` — exact-head GitHub CI qualification/error burn-down. В нём запрещены
новые функциональные решения: только подтверждённые failures нового HEAD.
