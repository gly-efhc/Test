# External shop release evidence checklist (2026-04-08)

## Product path
- Есть вход из Hub.
- Есть bootstrap state.
- Есть wallet sync guidance.
- Есть create intent.
- Есть payment details.
- Есть status polling.
- Есть terminal cleanup / return path.

## Route truth
- Handoff route работает как signed-token entry.
- Catalog route читает SSOT storefront source.
- Create-intent route не создаёт ложный secondary truth-layer.
- Status route привязан к тому же intent-layer.

## Admin / operator truth
- storefront packages управляются через общий truth-layer, а не через false-live модуль;
- admin surface не вводит оператора в заблуждение относительно SSOT.

## UX / release clarity
- страница честно показывает свою release stage;
- нет скрытого “MVP, но назван full release”; 
- есть ясные next-step тексты для оплаты и статуса.

## Remaining proof still needed
- повторный узкий product/runtime re-audit внешней storefront-slice после следующих волн.
