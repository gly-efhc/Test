# FAQ language and layout repair — cycle 1208

## HEAD

Input archive:
`EFHC_Bot_v168_24_cycle_1207_payment_status_route_diagnosis.zip`.

## Finding

The FAQ frontend had two user-visible problems:

1. Some FAQ labels were hardcoded in English.
2. The FAQ page had no compact bot-width shell.

This made the language switch look broken even when the catalog changed.
The page also looked too wide and heavy for the game simulation shell.

## Root cause

The FAQ page used the selected catalog through `ctx.lang`, but several
helper blocks still rendered literal English strings:

- `Quick FAQ sections`;
- `Where to go next`;
- `Quick topic links`;
- English subtitles for Wallet, History, Panels, Exchange, Referrals;
- English subtitles for Ranks.

The page root also used only a generic grid.  It had no FAQ-specific
width guard, overflow guard, or compact mobile spacing.

## Code changes

Changed files:

- `frontend/src/pages/faq.tsx`;
- `frontend/src/components/faq/FaqAccordionList.tsx`;
- `frontend/src/styles/globals.css`;
- `frontend/public/locale/*.json`.

Implemented:

- FAQ root now uses `key={ctx.lang}`;
- FAQ root now uses `efhc-faq-shell`;
- sticky search/category block now uses `efhc-faq-sticky`;
- hardcoded English quick-link texts moved to locale keys;
- all active locale JSON files received the required FAQ keys.

## Guard

Added:

`tests/architecture/test_faq_language_layout_guard.py`.

The guard checks:

- FAQ catalog follows `ctx.lang`;
- FAQ remounts on language change;
- hardcoded English helper labels are absent;
- all locale files contain the new FAQ keys;
- FAQ has the compact bot-width shell CSS.

## Checks

Local checks executed:

- `pytest` targeted visual/language guards: passed;
- `python3 -m py_compile` new guard: passed;
- `npm ci --ignore-scripts`: completed;
- `npx tsc --noEmit`: completed;
- locale JSON validation: completed.

`npm run build` compiled successfully but timed out at page-data
collection.  Build success is not claimed.

## Not claimed

This does not claim full browser click-proof.  It also does not claim
that every historical FAQ answer is perfectly translated.  The fixed
scope is the active FAQ UI shell and visible FAQ control labels.
