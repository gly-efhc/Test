# Inventory report

Cycle: v149_66

## Schemas
- SSOT schemas: efhc_admin, efhc_core

## Tables
- SSOT_TABLES_ORM rows: 38

## Routes
- SSOT_ROUTE_TABLE_MAP rows: 91
- NO_DB routes: 5
- NEED_TRACE routes: 0
- empty evidence_refs: 0

## Notes
- NO_DB routes are OK with empty tables.
- evidence_refs must be present for NO_DB.
