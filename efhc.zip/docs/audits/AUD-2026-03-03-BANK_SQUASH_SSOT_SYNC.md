### BANK_EFHC SSOT sync

- Removed legacy tables: efhc_core.bank_state, efhc_core.admin_bank_config, efhc_admin.bank_balances.
- Added central bank table: efhc_core.bank_balance.
- SSOT_TABLES_ORM.csv count now matches Base.metadata.
