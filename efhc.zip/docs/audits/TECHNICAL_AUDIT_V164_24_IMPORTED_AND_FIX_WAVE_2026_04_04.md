# Technical audit import and fix wave for EFHC Bot v164_24

> Status note (2026-04-04 later wave): this import/fix wave remains historical for `v164_24`; current backend hard-fix continuation is tracked in `POST_FIX_AUDIT_V164_25_IMPORT_AND_HARD_FIX_WAVE_2026_04_04.md`.


Date: 2026-04-04

## Source
This audit wave imports and validates the uploaded PDF audit for
`EFHC Bot v164_24`.

## Verified critical findings
The following findings from the imported audit were re-checked against the
archive code and confirmed as real defects before patching:

- EFHC-AUD-001 — `config_core` and `database_core` contract drift.
- EFHC-AUD-002 — `hub_routes` imported missing DB/session/decimal/shop APIs.
- EFHC-AUD-003 — legacy `wallet_models` module path missing.
- EFHC-AUD-004 — `PanelArchive` model missing.
- EFHC-AUD-005 — `RanksUserSnapshot` model missing.
- EFHC-AUD-006 — `TonInboxLog` imported from wrong model module.
- EFHC-AUD-007 — `nft_requests_service` module missing.
- EFHC-AUD-008..010 — scheduler DB/session/model aliases missing.
- EFHC-AUD-011 — `check_ton_inbox.run_once` missing.
- EFHC-AUD-012 — missing scheduler settings compatibility fields.
- EFHC-AUD-013 — `get_admin_bank_config` missing in admin CRUD.

## Patch wave
The archive was updated with a compatibility fix wave to restore importability
and bootstrap safety without re-expanding the MVP contour.

### Added or restored
- `backend/app/core/decimal_utils.py`
- `backend/app/models/wallet_models.py`
- `backend/app/services/nft_requests_service.py`

### Patched compatibility surfaces
- `backend/app/core/config_core.py`
- `backend/app/core/database_core.py`
- `backend/app/models/panels_models.py`
- `backend/app/models/ranks_models.py`
- `backend/app/models/transactions_models.py`
- `backend/app/services/shop_service.py`
- `backend/app/scheduler/check_ton_inbox.py`
- `backend/app/crud/admin/admin_crud.py`

## Validation performed
- Direct source verification of the PDF findings.
- `py_compile` on all patched Python files.

## Honesty boundary
This wave fixes the confirmed archive defects from the imported PDF audit.
It does not claim a brand-new full CI proof from this local environment.
