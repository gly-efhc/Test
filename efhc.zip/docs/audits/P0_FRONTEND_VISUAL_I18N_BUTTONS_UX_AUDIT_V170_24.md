# P0 Frontend Visual / I18N / Buttons / UX Audit — EFHC Bot v170.24

**Архив:** `EFHC_Bot_v170_24_cycle_1448_linkage_minor_findings_repair.zip`  
**Режим:** VISUAL / FRONTEND AUDIT-ONLY  
**Запреты режима:** код не исправлялся, бизнес-логика не менялась, экономика не менялась, backend contracts не менялись, тесты не удалялись, CI/workflows/lock files не менялись.

---

## 1. Verdict

**Статус:** `VISUAL_SAFE_NO_P0_FOUND`

По статическому визуальному/frontend-аудиту архива **не подтверждён P0-разрыв** в базовой связке:

```text
UI button → handler → API seam → backend route
```

для ключевых денежных пользовательских flow.

Архивный linkage-слой v170.24 указывает:

- `status: ok`
- `blockers: []`
- `critical_ui_state_missing: []`
- `missing_frontend_backend: []`
- `missing_frontend_openapi: []`
- `frontend_api_call_count: 83`
- `openapi_operation_count: 121`

Критические публичные маршруты не выглядят как fake UI: в ключевых местах есть реальные вызовы к backend/API, а не декоративные кнопки. Примеры:

- `/panels/activate`
- `/exchange/convert`
- `/tasks/claim`
- `/withdraw/request`
- `/shopfront/create-intent`
- `/hub/efhc-handoff`

При этом найден **серьёзный P1-кластер**, который нельзя считать косметикой. Он не блокирует release как P0 money-route failure, но снижает доверие к продукту, ухудшает человеко-понятность и делает часть UI визуально/семантически технической.

### Сводка серьёзности

| Severity | Count |
|---|---:|
| P0 | 0 |
| P1 | 8 |
| P2 | 2 |
| P3 | 0 |

### Общий вывод

EFHC Bot v170.24 технически выглядит значительно собраннее по связям frontend/backend, но визуально и UX-семантически ещё не готов как доверительный финансово-энергетический продукт без дополнительного polish/pass. Главные проблемы не в том, что кнопки отсутствуют, а в том, что часть интерфейса показывает пользователю или оператору технические статусы, raw enum/reason, смешанные языки и некорректные пользовательские обещания.

---

## 2. Scope

### Проверенные документы и источники архива

- `map_element.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/SSOT/EFHC_CANON.md`
- `docs/SSOT/HUB_SSOT.md`
- `docs/SSOT/LANGUAGE_CANON_SSOT.md`
- `docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md`
- `docs/SSOT/ONE_PROFILE_ROLE_MATRIX_SSOT.md`
- `docs/frontend/FRONTEND_PAGE_SOURCE_MAP.md`
- `docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md`
- `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`
- `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`
- `reports/generated/full_linkage_report_v170_24.json`
- `reports/generated/frontend_visible_functions_inventory_1209.json`
- `ops/operator_kernel/cache/file_map.json`
- `frontend/package.json`

### Проверенные frontend зоны

- `frontend/src/pages/`
- `frontend/src/components/`
- `frontend/src/features/`
- `frontend/src/lib/api/`
- `frontend/src/lib/i18n.ts`
- `frontend/src/pages/admin/`
- `frontend/public/`
- `reports/generated/`
- `reports/screenshots/public_ui/`

### Проверенное покрытие

| Metric | Result |
|---|---:|
| Public screens по inventory | 14 |
| Admin screens по inventory | 15 |
| Button-like interactive entries по inventory | 182 |
| Активные языки i18n | 13 |
| Целевые viewport-профили | 10 |
| Подтверждённый runtime screenshot bundle | Нет |

### Активные языки

В `frontend/src/lib/i18n.ts` явно зафиксированы 13 активных языков:

```text
ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw
```

Главная i18n-проблема не выглядит как массовое отсутствие locale-файлов. Главная проблема — **обход i18n-слоя** через raw строки, raw enum/status/reason и смешанный RU/EN runtime text.

---

## 3. Screen coverage table

| Screen | Route | Components | Buttons/API calls | Locales | Visual status | Functional status | Tests status |
|---|---|---|---|---|---|---|---|
| Energy | `/` | `Layout → index.tsx → LiveEnergyBlock → PublicEnergyInteractiveOverview` | Panels/Exchange links | 13 | `VISUAL_OK` | `FUNCTIONAL_OK` | Нужен screenshot smoke |
| Panels | `/panels` | `PanelsPage → GameHero/GameDetails → PublicPanelsActivationPreview` | Activation wired | 13 | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен countdown test |
| Exchange | `/exchange` | `ExchangePage → PublicExchangeInteractivePreview → ExchangePanel` | Convert wired | 13 | `VISUAL_OK` | `FUNCTIONAL_OK` | Нужен wording regression |
| Tasks | `/tasks` | `TasksPage → task cards → modal` | Claim/watch-ad wired | 13 | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен no-raw-status test |
| Referrals | `/referrals` | `ReferralsPage → ReferralListPage` | Copy/share/child routes wired | 13 | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | `FUNCTIONAL_OK` | Нужен long username test |
| Ranks | `/ranks` | `RanksPage → RankRow` | Filters/loadMore/findMe wired | 13 | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен no browser-player test |
| Web Profile | `/web-profile` | `WebProfilePage → ProfileWalletSection/ProfileHistorySection` | Wallet/history/FAQ tabs wired | 13 | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен reason humanization test |
| Withdraw | `/withdraw` | `WithdrawPage` | Create/cancel/list/detail wired | 13 | `VISUAL_BROKEN` | `FUNCTIONAL_RISK_P1` | Нужны history/outcome/return tests |
| FAQ | `/faq` | `FaqPage → FaqVerticalTree` | Search/tree | 13 | `VISUAL_OK` | `FUNCTIONAL_OK` | Нужен vertical-tree guard |
| HUB | `/hub` | `HubPage` | Two canonical actions | 13 | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | `FUNCTIONAL_OK` | Нужен canonical buttons test |
| Browser Shop | `/browser-shop` | `BrowserShopPage → GameProductCard` | Catalog/create-intent/status wired | 13 | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | `FUNCTIONAL_OK` | Нужен purchase visual flow smoke |
| Admin Withdrawals | `/admin/withdrawals` | operator list/detail/preview | Routes present | RU-first expected | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен human-readable status test |
| Admin Shop | `/admin/shop` | catalog/editor/bulk/delete | Routes present | RU-first expected | `VISUAL_NEEDS_POLISH` | `FUNCTIONAL_RISK_P1` | Нужен Russian-only runtime test |
| Admin Hub / Users / Bank / Reports / Panels / Tasks | `/admin/*` | operator surfaces | No confirmed P0 fake buttons | RU-first expected | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | `FUNCTIONAL_OK_WITH_SPOT_CHECK_LIMITS` | Нужен admin smoke suite |

---

## 4. Button/action coverage table

| Screen | Button/action | Handler/API route | Expected result | Actual result | Problem | Severity |
|---|---|---|---|---|---|---|
| Panels | Activate panel | `/panels/activate` | Активировать панель за 100 EFHC с понятным состоянием | Кнопка не fake, API есть | Countdown рядом с панелями считает время неверно | P1 |
| Exchange | Convert kWh → EFHC | `/exchange/convert` | Обмен строго 1:1 | Связка выглядит корректной | P0/P1 по кнопке не найден | Non-finding |
| Tasks | Claim reward | `/tasks/claim` | Понятное состояние claim/reward | API есть | Статусы могут отображаться raw enum | P1 |
| Referrals | Copy referral link | Clipboard/share | Скопировать ссылку | Кнопка выглядит провязанной | Нужен regression на длинные username/link | P2 risk |
| Ranks | Find me / filters | local/backend load | Найти пользователя в рейтинге | Работает по коду | Fallback `browser-player` запрещён каноном | P1 |
| Withdraw | Create withdraw | `/withdraw/request` | Создать заявку и показать понятный next step | API есть | После создания flow возвращает на `/`, не в Money-Center/history | P1 |
| Withdraw | Cancel withdraw | `/withdraw/{id}/cancel` | Отмена заявки с понятным статусом | API есть | История/исход могут быть raw | P1 |
| Shop | Buy/create intent | `/shopfront/create-intent` | Создать intent покупки | API есть | Нужен visual smoke по order/payment state | P2 risk |
| HUB | Пополнить EFHC | `/hub/efhc-handoff` / deposit handoff | Открыть пополнение | Связка есть | Нет P0 | Non-finding |
| HUB | EFHC VIP NFT | external/canonical CTA | Открыть VIP NFT | Связка есть | Нет P0 | Non-finding |
| Admin Shop | Archive/Delete | admin shop routes | Оператор понимает действие | Функционально провязано | Runtime labels `Archive`, `Delete`, `bulk`, `delete queue` | P1 |
| Admin Withdrawals | Preview/action status | admin withdraw routes | Русские понятные статусы | API есть | Raw/mixed status/outcome text | P1 |

---

## 5. I18N coverage table

| Locale | Keys total | Missing keys | Overflow risks | Mixed language | Critical issues |
|---|---:|---:|---|---|---|
| ru | Не пересчитывалось вручную | Нет массового collapse | Withdraw/Admin/Tasks | Да, есть English fragments в admin/public | Raw status/reason |
| en | Не пересчитывалось вручную | Нет массового collapse | Long labels | Возможны raw backend enums | Raw status/reason |
| uk | Не пересчитывалось вручную | Нет массового collapse | Long labels | Возможны raw backend enums | Raw status/reason |
| de | Не пересчитывалось вручную | Нет массового collapse | Высокий риск длинных строк | Возможны raw backend enums | Нужен layout smoke |
| fr | Не пересчитывалось вручную | Нет массового collapse | Высокий риск длинных строк | Возможны raw backend enums | Нужен layout smoke |
| es | Не пересчитывалось вручную | Нет массового collapse | Высокий риск длинных строк | Возможны raw backend enums | Нужен layout smoke |
| it | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |
| tr | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |
| pl | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |
| da | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |
| hi | Не пересчитывалось вручную | Нет массового collapse | Font/wrap risk | Возможны raw backend enums | Нужен screenshot smoke |
| id | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |
| sw | Не пересчитывалось вручную | Нет массового collapse | Средний риск | Возможны raw backend enums | Нужен layout smoke |

### Критический i18n-вывод

Главная проблема: **часть runtime UI не переводит значения, а печатает исходные коды**.

Особо опасные raw/mixed значения:

- `not_started`
- `approved`
- `auto_paid`
- `pending_check`
- `task_bonus:*`
- `main`
- `bonus`
- `bulk`
- `delete queue`
- `Archive`
- `Delete`
- `browser-player`
- `Request #...`

---

## 6. Text overflow / responsive audit

Целевые viewport размеры по задаче:

1. `320×568`
2. `360×640`
3. `375×667`
4. `390×844`
5. `414×896`
6. `430×932`
7. `768×1024`
8. `1024×768`
9. `1366×768`
10. `1920×1080`

### Ограничение проверки

В архиве не найден полноценный runtime screenshot bundle. В `reports/screenshots/public_ui/` лежит только `.gitkeep`, при наличии документации screenshot harness. Поэтому responsive-аудит является **static/layout risk audit**, а не доказанным browser screenshot proof.

### Риски переполнений

| Screen | Locale | Viewport | Problem | Evidence | Severity | Repair direction |
|---|---|---|---|---|---|---|
| Withdraw | all/de/fr/es | 320–430 mobile | Длинные history/status/outcome строки | `frontend/src/pages/withdraw.tsx` | P1/P2 | Human labels + wrap/truncate rules |
| Tasks | all | 320–430 mobile | Raw enum/status + длинные task titles | `frontend/src/pages/tasks.tsx` | P1 | Status map + card layout smoke |
| Referrals | all | 320–430 mobile | Long username/referral link risk | `frontend/src/components/referrals/ReferralListPage.tsx` | P2 | Username truncation, copy row test |
| FAQ | de/fr/es/hi/sw | 320–430 mobile | Длинные ответы могут ломать дерево | `frontend/src/components/faq/FaqVerticalTree.tsx` | P2 | Screenshot + max-width/wrap tests |
| Admin Shop | RU/operator | desktop/mobile | Bulk/delete/action rows могут ломаться | `frontend/src/pages/admin/shop.tsx` | P1 | Operator layout pass |
| Admin Withdrawals | RU/operator | desktop/mobile | request/user/wallet/status summaries | `frontend/src/pages/admin/withdrawals.tsx` | P1 | Human readable summary + table wrapping |

---

## 7. Visual quality audit

| Screen | Human quality rating | Main visual problem | Recommended improvement |
|---|---|---|---|
| Energy | `VISUAL_OK` | Нужны runtime screenshots | Закрепить smoke по 13 языкам |
| Panels | `VISUAL_NEEDS_POLISH` | Countdown математически неверен | Исправить форматтер и визуально усилить срок панели |
| Exchange | `VISUAL_OK` | Требуется guard wording | Закрепить 1:1 wording тестами |
| Tasks | `VISUAL_NEEDS_POLISH` | Raw statuses | Сделать status chips человеческими |
| Referrals | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | Long username/link risk | Truncate/copy UX polish |
| Ranks | `VISUAL_NEEDS_POLISH` | `browser-player` fallback | Убрать запрещённый fallback |
| Web Profile | `VISUAL_NEEDS_POLISH` | Raw reason risk in history | Единый normalizer истории |
| Withdraw | `VISUAL_BROKEN` | Raw history/outcome + wrong return target | Пересобрать человеко-понятную историю и возврат |
| FAQ | `VISUAL_OK` | Нужен screenshot proof | Vertical-tree regression |
| HUB | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | Нужен guard only canonical two actions | Hub canonical buttons test |
| Browser Shop | `VISUAL_ACCEPTABLE_WITH_MINOR_ISSUES` | Нужен visual purchase smoke | Зафиксировать order/payment states |
| Admin Shop | `VISUAL_NEEDS_POLISH` | Mixed RU/EN operator UI | Russian-first pass |
| Admin Withdrawals | `VISUAL_NEEDS_POLISH` | Raw statuses/outcome | Operator human labels |

---

## 8. Document/UI consistency audit

| UI area | Document source | Expected | Actual | Drift | Severity |
|---|---|---|---|---|---|
| Panels countdown | Frontend matrix / panels canon | 180-day lifetime displayed correctly | Countdown formatter uses wrong divisors | Да | P1 |
| Tasks statuses | UX/i18n/admin canon | Human-readable public statuses | Raw backend enums can leak | Да | P1 |
| Ranks fallback | Frontend screen registry / forbidden branch | No `browser-player` in runtime | `browser-player` fallback exists | Да | P1 |
| Withdraw return | One Profile role matrix | Return to account/history center | Pushes `/` | Да | P1 |
| Admin operator language | Language canon | Russian-first admin runtime | Mixed RU/EN labels | Да | P1 |
| Energy route docs | Frontend screen registry | Docs match actual routes | `/energy` still documented, page absent | Да | P2 |
| Screenshot proof | Public screenshot harness | Real screenshot bundle | only `.gitkeep` | Да | P2 |

---

## 9. Confirmed findings

### F-01 — P1 — Сломана математика countdown на Panels

**Files:** `frontend/src/pages/panels.tsx:72-88`  
**Surface:** `/panels`  
**Evidence:** форматтер оставшегося времени использует неправильные делители (`86`, `3`, `60`) вместо нормальной секундной математики (`86400`, `3600`, `60`).  
**User impact:** пользователь видит неверное оставшееся время жизни панели; визуально и доверительно ломается 180-day logic.  
**Repair direction:** изолированно исправить formatter countdown без изменения экономики, backend и срока панели.  
**Required test:** `test_panels_countdown_math_uses_86400_3600_60`.

### F-02 — P1 — Tasks показывает raw enum/status

**Files:** `frontend/src/pages/tasks.tsx:139-151`, `backend/app/services/tasks_service.py:1359-1395`  
**Surface:** `/tasks`  
**Evidence:** frontend возвращает `status` как есть; backend отдаёт состояния вроде `not_started`, `approved`, `auto_paid`, `pending_check`.  
**User impact:** человек видит технические статусы вместо понятных состояний задания.  
**Repair direction:** сделать полный status-map для public task states во всех 13 языках.  
**Required test:** `test_tasks_public_status_labels_no_raw_enum`.

### F-03 — P1 — В Ranks остался запрещённый fallback `browser-player`

**Files:** `frontend/src/pages/ranks.tsx:120-125`  
**Surface:** `/ranks`  
**Evidence:** browser fallback `browser-player` существует в runtime code, при том что канон запрещает такой fallback.  
**User impact:** browser user получает техническую/чужую метку вместо нормального имени.  
**Repair direction:** заменить на канонический user-facing label из i18n.  
**Required test:** `test_ranks_no_browser_player_fallback`.

### F-04 — P1 — Web Profile history пропускает raw reason-коды

**Files:** `frontend/src/features/profile/WebProfilePage.tsx:109-130`, `backend/app/services/tasks_service.py:751-757`  
**Surface:** `/web-profile` history  
**Evidence:** `reasonLabel` знает узкий список reasons; backend может писать `task_bonus:{task_code}` и другие pattern-based reasons.  
**User impact:** история баланса может показывать технические причины вместо человеческого описания операции.  
**Repair direction:** вынести единый reason-normalizer и покрыть pattern reasons.  
**Required test:** `test_balance_history_reason_humanization`.

### F-05 — P1 — Withdraw показывает raw reason, raw balance type и raw outcome

**Files:** `frontend/src/pages/withdraw.tsx:140-145`, `483-525`, `805-847`  
**Surface:** `/withdraw`  
**Evidence:** history/outcome/summary sections могут выводить исходные reason, balance_type, outcome_kind и nonlocalized fragments.  
**User impact:** экран вывода выглядит как техническая лента, а не как финансовый продукт.  
**Repair direction:** нормализовать `status`, `outcome_kind`, `reason`, `balance_type`; убрать `Request #` и raw text.  
**Required test:** `test_withdraw_history_and_outcome_labels_human_readable`.

### F-06 — P1 — `Вернуться в Money-Center` ведёт не туда, куда обещает

**Files:** `frontend/src/pages/withdraw.tsx:227-238`, `240-275`  
**Surface:** `/withdraw`  
**Evidence:** сохраняется `EFHC_RETURN_PROFILE_SECTION`, но ключ далее не используется; фактический переход идёт на `/`.  
**User impact:** после создания заявки пользователь попадает на Energy, а не в history/account center, что ломает ожидание flow.  
**Repair direction:** перенаправлять в канонический history/account center, предпочтительно `/web-profile?section=history`.  
**Required test:** `test_withdraw_return_goes_to_web_profile_history`.

### F-07 — P1 — Admin Shop смешивает RU/EN в operator runtime

**Files:** `frontend/src/pages/admin/shop.tsx:825-840`, `1060-1077`  
**Surface:** `/admin/shop`  
**Evidence:** runtime labels: `bulk`, `delete queue`, `Archive`, `Delete`, `facts`.  
**User impact:** оператор получает полу-технический, полу-английский интерфейс; выше риск неверного действия.  
**Repair direction:** полная русификация runtime labels и action semantics без изменения backend routes.  
**Required test:** `test_admin_shop_russian_only_runtime_labels`.

### F-08 — P1 — Admin Withdrawals показывает raw statuses/outcome_kind

**Files:** `frontend/src/pages/admin/withdrawals.tsx:397-406`, `421-423`, `523-526`, `623-624`  
**Surface:** `/admin/withdrawals`  
**Evidence:** видны `PENDING/PAID`, `success`, `request #`, `user`, `wallet`, `status`.  
**User impact:** оператору показываются технические summary strings вместо нормального операторского языка.  
**Repair direction:** ввести русские operator label maps и human-readable preview text.  
**Required test:** `test_admin_withdrawals_statuses_human_readable`.

### F-09 — P2 — Drift по route alias `/energy`

**Files/docs:** `docs/frontend/FRONTEND_PAGE_ELEMENT_MATRIX.md`, `docs/frontend/FRONTEND_SCREEN_REGISTRY.md`, `frontend/src/pages/index.tsx`  
**Surface:** docs vs actual routes  
**Evidence:** docs продолжают перечислять `/energy`, но route/page file отсутствует.  
**User impact:** следующий агент может искать/чинить несуществующий route.  
**Repair direction:** либо вернуть alias `/energy`, либо убрать его из активных route docs.  
**Required test:** `test_energy_route_docs_match_actual_routes`.

### F-10 — P2 — Нет runtime screenshot proof для visual QA

**Files/docs:** `reports/screenshots/public_ui/.gitkeep`, `docs/frontend/PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md`  
**Surface:** whole frontend  
**Evidence:** screenshot harness описан, но фактических снимков нет.  
**User impact:** нельзя доказательно закрыть overflow/overlap/safe-area по 10 viewport и 13 языкам.  
**Repair direction:** добавить реальный screenshot manifest и regression bundle.  
**Required test:** `test_visual_routes_smoke_all_languages`.

---

## 10. Non-findings

Проверено и признано безопасным в рамках статического аудита:

1. **Exchange** сохраняет канон `1 kWh = 1 EFHC`; P0/P1 drift по самой exchange-кнопке не подтверждён.
2. **Panels activation** не выглядит как fake UI: есть handler/API seam/idempotency/confirm.
3. **Referrals** в user-facing списках используют username вместо global_id.
4. **FAQ** построен как vertical tree, без подтверждённого horizontal pills/grid drift.
5. **HUB** сохраняет две ключевые public action cards и не превращён в лишнюю сетку действий.
6. **DepositModal** соответствует текущей модели thin launcher, а не full in-app payment center.
7. **Linkage report v170.24** не показывает P0-разрыв frontend/backend/openapi по основным routes.

---

## 11. Missing tests

Обязательные тесты перед production:

1. `test_panels_countdown_math_uses_86400_3600_60`
2. `test_tasks_public_status_labels_no_raw_enum`
3. `test_balance_history_reason_humanization`
4. `test_withdraw_history_and_outcome_labels_human_readable`
5. `test_withdraw_return_goes_to_web_profile_history`
6. `test_ranks_no_browser_player_fallback`
7. `test_admin_shop_russian_only_runtime_labels`
8. `test_admin_withdrawals_statuses_human_readable`
9. `test_all_visible_buttons_have_handlers`
10. `test_all_frontend_api_calls_have_backend_routes`
11. `test_no_dead_buttons_on_user_screens`
12. `test_no_dead_buttons_on_admin_screens`
13. `test_all_locales_have_same_translation_keys`
14. `test_no_missing_translation_keys_rendered`
15. `test_no_undefined_null_object_object_in_ui`
16. `test_no_debug_json_in_runtime_ui`
17. `test_no_internal_helper_text_in_runtime_ui`
18. `test_no_forbidden_words_in_runtime_ui`
19. `test_mobile_320_no_horizontal_scroll`
20. `test_mobile_390_no_text_overflow`
21. `test_all_main_screens_have_loading_empty_error_states`
22. `test_faq_vertical_tree_only`
23. `test_hub_has_only_canonical_primary_buttons`
24. `test_exchange_kwh_efhc_wording_consistent`
25. `test_withdraw_bonus_not_displayed_as_withdrawable`
26. `test_admin_tables_do_not_overflow_desktop`
27. `test_wallet_address_truncation`
28. `test_long_username_layout`
29. `test_long_translation_layout_de_fr_es`
30. `test_status_labels_are_human_readable`
31. `test_modals_close_correctly`
32. `test_double_click_money_buttons_disabled`
33. `test_visual_routes_smoke_all_languages`

---

## 12. Human improvement list

### 1. Исправить countdown панели

**Почему важно человеку:** срок панели — доверительный элемент. Если он выглядит неверно, пользователь сомневается во всём продукте.  
**Где применить:** `/panels`, карточки активных/архивных панелей.  
**Как проверить:** unit test + screenshot активной панели.

### 2. Убрать все raw enum/status/reason

**Почему важно человеку:** `approved`, `auto_paid`, `task_bonus:*` выглядят как ошибка разработки.  
**Где применить:** Tasks, Withdraw, Web Profile, Admin Withdrawals.  
**Как проверить:** no raw enum/status test.

### 3. Сделать Withdraw похожим на финансовый экран

**Почему важно человеку:** вывод средств — зона максимального доверия.  
**Где применить:** `/withdraw`, история заявок, success/error/outcome.  
**Как проверить:** create/cancel/list/detail flow + screenshot.

### 4. Вернуть пользователя в настоящий Money-Center

**Почему важно человеку:** после заявки человек ожидает видеть историю/статус, а не главный экран Energy.  
**Где применить:** после `createWithdraw()`, кнопка `Вернуться в Money-Center`.  
**Как проверить:** route assertion на `/web-profile?section=history`.

### 5. Довести admin до русского операторского продукта

**Почему важно человеку:** оператор должен понимать действие мгновенно, без английских технических слов.  
**Где применить:** Admin Shop, Admin Withdrawals, action previews.  
**Как проверить:** Russian-only runtime labels test.

### 6. Добавить screenshot доказательства

**Почему важно человеку:** нельзя уверенно говорить, что UI красивый и не ломается, без реальных снимков на малых экранах.  
**Где применить:** 10 viewport × ключевые public/admin screens × 13 языков минимум smoke.  
**Как проверить:** screenshot manifest + visual regression.

### 7. Провести единый beauty-pass

**Почему важно человеку:** EFHC должен выглядеть как аккуратный энергетическо-финансовый продукт, а не как техническая заготовка.  
**Где применить:** Panels, Withdraw, Tasks, Admin Shop, Admin Withdrawals.  
**Как проверить:** единые карточки, кнопки, статусы, empty/error/success states.

---

## 13. Repair plan

### Cycle A — P0 dead buttons / broken routes

P0 не подтверждён, но перед любым visual repair нужен recheck ключевых CTA:

- `/panels/activate`
- `/exchange/convert`
- `/tasks/claim`
- `/withdraw/request`
- `/withdraw/{id}/cancel`
- `/shopfront/create-intent`
- `/hub/efhc-handoff`

Цель: гарантировать, что после визуальных правок не появится fake UI или broken route.

### Cycle B — I18N missing keys / mixed language

Фокус:

- Tasks status map
- Web Profile history reason normalizer
- Withdraw history/outcome labels
- Admin Shop runtime labels
- Admin Withdrawals operator labels
- Ranks browser fallback

Цель: убрать bypassed i18n и raw strings.

### Cycle C — text overflow / responsive fixes

Фокус:

- Withdraw cards
- Tasks cards
- Referral link/username
- FAQ long answers
- Admin Shop bulk/delete rows
- Admin Withdrawals tables/summaries

Цель: закрыть 10 viewport и длинные языки.

### Cycle D — loading / empty / error / success states

Фокус:

- money buttons
- task claim states
- withdraw request states
- shop order/payment states
- admin mutation states

Цель: каждый важный action имеет loading/success/error/disabled.

### Cycle E — admin operator UX

Фокус:

- Admin Shop
- Admin Withdrawals
- Admin dangerous actions
- human status labels
- confirmations

Цель: оператор понимает каждое действие без технической догадки.

### Cycle F — visual polish / beauty pass

Фокус:

- spacing
- typography
- card hierarchy
- button consistency
- status chips
- empty/error/success style

Цель: интерфейс выглядит как продукт, а не как промежуточный технический экран.

### Cycle G — screenshot and regression tests

Фокус:

- 10 viewport
- 13 языков
- public screens
- admin screens
- Telegram WebApp safe area
- browser/PWA mode

Цель: доказательно закрыть visual QA перед production.

---

## 14. Questions for user

### Q1. Route `/energy`

**Проблема:** документы ещё упоминают `/energy`, но фактический экран Energy находится на `/`.  
**Почему нужен ответ:** иначе следующий агент может либо вернуть лишний alias, либо удалить нужный docs route.  
**Варианты:**

1. Вернуть alias `/energy` как совместимый путь.
2. Удалить `/energy` из активных документов и оставить только `/`.

**Рекомендация аудитора:** оставить только `/`, если отдельный alias не нужен для старых ссылок.

### Q2. Куда возвращать после Withdraw?

**Проблема:** UI обещает Money-Center, но фактически отправляет на `/`.  
**Почему нужен ответ:** надо выбрать канонический target.  
**Варианты:**

1. `/web-profile?section=history`
2. `/web-profile?section=wallet`
3. будущий отдельный Money-Center route

**Рекомендация аудитора:** `/web-profile?section=history`.

### Q3. Допустим ли английский в admin runtime?

**Проблема:** Admin Shop и Admin Withdrawals содержат runtime English labels.  
**Почему нужен ответ:** можно оставить технический operator jargon или сделать полностью русский слой.  
**Варианты:**

1. Полностью русский admin runtime.
2. Русский UI, но оставить технические enum в diagnostics-only.
3. Разрешить English jargon в operator UI.

**Рекомендация аудитора:** полностью русский admin runtime; технические enum — только diagnostics/internal.

---

## Final audit summary

1. **Verdict:** `VISUAL_SAFE_NO_P0_FOUND`.
2. **Проверено экранов:** 14 public + 15 admin по inventory.
3. **Проверено кнопок/interactive entries:** 182 по inventory.
4. **Проверено языков:** 13 активных языков.
5. **Viewport target:** 10 размеров; runtime screenshot proof отсутствует.
6. **Найдено:** P0=0, P1=8, P2=2, P3=0.
7. **Самые опасные проблемы:** Panels countdown, raw enum/status/reason, wrong withdraw return target, mixed RU/EN admin UI.
8. **Хуже всего для обычного человека:** Withdraw, Panels, Tasks, Ranks fallback.
9. **Хуже всего для оператора:** Admin Shop, Admin Withdrawals.
10. **Обязательные тесты:** countdown, no raw status, withdraw return, admin Russian-only, screenshot smoke.
11. **Циклов ремонта:** 7.
12. **Главный продуктовый вывод:** release не заблокирован P0, но перед production нужно закрыть P1-кластер, иначе EFHC Bot будет выглядеть технически рабочим, но недостаточно доверительным и дорогим для обычного пользователя.
