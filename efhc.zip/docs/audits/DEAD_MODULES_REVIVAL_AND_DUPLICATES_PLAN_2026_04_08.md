# DEAD MODULES REVIVAL AND DUPLICATES PLAN — 2026-04-08

## Правило пользователя

Найденные по смысловому аудиту мёртвые файлы и модули не удаляются.
Они считаются нужными и переводятся в план подключения/исправления.

Если найдены дубли:
1. сначала сравнить и перенести полезные данные;
2. показать пользователю дубль и предложение;
3. удалять только после согласования.

## Кандидаты на реанимацию / подключение

### Frontend
- `frontend/src/components/AdminCharts.tsx`
- `frontend/src/components/AdminTable.tsx`
- `frontend/src/components/AdsBanner.tsx`
- `frontend/src/components/ExchangePanel.tsx`
- `frontend/src/components/RanksTable.tsx`
- `frontend/src/components/ReferralsTabs.tsx`

### Backend
- `backend/app/services/efhc_deposits_service.py`
- `backend/app/services/orders_service.py`
- `backend/app/services/admin/admin_tasks_service.py`

## Кандидаты на дубли / overlap-зоны (пока не удалять)

### 1. Shop service overlap
- `backend/app/services/orders_service.py`
- `backend/app/services/shop_service.py`
- `backend/app/services/watcher_service.py`
- `backend/app/services/payment_intents_service.py`

Наблюдение:
`orders_service.py` выглядит как старый самостоятельный shop/order слой,
а активный runtime сейчас уже распределён по `shop_service`, watcher и
payment intents.

### 2. Exchange UI overlap
- `frontend/src/components/ExchangePanel.tsx`
- `frontend/src/pages/exchange.tsx`

Наблюдение:
есть отдельный готовый компонент exchange-panel и отдельная page-layer
реализация. Нужно решить, панель встраивается в page, либо остаётся как
shared component.

### 3. Referrals UI overlap
- `frontend/src/components/ReferralsTabs.tsx`
- `frontend/src/pages/referrals.tsx`
- `frontend/src/pages/referrals/active.tsx`
- `frontend/src/pages/referrals/inactive.tsx`

Наблюдение:
`ReferralsTabs.tsx` выглядит как thin wrapper на уже существующие страницы.
Нужно решить: использовать его как navigation shell или оставить страницы
без него.

## Порядок следующих циклов

- 466 — frontend resurrection wave 01: `ExchangePanel`, `ReferralsTabs`.
- 467 — frontend resurrection wave 02: `AdminCharts`, `AdminTable`,
  `AdsBanner`, `RanksTable`.
- 468 — backend resurrection wave 01: `admin_tasks_service`,
  `efhc_deposits_service`.
- 469 — backend overlap audit: `orders_service` vs active shop runtime,
  с переносом полезной логики и предложением по дублю на согласование.
- 470 — final re-audit of the revival wave and duplicate decision pack.
