# ADMIN SHOP EDITOR WAVE 661-670 — 2026-04-08

## Completed
1. Admin shop now loads storefront catalog and supports search/filter selection.
2. Product-card editor shell added for EFHC package cards.
3. TON and USDT price fields added together and separately.
4. Visibility control added.
5. Neutral image URL field and card preview added.
6. Browser shop now displays dual-price cards and optional quick package filters.

## Honest limitation
Current backend route persists prices and visibility. Title / description / image fields are currently preview-stage fields for the next editor step.
