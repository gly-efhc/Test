# Cycle 1090 — transition alias bridge

Добавлен переходный слой `bonus_efhc` в task routes и связанных
ответах. Старый `reward_efhc` сохранён до полного прохождения циклов.
