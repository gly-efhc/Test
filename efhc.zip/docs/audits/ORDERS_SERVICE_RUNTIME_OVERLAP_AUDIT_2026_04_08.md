# Orders service runtime overlap audit — 2026-04-08

## Scope
This audit confirms that `backend/app/services/orders_service.py` remains in an
overlap zone with the active shop runtime. It must not be deleted without a
compare-and-transfer pass.

## Active runtime today
- `shop_service.py`
- `watcher_service.py`
- `payment_intents_service.py`

## Overlap concern
`orders_service.py` still represents an order-domain slice, but the currently
active purchase and payment confirmation flow is spread across the active shop
runtime listed above.

## Required next step
Prepare a field-by-field transfer proposal that shows:
1. what data/model assumptions still live in `orders_service.py`;
2. what is already covered by the active shop runtime;
3. what must be moved before any future deletion proposal can even be shown.
