# FRONTEND 10 TO 99 ROADMAP V168_35

Status: planning and audit pass after archive merge.
HEAD: EFHC_Bot_v168_34_cycles_1219_1225_archive_merge.zip.

## Verdict

The user-visible frontend is still about 10 percent ready as a product.
The codebase has stronger technical infrastructure than the visible
product suggests, but infrastructure is not the same as a finished
WebApp/PWA game interface.

Current strength is survival infrastructure:

- canonical routes exist;
- browser fallback without Telegram tg_id exists;
- dark first paint exists;
- PWA manifest and service worker exist;
- targeted static guards pass locally.

Current blocker is product completeness:

- no final EFHC game visual system;
- no fully agreed visible element list in chat;
- no live browser/Docker proof in this pass;
- Profile/WebProfile still contains technical/operator language;
- page styles were patched by cycles, not rebuilt as one product
  layer;
- Dragon/Web3 references are not fully readable in this environment.

## Sandbox intake

The outer sandbox ZIP passed integrity check.
The UI reference bundle is readable and useful for cards, progress,
drawers, sheets, badges, buttons, empty states and layout patterns.
The admin refine bundle is readable and useful for future admin CRUD.
The TON HTTP reference bundle is readable.

The inner core ZIP had damaged central directory. It was partially
salvaged with `zip -FF`, but this is not full clean source proof.

The Dragon and Web3 Shop RAR files were listable only. The current
container has no working RAR backend. Their file lists still show saved
web bundles with HTML, JS, CSS, Telegram WebApp script, icons and game
or product assets, but full code extraction is not proven.

## What 99 percent means

99 percent frontend readiness means all of the following are true:

1. Energy opens first in Telegram, browser and PWA without blank
   state.
2. The app has one EFHC game shell, not page-by-page patches.
3. The six bottom buttons remain canonical and visible.
4. Each page has compact user-facing cards, no operator language.
5. Buttons give immediate feedback and never look broken.
6. Profile and Wallet are visually separated and understandable.
7. Browser-Shop is clean Web3 storefront without technical payloads.
8. Browser/PWA install works through system browser controls only.
9. Static guards, TypeScript, build, route proof and ZIP proof pass.
10. Live browser/Docker evidence is obtained or explicitly not
    claimed.

## Road to 99 percent

### Gate 0: stop the blank-screen risk

Goal: prove or repair the first visible render.

Required work:

- run TypeScript and production build if dependencies allow it;
- test direct browser route `/` with missing Telegram data;
- test `manifest.webmanifest` and `sw.js` availability;
- test Docker frontend if runtime is available;
- capture exact cause if the user still sees white screen.

Exit condition:

- Energy renders dark shell, visible progress bar and bottom menu.

### Gate 1: visible element agreement

Goal: approve what every page must show before major redesign.

Required work:

- Energy element list;
- Panels element list;
- Exchange element list;
- Tasks element list;
- Referrals element list;
- Ranks element list;
- Profile and Wallet element list;
- HUB and Browser-Shop element list;
- FAQ element list.

Exit condition:

- user approves leave / remove / move to admin / question map.

### Gate 2: EFHC visual component kit

Goal: replace visual patchwork by one reusable game UI layer.

Components to create:

- GameShell;
- GameHeader;
- BottomGameNav;
- ResourceChip;
- EnergyProgress;
- GameCard;
- ActionCard;
- StatusPill;
- CompactDrawer;
- GameEmptyState;
- GameSkeleton;
- GameToast.

Exit condition:

- all public pages use the same EFHC-branded primitives.

### Gate 3: Energy first screen

Goal: make Energy feel like the real product home.

Must show:

- total generated energy;
- visible progress bar even at zero;
- current rank/progress state without 12-level public catalogue;
- active panels summary;
- generation rate;
- EFHC balance chip;
- one or two primary actions only;
- no technical text.

Exit condition:

- first screen looks like a finished game dashboard.

### Gate 4: canonical page migration

Goal: finish each bottom-menu page without changing the menu.

Order:

1. Panels: active machine cards plus details drawer.
2. Exchange: simple converter plus history/details drawer.
3. Tasks: earning/ad cards with clear reward and status.
4. Referrals: invite card, growth progress, active/inactive lists.
5. Ranks: leaderboard cards, current user, refresh and find-me only.

Exit condition:

- every canonical page has compact, consistent game UI.

### Gate 5: Profile / Wallet / WebProfile cleanup

Goal: remove technical account-center language from public surfaces.

Required work:

- Profile remains account overview and settings;
- Wallet becomes a separate clear financial subsection;
- WebProfile stops showing contour, intent, watcher, tg_id and SKU to
  normal users;
- history becomes human timeline;
- technical state moves to Admin diagnostics only.

Exit condition:

- a normal user understands money state without reading system terms.

### Gate 6: HUB / Browser-Shop polish

Goal: make shop and top-up path feel like Web3 product, not console.

Required work:

- HUB keeps only two clean actions;
- Browser-Shop keeps product cards and Pay;
- no raw wallet, memo, token, intent, SKU or payload in public UI;
- payment states are short and human;
- wallet-open failure has one recovery action.

Exit condition:

- user can top up without seeing backend vocabulary.

### Gate 7: browser/PWA parity

Goal: same product in Telegram and browser.

Required work:

- desktop centered game frame;
- mobile Telegram-safe shell;
- browser state banner only if needed;
- PWA manifest, icons and service worker check;
- no custom fake install button;
- all pages render without global_id.

Exit condition:

- Telegram, browser and installed PWA open the same EFHC app.

### Gate 8: interaction hardening

Goal: no dead-looking controls.

Required work:

- inventory every public button;
- classify primary / secondary / hidden / admin-only;
- add immediate pending state;
- add short disabled reason;
- add compact toast;
- remove silent no-op patterns.

Exit condition:

- every visible button either works or explains one short reason.

### Gate 9: release evidence

Goal: avoid fake green.

Required proof:

- targeted pytest visual/browser guards;
- TypeScript noEmit;
- production build with real exit code;
- route smoke check;
- ZIP FLAT integrity;
- no garbage caches;
- browser screenshot/manual proof if available;
- Docker proof only if actually run.

Exit condition:

- 99 percent can be claimed only with proof list attached.

## Cycle plan

### 1226-1230: recovery and agreement

- 1226: run build/runtime audit and prove current blank-screen status;
- 1227: prepare visible element agreement table in chat;
- 1228: freeze EFHC visual token map;
- 1229: create reusable frontend component kit plan;
- 1230: corrected verdict, no release-ready claim.

### 1231-1240: visual foundation

- convert Dragon/Web3 reference into EFHC rules;
- do not copy brand or assets;
- map game cards, chips, bars and drawers;
- define desktop/mobile shell constraints.

### 1241-1260: Energy and canonical pages

- rebuild Energy as final first screen;
- migrate Panels, Exchange and Tasks;
- add consistent loading, empty and error states;
- preserve all canonical routes.

### 1261-1280: Referrals, Ranks, Profile and Wallet

- finish Referrals compact growth UI;
- finish Ranks leaderboard cards;
- split Profile and Wallet logically;
- clean WebProfile from technical public language.

### 1281-1300: HUB, Browser-Shop and buttons

- polish HUB and Browser-Shop;
- inventory all buttons;
- repair dead-looking states;
- add visible feedback and toasts.

### 1301-1325: visual polish

- align all pages to one EFHC visual grammar;
- add icon rhythm, spacing and progress consistency;
- complete FAQ compact shell;
- complete Profile/Wallet history timeline.

### 1326-1350: evidence and hardening

- run full frontend static guard pack;
- run TypeScript/build proof;
- regenerate route and call matrices;
- update NORM, SSOT and reports;
- issue final visual readiness verdict.

## Page-by-page priority

| Page | Current state | To reach 99 percent |
|---|---|---|
| Energy | Best current base | Final game home and hero polish |
| Panels | Compact repair started | Machine cards and details drawer |
| Exchange | Compact repair started | Simple converter, cleaner actions |
| Tasks | Compact earning cards started | Strong ad/reward game loop |
| Referrals | Browser fallback exists | Compact growth/invite surface |
| Ranks | Leader cards started | Final leaderboard and empty states |
| Profile | Large modal | Account overview, not kitchen sink |
| Wallet | Mixed with profile | Separate financial subsection |
| HUB | Mostly clean | Final two-card bridge polish |
| Browser-Shop | Cleaned MVP | Web3 storefront polish and proof |
| WebProfile | Too technical | Move diagnostics to Admin |
| FAQ | Compact shell exists | Final mobile readability pass |

## Important rule

Do not jump straight into random visual coding. First agree visible
page elements in chat, then implement component kit, then migrate pages.
This prevents another patchwork frontend.
