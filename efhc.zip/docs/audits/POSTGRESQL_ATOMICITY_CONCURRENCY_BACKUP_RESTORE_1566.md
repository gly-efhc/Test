# PostgreSQL atomicity, concurrency and restore proof — cycle 1566

## Scope

Cycle 1566 proves the local PostgreSQL boundary that remained partial after
cycle 1565. It does not change the database schema or economic formulas.
The active migration remains `0001` only.

The proof used a real isolated PostgreSQL 18.1 server. SQLite, mocked SQL and
in-memory transaction substitutes were not used.

## Fresh migration

A clean database named `efhc1566_proof` was created and upgraded through the
canonical Alembic entrypoint.

Verified result:

- PostgreSQL transactional DDL;
- Alembic head `0001`;
- schemas `efhc_core` and `efhc_admin` only;
- 45 tables in the two schemas, including Alembic state;
- 44 application metadata tables;
- migration command natural exit `0`.

Machine evidence:
`reports/generated/postgresql_migration_v171_42.json`.

## Business-service rollback

The proof seeded a user with `100.00000000 EFHC` and called the real
`withdraw_service.request_withdraw` path.

A controlled exception was injected after the nocommit helper had:

1. locked the user and bank rows;
2. changed the user balance;
3. changed the bank balance;
4. inserted the transfer ledger rows.

The outer service transaction then rolled back. A new session verified:

- user main balance remained `100.00000000`;
- no withdraw request survived;
- no user transfer log survived;
- no mirrored bank transfer log survived.

This proves that request creation, hold movement and ledger writes share one
real PostgreSQL transaction boundary.

Machine evidence:
`reports/generated/postgresql_transaction_proof_v171_42.json`.

## Concurrency and idempotency

Thirty-seven PostgreSQL-backed tests passed. They cover:

- two concurrent exchange attempts;
- exchange and withdraw racing on the same user;
- double withdraw approval;
- repeated approval with the same idempotency key;
- panel activation idempotency;
- withdraw request and hold atomicity;
- cancel and refund atomicity;
- Admin hold repair and bank balance invariants;
- ledger audit fields and transaction-boundary guards.

Result: `37 passed`, `0 failed`, two non-blocking deprecation warnings.

Machine evidence:
`reports/generated/postgresql_concurrency_v171_42.json`.

## Backup and restore

The source proof database was exported with `pg_dump` custom format and
restored with `pg_restore --exit-on-error` into a separately created database.

Verified after restore:

- 45 tables;
- 394 columns;
- 395 constraints;
- 216 indexes;
- Alembic head `0001`;
- exact control user and balances;
- identical normalized source and restore catalog fingerprints;
- restored database accepted a write and correctly rolled it back.

The temporary dump was deleted after verification and is not included in the
release archive.

Machine evidence:
`reports/generated/postgresql_backup_restore_v171_42.json`.

## CI-log repair

The supplied logs exposed two blocking defects:

- 14 ruff findings;
- 19 E2E collection failures because `requests` was absent from the test
  dependency contour.

Both root causes were repaired without deleting, skipping or weakening tests.
A separate real-PostgreSQL portability defect was also fixed by normalizing
standard PostgreSQL URLs to the asyncpg scheme for AsyncEngine tests.

Machine evidence: `reports/generated/log_repair_v171_42.json`.

## Visual proof

Fresh final-tree browser proof was captured at `390x844`:

- 12 public routes;
- all 17 Admin routes;
- all 12 mandatory Admin launcher DOM clicks;
- 29 current-cycle screenshots;
- no horizontal overflow;
- no runtime overlay;
- no residual splash.

The managed Chromium URL policy remained unchanged. The existing controlled
server-HTML proxy was used. Each Admin route/action used an isolated Chromium
process to prevent cumulative browser-resource leakage.

Machine evidence:

- `reports/generated/postgresql_public_visual_v171_42.json`;
- `reports/generated/postgresql_admin_visual_v171_42.json`;
- `reports/generated/postgresql_visual_summary_v171_42.json`.

## Exact proof boundary

Established locally:

- `LOCAL_INTEGRATION_PASSED` for the isolated PostgreSQL migration,
  transaction, concurrency and backup/restore scope;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- `LOCAL_VISUAL_PROOF_PASSED`;
- local CI-log root causes repaired.

Not established:

- production database proof;
- point-in-time recovery or multi-node failover;
- fresh GitHub CI for the output archive;
- live Telegram authorization;
- real TON or USDT transfers;
- real TonConnect proof;
- release-ready or production-ready status.

## Next cycle

Cycle 1567 is the security, privacy, legal and abuse-hardening pass. It must
also resolve the current high-severity Axios audit finding through an explicit
dependency/NORM/guard update rather than a silent lockfile change.
