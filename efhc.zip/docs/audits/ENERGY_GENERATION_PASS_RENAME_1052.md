# Cycle 1052 — energy generation pass rename

Status: done.

Scope:
- `backend/app/services/energy_service.py`

Decision:
The energy generation service is live and must not be removed. It performs
stable panel-based kWh generation and recovery after downtime.

Treatment:
- removed `round` / `раунд` wording from the service;
- renamed `max_rounds` to `max_passes`;
- renamed local `rounds` counter to `passes`;
- renamed returned `rounds` / `fallback_rounds` keys to
  `passes` / `fallback_passes`;
- updated comments and docstrings to describe processing passes.

Reasoning:
The forbidden concept was the old round wording, not the stable energy
simulation. Removing the whole service would break EFHC energy generation.
