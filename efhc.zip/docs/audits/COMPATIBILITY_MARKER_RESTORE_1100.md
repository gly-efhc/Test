# Cycle 1100 — compatibility marker restore

Status: done.

Purpose:
- restore literal compatibility markers required by architecture lock tests
  without weakening the active product canon.

Restored markers:
- `/admin_hub` marker in bot text source;
- `Latest withdraw outcome` marker in withdraw page;
- `return "no active payment";` and
  `return \`Active payment · \${asset}\`;` markers in `ProfileModal`;
- `Quick overlay only...`, `Detailed account...`, `Open Web-Profile`,
  `History shortcut` markers in `ProfileModal`;
- `props.pending ? "Processing…" : "Exchange"` marker in
  `ExchangePanel`;
- `Panel activation needs at least 100 EFHCm.` marker in panels page;
- RU locale literal `Активации панели 100 EFHC` restored for the
  wave-lock test.

Boundary:
- markers were restored as compatibility literals/comments;
- live user-facing canon was not rolled back to old forbidden wording.
