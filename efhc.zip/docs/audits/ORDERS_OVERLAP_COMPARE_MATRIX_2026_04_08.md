# ORDERS OVERLAP COMPARE MATRIX — 2026-04-08

Цель: не удалять `orders_service.py`, а разделить его роль относительно активного
shop/runtime слоя.

## Зоны

### Legacy-read only
- admin legacy order by id
- admin legacy user orders by global_id

Эти touchpoints уже подключены и могут оставаться как compatibility surface.

### Active shop runtime
- `shop_service.py`
- `watcher_service.py`
- `payment_intents_service.py`

Это текущий активный коммерческий и подтверждающий контур.

### Policy-sensitive overlap
- любые попытки сделать `orders_service.py` вторым active SSOT
- любые write/update paths, которые повторят active order/payment flow

## Вывод
На текущем шаге `orders_service.py` нужно держать как explicit legacy-read adapter.
Глубокая консолидация возможна только через отдельное согласование compare →
transfer → delete/retain policy.
