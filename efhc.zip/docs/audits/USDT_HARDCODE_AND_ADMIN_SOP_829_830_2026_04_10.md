# Cycles 829-830 — USDT hardcode + Admin SOP

Дата: 2026-04-10

## 829
- backend config default for `USDT_JETTON_MASTER_ADDRESS` set to the approved canon value
- frontend added `USDT_JETTON_MASTER_ADDRESS` constant
- browser-shop runtime helpers now have a frontend fallback to the hardcoded USDT master address

## 830
- created `docs/ADMIN_SOP.md` as a short routing guide for operators
- SOP links to `RELEASE_CANDIDATE_1.md` and `WITHDRAW_ADMIN_TONCONNECT_SSOT.md`
- updated withdraw SSOT with the full outbound Blitz flow description provided by the user

## Honest residuals
- no live mainnet payout proof in this environment
- no live USDT checkout proof in this environment
