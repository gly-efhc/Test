# DIAGNOSTIC: Инвентаризация схем / таблиц / маршрутов

Актуальный SSOT-срез без исторического шума.

## Числа

- схемы: **2** (`efhc_core`, `efhc_admin`)
- ORM-таблицы: **35**
- HTTP-маршруты: **89**
- test files: **176**

## Источники

- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- `backend/migrations/versions/0001_init.py`
- `tests/**/test_*.py`

## Правило

Этот документ фиксирует только текущий срез. Исторические расхождения
и старые цифры живут в `docs/audits/`.

## Legacy policy

Historical traces допустимы только в `docs/audits/`, `reports/`,
Healer и registry-записях. Они не входят в актуальный SSOT-срез и
не меняют правило двух схем БД.

## 2026-03-28 — cycle 74 hub_links

- Added planned active table: `efhc_core.hub_links`.
- Migration layer: all active tables must be covered by `backend/migrations/versions/0001_init.py`.
- Seed rows: `efhc_buy`, `vip_getgems`.


Дополнительный SSOT-marker: маршруты SSOT: **89**.

Страницы WebApp по current HEAD: user **10**, admin **11**. См. `docs/BOT_PAGES_INVENTORY_2026_03_31.md`.
