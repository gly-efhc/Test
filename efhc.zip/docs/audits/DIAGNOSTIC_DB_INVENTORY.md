# DIAGNOSTIC: схемы, таблицы и маршруты

Актуальный срез `v172.45`.

## База данных

- схемы: **2** (`efhc_core`, `efhc_admin`);
- ORM-таблицы: **48**;
- прикладные таблицы: **49** с `identity_migration_control`;
- физические таблицы: **50** с `alembic_version`;
- telemetry: SQL view;
- `efhc_core`: 42 ORM-таблицы;
- `efhc_admin`: 6 ORM-таблиц;
- active Alembic revision: `0001`;
- owner FK на `users.global_id`: 38.

## Маршруты

- OpenAPI paths: 131;
- OpenAPI operations: 136;
- frontend linkage: 99/99;
- Chromium: 102/102, failures 0 в fresh CI `83339629942`.

## Сверка с v171.89

- route handlers: 144/144 сохранены, добавлено 6;
- frontend pages: 38/38 сохранены;
- Telegram handlers: 28/28 сохранены;
- service modules: 50/50 сохранены;
- UI component files: 138/138 сохранены;
- ORM-таблицы: 44/44 сохранены, добавлены 4 identity/auth.

Historical traces допустимы только в явно исторических документах и
не определяют current runtime или release-схему.

Источники истины: ORM metadata, `SSOT_TABLES_ORM.csv`, OpenAPI,
route/linkage reports и единая migration `0001`.
