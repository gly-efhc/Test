# ADMIN SANDBOX EXPANSION AUDIT 631-640 — 2026-04-08

## Sources reviewed
- horizon-ui-chakra-nextjs-main
- refine-main
- ui-main

## What is most useful next
### Horizon UI
- richer dashboard cards with trend/meta rows;
- denser overview sections for KPI heavy pages;
- cleaner visual hierarchy for admin landing and statistics pages.

### Refine
- resource-first admin navigation;
- reusable list/filter/detail composition;
- better settings / forms / data editing rhythm.

### ui-main
- atomic cards, tabs, badges, helper blocks;
- reusable page spacing and section primitives.

## Safe adoption goals for EFHC
1. Расширить admin home до richer KPI/dashboard shell.
2. Добавить unified table/list shells для data-heavy страниц.
3. Добавить settings/cards editor grammar для будущих карточек и данных.
4. Подготовить statistics-heavy sections и denser overview panels.
5. Выделить shared admin surface primitives без слепого импорта чужих layouts.

## What should NOT be imported blindly
- auth/session frameworks;
- чужие роутинг-конвенции;
- внешний branding/wording;
- CRUD orchestration, не совпадающий с EFHC backend truth.
