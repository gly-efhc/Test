# Cycle 1018 — localization release checklist

Status: done.
Date: 2026-04-25.
Scope: localization range 983-1022.

## Purpose

This checklist defines the honest release gate for localization. It
keeps
local helper checks separate from GitHub CI and from human browser
proof.

## Static checks

- all locale bundles exist for the active language set;
- keys and placeholders are aligned;
- player-facing English-first canon is preserved;
- admin/operator Russian-first canon is preserved;
- FAQ consistency guard is available;
- notification/template inventory is documented;
- hardcoded-copy candidates are measured, not hidden;
- identical-to-English findings are measured and routed to the
  extension.

## Human browser checks

Before a final public localization claim, a person should open the main
screens and verify visible text, button length, tables and modals.

## GitHub CI boundary

Only the user runs GitHub CI. Local helper checks cannot be called green
GitHub CI and cannot replace the user's CI evidence.

## Current verdict

Localization is stronger than the old audit state, but full
release-ready
localization is not yet claimed because the extension tail remains open.
