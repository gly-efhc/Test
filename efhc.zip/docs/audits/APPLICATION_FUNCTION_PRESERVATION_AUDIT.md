# АУДИТ СОХРАННОСТИ ФУНКЦИЙ ПРИЛОЖЕНИЯ

Статус доказательности: **STATIC SOURCE AUDIT + SUPPLIED GITHUB CI EVIDENCE**.
Локальные `pytest`, Ruff, Flake8, Mypy, Bandit, `compileall`, Alembic, PostgreSQL integration, frontend build, CI и guards не запускались.

## 1. Источники

- рабочая база аудита: `EFHC_Bot_v173_40.zip`;
- предоставленный GitHub CI: `84948550953`, checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`, exact archive `12124946` bytes;
- исторический источник до финального перехода ownership: `EFHC_Bot_v171_89.zip`;
- active Kernel, SSOT и CANON текущего HEAD;
- статический `backend/openapi/openapi.json` текущего HEAD и исторического архива;
- frontend source tree текущего HEAD и `v171.89`.

## 2. Подтверждённый CI-контекст

Предоставленный CI для `v173.40` подтвердил:

- GREEN: Alembic/PostgreSQL, flake8, Mypy, Bandit, `compileall`, frontend production build;
- Ruff: **1 I001**;
- pytest: **45 failed / 1456 passed / 22 skipped**;
- прежний setup-кластер `identity_migration_control` больше не присутствует в списке failures;
- новый control-test `tests/architecture/test_application_function_surface_manifest.py` не входит в список 45 failures, но расширенный контракт текущего HEAD локально не запускался и требует следующего exact-head CI.

Из 45 failures выделены подтверждённые классы: остаточные test expectations после final `global_id` cutover, потерянный payment compatibility entrypoint, watcher injection seam, устаревшие ENV/identity ожидания, документальные manifests и одна строка payment reason, превышавшая размер DB-поля.

## 3. Сохранность страниц

Статическое сравнение page source tree `v171.89` и текущего HEAD:

- исторический page tree: **38** файлов;
- текущий page tree: **38** файлов;
- совпадение относительных путей: **38/38**;
- подтверждённых исчезнувших frontend page-файлов: **0**.

В fail-closed manifest зарегистрированы **37 пользовательских/служебных страниц**; отдельный физический Next.js API-файл `frontend/src/pages/api/tonconnect-manifest.ts` не относится к UI page inventory.

## 4. HTTP surface: исторический и текущий

Статический exported OpenAPI:

- `v171.89`: **125 paths / 130 HTTP operations**;
- текущий HEAD: **127 paths / 132 HTTP operations**.

Исторические paths, которых больше нет под тем же URL:

- `/admin/shop/order/legacy/{order_id}`;
- `/admin/shop/orders/user/legacy/{tg_id}`;
- `/admin/users/{tg_id}`;
- `/admin/users/{tg_id}/active`;
- `/admin/users/{tg_id}/vip`;
- `/admin/users/{tg_id}/wallet/reset`;
- `/referrals/active`;
- `/referrals/counters`;
- `/referrals/inactive`;
- `/referrals/stats`;
- `/sync/user/{tg_id}`.

Текущие paths, отсутствовавшие в `v171.89`:

- `/admin/access`;
- `/admin/shop/order/{order_id}`;
- `/admin/shop/orders/user/{global_id}`;
- `/admin/users/{global_id}`;
- `/admin/users/{global_id}/active`;
- `/admin/users/{global_id}/vip`;
- `/admin/users/{global_id}/wallet/reset`;
- `/auth/logout`;
- `/auth/session`;
- `/auth/telegram/session`;
- `/auth/ton/challenge`;
- `/auth/ton/proof`;
- `/sync/me`.

По direct-reference сравнению общих OpenAPI paths не найдено ни одного path, который был напрямую referenced frontend-кодом в `v171.89` и стал полностью unreferenced в текущем frontend. Это ограниченный статический критерий и не доказывает полноту продуктовой интеграции.

## 5. Admin: что действительно восстановлено

### 5.1. Восстановленные безопасные facade entrypoints

В предыдущем этапе уже восстановлены delegating compatibility surfaces, не возвращающие `tg_id` ownership:

- `backend/app/init.py::create_app`;
- `backend/app/database.py::get_engine`, `get_session_factory`;
- `backend/app/core/decimal_utils.py::d8`;
- `backend/app/models/order_models.py::ShopOrder`;
- FSM public API в `backend/app/bot/states.py`;
- Admin bot main facade `handler`, `router`, `kb_admin_entry`, `ADMIN_HUB_LABEL`;
- scheduler `TickContext`, `SchedulerError`, `JobTimeout`, `tick`, maintenance `run_once`;
- `RBAC.is_superadmin`.

На текущем этапе по историческому evidence и новому CI восстановлены дополнительные безопасные поверхности:

- `AdminService.credit_bonus_efhc`;
- `AdminService.credit_regular_efhc`;
- `AdminUsersService.credit_bonus_efhc`;
- `AdminUsersService.credit_regular_efhc`;
- `wallets_service.credit_user_from_bank`;
- `wallets_service._confirm_payment_intent`;
- `wallets_service.STATUS_CREDITED`;
- `wallets_service.STATUS_ERROR_SYS`;
- optional bank-credit injection seam в watcher/reconciliation;
- `nft_requests_service.refresh_vip_status_due_batch`;
- `nft_requests_service.refresh_vip_status_for_due_users`;
- `nft_requests_service.check_vip_nft_due_batch`.

Все эти восстановления являются фасадами/делегированием текущему canonical runtime. Старый business ownership по `tg_id` не возвращён.

### 5.2. Полный публичный AdminService, защищённый manifest

Контроль теперь регистрирует следующие публичные методы `AdminService`:

1. `resolve_admin`;
2. `require_role`;
3. `list_admin_logs`;
4. `get_setting`;
5. `mget_settings`;
6. `set_setting`;
7. `mset_settings`;
8. `snapshot_settings_daily`;
9. `restore_settings_from_snapshot`;
10. `get_bank_balance`;
11. `mint_efhc`;
12. `burn_efhc`;
13. `manual_bank_user_transfer`;
14. `toggle_user_panel`;
15. `get_coins_stats`;
16. `get_panels_stats`;
17. `get_referrals_stats`;
18. `get_shop_stats`;
19. `get_system_stats`;
20. `get_user_balances`;
21. `debug_user_progress`;
22. `credit_bonus_efhc`;
23. `credit_regular_efhc`;
24. `list_withdraw_requests`;
25. `admin_approve_withdraw`;
26. `admin_reject_withdraw`;
27. `admin_mark_withdraw_paid`;
28. `list_bonus_payouts`.

Дополнительно manifest защищает Admin bot `router`/`handler` surfaces и цепочку Admin NFT authority.

## 6. Admin NFT: проверенные статические anchors

В текущем source присутствуют:

- `backend/app/core/config_core.py` → `TON_ADMIN_NFT_IDS`;
- `backend/app/services/nft_check_service.py` → `TON_ADMIN_NFT_IDS`, `_admin_nft_id_for_asset`, `_filter_admin_nft_assets`, `_sync_admin_nft_wallet_state`;
- `backend/app/services/admin/admin_rbac.py` → `resolve_admin_nft`;
- `backend/app/deps.py` → `require_admin_or_nft_or_key`;
- `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.

Это подтверждает наличие статической authority chain в source. Runtime-проверка текущего HEAD не выполнялась.

Исторические `get_current_admin`, `get_admin_api_key_guard`, Telegram `_is_admin(tg_id)` и другие отдельные privilege authorities не восстанавливались, потому что active security CANON разрешает только server-side session + `global_id` + RBAC и резервный Admin NFT contour.

## 7. Старый Admin CRUD: почему не выполнен массовый rollback

После сравнения с `v171.89` остаются исторические backend-файлы без прямого одноимённого файла в current tree:

- `core/deps.py`;
- `crud/admin/admin_ads_crud.py`;
- `crud/admin/admin_bank_crud.py`;
- `crud/admin/admin_crud.py`;
- `crud/admin/admin_logs_crud.py`;
- `crud/admin/admin_notifications_crud.py`;
- `crud/admin/admin_panels_crud.py`;
- `crud/admin/admin_settings_crud.py`;
- `crud/admin/admin_stats_crud.py`;
- `crud/admin/admin_tasks_crud.py`;
- `crud/admin/admin_users_crud.py`;
- `crud/admin/admin_wallets_crud.py`;
- `crud/admin/admin_withdrawals_crud.py`;
- `crud/transfers_crud.py`;
- `scheduler/jobs/job_tasks_maintenance.py`;
- `schemas/ranks_schemas.py`.

Большинство `crud/admin/*` кроме `admin_crud.py` были небольшими placeholder-модулями. `admin_crud.py` содержал реальные read/status utilities, но одновременно старые `tg_id` business selectors и direct status mutation semantics. `core/deps.py` реэкспортировал provider-era dependency surface. `transfers_crud.py` и старые ranks schemas также содержали `tg_id`-era ownership. Поэтому прямой rollback этих файлов противоречил бы final `global_id` CANON.

Recovery candidates, которые нельзя автоматически удалять и нельзя вслепую возвращать:

- `efhc_transfers_recent_total`;
- `get_admin_bank_config`;
- `list_ton_inbox`;
- `set_ton_log_status_guarded`;
- `shop_order_status_counters`;
- `ton_inbox_status_counters`;
- `withdraw_status_counters`.

## 8. Bonus Awards: почему отдельной Admin page/route не было

Статическое историческое evidence `v171.89` показывает:

- OpenAPI path с отдельным Bonus Awards API не найден;
- отдельная Admin frontend Bonus Awards page не найдена;
- `docs/NORM/BONUS_AWARDS_LEGACY_GUARD_SCOPE.md` и `BONUS_AWARDS_LEGACY_STATUS.md` описывали `efhc_admin.bonus_awards` как legacy/dead, а не active пользовательский runtime.

Следовательно, подтверждённый дефект cleanup состоял не в отключении существовавшей Bonus page, а в удалении compatibility service/facade symbols. В current code сохраняются `WithdrawalsService.list_bonus_awards`, `process_bonus_award`, `reject_bonus_award` и `AdminService.list_bonus_payouts`; дополнительно восстановлен manual Admin credit facade через BANK для BONUS/MAIN bucket.

## 9. Admin HTTP operations без найденного прямого frontend caller

Эти операции **не являются dead code** и сохраняются по Fail-Closed Delete Policy:

1. `GET /admin/observability/events`;
2. `GET /admin/reports/bank`;
3. `GET /admin/reports/deposits`;
4. `GET /admin/reports/panels`;
5. `GET /admin/reports/users`;
6. `GET /admin/reports/withdrawals`;
7. `POST /admin/shop/items/set-price`;
8. `POST /admin/tasks/`;
9. `GET /admin/tasks/{task_id}`;
10. `PATCH /admin/tasks/{task_id}`;
11. `DELETE /admin/tasks/{task_id}`.

Отдельно перепроверены динамически формируемые Admin Withdraw/Hub URL. `repair-consistency`, approve, reject, outcome-preview и Hub update/toggle/reorder имеют frontend linkage и не включаются в этот список.

## 10. Публичные integration candidates

### Referral ranking

Backend сохраняет:

- `GET /ranks/referrals/my-plus-top/me`;
- `GET /ranks/referrals/top/me`.

Current `frontend/src/services/ranks.service.ts` использует общий kWh ranking, но direct usage двух referral-ranking routes в current Ranks UI не найден. Active frontend recovery docs при этом описывают отдельный рейтинг по рефералам. Статус: **RECOVERY_CANDIDATE / DOCUMENTATION-CODE INTEGRATION GAP**. Автоматическое UI-восстановление в рамках CI repair не выполняется.

### Shopfront profile

`GET /shopfront/profile` присутствует в backend/OpenAPI и generated seam, но direct frontend caller не найден. Это не подтверждено как новая потеря относительно `v171.89`; endpoint сохраняется как operational/integration surface.

## 11. Контроль от повторного удаления функций

Fail-closed manifest: `contracts/application_function_surface_v1.json`.
Контрольный CI-файл: `tests/architecture/test_application_function_surface_manifest.py`.

Текущая регистрация:

- OpenAPI paths: **127**;
- HTTP operations: **132**;
- frontend pages: **37**;
- критические Python symbols: **259**;
- Python modules: **44**;
- обязательные files: **14**.

Контроль проверяет наличие зарегистрированных files/symbols через source AST, exact checked-in OpenAPI path+operation set, frontend page set и критические текстовые anchors полномочий/совместимости. Он не должен становиться основанием удалять незарегистрированный code: registry — минимальный fail-closed floor, а не whitelist допустимого проекта.

Расширенная версия контроля в текущем HEAD **не запускалась локально**. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## 13. Follow-up цикла 1718 и окно согласования 1719–1731

GitHub CI `84954546920` на exact `v173.41` сузил технический остаток до
Mypy (`2` ошибки) и pytest (`17 failed / 1485 passed / 22 skipped`).
GREEN: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend
production build. Исправления цикла 1718 не возвращают retired `tg_id`
ownership или migration-control layer.

Подтверждена packaging-регрессия `v173.41`: executable metadata было
потеряно у release/ops scripts. По metadata предыдущего HEAD `v173.40`
восстановлены executable modes у `50` файлов. Также восстановлены `28`
исторических Unicode report filenames, для которых содержимое совпадало с
предыдущим HEAD, а изменилось только имя при прошлой упаковке.

Для дальнейшего решения спорных функций создан
`docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`. Десять волн
`1719–1728` распределяют найденные Admin/report/task/shop/referral/TON/NFT/
Bonus/payment/runtime compatibility surfaces. `1729` предназначен для
консолидации только согласованных решений, `1730` — для exact-head CI
qualification, `1731` — для подготовки backend/frontend audit handoff.

Ни один `PRESERVE_NO_UI_CALLER` или `RECOVERY_CANDIDATE` не становится
кандидатом на удаление только из-за отсутствия caller. Удаление допустимо
только после полного Fail-Closed Delete proof и явного решения пользователя.

## 11. Решение пользователя по группе цикла 1719

Статусы прежнего списка no-frontend-caller уточнены прямым решением пользователя:

- `/admin/observability/events` → `STUBBED_DUPLICATE`; сохранён route compatibility, но чтение `efhc_transfers_log` отключено, потому что функцию полностью дублирует `/admin/logs/transfers`.
- `/admin/reports/users` → `ACTIVE/UI_CONNECTED`; исправлен остаточный join `tg_id` на `global_id`.
- `/admin/reports/bank` → `ACTIVE/UI_CONNECTED`; удалена ошибочная идея отдельного `EFHC_BONUS` bank balance, отчёт использует единый `EFHC_MAIN` и BANK_EFHC system rows.
- `/admin/reports/panels` → `ACTIVE/UI_CONNECTED`.
- `/admin/reports/withdrawals` → `ACTIVE/UI_CONNECTED`.
- `/admin/reports/deposits` → `ACTIVE/UI_CONNECTED`; pending status согласован с canonical `PENDING`.
- Existing observability real-timeseries component подключён к `/admin/reports`.

Эти шесть operations больше не относятся к нерешённым recovery candidates цикла 1719. Следующая группа исследования — Admin Tasks, цикл 1720.



## Cycle 1720 — Admin Tasks / Ads / maintenance follow-up

По прямому решению пользователя группа Tasks получила статус `ACTIVE/UI_CONNECTED`:

- create/detail/update/delete подключены к полному Admin Tasks Editor;
- physical delete fail-closed блокируется при submissions, user status, bonus log или completion locks;
- `code` не меняется после появления истории;
- submissions и moderation сохранены;
- maintenance route сохранён, но описание исправлено: это retention cleanup credited task locks, не синхронизация task statuses.

Historical `v171.89` подтвердил, что `crud/admin/admin_tasks_crud.py` не содержал Task CRUD и только re-exported BANK/TON/Shop/Withdraw utilities. Он не восстановлен как ложная архитектурная граница; функции распределены по следующим тематическим циклам. `scheduler/jobs/job_tasks_maintenance.py` также не содержал runtime-функции. Реальный maintenance был и остаётся `tasks_maintenance -> tasks_autorestart.run_once`. Временная проверка TON payments подтверждена отдельным `check_ton_inbox/job_ton_watcher` contour, поэтому дубль Tasks/TON не установлен.

Отдельная `/admin/ads` существует; она сохранена и приведена к реальному provider registry/config-readiness для `builtin_timer`/`adsgram` без выдачи secret values. Отдельный Adsgram frontend-player в этом цикле не утверждается как реализованный.

Локальные application tests/builds/guards не запускались; новый exact-head CI обязателен.
