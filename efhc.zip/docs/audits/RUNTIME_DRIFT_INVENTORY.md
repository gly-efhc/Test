# Runtime Drift Inventory

> Historical snapshot: this document reflects an older HEAD/cycle state and must not be read as current release status. Current post-fix state is tracked by later 2026-04-04 audits and reports.


Текущий HEAD: EFHC_Bot_v158_28_cycle_51_faq_translations_runtime_parity_wave_2.zip
Последний закрытый цикл: 52 из 60

- Cycle 52: RU duplicate audit wave 3 completed as audit_only; direct-risk 0, auto deletions 0, auto replacements 0, review groups 4 / affected Q/A 8.

Дата: 2026-03-26
Архив: v158_16
Цикл: 40

## Назначение

Этот документ фиксирует классы drift между:
- SSOT
- frontend runtime
- docs
- tests
- release artifact

Цель цикла 21: не лечить всё сразу, а зафиксировать, что именно
должно проверяться на следующих циклах 22–30.

## Подтверждённые классы mismatch

| Класс | Источник истины | Целевая проекция | Что уже подтверждалось | Точки проверки |
|---|---|---|---|---|
| FAQ SSOT -> runtime catalog drift | `docs/SSOT/faq_ssot/*/faq_*.json` | `frontend/src/data/faq/catalogs.ts` | В `v157_28` был подтверждён и исправлен drift по RU FAQ runtime. | `pytest -q tests/architecture/test_faq_ru_synced_with_ssot.py`, прямое сравнение разделов/items, генерация catalog из SSOT. |
| Docs counts drift | фактическое дерево repo | `README.md`, `docs/OVERVIEW_SSOT_SYNC.md`, `docs/PROJECT_OVERVIEW_RU.md`, `docs/audits/DIAGNOSTIC_DB_INVENTORY.md`, `docs/NORM/TESTS_CATALOG.md` | Count-bearing docs уже несколько раз отставали после удаления/добавления файлов. | автоматический пересчёт `test_*.py`, route files, ORM/SSOT rows; `pytest -q tests/architecture/test_docs_ssot_sync.py`. |
| Route registry drift | `backend/app/routes/**` и `backend/app/routes/__init__.py` | route maps / overview docs / OpenAPI expectations | После lotteries decommission приходилось синхронизировать route maps вручную. | inventory `method + path + file + prefix`; `pytest -q tests/architecture/test_route_idempotency_policy.py`; `compileall backend/app/routes`. |
| Release artifact drift | текущее рабочее дерево | release ZIP | Уже подтверждались stale `logs/`, dead locale keys и historical мусор в релизе. | FLAT ZIP audit, grep по мусору, проверка отсутствия `__pycache__`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `node_modules`, `logs/`. |
| Line72 drift | канон репозитория | active tree | В `v157_28` подтверждён и исправлен хвост в `backend/app/bot/states.py`. | `pytest -q tests/architecture/test_max_line_length_72.py`. |
| Route/docs plan drift | active code audit | плановые docs | Стартовый план routes/migrations опирается на количество endpoints и migration files; при изменении дерева эти цифры должны обновляться. | точный route count, migration count, docs diff against active audit. |
| OpenAPI export drift | `api/index.py`, `backend/openapi/openapi.json` | Vercel entry / exported OpenAPI | Serverless entry может потерять `app`, а exported OpenAPI отстать от active route surface. | `py_compile api/index.py backend/app/main.py`; `pytest -q tests/architecture/test_openapi_startup_consistency.py`; compare `backend/openapi/openapi.json` with `docs/SSOT/ssot_pack/SSOT_ROUTES.csv`. |
| Idempotency policy drift | `backend/app/routes/**`, `ops/canon_rules.yaml` | route guards / SSOT policy / docs audit | Слабая проверка может смотреть только local path и не видеть mismatch на полном route path `prefix + local path`. | `pytest -q tests/architecture/test_route_idempotency_policy.py tests/architecture/test_idempotency_surface_docs_sync.py`; compare `docs/SSOT/ssot_pack/SSOT_IDEMPOTENCY_SURFACE.csv`. |

## Текущее состояние на цикл 21

### FAQ
- Языков SSOT: 13
- Разделов на язык: 20
- Вопросов на язык: 250
- Ответов на язык: 250
- Runtime FAQ catalog после `v157_28` синхронизирован с SSOT.

### Routes
- HTTP endpoints: 85
- duplicate method+path collisions: 0
- admin prefixes сейчас неоднородны:
  - `/admin`
  - `/admin/ads`
  - `/admin/logs`
  - `/admin/panels`
  - `/admin/sale-packages`
  - `/admin/shop`
  - `/admin/users`
  - `/api/admin`

### Tests
- `test_*.py` в репозитории: 97

### Migrations
- migration files: 1
- файл: `backend/migrations/versions/0001_init.py`

## Что должно стать объектом следующих циклов

### Цикл 22
- Детерминированная сборка `frontend/src/data/faq/catalogs.ts` из SSOT.
- Отдельный guard/test на full runtime parity, не только по RU.

### Цикл 23
- Полная инвентаризация route surface.
- Подготовка карты `route -> service -> table`.

### Цикл 24
- Выбор единого admin prefix канона.
- План миграции без поломки OpenAPI и фронтенда.

### Цикл 27
- Автоматизация пересчёта docs counts и route/test inventories.

## Контрольные проверки цикла 21

- `pytest -q tests/architecture/test_faq_ru_synced_with_ssot.py`
- `pytest -q tests/architecture/test_docs_ssot_sync.py`
- `pytest -q tests/architecture/test_route_idempotency_policy.py`
- `pytest -q tests/architecture/test_migrations_numbering_canon.py`
- `pytest -q tests/architecture/test_max_line_length_72.py`


### Цикл 22 — выполнено

- Добавлен генератор `ops/scripts/generate_faq_catalogs_from_ssot.py`.
- `frontend/src/data/faq/catalogs.ts` теперь пересобирается из `docs/SSOT/faq_ssot/*/faq_*.json`.
- Добавлен exact-match guard: `tests/architecture/test_faq_catalogs_generated_from_ssot.py`.

## Cycle 23
- Подтверждён route-surface drift: часть route modules вшивала `/api` локально, хотя финальный префикс задаётся через `settings.API_PREFIX`.
- Исправлено в `admin_referral_routes.py`, `admin_tasks_routes.py`, `me_routes.py`.
- Добавлен guard `tests/architecture/test_route_prefixes_no_embedded_api.py`.


## Cycle 24

- Admin route surface canonicalized: fixed local admin prefixes/tags.
- Added architecture guard for admin route module canon.
- Synced docs counts and tests catalog after new guard file.


## Cycle 25

- Подтверждён drift self-profile surface: активны сразу три маршрута `GET /api/v1/me`, `GET /user/me`, `GET /user/{tg_id}/me`.
- `GET /user/{tg_id}/me` является self-guarded alias, а не независимым tg_id-scoped профилем.
- Подтверждён docs drift: `docs/GENERAL/specification.md` и `docs/GENERAL/architecture.md` ещё ссылались на несуществующий `GET /api/user/profile`; `docs/NORM/API_CONTRACTS.md` описывал только alias `/user/{tg_id}/me` и не фиксировал `GET /api/v1/me` и `GET /user/me`.

| FAQ residual tail drift | `docs/SSOT/faq_ssot/fr/*`, `docs/SSOT/faq_ssot/pl/*`, `frontend/src/data/faq/catalogs.ts` | Russian canon / active runtime FAQ | После decommission lotteries в переводах оставались 5 active answer-tail mentions. | grep residuals + regenerate FAQ catalogs + exact count audit. |

| FAQ ban-token drift | `docs/SSOT/faq_ssot/**`, `frontend/src/data/faq/catalogs.ts` | канон запрета на лотереи/розыгрыши | После прошлой чистки в EN FAQ оставался запретный хвост про рискованную механику, хотя смысл уже запрещён. | exact grep по FAQ слоям + guard `test_faq_banned_terms_absent.py` + regenerate runtime FAQ. |


## Cycle 31 update

- Route inventory freeze added and aligned to 88 active SSOT routes.
- New freeze sources: `docs/SSOT/ssot_pack/SSOT_ROUTE_INVENTORY_FREEZE.csv`, `docs/audits/ROUTE_INVENTORY_FREEZE.md`.


## Cycle 33 update

- Подтверждён idempotency policy drift: старая архитектурная проверка анализировала только local route string без router prefix и не видела mismatch на полном пути.
- Синхронизированы actual patterns в `ops/canon_rules.yaml` для `/admin/withdrawals/...`, `/deposit/efhc`, `/skins/buy/...`, `/tasks/claim/...`, `/wallets/connect`, а также SHOULD-поверхности для non-monetary state-changing routes.
- Исправлен stale SSOT path `/api/admin/referrals/reassign` -> `/admin/referrals/reassign`.
- Добавлен audit source `docs/SSOT/ssot_pack/SSOT_IDEMPOTENCY_SURFACE.csv` и markdown summary `docs/IDEMPOTENCY_SURFACE_AUDIT.md`.


## Cycle 34 update

- Подтверждён response/error drift: `backend/app/main.py` не регистрировал `setup_exception_handlers(app)`, поэтому канонический JSON-формат ошибок не был гарантирован для `HTTPException`.
- `payment_intents_routes.py` и `wallets_routes.py` использовали dict-detail без канонических ключей `error/message/details`.
- Добавлен guard `tests/architecture/test_route_error_response_canon.py`; строки-detail остаются legacy-слоем до отдельной волны нормализации.


## Cycle 35 update
- Fixed `mypy` arg-type drift in `errors_core.setup_exception_handlers`.
- Removed false banned-substring hits from Healer atlas wording.
- Migration 0001 docs synced to current SSOT: 33 tables, 2 schemas, ORM-only 0001.


## Cycle 36
- CI log `logs_62194714005.zip` showed a single pytest failure from banned tg_id alias names inside `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`.
- Migration invariants were hardened to current canon: 33 tables, 2 schemas, ORM-only 0001, no alias terms in active migration docs/plan.

- Cycle 37: DB diagnostic docs synced to SSOT_TABLES_ORM current canon: 33 tables, 2 schemas, fixed stale 38/33 totals and malformed legacy-policy paragraphs.

| Route matrix/OpenAPI docs drift | `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md`, `backend/openapi/openapi.json` | route matrix / overview docs | Route matrix может держать stale counts, отсутствующие model file references и отставать от exported OpenAPI operations/paths. | `pytest -q tests/architecture/test_openapi_docs_route_matrix_sync.py`; compare counts with `docs/SSOT/ssot_pack/SSOT_ROUTES.csv` and `backend/openapi/openapi.json`. |

- Cycle 38: synchronized `MODEL_TABLE_ROUTE_TEST_MAP.md` with current SSOT/OpenAPI counts and replaced missing `backend/app/models/exchange_routes.py` reference with existing model file evidence.


## Cycle 39

- Release artifact drift закрыт: build script теперь исключает `.local_artifacts/`, `logs/` и `*.log`; добавлен dedicated guard.


## Статус после цикла 40

- Серия route/migration 31–40 закрыта regression pack-ом.
- Финально подтверждено локально: route inventory, idempotency surface, migration 0001 canon, migration invariants, DB diagnostics docs, OpenAPI/docs route matrix и release artifact hygiene проходят целевые guards.
- Подтверждённый residual drift цикла 40 был только один: stale count `test files` в `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md` (`111` -> `112`).


## Cycle 41
- FAQ inventory freeze выполнен.
- Зафиксированы runtime-source FAQ и totals 13×20×250.
- В RU найдено 22 прямых risk-candidate Q/A для wave 1.


## Cycle 42

- RU FAQ purge wave 1 completed.
- Section 14 fully replaced from risky tournament mechanics to safe section `Навигация и правила`.
- 5 additional RU answers cleaned outside section 14.
- RU total preserved at 250 Q/A; frontend runtime regenerated from SSOT.

- cycle 43: RU FAQ wave 2 review completed; direct-risk wave 1 remains closed, manual confirmation list prepared for next RU cleanup wave.

- cycle 44: RU section 14 refined in 5 Q/A; runtime FAQ regenerated from SSOT; no totals drift.
- cycle 45: faq translations/runtime parity wave 1 — done (v158_22)

## 2026-03-27 — Cycle 46

- FAQ RU direct-risk wave 2: новых кандидатов не подтверждено.
- Зафиксирован zero-candidate audit: `docs/archive_removed_elements/FAQ_RU_DIRECT_RISK_CANDIDATES_WAVE2.md`.
- Следующий слой FAQ-аудита переводится со direct-risk слов на слабые и дублирующие Q/A.



- Cycle 47: direct-risk layer remained clean; created RU weak/duplicate audit wave 1 with no runtime changes.

- 2026-03-27: Cycle 48 closed section 14 weak/duplicate review groups by point refinements without changing totals.

- Cycle 49: RU duplicate audit wave 2 completed; 3 groups / 6 Q/A candidates, no automatic FAQ edits.

- Cycle 50: RU duplicate wave 2 resolved by point refinements for 6 Q/A; runtime FAQ regenerated from SSOT.

- Cycle 51: non-RU FAQ parity wave 2 synced for IDs 3-7, 3-8, 8-6, 8-7, 16-8, 16-10; runtime catalogs regenerated from SSOT.

- cycle 53 / v158_30: RU duplicate resolution wave 3 synced 8 FAQ IDs in russian SSOT, regenerated runtime catalogs, review file moved to resolved state.

- Cycle 54: non-RU FAQ layers kept stale mirrored wording for ids 4-8, 4-9, 10-4, 10-12, 16-1, 16-5, 18-3, 18-9 after RU duplicate resolution wave 3; translation/runtime parity synced and catalogs regenerated.
