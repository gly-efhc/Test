# CYCLE 1716 — FUNCTION PRESERVATION / ADMIN / ROUTE / DOCS AUDIT

Статус доказательности: **STATIC SOURCE AUDIT + SUPPLIED GITHUB CI EVIDENCE**. Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guards не запускались.

## 1. Входные evidence

- Current HEAD: `EFHC_Bot_v173_39.zip`.
- Supplied GitHub CI: `84942802763`, checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Historical comparison archive: `EFHC_Bot_v171_89.zip`.
- Active Kernel/SSOT/CANON current HEAD.

## 2. GitHub CI 84942802763

Подтверждено логами:

- GREEN: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Ruff: **3 I001** import-order diagnostics.
- pytest: **61 failed, 1307 passed, 22 skipped, 130 errors**.
- Крупнейший setup-error cluster: test fixtures обращаются к удалённой после qualification таблице `efhc_core.identity_migration_control`.
- Alembic/PostgreSQL gate одновременно GREEN, а active post-migration canon фиксирует retirement migration-control layer. Поэтому таблица не восстанавливается в production schema; stale test fixtures/expectations переводятся на final-cutover contract.

Cycle 1716 patch ограничен подтверждёнными CI causes и explicit audit scope пользователя. Новый HEAD локально не квалифицировался.

## 3. Historical v171.89 symbol delta

Предварительный one-to-one symbol-name delta: **126** имён из `backend/app` v171.89 отсутствовали под теми же именами в v173.39. Это **не равно 126 потерянным функциям**: в delta смешаны renamed/moved surfaces, retired migration/provider-owner aliases, schema DTOs, compatibility facades и реальные recovery candidates.

Полный pre-restoration name delta:

- `AdminRebuildRanksIn`
- `AdminRebuildRanksOut`
- `AsyncSessionLocal`
- `JobTimeout`
- `LegacyOrderOut`
- `OrdersSettings`
- `PurchasePanelIn`
- `RankFeedOut`
- `RankLevelDef`
- `RankLevelsOut`
- `RankMeBlock`
- `RankSyncOut`
- `RankTopQueryIn`
- `RanksQueryIn`
- `RanksRowOut`
- `RanksSnapshotMetaOut`
- `SchedulerError`
- `ShopPurchaseEFHCIn`
- `ShopPurchaseEFHCOut`
- `TON_API_URL`
- `TON_WALLET`
- `TickContext`
- `TonConnectTx`
- `VIP_NFT_COLLECTION`
- `_bank_id`
- `_combined`
- `_create_vip_request`
- `_debit_user_bonus_first`
- `_decrease_stock_or_fail`
- `_deprecated`
- `_ensure_user_exists_by_tg`
- `_fallback_admin`
- `_fetch_tg_ids_with_wallet_batch`
- `_get_current_tg_id_impl`
- `_get_user_row_by_id`
- `_get_user_row_by_telegram`
- `_is_admin`
- `_is_bank_admin`
- `_iso_or_none`
- `_legacy_order_to_out`
- `_notify_admins_vip_request`
- `_proof_message`
- `_raise_legacy_shop_write_blocked`
- `_require_self_parent`
- `_resolve_rate_limit_tg_id`
- `_svc_list_referrals`
- `_to_int32_be`
- `_to_uint32_le`
- `_to_uint64_le`
- `_v_tg_id`
- `_validate_ton_address`
- `admin_legacy_get_order`
- `admin_legacy_list_user_orders`
- `append_transfer_extra_info`
- `async_session_maker`
- `async_session_maker_core`
- `backfill_user`
- `build_sku_for_order`
- `cancel_order_admin`
- `cancel_withdraw_request`
- `check_vip_nft_due_batch`
- `create_order`
- `credit_bonus_efhc`
- `credit_regular_efhc`
- `credit_user__main__from_bank_by_tg_id`
- `credit_user_bonus_from_bank_by_tg_id`
- `debit_user__main__to_bank_by_tg_id`
- `debit_user_bonus_to_bank_by_tg_id`
- `debug_user_progress_by_telegram`
- `efhc_transfers_recent_total`
- `finalize_order_by_payment`
- `generate_for_user`
- `get_admin_api_key_guard`
- `get_admin_bank_config`
- `get_current_admin`
- `get_current_tg_id`
- `get_current_user`
- `get_ranks_my_plus_top`
- `get_ranks_top`
- `get_referral_counters`
- `get_referrals_active`
- `get_referrals_inactive`
- `get_referrals_page_stats`
- `get_shop_service`
- `get_user_by_id`
- `get_user_by_telegram`
- `get_user_for_update`
- `get_user_profile_by_telegram`
- `get_user_progress_by_id`
- `get_user_progress_by_telegram`
- `get_user_snapshot_by_id`
- `get_user_snapshot_by_telegram`
- `get_user_tasks`
- `hash_password`
- `is_superadmin`
- `is_vip_item_code`
- `list_efhc_transfers`
- `list_orders`
- `list_orders_for_user`
- `list_shop_orders`
- `list_task_rewards_log`
- `list_tg_ids_in_snapshot`
- `list_ton_inbox`
- `list_user_ledger`
- `one_of`
- `parse_efhc_pack_qty`
- `post_claim_task`
- `refresh_vip_status_due_batch`
- `refresh_vip_status_for_due_users`
- `register_referral_and_reward`
- `require_admin`
- `search_users_by_telegram_prefix`
- `set_is_active`
- `set_shop_order_status_guarded`
- `set_ton_log_status_guarded`
- `set_ton_wallet`
- `set_vip_flag`
- `set_withdraw_status_guarded`
- `shop_order_status_counters`
- `submit_manual_vip_nft_claim`
- `sync_user_snapshot`
- `tick`
- `ton_inbox_status_counters`
- `update_username_if_changed`
- `verify_password`
- `withdraw_status_counters`

## 4. Admin-specific historical delta — 25 symbols

| Historical symbol | Classification | Current mapping / decision |
|---|---|---|
| `_get_user_row_by_id` | **REPLACED_CURRENT** | current _get_user_row(global_id) |
| `_get_user_row_by_telegram` | **RETIRED_BY_IDENTITY_CANON** | Telegram provider subject may not be Admin business selector |
| `_is_admin` | **REPLACED_CURRENT** | Telegram sender -> global_id -> RBAC / server-side session Admin gate |
| `_iso_or_none` | **RENAMED_CURRENT** | current _iso |
| `_v_tg_id` | **RETIRED_BY_IDENTITY_CANON** | tg_id Admin business validation removed after global_id cutover |
| `credit_bonus_efhc` | **REPLACED_CURRENT** | AdminUsersService.adjust_user_balance_via_bank / /admin/transfer with global_id and BONUS bucket |
| `credit_regular_efhc` | **REPLACED_CURRENT** | AdminUsersService.adjust_user_balance_via_bank / /admin/transfer with global_id and MAIN bucket |
| `debug_user_progress_by_telegram` | **REPLACED_CURRENT** | AdminService.debug_user_progress(global_id) |
| `efhc_transfers_recent_total` | **RECOVERY_CANDIDATE_READ_UTILITY** | historical read utility; direct rollback rejected because old CRUD used tg_id-era contracts |
| `get_admin_bank_config` | **RECOVERY_CANDIDATE_READ_UTILITY** | historical read utility; BankService/current Admin bank endpoints are authoritative |
| `get_user_progress_by_id` | **REPLACED_CURRENT** | get_user_progress(global_id) |
| `get_user_progress_by_telegram` | **RETIRED_BY_IDENTITY_CANON** | provider-subject Admin business selector retired |
| `get_user_snapshot_by_id` | **REPLACED_CURRENT** | get_user_snapshot(global_id) |
| `get_user_snapshot_by_telegram` | **RETIRED_BY_IDENTITY_CANON** | provider-subject Admin business selector retired |
| `is_superadmin` | **RESTORED_SAFE_COMPAT** | RBAC.is_superadmin(Admin) restored as pure role helper |
| `list_efhc_transfers` | **REPLACED_OR_CANDIDATE** | BankService.list_bank_user_transfers covers canonical bank/user transfer surface |
| `list_shop_orders` | **REPLACED_CURRENT** | current admin_shop_service list-orders surface |
| `list_ton_inbox` | **REPLACED_OR_CANDIDATE** | current Admin TON/deposit runtime and reconcile surfaces; no blind legacy CRUD rollback |
| `search_users_by_telegram_prefix` | **REPLACED_CURRENT** | search_users_by_global_prefix / Admin user search by canonical owner |
| `set_shop_order_status_guarded` | **REPLACED_CURRENT** | current admin_shop_service status/force-fulfill state surface |
| `set_ton_log_status_guarded` | **RECOVERY_CANDIDATE_OPERATIONAL** | legacy direct mutation not restored; current reconcile/deposit state machines remain authoritative |
| `set_withdraw_status_guarded` | **REPLACED_CURRENT** | WithdrawalsService approve/reject and Admin withdrawal routes |
| `shop_order_status_counters` | **RECOVERY_CANDIDATE_READ_UTILITY** | no direct rollback; preserve current shop service and reports |
| `ton_inbox_status_counters` | **RECOVERY_CANDIDATE_READ_UTILITY** | no direct rollback; current deposit runtime summary/reports exist |
| `withdraw_status_counters` | **RECOVERY_CANDIDATE_READ_UTILITY** | no direct rollback; current withdrawal list/report surfaces exist |

Вывод: массовый rollback `backend/app/crud/admin/*` **не выполняется**. Historical implementations смешивали operational read/status utilities с `tg_id`-business selectors и direct status mutations (`moderator_tg_id` и др.), несовместимыми с final `global_id`/state-machine canon. Safe compatibility entrypoints восстановлены отдельно; current Admin services/routes сохраняются.

## 5. Safe compatibility entrypoints restored

| Surface | Decision |
|---|---|
| `backend/app/init.py` → `create_app` | RESTORED_SAFE_COMPAT — startup compatibility facade; canonical object remains app.main.app |
| `backend/app/database.py` → `get_engine, get_session_factory` | RESTORED_SAFE_COMPAT — historical DB import facade; canonical implementation remains database_core |
| `backend/app/core/decimal_utils.py` → `d8` | RESTORED_SAFE_COMPAT — historical decimal helper re-export |
| `backend/app/models/order_models.py` → `ShopOrder` | RESTORED_SAFE_COMPAT — historical ORM import re-export to shop_models.ShopOrder |
| `backend/app/bot/states.py` → `FSM state public API` | RESTORED_SAFE_COMPAT — compatibility re-export to app.bot.fsm |
| `backend/app/bot/handlers/admin/admin__main__handlers.py` → `handler, router, kb_admin_entry, ADMIN_HUB_LABEL` | RESTORED_SAFE_COMPAT — historical Admin bot entrypoint facade |
| `backend/app/scheduler/scheduler_context.py` → `TickContext` | RESTORED_SAFE_COMPAT — scheduler compatibility data object |
| `backend/app/scheduler/scheduler_errors.py` → `SchedulerError, JobTimeout` | RESTORED_SAFE_COMPAT — scheduler compatibility exceptions |
| `backend/app/scheduler/scheduler_core.py` → `tick` | RESTORED_SAFE_COMPAT — delegates to current SchedulerService.run_single_tick |
| `backend/app/scheduler/tasks_maintenance.py` → `run_once` | RESTORED_SAFE_COMPAT — re-export to current tasks_autorestart.run_once |
| `backend/app/services/admin/admin_rbac.py` → `RBAC.is_superadmin` | RESTORED_SAFE_COMPAT — pure role compatibility helper; no separate authorization source |

Прямо **не восстановлены** как legacy implementation:

- `backend/app/core/deps.py` legacy facade с `get_current_tg_id` — конфликт с final owner canon.
- `backend/app/crud/transfers_crud.py` — historical business filters по `tg_id`.
- `backend/app/schemas/ranks_schemas.py` — historical tg-owned rank schema, заменён current global_id rank contracts.
- `backend/app/services/nft_requests_service.py` — historical manual claim path записывал tg-owned shop/admin metadata; current reconciliation/shop/NFT services являются каноническим контуром.
- historical Admin CRUD direct mutations — не возвращаются без отдельного global_id-native redesign/ТЗ.

## 6. Bonus Awards — почему нет отдельной Admin page/route

Проверка current HEAD и historical `v171.89` подтверждает: Bonus Awards существовал как **service/facade capability**, но отдельного dedicated Admin HTTP-route и отдельной Admin frontend page для Bonus Awards в `v171.89` уже не было. Поэтому утверждение «cleanup отключил существующий Bonus route/page» было бы неверным.

Current preserved surface:

- `contracts/admin_contract.py` — `BonusAwardFilters`;
- `admin_facade.py` — `list_bonus_payouts`;
- `admin_withdrawals_service.py` — legacy Bonus Awards service compatibility.

Предыдущий дефект состоял в удалении service/contract symbols как supposedly unused compatibility; эти protected capabilities были восстановлены в cycle 1714. Создание отдельной Bonus Admin page/route сейчас было бы **новой продуктовой интеграцией**, а не восстановлением доказанно существовавшего UI.

## 7. Backend routes без найденного direct Admin frontend caller

Статус для всех пунктов: **STATIC_NO_FRONTEND_CALLER_FOUND — PRESERVE**. Это не доказательство неиспользования runtime/external/operator клиентами и не разрешение на удаление.

| Route | Finding |
|---|---|
| `/admin/observability/events` | Operational observability endpoint; no direct frontend caller found in static source audit. |
| `/admin/reports/bank` | Specialized report API; no direct frontend caller found. |
| `/admin/reports/deposits` | Specialized report API; no direct frontend caller found. |
| `/admin/reports/panels` | Specialized report API; no direct frontend caller found. |
| `/admin/reports/users` | Specialized report API; no direct frontend caller found. |
| `/admin/reports/withdrawals` | Specialized report API; no direct frontend caller found. |
| `/admin/shop/items/set-price` | Admin Shop operational endpoint; UI currently uses upsert/status/delete surfaces. |
| `/admin/tasks/{task_id}` | Item-level task route; no direct frontend caller found in current Admin pages. |

Дополнительные observations:

- `/shopfront/profile`: generated frontend seam существует, но использования этого constant в текущем frontend source audit не найдено — **RECOVERY/INTEGRATION CANDIDATE**, не удалять backend route.
- health/readiness/db/runtime endpoints по назначению operational и могут не иметь UI caller — **EXPECTED_NO_UI**.
- `/auth/ton/challenge`, deposit/shop compatibility/public API surfaces нельзя объявлять unused только по отсутствию прямого literal caller; они сохраняются.

## 8. Docs/pages vs code audit — найденные несоответствия

### 8.1 Admin route map — CONFIRMED STALE DOCUMENTATION

`docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md` содержал legacy paths (`/admin/docs/history/legacy_artifacts/reports/overview`, legacy shop order paths и др.), которых нет в current static exported OpenAPI. В cycle 1716 route map актуализирован по current `backend/openapi/openapi.json`.

### 8.2 Ranks referral leaderboard — RECOVERY CANDIDATE

Backend current OpenAPI содержит `/ranks/referrals/my-plus-top/me` и `/ranks/referrals/top/me`. Current Ranks frontend service/UI использует overall leaderboard routes; отдельный referral-ranking mode/filter, описываемый frontend recovery documentation, в current page не найден. Это **кандидат утраченного/неподключённого frontend capability**. В cycle 1716 автоматически не восстанавливается: требуется отдельный UI patch/acceptance, чтобы не расширять CI repair без решения.

### 8.3 Panels “nearest expiration” — CANON/UI MISMATCH, NOT LOST FUNCTION

Current Panels page содержит отдельное отображение ближайшего expiration, тогда как актуальный пользовательский UI-канон требует получать эту семантику сортировкой списка без отдельного дублирующего блока. Это не утраченная функция; это отдельный UI cleanup candidate и в cycle 1716 не меняется.

### 8.4 Shop USDT — EXPLICITLY PENDING DESIGN

Frontend recovery docs требуют отдельного объяснения/approval exact USDT method. Поэтому отсутствие дополнительной реализации не классифицируется как подтверждённая потеря и не восстанавливается самовольно.

### 8.5 Referrals/Profile/Exchange/Panels basic functions

В ходе source audit direct evidence их current frontend/backend surfaces найдено; они не классифицированы как потерянные.

## 9. Function-presence control

Созданы:

- `contracts/application_function_surface_v1.json` — fail-closed registry: all current exported OpenAPI paths/operations, all frontend page files, required SSOT/core files и critical public/operational/background/Admin/compatibility Python symbols.
- `tests/architecture/test_application_function_surface_manifest.py` — CI control против случайного уменьшения registered surface. Production modules не импортируются; test читает source/manifest. **В cycle 1716 тест не запускался.**

Назначение: любое future intentional removal сначала требует явного изменения manifest/SSOT в том же approved ТЗ. «Нет caller» не является достаточным основанием.

## 10. Итоговый список confirmed/recovery outcomes

**RESTORED_SAFE_COMPAT:** startup facade, DB facade, decimal helper, ShopOrder re-export, FSM facade, Admin bot main facade, scheduler compatibility objects/entrypoint/maintenance, pure `RBAC.is_superadmin`.

**CONFIRMED STALE DOC:** Admin route map.

**RECOVERY CANDIDATE:** referral leaderboard frontend mode/filter; selected historical Admin read/status utilities that cannot be safely rolled back from tg_id-era implementation; `/shopfront/profile` frontend linkage.

**PRESERVE WITHOUT FRONTEND CALLER:** listed Admin observability/report/shop/task APIs and operational/public routes.

**NOT RESTORED BY CANON:** tg_id business selectors, migration-control/read-switch infrastructure, legacy direct Admin mutations, tg-owned NFT manual-claim implementation.

## 11. Verification status

Ни один локальный test/lint/type/build/Alembic/CI/guard не запускался. Function-presence test только создан. Все изменения v173.40 требуют следующего exact-head GitHub CI.

**PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED**
