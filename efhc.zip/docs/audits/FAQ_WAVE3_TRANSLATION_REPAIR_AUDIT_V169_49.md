# FAQ wave-3 translation repair audit — v169_49

## Verdict

PASS as a focused FAQ wave-3 translation/status repair.

## Evidence

- `docs/SSOT/faq_ssot/*/faq_*.json` updated for wave-3 languages.
- `docs/SSOT/faq_ssot/*/faq_*.md` regenerated from JSON.
- `frontend/src/data/faq/catalogs.ts` regenerated from SSOT.
- `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` updated from `NEEDS_WAVE3_REVIEW` to `WAVE3_REPAIRED_PENDING_HUMAN_REVIEW` for wave-3 languages.
- `reports/generated/faq_wave3_translation_repair_v169_49.json` records post-repair identical-question/answer counts.
- `tests/architecture/test_faq_wave3_translation_status_repair.py` guards the repair.

## Confirmed after repair

- 13 FAQ JSON files exist and are valid.
- 13 FAQ MD files exist.
- Every language has 20 sections and 250 Q&A items.
- No non-English FAQ answer remains identical to English.
- Remaining identical questions are allowed canonical level names only: items 221-232.
- The frontend FAQ catalog is generated from the repaired SSOT.

## Limits

No browser screenshot verdict, GitHub CI green, frontend build/typecheck or full human translation certification is claimed.
