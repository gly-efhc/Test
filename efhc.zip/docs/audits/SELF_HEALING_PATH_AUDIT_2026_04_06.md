# SELF_HEALING_PATH_AUDIT_2026_04_06

Статус: AUDIT / PROOF

## Назначение

Документ фиксирует доказательную карту для цикла 426/429:
self-healing контур после лечения energy/sync путей.

## Охват

### 1. Energy generation
- `backend/app/services/energy_service.py`
- `_begin_tx` больше не рекурсивен; чистая сессия использует `await db.begin()`.

### 2. Snapshot resync
- `backend/app/routes/sync_routes.py`
- `_enqueue_resync_energy` больше не содержит `await db.commit()` внутри SQL-строки.

### 3. Scheduler recovery
- `scheduler_task_log` используется как очередь fallback-задач
  с `task_type='resync_user_energy'` и статусом `queued`.

## Что должен доказывать тестовый слой

- `_begin_tx` не вызывает сам себя в else-ветке.
- `sync_routes` ставит `resync_user_energy` через валидный SQL-path.
- self-healing охватывает generation, snapshot resync и scheduler recovery.
