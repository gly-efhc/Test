# Cycle 1007 — notification/template manual repair

Status: done.
Date: 2026-04-25.
Scope: localization range 983-1022, cycle 1007.

## Purpose

Cycle 1007 repairs the confirmed notification/template tails found in
cycle 1006. This is a bounded manual repair pass: it improves live
notification fallback behavior without pretending that every frontend
hardcoded string has already been migrated.

## Repairs completed

### Shop order Telegram notifications

The shop order notification service no longer uses
only Russian text for payment success/error Telegram notifications.

The service now has explicit 13-language text buckets for:

- `success`;
- `error`.

The service resolves language from order `extra` first and then from
`efhc_core.users.meta`. Unknown or absent language falls back
to English,
which follows the player-facing fallback canon.

### Withdraw outcome promo fallback

The outcome service already had 13-language withdraw
comment defaults. Cycle 1007 extended withdraw promo
fallback buckets from
three languages to all 13 active EFHC Bot locales.

Affected promo buckets:

- `title`;
- `body`;
- `cta_label`.

### Task moderation templates

The tasks service already had 13-language defaults
for task moderation prefixes and fallback notes. Cycle 1007
verified this
with a dedicated guard and kept the existing locale-aware
system-template
lookup.

## Admin/operator boundary

Admin notifications remain Russian-first because they are operator/admin
surface. This is not a defect under the language canon.

## Guard

Added:

`ops/i18n/audit_notification_template_repair.py`

The guard checks:

- Python syntax for the relevant files;
- shop order notification buckets across 13 languages;
- withdraw comment fallback buckets across 13 languages;
- withdraw promo fallback buckets across 13 languages;
- task moderation template buckets across 13 languages.

## Boundary

Cycle 1007 does not claim full frontend hardcoded-string repair.
That work
belongs to cycles 1008-1010.
