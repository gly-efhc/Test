# Money-sensitive continuity program 906-910

## Purpose
Cycles 906-910 are treated as one linked hardening program, not as five
isolated tasks.

## Shared invariants
Every cycle in 906-910 must check the same linked layer:
- state names
- CTA
- return path
- canonical center
- outcome continuity

## Cycle map
### 906 — One-Profile role matrix hardening
Focus:
- Telegram / Hub / Browser-Shop / Web-Profile / ProfileModal role clarity

### 907 — Launcher -> outcome continuity contract
Focus:
- start state
- active intent
- terminal state
- next recommended action
- canonical return path
- latest outcome

### 908 — Payment intents product state machine
Focus:
- product-level state names and surface mapping

### 909 — Browser-Shop runtime states UX pass
Focus:
- first entry
- repeat entry
- success
- failed
- expired
- pending
- manual review

### 910 — Active intent / resume / return integration
Focus:
- latest active payment in Web-Profile
- resume flow from Browser-Shop
- terminal return path back to canonical center

## Controlled mode pre-decision
- Manual EFHC deposits remain in controlled mode until cycle 913.
- Cycle 913 must confirm or lift this restriction after a direct audit.
