# Cycle 968 — Browser-Shop payment instruction clarity

## Findings
The storefront had the required payment data, but instruction clarity after
intent creation still relied too much on implicit understanding.

## Applied hardening
- Added a bounded instruction block after payment details.
- The user now sees what to do after sending payment, when to wait, and where
  to verify the canonical result.

## Verdict
Instruction clarity is improved without changing payment engine semantics.
