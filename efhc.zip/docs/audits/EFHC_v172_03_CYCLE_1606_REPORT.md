# Отчёт цикла 1606 — API-контракт global_id

## Выполнено

Создан воспроизводимый contract fixture, который объединяет backend
Pydantic DTO, изолированную FastAPI/OpenAPI schema и frontend branded
DTO. Все внешние значения `global_id` остаются строками и сохраняют
ведущие нули.

Добавлены runtime/type tests и fail-closed guard против integer schema,
неопределённого `user_id`, преждевременного route wiring и изменения
Alembic chain.

## Не выполнялось

Не менялись активные API routes, PostgreSQL schema/data, primary key,
financial ownership, balances, panels, kWh, transactions, backfill,
dual-write и read switch.

## Следующий цикл

`1607 — Cross-language разделение GlobalId и TelegramId`.

После завершения 1606 остаётся `94` цикла до цикла 1700 включительно.

## Итог тестирования

- exact-tree collection: `2899`;
- `PASSED`: `2727`;
- `SKIPPED`: `172`;
- `FAILED`: `0`;
- `ERRORS`: `0`.

Пропуски: 95 browser E2E, 72 real PostgreSQL integration,
4 Postgres-only CI и 1 проверка без `DATABASE_URL`. Skip не считается
реальным PostgreSQL или Chromium proof.

Frontend release-assets: PASS, 29 файлов. Полный Next.js build и
performance budgets не выполнены: offline npm cache не содержит `zod`,
а `.next/build-manifest.json` отсутствует.

PostgreSQL reconciliation: `БЛОКИРОВАНО_СРЕДОЙ`; backfill, dual-write,
read switch и financial ownership switch остаются `false`.

## Release mirror

Release-архив содержит 756 ZIP entries. Проверены 755 внутренних
checksum и 753 source-backed файла; ошибок checksum, отсутствующих
source и SHA-256 расхождений нет. Release contract: 12 passed,
1 environment-dependent skip.

## Статус

`LOCAL_GLOBAL_ID_API_CONTRACT_READY / PG-0_REQUIRED /
NOT_PRODUCTION_RELEASE_READY`.
