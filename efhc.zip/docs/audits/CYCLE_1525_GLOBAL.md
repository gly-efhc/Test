# ТЗ: Исправление новых ошибок широкого аудита kwarg/signature mismatch

## Цикл 1525 — Global Signature Drift Fix / Panels Pagination P0 / Bot-NFT-Scheduler Runtime Hardening

Архив-источник:  
`v171.05` / актуальный backend-архив после цикла 1524

Режим работы:  
**P0-FIX / SIGNATURE-DRIFT-CLOSURE / RUNTIME-TEST-HARDENING / MYPY-SCOPE-EXPANSION / NO ECONOMY CHANGES**

Главная цель:  
Закрыть все новые ошибки, найденные широким аудитом по всей backend-кодовой базе:

```text
P0-PANELS-PAGINATION-CURSOR-TYPEERROR
P1-SCHEDULER-ARCHIVE-PANELS-DOUBLE-TYPEERROR
P1-BOT-REFERRAL-STATS-TYPEERROR
P1-BOT-RANKS-DOUBLE-BUG-SILENTLY-SWALLOWED
P1-NFT-ROUTES-WALLET-HAS-NFT-TYPEERROR
P2-ADMIN-FORMAT-DECIMAL-KWARG-MISMATCH
P1-MYPY-SCOPE-TOO-NARROW
```

---

# 1. Текущий статус

По результатам широкого аудита:

```text
P0: FOUND
P1: multiple open findings
P2/P3: open formatting issue
Root cause: function signature drift + narrow mypy scope + missing runtime tests
Production ready: NO
Release ready: NO
```

Ключевой системный вывод:

```text
CI/mypy не защищает весь backend от kwarg/signature mismatch, потому что mypy scope слишком узкий.
```

---

# 2. Жёсткие ограничения

Запрещено:

- менять экономику EFHC;
- менять цены, курсы, бонусные формулы, VIP-правила, начисления;
- менять бизнес-смысл panels, referrals, ranks, NFT;
- отключать routes вместо исправления;
- скрывать ошибки через `except Exception` без логирования;
- добавлять `# type: ignore` вместо исправления сигнатуры;
- исправлять только тесты без исправления runtime-кода;
- закрывать P0/P1 grep-тестами без runtime tests;
- писать `CI green`, если полный gate не запускался;
- писать `production ready` или `release ready`, пока P0/P1 открыты.

---

# 3. Задача A — P0 Panels pagination cursor TypeError

## 3.1. Finding ID

```text
P0-PANELS-PAGINATION-CURSOR-TYPEERROR
```

## 3.2. Файл

```text
backend/app/services/panels_service.py
```

## 3.3. Проблема

`encode_cursor(payload: dict)` вызывается с несуществующими kwargs:

```python
next_cursor = encode_cursor(
    ts=_as_iso(last.act_at) or "",
    id=int(last.id),
)
```

## 3.4. Требуемое исправление

Заменить на:

```python
next_cursor = encode_cursor(
    {"ts": _as_iso(last.act_at) or "", "id": int(last.id)}
)
```

## 3.5. Scope

Исправление должно затронуть:

```text
list_user_panels
list_active_panels
list_archived_panels
GET /panels
```

## 3.6. Runtime-тесты

Добавить:

```text
tests/efhc_backend/panels/test_panels_pagination_runtime.py
```

Тесты:

1. Пользователь с `limit + 1` active panels получает HTTP 200, `items` length == limit, `next_cursor` not empty, no TypeError.
2. Пользователь с `limit + 1` archived panels получает корректный `next_cursor`.
3. Вторая страница по `next_cursor` возвращает оставшиеся элементы.
4. `decode_cursor(encode_cursor(payload))` roundtrip сохраняет `ts` и `id`.
5. Сценарий `len(rows) <= limit` возвращает `next_cursor = None`.

## 3.7. Acceptance

```text
GET /panels не падает при >limit panels
next_cursor формируется через dict payload
active/archive pagination работает
runtime tests green
```

---

# 4. Задача B — P1 Scheduler archive panels double TypeError

## 4.1. Finding ID

```text
P1-SCHEDULER-ARCHIVE-PANELS-DOUBLE-TYPEERROR
```

## 4.2. Файлы

```text
backend/app/scheduler/archive_panels.py
backend/app/services/panels_service.py
```

## 4.3. Проблемы

Проблема 1:

```python
archive_expired_panels(db, batch_size=...)
```

Функция ожидает:

```python
archive_expired_panels(db, *, limit=1000) -> int
```

Проблема 2:

```python
res.get("archived", 0)
```

Но `res` — это `int`.

## 4.4. Требуемое исправление

Исправить вызов:

```python
res = await archive_expired_panels(
    db,
    limit=int(S.PANELS_ARCHIVE_BATCH_SIZE),
)
```

Исправить возврат:

```python
return {"archived": int(res)}
```

## 4.5. Runtime-тесты

Добавить:

```text
tests/efhc_backend/scheduler/test_archive_panels_scheduler_runtime.py
```

Тесты:

1. `run_once()` не падает при наличии expired panels.
2. `run_once()` возвращает dict `{"archived": N}`.
3. Expired panels становятся `is_active=False` и `archived_at != None`.
4. Non-expired panels не архивируются.
5. `PANELS_ARCHIVE_BATCH_SIZE` применяется как `limit`.

## 4.6. Acceptance

```text
scheduler archive panels no TypeError
expired panels archived
return shape stable: {"archived": int}
runtime tests green
```

---

# 5. Задача C — P1 Telegram bot referral stats TypeError

## 5.1. Finding ID

```text
P1-BOT-REFERRAL-STATS-TYPEERROR
```

## 5.2. Файл

```text
backend/app/bot/handlers/referrals_handlers.py
```

## 5.3. Проблема

Вызов:

```python
get_referral_stats(db, global_id=global_id)
```

Функция ожидает:

```python
get_referral_stats(db, *, inviter_global_id: int)
```

## 5.4. Требуемое исправление

Заменить на:

```python
get_referral_stats(db, inviter_global_id=global_id)
```

## 5.5. Тесты

Добавить:

```text
tests/efhc_backend/bot/test_referrals_handler_runtime.py
```

Тесты:

1. Handler вызывает `get_referral_stats` с `inviter_global_id`.
2. Команда/раздел "Рефералы" не падает.
3. Пользователь получает непустой/корректный текст статистики.
4. При ошибке сервиса ошибка логируется и пользователь получает человекопонятное сообщение.

## 5.6. Acceptance

```text
referrals handler no TypeError
referral stats displayed
bot tests green
```

---

# 6. Задача D — P1 Telegram bot ranks double bug

## 6.1. Finding ID

```text
P1-BOT-RANKS-DOUBLE-BUG-SILENTLY-SWALLOWED
```

## 6.2. Файл

```text
backend/app/bot/handlers/ranks_handlers.py
```

## 6.3. Проблемы

Проблема 1:

```python
get_user_rank_and_top(..., limit=10)
```

Функция ожидает:

```python
top_limit=100
```

Проблема 2:

```python
me, top = await get_user_rank_and_top(...)
```

Функция возвращает 3 значения:

```text
me, top, meta
```

Проблема 3:

```python
except Exception:
    me, top = None, []
```

Ошибка скрывается без логирования.

## 6.4. Требуемое исправление

Исправить вызов:

```python
me, top, meta = await get_user_rank_and_top(
    db,
    global_id=global_id,
    top_limit=10,
)
```

Добавить логирование:

```python
logger.exception("Failed to load ranks for bot user")
```

Не скрывать ошибку полностью. Если нужна graceful degradation, она должна быть observable в логах.

## 6.5. Тесты

Добавить:

```text
tests/efhc_backend/bot/test_ranks_handler_runtime.py
```

Тесты:

1. Handler вызывает `get_user_rank_and_top` с `top_limit`.
2. Handler корректно принимает 3 значения.
3. При наличии top rows бот отображает ранги.
4. При исключении пишет `logger.exception`.
5. Пользователь получает fallback-сообщение, а не молчаливую пустоту.

## 6.6. Acceptance

```text
ranks handler no TypeError
no ValueError unpacking
non-empty ranks displayed when data exists
exceptions logged
bot tests green
```

---

# 7. Задача E — P1/P2 NFT public route TypeError

## 7.1. Finding ID

```text
P1-NFT-ROUTES-WALLET-HAS-NFT-TYPEERROR
```

## 7.2. Файл

```text
backend/app/routes/nft_routes.py
```

## 7.3. Проблема

Вызов:

```python
wallet_has_nft_in_collection(
    wallet_address=wallet,
    collection_address=collection,
)
```

Функция ожидает:

```python
wallet_has_nft_in_collection(wallet, collection=None)
```

## 7.4. Требуемое исправление

Исправить на:

```python
wallet_has_nft_in_collection(wallet, collection)
```

или:

```python
wallet_has_nft_in_collection(wallet=wallet, collection=collection)
```

## 7.5. Дополнительное решение по статусу route

Проверить, является ли `GET /nft/has_vip`:

```text
active public API
debug route
legacy diagnostic route
```

Если active:

- оставить route;
- добавить тест;
- документировать.

Если debug/legacy:

- пометить как diagnostic/internal;
- оставить только при наличии auth/rate-limit;
- либо удалить отдельным решением.

## 7.6. Тесты

Добавить:

```text
tests/efhc_backend/routes/test_nft_routes_runtime.py
```

Тесты:

1. `GET /nft/has_vip` не падает с TypeError.
2. Valid wallet + mocked NFT checker → expected true/false.
3. Missing wallet param → 422/400.
4. Invalid wallet format → controlled error, не 500.
5. Route status documented: active/diagnostic/legacy.

## 7.7. Acceptance

```text
GET /nft/has_vip no TypeError
route behavior documented
route tests green
```

---

# 8. Задача F — P2 admin decimal formatting mismatch

## 8.1. Finding ID

```text
P2-ADMIN-FORMAT-DECIMAL-KWARG-MISMATCH
```

## 8.2. Файлы

```text
backend/app/routes/admin_observability_routes.py
backend/app/routes/admin_reports_routes.py
```

## 8.3. Проблема

Вызов:

```python
format_decimal_str(value, places=8)
```

Функция ожидает:

```python
format_decimal_str(value, decimals=8)
```

## 8.4. Требуемое исправление

Заменить все:

```python
places=8
```

на:

```python
decimals=8
```

для `format_decimal_str`.

## 8.5. Тесты

Добавить/расширить:

```text
tests/efhc_backend/admin/test_admin_reports_decimal_formatting.py
```

Тесты:

1. Admin reports форматируют decimal через `decimals=8`.
2. Admin observability форматирует decimal через `decimals=8`.
3. Нет fallback на raw `str(value)` из-за TypeError.
4. Output соответствует ожидаемому truncation/rounding.

## 8.6. Acceptance

```text
no places kwarg passed to format_decimal_str
admin numeric formatting stable
tests green
```

---

# 9. Задача G — системная защита: расширить mypy scope

## 9.1. Finding ID

```text
P1-MYPY-SCOPE-TOO-NARROW
```

## 9.2. Проблема

mypy не проверяет большую часть backend-кода, где найдены runtime-баги.

## 9.3. Требуемое изменение

В `pyproject.toml` или конфигурации CI расширить mypy coverage.

Минимальный первый шаг — добавить файлы с найденными ошибками:

```text
backend/app/services/panels_service.py
backend/app/scheduler/archive_panels.py
backend/app/bot/handlers/referrals_handlers.py
backend/app/bot/handlers/ranks_handlers.py
backend/app/routes/nft_routes.py
backend/app/routes/admin_observability_routes.py
backend/app/routes/admin_reports_routes.py
```

Предпочтительный вариант:

```text
backend/app/services
backend/app/routes
backend/app/bot
backend/app/scheduler
```

Итоговая цель:

```text
backend/app
```

## 9.4. Если полный mypy сразу слишком шумный

Допускается staged rollout:

```text
cycle 1525: найденные файлы + critical services/routes
cycle 1526: services/routes/bot/scheduler
cycle 1527: full backend/app
```

Но нужно добавить architecture guard уже сейчас.

## 9.5. Acceptance

```text
mypy проверяет все файлы, где были найдены новые kwarg mismatch bugs
mypy или architecture test ловит повтор этих ошибок
mypy report не вводит в заблуждение о реальном scope
```

---

# 10. Задача H — global signature drift architecture test

## 10.1. Новый тест

Добавить:

```text
tests/architecture/test_backend_signature_drift.py
```

## 10.2. Что проверять

AST-тест должен:

1. Строить карту функций в `backend/app`.
2. Проверять call-site keyword arguments.
3. Игнорировать функции с `**kwargs`.
4. Учитывать methods/classes/import aliases там, где возможно.
5. Минимум гарантированно покрывать найденные функции:

```text
encode_cursor
archive_expired_panels
get_referral_stats
get_user_rank_and_top
wallet_has_nft_in_collection
format_decimal_str
```

6. Падать, если кто-то снова передаст:
   - `encode_cursor(ts=..., id=...)`;
   - `archive_expired_panels(batch_size=...)`;
   - `get_referral_stats(global_id=...)`;
   - `get_user_rank_and_top(limit=...)`;
   - `wallet_has_nft_in_collection(wallet_address=..., collection_address=...)`;
   - `format_decimal_str(places=...)`.

## 10.3. Acceptance

```text
pytest tests/architecture/test_backend_signature_drift.py -q
```

должен проходить после фикса и падать на исходной версии с текущими багами.

---

# 11. Задача I — regression tests for all findings

Добавить один summary test file:

```text
tests/architecture/test_cycle1525_signature_regressions.py
```

Проверить, что:

```text
P0 panels cursor fixed
scheduler archive signature fixed
bot referrals signature fixed
bot ranks signature/unpacking fixed
nft route signature fixed
admin decimal formatting fixed
mypy scope includes fixed files
```

---

# 12. Документация

Создать/обновить:

```text
docs/NORM/CYCLE_1525_GLOBAL_SIGNATURE_DRIFT_FIX_REPORT.md
docs/NORM/PANELS_PAGINATION_CURSOR_RUNTIME_PROOF.md
docs/NORM/SCHEDULER_ARCHIVE_PANELS_RUNTIME_PROOF.md
docs/NORM/BOT_REFERRALS_RANKS_RUNTIME_PROOF.md
docs/NORM/NFT_ROUTE_RUNTIME_PROOF.md
docs/NORM/MYPY_SCOPE_EXPANSION_PLAN.md
docs/NORM/BACKEND_SIGNATURE_DRIFT_GUARD.md
KERNEL.md
HEALER_ATLAS.md
map_element.md
```

## 12.1. В отчёте обязательно указать

```text
finding id
file/line
root cause
exact fix
tests added
whether runtime-tested
whether mypy now covers it
whether architecture guard covers it
CI status
remaining risk
```

---

# 13. Обязательные команды проверки

Полный gate:

```bash
ruff check .
mypy backend/app
bandit -r backend/app
pytest
npm run build
```

Targeted tests:

```bash
pytest tests/efhc_backend/panels/test_panels_pagination_runtime.py -q
pytest tests/efhc_backend/scheduler/test_archive_panels_scheduler_runtime.py -q
pytest tests/efhc_backend/bot/test_referrals_handler_runtime.py -q
pytest tests/efhc_backend/bot/test_ranks_handler_runtime.py -q
pytest tests/efhc_backend/routes/test_nft_routes_runtime.py -q
pytest tests/efhc_backend/admin/test_admin_reports_decimal_formatting.py -q
pytest tests/architecture/test_backend_signature_drift.py -q
pytest tests/architecture/test_cycle1525_signature_regressions.py -q
```

Re-run critical prior tests:

```bash
pytest tests/efhc_backend/admin/test_admin_withdrawals_list_runtime.py -q
pytest tests/efhc_backend/admin/test_admin_withdrawals_hold_repair_runtime.py -q
pytest tests/efhc_backend/admin/test_admin_bank_bonus_debit_runtime.py -q
pytest tests/efhc_backend/nft/test_vip_nft_tonconnect_wallet_binding_sync.py -q
pytest tests/architecture/test_admin_money_call_signatures.py -q
pytest tests/architecture/test_db_drift_matrix.py -q
```

---

# 14. Acceptance criteria

Цикл 1525 считается закрытым только если:

```text
P0-PANELS-PAGINATION-CURSOR-TYPEERROR: CLOSED
P1-SCHEDULER-ARCHIVE-PANELS-DOUBLE-TYPEERROR: CLOSED
P1-BOT-REFERRAL-STATS-TYPEERROR: CLOSED
P1-BOT-RANKS-DOUBLE-BUG-SILENTLY-SWALLOWED: CLOSED
P1-NFT-ROUTES-WALLET-HAS-NFT-TYPEERROR: CLOSED or downgraded with documented legacy/diagnostic status
P2-ADMIN-FORMAT-DECIMAL-KWARG-MISMATCH: CLOSED
P1-MYPY-SCOPE-TOO-NARROW: CLOSED or staged with explicit expansion plan and guard
global signature drift architecture test added and green
runtime tests added for each live path
full pytest green
ruff green
mypy green with expanded scope
bandit green
npm build green
docs updated
release remains blocked until live Telegram / real TonConnect / release proof
```

---

# 15. Минимальный expected diff

Ожидаемые изменения:

```text
backend/app/services/panels_service.py
backend/app/scheduler/archive_panels.py
backend/app/bot/handlers/referrals_handlers.py
backend/app/bot/handlers/ranks_handlers.py
backend/app/routes/nft_routes.py
backend/app/routes/admin_observability_routes.py
backend/app/routes/admin_reports_routes.py
pyproject.toml
tests/efhc_backend/panels/test_panels_pagination_runtime.py
tests/efhc_backend/scheduler/test_archive_panels_scheduler_runtime.py
tests/efhc_backend/bot/test_referrals_handler_runtime.py
tests/efhc_backend/bot/test_ranks_handler_runtime.py
tests/efhc_backend/routes/test_nft_routes_runtime.py
tests/efhc_backend/admin/test_admin_reports_decimal_formatting.py
tests/architecture/test_backend_signature_drift.py
tests/architecture/test_cycle1525_signature_regressions.py
docs/NORM/CYCLE_1525_GLOBAL_SIGNATURE_DRIFT_FIX_REPORT.md
docs/NORM/MYPY_SCOPE_EXPANSION_PLAN.md
KERNEL.md
HEALER_ATLAS.md
map_element.md
```

---

# 16. Финальный отчёт в чат

После выполнения дать отчёт строго на русском языке:

```text
Сделан цикл 1525 — Global Signature Drift Fix.

Закрыто:
1. P0 panels pagination cursor TypeError.
2. Scheduler archive panels double TypeError.
3. Telegram bot referrals TypeError.
4. Telegram bot ranks double bug.
5. NFT has_vip route TypeError.
6. Admin decimal formatting kwarg mismatch.
7. Mypy scope расширен / добавлен global signature drift guard.
8. Runtime-тесты добавлены для всех live-paths.
9. Regression tests добавлены.

Проверки:
ruff:
mypy:
bandit:
pytest:
npm run build:
targeted panels:
targeted scheduler:
targeted bot referrals:
targeted bot ranks:
targeted nft route:
targeted admin formatting:
signature drift guard:

Статус:
P0: CLOSED
P1: CLOSED or explicitly downgraded/documented
Production ready: NOT CLAIMED
Release ready: NOT CLAIMED
Release gate: FAIL-CLOSED до live Telegram / real TonConnect / release proof.
```

---

# 17. Следующий безопасный цикл после 1525

```text
Cycle 1526 — Mypy Full Backend Rollout / Live Telegram Bot Proof / Real TonConnect Proof
```

Цель следующего цикла:

```text
довести mypy coverage до всего backend/app,
проверить live Telegram bot flows,
проверить real TonConnect,
закрывать release readiness только доказательствами.
```
