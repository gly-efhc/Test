# Hardcoded UI Strings Audit and Replacement List — Cycle 872 — 2026-04-16

## Goal
Controlled audit-pass only. No mass copy migration in this cycle.

## High-risk groups

### Wallet & finance
- `Wallet connected` -> `STR_WALLET_CONNECTED`
- `Not connected` -> `STR_WALLET_NOT_CONNECTED`
- `Connecting...` -> `STR_WALLET_CONNECTING`
- `Wallet required` -> `STR_WALLET_REQUIRED`
- `Link your wallet` -> `STR_LINK_YOUR_WALLET`
- `Purchase failed` -> `STR_PURCHASE_FAILED`
- `Deposit success` -> `STR_DEPOSIT_SUCCESS`
- `Withdrawal pending` -> `STR_WITHDRAWAL_PENDING`
- `Insufficient funds` -> `STR_INSUFFICIENT_FUNDS`
- `Transaction in progress` -> `STR_TRANSACTION_IN_PROGRESS`

### Common actions
- `Confirm` -> `STR_CONFIRM`
- `Cancel` -> `STR_CANCEL`
- `Submit` -> `STR_SUBMIT`
- `Done` -> `STR_DONE`
- `Close` -> `STR_CLOSE`
- `Back` -> `STR_BACK`
- `Next` -> `STR_NEXT`
- `Skip` -> `STR_SKIP`
- `Retry` -> `STR_RETRY`
- `Refresh` -> `STR_REFRESH`
- `Reload` -> `STR_RELOAD`

### System errors and alerts
- `Something went wrong` -> `STR_SOMETHING_WENT_WRONG`
- `An unexpected error occurred` -> `STR_UNEXPECTED_ERROR`
- `Please try again later` -> `STR_TRY_AGAIN_LATER`
- `Access denied` -> `STR_ACCESS_DENIED`
- `Unauthorized` -> `STR_UNAUTHORIZED`
- `Login required` -> `STR_LOGIN_REQUIRED`
- `Session expired` -> `STR_SESSION_EXPIRED`

### Empty / loading states
- `No data found` -> `STR_NO_DATA_FOUND`
- `Nothing to show yet` -> `STR_NOTHING_TO_SHOW_YET`
- `No transactions here` -> `STR_NO_TRANSACTIONS_HERE`
- `Coming soon` -> `STR_COMING_SOON`
- `Search...` -> `STR_SEARCH`
- `Type to search` -> `STR_TYPE_TO_SEARCH`
- `Loading...` -> `STR_LOADING`
- `Please wait` -> `STR_PLEASE_WAIT`

### Rewards and social
- `Task reward` -> `STR_TASK_REWARD`
- `Referral bonus` -> `STR_REFERRAL_BONUS`
- `Daily claim` -> `STR_DAILY_CLAIM`
- `Points earned` -> `STR_POINTS_EARNED`
- `Shop purchase` -> `STR_SHOP_PURCHASE`
- `Panel purchase` -> `STR_PANEL_PURCHASE`
- `Limited offer` -> `STR_LIMITED_OFFER`
- `Discount applied` -> `STR_DISCOUNT_APPLIED`
- `Invite friends` -> `STR_INVITE_FRIENDS`
- `Share link` -> `STR_SHARE_LINK`
- `Copied to clipboard` -> `STR_COPIED_TO_CLIPBOARD`

## Audit policy
- This cycle only fixes canon and replacement mapping.
- Mass migration of UI copy must be done later as a dedicated pass.
- Runtime meaning must stay aligned with glossary and i18n keys.
