# FRONTEND CYCLE 1280 PANEL ACTIVATION AUDIT V168_78

Date: 2026-05-21
Archive: EFHC_Bot_v168_78_cycle_1280_panel_activation_cta.zip
Cycle: 1280

## Scope

Cycle 1280 locks the public Panels activation call to action.
The goal is not to change panel economy. The goal is to prevent
future visual drift around panel activation.

## Canon confirmed

- Panel activation costs 100 EFHC.
- Public Panels page must not hide the activation price.
- User-facing activation gate uses total EFHC available for
  activation: bonus balance plus main balance.
- Debit order remains bonus first, then main.
- Backend economic canon remains unchanged.
- No database or migration work was performed.

## Code changes

- `frontend/src/pages/panels.tsx`
  - added activation CTA markers;
  - added bonus-first/main-second marker;
  - uses `sumScaledDown(mainBalance, bonusBalance, 8)` for the
    UI availability check;
  - displays a compact activation note near the CTA.

- `frontend/src/styles/globals.css`
  - added `.efhc-panels-activation-note` style.

- `frontend/public/locale/*.json`
  - added activation price and debit-order keys.

## Guard

Added:

- `tests/architecture/test_panel_activation_cta.py`

The guard checks:

- CTA marker for `100 EFHC`;
- debit marker `bonus-first-main-second`;
- total-balance UI gate;
- locale keys;
- report and plan coverage.

## What was not changed

- Backend service logic.
- Bank ledger logic.
- Panel price.
- Panel activation endpoint.
- Database schema.
- Bottom navigation.
