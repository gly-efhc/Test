# Frontend visible functions audit — cycle 1209

## Purpose

Cycle 1209 creates the first full static inventory of visible frontend
functions.  The goal is not to remove features immediately.  The goal is
to prepare a controlled user-approved triage.

The user's rule is now clear:

- не менять шесть нижних кнопок;
- do not collapse canonical pages;
- compress subsections inside those pages;
- remove artifact/debug functions from the game process;
- move operator/admin logic to the Admin panel;
- ask before deleting uncertain user-facing functions.

## Generated evidence

Static inventory was generated here:

`reports/generated/frontend_visible_functions_inventory_1209.json`

The inventory contains:

- canonical bottom navigation routes;
- public pages;
- admin page count;
- all static button-like JSX entries found by source scan;
- a note that static route presence is not live click proof.

## Static counts

The generated inventory currently records:

- 14 public pages;
- 15 admin pages;
- 182 button-like JSX entries;
- public page entries;
- shared public component entries;
- admin component entries;
- admin page entries.

These numbers are a map for the next repair cycles.
They are not a release verdict.

## Triage model

Each visible user function must be classified as one of four states:

1. оставить;
2. удалить;
3. перенести в админку;
4. вынести на вопрос.

This is now the mandatory model before removing public UI functions.

## Canon preserved

The six bottom buttons remain canonical:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

The first Energy screen remains the general information screen for
progress and generation.  It is not a first-action button screen.

## Button failure diagnosis

The static route guard still does not show a global broken-route layer.
The more likely causes of non-reactive buttons are:

- Telegram runtime is absent;
- `global_id` is absent;
- wallet session is absent;
- a button is disabled by state;
- the action is async and lacks immediate feedback;
- an artifact/debug control looks like a public user function;
- the frontend is visually overloaded.

The next cycles must inspect this by page and function group.

## Dragon-style meaning

Dragon style is visual only.

EFHC keeps:

- its routes;
- its economic canon;
- its six bottom buttons;
- its page names;
- its functions until separately approved.

EFHC may adopt:

- compact game cards;
- progress bars;
- resource chips;
- stronger visual hierarchy;
- hidden secondary controls;
- browser/PWA shell.

## Next repair direction

The next visible-function work should proceed page by page:

1. Energy: progress, generation, rank progress.
2. Panels: canonical page, compress secondary controls.
3. Exchange: canonical page, clarify inactive states.
4. Tasks: Dragon-like compact task cards.
5. Referrals: Dragon-like compact referral cards.
6. Ranks: progress-card model and leaderboard separation.
7. Profile/Wallet: detailed separate Wallet design approval.
8. Browser-Shop: keep Web3-style page through HUB.
9. Admin: keep admin-only surfaces under Admin.

## Not claimed

This audit does not prove live click success.
It proves route and source visibility for the next repair cycle.
