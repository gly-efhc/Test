# EFHC Bot — Full i18n / Localization Audit Report
**Version:** v169.45 (archive: EFHC_Bot_v169_45_public_visual_trust_pass_profile_wallet_history_faq.zip)
**Audit date:** 2026-06-02
**Mode:** AUDIT ONLY — no code was modified
**Auditor:** Claude Code, Senior Localization / i18n Auditor role

---

## 0. Methodology & Script Execution Status

| Script / Test | Result | Notes |
|---|---|---|
| `ops/i18n/audit_locale_coverage.py` | ✅ PASS | 1163 keys, all 13 langs match |
| `ops/i18n/audit_all_locale_parity.py` | ❌ FAIL | 5 empty keys (all langs), 2 HI placeholder drifts |
| `ops/i18n/audit_locale_inventory.py` | ✅ RAN | Outputs identical-to-EN counts |
| `ops/i18n/audit_ru_locale_value_quality.py` | ✅ RAN | 71 unexpected identical values |
| `ops/i18n/audit_uk_locale_value_quality.py` | ✅ RAN | ~50 unexpected identical |
| `ops/i18n/audit_de_locale_value_quality.py` | ✅ RAN | ~90 unexpected identical |
| `ops/i18n/audit_hi_locale_value_quality.py` | ✅ RAN | ~100 unexpected identical |
| `ops/i18n/audit_{fr,es,it,tr,pl,da,id,sw}_locale_value_quality.py` | ✅ RAN | Each produced unexpected identical list |
| `ops/i18n/audit_admin_ru_only.py` | ✅ PASS | 200 admin_ru keys, 0 raw keys, 0 empty |
| `ops/i18n/audit_no_admin_leak.py` | ✅ PASS | 0 admin key leaks into public |
| `ops/i18n/audit_faq_localization_consistency.py` | ✅ PASS | 13 langs, 20 sections, 250 Q&A each |
| `ops/i18n/audit_player_surface_matrix.py` | ✅ PASS | 26 files checked |
| `ops/i18n/audit_frontend_hardcoded_strings.py` | ❌ ERROR | "work pass report missing" — AssertionError |
| `ops/i18n/audit_bot_texts_parity.py` | ❌ ERROR | `spec_from__file__location` typo in script |
| `ops/i18n/audit_notifications_templates_inventory.py` | ❌ ERROR | "work pass inventory report missing" |
| `ops/i18n/audit_forbidden_gaming_contour.py` | ❌ ERROR | `rg` (ripgrep) not installed in env |
| Node scripts (`audit_identical_to_english.js`, `audit_locale_placeholders.js`) | ❌ NOT RUN | Node.js not available |
| Architecture tests (pytest) | ❌ NOT RUN | pytest not installable in network-isolated env |
| Architecture tests (manual re-run) | ✅ PASS | `test_frontend_translation_coverage`, `test_lang_code_uk_only` — PASS |
| `python ops/canon_guard.py` | ❌ NOT RUN | Would require full project deps |

**Impact of failed scripts:** The failing audit scripts for hardcoded strings and notifications are partially compensated by static analysis performed manually in this audit (see Sections 6, 11). The bot-texts parity script has a code typo (`spec_from__file__location`) that prevents it from running; the bot texts were audited manually instead.

---

## 1. Language Coverage Matrix

All 13 required locale files exist and are JSON-valid.

| Language | File exists | JSON valid | Total keys | Missing vs EN | Extra vs EN | Empty values | Status |
|---|---|---|---|---|---|---|---|
| en | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| ru | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| uk | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| de | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| fr | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| es | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| it | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| tr | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| pl | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| da | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| hi | ✅ | ✅ | 1163 | 0 | 0 | 5 + 2 PH | ❌ placeholder drift |
| id | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |
| sw | ✅ | ✅ | 1163 | 0 | 0 | 5 | ⚠️ 5 empty |

**Note:** `audit_locale_inventory.py` reports 1163 keys; `audit_locale_coverage.py` reports 1163 keys. Consistent.
Between v41 and v45 locale files are **identical** — no translations were added or changed in this release.

---

## 2. Empty Values — All 13 Languages (CRITICAL)

The following 5 keys are **empty strings `""`** in every single locale file, including English:

| Key | Expected purpose | Impact |
|---|---|---|
| `energy.hub_action` | Hub action button label on energy screen | Button renders blank |
| `energy.hub_action_note` | Sub-note for hub action | Note renders blank |
| `energy.profile_wallet_action` | Wallet action button label | Button renders blank |
| `energy.profile_wallet_note` | Sub-note for wallet action | Note renders blank |
| `profile.independent_shell_badge` | Badge label in profile shell | Badge renders blank |

**Severity: HIGH** — These are user-visible UI elements. Blank labels appear in all 13 languages. These are not intentional (no canonical reason found in docs for blank values).

**Recommended fix:** Fill these 5 keys in English first, then propagate translations.

---

## 3. Placeholder Mismatch — Hindi (CRITICAL)

| Key | EN value | HI value | Problem |
|---|---|---|---|
| `wallet.linked_wallets_count` | `'Linked wallets: {count}'` | `'लिंक किए गए वॉलेट'` | `{count}` placeholder REMOVED |
| `withdraw.request_number` | `'Withdraw request #{id}'` | `'अनुरोध संख्या'` | `{id}` placeholder REMOVED |

**Severity: HIGH** — HI users will see wallet count as `"लिंक किए गए वॉलेट"` with no number, and withdrawal request with no ID. Runtime will render broken UI or wrong data.

**Recommended fix:** Restore placeholders:
- `wallet.linked_wallets_count` (hi): `'लिंक किए गए वॉलेट: {count}'`
- `withdraw.request_number` (hi): `'अनुरोध #{{id}}'`

---

## 4. i18n Key Parity Matrix — Summary

Key parity is **perfect** (0 missing, 0 extra in all languages). All 1163 keys exist in all 13 locale files.

The parity guard (`audit_all_locale_parity.py`) is passing for key structure. Failures are value-level only (empty strings + placeholder drift).

---

## 5. Identical-to-English (Untranslated) — Full Audit

### 5.1 Allowlist status

The `identical_to_english_allowlist.json` contains only `exact_values` (brand terms like EFHC, TON, kWh) and `key_prefixes`. There is no explicit `always_identical_keys` list. The guard counts by exact-value matching.

### 5.2 Untranslated public-facing keys by language

The following counts represent **public-facing** keys that are still in English (value identical to `en.json`) after excluding admin prefixes and allowlisted brand terms:

| Language | True untranslated public keys | Fallback shown to user |
|---|---|---|
| ru | **52** | RU translation (correct) |
| uk | **88** | RU fallback (wrong) |
| de | **254** | RU fallback (wrong) |
| fr | **252** | RU fallback (wrong) |
| es | **252** | RU fallback (wrong) |
| it | **253** | RU fallback (wrong) |
| tr | **252** | RU fallback (wrong) |
| pl | **252** | RU fallback (wrong) |
| da | **253** | RU fallback (wrong) |
| hi | **259** | RU fallback (wrong) |
| id | **252** | RU fallback (wrong) |
| sw | **252** | RU fallback (wrong) |

### 5.3 Critical fallback issue — Canon violation

**CRITICAL FINDING:** `frontend/src/lib/i18n.ts` — `tFromDicts()` fallback chain:

```ts
dict[k] || ru[k] || embeddedRu[k] || embeddedEn[k] || humanizeMissingI18nKey(k)
```

The fallback goes to **Russian** before English. This violates `LANGUAGE_CANON_SSOT.md §4`:
> *"For player-facing surfaces the fallback language is English."*

**Practical impact:** A German user (DE) who encounters any of 254 untranslated keys will see **Russian text**, not English. For example:
- `energy.activate_panel_action` (DE=EN="Activate panel") → fallback = RU = "Активировать панель"
- `energy.available_kwh_chip` (DE=EN="Available kWh") → fallback = RU = "Доступно kWh"
- `portal.browser_shop.active_intent_error` (DE=EN="You already have...") → fallback = RU = "У вас уже есть..."

This affects **all 11 non-EN/RU languages** for **~187–209 keys** each.

**Severity: CRITICAL** — Player-facing surfaces mixing Russian into DE/FR/HI/SW/TR/PL/DA/IT/ES/ID/UK experience.

### 5.4 Domains with highest untranslated key counts (DE as reference)

| Domain | Untranslated keys |
|---|---|
| `portal` (Browser Shop) | 46 |
| `public_engagement` (Ranks preview, leaderboard) | 41 |
| `panels` (Panels activation, archive, interactive) | 27 |
| `public_profile_trust` (Trust layer, account center) | 26 |
| `profile` (Profile page elements) | 23 |
| `exchange` (Exchange interactive preview) | 18 |
| `energy` (Energy dashboard chips, buttons) | 17 |
| `history` (Filters, error states, reason labels) | 16 |
| `tasks` (Task buttons, demo tasks, help text) | 15 |
| `hub` (Hub action cards) | 8 |
| `wallet` (State map, error states) | 8 |
| `ranks` (Filters, labels) | 4 |
| `referrals` (Bonus rule, panels count) | 3 |
| `browser` (auth_needed) | 1 |
| `faq` (counts_summary) | 1 |

---

## 6. Frontend Hardcoded Strings Audit

### 6.1 Public-facing hardcoded strings

| File | Line | Text | Severity | Notes |
|---|---|---|---|---|
| `src/pages/app.tsx` | 587–591 | `"Проверяем доступ к Admin"`, `"Admin доступ закрыт"`, etc. | HIGH | Russian admin auth messages shown in app.tsx — accessible in main app shell |
| `src/components/ShopLayout.tsx` | 104 | `{t("profile.title") \|\| "Профиль"}` | MEDIUM | Russian fallback hardcoded as default for non-translated key |
| `src/data/faq/meta.ts` | 13–51 | Russian section titles as hardcoded strings in `faqMetaByLang.ru.*` | LOW | Expected for RU, but same structure for other langs — verified translated |
| `src/components/GlobalHeader.tsx` | 206 | `/* WalletGate action marker: Пополнить */` | INFO | Comment only, not user-facing |
| `src/features/browser-shop/BrowserShopPage.tsx` | 411 | `/* USDT и сложный Web3 runtime временно вырезаны */` | INFO | Comment only |

### 6.2 Admin hardcoded Cyrillic (978 lines across 33 files)

Per `LANGUAGE_CANON_SSOT.md §2`, admin/operator UI is **Russian-first by default**. The 978 hardcoded Cyrillic lines in admin components are **policy-compliant**. However, specific cases need attention:

**NOT policy-compliant (admin text exposed in public-adjacent areas):**

| File | Issue |
|---|---|
| `src/pages/app.tsx` (lines 587–591) | Russian admin auth messages in main `app.tsx` shell — shown to *any user* attempting access, not just authenticated admins |
| `src/components/AdminCharts.tsx` | Fallback title `"Графики админки"` — no concern if only admin-accessible |
| `src/components/AdminTable.tsx` | Fallback title `"Таблица админки"` — same as above |

**Policy-compliant (operator console, Russian-first is correct):**
- `AdminWithdrawalsMobileDecisionPanel.tsx`, `AdminTasksCatalogUxPanel.tsx`, `AdminSalePackagesPage.tsx`, `AdminReportsVisualDashboardPanel.tsx`, `AdminInteractiveBankDashboard.tsx` — all admin-only, Russian-first is canonical.

### 6.3 `audit_frontend_hardcoded_strings.py` — FAILED

Script requires a "work pass report" file not present in the archive. Manual fallback analysis performed above. **Audit confidence for hardcoded strings: PARTIAL** (manual static analysis, not exhaustive).

---

## 7. Backend Telegram Bot Text Audit

### 7.1 Structure

- **File:** `backend/app/bot/texts.py` (32 KB)
- **Languages:** All 13 (`en`, `ru`, `uk`, `de`, `fr`, `es`, `it`, `pl`, `tr`, `da`, `hi`, `id`, `sw`)
- **Keys:** 19 keys per language (all fully covered)
- **Fallback:** Russian → English → key (documented in module docstring)

### 7.2 Key coverage matrix

| Key | All 13 langs | Notes |
|---|---|---|
| `welcome` | ✅ | Placeholders: `{username}`, `{vip_flag}`, `{panels}`, `{avail_kwh}` |
| `menu` | ✅ | |
| `no_access` | ✅ | |
| `help` | ✅ | Multi-line commands list |
| `subscribe.required` | ✅ | Placeholder: `{channel}` |
| `panels.summary` | ✅ | Placeholders: `{count}`, `{per_sec}`, `{avail_kwh}` |
| `profile.header` | ✅ | |
| `profile.lines` | ✅ | Placeholders: `{global_id}`, `{vip_flag}`, `{panels}`, `{avail_kwh}`, `{total_kwh}` |
| `exchange.preview` | ✅ | Placeholders: `{kwh}`, `{efhc}` |
| `ranks.me` | ✅ | Placeholders: `{rank}`, `{total_kwh}` |
| `ranks.top.header` | ✅ | Placeholder: `{limit}` |
| `ranks.top.line` | ✅ | Placeholders: `{rank}`, `{username}`, `{total_kwh}` |
| `referrals.header` | ✅ | |
| `referrals.active.count` | ✅ | Placeholder: `{count}` |
| `referrals.inactive.count` | ✅ | Placeholder: `{count}` |
| `tasks.submitted` | ✅ | |
| `admin.entry` | ✅ | Admin-only (correct) |
| `admin.hub.entry` | ✅ | Admin-only (correct) |
| `faq.entry` | ✅ | |

### 7.3 Placeholder consistency (bot texts)

Manual check on `welcome`, `panels.summary`, `profile.lines`, `exchange.preview`, `ranks.top.line`: **all placeholders consistent across all 13 languages** ✅

### 7.4 Bot text quality issues (sampled)

The `audit_bot_texts_parity.py` script has a **code bug** (`spec_from__file__location` typo — should be `spec_from_file_location`). Manual quality check performed instead.

Bot text quality appears acceptable. The 19-key set is limited in scope (navigation layer only, as intended by module docs: "intentionally kept small and explicit because bot messages are trust-sensitive").

**Note on bot vs frontend divergence:** Bot texts and frontend locale files are **separate systems**. Bot uses `texts.py` with its own translations; frontend uses `locale/*.json`. There is no automated sync between them. This creates a risk of terminology drift (e.g., bot says "Panels: X" in one language format; frontend uses different phrasing). For the 13 audited bot keys, terminology appears aligned at the high level but was not exhaustively cross-checked for phrasing consistency.

---

## 8. FAQ Translation Audit

### 8.1 File coverage

All 13 languages have both JSON and MD files in `docs/SSOT/faq_ssot/`:

| Language | JSON | MD | Item count | Status |
|---|---|---|---|---|
| en | ✅ | ✅ | 250 | ✅ |
| ru | ✅ | ✅ | 250 | ✅ |
| uk | ✅ | ✅ | 250 | ✅ |
| de | ✅ | ✅ | 250 | ✅ |
| fr | ✅ | ✅ | 250 | ✅ |
| es | ✅ | ✅ | 250 | ✅ |
| it | ✅ | ✅ | 250 | ✅ |
| tr | ✅ | ✅ | 250 | ✅ |
| pl | ✅ | ✅ | 250 | ✅ |
| da | ✅ | ✅ | 250 | ✅ |
| hi | ✅ | ✅ | 250 | ✅ |
| id | ✅ | ✅ | 250 | ✅ |
| sw | ✅ | ✅ | 250 | ✅ |

### 8.2 Identical-to-English check

| Language | Identical questions | Identical answers | Severity |
|---|---|---|---|
| ru | 12 | 0 | ✅ (all 12 are rank names / technical labels) |
| uk | 12 | 0 | ✅ (same — rank names) |
| de | 32 | 21 | ⚠️ SEE BELOW |
| fr | 32 | 21 | ⚠️ SEE BELOW |
| es | 32 | 21 | ⚠️ SEE BELOW |
| it | 32 | 21 | ⚠️ SEE BELOW |
| tr | 32 | 21 | ⚠️ SEE BELOW |
| pl | 32 | 21 | ⚠️ SEE BELOW |
| da | 32 | 21 | ⚠️ SEE BELOW |
| hi | 38 | 21 | ⚠️ SEE BELOW |
| id | 32 | 21 | ⚠️ SEE BELOW |
| sw | 38 | 21 | ⚠️ SEE BELOW |

**Identical questions (32–38) breakdown:**
- 12 are rank level names (`Eco Initiate (0 kWh)`, `Hope Bringer (100 kWh)`, etc.) — **OK**, these are canonical brand names
- ~20 are genuine questions in English that should be translated (e.g., `"Why is the main wallet needed?"`, `"What is the bonus balance?"`, `"How do I understand the difference between Profile, Wallet, and History?"`)

**Identical answers (21) breakdown:**
All 21 identical answers are full English paragraphs about Profile/Wallet/History navigation (items 41–44, 53, 155–170, 238, 245). These are **not** acceptable as untranslated for DE/FR/HI/etc. users.

**Severity: HIGH** for 21 full FAQ answers still in English for 11 non-EN/RU/UK languages.

### 8.3 `TRANSLATION_STATUS.md` vs audit reality

The file claims all 13 languages "complete." The audit shows 21 identical answers and ~20 identical questions per non-EN/RU language. **The status file is inaccurate for the 11 wave-3 languages.**

### 8.4 FAQ frontend catalog vs SSOT

`frontend/src/data/faq/catalogs.ts` (1.6 MB) is a generated file. `audit_faq_localization_consistency.py` confirms 250 items per language. The frontend FAQ data appears properly generated from SSOT.

`frontend/src/data/faq/meta.ts` contains section title translations for all 13 languages directly in TypeScript — correct approach, no issues found.

---

## 9. Public UI Translation Surface Audit

Based on static analysis of changed files in v45 (profile, wallet, history, FAQ, ranks, tasks, referrals pages):

### 9.1 Key surface coverage by page

| Page / Feature | Uses t() | Hardcoded text | i18n gaps | Notes |
|---|---|---|---|---|
| `WebProfilePage.tsx` | 48 calls | 0 | energy/profile keys untranslated in 11 langs | Profile tabs OK |
| `ProfileWalletSection.tsx` | 17 calls | 0 | wallet.state_* keys untranslated in 11 langs | State map labels in EN only |
| `ProfileHistorySection.tsx` | 16 calls | 0 | history.filter_* untranslated in 11 langs | Filter tabs in EN only |
| `faq.tsx` page | 13 calls | 0 | — | Appears OK, delegates to FAQ catalog |
| `tasks.tsx` | 63 calls | 0 | tasks.button_claimed, demo tasks untranslated | Task buttons may appear in EN |
| `referrals.tsx` | 40 calls | 0 | referrals.bonus_rule_* untranslated | Bonus rule text in EN |
| `ranks.tsx` | 48 calls | 0 | ranks.filter_referrals, ranks.referrals untranslated | Filter in EN |
| `PublicProfileTrustLayer.tsx` | Uses t() | 0 | public_profile_trust.* 26 keys untranslated | Trust layer entirely in EN for 11 langs |
| `PublicPanelsActivationPreview.tsx` | Changed in v45 | Not checked | panels.* 27 keys untranslated | — |
| `PublicExchangeInteractivePreview.tsx` | Changed in v45 | Not checked | exchange.interactive_* untranslated | — |
| `PublicEnergyInteractiveOverview.tsx` | Changed in v45 | Not checked | energy.* 17 keys untranslated | — |

### 9.2 `FaqVerticalTree.tsx` — changed in v45

File changed between v41 and v45. Uses `useT()` hook. No hardcoded user-visible text found in component structure.

---

## 10. Admin UI Translation Audit

Per `LANGUAGE_CANON_SSOT.md §2`, admin UI is **Russian-first**. The 978 hardcoded Cyrillic lines across 33 admin files are **policy-compliant**.

| Admin page | Cyrillic lines | Policy | Status |
|---|---|---|---|
| `pages/admin/shop.tsx` | 107 | Russian-first operator | ✅ Compliant |
| `pages/admin/index.tsx` | 102 | Russian-first operator | ✅ Compliant |
| `pages/admin/bank.tsx` | 75 | Russian-first operator | ✅ Compliant |
| `features/admin/AdminSalePackagesPage.tsx` | 65 | Russian-first operator | ✅ Compliant |
| `pages/admin/tasks.tsx` | 57 | Russian-first operator | ✅ Compliant |
| etc. | ... | Russian-first operator | ✅ Compliant |

**Exception — NON-compliant:**

| File | Line | Text | Problem |
|---|---|---|---|
| `src/pages/app.tsx` | 587–591 | Russian admin auth messages | Located in MAIN APP shell, not admin-only route |

The admin auth messages in `app.tsx` lines 587–591 are shown to any user who somehow accesses the admin gate from the main shell. These Russian messages would appear to non-Russian users who are not admins.

---

## 11. Notification / Toast / Error Templates Audit

`audit_notifications_templates_inventory.py` failed with "work pass inventory report missing." Manual audit:

### 11.1 Frontend toast/error keys in locale files

Key observations from locale scan:
- `wallet.error_body`: `'Could not update wallet list...'` — untranslated in 11 langs (will show Russian)
- `portal.browser_shop.intent_create_failed`: `'Could not open the wallet. Try again.'` — untranslated in 11 langs
- `portal.browser_shop.active_intent_error`: `'You already have an unfinished payment...'` — untranslated in 11 langs
- `history.load_error`: `'Could not load history. Try again.'` — untranslated in 11 langs
- `exchange.amount_invalid_detail`, `exchange.amount_over_available`: error messages untranslated in 11 langs
- `exchange.confirm_exchange_detail`, `exchange.confirm_exchange_title`: confirmation modal untranslated in 11 langs

**Severity: HIGH** — Error messages and confirmation dialogs showing Russian to DE/FR/HI etc. users.

### 11.2 Backend notification templates

Backend `texts.py` does not include notification templates beyond the 19 bot text keys. Backend notifications beyond bot scope were not found in the archive (no `backend/app/bot/templates/` directory). **Coverage note:** Backend email/push templates (if any) were not found — not present in this archive.

---

## 12. Placeholder / Variable Consistency Audit

| Check | Result |
|---|---|
| All frontend locale placeholder mismatch | 2 found (HI: `{count}` and `{id}` removed) |
| Bot texts placeholder mismatch | 0 (all 19 keys consistent) |
| FAQ placeholder consistency | Not applicable (Q&A free-form text) |
| `{amount}`, `{balance}`, `{efhc}`, `{kwh}`, `{ton}` | No mismatches found in locale files |
| `{user}`, `{username}`, `{date}`, `{time}` | No mismatches found |
| `{count}`, `{id}`, `{rank}`, `{level}` | 2 mismatches in HI (see Section 3) |
| kWh/EFHC/TON unit translation | None found — units preserved correctly |
| `{{double-brace}}` format | Not used in frontend locales |
| `%s`, `%d` printf format | Not used |

---

## 13. Language System Architecture Issues

### 13.1 Fallback chain (CRITICAL — Canon violation)

**Location:** `frontend/src/lib/i18n.ts`, function `tFromDicts()`

**Problem:** The fallback chain is `dict → ru → embeddedRu → en → humanized_key`.

**Canon requirement** (`LANGUAGE_CANON_SSOT.md §4`): Player-facing fallback = **English**.

**Current behavior:** Any missing translation for DE/FR/HI/etc. silently shows **Russian** to the user.

**Fix required:**
```ts
// Current (wrong):
return dict[k] || ru[k] || embeddedRu[k] || embeddedEn[k] || humanizeMissingI18nKey(k);

// Correct (canon-compliant):
return dict[k] || embeddedEn[k] || humanizeMissingI18nKey(k);
```

Note: `ru[k]` and `embeddedRu[k]` must be removed from the fallback chain for player-facing surfaces.

### 13.2 Language selector

`SUPPORTED_LANGS` in `i18n.ts` lists all 13 languages with correct `uk` code (not `ua`). Language selector is correctly configured.

### 13.3 Test guard coverage gaps

Tests that exist (`test_frontend_translation_coverage.py`, `test_lang_code_uk_only.py`, etc.) cover key presence and `ua`/`uk` code. **No test exists** that:
- verifies the fallback chain uses English (not Russian) for player-facing surfaces
- detects that locale values identical to English for >10% of keys is a failure
- validates that placeholder `{count}` and `{id}` survive translation in all languages

---

## 14. Summary — Prioritized Findings

### CRITICAL (must fix before user-facing release)

| # | Finding | Affected | Fix |
|---|---|---|---|
| C1 | Fallback chain uses Russian instead of English | All 11 non-EN/RU languages | Remove `ru[k]` from `tFromDicts()` fallback |
| C2 | HI `wallet.linked_wallets_count` — `{count}` removed | Hindi users — wrong wallet count | Restore `{count}` in translation |
| C3 | HI `withdraw.request_number` — `{id}` removed | Hindi users — withdrawal ID missing | Restore `#{id}` in translation |
| C4 | 5 keys empty in ALL 13 languages (energy/profile badges) | All users | Fill `energy.hub_action`, `energy.hub_action_note`, `energy.profile_wallet_action`, `energy.profile_wallet_note`, `profile.independent_shell_badge` |

### HIGH (significant user impact)

| # | Finding | Affected | Fix |
|---|---|---|---|
| H1 | ~187–209 public-facing keys untranslated in 11 non-EN/RU langs → Russian shown | DE/FR/HI/SW/TR/PL/DA/IT/ES/ID/UK | Full translation pass per language |
| H2 | 21 FAQ answers identical to English in 11 languages | All FAQ users in those langs | FAQ translation pass for items 41–44, 53, 155–170, 238, 245 |
| H3 | Error/confirmation messages untranslated (wallet errors, shop errors, exchange confirmations) | 11 language users | Translate critical error keys |
| H4 | `app.tsx` Russian admin auth messages in main shell | Non-Russian non-admin users | Move to i18n key or use English |

### MEDIUM

| # | Finding | Affected | Fix |
|---|---|---|---|
| M1 | `audit_bot_texts_parity.py` has code bug (`spec_from__file__location`) | CI/CD guard broken | Fix typo to `spec_from_file_location` |
| M2 | `TRANSLATION_STATUS.md` incorrectly claims all 13 langs "complete" | Misleads future auditors | Update to reflect actual completion state |
| M3 | 20–26 FAQ questions in English for non-EN/RU langs (rank names are OK) | FAQ users | Translate the ~20 non-rank questions |
| M4 | `ShopLayout.tsx` fallback `|| "Профиль"` hardcoded Russian | Any language missing `profile.title` | Use `t("profile.title")` without fallback, or use EN fallback |
| M5 | `faq.counts_summary` untranslated in UK + 11 other langs | FAQ summary display | Translate key |

### LOW / INFO

| # | Finding | Affected | Fix |
|---|---|---|---|
| L1 | `audit_frontend_hardcoded_strings.py` requires "work pass report" to run | CI guard not usable | Remove the AssertionError precondition or generate report |
| L2 | `audit_notifications_templates_inventory.py` same precondition issue | CI guard not usable | Same fix |
| L3 | `audit_forbidden_gaming_contour.py` requires `rg` (ripgrep) | CI environment | Add ripgrep to CI deps |
| L4 | No test for fallback-chain canon compliance | Regression risk | Add `test_i18n_fallback_is_english.py` architecture test |
| L5 | Bot texts (`texts.py`) and frontend locale files not auto-synced | Terminology drift risk | Document sync policy; add parity check |

---

## 15. Document Status (Canon documents)

| Document | Status |
|---|---|
| `docs/SSOT/LANGUAGE_CANON_SSOT.md` | ✅ Exists, read |
| `docs/SSOT/faq_ssot/TRANSLATION_STATUS.md` | ✅ Exists — **INACCURATE** (claims complete for langs with 21 identical answers) |
| `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json` | ✅ Exists |
| `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md` | ✅ Exists |
| `docs/audits/LOCALIZATION_ALL_LOCALE_PARITY_999_2026_04_24.md` | ✅ Read — previous audit showed 0 issues at time |
| `docs/audits/LANGUAGE_EXTENSION_VERDICT_1040.md` | ✅ Read — claimed identical-to-EN = 0, **contradicted by current audit** |
| `ARCHITECTURAL_LOCKS.md` | ✅ Exists |
| All other canon docs listed in audit spec | ✅ Present |

**Note on verdict discrepancy:** `LANGUAGE_EXTENSION_VERDICT_1040.md` claims "identical-to-EN tail = 0" after cycles 1031–1040. Current audit finds 252–259 public-facing identical values per language. This is likely because new keys were added after cycle 1040 (energy interactive overview, public_engagement, public_profile_trust, panels interactive, exchange interactive, browser_shop portal) and were **not translated** for non-EN/RU languages. The verdict remains accurate for the scope it covered; the drift is post-1040.

---

## 16. Audit Limitations

1. `pytest` not runnable in this environment — architecture tests were run manually or not at all
2. `rg` (ripgrep) not available — `audit_forbidden_gaming_contour.py` did not run
3. Node.js not available — JS audit scripts not run
4. `audit_frontend_hardcoded_strings.py` failed due to precondition — hardcoded string scan was done manually (partial coverage)
5. Backend beyond `bot/texts.py` not fully audited — no handlers or admin handlers were scanned for user-facing strings
6. Browser/visual proof not performed — layout break risk for long translations assessed only by key length, not rendered output

---

*End of audit report. Total findings: 4 CRITICAL, 4 HIGH, 5 MEDIUM, 5 LOW/INFO.*
