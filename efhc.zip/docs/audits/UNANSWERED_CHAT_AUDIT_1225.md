# UNANSWERED CHAT AUDIT 1225

## User question

Why was the frontend still empty / ugly / not like the reference?

## Answer

The work before this point repaired many separate blockers, but it did
not first enforce one master visual shell and one full visible-elements
agreement. That was wrong for a game WebApp. A game-like app must first
have a stable visible frame: dark shell, first screen, progress, cards,
buttons, and clear navigation.

The new rule is:

- never hide the app because tg_id is missing;
- never depend on Telegram to show the game UI;
- fix the visible shell before polishing small details;
- every visible element must be listed in chat for approval;
- archive files are only AI working memory, not approval.

## User question

Why was only a small part of the Dragon reference used?

## Answer

Because the RAR source could not be fully extracted by available tools.
The earlier work used only visible assets and structure, then fixed
EFHC blockers one by one. That was not enough for the visual goal.
The correct next stage is to treat Dragon as a product model:
compact shell, cards, progress, strong visual center, and browser/PWA.

## User question

Can the user send screenshots?

## Answer

Yes. Screenshots of the target app will help more than RAR if the
archive cannot be fully extracted. The screenshots should show:

- first screen;
- bottom navigation;
- profile/wallet;
- shop;
- task/earning page;
- ranks/leaderboard;
- browser install view.

## User question

How to agree all elements?

## Answer

Use one page at a time in chat.
For each page, list visible elements and mark:

- keep;
- improve visually;
- remove;
- move to admin;
- needs user decision.

## User question

What is the next repair order?

## Answer

1. Stabilize blank screen and dark shell.
2. List all visible page elements in chat.
3. Repair Referrals or Profile / Wallet by user priority.
4. Add Dragon-style visual center to Energy.
5. Verify browser/PWA and Telegram show the same UI.
