# Energy/Ranks boundary repair — cycles 1211-1212

## Purpose

Cycles 1211-1212 repair a domain boundary error in the public UI.
Energy progress skins and thresholds are an internal Energy progression
mechanic.  Ranks is a leaderboard and must not expose the full 12-step
Energy progress ladder as a public ranking section.

## User correction

The user clarified that the first screen is canonical Energy: progress,
generation and general energy information.  The six bottom menu buttons
remain canonical and are not moved or renamed:

- Energy;
- Panels;
- Exchange;
- Tasks;
- Referrals;
- Ranks.

Ranks must stay a canonical page, but it is not the place for the hidden
Energy progress ladder.  The 12 progress levels may drive internal skin
and progress state, but they must not appear as an open list in Ranks.

## Root cause

The previous UI mixed two different mechanics:

1. Energy progress layer: an internal progression state based on total
   generated kWh and used to change visual skin/progress state.
2. Ranks leaderboard layer: a social comparison surface based on rank
   position and generated energy.

The mistake was treating the Energy progress ladder as visible Ranks
content.  This is now corrected.

## Code changes

- `frontend/src/pages/ranks.tsx` no longer imports `USER_LEVEL_SKINS`,
  `getUserLevel` or `LevelSkinBadge`.
- The Ranks page no longer renders the 12-level Energy ladder.
- The Ranks page no longer renders `Current level` / `Lx` as a public
  leaderboard card.
- `frontend/src/pages/index.tsx` keeps the progress bar but removes
  public level names and `level x/12` text from the Energy hero.
- `frontend/src/lib/skins.ts` comment was changed to clarify that the
  table is an internal Energy skin threshold source.

## What remains canonical

- The bottom navigation remains unchanged.
- Ranks still shows leaderboard rows, user rank and generated kWh.
- Energy still shows total generation, progress bar, rate and active
  panels signal.
- The internal 12-level table remains in code as a skin/progress source.

## Checks

Added architecture guard:

`tests/architecture/test_energy_ranks_boundary_guard.py`

It verifies that:

- Ranks does not render the Energy progress ladder;
- Energy progress keeps the progress bar but not public level names;
- the 12-level table remains an internal skin source;
- the glossary records the game simulator WebApp boundary.

## Not claimed

This is not a full visual redesign of Energy or Ranks.  It closes the
specific boundary error and prepares the next visual hierarchy pass.
