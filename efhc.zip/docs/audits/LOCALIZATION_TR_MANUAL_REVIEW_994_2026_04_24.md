# Localization TR manual review — cycle 994

Date: 2026-04-24
Version: v167_63
Scope: `frontend/public/locale/tr.json`

## Purpose

Cycle 994 continues the full manual localization repair range `983-1020+`.
The cycle manually repairs the Turkish locale after the English baseline and
the previous RU/UK/DE/FR/ES/IT/PL passes.

## What was reviewed

- Turkish locale bundle value quality.
- English fallback values identical to `en.json`.
- Cyrillic tails inherited from earlier RU/admin copy.
- Admin/operator copy, Hub/browser-shop copy, Web-Profile copy, wallet,
  exchange, panels, ranks, referrals, shop UI, tasks and withdraw copy.
- Placeholder and technical token preservation.

## Manual repair result

The Turkish bundle was repaired manually. Broad English fallback clusters were
replaced with Turkish wording. Russian/Cyrillic tails were removed. Stable
project/protocol tokens were preserved where they are intentionally identical,
for example EFHC, TON, VIP, Hub, URL, ID, Telegram and language names.

## Guard

Added:

- `ops/i18n/audit_tr_locale_value_quality.py`

Guard result during the cycle:

```text
OK: checked Turkish locale value quality.
Accepted identical keys: 26
Cyrillic tails: 0
```

## Limits

This cycle closes the Turkish frontend locale at the current manual guard level.
It does not declare the whole multilingual contour release-ready, because the
remaining language bundles and later backend/FAQ/template/hardcoded-string
cycles are still planned.
