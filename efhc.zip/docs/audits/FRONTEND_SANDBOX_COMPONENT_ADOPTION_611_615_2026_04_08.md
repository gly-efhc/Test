# Frontend sandbox component adoption 611-615 (2026-04-08)

## Scope
Convert the sandbox donor findings into EFHC-native shared components for the
current external web contour.

## Implemented components
- `TelegramHeroSection`
- `TelegramBadgeGroup`

## Applied surfaces
- `ShopEntryPage`
- `BrowserShopPage`
- `WebProfilePage`

## Why these components
The portal/profile/storefront surfaces already had repeated hero blocks and
badge rows. The sandbox audit showed that reusable surface primitives are more
valuable here than importing any foreign page implementation.

## Result
External EFHC web surfaces now share a cleaner hero/header grammar and badge
rhythm while staying fully inside EFHC's current shell, routes and wording.
