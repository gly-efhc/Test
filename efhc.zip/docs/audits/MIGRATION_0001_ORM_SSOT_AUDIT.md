# Migration 0001 vs ORM vs SSOT audit

Дата: 2026-03-26

## Подтверждённые факты
- Active migration file: `backend/migrations/versions/0001_init.py`.
- Active schemas: `efhc_core`, `efhc_admin`.
- Active table canon from `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`: 35.
- 0001 uses `Base.metadata.create_all(..., checkfirst=True)` and sanity
  against `SSOT_TABLES_ORM.csv`.

## Что было неверно до цикла 35
- Часть migration docs держала устаревший count таблиц.
- В части docs оставался устаревший тезис, что на этапе 0001 все
  ORM-таблицы создаются только в `efhc_core`.
- В `SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md` сохранялся старый mismatch
  inventory, не соответствующий текущему HEAD.

## Что закреплено после цикла 35
- 0001 остаётся ORM-only производным артефактом.
- Канон таблиц: 35 active schema-qualified tables.
- Канон схем: только `efhc_core`, `efhc_admin`.
- Active migration docs синхронизированы с current SSOT.
