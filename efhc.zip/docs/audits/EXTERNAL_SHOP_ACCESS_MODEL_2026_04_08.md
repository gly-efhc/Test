# External shop access model (2026-04-08)

## Правильная модель

Отдельная интернет-страница storefront должна:
1. открываться вне Telegram как обычная web page;
2. но не жить как полностью публичный анонимный checkout;
3. открываться по короткоживущему подписанному access key / handoff token,
   выданному backend после подтверждённого входа из Telegram;
4. использовать общий backend truth-layer и общий admin/operator layer.

## Почему так правильно

Это позволяет совместить:
- внешний web UX;
- контроль доступа и связку с Telegram user identity;
- единый payment intent truth-layer;
- единое operator/admin управление.

## Модульная схема

### Bot entry module
- Telegram-side entry page: `/shop`
- задача: запросить access key у backend и открыть отдельный storefront URL.

### External storefront module
- browser page: `/browser-shop`
- задача: отрисовать внешний storefront, bootstrap state, catalog, create intent,
  payment details, status flow.

### Access / truth routes
- `POST /shopfront/access-key`
- `GET /shopfront/bootstrap`
- `GET /shopfront/catalog`
- `POST /shopfront/create-intent`
- `GET /shopfront/intent-status`

## Truth rule

Storefront остаётся отдельной интернет-страницей по UX,
но не отдельной экономической системой.
Экономический truth-layer и operator/admin truth-layer остаются общими.
