# RELEASE PURITY PROOF BUNDLE — 2026-04-08

## Цель
Собрать доказательный bundle по release purity current HEAD.

## Что проверено по коду

### 1. Dedicated cleanup utility exists
`ops/cleanup_artifacts.py` удаляет transient junk:
- `___pycache___`
- `.pyc/.pyo`
- `.pytest_cache/.mypy_cache/.ruff_cache/.cache`
- `.local_artifacts`
- temp/log/tail files

### 2. Dedicated build script exists
`ops/build_efhc_zip.sh` делает:
- canon guard on repo root
- cleanup before staging
- staging snapshot via `rsync`
- final staged cleanup
- FLAT zip build
- post-pack guard against junk inside zip

### 3. Post-pack guard checks real archive content
Скрипт после упаковки проверяет:
- наличие ключевых canonical files
- отсутствие cache/log/junk patterns inside ZIP

## Что подтверждено
- release purity current HEAD держится не только на договорённости, но и на
  кодовом cleanup/build guard path.
- current release path уже содержит защиту от типовых рецидивов:
  transient junk, nested zip, cache tails, `.local_artifacts`, logs.

## Residual / что остаётся живым

### Residual 1: build script itself remains a sensitive path
Если build script меняется, его легко снова сломать. Поэтому release purity
нужно продолжать держать под guard tests.

### Residual 2: CI config update policy now chat-only
По новому правилу пользователя CI files обновляются только в чате.
Значит release/build policy должна отделяться от workflow-edit policy.

## Вывод
Release purity current HEAD выглядит доказуемо лучше baseline-аudit риска,
потому что cleanup/build discipline реально живёт в коде. Но это должен
подтверждать пользовательский GitHub CI, а не локальный псевдо-CI.
