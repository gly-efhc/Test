# OPERATOR_KERNEL_CONFIG_LOADING_CANON

work pass  
Archive: v169_19  
Status: active Operator Kernel canon

## Purpose

Operator Kernel YAML files must not be dead declarations.

work pass adds `ops/operator_kernel/config_loader.py` and wires runtime code
to the existing config files:

- `layers.yaml` -> `file_map.py` layer detection;
- `heavy_paths.yaml` -> `file_map.py` heavy path detection;
- `invariants.yaml` -> `context_capsule.py` invariant section;
- `tool_registry.yaml` -> `tool_registry.py` tool modes;
- `validation_routes.yaml` -> `validation_router.py` audit metadata;
- `routes.yaml` -> `route_resolver.py` config source metadata.

## Dependency boundary

The loader is stdlib-only. It intentionally parses the simple YAML subset used
by the archive instead of adding a new runtime dependency to Operator Kernel.

## CI boundary

This cycle does not change `ci.yml` or workflow files.
CI/workflow files remain manual-control files and may only be changed through
explicit chat patch approval.

## v169.91 Kernel refresh/version update

`routes.yaml` is now versioned with `version: 1`. `config_loader.read_config_text("routes.yaml")` validates this version during load and raises on mismatch. `ops/operator_kernel/refresh.sh` is the single-command cache refresh entrypoint and runs clean-cache, file map rebuild and context capsule rebuild.


## v169.92 Kernel mandatory Start Core update

Operator Kernel is now a mandatory archive-navigation layer. `READING_ENTRYPOINT`, `TOPIC_READING_ROUTES`, `ARCHIVE_SYNAPTIC_LINKS` and root `KERNEL.md` require loading `ops/operator_kernel/cache/file_map.json` and `ops/operator_kernel/config/routes.yaml` before topic analysis.

`ops/operator_kernel/file_map.py` now supports `--refresh` and warns when the generated `file_map.json` is missing or older than 7 days.
