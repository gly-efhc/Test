# CI log repair after FSM split

Status: DONE in v169.96.

## Purpose

This note records the narrow backend repairs made after the FSM split log run.

## Repairs

- `backend/app/bot/fsm/manager.py` uses `create_logged_task()` instead of raw `asyncio.create_task()`.
- FSM compatibility comments avoid numbered work-pass labels in non-exception source files.
- HEAL-0055 Atlas metadata no longer says long-retention deposit idempotency is future work.

## Guard meaning

Background tasks must be supervised so exceptions are logged. The FSM manager may spawn GC/bootstrap tasks only through the canonical helper.

## Boundaries

No FSM public API changed. `backend/app/bot/states.py` remains a compatibility facade.
