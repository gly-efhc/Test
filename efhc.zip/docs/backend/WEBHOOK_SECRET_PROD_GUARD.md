# WEBHOOK_SECRET_PROD_GUARD

work pass  
Archive: v169_19  
Status: active production security guard

## Rule

Production settings must fail closed when Telegram webhook auth secret is
empty.

`ENV=prod` requires a non-empty `TELEGRAM_WEBHOOK_SECRET`.

## Reason

`backend/app/routes/system_routes.py` validates the webhook secret only when
`TELEGRAM_WEBHOOK_SECRET` is configured. An empty production secret makes the
webhook route accept requests without secret-token verification.

## Implementation

`backend/app/core/config_core.py` now has an after-model validator:

- local/dev/ci environments may keep an empty webhook secret;
- production requires `TELEGRAM_WEBHOOK_SECRET`;
- missing production value raises `ValueError` during settings creation.

`env.prod.example` now also documents `SECRET_KEY` explicitly.
