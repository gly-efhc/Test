## Цикл 1791 — atomic Telegram webhook transaction boundary (v174.42)

- После проверки `TELEGRAM_WEBHOOK_SECRET` JSON body валидируется до dedupe state.
- `processed_external_events` marker вставляется без commit и принадлежит той же root transaction, что `process_update()`.
- Один final commit выполняет webhook только после успешной business processing.
- Duplicate branch делает rollback/read-only close и возвращает `dedupe=True`.
- Dedupe storage unavailable → rollback + `503 WEBHOOK_DEDUPE_UNAVAILABLE`; ordinary exception/cancellation → rollback + re-raise.
- Manual compensating DELETE processed marker запрещён.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

## Цикл 1747 — protected startup secrets

Для `prod/stage` startup fail-closed теперь распространяется также на `SECRET_KEY`: значение должно содержать не менее 32 символов и не совпадать с зарегистрированными placeholder. Проверка `TELEGRAM_WEBHOOK_SECRET` цикла 1746 сохраняется. Local/dev/ci остаются разрешённым контуром без обязательного production-secret набора.

## Цикл 1746 — protected environments

`TELEGRAM_WEBHOOK_SECRET` обязателен для `ENV=prod` и `ENV=stage`. Settings validation отклоняет запуск без секрета, а `/tg/webhook` повторно fail-closed отвечает `503`, если защищённое окружение каким-либо образом дошло до route с пустым secret. Local/dev/ci остаются вне этой обязательности по active contract.

# WEBHOOK_SECRET_PROD_GUARD

work pass  
Archive: v169_19  
Status: active production security guard

## Rule

Production settings must fail closed when Telegram webhook auth secret is
empty.

`ENV=prod` requires a non-empty `TELEGRAM_WEBHOOK_SECRET`.

## Reason

`backend/app/routes/system_routes.py` validates the webhook secret only when
`TELEGRAM_WEBHOOK_SECRET` is configured. An empty production secret makes the
webhook route accept requests without secret-token verification.

## Implementation

`backend/app/core/config_core.py` now has an after-model validator:

- local/dev/ci environments may keep an empty webhook secret;
- production requires `TELEGRAM_WEBHOOK_SECRET`;
- missing production value raises `ValueError` during settings creation.

`env.prod.example` now also documents `SECRET_KEY` explicitly.
