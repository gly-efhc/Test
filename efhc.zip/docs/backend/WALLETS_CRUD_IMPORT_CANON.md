# WALLETS CRUD IMPORT CANON — work pass

Date: 2026-05-31
Archive: `v169_31`

## Canon

`backend/app/crud/wallets_crud.py` must import `WalletBinding` from the
canonical model module:

```python
from app.models.wallets_models import WalletBinding
```

## Reason

The compatibility shim `app.models.wallet_models` was removed from active
runtime in PACK-03. Active runtime code must use the canonical
pluralized model module.

## Boundary

This change is a P3 cleanup. It does not change wallet behavior, database
schema, public routes, admin routes or migration policy.

## Guard

`tests/architecture/test_zip_encoding_wallets_crud_hotfix.py`
checks that `wallets_crud.py` uses the canonical import and does not use the
legacy shim.
