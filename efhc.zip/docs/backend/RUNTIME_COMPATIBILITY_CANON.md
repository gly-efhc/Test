# RUNTIME COMPATIBILITY CANON

Статус: ACTIVE / SSOT
Решение: цикл 1728

## 1. Зачем существует этот документ

В EFHC уже был подтверждённый класс регрессий после агрессивного cleanup: тонкие
фасады, старые import paths и compatibility-типы удалялись или переосмыслялись
по признаку «не найден текущий caller», хотя они сохраняли внешний, исторический
или операционный контракт.

Цикл 1728 закрепляет противоположное правило: **отсутствие caller не является
доказательством, что compatibility surface можно удалить**. Тупиковый на вид
файл, alias, реэкспорт или stub может существовать именно для того, чтобы старый
потребитель продолжал получать каноническую реализацию без второго runtime.

Каждое такое место должно оставаться тонким, иметь объясняющий комментарий рядом
с кодом и не превращаться в новый центр бизнес-логики.

## 2. Общие правила

1. `no caller != delete proof`.
2. Новый production-код использует канонический модуль/сервис, если ниже прямо
   не указано, что facade является официальным public API.
3. Compatibility facade не получает собственную бизнес-логику, состояние,
   второй engine, вторую ORM-модель, второй router или второй auth-path.
4. Сохранённое историческое имя не означает, что архитектура должна вернуться к
   старой реализации. Оно делегирует текущему CANON.
5. Автоматический cleanup, «мертвый код», «нет импортов», «можно импортировать
   напрямую» или «странное имя файла» не являются достаточными основаниями для
   удаления.
6. Удаление любого перечисленного surface возможно только после отдельного
   решения пользователя, полного delete-proof всех runtime/tooling/external
   способов вызова и последующей exact-head GitHub CI qualification.
7. Комментарии-послания в этих файлах являются частью архитектурного решения:
   будущий аудит должен прочитать их до предложения удалить или переписать
   compatibility path.

## 3. Матрица решений цикла 1728

| Surface | Канонический источник | Почему сохраняется | Правило для нового кода |
|---|---|---|---|
| `app.create_app` | `app.main.app` | Исторический startup/import seam. Возвращает тот же app и не создаёт второй FastAPI runtime. | Запускать `app.main:app`; не превращать facade во вторую фабрику. |
| `app.database.get_engine` | `app.core.database_core.get_engine` | Старый DB import path без второго engine. | Новый код импортирует `database_core`. |
| `app.database.get_session_factory` | `app.core.database_core.get_session_factory` | Старый DB import path без второй session factory. | Новый код импортирует `database_core`. |
| `app.core.decimal_utils.d8` | `app.deps.d8` | Сохраняет старый decimal import, не создавая вторую политику точности. | Новый код использует канонический helper. |
| `app.models.order_models.ShopOrder` | `app.models.shop_models.ShopOrder` | Защита исторического import path и от повторного появления второй ORM-модели `shop_orders`. | Никогда не объявлять здесь отдельную ORM-модель. |
| `app.bot.states` | `app.bot.fsm` | **Официальный стабильный public FSM facade**: скрывает внутреннее разбиение FSM. | Публичные FSM-потребители могут использовать facade; бизнес-логику сюда не переносить. |

Точный статус контракта: `app.bot.states` — официальный стабильный public FSM facade.
| `admin__main__handlers` | `admin_main_handlers` | Историческое имя файла; реэкспортирует тот же Admin router/handler. | Новый код использует `admin_main_handlers`; facade не получает второй router. |
| `TickContext` | `SchedulerService` runtime | Старый type/import contract, который current SchedulerService не обязан использовать. | Не строить новый scheduler context вокруг compatibility-типа. |
| `SchedulerError`, `JobTimeout` | Current SchedulerService error handling | Старые type/import contracts. | Не создавать параллельную error-policy. |
| `scheduler_core.tick` | `SchedulerService.run_single_tick` | Старый callable entrypoint с тем же каноническим тиком. | Новый код вызывает SchedulerService; facade остаётся тонким. |
| `tasks_maintenance.run_once` | `tasks_autorestart.run_once` | Старый import path для обслуживания задач. | Не создавать здесь второй maintenance engine и не смешивать с TON watcher. |
| `RBAC.is_superadmin` | `RBAC.resolve_admin` + `RBAC.require_role` / законный Admin NFT contour | Стабильный boolean helper после уже выполненного разрешения прав. | Никогда не использовать как самостоятельный auth bypass. |

## 4. Особая блокировка ShopOrder

`order_models.ShopOrder` обязан быть тем же Python-классом, что и
`shop_models.ShopOrder`. Исторический риск двойного определения ORM-модели для
одной таблицы делает этот реэкспорт защитным compatibility seam. Любая попытка
«вернуть полноценную модель» в `order_models.py` создаст второй источник ORM
истины и запрещена.

## 5. Особая блокировка FSM

`app.bot.states` с цикла 1728 больше не считается временным мостом «пока не
перенесены все импорты». Это официальный стабильный public facade. Внутренние
файлы `app.bot.fsm` можно реорганизовывать только с сохранением публичного
контракта facade либо по отдельному согласованному изменению API.

## 6. Особая блокировка RBAC

`RBAC.is_superadmin(admin)` отвечает только на вопрос: «имеет ли уже разрешённый
AdminUser роль SuperAdmin?». Он не устанавливает личность, не проверяет session,
не читает whitelist и не доказывает владение Admin NFT. Поэтому вызов helper до
канонического разрешения администратора является архитектурной ошибкой.

## 7. Delete policy

Чтобы предложить удаление compatibility surface из этой матрицы, будущий цикл
обязан одновременно предоставить:

- конкретное решение пользователя об удалении;
- полный список runtime/import/tooling/external callers и доказательство их
  миграции или отсутствия;
- доказательство, что удаление не создаёт второй путь/обход CANON;
- обновление preservation manifest и active SSOT;
- новый exact-head GitHub CI после патча.

До выполнения всех условий решение по умолчанию — **PRESERVE**.
