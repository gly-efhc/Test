# HEAL-0018 transaction boundary map

Status: DONE as audit/map in `v169_89 / repair pass`.
Marker: `NO_RUNTIME_BOUNDARY_REWRITE_IN_1409`.

## Goal

Define transaction ownership before changing financial transaction boundaries. repair pass intentionally does not rewrite service/route transaction logic. The next repair cycle must use this map so the fix is controlled and testable.

## Classification vocabulary

- `service-owned`: the service owns `begin/commit/rollback` because it performs a complete money/state transition.
- `route-owned`: the route/dependency owns the transaction and service helpers must not commit independently.
- `savepoint-only`: `begin_nested()` is allowed only as an explicit subtransaction with a documented caller. It must not be the hidden default for fixing `Session already begun`.
- `mixed/needs-repair`: current code mixes commits, rollback and nested contexts; this is the target for repair pass+ repair.

## Current boundary map

| File | Current markers | Classification | Cycle action |
|---|---|---|---|
| `backend/app/services/transactions_service.py` | `_tx_context()`, `begin_nested`, manual `commit/rollback`, read-through idempotency | `mixed/needs-repair` | 1410 should define service-owned contract for core bank movements and remove hidden nested fallback where possible. |
| `backend/app/services/withdraw_service.py` | `_tx_context()`, `begin_nested`, several commit/rollback phases | `mixed/needs-repair` | 1411 should align withdraw create/hold/mark with atomic or formal two-phase state machine. |
| `backend/app/services/payment_intents_service.py` | explicit service commits in intent creation paths | `service-owned candidate` | Keep package/custom contract from 1406; later ensure route does not wrap conflicting outer transaction. |
| `backend/app/services/efhc_deposits_service.py` | commented `async with db.begin()`, deposit/idempotency flow | `deposit-idempotency candidate` | 1412-1413 must prove durable deposit idempotency through `efhc_admin.idempotency_key`. |
| `backend/app/core/system_locks.py` | idempotency middleware over `efhc_admin.idempotency_key` | `middleware/lock-layer` | Must remain DB-backed safeguard, not process-local source of truth. |
| `backend/app/services/energy_service.py` | manual nested begin/commit/rollback | `mixed/needs-review` | Review after P0 money services; not first repair target unless logs point here. |
| `backend/app/services/panels_service.py` | `_tx_context()`, `begin_nested`, commit/rollback | `mixed/needs-review` | Keep outside immediate money core unless failures appear. |
| `backend/app/services/referral_service.py` | nested begin helper and commits | `mixed/needs-review` | Identity repair is done; transaction repair later if logs show failure. |
| `backend/app/services/tasks_service.py` | nested begin helper and many commits | `mixed/needs-review` | Later controlled audit. |
| `backend/app/services/wallet_binding_service.py` | begin_nested helper and several commits | `mixed/needs-review` | Wallet binding is not the first P0 money movement repair. |

## Repair order after this map

1. repair pass: `HEAL-0018` transaction-boundary repair for core service-owned money movements.
2. repair pass: `HEAL-0024` withdraw/exchange atomicity/state-machine repair.
3. repair pass: `HEAL-0055` deposit idempotency proof and long-retention policy.

## Acceptance criteria for future runtime repair

- No broad replacement of transaction logic without a service-by-service map.
- No `Session already begun` masking by undocumented `begin_nested()` fallback.
- No route/service double-commit for one money transition.
- Existing idempotency read-through invariants from repair pass remain active.

## Sandbox note

Песочница and `docs/history/legacy_artifacts/map_element.md` were used only as reference/navigation context for architecture discipline. No sandbox runtime, wallet/payment donor logic, CI workflow, lock file or translation was imported.

## repair pass runtime repair update

Status: `transactions_service.py` first runtime repair DONE in `v169_90`.

The repair pass map remains the evidence base. repair pass changed the core money
helper from hidden `begin_nested()` fallback to a service-owned commit/rollback
boundary. `exchange_service.exchange_kwh_to_efhc()` now closes its read-only
preflight autobegin before entering transactions_service.

Residual: `withdraw_service.py` remains `mixed/needs-repair` and is routed to
repair pass / HEAL-0024.
