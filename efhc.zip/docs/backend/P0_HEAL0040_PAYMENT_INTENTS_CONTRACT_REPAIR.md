# HEAL-0040 payment_intents contract repair

Status: DONE in `v169.88 / repair pass`.

## Canon

`payment_intents.package_id` has two valid states:

1. Package-based intents: `package_id` is a real package/shop item id.
2. Custom/package-less intents: `package_id = NULL`.

`0` is not a valid fake package sentinel.

## Runtime repair

Files:

- `backend/app/models/payment_intents_models.py`
- `backend/app/services/payment_intents_service.py`
- `backend/migrations/versions/0001_initial_release_schema.py`

Repairs:

- ORM: `PaymentIntent.package_id` is now `Mapped[int | None]` and `nullable=True`.
- Package path: `create_intent_deposit_by_package()` still inserts `:pid`.
- Custom deposit path: `create_intent_deposit_custom()` inserts `NULL`.
- Shop external/package-less path: `create_intent_shop_external()` inserts `NULL`, not `0`.
- Existing DB path: Alembic 0001 applies `ALTER COLUMN package_id DROP NOT NULL` before sanity checks.

## Guard

Active guard:

- `tests/architecture/test_heal0040_0044_payment_schema_contract.py`

## Boundaries

- No EFHC economics changed.
- No wallet/TonConnect payment logic copied from sandbox.
- No CI/workflow changed.
- No test was deleted, archived, skipped, xfailed or hidden.

## Follow-up

HEAL-0040 is repaired at code/schema-contract level. It still needs full DB CI proof in a real Alembic/Postgres run before release-ready can be claimed.
