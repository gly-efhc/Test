# DEV_TEST_REQUIREMENTS_SYNC_POLICY

work pass  
Archive: v169_19  
Status: active dependency policy

## Purpose

`requirements-dev.txt` must not block the exact pytest versions used by
`requirements-test.txt` and GitHub CI.

work pass synchronizes the local development pytest ranges with the pinned
test bootstrap layer:

- `pytest==9.0.3` in `requirements-test.txt`;
- `pytest-asyncio==1.4.0` in `requirements-test.txt`.

Therefore development ranges are now:

- `pytest>=9.0.3,<10.0.0`;
- `pytest-asyncio>=1.4.0,<2.0.0`.

## Runtime boundary

`backend/requirements.txt` remains runtime-only. It must not contain:

- `pytest`;
- `pytest-asyncio`;
- `freezegun`;
- linters/typecheckers.

`backend/requirements.lock` is generated from runtime requirements only and
must stay clean from test-only dependencies.

## Lock-file update command

Runtime lock-file generation uses `uv`:

```bash
uv pip compile backend/requirements.txt -o backend/requirements.lock
```

`uv` is an external developer tool and is installed separately:

```bash
pip install uv
```

## Update rule

When `requirements-test.txt` changes, check whether `requirements-dev.txt`
still allows the pinned pytest and pytest-asyncio versions. If not, update
both files in the same cycle and add a guard.
