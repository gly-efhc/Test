# HEAL-0018 transaction-boundary repair

Status: DONE as a controlled transaction-boundary runtime repair.
Base map: `docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md` from repair pass.

## Problem

Core money services used a hidden `_tx_context()` fallback:

- if the session already had an active transaction, use `begin_nested()`;
- otherwise use `db.begin()`.

That made `Session already begun` less visible but did not produce one clear
service-owned transaction boundary. In callers that performed a read-only
preflight first, SQLAlchemy `autobegin` could create an outer transaction before
the money service. The old helper then ran the money transition inside a
SAVEPOINT and the real root boundary remained ambiguous.

## repair pass repair

### Runtime files changed

- `backend/app/services/transactions_service.py`
- `backend/app/services/exchange_service.py`

### New core rule

`transactions_service` is the owner of the commit/rollback boundary for core
bank movements.

The helper now:

1. never calls `begin_nested()` as a hidden blanket fallback;
2. if a root session transaction already exists because of autobegin, it yields
   into that transaction and then commits/rolls back it explicitly;
3. if no transaction exists, it uses normal `db.begin()`.

### Exchange wrapper repair

`exchange_service.exchange_kwh_to_efhc()` performs a read-only preflight to keep
its public response evidence. That read can autobegin the session. repair pass
closes that read-only boundary with rollback before entering
`transactions_service`, so the money transition remains service-owned.

## What was intentionally not repaired in this cycle

- `withdraw_service.py` still has multi-phase withdraw request/hold/mark flows.
  That is repair pass / HEAL-0024.
- Wider mixed transaction helpers in non-core services remain for later audit or
  log-driven repair.
- No route dependency or CI workflow was changed.

## Guard

Active guard:

- `tests/architecture/test_heal0018_transaction_boundary_repair.py`

It checks that the core helper is contextmanager-based, that the hidden
`begin_nested()` return path is gone, and that exchange preflight explicitly
closes read-only autobegin before money service entry.

## Non-claims

This is a source-level and targeted-test repair. It does not claim GitHub CI
green, full local pytest green, release readiness, browser screenshots, live
Telegram proof or real wallet proof.

## Sandbox note

Песочница and `map_element.md` were used only as reference/navigation context
for architecture discipline. No sandbox runtime, lock file, CI workflow,
wallet/payment donor logic or translation text was imported.

## repair pass follow-up — HEAL-0024 atomicity

repair pass used the repair pass transaction-boundary repair as the base and removed the primary withdraw create/hold/mark split. `request_withdraw()` now runs the request row, no-commit hold transfer, transfer audit meta and `hold_done=TRUE` flag in one service-owned boundary. `transactions_service.debit_user_to_bank_nocommit()` exists only for higher-level state machines where the caller owns commit/rollback.
