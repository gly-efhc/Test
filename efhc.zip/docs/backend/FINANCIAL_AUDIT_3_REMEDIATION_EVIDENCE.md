# FINANCIAL AUDIT №3 — REMEDIATION EVIDENCE / цикл 1794

Дата: 2026-08-19  
Входной exact HEAD: `v174.50`  
SHA-256 входного архива: `ec735a9a631fde9c6275d62b19cdc5b15d53c0b5daca9d3fb85066699df46cc3`  
GitHub CI: `87472108257`  
Checkout: `22d9a9a7b95e42c4980c3019bea6fa53d99807e3`  
ТЗ аудита №3 SHA-256: `2772e1fd6325411d0f195b0078ce86653a8900ab8e852dca733049cebb24d61b`

## CI identity

CI `87472108257` проверил именно `v174.50`; все recorded gates GREEN. Pytest: `1729 passed / 22 skipped / 1 warning`. Следовательно, `v174.50` является exact-head GREEN anchor для цикла 1794. CI не содержит RED-причин для source repair; remediation ниже основана на прямом owner-approved Financial Audit №3.

Статусы ниже означают `REPAIRED / EXACT-HEAD CI PENDING`, а не GREEN: локальные project qualification suites для `v174.51` не запускались и результат source repairs должен подтвердить следующий exact-head GitHub CI.

## FIN-01 — Withdrawal: payout evidence ≠ PAID

- **Finding ID:** `FIN-01`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-01`; D2/fee boundary также `FIN3-03`, `FIN3-10`.
- **Old v174.50 evidence:** `backend/app/services/admin/admin_withdrawals_service.py:590-608`; `frontend/src/pages/admin/withdrawals.tsx:298-320` — wallet send и approval/PAID были семантически смешаны.
- **New source:** `backend/app/services/admin/admin_withdrawals_service.py:424+` (`mark_withdrawal_paid`), `:779+` (`record_payout_evidence`); routes `admin_withdrawals_routes.py:163+` и `:194+`; `withdraw_service.py:278` — D2 до hold.
- **Old failing regression scenario:** успешный wallet `sendTransaction()` сразу завершает заявку как PAID/approval; ручная external выплата не имеет отдельного explicit Paid action.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:100+`; локально не запускался, PASS ожидается только от следующего exact-head CI.
- **Data/transaction evidence:** payout evidence сохраняется отдельно и не переводит status в PAID; `mark-paid` выполняет explicit Admin action и required audit; withdrawal hold использует тот же D2-normalized amount, `network_fee_payer=project` записан в transfer metadata.
- **Remaining compatibility debt:** legacy `/approve` сохранён как compatibility route, но canonical frontend использует `payout-evidence` + `mark-paid`.

## FIN-03 — TON/USDT: asset-native atomic, не EFHC D8

- **Finding ID:** `FIN-03` + внешний EFHC D2 boundary.
- **Owner decision ID:** `QA-2026-08-19-FIN3-03`, `FIN3-11`; no-Oracle boundary — `FIN3-12`.
- **Old v174.50 evidence:** `hub_routes.py:705-715`; `payment_intents_service.py:481-505`; `payment_reconciliation_service.py:184-187` — external amount проходил через D8 abstraction.
- **New source:** `backend/app/domain/finance/external_amounts.py:26+`; EFHC2 payload `payment_intents_service.py:550+`; exact atomic equality `payment_reconciliation_service.py:190+`; direct EFHC D2 `watcher_service.py:1264+`; unmatched TON/USDT evidence использует classified transport, а не `d8()`/hardcoded TON.
- **Old failing regression scenario:** TON 9 decimals/USDT 6 decimals сначала нормализуются как EFHC D8; one-atomic-unit mismatch может быть скрыт неверной domain abstraction.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:23+`, `:31+`, `:44+`, `:49+`, а также watcher atomic transport tests; локально не запускались.
- **Data/transaction evidence:** PaymentIntent v2 фиксирует `asset + external_amount_atomic + external_decimals + efhc_amount_d8`; watcher передаёт raw atomic truth; settlement v2 сравнивает integer atomic equality. Internal monetary mutation остаётся EFHC ledger result.
- **Remaining compatibility debt:** frozen DB column `amount_asset_d8` и payload v1 остаются legacy/frozen-schema compatibility; для EFHC2 они не settlement authority. DDL не вводился.

## FIN-04 — ADS: completed view и reward независимы

- **Finding ID:** `FIN-04`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-04`.
- **Old v174.50 evidence:** `ad_manager.py:926-947`; scheduler не имел independent due-reward reconciliation.
- **New source:** `backend/app/services/ads/ad_manager.py:982+` (`reconcile_due_ad_rewards`); `backend/app/scheduler/ads_reward_reconciliation.py`; registration `backend/app/services/scheduler_service.py:398+`.
- **Old failing regression scenario:** verified/completed view зафиксирован, процесс падает до reward, а отдельного пути доведения reward нет.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:114+`; локально не запускался.
- **Data/transaction evidence:** reconciliation выбирает completed+verified sessions с `rewarded_at IS NULL` и повторно использует stable key `ads-session:{session_id}`; reward является отдельным idempotent obligation.
- **Remaining compatibility debt:** фактическая concurrency/idempotency qualification выполняется только GitHub/PostgreSQL gates следующего exact-head CI.

## FIN-05 — Watcher retry сохраняет exact transport

- **Finding ID:** `FIN-05`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-05` — product auto-retry policy остаётся `PENDING`; техническая корректность существующего retry обязательна независимо.
- **Old v174.50 evidence:** `watcher_service.py:1345-1377`; `jetton_parsing_service.py:51-58` — retry row не сохранял asset/master/token amount и мог быть переинтерпретирован как TON.
- **New source:** transport meta v2 `watcher_service.py:351+`; reconstruction/refetch `_retry_row_to_tx` `:1441+`; legacy refetch failure → `PENDING_MANUAL`; retry path не default'ит отсутствующий transport в TON.
- **Old failing regression scenario:** USDT/EFHC jetton попадает в retry без asset/master/atomic amount и обрабатывается как native TON.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:87+` и watcher retry/transport tests; локально не запускались.
- **Data/transaction evidence:** `ton_inbox_logs.meta` хранит `transport_version=2`, transport asset, financial asset, jetton master, atomic amount, decimals и native atomic amount; legacy row сначала authoritative refetch by tx_hash, иначе fail-closed manual state.
- **Remaining compatibility debt:** старые строки без v2 metadata требуют provider refetch; если authoritative transaction недоступна, автоматическая реконструкция намеренно не выполняется.

## FIN-06 — NFT нельзя approve без оплаты

- **Finding ID:** `FIN-06`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-06`.
- **Old v174.50 evidence:** `shop_service.py:1788-1793` — generic force-fulfill выбирал `APPROVED` для NFT до canonical paid-manual gate.
- **New source:** `backend/app/services/shop_service.py:1881+` требует `PAID_PENDING_MANUAL` и передаёт решение canonical Admin NFT service.
- **Old failing regression scenario:** unpaid `PENDING → APPROVED` через generic force-fulfill.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:75+`; локально не запускался.
- **Data/transaction evidence:** unpaid state блокируется до decision; canonical NFT service сохраняет собственный Admin audit contract.
- **Remaining compatibility debt:** generic force-fulfill endpoint сохранён как функция приложения, но отдельная NFT state machine из него удалена.

## FIN-07 — Monetary reporting только по canonical transfer ledger

- **Finding ID:** `FIN-07`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-08`.
- **Old v174.50 evidence:** `tasks_service.py:284-289`; `admin_routes.py:1085-1092`; `admin_bonus_service.py:1-10` — shadow ledgers/stale referral reasons использовались для monetary totals.
- **New source:** task monetary query `tasks_service.py:287+`; canonical reason registry `backend/app/standards/financial_reason_registry.py:3+`; Admin bonus/reporting paths используют `efhc_transfers_log`; referral reasons = `referral_active_unit/referral_level_bonus`.
- **Old failing regression scenario:** transfer ledger содержит фактическую проводку, shadow row отсутствует/старое reason name — отчёт показывает неверную сумму.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:125+`; локально не запускался.
- **Data/transaction evidence:** totals фильтруются по canonical ledger, direction/balance/reason; bank mirror rows не считаются пользовательским заработком.
- **Remaining compatibility debt:** `task_bonus_log`/`referral_bonus_ledger` физически сохранены как domain/evidence tables, но не monetary SSOT.

## FIN-08 — Admin force-fulfill требует actor/reason/audit

- **Finding ID:** `FIN-08`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-02`, `QA-2026-08-19-FIN3-07`.
- **Old v174.50 evidence:** `admin_shop_routes.py:251-265`; `admin_shop_service.py:150-162`; `shop_service.py:1849-1881` — financial mutation могла commit'иться без required Admin audit.
- **New source:** `backend/app/services/shop_service.py:1851+` требует reason/actor; `:1947+` пишет `SHOP_FORCE_FULFILL` через `AdminLogger.write(required=True)` до root commit; route/wrapper передают canonical Admin principal.
- **Old failing regression scenario:** BANK→USER credit и order transition успешно commit, а audit отсутствует либо его запись падает отдельно.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:75+`; локально не запускался.
- **Data/transaction evidence:** money mutation + order state + required Admin audit выполняются одной DB session/root transaction; audit failure не должен допустить final commit.
- **Remaining compatibility debt:** exact rollback/concurrency подтверждается следующим PostgreSQL/CI qualification, не локальным full suite.

## FIN-09 — Zero price = payment method unavailable

- **Finding ID:** `FIN-09`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-09`.
- **Old v174.50 evidence:** `shop_service.py:788-793`, `:943-950`, `:2196-2203`; `BrowserShopPage.tsx:817+` — `0` проходил проверки `is not None`.
- **New source:** Shop backend positive gates `shop_service.py:830+`, `:2271+`; create/intent boundary требует positive asset-native amount; frontend absolute guard `BrowserShopPage.tsx:825`.
- **Old failing regression scenario:** configured price `0` визуально/серверно остаётся доступным для checkout/free order.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:62+`; локально не запускался.
- **Data/transaction evidence:** backend является final authority: `price <= 0` не формирует валидный external amount/PaymentIntent; frontend лишь дублирует UX disable.
- **Remaining compatibility debt:** отсутствует; free-order semantics не вводились.

## FIN-10 — Oracle/FX/custom-rate остаётся удалённым

- **Finding ID:** `FIN-10`.
- **Owner decision ID:** `QA-2026-08-19-FIN3-12`.
- **Old state:** уже `RESOLVED IN v174.50`; повторный runtime repair не требовался.
- **New/current source:** Browser Shop продолжает брать только manual `price_ton` / `price_usdt`; active `backend/app/**` и `frontend/src/**` не содержат Oracle/FX pricing provider/call path.
- **Old failing regression scenario:** возврат CUSTOM_EFHC, fixed `0.3 USDT = 1 EFHC`, Oracle snapshot или скрытого FX provider.
- **Regression source:** `tests/architecture/test_financial_audit3_contract.py:62+`; semantic check допускает правильные negative-lock docs; локально не запускался.
- **Data/transaction evidence:** immutable intent snapshot создаётся из сохранённой Admin manual price, без внешнего курса.
- **Remaining compatibility debt:** compatibility input `custom_efhc_amount_d8` может оставаться в schema/API, но не является pricing/runtime decision input.

## Дополнительный P0 finding — temporal barrier before replay

При read-through settlement обнаружен порядок exact replay до полного временного barrier. `backend/app/services/payment_reconciliation_service.py:101+` приведён к обязательному порядку: trusted time → 180-day barrier → replay/idempotency → mutation → ledger. Это preservation существующего P0 owner invariant, а не новая экономика. Regression source: `tests/architecture/test_financial_audit3_contract.py:49+`; локально не запускался.

## Документальный canon

Созданы `FINANCIAL_TOPOLOGY_SSOT.md` и machine projection `FINANCIAL_TOPOLOGY_LOCK.json`; owner Q&A FIN3-01…12 внесены append-only, FIN3-05 оставлен `PENDING`; отдельно поднято историческое решение Shop TON/USDT. Обновлены EFHC/PaymentIntent/Shop/Withdraw/ADS/BANK SSOT/NORM без создания второго price SSOT.

## Preservation

- Shop `price_ton` / `price_usdt` остаются единственной ручной product price authority; Oracle/FX отсутствует.
- TON/USDT — внешние rails и не становятся внутренними EFHC balances/ledger assets.
- Internal EFHC остаётся D8; внешний EFHC deposit/withdraw — D2 ROUND_DOWN → D8 storage.
- frozen `0001_initial_release_schema.py` byte-equal exact-GREEN `v174.50`; `backend/app/models` byte-equal; `0002+` не создавались.
- Telegram root transaction, security middleware/error boundary, FAQ standalone release authority и не затронутые FRONTEND_v146 assets не менялись.
- Полные локальные qualification suites не запускались.

## Qualification boundary

ТЗ Definition of Done требует fresh exact-head CI для итогового SHA. Поэтому source remediation цикла завершён, но `v174.51` до нового GitHub CI имеет статус только `CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
