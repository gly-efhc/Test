# CI_TEST_DEPENDENCY_SANITY_CANON

work pass
Archive: v169_13

## Canon

Runtime dependencies and test dependencies stay separated.

- `backend/requirements.txt` is runtime-only.
- `requirements-test.txt` stores pytest-only helpers.
- `freezegun` remains test-only.

## CI rule

Before running `pytest -q`, CI must:

1. install `extracted/backend/requirements.txt`;
2. verify `extracted/requirements-test.txt` exists;
3. install `extracted/requirements-test.txt`;
4. import `freezegun` as a sanity check;
5. then run `PYTHONPATH=backend pytest -q`.

This prevents a collection-time failure in tests that import `freeze_time`.


## work pass hardening

work pass converts the basic sanity check into a dependency bootstrap lock.
The workflow now installs all pytest bootstrap packages from
`requirements-test.txt` and imports them before `pytest -q`.
