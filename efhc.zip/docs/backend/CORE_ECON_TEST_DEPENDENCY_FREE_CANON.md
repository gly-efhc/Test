# CORE_ECON_TEST_DEPENDENCY_FREE_CANON

work pass
Archive: v169_16
Status: NORM

## Rule

Core mathematical/economic architecture tests must avoid optional helper
packages when the same invariant can be proven with the Python standard
library.

## Reason

`logs_71060357686.zip` proved that a pytest collection-time dependency on
`freezegun` can block the whole test suite even though the actual invariant
requires only deterministic UTC delta arithmetic.

## Applied boundary

`tests/core/test_core_math_econ.py` must not import:

```text
freezegun
freeze_time
```

The test may use standard-library `datetime` for deterministic timestamps.

## CI file boundary

CI/workflow files remain manual-control files. If CI bootstrap still needs
changes, the assistant must present a manual patch in chat. It must not treat
a silent archive-only `ci.yml` edit as an applied user-side CI repair.
