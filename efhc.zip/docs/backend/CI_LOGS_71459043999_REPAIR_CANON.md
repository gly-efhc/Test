# CI_LOGS_71459043999_REPAIR_CANON

work pass
Archive: v169_17
Status: NORM

## Rule

When logs show a stale guard, the fix must update the stale guard to the
current active canon. The project must not roll back runtime code to make
an old guard pass.

## Applied in this cycle

The old work pass guard still expected the Next.js 14 baseline and the
old frontend Docker npm install boundary. The active canon is now:

- Next.js 16.2.6;
- React 19.2.6;
- Tailwind CSS v4.3;
- `next dev --turbo`;
- stable npm registry and npm ci safety flags in frontend Docker.

The guard was updated to protect the current canon.

## Cache hygiene rule

Operator Kernel generated caches must not reintroduce archived legacy
terms from `ORIGINAL_SOURCES`, `CHAT_BRANCHES` or `CHATS`. Those folders
are historical memory, not active route input for generated caches.

## CI boundary

CI/workflow files are manual-control files. This cycle did not change
`ci.yml`.
