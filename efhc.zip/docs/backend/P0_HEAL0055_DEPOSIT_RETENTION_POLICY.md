# P0 HEAL-0055 — Deposit idempotency long-retention policy

Status: active canon after `v169.93 / repair pass`.

## Decision

EFHC on-chain deposit duplicate protection is a durable reconciliation/audit
record, not a short-lived click lock. Deposit idempotency records in
`efhc_admin.idempotency_key` must be retained without automatic TTL expiry:

- scope: `deposit:efhc`;
- key: `deposit:efhc:<tx_hash>` or stable sha256 digest fallback if the raw
  key would exceed the 128-character DB limit;
- retention policy: `NON_EXPIRING`;
- DB value: `expires_at = NULL`;
- cached response: first completed response stored in `response_payload_json`;
- replay: repeated processing of the same transaction hash reads through the
  stored response instead of crediting again.

## Fingerprint rule

The same idempotency key must not be reused with a different watcher payload.
The service stores a stable request fingerprint over tx_hash, amount, memo,
from_address and to_address. If the same deposit key appears with a different
fingerprint, the service raises `idempotency_fingerprint_mismatch` instead of
silently treating the payload as a normal replay.

This protects against watcher drift, malformed replay, and accidental reuse of
a tx_hash with inconsistent amount/address metadata.

## Runtime anchors

- `backend/app/services/efhc_deposits_service.py`
- `backend/app/models/admin_models.py::IdempotencyKey`
- `backend/app/services/transactions_service.py::credit_user_from_bank(...)`

## Forbidden regression

- Do not replace deposit duplicate protection with `_ttl_seen`, set/dict memory
  cache, process-local state, or short `expires_at` values.
- Do not purge `scope=deposit:efhc` records as ordinary short HTTP idempotency
  locks.
- Do not allow same-key/different-payload deposit replay to credit again.

## Guard

- `tests/architecture/test_heal0055_deposit_idempotency_kernel_start_core.py`
- `tests/architecture/test_p0_cross_guard_consolidation.py`
