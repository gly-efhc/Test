# ADS MEDIATION CANON — EFHC Bot

## Цикл 1747 — security hardening reward authority

- Browser/client completion сам по себе не является доказательством rewarded-ad и не имеет права разрешать EFHCb reward.
- `CLIENT_REWARD_AUTHORITY_MODES` допускает client-triggered reward только для режима с независимой provider-side проверкой; текущий подтверждённый режим — `sdk_completion_plus_server_task_check` (Adexium).
- AdsGram `sdk_completion_plus_session` и RichAds `server_bid_plus_client_completion` сохраняются как provider/runtime capabilities, но их client completion не является reward authority и fail-closed завершает reward verification до появления независимого server-verifiable подтверждения.
- Monetag и AdMaven server postback требуют независимый `postback_secret` (`efhc_token`) до проверки публичной session correlation. Сам `ymid`/`CLICK_ID` не является аутентификацией источника callback.
- Browser callback не имеет права перезаписывать server/provider revenue estimate, если не прошёл независимую provider-side проверку.
- `builtin_timer` остаётся только DEV/CI diagnostic: его client completion может завершить диагностическую session, но `_finalize_verified_reward()` запрещает production EFHCb reward.
- Для RichAds HTTP transport и provider-specific frontend CSP сохраняется отдельный эксплуатационный блокер: точный TLS/provider allowlist нельзя выдумывать без подтверждённого provider contract.

Статус: **ACTIVE / OWNER-APPROVED**  
Кандидат: `v173.65`  

## Exact-head qualification

GitHub CI `85380431378` на входном `v173.64` подтвердил успешные Alembic/Bandit/Mypy/frontend build/Ruff и остальные non-pytest gates; pytest завершился `4 failed / 1530 passed / 22 skipped / 1 warning`. Все четыре failures относятся к stale test/guard/documentation expectations и не подтверждают новый ADS runtime defect. Цикл 1739 не меняет mediation/reward architecture. Кандидат `v173.65` требует нового exact-head CI.

## 1. Назначение

Этот документ является active CANON рекламной инфраструктуры EFHC. Он фиксирует единый mediation layer между Tasks, рекламными сетями, Admin → ADS, Telegram Bot и существующим финансовым контуром EFHCb.

Главная цепочка:

`Tasks → AdManager → AdProviderRegistry → provider adapter → provider confirmation → AdSession verification → Task reward snapshot → tasks_service → EFHCb`

Ни Tasks, ни пользовательская страница не знают SDK/API конкретной сети. Provider не определяет размер EFHCb.

## 2. Authority и frontend

- Утверждённый `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` остаётся visual/text CANON.
- Отдельное owner approval для ADS распространяется только на:
  - новый runtime ADS mechanism/states внутри существующей Tasks presentation;
  - полноценный Admin → ADS;
  - ADS subsection/Preview в Admin → Tasks;
  - новые ADS locale keys для всех 13 active languages.
- Старый Bot frontend не является visual donor.
- Provider-specific SDK/API запрещено встраивать непосредственно в Tasks.

## 3. Единственный AdManager

Canonical backend service:

`backend/app/services/ads/ad_manager.py`

Canonical frontend facade:

`frontend/src/lib/ads/AdManager.ts`

Responsibilities backend:

- provider config resolution;
- eligibility;
- global priority;
- fallback;
- server-owned `ad_session`;
- UTC daily limits;
- locale/GEO context;
- callback/postback verification;
- idempotency;
- reward finalization;
- append-only analytics;
- revenue telemetry;
- provider health/circuit breaker.

Responsibilities frontend:

- runtime SDK loading;
- preload/show;
- normalized lifecycle;
- transparent fallback without second user click;
- client telemetry;
- safe status polling;
- no direct EFHCb accounting.

## 4. Provider registry

Provider descriptors live in:

`backend/app/services/ads/provider_registry.py`

Runtime adapters live in:

`backend/app/integrations/ads/`

Registered provider codes:

- `adsgram`;
- `monetag`;
- `richads`;
- `admaven`;
- `adexium`;
- `tads`;
- `mybid`;
- `builtin_timer` — diagnostics only.

Adding another network means adding a descriptor + adapter/client implementation; Tasks and the financial path are not rewritten.

## 5. Provider trust status

### AdsGram

- Mini App Rewarded: official SDK `Adsgram.init({blockId})` + `show()`.
- Registry compatibility label остаётся **C**, но после security hardening browser SDK completion + server-owned session недостаточны для EFHCb reward authority.
- До независимого provider-side подтверждения AdsGram completion используется только как telemetry/UX signal и fail-closed не начисляет EFHCb.
- Bot-native API is a separate provider boundary and does not create a second EFHC reward mechanism.
- Supplemental Reward URL signal may be recorded, but does not independently mint/credit EFHCb.

### Monetag

- Rewarded Interstitial/Popup.
- Correlation: signed EFHC `ymid`; correlation доступна browser и не является source authentication.
- Server postback до correlation-check обязан пройти independent `postback_secret` (`efhc_token`).
- Server postback payload: `reward_event_type`, `estimated_price`, provider event metadata.
- EFHC verification level: **B**.
- Only `valued` verified reward event may advance reward verification.

### RichAds

- Telegram SSP/server-bid adapter.
- Provider boundary may receive only allowed request context: language, IP, UA, Telegram subject if needed, Premium status if available, `motivated=true`, configured bid floor/widget/publisher.
- Registry compatibility label остаётся **C**, но server bid + client completion не доказывают provider-confirmed completion и после security hardening не разрешают EFHCb reward.

### AdMaven

- TMA task adapter + server postback correlation.
- EFHC-owned signed `CLICK_ID` binds provider event to one `ad_session`, но не аутентифицирует источник callback.
- Server postback отдельно обязан пройти independent `postback_secret` (`efhc_token`).
- EFHC verification level: **B**.

### Adexium

- TMA widget/manual mode.
- Client completion is checked against provider task-check boundary where available.
- EFHC verification level: **C**.

### TADS / MyBid

- Provider capability is registered and Admin-configurable.
- Exact reward-verification/callback contracts were not confirmed from a public publisher contract available to this implementation.
- Therefore both adapters are **fail-closed `NOT_SUPPORTED` for production rewarded mediation** until the owner provides/obtains cabinet SDK/callback contracts.
- It is forbidden to invent a callback or grant EFHCb on client-only assumptions.

### builtin_timer

- Not an advertising network.
- DEV/CI/diagnostic mechanism only.
- Excluded from `PRODUCTION_PROVIDER_CODES` and commercial fallback.
- Even a successful test-mode timer must not create production EFHCb.

## 6. Runtime configuration

Canonical precedence:

`Admin DB override → ENV fallback`

Rules:

1. explicit Admin value overrides ENV;
2. absent Admin value falls back to ENV when the field permits fallback;
3. empty credential is absent;
4. missing required field → `NOT_CONFIGURED`;
5. unconfigured/disabled/ineligible provider is skipped;
6. application does not crash because one provider is unavailable.

Frontend receives only public runtime config from the backend for the current session. Provider credentials are never build-time `NEXT_PUBLIC_*` configuration.

## 7. Secrets

Canonical encryption key:

`ADS_SECRETS_ENCRYPTION_KEY`

- secret values are encrypted with Fernet before DB persistence;
- decrypted values never return in Admin GET;
- Admin sees only masks such as `••••••••7A91`;
- supported operations: Replace/Delete/Test;
- audit stores only the action (`secret_replaced` / `secret_deleted`), never old/new value;
- secrets are forbidden in analytics, exceptions, OpenAPI examples and frontend runtime payload.

## 8. Database

Historical `efhc_core.ads` is preserved and remains a distinct ads/rotation contour.

New mediation tables in `efhc_core`:

- `ad_provider_configs`;
- `ad_sessions`;
- `ad_daily_counters`;
- `ad_events`;
- `ad_admin_audit_log`;
- `ad_provider_daily_metrics`.

Project remains pre-release with one Alembic head. New tables belong to `0001_initial_release_schema.py` through `RELEASE_METADATA.create_all()`; creating `0002+` is forbidden without owner decision.

## 9. AdSession state machine

Main states:

`created → provider_selected → loading → shown → completed → verified → rewarded`

Terminal/alternate states:

- `no_fill`;
- `failed`;
- `skipped`;
- `expired`;
- `fraud_rejected`.

Impossible transitions are rejected. One session may create no more than one reward.

Each session stores:

- business owner `global_id`;
- task code;
- primary and actual provider;
- provider correlation/ref;
- app language/GEO/platform;
- immutable `reward_snapshot_efhcb`;
- fallback count/attempted providers;
- verification level;
- estimated/confirmed revenue when available.

## 10. Identity

Business runtime uses only `global_id`.

Telegram `tg_id` is permitted only on a real provider/Bot boundary and must resolve:

`tg_id → provider identity → global_id → ADS business logic`.

Provider-required Telegram subject never becomes business owner.

## 11. API

Primary public contract:

- `POST /ads/session`;
- `POST /ads/session/{session_id}/fallback`;
- `POST /ads/session/{session_id}/shown`;
- `POST /ads/session/{session_id}/event`;
- `POST /ads/session/{session_id}/client-complete`;
- `GET /ads/session/{session_id}`;
- provider postback boundaries.

Compatibility-only:

- `GET /ads/slot`;
- `POST /ads/callback/{provider}`.

Compatibility routes must not become the new production reward architecture.

## 12. Fallback

Global order is operator configuration, not a claim about permanent profitability.

Selection skips:

- missing config;
- disabled provider;
- unsupported format;
- GEO/language restriction;
- open circuit;
- SDK/provider failure/no-fill.

Primary provider of a provider-specific task is always tried first. Fallback changes `actual_provider`, not task identity. If all candidates are exhausted → `NO_FILL`, no reward.

## 13. Daily limit

Daily completion key:

`global_id + task_code + UTC_date`

Default when not configured: `10` successful rewarded completions/day.

Limit is checked before the ad and atomically reserved again before reward finalization. Reset boundary is `00:00 UTC`.

## 14. Reward authority

Only Tasks owns reward size:

`Task.bonus_efhc → ad_session.reward_snapshot_efhcb → tasks_service`

Provider values named `reward`, `amount`, `bonus`, `estimated_price`, etc. can never change EFHCb amount.

Reward snapshot is immutable for a started session. A later Admin edit of the task cannot change that session's reward.

Canonical financial path remains the existing task bonus path and `TaskCompleteLock`; no parallel balance mechanism exists.

## 15. Idempotency / anti-fraud

Required safeguards:

- server-owned session + expiry;
- session owner validation;
- provider event deduplication;
- provider correlation validation;
- one reward/session;
- immutable reward snapshot;
- daily atomic reservation;
- task total-limit reservation;
- existing financial idempotency key `ads-session:{session_id}`;
- replay-safe postbacks;
- rate limiting;
- impossible transition rejection;
- suspicious retry/failure telemetry.

Reward-authoritative provider event является одноразовым финансовым claim, а не только telemetry identity. `(provider, provider_event_id)` закрепляется ровно за одной EFHC `session_id` и одним canonical `global_id` до reward finalization. Повтор той же claimed session является idempotent read-through; reuse другой session/user fail-closed отклоняется до EFHCb payout. Event-log deduplication сама по себе не является financial replay guard.

Frontend countdown or client-only completion never constitutes universal proof of a real advertisement.

## 16. Locale and GEO

Active languages:

`en, ru, uk, de, fr, es, it, tr, pl, da, hi, id, sw`.

Language resolution:

1. app language;
2. Telegram `language_code`;
3. `en`.

GEO must not request GPS. Country may remain NULL. Only a trusted configured proxy/CDN country header or provider-owned GEO may be used. Unknown GEO does not invent a country.

## 17. Health / circuit breaker

Health states:

`healthy → degraded → circuit_open → probe → healthy`

Technical SDK/timeout/5xx/credentials errors may degrade/open circuit. `NO_FILL` is inventory state and is recorded in analytics but does not by itself equal broken credentials/provider health.

## 18. Analytics and Revenue Optimizer

Canonical source: `ad_sessions` + append-only `ad_events`.

Provider attempt metrics are event-based. This is mandatory for fallback: if A gives no-fill and B shows successfully, A still receives its request/no-fill/fallback-out telemetry.

Revenue относится к провайдеру, фактически создавшему монетизируемое событие/сессию, и хранится раздельно как estimated/confirmed, чтобы не задваивать доход по lifecycle.

Optimizer uses observed EFHC data including:

- requests;
- fills/fill rate;
- impressions;
- completed views;
- valued events;
- clicks;
- errors/no-fill;
- fallback in/out;
- estimated/confirmed revenue;
- revenue/request;
- revenue/completed view.

No provider is hardcoded as permanently more profitable than another.

## 19. Admin → ADS

Admin ADS is the single management center for:

- provider cards;
- enable/disable;
- Mini App/Bot/rewarded flags;
- priority;
- provider-specific public config;
- masked secret Replace/Delete;
- GEO/language allow/block;
- moderation status;
- configuration/SDK/request tests without EFHCb;
- health/error reset;
- dashboard 24h/7d/30d/custom;
- provider/GEO/language/task metrics;
- Revenue Optimizer recommendation/apply.

All writes require Admin authorization and create audit records.

## 20. Admin → Tasks

For `watch_ad`, the editor exposes the owner-approved ADS subsection:

- primary provider;
- reward EFHCb from `Task.bonus_efhc`;
- daily limit (default 10);
- fallback switch;
- required format;
- task-level placement override;
- activity schedule;
- Active;
- Preview/Test with no EFHCb reward.

Provider dropdown comes from Admin → ADS; provider count is not hardcoded.

## 21. Telegram Bot

Universal command:

`/ads → WebApp → Tasks → AdManager`.

AdsGram bot-native creative is an additional official provider surface. It does not create a second EFHCb financial architecture. If unavailable/error → universal WebApp flow remains available.

`frontend/src/lib/telegram.ts::showTelegramAd()` is a compatibility capability probe only and returns `unsupported`; it is not in production provider registry and cannot issue reward.

## 22. Testing/qualification rule

Architecture tests protect this CANON, but local tests/CI/build are forbidden by project owner. The implementation remains:

`PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`

until the owner supplies GitHub CI for the exact new HEAD.

## Независимость completed view и reward obligation

Owner-Decision-Ref: `QA-2026-08-19-FIN3-04`.

Verified/completed ad view не откатывается из-за ошибки reward delivery.
EFHCb reward является отдельным idempotent obligation с business key `ads-session:<session_id>`.
Scheduler reconciliation выбирает `completed_at IS NOT NULL AND verified_at IS NOT NULL AND rewarded_at IS NULL`, повторно вызывает canonical Tasks financial credit с тем же idempotency key и после read-through/credit закрывает `rewarded_at` ровно один раз.
