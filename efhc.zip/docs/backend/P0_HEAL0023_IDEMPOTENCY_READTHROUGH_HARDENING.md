# HEAL-0023 idempotency read-through hardening

Status: DONE in `v169_89 / repair pass`.

## Problem

`transactions_service._insert_log()` raises `RuntimeError("IDEMPOTENCY_CONFLICT:<key>")` when an `ON CONFLICT DO NOTHING` insert sees an existing transfer log. The general detector previously only recognized generic database messages containing both `unique` and `idempotency_key`.

That meant the explicit EFHC conflict marker could be handled indirectly by the transient `conflict` retry path, but it was not a first-class idempotency condition.

## Repair

`backend/app/services/transactions_service.py` now treats the explicit marker as a real idempotency conflict:

```text
msg.startswith("idempotency_conflict:")
or "idempotency_conflict:" in msg
or ("unique" in msg and "idempotency_key" in msg)
```

All remaining direct case-sensitive `str(exc).startswith("IDEMPOTENCY_CONFLICT:")` checks in the service were replaced by the shared `_is_idempotency_conflict(...)` helper.

## Preserved invariant

The operation still uses read-through semantics:

1. check existing transfer log by `idempotency_key`;
2. perform money movement once;
3. insert transfer log with unique key;
4. if a same-key race occurs, read the existing log and return an idempotent result instead of applying the balance change twice.

## Guard

Active guard:

- `tests/architecture/test_heal0023_0018_idempotency_transaction_boundary.py`

The guard verifies the direct marker support, absence of old direct `startswith("IDEMPOTENCY_CONFLICT:")` checks, and documentation link.

## Non-claims

This cycle does not claim full concurrency proof, full pytest green, GitHub CI green or release readiness. It hardens the source-level detector before deeper transaction-boundary and withdraw atomicity work.
