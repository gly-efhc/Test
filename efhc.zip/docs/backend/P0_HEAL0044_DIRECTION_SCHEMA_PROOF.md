# HEAL-0044 transfer direction schema proof

Status: DONE in `v169.88 / repair pass`.

## Canon

`efhc_core.efhc_transfers_log.direction` must support the current direction contract without truncation. The ORM model uses:

```text
String(24)
```

## Problem

Fresh DBs created from the current ORM were already safe, but existing DBs could still have the older `varchar(8)` column. `create_all(checkfirst=True)` does not widen existing columns.

## Repair

`backend/migrations/versions/0001_initial_release_schema.py` now performs an idempotent existing-schema repair:

```sql
ALTER TABLE efhc_core.efhc_transfers_log
ALTER COLUMN direction TYPE varchar(24)
```

only when the live column width is below 24.

Sanity now fails if the live column is missing or shorter than 24.

## Guard

Active guard:

- `tests/architecture/test_heal0040_0044_payment_schema_contract.py`

It verifies both model and migration proof anchors.

## Follow-up

Full production proof requires a real Alembic/Postgres run. This cycle provides code and migration proof but does not claim GitHub CI green.
