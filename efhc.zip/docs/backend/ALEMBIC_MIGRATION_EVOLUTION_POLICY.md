# ALEMBIC MIGRATION EVOLUTION POLICY

Статус: **ACTIVE / PRE-RELEASE**

## Единственный допустимый lineage

- Alembic head: `0001_initial_release_schema.py`.
- Все pre-release schema changes вносятся в `0001`.
- Создание `0002+` без прямого решения пользователя запрещено.

## Обязательная согласованность

`ORM ↔ migration 0001 ↔ raw SQL ↔ services ↔ routes ↔ frontend ↔ tests`.

Изменение owner-колонки требует backfill, `NOT NULL`, FK, indexes,
unique/check constraints, triggers/functions inventory, fresh database
и upgrade существующей pre-release базы.

Номера retired trigger/function specs не переиспользуются и не
перенумеровываются автоматически.
