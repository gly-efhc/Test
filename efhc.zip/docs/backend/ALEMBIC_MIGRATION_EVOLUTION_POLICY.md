# ALEMBIC_MIGRATION_EVOLUTION_POLICY

Дата: 2026-05-27  
Цикл: 1329  
Статус: active backend migration policy

## 1. Текущее состояние

В текущем архиве есть первая миграция:

`backend/migrations/versions/0001_initial_release_schema.py`

Она создаёт стартовые схемы и таблицы через ORM metadata / `create_all(checkfirst=True)`.

## 2. Канон дальнейшего развития

`0001_init.py` нельзя переписывать задним числом ради новых моделей.

Если добавляется новая таблица, колонка, индекс, enum или constraint, должен появиться новый файл:

`backend/migrations/versions/0002_*.py`

Далее — `0003_*`, `0004_*` и так далее.

## 3. Почему это важно

Если `0001_init.py` уже применён в базе, `alembic upgrade head` не выполнит его повторно. Поэтому новые модели, добавленные только в metadata, не появятся в рабочей БД без новой миграции.

## 4. Проверка

Для production-like окружения нужна проверка:

- `alembic upgrade head`;
- `alembic check` при наличии живой Postgres DB;
- CI guard: изменение models должно сопровождаться новой миграцией `0002+`.

В этом цикле живой DB не использовался, поэтому `alembic check` не заявляется как выполненный.
