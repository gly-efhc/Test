# P0 HEAL-0055 — Deposit cache DB idempotency

Status: active canon after `v169.92 / repair pass`.

## Problem

Deposit duplicate protection must not rely on process-local TTL memory caches. In serverless or multi-instance deployment, memory is not shared, so a local `_ttl_seen` cache cannot be the source of truth for EFHC deposit replay protection.

## Canonical rule

EFHC deposit idempotency is DB-backed and long-retention:

- table: `efhc_admin.idempotency_key`;
- model: `IdempotencyKey`;
- scope: `deposit:efhc`;
- key: `deposit:efhc:<tx_hash>` or digest fallback when the key would exceed 128 chars;
- expiry: `expires_at = NULL` for deposit records;
- response: first completed response is stored in `response_payload_json` and returned on replay.

## Runtime entry

`backend/app/services/efhc_deposits_service.py::process_efhc_deposit()` must:

1. normalize amount;
2. build canonical deposit idempotency key and fingerprint;
3. read-through existing DB idempotency response;
4. reserve the DB idempotency key;
5. resolve user by memo/wallet;
6. store unresolved-user response if no user is found;
7. credit via `transactions_service.credit_user_from_bank(...)`;
8. store successful response for future replays.

## Acceptance

- No `_ttl_seen` process-local cache may be the deposit duplicate source of truth.
- Replaying the same tx hash must not credit twice.
- Response replay must work after process restart and across multiple app instances.
- HTTP TTL duplicate lock may remain only as an additional UX guard if it is DB-backed.


## v169.93 / repair pass update

- Deposit idempotency retention is explicit: `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- Deposit reserve/store paths use the retention constant instead of ad-hoc TTL values.
- Same idempotency key with a different watcher payload raises `idempotency_fingerprint_mismatch`.
- `tests/architecture/test_p0_cross_guard_consolidation.py` protects the repaired P0 invariants together.
