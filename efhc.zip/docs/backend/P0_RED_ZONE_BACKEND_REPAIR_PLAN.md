<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# v169_89 repair pass HEAL-0023 / HEAL-0018 update

`HEAL-0023` is repaired at source/guard level: `transactions_service._is_idempotency_conflict()` now directly recognizes the explicit `IDEMPOTENCY_CONFLICT:<key>` marker and all remaining local conflict branches use the shared helper.

`HEAL-0018` is mapped, not yet runtime-repaired: `docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md` classifies service-owned, route-owned, savepoint-only and mixed transaction zones. Runtime transaction-boundary repair remains scheduled for repair pass.

Active guard: `tests/architecture/test_heal0023_0018_idempotency_transaction_boundary.py`.

Remaining active plan cycles: 11 (`1410-1420`): transaction-boundary repair, withdraw/exchange atomicity, deposit-cache proof/policy, P0 cross-guards, targeted backend/log pass, closure audit, then FSM split.

# v169_88 repair pass HEAL-0040 / HEAL-0044 repair update

`HEAL-0040` is repaired at code/schema-contract level: `payment_intents.package_id` is nullable for custom/package-less intents, package-based intents still use real `package_id`, and fake `0` package sentinels are forbidden. Existing DBs are repaired through Alembic 0001 by dropping `NOT NULL` from `efhc_core.payment_intents.package_id`.

`HEAL-0044` is repaired at migration/schema-proof level: Alembic 0001 widens existing `efhc_core.efhc_transfers_log.direction` columns below `varchar(24)` and fails sanity if the live width is below 24.

Active guard: `tests/architecture/test_heal0040_0044_payment_schema_contract.py`.

Remaining P0 cycles: `HEAL-0023`, `HEAL-0018`, `HEAL-0024`, `HEAL-0055`, then FSM split.

# v169_87 repair pass HEAL-0045 repair update

`HEAL-0045` is repaired for the confirmed `referrals_crud.admin_top_inviters()`
defect. The function no longer joins `*_global_id` columns to internal `User.id`.
It now uses `User.global_id` for referral and bonus aggregates and returns
`inviter_global_id` as the identity field.

Active guard: `tests/architecture/test_heal0045_global_id_identity_canon.py`.

Remaining P0 cycles: `HEAL-0040`, `HEAL-0044`, `HEAL-0023`, `HEAL-0018`,
`HEAL-0024`, `HEAL-0055`, then FSM split.

# v169_86 repair pass alignment update

User decisions from repair pass are now confirmed:

- `HEAL-0040`: `payment_intents.package_id` may be nullable for custom/package-less deposit intents.
- `HEAL-0024` / `HEAL-0018`: service/route transaction-boundary repair is allowed where required.
- FSM split: `backend/app/bot/states.py` remains a compatibility facade.
- New deposit-cache requirement: no process-local `_ttl_seen` as the source of truth; deposit duplicate protection must use durable `efhc_admin.idempotency_key` records.

The active cycle order is superseded by `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_1404-1420_P0_BACKEND_DEPOSIT_CACHE_AND_FSM_PLAN.md`.

# P0 Red Zone backend repair plan

Status: ACTIVE REPAIR PLAN after repair pass.  
Base HEAD: `v169.84`.  
Plan HEAD: `v169.85 / repair pass`.

## Goal

Close all confirmed P0 / Red Zone backend risks without weakening tests, hiding failures or changing EFHC economics.

## Non-negotiable rules

- Logs first if fresh `logs_*.zip` is supplied.
- No test deletion, archiving, mass skip, xfail or `norecursedirs` hiding.
- No CI green claim without factual CI proof.
- No financial repair by disabling checks.
- `tg_id` is the canonical external Telegram/WebApp identity in route/service contours.
- Money changes must preserve Decimal/Numeric 8-digit precision and rounding DOWN.
- User-facing public/admin boundary is not touched by backend repairs.

## Cycle order

| Cycle | Target | Action | Acceptance proof |
|---:|---|---|---|
| 1404 | HEAL-0045 global_id identity canon repair | Repair referrals_crud joins/select/grouping to use User.global_id; add guard for global_id/User.id drift. | Guard proves no `*.global_id == User.id` join remains in protected backend paths; targeted referral/admin tests pass. |
| 1405 | HEAL-0040 payment_intents contract repair | User decision needed: recommended nullable package_id for custom deposit intents; add ORM/migration/route/test alignment. | ORM, SQL inserts, migration and route tests agree on `package_id` contract; custom deposit path does not violate schema. |
| 1406 | HEAL-0044 schema proof for transfer direction width | Add migration/schema guard proving direction varchar(24) for existing and fresh DB paths. | Schema guard proves fresh ORM/migration and existing DB migration path use `direction varchar(24)`. |
| 1407 | HEAL-0023 idempotency read-through conflict hardening | Directly catch IDEMPOTENCY_CONFLICT, preserve read-through, add concurrency/idempotency guard. | Conflict marker is detected directly; concurrent same-key call read-through returns existing log without second balance change. |
| 1408 | HEAL-0018 transaction boundary map | Audit callers and nested transaction helpers; define service-owned vs route-owned transaction contracts. | Transaction ownership map exists for each service helper; ambiguous nested paths are classified before code edits. |
| 1409 | HEAL-0018 transaction boundary repair | Remove unsafe nested workaround where possible; keep explicit savepoint only where documented and tested. | Session boundary repair passes targeted service tests and no `Session already begun` workaround is used as hidden policy. |
| 1410 | HEAL-0024 exchange/withdraw atomicity repair | Withdraw create/hold/mark atomic transition or formal two-phase state machine with replay tests; verify exchange lock path. | Withdraw create/hold/mark invariant is protected by atomic or formally two-phase state-machine tests; exchange row-lock proof retained. |
| 1411 | P0 cross-guard consolidation without deleting tests | Add source guards for identity/payment/idempotency/transaction/schema invariants; no skip/xfail. | Cross-guards active; no active protection removed. |
| 1412 | P0 backend targeted test and log repair | Run targeted backend tests; if logs supplied, logs first; no production-ready claim without CI proof. | Targeted backend checks pass locally or logs are used to repair exact failures first. |


## Important design choice — HEAL-0040

Current code shows a direct contract conflict:

- `PaymentIntent.package_id` is `nullable=False`;
- `create_intent_deposit_custom()` inserts `NULL` for `package_id`;
- `hub_routes.py` uses the custom deposit path.

Recommended canonical decision:

`package_id` is nullable for custom/package-less deposit intents and required for package-based intents.

This keeps the HUB custom deposit UX alive and aligns model, SQL, routes and tests. The alternative is to disable custom deposit, but that is a product decision and should not be done silently.

## Required guards to add during repair cycles

- `test_backend_global_id_identity_canon_guard.py` — no global_id column may join to `User.id`.
- `test_payment_intents_contract_guard.py` — package and custom intent contracts are explicit.
- `test_transfer_direction_schema_width_guard.py` — `direction` width is at least 24 in ORM/migration proof.
- `test_idempotency_conflict_readthrough_guard.py` — explicit `IDEMPOTENCY_CONFLICT` read-through.
- `test_withdraw_atomic_state_transition_guard.py` — withdraw request/hold/hold_done invariant.
- `test_transaction_boundary_contract_guard.py` — no uncontrolled nested transaction drift.

These guards must be added in the same cycles as the repairs, not all at once as failing future tests.

## v169.90 / repair pass — HEAL-0018 first runtime repair

- `transactions_service._tx_context()` no longer uses hidden `begin_nested()` as
  a blanket workaround for `Session already begun`.
- Core money transitions are service-owned: the helper commits or rolls back the
  active root session transaction for the money-service call.
- `exchange_service.exchange_kwh_to_efhc()` closes the read-only preflight
  transaction before invoking transactions_service.
- Remaining Red Zone work: HEAL-0024 withdraw create/hold/mark atomicity in
  repair pass, plus deposit-cache repair pass and FSM repair pass.

# v169_91 repair pass HEAL-0024 / Kernel update

`HEAL-0024` primary withdraw atomicity is repaired at source/guard level. `request_withdraw()` no longer creates the request, commits, performs hold in a second service-owned transaction, then marks `hold_done` in a third phase. The primary path now commits request row + hold transfer + audit meta + `hold_done=TRUE` together.

Operator Kernel optimization was also accepted because it reduces repeated manual cache work: `ops/operator_kernel/refresh.sh` regenerates caches, `routes.yaml` has `version: 1`, and `config_loader` validates that version on load.

Remaining active plan cycles: 9 (`1412-1420`): deposit-cache DB proof/policy, P0 cross-guards, targeted tests/log repair, closure audit, then FSM split.



## v169.92 / repair pass — HEAL-0055 application

Deposit duplicate protection now has a service-level DB idempotency layer:

- `process_efhc_deposit()` writes to `efhc_admin.idempotency_key`;
- `scope = deposit:efhc`;
- `expires_at = NULL` for long retention;
- completed responses are stored in `response_payload_json` for replay read-through;
- process-local `_ttl_seen` is forbidden as monetary/deposit source of truth.

repair pass remains for explicit long-retention policy hardening and reconciliation documentation.


## v169.93 / repair pass update

- Deposit idempotency retention is explicit: `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- Deposit reserve/store paths use the retention constant instead of ad-hoc TTL values.
- Same idempotency key with a different watcher payload raises `idempotency_fingerprint_mismatch`.
- `tests/architecture/test_p0_cross_guard_consolidation.py` protects the repaired P0 invariants together.
