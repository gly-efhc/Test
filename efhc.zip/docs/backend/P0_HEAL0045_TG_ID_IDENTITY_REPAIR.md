# HEAL-0045 global_id identity canon repair

Status: DONE for the confirmed `referrals_crud.admin_top_inviters()` defect in
`v169.87 / repair pass`.

## Canon

`tg_id` is the only external/user identifier in Telegram/WebApp/API and
business-domain paths. `users.id` is an internal database primary key and must
not be joined to, compared with or returned as a replacement for Telegram ID.

## Defect repaired

File:

- `backend/app/crud/referrals_crud.py`

Function:

- `admin_top_inviters()`

Before the repair, the query joined referral and bonus `global_id` fields against
`User.id`. That was an identity-canon violation.

## Correct identity path

| Data source | Identity column | Join target |
|---|---|---|
| `ReferralLink.inviter_tg_id` | Telegram ID | `User.tg_id` |
| `active_subq.c.tg_id` | Telegram ID | `User.tg_id` |
| `bonus_subq.c.tg_id` | Telegram ID | `User.tg_id` |
| Admin aggregate output | Telegram ID | `inviter_tg_id` |

## Guard

Active regression guard:

- `tests/architecture/test_heal0045_global_id_identity_canon.py`

It is intentionally static/source-level, because this defect was a SQL query
construction drift and must be caught even without a live database.

## Boundaries

- No EFHC economics changed.
- No public/admin UI changed.
- No wallet/TonConnect logic changed.
- No CI/workflow changed.
- No test was deleted, archived, skipped, xfailed or hidden.
- No sandbox runtime code was imported.

## Follow-up

Continue with `HEAL-0040` in repair pass. Do not mark the full P0 Red Zone
closed until HEAL-0040, HEAL-0044, HEAL-0023, HEAL-0018, HEAL-0024 and
HEAL-0055 are also repaired/proven.
