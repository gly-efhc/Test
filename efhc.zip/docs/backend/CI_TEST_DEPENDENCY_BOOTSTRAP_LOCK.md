# CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK

work pass
Archive: v169_14

## Rule

CI test dependencies must be installed through the root
`requirements-test.txt` file before any pytest collection starts.

## Required sequence

1. Install `backend/requirements.txt`.
2. Verify `requirements-test.txt` exists.
3. Install `requirements-test.txt`.
4. Import pytest bootstrap packages:
   - `pytest`;
   - `pytest_asyncio`;
   - `freezegun`;
   - `psycopg`;
   - `alembic`;
   - `jwt`.
5. Only then run `PYTHONPATH=backend pytest -q`.

## Runtime boundary

`backend/requirements.txt` must stay free of pytest-only helpers.
`freezegun` must not be restored to runtime dependencies.

## Reason

`logs_71056336346.zip` proved that a separate test dependency layer can be
correct in documentation but still fail in CI if the workflow does not prove
that pytest-only packages are installed before collection.

## work pass clarification

work pass does not weaken the test-dependency bootstrap rule. It adds an
archive-side simplification: core mathematical tests should not import optional
pytest helper packages when a standard-library proof is sufficient.

Therefore `tests/core/test_core_math_econ.py` no longer imports `freezegun`.
`ci.yml` remains a manual-control file and is not silently changed by the
assistant.
