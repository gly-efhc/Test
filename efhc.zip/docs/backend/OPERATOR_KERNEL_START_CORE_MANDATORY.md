# Operator Kernel Start Core mandatory preload

Status: active after `v169.92 / repair pass`.

## Rule

Operator Kernel is a mandatory part of archive navigation. Before analyzing any topic, load:

- `ops/operator_kernel/cache/file_map.json`;
- `ops/operator_kernel/config/routes.yaml`.

Then use `routes.yaml` to determine the focused file list. Without Kernel, navigation is considered suboptimal and may miss important files.

## Root marker

The root `KERNEL.md` exists to make this rule visible at archive entry.

## Cache freshness

`ops/operator_kernel/file_map.py` warns when `file_map.json` is missing or older than 7 days. Refresh command:

```bash
python ops/operator_kernel/file_map.py --refresh
```

The helper script remains:

```bash
ops/operator_kernel/refresh.sh
```

## Boundary

Kernel is route acceleration, not evidence. Exact files still must be opened before factual claims.
