# P0 cross-guard consolidation

Status: active after `v169.93 / repair pass`.

## Purpose

repair pass adds a cross-guard layer that checks all repaired P0 backend
invariants together without deleting, archiving, skipping or xfail-ing any
existing test.

## Covered invariants

- `HEAL-0045`: Telegram identity fields join and expose `User.tg_id`, not
  internal `users.id`.
- `HEAL-0040`: `payment_intents.package_id` is nullable for custom/package-less
  intents; package intents keep a real package id; fake package sentinel `0` is
  forbidden.
- `HEAL-0044`: `efhc_transfers_log.direction` remains `String(24)` in ORM and
  migration proof.
- `HEAL-0023`: explicit `IDEMPOTENCY_CONFLICT` is routed through the shared
  idempotency conflict detector.
- `HEAL-0018`: core money transaction context no longer hides root-boundary
  errors with blanket `begin_nested()`.
- `HEAL-0024`: withdraw request + hold + `hold_done=TRUE` remains one
  service-owned transition in the primary path.
- `HEAL-0055`: deposit idempotency remains DB-backed, non-expiring and protected
  by request fingerprint checks.

## Active guard

`tests/architecture/test_p0_cross_guard_consolidation.py`

This is an additive guard. It does not replace the more specific HEAL guards.
