# FSM states.py split TZ

Status: DONE in the FSM split range-closure repair pass.
Source file before repair: `backend/app/bot/states.py`.

## Problem

`backend/app/bot/states.py` was `50816` bytes and `1091` lines. It mixed:

- DTO/constants: `BotStates`, `ConversationState`, TTL/data limits;
- backend abstraction: `StateBackend`;
- backend implementation: `MemoryStateBackend`;
- manager singleton/factory: `StateManager`, `get_state_manager`;
- handler decorators: `require_state`, `advance_state`, `clear_state_after`.

This violated single responsibility and made FSM changes risky.

## Approved user decision

`backend/app/bot/states.py` must remain a compatibility facade during migration.
Existing imports from `app.bot.states` must continue to work until a later
import-migration cycle explicitly changes handler imports.

## Implemented structure

```text
backend/app/bot/fsm/
  __init__.py
  dto.py
  backend.py
  manager.py
  decorators.py

backend/app/bot/states.py
  compatibility facade
```

## Module responsibilities

| Module | Responsibility |
|---|---|
| `fsm/dto.py` | `BotStates`, `ConversationState`, `StateKey`, TTL/data-size constants. |
| `fsm/backend.py` | `StateBackend` protocol and `MemoryStateBackend`. |
| `fsm/manager.py` | `StateManager`, singleton `get_state_manager`, state sanitation and GC. |
| `fsm/decorators.py` | `require_state`, `advance_state`, `clear_state_after`, `Handler`. |
| `states.py` | Backward-compatible re-export facade only. |

## Import-safety note

`backend/app/bot/__init__.py` now lazily imports the heavy aiogram bot runtime.
This lets `app.bot.fsm` and `app.bot.states` import in lightweight tooling and
architecture tests without requiring bot runtime dependencies.

## Guard

Active guard:

- `tests/architecture/test_fsm_states_split_facade.py`

The guard protects:

- `states.py` remains a small facade;
- all split modules exist;
- public API from `app.bot.states` and `app.bot.fsm` is identical;
- FSM import does not force eager `aiogram` import through `app.bot.__init__`.

## Non-goals

This split does not change bot economics, balances, TON/TonConnect logic,
withdraw logic, deposit logic, CI workflow or package locks.
