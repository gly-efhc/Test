# BACKEND_DEPENDENCY_RUNTIME_POLICY

Дата: 2026-05-27  
Цикл: 1329  
Статус: active dependency hygiene policy

## 1. Runtime requirements

`backend/requirements.txt` должен содержать только зависимости, нужные backend приложению в runtime.

Test/dev пакеты не должны находиться в runtime-файле:

- `pytest`;
- `pytest-asyncio`;
- `freezegun`;
- linters/typecheckers.

## 2. Test/dev requirements

Тестовые зависимости должны жить в:

- `requirements-dev.txt`;
- `requirements-test.txt`.

## 3. Lock policy

В work pass создан настоящий runtime lock-файл:

`backend/requirements.lock`

Команда генерации:

`uv pip compile backend/requirements.txt -o backend/requirements.lock`

Lock-файл не должен включать `pytest`, `pytest-asyncio`, `freezegun` и другие test-only зависимости. Для dev/test слоя используются отдельные requirements-файлы.

## 4. work pass CI test dependency installation rule

work pass confirmed that keeping `freezegun` out of runtime
requirements is correct, but CI must still install the separate test
requirements before running pytest.

Active rule:

- `backend/requirements.txt` remains runtime-only;
- `requirements-test.txt` contains pytest-only helpers such as
  `freezegun==1.5.1`;
- `ci.yml` must install `requirements-test.txt` before `pytest -q`.

This preserves production dependency hygiene and prevents pytest
collection failures for tests that legitimately import test helpers.


## work pass CI sanity addendum

`logs_71033084031.zip` proved that splitting test-only packages is not
enough if CI does not verify the test dependency layer before pytest. CI now
checks that `requirements-test.txt` exists, installs it and imports
`freezegun` before running `pytest -q`. This does not move `freezegun` back
into runtime requirements.


## work pass bootstrap lock addendum

`logs_71056336346.zip` repeated the `freezegun` collection failure. The repair
keeps runtime requirements clean and expands `requirements-test.txt` into the
single pinned bootstrap file for pytest-only packages. CI must not rely on
scattered ad-hoc pytest installs when a test requirements file exists.

## work pass clarification

`freezegun` still must not return to runtime requirements. work pass removes
the only direct import from `tests/core/test_core_math_econ.py`, so the core
math/economics architecture test no longer requires `freezegun` to collect.

This is the preferred repair when a test can prove the invariant with the
Python standard library.
