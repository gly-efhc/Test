<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED EVIDENCE**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# P0 HEAL decision register and deposit cache plan

Status: ACTIVE after `v169_88 / repair pass`.  
Base: `v169_85 / repair pass`.

## Confirmed user decisions

| Topic | Decision | Canonical consequence |
|---|---|---|
| `HEAL-0040` payment intents | YES: `package_id` may be nullable for custom/package-less deposit intents. | Custom deposit intents can store `package_id = NULL`; package-based intents keep package contract. ORM, migration, SQL and tests must agree. |
| `HEAL-0024` / `HEAL-0018` | YES: transaction boundaries may be changed where required. | Repair must be cycle-by-cycle, with clear ownership: service-owned or route-owned transaction, no hidden nested begin. |
| FSM split | YES: keep `backend/app/bot/states.py` as compatibility facade. | New `backend/app/bot/fsm/*` modules can be introduced without breaking existing handler imports. |

## Deposit cache / HEAL-0055 decision

Duplicate deposit protection must not rely on process-local TTL memory caches such as `_ttl_seen`. The durable source must be DB-backed idempotency through `efhc_admin.idempotency_key`, with records retained long enough for payment/deposit reconciliation and audit.

Current HEAD already has a DB-backed helper for HTTP TTL duplicate locks:

- `_acquire_idempotency_ttl_lock(...)`;
- `_build_ttl_lock_key(...)`;
- `IdempotencyKey` model on `efhc_admin.idempotency_key`.

However, the archive still needs explicit proof that deposit/payment duplicate protection has long-retention DB idempotency and cannot regress to memory-only behavior.

## Required repair/proof cycles

| Cycle | Scope | Required result |
|---:|---|---|
| 1412 | `HEAL-0055` deposit-cache proof guard | Prove no `_ttl_seen`/process-local duplicate cache exists in runtime monetary middleware; prove DB-backed lock uses `efhc_admin.idempotency_key`. |
| 1413 | `HEAL-0055` long-retention deposit idempotency policy | Define and guard retention policy for deposit/payment idempotency records beyond short click-TTL; reconcile with payment intent confirmation and tx-hash lock. |

## Acceptance rules

- No process-local set/dict/cache may be the source of truth for monetary/deposit duplicate protection.
- HTTP TTL duplicate lock may remain only as an extra UX/safety guard if backed by `efhc_admin.idempotency_key`.
- Deposit confirmation must remain idempotent across retries, process restarts and multiple app instances.
- `external_tx_hash` / tx-hash lock / payment intent status must not credit the same deposit twice.
- If a fresh log contradicts this plan, logs win and must be read first.


## repair pass HEAL-0045 decision/application

The user asked to continue repair pass. The confirmed global_id/users.id drift was
repaired in `backend/app/crud/referrals_crud.py::admin_top_inviters()`.

Canonical consequence now locked:

- any field named `global_id`, `*_global_id`, `inviter_global_id`, `invitee_global_id` must be
  compared to `User.global_id`, not `User.id`;
- admin aggregates must expose Telegram identity as `inviter_tg_id`;
- internal `User.id` may remain only for internal database mechanics, not for
  Telegram/user-facing identity joins.

Guard: `tests/architecture/test_heal0045_global_id_identity_canon.py`.


## repair pass HEAL-0040 / HEAL-0044 application

The repair pass user decision for `HEAL-0040` has now been applied:

- `PaymentIntent.package_id` is nullable for custom/package-less intents.
- Package-based deposit intents continue to store a real package id.
- `create_intent_deposit_custom()` and `create_intent_shop_external()` store `NULL`.
- Fake package sentinel `0` is not allowed.

`HEAL-0044` schema proof has also been applied:

- `EfhcTransferLog.direction` remains `String(24)` in ORM.
- Existing DBs are widened to `varchar(24)` by Alembic 0001 when needed.
- Sanity fails if the live DB has a shorter direction column.

Guard: `tests/architecture/test_heal0040_0044_payment_schema_contract.py`.


## v169_89 / repair pass alignment

- `HEAL-0023`: direct explicit conflict marker handling is now required. `IDEMPOTENCY_CONFLICT:<key>` must not fall through generic transient retry logic as the only path; it is a first-class idempotency read-through condition.
- `HEAL-0018`: transaction-boundary runtime repair must use `docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_MAP.md` as the control map.
- repair pass deliberately made no runtime transaction-boundary rewrite. The next code-changing boundary cycle is 1410.

## repair pass decision application — HEAL-0018

User-approved transaction-boundary repair is now applied to the first core
money-service layer. `transactions_service` is service-owned for commit/rollback;
read-only preflight wrappers must not leave an autobegin transaction open before
money-service entry. `exchange_service` implements that rule. Withdraw remains
scheduled for HEAL-0024 in repair pass.

## repair pass decision/status update

- `HEAL-0024` primary withdraw request path is now atomic. Request row, hold transfer, audit meta and `hold_done=TRUE` are committed together.
- A no-commit transfer helper is allowed only for service-owned higher-level state machines; direct money services remain service-owned boundaries.
- Operator Kernel route config is now versioned (`routes.yaml` `version: 1`) and validated on load.
- Next deposit-cache cycles remain `1412-1413`: DB idempotency proof and long-retention policy.


## v169.92 / repair pass — HEAL-0055 application

Deposit duplicate protection now has a service-level DB idempotency layer:

- `process_efhc_deposit()` writes to `efhc_admin.idempotency_key`;
- `scope = deposit:efhc`;
- `expires_at = NULL` for long retention;
- completed responses are stored in `response_payload_json` for replay read-through;
- process-local `_ttl_seen` is forbidden as monetary/deposit source of truth.

repair pass remains for explicit long-retention policy hardening and reconciliation documentation.


## v169.93 / repair pass update

- Deposit idempotency retention is explicit: `DEPOSIT_IDEMPOTENCY_RETENTION_POLICY = "NON_EXPIRING"` and `DEPOSIT_IDEMPOTENCY_EXPIRES_AT = None`.
- Deposit reserve/store paths use the retention constant instead of ad-hoc TTL values.
- Same idempotency key with a different watcher payload raises `idempotency_fingerprint_mismatch`.
- `tests/architecture/test_p0_cross_guard_consolidation.py` protects the repaired P0 invariants together.
