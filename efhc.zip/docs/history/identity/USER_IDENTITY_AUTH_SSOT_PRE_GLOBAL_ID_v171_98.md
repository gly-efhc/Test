# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# CURRENT LEGACY ALIAS ADDENDUM — v171.95

Cycle 1598 fixes the compatibility boundary:

- active alias: `User.legacy_runtime_id -> User.id`;
- future alias: `User.id -> User.user_id`, inactive;
- deterministic future backfill: `NULL users.user_id -> users.id`;
- existing non-null `users.user_id` is preserved;
- `tg_id`, wallet address and provider subject never derive `user_id`;
- database execution and runtime read switch are false.

## Retained EXPAND addendum — v171.94

Status: `ACTIVE / CANONICAL`.

The physical nullable `efhc_core.users.user_id BIGINT` column now exists
in ORM metadata and linear Alembic revision `0002`. Existing rows are not
backfilled. `users.id` remains the primary key and `users.global_id` remains
NOT NULL. Domain ownership and authentication reads are unchanged.

TON authentication policy is fixed for the future resolver:

- `EXISTING_TON_IDENTITY` opens the same existing `user_id`;
- `VERIFIED_LEGACY_WALLET_BINDING` links the identity to the same user;
- `NEW_VERIFIED_TON_WALLET` atomically creates a new user, `user_id`,
  TON identity and wallet binding;
- wallet connection without valid TON Proof is not authentication;
- automatic merge of two existing accounts is forbidden.

# USER IDENTITY AND MODULAR AUTH SSOT

Status: `ACTIVE / CANONICAL`.
Introduced: cycle `1593`.
Contract hardened in cycle `1594`; nominal value types adopted in cycle `1595`; isolated API/Pydantic contract prepared in cycle `1596`, archive target `v171.93`.

## 1. System identity

The only target system and domain owner identifier is `user_id`.

Target physical column for the later expand migration:

```text
users.user_id BIGINT
```

Allowed database range:

```text
1..9999999999
```

External API, frontend, operator UI and reports use exactly ten ASCII
digits:

```text
0000000001
9999999999
```

The canonical external notation is `^\d{10}$`; implementation must
accept ASCII digits `0-9` only. `0000000000` is invalid. Frontend stores
`user_id` as a string and must never use a JavaScript number for it.

Cycles 1594-1596 do not change the current ORM schema, Alembic head,
FastAPI ownership dependencies or domain reads. The v171.93 runtime
still has legacy `users.id` and `users.global_id` semantics until their
assigned expand, backfill and read-switch cycles.

## 2. Canonical value types

The provider-independent foundation is:

```text
UserId          = immutable nominal value object wrapping a validated integer
UserIdDisplay   = validated canonical ten-digit external string
ExternalUserId  = strict Pydantic-ready external contract
TelegramId      = immutable nominal Telegram provider value object
```

Canonical helpers:

```text
validate_user_id()
validate_tg_id()
validate_user_id_display()
format_user_id()
parse_user_id()
user_id_from_database()
user_id_to_database()
is_user_id()
is_tg_id()
```

A raw integer is not accepted by `format_user_id()` or
`user_id_to_database()`. It must first cross the explicit validation or
database boundary. `UserId` is not an `int` subclass and cannot compare
equal to `TelegramId` solely because the wrapped numbers match.

The authoritative side-effect-free implementation is:

```text
backend/app/identity/types.py
```

In cycle 1595 these types have unit-level executable coverage but are
still not wired into ORM ownership, general routes, `AuthContext`, DTOs
or financial services. `runtime_wired = false`.


## 3. Cycle 1596 external API contract

The isolated API contract is:

```text
backend/app/identity/api_contract.py
```

It defines:

```text
ApiExternalUserId
PydanticUserId
UserIdRequest
UserIdResponse
USER_ID_OPENAPI_SCHEMA
```

`PydanticUserId` accepts a canonical ten-digit external string or an
already validated `UserId`, stores `UserId`, and serializes only the
canonical string. `ApiExternalUserId` is the scalar string contract for
future FastAPI path/query use.

```text
api_contract_prepared = true
active_routes_wired = false
existing_dtos_wired = false
orm_wired = false
runtime_ownership_switched = false
```

OpenAPI must expose `type: string`, pattern `^[0-9]{10}$`, length 10,
and no integer alternative. Existing API payloads remain unchanged in
cycle 1596.

## 4. Telegram identity

`tg_id` means only the Telegram user identifier.

It is allowed in:

- Telegram WebApp and Login adapters;
- Telegram Bot API and update handlers;
- Telegram HMAC and initData validation;
- `user_identities` provider data after auth-core implementation;
- Telegram delivery and source-event metadata;
- temporary registered legacy compatibility code.

It is not the target permanent owner key for balances, panels,
finance, roles, rewards, tasks, referrals, wallets or history.

The following equivalence and indirect conversion are forbidden:

```text
global_id = user_id
user_id = int(global_id)
UserId(tg_id)
```

A TON-only account has no synthetic, zero, negative, hashed or
wallet-derived `global_id`.

## 5. Provider identity

Every login provider resolves through one identity registry:

```text
provider + provider_tenant + provider_subject
→ user_id
```

The first independent provider is:

```text
TON Connect + TON Proof
```

Telegram remains operational as an authentication adapter. Google,
Apple, Facebook and other providers are not enabled in this migration
range.

A provider subject, wallet address, email, username or display name is
never converted directly into `user_id`.

## 6. Auth context

Target domain code receives a provider-independent `AuthContext`.

Required fields:

```text
user_id
user_id_display
provider
provider_subject
identity_id
session_id
roles
optional tg_id
optional wallet_address
```

General domain routes must depend on `get_current_user_id()` or
`get_current_auth_context()` only after the relevant read switch.

The current `get_current_tg_id()` remains a registered LEGACY
compatibility dependency. It does not become a system-ID alias.

## 7. Wallet identity and financial binding

These concepts are separate:

```text
user_identities(provider='ton_wallet')
wallet_bindings.user_id
```

A wallet identity grants login after proof verification. A wallet
binding records the financial relationship. A displayed frontend
address is never ownership proof and cannot be used as `user_id`.

## 8. Temporary compatibility doctrine

Each temporary alias, fallback or shadow write must have:

- an explicit `LEGACY` marker;
- bounded files or modules;
- a compatibility test;
- a metric or fail-closed guard;
- an assigned migration cycle;
- an assigned removal cycle.

Existing pre-read-switch tests that preserve Telegram-based joins or
route ownership are LEGACY runtime compatibility tests. They protect data
until backfill/read switch and do not define the target architecture.

## 9. Migration sequence

The only approved sequence is:

```text
EXPAND
→ BACKFILL
→ DUAL WRITE
→ READ SWITCH
→ VALIDATE
→ CONTRACT
```

Legacy columns are not removed before reconciliation, zero fallback,
complete runtime tests and a dedicated contract cycle.

## 10. Financial invariants

Identity migration must not change any balance, kWh amount, panel,
transaction, deposit, withdrawal, referral, reward, rank, wallet
balance, idempotency key or transaction lock.

Allowed monetary difference:

```text
0.00000000
```

## 11. Cycle 1595 enforcement

Cycle 1595 adds the immutable value-object implementation and a
481-file semantic/exact patch boundary:

```text
ops/identity/user_id_value_type_patch_boundary.json
ops/identity/check_user_id_value_type_boundary.py
```

It rejects premature imports outside `backend/app/identity`, protected
runtime semantic changes, new protected files and active legacy wording
that presents `tg_id` as the permanent sole system identifier.

No migration or runtime ownership switch is part of this cycle.

## 12. Cycle 1594 enforcement

Cycle 1594 adds only the type contract and stronger negative guards.
It uses:

```text
ops/identity/tg_id_domain_boundary_baseline.json
ops/identity/check_tg_id_domain_boundary.py
ops/identity/user_id_contract_patch_boundary.json
ops/identity/check_user_id_contract_patch_boundary.py
```

The patch boundary hash-locks models, services, CRUD, routes, schemas,
migrations and frontend source. Only the side-effect-free identity type
package may be added to runtime code in this cycle.

## 13. Historical documents

Historical statements that define `tg_id` as the only EFHC user
identifier describe the pre-cycle-1593 runtime. Historical tests may
continue to verify that legacy runtime until its assigned migration.
They do not override this SSOT for new architecture or new code.


## 13. Cycle 1597 physical expand

The active Alembic chain is now:

```text
0001 -> 0002
```

Revision `0002_users_user_id_expand.py` adds:

```text
efhc_core.users.user_id BIGINT NULL
efhc_core.users_user_id_seq
UNIQUE(users.user_id)
CHECK user_id IS NULL OR user_id BETWEEN 1 AND 9999999999
```

It performs no historical-row backfill and no runtime read switch.
`users.id` remains the primary key and `users.global_id` remains NOT NULL.

## 14. TON wallet account-resolution decision

A wallet address is accepted only after valid TON Proof. The future
`purpose=login` resolver has exactly three successful branches:

```text
EXISTING_TON_IDENTITY
→ return its existing user_id

VERIFIED_LEGACY_WALLET_BINDING
→ attach ton_wallet identity to the binding's existing user_id
→ return that same user_id

NEW_VERIFIED_TON_WALLET
→ create users + new user_id + ton_wallet identity
  + wallet binding in one transaction
→ create_new_user_id = true
```

Rules:

```text
automatic_account_merge = false
wallet_connection_without_proof = not_authenticated
wallet_owned_by_other_user = conflict
concurrent_new_wallet_registration = one_user_only
```

A new TON-only account is therefore allowed by the target architecture.
It is not enabled in cycle 1597 because auth tables, sessions,
challenges, verified-wallet backfill and nullable `users.global_id` are not
yet complete.
