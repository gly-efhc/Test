# Статус диапазона после цикла 1601

Цикл `1601 — открытие диапазона и приёмка фундамента` завершён на
`v171.98`. Фундамент принят без backfill/read switch. Исправлена
доказательность генераторов audit/preflight. Следующий разрешённый цикл
— `1602 — независимый reconciliation baseline`; его PostgreSQL exit
gate остаётся заблокированным до предоставления реальной среды.

# EFHC Bot — канонический план рабочих циклов 1601–1700

**Направление:** переход от Telegram-зависимой модели пользователя к системному `user_id`, модульному auth-ядру и первому независимому входу `TON Connect + TON Proof`.

**Current HEAD после закрытия фундамента:** `EFHC_Bot_v171_97.zip`  
**Последний подтверждённый завершённый цикл на момент постановки:** `1592`  
**Диапазон этого документа:** `1601–1700` — ровно 100 последовательных циклов.  
**Стратегия данных:** `EXPAND → BACKFILL → DUAL WRITE → READ SWITCH → VALIDATE → CONTRACT`.

> Циклы `1593–1600` не перенумеровываются и не входят в этот документ. Они являются предшествующим фундаментальным диапазоном: повторный аудит, Cycle 0, начало/закрытие безопасного Cycle 1, первичные locks, guards и подготовка входного gate для цикла 1601.

> Статус после цикла 1600: фундамент `1593–1600` локально закрыт.
> Реальная PostgreSQL reconciliation остаётся обязательной внешней
> блокировкой; historical backfill и read switch запрещены.
> Цикл `1601` начинает приёмку с `v171.97`, следующий changed HEAD —
> `v171.98`.


## 1. Каноническая нумерация и версии

- Нумерация циклов проекта продолжается после `1592`; локальная нумерация `0–15` запрещена в именах рабочих циклов и отчётов.
- При строгом правиле «один завершённый цикл с фактическими изменениями = одна последовательная версия» плановый слот цикла `1601` — `v171.98`, цикла `1602` — `v171.99`, цикла `1603` — `v172.00`, цикла `1700` — `v172.97`.
- Цикл без фактических изменений не создаёт новый development/release HEAD и не потребляет номер версии.
- Каждый changed HEAD выпускается двумя отдельными архивами: development и `_RELEASE`, с внешними SHA-256 и receipts.

## 2. Неприкосновенные инварианты всего диапазона

1. `users.user_id` — единственный системный и доменный идентификатор пользователя.
2. `tg_id` — только внешний Telegram ID: adapter, identity, Telegram API, source event или явно зарегистрированный LEGACY compatibility context.
3. В PostgreSQL `user_id` — `BIGINT` в диапазоне `1–9999999999`; во внешнем API/UI — строка `^\d{10}$`; `0000000000` запрещён.
4. `wallet_address` не является пользователем; `ton_wallet` identity и финансовый `wallet_binding` остаются разными сущностями.
5. Telegram и TON обязаны открывать один `user_id`, когда подтверждённая identity принадлежит одному существующему аккаунту.
6. Автоматическое объединение двух существующих аккаунтов запрещено.
7. Экономика, balances, kWh, панели, транзакции, награды, рефералы, Decimal precision, locks и idempotency не изменяются auth-миграцией.
8. Допустимое денежное расхождение до/после каждого data cycle: `0.00000000`.
9. Legacy columns удаляются только после полного backfill, reconciliation, fallback=0, validated constraints и отдельного contract cycle.
10. `PRODUCTION_RELEASE_READY` запрещён без реального deployment, restore, rollback и live proof.

## 3. Волны диапазона

| Волна | Циклы | Результат |
|---|---:|---|
| I. Идентификаторы и фундамент | `1601–1610` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| II. Модульное auth-ядро | `1611–1620` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| III. Независимый TON Proof login | `1621–1630` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| IV. Frontend TON session-first | `1631–1640` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| V. Telegram как адаптер | `1641–1650` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VI. Expand доменной схемы | `1651–1660` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VII. Backfill и reconciliation | `1661–1670` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VIII. Dual-write и финансовый read switch | `1671–1680` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| IX. Миграция предметных модулей | `1681–1690` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| X. API/frontend/contract/release closure | `1691–1700` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |

## 4. Подробный план циклов

Каждый цикл ограничен одной причинно связанной задачей. Нельзя переносить следующий read switch или contract cleanup вперёд, пока не закрыт exit gate предыдущей волны.

### I. Идентификаторы и фундамент — циклы 1601–1610

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1601** | Открытие диапазона и приёмка фундамента | Проверить, что циклы 1593–1600 закрыли повторный аудит, архитектурные locks, базовый UserId и безопасный expand без изменения экономики. Зафиксировать exact HEAD, SHA-256, ZIP entries и незавершённые хвосты. | Есть подписанный baseline; нет скрытых изменений балансов, панелей, рефералов и идентичностей; входные reconciliation-метрики сохранены. | **Высокий** |
| **1602** | Независимый reconciliation baseline | Создать машинно-проверяемый pre-migration снимок пользователей, tg_id, кошельков, балансов, kWh, панелей, транзакций, выводов, рефералов, ролей, orphan и конфликтов. | Baseline воспроизводим на PostgreSQL; денежное расхождение равно 0.00000000; отчёт хранится вне release. | **Критический** |
| **1603** | Канонизация users.user_id | Проверить и завершить переход модели User на физическую колонку users.user_id BIGINT в диапазоне 1–9999999999 с временным LEGACY alias User.id. | User.user_id является SSOT; alias документирован, покрыт тестом и имеет цикл удаления; tg_id не вычисляет user_id. | **Критический** |
| **1604** | Backend UserId type system | Ввести UserId, TelegramId, format_user_id(), parse_user_id(), Pydantic-типы и единые ошибки валидации. | Все unit tests проходят; 0000000000 отклоняется; значения вне диапазона отклоняются; внутреннее хранение остаётся BIGINT. | **Средний** |
| **1605** | Frontend UserId string system | Ввести branded string-тип UserId, валидатор ^\d{10}$, форматирование и запрет JS number для системного ID. | TypeScript не допускает арифметику с user_id; сериализация сохраняет ведущие нули; typecheck и build зелёные. | **Высокий** |
| **1606** | API-контракт десятизначного user_id | Обновить базовые DTO/OpenAPI-контракты так, чтобы внешний user_id передавался строкой из десяти цифр, не меняя действующие domain payload раньше read switch. | Контракт backward-compatible там, где ещё требуется legacy; новые общие DTO не называют Telegram ID user_id. | **Высокий** |
| **1607** | Разделение UserId и TelegramId | Добавить статические и runtime guards против присваивания tg_id в user_id, передачи user_id в Telegram API и использования wallet_address как пользователя. | Негативные тесты ловят смешение типов; допустимые Telegram-specific участки не блокируются. | **Высокий** |
| **1608** | Строгий tg_id allowlist | Перевести guard новых tg_id-употреблений из наблюдения в fail-closed режим с явным allowlist Telegram adapters, identity registry, source events и legacy parsers. | Любое новое доменное поле/параметр tg_id вне allowlist ломает CI с точным file:line. | **Высокий** |
| **1609** | Реестр compatibility aliases | Составить единый реестр LEGACY aliases, fallback, dual-write shadow и legacy API с владельцем, тестом, метрикой и циклом удаления. | Нет безымянных aliases; каждый переходный механизм имеет sunset cycle и fail-closed guard. | **Средний** |
| **1610** | Закрытие волны идентификаторов | Выполнить migration dry-run, unit/API/type tests, reconciliation и независимую проверку development/release packaging. | Волна 1601–1610 закрыта; экономика неизменна; следующий exact HEAD допускает создание auth core. | **Критический** |

### II. Модульное auth-ядро — циклы 1611–1620

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1611** | Контракт AuthProvider | Создать provider-neutral Protocol/ABC, VerifiedIdentity и ошибки провайдера без создания пользователя и без доступа к игровой экономике. | Mock provider проходит контрактные тесты; будущий провайдер подключается без изменения domain services. | **Средний** |
| **1612** | Provider registry и feature flags | Создать реестр провайдеров, обязательную конфигурацию, disabled state и fail-closed startup validation. | TON и Telegram регистрируются явно; Google/Facebook/Apple отсутствуют в runtime UI и остаются disabled. | **Средний** |
| **1613** | Таблица user_identities | Добавить expand migration и ORM для user_identities с UNIQUE(provider, provider_tenant, provider_subject), FK на users.user_id и revoke/login flags. | Миграция upgrade/downgrade проверена; один provider subject не связывается с двумя users. | **Критический** |
| **1614** | IdentityResolver | Реализовать разрешение verified provider identity в user_id, включая conflict result и запрет автоматического merge двух существующих аккаунтов. | Resolver детерминирован, транзакционен и не принимает непроверенный subject от клиента как SSOT. | **Критический** |
| **1615** | Таблица auth_challenges | Добавить challenge_id, provider, purpose, challenge_hash, nonce_hash, domain, nullable user_id, TTL, consumed_at и metadata. | Challenge криптографически случаен, одноразов, purpose-bound и domain-bound; plaintext secret не хранится. | **Критический** |
| **1616** | Таблица auth_sessions | Добавить server-side session registry с hash opaque token, expires/revoked/last_seen и device metadata с минимизацией данных. | В БД отсутствует plaintext token; logout и logout-all аннулируют сессии; cookies имеют Secure/HttpOnly/SameSite. | **Критический** |
| **1617** | AuthContext и зависимости FastAPI | Добавить AuthContext, get_current_auth_context(), get_current_user_id(), get_current_user(), require_authenticated() и role dependencies. | Общий endpoint работает без tg_id; Telegram-specific endpoint может явно потребовать Telegram identity. | **Критический** |
| **1618** | user_roles и permissions core | Создать либо нормализовать user_roles на user_id, role registry и require_role/require_any_role без Telegram whitelist как конечного SSOT. | Роли принадлежат users.user_id; provider не определяет полномочия; legacy whitelist ещё не удаляется. | **Высокий** |
| **1619** | Auth audit и secret redaction | Добавить auth audit events, correlation IDs, безопасную диагностику и redaction initData, proof, session token, nonce и OAuth-like secrets. | Security tests подтверждают отсутствие полных секретов в логах, traces и ошибках API. | **Высокий** |
| **1620** | Auth core PostgreSQL gate | Запустить миграции и integration suite для identities, challenges, sessions, roles, resolver и concurrency на настоящем PostgreSQL. | Auth core зелёный, 0 skipped в обязательной integration-группе; финансовые таблицы не изменены. | **Критический** |

### III. Независимый TON Proof login — циклы 1621–1630

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1621** | Аудит существующего TON Proof | Разобрать текущий challenge/proof flow, найти зависимости от заранее известного global_id, frontend trust и недостаточные проверки криптографии. | Создан exact file:line report; отделены connection, ownership proof, signed, broadcast, confirmed и settled. | **Высокий** |
| **1622** | Независимый TON challenge endpoint | Реализовать POST /api/auth/v1/ton/challenge для purpose=login без текущего пользователя и для link/step_up с AuthContext. | Ответ содержит только challenge_id и public payload; nonce не переиспользуется и не связывается с tg_id. | **Критический** |
| **1623** | Канонический TON address resolver | Проверять workchain/address, public key и wallet state init; сохранять единое canonical raw address representation. | Один кошелёк не получает несколько identity из-за friendly/raw/testnet вариантов. | **Критический** |
| **1624** | Криптографическая проверка TON Proof | Реализовать/проверить подпись, public key, payload, domain, timestamp, network и state init по фактическому TON Proof контракту. | Положительные vectors проходят; modified signature/public key/payload отклоняются. | **Критический** |
| **1625** | Replay, TTL и consumption | Атомарно потреблять challenge, проверять TTL, purpose, domain и повторное использование под row lock/unique guarantee. | Два конкурентных verify запроса дают ровно одну успешную сессию; replay отклонён. | **Критический** |
| **1626** | Вход существующей TON identity | Разрешать существующую ton_wallet identity в прежний user_id без изменения wallet binding или доменных активов. | Повторный вход всегда открывает один аккаунт; balances/panels/referrals идентичны Telegram-входу. | **Критический** |
| **1627** | Связь с подтверждённым wallet_binding | Если identity отсутствует, но active proof_verified wallet binding уникально принадлежит существующему user_id, создать identity тому же пользователю. | Не создаётся дубликат аккаунта; конфликтующие bindings переводятся в fail-closed ручную проверку. | **Критический** |
| **1628** | Создание TON-only пользователя | Создать users + ton_wallet identity + обязательные стартовые записи + wallet_binding одной транзакцией без фиктивного global_id. | TON-only пользователь имеет nullable global_id, корректный user_id и нулевые стартовые балансы без бонусных повторов. | **Критический** |
| **1629** | Concurrency TON registration | Защитить конкурентное создание одного кошелька через unique constraints, locks и idempotent read-through. | Параллельные verify не создают двух users, identities или wallet bindings. | **Критический** |
| **1630** | TON auth security closure | Закрыть challenge/verify/session/logout API, security tests и PostgreSQL integration proof для TON login. | Все обязательные TON Proof негативные сценарии проходят; feature flag остаётся управляемым. | **Критический** |

### IV. Frontend TON session-first — циклы 1631–1640

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1631** | Frontend auth API client | Создать frontend/src/features/auth/api с challenge, verify, session, logout и типизированным error mapping. | Компоненты не вызывают raw auth endpoints напрямую; user_id остаётся string. | **Средний** |
| **1632** | AuthProvider и AuthGate | Создать frontend AuthProvider, AuthSession, AuthGate и provider-neutral состояние загрузки/ошибки/сессии. | Игровые страницы получают пользователя только из server session, не из Telegram global object. | **Высокий** |
| **1633** | TON Connect login screen | Добавить реальный TON login entrypoint без фиктивных Google/Facebook/Apple кнопок. | Кнопка доступна только при корректной backend/provider конфигурации; disabled state честно отображён. | **Средний** |
| **1634** | TON Proof request lifecycle | Связать challenge payload с TonConnect proof request, обработать отмену, disconnect, retry и stale challenge. | Frontend не объявляет proof подтверждённым до backend verify и выдачи сессии. | **Высокий** |
| **1635** | Auth error taxonomy | Согласовать backend/frontend коды expired, replay, wrong_domain, wallet_conflict, provider_disabled и session_invalid. | Пользователь получает безопасное сообщение; техническая диагностика коррелируется без утечки secrets. | **Средний** |
| **1636** | TON-only профиль | Обеспечить профиль и общие игровые shell-компоненты без Telegram username/tg_id, с отображением десятизначного user_id. | TON-only пользователь открывает базовые общие страницы без synthetic tg_id. | **Высокий** |
| **1637** | Provider UI registry | Формировать login UI только из реально enabled providers и серверной capability-конфигурации. | Неработающие провайдеры не видны; включение без обязательной конфигурации блокирует startup/CI. | **Средний** |
| **1638** | Cookie, CORS и CSRF hardening | Проверить Secure/HttpOnly/SameSite, trusted origins, credentials, CSRF для state-changing session endpoints и redirect policy. | Произвольные origins/redirects отклоняются; session token недоступен JavaScript. | **Критический** |
| **1639** | Frontend TON auth E2E | Добавить Playwright/mock-wallet E2E для success, cancel, expired, replay, conflict и session restore. | E2E выполняется против реального backend/test PostgreSQL, без page.set_content и synthetic application shell. | **Высокий** |
| **1640** | TON frontend wave closure | Выполнить typecheck, production build, E2E, visual checks login/profile и exact-HEAD packaging. | TON login contour готов к совместному использованию с Telegram adapter; live wallet proof ещё не подменяется mock proof. | **Критический** |

### V. Telegram как адаптер — циклы 1641–1650

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1641** | Backfill Telegram identities | Создать verified telegram identities для существующих users.tg_id, сохранив точное соответствие и отчёт конфликтов. | Количество уникальных tg_id совпадает; ни один user_id не изменён; orphan не исправляются предположениями. | **Критический** |
| **1642** | Telegram WebApp adapter | Преобразовать проверенный initData в VerifiedIdentity(provider=telegram, subject=tg_id) и передать IdentityResolver. | HMAC/auth_date/TTL/replay проверяются backend; domain logic не получает tg_id как owner key. | **Критический** |
| **1643** | Telegram Login adapter boundary | Подготовить отдельный адаптер Telegram Login по тому же provider contract без смешения с Mini App initData. | Оба Telegram flow возвращают единый provider subject contract; неавторизованный flow disabled. | **Высокий** |
| **1644** | Повторный вход существующего Telegram user | Гарантировать, что существующий tg_id всегда разрешается в прежний user_id и прежние активы. | Regression snapshot по balance/panels/referrals/roles полностью совпадает. | **Критический** |
| **1645** | Первый Telegram onboarding через identity | Создавать users + telegram identity и реферальную атрибуцию одной транзакцией при первом входе. | Сохранены permanent-zero, invalid-code rollback, self-referral/cycle guards и Activ-канон. | **Критический** |
| **1646** | request.state.auth_context | Перевести middleware на request.state.auth_context; request.state.tg_id оставить только LEGACY shadow для allowlisted кода. | Общие routes не зависят от state.tg_id; compatibility usage измеряется метрикой. | **Высокий** |
| **1647** | LEGACY get_current_tg_id adapter | Оставить get_current_tg_id() поверх AuthContext только для объективно Telegram-specific операций и добавить sunset guard. | Общий endpoint с этой зависимостью ломает CI; TON-only пользователь получает явную TelegramIdentityRequired. | **Высокий** |
| **1648** | Telegram-specific endpoint policy | Разделить общие игровые endpoints и Telegram actions/notifications, требующие tg_id. | API inventory однозначно маркирует Telegram-only routes; security tests проверяют границу. | **Средний** |
| **1649** | Notifications через identity lookup | Перевести сервис уведомлений на вход user_id с последующим поиском активной Telegram identity. | TON-only пользователь не получает фиктивный tg_id; отсутствие канала обрабатывается явно и идемпотентно. | **Высокий** |
| **1650** | Telegram compatibility closure | Запустить Telegram onboarding/session/role/referral regression и cross-provider same-account tests. | Mini App не имеет регрессий; tg_id больше не является системным владельцем в новых auth flows. | **Критический** |

### VI. Expand доменной схемы — циклы 1651–1660

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1651** | Повторная ORM-матрица перед expand | Пересканировать все ORM/SQL/DTO/service зависимости и заморозить точный список owner/actor/source global_id перед доменными миграциями. | Матрица содержит file:line, категорию, действие, цикл и риск; false positives отделены. | **Высокий** |
| **1652** | Expand финансовых таблиц | Добавить nullable user_id/actor_user_id в transactions, deposits, payment_intents, withdrawals, outcomes и связанные ledger tables без изменения сумм. | DDL не пересчитывает Numeric; индексы созданы безопасно; legacy global_id сохранён. | **Критический** |
| **1653** | Expand wallet и lock tables | Добавить user_id в wallet_bindings, wallet proof uses, connect idempotency, tx hash locks и иные ownership/lock таблицы. | Уникальность wallet/tx/idempotency сохранена; wallet address не становится user_id. | **Критический** |
| **1654** | Expand panels и energy | Добавить user_id в panels, panels_archive, generation/scheduler-owned records и необходимые индексы. | Панели не пересоздаются; statuses/dates/generated totals остаются byte/decimal-identical. | **Критический** |
| **1655** | Expand referrals, tasks и ranks | Добавить inviter_user_id, invitee_user_id, user_id и moderator_user_id в referral/task/rank/achievement tables. | Activ остаётся по activated_at; награды и пороги не пересчитываются. | **Критический** |
| **1656** | Expand shop, NFT и cosmetics | Добавить user_id в orders, shop, skins, cosmetics, NFT checks и related locks. | Покупки/скины/NFT ownership не меняются; legacy columns остаются до contract. | **Высокий** |
| **1657** | Expand admin actors и RBAC | Добавить added_by_user_id, granted_by_user_id, moderator_user_id и user_id для admin ownership/roles. | Legacy whitelist сохранён для backfill; новые permissions ссылаются на user_id. | **Высокий** |
| **1658** | Expand source events и TON logs | Добавить resolved_user_id рядом с parsed_global_id и иными внешними идентификаторами, сохраняя raw source semantics. | parsed_global_id остаётся атрибутом события; финансовый owner определяется только resolved_user_id. | **Высокий** |
| **1659** | FK/index deployment strategy | Добавить индексы, NOT VALID FK/checks либо эквивалентную безопасную стратегию для больших таблиц без длительной блокировки. | План lock-time измерен на clone; rollback и повторный запуск проверены. | **Критический** |
| **1660** | Schema expand closure | Прогнать Alembic upgrade/downgrade/upgrade, schema diff, ORM import и production builder. | Все новые поля nullable; ни одно legacy поле не удалено; приложение совместимо с прежним чтением. | **Критический** |

### VII. Backfill и reconciliation — циклы 1661–1670

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1661** | Backfill Telegram identity map | Материализовать однозначную таблицу legacy tg_id → user_id через user_identities и запретить догадки для orphan. | 0 конфликтующих provider subjects либо все конфликты явно quarantined. | **Критический** |
| **1662** | Backfill verified TON identities | Создать ton_wallet identities только из уникальных active proof_verified wallet_bindings после canonical address reconciliation. | Неподтверждённые users.ton_wallet не превращаются в login identity. | **Критический** |
| **1663** | Backfill финансового owner | Заполнить user_id финансовых таблиц через identity map в контролируемых batches с audit counters. | Суммы до/после равны до 8 знаков; orphan rows не удалены и не перепривязаны. | **Критический** |
| **1664** | Backfill wallet и idempotency owner | Заполнить user_id в wallet/lock/idempotency tables и проверить unique/ownership conflicts. | Один wallet/tx hash/idempotency key не связывается с разными users. | **Критический** |
| **1665** | Backfill panels и energy owner | Заполнить user_id в panels/archive/generation/scheduler records без изменения статусов и totals. | Количество панелей по каждому статусу и generated kWh полностью совпадает. | **Критический** |
| **1666** | Backfill referrals, tasks и ranks | Заполнить user/actor ids в referral/task/rank/achievement tables и проверить граф/пороговые награды. | Реферальные связи, activated_at, Lvl awards и task rewards идентичны baseline. | **Критический** |
| **1667** | Backfill shop, NFT и admin actors | Заполнить ownership/actor user_id для shop/NFT/cosmetics/admin roles и whitelist. | Покупки, роли и права не потеряны; ambiguous actors остаются nullable/report-only. | **Высокий** |
| **1668** | Orphan и conflict quarantine | Создать fail-closed отчёты и operational queue для orphan tg_id, duplicate wallet, conflicting provider subject и broken FK candidates. | Ни один конфликт не исправлен автоматически; deployment gate видит точное количество. | **Критический** |
| **1669** | Полная финансовая reconciliation | Сравнить 17+ канонических метрик до/после, включая balances, kWh, panels, tx, withdrawals, referrals, roles, locks. | Денежное расхождение 0.00000000; все count differences объяснены только новыми auth rows. | **Критический** |
| **1670** | Backfill closure и freeze | Зафиксировать backfill version, checksums, batch receipts и запрет повторного небезопасного выполнения. | Backfill идемпотентен; повторный запуск не меняет данные; dual-write может включаться feature flag. | **Критический** |

### VIII. Dual-write и финансовый read switch — циклы 1671–1680

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1671** | Dual-write framework | Создать единый owner-write helper: user_id SSOT, legacy global_id server-resolved shadow, mismatch fail-closed и metrics. | Клиентский global_id не принимается как owner; TON-only записи не получают фиктивный shadow. | **Критический** |
| **1672** | Fallback telemetry | Добавить метрики read fallback, dual-write mismatch, unresolved identity и legacy endpoint usage с cycle-removal targets. | Каждый fallback наблюдаем; нулевое значение является обязательным gate перед contract. | **Высокий** |
| **1673** | Users CRUD read switch | Перевести user CRUD/repositories/locks на user_id, оставив global_id только отдельным identity-search методом. | Поиск user_id и поиск global_id имеют разные именованные API; FOR UPDATE блокирует системного пользователя. | **Критический** |
| **1674** | Transactions service migration | Перевести transactions/ledger ownership, actor fields, joins и API на user_id с dual-write shadow. | Double-entry, Decimal precision, idempotency и audit trail не изменены. | **Критический** |
| **1675** | Deposits и payment intents | Перевести deposit/payment intent creation, status, settlement и reconciliation на user_id. | Один payment intent не оплачивается дважды; frontend status не считается settlement truth. | **Критический** |
| **1676** | Withdrawals и outcome events | Перевести request, state machine, locks, operator actions и outcome events на user_id/actor_user_id. | Повторный вывод и double approval блокируются; суммы и комиссии не меняются. | **Критический** |
| **1677** | Wallet bindings и proof records | Перевести wallet ownership/proof/idempotency на user_id, сохранив разделение login identity и financial binding. | Proof не заменяет settlement; один wallet не принадлежит двум users. | **Критический** |
| **1678** | Tx hash locks и concurrency | Перевести hash locks/unique keys на user_id там, где owner входит в контракт, без ослабления глобальной уникальности tx. | Concurrent deposit/withdraw/exchange tests не создают duplicate effects. | **Критический** |
| **1679** | Финансовая regression wave | Запустить PostgreSQL concurrency, rollback, idempotency, precision и baseline reconciliation после read switch финансов. | 0 денежных расхождений; 0 skipped в critical financial integration suite. | **Критический** |
| **1680** | Закрытие финансового контура | Переключить финансовые reads на user_id при нулевом fallback и сохранить legacy shadow до общего contract cycle. | Финансовый contour provider-independent; Telegram ID отсутствует в новых service signatures. | **Критический** |

### IX. Миграция предметных модулей — циклы 1681–1690

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1681** | Panels service migration | Перевести создание, активацию, archive, history, limits и ownership панелей на user_id. | Первая панель остаётся атомарной; Activ устанавливается один раз и не зависит от panels_count. | **Критический** |
| **1682** | Energy и scheduler migration | Перевести generation, accrual, snapshots и scheduler payloads на user_id; legacy payload parser оставить измеряемым. | kWh totals не меняются; повторный job не начисляет дважды. | **Критический** |
| **1683** | Referrals migration | Перевести inviter/invitee, codes, lists, counters, bonuses и locks на user_id с identity-based Telegram deep link resolution. | Late binding запрещена; permanent zero и лимит 10 000 сохранены. | **Критический** |
| **1684** | Tasks и rewards migration | Перевести submissions, moderator actors, statuses, rewards и completion locks на user_id. | Повторное начисление невозможно; Telegram event лишь источник identity. | **Высокий** |
| **1685** | Ranks и achievements migration | Перевести snapshots, cache, ranks и achievements на user_id; внешне показывать десятизначный ID при необходимости. | Ranking semantics и исторические результаты не пересчитаны. | **Высокий** |
| **1686** | Shop и orders migration | Перевести orders, checkout, product ownership и locks на user_id; Telegram linking оставить provider context. | TON-only пользователь может покупать через поддержанный flow без tg_id. | **Критический** |
| **1687** | NFT, skins и cosmetics migration | Перевести eligibility, ownership, skins/cosmetics и sync jobs на user_id. | Wallet proof и wallet binding проверяются отдельно; активы не дублируются. | **Высокий** |
| **1688** | TON memo UID canon | Ввести EFHC\|UID:0000000001\|...; legacy TG:<global_id> разрешать через identity map и писать resolved_user_id. | Новые memo не содержат global_id owner; legacy parser имеет telemetry и sunset cycle. | **Высокий** |
| **1689** | Admin и RBAC migration | Перевести admin services/routes/audit actors на user_id + user_roles; tg_id оставить поисковым provider-фильтром. | Telegram whitelist перестаёт быть SSOT, но сохраняется как backfill/audit source до contract. | **Критический** |
| **1690** | Notifications и external events | Перевести notifications/background/external event consumers на user_id с явным channel resolution. | Отсутствие Telegram identity не ломает domain transaction; source tg_id хранится отдельно. | **Высокий** |

### X. API/frontend/contract/release closure — циклы 1691–1700

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1691** | Общие API routes на AuthContext | Заменить get_current_tg_id на AuthContext/get_current_user_id во всех provider-neutral routes и добавить /api/auth/v1/session. | Общие игровые endpoints работают для Telegram и TON-only users. | **Критический** |
| **1692** | Admin API user_id canon | Перевести path/query DTO на десятизначный user_id; global_id оставить отдельным фильтром поиска, не owner parameter. | OpenAPI однозначно различает user_id и global_id; legacy routes имеют deprecation и telemetry. | **Высокий** |
| **1693** | OpenAPI и DTO parity gate | Пересобрать OpenAPI, frontend types и contract tests для session-first архитектуры и provider contexts. | Нет числа user_id в JS; нет поля user_id с Telegram-семантикой. | **Высокий** |
| **1694** | Frontend global session-first switch | Удалить ownership-зависимость от getTelegramUserId(), перевести hooks/query keys/cache/local storage на session.user_id. | Публичные страницы одинаково работают через TON и Telegram sessions. | **Критический** |
| **1695** | Admin frontend и provider context | Показывать системный user_id как основной идентификатор, а Telegram/TON как отдельные identities; роли брать из session/RBAC. | Администратор не авторизуется лишь по frontend whitelist или tg_id. | **Высокий** |
| **1696** | Cross-provider E2E и visual proof | Проверить одинаковые данные при Telegram и TON входе, TON-only сценарий и 34 routes × 3 widths на real Next.js/Chromium. | 102 route-backed checks свежие для exact HEAD; synthetic proof отсутствует. | **Критический** |
| **1697** | Global read switch и constraint validation | Перевести все reads на user_id, добиться fallback=0, валидировать FK/checks и установить NOT NULL там, где reconciliation доказала полноту. | Нет unresolved owner rows; блокировки и запросы используют user_id indexes. | **Критический** |
| **1698** | Contract cleanup stage | Удалить разрешённые aliases, legacy routes и domain tg_id columns только по отдельному validated списку; source/Telegram tg_id сохранить. | Схема после contract соответствует канону; rollback и backup restore доказаны на clone. | **Критический** |
| **1699** | Exact-HEAD release qualification | Запустить полный pytest/PostgreSQL/API/security/frontend/E2E/visual/archive suite, собрать development и release, SHA/receipts/JUnit/logs. | 0 critical skips/failures/errors; development→release mirror и archive safety подтверждены. | **Критический** |
| **1700** | Закрытие диапазона и production handoff | Выполнить deployment/update/rollback/restore/live Telegram/live TON Proof/live settlement evidence либо честно оставить LIVE_VERIFICATION_REQUIRED; закрыть range report. | Диапазон 1601–1700 закрыт только с causal/reconciliation/evidence package; PRODUCTION_RELEASE_READY — лишь после реального live proof. | **Критический** |

## 5. Обязательный результат каждого завершённого цикла

1. Точное описание фактических изменений и неизменяемой области.
2. Список изменённых файлов и миграций.
3. Updated audit matrix и remaining legacy inventory.
4. Команды проверок, exit code, passed/failed/skipped/errors/timeout/deselected.
5. JUnit и runtime/integration logs для соответствующего слоя.
6. Reconciliation report до/после для любого data-touching цикла.
7. Healer: root cause, runtime fix, regression guard, runtime test, causal report и repeat diagnostics.
8. Development ZIP и release ZIP только при фактических изменениях.
9. SHA-256, ZIP entries, CRC/safe paths/special entries/internal SHA/mode/mirror checks.
10. Честный статус и один следующий разрешённый цикл.

## 6. Обязательные reconciliation-метрики

- users count и unique `tg_id`;
- identities по provider/status;
- main/bonus balances;
- total/available/exchanged kWh;
- panels по статусам;
- transactions по типам;
- withdrawals по статусам;
- referral links и `activated_at`;
- active verified wallet bindings;
- orphan/conflict/provider-subject counts;
- roles и admin actors;
- idempotency/tx hash/transaction lock constraints.

## 7. Статусы диапазона

- `DEVELOPMENT_ONLY` — код/документация без полного локального release proof.
- `LOCAL_RELEASE_CANDIDATE` — локальные проверки и архивы собраны, но нет fresh exact-HEAD внешнего proof.
- `READY_FOR_TECHNICAL_DEPLOYMENT` — exact-HEAD CI и release acceptance зелёные.
- `LIVE_VERIFICATION_REQUIRED` — deployment возможен, live Telegram/TON/settlement/restore ещё не доказаны.
- `PRODUCTION_RELEASE_READY` — только после реального deployment, restore, rollback и live verification.

## 8. Финальный gate цикла 1700

Диапазон закрывается только при наличии единого evidence package, доказывающего:

- `user_id` является owner key во всех доменных и финансовых контурах;
- `tg_id` остаётся только в Telegram/identity/source/разрешённом legacy контексте;
- TON-only пользователь полноценно существует без фиктивного Telegram ID;
- Telegram и TON входы открывают один и тот же подтверждённый аккаунт;
- fallback и dual-write mismatch равны нулю до удаления legacy;
- финансовая reconciliation имеет расхождение `0.00000000`;
- full PostgreSQL/security/API/frontend/E2E/visual/archive gates зелёные;
- release переносим между VPS/хостинг-провайдерами;
- production-ready не объявлен без фактического live proof.

---

**Каноническое имя файла для включения в проект:**  
`docs/cycles/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md`
