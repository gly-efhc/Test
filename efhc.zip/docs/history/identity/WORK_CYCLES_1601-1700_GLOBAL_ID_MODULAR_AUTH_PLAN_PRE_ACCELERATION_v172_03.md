# Статус диапазона после цикла 1606

Цикл `1606 — API-контракт global_id` завершён на `v172.03`.
Backend DTO, OpenAPI fixture и frontend DTO имеют единый строковый
контракт. Активные routes не переключены. После цикла 1606 остаётся
`94` цикла до 1700 включительно. Следующий цикл — `1607`.

# Статус диапазона после цикла 1605

Цикл `1605 — Frontend GlobalId string system` завершён на `v172.02`.
Frontend получил branded string `GlobalId`, строгий parser десяти
ASCII-цифр и fail-closed запрет JavaScript number/BigInt/arithmetic.
Roadmap оптимизирован по архитектурным зависимостям и PostgreSQL gates.
Следующий цикл — `1606 — API-контракт global_id`.

# Статус диапазона после цикла 1604

Цикл `1604 — Backend GlobalId type finalization` завершён на
`v172.01` в статусе `LOCAL_BACKEND_TYPES_FINALIZED /
POSTGRESQL_PROOF_REQUIRED`. Канонический backend API очищен от legacy
`UserId` exports; compatibility сохранена только в явном модуле.
Следующий разрешённый цикл — `1605 — Frontend GlobalId string system`.

# Статус диапазона после цикла 1603

Цикл `1603 — Global ID PostgreSQL reconciliation baseline` завершён на
`v172.00` в статусе `GATE_PREPARED / REAL_POSTGRESQL_BLOCKED_BY_ENVIRONMENT`.
Gate воспроизводим, но production-data proof не получен из-за отсутствия
PostgreSQL-среды. Это не разрешает backfill или read switch. Следующий
цикл — `1604 — Backend GlobalId type finalization`.

# EFHC Bot — канонический план циклов 1601–1700 GLOBAL ID

Статус: `ACTIVE / CANONICAL`.
Канон обновлён циклом `1602`, target `v171.99`.

**Направление:** переход от Telegram-зависимой модели к единому
`global_id`, модульному auth-ядру и независимому входу
`TON Connect + TON Proof`.

**Current HEAD на входе цикла 1602:** `EFHC_Bot_v171_98.zip`.  
**Стратегия:** `EXPAND → GLOBAL ID ALIAS → POSTGRESQL PREFLIGHT →
BACKFILL → IDENTITY REGISTRY → AUTH CONTEXT → DUAL WRITE → SHADOW
READ → READ/WRITE SWITCH → PHYSICAL RENAME → CLEANUP`.

Физическая колонка на текущей стадии остаётся `users.user_id`.
`global_id` является каноническим ORM/API/domain именем через
`User.global_id = synonym("user_id")`. Отдельная четвёртая колонка не
создаётся.

Предыдущий roadmap сохранён в:
`docs/history/identity/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN_PRE_GLOBAL_ID_v171_98.md`.

## 1. Каноническая нумерация и версии

- Нумерация циклов проекта продолжается после `1592`; локальная нумерация `0–15` запрещена в именах рабочих циклов и отчётов.
- При строгом правиле «один завершённый цикл с фактическими изменениями = одна последовательная версия» плановый слот цикла `1601` — `v171.98`, цикла `1602` — `v171.99`, цикла `1603` — `v172.00`, цикла `1700` — `v172.97`.
- Цикл без фактических изменений не создаёт новый development/release HEAD и не потребляет номер версии.
- Каждый changed HEAD выпускается двумя отдельными архивами: development и `_RELEASE`, с внешними SHA-256 и receipts.

## 1.1. Оптимизированная модель выполнения после цикла 1605

Нумерация `1601–1700` сохраняется. Оптимизация не объединяет разные
рисковые изменения в один цикл, а устраняет искусственные блокировки и
дублирование доказательств.

### Две независимые линии

1. **Code line** — типы, contracts, guards, provider interfaces и
   криптографически изолированные компоненты. Она может готовиться без
   production PostgreSQL, если не меняет DDL и данные.
2. **Data line** — migrations, backfill, dual-write, shadow/read switch,
   physical rename и cleanup. Она всегда требует реальный PostgreSQL
   proof соответствующего уровня.

### Обязательные gates

| Gate | Где закрывается | Что разрешает | Что блокирует до PASS |
|---|---:|---|---|
| `PG-0 BASELINE` | `1603/1610` | Первую auth-схему с FK на физический `users.user_id` | `1613+` migrations и любое data-touching действие |
| `PG-1 AUTH CORE` | `1620` | Включение TON auth runtime | TON login feature flag в production |
| `PG-2 BACKFILL` | `1670` | Dual-write/shadow-read | Любой read switch |
| `PG-3 FINANCIAL SWITCH` | `1680` | Миграцию нефинансовых доменов | Финансовый switch при mismatch/fallback > 0 |
| `PG-4 PHYSICAL RENAME` | `1697` | Contract cleanup | Rename/NOT NULL/alias removal до fallback=0 |
| `RELEASE` | `1699–1700` | Production handoff | Production-ready без live/restore/rollback proof |

### Правило продолжения при недоступной БД

Если `PG-0` остаётся `BLOCKED_BY_ENVIRONMENT`, циклы `1606–1612` могут
готовить только code line. Цикл `1613` и все последующие DDL/data cycles
не могут быть объявлены завершёнными до реального `PG-0 PASS`. Это
позволяет не простаивать, но исключает фиктивное продвижение миграции.

### Устранённые дублирования

- `1606` создаёт начальный изолированный API contract; `1693` проверяет
  финальную parity уже после миграции routes — это разные gates.
- `1679` теперь является shadow-read regression до переключения; сам
  финансовый read switch выполняется только в `1680`.
- `1697` не повторяет миграцию всех reads: он закрывает fallback=0,
  валидирует constraints и выполняет только physical rename.
- Full archive/CI evidence формируется на каждом цикле локально, но
  единая release qualification выполняется один раз в `1699`.

## 2. Неприкосновенные инварианты всего диапазона

1. `global_id` — единственный системный и доменный идентификатор единого аккаунта; физическая колонка временно называется `users.user_id`.
2. `tg_id` — только внешний Telegram ID: adapter, identity, Telegram API, source event или явно зарегистрированный LEGACY compatibility context.
3. Логический `global_id` хранится в PostgreSQL как `BIGINT` в диапазоне `1–9999999999`; во внешнем API/UI — строка `^\d{10}$`; `0000000000` запрещён.
4. `wallet_address` не является пользователем; `ton_wallet` identity и финансовый `wallet_binding` остаются разными сущностями.
5. Telegram и TON обязаны открывать один `global_id`, когда подтверждённая identity принадлежит одному существующему аккаунту.
6. Автоматическое объединение двух существующих аккаунтов запрещено.
7. Экономика, balances, kWh, панели, транзакции, награды, рефералы, Decimal precision, locks и idempotency не изменяются auth-миграцией.
8. Допустимое денежное расхождение до/после каждого data cycle: `0.00000000`.
9. Legacy columns удаляются только после полного backfill, reconciliation, fallback=0, validated constraints и отдельного contract cycle.
10. `PRODUCTION_RELEASE_READY` запрещён без реального deployment, restore, rollback и live proof.

## 3. Волны диапазона

| Волна | Циклы | Результат |
|---|---:|---|
| I. Идентификаторы и фундамент | `1601–1610` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| II. Модульное auth-ядро | `1611–1620` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| III. Независимый TON Proof login | `1621–1630` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| IV. Frontend TON session-first | `1631–1640` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| V. Telegram как адаптер | `1641–1650` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VI. Expand доменной схемы | `1651–1660` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VII. Backfill и reconciliation | `1661–1670` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| VIII. Dual-write и финансовый read switch | `1671–1680` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| IX. Миграция предметных модулей | `1681–1690` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |
| X. API/frontend/contract/release closure | `1691–1700` | Контролируемое завершение соответствующего архитектурного слоя с отдельным exit gate. |

## 4. Подробный план циклов

Каждый цикл ограничен одной причинно связанной задачей. Нельзя переносить следующий read switch или contract cleanup вперёд, пока не закрыт exit gate предыдущей волны.

### I. Global ID и фундамент — циклы 1601–1610

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1601** | Открытие диапазона и приёмка фундамента | Принять exact `v171.97`, доказать EXPAND без backfill/read switch и сформировать `v171.98`. | Exact HEAD и blockers воспроизводимы; экономика не изменена. | **Высокий** |
| **1602** | Канонизация Global ID и compatibility aliases | Утвердить `global_id` как главный аккаунт; ввести `GlobalId`, `User.global_id = synonym("user_id")`, `legacy_pk`, `telegram_id`, новый SSOT/NORM/roadmap и fail-closed guards без изменения DDL. | Нет отдельной колонки `global_id`; Alembic head `0002`; новый код имеет канонический API; backfill/read switch false. | **Критический** |
| **1603** | Global ID PostgreSQL reconciliation baseline | Создать и реально выполнить pre-migration снимок users, physical `user_id`, providers, balances, kWh, panels, finance, referrals, roles, orphan/conflicts и sequence. | Baseline воспроизводим на PostgreSQL; денежное расхождение `0.00000000`; без БД статус BLOCKED, не PASSED. | **Критический** |
| **1604** | Backend GlobalId type finalization | Завершить вывод legacy `UserId` из нового production API, закрепить `GlobalId`, `TelegramId`, форматирование и единые ошибки. | Новый код не импортирует legacy type names; границы и негативные сценарии проходят. | **Средний** |
| **1605** | Frontend GlobalId string system | Ввести branded string `GlobalId`, `^[0-9]{10}$`, строгие API/display boundaries и запрет JavaScript number/BigInt/arithmetic. | Ведущие нули сохраняются; isolated runtime/typecheck и fail-closed guard зелёные; полный build честно маркируется environment-dependent. | **Высокий** |
| **1606** | API-контракт global_id | Создать изолированный backend/frontend DTO и OpenAPI schema `global_id: string` с format/pattern, сохранив зарегистрированные LEGACY envelopes до read switch. | Один contract fixture проходит backend↔OpenAPI↔frontend parity; новые DTO не содержат неопределённого `user_id`. | **Высокий** |
| **1607** | Cross-language разделение GlobalId и TelegramId | Согласовать nominal/branded types backend/frontend и усилить guards против provider-to-global assignment и передачи global_id в Telegram API. | Негативные compile/runtime/AST tests ловят прямое и косвенное смешение на обеих сторонах. | **Высокий** |
| **1608** | Семантический allowlist tg_id и legacy user_id | Перевести новые `tg_id` и физические/legacy `user_id` употребления в fail-closed классификацию provider/source/migration/compatibility. | Новое domain ownership-употребление либо неопределённый `user_id` ломает CI с file:line и причиной. | **Высокий** |
| **1609** | Реестр compatibility и sunset budget | Зарегистрировать aliases, legacy DTO/routes, fallbacks и shadow fields с владельцем, метрикой, разрешённым scope и sunset cycle. | Нет безымянных compatibility mechanisms; каждый элемент имеет removal gate и запрещён вне scope. | **Средний** |
| **1610** | Закрытие волны Global ID и PG-0 gate | Закрыть code line unit/API/type/archive gates и повторно выполнить реальный PostgreSQL baseline. При недоступной БД разрешён только статус `LOCAL_CODE_WAVE_CLOSED / PG-0_REQUIRED`. | Code line зелёная; экономика неизменна; `PG-0 PASS` обязателен до цикла 1613. | **Критический** |

### II. Модульное auth-ядро — циклы 1611–1620

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1611** | Контракт AuthProvider | Создать provider-neutral Protocol/ABC, VerifiedIdentity и ошибки провайдера без создания пользователя и без доступа к игровой экономике. | Mock provider проходит контрактные тесты; будущий провайдер подключается без изменения domain services. | **Средний** |
| **1612** | Provider registry и feature flags | Создать реестр провайдеров, обязательную конфигурацию, disabled state и fail-closed startup validation. | TON и Telegram регистрируются явно; Google/Facebook/Apple отсутствуют в runtime UI и остаются disabled. | **Средний** |
| **1613** | Таблица user_identities | Добавить expand migration и ORM для user_identities с UNIQUE(provider, provider_tenant, provider_subject), логическое поле `global_id`, PostgreSQL FK на физическую `users.user_id` до rename-stage и revoke/login flags. | Миграция upgrade/downgrade проверена; один provider subject не связывается с двумя users. | **Критический** |
| **1614** | IdentityResolver | Реализовать разрешение verified provider identity в global_id, включая conflict result и запрет автоматического merge двух существующих аккаунтов. | Resolver детерминирован, транзакционен и не принимает непроверенный subject от клиента как SSOT. | **Критический** |
| **1615** | Таблица auth_challenges | Добавить challenge_id, provider, purpose, challenge_hash, nonce_hash, domain, nullable global_id, TTL, consumed_at и metadata. | Challenge криптографически случаен, одноразов, purpose-bound и domain-bound; plaintext secret не хранится. | **Критический** |
| **1616** | Таблица auth_sessions | Добавить server-side session registry с hash opaque token, expires/revoked/last_seen и device metadata с минимизацией данных. | В БД отсутствует plaintext token; logout и logout-all аннулируют сессии; cookies имеют Secure/HttpOnly/SameSite. | **Критический** |
| **1617** | AuthContext и зависимости FastAPI | Добавить AuthContext, get_current_auth_context(), get_current_global_id(), get_current_user(), require_authenticated() и role dependencies. | Общий endpoint работает без tg_id; Telegram-specific endpoint может явно потребовать Telegram identity. | **Критический** |
| **1618** | user_roles и permissions core | Создать либо нормализовать user_roles на global_id, role registry и require_role/require_any_role без Telegram whitelist как конечного SSOT. | Роли принадлежат логическому global_id; физический FK до rename-stage указывает на `users.user_id`; provider не определяет полномочия; legacy whitelist ещё не удаляется. | **Высокий** |
| **1619** | Auth audit и secret redaction | Добавить auth audit events, correlation IDs, безопасную диагностику и redaction initData, proof, session token, nonce и OAuth-like secrets. | Security tests подтверждают отсутствие полных секретов в логах, traces и ошибках API. | **Высокий** |
| **1620** | Auth core PostgreSQL gate | Запустить миграции и integration suite для identities, challenges, sessions, roles, resolver и concurrency на настоящем PostgreSQL. | Auth core зелёный, 0 skipped в обязательной integration-группе; финансовые таблицы не изменены. | **Критический** |

### III. Независимый TON Proof login — циклы 1621–1630

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1621** | Аудит существующего TON Proof | Разобрать текущий challenge/proof flow, найти зависимости от заранее известного global_id, frontend trust и недостаточные проверки криптографии. | Создан exact file:line report; отделены connection, ownership proof, signed, broadcast, confirmed и settled. | **Высокий** |
| **1622** | Независимый TON challenge endpoint | Реализовать POST /api/auth/v1/ton/challenge для purpose=login без текущего пользователя и для link/step_up с AuthContext. | Ответ содержит только challenge_id и public payload; nonce не переиспользуется и не связывается с tg_id. | **Критический** |
| **1623** | Канонический TON address resolver | Проверять workchain/address, public key и wallet state init; сохранять единое canonical raw address representation. | Один кошелёк не получает несколько identity из-за friendly/raw/testnet вариантов. | **Критический** |
| **1624** | Криптографическая проверка TON Proof | Реализовать/проверить подпись, public key, payload, domain, timestamp, network и state init по фактическому TON Proof контракту. | Положительные vectors проходят; modified signature/public key/payload отклоняются. | **Критический** |
| **1625** | Replay, TTL и consumption | Атомарно потреблять challenge, проверять TTL, purpose, domain и повторное использование под row lock/unique guarantee. | Два конкурентных verify запроса дают ровно одну успешную сессию; replay отклонён. | **Критический** |
| **1626** | Вход существующей TON identity | Разрешать существующую ton_wallet identity в прежний global_id без изменения wallet binding или доменных активов. | Повторный вход всегда открывает один аккаунт; balances/panels/referrals идентичны Telegram-входу. | **Критический** |
| **1627** | Связь с подтверждённым wallet_binding | Если identity отсутствует, но active proof_verified wallet binding уникально принадлежит существующему global_id, создать identity тому же пользователю. | Не создаётся дубликат аккаунта; конфликтующие bindings переводятся в fail-closed ручную проверку. | **Критический** |
| **1628** | Создание TON-only пользователя | Создать users + ton_wallet identity + обязательные стартовые записи + wallet_binding одной транзакцией без фиктивного global_id. | TON-only пользователь имеет nullable global_id, корректный global_id и нулевые стартовые балансы без бонусных повторов. | **Критический** |
| **1629** | Concurrency TON registration | Защитить конкурентное создание одного кошелька через unique constraints, locks и idempotent read-through. | Параллельные verify не создают двух users, identities или wallet bindings. | **Критический** |
| **1630** | TON auth security closure | Закрыть challenge/verify/session/logout API, security tests и PostgreSQL integration proof для TON login. | Все обязательные TON Proof негативные сценарии проходят; feature flag остаётся управляемым. | **Критический** |

### IV. Frontend TON session-first — циклы 1631–1640

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1631** | Frontend auth API client | Создать frontend/src/features/auth/api с challenge, verify, session, logout и типизированным error mapping. | Компоненты не вызывают raw auth endpoints напрямую; global_id остаётся string. | **Средний** |
| **1632** | AuthProvider и AuthGate | Создать frontend AuthProvider, AuthSession, AuthGate и provider-neutral состояние загрузки/ошибки/сессии. | Игровые страницы получают пользователя только из server session, не из Telegram global object. | **Высокий** |
| **1633** | TON Connect login screen | Добавить реальный TON login entrypoint без фиктивных Google/Facebook/Apple кнопок. | Кнопка доступна только при корректной backend/provider конфигурации; disabled state честно отображён. | **Средний** |
| **1634** | TON Proof request lifecycle | Связать challenge payload с TonConnect proof request, обработать отмену, disconnect, retry и stale challenge. | Frontend не объявляет proof подтверждённым до backend verify и выдачи сессии. | **Высокий** |
| **1635** | Auth error taxonomy | Согласовать backend/frontend коды expired, replay, wrong_domain, wallet_conflict, provider_disabled и session_invalid. | Пользователь получает безопасное сообщение; техническая диагностика коррелируется без утечки secrets. | **Средний** |
| **1636** | TON-only профиль | Обеспечить профиль и общие игровые shell-компоненты без Telegram username/tg_id, с отображением десятизначного global_id. | TON-only пользователь открывает базовые общие страницы без synthetic tg_id. | **Высокий** |
| **1637** | Provider UI registry | Формировать login UI только из реально enabled providers и серверной capability-конфигурации. | Неработающие провайдеры не видны; включение без обязательной конфигурации блокирует startup/CI. | **Средний** |
| **1638** | Cookie, CORS и CSRF hardening | Проверить Secure/HttpOnly/SameSite, trusted origins, credentials, CSRF для state-changing session endpoints и redirect policy. | Произвольные origins/redirects отклоняются; session token недоступен JavaScript. | **Критический** |
| **1639** | Frontend TON auth E2E | Добавить Playwright/mock-wallet E2E для success, cancel, expired, replay, conflict и session restore. | E2E выполняется против реального backend/test PostgreSQL, без page.set_content и synthetic application shell. | **Высокий** |
| **1640** | TON frontend wave closure | Выполнить typecheck, production build, E2E, visual checks login/profile и exact-HEAD packaging. | TON login contour готов к совместному использованию с Telegram adapter; live wallet proof ещё не подменяется mock proof. | **Критический** |

### V. Telegram как адаптер — циклы 1641–1650

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1641** | Backfill Telegram identities | Создать verified telegram identities для существующих users.tg_id, сохранив точное соответствие и отчёт конфликтов. | Количество уникальных tg_id совпадает; ни один global_id не изменён; orphan не исправляются предположениями. | **Критический** |
| **1642** | Telegram WebApp adapter | Преобразовать проверенный initData в VerifiedIdentity(provider=telegram, subject=tg_id) и передать IdentityResolver. | HMAC/auth_date/TTL/replay проверяются backend; domain logic не получает tg_id как owner key. | **Критический** |
| **1643** | Telegram Login adapter boundary | Подготовить отдельный адаптер Telegram Login по тому же provider contract без смешения с Mini App initData. | Оба Telegram flow возвращают единый provider subject contract; неавторизованный flow disabled. | **Высокий** |
| **1644** | Повторный вход существующего Telegram user | Гарантировать, что существующий tg_id всегда разрешается в прежний global_id и прежние активы. | Regression snapshot по balance/panels/referrals/roles полностью совпадает. | **Критический** |
| **1645** | Первый Telegram onboarding через identity | Создавать users + telegram identity и реферальную атрибуцию одной транзакцией при первом входе. | Сохранены permanent-zero, invalid-code rollback, self-referral/cycle guards и Activ-канон. | **Критический** |
| **1646** | request.state.auth_context | Перевести middleware на request.state.auth_context; request.state.tg_id оставить только LEGACY shadow для allowlisted кода. | Общие routes не зависят от state.tg_id; compatibility usage измеряется метрикой. | **Высокий** |
| **1647** | LEGACY get_current_tg_id adapter | Оставить get_current_tg_id() поверх AuthContext только для объективно Telegram-specific операций и добавить sunset guard. | Общий endpoint с этой зависимостью ломает CI; TON-only пользователь получает явную TelegramIdentityRequired. | **Высокий** |
| **1648** | Telegram-specific endpoint policy | Разделить общие игровые endpoints и Telegram actions/notifications, требующие tg_id. | API inventory однозначно маркирует Telegram-only routes; security tests проверяют границу. | **Средний** |
| **1649** | Notifications через identity lookup | Перевести сервис уведомлений на вход global_id с последующим поиском активной Telegram identity. | TON-only пользователь не получает фиктивный tg_id; отсутствие канала обрабатывается явно и идемпотентно. | **Высокий** |
| **1650** | Telegram compatibility closure | Запустить Telegram onboarding/session/role/referral regression и cross-provider same-account tests. | Mini App не имеет регрессий; tg_id больше не является системным владельцем в новых auth flows. | **Критический** |

### VI. Expand доменной схемы — циклы 1651–1660

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1651** | Повторная ORM-матрица перед expand | Пересканировать все ORM/SQL/DTO/service зависимости и заморозить точный список owner/actor/source global_id перед доменными миграциями. | Матрица содержит file:line, категорию, действие, цикл и риск; false positives отделены. | **Высокий** |
| **1652** | Expand финансовых таблиц | Добавить nullable global_id/actor_global_id в transactions, deposits, payment_intents, withdrawals, outcomes и связанные ledger tables без изменения сумм. | DDL не пересчитывает Numeric; индексы созданы безопасно; legacy global_id сохранён. | **Критический** |
| **1653** | Expand wallet и lock tables | Добавить global_id в wallet_bindings, wallet proof uses, connect idempotency, tx hash locks и иные ownership/lock таблицы. | Уникальность wallet/tx/idempotency сохранена; wallet address не становится global_id. | **Критический** |
| **1654** | Expand panels и energy | Добавить global_id в panels, panels_archive, generation/scheduler-owned records и необходимые индексы. | Панели не пересоздаются; statuses/dates/generated totals остаются byte/decimal-identical. | **Критический** |
| **1655** | Expand referrals, tasks и ranks | Добавить inviter_global_id, invitee_global_id, global_id и moderator_global_id в referral/task/rank/achievement tables. | Activ остаётся по activated_at; награды и пороги не пересчитываются. | **Критический** |
| **1656** | Expand shop, NFT и cosmetics | Добавить global_id в orders, shop, skins, cosmetics, NFT checks и related locks. | Покупки/скины/NFT ownership не меняются; legacy columns остаются до contract. | **Высокий** |
| **1657** | Expand admin actors и RBAC | Добавить added_by_global_id, granted_by_global_id, moderator_global_id и global_id для admin ownership/roles. | Legacy whitelist сохранён для backfill; новые permissions ссылаются на global_id. | **Высокий** |
| **1658** | Expand source events и TON logs | Добавить resolved_global_id рядом с parsed_global_id и иными внешними идентификаторами, сохраняя raw source semantics. | parsed_global_id остаётся атрибутом события; финансовый owner определяется только resolved_global_id. | **Высокий** |
| **1659** | FK/index deployment strategy | Добавить индексы, NOT VALID FK/checks либо эквивалентную безопасную стратегию для больших таблиц без длительной блокировки. | План lock-time измерен на clone; rollback и повторный запуск проверены. | **Критический** |
| **1660** | Schema expand closure | Прогнать Alembic upgrade/downgrade/upgrade, schema diff, ORM import и production builder. | Все новые поля nullable; ни одно legacy поле не удалено; приложение совместимо с прежним чтением. | **Критический** |

### VII. Backfill и reconciliation — циклы 1661–1670

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1661** | Backfill Telegram identity map | Материализовать однозначную таблицу legacy tg_id → global_id через user_identities и запретить догадки для orphan. | 0 конфликтующих provider subjects либо все конфликты явно quarantined. | **Критический** |
| **1662** | Backfill verified TON identities | Создать ton_wallet identities только из уникальных active proof_verified wallet_bindings после canonical address reconciliation. | Неподтверждённые users.ton_wallet не превращаются в login identity. | **Критический** |
| **1663** | Backfill финансового owner | Заполнить global_id финансовых таблиц через identity map в контролируемых batches с audit counters. | Суммы до/после равны до 8 знаков; orphan rows не удалены и не перепривязаны. | **Критический** |
| **1664** | Backfill wallet и idempotency owner | Заполнить global_id в wallet/lock/idempotency tables и проверить unique/ownership conflicts. | Один wallet/tx hash/idempotency key не связывается с разными users. | **Критический** |
| **1665** | Backfill panels и energy owner | Заполнить global_id в panels/archive/generation/scheduler records без изменения статусов и totals. | Количество панелей по каждому статусу и generated kWh полностью совпадает. | **Критический** |
| **1666** | Backfill referrals, tasks и ranks | Заполнить user/actor ids в referral/task/rank/achievement tables и проверить граф/пороговые награды. | Реферальные связи, activated_at, Lvl awards и task rewards идентичны baseline. | **Критический** |
| **1667** | Backfill shop, NFT и admin actors | Заполнить ownership/actor global_id для shop/NFT/cosmetics/admin roles и whitelist. | Покупки, роли и права не потеряны; ambiguous actors остаются nullable/report-only. | **Высокий** |
| **1668** | Orphan и conflict quarantine | Создать fail-closed отчёты и operational queue для orphan tg_id, duplicate wallet, conflicting provider subject и broken FK candidates. | Ни один конфликт не исправлен автоматически; deployment gate видит точное количество. | **Критический** |
| **1669** | Полная финансовая reconciliation | Сравнить 17+ канонических метрик до/после, включая balances, kWh, panels, tx, withdrawals, referrals, roles, locks. | Денежное расхождение 0.00000000; все count differences объяснены только новыми auth rows. | **Критический** |
| **1670** | Backfill closure и freeze | Зафиксировать backfill version, checksums, batch receipts и запрет повторного небезопасного выполнения. | Backfill идемпотентен; повторный запуск не меняет данные; dual-write может включаться feature flag. | **Критический** |

### VIII. Dual-write и финансовый read switch — циклы 1671–1680

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1671** | Dual-write framework | Создать единый owner-write helper: global_id SSOT, legacy global_id server-resolved shadow, mismatch fail-closed и metrics. | Клиентский global_id не принимается как owner; TON-only записи не получают фиктивный shadow. | **Критический** |
| **1672** | Fallback telemetry | Добавить метрики read fallback, dual-write mismatch, unresolved identity и legacy endpoint usage с cycle-removal targets. | Каждый fallback наблюдаем; нулевое значение является обязательным gate перед contract. | **Высокий** |
| **1673** | Users CRUD read switch | Перевести user CRUD/repositories/locks на global_id, оставив global_id только отдельным identity-search методом. | Поиск global_id и поиск global_id имеют разные именованные API; FOR UPDATE блокирует системного пользователя. | **Критический** |
| **1674** | Transactions service migration | Перевести transactions/ledger ownership, actor fields, joins и API на global_id с dual-write shadow. | Double-entry, Decimal precision, idempotency и audit trail не изменены. | **Критический** |
| **1675** | Deposits и payment intents | Перевести deposit/payment intent creation, status, settlement и reconciliation на global_id. | Один payment intent не оплачивается дважды; frontend status не считается settlement truth. | **Критический** |
| **1676** | Withdrawals и outcome events | Перевести request, state machine, locks, operator actions и outcome events на global_id/actor_global_id. | Повторный вывод и double approval блокируются; суммы и комиссии не меняются. | **Критический** |
| **1677** | Wallet bindings и proof records | Перевести wallet ownership/proof/idempotency на global_id, сохранив разделение login identity и financial binding. | Proof не заменяет settlement; один wallet не принадлежит двум users. | **Критический** |
| **1678** | Tx hash locks и concurrency | Перевести hash locks/unique keys на global_id там, где owner входит в контракт, без ослабления глобальной уникальности tx. | Concurrent deposit/withdraw/exchange tests не создают duplicate effects. | **Критический** |
| **1679** | Финансовая shadow-read regression | Запустить PostgreSQL shadow reads, mismatch/fallback telemetry, concurrency, rollback, idempotency, precision и baseline reconciliation до переключения финансовых reads. | Денежное расхождение `0.00000000`; mismatch/fallback=0; 0 skipped в critical financial integration suite. | **Критический** |
| **1680** | Финансовый read switch и PG-3 closure | Переключить финансовые reads на global_id только после зелёного 1679, повторить reconciliation и сохранить legacy shadow до общего contract cycle. | Финансовый contour provider-independent; mismatch/fallback остаются 0 после switch; Telegram ID отсутствует в новых service signatures. | **Критический** |

### IX. Миграция предметных модулей — циклы 1681–1690

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1681** | Panels service migration | Перевести создание, активацию, archive, history, limits и ownership панелей на global_id. | Первая панель остаётся атомарной; Activ устанавливается один раз и не зависит от panels_count. | **Критический** |
| **1682** | Energy и scheduler migration | Перевести generation, accrual, snapshots и scheduler payloads на global_id; legacy payload parser оставить измеряемым. | kWh totals не меняются; повторный job не начисляет дважды. | **Критический** |
| **1683** | Referrals migration | Перевести inviter/invitee, codes, lists, counters, bonuses и locks на global_id с identity-based Telegram deep link resolution. | Late binding запрещена; permanent zero и лимит 10 000 сохранены. | **Критический** |
| **1684** | Tasks и rewards migration | Перевести submissions, moderator actors, statuses, rewards и completion locks на global_id. | Повторное начисление невозможно; Telegram event лишь источник identity. | **Высокий** |
| **1685** | Ranks и achievements migration | Перевести snapshots, cache, ranks и achievements на global_id; внешне показывать десятизначный ID при необходимости. | Ranking semantics и исторические результаты не пересчитаны. | **Высокий** |
| **1686** | Shop и orders migration | Перевести orders, checkout, product ownership и locks на global_id; Telegram linking оставить provider context. | TON-only пользователь может покупать через поддержанный flow без tg_id. | **Критический** |
| **1687** | NFT, skins и cosmetics migration | Перевести eligibility, ownership, skins/cosmetics и sync jobs на global_id. | Wallet proof и wallet binding проверяются отдельно; активы не дублируются. | **Высокий** |
| **1688** | TON memo UID canon | Ввести EFHC\|UID:0000000001\|...; legacy TG:<global_id> разрешать через identity map и писать resolved_global_id. | Новые memo не содержат global_id owner; legacy parser имеет telemetry и sunset cycle. | **Высокий** |
| **1689** | Admin и RBAC migration | Перевести admin services/routes/audit actors на global_id + user_roles; tg_id оставить поисковым provider-фильтром. | Telegram whitelist перестаёт быть SSOT, но сохраняется как backfill/audit source до contract. | **Критический** |
| **1690** | Notifications и external events | Перевести notifications/background/external event consumers на global_id с явным channel resolution. | Отсутствие Telegram identity не ломает domain transaction; source tg_id хранится отдельно. | **Высокий** |

### X. API/frontend/contract/release closure — циклы 1691–1700

| Цикл | Наименование | Объём | Критерий выхода | Риск |
|---:|---|---|---|---|
| **1691** | Общие API routes на AuthContext | Заменить get_current_tg_id на AuthContext/get_current_global_id во всех provider-neutral routes и добавить /api/auth/v1/session. | Общие игровые endpoints работают для Telegram и TON-only users. | **Критический** |
| **1692** | Admin API global_id canon | Перевести path/query DTO на десятизначный global_id; global_id оставить отдельным фильтром поиска, не owner parameter. | OpenAPI однозначно различает global_id и global_id; legacy routes имеют deprecation и telemetry. | **Высокий** |
| **1693** | OpenAPI и DTO parity gate | Пересобрать OpenAPI, frontend types и contract tests для session-first архитектуры и provider contexts. | Нет числа global_id в JS; нет поля global_id с Telegram-семантикой. | **Высокий** |
| **1694** | Frontend global session-first switch | Удалить ownership-зависимость от getTelegramUserId(), перевести hooks/query keys/cache/local storage на session.global_id. | Публичные страницы одинаково работают через TON и Telegram sessions. | **Критический** |
| **1695** | Admin frontend и provider context | Показывать системный global_id как основной идентификатор, а Telegram/TON как отдельные identities; роли брать из session/RBAC. | Администратор не авторизуется лишь по frontend whitelist или tg_id. | **Высокий** |
| **1696** | Cross-provider E2E и visual proof | Проверить одинаковые данные при Telegram и TON входе, TON-only сценарий и 34 routes × 3 widths на real Next.js/Chromium. | 102 route-backed checks свежие для exact HEAD; synthetic proof отсутствует. | **Критический** |
| **1697** | PG-4 fallback closure и physical rename | Не повторяя завершённые read switches, доказать fallback=0 по всем контурам, валидировать FK/checks и выполнить отдельный rename `users.user_id → users.global_id` с NOT NULL только при полной доказанности. | Нет unresolved owner rows; физическая схема соответствует канону; rollback/restore rename доказаны на clone. | **Критический** |
| **1698** | Contract cleanup stage | Удалить разрешённые aliases, legacy routes и domain tg_id columns только по отдельному validated списку; source/Telegram tg_id сохранить. | Схема после contract соответствует канону; rollback и backup restore доказаны на clone. | **Критический** |
| **1699** | Exact-HEAD release qualification | Запустить полный pytest/PostgreSQL/API/security/frontend/E2E/visual/archive suite, собрать development и release, SHA/receipts/JUnit/logs. | 0 critical skips/failures/errors; development→release mirror и archive safety подтверждены. | **Критический** |
| **1700** | Закрытие диапазона и production handoff | Выполнить deployment/update/rollback/restore/live Telegram/live TON Proof/live settlement evidence либо честно оставить LIVE_VERIFICATION_REQUIRED; закрыть range report. | Диапазон 1601–1700 закрыт только с causal/reconciliation/evidence package; PRODUCTION_RELEASE_READY — лишь после реального live proof. | **Критический** |

## 5. Обязательный результат каждого завершённого цикла

1. Точное описание фактических изменений и неизменяемой области.
2. Список изменённых файлов и миграций.
3. Updated audit matrix и remaining legacy inventory.
4. Команды проверок, exit code, passed/failed/skipped/errors/timeout/deselected.
5. JUnit и runtime/integration logs для соответствующего слоя.
6. Reconciliation report до/после для любого data-touching цикла.
7. Healer: root cause, runtime fix, regression guard, runtime test, causal report и repeat diagnostics.
8. Development ZIP и release ZIP только при фактических изменениях.
9. SHA-256, ZIP entries, CRC/safe paths/special entries/internal SHA/mode/mirror checks.
10. Честный статус и один следующий разрешённый цикл.

## 6. Обязательные reconciliation-метрики

- users count и unique `tg_id`;
- identities по provider/status;
- main/bonus balances;
- total/available/exchanged kWh;
- panels по статусам;
- transactions по типам;
- withdrawals по статусам;
- referral links и `activated_at`;
- active verified wallet bindings;
- orphan/conflict/provider-subject counts;
- roles и admin actors;
- idempotency/tx hash/transaction lock constraints.

## 7. Статусы диапазона

- `DEVELOPMENT_ONLY` — код/документация без полного локального release proof.
- `LOCAL_RELEASE_CANDIDATE` — локальные проверки и архивы собраны, но нет fresh exact-HEAD внешнего proof.
- `READY_FOR_TECHNICAL_DEPLOYMENT` — exact-HEAD CI и release acceptance зелёные.
- `LIVE_VERIFICATION_REQUIRED` — deployment возможен, live Telegram/TON/settlement/restore ещё не доказаны.
- `PRODUCTION_RELEASE_READY` — только после реального deployment, restore, rollback и live verification.

## 8. Финальный gate цикла 1700

Диапазон закрывается только при наличии единого evidence package, доказывающего:

- `global_id` является owner key во всех доменных и финансовых контурах;
- `tg_id` остаётся только в Telegram/identity/source/разрешённом legacy контексте;
- TON-only пользователь полноценно существует без фиктивного Telegram ID;
- Telegram и TON входы открывают один и тот же подтверждённый аккаунт;
- fallback и dual-write mismatch равны нулю до удаления legacy;
- финансовая reconciliation имеет расхождение `0.00000000`;
- full PostgreSQL/security/API/frontend/E2E/visual/archive gates зелёные;
- release переносим между VPS/хостинг-провайдерами;
- production-ready не объявлен без фактического live proof.

---

**Каноническое имя файла для включения в проект:**  
`docs/cycles/WORK_CYCLES_1601-1700_GLOBAL_ID_MODULAR_AUTH_PLAN.md`
