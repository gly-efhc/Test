# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон локально закрыт без historical backfill и runtime read
switch. Реальная PostgreSQL reconciliation остаётся обязательной
внешней блокировкой. GitHub CI не запускался; основной пакет ещё не
готов. Следующий цикл — `1601`, следующая версия — `v171.98`.

Все новые и изменяемые инженерные артефакты оформляются на русском
языке. Технические идентификаторы и протоколы не переводятся.

# CURRENT LEGACY ALIAS / HARNESS NORM — v171.95

Cycle 1598 is a preparation-only stage after EXPAND:

1. expose a bounded `LEGACY` ORM synonym to the current primary key;
2. register, but do not activate, the future `User.id` compatibility
   mapping to `User.user_id`;
3. render read-only preflight and future guarded backfill SQL;
4. preserve assigned `user_id` values;
5. reject duplicate, range and collision conflicts;
6. prohibit database execution, read switch and financial mutation.

## Retained EXPAND NORM — v171.94

The active migration head is `0002`. This stage is EXPAND only:
nullable `users.user_id`, bounded sequence, range check and uniqueness.
No historical backfill, read switch, `tg_id` relaxation or financial
mutation is permitted. Existing databases upgrade linearly from `0001`;
fresh databases reach the same `head=0002`.

# USER IDENTITY MIGRATION NORM

Status: `ACTIVE / MANDATORY`.
SSOT: `docs/SSOT/USER_IDENTITY_AUTH_SSOT.md`.
Cycle range: `1593-1700`.
Current completed cycle: `1600`, archive target `v171.97`.

## 1. Naming rules

- System user: `user_id` / `UserId`.
- External system representation: `UserIdDisplay` or
  `ExternalUserId`.
- Telegram user: `tg_id` / `TelegramId`.
- Provider subject: `provider_subject`.
- TON address: `wallet_address`.
- Provider name: `provider`.

No variable named `global_id` may contain a system `user_id`. No variable
named `user_id` may contain a Telegram identifier, provider subject or
wallet address.

## 2. UserId contract

The canonical contract is:

```text
internal storage target = BIGINT
minimum = 1
maximum = 9999999999
external form = exactly 10 ASCII digits
canonical notation = ^\d{10}$
zero = forbidden
```

The executable foundation is:

```text
backend/app/identity/types.py
```

Required types and helpers:

```text
UserId
TelegramId
UserIdDisplay
ExternalUserId
validate_user_id()
validate_tg_id()
validate_user_id_display()
format_user_id()
parse_user_id()
user_id_from_database()
user_id_to_database()
is_user_id()
is_tg_id()
```

`UserId` and `TelegramId` are frozen, slotted nominal value objects.
They are not interchangeable with each other or with raw integers.
Formatting and database output require a validated `UserId`.

`bool`, float, whitespace, signs, separators, Unicode digit glyphs and
integer coercion from API values are rejected.

Cycle-1596 wiring state:

```text
value_type_unit_wired = true
api_contract_prepared = true
pydantic_models_prepared = true
active_routes_wired = false
existing_dtos_wired = false
runtime_wired = false
orm_wired = false
frontend_wired = false
```

Unit-level wiring means only the isolated identity package and tests.
No production module outside `backend/app/identity` may import the new
types through cycle 1596.

## 3. External API/Pydantic preparation

Cycle 1596 may add only isolated API contract modules and tests. The
approved symbols are:

```text
ApiExternalUserId
PydanticUserId
UserIdRequest
UserIdResponse
```

Rules:

- JSON and OpenAPI type is `string` only;
- exact executable pattern is `^[0-9]{10}$`;
- leading zeroes are preserved on output;
- API integers and coercion are rejected;
- `TelegramId`, wallet and provider values are rejected;
- active routes and existing DTOs cannot import these symbols yet;
- no response may expose system `user_id` as JSON number.

## 4. Temporary compatibility

Each temporary alias must include:

- a `LEGACY` comment;
- a bounded scope;
- a compatibility test;
- a planned migration cycle;
- a planned removal cycle;
- a CI baseline that prevents new use.

Allowed future temporary mechanisms include:

- `User.id` as an ORM alias to `User.user_id` after expand;
- `get_current_tg_id()` over provider-aware auth context;
- server-side legacy parameter resolution;
- dual-write with `user_id` as SSOT;
- legacy TON memo parsing.

None of these compatibility aliases is created through cycle 1595.

## 5. Current legacy test doctrine

Tests that assert joins, filters or routes by `tg_id` must be marked as
LEGACY runtime compatibility. They preserve the exact pre-migration
behavior until the corresponding expand/backfill/read-switch cycle.
They must never state that `tg_id` is the target system identity.

New tests use separate `UserId` and `TelegramId` terminology and must
include negative cases for indirect conversion.

## 6. Cycle allocation

Local planning labels `0-15` are architecture phases, not project cycle
numbers. They must not be renumbered one-to-one.

The authoritative foundation range is:

| Cycle | Scope |
|---:|---|
| 1593 | Exact audit, SSOT/NORM, allowlist and CI baseline |
| 1594 | UserId contract, type foundation and negative guards |
| 1595 | Contract adoption preparation without schema switch |
| 1596 | External API/Pydantic adoption preparation |
| 1597 | `users.user_id` expand migration design and dry-run |
| 1598 | Explicit LEGACY alias and migration test harness |
| 1599 | PostgreSQL reconciliation execution and gate hardening |
| 1600 | Foundation closure and exact-HEAD handoff gate |

The authoritative detailed implementation roadmap is:

```text
docs/cycles/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md
```

## 7. CI boundary from cycle 1595

The cycle-1595 boundary protects `481` runtime/schema/frontend files.
Python semantics are hashed after removing docstrings; non-Python files
use exact bytes. It permits doctrine comments to be corrected but blocks
any executable ownership or schema change.

It additionally enforces zero imports of `app.identity` by production
modules outside the identity package.

## 8. CI boundary inherited from cycle 1594

The V2 identity guard enforces:

- no new tracked Telegram identifier file;
- no increase in existing legacy identifier counts;
- explicit Telegram-specific allowlist;
- semantic categories for each legacy file;
- assigned migration and removal cycles;
- no new `get_current_tg_id()` dependency;
- no direct or indirect Telegram-to-system ID assignment;
- no wallet-address-to-system-ID assignment;
- no `UserId()` construction from provider data.

The cycle-specific patch guard additionally hash-locks:

- ORM models;
- Alembic migrations;
- services and CRUD;
- FastAPI routes and dependencies;
- Pydantic schemas;
- frontend source.

## 9. Reconciliation

Every data-changing cycle must capture before and after values for:

- user and identity counts;
- unique provider subjects;
- all balance and kWh totals;
- panel counts by state;
- transaction and withdrawal counts by state;
- referral and wallet counts;
- orphan and conflict counts;
- roles, idempotency and transaction lock constraints.

A missing database is reported as `NOT_RUN_DB_UNAVAILABLE`. It must
never be reported as a passed PostgreSQL reconciliation.

Cycles 1594-1595 have no data migration, so reconciliation remains
the unchanged read-only baseline status.

## 10. TON and Telegram rules

TON login starts without a current Telegram user. Telegram login
validates initData, resolves the Telegram identity and returns the same
`user_id` on every valid login.

No existing accounts are merged automatically. No wallet address is
trusted without a valid proof and challenge.

## 11. Contract gate

Legacy owner columns may be removed only after:

- complete backfill;
- zero unresolved orphan and conflict findings;
- zero compatibility fallback;
- green PostgreSQL, auth and financial suites;
- exact-HEAD CI;
- a separate approved contract cycle.


## 12. Cycle 1597 EXPAND execution

Cycle 1597 begins the real schema sequence with revision `0002` because
a database already stamped at `0001` will not execute a modified `0001`
again.

Permitted changes:

- nullable `users.user_id BIGINT`;
- independent bounded sequence;
- default for newly created users;
- unique and range constraints;
- PostgreSQL offline DDL rendering and migration-path tests.

Forbidden changes:

- historical user_id backfill;
- `users.global_id` nullability change;
- `users.user_id` NOT NULL or primary-key switch;
- domain read/write switch;
- TON login activation;
- financial mutation.

Future TON login must resolve verified wallets in this order:

1. existing TON identity;
2. unique active proof-verified legacy wallet binding;
3. new atomic user + identity + binding creation.

Conflicts fail closed. Existing accounts are not merged automatically.
