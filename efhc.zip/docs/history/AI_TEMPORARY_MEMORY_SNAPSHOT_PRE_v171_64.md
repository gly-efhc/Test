# Historical snapshot — AI temporary memory before v171.64

Status: HISTORY / NOT DEFAULT READ.

This snapshot preserves the former accumulated temporary-memory file. It is not an active AI operational source and may be opened only by an explicit historical/forensic route.


## 2026-05-18 temporary memory — v168_49

The user reported that public UI content was polluted by technical
notices and unsanctioned Energy actions.  v168_49 preserves Docker
fixes from v168_48 but removes the HUB runtime notice, removes HUB and
Wallet/Profile action cards from Energy, restores visible balances and
hides browser/PWA/internal shell labels from public Profile.  Routine
Docker instructions must not use `down -v` because it deletes local DB
volumes and can wipe balances/panels in the local stand.

## 2026-05-18 temporary memory — v168_45

User pasted a Docker log: backend built, frontend stopped at
`RUN npm ci`.  This is classified as a frontend dependency install
blocker/hang or visibility problem, not as backend or Telegram runtime.
`ops/docker/Dockerfile.frontend` was hardened with explicit npm
registry, no-audit/no-fund/progress=false and fetch retries.  Docker
runtime proof is still not claimed because Docker is unavailable in the
assistant container.

## 2026-05-18 temporary memory — v168_44

Fresh log `logs_69555566503.zip` was green.  Gate summary confirmed
exit code zero for alembic, bandit, compileall, flake8, mypy, npm ci,
npm build, pytest, psql and ruff.  Pytest reported 538 passed.

The pass closed remaining tails rather than chasing fake failures:
work pass now compress Panels, Exchange, Tasks, Referrals and
Ranks with `GameDetails`; public route entry points are preserved; npm
audit warnings were reduced to zero by updating frontend dependency
pins and using safe overrides for transitive packages.

## 2026-05-18 temporary memory — v168_43

Fresh log `logs_69510727201.zip` was repaired.  Internal helper routes
`/cron/tick` and `/tg/webhook` are now tracked in
`docs/SSOT/ssot_pack/SSOT_INTERNAL_ROUTES.csv`, while
`SSOT_ROUTES.csv` remains the public OpenAPI route surface.  Energy
work pass are closed as compact first-screen polish: EFHC chip,
HUB card, Wallet/Profile card, bottom menu preserved and action-count
guard added.

## 1217-1218 temporary memory

User requires human questions in chat. Do not ask technical robot-style
questions. For visual/product approval, ask simple questions with clear
examples.

## 2026-05-17 temporary memory — visual reference and language

The user clarified two active UI rules:

1. Language selector in Profile must be one current-language button with
   dropdown choices, not a visible rail of all languages.
2. Dragon/Web3 uploaded sandboxes are visual references for future EFHC
   polish: game-like surfaces, buttons, progress bars and standalone
   browser launch.  EFHC functions and brand must remain EFHC.

# AI TEMPORARY MEMORY PENDING

## Срочная временная память — 2026-04-08

- Подтверждённый рецидив AI-layer: попытка снова запускать локально то,
  что пользователь делает GitHub CI-прогонами.
- Это запрещено. Лечим только по `logs_*.zip` от пользователя и не
  делаем локальный псевдо-CI.
- Подтверждённый рецидив AI-layer: отсутствие вопросов при реальной
  неясности.
- Это запрещено. При неясности сначала вопрос, потом изменение.
- CI-файлы меняются только в чате по отдельному прямому поручению
  пользователя; внутри архива самовольно не правим.
- Подтверждённое правило вопросов итерации: сначала делать весь
  совместимый объём без вопросов, не дробить искусственно и задавать в
  конце только 2 вопроса, которые реально меняют архитектуру или
  продуктовую модель.
- Не надо спрашивать порядок двух совместимых подзадач, мелкие
  visual-варианты и то, что уже читается из HEAD/кода/канона.

Purpose: temporary alignment layer for short-lived but operationally
important
facts that still need later consolidation into stable AI docs, canon,
norm,
WORK_CYCLES, Q&A or reports.

## Rules

- Do not store permanent canon here if it already belongs in stable AI
  docs.
- Use this file for transitional memory that affects near-term cycles.
- After consolidation, move or remove items instead of duplicating them
  forever.


## Consolidated on 2026-04-16 after work pass

The following themes are no longer temporary-only and are now fixed in
stable
AI / SSOT / cycle documents:
- Telegram-first product canon
- one-profile EFHC model across bot and web
- Hub as the external economic sector handoff
- shared launcher behavior across top-up entry points
- release-truth maturity labels and governance
- glossary canon for `not release contour`

Temporary memory should no longer be used as the main carrier of those
items.


## Consolidated on 2026-04-24 during work pass

The following temporary rules are no longer temporary-only:

- manual localization anti-bypass rule;
- one request = one cycle by default;
- archive compression / scope integrity guard;
- sandbox/reference-only donor rule.

Canonical/current locations:

- `docs/AI/AI_OPERATOR_RULES_EFHC.md`;
- `docs/SSOT/LANGUAGE_CANON_SSOT.md`;
- `docs/NORM/RELEASE_ARCHIVE_HYGIENE_NORM.md`;
- `docs/NORM/UNIFIED_EXTERNAL_STOREFRONT_NORM.md`;
- `docs/NORM/FRONTEND_TON_RUNTIME_PATH_NORM.md`;
- `docs/SSOT/TERMS_GLOSSARY.md`.

The older notes below remain as historical planning memory only where a
stable
AI/NORM/SSOT document now carries the rule.

## Current pending items

### Frontend shell simplification (2026-04-04)

- WebApp and browser flow must be treated as one frontend shell, not as
  two separate products.
- Telegram is an embedded/context layer and handoff surface, not a
  reason to fork the TON/TonConnect/runtime stack.
- Checkout, TonConnect, TON runtime, and EFHC-owned
  `frontend/src/lib/ton/*` logic should stay unified across embedded
  Telegram entry and direct browser entry.

### Browser Shop / VIP / payment semantics

- Browser-shop MVP uses the model: one selected card or one custom
  amount = one
  checkout = one payment intent = one operation.
- The external Shop product surface is unified on one page and should
  include:
  package cards, one custom EFHC card, and EFHC VIP NFT cards.
- Hub inside Telegram remains a link/handoff screen only. Purchases stay
  in the
  external browser sector.
- Direct browser entry is allowed, but final confirmation requires
  Telegram
  linking and return to the same unfinished checkout state.
- Browser web-session is short-lived and scoped to the current checkout.
- If a Telegram-linked user already has a bound wallet in the bot, the
  external
  Shop should reuse that binding instead of forcing a repeated
  wallet-linking
  step.
- Memo-based reconciliation is the primary matching mechanism for
  incoming TON /
  USDT payments in MVP.
- Checkout must expose enough data for the bot/backend to verify payment
  and
  perform ledger postings from the bank to the user account.
- Expired or abandoned intents should remain in backend history, but
  must not
  pollute the visible profile history in the bot.
- Unified user-facing history in the bot stays simple: successful
  browser-shop
  purchase is shown as a normal incoming EFHC top-up.

### VIP semantics confirmed from archive and chat

- VIP cards/NFT are not an activation flow inside the shop; they are
  checked by the bot and stay a separate external/verification contour.
- VIP status itself is checked automatically by the bot.
- EFHC VIP NFT is not auto-issued after payment; instead a manual issue
  request
  is created in the admin area.
- Old shop logic already supports NFT VIP as a distinct item type and
  uses a
  manual-pending-paid order status for that flow.

### Custom and package pricing

- Custom purchase input is entered in EFHC only.
- Current base custom rate: 0.3 USDT = 1 EFHC.
- TON amount is an oracle-based floating equivalent of the USDT sum and
  must be
  fixed inside the intent for its TTL.
- Package cards use separately assigned manual prices.
- Minimum threshold for custom purchase: 10 EFHC.
- Quantities and calculations remain canonically compatible with 8
  decimals,
  even if UI displays them in a simplified way.


### Final canon after iteration #10

- Browser-shop MVP canon: one storefront, one checkout pattern, one
  status
  screen, no cart, one selected product = one operation.
- Telegram linking must be mandatory before final confirmation, but the
  page
  should prefer automatic linking by handoff key whenever possible.
- The browser page should expose top-level controls for Telegram sync
  and
  wallet sync when auto-binding by key is not available.
- Economic canon reminder: user-facing wording may say incoming/outgoing
  for
  convenience, but real accounting logic remains debit/credit postings
  between
  the user and the bank.


### Operator note from current chat

- The assistant must continue writing all important chat details into
  temporary
  AI memory during the browser-shop planning and build-out, not only
  after full
  implementation cycles.

### Pricing and card-model details

- Browser-shop pricing layer must be described in detail in Russian.
- Package cards may use manually assigned prices that are independent
  from the
  base custom rate.
- Custom purchase uses the base rate only and starts from EFHC quantity
  input.
- TON amount is always the oracle-based equivalent of the current USDT
  total
  and is frozen inside the intent until TTL expiry.
- Product page should remain compact enough for approximately 30-50
  total
  positions without introducing a cart model.
- Page-top sync controls must exist for Telegram and wallet
  synchronization if
  auto-binding by key is unavailable.


### Checkout / status planning details

- Unified checkout must be described as a single pattern for package
  cards,
  custom EFHC purchase and VIP NFT cards.
- Final checkout payload shown to the user must always include enough
  data for
  payment verification: payment address, memo, amount, TTL and current
  status.
- Status screen is its own required page/state and should differentiate
  text for
  EFHC-credit flows and VIP manual-issue flows.
- Documentation updates must stay in sync across AI / SSOT / NORM /
  GENERAL as
  cycles progress.


### Intent / memo contract details

- Browser-shop intent contract must stay strictly single-operation: one
  product
  or one custom amount -> one draft checkout -> one linked checkout ->
  one
  payment intent.
- Payment intent is created only after Telegram linking is confirmed.
- Draft checkout state may exist before linking but must not become a
  payment
  intent yet.
- Memo must be unique per operation and serve as the primary
  reconciliation key
  together with the configured receiving address and asset context.
- Intent must freeze the pricing snapshot needed for payment
  verification until
  TTL expiry.


### Verified memo immutability

- Current code audit confirms that client payload for external shop
  order does
  not include a memo field.
- `ShopOrderExternalIn` currently exposes only `sku`, `quantity` and
  `pay_method`.
- External order memo is generated server-side by
  `_build_memo_for_external()`.
- Route-level order flow then overwrites returned payment data with
  intent
  payload generated by the payment-intent layer.
- User must not be allowed to edit or replace memo in the browser-shop
  UI.
- Server remains the sole source of truth for memo generation.


### Anti-fraud watcher rules

- Memo alone must never grant credit.
- A payment may be credited only if there is a site-created authorized
  intent or
  equivalent server-side purchase signal created before the on-chain
  transfer.
- Watcher must ignore arbitrary incoming payments with copied/guessed
  memo if
  they do not match the full expected payment profile.
- Required match set for crediting:
  - existing authorized pending intent
  - correct receiving address context
  - correct asset type
  - exact expected memo
  - amount matching the frozen expected amount under the accepted rules
  - non-expired / still valid intent state
- Unmatched or underpaid memo-bearing transfers must be treated as
  foreign /
  unsolicited payments and must not create user credit automatically.


### Browser-shop UI/UX and return-to-bot details

- Browser-shop should look visually separate from the Telegram WebApp
  even
  though it lives inside the same repository.
- Storefront must stay compact, readable and single-page without cart
  complexity.
- One-card -> one-operation flow must stay visually obvious to the user.
- Status screen must clearly separate waiting, confirmed,
  credited/manual issue
  and expired/error outcomes.
- Return-to-bot action should stay simple: open the bot, without
  overcomplicated
  deep-link routing.


### MVP validation gate

- Before code-start, Hub + browser-shop must be validated as one
  connected MVP
  contour, not as isolated documentation fragments.
- Validation checklist must cover: Hub handoff, direct browser entry,
  Telegram
  linking, wallet reuse, storefront, checkout, status screen, intent
  contract,
  immutable memo, anti-fraud watcher rules, business logic by item type,
  user-facing history, simple return-to-bot.
- After validation, the next step is code-start, not a return to generic
  ideation, unless a new ambiguity is discovered.


### Aftercare / cleanup details before code-start

- Browser-shop code-start should not inherit unresolved placeholder
  texts or
  vague user messages from the planning phase.
- Aftercare for the MVP line means cleaning transitional wording,
  temporary
  guidance text and any ambiguous helper states around
  checkout/status/linking.
- Cleanup must preserve canon, NORM and audit history while removing
  needless
  ambiguity from user-facing strings and planning leftovers.


### Storefront code-start details

- Browser-shop now has its first real storefront-code layer, not only
  shell text.
- Storefront cards are loaded from backend catalog data instead of
  remaining
  purely static placeholders.
- Custom EFHC card still exists as a separate first-class storefront
  card and
  remains outside the shared catalog feed for now.
- Checkout actions are still intentionally disabled until the next
  cycles build
  real checkout/status/linking behavior.


### Checkout shell code-start details

- Browser-shop now has a user-clickable checkout shell instead of
  disabled card
  buttons only.
- Custom EFHC card opens its own checkout state with quantity input.
- Catalog-backed cards open a checkout summary with asset switch and
  memo/TTL
  preview.
- Status screen now exists as a separate interactive shell block, even
  before
  real intent/linking wiring is implemented.


### Linking and wallet-reuse code-start details

- Browser-shop bootstrap now distinguishes not only guest vs
  handoff-bound
  entry, but also whether an active wallet binding already exists.
- Wallet reuse is now represented in the backend bootstrap contract
  rather than
  being only a planning promise.
- UI sync buttons should reflect actual state: Telegram sync disabled
  when
  already linked, wallet sync disabled when an active wallet is already
  reused.


### Intent creation code-start details

- Browser-shop now has its first real intent-creation route instead of a
  pure
  planning shell.
- Current code-start path requires a valid handoff token and an already
  active
  wallet binding before intent creation is allowed.
- Intent creation reuses existing shop external order logic and
  payment-intent
  service instead of introducing a parallel purchase path.
- The frontend now surfaces returned memo, amount, destination wallet
  and order
  identifier after intent creation.


### Watcher-side matching code-start details

- Browser-shop now has its first token-based intent-status polling path.
- The external shop can ask backend for intent status using the same
  handoff
  identity context instead of relying on open guest polling.
- This is the first real bridge between browser-shop UI and watcher-side
  intent
  state, even though full business-result finishing is still in the next
  cycle.


### Business-finish code-start details

- Browser-shop status shell now has user-facing result text that differs
  for
  EFHC credit flows and VIP manual-issue flows.
- Browser-shop bootstrap can now expose a simple bot-open URL when
  BOT_USERNAME
  is configured in environment.
- User-facing finish now includes a simple return-to-bot action instead
  of only
  technical status data.


### Telegram sync action code-start details

- Browser-shop bootstrap now may expose a dedicated Telegram sync URL if
  `BOT_USERNAME` is configured.
- Telegram sync is now a real UI action for guest browser entry instead
  of only
  a disabled placeholder.
- Current sync action is intentionally simple: open the bot via a sync
  start
  link, without pretending that full automatic return-state restoration
  is
  already solved in code.


### Batch progress for cycles 272-276

- Wallet sync action now mirrors Telegram sync with its own practical
  bot-entry
  link when configured.
- Custom EFHC card now has a live USDT preview based on the base rate,
  while TON
  preview remains intentionally deferred to the intent-freeze stage.
- Checkout creation now enforces basic guards before intent creation:
  Telegram sync required, wallet sync required, and custom minimum
  threshold.
- Storefront cards now have clearer badge-like product cues for EFHC
  packages
  and VIP NFT entries.
- Status polling now refreshes real backend state and maps
  CONFIRMED/SENT into
  user-facing shell states.


### Batch progress for cycles 277-280

- Anti-fraud integration guards now explicitly block invalid pay
  methods, non-1
  quantities, inactive/missing storefront SKUs and unsupported
  pay-method/item
  combinations before browser-shop intent creation.
- `CUSTOM_EFHC` intent creation is now honestly blocked until a
  dedicated backend
  pricing/order flow is wired, instead of pretending the current
  catalog-based
  intent path already supports it.
- Admin sale-packages now has its first MVP UI in admin frontend: list,
  create
  and toggle active state.
- Release readiness is still not green: frontend build proof and live
  end-to-end
  browser-shop payment proof are still absent in this cycle.


### Batch progress for cycles 281-284

- Dedicated backend flow now exists for `CUSTOM_EFHC` intent creation.
- Current custom EFHC MVP truthfully supports `USDT` only; custom TON
  remains
  blocked until oracle-based pricing is wired.
- Custom intent creation now freezes the base-rate pricing snapshot at
  intent
  creation time and stores it in the normal `deposit_efhc` intent path.
- Browser-shop now persists checkout draft state locally and restores it
  after
  returning from Telegram sync or wallet sync.
- Current restore behavior is browser-state restoration, not yet a
  stronger
  server-verified return-state protocol.


### Batch progress for cycles 285-290

- Admin sale-packages management is now richer: list/create/edit/toggle.
- Browser-shop visible wording is cleaner and less shell-like for the
  user.
- Browser-shop now has browser-side draft restore for sync returns and
  that route/state
  path was verified in the current archive.
- Frontend `npm ci` and `npm run build` were both completed successfully
  in this pass after
  fixing real TypeScript breakages.
- Release gate v2 is stronger than before but still not fully green
  because live on-chain
  end-to-end payment proof is still absent and custom TON remains
  blocked.
- Remarks audit: HEAL-0010 pagination-missing issue is not confirmed as
  current; `Pagination`
  exists in `admin_logging.py` and is imported/exported.


### Batch progress for cycles 291-300

- HEAL-0018 received a first targeted code treatment in
  `withdraw_service.py` via
  nested-aware transaction context.
- HEAL-0016 TON validator wave now reuses TonConnect parser semantics in
  wallet
  normalization and withdraw-address validation.
- A regression test file for realistic TON addresses was added, but
  truthful test
  execution was blocked in this pass by missing importable SQLAlchemy in
  the local
  test environment.
- HEAL-0010 pagination-missing issue was checked again and still does
  not confirm as
  a current live bug.
- Skins/VIP healer items remain audited but not falsely declared closed.
- Browser-shop release gate v3 is stronger but still not fully green.


### Batch progress for work pass — `Session already begun` wave received targeted continuation in
  energy/referral/tasks/wallet-binding services via nested-aware
  `_begin_tx(db)` helpers.
- This remains a targeted healer treatment, not a universal claim that
  every transaction-boundary issue in the whole project is now gone.
- Current line72 snapshot for Python tests in this pass: 243 violations
  above 72 chars.
- Release gate v4 remains non-green mainly because live payment proof
  and broader healer cleanup are still missing.


### Emergency backend line72 correction

- User clarified that the main urgent question is line72 in backend.
- Direct measurement in current HEAD showed 10 backend Python line72
  violations before the emergency fix.
- After targeted wrapping in backend files, current backend line72
  snapshot in this pass is 0 violations.
- Tests still remain non-green for line72 in this pass: 151 violations
  after formatter-assisted reduction.


### Emergency degradation memory — 2026-04-02

- Main urgent user concern is line72 in backend.
- Backend line72 was measured directly and reduced from 10 violations to
  0.
- Tests line72 remains non-green: 151 violations in the current slice.
- Long package waves previously degraded because final control checks
  were not
  always re-run before moving to the next queue.
- Confirmed process degradations from archive history:
  - backend line72 drift;
  - tests line72 drift;
  - delayed final verification layer;
  - queue continuity slip in chat;
  - English roadmap leakage in chat;
  - delayed synchronous update of AI/NORM/GENERAL/registries in some
    waves.
- Existing planned queue after 311 must be pushed further until
  anti-degradation
  cycles are completed.


### work pass completion result — tests line72 emergency wave

- tests line72 was reduced from 151 to 0 in the current slice.
- `python -m compileall tests` passes after syntax repairs in the
  touched tests.
- Current archive audit still does not prove that most special control
  tests
  vanished; the stronger conclusion is that many controls still exist,
  but the
  mandatory final verification layer was not rerun consistently enough.


### Recovered legacy controls from v157 archive

- old archive contained a stricter compact control model that must
  remain alive
  in the current AI layer;
- especially important restored controls: logs-first CI truth, no green
  claims
  without fresh logs, no ZIP without real changes, mandatory
  reports/registries
  after confirmed cycles, tg_id only, 2 DB schemas,
  bank/withdraw/economic
  canon, periodic docs-vs-code sync, and CI runner reproducibility
  controls.


### work pass continuity enforcement

- Queue continuity and Russian-only roadmap are now treated as
  first-class
  control rules rather than stylistic preferences.
- Any future emergency-wave must explicitly insert new cycles and shift
  the old
  queue forward instead of silently jumping over it.


### work pass emergency enforcement

- Synchronous update of AI/NORM/GENERAL/registries is now a hard control
  rule.
- Archive audit still shows that many guard tests exist; the real
  weakness was
  final verification rerun discipline.
- Postgres-only policy for row-lock / SQL-function sensitive tests is
  now
  explicitly recorded.


### Russian-only chat enforcement reminder

- User-facing cycle descriptions must remain fully Russian.
- Any recurrence of English cycle wording in chat is treated as a
  control
  degradation, not as a cosmetic slip.


### work pass release-wave reminder

- Live payment proof cannot be claimed without a real on-chain payment
  event and
  captured evidence.
- In the absence of a live payment event, release-wave cycles must
  remain honest
  and operate through preparation, verification, gates and consolidated
  risk
  audits.

## work pass manual log-fix wave
- Источник истины по блоку: logs_63144383921.zip.
- Нельзя считать логовый пакет закрытым только по compileall; нужен
  свежий subset-proof или новый CI-log.
- В этой среде часть локальных pytest/bandit доказательств ограничена
  отсутствием установленных инструментов (sqlalchemy/bandit).

## work pass manual log-fix wave
- Источник: logs_63146798186.zip.
- Исправлены вручную новые блокеры после work pass:
  - mypy undefined name safe_payment_intents_table;
  - frontend build type error в BrowserShopPage className;
  - stale/duplicate import headers в ряде тестов вскрыли новую
    ruff-wave.
- Текущий остаток после ручного пакета: 26 ruff/import ошибок в tests +
  payment_intents_service scope cleanup still needs fresh ruff proof.

## work pass manual ruff-wave closure
- Продолжение logs_63146798186.zip.
- Добита остаточная ruff/import волна по целевому пакету test files и
  payment_intents_service.
- Подтверждено: ruff по целевому пакету файлов проходит.
- Ограничение: это не означает автоматически зелёный полный CI; нужен
  новый лог после архива.

## work pass manual pytest gate fix
- Источник: logs_63148944432.zip.
- Gate summary показал: после work pass все шаги зелёные, кроме pytest.
- Подтверждённая причина pytest fail: у panel tests исчез async-marking,
  поэтому CI видел async def без поддержки.
- Bandit warnings по nosec не были gate-fail в этом логе.

## work pass green CI proof
- Источник: logs_63150433402.zip.
- Подтверждено по 24_Gate summary.txt: все gate steps прошли с exit=0.
- Это первый подтверждённый зелёный CI после логовых волн 331-334.
- Подтверждены: alembic, bandit, compileall, flake8, mypy, npm build,
  pytest, ruff.

## work pass docs-before-build rule
- Новое контрольное правило пользователя: документы текущего цикла
  должны быть заполнены до сборки релизного ZIP, а не догоняться
  следующим циклом.
- Перед выдачей архива обязательно сначала синхронно обновить AI / SSOT
  / NORM / GENERAL, WORK_CYCLES, Q&A, Healer и reports, и только потом
  собирать ZIP.

## work pass pending carry-forward
- User `GET /withdraw/list` is now read-only; withdraw repair moved out
  of the user read path and into admin-only execution.
- `/exchange/convert/{global_id}` now preserves the `amount_kwh` contract:
  omitted amount = full exchange, explicit amount = partial exchange.
- `api/index.py` now loads `.env` before importing `app.main`.
- `backend/app/init.py` now delegates `create_app()` to the
  canonical `app.main.app`.
- USDT live checkout path is temporarily disabled until a real jetton
  transfer payload exists.
- work pass remains open for real jetton transfer implementation or a
  stronger deferred-state package.

## work pass deferred-state closure
- work pass closed via a stronger deferred-state package instead of a
  fake real-jetton claim.
- USDT is now blocked earlier in hub/shop/payment-intents/catalog
  layers, not only at final tx assembly.
- Honest live state: TON-only checkout until a real TEP-74 jetton
  payload can be generated and proven.

## work pass sandbox curation
- A new local folder `песочница/` was created in HEAD.
- It contains 10 curated donor sources for future cycles: sdk-main,
  reactjs-template, nextjs-template, demo-telegram-bot, pytonconnect,
  telegram-web-app-shop, telebook, react-telegram-web-app,
  tma-starter-kit, fastapi-telegram-mini-app.
- Main donor priority for real USDT jetton transfer: `sdk-main`.


## work pass donor audit + EFHC jetton canon
- Пользователь потребовал продолжить работу и добавить в канон его EFHC
  jetton.
- Подтверждено по current HEAD: `EFHC_JETTON_MASTER_ADDRESS` уже имеет
  живое значение `EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw` в
  config-layer.
- Это значение зафиксировано в каноне как внешний EFHC jetton (`EFHCj`)
  с decimals d8.
- Выполнен только аудит и карта переноса доноров; live implementation
  real USDT jetton transfer в этом цикле не заявлялась.
- Главный документ текущей подготовительной фазы:
  `docs/GENERAL/USDT_REAL_JETTON_DONOR_AUDIT_AND_TRANSFER_MAP.md`.

## work pass donor integration prep
- Пользователь потребовал продолжить циклы 349-354 аккуратно, вручную и
  без спешки, с оперативным заполнением документов и логов.
- В этой волне выполнен подготовительный audit package без ложного
  заявления о live USDT implementation.
- Зафиксированы отдельные документы по donor surface (`sdk-main`),
  frontend adapter plan, recipient/payload/fee decisions, backend
  intent/watcher alignment, guard-test package и live gating.
- Главный текущий вывод: `sdk-main` даёт минимально достаточный donor
  surface через `TransferUsdt.tsx` + units helpers + SDK dependency set;
  остальная песочница остаётся reference-only.

## work pass implementation wave progress
- Пользователь потребовал продолжить циклы 355-370 аккуратно, вручную и
  без спешки, с оперативным заполнением документов и логов.
- В этом проходе закрыта безопасная стартовая часть implementation wave
  без ложного включения USDT live.
- Подготовлены и добавлены frontend foundation files:
  - `frontend/src/lib/ton/units.ts`
  - `frontend/src/lib/ton/payload.ts`
  - `frontend/src/lib/ton/policy.ts`
  - `frontend/src/lib/ton/index.ts`
- Локально подтверждено: targeted TypeScript check по `src/lib/ton/*.ts`
  проходит.
- Ограничение: полный frontend build-proof и dependency install wave не
  заявлялись в этой среде.

## work pass current pass
- Проведена dependency manifest wave во frontend:
  `frontend/package.json` и `frontend/package-lock.json` обновлены под
  `@ton/core`, `@ton/ton`, `@ton-community/assets-sdk`.
- Честное ограничение: `npm install` в этой среде упирается в `E401
  Incorrect or missing password`, поэтому node_modules/install-proof и
  full build-proof не заявляются.
- Добавлены дополнительные safe helper files:
  - `frontend/src/lib/ton/constants.ts`
  - `frontend/src/lib/ton/recipient.ts`
- Локально подтверждено: targeted `tsc` по `src/lib/ton/*.ts` проходит и
  после расширения helper-layer.

## work pass current pass
- Продолжена implementation wave после dependency manifest pass.
- Добавлены новые files:
  - `frontend/src/lib/ton/tx.ts`
  - `frontend/src/lib/ton/usdt-transfer-plan.ts`
- `usdt-transfer-plan.ts` не строит TEP-74 body сам, но уже нормализует:
  - asset/decimals,
  - canonical payload,
  - recipient policy,
  - fee policy,
  - query_id,
  - sender/response addresses.
- Локально подтверждено: targeted `tsc` по `src/lib/ton/*.ts` проходит и
  после этих файлов.
- Честная граница: real SDK-backed builder cycle всё ещё не заявляется
  завершённым.

## work pass backend intent enrichment pass
- Продолжена implementation wave по safe path без ложного USDT live
  enable.
- Backend слой enriched optional transport metadata в intent/status
  responses:
  - `tonconnect_transport_kind`
  - `jetton_master_address`
  - `jetton_decimals`
  - `forward_payload_text`
  - `fee_message_ton_amount`
  - `forward_ton_amount`
  - `recipient_strategy`
- Изменены:
  - `backend/app/services/payment_intents_service.py`
  - `backend/app/schemas/hub_schemas.py`
  - `backend/app/schemas/deposit_schemas.py`
  - `backend/app/schemas/payment_intents_schemas.py`
  - frontend local types in `BrowserShopPage.tsx`
- Локально подтверждено: compileall по изменённым backend Python-файлам
  проходит.

## work pass SDK-backed builder pass
- Написан unverified implementation слой для будущего real jetton
  transfer:
  - `frontend/src/lib/ton/jetton-transfer-builder.ts`
  - `frontend/src/lib/ton/usdt-transfer.ts`
- Builder-layer содержит:
  - sender jetton wallet resolution;
  - balance read attempt;
  - forward payload cell build;
  - jetton transfer body build;
  - TonConnect tx assembly;
  - high-level `buildUsdtTransfer(...)` adapter.
- Честная граница: из-за отсутствия установленного TON SDK в среде это
  unverified implementation pass, не runtime-proof.
- Локально подтверждено только syntax-level proof через TypeScript
  transpileModule; module-resolution/runtime proof не заявляется.

## Cycles ongoing — browser-shop transport integration pass
- Добавлен `frontend/src/lib/ton/browser-shop-intent.ts`.
- Новый helper умеет читать transport metadata из browser-shop intent и
  собирать builder-ready USDT transfer plan без смешения UI и blockchain
  policy.
- `BrowserShopPage.tsx` теперь безопасно показывает transport metadata
  preview, если backend уже отдаёт эти optional поля.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files, включая
    `browser-shop-intent.ts`, проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.

## Current pass — readiness and tx normalization
- Добавлены:
  - `frontend/src/lib/ton/tonconnect-normalize.ts`
  - `frontend/src/lib/ton/usdt-readiness.ts`
- BrowserShopPage теперь умеет:
  - нормализовать raw `tonconnect_tx` в локальный `TonConnectTx`
    preview;
  - честно показывать readiness будущего USDT builder path;
  - выводить список недостающих transport metadata полей.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.

## Current pass — runtime gate state integration
- Добавлены:
  - `frontend/src/lib/ton/feature-gates.ts`
  - `frontend/src/lib/ton/browser-shop-usdt-runtime.ts`
- BrowserShopPage теперь умеет показывать:
  - `runtime mode`;
  - `USDT runtime status`;
  - `preview-ready`;
  - `checkout-ready`;
  - `blocking reasons`.
- Локально подтверждено:
  - targeted `tsc` по pure local TON files проходит;
  - syntax-level transpile proof по `BrowserShopPage.tsx` проходит.
- Честная граница: live USDT state остаётся disabled; runtime proof
  builder/adaptor слоя по-прежнему не заявляется.

## Current pass — server-truth USDT mode integration
- Backend truth-point добавлен: `usdt_checkout_mode` теперь проходит
  через browser-shop bootstrap и payment-intent transport contracts.
- Frontend gate/state helper теперь учитывает server mode.
- BrowserShopPage показывает серверный режим отдельно от локального
  runtime summary.
- Локально подтверждено: compileall backend; targeted tsc по pure local
  TON files; transpile proof страницы.
- Жёсткая граница сохраняется: live USDT mode всё ещё `disabled`.

## Current pass — watcher transport split + command summary integration
- Добавлен `frontend/src/lib/ton/browser-shop-usdt-command.ts`.
- Добавлен `backend/app/services/watcher_transport.py`.
- `watcher_service.py` теперь опирается на transport decision layer для
  разделения `native_ton / efhc_jetton / jetton_transfer`.
- Подтверждено: `3 passed` для
  `tests/architecture/test_watcher_transport_modes.py`.

## Current pass — watcher validation hardening
- `watcher_transport.py` теперь различает `unknown_jetton`.
- Добавлена `validate_payment_intent_transport(...)`.
- `watcher_service.py` теперь переводит unsupported transport cases в
  `pending_manual` с записью в `unmatched_incoming`.
- Подтверждено: `6 passed` для
  `tests/architecture/test_watcher_transport_modes.py`.

## Current pass — log-fix wave: repo hygiene + mypy/ruff
- Исправлен подтверждённый mypy issue в `transactions_service.TxResult`.
- Удалён `frontend/tsconfig.tsbuildinfo`.
- `песочница` исключена из repo-wide guard tests как donor-store.
- `tg-id alias` заменён на `tg_id` во frontend TON helper files.
- Добавлен SSOT lock comment в `exchange_service.py`.
- Локально подтверждено: mypy success, ruff success, 15/15 локально на
  пакете упавших CI tests.

## Current pass — tg-id alias doc cleanup + blocker registry
- Исправлен свежий log fail: `test_no_tg_id_aliases_repo` теперь
  проходит.
- Документы и реестры очищены от alias-формы `tg-id alias` / прежних
  упоминаний.
- В `WORK_CYCLES.md` зафиксирован честный список причин, почему ещё не
  закрыты 356, 358–364, 368–370.

- 2026-04-03: work pass advanced again: added process-level watcher
  tests for already_final, foreign wallet skip, native TON intent path,
  plus retained unknown/usdt jetton intent checks. Local proof: 11
  passed across watcher transport/process test package.

- 2026-04-03: work pass advanced again: watcher process-level tests now
  cover unknown jetton block, USDT confirm D6 path, already_final
  short-circuit, foreign wallet skip, native TON intent path, and
  confirm-failure->pending_manual branches. Local proof: watcher suite
  13 passed; payment-intent USDT suite 2 passed, 3 skipped.

- 2026-04-03: New log `logs_63240230827.zip` fixed locally. Resolved:
  watcher_service schema drift on ton_inbox_logs.utime, repo docs alias
  in WORK_CYCLES, and ruff import order in watcher process tests. Local
  proof: mypy backend/app success; ruff backend/api/ops/tests success;
  targeted pytest package 16 passed, 3 skipped.

- 2026-04-03: New log `logs_63241331034.zip` fixed locally. Removed
  asyncpg ambiguous parameter issue in watcher upsert by casting status
  and replacing parameterized status comparisons with literal
  final-status checks. Local proof: targeted pytest package 16 passed /
  3 skipped; ruff success; mypy success.

- 2026-04-03: Added `ton-access-main` and `ton-crypto-master` into
  `песочница/` as TON donor/reference archives for simplifying the
  runtime dependency path.

- 2026-04-03: one-pass blocker attack: removed
  `@ton-community/assets-sdk` from active runtime path and rewrote
  jetton builder to low-level `@ton/core` + `@ton/ton` only. Then
  rechecked npm install blocker.

- 2026-04-03: added `ton-core-main` and `ton-main` into `песочница/` as
  local source donors for the minimal TON runtime path.

- 2026-04-03: major blocker attack continued. Removed `@ton/core` and
  `@ton/ton` from npm dependency path, mapped them to local sandbox
  sources via `tsconfig.json`, regenerated lockfile, and re-checked npm.
  Result: old TON/package blocker moved forward; current npm E401 now
  hits `@tonconnect/ui-react` / `@tonconnect/ui` (and dev install
  previously also hit `@types/node`).

- 2026-04-03: audited sandbox for TonConnect UI. Main donor is
  `sdk-main`; local source donors for runtime path are `ton-core-main`,
  `ton-main`, `ton-crypto-master`; `ton-access-main` remains endpoint
  reference only.
- 2026-04-03: breakthrough on main frontend blocker. TonConnect UI npm
  package removed from active dependency path; local compat layer added
  on top of sdk-main source donors. `npm ci` now passes. Remaining
  blocker moved from install-layer to type/build proof in local donor
  sources.
- 2026-04-03: sandbox audit refreshed again. Newly uploaded archives
  added to `песочница/` only as secondary reference-pool; main blocker
  donors unchanged.
- 2026-04-03: second missing-batch audit completed; 5 new UI/reference
  archives added to `песочница/`. Main blocker donors unchanged.
- 2026-04-03: main install blocker stays resolved. Additional pass
  pushed Next build deeper by patching local sdk/protocol donor-source
  typing; current residual blocker is isolatedModules/export-type
  compatibility inside local TonConnect donor sources.
- 2026-04-03: continued build/type attack on local `sdk-main` donors.
  Next build now reaches deeper local `sdk` export surfaces after
  protocol fixes and local type shims. Residual blocker moved from
  protocol entrypoint to `sdk/src/models/index.ts`.
- 2026-04-03: deep audit pass on work pass. `npm ci` still green;
  `next build` pushed deeper again. Current top stop moved from protocol
  entrypoint to `sdk/src/models/index.ts`, confirming the blocker is now
  localized inside donor-source type exports.
- 2026-04-03: extended sandbox attack on 358–359. Build moved from
  `sdk/src/index.ts` to `sdk/src/models/index.ts`. Re-run of `npm ci`
  later in the same session regressed with registry 401 on unrelated
  packages (`@twa-dev/types`, `@tanstack/query-core`), which looks like
  an environment/auth fluctuation rather than the old TON blocker.
- 2026-04-03: strategic plan fixed in docs. New order: (1) unify one TON
  runtime path, (2) add browser polyfill layer, (3) only then return to
  full USDT runtime logic. Work started: `frontend/src/polyfills.ts`
  added and imported first in `app.tsx`; `buffer` added to frontend
  deps.

- 2026-04-04: Added missing TON/TonConnect donors to sandbox and locked
  a simpler official runtime strategy: published TON runtime packages +
  Tonkeeper-compatible TonConnect UI/SDK path.

- 2026-04-04: clarified project rule — the external storefront may live
  in the same backend/admin repository, but remains an external
  storefront. Telegram-side EFHC/VIP handoff must not be treated or
  worded as an in-app sale flow.

- 2026-04-04: unfinished queue rebased. Preserve cycle numbers 358-370,
  but treat them under the common direction: one external storefront,
  one frontend shell, Telegram as handoff/context only, shared runtime
  path, EFHC top-up split from VIP verification.

- 2026-04-04: common-shell advance pack landed. TonConnect compat
  restore state no longer stays hardcoded false; guard pack now protects
  one provider, external EFHC handoff split, and unified storefront norm
  sync.

- 2026-04-09 — Защита от archive-scope regression: partial/frontend-only
  ZIP
  нельзя считать новым HEAD поверх последней полной стабильной версии
  без
  прямого подтверждения пользователя. Приоритет всегда у последней
  полной
  версии; удаление или сужение состава архива без разрешения запрещено.

## Правило простых вопросов
- вопросы пользователю задавать простым человеческим языком;
- избегать технических терминов, если без них можно обойтись;
- если технический термин неизбежен, сначала объяснить его простыми
  словами;
- не задавать вопросы в форме архитектурного жаргона;
- вопросы итерации должны быть короткими, понятными и связанными с
  реальным выбором пользователя, а не с внутренним устройством кода.


### Agreed next structured blocks from current chat

- work pass: move the remaining user-facing pages toward a clearer
  button-and-section presentation layer.
- work pass: bring the remaining admin pages to one visible UI
  standard.
- work pass: start the SSOT contract hardening wave with OpenAPI +
  automatic frontend type generation.
- work pass: add runtime validation for frontend requests and
  responses after the OpenAPI/type-generation wave.
- work pass: current pass is reserved for control-docs
  actualization before the next implementation blocks continue.

## Rule of strict sequential cycle execution
- Work cycles must be executed strictly in numeric order without jumps:
  775, then 776, then 777, then 778, and so on.
- It is forbidden to execute work pass if work pass has not actually
  been completed first.
- If the user assigns exact cycle numbers to work blocks, this means the
  user has approved the execution sequence of those blocks.
- Planned future blocks may be recorded in docs, but real execution must
  still follow the numeric order step by step.
- Archive numbering may continue independently, but cycle execution
  order may not jump ahead of the first unfinished approved cycle.


## 2026-04-16 — promoted from temporary to active canon

- Web-Profile is now the canonical account center.
- ProfileModal stays the light cockpit layer.
- DepositModal stays launcher-only and must not regain local polling,
  local resume logic or an alternative status machine.
- Backend/storefront truth leads the money path.
- Release-truth labels are active canon terms:
  helper, internal, draft, read-only, not release contour.


### Final gate and forbidden-substring discipline (2026-04-16)

- work pass final gate must include active release contour plus
  AI-layer,
  glossary consistency and helper/internal/draft marking consistency.
- The next official block after 870 is approved as 871-890 and must be
  opened explicitly in cycle docs before implementation enters that
  band.
- Forbidden-substring drift is a real canon risk in active docs: even an
  innocent English word can contain a banned legacy token.
- Broad test weakening is forbidden. Narrow exceptions may exist only
  after
  explicit user approval and must be documented as exact exceptions.

## Materialized canon moved out of pending

- Web-Profile = canonical account center
- ProfileModal = cockpit
- DepositModal = thin launcher
- helper/internal/draft/read-only/not release contour = active maturity
  labels
- forbidden words / narrow exceptions policy is now fixed in SSOT


## Archive numbering canon

- Архивные номера продолжаются строго последовательно внутри активной
  версии без самовольных прыжков и дублей.
- После `v167_02_` следующий ряд ведётся так:
  `v167_03_` ... `v167_99_`, затем `v168_00_`, `v168_01_` и далее.
- Перед выдачей нового ZIP ИИ обязан сверить последний реально выданный
  архив и продолжить нумерацию от него.
- Нельзя придумывать параллельные ветки архивных имён.

## 2026-04-24 — localization audit carry-over after work pass — Uploaded audit `EFHC_Localization_Audit_Detailed_Report.pdf` was
  imported into `docs/audits/` as md text.
- Audit-of-audit accepted it as valid localization pressure, not as
  automatic release verdict.
- Explicit RU locale leaks were repaired in `ru.json`.
- `ops/i18n/audit_ru_locale_value_quality.py` now guards the most
  important RU keys from silently reverting to English values.
- Remaining work: non-RU locale value-quality audit, bot/backend text
  synchronization, FAQ localization and visual long-language checks.

## Operator note 2026-05-16 — v168_20

work pass continued the visual repair range.

- 1200 is only a bridge verdict, not release readiness.
- 1201 cleaned public HUB to exactly two actions:
  Top up EFHC and EFHC VIP NFT.
- HUB technical details now belong to `/admin/diagnostics`.
- Browser-Shop cleanup remains the next active visual blocker.

### Browser-Shop layout repaired in v168_21

work pass moved `/browser-shop` out of the common Mini App
layout and into dedicated `ShopLayout`.  The next visual repairs must
clean the storefront body itself: product cards, admin fields,
wallet/memo/copy and payment diagnostics.

## Current visual repair memory after v168_22

- Profile language switcher and language bar were repaired in
  v168_18.
- Direct Deposit was repaired in v168_19 as a clean `+` road.
- Public HUB was cleaned to two actions in v168_20.
- Browser-Shop was moved to dedicated `ShopLayout` in v168_21.
- Browser-Shop public cards and payment diagnostics were cleaned in
  v168_22.
- Next active risk: Pay must open TON wallet immediately while raw
  transaction payloads stay internal.


## v168_24 temporary memory

work pass added Browser-Shop payment status polling after TON wallet
handoff and a static route diagnosis.  Current frontend page routes are
not globally missing.  The broader button problem is likely caused by
UX over-expansion, disabled/tokenless states, Telegram-only runtime
assumptions and weak visible feedback.

The Dragon-style visual extension plan for work pass now exists
at `docs/cycles/WORK_CYCLES_1231-1350_DRAGON_VISUAL_FUNCTIONS_PLAN.md`.

## v168_25 work pass temporary memory

The user clarified that the six bottom navigation buttons are canonical:
Energy, Panels, Exchange, Tasks, Referrals, Ranks.

Do not collapse or rename them during Dragon-style visual work.
Compress only subsections and artifact functions inside canonical pages.

FAQ was repaired for selected-language helper labels and compact bot
simulation width.

## v168_26 work pass pending memory

User confirmed that EFHC frontend compression must not change the six
canonical bottom buttons.  The first screen is Energy with progress and
generation information.  Canonical pages remain separate.  Compression
must happen inside pages and subsections.

Visible user functions require an audit and approval model:
leave, delete, move to Admin, or ask.

Dragon reference is visual only.  EFHC should adopt compact game cards,
progress bars, resource chips and browser/PWA shell direction, but must
not copy Dragon brand or assets.
## v168_27 temporary memory

work pass executed targeted shell/Docker/Telegram SDK corrections and
created the first visible-function triage table.  The six bottom menu
buttons remain immutable.  Browser install remains system/PWA controlled
without a custom EFHC install button.


## work pass user correction

- Chat is the approval place.  Archive Q/A files are memory and
  evidence, not a replacement for user approval in chat.
- Energy is the canonical first screen with progress and generation.
- The 12 Energy progress levels must not appear openly in Ranks.
- Ranks is a leaderboard, not an Energy progress catalogue.
- Dragon-style means visual layer and progressive disclosure, not
  changes to canonical EFHC functions or bottom menu names.

## v168_29 temporary memory

User clarified that all questions and answers are approved only in chat.
Archive records are internal working memory, not an approval interface.

User goal: EFHC should become a dual-surface application like the Dragon
reference: opens in Telegram and also opens independently in a
browser as a PWA-style app.  Use the browser system install prompt
only.

## 2026-05-17 browser independence correction

User launched the app and reported white/empty frontend, no dark visual
layer and no visible progress bars.  Treat this as a real blocker.

New rule: EFHC must render as a complete app without Telegram `tg_id`.
Telegram identity may personalize and unlock real server actions, but
missing identity must never blank Energy, Panels, Exchange, Tasks,
Referrals, Ranks, Profile, HUB or Browser Shop.

All details are agreed only in chat.  Archive notes are internal working
memory, not approval.
## v168_35 frontend 10-to-99 audit

Use v168_35 roadmap before large visual coding.
Agree visible elements in chat first.

## v168_36 live app blocker memory

The user provided the current Cloudflare app URL and Dragon screenshots.
The live app text exposed raw i18n keys such as `energy.title` and
`nav.hub`, confirming that the browser frontend is not product-ready.
Treat raw key leakage as a blocker, not a cosmetic issue.

Immediate rule: first paint and locale-fetch failure must still show
normal UI copy through embedded fallback dictionaries. Continue next
with
Energy first-screen proof and then the EFHC Game UI Kit.

## v168_37 independent shell and profile route memory

User confirmed that the Telegram interface exists, but EFHC must move
away from Telegram-shell dependence.  Telegram may personalize and carry
identity, but EFHC must have its own independent browser/PWA game shell.

User reported a blocker: Profile opened as an overlay, not as a normal
page, and the overlay had no clear Back/Exit path.  This can create
stacked overlays and the feeling that the app has frozen.

Current repair: active Layout no longer mounts ProfileModal for header
profile entry.  `openProfile()` routes to `/web-profile`.
Web Profile is
now a normal page with Back and Exit controls and does not require a
Telegram access token to render.

The first-page Dragon screenshots/code archive are visual references:
centered dark game shell, top player/resource/action header, large hero,
progress bar, compact action/stat cards and fixed rounded bottom nav.
Do not copy Dragon brand; adapt the visual principles to EFHC.

## v168_38 Energy first-screen memory

User confirmed that Profile remains a normal `/web-profile` page and
that Energy should move closer to Dragon first-screen structure without
copying Dragon branding or assets.

Current repair strengthens Energy as the first screen: large EFHC hero,
central kWh resource number, progress strip, active panels chip,
generation-rate chip and two first-screen action cards for Panels and
Exchange.  The duplicate pre-page skin hero on `/` was removed so Energy
has one clear first screen.

Next product step: begin the shared EFHC Game UI Kit and apply the same
visual language to Panels, Exchange, Tasks, Referrals and Ranks.

## v168_39 Game UI Kit memory

User directed that the team must not spread attention.  After Energy,
the next layer is a single EFHC Game UI Kit applied to Panels, Exchange,
Tasks, Referrals and Ranks.

User findings accepted as blockers:

- Profile / Wallet / History tabs must be localized.
- Wallet connection is not currently fully working; explain that it
  depends on TonConnect manifest, wallet runtime and real backend user
  binding.
- Public pages must hide technical errors when lists are empty or routes
  fail.
- Admin button must be visible for admin accounts.
- Flicker must be reduced by preventing splash reappearance and repeated
  Telegram MainButton re-registration.
- Bottom navigation must be more beautiful while preserving canonical
  labels.

## v168_40 temporary memory

- User asked to read documents, run the v168_39 live check, continue
  Wallet + HUB + Browser-Shop in the same EFHC Game UI Kit, update
  missed cycles and fix FAQ overflow.
- Live tunnel from the previous chat returned `502 Bad Gateway`, so no
  live visual success was claimed.
- FAQ now has strict application-frame containment.
- `/web-profile` Wallet and History now use Game UI Kit stat / notice
  primitives.
- HUB and Browser-Shop now use the shared Game UI Kit visual language.
- Browser-Shop public error state no longer renders raw exception text.

## v168_41 temporary memory

- work pass closed as Wallet state-map + TonConnect proof UI
  foundation.
- Wallet public states: connected, not connected, pending proof,
  wallet error, backend error, bound.
- `logs_69492808512.zip` was used as active repair input.
- `Песочница.xz` unpacked successfully as a readable tar/xz donor.
- Full build success is not claimed: Next build timed out during page
  data.

## 2026-05-18 temporary memory — v168_42

Fresh log pack `logs_69501935339.zip` contained 6 Ruff import-order
findings and 13 architecture pytest failures.  The v168_42 pass repaired
those confirmed blockers locally and did not claim GitHub CI.

The previous Cloudflare URL did not resolve from the environment, so
live visual success was not claimed.  Next live proof needs a fresh
working URL or user-provided runtime screenshot/log.

## v168_46 temporary memory

User reported that Docker stopped working and identified v168_37 as the
last working Docker archive.  The visible Docker log confirmed backend
build success and frontend stop at `RUN npm ci`.

The regression source is the frontend dependency layer, not the backend.
In v168_44 the package metadata was changed during npm-audit
cleanup, and v168_45 changed the frontend Dockerfile npm-ci
instruction.  v168_46
restores the v168_37 Docker-known-good frontend dependency baseline:
`ops/docker/Dockerfile.frontend`, `frontend/package.json`, and
`frontend/package-lock.json`.

Future dependency upgrades must be done only in a separate
Docker-proofed cycle, not inside a visual-polish release branch.

## 2026-05-18 temporary memory — v168_47

User provided Docker history. Corrected diagnosis: Docker was not only
blocked at frontend `npm ci`; the history shows runtime API requests and
backend health checks. The hard backend blocker is asyncpg receiving the
unsupported psycopg-style `sslmode` query parameter. Local Docker async
DATABASE_URL must not use `?sslmode=disable`; external SSL-required URLs
must be normalised before create_async_engine.


## 2026-05-18 temporary memory — v168_48

User provided the next Docker log from v168_47.  The previous
asyncpg sslmode repair exposed a second local Docker blocker: Alembic
/ psycopg2 tried to use SSL against local compose Postgres and failed
with `server does not support SSL, but SSL was required`.

Fix in v168_48: local Docker `PSYCOPG_URL` explicitly uses
`?sslmode=disable`, while `backend/migrations/env.py` no longer
auto-adds `sslmode=require` for ENV local/dev/ci/test or compose hosts
`db` and `postgres`.  Async `DATABASE_URL` remains without psycopg
sslmode.


## 2026-05-20 temporary memory — v168_50

User reported that FAQ disappeared and buttons in admin/app were not
working.  Repair boundary: keep Docker fixes from v168_48 and public UI
rollback from v168_49, restore FAQ entry points, add missing
`/admin/logs`, and replace unsafe Link-wrapped Button navigation with
Button `href` mode in critical surfaces.

Important distinction for future work: a route button can work while an
admin API action still fails because admin credentials/ENV are missing.
Do not classify protected API auth/config failures as route deletion.


## v168_51 — FAQ / tunnel / routes / admin correction

- FAQ must be a vertical section/subsection/question tree, not a pill or
  quick-button interface.
- Profile must keep a visible FAQ entry.
- Cloudflare quick tunnel failure is diagnosed separately from EFHC
  runtime: local frontend and Docker-to-host frontend may work while
  `POST https://api.trycloudflare.com/tunnel` fails externally.
- Admin root must move toward clear app-button launcher cards, not a
  mixed technical proof page.
- Route targets must be checked with `ops/local/check_frontend_routes.py`.

## 2026-05-20 temporary memory — v168_55

The user ordered creation of a controlled frontend shell system and then
asked to fill all frontend requirements from documents, dialogues and
Q/A.  The active rule is now: frontend cannot be repaired only by code.
The assistant must operate through `docs/frontend/` first.

Confirmed current visual decisions:

- FAQ must show the full section/subsection list immediately and stay
  compact on a smartphone.
- FAQ must remain a vertical tree and not category pills.
- Profile is `/web-profile`, not overlay.
- Wallet in Profile must use real wallet/history components.
- Browser-Shop payment states must be human-readable in all languages.
- Admin is still not acceptable as final product; the user rates it
  around 35 percent and expects a real Russian operator console with
  app tiles, graphs and understandable functions.
- `Песочница.xz` is a visual donor for layout, app-grid, cards,
  dashboard and graph principles, not for brand copying.
- Energy is the next recommended controlled visual pass.

## 2026-05-20 temporary memory — v168_56

The user asked why the transcript file disappeared and how AI documents
and tests allowed file deletion.  The accessible `v168_51` - `v168_55`
archives already lacked a standalone transcript.  The only physical
clue was an index row for `reports/chat_audit_2026-02-27.md`; that file
was missing.

Corrective rule: `docs/NORM/CHAT_TRANSCRIPT.md` is now mandatory.  Q/A
register is not enough.  A document-retention guard was added and must
be run for memory/control-layer cycles.


## v168_57 pending memory: lost transcript continuity

The user clarified that Q/A and transcript are separate files.  The
absence of a living transcript caused loss of continuity across about
20 previous chats.  Future cycles must update CHAT_TRANSCRIPT as the
chat-to-chat memory and may not replace it with Q/A register entries.

## Pending memory recovery — updated v168_59

The current chat is branch 21. Branches 20, 19, 18, 13 and 10 have been
restored as source files in `docs/NORM/CHAT_BRANCHES/`.

They must be used as historical sources for `CHAT_TRANSCRIPT.md`, not as
replacement documents. Later branches have priority over earlier ones.
Do not invent missing branches.


## v168_61 frontend page-description rule

Before asking the user frontend composition questions, read the page
source documents in `docs/audits/` and `docs/NORM/` that already describe
visible elements.  Do not repeat questions whose answers are already in
those documents.  If a source is missing, state the missing file name.
If the source exists, use it as the primary page description.


## v168_62 frontend page-source correction

For EFHC frontend work, recent visual audits are not the first source
for
page composition. The operator must first read the ancient page-
description
sources: `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`,
`docs/GENERAL/specification.md`, `docs/cycles/WORK_CYCLES_0-100.md`,
`docs/SSOT/ENERGY_RULES.md`, `docs/SSOT/PANELS_SSOT.md`,
`docs/SSOT/HUB_SSOT.md`, `docs/NORM/RANKS_RULES.md` and
`docs/NORM/REFERRALS_RULES.md`.

The operator must not ask the user about screen elements already
described
in those files or later direct chat answers. If an element is not found,
the absence must be stated exactly before asking.


## v168_64 frontend original-source recovery rule

- Original PDF sources are not permanent canon and must not be retained
  as living project sources.
- Keep only MD historical intent if needed for comparison.
- User answers to Q/A are the active canon.
- If original intent, current code and user answer conflict, ask user.
- Use `docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md` before any
  frontend restoration pass.

## 2026-05-20 — frontend function-canon recovery rule

Before changing a frontend page, read the recovered function canon and
old page sources. Do not replace a meaningful function with a simplified
visual substitute. Example: panel `age` is not enough; the user canon is
activation date, deactivation date and live countdown to deactivation.
If a question is unclear, explain it in simple Russian before asking
again. Do not ask technical robot-style questions.

## Chat-first communication rule

Архив — это рабочая память ИИ и контрольный слой проекта, но не канал
коммуникации с пользователем. Пользователь согласует решения только в
чате.

Если пользователю нужно объяснение, вопрос, уточнение, причина
регресса, смысл термина или вариант решения, ассистент обязан сначала
написать это в чате простым русским языком. Только после этого то же
решение можно занести в архив.

Запрещено:

- писать `объяснение записано в файл`, не дав объяснение в чате;
- считать запись в архиве пользовательским ответом;
- требовать от пользователя читать архив для понимания текущего решения;
- подменять диалог ссылкой на внутренний документ.

Разрешено:

- дублировать уже сказанное в чате в `CHAT_TRANSCRIPT.md`;
- переносить утверждённые ответы в Q/A register;
- фиксировать итог в AI/frontend/reports документах.
