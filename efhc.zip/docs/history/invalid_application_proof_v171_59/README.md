# Invalid application proof history

These scripts were removed from active `ops/frontend` because they render manual HTML with `page.set_content`. They may be studied as prototypes but cannot prove the EFHC application UI.
