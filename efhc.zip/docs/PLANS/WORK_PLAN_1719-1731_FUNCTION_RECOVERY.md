# ПЛАН 1719–1731 — ВОССТАНОВЛЕНИЕ, СОГЛАСОВАНИЕ И ОЧИСТКА ФУНКЦИОНАЛЬНОЙ ПОВЕРХНОСТИ

Статус: **ЗАВЕРШЁН ДО ЦИКЛА 1731 / HANDOFF PREPARED / NEXT EXACT-HEAD CI REQUIRED**.

Цель: последовательно разобрать все выявленные в циклах 1716–1718
функции, маршруты, compatibility surfaces и integration candidates,
восстановить действительно потерянное, подключить нужное и исключить
только доказанно лишнее после явного решения пользователя.

## 1. Правило нумерации

Пользователь запросил 10 исследовательских циклов в диапазоне 1719–1729.
Так как 1719–1729 включительно содержит 11 номеров, план фиксирует:

- `1719–1728` — десять волн исследования и согласования;
- `1729` — итоговая консолидация решений десяти волн;
- `1730` — exact-head CI/error qualification после изменений;
- `1731` — подготовка к последующим аудитам и frontend-работе.

## 2. Обязательный процесс каждой волны 1719–1728

Каждый цикл проходит четыре этапа и не закрывается до завершения
согласования:

1. **Evidence.** Прочитать только относящиеся к текущей группе current
   code, active SSOT/CANON, `v171.89` evidence, route/function catalog и
   свежий GitHub CI пользователя, если он предоставлен.
2. **Разбор в чате.** Для каждого элемента сообщить:
   - что это за route/function;
   - где он находится и какой у него текущий статус;
   - какую функцию приложения он обеспечивает;
   - почему он может быть нужен или почему выглядит избыточным;
   - является ли он `ACTIVE`, `RESTORED_SAFE_COMPAT`,
     `PRESERVE_NO_UI_CALLER`, `RECOVERY_CANDIDATE` или
     `REMOVAL_CANDIDATE_REQUIRES_PROOF`;
   - как именно предлагается его сохранить, восстановить, подключить,
     заменить или удалить.
3. **Вопросы пользователю.** Получить явное решение по спорным функциям.
   Отсутствие frontend caller, прямого Python caller или старое имя не
   является разрешением на удаление.
4. **Реализация.** Выполнить только утверждённое решение минимальным
   патчем. Затем один раз обновить cycle/report/current docs и создать
   один следующий HEAD ZIP. Локальные tests/builds/guards/CI не запускать.

## 3. Критерий удаления

Функция может перейти в удаление только если одновременно доказано, что
она не является route/public API, compatibility boundary, security/Admin
capability, external integration, scheduled/background entrypoint,
dynamic caller, documented contract или recovery mechanism, и
пользователь прямо согласовал удаление. Иначе статус — **СОХРАНИТЬ**.

## 4. Распределение десяти волн

### Цикл 1719 — Admin Observability и Reports

**Группа:** шесть подтверждённых Admin HTTP operations без найденного
прямого frontend caller:

- `GET /admin/observability/events`;
- `GET /admin/reports/bank`;
- `GET /admin/reports/deposits`;
- `GET /admin/reports/panels`;
- `GET /admin/reports/users`;
- `GET /admin/reports/withdrawals`.

**Задача:** сопоставить backend handlers, current `admin/diagnostics.tsx`
и `admin/reports.tsx`, operational/recovery use и документацию. Определить,
должны ли routes оставаться API-only или быть подключены к Admin UI.

**Варианты реализации:** сохранить API-only; добавить UI-секции поверх
существующих страниц; объединить только при доказанной семантической
эквивалентности; удаление рассматривать только после полного delete-proof.

**Вопрос пользователю:** какие отчёты и event stream должны быть доступны
непосредственно из Admin Panel, а какие сознательно остаются служебным API?

### Результат цикла 1719 — СОГЛАСОВАНО И РЕАЛИЗОВАНО

Решение пользователя:

- `/admin/observability/events` отклонён как дублирующий; сохранён compatibility stub с обязательным объяснением причины и replacement `/admin/logs/transfers`;
- `/admin/reports/users`, `/bank`, `/panels`, `/withdrawals`, `/deposits` признаны нужными и полностью подключены к Admin Reports dashboards;
- users-report переведён на `global_id`; BANK-report приведён к `BANK_EFHC + EFHC_MAIN`;
- существующий real-timeseries observability dashboard подключён к `/admin/reports`;
- следующий исследовательский цикл — 1720.

### Цикл 1720 — Admin Tasks CRUD и task maintenance

**Группа:**

- `POST /admin/tasks/`;
- `GET /admin/tasks/{task_id}`;
- `PATCH /admin/tasks/{task_id}`;
- `DELETE /admin/tasks/{task_id}`;
- historical `crud/admin/admin_tasks_crud.py`;
- historical `scheduler/jobs/job_tasks_maintenance.py` как evidence старой
  task-maintenance поверхности.

**Задача:** установить, какие операции уже доступны через current
`admin/tasks.tsx`, какие остались API-only, а какие historical symbols были
placeholder/replaced. Проверить CRUD, moderation и refresh-status workflow
как одну продуктовую цепочку.

**Варианты реализации:** подключить недостающие CRUD controls к current
Admin Tasks; сохранить API-only для automation; восстановить facade только
если current service не предоставляет эквивалент; не возвращать старый
`tg_id` ownership.

**Вопрос пользователю:** нужна ли полная ручная CRUD-редактура задач из
Admin Panel или часть операций должна оставаться только backend API?

### Результат цикла 1720 — СОГЛАСОВАНО И РЕАЛИЗОВАНО

Решение пользователя:

- создан полный многофункциональный Admin Tasks Editor: create/detail/edit/deactivate/safe-delete;
- canonical DTO расширен до `code/title/description/type/active/bonus/price/limits/proof/meta`; `performed_count` read-only;
- изменение `code` после появления task history и физическое удаление при любой истории блокируются fail-closed;
- submissions/moderation сохранены и остаются основой Tasks; банковская выплата не переносилась из canonical transactions contour;
- `/admin/tasks/refresh-statuses` сохранён как compatibility boundary, но UI исправлен на фактическую семантику обслуживания `task_complete_lock`;
- отдельная `/admin/ads` уже существует, поэтому провайдеры не дублируются в Tasks Editor; Ads Admin показывает registry/config readiness `builtin_timer` и `adsgram` без раскрытия секретов;
- historical `admin_tasks_crud.py` признан неверно названным re-export чужих Admin utilities и распределён по циклам 1721/1723/1724/1726 вместо rollback;
- historical `job_tasks_maintenance.py` функции не содержал; реальный task maintenance — `tasks_autorestart.run_once`, а временная проверка TON-транзакций — отдельный активный `check_ton_inbox/job_ton_watcher`; дубль не подтверждён;
- следующий исследовательский цикл — 1721.

### Цикл 1721 — Admin Shop, order status и Shopfront profile — ВЫПОЛНЕНО

**Решение пользователя:** функции Shop 1–8 объединены в единый многофункциональный Shop Management.

**Реализованный scope:**

- единый Admin Shop Editor -> canonical Shop service -> цены, методы оплаты, status, history;
- внешняя `/browser-shop` как полноценная HTML-витрина с signed handoff и `/shopfront/profile`;
- EFHC packages, NFT/external-link карточки и расширяемые новые card types;
- глобальный `/admin/shop/orders/status-counters`;
- восстановленный `admin_force_fulfill_order` только по `global_id`;
- order detail и user orders включены в общий Shop operator flow;
- delete guard исправлен по реальному SKU/order history;
- history карточки сохраняется;
- `set-price` оставлен compatibility API без отдельного дублирующего редактора.

**Следующее исследование:** цикл 1722 — Referral ranking и referral integration.

### Цикл 1722 — Referral ranking и referral integration

**Группа:**

- `GET /ranks/referrals/my-plus-top/me`;
- `GET /ranks/referrals/top/me`;
- handlers `get_my_referrals_rank_me`, `get_referrals_top_me`;
- current `frontend/src/pages/ranks.tsx`;
- current referral services/statistics как источник данных;
- historical frontend recovery documentation о referral ranking.

**Задача:** установить, является ли отсутствие referral ranking mode в
current UI потерянной функцией. Сопоставить его с kWh ranking и referral
page, не смешивая разные ranking semantics.

**Варианты реализации:** восстановить отдельный tab/mode в Ranks; вынести
на Referrals; оставить backend-only; удалить route только при явном отказе
и доказательстве отсутствия external contract.

**Вопрос пользователю:** нужен ли отдельный рейтинг по рефералам в UI и
где он должен находиться — Ranks или Referrals?

### Итог цикла 1722 — FRONTEND MERGE ВЫПОЛНЕН

Первоначально группа была отложена до frontend merge. Позднее в том же цикле пользователь предоставил отдельный patch + ТЗ и прямо поручил продолжить перенос. Итоговое решение supersedes промежуточный `DEFERRED_TO_FRONTEND_MERGE`.

- рабочие `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` перенесены минимальным patch поверх актуального HEAD;
- backend referral/ranking routes и formulas не менялись;
- `/ranks` использует `RankMode = kwh | referrals`, отдельные query keys и существующие `/ranks/referrals/*`;
- `/referrals` использует только real backend stats/list/link/bonus asset;
- Lvl 1–5 берутся только из backend `level_steps`;
- share targets: Telegram, WhatsApp, Viber, Facebook, X;
- offline/demo/mock/sandbox не перенесены;
- `global_id` остаётся внутренним owner/key и не выводится как публичное имя;
- active canon: `docs/frontend/REFERRALS_RANKS_FRONTEND_CANON.md`.

Следующий исследовательский цикл: **1723 — Admin financial/status utilities**.

### Цикл 1723 — Admin financial/status utilities

**Группа historical recovery candidates:**

- `efhc_transfers_recent_total`;
- `get_admin_bank_config`;
- `shop_order_status_counters` — закрыт в Shop Management: восстановлен и больше не относится к нерешённой группе;
- `withdraw_status_counters`;
- current `AdminService.get_bank_balance` и
  `AdminService.manual_bank_user_transfer` как replacement evidence;
- current Admin statistics/report services как возможные replacements.

**Задача:** определить, какие historical read/status utilities несут
уникальную operational ценность и какие полностью заменены current
services/routes. Никаких старых `tg_id` selectors не возвращать.

**Варианты реализации:** global-id/system-entity read-only facade;
использование current stats service; документированное `REPLACED`; removal
только после явного решения пользователя.

**Вопрос пользователю:** какие финансовые/статусные показатели должны быть
отдельными Admin diagnostics, а какие достаточно получать из текущих
Reports/Bank страниц?

### Итог цикла 1723 — СОГЛАСОВАНО И РЕАЛИЗОВАНО

Решение пользователя:

- `efhc_transfers_recent_total` не возвращается; его полезная семантика встроена в `/admin/reports/bank` как bank-side credit/debit/total event counters;
- `get_admin_bank_config` не возвращается; вместо него реализован canonical Bank Policy в существующем Bank Report;
- `/admin/reports/withdrawals` расширен DB-wide `TOTAL/PENDING/PAID/REJECTED/CANCELED`, а `/admin/withdrawals` использует глобальные counters;
- `shop_order_status_counters` остаётся закрытым решением Shop Management;
- старые `tg_id` selectors и legacy facades не возвращались.

Следующее исследование: цикл 1724 — TON inbox, deposit operations и recovery controls.

### Цикл 1724 — TON inbox, deposit operations и recovery controls

**Группа:**

- `list_ton_inbox`;
- `set_ton_log_status_guarded`;
- `ton_inbox_status_counters`;
- `POST /admin/ton/reconcile`;
- `POST /admin/efhc-deposits/process`;
- `POST /admin/efhc-deposits/reprocess/{tx_hash}`;
- `GET /admin/efhc-deposits/runtime-summary`.

**Задача:** сопоставить historical TON inbox operations с current watcher,
reconciliation и deposit Admin page. Особое внимание — безопасности ручной
смены статуса: mutation не должна обходить settlement/reversal canon.

**Варианты реализации:** read-only inbox/counters; guarded recovery action
через canonical reconciliation; оставить current routes как достаточную
замену; не восстанавливать прямую небезопасную status mutation.

**Вопрос пользователю:** нужен ли в Admin Panel отдельный TON inbox с
ручными recovery-действиями или достаточно существующего reconciliation/
deposit workflow?


### Итог цикла 1724 — СОГЛАСОВАНО И РЕАЛИЗОВАНО

Решение пользователя:

- создать полноценный TON Inbox внутри существующего `/admin/efhc-deposits`, без отдельной дублирующей Admin-страницы;
- весь видимый Admin-интерфейс формулировать человеческим языком и понятными действиями, без внутренних runtime/watcher/replay/exception/status терминов как языка UI;
- сохранить безопасную повторную обработку реальной сохранённой операции;
- не восстанавливать произвольную ручную смену финансового статуса;
- сохранить free-form manual process только как отдельно обозначенную аварийную возможность;
- исправить reconciliation: передавать limit, не имитировать отсутствующую cursor-pagination, показывать фактический результат;
- `pending_manual` считать финальным состоянием, требующим решения администратора, и исключить из автоматических retry;
- распространить human-language правило на уже пройденные Reports, Bank, Withdrawals, Tasks, Ads и Shop.

Реализация цикла защищена каноном `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.

Следующее исследование: цикл 1725 — Admin NFT, VIP и manual claim.

### Цикл 1725 — Admin NFT, VIP и manual claim

**Группа:**

- historical `submit_manual_vip_nft_claim(tg_id, ...)`;
- `refresh_vip_status_due_batch`;
- `refresh_vip_status_for_due_users`;
- `check_vip_nft_due_batch`;
- `_admin_nft_id_for_asset`;
- `_filter_admin_nft_assets`;
- `_sync_admin_nft_wallet_state`;
- `resolve_admin_nft`;
- `require_admin_or_nft_or_key` и `TON_ADMIN_NFT_IDS` authority chain.

**Задача:** отделить Admin NFT credential от VIP NFT business status и
решить, нужен ли manual claim/recheck workflow. Historical `tg_id` claim
не может быть возвращён как есть.

**Варианты реализации:** новый `global_id`/verified-wallet Admin operation;
только автоматический NFT checker; оставить maintenance facades как stable
compatibility surface; исключить старый claim как `REPLACED_BY_CANON`.

**Вопрос пользователю:** нужен ли администратору ручной NFT/VIP recheck или
claim, и если нужен — какие действия он должен разрешать?

**Решение и реализация 1725:**

- ручной VIP override отклонён; Admin использует фактическую NFT-проверку одного пользователя или всех пользователей;
- historical `submit_manual_vip_nft_claim(tg_id, ...)` окончательно классифицирован `REPLACED_BY_CANON / DO_NOT_RESTORE`;
- оплаченный Shop NFT order является единственной заявкой на выдачу; создан полноценный Admin workflow ожидание → выдано/отклонено с причиной и аудитом;
- Admin NFT credential chain `TON_ADMIN_NFT_IDS` сохранена независимо от обычного VIP;
- maintenance compatibility facades сохранены и делегируют единому NFT service;
- active canon: `docs/admin/ADMIN_VIP_NFT_MANAGEMENT_CANON.md`.

Следующее исследование: цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.

### Цикл 1726 — Bonus Awards, Withdraw и Admin manual credits — ВЫПОЛНЕНО

**Решение пользователя и результат:**

- единственный write-контур ручных операций: `Admin UI -> /admin/transfer -> BankService.manual_bank_user_transfer -> transactions_service -> BANK_EFHC <-> USER(global_id)`;
- `credit_bonus_efhc`, `credit_regular_efhc`, `adjust_user_balance_via_bank` сохранены как compatibility facades и делегируют тому же BankService;
- создан раздел «Бонусы и начисления» на активных `task_bonus_log`, `referral_bonus_ledger` и банковском ledger; dead `bonus_awards` не возвращён;
- ручное начисление EFHCb использует существующий `/admin/transfer`, новый money-write route не создан;
- Bonus отделён от Withdraw: EFHCb не выводится, Withdraw только EFHCm;
- `admin_mark_withdraw_paid` закреплён как `REPLACED_BY_CANON` с сохранённым compatibility entrypoint;
- Users/Bonus/Withdraw Admin UI приведён к утверждённому человеческому языку; расширен `ADMIN_HUMAN_LANGUAGE_CANON.md`;
- active canon: `docs/admin/ADMIN_BONUSES_AND_MANUAL_CREDITS_CANON.md`.

Следующее исследование: цикл 1727 — Wallets, payment intents, watcher и reconciliation.

### Цикл 1727 — Wallets, payment intents, watcher и reconciliation — ВЫПОЛНЕНО

**Решение пользователя и результат:**

- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical confirmation point;
- Wallet/Payment/Watcher/Reconciliation boundaries — string global_id, BIGINT только на явной DB-boundary;
- G/GID memo/payload — string global_id; TG — только provider/historical subject;
- wallet/watcher compatibility aliases сохранены, новый код не должен их использовать как бизнес-центр;
- payment flow переведён на `payment.flow.*` keys и 13 frontend локализаций;
- active canon: `docs/payments/WALLET_PAYMENT_RECONCILIATION_CANON.md`.

Следующее исследование: цикл 1728 — общие runtime compatibility surfaces.

### Цикл 1728 — Общие runtime compatibility surfaces — ВЫПОЛНЕНО

**Решение пользователя и результат:**

- `create_app`, `get_engine`, `get_session_factory`, `d8` и
  `order_models.ShopOrder` закреплены как бессрочные import/startup/ORM
  compatibility facades; отсутствие caller не является delete-proof;
- `app.bot.states` закреплён как официальный стабильный public FSM facade;
- `admin__main__handlers`, `TickContext`, `SchedulerError`, `JobTimeout`,
  `scheduler_core.tick`, `tasks_maintenance.run_once` сохраняются бессрочно как
  compatibility-only surfaces и не являются новым CANON для разработки;
- `RBAC.is_superadmin` закреплён как стабильный boolean helper только после
  канонического разрешения Admin identity/RBAC; auth bypass запрещён;
- рядом с каждым тупиковым/compatibility местом оставлены подробные русские
  комментарии-послания будущим аудитам с причиной сохранения;
- создан `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`; правило проекта:
  `no caller != delete proof`, удаление только по отдельному решению пользователя
  после полного delete-proof и последующего exact-head GitHub CI.

Следующий цикл: `1729 — консолидация десяти решений`.

## 5. Цикл 1729 — консолидация десяти решений — ВЫПОЛНЕНО

- создана единая decision matrix `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`;
- все десять волн 1719–1728 классифицированы как `KEEP / CONNECT_UI / RESTORE_FACADE / REPLACE / REMOVE_APPROVED`;
- выполнен отдельный alias audit: удалены только 7 private transitional SQL aliases с полным delete-proof;
- ENV/provider/wire/history aliases и явно сохранённые compatibility facades оставлены;
- function manifest и active SSOT/CANON синхронизированы с кандидатом `v173.54 / cycle 1729`;
- локальные tests/builds/guards/CI не запускались;
- следующий цикл: `1730 — exact-head qualification и error burn-down`.

## 6. Цикл 1730 — exact-head qualification и error burn-down — PATCH ВЫПОЛНЕН

- Получен GitHub CI `85145865998` на payload, идентифицированный как `v173.54` по совпадающему размеру `12046473` bytes и внутренним v173.54-specific artifacts; SHA-256 CI payload в логах отсутствует.
- FAILED: Mypy `4`; pytest `3 failed / 1499 passed / 22 skipped / 1 warning`. Остальные canonical gates из summary имеют exit `0`, включая frontend build.
- Исправлены только подтверждённые причины: четыре typed DB-boundary return, два stale traceability hygiene expectations и current manifest drift.
- Новых feature/cleanup решений не добавлено; compatibility/alias/identity/economy semantics не менялись.
- Новый кандидат: `v173.55`; локальные tests/builds/guards/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- При наличии новых failures следующий run продолжает burn-down 1730; к циклу 1731 переходить только после отсутствия новых подтверждённых CI-проблем.

## 7. Цикл 1731 — backend/frontend audit + итоговый handoff — ЗАВЕРШЁН

- Входной `v173.56` квалифицирован supplied GitHub CI `85157912581`: все canonical gates `exit=0`, pytest `1502 passed / 22 skipped / 1 warning`.
- Final static decision matrix подтверждает exact protected floor: `135 paths / 140 operations / 38 frontend pages / 312 symbols / 58 modules / 68 files`, missing `0`.
- Current OpenAPI/Admin/page inventory синхронизирован в `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; stale OpenAPI manifest counts исправлены до `135/140/154 schemas`.
- Referrals/Ranks и Browser Shop подтверждены как current UI-connected surfaces. Compatibility surfaces цикла 1728 и решения consolidation 1729 сохраняются; отсутствие caller не используется как delete-proof.
- Frontend generated Admin seams: 66 constants; 54 имеют прямое именованное использование, 12 вынесены только в review backlog без удаления/восстановления второй реализации.
- Подтверждённый identity carry-over: static AST inventory `375` direct `int(...)` calls с `global_id`-содержащим аргументом в `60` production-файлах. Нужна отдельная per-boundary классификация; broad rewrite в 1731 запрещён и не выполнялся.
- Подтверждённый Admin UX carry-over: видимые technical labels в Panels/Tasks/Referrals и нескольких Admin runtime dashboards расходятся с `ADMIN_HUMAN_LANGUAGE_CANON`; нужна отдельная humanization/localization волна без изменения API semantics.
- Итоговый handoff записан в `CONTINUE_IN_NEW_CHAT.md` и current section `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Runtime/backend/frontend production code не менялся; destructive cleanup не выполнялся.
- Кандидат `v173.57` требует следующего exact-head CI. Следующий cycle number не назначается автоматически.

## 8. Итоговая цель диапазона

К концу 1731 проект должен иметь документированную и согласованную
functional surface, где каждая спорная функция имеет доказательный статус,
потерянные функции восстановлены только в canonical форме, лишние функции
удалены только после явного решения и delete-proof, а frontend backlog
основан на фактическом backend API, а не на предположениях.
