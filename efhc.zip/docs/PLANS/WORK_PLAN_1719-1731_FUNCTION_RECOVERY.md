# ПЛАН 1719–1731 — ВОССТАНОВЛЕНИЕ, СОГЛАСОВАНИЕ И ОЧИСТКА ФУНКЦИОНАЛЬНОЙ ПОВЕРХНОСТИ

Статус: **ACTIVE PLAN**.

Цель: последовательно разобрать все выявленные в циклах 1716–1718
функции, маршруты, compatibility surfaces и integration candidates,
восстановить действительно потерянное, подключить нужное и исключить
только доказанно лишнее после явного решения пользователя.

## 1. Правило нумерации

Пользователь запросил 10 исследовательских циклов в диапазоне 1719–1729.
Так как 1719–1729 включительно содержит 11 номеров, план фиксирует:

- `1719–1728` — десять волн исследования и согласования;
- `1729` — итоговая консолидация решений десяти волн;
- `1730` — exact-head CI/error qualification после изменений;
- `1731` — подготовка к последующим аудитам и frontend-работе.

## 2. Обязательный процесс каждой волны 1719–1728

Каждый цикл проходит четыре этапа и не закрывается до завершения
согласования:

1. **Evidence.** Прочитать только относящиеся к текущей группе current
   code, active SSOT/CANON, `v171.89` evidence, route/function catalog и
   свежий GitHub CI пользователя, если он предоставлен.
2. **Разбор в чате.** Для каждого элемента сообщить:
   - что это за route/function;
   - где он находится и какой у него текущий статус;
   - какую функцию приложения он обеспечивает;
   - почему он может быть нужен или почему выглядит избыточным;
   - является ли он `ACTIVE`, `RESTORED_SAFE_COMPAT`,
     `PRESERVE_NO_UI_CALLER`, `RECOVERY_CANDIDATE` или
     `REMOVAL_CANDIDATE_REQUIRES_PROOF`;
   - как именно предлагается его сохранить, восстановить, подключить,
     заменить или удалить.
3. **Вопросы пользователю.** Получить явное решение по спорным функциям.
   Отсутствие frontend caller, прямого Python caller или старое имя не
   является разрешением на удаление.
4. **Реализация.** Выполнить только утверждённое решение минимальным
   патчем. Затем один раз обновить cycle/report/current docs и создать
   один следующий HEAD ZIP. Локальные tests/builds/guards/CI не запускать.

## 3. Критерий удаления

Функция может перейти в удаление только если одновременно доказано, что
она не является route/public API, compatibility boundary, security/Admin
capability, external integration, scheduled/background entrypoint,
dynamic caller, documented contract или recovery mechanism, и
пользователь прямо согласовал удаление. Иначе статус — **СОХРАНИТЬ**.

## 4. Распределение десяти волн

### Цикл 1719 — Admin Observability и Reports

**Группа:** шесть подтверждённых Admin HTTP operations без найденного
прямого frontend caller:

- `GET /admin/observability/events`;
- `GET /admin/reports/bank`;
- `GET /admin/reports/deposits`;
- `GET /admin/reports/panels`;
- `GET /admin/reports/users`;
- `GET /admin/reports/withdrawals`.

**Задача:** сопоставить backend handlers, current `admin/diagnostics.tsx`
и `admin/reports.tsx`, operational/recovery use и документацию. Определить,
должны ли routes оставаться API-only или быть подключены к Admin UI.

**Варианты реализации:** сохранить API-only; добавить UI-секции поверх
существующих страниц; объединить только при доказанной семантической
эквивалентности; удаление рассматривать только после полного delete-proof.

**Вопрос пользователю:** какие отчёты и event stream должны быть доступны
непосредственно из Admin Panel, а какие сознательно остаются служебным API?

### Цикл 1720 — Admin Tasks CRUD и task maintenance

**Группа:**

- `POST /admin/tasks/`;
- `GET /admin/tasks/{task_id}`;
- `PATCH /admin/tasks/{task_id}`;
- `DELETE /admin/tasks/{task_id}`;
- historical `crud/admin/admin_tasks_crud.py`;
- historical `scheduler/jobs/job_tasks_maintenance.py` как evidence старой
  task-maintenance поверхности.

**Задача:** установить, какие операции уже доступны через current
`admin/tasks.tsx`, какие остались API-only, а какие historical symbols были
placeholder/replaced. Проверить CRUD, moderation и refresh-status workflow
как одну продуктовую цепочку.

**Варианты реализации:** подключить недостающие CRUD controls к current
Admin Tasks; сохранить API-only для automation; восстановить facade только
если current service не предоставляет эквивалент; не возвращать старый
`tg_id` ownership.

**Вопрос пользователю:** нужна ли полная ручная CRUD-редактура задач из
Admin Panel или часть операций должна оставаться только backend API?

### Цикл 1721 — Admin Shop, order status и Shopfront profile

**Группа:**

- `POST /admin/shop/items/set-price`;
- `GET /shopfront/profile`;
- historical `shop_order_status_counters`;
- current Admin Shop item/order API как replacement evidence;
- current `/admin/shop/order/{order_id}` и
  `/admin/shop/orders/user/{global_id}` как canonical global-id routes.

**Задача:** понять, нужен ли отдельный set-price UI, является ли
`shopfront/profile` реальной frontend dependency или резервным contract,
и потеряна ли самостоятельная ценность status counters.

**Варианты реализации:** подключить controls/profile; оставить API-only;
восстановить global-id facade для counters; удалить только доказанный
дубликат после согласования.

**Вопрос пользователю:** должны ли price editing и shopfront profile быть
видимыми пользовательскими/Admin функциями или сохраняться как внутренние
API contracts?

### Цикл 1722 — Referral ranking и referral integration

**Группа:**

- `GET /ranks/referrals/my-plus-top/me`;
- `GET /ranks/referrals/top/me`;
- handlers `get_my_referrals_rank_me`, `get_referrals_top_me`;
- current `frontend/src/pages/ranks.tsx`;
- current referral services/statistics как источник данных;
- historical frontend recovery documentation о referral ranking.

**Задача:** установить, является ли отсутствие referral ranking mode в
current UI потерянной функцией. Сопоставить его с kWh ranking и referral
page, не смешивая разные ranking semantics.

**Варианты реализации:** восстановить отдельный tab/mode в Ranks; вынести
на Referrals; оставить backend-only; удалить route только при явном отказе
и доказательстве отсутствия external contract.

**Вопрос пользователю:** нужен ли отдельный рейтинг по рефералам в UI и
где он должен находиться — Ranks или Referrals?

### Цикл 1723 — Admin financial/status utilities

**Группа historical recovery candidates:**

- `efhc_transfers_recent_total`;
- `get_admin_bank_config`;
- `shop_order_status_counters` — окончательная оценка после 1721;
- `withdraw_status_counters`;
- current `AdminService.get_bank_balance` и
  `AdminService.manual_bank_user_transfer` как replacement evidence;
- current Admin statistics/report services как возможные replacements.

**Задача:** определить, какие historical read/status utilities несут
уникальную operational ценность и какие полностью заменены current
services/routes. Никаких старых `tg_id` selectors не возвращать.

**Варианты реализации:** global-id/system-entity read-only facade;
использование current stats service; документированное `REPLACED`; removal
только после явного решения пользователя.

**Вопрос пользователю:** какие финансовые/статусные показатели должны быть
отдельными Admin diagnostics, а какие достаточно получать из текущих
Reports/Bank страниц?

### Цикл 1724 — TON inbox, deposit operations и recovery controls

**Группа:**

- `list_ton_inbox`;
- `set_ton_log_status_guarded`;
- `ton_inbox_status_counters`;
- `POST /admin/ton/reconcile`;
- `POST /admin/efhc-deposits/process`;
- `POST /admin/efhc-deposits/reprocess/{tx_hash}`;
- `GET /admin/efhc-deposits/runtime-summary`.

**Задача:** сопоставить historical TON inbox operations с current watcher,
reconciliation и deposit Admin page. Особое внимание — безопасности ручной
смены статуса: mutation не должна обходить settlement/reversal canon.

**Варианты реализации:** read-only inbox/counters; guarded recovery action
через canonical reconciliation; оставить current routes как достаточную
замену; не восстанавливать прямую небезопасную status mutation.

**Вопрос пользователю:** нужен ли в Admin Panel отдельный TON inbox с
ручными recovery-действиями или достаточно существующего reconciliation/
deposit workflow?

### Цикл 1725 — Admin NFT, VIP и manual claim

**Группа:**

- historical `submit_manual_vip_nft_claim(tg_id, ...)`;
- `refresh_vip_status_due_batch`;
- `refresh_vip_status_for_due_users`;
- `check_vip_nft_due_batch`;
- `_admin_nft_id_for_asset`;
- `_filter_admin_nft_assets`;
- `_sync_admin_nft_wallet_state`;
- `resolve_admin_nft`;
- `require_admin_or_nft_or_key` и `TON_ADMIN_NFT_IDS` authority chain.

**Задача:** отделить Admin NFT credential от VIP NFT business status и
решить, нужен ли manual claim/recheck workflow. Historical `tg_id` claim
не может быть возвращён как есть.

**Варианты реализации:** новый `global_id`/verified-wallet Admin operation;
только автоматический NFT checker; оставить maintenance facades как stable
compatibility surface; исключить старый claim как `REPLACED_BY_CANON`.

**Вопрос пользователю:** нужен ли администратору ручной NFT/VIP recheck или
claim, и если нужен — какие действия он должен разрешать?

### Цикл 1726 — Bonus Awards, Withdraw и Admin manual credits

**Группа:**

- `AdminService.credit_bonus_efhc`;
- `AdminService.credit_regular_efhc`;
- `AdminUsersService.credit_bonus_efhc`;
- `AdminUsersService.credit_regular_efhc`;
- `AdminService.list_bonus_payouts`;
- `WithdrawalsService.list_bonus_awards`;
- `WithdrawalsService.process_bonus_award`;
- `WithdrawalsService.reject_bonus_award`.

**Задача:** определить, какие восстановленные service/facade functions
являются permanent Admin contract, а какие нужны только compatibility.
Отдельно решить, нужен ли Bonus Awards UI: historical отдельная page/route
не была подтверждена.

**Варианты реализации:** оставить service-only; добавить отдельную секцию
в Admin Withdraw/Users; выделить новый canonical Admin route только после
утверждения; не возвращать dead legacy table semantics.

**Вопрос пользователю:** нужен ли самостоятельный интерфейс Bonus Awards и
ручного BONUS/MAIN начисления, или эти capabilities должны оставаться
служебными механизмами администратора?

### Цикл 1727 — Wallets, payment intents, watcher и reconciliation

**Группа:**

- `wallets_service.credit_user_from_bank`;
- `wallets_service._confirm_payment_intent`;
- `wallets_service.STATUS_CREDITED`;
- `wallets_service.STATUS_ERROR_SYS`;
- watcher bank-credit injection seam;
- shared `confirm_payment_intent` reconciliation surface;
- shop-external/deposit confirmation chain как contract evidence.

**Задача:** решить, какие восстановленные compatibility aliases должны
оставаться permanent stable imports, какие можно документировать как
internal delegation, и какие callers должны перейти на shared
reconciliation service.

**Варианты реализации:** сохранить aliases навсегда; объявить controlled
compatibility boundary; выполнить caller migration только по доказанному
списку и лишь после согласования; удалить alias только после отдельного
qualification cycle.

**Вопрос пользователю:** предпочитается долгосрочная обратная совместимость
wallet/payment imports или окончательный единый reconciliation API после
доказанной миграции всех callers?

### Цикл 1728 — Общие runtime compatibility surfaces

**Группа:**

- `backend/app/init.py::create_app`;
- `backend/app/database.py::get_engine`, `get_session_factory`;
- `backend/app/core/decimal_utils.py::d8`;
- `backend/app/models/order_models.py::ShopOrder`;
- FSM public API в `backend/app/bot/states.py`;
- Admin bot main facade `handler`, `router`, `kb_admin_entry`,
  `ADMIN_HUB_LABEL`;
- scheduler `TickContext`, `SchedulerError`, `JobTimeout`, `tick`;
- maintenance `run_once`;
- `RBAC.is_superadmin`.

**Задача:** для каждой family установить реальные current callers,
external/import compatibility и recovery value. Эти surfaces были
восстановлены после cleanup; повторное удаление по признаку «не вижу
caller» запрещено.

**Варианты реализации:** закрепить permanent compatibility contract;
свести к thin facade; пометить `REPLACED` с migration path; удаление —
только после доказательства отсутствия всех защищённых способов вызова и
явного решения пользователя.

**Вопрос пользователю:** какие из этих compatibility families должны стать
официальным стабильным API проекта, а какие допускается постепенно вывести
после полной caller migration?

## 5. Цикл 1729 — консолидация десяти решений

После завершения 1719–1728:

- собрать единую decision matrix `KEEP / CONNECT_UI / RESTORE_FACADE /
  REPLACE / REMOVE_APPROVED`;
- убедиться, что для каждого `REMOVE_APPROVED` выполнен полный delete-proof;
- завершить только уже утверждённые остаточные изменения;
- синхронизировать function manifest, active SSOT/CANON и route map;
- не запускать новый cleanup по собственной инициативе;
- сформировать один HEAD для следующего GitHub CI.

## 6. Цикл 1730 — exact-head qualification и error burn-down

- принять GitHub CI пользователя на HEAD после 1729;
- исправить только подтверждённые failures;
- не добавлять новые функциональные решения;
- не запускать локальные tests/builds/guards/CI;
- зафиксировать qualification status или следующий exact-head patch.

## 7. Цикл 1731 — подготовка к frontend и новым аудитам

- зафиксировать окончательную backend function/route decision matrix;
- сформировать frontend integration backlog по утверждённым routes;
- актуализировать описание страниц против утверждённой backend surface;
- выделить оставшиеся audit questions без их самовольной реализации;
- подготовить handoff для следующей frontend/audit фазы;
- destructive cleanup в этом цикле запрещён без нового прямого ТЗ.

## 8. Итоговая цель диапазона

К концу 1731 проект должен иметь документированную и согласованную
functional surface, где каждая спорная функция имеет доказательный статус,
потерянные функции восстановлены только в canonical форме, лишние функции
удалены только после явного решения и delete-proof, а frontend backlog
основан на фактическом backend API, а не на предположениях.
