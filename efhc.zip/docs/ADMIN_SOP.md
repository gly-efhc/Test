# EFHC production operator quick guide

Status: active release v171.69 operator entry.

## Deployment or update

Use `README.md` in the release root and
`docs/RUNBOOKS/DEPLOYMENT_ROLLBACK.md`.

## Payment not reconciled

1. Do not manually credit from frontend evidence alone.
2. Compare the internal operation identity with public on-chain evidence.
3. Review watcher and reconciliation status.
4. Use an approved Admin rescue action only after evidence is complete.
5. Record operator, timestamp, reason and transaction hash.

## Withdrawal

1. Open the protected Admin withdrawals route.
2. Confirm recipient, asset, amount and operation identity.
3. Sign through the configured `WalletProvider` flow.
4. Do not mark paid before backend confirmation and reconciliation.

## Incident

Freeze affected money automation when settlement truth is ambiguous.
Keep unrelated services available only when financial invariants remain
safe. Use the rollback and restore runbooks; never expose secrets in
incident notes.
