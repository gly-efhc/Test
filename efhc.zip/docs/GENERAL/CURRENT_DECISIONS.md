<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- Owner Q/A lock 2026-08-16: каждый owner-facing вопрос сначала записывается `PENDING` в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; после ответа исходный вопрос сохраняется и дополняется точным ответом. Пропущенный реестр обязан быть восстановлен по exact evidence; ответы не придумываются.
- Единый тестовый контур: только GitHub CI, запускаемый пользователем. Ассистент не запускает локальные tests/guards/lint/type/build/Alembic/CI checks; исправляет только подтверждённые failures из предоставленных логов.
- Архивный workflow: один цикл создаёт только один новый `EFHC_Bot_vNNN_NN.zip`, который является Development HEAD и источником следующего цикла. RELEASE/MATRIX/sidecar/auxiliary archives автоматически не создаются.
- Emergency override: циклы `1706–1710` используются только для латания подтверждённых критических регрессов; прежний план `1706–1709` сдвинут на `1711–1714`.
- BANK canon перенесён в `docs/SSOT/BANK_CANON.md`: `BANK_EFHC` — standalone `system_entity`, не пользователь; у bank ledger row `global_id=NULL`, `tg_id=NULL`.
- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Numbered chat transcripts находятся в `docs/chats/`; остальные исторические artifacts не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.
- Frontend разрабатывается отдельно; после квалификации текущей backend/identity migration перенос утверждённого release frontend в основной EFHC оформляется отдельным будущим решением. Это не цикл 1708 и сейчас не является утверждённым планом.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.

- Numeric `BANK_EFHC` ENV удалён из active config/release preflight/ops. Центральный банк идентифицируется только `system_entity=BANK_EFHC`; bank ledger row не имеет `global_id`/`tg_id`.
- Admin access имеет два независимых источника: обычный Admin list = active `admin_whitelist.global_id` + explicit RBAC role; Admin NFT = точный адрес NFT-item из `TON_ADMIN_NFT_IDS` внутри `TON_NFT_COLLECTION`, обнаруженный штатным NFT/VIP checker. `admin_nft_whitelist` — только derived cache; `ton_wallet_id` не становится owner. Канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Admin cleanup lock: запрещено удалять Admin route/service/handler/contract только по признаку `no callers` или compatibility-label без сравнения с последним exact-green functional composition. Cycle 1714 recovery anchor: v173.36; Admin HTTP routes 63/63 сохранены; Bonus Awards block восстановлен после ошибочного удаления в 1713.


## Cycle 1716 — function-preservation lock

- `contracts/application_function_surface_v1.json` is the fail-closed registered application surface.
- `tests/architecture/test_application_function_surface_manifest.py` is CI-only control against accidental removal; assistant does not run it locally.
- No-caller/no-frontend evidence never implies permission to delete public/Admin/operational/compatibility surface.
- Historical `v171.89` may be used as evidence, but tg_id-owned/migration-era implementation is not restored over active `global_id` CANON.
