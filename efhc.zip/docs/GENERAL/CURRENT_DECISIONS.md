## ТЕКУЩЕЕ OWNER-РЕШЕНИЕ — v174.96 / цикл 1836

1. Энергетическая серия уровней (исторически `19-7…19-18`) и реферальная серия (исторически `19-19…19-24`) возвращены в **защищённый канон**.
2. После reindex цикла `1835` текущие позиции этих серий — `19-6…19-17` и `19-18…19-23`; защита относится к смысловым сериям и сохраняется при последующих позиционных сдвигах.
3. Запрещено удалять, объединять, сжимать или заменять эти 18 Q&A ради освобождения слотов. Разрешено улучшать только описания, не уничтожая уровни, порядок, пороги и смысл прогрессии.
4. Любая разрешённая правка описаний выполняется параллельно во всех `16` FAQ SSOT/runtime языках.
5. Новые Q&A `N1–N38` OWNER пока не утверждены; не добавлять.
6. Предыдущее предложение использовать уровневые серии для освобождения слотов признано ошибочным и отменено.

---

## ТЕКУЩЕЕ OWNER-РЕШЕНИЕ — цикл 1836

1. Канон application localization: `16/16`.
2. Канон FAQ runtime и FAQ SSOT: `16/16`, ровно `20` разделов, максимум `250` Q&A, одинаковая per-section структура всех языков; фактически после цикла `1835` — `206` Q&A.
3. Утверждённая волна дублей применена во всех языках; новые Q&A `N1–N38` OWNER пока не утвердил и они не добавляются.
4. Исторические серии `19-7…19-18` и `19-19…19-24` являются защищённым каноном уровней прогресса. После текущего переиндексирования это `19-6…19-17` и `19-18…19-23`. Все 12 Energy levels и 6 Referral levels должны сохраняться как отдельные уровни.
5. Эти 18 Q&A запрещено удалять, объединять, считать смысловыми дублями или использовать как свободные слоты. Разрешено только улучшать описание с сохранением уровня, progression order и действующих thresholds/rewards.
6. Предыдущее предложение снять защиту с уровневых серий отменено прямым решением OWNER. Authority: `docs/SSOT/faq_ssot/RU_FAQ_LEVEL_SERIES_CANON.md`.
7. Cycle `1836`: exact-head CI repair + фиксация protected-canon статуса; FAQ Q&A text не меняется.

---

# ТЕКУЩЕЕ РЕШЕНИЕ OWNER — v174.89 / цикл 1829

## ТЕКУЩЕЕ OWNER-ИСПОЛНЕНИЕ — cycle 1830 / Korean FAQ corrective

- Канон `16/16` приложения, FAQ runtime и FAQ SSOT не изменяется: `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
- Cycle `1830` выполняет только corrective-quality reconciliation Korean FAQ поверх уже физически полного `16/16`.
- Любая корректировка FAQ выполняется одновременно в SSOT и checked-in runtime; SSOT остаётся duplicate-control и не получает права автоматически переписывать runtime.
- В этом цикле подтверждены и исправлены только `8` Korean формулировок; unrelated Russian/Japanese FAQ не переписываются.
- Следующий cycle `1831` продолжает quality/corrective reconciliation Japanese FAQ только по подтверждённым findings.


## ТЕКУЩЕЕ OWNER-РЕШЕНИЕ — cycle 1829 / канон 16 языков приложения и FAQ

1. Канон приложения: ровно `16` runtime-языков — `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
2. Канон FAQ приложения и `docs/SSOT/faq_ssot`: тот же полный набор `16/16`; каждый язык физически содержит ровно `20` разделов и максимум `250` Q&A; после цикла `1835` фактически `206` Q&A.
3. Для всех поддерживаемых языков FAQ checked-in runtime catalog обязателен. Нормальный fallback вместо отсутствующего `ko`/`ja` запрещён; `faqCatalogByLang` является полным `Record<Lang, FaqCatalog>`.
4. Application locale keyset/placeholders/registries должны охватывать все `16` языков; неполный language list в active guard/test считается Anti-Stale.
5. Unfinished-marker `TODO/FIXME/TBD` контролируется только в shipping code. Документы и локализованный FAQ не являются кодовым scope; обычное Portuguese слово `todo` разрешено.
6. FAQ runtime и SSOT изменяются параллельно с duplicate-control; SSOT не получает права автоматически переписывать checked-in runtime.
7. Исторические документы и immutable reports могут содержать фактические старые counts `13/14`; они не переопределяют текущий канон `16/16`.


## Сведения: исторический snapshot cycle 1828

- Cycle `1828` завершает утверждённый Portuguese FAQ block `1827–1828` semantic/corrective pass.
- FAQ приложения и SSOT FAQ изменяются параллельно; Portuguese checked-in runtime и SSOT duplicate-control representations должны совпадать.
- Подтверждённый exact-head CI `89741881397` defect относится к Portuguese text/unfinished-marker interaction; строгий placeholder/TODO guard не ослабляется.
- Portuguese FAQ остаётся `20` разделов / `250` Q&A; checked-in FAQ catalogs остаются `14`, runtime locales `16`, controlled fallback FAQ — `ko/ja`.
- Устаревший RU FAQ item о `13` языках не переписывается в Portuguese-only cycle и переносится кандидатом в Russian FAQ revision cycle `1833`.
- Следующий блок: cycles `1829–1830` — Korean FAQ `ko` с параллельным SSOT/runtime контролем.
- Human linguistic certification не заявляется без отдельного evidence/approval.

# ТЕКУЩИЕ РЕШЕНИЯ — cycle 1823 / Portuguese localization + CI language-policy repair

- CI `89650944656` доказан exact-head для `v174.82`: все gates GREEN, кроме pytest `1 failed / 1778 passed / 22 skipped / 1 warning`; единственная подтверждённая причина — document-language policy.
- Cycle 1823 завершает Portuguese `pt` на player-facing runtime surfaces; semantic source остаётся verified Russian canon. FAQ `pt` в этом цикле не создаётся и продолжает controlled fallback до cycles 1827–1828.
- OWNER-план runtime: 1824=`ko`, 1825=`ja`, 1826=глобальная сверка всех runtime language keys. OWNER-план FAQ: 1827–1828=`pt`, 1829–1830=`ko`, 1831–1832=`ja`; 1833–1837=FAQ revision/new Q&A/OWNER review повторов.
- Повторяющиеся FAQ items не удалять и не заменять автоматически: сначала составить список кандидатов и получить прямое решение OWNER.
- Новые исправления и Portuguese coverage квалифицируются следующим exact-head GitHub CI; локальные full suites/build не запускать.

---

# Сведения: CURRENT IMPLEMENTATION STATUS — cycle 1821

Новых OWNER business decisions не вводилось. Cycle 1821 исправляет только дефекты exact-head CI `89612278523` на `v174.80`; OWNER contracts cycles 1818–1820 сохраняются без изменения.

- Shop external reconciliation остаётся PaymentIntent/ShopOrder/root-transaction authority; misplaced Shop block возвращён из `deposit_efhc` в `shop_external`.
- Verified primary wallet requirement не ослаблен; PostgreSQL transaction fixture обновлён под уже действующий security precondition.
- Runtime locales = 16; checked-in FAQ catalogs = 13; controlled fallback для отсутствующих FAQ catalogs сохраняется.
- Production automatic Shop prices по-прежнему запрещены; Custom EFHCm остаётся integer `>=1` с Admin D2 rate за 1 EFHCm.
- Fresh exact-head CI обязателен для v174.81.

---

# Сведения: CURRENT IMPLEMENTATION STATUS — cycle 1820

Новых OWNER business decisions не вводилось. Cycle 1820 реализует direct answers `QA-2026-08-27-FRONTEND248-01…10`: backend-authoritative Custom pricing, one operational VIP product, atomic selected-number reservation, paid ShopOrder-only history и external TON/USDT reconciliation. Production automatic prices остаются запрещены.

# Сведения: CURRENT DECISIONS — cycle 1819 / frontend product-surface implementation

Новых OWNER business decisions в cycle 1819 не вводилось. Реализация следует direct answers `QA-2026-08-27-FRONTEND248-01…10`: Browser Shop/Profile/Orders/Hub/Admin product surfaces переносится только как frontend slice; production automatic prices удалены; Custom остаётся runtime integer `>=1 EFHCm` с D2 rate per `1 EFHCm`; customer VIP consolidated; paid Orders отделены от PaymentIntent; external TON/USDT и selected-number payment остаются fail-closed. Five backend Shop donor files не изменяются до cycle 1820.

> Historical decisions ниже retained as evidence и не переопределяют этот block.

# Сведения: CURRENT DECISIONS — cycle 1818 / direct OWNER answers for FRONTEND_v248 integration

- Сведения: `EFHC_PACKAGE_CUSTOM / Обмен EFHCm` restored as an intentional runtime product capability: integer quantity `>=1 EFHCm`; `custom_efhc_amount_d8` carries quantity.
- Сведения: Custom external `price_ton` / `price_usdt` are D2 rates per `1 EFHCm`; backend is responsible for exact `rate × quantity`. Fixed package prices remain full-package prices.
- Сведения: No production automatic/default Shop prices. Price missing from Admin means that payment method is unavailable; `0.00` remains visible but purchase-disabled.
- Сведения: Canonical fixed denominations are exactly `10, 50, 100, 150, 200, 250, 300, 350, 500, 750, 1000, 1500, 2000, 2500, 3000 EFHCm`, plus Custom.
- Сведения: One operational customer-facing VIP product supports `TON / USDT / EFHC`; legacy payment-specific VIP SKU are read/history compatibility only.
- Сведения: Selected VIP number payment is forbidden until atomic backend reservation exists; ordinary Admin-assigned VIP flow is separate.
- Сведения: `My orders` = paid `ShopOrder` only; pre-payment `PaymentIntent` history is separate.
- Сведения: Production external TON/USDT checkout remains fail-closed until the complete server-side reconciliation chain is integrated and proven.
- Сведения: Primary wallet security authority is canonical primary TON address. If `wallet_app` transport metadata is unresolved, generic chooser is permitted only with exact address match.
- Сведения: Five backend Shop files from patch are deferred to cycle 1820; cycles 1818–1819 transfer frontend only.
- Сведения: OWNER-supplied `SHOP_v249.html` is demo/reference material. A clean non-executable presentation reference is stored separately and is not production runtime authority.

> Сведения: Historical decisions below are retained as evidence and do not override this block.

# ТЕКУЩИЙ STATUS — cycle 1817 / FRONTEND_v248 patch audit

- Direct OWNER scope: cycle `1817` выполняет анализ patch; cycles `1818–1820` предназначены для поэтапного внедрения/переноса patch в main.
- Fresh GitHub CI `88320337434` доказан exact-head для `v174.76` и полностью GREEN `12/12`; `v174.76` становится новым fully qualified GREEN anchor.
- Patch `EFHC_MAIN_PATCH_v174_76_from_FRONTEND_v248_CYCLE_0091.zip` exact-base соответствует `v174.76`; manifest payload `95 + 1 deletion` проверен по SHA/size.
- Cycle 1817 не переносит functional patch bytes: подтверждены прямые frontend↔financial CANON conflicts (`CUSTOM_EFHC` runtime rate, automatic/default Shop pricing, withdrawal recovery regression), поэтому действует mandatory OWNER escalation.
- Зарегистрированы `10` PENDING questions `QA-2026-08-27-FRONTEND248-01…10`; уже утверждённые D2/zero-price/Bank snapshot/FAQ/withdrawal rules не переспрашиваются.
- План cycles `1818–1820`: foundation/wallet/release integrity → product surfaces → financial-sensitive reconciliation/authority closure.

> Historical blocks ниже являются evidence и не переопределяют active OWNER CANON.

# ТЕКУЩИЙ STATUS — cycle 1816 / exact-head CI `88318025922` qualification repair

Новых OWNER decisions по economics, security, schema, frontend, financial precision или document-language CANON не вводилось. CI `88318025922` доказан exact-head для `v174.75` и дал `11/12 GREEN`; единственный RED — pytest current-state parity guard из-за stale `IDENTITY_MIGRATION_STATE_CURRENT=v174.74/1814` при `TEST_GUARD_MANIFEST=v174.75/1815`. Сам guard соответствует active Test Authority и сохраняется без ослабления; repair ограничен current/release metadata. Pre-package hygiene отдельно удаляет унаследованный `.pytest_cache` по existing `HEAL-0063 / CASE-0063`; это release hygiene, не production defect. Последний fully GREEN exact-head остаётся `v174.74` / CI `88312667980`; `v174.76` требует fresh exact-head CI.

> Historical blocks ниже являются evidence и не переопределяют active OWNER CANON.

# ТЕКУЩИЙ STATUS — cycle 1814 / exact-head CI repair

Новых OWNER decisions по economics, security, schema, frontend или document-language CANON не вводилось. CI `88307377458` проверил exact `v174.73` и подтвердил единственный RED-контур pytest с тремя integration/governance defects. Repair обязан сохранять active CANON и не менять runtime ради stale metadata. Последний fully GREEN exact-head остаётся `v174.69` / CI `88066448299`.

> Historical blocks ниже являются evidence и не переопределяют active OWNER CANON.

# ТЕКУЩИЙ OWNER DECISION — cycle 1813 / document language boundary

Маркер: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`.

OWNER установил: в `documents`, `reports`, `cycles` и `chat` описательная часть
обязана быть на русском, но `technical terms` и `concepts` должны сохраняться
на English. Эта policy не применяется к `source code`. Разрешена технически
обоснованная English normalization code, но document language не может быть
самостоятельной причиной code changes.

# ТЕКУЩИЕ РЕШЕНИЯ — 2026-08-22 / цикл 1812 / область языковой политики

- OWNER DECISION: команда о русском языке относится только к документам, отчётам и чату.
- Язык программного кода этой командой не регулируется. Нельзя менять identifiers, test names, docstring, comments, API/SQL/protocol/machine literals только ради прохождения русскоязычного guard.
- Existing code с русскими, английскими или смешанными identifiers не переименовывается без отдельной функциональной/технической причины.
- Current document-language guard проверяет документы/человекочитаемые reports и не сканирует source code.
- UI/i18n и технические code-style conventions остаются отдельными нормами и не выводятся из требования русскоязычных отчётов.

> Исторические блоки ниже являются evidence и не переопределяют этот OWNER DECISION.

# ТЕКУЩИЕ РЕШЕНИЯ — 2026-08-22 / цикл 1811 / CI repair + mini-audit

- `FRONTEND_v195` остаётся текущей owner-controlled frontend authority. Документ `FRONTEND_MAIN_SYNC_AUDIT_v196.md` является evidence для reconciliation, но без physical FRONTEND_v196 archive/patch не повышает main authority до v196.
- OWNER withdrawal rule: normal path `wallet send → payout-evidence → automatic mark-paid`. Кнопка `Оплачено` сохраняется как recovery: при persisted wallet evidence повторяет wallet-confirmed `mark-paid`, а без evidence открывает manual paid flow с обязательной причиной.
- Ручная фиксация `Оплачено` существует именно для случаев, когда фактическая оплата произошла, но подтверждение/ответ кошелька не было надёжно зафиксировано.
- Mini-audit подтвердил программную нормализацию frontend identity error object: machine keys только `field/code/message`; русские пользовательские тексты не затрагиваются.
- Consolidated Admin UX FRONTEND_v195 сохраняется: `Логи` являются compatibility alias к `Отчёты и журналы`, `sale-packages` — compatibility route внутри Shop; stale launcher expectations не возвращаются.
- Panel protective и withdrawal routes проверяются через generated seam constants, а не через устаревшие literal-path implementation assertions.
- Внешние EFHC deposit/withdraw и Browser Shop — D2 business boundary; native decimals не расширяют business precision.
- При новом подтверждённом frontend↔financial/security конфликте по-прежнему требуется прямое OWNER clarification.
- Backend/schema/frozen migration не меняются в текущем repair.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩИЕ РЕШЕНИЯ — 2026-08-22 / цикл 1810 / FRONTEND_v195

- `FRONTEND_v195` принят как новая owner-controlled visual/UX frontend authority; его более сильные изменения имеют приоритет над `FRONTEND_v182`, кроме случаев отдельного прямого OWNER решения.
- OWNER final clarification: дополнительный refresh `efhc_core.bank_metrics_snapshot` при открытии Admin-модулей сохраняется. Общий `AdminPage` вызывает `/admin/reports/overview`; на Admin index, Bank, Panels и Reports собственный overview исключает двойной refresh через `refreshBankSnapshot={false}`.
- Shop `0.00` остаётся видимым, но purchase disabled; Admin external Shop price строго D2 без silent rounding.
- OWNER clarification: внешний EFHC deposit, внешний EFHC withdrawal и внешний Browser Shop используют D2 как business boundary. TON D9 / USDT D6 являются только native atomic transport/execution representation уже утверждённой внешней суммы и не разрешают >D2 business precision.
- Bank export selector остаётся `100/1000/100000/1000000/Все`; выполнение — backend server-side.
- FAQ остаётся самостоятельным checked-in production runtime authority; FAQ SSOT — duplicate/control verification only.
- PaymentIntent: OWNER дал FRONTEND_v195 patch приоритет. Проверенный конфликт с backend native-atomic settlement не подтвердился: donor frontend transport принят; authoritative settlement/reconciliation по native atomic остаётся backend responsibility.
- Русифицированные TypeScript program identifiers/types/machine literals нормализуются на canonical English tokens; русский пользовательский UI сохраняется.
- Historical frontend tests следуют Anti-Stale Contract и не могут откатывать current owner authority ради старой implementation shape.
- OWNER conflict rule: при любом подтверждённом конфликте frontend patch с active financial/security CANON оператор обязан запросить прямое решение владельца и не выбирает сторону самостоятельно.
- Backend/schema не изменяются этой frontend интеграцией.

## CURRENT — v174.69 / цикл 1809 / exact-head GREEN + Test Authority evidence

- Новых OWNER economic/security/schema/frontend решений не вводилось.
- CI `88039356151` exact-head для `v174.68` полностью GREEN; `v174.68` становится последним fully GREEN anchor.
- Проверено, что dedicated ApplicationClock regression source был добавлен в `v174.65` и содержит `5` тестов, включая `3` динамических wall-clock jump tests.
- Подтверждённого test gap нет; Test Authority не допускает добавление дублирующего теста только ради увеличения mutable count.
- `v174.69` требует fresh exact-head GitHub CI.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## CURRENT — v174.68 / цикл 1808 / qualification metadata repair

- Новых OWNER economic/security/schema/frontend решений не вводилось.
- CI `88034310249` exact-head для `v174.67` подтвердил единственный qualification RED: stale numbered work-pass prose в machine frontend authority manifest.
- Test Authority требует исправить metadata, а не ослаблять hygiene guard.
- FRONTEND_v182 runtime/source-lock и все higher CANON сохраняются без изменений.
- `v174.68` требует fresh exact-head GitHub CI.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## CURRENT — v174.67 / цикл 1807 / ApplicationClock financial-row timestamps

- Новых экономических, schema, frontend или security OWNER правил не вводилось.
- CI `87928232215` доказал exact `v174.66` полностью GREEN и квалифицировал repairs цикла 1806.
- OWNER scope цикла 1807: direct wall-clock timestamps финансовых CRUD rows, участвующих в age/retry/ledger semantics, используют `app.lib.time.utcnow()`.
- `financial_retention_service.py`, пороги `180/370/400`, delete policy и transaction ownership не менять.
- Presentation/audit timestamps не переводятся механически без подтверждённого elapsed-time смысла.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## CURRENT — v174.66 / цикл 1806 / CI qualification repair

Новых экономических, финансовых, schema, frontend или security OWNER решений в цикле 1806 не вводилось. CI `87917878179` исправляется строго по подтверждённым diagnostics: import order, typed-return boundaries и stale current-state metadata. Active OWNER/CANON/NORM остаются без изменения.

## CURRENT — v174.65 / цикл 1805 / единый business-time источник

- Прямое OWNER задание: elapsed/access/financial/scheduler code, которому важно прошедшее время, использует `backend/app/lib/time.py::utcnow()`; direct Python wall-clock в таких paths является обходом.
- Чистые physical/audit/presentation timestamps не являются автоматической целью механической замены; решение определяется semantics, а не grep-only формой.
- Financial retention thresholds `180/370/400` и deletion algorithm не изменять: только source of `now`.
- Локальные qualification suites запрещены; новый candidate проверяется следующим exact-head GitHub CI.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

## CURRENT — v174.64 / цикл 1804 / полный CANON формул Admin → Банк

- **OWNER DECISION:** существующий `docs/NORM/BANK_METRICS_INTEGER_SNAPSHOT.md` актуализировать и закрепить как полный формульный CANON/NORM, без параллельного второго authority.
- **OWNER DECISION:** документ охватывает всю математику страницы Admin → Банк, а не только 11 строк Балансовой карты.
- **Проверенный runtime факт:** `efhc_core.bank_metrics_snapshot` materializes server-side Bank math; `fixed_obligations` остаётся signed формулой `fixed_generated - fixed_population × 100` без clamp к нулю.
- **Проверенный runtime факт:** `_pct_d8` при denominator `0` materializes `0.00000000%`; browser division/fallback отсутствует.
- **OWNER DECISION:** текущий FRONTEND_v182 для этого контура менять не требуется.
- Production backend/frontend/test/schema formulas не меняются; последний exact-head GREEN остаётся `v174.62` / CI `87895142054`.

## CURRENT — v174.63 / цикл 1803 / exact-head GREEN evidence closure

- Новых business/financial/security OWNER DECISION в этом цикле нет.
- CI `87895142054` доказал exact `v174.62` GREEN по SHA-256 `f681f232ec4f8de8cf8ccd93ab371aeec2146bfc6137d09adc0dee9112d093b4`; checkout `339ff292ee97b8656ed10c62f9c653beabcb68f3`.
- Подтверждённых defect/root cause нет, поэтому production runtime и tests не изменяются.
- Последний exact-head GREEN теперь `v174.62`; текущий `v174.63` — только evidence/governance/release metadata candidate до следующего exact-head CI.

## CURRENT — v174.62 / цикл 1802 / CI qualification repair

- Latest direct owner contracts не изменены; protective Panel authority: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`.
- CI `87886177473` repair не меняет бизнес-экономику; production runtime исправляется только по подтверждённым source defects, stale tests следуют Test Authority.
- Active NORM filenames стабильны и не содержат release/event suffix.
- FRONTEND_v182 confirmed bugfixes разрешены напрямую; новый UX/functionality этим циклом не вводится.

## CURRENT — v174.61 / PANEL-PROTECT

- Latest direct owner contract: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`.
- Manual Admin protective deactivation only: dead marker, aggregate U/R/NET, no debt, no negative balances, no per-Panel exchange attribution.
- Dead is invisible to ordinary lists/aggregates but visible to exact Admin lookup/audit/export; same Panel ID can be paid-reactivated for 100 EFHC.
- FRONTEND_v182 remains visual authority subject to these later direct decisions; next frontend patch must consume reconciliation handoff.

## Текущие решения 2026-08-20 / циклы 1798–1800 — FRONTEND_v182 + Bank snapshot

- CI `87706114541` проверил exact `v174.58` SHA-256 `93f80c6a3fdd95952f7d9bc5dc977d4d42db3c50d560309d5c8a68edd820ee73`, checkout `29be709f31bff90898826c07994373deeda436a8`; все recorded gates GREEN кроме одного stale pytest raw-error implementation guard.
- Owner-supplied `EFHC_Bot_v174_59.zip` принят как donor/sample FRONTEND_v182 и Bank snapshot integration, а не как безусловный replacement current CANON. FRONTEND_v182 — текущая owner-controlled frontend authority.
- Selective merge rule: подтверждённые v182 frontend изменения принимаются, но donor не может откатить более высокий Shop D2/zero-price, atomic PaymentIntent, withdrawal `payout-evidence → mark-paid`, FAQ checked-in authority или другие active financial/security contracts.
- Tests/guards, противоречащие FRONTEND_v182 только по старой implementation shape, синхронизируются в той же итерации; реальные invariant tests сохраняются.
- Прямое owner decision разрешает новую singleton table `efhc_core.bank_metrics_snapshot`; table surface становится `53 ORM / 54 physical including alembic_version`. `0002+` не создаётся; supplied `URGENT_BANK_METRICS_SNAPSHOT.sql` предназначен для existing DB.
- Snapshot service transaction-neutral: скрытый service commit запрещён; commit/rollback принадлежит application boundary.
- Admin Panels Q&A `ADM-M09-01…19` имеют приоритет для v182 Panels behavior. Protective deactivation backend не симулируется: frontend остаётся fail-closed до отдельного atomic backend contract.

## Текущие решения 2026-08-20 / цикл 1797 — Admin Panels owner Q&A registry sync

- В active append-only Q&A register перенесены `QA-2026-08-20-ADM-M09-01…19` из `ADMIN_PANELS_OWNER_QA_v170.md`.
- Источник относится к owner-controlled redesign `Admin → Панели`; поздние QA-11/13/18 имеют приоритет над ранними пересекающимися формулировками.
- Регистрация решений не является самостоятельным разрешением на backend/main implementation; source boundaries сохраняются.
- Текущий integrated frontend source этой docs-only итерацией не изменяется.

## Текущие решения 2026-08-20 / цикл 1797 — CI 87591506394 + FRONTEND_v168 test sync

- Exact CI `87591506394` проверил `v174.56` SHA-256 `411b1c34e5fb05ac54004f589ec1bde453f79c31f93e2c5fe1e89082eac2aa9f`, checkout `22bb7d02d48a4aaaab4b7df3cf43646a8aec7630`.
- Реальные frontend defects из CI исправляются сразу; новые functional/visual changes по-прежнему требуют owner spec/patch.
- Tests/guards, которые противоречат утверждённому `FRONTEND_v168` только по старой implementation shape, синхронизируются с current contract в той же итерации.
- Финансовая граница не меняется: внешние EFHC deposit/withdraw/Shop = D2 boundary; внутренние EFHC operations = D8; `0.00` оставляет товар видимым, но purchase disabled.

## Текущие решения 2026-08-20 / цикл 1796 — D2/D8, Shop, FRONTEND_v168 и Test Authority

- **OWNER DECISION — financial boundary:** D2 применяется только к внешним операциям: внешний ввод EFHC, внешний вывод EFHC и внешний Shop. Все внутренние операции EFHC выполняются в D8.
- **OWNER DECISION — Shop topology:** внутреннего магазина не существует и существовать не может. Shop — отдельная открываемая HTML-страница для покупок, связанная с backend и Admin Panel.
- **OWNER DECISION — zero price:** `0.00` является допустимым состоянием товара; товар остаётся доступным, но кнопка/действие покупки деактивировано. `0.00` не является бесплатной покупкой.
- **OWNER DECISION — manual recovery:** новую функцию не добавлять. Ручной Admin contour уже реализован через модуль `Пользователи`; точечный D2/emergency scope не должен создавать дублирующий recovery UI/API.
- **OWNER DECISION — frontend:** `FRONTEND_v168` контролируется владельцем. Если задача требует frontend-изменения, оператор сначала выдаёт владельцу ТЗ и предлагаемый код; фактическое frontend-изменение должно прийти следующим owner patch, иначе оно будет перезаписано.
- **OWNER DECISION — tests:** устаревший test можно удалить, но только при высокой уверенности после сверки с актуальными CANON/NORM/SSOT и owner decisions; при неопределённости test сохраняется и вопрос выносится владельцу.
- Active provenance: `QA-2026-08-20-FIN3-14`, `QA-2026-08-20-FIN3-15`, `QA-2026-08-20-FIN3-16`, `QA-2026-08-20-FRONTEND-01`, `QA-2026-08-20-TESTAUTH-02`.

## Текущие решения 2026-08-19 / цикл 1795 — Test Authority / Anti-Stale Contract

- **OWNER DECISION:** тест не является SSOT. Authority: последнее прямое решение владельца → active CANON/SSOT/NORM → production runtime invariant → test/guard.
- Если expectation устарел относительно более высокого authority, он обновляется или удаляется в той же итерации. Запрещено откатывать корректный production runtime только ради stale implementation test.
- P0 financial/security/idempotency/transaction invariants остаются fail-closed; anti-stale policy не является основанием их ослаблять.
- Exact mutable counts routes/operations/schemas/test functions не являются development lock. Для расширяемой поверхности используется set/parity или required-subset проверка.
- CI `87522913463` подтвердил один реальный compatibility regression и одновременно stale hardcoded Admin seam count; поэтому тесты классифицируются по invariant, а не по факту падения.
- Active NORM: `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87405882481` engineering-language qualification repair

- Exact `v174.49` подтверждён SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768` и checkout `b69ed98e13c7995343429df2975fe2e893ada297`; RED только pytest language-policy guard.
- Guard является действующим authority и не устарел: новые/изменяемые инженерные артефакты должны быть на русском. Baseline не повышается для active drift.
- Исправляются только `14` подтверждённых narrative-строк в `KERNEL.md` и `START_HERE.md`; runtime, test semantics и финансовые/Shop contracts не меняются.
- Candidate/handoff: `EFHC_Bot_v174_50.zip`; следующий verifier — fresh exact-head GitHub CI.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87386543243` qualification repair

- Direct owner scope: продолжить цикл `1793`, работать по exact HEAD/active Kernel/SSOT/CANON и исправить подтверждённые ошибки новых CI-логов без локальной project qualification.
- Run `87290901436` квалифицировал exact `v174.47` GREEN. Run `87386543243` проверил exact `v174.48`; RED только один brittle Shop documentation guard.
- Shop owner decision не меняется: ручные независимые `price_ton`/`price_usdt`, без oracle/FX. Test должен проверять этот invariant, а не конкретный падеж фразы.
- Candidate/handoff после repair: `EFHC_Bot_v174_49.zip`; frozen schema/FAQ/FRONTEND_v146 сохраняются.

## Текущие решения 2026-08-19 / цикл 1793 — ручные цены Shop TON/USDT

- **OWNER DECISION:** Shop не использует ценовой oracle/FX service. Администратор вручную определяет сумму TON и/или USDT для каждой карточки через `price_ton` / `price_usdt`.
- Старый special-case `CUSTOM_EFHC` с формулой `0.3 USDT = 1 EFHC` и блокировкой TON удалён из runtime. Все checkout SKU используют единый catalog-item pricing flow.
- Legacy `custom_efhc_amount_d8` допускается только как совместимый входной атрибут и игнорируется; он не может влиять на цену, intent или settlement.
- Intent фиксирует текущую ручную цену карточки на TTL. Изменение Admin Shop price влияет только на новые intent.
- Scope ограничен Shop pricing. Exchange, watcher, BANK/ledger, schema, FAQ и visual frontend authority не меняются.
- Candidate/handoff: `EFHC_Bot_v174_48.zip`; fresh exact-head GitHub CI обязателен.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87278222904` qualification repair

- **OWNER DECISION:** открыть/продолжить цикл `1793`, работать по exact HEAD/active Kernel/SSOT/CANON и исправить все подтверждённые ошибки supplied CI `87278222904` без локальной project qualification.
- Exact CI input: `v174.44` SHA-256 `54b882e871626e7190161c419e9c1f407c9b6a6080478465570ab08856354154`, checkout `001316adea12d34348a510da3cc8b401cbc6f199`; RED только Flake8 critical/Ruff/Mypy/pytest, frontend/PostgreSQL/Alembic GREEN.
- Deep remediation `v174.44` остаётся authority; stale test expectation не может вернуть старые DB-session/middleware/export lifecycle contracts.
- Frozen `0001`, FAQ standalone authority, FRONTEND_v146 и financial formulas данным qualification repair не меняются.
- Candidate/handoff после repair: `EFHC_Bot_v174_45.zip`; descriptive suffixes и owner-facing sidecars запрещены; fresh exact-head GitHub CI обязателен.

## Текущие решения 2026-08-19 / цикл 1792 — глубокое исправление backend

- Direct owner order: исправить все подтверждённые errors Deep Backend Remediation Specification для exact `v174.43`, дополнительно перепроверить аудит, не запускать local project qualification.
- Runtime ownership decision: root transaction только у application use-case owner; CRUD/composable services используют flush/savepoint, cancellation propagates, runtime/scheduler DB session = canonical `db_session()`.
- Financial QA decision: production runtime использует тот же canonical `split_bonus_then_main`, который тестируется; duplicate runtime implementation запрещена.
- Frozen schema, FAQ standalone authority и approved FRONTEND_v146 не меняются данным backend scope.
- Candidate/handoff после repair: `EFHC_Bot_v174_44.zip`; descriptive suffixes и owner-facing sidecars запрещены; exact-head GitHub CI обязателен.

# CURRENT DECISIONS — v174.43 / цикл 1792

- **OWNER DECISION:** открыть/продолжить цикл `1792` и исправить все подтверждённые ошибки GitHub CI `87220054352` по active Kernel/SSOT/CANON.
- Existing owner decisions remain unchanged: approved FRONTEND_v146 is visual/UX/text authority; FAQ is standalone checked-in release asset; schema-change governance lock remains active.
- CI tests are verification, not authority over correct current runtime; stale harness is updated when current source authority is confirmed.

# CURRENT DECISIONS — v174.42 / цикл 1791 corrective re-audit

- **OWNER DECISION:** выполнить полный confirmed scope ТЗ `EFHC_v174_41_REAUDIT_TECHNICAL_SPEC.md`, включая Phase A, B и C, не ограничиваясь только webhook.
- FAQ production assets остаются самостоятельными; FAQ SSOT только duplicate-control и не пишет runtime.
- Frozen `0001` и schema-change governance lock сохраняются; данный ТЗ прямо запрещает migration `0002+`/new table для webhook repair.
- Tests должны доказывать transaction boundary реальным helper/real PostgreSQL integration и не должны mock’ом скрывать ранний commit.
- Current candidate `v174.42` не GREEN до fresh exact-head GitHub CI.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

## Current 2026-08-18 / cycle 1791 / exact-head GREEN + full application audit

- Direct owner order: record supplied GREEN logs and audit the application across all functions. Cycle `1791` is the current audit scope.
- Exact `v174.40` is qualified GREEN by CI `87088984879`: SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`, all recorded gates exit `0`, pytest `1670 passed / 22 skipped / 1 warning`.
- Audit repairs may fix confirmed runtime/security/financial/ops/documentation defects, but the resulting `v174.41` does not inherit GREEN and requires a new exact-head CI.
- Existing owner locks remain: FRONTEND_v146 visual/UX/text authority; FAQ/locale/PWA standalone release assets; schema-change governance lock on unapproved DDL with normal CRUD allowed; canonical no-suffix archive filename.

## Current 2026-08-18 / cycle 1790 continuation / CI 87074955772

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87074955772`, and explain the database/table lock for mutual understanding.
- Exact CI `87074955772` tested `v174.39` SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872` / checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`; only pytest failed: `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Confirmed defect: two English docstrings in development-only FAQ duplicate-control verifier; minimal translation repair only.
- Clarification: current database lock is a schema-change governance lock, not a runtime table lock. Existing tables and CRUD are not blocked. Frozen `0001`/`0002+` policy remains active until an explicit owner decision authorizes global unlock or a specific schema change.
- FAQ standalone release-asset decision remains active; SSOT cannot overwrite runtime.
- Canonical candidate/handoff: `EFHC_Bot_v174_40.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1790

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87062684580`, make FAQ a standalone release asset, keep FAQ SSOT as duplicate control with no runtime influence, verify other pre-packaging dependencies, and do not run local full tests/build/CI.
- Exact CI `87062684580` tested `v174.38` SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75` / checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`; all other recorded gates GREEN.
- Owner superseding decision: checked-in production FAQ runtime is release authority. FAQ SSOT/generator may validate parity but may not write runtime. The earlier cycle-1789 recommendation is now APPROVED and superseded as an owner decision.
- Release application-asset contract: package builder verifies checked-in FAQ/locale/PWA/integrity assets and must not regenerate them during packaging. Packaging-only release metadata/checksum creation remains allowed.
- Schema policy is unchanged: frozen `0001`, `0002+` only by separate direct owner decision. The question «Разблокировал таблицы?» is answered by current authority: **нет, глобального unlock не было**.
- Canonical candidate/handoff after this cycle: `EFHC_Bot_v174_39.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1789 continuation

- Direct owner order: continue cycle `1789`, repair only confirmed failures from GitHub CI `86992003426`, audit FAQ release independence and current tables/migrations/routes/documents; do not run local full tests/build/CI.
- Exact CI `86992003426` tested `v174.37` SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d` / checkout `7384e8284dbde416086a13bd23de7136be585681`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Repairs are qualification-only; approved FRONTEND_v146 remains unchanged.
- Migration authority remains locked by active CANON/NORM: frozen `0001`, `0002+` only by direct owner decision. Current cycle contains no schema-change authorization.
- **RECOMMENDATION (not owner decision):** make checked-in FAQ runtime a standalone release asset and change packaging from generate+package to verify+package, while keeping SSOT/generator in development governance. Until direct approval, existing release scripts remain unchanged.
- Canonical candidate/handoff after this repair: `EFHC_Bot_v174_38.zip`; no descriptive suffixes and no extra owner-facing files.

- Direct owner order 2026-08-18 opens cycle `1789` for exact CI `86988434882` repair and FAQ/release-script verification.
- Test authority from cycle `1788` remains active: approved FRONTEND_v146 beats stale visual/text literals; real backend/security/financial invariants stay fail-closed.
- CI `86988434882` tested exact `v174.36` SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77` / checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`; all gates GREEN except pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Candidate `v174.37` contains qualification-only repair and requires next exact-head CI.
- Release architecture fact: frontend runtime/prebuild is SSOT-independent; production release packaging still generates FAQ from FAQ SSOT before staging under the existing approved design.
- Canonical next handoff: `EFHC_Bot_v174_37.zip`; descriptive archive suffixes/owner-facing sidecars remain forbidden.

- Owner decision 2026-08-18 / cycle `1788`: approved FRONTEND_v146 visual/UX/text/functions имеют приоритет над stale frontend tests. Если изменение patch корректно, stale expectation обновляется/удаляется; tests не должны блокировать разработку. Реальные backend/security/financial invariants сохраняются fail-closed.
- Owner decision 2026-08-18: при доказанном runtime defect и stale test разрешено исправлять оба; runtime — только при независимом evidence.
- Owner archive decision 2026-08-18: следующий handoff = `EFHC_Bot_v174_36.zip`; descriptive suffixes запрещены, owner-facing handoff содержит только основной archive.
- CI evidence `86966635485`: exact previous `v174.35` payload SHA-256 `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`, checkout `d878a1d4bb2e014ede2cf0c9d95ccd03f9b6f4a2`; core/backend/schema/frontend build GREEN, Ruff+pytest qualification RED. Candidate `v174.36` содержит repair и требует нового exact-head CI.

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- Owner Q/A recovery lock 2026-08-16: при подозрении на пропущенный реестр или прямом owner order нужно пройти **все доступные numbered `docs/chats/*.md`**, зарегистрировать доказуемые Q/A, а ответы без достаточного source context пометить unresolved/context-incomplete. Архивный transcript не заменяет Q/A register; согласование с владельцем происходит только в чате.

- Current owner scope: cycles `1786–1787` are explicitly opened; `1786` = Shop operator decomposition, `1787` = archive/Q&A/SSOT consolidation. After `1787`, no future functional cycle is automatically approved.

- Admin cycles 1785–1787 owner UX lock: одна непрерывная сетка ровно 20 плиток; grouping 4×5 отклонён; API Workbench остаётся видимым; плитки классифицируются ненавязчивым category-color accent; `/admin/panels` обязан иметь rich real-data analytics; Deposits при known Global ID даёт только переход `Открыть пользователя`; `ADMIN-P15` закрыт упрощённым Shop split: `Магазин` = каталог/общий обзор, отдельные плитки `Заказы` и `Выдача / VIP NFT` deep-link в существующие modes, одна резервная плитка остаётся свободной.

- Owner Q/A lock 2026-08-16: каждый owner-facing вопрос сначала записывается `PENDING` в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; после ответа исходный вопрос сохраняется и дополняется точным ответом. Пропущенный реестр обязан быть восстановлен по exact evidence; ответы не придумываются.
- Единый тестовый контур: только GitHub CI, запускаемый пользователем. Ассистент не запускает локальные tests/guards/lint/type/build/Alembic/CI checks; исправляет только подтверждённые failures из предоставленных логов.
- Архивный workflow: один цикл создаёт только один новый `EFHC_Bot_vNNN_NN.zip`, который является Development HEAD и источником следующего цикла. RELEASE/MATRIX/sidecar/auxiliary archives автоматически не создаются.
- Emergency override: циклы `1706–1710` используются только для латания подтверждённых критических регрессов; прежний план `1706–1709` сдвинут на `1711–1714`.
- BANK canon перенесён в `docs/SSOT/BANK_CANON.md`: `BANK_EFHC` — standalone `system_entity`, не пользователь; у bank ledger row `global_id=NULL`, `tg_id=NULL`.
- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Numbered chat transcripts находятся в `docs/chats/`; остальные исторические artifacts не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.
- Frontend разрабатывается отдельно; после квалификации текущей backend/identity migration перенос утверждённого release frontend в основной EFHC оформляется отдельным будущим решением. Это не цикл 1708 и сейчас не является утверждённым планом.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.

- Numeric `BANK_EFHC` ENV удалён из active config/release preflight/ops. Центральный банк идентифицируется только `system_entity=BANK_EFHC`; bank ledger row не имеет `global_id`/`tg_id`.
- Admin access имеет два независимых источника: обычный Admin list = active `admin_whitelist.global_id` + explicit RBAC role; Admin NFT = точный адрес NFT-item из `TON_ADMIN_NFT_IDS` внутри `TON_NFT_COLLECTION`, обнаруженный штатным NFT/VIP checker. `admin_nft_whitelist` — только derived cache; `ton_wallet_id` не становится owner. Канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Admin cleanup lock: запрещено удалять Admin route/service/handler/contract только по признаку `no callers` или compatibility-label без сравнения с последним exact-green functional composition. Cycle 1714 recovery anchor: v173.36; Admin HTTP routes 63/63 сохранены; Bonus Awards block восстановлен после ошибочного удаления в 1713.


## Cycle 1716 — function-preservation lock

- `contracts/application_function_surface_v1.json` is the fail-closed registered application surface.
- `tests/architecture/test_application_function_surface_manifest.py` is CI-only control against accidental removal; assistant does not run it locally.
- No-caller/no-frontend evidence never implies permission to delete public/Admin/operational/compatibility surface.
- Historical `v171.89` may be used as evidence, but tg_id-owned/migration-era implementation is not restored over active `global_id` CANON.

## 2026-08-19 / cycle 1794 — FINANCIAL TOPOLOGY LOCK

- TON/USDT = только внешние rails покупки EFHC.
- Internal money = EFHC (`EFHCm`, `EFHCb`, `BANK_EFHC`) через `efhc_transfers_log`.
- Withdrawal = только EFHC.
- D8 = EFHC/kWh; TON = nanotons; USDT = `10^6` units.
- External EFHC deposit/withdraw = D2 `ROUND_DOWN` → D8 storage.
- Shop `price_ton`/`price_usdt` задаются Admin независимо; `price <= 0` = unavailable.
- Business EFHC commission отсутствует; deposit network fee платит user, withdraw network fee платит project.
- NFT без confirmed payment не может перейти в `APPROVED`.
- Verified/completed ADS view финален независимо от reward; reward доводится idempotently.
- Oracle/FX/custom-rate pricing удалён и не восстанавливается без нового owner decision.
- Authority: `docs/SSOT/FINANCIAL_TOPOLOGY_SSOT.md` + Q/A `FIN3-01…12`.

## 2026-08-20 / cycle 1796 — Shop external D2 price lock

- OWNER DECISION `QA-2026-08-19-FIN3-13`: ручные `price_ton` / `price_usdt` независимы и имеют максимум D2.
- `>2` decimals отклоняются backend; silent rounding запрещён.
- Frontend блокирует ввод/submit >D2, но financial authority остаётся backend service boundary.
- После D2 validation Shop price один раз преобразуется в native atomic units: TON `10^9`, USDT `10^6`; PaymentIntent фиксирует exact atomic snapshot.
- `0.00` остаётся допустимой disabled-конфигурацией, но checkout/PaymentIntent недоступны.
- Internal EFHC, `quantity_efhc`, `efhc_amount_d8` и ledger остаются D8. Oracle/FX не восстанавливаются.

