## CURRENT — v174.62 / цикл 1802 / CI qualification repair

- Latest direct owner contracts не изменены; protective Panel authority: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`.
- CI `87886177473` repair не меняет бизнес-экономику; production runtime исправляется только по подтверждённым source defects, stale tests следуют Test Authority.
- Active NORM filenames стабильны и не содержат release/event suffix.
- FRONTEND_v182 confirmed bugfixes разрешены напрямую; новый UX/functionality этим циклом не вводится.

## CURRENT — v174.61 / PANEL-PROTECT

- Latest direct owner contract: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`.
- Manual Admin protective deactivation only: dead marker, aggregate U/R/NET, no debt, no negative balances, no per-Panel exchange attribution.
- Dead is invisible to ordinary lists/aggregates but visible to exact Admin lookup/audit/export; same Panel ID can be paid-reactivated for 100 EFHC.
- FRONTEND_v182 remains visual authority subject to these later direct decisions; next frontend patch must consume reconciliation handoff.

## Текущие решения 2026-08-20 / циклы 1798–1800 — FRONTEND_v182 + Bank snapshot

- CI `87706114541` проверил exact `v174.58` SHA-256 `93f80c6a3fdd95952f7d9bc5dc977d4d42db3c50d560309d5c8a68edd820ee73`, checkout `29be709f31bff90898826c07994373deeda436a8`; все recorded gates GREEN кроме одного stale pytest raw-error implementation guard.
- Owner-supplied `EFHC_Bot_v174_59.zip` принят как donor/sample FRONTEND_v182 и Bank snapshot integration, а не как безусловный replacement current CANON. FRONTEND_v182 — текущая owner-controlled frontend authority.
- Selective merge rule: подтверждённые v182 frontend изменения принимаются, но donor не может откатить более высокий Shop D2/zero-price, atomic PaymentIntent, withdrawal `payout-evidence → mark-paid`, FAQ checked-in authority или другие active financial/security contracts.
- Tests/guards, противоречащие FRONTEND_v182 только по старой implementation shape, синхронизируются в той же итерации; реальные invariant tests сохраняются.
- Прямое owner decision разрешает новую singleton table `efhc_core.bank_metrics_snapshot`; table surface становится `53 ORM / 54 physical including alembic_version`. `0002+` не создаётся; supplied `URGENT_BANK_METRICS_SNAPSHOT.sql` предназначен для existing DB.
- Snapshot service transaction-neutral: скрытый service commit запрещён; commit/rollback принадлежит application boundary.
- Admin Panels Q&A `ADM-M09-01…19` имеют приоритет для v182 Panels behavior. Protective deactivation backend не симулируется: frontend остаётся fail-closed до отдельного atomic backend contract.

## Текущие решения 2026-08-20 / цикл 1797 — Admin Panels owner Q&A registry sync

- В active append-only Q&A register перенесены `QA-2026-08-20-ADM-M09-01…19` из `ADMIN_PANELS_OWNER_QA_v170.md`.
- Источник относится к owner-controlled redesign `Admin → Панели`; поздние QA-11/13/18 имеют приоритет над ранними пересекающимися формулировками.
- Регистрация решений не является самостоятельным разрешением на backend/main implementation; source boundaries сохраняются.
- Текущий integrated frontend source этой docs-only итерацией не изменяется.

## Текущие решения 2026-08-20 / цикл 1797 — CI 87591506394 + FRONTEND_v168 test sync

- Exact CI `87591506394` проверил `v174.56` SHA-256 `411b1c34e5fb05ac54004f589ec1bde453f79c31f93e2c5fe1e89082eac2aa9f`, checkout `22bb7d02d48a4aaaab4b7df3cf43646a8aec7630`.
- Реальные frontend defects из CI исправляются сразу; новые functional/visual changes по-прежнему требуют owner spec/patch.
- Tests/guards, которые противоречат утверждённому `FRONTEND_v168` только по старой implementation shape, синхронизируются с current contract в той же итерации.
- Финансовая граница не меняется: внешние EFHC deposit/withdraw/Shop = D2 boundary; внутренние EFHC operations = D8; `0.00` оставляет товар видимым, но purchase disabled.

## Текущие решения 2026-08-20 / цикл 1796 — D2/D8, Shop, FRONTEND_v168 и Test Authority

- **OWNER DECISION — financial boundary:** D2 применяется только к внешним операциям: внешний ввод EFHC, внешний вывод EFHC и внешний Shop. Все внутренние операции EFHC выполняются в D8.
- **OWNER DECISION — Shop topology:** внутреннего магазина не существует и существовать не может. Shop — отдельная открываемая HTML-страница для покупок, связанная с backend и Admin Panel.
- **OWNER DECISION — zero price:** `0.00` является допустимым состоянием товара; товар остаётся доступным, но кнопка/действие покупки деактивировано. `0.00` не является бесплатной покупкой.
- **OWNER DECISION — manual recovery:** новую функцию не добавлять. Ручной Admin contour уже реализован через модуль `Пользователи`; точечный D2/emergency scope не должен создавать дублирующий recovery UI/API.
- **OWNER DECISION — frontend:** `FRONTEND_v168` контролируется владельцем. Если задача требует frontend-изменения, оператор сначала выдаёт владельцу ТЗ и предлагаемый код; фактическое frontend-изменение должно прийти следующим owner patch, иначе оно будет перезаписано.
- **OWNER DECISION — tests:** устаревший test можно удалить, но только при высокой уверенности после сверки с актуальными CANON/NORM/SSOT и owner decisions; при неопределённости test сохраняется и вопрос выносится владельцу.
- Active provenance: `QA-2026-08-20-FIN3-14`, `QA-2026-08-20-FIN3-15`, `QA-2026-08-20-FIN3-16`, `QA-2026-08-20-FRONTEND-01`, `QA-2026-08-20-TESTAUTH-02`.

## Текущие решения 2026-08-19 / цикл 1795 — Test Authority / Anti-Stale Contract

- **OWNER DECISION:** тест не является SSOT. Authority: последнее прямое решение владельца → active CANON/SSOT/NORM → production runtime invariant → test/guard.
- Если expectation устарел относительно более высокого authority, он обновляется или удаляется в той же итерации. Запрещено откатывать корректный production runtime только ради stale implementation test.
- P0 financial/security/idempotency/transaction invariants остаются fail-closed; anti-stale policy не является основанием их ослаблять.
- Exact mutable counts routes/operations/schemas/test functions не являются development lock. Для расширяемой поверхности используется set/parity или required-subset проверка.
- CI `87522913463` подтвердил один реальный compatibility regression и одновременно stale hardcoded Admin seam count; поэтому тесты классифицируются по invariant, а не по факту падения.
- Active NORM: `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87405882481` engineering-language qualification repair

- Exact `v174.49` подтверждён SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768` и checkout `b69ed98e13c7995343429df2975fe2e893ada297`; RED только pytest language-policy guard.
- Guard является действующим authority и не устарел: новые/изменяемые инженерные артефакты должны быть на русском. Baseline не повышается для active drift.
- Исправляются только `14` подтверждённых narrative-строк в `KERNEL.md` и `START_HERE.md`; runtime, test semantics и финансовые/Shop contracts не меняются.
- Candidate/handoff: `EFHC_Bot_v174_50.zip`; следующий verifier — fresh exact-head GitHub CI.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87386543243` qualification repair

- Direct owner scope: продолжить цикл `1793`, работать по exact HEAD/active Kernel/SSOT/CANON и исправить подтверждённые ошибки новых CI-логов без локальной project qualification.
- Run `87290901436` квалифицировал exact `v174.47` GREEN. Run `87386543243` проверил exact `v174.48`; RED только один brittle Shop documentation guard.
- Shop owner decision не меняется: ручные независимые `price_ton`/`price_usdt`, без oracle/FX. Test должен проверять этот invariant, а не конкретный падеж фразы.
- Candidate/handoff после repair: `EFHC_Bot_v174_49.zip`; frozen schema/FAQ/FRONTEND_v146 сохраняются.

## Текущие решения 2026-08-19 / цикл 1793 — ручные цены Shop TON/USDT

- **OWNER DECISION:** Shop не использует ценовой oracle/FX service. Администратор вручную определяет сумму TON и/или USDT для каждой карточки через `price_ton` / `price_usdt`.
- Старый special-case `CUSTOM_EFHC` с формулой `0.3 USDT = 1 EFHC` и блокировкой TON удалён из runtime. Все checkout SKU используют единый catalog-item pricing flow.
- Legacy `custom_efhc_amount_d8` допускается только как совместимый входной атрибут и игнорируется; он не может влиять на цену, intent или settlement.
- Intent фиксирует текущую ручную цену карточки на TTL. Изменение Admin Shop price влияет только на новые intent.
- Scope ограничен Shop pricing. Exchange, watcher, BANK/ledger, schema, FAQ и visual frontend authority не меняются.
- Candidate/handoff: `EFHC_Bot_v174_48.zip`; fresh exact-head GitHub CI обязателен.

## Текущие решения 2026-08-19 / цикл 1793 — CI `87278222904` qualification repair

- **OWNER DECISION:** открыть/продолжить цикл `1793`, работать по exact HEAD/active Kernel/SSOT/CANON и исправить все подтверждённые ошибки supplied CI `87278222904` без локальной project qualification.
- Exact CI input: `v174.44` SHA-256 `54b882e871626e7190161c419e9c1f407c9b6a6080478465570ab08856354154`, checkout `001316adea12d34348a510da3cc8b401cbc6f199`; RED только Flake8 critical/Ruff/Mypy/pytest, frontend/PostgreSQL/Alembic GREEN.
- Deep remediation `v174.44` остаётся authority; stale test expectation не может вернуть старые DB-session/middleware/export lifecycle contracts.
- Frozen `0001`, FAQ standalone authority, FRONTEND_v146 и financial formulas данным qualification repair не меняются.
- Candidate/handoff после repair: `EFHC_Bot_v174_45.zip`; descriptive suffixes и owner-facing sidecars запрещены; fresh exact-head GitHub CI обязателен.

## Текущие решения 2026-08-19 / цикл 1792 — глубокое исправление backend

- Direct owner order: исправить все подтверждённые errors Deep Backend Remediation Specification для exact `v174.43`, дополнительно перепроверить аудит, не запускать local project qualification.
- Runtime ownership decision: root transaction только у application use-case owner; CRUD/composable services используют flush/savepoint, cancellation propagates, runtime/scheduler DB session = canonical `db_session()`.
- Financial QA decision: production runtime использует тот же canonical `split_bonus_then_main`, который тестируется; duplicate runtime implementation запрещена.
- Frozen schema, FAQ standalone authority и approved FRONTEND_v146 не меняются данным backend scope.
- Candidate/handoff после repair: `EFHC_Bot_v174_44.zip`; descriptive suffixes и owner-facing sidecars запрещены; exact-head GitHub CI обязателен.

# CURRENT DECISIONS — v174.43 / цикл 1792

- **OWNER DECISION:** открыть/продолжить цикл `1792` и исправить все подтверждённые ошибки GitHub CI `87220054352` по active Kernel/SSOT/CANON.
- Existing owner decisions remain unchanged: approved FRONTEND_v146 is visual/UX/text authority; FAQ is standalone checked-in release asset; schema-change governance lock remains active.
- CI tests are verification, not authority over correct current runtime; stale harness is updated when current source authority is confirmed.

# CURRENT DECISIONS — v174.42 / цикл 1791 corrective re-audit

- **OWNER DECISION:** выполнить полный confirmed scope ТЗ `EFHC_v174_41_REAUDIT_TECHNICAL_SPEC.md`, включая Phase A, B и C, не ограничиваясь только webhook.
- FAQ production assets остаются самостоятельными; FAQ SSOT только duplicate-control и не пишет runtime.
- Frozen `0001` и schema-change governance lock сохраняются; данный ТЗ прямо запрещает migration `0002+`/new table для webhook repair.
- Tests должны доказывать transaction boundary реальным helper/real PostgreSQL integration и не должны mock’ом скрывать ранний commit.
- Current candidate `v174.42` не GREEN до fresh exact-head GitHub CI.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

## Current 2026-08-18 / cycle 1791 / exact-head GREEN + full application audit

- Direct owner order: record supplied GREEN logs and audit the application across all functions. Cycle `1791` is the current audit scope.
- Exact `v174.40` is qualified GREEN by CI `87088984879`: SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`, all recorded gates exit `0`, pytest `1670 passed / 22 skipped / 1 warning`.
- Audit repairs may fix confirmed runtime/security/financial/ops/documentation defects, but the resulting `v174.41` does not inherit GREEN and requires a new exact-head CI.
- Existing owner locks remain: FRONTEND_v146 visual/UX/text authority; FAQ/locale/PWA standalone release assets; schema-change governance lock on unapproved DDL with normal CRUD allowed; canonical no-suffix archive filename.

## Current 2026-08-18 / cycle 1790 continuation / CI 87074955772

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87074955772`, and explain the database/table lock for mutual understanding.
- Exact CI `87074955772` tested `v174.39` SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872` / checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`; only pytest failed: `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Confirmed defect: two English docstrings in development-only FAQ duplicate-control verifier; minimal translation repair only.
- Clarification: current database lock is a schema-change governance lock, not a runtime table lock. Existing tables and CRUD are not blocked. Frozen `0001`/`0002+` policy remains active until an explicit owner decision authorizes global unlock or a specific schema change.
- FAQ standalone release-asset decision remains active; SSOT cannot overwrite runtime.
- Canonical candidate/handoff: `EFHC_Bot_v174_40.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1790

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87062684580`, make FAQ a standalone release asset, keep FAQ SSOT as duplicate control with no runtime influence, verify other pre-packaging dependencies, and do not run local full tests/build/CI.
- Exact CI `87062684580` tested `v174.38` SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75` / checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`; all other recorded gates GREEN.
- Owner superseding decision: checked-in production FAQ runtime is release authority. FAQ SSOT/generator may validate parity but may not write runtime. The earlier cycle-1789 recommendation is now APPROVED and superseded as an owner decision.
- Release application-asset contract: package builder verifies checked-in FAQ/locale/PWA/integrity assets and must not regenerate them during packaging. Packaging-only release metadata/checksum creation remains allowed.
- Schema policy is unchanged: frozen `0001`, `0002+` only by separate direct owner decision. The question «Разблокировал таблицы?» is answered by current authority: **нет, глобального unlock не было**.
- Canonical candidate/handoff after this cycle: `EFHC_Bot_v174_39.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1789 continuation

- Direct owner order: continue cycle `1789`, repair only confirmed failures from GitHub CI `86992003426`, audit FAQ release independence and current tables/migrations/routes/documents; do not run local full tests/build/CI.
- Exact CI `86992003426` tested `v174.37` SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d` / checkout `7384e8284dbde416086a13bd23de7136be585681`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Repairs are qualification-only; approved FRONTEND_v146 remains unchanged.
- Migration authority remains locked by active CANON/NORM: frozen `0001`, `0002+` only by direct owner decision. Current cycle contains no schema-change authorization.
- **RECOMMENDATION (not owner decision):** make checked-in FAQ runtime a standalone release asset and change packaging from generate+package to verify+package, while keeping SSOT/generator in development governance. Until direct approval, existing release scripts remain unchanged.
- Canonical candidate/handoff after this repair: `EFHC_Bot_v174_38.zip`; no descriptive suffixes and no extra owner-facing files.

- Direct owner order 2026-08-18 opens cycle `1789` for exact CI `86988434882` repair and FAQ/release-script verification.
- Test authority from cycle `1788` remains active: approved FRONTEND_v146 beats stale visual/text literals; real backend/security/financial invariants stay fail-closed.
- CI `86988434882` tested exact `v174.36` SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77` / checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`; all gates GREEN except pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Candidate `v174.37` contains qualification-only repair and requires next exact-head CI.
- Release architecture fact: frontend runtime/prebuild is SSOT-independent; production release packaging still generates FAQ from FAQ SSOT before staging under the existing approved design.
- Canonical next handoff: `EFHC_Bot_v174_37.zip`; descriptive archive suffixes/owner-facing sidecars remain forbidden.

- Owner decision 2026-08-18 / cycle `1788`: approved FRONTEND_v146 visual/UX/text/functions имеют приоритет над stale frontend tests. Если изменение patch корректно, stale expectation обновляется/удаляется; tests не должны блокировать разработку. Реальные backend/security/financial invariants сохраняются fail-closed.
- Owner decision 2026-08-18: при доказанном runtime defect и stale test разрешено исправлять оба; runtime — только при независимом evidence.
- Owner archive decision 2026-08-18: следующий handoff = `EFHC_Bot_v174_36.zip`; descriptive suffixes запрещены, owner-facing handoff содержит только основной archive.
- CI evidence `86966635485`: exact previous `v174.35` payload SHA-256 `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`, checkout `d878a1d4bb2e014ede2cf0c9d95ccd03f9b6f4a2`; core/backend/schema/frontend build GREEN, Ruff+pytest qualification RED. Candidate `v174.36` содержит repair и требует нового exact-head CI.

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- Owner Q/A recovery lock 2026-08-16: при подозрении на пропущенный реестр или прямом owner order нужно пройти **все доступные numbered `docs/chats/*.md`**, зарегистрировать доказуемые Q/A, а ответы без достаточного source context пометить unresolved/context-incomplete. Архивный transcript не заменяет Q/A register; согласование с владельцем происходит только в чате.

- Current owner scope: cycles `1786–1787` are explicitly opened; `1786` = Shop operator decomposition, `1787` = archive/Q&A/SSOT consolidation. After `1787`, no future functional cycle is automatically approved.

- Admin cycles 1785–1787 owner UX lock: одна непрерывная сетка ровно 20 плиток; grouping 4×5 отклонён; API Workbench остаётся видимым; плитки классифицируются ненавязчивым category-color accent; `/admin/panels` обязан иметь rich real-data analytics; Deposits при known Global ID даёт только переход `Открыть пользователя`; `ADMIN-P15` закрыт упрощённым Shop split: `Магазин` = каталог/общий обзор, отдельные плитки `Заказы` и `Выдача / VIP NFT` deep-link в существующие modes, одна резервная плитка остаётся свободной.

- Owner Q/A lock 2026-08-16: каждый owner-facing вопрос сначала записывается `PENDING` в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; после ответа исходный вопрос сохраняется и дополняется точным ответом. Пропущенный реестр обязан быть восстановлен по exact evidence; ответы не придумываются.
- Единый тестовый контур: только GitHub CI, запускаемый пользователем. Ассистент не запускает локальные tests/guards/lint/type/build/Alembic/CI checks; исправляет только подтверждённые failures из предоставленных логов.
- Архивный workflow: один цикл создаёт только один новый `EFHC_Bot_vNNN_NN.zip`, который является Development HEAD и источником следующего цикла. RELEASE/MATRIX/sidecar/auxiliary archives автоматически не создаются.
- Emergency override: циклы `1706–1710` используются только для латания подтверждённых критических регрессов; прежний план `1706–1709` сдвинут на `1711–1714`.
- BANK canon перенесён в `docs/SSOT/BANK_CANON.md`: `BANK_EFHC` — standalone `system_entity`, не пользователь; у bank ledger row `global_id=NULL`, `tg_id=NULL`.
- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Numbered chat transcripts находятся в `docs/chats/`; остальные исторические artifacts не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.
- Frontend разрабатывается отдельно; после квалификации текущей backend/identity migration перенос утверждённого release frontend в основной EFHC оформляется отдельным будущим решением. Это не цикл 1708 и сейчас не является утверждённым планом.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.

- Numeric `BANK_EFHC` ENV удалён из active config/release preflight/ops. Центральный банк идентифицируется только `system_entity=BANK_EFHC`; bank ledger row не имеет `global_id`/`tg_id`.
- Admin access имеет два независимых источника: обычный Admin list = active `admin_whitelist.global_id` + explicit RBAC role; Admin NFT = точный адрес NFT-item из `TON_ADMIN_NFT_IDS` внутри `TON_NFT_COLLECTION`, обнаруженный штатным NFT/VIP checker. `admin_nft_whitelist` — только derived cache; `ton_wallet_id` не становится owner. Канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Admin cleanup lock: запрещено удалять Admin route/service/handler/contract только по признаку `no callers` или compatibility-label без сравнения с последним exact-green functional composition. Cycle 1714 recovery anchor: v173.36; Admin HTTP routes 63/63 сохранены; Bonus Awards block восстановлен после ошибочного удаления в 1713.


## Cycle 1716 — function-preservation lock

- `contracts/application_function_surface_v1.json` is the fail-closed registered application surface.
- `tests/architecture/test_application_function_surface_manifest.py` is CI-only control against accidental removal; assistant does not run it locally.
- No-caller/no-frontend evidence never implies permission to delete public/Admin/operational/compatibility surface.
- Historical `v171.89` may be used as evidence, but tg_id-owned/migration-era implementation is not restored over active `global_id` CANON.

## 2026-08-19 / cycle 1794 — FINANCIAL TOPOLOGY LOCK

- TON/USDT = только внешние rails покупки EFHC.
- Internal money = EFHC (`EFHCm`, `EFHCb`, `BANK_EFHC`) через `efhc_transfers_log`.
- Withdrawal = только EFHC.
- D8 = EFHC/kWh; TON = nanotons; USDT = `10^6` units.
- External EFHC deposit/withdraw = D2 `ROUND_DOWN` → D8 storage.
- Shop `price_ton`/`price_usdt` задаются Admin независимо; `price <= 0` = unavailable.
- Business EFHC commission отсутствует; deposit network fee платит user, withdraw network fee платит project.
- NFT без confirmed payment не может перейти в `APPROVED`.
- Verified/completed ADS view финален независимо от reward; reward доводится idempotently.
- Oracle/FX/custom-rate pricing удалён и не восстанавливается без нового owner decision.
- Authority: `docs/SSOT/FINANCIAL_TOPOLOGY_SSOT.md` + Q/A `FIN3-01…12`.

## 2026-08-20 / cycle 1796 — Shop external D2 price lock

- OWNER DECISION `QA-2026-08-19-FIN3-13`: ручные `price_ton` / `price_usdt` независимы и имеют максимум D2.
- `>2` decimals отклоняются backend; silent rounding запрещён.
- Frontend блокирует ввод/submit >D2, но financial authority остаётся backend service boundary.
- После D2 validation Shop price один раз преобразуется в native atomic units: TON `10^9`, USDT `10^6`; PaymentIntent фиксирует exact atomic snapshot.
- `0.00` остаётся допустимой disabled-конфигурацией, но checkout/PaymentIntent недоступны.
- Internal EFHC, `quantity_efhc`, `efhc_amount_d8` и ledger остаются D8. Oracle/FX не восстанавливаются.

