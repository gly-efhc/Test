# CURRENT DECISIONS — v174.42 / цикл 1791 corrective re-audit

- **OWNER DECISION:** выполнить полный confirmed scope ТЗ `EFHC_v174_41_REAUDIT_TECHNICAL_SPEC.md`, включая Phase A, B и C, не ограничиваясь только webhook.
- FAQ production assets остаются самостоятельными; FAQ SSOT только duplicate-control и не пишет runtime.
- Frozen `0001` и schema-change governance lock сохраняются; данный ТЗ прямо запрещает migration `0002+`/new table для webhook repair.
- Tests должны доказывать transaction boundary реальным helper/real PostgreSQL integration и не должны mock’ом скрывать ранний commit.
- Current candidate `v174.42` не GREEN до fresh exact-head GitHub CI.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

## Current 2026-08-18 / cycle 1791 / exact-head GREEN + full application audit

- Direct owner order: record supplied GREEN logs and audit the application across all functions. Cycle `1791` is the current audit scope.
- Exact `v174.40` is qualified GREEN by CI `87088984879`: SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`, all recorded gates exit `0`, pytest `1670 passed / 22 skipped / 1 warning`.
- Audit repairs may fix confirmed runtime/security/financial/ops/documentation defects, but the resulting `v174.41` does not inherit GREEN and requires a new exact-head CI.
- Existing owner locks remain: FRONTEND_v146 visual/UX/text authority; FAQ/locale/PWA standalone release assets; schema-change governance lock on unapproved DDL with normal CRUD allowed; canonical no-suffix archive filename.

## Current 2026-08-18 / cycle 1790 continuation / CI 87074955772

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87074955772`, and explain the database/table lock for mutual understanding.
- Exact CI `87074955772` tested `v174.39` SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872` / checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`; only pytest failed: `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Confirmed defect: two English docstrings in development-only FAQ duplicate-control verifier; minimal translation repair only.
- Clarification: current database lock is a schema-change governance lock, not a runtime table lock. Existing tables and CRUD are not blocked. Frozen `0001`/`0002+` policy remains active until an explicit owner decision authorizes global unlock or a specific schema change.
- FAQ standalone release-asset decision remains active; SSOT cannot overwrite runtime.
- Canonical candidate/handoff: `EFHC_Bot_v174_40.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1790

- Direct owner order: continue cycle `1790`, repair only confirmed failures from GitHub CI `87062684580`, make FAQ a standalone release asset, keep FAQ SSOT as duplicate control with no runtime influence, verify other pre-packaging dependencies, and do not run local full tests/build/CI.
- Exact CI `87062684580` tested `v174.38` SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75` / checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`; all other recorded gates GREEN.
- Owner superseding decision: checked-in production FAQ runtime is release authority. FAQ SSOT/generator may validate parity but may not write runtime. The earlier cycle-1789 recommendation is now APPROVED and superseded as an owner decision.
- Release application-asset contract: package builder verifies checked-in FAQ/locale/PWA/integrity assets and must not regenerate them during packaging. Packaging-only release metadata/checksum creation remains allowed.
- Schema policy is unchanged: frozen `0001`, `0002+` only by separate direct owner decision. The question «Разблокировал таблицы?» is answered by current authority: **нет, глобального unlock не было**.
- Canonical candidate/handoff after this cycle: `EFHC_Bot_v174_39.zip`; no descriptive archive suffixes and no extra owner-facing files.

## Current 2026-08-18 / cycle 1789 continuation

- Direct owner order: continue cycle `1789`, repair only confirmed failures from GitHub CI `86992003426`, audit FAQ release independence and current tables/migrations/routes/documents; do not run local full tests/build/CI.
- Exact CI `86992003426` tested `v174.37` SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d` / checkout `7384e8284dbde416086a13bd23de7136be585681`; RED only pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Repairs are qualification-only; approved FRONTEND_v146 remains unchanged.
- Migration authority remains locked by active CANON/NORM: frozen `0001`, `0002+` only by direct owner decision. Current cycle contains no schema-change authorization.
- **RECOMMENDATION (not owner decision):** make checked-in FAQ runtime a standalone release asset and change packaging from generate+package to verify+package, while keeping SSOT/generator in development governance. Until direct approval, existing release scripts remain unchanged.
- Canonical candidate/handoff after this repair: `EFHC_Bot_v174_38.zip`; no descriptive suffixes and no extra owner-facing files.

- Direct owner order 2026-08-18 opens cycle `1789` for exact CI `86988434882` repair and FAQ/release-script verification.
- Test authority from cycle `1788` remains active: approved FRONTEND_v146 beats stale visual/text literals; real backend/security/financial invariants stay fail-closed.
- CI `86988434882` tested exact `v174.36` SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77` / checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`; all gates GREEN except pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Candidate `v174.37` contains qualification-only repair and requires next exact-head CI.
- Release architecture fact: frontend runtime/prebuild is SSOT-independent; production release packaging still generates FAQ from FAQ SSOT before staging under the existing approved design.
- Canonical next handoff: `EFHC_Bot_v174_37.zip`; descriptive archive suffixes/owner-facing sidecars remain forbidden.

- Owner decision 2026-08-18 / cycle `1788`: approved FRONTEND_v146 visual/UX/text/functions имеют приоритет над stale frontend tests. Если изменение patch корректно, stale expectation обновляется/удаляется; tests не должны блокировать разработку. Реальные backend/security/financial invariants сохраняются fail-closed.
- Owner decision 2026-08-18: при доказанном runtime defect и stale test разрешено исправлять оба; runtime — только при независимом evidence.
- Owner archive decision 2026-08-18: следующий handoff = `EFHC_Bot_v174_36.zip`; descriptive suffixes запрещены, owner-facing handoff содержит только основной archive.
- CI evidence `86966635485`: exact previous `v174.35` payload SHA-256 `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`, checkout `d878a1d4bb2e014ede2cf0c9d95ccd03f9b6f4a2`; core/backend/schema/frontend build GREEN, Ruff+pytest qualification RED. Candidate `v174.36` содержит repair и требует нового exact-head CI.

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- Owner Q/A recovery lock 2026-08-16: при подозрении на пропущенный реестр или прямом owner order нужно пройти **все доступные numbered `docs/chats/*.md`**, зарегистрировать доказуемые Q/A, а ответы без достаточного source context пометить unresolved/context-incomplete. Архивный transcript не заменяет Q/A register; согласование с владельцем происходит только в чате.

- Current owner scope: cycles `1786–1787` are explicitly opened; `1786` = Shop operator decomposition, `1787` = archive/Q&A/SSOT consolidation. After `1787`, no future functional cycle is automatically approved.

- Admin cycles 1785–1787 owner UX lock: одна непрерывная сетка ровно 20 плиток; grouping 4×5 отклонён; API Workbench остаётся видимым; плитки классифицируются ненавязчивым category-color accent; `/admin/panels` обязан иметь rich real-data analytics; Deposits при known Global ID даёт только переход `Открыть пользователя`; `ADMIN-P15` закрыт упрощённым Shop split: `Магазин` = каталог/общий обзор, отдельные плитки `Заказы` и `Выдача / VIP NFT` deep-link в существующие modes, одна резервная плитка остаётся свободной.

- Owner Q/A lock 2026-08-16: каждый owner-facing вопрос сначала записывается `PENDING` в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; после ответа исходный вопрос сохраняется и дополняется точным ответом. Пропущенный реестр обязан быть восстановлен по exact evidence; ответы не придумываются.
- Единый тестовый контур: только GitHub CI, запускаемый пользователем. Ассистент не запускает локальные tests/guards/lint/type/build/Alembic/CI checks; исправляет только подтверждённые failures из предоставленных логов.
- Архивный workflow: один цикл создаёт только один новый `EFHC_Bot_vNNN_NN.zip`, который является Development HEAD и источником следующего цикла. RELEASE/MATRIX/sidecar/auxiliary archives автоматически не создаются.
- Emergency override: циклы `1706–1710` используются только для латания подтверждённых критических регрессов; прежний план `1706–1709` сдвинут на `1711–1714`.
- BANK canon перенесён в `docs/SSOT/BANK_CANON.md`: `BANK_EFHC` — standalone `system_entity`, не пользователь; у bank ledger row `global_id=NULL`, `tg_id=NULL`.
- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Numbered chat transcripts находятся в `docs/chats/`; остальные исторические artifacts не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.
- Frontend разрабатывается отдельно; после квалификации текущей backend/identity migration перенос утверждённого release frontend в основной EFHC оформляется отдельным будущим решением. Это не цикл 1708 и сейчас не является утверждённым планом.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.

- Numeric `BANK_EFHC` ENV удалён из active config/release preflight/ops. Центральный банк идентифицируется только `system_entity=BANK_EFHC`; bank ledger row не имеет `global_id`/`tg_id`.
- Admin access имеет два независимых источника: обычный Admin list = active `admin_whitelist.global_id` + explicit RBAC role; Admin NFT = точный адрес NFT-item из `TON_ADMIN_NFT_IDS` внутри `TON_NFT_COLLECTION`, обнаруженный штатным NFT/VIP checker. `admin_nft_whitelist` — только derived cache; `ton_wallet_id` не становится owner. Канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Admin cleanup lock: запрещено удалять Admin route/service/handler/contract только по признаку `no callers` или compatibility-label без сравнения с последним exact-green functional composition. Cycle 1714 recovery anchor: v173.36; Admin HTTP routes 63/63 сохранены; Bonus Awards block восстановлен после ошибочного удаления в 1713.


## Cycle 1716 — function-preservation lock

- `contracts/application_function_surface_v1.json` is the fail-closed registered application surface.
- `tests/architecture/test_application_function_surface_manifest.py` is CI-only control against accidental removal; assistant does not run it locally.
- No-caller/no-frontend evidence never implies permission to delete public/Admin/operational/compatibility surface.
- Historical `v171.89` may be used as evidence, but tg_id-owned/migration-era implementation is not restored over active `global_id` CANON.
