<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

- Direct owner order 2026-08-18 opens cycle `1789` for exact CI `86988434882` repair and FAQ/release-script verification.
- Test authority from cycle `1788` remains active: approved FRONTEND_v146 beats stale visual/text literals; real backend/security/financial invariants stay fail-closed.
- CI `86988434882` tested exact `v174.36` SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77` / checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`; all gates GREEN except pytest `3 failed / 1666 passed / 22 skipped / 1 warning`. Candidate `v174.37` contains qualification-only repair and requires next exact-head CI.
- Release architecture fact: frontend runtime/prebuild is SSOT-independent; production release packaging still generates FAQ from FAQ SSOT before staging under the existing approved design.
- Canonical next handoff: `EFHC_Bot_v174_37.zip`; descriptive archive suffixes/owner-facing sidecars remain forbidden.

- Owner decision 2026-08-18 / cycle `1788`: approved FRONTEND_v146 visual/UX/text/functions имеют приоритет над stale frontend tests. Если изменение patch корректно, stale expectation обновляется/удаляется; tests не должны блокировать разработку. Реальные backend/security/financial invariants сохраняются fail-closed.
- Owner decision 2026-08-18: при доказанном runtime defect и stale test разрешено исправлять оба; runtime — только при независимом evidence.
- Owner archive decision 2026-08-18: следующий handoff = `EFHC_Bot_v174_36.zip`; descriptive suffixes запрещены, owner-facing handoff содержит только основной archive.
- CI evidence `86966635485`: exact previous `v174.35` payload SHA-256 `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`, checkout `d878a1d4bb2e014ede2cf0c9d95ccd03f9b6f4a2`; core/backend/schema/frontend build GREEN, Ruff+pytest qualification RED. Candidate `v174.36` содержит repair и требует нового exact-head CI.

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- Owner Q/A recovery lock 2026-08-16: при подозрении на пропущенный реестр или прямом owner order нужно пройти **все доступные numbered `docs/chats/*.md`**, зарегистрировать доказуемые Q/A, а ответы без достаточного source context пометить unresolved/context-incomplete. Архивный transcript не заменяет Q/A register; согласование с владельцем происходит только в чате.

- Current owner scope: cycles `1786–1787` are explicitly opened; `1786` = Shop operator decomposition, `1787` = archive/Q&A/SSOT consolidation. After `1787`, no future functional cycle is automatically approved.

- Admin cycles 1785–1787 owner UX lock: одна непрерывная сетка ровно 20 плиток; grouping 4×5 отклонён; API Workbench остаётся видимым; плитки классифицируются ненавязчивым category-color accent; `/admin/panels` обязан иметь rich real-data analytics; Deposits при known Global ID даёт только переход `Открыть пользователя`; `ADMIN-P15` закрыт упрощённым Shop split: `Магазин` = каталог/общий обзор, отдельные плитки `Заказы` и `Выдача / VIP NFT` deep-link в существующие modes, одна резервная плитка остаётся свободной.

- Owner Q/A lock 2026-08-16: каждый owner-facing вопрос сначала записывается `PENDING` в `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; после ответа исходный вопрос сохраняется и дополняется точным ответом. Пропущенный реестр обязан быть восстановлен по exact evidence; ответы не придумываются.
- Единый тестовый контур: только GitHub CI, запускаемый пользователем. Ассистент не запускает локальные tests/guards/lint/type/build/Alembic/CI checks; исправляет только подтверждённые failures из предоставленных логов.
- Архивный workflow: один цикл создаёт только один новый `EFHC_Bot_vNNN_NN.zip`, который является Development HEAD и источником следующего цикла. RELEASE/MATRIX/sidecar/auxiliary archives автоматически не создаются.
- Emergency override: циклы `1706–1710` используются только для латания подтверждённых критических регрессов; прежний план `1706–1709` сдвинут на `1711–1714`.
- BANK canon перенесён в `docs/SSOT/BANK_CANON.md`: `BANK_EFHC` — standalone `system_entity`, не пользователь; у bank ledger row `global_id=NULL`, `tg_id=NULL`.
- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Numbered chat transcripts находятся в `docs/chats/`; остальные исторические artifacts не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.
- Frontend разрабатывается отдельно; после квалификации текущей backend/identity migration перенос утверждённого release frontend в основной EFHC оформляется отдельным будущим решением. Это не цикл 1708 и сейчас не является утверждённым планом.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.

- Numeric `BANK_EFHC` ENV удалён из active config/release preflight/ops. Центральный банк идентифицируется только `system_entity=BANK_EFHC`; bank ledger row не имеет `global_id`/`tg_id`.
- Admin access имеет два независимых источника: обычный Admin list = active `admin_whitelist.global_id` + explicit RBAC role; Admin NFT = точный адрес NFT-item из `TON_ADMIN_NFT_IDS` внутри `TON_NFT_COLLECTION`, обнаруженный штатным NFT/VIP checker. `admin_nft_whitelist` — только derived cache; `ton_wallet_id` не становится owner. Канон: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Admin cleanup lock: запрещено удалять Admin route/service/handler/contract только по признаку `no callers` или compatibility-label без сравнения с последним exact-green functional composition. Cycle 1714 recovery anchor: v173.36; Admin HTTP routes 63/63 сохранены; Bonus Awards block восстановлен после ошибочного удаления в 1713.


## Cycle 1716 — function-preservation lock

- `contracts/application_function_surface_v1.json` is the fail-closed registered application surface.
- `tests/architecture/test_application_function_surface_manifest.py` is CI-only control against accidental removal; assistant does not run it locally.
- No-caller/no-frontend evidence never implies permission to delete public/Admin/operational/compatibility surface.
- Historical `v171.89` may be used as evidence, but tg_id-owned/migration-era implementation is not restored over active `global_id` CANON.
