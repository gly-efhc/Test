<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# CURRENT DECISIONS

Статус: **ACTIVE DERIVED INDEX**

Этот current index является **separate document**, не является
стенограммой и не может заменять исторический Q/A register.

Этот файл содержит только действующие решения, которые ещё не отражены в
профильном CANON/SSOT/NORM. После переноса решения в профильный документ
оно удаляется отсюда.

## Current

- `global_id` — единственный внутренний account/business owner.
- `tg_id` — только Telegram provider subject и delivery recipient.
- Единственная pre-release migration — `0001_initial_release_schema.py`.
- Исторические Q&A находятся в `АРТЕФАКТЫ/` и не определяют current state.
- Статус проекта остаётся `EXACT_HEAD_CI_REQUIRED` до нового GitHub CI.

## Языковой канон

- Запрещено переводить русский язык с английского; исходный русский инженерный текст должен сохраняться и не восстанавливаться обратным машинным переводом.

## Контроль SSOT

- SSOT может быть регрессом, если он противоречит фактическому коду, последнему решению пользователя или exact-head CI; такие противоречия исправляются, а не объявляются каноном.
