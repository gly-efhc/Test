# BROWSER_SHOP_MVP_CHECKLIST

Статус: GENERAL
Якорь: финальная валидация MVP

## Checklist

- [x] Hub inside Telegram = link/handoff layer only
- [x] Direct browser entry supported
- [x] Telegram linking before final confirmation
- [x] Existing wallet binding reused when possible
- [x] One storefront
- [x] No cart
- [x] One product = one operation
- [x] Unified checkout pattern
- [x] Separate status screen
- [x] Immutable server-side memo
- [x] Payment intent after linking only
- [x] Anti-fraud full-match watcher rule
- [x] package/custom -> main balance credit
- [x] VIP NFT -> manual issue request
- [x] Simple return-to-bot
