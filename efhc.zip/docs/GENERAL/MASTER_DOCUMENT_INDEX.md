# MASTER DOCUMENT INDEX

Полный master-index всех документных файлов текущего HEAD. Этот файл нужен как главная карта архива перед пофайловой ревизией. Решение по каждому документу принимает пользователь.

## Правила текущей фазы

- ядро архива не исключается из инвентаризации, но остаётся отдельным рабочим слоем;
- все audit-документы и лог-аудиты перенесены в `EXTERNAL_ARTIFACTS_HISTORY` и в текущих пакетах по 5 не рассматриваются;
- `EXTERNAL_ARTIFACTS_HISTORY` пока не трогаем;
- `artifacts/` — корзина архива для удалённых и вырезанных элементов и не входит в master-index как рабочий слой.
- Рабочий индекс не перечисляет файлы из `artifacts/`; исторические переносы могут кратко упоминаться только в narrative history без посрочного индексирования артефактов.
- подробная работа дальше идёт пакетами по 5 файлов.

## Сводка по архиву

- `(root)`: **27**
- `backend`: **270**
- `docs`: **272**
- `frontend`: **18**
- `ops`: **17**
- `reports`: **508**
- `tests`: **8**

- Всего документных файлов в индексе: **872**

## Сводка по предварительным рекомендациям

- актуализировать: **13**
- не рассматривать сейчас: **597**
- пока оставить в artifacts: **3**
- проверить вручную: **224**
- проверить на объединение: **20**
- сохранить: **15**

## Где смотреть полный список

- `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv` — полный индекс со всеми файлами и полями описания.
- `docs/GENERAL/ARCHIVE_NAV_INDEX.md` — навигационный индекс для чтения архива по приоритетам.

- 2026-04-01: Cycle 207 — `docs/ACTIVE_WORDING_GUARDS_WAVE_2026_03_31.md` выведен из active docs слоя в `archived historical file`; короткий `ADMIN_PANEL_SPEC.md` объединён с более полным описанием админ-панели и актуализирован; `docker-compose.yml` и `docs/NORM/ADMIN_RBAC.md` мягко актуализированы.

- 2026-04-01: Cycle 208 — `docs/ADMIN_REPORTING_HUB_HARDENING.md` объединён по смыслу с `docs/GENERAL/ADMIN_PANEL_SPEC.md` и выведен в `archived historical file`; ADR 0001/0002/0003 и `docs/AI/AI_OPERATOR_RULES_EFHC.md` мягко актуализированы по текущему HEAD.

- 2026-04-01: Cycle 209 — `docs/API_REFERENCE.md` объединён с более сильным `docs/NORM/API_CONTRACTS.md` и выведен в `archived historical file`; `docs/AI/AI_RESILIENCE_CANON.md`, `docs/NORM/API_CONTRACTS.md`, `docs/NORM/ARCHITECTURAL_LOCKS.md` и `docs/GENERAL/ARCHITECTURE_DEPENDENCIES_RU.md` мягко актуализированы по текущему HEAD.

- 2026-04-01: Cycle 210 — три wave/plan документа (`ARCHIVE_DOCS_UPDATE_PLAN_196_200`, `BACKEND_BOT_WORDING_SYNC_2026_03_31`, `BACKEND_INTERNAL_PANEL_NAMING_REFACTOR_2026_03_31`) выведены в `archived historical file` после смыслового переноса в `EXTERNAL_ARTIFACTS_HISTORY`; `ARCHIVE_NAV_INDEX.md` актуализирован; `BACKGROUND_TASKS_STANDARD.md` повышен до NORM и отражён в `docs/SSOT/SSOT_INDEX.md`.

- 2026-04-01: Cycle 211 — `docs/BACKGROUND_TASKS_STANDARD.md` переименован в `docs/NORM/TASKS_STANDARD.md`; связанные active реестры и индексы синхронизированы с новым путём.

- 2026-04-01: Cycle 212 — `BANK_CANON_SHORT.md` подтверждён как сильный short-canon и добавлен в NORM через `SSOT_INDEX`; `BOT_PAGES_INVENTORY_2026_03_31.md` переведён в `EXTERNAL_ARTIFACTS_HISTORY`; `BOT_WEBAPP_ENTRYPOINT_STABILIZATION.md`, `CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml` и `CODE_CLEANUP_AND_IMPROVEMENT_10_CYCLES_PLAN.md` выведены из active слоя.

- 2026-04-01: Cycle 213 — `docs/GENERAL/DOCKER_LOCAL.md` синхронизирован с текущим Docker layer; `docs/SSOT/DTO_INPUT_CANON.md` повышен до NORM через `docs/SSOT/SSOT_INDEX.md`; `docs/SSOT/EFHC_CANON.md` мягко вычищен по подтверждённой точке drift; `docs/SSOT/ENERGY_RULES.md` дополнен явной связью с exchange/available_kwh SSOT; `docs/NORM/ERROR_CODES.md` дополнен кодами `WALLET_REQUIRED` и `HUB_HANDOFF_NOT_CONNECTED`.

- 2026-04-01: Cycle 214 — `FAQ_BOT_HELP_PARITY_WAVE.md` выведен в `archived historical file`; `EVENTS_MATRIX.md`, `EXCHANGE_WITHDRAW_MECHANICS_SSOT.md`, `FAQ_APPROVAL_GOVERNANCE.md` и `FAQ_CODE_GENERATION_HARDENING.md` мягко актуализированы по текущему HEAD.
- 2026-04-01: Cycle 215 — `FAQ_COVERAGE_MATRIX.md` выведен в `archived historical file`; `FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`, `FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`, `FAQ_HUB_RU_REWRITE_WAVE1.md` и `FAQ_INVENTORY_FREEZE.csv` переведены в `EXTERNAL_ARTIFACTS_HISTORY`.
- 2026-04-01: Cycle 216 — `FAQ_INVENTORY_FREEZE.md` переведён в `EXTERNAL_ARTIFACTS_HISTORY`; `FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`, `FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`, `FAQ_PANELS_RATES_RU_DRAFT.md` и `FAQ_PANELS_RU_REWRITE_WAVE1.md` выведены в `archived historical file`.
- 2026-04-01: Cycle 217 — `FAQ_REPLACEMENT_LEDGER.md` переведён в `EXTERNAL_ARTIFACTS_HISTORY`; `FAQ_SSOT.md` мягко актуализирован; `FAQ_TOPBAR_RU_REWRITE_WAVE1.md`, `FAQ_VIP_RU_REWRITE_WAVE1.md` и `FAQ_WALLET_RU_REWRITE_WAVE1.md` выведены в `archived historical file`.
- 2026-04-01: Cycle 218 — `FRONTEND_ACTIVE_LOCALE_SYNC_2026_03_31.md`, `HUB_ADMIN_ENTITY_DESIGN.md` и `HUB_ADMIN_MIGRATION_MODEL_WAVE.md` переведены в `EXTERNAL_ARTIFACTS_HISTORY`; `HUB_ALIAS_PRESSURE_TEST.md` и `HUB_ALIAS_REMOVAL_WAVE2.md` выведены в `archived historical file`.
- 2026-04-01: Cycle 219 — `HUB_CYCLES_91_100_PLAN.md` сведен в `EXTERNAL_ARTIFACTS_HISTORY`; `HUB_EFHC_HANDOFF_IMPLEMENTATION_WAVE1.md`, `HUB_FAQ_SECTION_13_RU_DRAFT.md` и `HUB_FINAL_ALIAS_REMOVAL_DESIGN.md` переведены в `EXTERNAL_ARTIFACTS_HISTORY`; `HUB_FINAL_ALIAS_REMOVAL_WAVE1.md` выведен в `archived historical file`.
- 2026-04-01: Cycle 220 — `HUB_FINAL_COMMERCE_CLEANUP_RELEASE_STABILIZATION.md` сведен в `EXTERNAL_ARTIFACTS_HISTORY`; `HUB_GUARDS_REGRESSION_PACK.md`, `HUB_SERIES_61_100_FINAL_HANDOFF.md` и `I18N_ADMIN_VERIFICATION_2026_03_31.md` переведены в `EXTERNAL_ARTIFACTS_HISTORY`; `HUB_SSOT.md` мягко актуализирован.
- 2026-04-01: Cycle 221 — historical i18n wave-docs выведены в `archived historical file`: `I18N_ADMIN_WAVE1_2026_03_31.md`, `I18N_ADMIN_WAVE2_2026_03_31.md`, `I18N_COMMON_BALANCES_WAVE1_2026_03_31.md`, `I18N_EXCHANGE_ENERGY_WAVE1_2026_03_31.md`, `I18N_HISTORY_WITHDRAW_WAVE1_2026_03_31.md`.
- 2026-04-01: Cycle 222 — `I18N_HUB_FAQ_WAVE2_2026_03_31.md`, `I18N_MISSING_KEY_MATRIX_2026_03_31.md`, `I18N_MISSING_TRANSLATIONS_PLAN_191_195.md`, `I18N_PANELS_WAVE1_2026_03_31.md`, `I18N_PROFILE_WAVE1_2026_03_31.md` выведены в `archived historical file`.
- 2026-04-01: Cycle 223 — `I18N_SYNC_PLAN_181_190.md`, `I18N_TASKS_REFERRALS_WAVE1_2026_03_31.md`, `I18N_WALLET_WAVE1_2026_03_31.md`, `LEGACY_CLEANUP_WAVE2.md`, `LEGACY_FRONTEND_FAQ_SOURCES_CLEANUP_2026_03_31.md` выведены в `archived historical file`; исторически важные выводы двух legacy cleanup документов сохранены в `EXTERNAL_ARTIFACTS_HISTORY`.

- 2026-04-01: Cycle 224 — master-index очищен от слоя `artifacts/` по правилу пользователя: артефакты являются корзиной/мусором и не должны учитываться как рабочие индексные записи.
- 2026-04-01: Cycle 225 — master-index сохранён без записей `artifacts/`; three historical notes (`MIGRATION_RESET_TO_0001_2026_03_31.md`, `OBSERVABILITY_METRICS_PLAN.md`, `OPENAPI_RELEASE_DOCS_FREEZE_2026_03_31.md`) removed from active indexing after their important content was moved into `EXTERNAL_ARTIFACTS_HISTORY` / active docs.
- 2026-04-01: Cycle 226 — overview/panels pack 1 cleaned from standalone historical notes; important content absorbed into `EXTERNAL_ARTIFACTS_HISTORY` and active NORM/SSOT docs.
- 2026-04-01: Cycle 227 — panels pack 2 cleaned from standalone historical notes; important panels compatibility/boundary content absorbed by `docs/SSOT/PANELS_SSOT.md` and `EXTERNAL_ARTIFACTS_HISTORY`.
- 2026-04-01: Cycle 228 — panels/project/release pack cleaned; historical notes decomposed into active docs, while `QUESTIONS_AND_ANSWERS_REGISTER.md` and `RANKS_RULES.md` were upgraded to NORM.
- 2026-04-01: Cycle 229 — `REFERRALS_RULES.md` and `ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md` promoted to NORM; `RELEASE_ARTIFACT_HYGIENE_WAVE_2.md` and `ROUTES_MIGRATIONS_REPAIR_10_CYCLES_PLAN.md` removed from active indexing after absorption into `EXTERNAL_ARTIFACTS_HISTORY`; `ROUTE_INVENTORY_FREEZE.md` left pending separate user decision.

- 2026-04-01: Cycle 230 — `docs/SSOT/ROUTE_RESPONSE_ERROR_CANON.md` нормализован как NORM; historical notes `ROUTE_OPENAPI_GENERATION_HARDENING_2026_03_31.md`, `ROUTE_TABLE_MAP_REFRESH_2026_03_31.md` и `SCHEDULER_PLAYBOOK.md` поглощены active docs и выведены из active слоя; `SECURITY_EXCEPTIONS_REGISTER.md` переведён в NORM.

- 2026-04-01: Cycle 231 — `BANK_DEFICIT.md` разобран и поглощён `docs/SSOT/BANK_CANON.md` / `docs/SSOT/EFHC_CANON.md`; `INCIDENTS.md` и `RECONCILIATION.md` актуализированы как active runbooks; archive_removed FAQ candidate/replacement traces выведены в глубокий архивный слой.

- 2026-04-01: Cycle 232 — оставшиеся `FAQ_RU_DUPLICATE_CANDIDATES_WAVE4.md` и `FAQ_RU_WEAK_DUPLICATE_CANDIDATES_WAVE1.md` выведены из `docs/archive_removed_elements/` в `artifacts/archive_removed_elements/`.

- 2026-04-01: Cycle 233 — выполнен полный sync журналов циклов, реестров и reports с текущим HEAD; historical chat directives и late-cycle решения досинхронизированы в active continuity docs.

- 2026-05-22: v168_84 / work pass — добавлены audit/report/JSON и
  guard для Exchange kWh -> EFHC only boundary; сохранена ветка 21 как
  `EXTERNAL_ARTIFACTS_HISTORY`; обновлены frontend cycle docs,
  `CHAT_TRANSCRIPT.md`, Q/A register, tests catalog и reports index.

- 2026-05-22: v168_85 / work pass — добавлены polish-правки
  Exchange amount/preview, guard `test_exchange_amount_preview.py`,
  audit/report/JSON цикла 1287; `21.md` дополнительно сохранён в
  `EXTERNAL_ARTIFACTS_HISTORY` как пользовательская папка чатов.
## v168_86 work pass Exchange History light boundary

- docs/history/legacy_artifacts/reports/change_cycle_2026-05-22_v168_86_cycle_1288_exchange_history_link.md
- docs/history/legacy_artifacts/reports/generated/frontend_cycle_1288_exchange_history_link_v168_86.json
- docs/history/legacy_artifacts/docs/audits/FRONTEND_CYCLE_1288_EXCHANGE_HISTORY_LINK_AUDIT_V168_86.md
- tests/architecture/test_exchange_history_link.py

## v168_87 work pass Exchange route contract

- docs/history/legacy_artifacts/reports/change_cycle_2026-05-22_v168_87_cycle_1289_exchange_route_contract.md
- docs/history/legacy_artifacts/reports/generated/frontend_cycle_1289_exchange_route_contract_v168_87.json
- docs/history/legacy_artifacts/reports/generated/frontend_sandbox_intake_v168_87.json
- docs/history/legacy_artifacts/docs/audits/FRONTEND_CYCLE_1289_EXCHANGE_ROUTE_CONTRACT_AUDIT_V168_87.md
- docs/frontend/FRONTEND_SANDBOX_REFERENCE.md
- tests/architecture/test_exchange_route_contract.py

- `EXTERNAL_ARTIFACTS_HISTORY`
  — change report for audit repair work pass.
- `EXTERNAL_ARTIFACTS_HISTORY`
  — audit repair report for uploaded AUDIT_TZ_v168_83.md.
- `EXTERNAL_ARTIFACTS_HISTORY`
  — generated machine summary for work pass.
- `EXTERNAL_ARTIFACTS_HISTORY` — uploaded source audit
  used as repair task for v168_88 / work pass.

## v168_89 work pass additions

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_tasks_earning_boundary.py`



## v168_90 work pass additions

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_tasks_ads_action.py`


## v168_91 work pass additions

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_tasks_hidden_execution_log.py`

- v168_92 work pass: Tasks proof and Referrals current-user boundary docs/history/legacy_artifacts/reports/tests.

## v168_93 work pass — docs/history/legacy_artifacts/reports/change_cycle_2026-05-25_v168_93_cycles_1297_1302_referrals_ranks.md
- docs/history/legacy_artifacts/docs/audits/FRONTEND_CYCLES_1297_1302_REFERRALS_RANKS_AUDIT_V168_93.md
- docs/history/legacy_artifacts/reports/generated/frontend_cycles_1297_1302_referrals_ranks_v168_93.json

## v168_94 work pass additions

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_profile_wallet_history_faq.py`

- `docs/admin/ADMIN_ROUTES_MAP.md` — Admin route map for work pass.
- `EXTERNAL_ARTIFACTS_HISTORY` — next Admin recovery plan.

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`


## v168_98 CI logs 70700012125 repair

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`

## v168_99 work pass admin users audit

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_admin_users.py`

## v169_00 work pass admin users readability

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_admin_users_variant_a.py`


## v169_01 work pass admin bank sandbox visual

- `docs/admin/ADMIN_SANDBOX_VISUAL_REFERENCE.md`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_admin_bank.py`


## v169_02 archive numbering regression audit

- `EXTERNAL_ARTIFACTS_HISTORY`
- `docs/NORM/ARCHIVE_NUMBERING_CANON.md`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_archive_numbering_canon_v169_02.py`

## v169_03 work pass documents

- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_admin_bank_variant_a.py`

## v169_04 work pass documents

- `docs/admin/ADMIN_INTERACTIVE_DASHBOARD_CANON.md`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `EXTERNAL_ARTIFACTS_HISTORY`
- `tests/architecture/test_admin_interactive_dashboard.py`
