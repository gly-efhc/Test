<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Техническое задание v001
# Внедрение алгоритмов ускоренной AI-работы с архивом EFHC Bot

**Архив-цель:** `EFHC_Bot_v169_14_cycle_1335_ci_logs_71056336346_repair.zip`  
**Проект:** EFHC Bot — Telegram WebApp + FastAPI backend + frontend/admin surface + документационный AI/SSOT/NORM/control-layer.  
**Внешний архитектурный референс:** `claude-code-main.zip`, использовать только как источник инженерных идей: маршрутизация, индексация, context capsule, tool registry, task state, patch planner, targeted validation. Прямое копирование исходного кода не использовать.  
**Главная цель:** ускорить работу ChatGPT / AI-исполнителя с EFHC Bot архивом в несколько раз за счёт предварительной карты архива, быстрых маршрутов, индексов, кешей, точечного чтения и управляемого цикла изменений.  
**Условие пользователя:** тестовая среда считается безопасной; модуль удаления/очистки секретов из окружения (`env scrub`) **не внедрять** и не включать в план реализации.

---

## 0. Короткий вывод

В текущем EFHC Bot архиве уже есть сильная AI-навигационная основа:

```text
README.md
ARCHITECTURAL_LOCKS.md
docs/AI/READING_ENTRYPOINT.md
docs/AI/READING_BUDGET.md
docs/AI/TOPIC_READING_ROUTES.md
docs/AI/ARCHIVE_FAST_MANIFEST.md
docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
docs/AI/AI_OPERATOR_RULES_EFHC.md
docs/SSOT/SSOT_INDEX.md
docs/NORM/ARCHITECTURAL_LOCKS.md
HEALER_ATLAS.md
EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
reports/REPORTS_INDEX.md
docs/cycles/WORK_CYCLES.md
```

Но сейчас это в основном **документная маршрутизация для человека/AI**, а не полноценный машинный `Operator Kernel`.

Задача ТЗ — добавить слой, который будет делать автоматически:

```text
запрос пользователя
→ классификация типа задачи
→ выбор маршрута чтения
→ выбор точных файлов
→ выбор точных фрагментов
→ сбор context capsule
→ план патча
→ точечные проверки
→ отчёт цикла
→ обновление индексов
```

Целевой результат: ChatGPT перестаёт перечитывать сотни документов и начинает работать через короткий, точный, машинно-собранный контекст.

---

## 1. Что обнаружено в архиве EFHC Bot v169_14

### 1.1. Размер и состав

Статический осмотр архива показал:

| Метрика | Значение |
|---|---:|
| Всего файлов | 2351 |
| Markdown-документов | 1239 |
| Python-файлов | 652 |
| JSON-файлов | 180 |
| TSX-файлов | 126 |
| TS-файлов | 63 |
| `backend/app/` | 276 файлов |
| `frontend/` | 234 файла |
| `docs/AI/` | 21 файл |
| `docs/SSOT/` | 83 файла |
| `docs/NORM/` | 45 файлов |
| `docs/audits/` | 534 файла |
| `reports/` | 554 файла |
| `ops/` | 130 файлов |
| `tests/` | 278 файлов |

Главная проблема скорости: архив уже большой, но большая часть файлов нужна **не всегда**. Особенно тяжёлые зоны:

```text
docs/audits/
reports/
docs/cycles/
frontend/
backend/
tests/
FAQ/locales/i18n
```

Эти зоны должны загружаться только по маршруту задачи, а не при каждом старте.

### 1.2. Уже существующая AI-оптимизация

В архиве уже есть правильная база:

```text
docs/AI/READING_ENTRYPOINT.md
```

задаёт быстрый старт и запрещает случайное full-archive loading.

```text
docs/AI/READING_BUDGET.md
```

фиксирует Normal Start Core, Topic Core, Extended Start и Heavy Audit.

```text
docs/AI/TOPIC_READING_ROUTES.md
```

определяет тематические маршруты: withdraw, panels, exchange, shop/payment, TonConnect, FAQ, multilingual audit, admin/operator, CI/log repair, release audit, frontend visual shell, chat memory.

```text
docs/AI/ARCHIVE_FAST_MANIFEST.md
```

даёт короткую карту архива.

```text
docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
```

связывает намерения пользователя с нужными документами и кодовыми областями.

Новый Operator Kernel не должен ломать эти документы. Он должен сделать их машинно-исполняемыми.

---

## 2. Главная цель внедрения

Создать внутри EFHC Bot архива слой:

```text
ops/operator_kernel/
```

который будет выступать как локальный ускоритель AI-работы с архивом.

Он не заменяет ChatGPT и не является самостоятельной моделью. Его назначение:

```text
1. быстро понять задачу;
2. найти нужные документы и код;
3. собрать минимальный контекст;
4. подготовить план действий;
5. не читать лишнее;
6. не повторять уже сделанную работу;
7. не нарушать CI/cycle/canon-правила EFHC Bot;
8. ускорить следующие циклы.
```

---

## 3. Канонические ограничения EFHC Bot, которые нельзя нарушать

Operator Kernel обязан подчиняться существующим правилам архива.

### 3.1. Приоритет источников

Работать в порядке:

```text
1. Живая инструкция пользователя в текущем чате.
2. Текущий HEAD-архив, открытый напрямую.
3. AI docs как главный способ работы.
4. SSOT / NORM / memory-layer как continuity и правила.
5. Свежие logs_*.zip как главный источник фактов о CI для текущего HEAD.
```

### 3.2. CI-правило

Полные GitHub CI прогоны выполняет только пользователь.

Operator Kernel не имеет права:

```text
- заявлять, что локальный прогон равен GitHub CI;
- запускать полный CI как замену пользовательского CI;
- писать «всё зелёное» без свежего подтверждения логами, тестом или прямым аудитом;
- самовольно менять ci.yml или workflow-файлы внутри архива без отдельного поручения пользователя.
```

Разрешены только точечные вспомогательные проверки:

```text
- чтение кода;
- grep/ripgrep;
- compileall отдельного файла/модуля;
- targeted unit/static check изменённого участка;
- локальная сборка архива;
- targeted validator/guard по affected area.
```

### 3.3. Циклы и отчёты

Если Operator Kernel применяется для рабочего цикла, он должен помогать вести обязательные слои:

```text
docs/cycles/WORK_CYCLES.md
нужный диапазонный WORK_CYCLES_*.md
docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md
EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
HEALER_ATLAS.md
docs/healer/HEALER_ATLAS.md
docs/healer/HEALER_CASEBOOK.md
reports/REPORTS_INDEX.md
reports/change_cycle_*.md
```

### 3.4. Релизный ZIP

Релизный архив должен оставаться:

```text
FLAT
без обёртки-папки
без __pycache__
без .pytest_cache
без .mypy_cache
без .ruff_cache
без node_modules
без .next
без *.pyc / *.pyo
без временных ci_*.txt
```

### 3.5. Неприкосновенные продуктовые инварианты

Operator Kernel должен знать и проверять как hard invariants:

```text
global_id only
2 схемы БД: efhc_core, efhc_admin
active migration layer: backend/migrations/versions/0001_initial_release_schema.py
1 EFHC = 1 kWh
withdraw только из main_balance
bonus_balance не withdrawable
внутренние траты: сначала bonus, потом main
Bank ↔ User экономика
FAQ SSOT + русский FAQ как главный канон
route/service/model/migration/test sync
```

---

## 4. Что именно берём из Claude Code-подобной архитектуры

Берём не код, а алгоритмы.

### 4.1. Project Map

Быстрая карта архива:

```text
файл → тип → слой → размер → хеш → тема → связанные файлы
```

### 4.2. Query Classifier

Определение типа задачи:

```text
ci_log_repair
frontend_visual
backend_route_repair
admin_ui
shop_payment
withdraw
panels
exchange
faq
tonconnect
localization
cycle_docs
release_build
audit
prompt_continuation
archive_hygiene
```

### 4.3. Route Resolver

Преобразование типа задачи в точный список документов и кода.

Пример:

```text
admin_shop_payment
→ docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md
→ docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md
→ backend/app/routes/admin_shop_routes.py
→ backend/app/services/admin/admin_shop_service.py
→ backend/app/routes/shopfront_routes.py
→ frontend/src/pages/admin/...
→ frontend/src/components/admin/...
→ tests/architecture/*shop*admin*
→ latest reports with SHOP / ADMIN / PAYMENT
```

### 4.4. Context Capsule Builder

Сбор короткого пакета для ChatGPT:

```text
- задача пользователя;
- архивная версия;
- текущий цикл;
- релевантные каноны;
- релевантные NORM;
- найденные файлы;
- свежий отчёт/лог;
- affected code snippets;
- риски;
- разрешённые проверки;
- proposed patch plan.
```

### 4.5. Tool Registry

Единый реестр локальных инструментов:

```text
read_file
search_archive
grep_archive
build__file__map
classify_task
resolve_route
build_context_capsule
find_latest_report
find_healer_case
plan_patch
apply_patch
run_targeted_check
update_cycle_docs
build_release_zip
```

### 4.6. Patch Planner

Перед записью изменений всегда:

```text
1. определить affected files;
2. определить affected docs;
3. определить tests/guards;
4. подготовить diff plan;
5. применить только подтверждённые изменения;
6. обновить отчёты и memory layers;
7. собрать ZIP только после cleanup/guard.
```

### 4.7. Task State Machine

Состояние каждой операции:

```text
created
classified
context_built
planned
patched
validated
reported
released
failed
blocked
```

---

## 5. Что НЕ внедрять

Не внедрять:

```text
- прямое копирование исходников Claude Code;
- телеметрию;
- автообновления;
- marketplace плагинов;
- удалённые MCP-серверы по умолчанию;
- OAuth/keychain-логику;
- dangerously-skip-permissions;
- автономный агент, который сам меняет архив без задачи;
- full CI runner как замену GitHub CI пользователя;
- env scrub / очистку секретов из окружения.
```

Отдельно зафиксировано по условию пользователя:

```text
Environment secret scrubbing не внедрять.
```

---

## 6. Новая структура файлов

Добавить в архив:

```text
ops/operator_kernel/
  init.py
  file_map.py
  task_classifier.py
  route_resolver.py
  context_capsule.py
  tool_registry.py
  patch_planner.py
  validation_router.py
  task_state.py
  report_writer.py
  cache_manager.py
  archive_hygiene.py
  run_operator_cycle.py

ops/operator_kernel/config/
  routes.yaml
  layers.yaml
  tool_registry.yaml
  validation_routes.yaml
  heavy_paths.yaml
  invariants.yaml

ops/operator_kernel/cache/
  gitkeep

ops/operator_kernel/state/
  gitkeep
```

Добавить документы:

```text
docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md
docs/AI/EFHC_CONTEXT_CAPSULE_PROTOCOL.md
docs/NORM/EFHC_OPERATOR_KERNEL_PERMISSION_STANDARD.md
docs/NORM/EFHC_OPERATOR_KERNEL_PATCH_STANDARD.md
docs/NORM/EFHC_OPERATOR_KERNEL_VALIDATION_STANDARD.md
docs/GENERAL/EFHC_OPERATOR_KERNEL_IMPLEMENTATION_PLAN.md
docs/audits/EFHC_OPERATOR_KERNEL_ADOPTION_AUDIT.md
```

Добавить тесты/guards:

```text
tests/architecture/test_operator_kernel_routes.py
tests/architecture/test_operator_kernel_context_capsule.py
tests/architecture/test_operator_kernel_no_full_archive_default.py
tests/architecture/test_operator_kernel_ci_boundary.py
tests/architecture/test_operator_kernel_cycle_sync.py
tests/architecture/test_operator_kernel_archive_hygiene.py
```

---

## 7. Project Map

### 7.1. Назначение

`file_map.py` строит быстрый индекс архива.

Выходной файл:

```text
ops/operator_kernel/cache/file_map.json
```

Формат:

```json
{
  "archive_name": "EFHC_Bot_v169_14_cycle_1335_ci_logs_71056336346_repair.zip",
  "generated_at_utc": "2026-05-29T00:00:00Z",
  "files_total": 2351,
  "entries": [
    {
      "path": "docs/AI/TOPIC_READING_ROUTES.md",
      "layer": "AI",
      "kind": "routing_doc",
      "ext": ".md",
      "size_bytes": 12345,
      "sha256": "...",
      "topics": ["routing", "reading", "archive"],
      "heavy": false,
      "default_start_core": true
    }
  ]
}
```

### 7.2. Layer classification

Правила классификации:

```text
docs/AI/        → AI layer
docs/SSOT/      → SSOT layer
docs/NORM/      → NORM layer
docs/GENERAL/   → GENERAL layer
docs/audits/    → AUDIT layer
reports/        → REPORT layer
docs/cycles/    → CYCLE layer
backend/app/    → BACKEND_RUNTIME
frontend/       → FRONTEND_RUNTIME
ops/            → OPS_LAYER
tests/          → TEST_LAYER
```

### 7.3. Heavy paths

По умолчанию не грузить полностью:

```text
docs/audits/
reports/
docs/cycles/
frontend/
backend/
tests/
docs/SSOT/faq_ssot/
frontend/src/data/faq/catalogs.ts
```

Эти пути доступны только по маршруту задачи.

---

## 8. Query Classifier

### 8.1. Назначение

`task_classifier.py` принимает пользовательский запрос и возвращает класс задачи.

Пример:

```json
{
  "task_type": "ci_log_repair",
  "confidence": 0.94,
  "signals": ["logs_", "CI", "pytest", "repair"],
  "requires_logs": true,
  "requires_code_patch": true,
  "requires_docs_update": true,
  "requires_release_zip": true
}
```

### 8.2. Основные классы задач

```text
archive_orientation
ci_log_repair
frontend_visual_repair
frontend_dependency_repair
backend_route_repair
backend_service_repair
database_migration_review
admin_ui_recovery
shop_payment_repair
withdraw_repair
panels_repair
exchange_repair
faq_repair
localization_audit
tonconnect_wallet_repair
cycle_docs_repair
healer_memory_update
release_archive_build
prompt_continue_new_chat
full_audit
```

### 8.3. Сигналы классификации

```text
logs_*.zip, pytest, freezegun, npm build, CI → ci_log_repair
Admin, UI Kit, dashboard, sandbox, operator → admin_ui_recovery
Shop, payment, Web3, external payment → shop_payment_repair
Withdraw, withdrawal, TON payout → withdraw_repair
Panels, activation, countdown → panels_repair
FAQ, language, translation, catalog → faq_repair
Next.js, React, Tailwind, npm → frontend_dependency_repair
cycle, WORK_CYCLES, report → cycle_docs_repair
release ZIP, archive, clean → release_archive_build
```

---

## 9. Route Resolver

### 9.1. Назначение

`route_resolver.py` превращает `task_type` в список файлов для чтения.

Он должен использовать существующие документы:

```text
docs/AI/TOPIC_READING_ROUTES.md
docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
docs/GENERAL/MASTER_DOCUMENT_INDEX.csv
docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md
docs/NORM/TESTS_CATALOG.md
```

### 9.2. Базовый старт

Для любой задачи сначала читается минимальный Start Core:

```text
docs/AI/READING_ENTRYPOINT.md
docs/AI/READING_BUDGET.md
docs/AI/TOPIC_READING_ROUTES.md
docs/AI/ARCHIVE_FAST_MANIFEST.md
docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
docs/AI/AI_OPERATOR_RULES_EFHC.md
docs/SSOT/SSOT_INDEX.md
docs/NORM/ARCHITECTURAL_LOCKS.md
```

Но Operator Kernel должен не включать эти файлы целиком в каждый capsule, а извлекать из них только релевантные секции.

### 9.3. CI/log repair route

Для `ci_log_repair`:

```text
1. свежий logs_*.zip пользователя;
2. docs/AI/AI_OPERATOR_RULES_EFHC.md — CI boundary;
3. docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md;
4. docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md;
5. requirements-test.txt;
6. ci.yml — только если пользователь прямо просит обновить CI;
7. failing test file from log;
8. related docs/audits/CI_LOGS_*;
9. latest reports/change_cycle_*;
10. relevant architecture guard.
```

### 9.4. Admin UI route

Для `admin_ui_recovery`:

```text
1. docs/AI/TOPIC_READING_ROUTES.md — Admin/operator contour;
2. docs/admin/* relevant 1326-1335;
3. docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md;
4. frontend/src/pages/admin/*;
5. frontend/src/components/admin/*;
6. backend/app/routes/admin_*;
7. backend/app/services/admin/*;
8. tests/architecture/*admin*;
9. latest admin reports;
10. active cycle range 1321-1350.
```

### 9.5. Shop payment route

Для `shop_payment_repair`:

```text
1. docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md;
2. docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md;
3. docs/SSOT/TON_MEMO_SPEC.md;
4. backend/app/routes/admin_shop_routes.py;
5. backend/app/routes/shop_routes.py;
6. backend/app/routes/shopfront_routes.py;
7. backend/app/services/admin/admin_shop_service.py;
8. backend/app/services/shop_service.py;
9. backend/app/models/shop_models.py;
10. frontend shop/admin surfaces;
11. shop/payment tests;
12. latest shop/payment reports.
```

### 9.6. Frontend dependency route

Для `frontend_dependency_repair`:

```text
1. frontend/package.json;
2. frontend/package-lock.json, если есть;
3. docs/backend/BACKEND_DEPENDENCY_RUNTIME_POLICY.md, если касается CI install;
4. docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md;
5. docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md;
6. docs/audits/FRONTEND_* dependency/migration docs;
7. frontend config files;
8. exact failed build file from logs;
9. latest frontend reports.
```

---

## 10. Context Capsule Builder

### 10.1. Назначение

`context_capsule.py` собирает компактный пакет для AI.

Выходной файл:

```text
ops/operator_kernel/cache/context_capsule_latest.md
```

### 10.2. Формат context capsule

```markdown
# EFHC Context Capsule

## Task
...

## Archive
EFHC_Bot_v169_14_cycle_1335_ci_logs_71056336346_repair.zip

## Task classification
- type: admin_ui_recovery
- confidence: 0.91

## Active cycle status
- last completed: 1335
- next: 1336 — Shop admin actions and Web3 payment separation on UI Kit

## Required rules
- CI runs only by user
- no full archive reading by default
- do not modify ci.yml unless explicit user request
- update reports/cycles/healer when confirmed changes are made

## Relevant canon
...

## Relevant files
...

## Affected code snippets
...

## Latest reports
...

## Proposed action
...

## Allowed checks
...

## Forbidden checks
...
```

### 10.3. Token budget

Целевой размер:

| Режим | Размер |
|---|---:|
| quick answer | 10k–40k tokens |
| focused patch | 40k–120k tokens |
| CI/log repair | 60k–180k tokens |
| frontend visual task | 80k–220k tokens |
| release audit | 150k–400k tokens |
| explicit full audit | по прямому запросу |

Главная цель: заменить 500k–1.5M токенов startup reading на 30k–150k токенов точного capsule.

---

## 11. Cache Manager

### 11.1. Назначение

`cache_manager.py` хранит вычисленные карты и результаты.

Кеши:

```text
ops/operator_kernel/cache/file_map.json
ops/operator_kernel/cache/topic_index.json
ops/operator_kernel/cache/symbol_index.json
ops/operator_kernel/cache/route_index.json
ops/operator_kernel/cache/test_index.json
ops/operator_kernel/cache/report_index.json
ops/operator_kernel/cache/cycle_index.json
ops/operator_kernel/cache/healer_index.json
ops/operator_kernel/cache/context_capsule_latest.md
```

### 11.2. Инвалидация кеша

Кеш считается устаревшим, если изменились:

```text
- размер файла;
- sha256 файла;
- mtime при распаковке;
- имя архива;
- reports/REPORTS_INDEX.md;
- docs/cycles/WORK_CYCLES.md;
- docs/AI/TOPIC_READING_ROUTES.md;
- docs/AI/ARCHIVE_SYNAPTIC_LINKS.md;
- docs/GENERAL/MASTER_DOCUMENT_INDEX.csv.
```

### 11.3. Почему кеш ускорит работу

Без кеша AI каждый раз заново ищет:

```text
какие файлы есть
какие документы активны
где последние отчёты
какой цикл текущий
какие тесты связаны с темой
какие route/service/model связаны
```

С кешем это уже готовые lookup-таблицы.

---

## 12. Symbol / Endpoint / Route Index

### 12.1. Backend index

Нужно создать индекс:

```text
ops/operator_kernel/cache/backend_symbol_index.json
```

Содержит:

```text
FastAPI routers
route paths
HTTP methods
service functions
CRUD modules
schemas
models
migration table references
```

Пример:

```json
{
  "route": "/admin/shop/orders",
  "method": "GET",
  "file": "backend/app/routes/admin_shop_routes.py",
  "service_candidates": [
    "backend/app/services/admin/admin_shop_service.py"
  ],
  "models": [
    "backend/app/models/shop_models.py"
  ],
  "tests": [
    "tests/architecture/test_admin_shop_*.py"
  ]
}
```

### 12.2. Frontend index

Нужно создать индекс:

```text
ops/operator_kernel/cache/frontend_route_index.json
```

Содержит:

```text
pages
components
admin components
API clients
i18n dictionaries
visual registry links
tests/guards
```

### 12.3. Docs index

Нужно создать индекс:

```text
ops/operator_kernel/cache/docs_semantic_index.json
```

Содержит:

```text
document title
layer
status
topics
cycle numbers
version markers
related files
must-read sections
forbidden/default-heavy flag
```

---

## 13. Validation Router

### 13.1. Назначение

`validation_router.py` выбирает точечные проверки по affected files.

Примеры:

| Изменённый путь | Проверка |
|---|---|
| `backend/app/...py` | `python -m compileall <file>` + related targeted tests |
| `frontend/...tsx` | frontend typecheck/build route по задаче, не full CI |
| `docs/AI/...md` | architecture guard для AI docs |
| `docs/SSOT/...md` | SSOT index/canon guard |
| `docs/cycles/...md` | cycle sync guard |
| `ci.yml` | только если пользователь прямо поручил |
| `requirements-test.txt` | dependency sanity guard |

### 13.2. CI boundary

Validation Router обязан всегда маркировать результат:

```text
LOCAL_AUX_CHECK_ONLY
```

и никогда не писать:

```text
GitHub CI green
```

без свежих логов пользователя.

---

## 14. Patch Planner

### 14.1. Назначение

`patch_planner.py` создаёт план изменений до записи файлов.

Формат:

```json
{
  "task_id": "op_20260529_001",
  "task_type": "shop_payment_repair",
  "affected_files": [
    "frontend/src/pages/admin/shop.tsx",
    "docs/audits/SHOP_ADMIN_PAYMENT_SEPARATION.md",
    "reports/change_cycle_2026-05-29_v169_15_cycle_1336_shop_admin_actions.md"
  ],
  "forbidden_files": [],
  "requires_user_ci": true,
  "requires_cycle_update": true,
  "requires_healer_update": true,
  "allowed_checks": [
    "targeted grep",
    "frontend typecheck if dependencies present",
    "architecture guard for added doc"
  ]
}
```

### 14.2. Запрещённые silent changes

Patch Planner должен блокировать:

```text
- удаление docs/SSOT без прямого указания;
- удаление reports без прямого указания;
- сужение архива;
- изменение CI без прямого указания;
- изменение migration strategy без task route;
- изменение FAQ canon без FAQ route;
- изменение публичной экономики без SSOT route.
```

---

## 15. Task State Machine

### 15.1. Назначение

`task_state.py` ведёт машинную память выполнения.

Файл состояния:

```text
ops/operator_kernel/state/tasks.jsonl
```

Запись:

```json
{
  "task_id": "op_20260529_001",
  "archive": "EFHC_Bot_v169_14_cycle_1335_ci_logs_71056336346_repair.zip",
  "status": "reported",
  "task_type": "operator_kernel_tz",
  "cycle": null,
  "read_files": [
    "README.md",
    "docs/AI/READING_ENTRYPOINT.md",
    "docs/AI/TOPIC_READING_ROUTES.md"
  ],
  "changed_files": [
    "docs/GENERAL/EFHC_OPERATOR_KERNEL_IMPLEMENTATION_PLAN.md"
  ],
  "checks": [],
  "result": "TZ prepared"
}
```

### 15.2. Статусы

```text
created
classified
routed
context_built
planned
patched
validated
reported
released
blocked
failed
```

---

## 16. Report Writer

### 16.1. Назначение

`report_writer.py` помогает создавать отчёты цикла по правилам EFHC.

Он должен уметь формировать 10 пунктов:

```text
1. Что упало
2. Где
3. Root cause
4. Что исправлено
5. Сколько ошибок всего
6. Сколько исправил
7. Сколько осталось
8. Какие файлы изменены
9. Какой ZIP выдан
10. Что осталось сделать или закончил
```

### 16.2. Отчёты не должны быть пустыми

Пустой или краткий cycle-report считается деградацией control-layer.

Report Writer должен требовать:

```text
- input;
- confirmed failure or task;
- changed files;
- result;
- next cycle;
- archive name;
- local checks status;
- GitHub CI status only if provided by user logs.
```

---

## 17. Archive Hygiene

### 17.1. Назначение

`archive_hygiene.py` проверяет ZIP перед выдачей.

Проверки:

```text
- FLAT structure;
- no wrapper folder;
- no __pycache__;
- no *.pyc;
- no .pytest_cache;
- no .mypy_cache;
- no .ruff_cache;
- no node_modules;
- no .next;
- no temporary ci_*.txt;
- required anchors exist;
- docs/SSOT exists;
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md exists;
- HEALER_ATLAS.md exists;
- reports/ exists;
```

### 17.2. Integration with existing canon guard

Использовать существующий:

```text
python ops/canon_guard.py
```

Но не заменять его. Operator Kernel должен только маршрутизировать и объяснять, какой guard нужен.

---

## 18. Конфигурация маршрутов

Создать:

```text
ops/operator_kernel/config/routes.yaml
```

Пример:

```yaml
start_core:
  - docs/AI/READING_ENTRYPOINT.md
  - docs/AI/READING_BUDGET.md
  - docs/AI/TOPIC_READING_ROUTES.md
  - docs/AI/ARCHIVE_FAST_MANIFEST.md
  - docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
  - docs/AI/AI_OPERATOR_RULES_EFHC.md
  - docs/SSOT/SSOT_INDEX.md
  - docs/NORM/ARCHITECTURAL_LOCKS.md

tasks:
  ci_log_repair:
    docs:
      - docs/AI/AI_OPERATOR_RULES_EFHC.md
      - docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md
      - docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md
    code_globs:
      - requirements-test.txt
      - tests/**/*.py
      - ops/**/*.py
    restricted:
      - ci.yml
    note: "ci.yml editable only by explicit user request"

  admin_ui_recovery:
    docs:
      - docs/AI/TOPIC_READING_ROUTES.md
      - docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md
    code_globs:
      - frontend/src/pages/admin/**/*.tsx
      - frontend/src/components/admin/**/*.tsx
      - backend/app/routes/admin_*.py
      - backend/app/services/admin/*.py
      - tests/architecture/*admin*.py

  shop_payment_repair:
    docs:
      - docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md
      - docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md
      - docs/SSOT/TON_MEMO_SPEC.md
    code_globs:
      - backend/app/routes/*shop*.py
      - backend/app/services/**/*shop*.py
      - backend/app/models/*shop*.py
      - frontend/src/**/*shop*.tsx
      - tests/**/*shop*.py
```

---

## 19. Реестр инструментов

Создать:

```text
ops/operator_kernel/config/tool_registry.yaml
```

Инструменты:

```yaml
tools:
  read_file:
    mode: read_only
    description: "Read a selected file"

  search_archive:
    mode: read_only
    description: "Search by path/name/content"

  build__file__map:
    mode: read_only_output_cache
    description: "Create file_map.json"

  classify_task:
    mode: read_only_output_cache
    description: "Classify user request"

  resolve_route:
    mode: read_only_output_cache
    description: "Resolve exact reading route"

  build_context_capsule:
    mode: read_only_output_cache
    description: "Build compact AI context"

  plan_patch:
    mode: dry_run
    description: "Create patch plan without writing"

  apply_patch:
    mode: write
    description: "Apply approved patch"

  run_targeted_check:
    mode: local_aux_check
    description: "Run narrow local check only"

  build_release_zip:
    mode: release
    description: "Clean and build flat release archive"
```

---

## 20. Permission Standard

Создать:

```text
docs/NORM/EFHC_OPERATOR_KERNEL_PERMISSION_STANDARD.md
```

Режимы:

```text
READ_ONLY
DRY_RUN
PATCH_PLANNED
APPROVED_WRITE
LOCAL_AUX_CHECK
RELEASE_BUILD
BLOCKED
```

Матрица:

| Действие | Режим по умолчанию |
|---|---|
| Читать документы | READ_ONLY |
| Строить file map | READ_ONLY |
| Строить context capsule | READ_ONLY |
| Планировать патч | DRY_RUN |
| Менять код | APPROVED_WRITE |
| Менять docs/AI | APPROVED_WRITE |
| Менять docs/SSOT | APPROVED_WRITE + SSOT route |
| Менять ci.yml | BLOCKED без прямого запроса |
| Запускать полный CI | BLOCKED |
| Запускать targeted check | LOCAL_AUX_CHECK |
| Собирать release ZIP | RELEASE_BUILD |

---

## 21. Точечные проверки вместо полного CI

Operator Kernel должен уметь выбирать узкую проверку.

### 21.1. Python backend

```text
python -m compileall backend/app/path/to/file.py -q
pytest tests/path/to/targeted_test.py -q
```

Только если тест связан с изменённым участком.

### 21.2. Frontend

```text
cd frontend && npm run typecheck
```

или более узкая проверка, если появится локальный script.

Важно: это не GitHub CI.

### 21.3. Docs guard

```text
python ops/canon_guard.py
```

или targeted architecture tests.

---

## 22. Индекс последних отчётов

Создать:

```text
ops/operator_kernel/cache/report_index.json
```

Формат:

```json
{
  "latest_report": "reports/change_cycle_2026-05-27_v169_14_cycle_1335_ci_logs_71056336346_repair.md",
  "by_topic": {
    "ci": ["..."],
    "admin": ["..."],
    "shop": ["..."],
    "frontend": ["..."]
  },
  "by_cycle": {
    "1335": "reports/change_cycle_2026-05-27_v169_14_cycle_1335_ci_logs_71056336346_repair.md"
  }
}
```

Назначение: быстро находить последний relevant report без чтения всех 554 reports.

---

## 23. Индекс циклов

Создать:

```text
ops/operator_kernel/cache/cycle_index.json
```

Должен фиксировать:

```text
last completed cycle
next cycle
active range file
shifted cycles
done/todo counts
cycle-to-report link
cycle-to-version link
```

Для текущего архива:

```text
1335 — CI logs 71056336346 repair: test dependency bootstrap lock
next: 1336 — Shop admin actions and Web3 payment separation on UI Kit
active range: docs/cycles/WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md
```

---

## 24. Healer index

Создать:

```text
ops/operator_kernel/cache/healer_index.json
```

Должен связывать:

```text
ошибка / болезнь
→ Healer card
→ report
→ tests/guards
→ affected files
→ recurrence status
```

Цель: при повторной ошибке не проводить полный поиск, а сразу поднимать старую карту болезни.

---

## 25. Master Document Index adapter

В архиве есть:

```text
docs/GENERAL/MASTER_DOCUMENT_INDEX.csv
```

Operator Kernel должен читать его как один из источников навигации, но не считать абсолютной истиной без проверки файла.

Создать адаптер:

```text
ops/operator_kernel/master_index_adapter.py
```

Функции:

```text
load_master_index()
find_docs_by_topic(topic)
find_docs_by_layer(layer)
find_stale_entries()
compare_index_with_actual_files()
```

---

## 26. Интеграция с существующими AI-документами

### 26.1. `docs/AI/READING_ENTRYPOINT.md`

Добавить секцию:

```markdown
## Operator Kernel acceleration

If `ops/operator_kernel/cache/file_map.json` exists and is fresh, use it
before broad archive navigation. The kernel does not replace Start Core;
it resolves Start Core and Topic Core into a compact context capsule.
```

### 26.2. `docs/AI/READING_BUDGET.md`

Добавить:

```markdown
## Operator Capsule Budget

For repeated tasks, prefer generated context capsules:
- quick answer: 10k–40k tokens;
- focused patch: 40k–120k tokens;
- log repair: 60k–180k tokens.
```

### 26.3. `docs/AI/TOPIC_READING_ROUTES.md`

Добавить машинную ссылку:

```markdown
Machine route config:
`ops/operator_kernel/config/routes.yaml`
```

### 26.4. `docs/AI/ARCHIVE_FAST_MANIFEST.md`

Добавить:

```markdown
Generated file map:
`ops/operator_kernel/cache/file_map.json`
```

### 26.5. `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`

Добавить связь:

```markdown
Operator Kernel route resolver uses this file as human-readable synaptic map.
Machine-readable routes live in `ops/operator_kernel/config/routes.yaml`.
```

---

## 27. Интеграция с Makefile

Сейчас Makefile содержит:

```makefile
canon:
	python ops/canon_guard.py
```

Добавить команды:

```makefile
.PHONY: operator-map operator-capsule operator-plan operator-check operator-clean

operator-map:
	python ops/operator_kernel/run_operator_cycle.py --mode map

operator-capsule:
	python ops/operator_kernel/run_operator_cycle.py --mode capsule

operator-plan:
	python ops/operator_kernel/run_operator_cycle.py --mode plan

operator-check:
	python ops/operator_kernel/run_operator_cycle.py --mode targeted-check

operator-clean:
	python ops/operator_kernel/run_operator_cycle.py --mode clean-cache
```

Не добавлять команду full CI.

---

## 28. CLI интерфейс Operator Kernel

Файл:

```text
ops/operator_kernel/run_operator_cycle.py
```

Команды:

```bash
python ops/operator_kernel/run_operator_cycle.py --mode map
python ops/operator_kernel/run_operator_cycle.py --mode classify --query "..."
python ops/operator_kernel/run_operator_cycle.py --mode route --task-type admin_ui_recovery
python ops/operator_kernel/run_operator_cycle.py --mode capsule --query "..."
python ops/operator_kernel/run_operator_cycle.py --mode plan --query "..."
python ops/operator_kernel/run_operator_cycle.py --mode targeted-check --changed-file path
python ops/operator_kernel/run_operator_cycle.py --mode report --task-id op_...
```

Вывод должен быть:

```text
- краткий summary в stdout;
- полный результат в ops/operator_kernel/cache/ или state/;
- без огромных дампов в консоль.
```

---

## 29. Целевой эффект ускорения

### 29.1. Текущий режим

Сейчас при сложной задаче AI часто вынужден читать:

```text
AI docs
SSOT docs
NORM docs
cycles
reports
audits
backend
frontend
tests
logs
```

Это легко превращается в сотни файлов.

### 29.2. После внедрения

Для типовой задачи AI будет читать:

```text
1 context capsule
5–20 точных документов
3–15 точных code files
1–5 тестов/guards
1–3 последних reports
```

### 29.3. Оценка ускорения

| Тип задачи | Ожидаемое ускорение |
|---|---:|
| Быстрый вопрос по архиву | 3–5x |
| CI/log repair | 2–4x |
| Frontend/admin visual cycle | 2–5x |
| Документная актуализация | 3–7x |
| Поиск текущего цикла/отчёта | 5–10x |
| Продолжение работы в новом чате | 4–8x |
| Release/archive hygiene | 2–4x |

Реалистичная общая цель: **ускорение в 3–5 раз** на повторяющихся EFHC-задачах.

При хорошем кешировании reports/cycles/docs возможно **до 7–10 раз** для навигационных операций.

---

## 30. Порядок внедрения по циклам

### Цикл A — Kernel Foundation

Добавить:

```text
ops/operator_kernel/file_map.py
ops/operator_kernel/cache_manager.py
ops/operator_kernel/run_operator_cycle.py
ops/operator_kernel/config/layers.yaml
ops/operator_kernel/config/heavy_paths.yaml
```

Результат:

```text
file_map.json
basic layer classification
heavy paths detection
```

### Цикл B — Routing Foundation

Добавить:

```text
task_classifier.py
route_resolver.py
routes.yaml
```

Результат:

```text
query → task_type → route files
```

### Цикл C — Context Capsule

Добавить:

```text
context_capsule.py
EFHC_CONTEXT_CAPSULE_PROTOCOL.md
```

Результат:

```text
context_capsule_latest.md
```

### Цикл D — Report/Cycle/Healer Index

Добавить:

```text
report_index.json
cycle_index.json
healer_index.json
report_writer.py
```

Результат:

```text
быстрый поиск latest report, active cycle, healer cases
```

### Цикл E — Patch Planner

Добавить:

```text
patch_planner.py
EFHC_OPERATOR_KERNEL_PATCH_STANDARD.md
```

Результат:

```text
affected files plan before modifications
```

### Цикл F — Validation Router

Добавить:

```text
validation_router.py
EFHC_OPERATOR_KERNEL_VALIDATION_STANDARD.md
```

Результат:

```text
changed files → targeted checks
```

### Цикл G — Archive Hygiene / Release Support

Добавить:

```text
archive_hygiene.py
operator-clean / operator-check commands
```

Результат:

```text
release ZIP readiness precheck
```

### Цикл H — AI Docs Integration

Обновить:

```text
docs/AI/READING_ENTRYPOINT.md
docs/AI/READING_BUDGET.md
docs/AI/TOPIC_READING_ROUTES.md
docs/AI/ARCHIVE_FAST_MANIFEST.md
docs/AI/ARCHIVE_SYNAPTIC_LINKS.md
```

Результат:

```text
человекочитаемые AI docs знают о машинном Operator Kernel
```

---

## 31. Acceptance Criteria

### 31.1. Функциональные критерии

Operator Kernel считается внедрённым, если:

```text
1. строит file_map.json;
2. классифицирует минимум 12 типов задач;
3. строит route files по задаче;
4. собирает context capsule;
5. создаёт report_index.json;
6. создаёт cycle_index.json;
7. создаёт healer_index.json;
8. планирует patch без записи;
9. выбирает targeted checks;
10. не читает heavy paths по умолчанию;
11. не меняет ci.yml без явного поручения;
12. не запускает full CI;
13. обновляет AI/NORM docs о своём существовании;
14. имеет architecture guards.
```

### 31.2. Тестовые критерии

Должны проходить:

```text
python -m pytest tests/architecture/test_operator_kernel_routes.py -q
python -m pytest tests/architecture/test_operator_kernel_context_capsule.py -q
python -m pytest tests/architecture/test_operator_kernel_no_full_archive_default.py -q
python -m pytest tests/architecture/test_operator_kernel_ci_boundary.py -q
python -m pytest tests/architecture/test_operator_kernel_cycle_sync.py -q
python -m pytest tests/architecture/test_operator_kernel_archive_hygiene.py -q
```

Плюс:

```text
python ops/canon_guard.py
```

если цикл включает изменение docs/canon/structure.

---

## 32. Пример результата для следующего цикла 1336

Задача:

```text
1336 — Shop admin actions and Web3 payment separation on UI Kit
```

Operator Kernel должен классифицировать:

```json
{
  "task_type": "shop_payment_repair",
  "secondary_type": "admin_ui_recovery",
  "cycle": 1336
}
```

Route:

```text
docs/cycles/WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md
docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md
docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md
docs/SSOT/TON_MEMO_SPEC.md
docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md
backend/app/routes/admin_shop_routes.py
backend/app/services/admin/admin_shop_service.py
backend/app/routes/shopfront_routes.py
backend/app/services/shop_service.py
frontend/src/pages/admin/*shop*.tsx
frontend/src/components/admin/*
tests/architecture/*shop*.py
latest shop/admin/payment reports
```

Context capsule должен выдать:

```text
- что именно нужно разделить: admin actions vs Web3 payment flow;
- какие UI Kit компоненты уже существуют;
- какие backend routes нельзя смешивать;
- какие публичные raw payload детали нельзя показывать;
- какие tests/guards должны быть затронуты;
- какие cycle/report/healer docs нужно обновить.
```

---

## 33. Необходимые guards

### 33.1. No full archive default

Тест должен доказать:

```text
Operator Kernel не включает docs/audits/*, reports/*, full backend, full frontend в default capsule.
```

### 33.2. CI boundary

Тест должен доказать:

```text
ci.yml находится в restricted zone;
full CI command отсутствует;
GitHub CI verdict не генерируется локально.
```

### 33.3. Cycle sync

Тест должен доказать:

```text
если task_type требует рабочего цикла, plan содержит reports + WORK_CYCLES + Q&A/Healer hooks.
```

### 33.4. Context capsule

Тест должен доказать:

```text
capsule содержит archive, task_type, route, relevant rules, allowed checks, forbidden checks.
```

### 33.5. Archive hygiene

Тест должен доказать:

```text
release precheck блокирует transient junk и wrapper folder.
```

---

## 34. Минимальная реализация MVP

MVP Operator Kernel может быть простым Python-слоем без внешних зависимостей.

Минимальные файлы:

```text
ops/operator_kernel/init.py
ops/operator_kernel/file_map.py
ops/operator_kernel/task_classifier.py
ops/operator_kernel/route_resolver.py
ops/operator_kernel/context_capsule.py
ops/operator_kernel/run_operator_cycle.py
ops/operator_kernel/config/routes.yaml
ops/operator_kernel/config/heavy_paths.yaml
```

Минимальные команды:

```bash
python ops/operator_kernel/run_operator_cycle.py --mode map
python ops/operator_kernel/run_operator_cycle.py --mode capsule --query "CI logs repair"
```

Минимальный результат:

```text
ops/operator_kernel/cache/file_map.json
ops/operator_kernel/cache/context_capsule_latest.md
```

---

## 35. Будущее развитие

После MVP можно добавить:

```text
- AST/symbol index for Python;
- TSX component dependency graph;
- route/service/model/test graph;
- report summarizer;
- healer recurrence detector;
- FAQ locale diff index;
- admin UI surface registry;
- release ZIP builder integration;
- semantic chunking docs/index;
- vector index optional, если будет отдельное решение.
```

Не добавлять без отдельного решения:

```text
- external LLM calls from inside archive;
- MCP servers;
- plugin marketplace;
- telemetry;
- autonomous background agent.
```

---

## 36. Итоговая формула

```text
EFHC Bot archive
→ existing AI/SSOT/NORM control-layer
→ Operator Kernel file map
→ query classifier
→ route resolver
→ context capsule
→ patch planner
→ targeted validation
→ cycle/report/healer sync
→ faster ChatGPT work
```

Главный эффект:

```text
ChatGPT получает не весь архив,
а точную context capsule по задаче.
```

Для EFHC Bot это особенно важно, потому что архив содержит:

```text
1239 markdown-документов
652 python-файла
554 reports
534 audit-документа
278 tests
234 frontend-файла
```

Без Kernel это создаёт избыточное чтение. С Kernel работа переходит в режим:

```text
не «прочитать всё»,
а «прочитать правильное».
```

Целевой практический результат: **ускорение работы ChatGPT с EFHC Bot архивом в 3–5 раз**, а для навигации по циклам, reports, routes и docs — до **7–10 раз**.
