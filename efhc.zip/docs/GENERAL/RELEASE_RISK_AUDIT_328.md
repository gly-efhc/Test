# RELEASE RISK AUDIT 328

## Main remaining risks

- absence of live payment proof
- absence of post-proof verification
- unresolved skins/facade cleanup debts
- unresolved broader healer backlog outside the browser-shop line
