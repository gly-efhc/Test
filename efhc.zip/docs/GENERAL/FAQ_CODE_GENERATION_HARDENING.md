# FAQ Code Generation Hardening

Status: ACTIVE
Cycle: 105

## Confirmed hardening

- Generator source: `ops/scripts/generate_faq_catalogs_from_ssot.py`
- Runtime target: `frontend/src/data/faq/catalogs.ts`
- Governance gate: `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`

## Validation now enforced before rebuild

- approval manifest exists;
- `entries_total` matches real entry count;
- each approval entry contains the required fields;
- all 13 active SSOT FAQ JSON files keep 20 sections;
- all 13 active SSOT FAQ JSON files keep 250 Q/A;
- section 13 stays `Hub` in every active SSOT JSON.

## Current HEAD audit note

- generator file присутствует: `ops/scripts/generate_faq_catalogs_from_ssot.py`
- approval files присутствуют в `docs/SSOT/faq_ssot/`

## Result

Runtime rebuild is no longer treated as a blind transform from JSON to
TypeScript. It now depends on a validated governance manifest plus
validated SSOT inventory.
