# USDT FRONTEND BLOCKCHAIN ADAPTER PLAN — work pass

Статус: GENERAL.
Цель: спроектировать целевой frontend-слой для real USDT
jetton transfer без преждевременного включения live flow.

## Целевой новый слой

Предлагаемый target-path:
- `frontend/src/lib/ton/jetton-transfer.ts`
- `frontend/src/lib/ton/units.ts`
- `frontend/src/lib/ton/usdt-transfer.ts`

## Целевые функции

### F1 — `toJettonUnits(value, decimals)`
Назначение:
- перевод UI-значения в on-chain units.

### F2 — `fromJettonUnits(value, decimals)`
Назначение:
- обратный показ on-chain amount в UI.

### F3 — `resolveSenderJettonWallet(...)`
Назначение:
- по owner wallet + jetton master получить sender jetton wallet.

### F4 — `buildUsdtJettonTransferBody(...)`
Назначение:
- собрать TEP-74 body для реального USDT transfer.

### F5 — `buildUsdtTonConnectMessage(...)`
Назначение:
- собрать TonConnect message в sender jetton wallet.

### F6 — `buildUsdtForwardPayload(...)`
Назначение:
- кодировать payload из server-issued intent canon.

## Врезка в текущий frontend

Текущая точка интеграции:
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`

Правильный принцип:
- BrowserShopPage не должен знать детали TEP-74 сериализации;
- страница должна вызывать только новый adapter layer.

## Почему нужен отдельный adapter

Без отдельного слоя проект получит:
- UI + blockchain coupling;
- повторное расползание pseudo-payload логики;
- сложность тестирования d6/d8 и payload packing.

С adapter layer проект получает:
- изолированный blockchain helper;
- отдельные guard-tests;
- возможность оставить live gating до полного readiness proof.

## Границы этого цикла

В этом цикле только architecture plan.
Live implementation и dependency install в этот цикл не входят.
