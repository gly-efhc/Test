# BROWSER SHOP RELEASE GATE V5

## Green only if all are true

- backend line72 = 0
- tests line72 = 0
- compile checks green
- frontend build proof present
- browser-shop flow compile/build proof present
- live payment proof captured
- post-proof verification captured
- active healer debts accepted or treated to the current release threshold

## Current state

- not green yet;
- missing live payment proof and post-proof verification.
