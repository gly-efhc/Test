# Skin switcher implementation wave 1

Date: 2026-03-28
Cycle: 92
Status: ACTIVE
Scope: runtime/API layer only

## Confirmed baseline

After cycle 91 the concept layer was fixed, but the active implementation
still used only the mixed legacy surface:
- `GET /skins/my`
- `POST /skins/activate/{skin_id}`
- `POST /skins/buy/{skin_id}`
- `price_efhc`
- `purchased_at`

That surface was not a clean switcher-facing runtime/API layer.

## Implementation added in cycle 92

### New switcher-facing API

- `GET /skins/switcher`
- `POST /skins/switcher/activate/{skin_id}`

### New switcher-facing shape

- `current_level`
- `available_skin_ids`
- `active_skin_id`
- `items[]`
  - `skin_id`
  - `title`
  - `asset_path`
  - `is_unlocked`
  - `is_active`

### Synchronization rule

The implementation now synchronizes `active_skin_id` with the progression
canon:
- unlocked set is derived from the 12-level progression scale;
- if stored `active_skin_id` is not in the unlocked set, it is rewritten to
  the highest unlocked skin;
- if no row exists, a canonical row is created.

## What remains intentionally unchanged

Cycle 92 does not yet remove the legacy commerce bridge:
- `POST /skins/buy/{skin_id}`
- `price_efhc`
- `purchased_at`
- history in `user_skins`

Those traces remain for later cleanup waves.

## Result

Skin switcher now has its own runtime/API layer, separate from Hub and
separate from the old purchase-oriented surface.
