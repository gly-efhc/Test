# EFHC_OPERATOR_KERNEL_IMPLEMENTATION_PLAN

Status: IMPLEMENTED MVP. work pass. Archive: v169_15.

## Implemented in work pass

Added `ops/operator_kernel/` with:

- file map builder;
- task classifier;
- route resolver;
- context capsule builder;
- tool registry;
- patch planner;
- validation router;
- task state JSONL storage;
- report writer;
- cache manager;
- archive hygiene checker;
- master document index adapter;
- CLI entrypoint `run_operator_cycle.py`.

Added machine-readable configs:

- `routes.yaml`;
- `layers.yaml`;
- `tool_registry.yaml`;
- `validation_routes.yaml`;
- `heavy_paths.yaml`;
- `invariants.yaml`.

Added cache outputs:

- `file_map.json`;
- `context_capsule_latest.md`;
- `report_index.json`;
- `cycle_index.json`;
- `healer_index.json`.

## Next optional hardening

Future cycles may add AST symbol extraction, TSX dependency graph,
FAQ locale diff index and richer report summarization.
