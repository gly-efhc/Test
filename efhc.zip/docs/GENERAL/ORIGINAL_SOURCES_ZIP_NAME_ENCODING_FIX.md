# ORIGINAL SOURCES ZIP NAME ENCODING FIX — work pass

Date: 2026-05-31
Archive: `v169_31`

## Problem

Two files in:

`docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/`

had very long mojibake / non-ASCII names. On Linux unzip these names exceeded
filesystem filename limits and caused extraction failure before the full archive
could be opened.

## Decision

Do not weaken the retention guard to `>= 13`. Preserve the stronger guarantee:
all 15 markdown source files must extract and remain visible.

The two problematic filenames were renamed to ASCII transliteration:

1. `ai_self_recovery_protection_points.md`
2. `efhc_bot_tz_lost_functions_recovery.md`

## Boundary

Only filenames changed. File contents were preserved. The original-source layer
remains markdown-only:

- no `pdf/` folder;
- no `text/` folder;
- `md/` contains exactly 15 `.md` files.

## Verification

Expected checks:

```bash
unzip -q efhc.zip -d /tmp/t
ls /tmp/t/docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/ | wc -l
pytest tests/architecture/test_document_retention_guard.py -q
pytest tests/architecture/test_zip_encoding_wallets_crud_hotfix.py -q
```

Expected result: 15 files and passing guards.
