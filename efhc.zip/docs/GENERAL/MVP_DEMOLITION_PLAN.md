# SUPERSEDED CURRENT STATE

This historical TON-only demolition plan is retained for audit history.
It does not override the current TON/GRAM and USDT Browser Shop canon.

---

# MVP demolition norm

## Scope
The external storefront must stay on a thin TON-only MVP path until the install/build/runtime chain is proven.

## Mandatory cuts
- Browser storefront must not expose live USDT checkout UI.
- Browser storefront must not import heavy `frontend/src/lib/ton/*` runtime helpers.
- VIP acquisition must not appear as a storefront catalog item.
- Telegram Hub remains a handoff shell, not a checkout surface.

## Allowed MVP path
- Signed Telegram handoff token.
- External storefront bootstrap.
- TON-only custom EFHC top-up.
- TON-only catalog intents.
- Simple polling of payment intent status.
- External VIP collection link + bot-side ownership verification.
