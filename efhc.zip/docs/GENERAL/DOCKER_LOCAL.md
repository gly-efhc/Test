# Docker local environment

## Что входит

Локальный Docker-стенд поднимает три сервиса:
- `db` — PostgreSQL 16;
- `backend` — EFHC backend/бот;
- `frontend` — Next.js frontend.

## Что уже настроено

- backend ждёт доступность БД перед стартом;
- backend выполняет `alembic upgrade head` при запуске;
- frontend проксирует `/api/*` и служебные ручки на backend;
- данные PostgreSQL лежат в volume `pgdata`;
- значения environment могут браться из `docker-compose.yml` c
  interpolation defaults и из `.env.local`.

## Быстрый старт

```bash
cp env.docker.example .env.local
make docker-up
```

For detailed local ENV and smoke checks, read:

- `docs/GENERAL/LOCAL_ENV_AND_SMOKE_TESTS.md`

## Полезные команды

```bash
make docker-ps
make docker-logs
make docker-down
```

Do not use `docker compose down -v` for routine restarts.
It deletes the local PostgreSQL volume and can wipe local test data.

## URL после старта

- frontend: `http://localhost:3000`
- backend: `http://localhost:8000`
- health: `http://localhost:8000/health`
- docs: `http://localhost:8000/docs`

## Переменные окружения

Базовый набор для Docker задан в `docker-compose.yml`.
Если нужен локальный override, используйте `.env.local` на основе
`env.docker.example`.

Ключевые переменные:
- `DATABASE_URL`
- `SYNC_DATABASE_URL`
- `DB_SCHEMA_CORE`
- `DB_SCHEMA_ADMIN`
- `NEXT_PUBLIC_API_PROXY_TARGET`
- `DOCKER_RUN_MIGRATIONS`
- `DOCKER_WAIT_FOR_DB`
- `NEXT_PUBLIC_ADMIN_TG_IDS`

## Канон

- Docker не меняет бизнес-логику EFHC;
- финансовые инварианты и SSOT не зависят от Docker;
- Docker даёт воспроизводимое локальное окружение для работы.

## Data safety

Normal restart keeps data:

```bash
docker compose down
docker compose up --build
```

Volume deletion is destructive and is allowed only for an intentional
clean database reset.


> `NEXT_PUBLIC_ADMIN_TG_IDS` — legacy compatibility env. Runtime frontend v173.27 не использует его для admin rights; права проверяются server-side через `/admin/access` по `global_id` + explicit RBAC role. Удаление остаточного env из CI/Docker выполняется только в alias-cleanup 1708–1709.
