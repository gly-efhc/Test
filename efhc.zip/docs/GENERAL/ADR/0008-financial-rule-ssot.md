# ADR 0008 — Runtime SSOT финансового spend rule

Статус: принято в цикле 1792.

## Решение

`app.standards.finance_rules` является единственной runtime-реализацией `SpendBreakdown` и `split_bonus_then_main`. Production `transactions_service` импортирует эти symbols и не содержит локальной копии.

FAQ и документация не являются runtime financial SSOT.

## Причина

В `v174.43` unit tests проверяли canonical helper, а production service вызывал независимую локальную копию. Арифметика совпадала, но QA coverage могла оставаться GREEN после будущего drift runtime-копии.

## Контроль

Architecture guard запрещает повторное объявление этих symbols в runtime service; existing financial tests продолжают проверять canonical pure rule.
