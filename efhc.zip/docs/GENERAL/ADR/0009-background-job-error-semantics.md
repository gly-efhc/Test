# ADR 0009 — Ошибки background jobs

Статус: принято в цикле 1792.

## Решение

Background job различает три результата:

- ожидаемый business outcome может возвращаться как DTO;
- unexpected infrastructure/system exception приводит к root rollback и stable error result только после rollback либо пробрасывается owner layer;
- cancellation всегда приводит к rollback у transaction owner и повторному `raise`.

Путь `unexpected exception → error DTO → commit` запрещён.

## Причина

`v174.43` TON scheduler скрывал unexpected exception внутри `TickResult(status="error")`, а caller затем выполнял commit.

## Контроль

Regression tests проверяют success/exception/timeout/cancellation transaction semantics и отсутствие commit на failed path.
