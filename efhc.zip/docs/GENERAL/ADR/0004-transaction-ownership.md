# ADR 0004 — Владение транзакцией

Статус: принято в цикле 1792.

## Решение

Root `commit/rollback` принадлежит только верхнему application use-case: HTTP route, Telegram update boundary, scheduler job или worker adapter.

Composable service/repository/CRUD-код выполняет `execute`, `flush` и при ожидаемом конфликте `begin_nested()`/savepoint. Он не завершает чужую root transaction.

Legacy compatibility wrapper может владеть root transaction только если это прямо следует из его standalone-контракта; transaction-neutral variant должен иметь явное имя и использоваться внутри составного use-case.

## Причина

`v174.43` содержал несколько independently committed частей одного Shop/payment use-case и root rollback внутри CRUD. Это создавало partial-state и возможность отката предыдущих mutations вызывающего use-case.

## Контроль

Architecture guards запрещают root `commit/rollback` в `backend/app/crud/**` и проверяют единый root owner внешнего Shop order flow.
