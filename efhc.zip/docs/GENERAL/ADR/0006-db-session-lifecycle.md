# ADR 0006 — Жизненный цикл DB session

Статус: принято в цикле 1792.

## Решение

Публичных контракта два:

1. FastAPI dependency `app.deps.get_db`, реализованный как adapter поверх canonical `db_session()`.
2. Для runtime/scheduler/CLI: `async with app.core.database_core.db_session() as db`.

Scheduler не импортирует `get_db` и не потребляет async-generator вручную. Canonical FastAPI lifespan детерминированно вызывает `dispose_engine()` при shutdown.

## Причина

Конкурирующие session APIs уже привели к `async with get_db()` над async generator и недетерминированному lifecycle.

## Контроль

Architecture guard запрещает scheduler-import `get_db`; `dispose_engine()` имеет idempotent shutdown contract.
