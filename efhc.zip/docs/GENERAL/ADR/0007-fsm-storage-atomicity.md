# ADR 0007 — Атомарность FSM storage

Статус: принято в цикле 1792.

## Решение

Для текущего single-process runtime read → expected-state validation → mutate → write выполняются под per-key striped lock. `MemoryStateBackend` сохраняет и возвращает копии mutable state, чтобы caller не изменял storage вне lock.

Перед horizontal scale process-local lock недостаточен. Distributed backend обязан предоставить CAS/version или эквивалентную distributed atomic primitive; это отдельный future owner scope и не требует schema change в текущем цикле.

## Контроль

Concurrency regression проверяет, что из конкурентных `expected=A` transitions успешен максимум один, а parallel `update_data` не теряет ключи.
