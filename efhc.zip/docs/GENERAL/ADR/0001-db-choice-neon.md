# ADR-0001: Выбор PostgreSQL (Neon)

## Status
Accepted.

## Context
EFHC Bot требует:
- транзакционности для денежных операций;
- строгих инвариантов и аудита;
- поддержки двух схем текущего канона:
  - `efhc_core`
  - `efhc_admin`
- предсказуемого миграционного слоя;
- удобной аналитики и расследований.

## Decision
Используем **PostgreSQL** как основную СУБД проекта.
В managed/cloud-сценарии допустимым базовым вариантом остаётся Neon,
но решение документа относится именно к классу PostgreSQL, а не к
жёсткой привязке ко всем возможным operational деталям одного провайдера.

## Rationale
- ACID-транзакции для финансовых контуров.
- Нормальная работа со схемами `efhc_core` и `efhc_admin`.
- Прозрачный SQL-аудит и расследование инцидентов.
- Совместимость с SQLAlchemy и Alembic.
- Предсказуемое поведение для текущего канона `0001 only` в первом
  релизе MVP.

## Consequences
### Positive
- Чёткие транзакционные границы.
- Простая аналитика и сверка через SQL.
- Возможность enforced-инвариантов через constraints и indexes.
- Нормальная база для двухсхемного канона проекта.

### Negative
- Нужно следить за миграциями и версионированием схемы.
- Нужно планировать индексы на hot-path таблицах.
- Нельзя ослаблять operational discipline в DB и migration layers.

## Operational Notes (current HEAD)
### Checks
- `python -m compileall backend ops`
- `pytest`
- direct audit of schema/migration docs and current `0001 only` layer

### Rollback
- Откат миграции только через Alembic.
- Прямые SQL-правки в проде запрещены, кроме аварийного чтения и
  отдельно санкционированного emergency response.
