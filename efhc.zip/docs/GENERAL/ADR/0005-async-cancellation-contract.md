# ADR 0005 — Контракт async cancellation

Статус: принято в цикле 1792.

## Решение

`asyncio.CancelledError` является lifecycle signal и не преобразуется в normal business result внутри scheduler/worker child path.

Функция, владеющая transaction, при cancellation выполняет rollback и затем повторно пробрасывает `CancelledError`. Вложенная операция либо не ловит cancellation, либо логирует и делает `raise`.

## Причина

В `v174.43` TON scheduler преобразовывал cancellation в DTO, после чего outer timeout/orchestration мог принять отменённую работу за обычное завершение и дойти до commit.

## Контроль

AST guard запрещает `return`/`break` внутри `except asyncio.CancelledError` в scheduler contour.
