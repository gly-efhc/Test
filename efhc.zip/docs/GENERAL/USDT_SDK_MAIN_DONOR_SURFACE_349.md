# USDT SDK-MAIN DONOR SURFACE — CYCLE 349

Статус: GENERAL.
Цель: выделить минимальный полезный donor surface из
`песочница/sdk-main` без массового копирования демо-приложения.

## Главный путь

- `песочница/sdk-main/apps/demo-dapp-with-react-ui/`

## Подтверждённо полезные файлы

### A1 — `src/components/TransferUsdt/TransferUsdt.tsx`
Полезные узлы:
- `useTonConnectUI`
- `useTonWallet`
- `TonClient`
- `JettonWallet`
- `Address`
- `beginCell`
- `JettonMinter.createFromAddress(...)`
- `storeJettonTransferMessage(...)`
- `toBoc().toString('base64')`

Что брать по смыслу:
- схему получения sender jetton wallet;
- схему сборки реального jetton transfer body;
- схему TonConnect message в sender jetton wallet.

Что не брать как есть:
- захардкоженный USDT master;
- demo destination;
- строку `hello!` в `forwardPayload`;
- внешние toncenter endpoints как runtime truth.

### A2 — `src/utils/units.ts`
Полезные узлы:
- `parseUnits`
- `formatUnits`

Что брать по смыслу:
- точные helper-функции для d6/d8 normalization в frontend.

Что не брать как есть:
- без проверки на совпадение с текущим Decimal/D8 каноном backend.

### A3 — `src/server/utils/transactions-utils.ts`
Полезные узлы:
- `retry(...)`

Что брать по смыслу:
- только идеи retry/wait helper для non-runtime tooling;
- не переносить напрямую в live browser bundle без причины.

### A4 — `package.json`
Подтверждённо полезные зависимости:
- `@ton/ton`
- `@ton/core`
- `@ton-community/assets-sdk`

Необязательные для нашей цели:
- `@reown/appkit-universal-connector`
- demo/testing/debug зависимости

## Минимальный donor surface для EFHC Bot

Из `sdk-main` в следующие циклы реально нужен только смысловой минимум:
- паттерн `TransferUsdt.tsx`;
- `parseUnits` / `formatUnits` логика;
- список нужных SDK dependencies.

Всё остальное в `sdk-main` считать reference-only.

## Что уже видно как gap в EFHC Bot

Текущий `frontend/package.json` содержит:
- `@tonconnect/ui-react`

Но не содержит:
- `@ton/ton`
- `@ton/core`
- `@ton-community/assets-sdk`

Следовательно, цикл реальной реализации потребует controlled
расширения frontend dependency-layer.
