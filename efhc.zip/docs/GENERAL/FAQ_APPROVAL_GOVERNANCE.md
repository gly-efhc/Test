# FAQ Approval Governance

Status: ACTIVE
Cycle: 103
Scope: FAQ SSOT / runtime rebuild / translations / bot-help parity

## 1. Назначение

Этот документ восстанавливает обязательный порядок согласования FAQ.

FAQ нельзя больше менять прямой волной rewrite/rebuild без
предварительного draft-пакета и фиксации согласования.

## 2. Обязательный порядок

Каждая новая волна FAQ обязана идти так:

1. direct audit текущего HEAD;
2. draft package;
3. approval register entry;
4. approval manifest update;
5. rewrite русского SSOT;
6. rebuild русского JSON;
7. rebuild переводов;
8. runtime rebuild;
9. bot/help parity;
10. freeze report.

## 3. Что считается draft package

Draft package обязан содержать:

- цель волны;
- scope по section/question ids;
- список старых формулировок;
- список новых формулировок;
- указание, меняется ли смысл или только wording;
- риск-факторы;
- список файлов, которые будут затронуты после approval.

## 4. Что считается approval

Approval считается только тогда, когда в репозитории обновлены оба слоя:

- `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`

Устное упоминание в чате без записи в эти два файла не считается
завершённым approval gate для новой FAQ-волны.

## 5. Запреты

Запрещено:

- менять `docs/SSOT/faq_ssot/ru/faq_ru.md` без draft package;
- менять `docs/SSOT/faq_ssot/ru/faq_ru.json` до approval;
- пересобирать `frontend/src/data/faq/catalogs.ts` до approval;
- массово менять переводы до approval русского пакета;
- подгонять approval задним числом без записи в register и manifest.

## 6. Источник истины

Главный смысловой канон остаётся здесь:

- `docs/SSOT/faq_ssot/ru/faq_ru.md`

Но право на rewrite возникает только после approval gate,
зафиксированного в register + manifest.

## 6A. Current HEAD audit note

В текущем HEAD approval gate представлен файлами:

- `docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md`
- `docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json`

## 7. Минимальный состав approval manifest

Каждая запись approval manifest обязана содержать:

- `approval_id`
- `status`
- `scope`
- `source_cycle`
- `ru_section_ids`
- `ru_question_ids`
- `change_kind`
- `draft_doc`
- `approved_by_user`
- `approval_basis`
- `rewrite_allowed`
- `runtime_rebuild_allowed`
- `notes`

## 8. Статусы

Разрешённые статусы:

- `draft`
- `approved`
- `superseded`
- `rejected`
- `implemented`

## 9. Правило runtime rebuild

`frontend/src/data/faq/catalogs.ts` можно пересобирать только когда:

- approval manifest entry имеет `status = approved` или `implemented`;
- `rewrite_allowed = true`;
- `runtime_rebuild_allowed = true`.

## 10. Историческая ошибка серии 77–82

В серии Hub FAQ migration approval gate был восстановлен не полностью:

- cycle 77 создал только draft по section 13;
- cycles 79–82 провели rewrite/rebuild быстрее, чем был возвращён
  обязательный approval governance layer.

Это считается ошибкой процесса, а не новой нормой.

## 11. Последствия для следующих циклов

Следующие FAQ-циклы обязаны опираться на этот документ:

- 104 — FAQ runtime vs SSOT parity audit
- 105 — FAQ code generation hardening
- 106 — FAQ bot/help parity wave
- 107 — multilingual FAQ legal wording audit
- 111–115 — post-handoff FAQ governance waves
