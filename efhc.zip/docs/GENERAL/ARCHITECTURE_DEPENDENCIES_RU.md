<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# EFHC Bot — схема и зависимости (RU, SSOT)

## 1. Репозиторий: верхний уровень

- `backend/` — FastAPI backend, модели, сервисы, scheduler.
- `frontend/` — Next.js WebApp (пользователь + admin).
- `api/` — вспомогательные файлы для entry/deploy слоя.
- `ops/` — guard, inventory, packaging и служебные операции.
- `tests/` — тесты канона и регрессии.
- `docs/` — checked-in документация проекта.
- `artifacts/` — архивная корзина, не active runtime слой.

## 2. Backend: ключевые подсистемы

- `backend/app/routes/` — HTTP routes (FastAPI).
- `backend/app/services/` — бизнес-логика по доменам.
- `backend/app/models/` — SQLAlchemy модели.
- `backend/app/schemas/` — Pydantic схемы.
- `backend/app/database.py` — подключение к БД и сессии.
- `backend/app/deps.py` — FastAPI dependencies.
- `backend/app/integrations/` — внешние интеграции.
- `backend/app/scheduler/` — фоновые задачи.
- `backend/migrations/` — Alembic migration layer.

## 3. Frontend: ключевые подсистемы

- `frontend/src/pages/` — страницы WebApp и admin.
- `frontend/src/components/` — UI components.
- `frontend/src/lib/` — клиент API и утилиты.
- `frontend/src/hooks/` — React hooks.
- `frontend/public/locale/` — checked-in locale assets.

## 4. Внешние зависимости и сервисы

### Runtime
- Python 3.x, FastAPI, Uvicorn/ASGI.
- SQLAlchemy, asyncpg, Alembic.
- PostgreSQL как основное хранилище.
- Telegram Bot API и Telegram WebApp initData.
- TON / wallet / memo / external commerce integrations текущего HEAD.

### Dev/Test
- pytest;
- ruff;
- mypy;
- freezegun;
- guard/inventory scripts из `ops/`.

## 5. Зависимости между слоями

- routes → services → models/schemas → database;
- scheduler/watchers → services → database;
- frontend → backend HTTP API;
- docs/guards/tests должны быть синхронны с current HEAD.

Критичное:
- внешний идентификатор пользователя во всех доменах: `global_id`;
- идемпотентность критичных операций;
- audit и reports как обязательный след подтверждённых циклов;
- `artifacts/` не является active dependency-layer.

## 6. Где смотреть точные списки

- `docs/GENERAL/dependency_map.md` — обзор pip-зависимостей и их роли;
- `backend/requirements.txt` — checked-in Python dependency manifest;
- `frontend/package.json` — frontend dependencies;
- `docs/NORM/MODULES_DEPENDENCIES.md` — обзор зависимостей модулей;
- `docs/MASTER_DOCUMENT_INDEX.*` — карта checked-in document layer.
