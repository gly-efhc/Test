# EFHC Bot — схема и зависимости (RU, SSOT)

## 1. Репозиторий: верхний уровень

- `backend/` — FastAPI backend, модели, сервисы, scheduler.
- `frontend/` — Next.js WebApp (пользователь + admin).
- `api/` — вспомогательные файлы для entry/deploy слоя.
- `ops/` — guard, inventory, packaging и служебные операции.
- `tests/` — тесты канона и регрессии.
- `docs/` — checked-in документация проекта.
- `artifacts/` — архивная корзина, не active runtime слой.

## 2. Backend: ключевые подсистемы

- `backend/app/routes/` — HTTP routes (FastAPI).
- `backend/app/services/` — бизнес-логика по доменам.
- `backend/app/models/` — SQLAlchemy модели.
- `backend/app/schemas/` — Pydantic схемы.
- `backend/app/database.py` — подключение к БД и сессии.
- `backend/app/deps.py` — FastAPI dependencies.
- `backend/app/integrations/` — внешние интеграции.
- `backend/app/scheduler/` — фоновые задачи.
- `backend/migrations/` — Alembic migration layer.

## 3. Frontend: ключевые подсистемы

- `frontend/src/pages/` — страницы WebApp и admin.
- `frontend/src/components/` — UI components.
- `frontend/src/lib/` — клиент API и утилиты.
- `frontend/src/hooks/` — React hooks.
- `frontend/public/locale/` — checked-in locale assets.

## 4. Внешние зависимости и сервисы

### Runtime
- Python 3.x, FastAPI, Uvicorn/ASGI.
- SQLAlchemy, asyncpg, Alembic.
- PostgreSQL как основное хранилище.
- Telegram Bot API и Telegram WebApp initData.
- TON / wallet / memo / external commerce integrations текущего HEAD.

### Dev/Test
- pytest;
- ruff;
- mypy;
- freezegun;
- guard/inventory scripts из `ops/`.

## 5. Зависимости между слоями

- routes → services → models/schemas → database;
- scheduler/watchers → services → database;
- frontend → backend HTTP API;
- docs/guards/tests должны быть синхронны с current HEAD.

Критичное:
- внешний идентификатор пользователя во всех доменах: `global_id`;
- идемпотентность критичных операций;
- audit и reports как обязательный след подтверждённых циклов;
- `artifacts/` не является active dependency-layer.

## 6. Где смотреть точные списки

- `docs/GENERAL/dependency_map.md` — обзор pip-зависимостей и их роли;
- `backend/requirements.txt` — checked-in Python dependency manifest;
- `frontend/package.json` — frontend dependencies;
- `docs/NORM/MODULES_DEPENDENCIES.md` — обзор зависимостей модулей;
- `docs/MASTER_DOCUMENT_INDEX.*` — карта checked-in document layer.
