# PUBLIC_COPY_FIREWALL.md

## Status

- `PUBLIC_TECHNICAL_COPY_ALLOWED = false`
- `PUBLIC_RELEASE_ALLOWED = false` when the public-copy guard finds
  forbidden technical text in user-visible public UI.
- `SPLASH_ONLY_SCREENSHOT_ALLOWED = false`

## Purpose

EFHC public UI must speak in product language: energy, panels, balance,
progress, exchange, team, tasks, rewards, history, profile, wallet,
operation, accrual, refresh and retry. Development language must not leak to
ordinary users.

## Guard boundary

This document is the current product-language firewall law. Historical scanner/policy/pytest artifacts that are absent from the physical HEAD are not current guards and must not be cited as executed. Validation is bounded to guards actually present in the current release plus direct source/locale inspection when this law is in scope.

## Public release rule

A public page is not accepted when it contains visible copy such as technical
runtime wording, raw transport wording, development-only labels, stack-like
errors, placeholder-null text or rough load-failure copy.

## Allowed technical zones

Technical language remains allowed in backend internals, tests, CI scripts,
internal documentation, reports, logs and closed admin diagnostics. It is not
allowed as ordinary public UI copy.

## Visual proof rule

A screenshot is not valid evidence when it only shows the splash screen or
only the EFHC logo. The page must be loaded enough for the user to see actual
content at mobile width.

## Public copy firewall pass note

Public copy firewall pass enabled the static public-copy firewall and the pytest guard. DOM
visual proof still requires a running frontend/browser environment and is not
claimed from the sandbox alone.
