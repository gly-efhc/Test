# Sandbox Audit Index

## Главные доноры по слоям

### TonConnect UI
- `песочница/sdk-main`
  - demo React UI app
  - docs for `@tonconnect/ui-react`
  - references for `TonConnectUIProvider`, `useTonConnectUI`, `TonConnectButton`

### Minimal TON runtime path
- `песочница/ton-core-main`
  - local source donor for `@ton/core`
- `песочница/ton-main`
  - local source donor for `@ton/ton`
- `песочница/ton-crypto-master`
  - local source donor for `@ton/crypto`

### TON network access
- `песочница/ton-access-main`
  - endpoint/access reference
  - not a replacement for TonConnect UI

### Secondary UI/architecture references
- `песочница/reactjs-template-master`
- `песочница/nextjs-template-master`
- `песочница/telegram-web-app-shop-main`
- `песочница/telebook-main`

## Current practical conclusion
1. `sdk-main` is the main donor for TonConnect UI patterns.
2. `ton-core-main` + `ton-main` + `ton-crypto-master` are the local source donors for bypassing part of the npm blocker in cycles 356/358/359.
3. `ton-access-main` helps with endpoint access, but does not solve TonConnect UI installation by itself.

## Newly added secondary references
- `песочница/react-circle-master` — React/Mini App UI reference only.
- `песочница/MaterialM-Tailwind-Nextjs-Free-main` — generic Next/Tailwind UI reference only.
- `песочница/idle-game-master` — gameplay/state-flow reference, not a TonConnect/TON blocker donor.
- `песочница/crypto-clicker-miniapp-main` — mini-app/game UX reference, not a TonConnect/TON blocker donor.
- `песочница/advanced-telegram-bots-master` — Telegram bot patterns reference, secondary only.

## Updated practical conclusion
1. Missing donor archives from the new upload batch were added to `песочница/`.
2. They expand reference coverage, but they do not replace the main blocker donors.
3. The main blocker donors remain: `sdk-main`, `ton-core-main`, `ton-main`, `ton-crypto-master`.

## Newly added UI/reference donors (batch 2)
- `песочница/TeleVue-master` — Vue/Telegram UI reference only.
- `песочница/TelegramUI-main` — Telegram-styled UI reference only.
- `песочница/ng-telegram-webapp-master` — Angular Telegram WebApp wrapper/reference only.
- `песочница/Mark42-master` — UI kit reference only.
- `песочница/awesome-telegram-mini-apps-main` — curated ecosystem/reference index only.

## Updated practical conclusion (batch 2)
1. Missing archives from the second uploaded batch were added to `песочница/`.
2. These 5 archives are UI/reference donors, not core blocker donors.
3. Main blocker donors remain unchanged: `sdk-main`, `ton-core-main`, `ton-main`, `ton-crypto-master`.

## 2026-04-04 — Donor expansion for TON/TonConnect resolution
- Added donors: assets-sdk-main, demo-dapp-master, demo-dapp-with-react-ui-master, minter-main, token-contract-main, tma.js-master, twa-template-main, mytonwallet-master.
- Highest-value donors now: sdk-main, ton-core-main, ton-main, ton-crypto-master, demo-dapp-with-react-ui-master.
- Main use: resolve TON runtime path and TonConnect UI/runtime path without relying on raw donor-source as the final production path.
- Reference-only or secondary donors: assets-sdk-main, minter-main, token-contract-main, tma.js-master, twa-template-main, mytonwallet-master.


## 2026-04-04 — Duplicate cleanup pass
- Confirmed logical duplicate removed from active sandbox: `demo-dapp-with-react-ui-master`.
- Reason: the same donor purpose is already present inside `sdk-main/apps/demo-dapp-with-react-ui`, which is the stronger reference because it stays co-located with the local TonConnect SDK monorepo.
- Action taken conservatively: moved the standalone duplicate into `artifacts/archive_removed_elements/sandbox_duplicates/` instead of destructive deletion.
- No wider sandbox purge is claimed; other folders remain because direct duplicate proof was not strong enough.
