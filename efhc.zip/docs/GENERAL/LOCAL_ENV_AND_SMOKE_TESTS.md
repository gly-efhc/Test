# EFHC local ENV and smoke tests

## Purpose

This runbook is for real local checks on a PC after Docker starts.
It separates three layers:

1. Docker engine is running.
2. EFHC containers are built and running.
3. Backend, frontend and public functions answer real requests.

## Safe restart

Use this for normal restarts when local data must be preserved:

```powershell
cd "C:\Users\adm1n\Desktop\DOKER\EFHC_Bot_v168_49"
docker compose down
docker compose --progress plain build --no-cache backend
docker compose --progress plain build --no-cache frontend
docker compose up
```

Do not use volume deletion for routine restarts.  Volume deletion wipes
local PostgreSQL data and can remove local balances, panels and seed
state.

Use volume deletion only when a clean database is intentionally needed.

## Minimal Docker ENV for local PC

Create `.env.local` from `env.docker.example`.
For a local Docker test, these values are enough:

```env
ENV=local
LOG_JSON=false
API_HOST=0.0.0.0
API_PORT=8000
DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/efhc
SYNC_DATABASE_URL=postgresql://postgres:postgres@db:5432/efhc
PSYCOPG_URL=postgresql://postgres:postgres@db:5432/efhc?sslmode=disable
DB_SCHEMA_CORE=efhc_core
DB_SCHEMA_ADMIN=efhc_admin
CORS_ALLOW_ORIGINS=http://localhost:3000,http://frontend:3000
NEXT_PUBLIC_API_PROXY_TARGET=http://backend:8000
NEXT_PUBLIC_TWA_RETURN_URL=http://localhost:3000
ADMIN_TG_ID=123456789
NEXT_PUBLIC_ADMIN_TG_IDS=  # legacy compatibility only; runtime admin access ignores it
SCHEDULER_ENABLED=false
DOCKER_RUN_MIGRATIONS=1
DOCKER_WAIT_FOR_DB=1
```

## ENV for real Telegram tests

For real Telegram WebApp tests, also set:

```env
TELEGRAM_BOT_TOKEN=<real bot token from BotFather>
TELEGRAM_WEBHOOK_SECRET=<stable random secret if webhook is used>
NEXT_PUBLIC_TWA_RETURN_URL=<public https app URL>
```

The local browser can run without Telegram data, but real Telegram
initData validation needs a real bot token.

## ENV for real TON / deposit tests

For real TON payment and watcher checks, also set:

```env
TON_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW
TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW
TON_API_URL=https://tonapi.io/v2
TON_API_KEY=<real tonapi key if required>
TON_NFT_COLLECTION=EQASPXkEI0NsZQzqkPjk6O_i752LfwSWRFT9WzDc2SJ2zgi0
```

Without these values, the UI can be checked, but real deposits,
watcher reconciliation and NFT verification are not fully testable.

## Local smoke test

After `docker compose up` opens the stack, run from another PowerShell:

```powershell
cd "C:\Users\adm1n\Desktop\DOKER\EFHC_Bot_v168_49"
python ops/local/runtime_smoke.py --tg-id 123456789
```

The smoke test checks:

- backend health;
- DB health;
- frontend HTML;
- locale file;
- PWA manifest;
- sync snapshot;
- tasks catalog;
- ranks endpoint;
- shopfront catalog.

If any check fails, send the smoke output and the backend log tail.


## v168_50 route smoke extension

The local smoke script now also checks `/faq` and `/admin/logs`.
This protects the public FAQ route and admin diagnostics link surface.
It does not prove protected admin API actions unless admin credentials
and backend ENV are configured.


> `NEXT_PUBLIC_ADMIN_TG_IDS` — legacy compatibility env. Runtime frontend v173.25 не использует его для admin rights; права проверяются server-side через `/admin/access` по `global_id` + explicit RBAC role. Удаление остаточного env из CI/Docker выполняется только в alias-cleanup 1708–1709.
