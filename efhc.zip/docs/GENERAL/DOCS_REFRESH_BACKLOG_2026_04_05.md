# Docs refresh backlog — 2026-04-05

## Highest priority refresh candidates
1. `docs/GENERAL/READINESS_AUDIT.md`
   - pre-hardening readiness language must be checked against the current line.
2. `docs/GENERAL/BROWSER_SHOP_RELEASE_GATE_V6.md`
   - still tied to an older storefront/runtime phase and needs active-status note.
3. `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`
   - contains stale HEAD/history notes in multiple rows.
4. `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`
   - refreshed now, but should be rechecked after the next migration wave.
5. `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/TESTS_CATALOG.md`
   - refreshed HEAD pointer now, but needs a broader pass after the next CI wave.

## Why this backlog exists
The project keeps a very large historical document surface. The next updates must
prioritize documents that can still be mistaken for active release/readiness
truth.
