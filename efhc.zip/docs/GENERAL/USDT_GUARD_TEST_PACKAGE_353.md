# USDT GUARD TEST PACKAGE — CYCLE 353

Статус: GENERAL.
Цель: заранее определить минимальный guard-test пакет,
без которого USDT нельзя возвращать в live checkout.

## T1 — builder tests

Проверять:
- сборку jetton transfer body;
- наличие payload в `forward_payload`;
- корректность адреса назначения;
- корректность fee-message amount.

## T2 — decimals tests

Проверять:
- USDT d6;
- EFHC jetton d8;
- отсутствие silent mixing d6/d8;
- exact requested vs encoded amount.

## T3 — adapter tests

Проверять:
- BrowserShopPage вызывает adapter, а не сериализует payload сам;
- live page не содержит новых hardcoded demo values.

## T4 — backend contract tests

Проверять:
- intent отдаёт данные, достаточные для real jetton send path;
- USDT не включается без нужных settings;
- старый pseudo-payload путь не возвращается.

## T5 — watcher tests

Проверять:
- exact matching по `forward_payload`;
- reject fake jetton wallet / fake master;
- idempotent confirm on repeated notifications;
- unmatched goes to `unmatched_incoming`.

## T6 — regression tests

Проверять:
- rollback в fake string payload невозможен;
- live enable невозможно без прохождения release gates.
