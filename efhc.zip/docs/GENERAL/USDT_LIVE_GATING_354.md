# USDT LIVE GATING — CYCLE 354

Статус: GENERAL control gates.
Цель: зафиксировать минимальные условия, при которых USDT
можно будет вернуть в live checkout.

## Gate G1 — frontend dependency proof

Должны быть добавлены и реально использоваться:
- `@ton/ton`
- `@ton/core`
- `@ton-community/assets-sdk`

## Gate G2 — adapter proof

Должен существовать отдельный frontend adapter layer для
real jetton transfer; BrowserShopPage не должен собирать body сам.

## Gate G3 — recipient strategy proof

Должен быть утверждён один канон:
- owner-derived recipient wallet;
- или fixed recipient jetton wallet.

## Gate G4 — payload canon proof

Должен быть зафиксирован final `forward_payload` contract,
совместимый с current payment intent canon.

## Gate G5 — backend intent proof

Backend должен честно выдавать данные, достаточные для
real USDT send path, без скрытых demo constants.

## Gate G6 — watcher proof

Watcher должен подтверждать real jetton flow, а не только
legacy comment-style assumptions.

## Gate G7 — guard-test proof

Должен существовать и проходить dedicated guard-test package:
- builder;
- decimals;
- adapter;
- backend contract;
- watcher;
- regression no-pseudo-path.

## Gate G8 — documentation proof

До включения USDT live mode должны быть синхронно обновлены:
- SSOT;
- NORM/GENERAL docs;
- WORK_CYCLES;
- Q&A;
- Healer;
- reports.

## Честное текущее состояние

На конец цикла 354 проект всё ещё находится в режиме:
- TON-only live checkout;
- USDT disabled until real jetton implementation proof.
