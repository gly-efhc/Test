<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# USDT RECIPIENT / PAYLOAD / FEE DECISIONS — work pass

Статус: GENERAL pending decisions map.
Цель: зафиксировать решения, которые нужны до реальной
реализации USDT jetton transfer.

## D4 — Recipient strategy

Нужно выбрать один канон:

### Вариант R1 — хранить owner address получателя
Плюсы:
- ближе к стандартной модели jetton wallet derivation;
- меньше риска хранить устаревший recipient jetton wallet.

Минусы:
- frontend/backend должны корректно вычислять recipient wallet;
- нужен явный и проверяемый derivation path.

### Вариант R2 — хранить готовый recipient jetton wallet
Плюсы:
- проще для runtime send path;
- меньше вычислений на клиенте.

Минусы:
- выше риск drift, если wallet policy сменится;
- требуется отдельная валидация принадлежности wallet
  ожидаемому master contract.

Рабочая рекомендация текущего цикла:
- предпочесть `R1`, если backend сможет хранить owner truth,
  а runtime будет вычислять jetton wallet детерминированно.

## D5 — Forward payload canon

Уже подтверждённый проектный payload canon:
- `EFHC:<purpose>:<intent_id>:<global_id>`

Что нужно решить до реализации:
- сериализуем ли payload как plain comment cell;
- допускаем ли только exact-match;
- сохраняем ли текущую tolerant matching логику как
  fallback только на переходный период.

Рабочая рекомендация текущего цикла:
- для real USDT flow использовать один канон:
  server-issued payload -> comment in `forward_payload`.

## D6 — Fee policy

Нужно подтвердить:
- какой `forward_ton_amount` обязателен;
- какой `TonConnect message amount` идёт на fees/excess;
- кто считается источником истины для fee numbers:
  frontend constant или backend-issued field.

Рабочая рекомендация текущего цикла:
- fee policy должна приходить с backend либо из SSOT config,
  а не жить как demo constant во frontend.

## Query ID policy

Нужно выбрать:
- `0` как допустимый фиксированный `query_id`;
- или unique query id per intent/send attempt.

Рабочая рекомендация текущего цикла:
- привязать `query_id` к intent/send-attempt политике,
  а не оставлять вечный demo `0`.
