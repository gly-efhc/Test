# Agent Skills Upstream Index

- Source archive: `agent-skills-main.zip`.
- Integrated as EFHC Agent Skills Adapter foundation.
- Upstream areas inspected: `skills`, `agents`, `commands`, `.claude/commands`,
  `.gemini/commands`, `references` and `hooks`.
- Active EFHC copy exists at repository root under `skills/`, `agents/`,
  `commands/`, `.claude/commands/`, `.gemini/commands/`, `references/` and
  `hooks/`.
- Upstream material is not higher than EFHC AI Archive Laws, SSOT or NORM.
- Commands and meta-skill are adapted to the EFHC threshold model.
- Upstream refresh must be performed only in a dedicated future cycle.
