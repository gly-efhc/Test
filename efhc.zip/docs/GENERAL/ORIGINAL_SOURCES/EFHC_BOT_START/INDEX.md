# EFHC Bot original-source recovery layer

Статус: historical comparison layer, not canonical source.
Дата обновления: 2026-06-01.
Примечание: имена файлов в `md/` нормализованы безопасно. Содержимое первоисточников сохранено; версионные и цикловые метки release/audit/report/test слоя не удалялись.

PDF-первоисточники удалены из архива по решению пользователя. Они были использованы только как стартовый ориентир для вопросов. Постоянным каноном являются ответы пользователя на вопросы и новые living-документы.

## Сохранённый MD-слой

- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/achievement_scales_tz.md` — Техническое описание шкал достижений EFHC Bot
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/admin_panel_tz.md` — Техническое задание: админ-панель EFHC Bot
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/ai_self_recovery_protection_points.md` — Живые точки самовосстановления и ИИ-защит
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/bonus_system_tz.md` — Техническое описание системы бонусов EFHC Bot
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/dashboard_page_tz.md` — Техническое задание: страница Главная / Dashboard
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_bank_tz.md` — Техническое описание банка EFHC
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_bot_tz_lost_functions_recovery.md` — Дополнение к ТЗ EFHC Bot: восстановление потерянных функций
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_project_overview.md` — Проект EFHC — Energy for Humanity Coin
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/exchange_page_tz.md` — Техническое задание: страница Обмен / Exchange
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/panels_page_tz.md` — Техническое задание: страница Панели / Panels
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/rating_page_tz.md` — Техническое задание: страница Рейтинг / Rating
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/referrals_page_tz.md` — Техническое задание: страница Рефералы / Referrals
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/shop_page_tz.md` — Техническое задание: страница Магазин / Shop
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/tasks_page_tz.md` — Техническое задание: страница Задания / Tasks
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/user_statuses_tz.md` — Статусы пользователей EFHC Bot

## Правило имён

- Внутри `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/` используются короткие semantic filenames без mojibake и без suffix `(1)/(2)/(3)`.
- Release/version/cycle traceability в audit/report/test/cycle слоях сохраняется и не считается ошибкой.
- Массовое переименование проектных файлов без отдельного разрешения запрещено.
