# USDT REAL JETTON DONOR AUDIT AND TRANSFER MAP

Статус: GENERAL working map.
Основание: цикл 348.
Главная цель: не тащить песочницы целиком, а выделить
точные донорские компоненты для будущей полной безопасной
реализации real USDT jetton transfer в EFHC Bot.

## 1. Итог аудита доноров

Главный донор:
- `песочница/sdk-main`

Вторичные доноры:
- `песочница/reactjs-template-master`
- `песочница/nextjs-template-master`
- `песочница/demo-telegram-bot-master`
- `песочница/pytonconnect-main`
- `песочница/telegram-web-app-shop-main`
- `песочница/telebook-main`
- `песочница/react-telegram-web-app-master`
- `песочница/tma-starter-kit-main`
- `песочница/fastapi-telegram-mini-app-main`

## 2. Главный донорский узел

Ключевой путь:
- `песочница/sdk-main/apps/demo-dapp-with-react-ui/`

Ключевой компонент:
- `src/components/TransferUsdt/TransferUsdt.tsx`

Почему это главный донор:
- уже использует `@tonconnect/ui-react`;
- использует `@ton/ton` и `@ton/core`;
- использует `@ton-community/assets-sdk`;
- умеет получать jetton wallet address;
- умеет собирать TEP-74 transfer body;
- умеет кодировать BOC в base64 для TonConnect;
- ближе всего к реальной задаче EFHC Bot.

## 3. Индекс полезных компонентов

### D001 — TonConnect provider shell
Источники:
- `sdk-main`
- `reactjs-template-master`
- `nextjs-template-master`

Назначение в EFHC Bot:
- unified provider layer для browser-shop checkout shell.

### D002 — TEP-74 jetton transfer body builder
Источник:
- `sdk-main`

Назначение в EFHC Bot:
- собрать реальный USDT jetton transfer payload вместо
  старого pseudo-payload.

### D003 — sender jetton wallet derivation
Источник:
- `sdk-main`

Назначение в EFHC Bot:
- получать sender jetton wallet из owner wallet и
  конкретного jetton master.

### D004 — recipient jetton wallet strategy
Источники:
- `sdk-main` как reference
- текущий EFHC Bot backend/config как SSOT

Назначение в EFHC Bot:
- выбрать и закрепить канон: переводить в owner address
  с вычислением recipient wallet или хранить готовый
  recipient jetton wallet как конфиг.

### D005 — forward payload / memo canon
Источники:
- текущий EFHC Bot SSOT
- `sdk-main` как transport reference

Назначение в EFHC Bot:
- положить каноничный payload EFHC intent в
  `forward_payload` реального jetton transfer.

### D006 — asset/decimals normalization
Источники:
- `sdk-main`
- текущий backend config

Назначение в EFHC Bot:
- USDT должен жить как d6; EFHC jetton как d8;
  внутренние суммы и on-chain amount нельзя смешивать.

### D007 — watcher confirm contract for jettons
Источники:
- текущий `watcher_service`
- TON jetton payment processing model

Назначение в EFHC Bot:
- перейти от pseudo comment matching к реальному
  jetton confirmation path.

### D008 — checkout UI/UX shell
Источники:
- `telegram-web-app-shop-main`
- `telebook-main`
- `reactjs-template-master`

Назначение в EFHC Bot:
- только как UX/pattern donor, без переноса чужой
  business logic.

### D009 — bot-side connector / session references
Источники:
- `demo-telegram-bot-master`
- `pytonconnect-main`

Назначение в EFHC Bot:
- reference для TonConnect session/bridge; не основной
  донор для frontend payload builder.

### D010 — Mini App bootstrap references
Источники:
- `tma-starter-kit-main`
- `react-telegram-web-app-master`
- `fastapi-telegram-mini-app-main`

Назначение в EFHC Bot:
- использовать только если потребуется подчистить
  bootstrap/provider/init sequence.

## 4. Что переносить нельзя как есть

Запрещено переносить без адаптации:
- demo адреса и demo jetton masters;
- прямые внешние API endpoints песочниц;
- showcase UI и демо-состояния как runtime truth;
- любую логику, которая обходит current SSOT EFHC Bot;
- любую чужую схему memo, если она ломает наш intent canon.

## 5. Карта переноса по слоям EFHC Bot

### Слой F1 — frontend blockchain adapter
Цель:
- новый чистый frontend helper/module для real jetton transfer.

Будущие целевые элементы:
- TonConnect transaction builder;
- USDT amount d6 conversion;
- sender jetton wallet resolution;
- forward payload packer;
- tx body to BOC/base64.

### Слой F2 — browser-shop checkout integration
Цель:
- встроить новый adapter в существующий browser-shop
  checkout/status shell без поломки TON-only live flow до готовности.

### Слой B1 — backend intent contract
Цель:
- сохранить сервер как источник истины для intent, asset,
  payload, amount, receiver policy и антифрода.

### Слой B2 — watcher / confirmation
Цель:
- подготовить confirm logic к реальному jetton flow.

### Слой D1 — docs / canon / release gates
Цель:
- не выпустить USDT live path раньше полного прохождения
  кодовых и документных gate-подтверждений.

## 6. Предлагаемая серия следующих циклов

### Цикл 349
Точечный разбор `sdk-main` и извлечение минимума donor surface:
- зависимости;
- transfer builder;
- helper-layer;
- wallet derivation points.

### Цикл 350
Проектирование EFHC frontend blockchain adapter под USDT jetton:
- без включения live flow;
- только чистая внутренняя архитектурная врезка.

### Цикл 351
Канон recipient strategy и payload packing:
- owner vs recipient jetton wallet;
- forward payload format;
- fee policy;
- query_id policy.

### Цикл 352
Backend intent/watcher alignment audit:
- как current payment_intents/watcher_service должны
  принять real jetton flow.

### Цикл 353
Guard-test package design:
- golden tests на builder;
- d6/d8 tests;
- matcher tests;
- запрет rollback в pseudo-payload.

### Цикл 354
Решение по live gating:
- когда именно USDT можно вернуть в live checkout;
- какие release gates обязательны до включения.

## 7. Открытые параметры, которые проекту всё ещё нужны

Для полной реализации real USDT jetton transfer проекту
всё ещё нужны подтверждённые значения/решения:
- каноничный `USDT_JETTON_MASTER_ADDRESS`;
- стратегия recipient wallet;
- окончательный fee policy;
- окончательный `forward_payload` packing contract;
- watcher confirm contract под jetton flow.

## 8. Уже подтверждённые якоря проекта

- Каноничный EFHC jetton master address:
  `EQDNcpWf9mXgSPDubDCzvuaX-juL4p8MuUwrQC-36sARRBuw`
- Каноничные EFHC jetton decimals: `8`
- Главный donor для real USDT jetton transfer: `sdk-main`
- Live state до полной реализации: TON-only checkout,
  USDT disabled.
