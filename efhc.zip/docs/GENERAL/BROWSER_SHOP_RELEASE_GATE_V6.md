# BROWSER SHOP RELEASE GATE V6

## Status note
This document is historical and tied to an earlier storefront/runtime phase. It
should not be read as the current release truth.

## Historical note
Still not eligible for a full release claim until live payment proof and
post-proof verification are attached.
