# DB_SCHEMA (SSOT)

## Канон схем

- разрешены только `efhc_core` и `efhc_admin`;
- третьи схемы запрещены;
- миграция `0001_init.py` обязана поднимать только эти две схемы.

## Актуальные числа

- схемы: **2**
- ORM-таблицы: **35**

## Ключевые контуры

- `efhc_core.users`
- `efhc_core.bank_balance`
- `efhc_core.efhc_transfers_log`
- `efhc_core.withdraw_requests`
- `efhc_core.panels`
- `efhc_admin.admin_action_log`

## Денежные правила

- деньги и kWh хранятся как `NUMERIC(..., 8)`;
- денежные POST обязаны быть идемпотентными;
- обход сервисного контура для денег запрещён.

## Источники

- `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`
- `docs/SSOT/ssot_pack/SSOT_TABLES_MIGRATIONS.csv`
- `backend/app/models/*`
- `backend/migrations/versions/0001_init.py`

## Legacy migration policy

Historical traces допустимы только в migration-history,
audit-history, Healer и reports. Они не меняют active SSOT и
не допускают третью схему. Любые старые расхождения учитываются
только по отдельному подтверждённому DB/CI/audit сигналу.
