# BROWSER_SHOP_AFTERCARE_AND_CLEANUP_GUIDE

Статус: GENERAL
Якорь: cycle 263+

## 1. Назначение

Документ фиксирует, что именно нужно дочистить в browser-shop линии перед и во
время кодового старта, чтобы MVP не тащил за собой лишние planning-хвосты.

## 2. Что считается aftercare

Aftercare = доведение уже согласованной линии до чистого рабочего состояния без
ломки канона и без переизобретения продукта.

## 3. Что нужно чистить

- временные формулировки планового этапа
- неоднозначные user-facing тексты
- placeholder-подсказки в checkout/status/linking flow
- лишние переходные комментарии, если они больше не нужны после кода
- дубли описаний между UI-текстами и planning-слоем

## 4. Что нельзя ломать cleanup'ом

- канон Hub как link/handoff layer
- one product = one operation
- immutable memo
- anti-fraud full-match logic
- debit/credit экономику между пользователем и банком
- историю аудита и change reports

## 5. Цель cleanup

К моменту после кодового старта browser-shop должен иметь:
- чистые user-facing тексты
- прозрачный checkout/status flow
- отсутствие лишних planning-сущностей в пользовательском интерфейсе
- предсказуемый support/debug слой
