# EFHC Project Specification

Статус: DERIVED (производный документ).
SSOT-якоря: docs/SSOT/SSOT_INDEX.md, docs/SSOT/EFHC_CANON.md,
docs/SSOT/TERMS_GLOSSARY.md,
docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md.

Правило: этот документ не вводит новых норм.
Если есть конфликт с NORM-документами, приоритет у SSOT.

## 1. Общие правила и параметры

## 1.1 UI канон (DERIVED)

- Глобальный хедер отображается на всех вкладках:
  аватар, username, LVL, общий баланс Total (main+bonus),
  кнопки + и Hub.
- Нижняя навигация (Bottom Nav) содержит ровно 6 вкладок в порядке:
  Energy | Panels | Exchange | Tasks | Referrals | Ranks.
- Energy использует "живое" обновление E(t) от server_now_iso и
  gen_per_sec_effective (2–4 обновления UI в секунду) и шкалу 12 уровней
  по порогам kWh.

SSOT-якоря:
- docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md (DERIVED),
- docs/SSOT/EFHC_CANON.md (NORM),
- docs/NORM/ARCHITECTURAL_LOCKS.md (NORM).

- Генерация панелей фиксированная, только в секундах:
  - `GEN_PER_SEC_BASE_KWH = 0.00000692` кВт/сек
  - `GEN_PER_SEC_VIP_KWH  = 0.00000741` кВт/сек
- Флаг **VIP** меняется внешним процессом ежедневно в 00:00 по наличию
- NFT.
- Флаг **ACTIVE** включается при первой покупке панели (навсегда).
- Денежная точность — 8 знаков после запятой (округление вниз).
- Обменник: EXCHANGE_ALL kWh → EFHC MAIN 1:1.
  Зеркало: available = max(total_generated - exchanged, 0).
  SSOT: docs/SSOT/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md.
- Все списания у пользователей идут в банк (global_id из ENV).
- Лимит панелей: 1000 (минус архивные).
- Реф-бонус:
  - Разовый 0,1 EFHCb за первую панель каждого прямого реферала (до 10 000 активных прямых рефералов).
  - Автоматические разовые награды Lvl 1–5: 1 / 10 / 100 / 300 / 1000 EFHCb.
  - Полный цикл: 10 000 × 0,1 = 1 000 EFHCb; сумма Lvl = 1 411 EFHCb; итог = 2 411 EFHCb.
  - Пороговые бонусы: 10→1 EFHC, 100→10 EFHC, 1000→100 EFHC, 3000→300
    EFHC, 10000→1000 EFHC.

---

## 2. Валюты и операции
- Пользователь может платить: **TON**, **USDT**, **EFHC**.
- Вывод возможен **только EFHC**.
- EFHC-пакеты покупаются за TON/USDT.
- VIP NFT выдается вручную админом по заявке (TON / USDT / EFHC).
- Все товары магазина имеют уникальный `custom_memo` для валидации
  транзакции.

---

## 3. Покупки и MEMO
- MEMO формируется по SSOT ton_memo.
- Пользователь не выбирает сумму вручную — фиксируется `expected_amount`
  + `expected_currency` + `expected_memo`.
- Проверка входящей транзакции:
  - Если всё совпало:
    - `efhc_pack_*` → заказ completed, EFHC начислены пользователю.
    - `vip_nft_*`   → заказ pending (ожидает выдачи NFT админом).
  - Если не совпало → заказ canceled (с диагностикой).

---

## 4. Cron-задачи
- **00:00 UTC** — проверка VIP-NFT (установка `vip_active`).
- **00:30 UTC** — начисление kWh по активным панелям.
- **01:00 UTC** — архивирование панелей.
- **01:30 UTC** — чистка логов и reconcile за последние 72 часа
  (APScheduler).

---

## 5. Логирование
### EFHC-транзакции
- `shop_buy_efhc` — покупка EFHC (банк → user)
- `shop_panel_bonus` — списание бонусных EFHC (user → банк)
- `shop_panel_efhc` — списание EFHC при покупке панели (user → банк)
- `exchange_kwh_to_efhc` — обмен kWh→EFHC
- `withdraw_lock` — блокировка EFHC при выводе
- `withdraw_refund` — возврат при отказе
- `task_reward` — награда за задание

### Реф-бонусы
- `first_panel` — 0.1 EFHC при первой панели у реферала.
- `threshold` — бонусы за пороги активных рефералов.

---

## 6. API
- `GET /api/v1/me` — облегчённая safe-витрина профиля.
  Поля: `global_id`, `username`, `vip`.
- `GET /user/me` — единственный self-profile endpoint с
  балансами и каноническими ставками генерации.
- `GET /user/me/panels-summary` — canonical self-route для
  сводки панелей текущего пользователя.
- `GET /panels/{global_id}/active` и
  `GET /panels/{global_id}/archive` — активные и архивные панели.
- `POST /panels/activate/{global_id}` — каноничный путь
  активации панели.
- `POST /panels/buy/{global_id}` — compat path текущей release-line.
- `POST /exchange/convert/{global_id}` — обмен kWh→EFHC.
  При `amount_kwh` делает partial exchange.
  Без `amount_kwh` делает full exchange.
- `GET /api/ranks/global` — общий рейтинг
- `GET /api/ranks/referral` — рейтинг по рефералам
- `GET /api/referrals` — дерево рефералов
- `GET /api/shop/config` — адреса TON/USDT, NFT-маркет, auto-memo
- `POST /api/shop/buy` — создание заказа
- `POST /api/shop/check-payment` — ручная проверка транзакции
- `GET /api/admin/*` — банк EFHC, выводы, товары, заказы, логи

---

## 7. Watcher (TON)
- Фоновая задача: каждые 10-30 сек `process_incoming_payments()`.
- EFHC депозит:
  - MEMO: `EFHC:<global_id>`
  - EFHC начисляются пользователю 1:1 с банка.
- Покупка пакета EFHC за TON/USDT:
  - MEMO: `BUY:EFHC:<qty>:TG:<global_id>[:OID:<order_id>]`
  - Вотчер проверяет, что сумма на блокчейне совпала с ценой пакета.
  - Затем начисляет ровно `<qty>` EFHC пользователю с банка.
- Reconcile:
  - Ручной (`POST /admin/shop/reconcile`)
  - Авто в 01:30 UTC

---

## 8. Логика покупок
### Покупка за EFHC
- Пользователь → Банк
- EFHC списываются у пользователя, зачисляются Банку.
- `shop_items.stock` уменьшается.
- Создаётся order.

### Покупка за TON / USDT
- Пользователь оплачивает внешне.
- Банк → Пользователь
- EFHC начисляются пользователю (`credit_user_from_bank`).
- `shop_items.stock` уменьшается.
- Создаётся order.

### Current payment implementation
- Browser Shop supports TON/GRAM native checkout.
- Browser Shop supports USDT jetton checkout through a real TEP-74
  transfer builder.
- Both flows require a pre-created intent and exact watcher
  reconciliation.
- Direct Deposit through `+` is a separate EFHC jetton → EFHCm
  contour.
