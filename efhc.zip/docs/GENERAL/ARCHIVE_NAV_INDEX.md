# ARCHIVE NAV INDEX

Статус: **ACTIVE NAVIGATION / v173.14**.

Исторический архив не является current CANON/SSOT/NORM, но является
обязательной доказательной историей проекта.

## Текущие точки входа

1. `docs/AI/AI_OPERATOR_RULES_EFHC.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/GENERAL/CURRENT_DECISIONS.md`.
6. `docs/PLANS/WORK_PLAN_1693-1707.md`.

## Исторические контуры

- Cycles: `docs/cycles/`.
- Long-range cycles 1701–1800:
  `docs/cycles/WORK_CYCLES_1701-1800.md`.
- Chats: `docs/chats/`.
- Immutable reports: `reports/numbered/`.
- Historical tests: `АРТЕФАКТЫ/Тесты/`.
- Historical identity cutover code: `АРТЕФАКТЫ/Код/`.
- Other historical documents/audits: `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/`.

## Manifests

- `АРТЕФАКТЫ/МАНИФЕСТЫ/CYCLE_ARCHIVE_MANIFEST.csv`.
- `АРТЕФАКТЫ/МАНИФЕСТЫ/CHAT_ARCHIVE_MANIFEST.csv`.
- `АРТЕФАКТЫ/МАНИФЕСТЫ/REPORTS_NUMBERING_MANIFEST.csv`.

`reports/current/` — только operational pointers. История reports находится
только в numbered archive согласно `docs/NORM/IMMUTABLE_HISTORY_NORM.md`.
