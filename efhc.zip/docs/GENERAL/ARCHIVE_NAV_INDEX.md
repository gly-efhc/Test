# ARCHIVE NAV INDEX

Статус: **ACTIVE NAVIGATION / v173.14**.

Исторический архив не является current CANON/SSOT/NORM, но является
обязательной доказательной историей проекта.

## Текущие точки входа

1. `docs/AI/AI_OPERATOR_RULES_EFHC.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/GENERAL/CURRENT_DECISIONS.md`.
6. `docs/PLANS/WORK_PLAN_1693-1709.md`.

## Исторические контуры

- Cycles: `docs/cycles/`.
- Long-range cycles 1701–1800:
  `docs/cycles/WORK_CYCLES_1701-1800.md`.
- Chats: `docs/chats/`.
- Immutable reports: `reports/numbered/`.
- Historical tests: `docs/history/test_archive/`.
- Historical identity cutover code: `docs/history/code_archive/`.
- Other historical documents/audits: `docs/history/legacy_artifacts/`.

## Manifests

- `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`.
- `reports/manifests/CHAT_ARCHIVE_MANIFEST.csv`.
- `reports/manifests/REPORTS_NUMBERING_MANIFEST.csv`.

`reports/current/` — только operational pointers. История reports находится
только в numbered archive согласно `docs/NORM/IMMUTABLE_HISTORY_NORM.md`.
