# ARCHIVE NAV INDEX

Этот файл нужен как навигационная карта чтения архива.

## Порядок чтения нового HEAD

1. `docs/AI/AI_OPERATOR_RULES_EFHC.md`
2. `docs/SSOT/SSOT_INDEX.md`
3. `docs/NORM/ARCHITECTURAL_LOCKS.md`
4. `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/cycles/WORK_CYCLES.md` (индекс диапазонных файлов циклов)
5. `docs/GENERAL/CURRENT_DECISIONS.md`
6. реестры и Healer:
   - `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
   - `HEALER_ATLAS.md`
   - `docs/healer/HEALER_ATLAS.md`
   - `docs/healer/HEALER_CASEBOOK.md`
7. overview/architecture/docs root
8. translation assets `frontend/public/locale/`
9. audits `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/`
10. reports `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/`
11. `artifacts/`

## Что не брать в первые пакеты по 5

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/reports/`
- log-документы
- `artifacts/`, если пользователь не дал отдельное решение

## Что разбирать в приоритете после индекса

- корневые документы
- обзорные и архитектурные документы `docs/`
- SSOT/реестры на предмет объединения и актуализации
- translation/locale assets по отдельному решению

## Продолжение в новом чате

- `docs/AI/CONTINUE_NEW_CHAT_V162_02_PROMPT.md`


- Rule: all inventory and audit documents of any form must live under `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/audits/`.
