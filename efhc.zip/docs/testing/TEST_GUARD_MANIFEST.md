# TEST GUARD MANIFEST v173.41

- Версия: `v173.41`.
- Цикл: `1717`.
- Последний предоставленный GitHub CI: `84948550953` на exact `v173.40`, checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`, archive `12124946` bytes.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Ruff: `1` I001.
- Pytest: `45 failed / 1456 passed / 22 skipped`.
- Подтверждённые failures исправлены только по предоставленному CI evidence; локальные проверки не выполнялись.
- Active architecture test surface по предоставленному CI: `262` файлов.
- Fail-closed registry: `contracts/application_function_surface_v1.json` — `259` критических Python symbols / `44` modules / `14` required files.
- Control test: `tests/architecture/test_application_function_surface_manifest.py`; расширен, **локально не запускался**.
- Архивный закон `AI_ARCHIVE_LAWS` остаётся обязательным активным reference для test/document guard layer.
- Historical function evidence: `v171.89`.
- Identity ownership migration остаётся qualified на exact-green `v173.36`; migration-control/read-switch/tg-owned runtime не возвращается.
- Следующий exact-head CI требуется для `v173.41`.
