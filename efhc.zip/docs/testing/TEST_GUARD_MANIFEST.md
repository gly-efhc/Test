# TEST GUARD MANIFEST v173.40

- Версия: `v173.40`.
- Цикл: `1716`.
- Latest supplied GitHub CI `84942802763` on exact `v173.39` / checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Ruff: `3` I001.
- Pytest: `61 failed / 1307 passed / 22 skipped / 130 errors`.
- Cycle 1716 patches are not locally verified.
- New fail-closed function-presence registry: `contracts/application_function_surface_v1.json`.
- New control test: `tests/architecture/test_application_function_surface_manifest.py`; **created, not run locally**.
- Historical function evidence source: `v171.89`.
- Identity ownership migration remains qualified on exact-green `v173.36`; no migration-control/read-switch rollback.
- Next exact-head CI required for `v173.40`.
