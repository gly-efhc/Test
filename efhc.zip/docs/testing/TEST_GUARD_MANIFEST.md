# TEST GUARD MANIFEST

Канонические законы AI-архива: `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`.
 v173.42

- Версия: `v173.42`.
- Цикл: `1718`.
- Последний предоставленный GitHub CI: `84954546920` на exact `v173.41`, archive `12135299` bytes.
- Green gates: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff, frontend production build.
- Mypy: `2` errors `no-any-return`.
- Pytest: `17 failed / 1485 passed / 22 skipped`.
- Подтверждённые failures исправлены только по предоставленному CI evidence; локальные проверки не выполнялись.
- Fail-closed registry: `contracts/application_function_surface_v1.json` — `259` критических Python symbols / `44` modules / `14` required files.
- Control test: `tests/architecture/test_application_function_surface_manifest.py`; локально не запускался.
- Test-layer `tg_id` registered count по supplied CI снизился с historical manifest `440` до live `429`; business-selector violations в соответствующем CI gate не были заявлены как failure. Exact equality заменена на fail-closed non-growth expectation.
- Identity ownership migration остаётся qualified на exact-green `v173.36`; migration-control/read-switch/tg-owned runtime не возвращается.
- Следующий exact-head CI требуется для `v173.42`.
