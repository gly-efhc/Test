# TEST GUARD MANIFEST v173.36

- Версия: `v173.36`.
- Цикл: `1711`.
- Active architecture test files: `261`.
- Active Python test files: `441`.
- Fresh GitHub CI `84921131844` проверил byte-exact `v173.35`: checkout `ffdc369b3eaaf65eacbac48f31e7e7743458434e`, archive size `11846393`, Git blob SHA-1 `9d729596849cd9c80eb6480acc92c04881fe7419`.
- Pytest: `1498 passed / 22 skipped / 1 warning`; total collected outcome `1520`.
- Alembic/PostgreSQL, flake8, Ruff, Mypy, Bandit, compileall, npm ci и production frontend build: PASS.
- Подтверждённых failures в 1711 нет; локальный полный pytest/CI/build не повторялся.
- Test `tg_id` registry: `441`; business-selector violations = `0` по tested `v173.35` state.
- `global_id=1313131313` зарезервирован для SuperAdmin и защищён architecture guard.
- Active AI archive-law authority: `docs/AI/AI_ARCHIVE_LAWS.md`.
- Admin NFT authority: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.
- Следующий цикл: `1712 Qualification milestone`.
- `v173.36` — documentation/status/version packaging continuation после exact-green `v173.35`; для байтов `v173.36` требуется следующий exact-head CI.
