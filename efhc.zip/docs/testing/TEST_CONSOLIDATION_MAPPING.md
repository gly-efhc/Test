<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
# Test consolidation mapping

Текущий test-layer не использует version/cycle-specific tests как
постоянные guards.

## Действующие тематические группы

- Identity и API: `test_global_id_canon_foundation.py`,
  `test_global_id_api_contract.py`, `test_global_id_types.py`.
- Provider boundaries: Telegram, TON и cross-provider suites.
- PostgreSQL: финальная release schema `0001` и текущие owner FK.
- Экономика: `test_economic_risk_guards.py` и
  `test_economic_integrity_guards.py`.
- Frontend/PWA: текущие case-модули обнаруживаются динамически; ссылки
  на архивированные case-файлы запрещены.
- Документы: `test_active_document_surface.py`.
- Активный test-layer: `test_active_test_surface.py`.

## Архив

Полный mapping каждого старого файла:
`docs/history/test_archive/TEST_ARCHIVE_MANIFEST_v173_10.json`.

Переименования:
`docs/history/test_archive/TEST_RENAME_MAP_v173_10.json`.
