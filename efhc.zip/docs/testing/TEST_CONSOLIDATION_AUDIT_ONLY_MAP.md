<!-- EFHC_GLOBAL_IDENTITY_CANON_V3: ACTIVE -->
# Test audit-only map

Исторические test suites не участвуют в pytest collection и находятся
в `docs/history/test_archive/ИСТОРИЧЕСКИЕ_TESTS/`.

Текущие метрики и классификация всех активных и архивных файлов:

- `docs/history/test_archive/TEST_AUDIT_v173_10.csv`;
- `docs/history/test_archive/TEST_AUDIT_v173_10.json`;
- `docs/history/test_archive/TEST_AUDIT_SUMMARY_v173_10.json`.

Архив не является источником требований. Действующие guards указаны в
`docs/testing/TEST_GUARD_MANIFEST.json`.
