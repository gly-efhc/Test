# Governance v171.60 replacement mapping

- `ops/frontend/cycle_1573_v171_59_browser_proof.py` → removed from active ops; forensic copy in `docs/history/invalid_application_proof_v171_59/`; future replacement must be route-backed `page.goto()` proof.
- `ops/frontend/profile_header_component_proof_v171_56.py` → removed from active ops; forensic copy retained; component HTML is not application proof.
- Multiple startup orders in AGENTS/KERNEL/READING_ENTRYPOINT/AI Startup → single `START_HERE.md`, with compatibility pointers retained.
- Hard-coded AI law hash in integrity script → active lock-controlled hash with synchronized CANON/NORM.

Protection semantics are strengthened; no runtime/business guard is removed.
