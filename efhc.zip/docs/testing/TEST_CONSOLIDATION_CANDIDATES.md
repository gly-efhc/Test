# Test consolidation candidates — audit only, current repair cycle

Status: AUDIT ONLY. No test was deleted, archived, skipped, xfailed or merged
in this document.

## Rule

Consolidation means reducing duplicate files while preserving every protective
invariant. It is illegal to replace many specific guards with one shallow smoke
test. Every future consolidation requires one-to-one mapping in
`docs/testing/TEST_GUARD_MANIFEST.json`.

## Candidate groups

| Domain | Possible safe form | Why not done now |
|---|---|---|
| Wave-3 i18n domain guards | One parametrized file with domain table and per-domain expected keys. | Requires user approval and mapping for every old file. |
| Cycle-marker docs guards | One parametrized cycle-marker guard using a table of file → markers. | Current failures are being healed first; no consolidation during repair. |
| Public visual evidence guards | Domain parametrization by route and evidence file. | Must preserve route-specific invariants and non-claim markers. |
| PWA / shell / document guards | One domain file with separate tests for `_app`, `_document`, `/app`, service worker and manifest. | Needs mapping because these invariants are different. |
| Route/evidence existence guards | Parameterized manifest-driven guard. | Requires a verified manifest before merging. |

## Non-candidates

- `test_max_line_length_72.py`: this is a style blocker, not a duplicate guard.
- AI archive laws integrity tests: these are legal locks and must stay explicit.
- Test-suite integrity guard: this is a meta-guard against hiding tests.

## Required user decision

Future consolidation is allowed only after the user approves a concrete
manifest showing:

1. old test;
2. protected invariant;
3. replacement active test;
4. collection proof;
5. reason why the replacement is safe.


## Cycle 1390 result

User authorized consolidation in several domains. This cycle completed only the
safe, fully mapped wave-3 i18n consolidation.

Completed:

- wave-3 i18n guards: five old active files mapped to one active wrapper.

Still audit/planning only:

- cycle-marker docs guards;
- public visual evidence guards;
- PWA / shell / document guards;
- route/evidence existence guards.

These remaining groups must not be merged until their one-to-one replacement
mapping is written and approved by the active guard manifest.


## Cycle 1398 audit-only map

Cycle 1398 prepared a stable candidate map without changing tests:

`docs/testing/TEST_CONSOLIDATION_AUDIT_ONLY_MAP.md`

Generated evidence:

`docs/history/legacy_artifacts/reports/generated/test_consolidation_audit_only_map_v169_80.json`

Mapped groups:

- docs/cycles and cycle-marker guards;
- public visual evidence guards;
- PWA / shell / document guards;
- route / evidence existence guards.

No active consolidation was executed in cycle 1398. The map is not a
permission to merge tests. Cycle 1399 still requires direct user approval.
