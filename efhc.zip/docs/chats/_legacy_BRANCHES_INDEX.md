<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / PRESERVED TRANSCRIPT**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Индекс восстановленных веток чатов

Дата обновления: 2026-06-01.
Статус: живой индекс источников стенограммы.

## Правило

Этот индекс показывает, какие ветки чатов физически сохранены в `docs/NORM/CHAT_BRANCHES/` и как они используются для восстановления `docs/NORM/CHAT_TRANSCRIPT.md`.

Поздние ветки имеют приоритет над ранними. Старые ветки являются историческим слоем и не отменяют более поздние решения пользователя.

## Таблица веток

| Ветка | Файл | Статус | Использование |
|---|---|---|---|
| 20 | `20.md` | сохранена | визуальный frontend v168_33-v168_51 |
| 19 | `19.md` | сохранена | visual audit, Dragon, PWA, tg_id |
| 18 | `18.md` | сохранена | HEAD/no-delete и road-fix v168_01-v168_16 |
| 13 | `13.md` | сохранена | document layers, glossary, release gate |
| 10 | `10.md` | сохранена | work pass, CI, Healer, test rules |

## Дедупликация веток 21 и 22

`docs/NORM/CHAT_BRANCHES/21.md` и `docs/NORM/CHAT_BRANCHES/22.md` удалены как точные дубликаты. Canonical copies сохранены без переименования:

- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/21.md`
- `АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/АРТЕФАКТЫ/ИСТОРИЧЕСКИЕ_ДОКУМЕНТЫ/docs/NORM/CHATS/22.md`

## Ветка 20

Источник: `docs/NORM/CHAT_BRANCHES/20.md`.

## Ветка 19

Источник: `docs/NORM/CHAT_BRANCHES/19.md`.

## Ветка 18

Источник: `docs/NORM/CHAT_BRANCHES/18.md`.

## Ветка 13

Источник: `docs/NORM/CHAT_BRANCHES/13.md`.

## Ветка 10

Источник: `docs/NORM/CHAT_BRANCHES/10.md`.
