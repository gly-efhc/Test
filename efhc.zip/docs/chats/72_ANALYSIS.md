# Анализ чата 72 — forensic recovery и authority-аудит цикла 1849

Статус: ТЕКУЩЕЕ RECOVERY-ДОКАЗАТЕЛЬСТВО / цикл `1849`.

Источник: `docs/chats/72.md`, SHA-256 `7e0b97e3b380f48404722ba90d5bf65a1ddaabcebd70681f2cdcc4fe0a4c88d7`. Transcript сохранён побайтно; исторические ошибочные claims внутри него не переписываются, а корректируются текущими authority-документами.

## 1. Что уже физически закрыто после состояния v175.11

1. Rank-guard regression из `v175.11` устранён в `v175.12`: граница legacy-токена ограничена ASCII-буквами. Поэтому identifier-like формы с `_`/цифрами остаются detectable, а обычное слово `demonstrating` не даёт ложного совпадения. Exact-head CI `90285472566` не содержит этих прежних pytest FAIL.
2. FAQ mismatch `6-15`, `7-6`, `10-2` устранён физически в `v175.12` во всех `16` SSOT/runtime языках и bundled representation. Новых Q&A не добавлялось; структура остаётся `16 × 20 × 230`.
3. Active FAQ/current-state pointers были переведены на актуальную recovery-линию; translation/localization execution заморожен.
4. Short Operator / ZIP-first / latest OWNER priority уже присутствует в current entry points, но отдельный активный CANON добавлен в текущем recovery release, чтобы исключить повторную зависимость от исторических формулировок.

## 2. Хвосты из 72.md, которые оставались в v175.13

1. `FAQ-APPROVAL-0040` содержал слишком сильный claim о text-specific OWNER approval. OWNER утвердил план/scope screen-name reconciliation, но конкретные EN wording `14-2/14-12/14-17` не были отдельно показаны и утверждены как готовый текст. В current manifest/register эта запись корректируется как scope-authorized implementation record, а не как отдельное text-specific OWNER approval.
2. `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md` всё ещё требовал запуск route-selected tests/guards **до packaging**, что конфликтовало с последним OWNER ZIP-first law. Эта строка superseded: обязательный порядок теперь implementation → minimal governance/report → physical ZIP → optional targeted checks only if time remains.
3. Чат `72.md` физически отсутствовал в `docs/chats/`; добавлен побайтно и зарегистрирован.
4. Текущий exact-head CI `90285472566` подтвердил новый Ruff `I001` и один Russian engineering language policy RED. Они относятся к текущему recovery scope и исправляются в candidate `v175.14`.

## 3. Что не считается хвостом текущего product scope

- Temporary claims `681`/`174` multilingual positions из failed trees не являются physical project state и не восстанавливаются.
- Historical reports/cycle records с неверными на тот момент claims не переписываются; они сохраняются как provenance и superseded evidence.
- Плановые переводы `1850–1883` не возобновляются автоматически.
- DB schema, Alembic, financial/security/TON/payment architecture в 72.md не показаны как физически повреждённые; текущий corrective scope их не меняет.

## 4. Текущая граница release

Физический вход: `EFHC_Bot_v175_13.zip` / SHA-256 `bbbf4f8cf74c67217f6c886812fbcd0db1be57f56d7c6f62bcf65c35202b00f3`.

Точный CI по HEAD: `90285472566`.

Кандидат после текущих исправлений: `v175.14`. Цикл `1849` остаётся открытым до нового exact-head CI для candidate; GREEN/PASS заранее не заявляется.
