<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / PRESERVED TRANSCRIPT**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

# Папка восстановленных веток чатов

Эта папка хранит первоисточники восстановленных веток чатов EFHC Bot.

Файлы вида `18.md`, `19.md`, `20.md` являются источниками для
восстановления `docs/NORM/CHAT_TRANSCRIPT.md`.

Они не являются заменой стенограммы и не являются заменой
`docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`.

## Слои

- `CHAT_BRANCHES/*.md` — первоисточники старых веток.
- `CHAT_TRANSCRIPT.md` — краткая память диалога из чата в чат.
- `QUESTIONS_AND_ANSWERS_REGISTER.md` — вопросы, ответы и согласования.

## Правило приоритета

Более поздние ветки имеют приоритет над более ранними.

Старые ветки используются как исторический источник, но не отменяют
новый канон пользователя.

## Текущий набор

- `20.md` — визуальный frontend v168_33-v168_51.
- `19.md` — visual audit, Dragon-style, PWA, tg_id independence.
- `18.md` — HEAD/no-delete, reading-control, road-fix v168_01-v168_16.
- `13.md` — document layers, glossary-first, release-core v167.
- `10.md` — work pass, CI hardening, Healer, test rules.

## Запрет

Нельзя восстанавливать отсутствующую ветку догадками. Если файла нет,
нужно честно указать пропуск.
