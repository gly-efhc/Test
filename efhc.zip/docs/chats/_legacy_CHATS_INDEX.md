# Индекс чатов EFHC Bot

Статус: living index.
Дата обновления: 2026-08-06.

## Сохранённые чаты

- `40.md` — сохранённая canonical-стенограмма ветки 40.
- `41.md` — сохранённая canonical-стенограмма ветки 41.
- `43.md` — сохранённая canonical-стенограмма ветки 43.
- `44.md` — сохранённая canonical-стенограмма ветки 44.
- `45.md` — сохранённая canonical-стенограмма ветки 45.
- `47.md` — сохранённая canonical-стенограмма ветки 47.
- `49.md` — сохранённая canonical-стенограмма ветки 49.
- `50.md` — сохранённая canonical-стенограмма ветки 50.
- `51.md` — сохранённая canonical-стенограмма ветки 51.



- `36.md` — видимый чат EFHC Bot: циклы `1528–1538`,
  Kernel/map compaction, fresh CI repairs, referral persistence,
  artifact hygiene and prompt continuation into cycle 1539/1540;
  canonical copy в `docs/NORM/CHATS/36.md`.

- `35.md` — видимый чат EFHC Bot: циклы `1515–1525`,
  live proof gate, frontend i18n closure, withdrawals P0 repair,
  withdrawals fixture isolation, archive numbering incident and
  corrected canonical HEAD `EFHC_Bot_v171_00_cycle_1525_archive_numbering_rollover_repair.zip`;
  canonical copy в `docs/NORM/CHATS/35.md`.

- `34.md` — экспорт рабочего чата EFHC Bot: циклы `1500–1514`,
  переход к диапазону `1501–1600`, Dashboard/Admin repair line,
  wallet/payment/withdraw каноны, CI log repairs, admin runtime fixes
  and final HEAD `EFHC_Bot_v170_90_cycle_1514_admin_ux_qa_visual_regression_click_proof.zip`;
  canonical copy в `docs/NORM/CHATS/34.md`.


- `33.md` — экспорт рабочего чата Dashboard/Admin линии: циклы
  `1486–1499`, закрытие dashboard-направления, VIS-03 repair,
  green-proof входной линии, финальный HEAD `EFHC_Bot_v170_75_cycle_1499_vis_03_withdraw_history_semantic_repair.zip`;
  canonical copy в `docs/NORM/CHATS/33.md`.

- `32.md` — экспорт рабочего чата Dashboard-направления: циклы
  `1466–1485`, dependency audit triage, runtime dashboard ports,
  финальный HEAD `EFHC_Bot_v170_61_cycle_1485_admin_deposits_dashboard_upgrade.zip`;
  canonical copy в `docs/NORM/CHATS/32.md`.
- `31.md` — экспорт рабочего чата Dashboard foundation линии:
  циклы `1447–1465`, chat docs intake, visual/i18n repair,
  dashboard toolbar foundation, финальный HEAD `EFHC_Bot_v170_41_cycle_1465_dashboard_toolbar_foundation.zip`;
  canonical copy в `docs/NORM/CHATS/31.md`.


- `30.md` — видимый полный чат текущей linkage-линии:
  циклы `1437–1446`, P0 linkage repair, CI log repair,
  BNB skin cleanup, финальный контекст для `v170.22`;
  canonical copy в `docs/NORM/CHATS/30.md`.
- `28.md` — видимый архив диалога линии `v169.96 → v170.12`:
  циклы `1422–1436`, economic repair, security repair,
  Operator Kernel hardening, cold-start UX, linkage freeze;
  canonical copy в `docs/NORM/CHATS/28.md`.
- `27.md` — подробный экспорт рабочего чата после закрытия
  диапазона `1390–1400`: старт от `v169.82`, i18n repair,
  P0 Red Zone plan, cycles `1401+`; canonical copy в
  `docs/NORM/CHATS/27.md`.
- `26.md` — подробный экспорт рабочего чата диапазона
  `1391–1400`: CI log repair, test-control law, filename
  hygiene, range closure; canonical copy в
  `docs/NORM/CHATS/26.md`.
- `25.md` — видимый экспорт рабочего чата ветки 25: диапазон
  `1390–1400 — CI log repair and test healing`, финальный
  HEAD входной линии `EFHC_Bot_v169_72_cycle_1390_filename_`
  `hygiene_repair.zip`, правило продолжения `1391+` через логи,
  root cause repair и test-control law; canonical copy в
  `docs/NORM/CHATS/25.md`.
- `24.md` — видимый экспорт рабочего чата ветки 24: диапазон
  `1351–1375 — CLOSED`, финальный HEAD
  `EFHC_Bot_v169_54_tonconnect_wallet_ux_range_closure.zip`,
  финальная навигация `map_element.md`, правило `1376+` только
  после нового аудита/задачи; canonical copy в
  `docs/NORM/CHATS/24.md`.
- `22.md` — видимая стенограмма ветки 22, canonical copy в
  `docs/NORM/CHATS/`.
- `21.md` — видимая стенограмма ветки 21, canonical copy в
  `docs/NORM/CHATS/`.

## Дедупликация

Дубликаты `docs/NORM/CHAT_BRANCHES/21.md` и
`docs/NORM/CHAT_BRANCHES/22.md` удалены, потому что их содержимое
полностью совпадало с `docs/NORM/CHATS/21.md` и
`docs/NORM/CHATS/22.md`.

`24.md`, `25.md`, `26.md`, `27.md`, `28.md`, `30.md`, `31.md`, `32.md`, `33.md`, `34.md`, `35.md` и `36.md` добавлены
только в canonical-папку `docs/NORM/CHATS/`; дубликаты в
`docs/NORM/CHAT_BRANCHES/` не создавались.

## Связанные документы

- `docs/NORM/CHAT_TRANSCRIPT.md` — живая стенограмма текущей линии.
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` — отдельный Q/A
  реестр.
- `docs/NORM/CHAT_BRANCHES/` — восстановленные ранние ветки 10, 13,
  18, 19, 20; ветки 21, 22, 24, 25, 26, 27, 28, 30, 31, 32, 33, 34, 35 и 36 хранятся
  только в canonical `docs/NORM/CHATS/`.

Проверочный якорь текущей canonical-группы: ветки 21, 22, 24, 25,
26, 27, 28, 30, 31, 32, 33, 34 и 35.


## Compatibility guard anchors

Legacy guard anchor: ветки 21, 22 и 24.
Legacy guard anchor: ветки 21, 22, 24 и 25.
Legacy guard anchor: ветки 21, 22, 24, 25, 26, 27, 28 и 30.

Legacy guard anchor: ветки 21, 22, 24, 25, 26, 27, 28, 30, 31, 32, 33, 34, 35 и 36.
