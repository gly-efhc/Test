<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **HISTORICAL / SUPERSEDED.** Этот план или аудит сохранён для истории.
> Действующий закон: `global_id` — главный персональный идентификатор и owner;
> `tg_id` — только Telegram provider subject. Старые стадии `user_id` не являются
> текущим контрактом.

# План UserId и TON-аутентификации — v171.98

## Принятый фундамент

Цикл 1601 подтвердил точный EXPAND-контур без historical backfill,
runtime read switch и финансового ownership switch. Alembic head —
`0002`; `users.id` остаётся primary key; `users.user_id` остаётся
nullable BIGINT.

## TON-вход

1. Валидный TON Proof и известная TON identity открывают прежний
   `user_id`.
2. Новый подтверждённый кошелёк создаёт `users`, `user_id`,
   `user_identities(provider=ton_wallet)` и `wallet_bindings` одной
   транзакцией.
3. Wallet connection без TON Proof не является аутентификацией.
4. Фиктивный `tg_id` для TON-only пользователя запрещён.
5. Автоматическое объединение существующих аккаунтов запрещено.

## Следующий цикл

`1602 — независимый reconciliation baseline`.
Реальное PostgreSQL выполнение обязательно для exit gate; локальный
SQL, unit-тесты и planning harness не заменяют runtime evidence.
