# CURRENT HEAD — v174.47 / цикл 1793 CI qualification repair

- Exact GitHub CI `87288059313` проверил `v174.46` SHA-256 `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`. Все recorded gates GREEN, кроме pytest: `1 failed / 1727 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — устаревший baseline русскоязычной инженерной политики для `CONTINUE_IN_NEW_CHAT.md`: файл содержит `53` неизменяемых исторических англоязычных snapshot-фрагмента при разрешённом historical count `36`.
- Исторические handoff-фрагменты не переписываются. Baseline повышен строго `36 → 53`; любой следующий новый англоязычный prose-фрагмент остаётся fail-closed нарушением.
- Runtime/backend/frontend/DB не менялись. Frozen `0001`, отсутствие `0002+`, FAQ standalone authority, FRONTEND_v146 и deep-remediation contracts сохранены.
- Immutable report `02365`; следующий `02366`; canonical handoff `EFHC_Bot_v174_47.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.46 / цикл 1793 CI qualification repair

- Exact GitHub CI `87285361835` проверил `v174.45` SHA-256 `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Mypy, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend build. RED: Ruff `1×I001`, pytest `17 failed / 1711 passed / 22 skipped / 1 warning`.
- Подтверждённый runtime defect: Panels после canonical financial SSOT migration всё ещё использовал удалённый `transactions_service.SpendBreakdown`; теперь `SpendBreakdown/split_bonus_then_main` импортируются напрямую из `app.standards.finance_rules`.
- Qualification repair: financial SSOT guard проверяет AST contract, Shop guard требует безопасный `CAST(:extra AS jsonb)`, Ruff import-order исправлен.
- Deep backend remediation не откатывается; frozen `0001`, отсутствие `0002+`, FAQ standalone authority и FRONTEND_v146 сохраняются.
- Immutable report `02364`; следующий `02365`; canonical handoff `EFHC_Bot_v174_46.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.45 / цикл 1793 CI qualification repair

- Exact GitHub CI `87278222904` проверил `v174.44` SHA-256 `54b882e871626e7190161c419e9c1f407c9b6a6080478465570ab08856354154`, checkout `001316adea12d34348a510da3cc8b401cbc6f199`.
- GREEN: Development HEAD SHA, Flake8 full-report, Bandit, compileall, PostgreSQL preflight/Alembic, npm install и frontend production build. RED: Flake8 critical `2×F821`, Ruff `8`, Mypy `2`, pytest `8 failed / 1720 passed / 22 skipped / 1 warning`.
- Подтверждённые source repairs: восстановлен `get_session_factory` для auth/provider session boundary; два Shop JSONB bind-cast приведены к `CAST(:extra AS jsonb)` для SQLAlchemy/asyncpg.
- Qualification repairs: Ruff import/SIM/F401 hygiene; scheduler tests переведены на canonical `db_session()`; middleware guards проверяют единый installer; profile export guards проверяют текущую sync-background + async-failure cleanup семантику.
- Deep-remediation contracts `v174.44` не откатываются: root transaction ownership, scheduler cancellation, FSM atomicity, financial SSOT и bounded export сохраняются. Frozen `0001`, FAQ и FRONTEND_v146 unchanged; `0002+` отсутствует.
- Immutable report `02363`; следующий `02364`; canonical handoff `EFHC_Bot_v174_45.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.44 / цикл 1792 deep backend remediation

- Exact CI `87235658448` проверил `v174.43` SHA-256 `0b36f6f734c8a0e3dd94d68b5b35c05331a078845d657bf5021620280d19c739`, checkout `ce2f5085551ff06c1e6a1512eccc6dec3749f049`; все recorded gates GREEN кроме pytest `5 failed / 1697 passed / 22 skipped / 1 warning`.
- Direct owner scope: реализованы подтверждённые `DEF-01…DEF-18` из Deep Backend Remediation Specification и повторно проверен audit. Основные изменения: startup/lifecycle, transaction ownership, scheduler cancellation, FSM atomicity, Shop/payment UoW, CRUD savepoints, единый financial SSOT, bounded queries/export и canonical DB session contract.
- CI-specific watcher failures исправлены только в test harness; production P0 `trusted time → 180-day barrier → replay/idempotency → mutation → ledger` не откатывался. Historical English snapshots не переписывались; language baseline ограничен фактическим historical count.
- Frozen `0001`, FAQ authority/content и FRONTEND_v146 visual/UX/text сохранены; `0002+` отсутствует.
- Immutable report `02362`; следующий `02363`; canonical handoff `EFHC_Bot_v174_44.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются только доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.43 / цикл 1792

- Input exact CI: run `87220054352` on `v174.42` SHA-256 `2ef41df8ec14235d584ccc2a2994cca780c58d0e993de2aacdba3957c56384c8`, checkout `fe6d0d4f32a75d8419f0d165afffc18fef76cc02`.
- Confirmed RED repaired: Ruff 16, Mypy 1, pytest 11 failures by seven root-cause groups; no speculative repairs.
- P0 watcher and Telegram webhook transaction runtime are preserved; six watcher RED and two webhook RED were stale/new test-harness defects, not reasons to rollback runtime.
- Runtime fixes are bounded to scheduler health alias and TonConnect stable typed fail-closed reason. Owner ENV templates synchronized.
- Current report `02361`; next `02362`; canonical handoff `EFHC_Bot_v174_43.zip`.
- Status: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Historical blocks below are evidence only and do not override this first block.

# CURRENT HEAD — кандидат v174.42 / цикл 1791 corrective re-audit по утверждённому ТЗ

- Входной exact candidate: `v174.41`, SHA-256 `baf1ab7b318c69988a4079d8aef022092e4a0499579058e99431cf58903b9a2c`. Owner-approved ТЗ повторного аудита SHA-256 `7f17d680a06cca5cc581a27a0cf1577d5c0a51e9cbe1c3184ad40ae0969b75e8` фиксирует только подтверждённые defects и запрещает менять бизнес-экономику, FAQ authority и frozen schema.
- Ранее зафиксированный exact-head GREEN anchor остаётся `v174.40` по GitHub CI `87088984879`; GREEN **не наследуется** текущим `v174.42`.
- Release-blocking Telegram repair: dedupe marker больше не коммитится до business processing; dedupe storage failure fail-closed; JSON валидируется до marker; webhook владеет единственным root transaction; cancellation/error вызывают rollback; compensating DELETE удалён; `/start` unexpected onboarding errors пробрасываются; onboarding core transaction-neutral и использует savepoint.
- Security/error repair: 17 broad internal 5xx exception disclosures закрыты stable error codes; canonical `app.main:app` применяет `TrustedHostMiddleware`, когда allowlist настроен; active wallet TonConnect proof использует configured-domain-first canonical resolver и не считает request Host production authority.
- Validation/lifecycle repair: raw `Idempotency-Key` валидируется до hash (`<=128`, control chars forbidden); scheduler operational values имеют positive bounds и backoff ordering; logging всегда заполняет `tg_id`; PWA снимает `updatefound/statechange`; serverless VIP tick использует explicit `db_session()` context.
- Добавлены regression/integration test sources, включая real dedupe helper, cancellation/fail-closed cases и PostgreSQL concurrent duplicate/root transaction scenarios. Локально эти tests не запускались; результат должен подтвердить fresh exact-head GitHub CI.
- Frozen migration `0001` и FAQ runtime/FAQ duplicate-control content не менялись. `0002+` не создана. FAQ остаётся самостоятельным checked-in release asset.
- Frontend visual/UX/text authority FRONTEND_v146 не изменён. PWA runtime lifecycle source изменён non-visual; release metadata синхронизированы статически: authority `INTEGRATED_FRONTEND_SOURCE_v174.42_FRONTEND_v146`, controlled entries `195`, source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`, PWA `efhc-acecaa494ab54fe4`.
- Immutable report: `02360`; следующий `02361`. Canonical handoff: `EFHC_Bot_v174_42.zip`. Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.41 / цикл 1791 exact-head GREEN + полный функциональный аудит

- GitHub CI `87088984879` полностью квалифицировал exact `v174.40`: archive SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`; все recorded gate exits `0`; pytest `1670 passed / 22 skipped / 1 warning`; frontend production build и PostgreSQL/Alembic PASS. `v174.40` зафиксирован как **EXACT-HEAD GREEN**.
- По прямому owner order открыт цикл `1791` и выполнен полный статический аудит зарегистрированной application surface и всех финансово/security/ops-critical mutation contours. Public surface сохранён: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`; registered protected Python surface `371 symbols / 70 modules / 86 files`; frontend product pages `39`.
- Подтверждённые repairs нового candidate: watcher P0 `trusted time → 180-day barrier → replay → mutation → ledger`; readiness принимает только authorized migration `0001`; `/cron/tick` в prod/stage регистрирует scheduler jobs strict; encrypted recovery требует ciphertext SHA-256; production update/release contour использует канонический `EFHC_Bot_vNNN_NN.zip` без `_RELEASE`.
- DR/VPS runbooks и current application-function authority синхронизированы с exact source. Referral leaderboard public routes отмечены retired при сохранённой referral economy; Skins — progression-only, `/skins/buy/{skin_id}` остаётся fail-closed compatibility `409 SKIN_COMMERCE_DISABLED`.
- Database schema не менялась: ORM `52 = 45 core + 7 admin`, frozen `0001` сохранён, `0002+` отсутствует. Schema lock — governance lock на неутверждённый DDL, не runtime table/CRUD lock.
- FRONTEND_v146 runtime bytes не менялись. Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.41_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ/locale/PWA остаются standalone checked-in release assets.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI после audit repairs не запускались. Поэтому `v174.41` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**, а не GREEN.
- Immutable report: `02359`; следующий `02360`. Canonical handoff: `EFHC_Bot_v174_41.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.40 / цикл 1790 CI qualification hygiene

- GitHub CI `87074955772` проверил exact `v174.39`: SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872`, checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`. GREEN все recorded gates кроме pytest; pytest `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Единственный confirmed defect — два английских docstring в development-only FAQ duplicate-control verifier. Исправлены только docstring; runtime/frontend/backend/schema semantics не менялись.
- FAQ остаётся самостоятельным checked-in release asset; SSOT — duplicate control only, без runtime write. Release packaging остаётся application-byte verify-only.
- Важно: database/schema lock — это governance lock на неутверждённые DDL/schema/migration changes, **не** runtime lock таблиц и **не** запрет CRUD. Существующие 52 таблицы работают штатно. Frozen `0001` и запрет `0002+` сохраняются до отдельного direct owner decision о schema unlock/change.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.40_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. Frontend controlled bytes не менялись.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не запускались. Candidate `v174.40` требует следующего exact-head GitHub CI.
- Immutable report: `02358`; следующий `02359`. Canonical handoff: `EFHC_Bot_v174_40.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.39 / цикл 1790 release-asset independence + CI qualification repair

- GitHub CI `87062684580` проверил exact `v174.38`: SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75`, checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`. GREEN: Development HEAD SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures классифицированы как qualification-only: hardcoded frontend authority предыдущей версии и два legacy-term guards, ошибочно сканировавшие current control-plane/evidence summaries. Runtime/backend/frontend product behavior этим CI не опровергнут.
- Прямое owner decision цикла 1790: checked-in frontend FAQ является самостоятельным production release asset; FAQ SSOT остаётся только дублирующим контролем и не может генерировать или переписывать runtime FAQ.
- Release packaging переведён в verify-only application-asset mode: `build_release_archive.py` проверяет заранее готовые FAQ/locale/PWA assets и не запускает FAQ/PWA generators. Packaging создаёт только собственные release metadata/checksums в staging.
- Dependency audit: frontend prebuild уже verify-only; OpenAPI/API/backend/schema runtime не генерируются из docs/SSOT при release packaging; development generators остаются вне packaging.
- Database migration lock остаётся active: frozen `0001_initial_release_schema.py`; `0002+`/schema expansion только по отдельному direct owner decision. В cycle 1790 schema не менялась.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.39_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ content Q/A bytes не менялись; изменён только authority header и release-control metadata.
- Локальные tests/build/CI/Alembic/PostgreSQL не запускались. Candidate `v174.39` требует следующего exact-head GitHub CI.
- Immutable report: `02357`; следующий `02358`. Canonical handoff: `EFHC_Bot_v174_39.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.38 / цикл 1789 continuation CI qualification repair

- GitHub CI `86992003426` проверил exact `v174.37`: SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d`, checkout `7384e8284dbde416086a13bd23de7136be585681`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures repaired только в qualification layer: stale Admin history literal → current functional contract; FAQ test function name → Russian engineering policy; stale `current_cycle` → current state key `cycle`. Approved FRONTEND_v146 runtime не откатывался.
- FAQ current parity: `13 × 250/250` SSOT↔runtime. Runtime/prebuild SSOT-independent; release packaging пока SSOT-generating. Standalone verify-only FAQ packaging — **RECOMMENDATION, не owner decision**, поэтому release scripts не менялись.
- Routes/schema audit: `160 paths / 166 public ops / 8 hidden / 174 mounted`; OpenAPI `169 schemas`; ORM/frozen migration exact `52 = 45 core + 7 admin`. Migration lock остаётся active: `0001` frozen; `0002+` только по direct owner decision.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.38_FRONTEND_v146`; entries `195`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`. Backend routes/services, frozen `0001`, FAQ runtime и release scripts cycle continuation не менялись.
- Локальные tests/build/CI не запускались. Candidate `v174.38` требует следующего exact-head GitHub CI.
- Immutable report: `02356`; следующий `02357`. Canonical handoff: `EFHC_Bot_v174_38.zip`; descriptive suffixes/owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.37 / цикл 1789 CI qualification repair

- GitHub CI `86988434882` проверил exact предыдущий `v174.36`: SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77`, checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 failures — stale qualification guards относительно approved FRONTEND_v146: Admin copy literal заменён функциональным EFHCb/EFHCm selector contract; FAQ historical translation literals заменены current SSOT↔runtime parity; HI history registry expectation `7 -> 13`. Runtime/frontend patch не откатывался.
- FAQ delta FRONTEND_v146 велик только в `hi/id/sw`; остальные 10 языков Q/A не изменены. Cycle 1789 не меняет FAQ runtime content.
- Release audit: frontend runtime/prebuild отвязан от Python/docs/SSOT, но release packaging всё ещё намеренно генерирует FAQ из SSOT через `build_release_archive.py -> prepare_frontend_release_assets.py -> generate_faq_catalogs_from_ssot.py`. Release scripts не менялись.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.37_FRONTEND_v146`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA build id `efhc-1466a8410f8c50ab`. Frozen `0001`, backend/API/financial semantics unchanged.
- Локальные tests/build/CI не запускались. Candidate `v174.37` требует следующего exact-head GitHub CI.
- Immutable report: `02355`; следующий `02356`. Canonical handoff: `EFHC_Bot_v174_37.zip`, без descriptive suffix и sidecars.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT PROJECT STATE — v174.36 / cycle 1788 qualification repair

- Exact supplied CI evidence: run `86966635485` tested previous `v174.35` SHA `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`; frontend build and core backend/schema gates GREEN, Ruff/pytest qualification RED.
- Approved FRONTEND_v146 remains visual/UX/text authority; stale tests do not override it.
- Current frontend source authority: `INTEGRATED_FRONTEND_SOURCE_v174.36_FRONTEND_v146` / `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`.
- Candidate `v174.36` is not exact-head GREEN until the next GitHub CI. Local full test/build execution was not performed.

# CURRENT DEVELOPMENT HEAD — кандидат v174.35 / цикл 1788

- Owner открыл `1788` для интеграции supplied FRONTEND_v146 runtime-only patch в exact `v174.35`.
- Patch SHA-256 `19e7b087da7ce017013fa025bcbba29bdeca708c565008d2610139df56d87ebf` применён к `74` frontend paths и удалён после установки; base `VERSION` остаётся `v174.35`.
- Frontend source authority: `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`; backend/API/security/financial CANON не подменяется patch.
- Последний доступный exact-head GREEN: `v174.33`, CI `86661926957`. `v174.35` остаётся candidate до нового exact-head CI.
- Новые CI logs в текущем handoff фактически отсутствуют; no-evidence failures не реконструируются.
- Immutable report `02353`; next `02354`; future range `1801–1900` создан без автоматического открытия циклов.

> **Historical boundary:** нижележащие прежние «текущие» блоки являются историческими snapshots.

# CURRENT DEVELOPMENT HEAD — кандидат v174.34 / цикл 1787

- Exact-head `v174.33` полностью GREEN в GitHub CI `86661926957`; SHA-256 payload `ae5dc9fb2657957b40560cbb350aad435168532c575a2c492ba703f3635f4a5f`; pytest `1664 passed / 22 skipped / 1 warning`; frontend PASS; все canonical gates `exit=0`.
- `v174.34` — document/Q&A/archive-integrity continuation цикла `1787`; production backend/frontend/OpenAPI/schema/financial semantics не меняются.
- Active startup: `START_HERE.md` → `KERNEL.md`. Active Q/A authority: `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`. Historical recovery audit: `docs/audits/Q_A_CHAT_RECOVERY_AUDIT.md`.
- Проверены все 35 доступных numbered chats; 58 explicit Q/A markers в 9 чатах. Неизвестные ответы не реконструируются.
- Immutable report `02352`; следующий `02353`; после `1787` автоматически утверждённых functional cycles нет. Следующий verifier — exact-head GitHub CI `v174.34`.

> **Historical boundary:** все расположенные ниже прежние «текущие» блоки являются снимками истории и не переопределяют этот первый блок.

## Текущая рабочая блокировка — кандидат v173.71 / цикл 1743 — exact-head CI burn-down после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_70.zip`, SHA-256 `fe70e8d27ad1021c85bc9fa46adde832bd52f3c0cc0a27f9be80445f4b869601`, размер `12452372` bytes.
- Exact-head GitHub CI `85540647405`, checkout `49f522c81c324c02134a4bbed4f200f678d98b72`; CI `efhc.zip` имеет тот же размер `12452372` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, compileall, Flake8 critical/full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Ruff — `7` fixable diagnostics; Mypy — `1` typing error; Bandit — `2` B608 low-confidence findings; pytest — `4 failed / 1545 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: import/lint drift; nullable typing materialized deposit recovery; Panels SQL больше не собирается конкатенацией fixed owner-clause; emergency deposit использует external-event idempotency только по immutable `tx_hash`; stale canonical actor fixture и watcher-CANON assertion синхронизированы; Russian Engineering NORM исправлен в двух строках `KERNEL.md`.
- Обязательный Admin audit остаётся fail-closed и атомарным; audit actor — canonical `users.global_id`. RBAC, Admin NFT, strict financial Idempotency-Key для класса `MUST`, materialized-only deposit recovery и rollback semantics аудита 2/10 не ослаблены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02274`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- `require_admin` остаётся authentication/read gate; каждый state-changing Admin `POST/PUT/PATCH/DELETE` требует `require_admin_write` с минимумом Moderator. `Analyst/auditor` получает `403`.
- Emergency EFHC recovery принимает только `tx_hash` и использует только materialized `efhc_core.ton_inbox_logs` под `FOR UPDATE`; client-supplied amount/MEMO/address/raw больше не являются доказательством транзакции.
- Ручная Bank операция фиксирует money ledger + обязательный `admin_action_log` + notification outbox в одной DB transaction; Telegram delivery — только после commit.
- Повторный `Idempotency-Key` с иным финансовым payload даёт `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload допускает read-through.
- Admin NFT использует уже проверенный canonical principal и не проходит whitelist-only повторную авторизацию.
- Panels service использует canonical `archived_at`; compatibility facade делегирует `toggle_panel`; rollback balance type выводится только из исходной ledger-записи.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

# CURRENT CYCLE 1741 — v173.67 candidate

Exact-head CI `85400569189` for input `v173.66` is GREEN on all canonical gates. Cycle 1741 records a static function/route/table audit; runtime/frontend/schema are unchanged. Current candidate `v173.67` changes audit/SSOT/guard files and therefore requires its own exact-head CI.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# EFHC Bot — Development HEAD candidate v173.65 / цикл 1739

GitHub CI `85354825033` на входном `v173.63` (`12252439` bytes) выявил failures Alembic/Bandit/Mypy/frontend build/pytest/Ruff. Исправлены только подтверждённые причины: stale Alembic FK validator `39→41`, CI-reported ADS typing/import/security diagnostics, один TS compatibility prop, stale ADS/Tasks/PATCH guards, точечные provider wire aliases, protected ADS directories и Russian engineering NORM.

Frontend PATCH_002 остаётся visual/text CANON; exact visual files не переписывались. ADS business owner остаётся `global_id`; `builtin_timer` production monetization не возвращён. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.63 / циклы 1735–1737

Полностью реализован owner-directed ADS mediation scope: server-owned `AdManager`, provider registry/adapters, encrypted Admin configuration, ad sessions, UTC daily limits, verified/idempotent EFHCb reward через existing Tasks financial path, automatic fallback, health/circuit breaker, Admin ADS/Tasks, runtime frontend AdManager, analytics/Revenue Optimizer и Telegram Bot integration. `builtin_timer` — только DEV/CI/diagnostics; TADS/MyBid зарегистрированы fail-closed до подтверждённого cabinet reward contract.

Frontend PATCH_002 остаётся visual/text CANON. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.60 / цикл 1734

Цикл 1734 — owner-directed corrective merge после выявления неверного приоритета в цикле 1733. Утверждённый `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` является visual/text CANON; старый Bot UI не восстанавливается ради stale CI guards. Backend/CANON остаётся authority только для contracts/data/business/security. Функции обеих веток сохраняются.

Active merge documents: `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md`, `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`, `docs/frontend/FRONTEND_FUNCTION_UNION_MAP.json`, `docs/testing/FRONTEND_LEGACY_GUARD_MIGRATION.json`. Кандидат `v173.60` локально не тестировался и требует exact-head GitHub CI.

---

# EFHC Bot — Development HEAD candidate v173.59 / цикл 1733

Цикл 1733 обрабатывает exact-head GitHub CI `85239758056` для входного `v173.58` (`12106717` bytes). Подтверждённые failures: Ruff `1`, Mypy `1`, frontend TypeScript build `10 diagnostics`, pytest `57 failed / 1445 passed / 22 skipped / 1 warning`. Исправления ограничены подтверждёнными причинами: tooling/type/build defects, восстановление перезаписанных frontend protection invariants и минимальная актуализация stale expectations только для утверждённых контрактов 1732.

Function surface остаётся `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# EFHC Bot — Development HEAD candidate v173.58 / цикл 1732

Цикл 1732 внедряет проверенный по source SHA production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` поверх exact input `v173.57`. Overlay содержит 176 файлов (`131 modify + 45 add`), без standalone/demo/simulation runtime; добавлены bridge API `GET /auth/profile-photos` и `GET /tasks/earnings/me`. Current surface: `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`.

Wallet bridge сохранён в string-`global_id` CANON с явным DB-boundary helper. Новые инженерные авторские тексты приведены к русскоязычному NORM. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

## Текущее состояние разработки — кандидат v173.54 / цикл 1729

- Завершена консолидация десяти решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- GitHub CI `85124642409` для входного `v173.53`: GREEN Ruff/Bandit/Flake8/Alembic/PostgreSQL/compileall/npm ci; подтверждённые Mypy/pytest/frontend failures исправлены минимально.
- Удалены только 7 private transitional SQL aliases с полным delete-proof; внешние/исторические aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1730 — exact-head qualification и error burn-down.

## Текущее состояние разработки — кандидат v173.53 / цикл 1728

- Завершён цикл 1728 — Общие runtime compatibility surfaces.
- Supplied exact-head CI `85114913383` на `v173.52`: подтверждённые Ruff/Mypy/Bandit/pytest/frontend failures исправлены минимально; string-`global_id` CANON не откатывался.
- Создан `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`; правило `no caller != delete proof` закреплено как active policy.
- `app.bot.states` — официальный public FSM facade; остальные утверждённые import/startup/scheduler/Admin surfaces сохраняются бессрочно как thin compatibility contracts.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1729 — консолидация десяти решений.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Current state

Цикл 1718 обработал exact `v173.41` GitHub CI `84954546920`, archive size `12135299` bytes. Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy — `2` ошибки; pytest — `17 failed / 1485 passed / 22 skipped`.

`v173.42` содержит минимальные patches только по подтверждённым CI causes. Final `global_id` ownership, BANK и Admin NFT canons не ослаблялись; retired migration-control/read-switch/tg-owned business runtime не возвращён.

Исправлена packaging-регрессия `v173.41`: восстановлены executable modes release/ops scripts и Unicode-имена исторических reports без изменения их содержимого.

Создан план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: циклы 1719–1728 последовательно согласуют спорные функции, 1729 консолидирует решения, 1730 квалифицирует результат через GitHub CI пользователя, 1731 готовит frontend/audit handoff.

Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guard проверки не запускались. `production_release_ready=false`. Следующий цикл: **1719 — Admin Observability и Reports**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.

## Автономный production DevOps

Production monitoring, безопасный autopilot, local encrypted backup, owner SSH/SFTP export и diagnostic bundle описаны в `docs/SSOT/AUTONOMOUS_DEVOPS_SSOT.md` и `release_docs/DEVOPS.md`. Полный owner-facing production ENV template — `env.release.example` / release `.env.example`.
