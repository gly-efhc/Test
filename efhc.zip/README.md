# EFHC Bot — Development HEAD candidate v173.65 / цикл 1739

GitHub CI `85354825033` на входном `v173.63` (`12252439` bytes) выявил failures Alembic/Bandit/Mypy/frontend build/pytest/Ruff. Исправлены только подтверждённые причины: stale Alembic FK validator `39→41`, CI-reported ADS typing/import/security diagnostics, один TS compatibility prop, stale ADS/Tasks/PATCH guards, точечные provider wire aliases, protected ADS directories и Russian engineering NORM.

Frontend PATCH_002 остаётся visual/text CANON; exact visual files не переписывались. ADS business owner остаётся `global_id`; `builtin_timer` production monetization не возвращён. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.63 / циклы 1735–1737

Полностью реализован owner-directed ADS mediation scope: server-owned `AdManager`, provider registry/adapters, encrypted Admin configuration, ad sessions, UTC daily limits, verified/idempotent EFHCb reward через existing Tasks financial path, automatic fallback, health/circuit breaker, Admin ADS/Tasks, runtime frontend AdManager, analytics/Revenue Optimizer и Telegram Bot integration. `builtin_timer` — только DEV/CI/diagnostics; TADS/MyBid зарегистрированы fail-closed до подтверждённого cabinet reward contract.

Frontend PATCH_002 остаётся visual/text CANON. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.60 / цикл 1734

Цикл 1734 — owner-directed corrective merge после выявления неверного приоритета в цикле 1733. Утверждённый `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` является visual/text CANON; старый Bot UI не восстанавливается ради stale CI guards. Backend/CANON остаётся authority только для contracts/data/business/security. Функции обеих веток сохраняются.

Active merge documents: `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md`, `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`, `docs/frontend/FRONTEND_FUNCTION_UNION_MAP.json`, `docs/testing/FRONTEND_LEGACY_GUARD_MIGRATION.json`. Кандидат `v173.60` локально не тестировался и требует exact-head GitHub CI.

---

# EFHC Bot — Development HEAD candidate v173.59 / цикл 1733

Цикл 1733 обрабатывает exact-head GitHub CI `85239758056` для входного `v173.58` (`12106717` bytes). Подтверждённые failures: Ruff `1`, Mypy `1`, frontend TypeScript build `10 diagnostics`, pytest `57 failed / 1445 passed / 22 skipped / 1 warning`. Исправления ограничены подтверждёнными причинами: tooling/type/build defects, восстановление перезаписанных frontend protection invariants и минимальная актуализация stale expectations только для утверждённых контрактов 1732.

Function surface остаётся `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# EFHC Bot — Development HEAD candidate v173.58 / цикл 1732

Цикл 1732 внедряет проверенный по source SHA production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` поверх exact input `v173.57`. Overlay содержит 176 файлов (`131 modify + 45 add`), без standalone/demo/simulation runtime; добавлены bridge API `GET /auth/profile-photos` и `GET /tasks/earnings/me`. Current surface: `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`.

Wallet bridge сохранён в string-`global_id` CANON с явным DB-boundary helper. Новые инженерные авторские тексты приведены к русскоязычному NORM. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

## Текущее состояние разработки — кандидат v173.54 / цикл 1729

- Завершена консолидация десяти решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- GitHub CI `85124642409` для входного `v173.53`: GREEN Ruff/Bandit/Flake8/Alembic/PostgreSQL/compileall/npm ci; подтверждённые Mypy/pytest/frontend failures исправлены минимально.
- Удалены только 7 private transitional SQL aliases с полным delete-proof; внешние/исторические aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1730 — exact-head qualification и error burn-down.

## Текущее состояние разработки — кандидат v173.53 / цикл 1728

- Завершён цикл 1728 — Общие runtime compatibility surfaces.
- Supplied exact-head CI `85114913383` на `v173.52`: подтверждённые Ruff/Mypy/Bandit/pytest/frontend failures исправлены минимально; string-`global_id` CANON не откатывался.
- Создан `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`; правило `no caller != delete proof` закреплено как active policy.
- `app.bot.states` — официальный public FSM facade; остальные утверждённые import/startup/scheduler/Admin surfaces сохраняются бессрочно как thin compatibility contracts.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1729 — консолидация десяти решений.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Current state

Цикл 1718 обработал exact `v173.41` GitHub CI `84954546920`, archive size `12135299` bytes. Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy — `2` ошибки; pytest — `17 failed / 1485 passed / 22 skipped`.

`v173.42` содержит минимальные patches только по подтверждённым CI causes. Final `global_id` ownership, BANK и Admin NFT canons не ослаблялись; retired migration-control/read-switch/tg-owned business runtime не возвращён.

Исправлена packaging-регрессия `v173.41`: восстановлены executable modes release/ops scripts и Unicode-имена исторических reports без изменения их содержимого.

Создан план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: циклы 1719–1728 последовательно согласуют спорные функции, 1729 консолидирует решения, 1730 квалифицирует результат через GitHub CI пользователя, 1731 готовит frontend/audit handoff.

Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guard проверки не запускались. `production_release_ready=false`. Следующий цикл: **1719 — Admin Observability и Reports**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.