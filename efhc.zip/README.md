# EFHC Bot v173.38

## Current state

Cycle 1714 processed exact `v173.37` GitHub CI `84937506938`. Production defects introduced by post-migration cleanup were repaired; Admin functional composition was compared against exact-green v173.36 and the mistakenly removed Bonus Awards service/facade/contract was restored.

`v173.38` requires its own exact-head GitHub CI. Test-layer work was stopped by direct user instruction and no local qualification suites were run. `production_release_ready=false`. Next cycle: **1715 — exact-head follow-up**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.
