# EFHC Bot — development candidate v172.66

Циклы 1641–1646 сохранены. Повреждающий механический codemod v172.65
заменён безопасной пересборкой поверх рабочего runtime-ядра.

Ключевые документы:

- `START_HERE.md` — текущий статус;
- `docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md` — правила работы по логам;
- `docs/NORM/TZ/TZ_global_id_full_cutover.md` — исходное ТЗ;
- `docs/audits/GLOBAL_OWNER_CONTROLLED_REBASE_V172_66.md` — аудит;
- `docs/cycles/WORK_CYCLES_1640_1665_APPROVED_PLAN.md` — план;
- `CONTINUE_IN_NEW_CHAT.md` — следующий шаг.

Статус: точечный набор failures из CI прошёл, exact-head CI
обязателен,
production cutover не выполнен, production release не готов.
