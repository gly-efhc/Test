# ТЕКУЩИЙ HEAD — v174.76 / cycle 1816 / exact-head CI 88318025922 qualification repair

- Physical input: `EFHC_Bot_v174_75.zip`, SHA-256 `667bb907c9e4267f2b8906424fc02b541524f60f7d64fdf63655c4cd3a518ee3`.
- CI `88318025922` доказан exact-head для `v174.75`: Development SHA совпал с physical archive; checkout `4520abf24956b1ddcaac1054401cfc2410d130a9`; logs SHA-256 `f09009552fd59ef859a1a001217fdc6093a0f7832b74f01f1778941798873a03`.
- Gate matrix исходного HEAD: `11/12 GREEN`; RED только pytest `1 failed / 1772 passed / 22 skipped / 1 warning`. Ruff `All checks passed!`; Mypy `361 source files` без ошибок; Bandit `No issues identified`; frontend production build `Compiled successfully` / `EFHC BUILD VERIFY: PASS`; Alembic `metadata_tables=53`, `tables_in_schemas=54`.
- Единственный подтверждённый root cause — `manifest drift / qualification metadata defect`: `docs/testing/TEST_GUARD_MANIFEST.json` уже был `v174.75 / cycle 1815`, а `reports/current/IDENTITY_MIGRATION_STATE_CURRENT.json` оставался `v174.74 / cycle 1814`.
- Упавший `test_test_suite_integrity.py` защищает действующий current-state parity invariant и не является stale test; исправляется stale current metadata, test/runtime semantics не ослабляются.
- Последний полностью подтверждённый exact-head GREEN остаётся `v174.74` / CI `88312667980`; GREEN не переносится на новый candidate автоматически.
- Backend/frontend functional source, tests, schema, financial/business semantics и frozen `0001` не менялись. Frontend authority остаётся `FRONTEND_v195`, source-lock `30bd3f8ed09dea22f54dbc121a7fa36efda9be766a79a5180c94f48ad7b95fcf`.
- Pre-package hygiene выявила унаследованный из input archive `.pytest_cache` (`7` ZIP entries); cache удалён по existing Healer pattern `HEAL-0063 / CASE-0063`, без нового disease case.
- `VERSION=v174.76`; version-derived PWA metadata пересчитана: build-id `efhc-4f2f1d6ec296818c`; checked-in FAQ runtime authority не регенерировалась из SSOT.
- Immutable report `02395`; следующий `02396`. `v174.76` — candidate и требует fresh exact-head GitHub CI.
- Полные local qualification suites не запускать.

> Historical blocks ниже являются evidence и не переопределяют current state.

# ТЕКУЩИЙ HEAD — v174.73 / cycle 1813 / document language regression protection + Healer

- Physical input: `EFHC_Bot_v174_72.zip`.
- OWNER CANON: human-readable `documents`, `reports`, `cycles` и owner-facing `chat` используют Russian descriptive prose, сохраняя `technical terms` и `concepts` на English.
- `Document language policy` не является `source code style policy`; она не регулирует `source code`, `identifiers`, `test names`, `comments`, `docstrings`, `types`, `properties`, `machine literals`, `API/SQL/protocol` names.
- Permanent marker: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`. Machine CANON фиксирует `source_code_in_scope: false` и `code_rename_for_document_language: forbidden`.
- Permanent architecture guard: `tests/architecture/test_document_language_scope_canon.py`.
- Healer disease: `HEAL-0127 / CASE-0140`, category `governance_language_scope_regression`, severity `P1`.
- Direct OWNER permission использована для amendment `AI_ARCHIVE_LAWS`; lock SHA синхронизирован.
- Runtime/backend/frontend/schema/business semantics не менялись. Последний подтверждённый exact-head GREEN остаётся `v174.69` / CI `88066448299`; `v174.73` требует fresh exact-head GitHub CI.
- Immutable report `02392`; следующий `02393`.
- Полные local qualification suites не запускать.

> Historical blocks ниже являются evidence и не переопределяют current OWNER CANON.

# ТЕКУЩИЙ HEAD — v174.72 / цикл 1812 / исправление области русскоязычной политики

- Physical input: `EFHC_Bot_v174_71.zip`.
- OWNER correction: команда «все отчёты в чате и архиве на русском языке» относится только к человекочитаемым документам, отчётам и сообщениям в чате.
- Программный код полностью исключён из этой языковой политики: она не задаёт язык identifiers, имён test-функций, docstring, comments, API/SQL/protocol/machine literals и иных code artifacts.
- Подтверждена первопричина: legacy `ops/quality/check_russian_engineering_language.py` сканировал `backend/**/*.py`, `ops/**/*.py`, `scripts/**/*.py`, `tests/**/*.py` и отдельно запрещал нерусские имена `test_*`; именно поэтому policy затрагивала код.
- Guard исправлен по OWNER scope: теперь он контролирует только Markdown/текстовые документы и текущие человекочитаемые reports; программные source directories не квалифицируются по языку.
- Active NORM переписан под документную область. Добавлен regression contract: английские Python docstring/comment/test name допустимы, новый английский README остаётся нарушением документной политики.
- Исторические смешанные/русские code identifiers не переименовываются массово: язык больше не является причиной менять code/node IDs.
- Runtime/backend/frontend/business/schema semantics не менялись. Последний подтверждённый exact-head GREEN остаётся `v174.69` / CI `88066448299`; `v174.72` требует следующего exact-head GitHub CI.
- Immutable report `02391`; следующий `02392`.
- Локальные полные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами прежних состояний и не переопределяют текущую OWNER-норму.

# CURRENT HEAD — v174.71 / цикл 1811 / CI `88284991086` + FRONTEND_v196 mini-audit repair

- Physical input: `EFHC_Bot_v174_70.zip`, SHA-256 `56db5d7d024e5c0700132b16133e35062e34eb46bcd56ccdf9593638922590c3`.
- CI `88284991086` доказан exact-head для `v174.70`: checkout `01c8b2874dbf7cd22d7d754f1b97c92a020f390b`, logs SHA-256 `71273d053fb9cafc47079cb5efe0ddf689591ffb45f83c851c3aaffe1b5ffe0c`.
- Gate matrix исходного HEAD: `10/12 GREEN`; RED — pytest `14 failed / 1749 passed / 22 skipped / 1 warning` и frontend production build с `3` TypeScript diagnostics. Ruff, Mypy, Flake8, Bandit, compileall, PostgreSQL/Alembic и npm install — GREEN.
- Исправлены только подтверждённые CI причины: missing `Button` import, Admin Shop nullable editor contract, два unsafe raw-error render shape, stale frontend/admin/withdraw tests и machine compatibility marker после FRONTEND_v195 consolidation.
- Mini-audit `FRONTEND_MAIN_SYNC_AUDIT_v196.md` SHA-256 `45a13d5bc5bd3987c61200aec3104b4ada02dfb1e7de97684c8d1a9cc8131915` разобран полностью как входное evidence: заявленные `25` diff имеют disposition; отдельно подтверждён main defect `identity.ts` — `12` кириллических program property identifiers заменены на `field/code/message`. Архив/patch FRONTEND_v196 не предоставлялся, поэтому byte-exact authority FRONTEND_v196 не утверждается; текущая authority остаётся FRONTEND_v195 + подтверждённые main repairs.
- OWNER withdrawal rule: после успешного wallet send + сохранённого `payout-evidence` frontend сразу вызывает `mark-paid`; если evidence/ответ не зафиксирован, оператор нажимает `Оплачено`, и без evidence открывается manual recovery с обязательной причиной. Отдельная кнопка `Оплачено` сохраняется.
- Внешние deposit/withdraw/Browser Shop остаются D2 business boundary; TON D9 / USDT D6 — только native atomic transport.
- Backend/schema/frozen `0001` не менялись. Последний полностью GREEN exact-head остаётся `v174.69` / CI `88066448299`; `v174.70` не GREEN.
- Frontend authority `211/211`, source-lock `30bd3f8ed09dea22f54dbc121a7fa36efda9be766a79a5180c94f48ad7b95fcf`; PWA build-id `efhc-d7cd1db33319cb2a`; release assets `29/29`.
- Immutable report `02390`; следующий `02391`. `v174.71` — candidate / next exact-head GitHub CI required.
- Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.70 / цикл 1810 / FRONTEND_v195 reconciliation

- Physical input: `EFHC_Bot_v174_69.zip`, SHA-256 `a6095e4da727f232f2a715c3e7d1ebad9b1fd7e2842c5b2eb0bf11df7f59cfd0`.
- Exact-head CI `88066448299` проверил `v174.69`: checkout `91065a41ba9450359ddded5f2643196c74f448d0`, все `12/12` gates GREEN, pytest `1760 passed / 22 skipped / 1 warning`, frontend build PASS.
- `v174.69` — последний полностью GREEN exact-head.
- Owner patch `FRONTEND_v195` интегрирован с обязательным higher-CANON overlay: Bank snapshot refresh/export, Shop D2/`0.00` disabled и checked-in FAQ authority; PaymentIntent frontend transport принят из FRONTEND_v195 при неизменной backend native-atomic settlement authority.
- Внешний EFHC deposit/withdraw и Browser Shop остаются D2 business boundary; TON D9 / USDT D6 — только native atomic transport representation уже утверждённой внешней суммы.
- Подтверждённые compile-level donor defects исправлены; backend/schema не изменялись.
- При подтверждённом frontend↔financial/security CANON conflict требуется прямое OWNER clarification; оператор не выбирает сторону самостоятельно.
- Frontend authority `211/211`, source-lock `cb62c557bcd3583c4481e32053a642bd9455344f003255e69aee6ec72408588f`; PWA build-id `efhc-2149972a23ae2dbe`; release assets `29/29`.
- Immutable report `02389`; следующий `02390`. `v174.70` — candidate / next exact-head GitHub CI required.
- Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.69 / цикл 1809 / CI `88039356151` exact-head GREEN evidence closure

- CI `88039356151` доказан exact-head для `v174.68`: SHA-256 `e5a27a508c66e65f7fd7a37965dacf04cd16e519433472ca91ea343c151974f5`, checkout `3689d3158d76d8d9e8e77767bc7b7f8702d0b424`; supplied logs SHA-256 `9ca114b68620a9ba08c40f45e10bca4958728ba8c0f16bf7b6ae98d960b9732c`.
- Все `12/12` gates GREEN; pytest `1760 passed / 22 skipped / 1 warning`. `v174.68` — новый последний полностью GREEN exact-head.
- Dedicated ApplicationClock regression file существует с `v174.65`: `5` tests, включая `3` динамических wall-clock jump unit-tests; одинаковый total в последующих CI не означает отсутствие этих тестов.
- Подтверждённого test gap нет; runtime/frontend/test source не менялись.
- `v174.69` — candidate / next exact-head GitHub CI required; immutable report `02388`, следующий `02389`.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.68 / цикл 1808 / CI `88034310249` hygiene repair

- CI `88034310249` доказан exact-head для `v174.67`: SHA-256 `b386cb38023b7b9d022b9008f82665ac6ab93e091c37f7bff35147267395e695`, checkout `3b9809f5d3424d8724ca801428aba5c6a91a7bfd`; supplied logs SHA-256 `3e8efec8c1ec6deb68fc5da17d4162ef65fb6bb7108b7b316b801571f864fe37`.
- GREEN: Development SHA, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build. RED только pytest: `1 failed / 1759 passed / 22 skipped / 1 warning`.
- Единственная причина — numbered work-pass label в `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; guard корректен, test не ослаблялся.
- Repair только qualification/governance metadata; frontend/runtime source, financial/security invariants и schema не менялись.
- Последний полностью GREEN exact-head: `v174.66` / CI `87928232215`. `v174.68` — candidate / next exact-head GitHub CI required.
- Immutable report `02387`; следующий `02388`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.67 / цикл 1807 / CI `87928232215` GREEN + financial timestamps ApplicationClock

- Physical input: `EFHC_Bot_v174_66.zip`, SHA-256 `ad06f32010608ac9b350f8fa35b2bccdca4e89503ac975c8c62523e7bd801c89`; CI Development HEAD SHA совпал точно, checkout `15aeb2e019dac699ee1a959a256997a4d1ea23ca`.
- CI `87928232215`: все `12/12` gates GREEN; Ruff `All checks passed!`, Mypy `361 source files` без ошибок, pytest `1760 passed / 22 skipped / 1 warning`, frontend build PASS.
- `v174.66` является новым последним полностью GREEN exact-head.
- Исправлены четыре подтверждённых direct wall-clock timestamp: `efhc_transfers_log.created_at`, `ton_inbox_logs.created_at/updated_at` и `ReferralBonusLedger.created_at`; все используют `app.lib.time.utcnow()`.
- Existing ApplicationClock architecture guard расширен на `transactions_crud.py` и `referrals_crud.py`.
- Retention thresholds `180/370/400`, delete policy, frontend source, financial formulas и schema/migration не менялись.
- `v174.67` — candidate / next exact-head GitHub CI required.
- Immutable report `02386`, следующий `02387`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.66 / цикл 1806 / ремонт exact-head CI `87917878179`

- Physical input: `EFHC_Bot_v174_65.zip`, SHA-256 `b070a03c6e474809aede2c68945283875eeee34620cc92f63a8a4f1d979cf13b`; CI Development HEAD SHA совпал точно, checkout `d1e98c63e4ade94a8bb7ac74b7fd92d1297e1d64`.
- CI GREEN: Development SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build. RED: Ruff `5`, Mypy `12`, pytest `1`.
- Исправлены только подтверждённые root causes: пять import-order defects, typed-return boundaries ApplicationClock wrappers и stale `IDENTITY_MIGRATION_STATE_CURRENT` metadata.
- pytest evidence исходного HEAD: `1759 passed / 22 skipped / 1 warning / 1 failed`; единственный failure — version/cycle drift current-state manifest.
- Frontend source, financial formulas, Panel economics, schema/migration и retention thresholds не менялись.
- Последний полностью GREEN exact-head до следующей квалификации остаётся `v174.62` / CI `87895142054`; `v174.66` требует fresh exact-head GitHub CI.
- Immutable report `02385`, следующий `02386`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.65 / цикл 1805 / закрытие обходов ApplicationClock

- Физический вход: `EFHC_Bot_v174_64.zip`, SHA-256 `913e34cacf4ba7d95bb37214d8c1b3ee2589a615389f455781c0a11b91da6a5e`, `VERSION=v174.64`.
- OWNER scope: устранить обходы `ApplicationClock` в elapsed/access/financial/scheduler logic без изменения самого clock и без изменения финансовых порогов/алгоритмов.
- Исправлены NFT cache TTL, NFT `checked_at`, financial retention `now` и подтверждённые дополнительные business-time bypasses в auth/session, locks/rate-limit, Shop/PaymentIntent, TON, Tasks, ADS, Bot FSM, watcher/withdraw и scheduler/report windows.
- Pure physical/audit/presentation timestamps не переводились механически на ApplicationClock; bootstrap `app.lib.time.ApplicationClock` остаётся wall-clock anchor по CANON.
- `financial_retention_service.py` и `financial_retention_foundation_service.py` byte-exact относительно входа; `180/370/400`, delete order и deletion policy не менялись.
- Добавлен regression source `tests/architecture/test_application_clock_business_paths.py`; локальный pytest и остальные qualification suites не запускались.
- Новых фактически доступных GitHub CI-логов для `v174.64` не было. Последний exact-head GREEN остаётся `v174.62` / CI `87895142054`; `v174.65` требует fresh exact-head GitHub CI.
- Immutable report `02384`, следующий `02385`.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.64 / цикл 1804 / полный CANON формул Admin → Банк

- Physical input: `EFHC_Bot_v174_63.zip`, SHA-256 `2524f36e86db14fcd42107ba6325a644b9594f68f4f8c0b466334dbf330f2f3c`, `VERSION=v174.63`, CRC PASS.
- По прямому OWNER scope существующий `docs/NORM/BANK_METRICS_INTEGER_SNAPSHOT.md` расширен до полного ACTIVE CANON/NORM всех формул Admin → Банк; второй параллельный формульный документ не создавался.
- Статически подтверждены source formulas backend snapshot, singleton `efhc_core.bank_metrics_snapshot`, frozen `0001`, `/admin/reports/overview`, FRONTEND_v182 и canonical owner Q&A.
- Snapshot устраняет browser-side reconstruction, но не меняет математику: `fixed_obligations = fixed_generated - fixed_population × 100` остаётся signed без `max(0)`; при denominator `0` backend percentage rule возвращает `0.00000000%`.
- Frontend runtime не менялся по OWNER decision: он читает готовые `bank_metrics_*` facts, fail closed без snapshot и выполняет только presentation formatting.
- Backend/frontend/test/schema runtime source не менялись. Последний exact-head GREEN остаётся `v174.62` / CI `87895142054`; `v174.64` требует fresh exact-head GitHub CI.
- Immutable report `02383`, следующий `02384`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.63 / цикл 1803 / exact-head GREEN CI `87895142054`

- CI `87895142054` доказан как exact-head для `v174.62`: SHA-256 `EFHC_Bot_v174_62.zip` = `f681f232ec4f8de8cf8ccd93ab371aeec2146bfc6137d09adc0dee9112d093b4`, совпадает с Development HEAD SHA CI; checkout `339ff292ee97b8656ed10c62f9c653beabcb68f3`.
- SHA-256 предоставленного архива CI-логов: `a832963f8c82bd4ecb2ed5824bdb96a016ea3aec70e508c7905569a1df7f4e70`.
- Все `12/12` gate exit-файлов CI имеют `exit=0`; Flake8 full дополнительно сообщил `0`, Ruff — `All checks passed`, Mypy — `361 source files` без issues, Bandit — `0` issues.
- pytest: `1755 passed / 22 skipped / 1 warning`; frontend latest-dependency production build: `EFHC BUILD VERIFY: PASS`.
- Alembic выполнил единственный `0001`: `metadata_tables=53`, `tables_in_schemas=54`; `0002+` не вводились.
- Подтверждённых новых production/frontend/test defects нет. Финальный static read-back выявил только stale governance/evidence count: `TEST_GUARD_MANIFEST.active_architecture` исправлен `298 → 286` по фактическим `tests/architecture/test_*.py` и lightweight guard `--no-collect`. Runtime, financial CANON, schema source, FRONTEND_v182 source и tests в цикле 1803 не изменяются.
- `v174.62` теперь является последним подтверждённым exact-head GREEN. Текущий `v174.63` содержит только evidence/governance/release metadata closure и поэтому сам требует нового exact-head GitHub CI.
- Immutable report `02382`, следующий `02383`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩАЯ ДИСПЕТЧЕРСКАЯ ЗАПИСЬ — v174.62 / цикл 1802 / ремонт CI `87886177473`

- Точный вход CI: `v174.61`, SHA-256 `467af005d6ed6f1a336859a7d376092778e168493ac6e9352419a75627d4d7e5`; checkout `2516d70469ea8cdc69f8935fc368b2a25ced7be8`; SHA-256 архива логов CI `2aeae3e442c422d20d2a6faa7554fe306ef5f46a9c38893a33f1d9cd27e5aaa5`.
- Успешные проверки CI: Development SHA, Flake8 critical/full, Mypy, compileall, PostgreSQL preflight, Alembic, npm install. Ошибочные проверки CI: Ruff `5`, Bandit `3`, pytest `4`, frontend build `2`.
- Исправления исходного кода: порядок импортов и неиспользуемые импорты Ruff, fail-closed разбор доказательств Bandit, ORM-подсчёт активных Панелей, два поля frontend type-contract для withdrawal.
- Синхронизация Test Authority: active NORM получили стабильные имена; i18n guard проверяет текущий точный паритет 13 локалей без устаревшего `1694`; decrement guard допускает только утверждённое владельцем исключение protective Panel; Panel spend guard следует текущему lifecycle.
- Финансовый/runtime CANON protective Panel цикла 1801 не менялся; схема остаётся `53 ORM / frozen 0001 / 0002+ = 0`.
- Отчёт `02381`, следующий `02382`. Кандидат `v174.62` требует свежий exact-head GitHub CI; локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT RELEASE — v174.61 / cycle 1801

Текущий candidate реализует direct OWNER contract ручной защитной деактивации Панелей. Канон: `U=min(G,A)`, `R=G-U`, `NET=100-R`; dead marker `panels.meta.protectively_voided=true`; обычные списки/scheduler/aggregates dead не читают; exact Admin lookup/audit/export читают; повторная активация той же Панели требует новые `100.00000000 EFHC`. Active inputs: `docs/NORM/EFHC_PANEL_PROTECTIVE_DEACTIVATION_OWNER_CONTRACT.md`, `docs/frontend/EFHC_FRONTEND_OWNER_QA_v182.md`, `docs/frontend/FRONTEND_v182_BACKEND_RECONCILIATION_HANDOFF.md`. Report `02380`, следующий `02381`. Fresh exact-head GitHub CI обязателен; локальные qualification suites не запускать.

# CURRENT HEAD — v174.60 / cycle 1800 — FRONTEND_v182 + owner-approved Bank snapshot

- Base exact-head CI evidence: GitHub CI `87706114541` tested exact `v174.58` SHA-256 `93f80c6a3fdd95952f7d9bc5dc977d4d42db3c50d560309d5c8a68edd820ee73`, checkout `29be709f31bff90898826c07994373deeda436a8`; all recorded gates GREEN except one stale pytest raw-error implementation guard (`1 failed / 1749 passed / 22 skipped / 1 warning`).
- CI log archive SHA-256: `b8530b8ffd22aa421e7207fdf2edcee9d27d0349e870444a6e4e2737f3a6927d`.
- Owner donor/sample `EFHC_Bot_v174_59.zip` SHA-256 `956844e259b8294e7de35bbf5a5ba99db305bed368bf10182621e4bbb1ab6fd9` supplied FRONTEND_v182 + Bank snapshot integration. Merge is selective: higher Shop D2/zero-price, atomic PaymentIntent, withdrawal Paid and FAQ checked-in CANON are preserved.
- FRONTEND_v182 is current owner-controlled frontend authority. Current approved source manifest: `INTEGRATED_FRONTEND_SOURCE_v174.60_FRONTEND_v182`, `211/211` paths.
- New owner-approved canonical table: `efhc_core.bank_metrics_snapshot`; ORM surface `53 = 46 efhc_core + 7 efhc_admin`; expected clean physical surface `54` including `alembic_version`. Frozen lineage remains only `0001`; no `0002+`. Existing DB compatibility: root `URGENT_BANK_METRICS_SNAPSHOT.sql`.
- Snapshot service is transaction-neutral; application route owns commit/rollback. BANK/ledger/source tables remain primary financial truth.
- FRONTEND_v182 backend compatibility adds `GET /admin/panels/{panel_id}`, cursor Panel list and Admin logs CSV/XLSX export. Checked-in static OpenAPI: `165 paths / 171 public operations / 169 schemas`; hidden `8`; mounted expected `179`.
- Protective Panel deactivation remains fail-closed until separate owner-approved atomic refund/split/generated-kWh-annul backend contract. Admin Panels Q&A `ADM-M09-01…19` remains authority.
- Candidate `v174.60` requires fresh exact-head GitHub CI; no GREEN claim transfers from `v174.58` or donor `v174.59`.

# CURRENT HEAD — v174.58 / цикл 1797 / Admin Panels owner Q&A registry sync

- Physical base: exact candidate `v174.57` SHA-256 `c46724089a4ab4c9b589db7b2af5c2aebe47b3346e1384050046ed218d3b16e5`; runtime/backend/frontend/tests этой документационной итерацией не изменяются.
- В active append-only `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` перенесены `QA-2026-08-20-ADM-M09-01…19` из owner-authority `ADMIN_PANELS_OWNER_QA_v170.md`.
- Поздние уточнения сохранены с приоритетом: QA-11 финализирует отсутствие отдельного central KPI; QA-13 задаёт population деактивированных Панелей; QA-18 исключает защитно аннулированные Панели из экономической формулы.
- Зафиксированы exact D8 boundaries, исходный EFHCb/EFHCm refund split, `generated_kwh = 0.00000000` после защитной деактивации и правила поиска Global ID / Panel ID.
- Перенос Q&A не является самостоятельным разрешением на изменение backend/main; source context сохраняет backend authority `v174.54` read-only для этого redesign-документа.
- Последний подтверждённый exact-head GREEN остаётся `v174.54` / CI `87542599519`. Новый docs-only candidate требует fresh exact-head CI.
- Immutable report `02376`; следующий `02377`; canonical handoff `EFHC_Bot_v174_58.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.57 / цикл 1797 / CI `87591506394` repair

- Physical input: `v174.56` SHA-256 `411b1c34e5fb05ac54004f589ec1bde453f79c31f93e2c5fe1e89082eac2aa9f`; supplied CI logs ZIP SHA-256 `3a3dcce04e744d53cab0ba991dda4ab7dec2945518c744abfeb6c0f6ebb32aa3`. Checkout: `22bb7d02d48a4aaaab4b7df3cf43646a8aec7630`.
- CI GREEN: Development SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install. RED: Ruff `2`, Mypy `3`, frontend build `2` TypeScript errors, pytest `12 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые source defects: Ruff import order; Mypy typed-return boundaries; два TypeScript defects `admin/shop.tsx`; запрещённый financial UI `Number()` в Bank ratio. Исправлены минимально без нового frontend functionality.
- Pytest qualification debt после FRONTEND_v168: stale Bank emergency href, old Users `limit=50`, old logs virtualization marker, old Tasks runtime/label literals, old zero-price expectation, raw-error state-name expectation; directory/test/current-manifest drift. Tests перепривязаны к current observable/invariant contract, а не к superseded implementation shape.
- OWNER clarification: confirmed frontend defects исправляются сразу; новые functional/visual changes требуют ТЗ/owner patch. Tests, противоречащие owner-approved frontend patch только по старой implementation shape, обязаны синхронизироваться в той же итерации.
- Frozen `0001`, отсутствие `0002+`, D2/D8 boundary, TON/USDT native atomic, Oracle/FX prohibition, BANK/ledger, Telegram transaction ownership не меняются.
- Immutable report `02375`; следующий `02376`; canonical handoff `EFHC_Bot_v174_57.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.56 / цикл 1796 / owner clarifications documentation sync

- База этой итерации: `v174.55` SHA-256 `08211128a3220112b6d1e76b3b8a451aad19edff67a59a531d704fc8e3123f9b`; runtime source из `v174.55` не переписывается данной документационной синхронизацией.
- Последний подтверждённый exact-head GREEN остаётся `v174.54`, GitHub CI `87542599519`, checkout `2c8b5fab3b21f608d77daa54782963e971f9ff35`, pytest `1745 passed / 22 skipped / 1 warning`.
- Прямое решение владельца уточняет финансовую границу: **D2 только на внешних операциях** — внешний ввод EFHC, внешний вывод EFHC и внешний Shop. Все внутренние операции EFHC остаются D8. Внутреннего магазина не существует и не должно существовать; Shop — отдельная открываемая HTML-страница, связанная с backend и Admin Panel.
- `0.00` сохраняется как допустимое состояние цены товара: товар остаётся доступным/видимым, но действие покупки при нулевой цене деактивировано; бесплатная покупка и создание payment flow при `0.00` запрещены.
- Новый manual recovery UI/API не создаётся: владелец подтвердил, что необходимый ручной контур уже реализован в Admin Panel через модуль `Пользователи`; D2/emergency remediation не должен его дублировать.
- `FRONTEND_v168` — owner-controlled frontend authority. Самостоятельные изменения frontend runtime/UX/text в backend/financial циклах запрещены: при необходимости оператор готовит ТЗ и предложенный код владельцу, а изменение входит в следующий owner frontend patch. Текущая итерация не меняет `frontend/src` или `frontend/public`.
- Test Authority уточнён: stale test разрешено удалить только при высокой уверенности после сверки с актуальными OWNER DECISION/CANON/NORM/SSOT; при сомнении test сохраняется и конфликт эскалируется владельцу. P0 financial/security/business invariants не ослабляются.
- Immutable report `02374`; следующий `02375`; canonical handoff `EFHC_Bot_v174_56.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.55 / цикл 1796 / CI `87542599519` GREEN + FRONTEND_v168 + D2

- GitHub CI `87542599519` проверил точный `v174.54`: SHA-256 `fc8d18a59f9d7dec91cd2ecb8d0ca0cfaa8ae1cb9c015ad5014f4aec2f196861`, checkout `2c8b5fab3b21f608d77daa54782963e971f9ff35`; все recorded gates GREEN, pytest `1745 passed / 22 skipped / 1 warning`. `v174.54` является новым подтверждённым точным GREEN-якорем.
- В цикл 1796 внедрён owner-approved `FRONTEND_v168`: patch SHA-256 `6de94223431af7ee8856bfdf069b8e39efd22df6486525cb485f274cc070963d`, `41` frontend path, конфликтов применения не было; внешний `.patch` не является частью текущего HEAD/релизного ZIP.
- Frontend authority переведён на FRONTEND_v168 и расширен до `211` контролируемых source-path. FAQ остаётся checked-in production authority; FAQ SSOT не переписывает runtime FAQ.
- Финальное owner-уточнение D2: ручные Shop `price_ton`/`price_usdt` имеют максимум D2; значения >D2 отклоняются без скрытого округления. После проверки цена конвертируется в native atomic units: TON `10^9`, USDT `10^6`; внутренний EFHC и `efhc_amount_d8` остаются D8.
- Emergency EFHC deposit получает сумму из exact transport-v2 `amount_atomic/token_decimals`, затем применяет external EFHC D2 ROUND_DOWN; автоматический fallback на native `ton_inbox_logs.amount` не используется. Legacy row без evidence делает authoritative refetch либо завершается fail-closed.
- Frozen `0001` не менялся; `0002+` не создавались. Backend HTTP surface остаётся `162 paths / 168 public operations / 169 schemas / 8 hidden / 176 mounted`.
- Immutable report `02373`; следующий `02374`; canonical handoff `EFHC_Bot_v174_55.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.54 / цикл 1795 / CI `87533782588` qualification repair

- GitHub CI `87533782588` проверил exact `v174.53`: SHA-256 `b850f2ccd6cb1f43300e6b476ed6331f35594b1f82328e3c50acac5ee28de0df`, checkout `f5e1540bd7856b31a655e98d55e50334877a40fd`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED только pytest: `4 failed / 1741 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: missing AI Archive Laws reference в новом Test Guard manifest; stale current frontend authority version metadata; три сдвинутых exact identity line anchors; direct-script import defect Anti-Stale checker.
- Все repairs относятся к qualification/tooling/governance. Backend/frontend runtime, финансовая модель, Shop pricing, TON/USDT atomic settlement, external EFHC D2, BANK/ledger, temporal/replay ordering и Telegram transaction ownership не менялись.
- Test Authority / Anti-Stale Contract сохраняется без ослабления: полезные fail-closed invariant tests не удалялись; stale implementation expectations не имеют права переопределять active OWNER DECISION/CANON/NORM/SSOT.
- Frozen `0001` не меняется; `0002+` не создаются. Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.54` требует fresh exact-head GitHub CI.
- Immutable report `02372`; следующий `02373`; canonical handoff `EFHC_Bot_v174_54.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.53 / цикл 1795 / CI `87522913463` + Test Authority / Anti-Stale

- GitHub CI `87522913463` проверил exact `v174.52`: SHA-256 `f06ccd41922f753debecf32196815994eb3bc845ed06d9dfa20d6a9959901de0`, checkout `c55f6b0a9478df58b6c2bc40115a282d56fd7913`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install и frontend build. RED: Ruff `4`, Mypy `1`, pytest `4 failed / 1738 passed / 22 skipped / 1 warning`.
- Подтверждённые причины: четыре Ruff import-order diagnostics; один Mypy return-type diagnostic в ADS scheduler adapter; один stale hardcoded Admin seam count; один реальный compatibility regression, породивший три pytest failure — `wallets_service._confirm_payment_intent()` не пропускал canonical `external_amount_atomic/external_decimals`.
- Runtime repair ограничен compatibility facade и не меняет финансовую модель: atomic TON/USDT, external EFHC D2, ledger, replay/time barrier, Shop pricing и Oracle/FX prohibition сохранены.
- OWNER DECISION: действует `docs/NORM/TEST_AUTHORITY_ANTI_STALE_CONTRACT.md`. Тест не является SSOT; authority: OWNER DECISION → CANON/SSOT/NORM → runtime invariant → guard/test. Stale expectation обновляется или удаляется в той же итерации; правильный runtime запрещено откатывать только ради stale implementation test.
- Удалены brittle exact-count locks для mutable test/API surface; behavioural/parity/security/financial invariants сохранены. Structural anti-stale guard включён в test-suite integrity.
- Frozen `0001` не меняется; `0002+` не создаются. Последний exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.53` требует fresh exact-head GitHub CI.
- Immutable report `02371`; следующий `02372`; canonical handoff `EFHC_Bot_v174_53.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.52 / цикл 1795 / CI `87512306629` remediation

- GitHub CI `87512306629` проверил exact `v174.51`: SHA-256 `79d07b081fb73060f1ecd85b0cec61b4800912ade2f865fb7bb2968abfbb0e11`, checkout `1d022dfba994e4f09d35ffdf7f177823abb0b379`; SHA payload совпадает с физическим HEAD.
- GREEN: Development HEAD SHA, Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic и npm install. RED: Ruff `6`, Mypy `7`, frontend build `1` TypeScript error, pytest `20 failed / 1722 passed / 22 skipped / 1 warning`.
- Подтверждённые причины сгруппированы: release executable-mode defect; generated frontend/admin seam drift; source lint/type diagnostics; stale qualification expectations после owner-approved Financial Audit №3; history/directory/hash manifest drift.
- Исправления не меняют Shop economics, asset-native TON/USDT settlement, external EFHC D2, withdrawal `Оплатить → Оплачено`, NFT paid gate, Admin audit, ADS reconciliation, P0 temporal barrier или canonical ledger reporting. Oracle/FX не восстанавливаются.
- Frozen `0001` не меняется; `0002+` не создаются. Public source surface остаётся `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`; новые routes в этом цикле не добавлялись.
- Последний подтверждённый exact-head GREEN остаётся `v174.50` / CI `87472108257`. `v174.52` требует собственного fresh exact-head GitHub CI.
- Immutable report `02370`; следующий `02371`; canonical handoff `EFHC_Bot_v174_52.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.51 / цикл 1794 / Financial Audit №3 remediation

- GitHub CI `87472108257` проверил exact `v174.50`: SHA-256 `ec735a9a631fde9c6275d62b19cdc5b15d53c0b5daca9d3fb85066699df46cc3`, checkout `22d9a9a7b95e42c4980c3019bea6fa53d99807e3`; все recorded gates GREEN, pytest `1729 passed / 22 skipped / 1 warning`. `v174.50` теперь **EXACT-HEAD GREEN**.
- Цикл 1794 исполняет direct owner-approved Financial Audit №3: FIN-01/03/04/05/06/07/08/09 подтверждены source и исправлены; FIN-10 остаётся закрытым, Oracle/FX не восстанавливаются.
- External TON/USDT отделены от EFHC D8 и фиксируются/settle в asset-native atomic units; внешний EFHC deposit/withdraw использует D2 ROUND_DOWN → internal D8.
- Withdrawal разделён на payout evidence и explicit `Оплачено`; NFT unpaid approval запрещён; Shop force-fulfill имеет required Admin audit; zero-price fail-closed; ADS reward reconciliation и canonical ledger reporting добавлены.
- P0 порядок settlement: trusted time → 180-day barrier → replay/idempotency → mutation → ledger. Frozen `0001` неизменён, `0002+` отсутствуют.
- Static public surface после двух новых explicit withdrawal actions: `162 paths / 168 public ops / 169 schemas / 8 hidden / 176 mounted`. Live proof — следующий GitHub CI.
- Immutable report `02369`; следующий `02370`; canonical handoff `EFHC_Bot_v174_51.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.50 / цикл 1793 / CI `87405882481` qualification repair

- GitHub CI `87405882481` проверил exact `v174.49`: SHA-256 `efefa2727537f5e81d7e6a8fc679f79ade495bb08e82497d09d71625c6fd2768`, checkout `b69ed98e13c7995343429df2975fe2e893ada297`. SHA payload полностью совпадает с предоставленным физическим HEAD.
- GREEN: Development HEAD SHA-256, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic upgrade, npm install и frontend build. RED только pytest: `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая первопричина — drift русскоязычной инженерной документации: active guard обнаружил `14` новых англоязычных narrative-строк (`6` в `KERNEL.md`, `8` в `START_HERE.md`). Это корректный fail-closed qualification guard, а не stale test и не runtime defect.
- Исправлены только эти `14` строк. Baseline и сам test не изменялись; backend/frontend runtime, Shop pricing, financial SSOT, schema и transaction ownership не откатывались.
- Последний подтверждённый exact-head GREEN остаётся `v174.47` / CI `87290901436`. `v174.50` GREEN не считается до fresh exact-head GitHub CI.
- Immutable report `02368`; следующий `02369`; canonical handoff `EFHC_Bot_v174_50.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.49 / цикл 1793 CI qualification repair

- Run `87290901436` полностью квалифицировал exact `v174.47`: SHA-256 `587c43298864805e7339ce6f88c8f7e284660c59a50449433a5811009b21b698`, checkout `cf3aea612813ce3cf43fe9b64d0ecfcdf35a4976`, все recorded gate exits `0`. `v174.47` = **EXACT-HEAD GREEN**.
- Более новый run `87386543243` проверил exact `v174.48`: SHA-256 `607da2ba1f2643266d2e62eb070790a1f8b3d2e5c3bbd46c31c44208ef22d826`, checkout `6760c21915d6cd605c7e461e99485b043a0fd980`; все recorded gates GREEN, кроме pytest `1 failed / 1728 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — brittle Shop architecture guard: после подтверждения всех runtime invariants он требовал буквальную форму `"ручную цену"`, тогда как active NORM уже фиксирует `администратор независимо задаёт` `price_ton`/`price_usdt` и manual price runtime authority.
- Исправлен только guard: он проверяет канонический смысл, а не падежный литерал. Shop runtime/NORM, owner pricing decision, frozen `0001`, FAQ и FRONTEND_v146 не откатываются.
- Локальные project tests/build/CI не запускались. Immutable report `02367`; следующий `02368`; canonical handoff `EFHC_Bot_v174_49.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.48 / цикл 1793 OWNER DECISION: ручные цены Shop TON/USDT

- **OWNER DECISION:** Shop не использует ценовой оракул, внешний FX-курс или автоматическую конвертацию TON/USDT. Администратор вручную задаёт `price_ton` и/или `price_usdt` для каждой товарной карточки.
- Удалена special-case ветка `CUSTOM_EFHC`: больше нет автоматического курса `0.3 USDT = 1 EFHC` и блокировки TON из-за отсутствия oracle. Любой checkout SKU проходит общий catalog/order flow и использует только сохранённую цену карточки.
- Legacy поле `custom_efhc_amount_d8` оставлено только для обратной совместимости payload и игнорируется Shop runtime; pricing authority оно не является.
- Payment Intent фиксирует выбранную ручную цену на TTL; изменение карточки влияет только на новые intent. Exchange и другие финансовые контуры не меняются.
- Frozen `0001`, отсутствие `0002+`, FAQ standalone authority и visual/UX/text FRONTEND_v146 сохраняются. Локальные project tests/build/CI не запускались.
- Immutable report `02366`; следующий `02367`; canonical handoff `EFHC_Bot_v174_48.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.47 / цикл 1793 CI qualification repair

- Exact GitHub CI `87288059313` проверил `v174.46` SHA-256 `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`. Все recorded gates GREEN, кроме pytest: `1 failed / 1727 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — устаревший baseline русскоязычной инженерной политики для `CONTINUE_IN_NEW_CHAT.md`: файл содержит `53` неизменяемых исторических англоязычных snapshot-фрагмента при разрешённом historical count `36`.
- Исторические handoff-фрагменты не переписываются. Baseline повышен строго `36 → 53`; любой следующий новый англоязычный prose-фрагмент остаётся fail-closed нарушением.
- Runtime/backend/frontend/DB не менялись. Frozen `0001`, отсутствие `0002+`, FAQ standalone authority, FRONTEND_v146 и deep-remediation contracts сохранены.
- Immutable report `02365`; следующий `02366`; canonical handoff `EFHC_Bot_v174_47.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.46 / цикл 1793 CI qualification repair

- Exact GitHub CI `87285361835` проверил `v174.45` SHA-256 `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Mypy, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend build. RED: Ruff `1×I001`, pytest `17 failed / 1711 passed / 22 skipped / 1 warning`.
- Подтверждённый runtime defect: Panels после canonical financial SSOT migration всё ещё использовал удалённый `transactions_service.SpendBreakdown`; теперь `SpendBreakdown/split_bonus_then_main` импортируются напрямую из `app.standards.finance_rules`.
- Qualification repair: financial SSOT guard проверяет AST contract, Shop guard требует безопасный `CAST(:extra AS jsonb)`, Ruff import-order исправлен.
- Deep backend remediation не откатывается; frozen `0001`, отсутствие `0002+`, FAQ standalone authority и FRONTEND_v146 сохраняются.
- Immutable report `02364`; следующий `02365`; canonical handoff `EFHC_Bot_v174_46.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.45 / цикл 1793 CI qualification repair

- Exact GitHub CI `87278222904` проверил `v174.44` SHA-256 `54b882e871626e7190161c419e9c1f407c9b6a6080478465570ab08856354154`, checkout `001316adea12d34348a510da3cc8b401cbc6f199`.
- GREEN: Development HEAD SHA, Flake8 full-report, Bandit, compileall, PostgreSQL preflight/Alembic, npm install и frontend production build. RED: Flake8 critical `2×F821`, Ruff `8`, Mypy `2`, pytest `8 failed / 1720 passed / 22 skipped / 1 warning`.
- Подтверждённые source repairs: восстановлен `get_session_factory` для auth/provider session boundary; два Shop JSONB bind-cast приведены к `CAST(:extra AS jsonb)` для SQLAlchemy/asyncpg.
- Qualification repairs: Ruff import/SIM/F401 hygiene; scheduler tests переведены на canonical `db_session()`; middleware guards проверяют единый installer; profile export guards проверяют текущую sync-background + async-failure cleanup семантику.
- Deep-remediation contracts `v174.44` не откатываются: root transaction ownership, scheduler cancellation, FSM atomicity, financial SSOT и bounded export сохраняются. Frozen `0001`, FAQ и FRONTEND_v146 unchanged; `0002+` отсутствует.
- Immutable report `02363`; следующий `02364`; canonical handoff `EFHC_Bot_v174_45.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.44 / цикл 1792 deep backend remediation

- Exact CI `87235658448` проверил `v174.43` SHA-256 `0b36f6f734c8a0e3dd94d68b5b35c05331a078845d657bf5021620280d19c739`, checkout `ce2f5085551ff06c1e6a1512eccc6dec3749f049`; все recorded gates GREEN кроме pytest `5 failed / 1697 passed / 22 skipped / 1 warning`.
- Direct owner scope: реализованы подтверждённые `DEF-01…DEF-18` из Deep Backend Remediation Specification и повторно проверен audit. Основные изменения: startup/lifecycle, transaction ownership, scheduler cancellation, FSM atomicity, Shop/payment UoW, CRUD savepoints, единый financial SSOT, bounded queries/export и canonical DB session contract.
- CI-specific watcher failures исправлены только в test harness; production P0 `trusted time → 180-day barrier → replay/idempotency → mutation → ledger` не откатывался. Historical English snapshots не переписывались; language baseline ограничен фактическим historical count.
- Frozen `0001`, FAQ authority/content и FRONTEND_v146 visual/UX/text сохранены; `0002+` отсутствует.
- Immutable report `02362`; следующий `02363`; canonical handoff `EFHC_Bot_v174_44.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются только доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.43 / цикл 1792

- Input exact CI: run `87220054352` on `v174.42` SHA-256 `2ef41df8ec14235d584ccc2a2994cca780c58d0e993de2aacdba3957c56384c8`, checkout `fe6d0d4f32a75d8419f0d165afffc18fef76cc02`.
- Confirmed RED repaired: Ruff 16, Mypy 1, pytest 11 failures by seven root-cause groups; no speculative repairs.
- P0 watcher and Telegram webhook transaction runtime are preserved; six watcher RED and two webhook RED were stale/new test-harness defects, not reasons to rollback runtime.
- Runtime fixes are bounded to scheduler health alias and TonConnect stable typed fail-closed reason. Owner ENV templates synchronized.
- Current report `02361`; next `02362`; canonical handoff `EFHC_Bot_v174_43.zip`.
- Status: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Historical blocks below are evidence only and do not override this first block.

# CURRENT HEAD — кандидат v174.42 / цикл 1791 corrective re-audit по утверждённому ТЗ

- Входной exact candidate: `v174.41`, SHA-256 `baf1ab7b318c69988a4079d8aef022092e4a0499579058e99431cf58903b9a2c`. Owner-approved ТЗ повторного аудита SHA-256 `7f17d680a06cca5cc581a27a0cf1577d5c0a51e9cbe1c3184ad40ae0969b75e8` фиксирует только подтверждённые defects и запрещает менять бизнес-экономику, FAQ authority и frozen schema.
- Ранее зафиксированный exact-head GREEN anchor остаётся `v174.40` по GitHub CI `87088984879`; GREEN **не наследуется** текущим `v174.42`.
- Release-blocking Telegram repair: dedupe marker больше не коммитится до business processing; dedupe storage failure fail-closed; JSON валидируется до marker; webhook владеет единственным root transaction; cancellation/error вызывают rollback; compensating DELETE удалён; `/start` unexpected onboarding errors пробрасываются; onboarding core transaction-neutral и использует savepoint.
- Security/error repair: 17 broad internal 5xx exception disclosures закрыты stable error codes; canonical `app.main:app` применяет `TrustedHostMiddleware`, когда allowlist настроен; active wallet TonConnect proof использует configured-domain-first canonical resolver и не считает request Host production authority.
- Validation/lifecycle repair: raw `Idempotency-Key` валидируется до hash (`<=128`, control chars forbidden); scheduler operational values имеют positive bounds и backoff ordering; logging всегда заполняет `tg_id`; PWA снимает `updatefound/statechange`; serverless VIP tick использует explicit `db_session()` context.
- Добавлены regression/integration test sources, включая real dedupe helper, cancellation/fail-closed cases и PostgreSQL concurrent duplicate/root transaction scenarios. Локально эти tests не запускались; результат должен подтвердить fresh exact-head GitHub CI.
- Frozen migration `0001` и FAQ runtime/FAQ duplicate-control content не менялись. `0002+` не создана. FAQ остаётся самостоятельным checked-in release asset.
- Frontend visual/UX/text authority FRONTEND_v146 не изменён. PWA runtime lifecycle source изменён non-visual; release metadata синхронизированы статически: authority `INTEGRATED_FRONTEND_SOURCE_v174.42_FRONTEND_v146`, controlled entries `195`, source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`, PWA `efhc-acecaa494ab54fe4`.
- Immutable report: `02360`; следующий `02361`. Canonical handoff: `EFHC_Bot_v174_42.zip`. Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.41 / цикл 1791 exact-head GREEN + полный функциональный аудит

- GitHub CI `87088984879` полностью квалифицировал exact `v174.40`: archive SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`; все recorded gate exits `0`; pytest `1670 passed / 22 skipped / 1 warning`; frontend production build и PostgreSQL/Alembic PASS. `v174.40` зафиксирован как **EXACT-HEAD GREEN**.
- По прямому owner order открыт цикл `1791` и выполнен полный статический аудит зарегистрированной application surface и всех финансово/security/ops-critical mutation contours. Public surface сохранён: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`; registered protected Python surface `371 symbols / 70 modules / 86 files`; frontend product pages `39`.
- Подтверждённые repairs нового candidate: watcher P0 `trusted time → 180-day barrier → replay → mutation → ledger`; readiness принимает только authorized migration `0001`; `/cron/tick` в prod/stage регистрирует scheduler jobs strict; encrypted recovery требует ciphertext SHA-256; production update/release contour использует канонический `EFHC_Bot_vNNN_NN.zip` без `_RELEASE`.
- DR/VPS runbooks и current application-function authority синхронизированы с exact source. Referral leaderboard public routes отмечены retired при сохранённой referral economy; Skins — progression-only, `/skins/buy/{skin_id}` остаётся fail-closed compatibility `409 SKIN_COMMERCE_DISABLED`.
- Database schema не менялась: ORM `52 = 45 core + 7 admin`, frozen `0001` сохранён, `0002+` отсутствует. Schema lock — governance lock на неутверждённый DDL, не runtime table/CRUD lock.
- FRONTEND_v146 runtime bytes не менялись. Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.41_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ/locale/PWA остаются standalone checked-in release assets.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI после audit repairs не запускались. Поэтому `v174.41` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**, а не GREEN.
- Immutable report: `02359`; следующий `02360`. Canonical handoff: `EFHC_Bot_v174_41.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.40 / цикл 1790 CI qualification hygiene

- GitHub CI `87074955772` проверил exact `v174.39`: SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872`, checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`. GREEN все recorded gates кроме pytest; pytest `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Единственный confirmed defect — два английских docstring в development-only FAQ duplicate-control verifier. Исправлены только docstring; runtime/frontend/backend/schema semantics не менялись.
- FAQ остаётся самостоятельным checked-in release asset; SSOT — duplicate control only, без runtime write. Release packaging остаётся application-byte verify-only.
- Важно: database/schema lock — это governance lock на неутверждённые DDL/schema/migration changes, **не** runtime lock таблиц и **не** запрет CRUD. Существующие 52 таблицы работают штатно. Frozen `0001` и запрет `0002+` сохраняются до отдельного direct owner decision о schema unlock/change.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.40_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. Frontend controlled bytes не менялись.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не запускались. Candidate `v174.40` требует следующего exact-head GitHub CI.
- Immutable report: `02358`; следующий `02359`. Canonical handoff: `EFHC_Bot_v174_40.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.39 / цикл 1790 release-asset independence + CI qualification repair

- GitHub CI `87062684580` проверил exact `v174.38`: SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75`, checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`. GREEN: Development HEAD SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures классифицированы как qualification-only: hardcoded frontend authority предыдущей версии и два legacy-term guards, ошибочно сканировавшие current control-plane/evidence summaries. Runtime/backend/frontend product behavior этим CI не опровергнут.
- Прямое owner decision цикла 1790: checked-in frontend FAQ является самостоятельным production release asset; FAQ SSOT остаётся только дублирующим контролем и не может генерировать или переписывать runtime FAQ.
- Release packaging переведён в verify-only application-asset mode: `build_release_archive.py` проверяет заранее готовые FAQ/locale/PWA assets и не запускает FAQ/PWA generators. Packaging создаёт только собственные release metadata/checksums в staging.
- Dependency audit: frontend prebuild уже verify-only; OpenAPI/API/backend/schema runtime не генерируются из docs/SSOT при release packaging; development generators остаются вне packaging.
- Database migration lock остаётся active: frozen `0001_initial_release_schema.py`; `0002+`/schema expansion только по отдельному direct owner decision. В cycle 1790 schema не менялась.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.39_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ content Q/A bytes не менялись; изменён только authority header и release-control metadata.
- Локальные tests/build/CI/Alembic/PostgreSQL не запускались. Candidate `v174.39` требует следующего exact-head GitHub CI.
- Immutable report: `02357`; следующий `02358`. Canonical handoff: `EFHC_Bot_v174_39.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.38 / цикл 1789 continuation CI qualification repair

- GitHub CI `86992003426` проверил exact `v174.37`: SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d`, checkout `7384e8284dbde416086a13bd23de7136be585681`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures repaired только в qualification layer: stale Admin history literal → current functional contract; FAQ test function name → Russian engineering policy; stale `current_cycle` → current state key `cycle`. Approved FRONTEND_v146 runtime не откатывался.
- FAQ current parity: `13 × 250/250` SSOT↔runtime. Runtime/prebuild SSOT-independent; release packaging пока SSOT-generating. Standalone verify-only FAQ packaging — **RECOMMENDATION, не owner decision**, поэтому release scripts не менялись.
- Routes/schema audit: `160 paths / 166 public ops / 8 hidden / 174 mounted`; OpenAPI `169 schemas`; ORM/frozen migration exact `52 = 45 core + 7 admin`. Migration lock остаётся active: `0001` frozen; `0002+` только по direct owner decision.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.38_FRONTEND_v146`; entries `195`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`. Backend routes/services, frozen `0001`, FAQ runtime и release scripts cycle continuation не менялись.
- Локальные tests/build/CI не запускались. Candidate `v174.38` требует следующего exact-head GitHub CI.
- Immutable report: `02356`; следующий `02357`. Canonical handoff: `EFHC_Bot_v174_38.zip`; descriptive suffixes/owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.37 / цикл 1789 CI qualification repair

- GitHub CI `86988434882` проверил exact предыдущий `v174.36`: SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77`, checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 failures — stale qualification guards относительно approved FRONTEND_v146: Admin copy literal заменён функциональным EFHCb/EFHCm selector contract; FAQ historical translation literals заменены current SSOT↔runtime parity; HI history registry expectation `7 -> 13`. Runtime/frontend patch не откатывался.
- FAQ delta FRONTEND_v146 велик только в `hi/id/sw`; остальные 10 языков Q/A не изменены. Cycle 1789 не меняет FAQ runtime content.
- Release audit: frontend runtime/prebuild отвязан от Python/docs/SSOT, но release packaging всё ещё намеренно генерирует FAQ из SSOT через `build_release_archive.py -> prepare_frontend_release_assets.py -> generate_faq_catalogs_from_ssot.py`. Release scripts не менялись.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.37_FRONTEND_v146`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA build id `efhc-1466a8410f8c50ab`. Frozen `0001`, backend/API/financial semantics unchanged.
- Локальные tests/build/CI не запускались. Candidate `v174.37` требует следующего exact-head GitHub CI.
- Immutable report: `02355`; следующий `02356`. Canonical handoff: `EFHC_Bot_v174_37.zip`, без descriptive suffix и sidecars.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT PROJECT STATE — v174.36 / cycle 1788 qualification repair

- Exact supplied CI evidence: run `86966635485` tested previous `v174.35` SHA `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`; frontend build and core backend/schema gates GREEN, Ruff/pytest qualification RED.
- Approved FRONTEND_v146 remains visual/UX/text authority; stale tests do not override it.
- Current frontend source authority: `INTEGRATED_FRONTEND_SOURCE_v174.36_FRONTEND_v146` / `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`.
- Candidate `v174.36` is not exact-head GREEN until the next GitHub CI. Local full test/build execution was not performed.

# CURRENT DEVELOPMENT HEAD — кандидат v174.35 / цикл 1788

- Owner открыл `1788` для интеграции supplied FRONTEND_v146 runtime-only patch в exact `v174.35`.
- Patch SHA-256 `19e7b087da7ce017013fa025bcbba29bdeca708c565008d2610139df56d87ebf` применён к `74` frontend paths и удалён после установки; base `VERSION` остаётся `v174.35`.
- Frontend source authority: `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`; backend/API/security/financial CANON не подменяется patch.
- Последний доступный exact-head GREEN: `v174.33`, CI `86661926957`. `v174.35` остаётся candidate до нового exact-head CI.
- Новые CI logs в текущем handoff фактически отсутствуют; no-evidence failures не реконструируются.
- Immutable report `02353`; next `02354`; future range `1801–1900` создан без автоматического открытия циклов.

> **Historical boundary:** нижележащие прежние «текущие» блоки являются историческими snapshots.

# CURRENT DEVELOPMENT HEAD — кандидат v174.34 / цикл 1787

- Exact-head `v174.33` полностью GREEN в GitHub CI `86661926957`; SHA-256 payload `ae5dc9fb2657957b40560cbb350aad435168532c575a2c492ba703f3635f4a5f`; pytest `1664 passed / 22 skipped / 1 warning`; frontend PASS; все canonical gates `exit=0`.
- `v174.34` — document/Q&A/archive-integrity continuation цикла `1787`; production backend/frontend/OpenAPI/schema/financial semantics не меняются.
- Active startup: `START_HERE.md` → `KERNEL.md`. Active Q/A authority: `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`. Historical recovery audit: `docs/audits/Q_A_CHAT_RECOVERY_AUDIT.md`.
- Проверены все 35 доступных numbered chats; 58 explicit Q/A markers в 9 чатах. Неизвестные ответы не реконструируются.
- Immutable report `02352`; следующий `02353`; после `1787` автоматически утверждённых functional cycles нет. Следующий verifier — exact-head GitHub CI `v174.34`.

> **Historical boundary:** все расположенные ниже прежние «текущие» блоки являются снимками истории и не переопределяют этот первый блок.

## Текущая рабочая блокировка — кандидат v173.71 / цикл 1743 — exact-head CI burn-down после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_70.zip`, SHA-256 `fe70e8d27ad1021c85bc9fa46adde832bd52f3c0cc0a27f9be80445f4b869601`, размер `12452372` bytes.
- Exact-head GitHub CI `85540647405`, checkout `49f522c81c324c02134a4bbed4f200f678d98b72`; CI `efhc.zip` имеет тот же размер `12452372` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, compileall, Flake8 critical/full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Ruff — `7` fixable diagnostics; Mypy — `1` typing error; Bandit — `2` B608 low-confidence findings; pytest — `4 failed / 1545 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: import/lint drift; nullable typing materialized deposit recovery; Panels SQL больше не собирается конкатенацией fixed owner-clause; emergency deposit использует external-event idempotency только по immutable `tx_hash`; stale canonical actor fixture и watcher-CANON assertion синхронизированы; Russian Engineering NORM исправлен в двух строках `KERNEL.md`.
- Обязательный Admin audit остаётся fail-closed и атомарным; audit actor — canonical `users.global_id`. RBAC, Admin NFT, strict financial Idempotency-Key для класса `MUST`, materialized-only deposit recovery и rollback semantics аудита 2/10 не ослаблены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02274`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- `require_admin` остаётся authentication/read gate; каждый state-changing Admin `POST/PUT/PATCH/DELETE` требует `require_admin_write` с минимумом Moderator. `Analyst/auditor` получает `403`.
- Emergency EFHC recovery принимает только `tx_hash` и использует только materialized `efhc_core.ton_inbox_logs` под `FOR UPDATE`; client-supplied amount/MEMO/address/raw больше не являются доказательством транзакции.
- Ручная Bank операция фиксирует money ledger + обязательный `admin_action_log` + notification outbox в одной DB transaction; Telegram delivery — только после commit.
- Повторный `Idempotency-Key` с иным финансовым payload даёт `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload допускает read-through.
- Admin NFT использует уже проверенный canonical principal и не проходит whitelist-only повторную авторизацию.
- Panels service использует canonical `archived_at`; compatibility facade делегирует `toggle_panel`; rollback balance type выводится только из исходной ledger-записи.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

# CURRENT CYCLE 1741 — v173.67 candidate

Exact-head CI `85400569189` for input `v173.66` is GREEN on all canonical gates. Cycle 1741 records a static function/route/table audit; runtime/frontend/schema are unchanged. Current candidate `v173.67` changes audit/SSOT/guard files and therefore requires its own exact-head CI.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# EFHC Bot — Development HEAD candidate v173.65 / цикл 1739

GitHub CI `85354825033` на входном `v173.63` (`12252439` bytes) выявил failures Alembic/Bandit/Mypy/frontend build/pytest/Ruff. Исправлены только подтверждённые причины: stale Alembic FK validator `39→41`, CI-reported ADS typing/import/security diagnostics, один TS compatibility prop, stale ADS/Tasks/PATCH guards, точечные provider wire aliases, protected ADS directories и Russian engineering NORM.

Frontend PATCH_002 остаётся visual/text CANON; exact visual files не переписывались. ADS business owner остаётся `global_id`; `builtin_timer` production monetization не возвращён. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.63 / циклы 1735–1737

Полностью реализован owner-directed ADS mediation scope: server-owned `AdManager`, provider registry/adapters, encrypted Admin configuration, ad sessions, UTC daily limits, verified/idempotent EFHCb reward через existing Tasks financial path, automatic fallback, health/circuit breaker, Admin ADS/Tasks, runtime frontend AdManager, analytics/Revenue Optimizer и Telegram Bot integration. `builtin_timer` — только DEV/CI/diagnostics; TADS/MyBid зарегистрированы fail-closed до подтверждённого cabinet reward contract.

Frontend PATCH_002 остаётся visual/text CANON. Current registered surface: `339 symbols / 62 modules / 77 files / 155 OpenAPI paths / 161 operations / 39 frontend pages`. Локальные tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# EFHC Bot — Development HEAD candidate v173.60 / цикл 1734

Цикл 1734 — owner-directed corrective merge после выявления неверного приоритета в цикле 1733. Утверждённый `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` является visual/text CANON; старый Bot UI не восстанавливается ради stale CI guards. Backend/CANON остаётся authority только для contracts/data/business/security. Функции обеих веток сохраняются.

Active merge documents: `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md`, `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`, `docs/frontend/FRONTEND_FUNCTION_UNION_MAP.json`, `docs/testing/FRONTEND_LEGACY_GUARD_MIGRATION.json`. Кандидат `v173.60` локально не тестировался и требует exact-head GitHub CI.

---

# EFHC Bot — Development HEAD candidate v173.59 / цикл 1733

Цикл 1733 обрабатывает exact-head GitHub CI `85239758056` для входного `v173.58` (`12106717` bytes). Подтверждённые failures: Ruff `1`, Mypy `1`, frontend TypeScript build `10 diagnostics`, pytest `57 failed / 1445 passed / 22 skipped / 1 warning`. Исправления ограничены подтверждёнными причинами: tooling/type/build defects, восстановление перезаписанных frontend protection invariants и минимальная актуализация stale expectations только для утверждённых контрактов 1732.

Function surface остаётся `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# EFHC Bot — Development HEAD candidate v173.58 / цикл 1732

Цикл 1732 внедряет проверенный по source SHA production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` поверх exact input `v173.57`. Overlay содержит 176 файлов (`131 modify + 45 add`), без standalone/demo/simulation runtime; добавлены bridge API `GET /auth/profile-photos` и `GET /tasks/earnings/me`. Current surface: `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`.

Wallet bridge сохранён в string-`global_id` CANON с явным DB-boundary helper. Новые инженерные авторские тексты приведены к русскоязычному NORM. Локальные application tests/build/CI не запускались. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

## Текущее состояние разработки — кандидат v173.54 / цикл 1729

- Завершена консолидация десяти решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- GitHub CI `85124642409` для входного `v173.53`: GREEN Ruff/Bandit/Flake8/Alembic/PostgreSQL/compileall/npm ci; подтверждённые Mypy/pytest/frontend failures исправлены минимально.
- Удалены только 7 private transitional SQL aliases с полным delete-proof; внешние/исторические aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1730 — exact-head qualification и error burn-down.

## Текущее состояние разработки — кандидат v173.53 / цикл 1728

- Завершён цикл 1728 — Общие runtime compatibility surfaces.
- Supplied exact-head CI `85114913383` на `v173.52`: подтверждённые Ruff/Mypy/Bandit/pytest/frontend failures исправлены минимально; string-`global_id` CANON не откатывался.
- Создан `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`; правило `no caller != delete proof` закреплено как active policy.
- `app.bot.states` — официальный public FSM facade; остальные утверждённые import/startup/scheduler/Admin surfaces сохраняются бессрочно как thin compatibility contracts.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1729 — консолидация десяти решений.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Current state

Цикл 1718 обработал exact `v173.41` GitHub CI `84954546920`, archive size `12135299` bytes. Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy — `2` ошибки; pytest — `17 failed / 1485 passed / 22 skipped`.

`v173.42` содержит минимальные patches только по подтверждённым CI causes. Final `global_id` ownership, BANK и Admin NFT canons не ослаблялись; retired migration-control/read-switch/tg-owned business runtime не возвращён.

Исправлена packaging-регрессия `v173.41`: восстановлены executable modes release/ops scripts и Unicode-имена исторических reports без изменения их содержимого.

Создан план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: циклы 1719–1728 последовательно согласуют спорные функции, 1729 консолидирует решения, 1730 квалифицирует результат через GitHub CI пользователя, 1731 готовит frontend/audit handoff.

Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guard проверки не запускались. `production_release_ready=false`. Следующий цикл: **1719 — Admin Observability и Reports**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.

## Автономный production DevOps

Production monitoring, безопасный autopilot, local encrypted backup, owner SSH/SFTP export и diagnostic bundle описаны в `docs/SSOT/AUTONOMOUS_DEVOPS_SSOT.md` и `release_docs/DEVOPS.md`. Полный owner-facing production ENV template — `env.release.example` / release `.env.example`.
