# EFHC Bot — development candidate v172.65

Циклы 1641–1645 сохранены. Цикл 1646 начал безопасное удаление
legacy-алиасов без runtime-callers.

Ключевые документы:

- `START_HERE.md` — текущий статус;
- `docs/NORM/TZ/TZ_global_id_full_cutover.md` — исходное ТЗ;
- `docs/audits/LEGACY_ALIAS_REMOVAL_AUDIT_V172_64.md` — аудит;
- `docs/cycles/WORK_CYCLES_1640_1665_APPROVED_PLAN.md` — план;
- `CONTINUE_IN_NEW_CHAT.md` — следующий шаг.

Статус: локальные ошибки fresh CI исправлены, exact-head CI обязателен,
production cutover не выполнен, production release не готов.
