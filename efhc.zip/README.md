<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

# EFHC Bot — current identity canon v173.08

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.


## Текущая release schema

- один Alembic head;
- `backend/migrations/versions/0001_initial_release_schema.py`;
- `users.global_id` — физический account owner;
- exact-head GitHub CI остаётся источником финальной квалификации.

---

# Восстановленный полный README v171.89

## EFHC Agent Skills Adapter

This archive includes root `AGENTS.md`, `CLAUDE.md` and
`docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md`. Agent Skills are used as a workflow
layer below AI Archive Laws, SSOT and NORM. The adapter uses a P0/P1/P2
threshold model and does not replace archive cycles, reports, Healer or guards.

---

## Canon Guard
Перед тестами/деплоем обязательно: `make canon`
(или `python ops/canon_guard.py`).

# EFHC-Bot — Energy for Humanity Coin

**EFHC** — энергетический токен и игровая экономика, где внутриигровой
курс фиксирован: **1 EFHC = 1 кВт·ч**.

## Актуальный срез

Точные счётчики проекта могут меняться между циклами.
Актуальные подтверждённые значения нужно брать из профильных документов и
инвентаризаций HEAD, а не из этого README.

Базовые ориентиры:
- схемы БД: `efhc_core`, `efhc_admin`;
- active migration layer: `0001_init.py`;
- backend: `backend/`;
- bot: `backend/app/bot/`;
- webapp: `frontend/`;
- ops: `ops/`;
- docs: `docs/`.

## Почему EFHC-Bot
- безопасная экономика: только движения **Bank ↔ User**;
- идемпотентность денежных POST;
- пер-секундная генерация энергии;
- VIP NFT, Hub, Referrals, Panels, Exchange, Admin;
- полный audit trail.

## Источники истины
- `docs/AI/AI_OPERATOR_RULES_EFHC.md`
- `docs/SSOT/SSOT_INDEX.md`
- `docs/SSOT/EFHC_CANON.md`
- `docs/NORM/ARCHITECTURAL_LOCKS.md`
- `docs/cycles/WORK_CYCLES.md` (индекс)
- `docs/GENERAL/MASTER_DOCUMENT_INDEX.md`

## Быстрая навигация по документации
- обзор проекта: `docs/PROJECT_OVERVIEW_RU.md`
- карта model→table→route→test:
  `docs/NORM/MODEL_TABLE_ROUTE_TEST_MAP.md`
- банковый канон: `docs/SSOT/BANK_CANON.md`
- каталог тестов: `docs/NORM/TESTS_CATALOG.md`
- навигация по архиву: `docs/GENERAL/ARCHIVE_NAV_INDEX.md`
- продолжение в новом чате:
  `docs/AI/CONTINUE_NEW_CHAT_V162_02_PROMPT.md`

## Healer

Healer хранит медицинские карточки болезней проекта
(`atlas.json`) и историю лечения (`casebook.json`).
Записи подтверждённых циклов дублируются в Healer,
`EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` и `reports/`.

## Docker local environment

Для локальной работы через Docker подготовлен полный стенд:
- `db` — PostgreSQL 16;
- `backend` — FastAPI/бот с ожиданием БД и `alembic upgrade head`;
- `frontend` — Next.js с same-origin proxy на backend.

Быстрый старт:

```bash
cp env.docker.example .env.local
make docker-up
```

После старта:
- frontend: `http://localhost:3000`
- backend: `http://localhost:8000`
- health: `http://localhost:8000/health`
- swagger: `http://localhost:8000/docs`

Полные инструкции: `docs/GENERAL/DOCKER_LOCAL.md`.

## EFHC Bot overview

EFHC Bot is a Telegram WebApp + FastAPI backend + admin surface for the EFHC energy economy.

Core economic rules reflected by the current HEAD:

- `1 EFHC = 1 kWh` inside the game;
- `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`;
- withdrawals come only from `main_balance`;
- `bonus_balance` is not withdrawable;
- balance movements are mediated through the EFHC bank canon.

