# EFHC Bot v173.37

## Current qualification state v173.37

Cycle 1712 qualified the completed `global_id` ownership migration using exact-head GitHub CI `84923645231` on byte-exact `v173.36`. Cycle 1713 then removed retired runtime migration aliases/stubs/temp infrastructure and old business `tg_id` routes.

`v173.36` is the exact-green qualification anchor. `v173.37` is the post-migration cleanup package and requires its own exact-head CI before package-specific qualification. Next cycle: **1714 — Alias cleanup qualification**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- externalized obsolete artifacts: отдельный `EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`;
- устаревшие code/test/document snapshots отсутствуют в active HEAD.

`reports/current/` содержит только текущие operational ledgers; immutable история
создаётся по `docs/NORM/IMMUTABLE_HISTORY_NORM.md`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.
6. `docs/PLANS/WORK_PLAN_1693-1709.md`.
