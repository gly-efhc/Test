<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.10

Статус: **DEVELOPMENT HEAD / EXACT_HEAD_CI_REQUIRED**  
Текущий цикл: **1690**

## Каноническая архитектура

- Backend: Python, FastAPI, SQLAlchemy, PostgreSQL, Alembic.
- Frontend: Next.js, React, TypeScript, Telegram Web App.
- Единственный внутренний account/business owner: `global_id`.
- Во внешнем API `global_id` — строка `^[0-9]{10}$`; в PostgreSQL — BIGINT.
- `tg_id` используется только как Telegram provider subject или delivery
  recipient.
- Единственный Alembic head:
  `backend/migrations/versions/0001_initial_release_schema.py`.
- Постоянное английское имя активного статуса: `Activ`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/CURRENT_CYCLE.md`.

Исторические документы находятся в `АРТЕФАКТЫ/` и не являются current
CANON/SSOT/NORM.
