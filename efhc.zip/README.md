<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.29

## Current qualification state v173.29

Циклы 1704–1705 завершены. Цикл 1706 остаётся IN PROGRESS; fresh exact-head GitHub CI `84865747522`
(`6d5002fbce58579f2c09f28f60762a15184d4510`) подтвердил 3 pytest failures при остальных gate exit=0. Три причины исправлены;
требуется следующий exact-head run. `global_id=1313131313` зарезервирован для SuperAdmin,
но права по-прежнему выдаются только server-side whitelist + RBAC.

Статус: **DEVELOPMENT HEAD / NEXT_EXACT_HEAD_GITHUB_CI_REQUIRED**  
Текущий цикл: **1706**

## Каноническая архитектура

- Единственный внутренний account/business owner: `global_id`.
- Внешний `global_id`: строка `^[0-9]{10}$`; `0000000000` запрещён.
- `tg_id` — только Telegram provider subject / ingress / delivery / payment metadata.
- Цепочка identity: `provider + subject -> global_id -> business runtime`.
- `business_owner_tg_id = 0`; provider-boundary surface контролируется построчно.
- Business frontend/query keys и post-auth `/sync/me` provider-neutral.
- Единственный Alembic head: `backend/migrations/versions/0001_initial_release_schema.py`.
- `Activ` и экономические константы не изменяются без решения пользователя.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- externalized obsolete artifacts: отдельный `EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`;
- устаревшие code/test/document snapshots отсутствуют в active HEAD.

`reports/current/` содержит только текущие operational ledgers; immutable история
создаётся по `docs/NORM/IMMUTABLE_HISTORY_NORM.md`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.
6. `docs/PLANS/WORK_PLAN_1693-1709.md`.
