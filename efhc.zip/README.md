## Canon Guard
Перед тестами/деплоем обязательно: `make canon`
(или `python ops/canon_guard.py`).

# EFHC-Bot — Energy for Humanity Coin

**EFHC** — энергетический токен и игровая экономика, где внутриигровой
курс фиксирован: **1 EFHC = 1 кВт·ч**.

## Актуальный срез
- схемы БД: **2** (`efhc_core`, `efhc_admin`)
- ORM-таблицы: **38**
- HTTP-маршруты: **92**
- test files: **74**
- миграции: единая `0001_init.py`

## Почему EFHC-Bot
- безопасная экономика: только движения **Bank ↔ User**;
- идемпотентность денежных POST;
- пер-секундная генерация энергии;
- VIP NFT, lotteries, shop, referrals, panels;
- full admin и audit trail.

## Архитектура
- Backend: `backend/`
- Bot: `backend/app/bot/`
- WebApp: `frontend/`
- Ops: `ops/`
- Docs: `docs/`

## Источники истины
- `docs/OVERVIEW_SSOT_SYNC.md`
- `docs/EFHC_CANON.md`
- `docs/ssot_pack/*`
- `tests/**/test_*.py`

## Документация
- обзор проекта: `docs/PROJECT_OVERVIEW_RU.md`
- карта model→table→route→test:
  `docs/MODEL_TABLE_ROUTE_TEST_MAP.md`
- банковый канон: `docs/BANK_CANON_SHORT.md`
- каталог тестов: `docs/TESTS_CATALOG.md`
