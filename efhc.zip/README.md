## Текущее состояние разработки — кандидат v173.53 / цикл 1728

- Завершён цикл 1728 — Общие runtime compatibility surfaces.
- Supplied exact-head CI `85114913383` на `v173.52`: подтверждённые Ruff/Mypy/Bandit/pytest/frontend failures исправлены минимально; string-`global_id` CANON не откатывался.
- Создан `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`; правило `no caller != delete proof` закреплено как active policy.
- `app.bot.states` — официальный public FSM facade; остальные утверждённые import/startup/scheduler/Admin surfaces сохраняются бессрочно как thin compatibility contracts.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные qualification checks не запускались; требуется следующий exact-head GitHub CI.
- Следующий цикл: 1729 — консолидация десяти решений.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Current state

Цикл 1718 обработал exact `v173.41` GitHub CI `84954546920`, archive size `12135299` bytes. Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy — `2` ошибки; pytest — `17 failed / 1485 passed / 22 skipped`.

`v173.42` содержит минимальные patches только по подтверждённым CI causes. Final `global_id` ownership, BANK и Admin NFT canons не ослаблялись; retired migration-control/read-switch/tg-owned business runtime не возвращён.

Исправлена packaging-регрессия `v173.41`: восстановлены executable modes release/ops scripts и Unicode-имена исторических reports без изменения их содержимого.

Создан план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: циклы 1719–1728 последовательно согласуют спорные функции, 1729 консолидирует решения, 1730 квалифицирует результат через GitHub CI пользователя, 1731 готовит frontend/audit handoff.

Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guard проверки не запускались. `production_release_ready=false`. Следующий цикл: **1719 — Admin Observability и Reports**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.