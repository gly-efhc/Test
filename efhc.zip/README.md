<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.36

## Current qualification state v173.36

Fresh GitHub CI `84921131844` доказал byte-exact `v173.35`: checkout `ffdc369b3eaaf65eacbac48f31e7e7743458434e`,
`efhc.zip` `11846393` bytes, Git blob SHA-1 `9d729596849cd9c80eb6480acc92c04881fe7419`. Все canonical gates green;
pytest `1498 passed / 22 skipped / 1 warning`.

Цикл **1711 — Exact-head CI burn-down** закрыт без code patch: подтверждённых
ошибок не было. Следующий цикл — **1712 Qualification milestone**.

Статус текущего архива `v173.36`: **DEVELOPMENT HEAD / PREDECESSOR EXACT-HEAD GREEN / CURRENT PACKAGE EXACT-HEAD REQUIRED**.  
`production_release_ready = false`.

## Каноническая архитектура

- Единственный внутренний account/business owner: `global_id`.
- Внешний `global_id`: строка `^[0-9]{10}$`; `0000000000` запрещён.
- `tg_id` — только Telegram provider subject / ingress / delivery / payment metadata.
- Цепочка identity: `provider + subject -> global_id -> business runtime`.
- `business_owner_tg_id = 0`; provider-boundary surface контролируется построчно.
- Business frontend/query keys и post-auth `/sync/me` provider-neutral.
- Единственный Alembic head: `backend/migrations/versions/0001_initial_release_schema.py`.
- `Activ` и экономические константы не изменяются без решения пользователя.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- externalized obsolete artifacts: отдельный `EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`;
- устаревшие code/test/document snapshots отсутствуют в active HEAD.

`reports/current/` содержит только текущие operational ledgers; immutable история
создаётся по `docs/NORM/IMMUTABLE_HISTORY_NORM.md`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.
6. `docs/PLANS/WORK_PLAN_1693-1709.md`.
