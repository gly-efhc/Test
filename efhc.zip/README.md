# EFHC Bot — development candidate v172.57

Цикл 1640: write-side foundation полного business cutover на `global_id`.

Ключевые документы:

- `START_HERE.md` — текущий статус;
- `docs/NORM/TZ/TZ_global_id_full_cutover.md` — исходное ТЗ;
- `docs/cycles/WORK_CYCLES_1640-1650_GLOBAL_ID_FULL_CUTOVER.md` — план;
- `docs/audits/CYCLE_1640_GLOBAL_ID_IDEMPOTENCY_AUDIT.md` — audit;
- `CONTINUE_IN_NEW_CHAT.md` — следующий шаг.

Статус: local scope complete, fresh exact-head CI required,
production release not ready.
