## Canon Guard
Перед тестами/деплоем обязательно: `make canon` (или `python
ops/canon_guard.py`).

# EFHC-Bot (Canon v2.8) — Energy for Humanity Coin

**EFHC (Energy for Humanity Coin)** — утилитарный энергетический токен и
экосистема, где **1 EFHC = 1 кВт·ч** (фиксированный внутриигровой курс).
Этот репозиторий содержит полный стек: **FastAPI backend + aiogram bot +
Next.js WebApp + Full Admin Panel + Ads/Rotations**.

## Почему EFHC-Bot
- ✅ **Безопасная экономика**: только движения **Bank ↔ User**, никакого
  P2P.
- ✅ **Идемпотентность**: все денежные операции через `Idempotency-Key` и
  журнал `efhc_transfers_log`.
- ✅ **Пер-секундная генерация энергии**: начисление строго по времени,
  без ручных “подкруток”.
- ✅ **VIP NFT**: проверка владения NFT (VIP) по расписанию и по событию
  входа.
- ✅ **Full Admin**: пользователи, банк, заявки на вывод, панели, shop,
  задания, лотереи, реклама, отчёты, логи.
- ✅ **Реклама / Ads**: ротация баннеров и интеграционные хуки под
  Telegram Ads API.

## Быстрый старт (локально)
1) Скопируйте `.env.local.example` → `.env.local` и заполните
`BOT_TOKEN`, `ADMIN_IDS`. 2) Запустите:
```bash
docker compose -f ops/docker/docker-compose.yml up --build
```
3) Backend: `http://localhost:8000`
4) Frontend (WebApp): `http://localhost:3000`

## Перед стартом (обязательно)
1) Примените миграции Alembic:
```bash
alembic upgrade head
```
2) Проверьте здоровье БД и схему:
- `GET /health/db` — соединение + ключевые колонки
- `GET /health/db-schema` — контроль колонок `withdraw_requests`

Если `/health/db-schema` возвращает `missing`, значит миграции не
применены. В таком случае сервис может падать ошибками вида `column does
not exist`.

## Архитектура
- Backend: `backend/` (FastAPI, SQLAlchemy 2.0 async, Alembic)
- Bot: `backend/app/bot/` (aiogram 3)
- WebApp: `frontend/` (Next.js + Tailwind)
- Ops: `ops/` (Docker, k8s, monitoring, scripts)
- Docs: `docs/` (канон, правила, runbooks, ADR)

## Реклама (Ads) и партнёрства
EFHC-Bot поддерживает **ротацию рекламных слотов** (Ads) и подготовлен к
интеграции с **Telegram Ads API**:
- показ баннеров в WebApp и бот-сообщениях
- управление весами/периодами показа через Full Admin
- отчёты и ежедневные сводки (scheduler)

## Full Admin
Админ-панель доступна в WebApp (раздел `/admin`):
- Dashboard: KPI по пользователям/банку/выводам/генерации
- Users: статусы, балансы, VIP/NFT, панели, рефералы
- Bank: центральный баланс, операции, аудит
- Withdrawals: обработка заявок, приоритет VIP
- Shop/Tasks/Draws/Ads: управление контентом
- Logs: фильтры, поиск, экспорт

## Лицензия
MIT (см. LICENSE)


## Важно: миграции обязательны
Перед запуском backend **обязательно** выполните миграции Alembic до
актуального `head`. Без миграций (в частности
`20260216_0006_withdraw_requests_unify.py`) сервис вывода/админка могут
упасть с ошибкой отсутствующих колонок.

## Важно: аутентификация пользователя (security gate)
По умолчанию backend **не доверяет** идентификатору из query/headers.

**Разрешённый путь в проде:**
- `request.state.tg_id` (если у вас стоит middleware, который
  валидирует Telegram initData / JWT и кладёт tg_id в state)
- или заголовок `X-Telegram-Init-Data` (валидируется HMAC через
  `security_core.verify_telegram_init_data`)

Это сделано, чтобы исключить подмену личности и вывод/просмотр чужих
данных.


## Documentation

- Аудиты (PDF): `docs/audits/README.md`
