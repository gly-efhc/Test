Physical checkpoint: FRONTEND_v793 / Cycle0512 iteration01 / report00744 / AuthContext tests and safe Python formatting; Flake8 NOT RUN, PARTIAL.
Physical checkpoint: FRONTEND_v792 / Cycle0511 iteration04 / report00743 / local Python formatting + active identity and k6 test remediation; Flake8 exact HEAD NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v788 / Cycle0510 iteration01 / report00739 / 100 locally source-checked Python formatting edits and no-deletion redundant tests audit; Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v778 / Cycle0498 iteration01 / report00729 / 41 AST/token-identical Python indentation corrections (E122 4, E125 36, E127 19, E131 41); post-fix Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v777 / Cycle0497 iteration01 / report00728 / 68 AST/token-identical E125 formatting corrections in Python test sources; post-fix Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v776 / Cycle0496 iteration01 / report00727 / 100 AST/token-identical E128 indentation source corrections in 27 Python tests; Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v775 / Cycle0495 iteration01 / report00726 / 100 AST/token-identical E128 indentation source corrections in 33 Python tests; Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v774 / Cycle0494 iteration01 / report00725 / 100 AST/token-identical E128 indentation source corrections in 41 Python tests; Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v773 / Cycle0493 iteration01 / report00724 / 99 AST-and-token-identical E251 and 1 E275; cycle-numbering guard fixed; fresh v772 Flake8 baseline 1890; post-fix Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v772 / Cycle0492 iteration01 / report00723 / 100 AST-identical formatting changes (72 E203, 28 E501), report guards inherited from v771, Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v770 / Cycle0490 iteration01 / report00721 / safety correction: 48 unqualified E251 edits rejected before release, 28 prior E251 regressions reverted using exact v768 lines; AST PASS; Flake8 NOT RUN; PARTIAL.
Physical checkpoint: FRONTEND_v769 / Cycle0489 iteration01 / report00720 / 100 source-level corrections (E211: 8, E251: 28, E502: 22, W293: 42) in 37 AST-equal Python files; Flake8 NOT RUN, PARTIAL.
Physical checkpoint: FRONTEND_v768 / Cycle0488 iteration01 / report00719 / 100 source-level corrections (E502: 100) in 31 AST-equal Python files; Flake8 NOT RUN, PARTIAL.
Physical checkpoint: FRONTEND_v767 / Cycle0487 iteration01 / report00718 / 100 E502 source-level corrections in 60 AST-equal Python files; Flake8 NOT RUN, result PARTIAL.
Physical checkpoint: FRONTEND_v766 / Cycle0486 iteration01 / report00717 / 100 E502 source-level corrections in 46 AST-equal Python files; Flake8 NOT RUN, result PARTIAL.
Physical checkpoint: FRONTEND_v765 / Cycle0485 iteration01 / report00716 / 100 historical v762-log formatting positions addressed in 31 AST-equal Python files; Flake8 NOT RUN, result PARTIAL.
Physical checkpoint: FRONTEND_v764 / Cycle0484 iteration01 / report00715 / 100 v762 diagnostic positions corrected locally in 36 AST-equal Python files; Flake8 NOT RUN, result PARTIAL.
Physical checkpoint: FRONTEND_v763 / Cycle0483 iteration01 / fresh Flake8 v762: 2,548 diagnostics; 100 AST-preserving local formatting actions; full qualification NOT RUN.
Physical checkpoint: FRONTEND_v749 / Cycle0473 iteration02 / report00700 / OWNER 100 EFHC forward ledger finance amendment / PostgreSQL NOT RUN / Flake8 OPEN / external CI NOT RUN.
Physical checkpoint: FRONTEND_v748 / Cycle0473 iteration01 / report00699 / OWNER docs/contracts patch applied 32 files; Cycle0472 Flake8 OPEN; external CI NOT RUN.
Physical checkpoint: FRONTEND_v747 / Cycle0472 iteration05 / report00698 / Flake8 planning only; Cycle0473 docs reserved; 0474–0505 planned; Flake8/FULL NOT RUN.
Physical checkpoint: FRONTEND_v746 / Cycle0472 iteration04 / report00697 / Flake8 PARTIAL (52 overlong lines, Flake8 NOT RUN); full CI NOT RUN.
# EFHC Frontend

GitHub working repository for the EFHC application source.

Canonical production release schema: [`Схема приложения.md`](Схема%20приложения.md).  
Visual release/deploy schema: [`Схема приложения — визуальная.md`](Схема%20приложения%20%E2%80%94%20визуальная.md).  
Runtime/causal architecture: [`APPLICATION_WORKING_SCHEMA.md`](APPLICATION_WORKING_SCHEMA.md).

Working status: Cycle ID `0463` — DONE / FRONTEND_v702 / report00663 / OWNER I18N + CT06/CT10 CORRECTIONS. Cycle0460 OWNER visual gate remains open; its overbroad qualification wording remains superseded by Cycle0461 evidence.
Current physical checkpoint: `FRONTEND_v763` — Cycle0483 bounded Flake8 engineering checkpoint, PARTIAL.
Current physical release identity: `FRONTEND_v763`.
Current numbered report: `00718__reports_FRONTEND_ADMIN_CYCLE_0487_iteration_01_FRONTEND_v767_flake8_bounded_E502_remediation.md`; next `00719`.
Current engineering candidate: FRONTEND_v763; 27 Python source paths with AST-preserving edits; full lint NOT RUN; Admin visual frozen.

Universal new-chat bootstrap/handoff prompt: `frontend_promt.md` (OWNER-protected; current state still comes from the physical archive).

Current reports/process authority:
- `reports/README.md`;
- `reports/rules/00001__rules_reports_section_numbering_and_logging_canon.md`;
- `reports/rules/00002__rules_dynamic_reports_navigation_nonblocking_work.md`;
- `docs/NORM/EFHC_REPORTING_RULES_TZ.md`;
- `docs/NORM/FRONTEND_REPORT_STANDARD.md`;
- `docs/frontend/FRONTEND_REPORTS_CONSOLIDATION_0430-0433_PLAN.md`;
- `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md`.

Historical recovery provenance (not current reporting authority):
- `docs/frontend/FRONTEND_REPOSITORY_TARGET_CONTRACT_0426.md`;
- `docs/frontend/FRONTEND_REPOSITORY_GAP_MAP_0426.json`;
- `docs/frontend/FRONTEND_REPOSITORY_RECOVERY_0426-0429_PLAN.md`.

Reports sequence:
- `0430` — full reports census + immutable migration map — DONE;
- `0431` — physical consolidation + roadmap relocation + OWNER reports architecture canon — DONE;
- `0432` — unified number-first reports/cycles + single JSON manifest + reporting-rules hardening — DONE;
- `0433` — backend single-source cleanup + Frontend chat-history recovery/archive workflow — DONE;
- `0434` — dynamic non-blocking reports navigation + exact nine-plugin whitelist/control-plane causality — DONE.

Historical Cycle0429 remainder0435–0444 is complete.0445 and0446 completed by direct OWNER assignments;0447/0448 приняты OWNER и merged PR5;0449 завершён;0450 is DONE ENGINEERING; historical Theme04→Theme13 allocation for 0451–0460 is now superseded by the direct OWNER `COLOR ≠ DESIGN` roadmap for future 0453–0460; none starts automatically. Cycle0435 is complete. Cycle0436 is complete: Support/Hub and the three OWNER-authorized referral/payout backend+OpenAPI seams pass Architecture16/16, targeted backend51/51, regression124/124, performance45/45 and typecheck/build; final outcome is in existing report00617. Cycle0437 is complete: TON-only outcome persistence, ORM role Enum serialization and release-schema drift detection; PostgreSQL/migration checks 132 PASS / 1 historical pre-squash SKIP, native bootstrap twice PASS, frontend regression124/124 and typecheck PASS; final report00619. Cycle0438 is complete: individual eight-field cycle entries and full runtime/OpenAPI174 paths/181 operations/190 schemas parity; architecture80/80, backend72/72, regression124/124, performance45/45, typecheck/build PASS; one final report00620. Cycle0439 is complete: release policy/version parity, executable modes, deterministic packaging/membership and runtime receipt-path repair; release55/profile13 PASS, regression124/124, performance45/45, typecheck/build/assets PASS; one final report00621. Packaging qualification used temporary staging and in-memory ZIPs; no physical release issued. No protected business-semantic mutation. Cycle0440 is complete: canonical app package resolution uncovered110 typing errors/48 files; mypy0/362 and Ruff PASS after type/runtime contract repairs explicitly authorized by OWNER. Relevant backend/PostgreSQL/contracts162/162, regression124/124, performance45/45, typecheck/build and schema/OpenAPI parity PASS; one final report00622. Cycle0441 is complete: all157 baseline FAIL classified; full pytest1792 PASS /61 justified historical/nonapplicable SKIP, no FAIL/ERROR; three transferred architecture FAIL resolved. Release runtime-version authority, current assertions/fixtures/guard boundaries and FAQ duplicate mirrors corrected; protected production semantics unchanged. Mypy0/362, Ruff, PostgreSQL/schema/OpenAPI, regression124/124, performance45/45 and typecheck/build PASS; one final report00623. Cycle0442 is complete: current production/browser navigation, floating PWA spacing, portfolio/Shop cache refresh, nullable task API/claim visibility, decimal profile balance display, CSS parser, native TON transport and USDT canonical memo defects repaired without protected business-semantic changes; existing auth/provider/DTO/visual fixtures currentized. Combined browser/async pytest fixture lifetime and atomic TTL assertion repaired by root cause. Clean default typecheck/build/assets/routes, regression124/124, performance45/45 and all56 browser cases PASS. Full pytest1848 PASS /41 historical SKIP /0 FAIL/ERROR; mypy0/362, Ruff and PostgreSQL/schema/OpenAPI parity PASS. One final report00624. Cycle0443 is complete: actual exact-HEAD native and GitHub FAST/FULL/RELEASE/Security PASS; one existing report00625 finalized for the whole cycle. Qualification remains reusable evidence. Cycle0444 is complete: physical/main ancestry, exact canonical release mappings, anti-loss and deterministic repeated in-memory packaging PASS; one final report00626. Historical remainder0435–0444 complete, not final project or physical release. Cycle0445 DONE: initial41 SKIP classified A35/D5/E1; existing stale language case restored, final40 justified SKIP, actionable/unjustified0. Targeted language8 and closure12 PASS; exact engineering4927 native FAST/Security/FULL/RELEASE PASS; one report00627. Main4033 is separate OWNER merge checkpoint of PR3; current PR4 draft/open. Cycle0446 DONE:10 actual external/provider surfaces classified; canonical deposit memo, lossless TON transport, bridge lifecycle/availability/receipt and unsigned gas contracts repaired. Targeted27 PASS/1 unchanged historical SKIP, typecheck/scoped Ruff and exact engineering7553603 native FAST/Security/FULL/RELEASE PASS. One final report00628; explicit live-provider/on-chain limitations, funds movement0; PR4 draft/open, main4033 unchanged. Cycle0450 historical engineering closure is retained. Cycle0451 Theme04 is OWNER visually accepted. Subsequent OWNER maintenance through v678 fixed Theme03 Ranks shared actions and Referrals social brand ownership. Cycle0452 is DONE / CLOSED BY OWNER ADVANCE in FRONTEND_v682/report00649. Cycle0453 is DONE in FRONTEND_v683/report00650. Cycle0454 is DONE in FRONTEND_v684/report00651: `color_theme_id` and independent `interface_variants` are split, legacy13→10 migration preserves effective designs, and color changes do not reset forms. Cycle0455 was previously marked DONE at FRONTEND_v685/report00652 but is now REOPENED by direct OWNER visual-regression finding. The v685 broad Shared Color stylesheet is rejected and quarantined; FRONTEND_v687 restores the v684 authored visual baseline while retaining safe Cycle0454/0455 state, RP35/PB35, clipping and TON5 work. Cycle0456 is DONE / CLOSED BY OWNER ADVANCE at FRONTEND_v692/report00655. Cycle0457 is DONE at FRONTEND_v693/report00656. Cycle0458 is DONE at FRONTEND_v694/report00657. Cycle0459 is DONE at FRONTEND_v696/report00658. Cycle0460 engineering is DONE at FRONTEND_v698/report00659 and remains on OWNER visual gate; Cycle0461 external-audit recovery is complete in FRONTEND_v700/report00661; Cycle0462 exact-CI root-cause recovery is complete in FRONTEND_v701/report00662; Cycle0463 OWNER correction is complete in FRONTEND_v702/report00663; Cycle0464 current iteration04 v706/report00667; Cycle0465 accepted at FRONTEND_v718/report00677; Cycle0466 started by direct OWNER command and issued FRONTEND_v719/report00678; Cycles0467–0470 require direct OWNER start.

Local chat workspace is the primary mutable engineering workspace. GitHub is repository source/history/CI authority beneath direct OWNER/SSOT/CANON/NORM and is updated by bounded sync after local work. Physical `FRONTEND_vNNN.zip`, standalone HTML and Shop HTML remain immutable checkpoints delivered in chat.

Allowed plugin control plane: EFHC CODE = governance/orchestration; GitHub = source/history/CI; Linear = primary work-state; Railway = runtime/deploy; PostHog = product analytics; Context7 = current technical docs; Notion = durable knowledge; DigitalOcean = remote engineering environment; Atlassian = reserve-only. Any additional plugin requires direct OWNER approval.

Physical release / repository sync: `_import/` is OWNER-PROTECTED and permanent in both GitHub and every full repository checkpoint. OWNER uploads the complete `FRONTEND_vNNN.zip` to `_import/`; `repository-import-sync` validates it and mirrors the repository to that full release. The transport ZIP is removed after successful sync, while `_import/README.md` must remain. Patch-only transport is not the primary update mechanism. Nested ZIP is allowed only under `_import/`. Cache/build/temp garbage remains forbidden. Current archive ceiling: 19 MiB.

Backend current source authority: `docs/backend/BACKEND_SOURCE_AUTHORITY.md` (`backend/` single code tree + root `api/` deployment wrapper).

Frontend chat-history corpus: `docs/chats/` — 46 OWNER-provided Frontend chat files with SHA manifest, recovery registry and explicit missing-number register.

Tool/plugin catalog: `docs/AI/EFHC_AVAILABLE_PLUGINS_AND_SKILLS.md`.

Public TON runtime canon for real transaction tests: `release_config/TON_PUBLIC_RUNTIME.json` with dotenv mirror `env.ton.public`. Known public runtime values are preserved separately from unresolved private ENV recovery.


## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО** удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять concrete value placeholder/empty/default; выполнять destructive redaction; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; либо считать `.gitignore`, `.dockerignore`, secret classification или generic best practice разрешением на удаление.

Если обнаружен security concern: **сохранить исходные bytes → STOP destructive mutation → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV требует отдельной прямой команды и before/after evidence.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или выдавать placeholders за восстановление. Human authority: `docs/SSOT/ENV_PROTECTION_SSOT.md`; machine policy: `release_config/ENV_OWNER_PROTECTION.json`; recovery state: `release_config/ENV_RECOVERY_STATUS.json`.

Историческая closure Cycle0448: Exact 5a4d3ec5c2789b2855ae43863f4c4a2bef888965: native FAST38324479934/Security38324479912/FULL+RELEASE38324480147 PASS, 0 FAIL/ERROR; exact EFHC D8, provider/SQL atomicity/schema64, regression124/124, performance45/45, typecheck/build/Ruff/mypy0/364. Live GRAM/EFHC BLOCKED: allocated signer и deployed API/runtime binding отсутствуют; funds movement0. Итоговый report: `reports/numbered/00632__reports_FRONTEND_ADMIN_CYCLE_0448_iteration_01_Cycle0448_точный_D8_EFHC_и_атомарные_provider_ledger_contracts.md`. PR5 draft/open, main2ae3b9f unchanged; no physical release/comments/new branch/PR.

Cycle0449: Engineering c77d6652ba6072ebc1264b3ec8abaac36a1370bd: targeted181 PASS; Ruff PASS/mypy0 affected5; native FAST38332100270/Security38332100513/FULL+RELEASE38332100492 PASS на exact HEAD,0 FAIL/ERROR; provider/PG retry/scheduler/lifecycle/redaction доказаны; protected source Cycle0448 сохранён. Итоговый report: `reports/numbered/00633__reports_FRONTEND_ADMIN_CYCLE_0449_iteration_01_Cycle0449_операционная_устойчивость_provider_PostgreSQL_scheduler_и_lifecycle.md`. PR6 draft/open; main78d280115add60744eef95eb25a8d079f62aa32c unchanged. PR5 исторически merged по OWNER decision; physical release666 сохранён. No physical release/comments/0450.
