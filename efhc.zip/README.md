> Current Development HEAD candidate: `v173.48`; completed cycle 1723; next exact-head GitHub CI required.

# EFHC Bot v173.42

## Current state

Цикл 1718 обработал exact `v173.41` GitHub CI `84954546920`, archive size `12135299` bytes. Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy — `2` ошибки; pytest — `17 failed / 1485 passed / 22 skipped`.

`v173.42` содержит минимальные patches только по подтверждённым CI causes. Final `global_id` ownership, BANK и Admin NFT canons не ослаблялись; retired migration-control/read-switch/tg-owned business runtime не возвращён.

Исправлена packaging-регрессия `v173.41`: восстановлены executable modes release/ops scripts и Unicode-имена исторических reports без изменения их содержимого.

Создан план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: циклы 1719–1728 последовательно согласуют спорные функции, 1729 консолидирует решения, 1730 квалифицирует результат через GitHub CI пользователя, 1731 готовит frontend/audit handoff.

Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/Alembic/frontend build/CI/guard проверки не запускались. `production_release_ready=false`. Следующий цикл: **1719 — Admin Observability и Reports**.

## История проекта

- циклы: `docs/cycles/`;
- чаты: `docs/chats/`;
- immutable reports: `reports/numbered/`;
- active SSOT: `docs/SSOT/`;
- current operational ledgers: `reports/current/`.

## Начало работы

1. `START_HERE.md`.
2. `docs/SSOT/SSOT_INDEX.md`.
3. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. `docs/NORM/ARCHITECTURAL_LOCKS.md`.
5. `docs/cycles/WORK_CYCLES_1701-1800.md`.
