# ТЕКУЩИЙ OWNER-КАНОН ЛОКАЛИЗАЦИИ — цикл 1829

- Приложение имеет ровно `16` полноценных runtime-языков: `ru, en, uk, de, fr, es, it, tr, pl, da, hi, id, sw, pt, ko, ja`.
- FAQ приложения и FAQ SSOT имеют тот же обязательный физический набор `16/16`; каждый язык содержит `20` разделов / `250` Q&A.
- Language keyset, placeholders, selectors и registries обязаны охватывать все `16` языков.
- Для поддерживаемого языка отсутствие FAQ catalog является release defect; FAQ fallback не заменяет физический каталог.
- `TODO/FIXME/TBD` unfinished-marker контроль относится только к shipping source code. Документы и локализованный FAQ исключены из этого code scope; естественное Portuguese слово `todo` разрешено.
- Старые упоминания `13/14` языков в исторических разделах сохраняются только как evidence прошлого состояния и не переопределяют текущий канон `16/16`.

<!-- Активный канон EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Якорь identity: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

Для провайдера TON канонический идентификатор — `ton_wallet_id`; его значение
равно адресу TON-кошелька. Имя `ton_address` запрещено как псевдоним
идентификатора провайдера; универсальная колонка `provider_subject` для
`provider=ton` хранит значение `ton_wallet_id`.

# Участие в разработке EFHC

## Перед изменениями

1. Прочитать `docs/SSOT/SSOT_INDEX.md`.
2. Проверить `docs/NORM/ARCHITECTURAL_LOCKS.md`.
3. Использовать только текущие документы из
   `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. Не использовать внешний `ARTIFACTS_HISTORY` ZIP как current contract и не воссоздавать `docs/history/`.

## Identity

- Business runtime принимает и возвращает `global_id`.
- Внешний `global_id` всегда string `^[0-9]{10}$`.
- `tg_id` допустим только на реальной Telegram/provider boundary.
- Запрещены `tg_provider_id`, `telegram_provider_id`, owner FK на `tg_id`
  и numeric coercion `global_id`.

## Schema и проверки

- Pre-release schema меняется только в migration `0001`.
- Нельзя повышать baseline или расширять allowlist ради прохождения CI.
- Полный локальный CI и полный pytest не выполняются вместо GitHub CI.
- Фактическая история цикла фиксируется в `docs/cycles/` и `reports/numbered/`; superseded bytes при необходимости хранятся только во внешнем `ARTIFACTS_HISTORY` ZIP.
