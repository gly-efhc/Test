<!-- Активный канон EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Якорь identity: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

Для провайдера TON канонический идентификатор — `ton_wallet_id`; его значение
равно адресу TON-кошелька. Имя `ton_address` запрещено как псевдоним
идентификатора провайдера; универсальная колонка `provider_subject` для
`provider=ton` хранит значение `ton_wallet_id`.

# Участие в разработке EFHC

## Перед изменениями

1. Прочитать `docs/SSOT/SSOT_INDEX.md`.
2. Проверить `docs/NORM/ARCHITECTURAL_LOCKS.md`.
3. Использовать только текущие документы из
   `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`.
4. Не использовать содержимое `docs/history/` как current contract.

## Identity

- Business runtime принимает и возвращает `global_id`.
- Внешний `global_id` всегда string `^[0-9]{10}$`.
- `tg_id` допустим только на реальной Telegram/provider boundary.
- Запрещены `tg_provider_id`, `telegram_provider_id`, owner FK на `tg_id`
  и numeric coercion `global_id`.

## Schema и проверки

- Pre-release schema меняется только в migration `0001`.
- Нельзя повышать baseline или расширять allowlist ради прохождения CI.
- Полный локальный CI и полный pytest не выполняются вместо GitHub CI.
- Исторический документ после закрытия цикла переносится в `docs/history/`
  с manifest и SHA-256.
