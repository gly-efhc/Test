<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Contributing

Этот файл является краткой точкой входа для разработчика.

## Что читать в первую очередь

1. `docs/AI/AI_OPERATOR_RULES_EFHC.md`
2. `docs/SSOT/SSOT_INDEX.md`
3. `docs/NORM/ARCHITECTURAL_LOCKS.md`
4. `docs/cycles/WORK_CYCLES.md`
5. `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`

## Как работать с проектом

- Работать только по последнему HEAD-архиву.
- Не выдумывать факты и не объявлять фиксы без подтверждения.
- Все реальные изменения фиксировать в `docs/cycles/WORK_CYCLES.md`, реестрах и отчётах.
- Не ломать канон EFHC, SSOT, bank canon, withdraw canon, tg_id only и migration canon `0001 only`.
- Audit-документы и лог-аудиты живут в `docs/audits/`.
- Папка `artifacts/` является корзиной архива для удалённых и вырезанных элементов после согласования пользователя.

## Перед изменениями

- Открыть HEAD-архив.
- Прочитать AI/SSOT/registry слой.
- Проверить свежие логи, если они есть.
- Сверить код, документы и циклы.

## Перед релизом

- Обновить `docs/cycles/WORK_CYCLES.md`.
- Обновить обязательные реестры.
- Собрать FLAT ZIP без мусора.
- Дать честный отчёт по 10 пунктам.
