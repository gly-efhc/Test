# CURRENT HEAD — v174.47 / цикл 1793 CI qualification repair

- Exact GitHub CI `87288059313` проверил `v174.46` SHA-256 `fda32d417d20663ff5c19d9b414d6d6eefe3de06514a13525f661e499b4e8f32`, checkout `64c11a5dba3a081b9aeef4ec59158435e8a10cdb`. Все recorded gates GREEN, кроме pytest: `1 failed / 1727 passed / 22 skipped / 1 warning`.
- Единственная подтверждённая причина RED — устаревший baseline русскоязычной инженерной политики для `CONTINUE_IN_NEW_CHAT.md`: файл содержит `53` неизменяемых исторических англоязычных snapshot-фрагмента при разрешённом historical count `36`.
- Исторические handoff-фрагменты не переписываются. Baseline повышен строго `36 → 53`; любой следующий новый англоязычный prose-фрагмент остаётся fail-closed нарушением.
- Runtime/backend/frontend/DB не менялись. Frozen `0001`, отсутствие `0002+`, FAQ standalone authority, FRONTEND_v146 и deep-remediation contracts сохранены.
- Immutable report `02365`; следующий `02366`; canonical handoff `EFHC_Bot_v174_47.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.46 / цикл 1793 CI qualification repair

- Exact GitHub CI `87285361835` проверил `v174.45` SHA-256 `3cc9d0a7a3f274b2eaedb89a85a081587a4aad6571a452ead758de24ff8bc75e`, checkout `b527ac44347a7714c3ac927bed6826a4c284218f`.
- GREEN: Development HEAD SHA, Flake8 critical/full, Mypy, Bandit, compileall, PostgreSQL/Alembic, npm install и frontend build. RED: Ruff `1×I001`, pytest `17 failed / 1711 passed / 22 skipped / 1 warning`.
- Подтверждённый runtime defect: Panels после canonical financial SSOT migration всё ещё использовал удалённый `transactions_service.SpendBreakdown`; теперь `SpendBreakdown/split_bonus_then_main` импортируются напрямую из `app.standards.finance_rules`.
- Qualification repair: financial SSOT guard проверяет AST contract, Shop guard требует безопасный `CAST(:extra AS jsonb)`, Ruff import-order исправлен.
- Deep backend remediation не откатывается; frozen `0001`, отсутствие `0002+`, FAQ standalone authority и FRONTEND_v146 сохраняются.
- Immutable report `02364`; следующий `02365`; canonical handoff `EFHC_Bot_v174_46.zip`.
- Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# SECURITY CURRENT — v174.45 / цикл 1793 CI qualification repair

- Exact CI `87278222904` подтвердил, что security/lifecycle remediation `v174.44` дошла до execution gates; RED security-related pytest были stale architecture expectations, а не доказательством отсутствия middleware.
- Canonical `app.main:app` вызывает единый `install_security_middlewares(app)`; guards теперь проверяют installer, а не требуют дублировать `MonetaryRateLimitMiddleware` напрямую в `main.py`.
- Missing `get_session_factory` в auth/provider dependency исправлен восстановлением canonical session-factory import; auth semantics не ослаблены.
- Frozen schema, Telegram/TonConnect guards, financial P0 и FRONTEND_v146 не меняются. Следующий verifier — exact-head GitHub CI `v174.45`.

> Исторические SECURITY snapshots ниже не переопределяют этот блок.

# SECURITY CURRENT — v174.44 / цикл 1792 deep backend remediation

- Startup prod/stage fail-closed: existing system locks + DB preflight через canonical lifespan.
- Monetary security middlewares устанавливаются единым canonical installer; idempotency middleware присутствует на `app.main:app`.
- Scheduler cancellation propagates; unexpected failure не достигает commit.
- Watcher DB infrastructure error не продолжает SQL через потенциально aborted transaction; P0 financial order сохранён.
- Shop external order + PaymentIntent принадлежат одной root transaction; CRUD expected conflict изолируется savepoint.
- Frozen schema/FAQ/frontend owner locks не изменены. Candidate требует fresh exact-head GitHub CI.

# SECURITY CURRENT — v174.43 / цикл 1792

- CI `87220054352` qualification repair preserves prior webhook/watcher/security hardening.
- Admin broad 5xx handlers keep stable redacted error codes and now explicitly suppress exception chaining in generated HTTP exceptions (`from None`) after server-side `logger.exception`.
- TonConnect production missing-domain failure preserves stable canonical reason `CONFIGURED_DOMAIN_REQUIRED`; request Host remains non-authoritative.
- No auth/RBAC/schema/financial relaxation was introduced.

# SECURITY CURRENT — v174.42 / цикл 1791 corrective re-audit

- Telegram authenticated webhook dedupe теперь atomic с business DB processing: marker не становится permanent до успешного root commit; dedupe storage failure fail-closed; cancellation/error rollback + re-raise.
- 17 подтверждённых broad-exception 5xx disclosure paths заменены stable public codes с internal logging.
- Canonical FastAPI runtime применяет configured `TrustedHostMiddleware`; TonConnect wallet proof production domain config-first и не доверяет request Host как authority.
- Idempotency raw boundary: `<=128`, control chars forbidden, validation до SHA-256.
- Frozen schema и financial formulas данным security repair не менялись. Fresh exact-head CI обязателен.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
# Политика безопасности EFHC — active production contract

Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.
Admin NFT authority: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.

## 1. Каноническая identity/session boundary

- Владельцем privileged и financial account является только canonical `global_id`.
- Физический user key — `users.global_id`; provider subjects не дублируются в `users` и разрешаются через `user_identities`, а TON ownership — через active verified `wallet_bindings`.
- Административные и финансовые действия требуют проверенной server-side auth session; client-controlled Telegram headers, `X-Admin-Id`, provider subject IDs и общий `SECRET_KEY` не являются authorization bypass.
- Audit actor — только `actor_global_id`; provider subjects остаются identity/delivery metadata и не становятся business owner identifiers.
- Raw provider subjects, bearer credentials, wallet proofs, private keys и seed material запрещено записывать в application logs и diagnostic artifacts.

## 2. Резерв SuperAdmin

`global_id=1313131313` зарезервирован для SuperAdmin account и не выдаётся обычной регистрацией. Сам резерв не является credential и не обходит обычный Admin gate.

## 3. Два канонических источника Admin access

После валидной server-side session EFHC намеренно поддерживает **два независимых Admin credential**:

1. **Admin list / RBAC** — active `efhc_admin.admin_whitelist.global_id` + явная active RBAC role.
2. **Special Admin NFT** — любая active verified TON identity того же session `global_id` владеет конкретным NFT item из `TON_ADMIN_NFT_IDS`, item принадлежит canonical `TON_NFT_COLLECTION`, а derived `efhc_admin.admin_nft_whitelist` active и fresh в пределах `NFT_CACHE_TTL_SECONDS`.

Обычный VIP NFT **не даёт Admin privileges**. Admin credential является только специально настроенный Admin NFT item. Admin NFT даёт обычный Admin/Moderator-equivalent access согласно `ADMIN_NFT_ACCESS_CANON`, но не создаёт отдельный SuperAdmin status.

Если `TON_ADMIN_NFT_IDS` пуст, state stale/unverified или NFT больше не принадлежит пользователю, Admin NFT path обязан fail closed. При передаче Admin NFT derived access переходит новому владельцу после canonical refresh; freshness boundary не позволяет использовать просроченный derived state.

## 4. Browser Shop handoff bearer

- Новые Browser Shop handoff URLs обязаны помещать short-lived handoff credential во **fragment URL**, а не в query string. Fragment не отправляется HTTP-серверу, reverse proxy и link-preview fetch.
- Browser Shop frontend переносит credential в `sessionStorage`, удаляет его из URL/history и использует header `X-EFHC-Handoff` для последующих read API requests.
- Query parameter `token=` сохраняется временно только как backward-compatibility input для уже выданных/старых clients. Новый server-generated URL и текущий frontend не должны генерировать query bearer URL.
- Telegram message с handoff link обязан использовать `disable_web_page_preview=True`.
- Текущий handoff JWT остаётся short-lived и reusable до `exp`. Полный single-use exchange требует отдельного изменения auth semantics. Его можно проектировать поверх уже существующего `auth_challenges` storage без автоматического добавления новой таблицы, но только после отдельного owner review.

## 5. TON wallet proof и connect idempotency

- Явная пользовательская отвязка canonical `wallet_bindings` физически освобождает TON address для новой подтверждённой привязки; compatibility-имя backend helper не означает soft ownership.
- Anti-replay marker подтверждённого TonConnect proof действует `24h`. Истёкший marker не является вечным ownership lock и удаляется только при повторной проверке того же hash.
- `/wallets/connect` idempotency действует `7d`. Replay возвращает прежний результат только пока соответствующий binding существует, active и proof-verified; stale idempotency не может восстановить удалённое/отозванное владение.
- Снятие VIP после исчезновения последнего допустимого wallet source выполняется через тот же BASE/VIP energy checkpoint, а не отдельным прямым `is_vip` UPDATE.

## 6. Health и diagnostics

- Public liveness/readiness endpoints отдают только coarse health state и HTTP status.
- `/api/health/db` публично отдаёт только safe DB/schema summary (`ok` + stable status code), без schema/table names, missing-column lists и raw exceptions.
- `/api/health/db-schema` остаётся публичной DevOps-проверкой, но отдаёт только coarse `ok/status` и HTTP 503 при mismatch/unavailable; schema/table/missing-column details остаются только в server logs.
- Detailed `/api/health/runtime` требует либо валидную Admin session (включая canonical Admin NFT path), либо валидный `X-Metrics-Token`.
- Health handlers никогда не возвращают `str(exc)`/raw SQL-driver errors клиенту. Полный exception остаётся только в server logs.
- `/meta/health_db` остаётся coarse PostgreSQL readiness probe и возвращает HTTP 503 при database failure.

## 7. Безопасность изменений и удалений

Публичную, compatibility- или security-boundary нельзя удалять только потому, что поиск по репозиторию не нашёл вызывающий код. Перед удалением владелец должен получить понятное объяснение: что именно удаляется, для чего оно существует, чем заменено и какой риск совместимости остаётся. Удаление выполняется только после явного подтверждения владельца.


## External financial time barrier

Новое первичное зачисление из внешнего financial event разрешено только после двойной server-side проверки времени: trusted operation time из проверенного внешнего источника и сохранённый server first-seen. Строгая граница — 180 суток; `age >= 180 days` приводит к `EXPIRED / NO CREDIT` до replay/idempotency и до BANK/user mutation. Клиентское время не является authority. Reprocess не может подменять trusted time текущей датой или временем повторного наблюдения.
