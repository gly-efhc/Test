<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
# Политика безопасности EFHC — active production contract

Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.
Admin NFT authority: `docs/SSOT/ADMIN_NFT_ACCESS_CANON.md`.

## 1. Каноническая identity/session boundary

- Владельцем privileged и financial account является только canonical `global_id`.
- Физический user key — `users.global_id`; provider subjects не дублируются в `users` и разрешаются через `user_identities`, а TON ownership — через active verified `wallet_bindings`.
- Административные и финансовые действия требуют проверенной server-side auth session; client-controlled Telegram headers, `X-Admin-Id`, provider subject IDs и общий `SECRET_KEY` не являются authorization bypass.
- Audit actor — только `actor_global_id`; provider subjects остаются identity/delivery metadata и не становятся business owner identifiers.
- Raw provider subjects, bearer credentials, wallet proofs, private keys и seed material запрещено записывать в application logs и diagnostic artifacts.

## 2. Резерв SuperAdmin

`global_id=1313131313` зарезервирован для SuperAdmin account и не выдаётся обычной регистрацией. Сам резерв не является credential и не обходит обычный Admin gate.

## 3. Два канонических источника Admin access

После валидной server-side session EFHC намеренно поддерживает **два независимых Admin credential**:

1. **Admin list / RBAC** — active `efhc_admin.admin_whitelist.global_id` + явная active RBAC role.
2. **Special Admin NFT** — любая active verified TON identity того же session `global_id` владеет конкретным NFT item из `TON_ADMIN_NFT_IDS`, item принадлежит canonical `TON_NFT_COLLECTION`, а derived `efhc_admin.admin_nft_whitelist` active и fresh в пределах `NFT_CACHE_TTL_SECONDS`.

Обычный VIP NFT **не даёт Admin privileges**. Admin credential является только специально настроенный Admin NFT item. Admin NFT даёт обычный Admin/Moderator-equivalent access согласно `ADMIN_NFT_ACCESS_CANON`, но не создаёт отдельный SuperAdmin status.

Если `TON_ADMIN_NFT_IDS` пуст, state stale/unverified или NFT больше не принадлежит пользователю, Admin NFT path обязан fail closed. При передаче Admin NFT derived access переходит новому владельцу после canonical refresh; freshness boundary не позволяет использовать просроченный derived state.

## 4. Browser Shop handoff bearer

- Новые Browser Shop handoff URLs обязаны помещать short-lived handoff credential во **fragment URL**, а не в query string. Fragment не отправляется HTTP-серверу, reverse proxy и link-preview fetch.
- Browser Shop frontend переносит credential в `sessionStorage`, удаляет его из URL/history и использует header `X-EFHC-Handoff` для последующих read API requests.
- Query parameter `token=` сохраняется временно только как backward-compatibility input для уже выданных/старых clients. Новый server-generated URL и текущий frontend не должны генерировать query bearer URL.
- Telegram message с handoff link обязан использовать `disable_web_page_preview=True`.
- Текущий handoff JWT остаётся short-lived и reusable до `exp`. Полный single-use exchange требует отдельного изменения auth semantics. Его можно проектировать поверх уже существующего `auth_challenges` storage без автоматического добавления новой таблицы, но только после отдельного owner review.

## 5. TON wallet proof и connect idempotency

- Явная пользовательская отвязка canonical `wallet_bindings` физически освобождает TON address для новой подтверждённой привязки; compatibility-имя backend helper не означает soft ownership.
- Anti-replay marker подтверждённого TonConnect proof действует `24h`. Истёкший marker не является вечным ownership lock и удаляется только при повторной проверке того же hash.
- `/wallets/connect` idempotency действует `7d`. Replay возвращает прежний результат только пока соответствующий binding существует, active и proof-verified; stale idempotency не может восстановить удалённое/отозванное владение.
- Снятие VIP после исчезновения последнего допустимого wallet source выполняется через тот же BASE/VIP energy checkpoint, а не отдельным прямым `is_vip` UPDATE.

## 6. Health и diagnostics

- Public liveness/readiness endpoints отдают только coarse health state и HTTP status.
- `/api/health/db` публично отдаёт только safe DB/schema summary (`ok` + stable status code), без schema/table names, missing-column lists и raw exceptions.
- `/api/health/db-schema` остаётся публичной DevOps-проверкой, но отдаёт только coarse `ok/status` и HTTP 503 при mismatch/unavailable; schema/table/missing-column details остаются только в server logs.
- Detailed `/api/health/runtime` требует либо валидную Admin session (включая canonical Admin NFT path), либо валидный `X-Metrics-Token`.
- Health handlers никогда не возвращают `str(exc)`/raw SQL-driver errors клиенту. Полный exception остаётся только в server logs.
- `/meta/health_db` остаётся coarse PostgreSQL readiness probe и возвращает HTTP 503 при database failure.

## 7. Безопасность изменений и удалений

Публичную, compatibility- или security-boundary нельзя удалять только потому, что поиск по репозиторию не нашёл вызывающий код. Перед удалением владелец должен получить понятное объяснение: что именно удаляется, для чего оно существует, чем заменено и какой риск совместимости остаётся. Удаление выполняется только после явного подтверждения владельца.


## External financial time barrier

Новое первичное зачисление из внешнего financial event разрешено только после двойной server-side проверки времени: trusted operation time из проверенного внешнего источника и сохранённый server first-seen. Строгая граница — 180 суток; `age >= 180 days` приводит к `EXPIRED / NO CREDIT` до replay/idempotency и до BANK/user mutation. Клиентское время не является authority. Reprocess не может подменять trusted time текущей датой или временем повторного наблюдения.
