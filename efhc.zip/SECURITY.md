<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## SuperAdmin reservation / admin access lock v173.27

`global_id=1313131313` зарезервирован для SuperAdmin и не выдаётся обычной
регистрацией. Резерв сам по себе не является credential: административный доступ
требует server-side session, active `admin_whitelist.global_id` и explicit RBAC
role. Provider subject и NFT/VIP не предоставляют admin privileges.

## Corrective boundary v172.26

Fresh CI `83093436890` доказал syntax defect telemetry view migration
`0009`. Исправление меняет только SQL composition telemetry view и
подтверждённые static findings. Dual-write security semantics, monetary
data и legacy authority не ослабляются. Цикл `1625` не начат.

## Identity security lock v173.24

- Privileged/session account owner: только `global_id`.
- Audit actor: только `actor_global_id`; provider subjects не являются audit owner.
- Новые internal signed handoff claims не содержат `tg_id`/другие provider subjects.
- Raw provider subjects не записываются в application logs; provider delivery остаётся отдельной boundary.

## Admin identity reservation

`global_id=1313131313` зарезервирован для SuperAdmin account. Резервирование
идентификатора не заменяет RBAC: доступ требует active whitelist и явной роли.
NFT/VIP не является admin credential.
