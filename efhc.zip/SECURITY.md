<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_TON_PROVIDER_SUBJECT_CANON_V173_23 -->
TON provider subject: `ton_wallet_id` = адрес TON-кошелька. `ton_address` не
является provider-subject alias; generic storage `provider_subject` для
`provider=ton` содержит значение `ton_wallet_id`.

# Текущий статус v172.52 — циклы 1636–1637

Fresh GitHub CI `83405061075` проверил exact
`EFHC_Bot_v172_51.zip` размером `12650102` байта. PostgreSQL,
единая migration `0001`, production frontend build и все `102`
route-backed Chromium checks прошли. Красный итог вызвали только
`13` статических/документных pytest guards, один Ruff import-order
finding и один Mypy return-type finding. Runtime, schema, auth и
financial regression не подтверждены.

Цикл `1636` квалифицирован реальным PostgreSQL-прогоном ядра.
В `v172.52` выполнен цикл `1637`:

- Telegram Bot `/start` создаёт новый account только через
  `AccountRegistrationService`;
- raw SQL вставка `users` из referral onboarding удалена;
- `User`, immutable `ReferralLink` и Telegram `UserIdentity`
  создаются атомарно в одной транзакции;
- invalid/missing referral отклоняется до создания account;
- существующий пользователь, включая permanent `0 user`, не может
  получить позднюю referral-привязку;
- WebApp и TON callers не переключались и остаются scope цикла `1639`;
- migration, schema, экономика и шесть нижних маршрутов не менялись.

Visual gate exact `v172.51` прошёл `102/102`, но переданный архив
`ci_artifacts (3).zip` не содержит PNG. Поэтому пользовательская
visual acceptance follow-up цикла `1635` остаётся открытой.

```text
CURRENT_HEAD_V172_52
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_IMPLEMENTED
CYCLE_1637_EXACT_HEAD_CI_REQUIRED
CYCLE_1638_NOT_STARTED
CYCLE_1639_NOT_STARTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---
# Актуализация qualification boundary — v172.39

v172.39 исправляет переносимость ZIP: все не-ASCII имена обязаны иметь
UTF-8-флаг, mojibake блокируется до упаковки и после неё. Изменений в
backend authorization, Bearer session, TON Proof и Telegram HMAC нет.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Cycle `1631` не начат; Alembic head `0012`.

---

# Актуализация qualification boundary — v172.38

Admin visual proof в v172.38 активируется только в автоматизированном
браузере на localhost и не изменяет backend authorization. Telegram
allowlist, Bearer session, TON Proof, Telegram HMAC и no-auto-merge
остаются неизменными. Universal CI не менялся.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Cycle `1631` не начат; Alembic head `0012`.

---

# Актуализация qualification boundary — v172.37

Client admin guard остаётся только UX-слоем; backend authorization не
изменён. Corrective v172.37 исключает преждевременный redirect до
завершения чтения Telegram identity. Bearer session, Telegram HMAC,
TON Proof, raw-initData prohibition и financial boundaries не менялись.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.36

Chromium CI доказал реальный CSP defect: `_document.tsx` подключает
`https://telegram.org/js/telegram-web-app.js`, а `script-src` не разрешал
его origin. CSP дополнен только `https://telegram.org`; остальные
ограничения сохранены. Raw Telegram `initData` по-прежнему запрещён как
business API fallback, Bearer/cross-provider proof остаётся fail-closed.
Physical rename цикла `1631` не начат.

---

# Актуализация qualification boundary — v172.35

Raw Telegram `initData` остаётся запрещённым business-auth fallback.
Real Chromium proof v172.34 завершился fail-closed, поэтому physical
rename не разрешён. v172.35 усиливает только доказательность: ожидание
Bearer `/api/auth/session` request и точный JSON failures. Canonical CI
обновлён по прямой команде без ослабления static/security gates.

---

# Актуализация qualification boundary — v172.34

Fresh exact-head CI v172.33 не закрыл цикл `1630`: PostgreSQL/API
negative contract получил wrong DB input profile, а Chromium proof был
пропущен. Corrective v172.34 исправляет только evidence/test harness,
stale contracts и Ruff. Production ownership, financial semantics,
migrations и CI workflows не меняются. Цикл `1631` не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация cross-provider session boundary — v172.33

Current HEAD: `EFHC_Bot_v172_33.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin business API требуют server-side Bearer
session. Raw Telegram `initData` допускается только как credential для
явного `/auth/telegram/session`, а не как business-auth fallback.
Canonical owner остаётся `global_id`; internal legacy `tg_id` selector
до `1631` разрешён только после session → global_id resolution.
Financial write semantics, precision, idempotency и formulas не менялись.
Цикл `1631` не начат. SSOT имеет приоритет при конфликте канона.

---

# Актуализация session-first ownership — v172.32

Current HEAD: `EFHC_Bot_v172_32.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin API используют server-side Bearer
session как primary transport и canonical `global_id` как owner.
Legacy Telegram transport остаётся измеряемой compatibility-веткой.
Frontend owner cache использует `GlobalId`. Financial write semantics,
precision, idempotency и formulas не менялись. Cycle `1630` не начат.
SSOT имеет приоритет над техническими заданиями при конфликте канона.

---

# Актуализация identity ownership — v172.31

Current HEAD: `EFHC_Bot_v172_30.zip`. Alembic head `0011`. Financial read switch использует `global_id`; legacy writes, dual-write, precision, idempotency и formulas неизменны. Cycle `1628` не начат. SSOT имеет приоритет над техническими заданиями при конфликте текущего канона.

---

# Security boundary v172.29

Financial read switch запрещён. Corrective scope не меняет balances,
amounts, precision, idempotency, owner semantics или migration `0010`.
Новый exact-head CI обязан доказать `fallback/mismatch/orphan/ambiguous = 0`
и monetary discrepancy `0.00000000` до цикла `1627`.

---

# Security boundary v172.28

Cycle `1626` не переключает financial reads и не меняет денежные
значения. Read-only gate проверяет shadow ownership, точное денежное
расхождение, Numeric precision/scale и idempotency constraints. Любой
`fallback`, `mismatch`, `orphan` или `ambiguous` в financial scopes
завершает validation fail closed. `0011` отсутствует; `1627` не начат.

---

# Security boundary v172.27

`0010` не меняет authentication, cryptography или financial values.
Bearer `AuthContext.global_id` имеет приоритет для новых
non-financial reads; Telegram ID остаётся только legacy ingress.
Read switch разрешён лишь при нулевых fallback/mismatch/orphan/
ambiguous для non-financial scopes. Operator rollback возвращает
чтение на legacy без удаления shadow data.

---

# EFHC — активная security boundary

1. `global_id` — единственный account owner.
2. Физический FK target — `users.global_id`.
3. `users.user_id` отсутствует; вторая account-owner колонка запрещена.
4. Dual-write обязан fail closed при owner conflict/orphan.
5. Owner inference из memo/address/email/wallet запрещён.
6. Денежные значения, precision, payout и idempotency не меняются.
7. Canonical runtime ownership через `global_id` является authoritative.
8. Provider fallback не может подменять canonical owner; новые switch-операции требуют отдельной квалификации.
9. GitHub CI workflow не ослабляется и не изменяется.

## Corrective boundary v172.26

Fresh CI `83093436890` доказал syntax defect telemetry view migration
`0009`. Исправление меняет только SQL composition telemetry view и
подтверждённые static findings. Dual-write security semantics, monetary
data и legacy authority не ослабляются. Цикл `1625` не начат.
