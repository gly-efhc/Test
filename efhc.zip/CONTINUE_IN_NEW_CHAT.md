<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.10 — продолжение работы

Статус: **CURRENT HANDOFF / EXACT_HEAD_CI_REQUIRED**

- Development: `EFHC_Bot_v173_10.zip`.
- Release: `EFHC_Bot_v173_10_RELEASE.zip`.
- Matrix: `EFHC_Bot_v173_10_MATRIX_TECHNICAL.zip`.
- Завершённый цикл: `1690`.
- Следующий цикл определяется новым утверждённым планом пользователя.
- Последний входной CI evidence: run `31122027818`, commit
  `e74ed101de1612fb6ec45ce74a302a94432a7095`.

## Канон identity

`global_id` — единственный внутренний account/business owner.
`tg_id` — только Telegram provider subject, authentication ingress или
Telegram delivery metadata. Фиктивная пара `global_id = tg_id` запрещена.

## Результат цикла 1690

- выполнен полный аудит активного `tests/`;
- исторические tests перенесены в `АРТЕФАКТЫ/Тесты/` с SHA-256;
- version/cycle/CI test names заменены тематическими именами;
- постоянные экономические guards объединены;
- E2E evidence вынесен из репозитория в `EFHC_TEST_ARTIFACT_DIR`;
- активные fixtures и service calls используют `global_id`;
- `tg_id` остаётся только в точечных provider-boundary тестах;
- добавлен `check_active_test_surface.py`;
- полный pytest локально не выполнялся.

Перед продолжением использовать только фактический v173.10 и новый
exact-head GitHub CI.
