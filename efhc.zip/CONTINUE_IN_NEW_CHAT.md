# EFHC Bot v173.01 — цикл 1684

Архивы:

- `EFHC_Bot_v173_01.zip`;
- `EFHC_Bot_v173_01_RELEASE.zip`;
- `EFHC_Bot_v173_01_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_01.zip`.

Цикл 1684 исправляет все ошибки GitHub CI v173.00 и переводит
transactions, ledger, balances, wallet ownership и panel activation
на canonical `global_id`. Provider `tg_id` остаётся только на
Telegram/TonConnect границе и в historical read-through.

Принудительный переход тестов реализован семантически. AST-guard
запрещает передачу `tg_id` в business services и требует явный
`global_id`. Telegram auth, initData, webhook, Bot API, membership,
TonConnect proof, physical provider fields и historical evidence
сохраняются и регистрируются построчно.

Полная матрица находится в `reports/generated/`. Actionable/review
остаток равен `2019`. Business-owner `tg_id` ещё не равен
нулю, поэтому окончательная миграция не закрыта.

Канон цикла 1632 и единая pre-release migration
`0001_initial_release_schema.py` сохраняются. Новую `0002` не создавать.

Следующий цикл: 1685. Осталось шесть циклов текущего плана: 1685–1690.

## Обязательный канон работы

При наличии полного ZIP пользовательских GitHub CI-логов запрещены
глупые, бессмысленные и дублирующие полные локальные CI, полный pytest
и повтор уже зелёных этапов. Выполняются короткие точечные проверки,
исправляется первый causal failure и все независимые причины.
Полную квалификацию выполняет следующий exact-head GitHub CI пользователя.

До exact-head CI v173.01 допустим только статус
`EXACT_HEAD_CI_REQUIRED`.
