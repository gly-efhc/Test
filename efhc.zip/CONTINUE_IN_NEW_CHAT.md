<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.36 — продолжение работы

Статус: **CURRENT HANDOFF / CYCLE 1711 CLOSED / CYCLE 1712 NEXT**

- Development: `EFHC_Bot_v173_36.zip`.
- Release: `EFHC_Bot_v173_36_RELEASE.zip`.
- Matrix: `EFHC_Bot_v173_36_MATRIX_TECHNICAL.zip`.
- Завершённый цикл: `1711 — Exact-head CI burn-down`.
- Следующий цикл: `1712 — Qualification milestone`.
- Active plan: `docs/PLANS/WORK_PLAN_1693-1709.md` emergency extension through 1714.

## External proof

GitHub CI `84921131844` проверил byte-exact `v173.35`:
- checkout SHA `ffdc369b3eaaf65eacbac48f31e7e7743458434e`;
- `efhc.zip` size `11846393` bytes;
- Git blob SHA-1 `9d729596849cd9c80eb6480acc92c04881fe7419` совпадает с локальным `v173.35`;
- все canonical gates exit=0;
- pytest `1498 passed / 22 skipped / 1 warning`;
- frontend production build PASS;
- Alembic/PostgreSQL PASS.

В 1711 подтверждённых ошибок не было, production/runtime/schema/economy/admin code
не менялся. `v173.36` — status/version/package continuation после зелёного `v173.35`;
его собственные байты требуют exact-head CI перед отдельным qualification claim.

## Active canon

- `global_id` — единственный business/account/admin/audit owner.
- BANK ledger identity: `system_entity=BANK_EFHC`, `global_id=NULL`, `tg_id=NULL`.
- Admin list: `admin_whitelist.global_id + explicit RBAC role`.
- Admin NFT: exact NFT-item address из `TON_ADMIN_NFT_IDS`, authority следует за
  фактическим владельцем NFT через штатный NFT/VIP checker.
- Economy: все денежные движения `BANK_EFHC ↔ USER` по `docs/SSOT/ECONOMY_CANON.md`.
- Alembic head: только `0001_initial_release_schema.py`.
