# Продолжение EFHC после v172.65

## Единственный HEAD

`EFHC_Bot_v172_65.zip`

## Что выполнено

- глобально проаудированы все `tg_id`;
- 158 runtime-файлов массово переведены на `global_id`;
- введён временный `global_owner_alias.py`;
- provider fact переименован в `telegram_provider_id`;
- business runtime debt вне allowlist равен нулю;
- backend компилируется;
- функциональные тесты намеренно не запускались.

## Следующая работа

1. Запустить exact v172.65 main CI.
2. Исправить все PostgreSQL, pytest, Ruff, Flake8, Mypy и Bandit ошибки.
3. Подтвердить Telegram/TON-only equivalence, idempotency и concurrency.
4. После полного PASS удалить alias-harness, ORM synonyms, deprecated
   routes и historical compatibility tails.

## Запрещено

- выполнять production cutover без отдельной команды;
- возвращать `tg_id` в business ownership;
- менять public visual, Admin UX, screenshot workflow или canonical CI;
- объявлять runtime PASS до fresh exact-head CI.
