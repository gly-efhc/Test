<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.09 — продолжение работы

Статус: **CURRENT HANDOFF / EXACT_HEAD_CI_REQUIRED**

## Текущая база

- Development: `EFHC_Bot_v173_09.zip`.
- Release: `EFHC_Bot_v173_09_RELEASE.zip`.
- Matrix: `EFHC_Bot_v173_09_MATRIX_TECHNICAL.zip`.
- Завершённый цикл: `1689`.
- Следующий цикл: `1690`.
- Предыдущий exact-head evidence: run `31122027818`, commit
  `e74ed101de1612fb6ec45ce74a302a94432a7095`.

## Действующий закон

`provider + subject → global_id → business runtime`.

`global_id` — string ровно из 10 ASCII-цифр и единственный внутренний
account/business owner. `tg_id` — только Telegram provider subject и
Telegram delivery recipient.

## Результат цикла 1689

- создано историческое хранилище `АРТЕФАКТЫ/`;
- старые audits, cycles, reports и legacy NORM/SSOT исключены из active tree;
- действующие identity-документы и названия переписаны под `global_id`;
- подготовлен полный manifest и список кандидатов на окончательное удаление;
- физическое удаление без утверждения пользователя не выполнялось.

## Обязательный канон работы по CI

Запрещены глупые, бессмысленные и дублирующие полные локальные прогоны.
Разрешены короткие точечные проверки конкретного исправления, machine
guards, compileall и test collection. Главный источник истины — следующий exact-head GitHub CI пользователя.
