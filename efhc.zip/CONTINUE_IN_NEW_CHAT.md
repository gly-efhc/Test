## Текущая рабочая блокировка — кандидат v173.50

- Завершён цикл 1725 — Admin VIP, Admin NFT и заявки на ручную выдачу VIP NFT.
- Supplied CI `85009844836` на `v173.49`: Ruff 2; pytest `4 failed / 1498 passed / 22 skipped`; frontend checksum failure; подтверждённые причины исправлены без локальных проверок.
- VIP больше не переключается вручную; используется единый NFT checker.
- `submit_manual_vip_nft_claim` не восстанавливать; заявка — исходный paid Shop NFT order.
- Новый Admin workflow: проверка VIP/NFT и очередь ручной выдачи NFT.
- Function floor: 299 symbols / 54 modules / 59 files / 134 paths / 139 operations.
- Следующий цикл: 1726 — Bonus Awards, Withdraw и Admin manual credits.

## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.

# ТЕКУЩИЙ HANDOFF — EFHC Bot v173.49 candidate

Завершённый цикл: **1724**. Следующий: **1725 — Admin NFT, VIP и manual claim**.

- Exact-head CI `85001150793` проверил `v173.48`: pytest `2 failed / 1500 passed / 22 skipped`; frontend prebuild остановился на checksum `ru`; Ruff, Mypy, Flake8, Bandit, compileall, Alembic/PostgreSQL и npm ci по предоставленным логам GREEN.
- Подтверждённые CI causes исправлены без расширения scope.
- `/admin/efhc-deposits` объединяет обзор, входящие операции, несопоставленные операции, безопасную повторную обработку, сверку за период и отдельно обозначенное аварийное действие.
- Business owner остаётся `global_id`; `parsed_tg_id` — только provider metadata.
- Произвольная ручная смена финансового статуса запрещена; `pending_manual` исключён из автоматических повторных попыток.
- Active canon: `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
# CONTINUE IN NEW CHAT — EFHC Bot v173.42

Current completed cycle: **1718**. Next: **1719**.

## Exact evidence

- supplied exact-head CI: `84954546920`;
- exact tested archive: `v173.41`;
- archive size: `12135299` bytes;
- green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build;
- failed gates: Mypy (`2`) и pytest (`17 failed / 1485 passed / 22 skipped`);
- confirmed causes patched in `v173.42`;
- `v173.42` ещё не получил exact-head GitHub CI.

## Function recovery plan

- active plan: `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `1719–1728`: десять волн исследования и согласования functions/routes;
- `1729`: итоговая decision matrix и только утверждённые изменения;
- `1730`: exact-head CI qualification/error burn-down;
- `1731`: backend/frontend audit handoff preparation.

## Critical locks

- GitHub CI пользователя — единственный application test/qualification contour; ассистент не запускает локальные tests, guards, lint/type/build/Alembic/CI checks.
- `global_id` остаётся единственным business/account/privileged/audit owner.
- BANK и Admin NFT canons неизменны.
- Отсутствие frontend/Python caller не разрешает удалять route/Admin/compatibility/operational surface.
- Удаление в 1719–1729 возможно только после полного Fail-Closed Delete proof и явного решения пользователя.
- Не объявлять `v173.42` PASS/production-ready до exact-head GitHub CI.


## Cycle 1720 current handoff

- Candidate HEAD: v173.44; next cycle 1721.
- Admin Tasks full editor implemented with fail-closed history preservation.
- Admin Ads provider registry/readiness connected separately; secrets remain server-side.
- `tasks_autorestart` is task-lock maintenance; TON time-based payment watcher is `check_ton_inbox/job_ton_watcher`.
- Status: PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED.
