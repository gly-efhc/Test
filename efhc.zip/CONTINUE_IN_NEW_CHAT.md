# EFHC Bot v173.05 — цикл 1686

Архивы:

- `EFHC_Bot_v173_05.zip`;
- `EFHC_Bot_v173_05_RELEASE.zip`;
- `EFHC_Bot_v173_05_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_05.zip`.

Цикл 1686 продолжает fix-forward переход глобальных business-owner
употреблений `tg_id` на canonical `global_id` и исправляет все причины,
подтверждённые exact-head GitHub CI v173.04.

GitHub CI v173.04 имел зелёные Ruff, Mypy, flake8, Bandit, compileall,
Alembic и frontend build. Упал только pytest: 3 ошибки, 3261 пройденный
и 28 пропущенных тестов.

Исправлены три причины CI:

1. Устранено превышение канонического лимита длины строки в
   `idempotency_compat.py`.
2. Handoff снова содержит точный обязательный запрет на глупые,
   бессмысленные и дублирующие проверки.
3. Подтверждение `shop_external` использует уже записанный canonical
   `global_id` заказа и больше не переводит корректный платёж в
   `pending_manual` из-за отсутствия legacy Telegram owner.

В scope цикла 1686 переведены panels, tasks и ads:

- panel ownership, archive, активация и energy generation используют
  `global_id`;
- удалены legacy panel routes с owner path `tg_id`;
- admin panels filter и DTO используют `global_id`;
- task status, bonus log, complete lock и submission ownership используют
  `global_id`;
- `task_submissions.tg_id` остаётся только nullable Telegram recipient
  metadata и не является owner;
- task frontend contracts публикуют `global_id`;
- ads business response использует `global_id`, а `tg_id` остаётся только
  в подписанном provider token и Telegram callback boundary;
- migration `0001` сохраняет стабильные номера dual-write функций и
  удаляет retired owner trigger `task_submissions.tg_id` без создания
  migration `0002`.

Полная матрица находится в `reports/generated/`. Business-owner
`tg_id = 0` ещё не доказан, поэтому миграция не закрыта.

Следующий цикл: 1687. Осталось четыре цикла текущего плана: 1687–1690.

## Сохранённый фундамент

Цикл 1632 закрепил физический owner-контур `users.global_id` и
единственную pre-release migration `0001_initial_release_schema.py`.
Новая migration `0002` не создаётся.

## Обязательный канон работы

Запрещено добавлять глупые, бессмысленные и дублирующие проверки,
которые не выявляют новую причинную ошибку и только замедляют CI.

При наличии полного ZIP пользовательских GitHub CI-логов запрещены
дублирующие полные локальные CI, полный pytest, test-shards и повтор уже
зелёных этапов. Запрещено ждать медленные общие тестовые прогоны или
задерживать выдачу архивов ради дополнительных проверок.

Исправляются первый causal failure и все независимые причины. Разрешены
только короткие точечные проверки конкретного исправления, `compileall`,
test collection и необходимые machine guards. Полную квалификацию
проводит следующий exact-head GitHub CI пользователя.

До exact-head CI v173.05 допустим только статус
`EXACT_HEAD_CI_REQUIRED`.
