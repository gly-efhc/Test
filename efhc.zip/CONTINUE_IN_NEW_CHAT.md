# EFHC Bot v173.03 — цикл 1685

Архивы:

- `EFHC_Bot_v173_03.zip`;
- `EFHC_Bot_v173_03_RELEASE.zip`;
- `EFHC_Bot_v173_03_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_03.zip`.

Цикл 1685 продолжает fix-forward переход глобальных business-owner
употреблений `tg_id` на canonical `global_id` и исправляет все причины,
подтверждённые exact-head GitHub CI v173.02.

Новый CI v173.02 больше не зависает: он завершился за 3 минуты 20 секунд.
Оставшиеся 40 pytest-падений, 1 Ruff и 6 Mypy ошибок были сведены к
нескольким общим разрывам и исправлены без возврата legacy business API:
referral→panels callback, Payment Intent owner contracts, wallet fixtures,
admin bank DTO, identity boundary, line-72, русскоязычная политика и
handoff contracts.

Referral schema, ORM, CRUD, services, routes, frontend и tests используют
обязательные `inviter_global_id`, `invitee_global_id` и `global_id` для
ownership. `inviter_tg_id`, `invitee_tg_id` и `tg_id` сохраняются только
как Telegram/provider metadata и historical read-through.

Принудительный переход тестов выполняется семантически. AST-guard
запрещает передачу `tg_id` в business services и требует явный
`global_id`. Текущий результат: 0 business-selector нарушений;
зарегистрировано 615 допустимых Telegram/provider/schema/historical
употреблений в тестах.

Полная матрица находится в `reports/generated/`:

- всего identity token-употреблений: `3318`;
- actionable/review остаток: `1760`;
- allowed/preserved: `1558`.

Business-owner `tg_id = 0` ещё не доказан, поэтому миграция не закрыта.

Следующий цикл: 1686. Осталось пять циклов текущего плана: 1686–1690.

## Сохранённый фундамент

Цикл 1632 закрепил физический owner-контур `users.global_id` и
единственную pre-release migration `0001_initial_release_schema.py`.
Новая migration `0002` не создаётся.

## Обязательный канон работы

При наличии полного ZIP пользовательских GitHub CI-логов запрещены
глупые, бессмысленные и дублирующие полные локальные CI, полный pytest
и повтор уже зелёных этапов. Исправляются первый causal failure и все
независимые причины. Выполняются короткие точечные проверки. Полную квалификацию
проводит следующий exact-head GitHub CI пользователя.

До exact-head CI v173.03 допустим только статус
`EXACT_HEAD_CI_REQUIRED`.
