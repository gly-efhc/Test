# Продолжение EFHC после v172.61

## Единственный code HEAD

- `EFHC_Bot_v172_61.zip` — development;
- `EFHC_Bot_v172_61_RELEASE.zip` — release;
- `EFHC_Bot_v172_61_MATRIX_TECHNICAL.zip` — evidence.

## Что сделано

- исправлены все подтверждённые ошибки CI exact v172.60;
- production dual-write triggers и safety checks не ослаблялись;
- Referral nullable SQL parameter типизирован;
- bank mirror отделён от пользовательского owner mapping;
- legacy fixtures приведены к реальному identity contract;
- Tasks и ad rewards переведены на canonical `global_id`;
- ranks snapshot и leaderboard поддерживают TON-only accounts;
- wallet read-side использует canonical owner;
- visual, Admin UX, screenshots и GitHub workflows не изменялись.

## Следующий обязательный порядок

1. Запустить unchanged main CI exact v172.61.
2. Исправлять все подтверждённые causal failures свежего run.
3. При PASS квалифицировать циклы 1643–1644.
4. Продолжить цикл 1645: callers, watcher и achievements.
5. Production flags не переключать до отдельного cutover gate.

```text
CURRENT_HEAD_V172_61
CYCLE_1643_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1644_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1643_1644_EXACT_HEAD_CI_REQUIRED
CYCLE_1645_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Продолжение EFHC после v172.60

## Единственный code HEAD

- `EFHC_Bot_v172_60.zip` — development;
- `EFHC_Bot_v172_60_RELEASE.zip` — release;
- `EFHC_Bot_v172_60_MATRIX_TECHNICAL.zip` — evidence.

## Что сделано

- исправлены все подтверждённые ошибки CI exact v172.59;
- обязательный migration-control singleton восстанавливается test fixture;
- production safety не ослаблена;
- Ruff/Mypy/Bandit и language-policy причины исправлены;
- возвращён post-lock idempotency read-through;
- referral rewards переведены на canonical `global_id`;
- старые referral rows поддержаны только при shadow `global_id IS NULL`;
- referral и exchange idempotency keys получили cutover-compatible выбор;
- visual/Admin/screenshot/main CI не изменялись.

## Следующий обязательный порядок

1. Запустить unchanged main CI exact v172.60.
2. Исправлять только подтверждённые causal failures из свежих логов.
3. При PASS квалифицировать циклы 1641–1643.
4. Продолжить цикл 1644: Tasks, Ranks, Wallets.
5. Production flags не переключать до отдельного cutover gate.

```text
CURRENT_HEAD_V172_60
CYCLE_1641_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1642_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1643_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1643_EXACT_HEAD_CI_REQUIRED
CYCLE_1644_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Продолжение EFHC после v172.59

## Единственный code HEAD

- `EFHC_Bot_v172_59.zip` — development;
- `EFHC_Bot_v172_59_RELEASE.zip` — release;
- `EFHC_Bot_v172_59_MATRIX_TECHNICAL.zip` — evidence.

## Что сделано

- сохранён visual baseline v172.58 без новых визуальных изменений;
- сохранён write-side foundation цикла 1640;
- transactions и ledger переведены на canonical `global_id`;
- Panels, Withdrawals и создание Payment Intents переведены на owner;
- TON-only account поддержан без обязательного `tg_id`;
- legacy selector остаётся временно до cleanup-циклов;
- production cutover flags не переключались.

## Следующий обязательный порядок

1. Запустить unchanged main CI exact v172.59.
2. Исправлять только первый causal failure из свежих логов.
3. После code-CI продолжить цикл 1643 по referral и idempotency.
4. Не смешивать identity, visual, Admin и screenshot contours.

```text
CURRENT_HEAD_V172_59
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
CYCLE_1643_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Продолжение EFHC после v172.58

## Единственный code HEAD

- `EFHC_Bot_v172_58.zip` — development;
- `EFHC_Bot_v172_58_RELEASE.zip` — release;
- `EFHC_Bot_v172_58_MATRIX_TECHNICAL.zip` — evidence.

## Что сделано

- сохранён весь backend/global_id scope v172.57;
- v172.50 закреплён как public visual baseline;
- полностью удалён отклонённый decorative layer v172.51;
- сохранены Back/profile/safe-area/QA improvements;
- утверждён план 1640–1665;
- добавлен guard против визуальной регрессии.

## Следующий обязательный порядок

1. exact-head main CI v172.58;
2. exact-head 102 screenshots и пользовательская acceptance;
3. qualification цикла 1640;
4. цикл 1641 — transactions/ledger canonical global_id;
5. не смешивать identity, visual и Admin contours.

```text
CURRENT_HEAD_V172_58
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Продолжение EFHC после v172.57

> Текущий верхний handoff. Исторический v172.56 handoff сохранён ниже.

## Единственный code HEAD

- `EFHC_Bot_v172_57.zip` — development archive;
- `EFHC_Bot_v172_57_RELEASE.zip` — release archive;
- `EFHC_Bot_v172_57_MATRIX_TECHNICAL.zip` — evidence archive.

Цикл 1640: write-side foundation.

## Что сделано

- main CI exact v172.56 был PASS;
- visual evidence отложено прямой директивой пользователя;
- добавлен locked write-side owner resolver;
- TON-only owner работает без обязательного `tg_id` на resolver boundary;
- завершён idempotency audit;
- schema и financial operations пока не переписаны.

## Следующий обязательный порядок

1. Fresh universal main CI exact v172.57.
2. При PASS закрыть цикл 1640.
3. Начать цикл 1641: transactions/ledger canonical `global_id` owner.
4. Не смешивать 1641 с cutover flags — production switch только цикл 1645.
5. После 1645 удалить aliases/tails в 1646–1647.
6. Полная qualification — циклы 1648–1650.

```text
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Продолжение EFHC после v172.56

Current HEAD: `EFHC_Bot_v172_56.zip`.

Связанные пакеты:

- `EFHC_Bot_v172_56_RELEASE.zip`;
- `EFHC_Bot_v172_56_MATRIX_TECHNICAL.zip`.

Fresh GitHub CI `83583696254` проверил exact `v172.55`: все static,
security, PostgreSQL/Alembic и production frontend gates прошли. Pytest дал
`3219 passed`, `28 skipped` и один failure только в cross-provider
qualification fixture. Chromium был корректно пропущен.

В `v172.56`:

- production-код цикла `1639` не меняется;
- после назначения TON-first account нового `tg_id` qualification fixture
  явно выполняет `flush()` до вставки `ReferralCode`;
- строгий FK и provider-neutral owner semantics сохранены;
- migration `0001`, schema, экономика, ledger и idempotency не меняются;
- schema-freeze и squash цикла `1632` сохраняются без изменений; активна только `0001_initial_release_schema.py`;
- цикл `1640` не начат.

Следующая работа:

1. выполнить exact-head GitHub CI `v172.56`;
2. подтвердить PostgreSQL cross-provider test без единственного failure;
3. получить Chromium `102/102` и отдельный artifact с PNG;
4. только после PASS квалифицировать цикл `1639` и разрешить цикл `1640`.

```text
CURRENT_HEAD_V172_56
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
