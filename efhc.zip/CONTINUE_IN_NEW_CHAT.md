## Текущая рабочая блокировка — кандидат v173.55 / цикл 1730

- GitHub CI `85145865998` проверил `efhc.zip` размером `12046473` bytes; размер совпадает с загруженным `EFHC_Bot_v173_54.zip`. Checkout: `3dd76713f4dea04ebb8d728385eab80f1726e41d`.
- CI-лог не содержит SHA-256 самого `efhc.zip`; принадлежность к `v173.54` дополнительно подтверждается содержимым failures: `TEST_GUARD_MANIFEST.version=v173.54` и новым consolidation document цикла 1729.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci и frontend build. FAILED: Mypy `4`; pytest `3 failed / 1499 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: четыре `no-any-return` на явных `global_id -> BIGINT` DB-boundaries; stale traceability exception list для active plan/consolidation docs; рассинхронизация `TEST_GUARD_MANIFEST` и `IDENTITY_MIGRATION_STATE_CURRENT`.
- String `global_id` contract, решения 1719–1729, compatibility surfaces и alias policy не менялись; нового cleanup не выполнялось.
- Function-preservation floor не изменён: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02258__cycle_1730_exact_head_ci_error_burn_down.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий плановый цикл: `1731 — backend/frontend audit + handoff`; если новый exact-head CI выявит failures, сначала продолжается error burn-down цикла 1730.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущая рабочая блокировка — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.

# ТЕКУЩИЙ HANDOFF — EFHC Bot v173.49 candidate

Завершённый цикл: **1724**. Следующий: **1725 — Admin NFT, VIP и manual claim**.

- Exact-head CI `85001150793` проверил `v173.48`: pytest `2 failed / 1500 passed / 22 skipped`; frontend prebuild остановился на checksum `ru`; Ruff, Mypy, Flake8, Bandit, compileall, Alembic/PostgreSQL и npm ci по предоставленным логам GREEN.
- Подтверждённые CI causes исправлены без расширения scope.
- `/admin/efhc-deposits` объединяет обзор, входящие операции, несопоставленные операции, безопасную повторную обработку, сверку за период и отдельно обозначенное аварийное действие.
- Business owner остаётся `global_id`; `parsed_tg_id` — только provider metadata.
- Произвольная ручная смена финансового статуса запрещена; `pending_manual` исключён из автоматических повторных попыток.
- Active canon: `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
# CONTINUE IN NEW CHAT — EFHC Bot v173.42

Current completed cycle: **1718**. Next: **1719**.

## Exact evidence

- supplied exact-head CI: `84954546920`;
- exact tested archive: `v173.41`;
- archive size: `12135299` bytes;
- green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build;
- failed gates: Mypy (`2`) и pytest (`17 failed / 1485 passed / 22 skipped`);
- confirmed causes patched in `v173.42`;
- `v173.42` ещё не получил exact-head GitHub CI.

## Function recovery plan

- active plan: `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `1719–1728`: десять волн исследования и согласования functions/routes;
- `1729`: итоговая decision matrix и только утверждённые изменения;
- `1730`: exact-head CI qualification/error burn-down;
- `1731`: backend/frontend audit handoff preparation.

## Critical locks

- GitHub CI пользователя — единственный application test/qualification contour; ассистент не запускает локальные tests, guards, lint/type/build/Alembic/CI checks.
- `global_id` остаётся единственным business/account/privileged/audit owner.
- BANK и Admin NFT canons неизменны.
- Отсутствие frontend/Python caller не разрешает удалять route/Admin/compatibility/operational surface.
- Удаление в 1719–1729 возможно только после полного Fail-Closed Delete proof и явного решения пользователя.
- Не объявлять `v173.42` PASS/production-ready до exact-head GitHub CI.


## Cycle 1720 current handoff

- Candidate HEAD: v173.44; next cycle 1721.
- Admin Tasks full editor implemented with fail-closed history preservation.
- Admin Ads provider registry/readiness connected separately; secrets remain server-side.
- `tasks_autorestart` is task-lock maintenance; TON time-based payment watcher is `check_ton_inbox/job_ton_watcher`.
- Status: PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED.