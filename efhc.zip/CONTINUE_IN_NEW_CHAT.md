# EFHC Bot v173.02 — цикл 1685

Архивы:

- `EFHC_Bot_v173_02.zip`;
- `EFHC_Bot_v173_02_RELEASE.zip`;
- `EFHC_Bot_v173_02_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_02.zip`.

Цикл 1685 исправляет критическое повреждение exact-head CI v173.01 и
переводит referral/identity-resolution контур на canonical `global_id`.
CI v173.01 был отменён после 94% pytest из-за PostgreSQL lock cascade,
возникшего после повреждающего codemod цикла 1684. GitHub workflow и
infrastructure не изменяются.

Referral schema, ORM, CRUD, services, routes, frontend и tests теперь
используют обязательные `inviter_global_id`, `invitee_global_id` и
`global_id` для ownership. `inviter_tg_id`, `invitee_tg_id` и `tg_id`
сохранены только как nullable Telegram/provider metadata и historical
read-through. Новая migration `0002` не создаётся: pre-release канон
остаётся в `0001_initial_release_schema.py`.

Принудительный переход тестов выполняется семантически. AST-guard
запрещает передачу `tg_id` в business services и требует явный
`global_id`. Telegram auth, initData, webhook, Bot API, membership,
provider mapping, physical Telegram fields и historical evidence
сохраняются построчно в machine inventory.

Полная матрица находится в `reports/generated/`. Текущий
аctionable/review-остаток: `1764`; всего token-употреблений: `3349`;
разрешено или сохранено: `1585`. Business-owner `tg_id` ещё не равен
нулю, поэтому окончательная миграция не закрыта.

Следующий цикл: 1686. Осталось пять циклов текущего плана: 1686–1690.

## Обязательный канон работы

При наличии полного ZIP пользовательских GitHub CI-логов запрещены
глупые, бессмысленные и дублирующие полные локальные CI, полный pytest
и повтор уже зелёных этапов. Исправляются первый causal failure и все независимые причины;
выполняются короткие точечные проверки и связанные проверки. Полную квалификацию проводит
следующий exact-head GitHub CI пользователя.

До exact-head CI v173.02 допустим только статус
`EXACT_HEAD_CI_REQUIRED`.
