<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.12 — продолжение работы

Статус: **CURRENT HANDOFF / EXACT_HEAD_CI_REQUIRED**

- Development: `EFHC_Bot_v173_12.zip`.
- Release: `EFHC_Bot_v173_12_RELEASE.zip`.
- Matrix: `EFHC_Bot_v173_12_MATRIX_TECHNICAL.zip`.
- Завершённый цикл: `1692`.
- Следующий цикл: `1693`.
- Активный план: `1693–1707`, осталось `15` циклов.
- Долгосрочная карта: `АРТЕФАКТЫ/Циклы/WORK_CYCLES_1701-1800_GLOBAL_ID_PLATFORM_EVOLUTION.md`.
- Последний входной exact-head CI: run `84563990753`, commit
  `a107ad26b08060304b1025e4094472333a5bb9d2`.

## Результат 1692

- исправлены 3 Ruff и 9 pytest failures последнего exact-head CI;
- `/sync/me`, profile/withdraw DTO и business frontend query keys стали provider-neutral;
- `tg_id` сохранён только в Telegram ingress/delivery/payment/proof boundaries;
- восстановлены архивы циклов, numbered chat transcripts и immutable reports;
- создан монотонный `reports_NNNNN` registry и fail-closed cadence guard;
- создан новый рабочий план `1693–1707`;
- создан долгосрочный документ циклов `1701–1800`;
- `business_owner_tg_id = 0`; migration `0002+` отсутствуют.

Перед продолжением использовать только фактический v173.12 и новый exact-head CI.
