# EFHC Bot v172.94 — цикл 1677

Архивы цикла:
- `EFHC_Bot_v172_93.zip`;
- `EFHC_Bot_v172_93_RELEASE.zip`;
- `EFHC_Bot_v172_93_MATRIX_TECHNICAL.zip`.

Текущий exact HEAD: `EFHC_Bot_v172_93.zip`.

Статус: `FINAL_IDENTITY_MIGRATION_IMPLEMENTED`; требуется exact-head GitHub CI.

# Утверждённый канон провайдеров — 2026-08-05

```text
Telegram → tg_id
TON      → ton_address
Google   → google_id
Apple    → apple_id
Facebook → fb_id
Discord  → discord_id
GitHub   → github_id
provider + subject → global_id
```

`global_id` — единственный business owner. Один `global_id` может иметь несколько provider identities. После identity resolution весь business runtime использует только `global_id`.

SSOT: `docs/SSOT/PROVIDER_IDENTIFIER_NAMING_CANON.md`.
Причинность: `docs/SSOT/PROVIDER_IDENTITY_CAUSAL_MAP.md`.
NORM: `docs/NORM/PROVIDER_IDENTITY_RESOLUTION_NORM.md`.
Следующий цикл: реализация канона в runtime, ORM, API, migration, tests и guards.

---

# Текущий статус v172.94 — цикл 1673

Главный архив: `EFHC_Bot_v172_88.zip`.

Релизный архив: `EFHC_Bot_v172_88_RELEASE.zip`.

Техническая матрица: `EFHC_Bot_v172_88_MATRIX_TECHNICAL.zip`.

## Текущий результат

- Исправлены все ошибки GitHub CI из пользовательского архива.
- Выполнен цикл 1672.
- Проведён повторный аудит связей, маршрутов, таблиц и остаточных `tg_id`.
- Миграции 0001 и 0002 объединены в единую каноническую миграцию 0001.
- Начато контролируемое удаление старых aliases.
- Telegram provider identity сохранена отдельно от business `global_id`.
- Следующий этап: exact-head CI и дальнейшее удаление alias-harness.

## Сохранённый исторический маркер

Цикл 1632 сохраняется в migration lineage и архитектурной истории проекта.
Каноническая миграция: `0001_initial_release_schema.py`.

## Обязательный канон работы по пользовательским CI-логам

Полный архив GitHub CI-логов пользователя является главным источником истины для repair-pass.

Процесс: логи пользователя → точный run и HEAD → первый причинный сбой → независимые причины → исправление всех подтверждённых ошибок → короткие точечные проверки → новая версия → следующий exact-head CI.

Запрещено выполнять глупые, бессмысленные и дублирующие локальные прогоны. Без доказанной необходимости нельзя повторять полный локальный CI, полный pytest, уже зелёный frontend build или другие доказанные этапы. Разрешены только короткие точечные проверки. Полная квалификация выполняется через следующий exact-head GitHub CI пользователя.


## Цикл 1673
Несогласованный codemod v172.88 исправлен. Runtime возвращён к согласованному global_id boundary; новый exact-head CI обязателен.
