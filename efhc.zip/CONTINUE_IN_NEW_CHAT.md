# CURRENT HANDOFF — EFHC Bot v173.65 candidate / цикл 1739

Входной HEAD: `EFHC_Bot_v173_64.zip`, SHA-256 `9568bc1b8f76aa735d713490597d426f5ebeb00758197d96056273ad97adb934`, размер `12351381` bytes. GitHub CI `85380431378`, checkout `0eaca2cc7c516f595fd44edce89d3bb3c6a60c60`, использовал `efhc.zip` того же размера; SHA-256 CI payload в логах не опубликован.

Все canonical gates кроме pytest завершились `exit=0`. Pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`. Исправлены только подтверждённые stale test/guard/documentation expectations: PostgreSQL FK count `39 → 41` в двух integration tests, exact-fragment identity disposition и Russian Engineering NORM. Production runtime/backend/frontend не изменялся.

Локальные application tests/build/linters/Alembic/CI не запускались. Статус кандидата `v173.65`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---


# CURRENT HANDOFF — EFHC Bot v173.63 candidate / циклы 1735–1737

Входной HEAD: `EFHC_Bot_v173_60.zip`, SHA-256 `03be8f51a4a649f7ebc2e44cc8f9abce88e7ca71a072574654e3b93e0cb36179`. По прямому ТЗ владельца рекламная инфраструктура реализована тремя последовательными циклами 1735–1737 без сокращения scope.

Active CANON: `docs/backend/ADS_MEDIATION_CANON.md`. Production path: `Tasks → frontend AdManager → POST /ads/session → provider registry/fallback → provider confirmation → server AdSession verification → Task reward snapshot → existing tasks_service → EFHCb`. Provider callback не задаёт размер EFHCb. `global_id` остаётся business owner; Telegram subject используется только на provider/Bot boundary.

Configuration: Admin DB override над ENV, encrypted secrets, masked Admin GET, runtime public config без rebuild. `builtin_timer` DEV/CI only. TADS/MyBid зарегистрированы, но fail-closed до точного official cabinet SDK/callback contract; их Widget ID сам по себе не считается proof просмотра.

Admin ADS/Tasks, frontend mediation, 13 locales, analytics/Revenue Optimizer, provider health/circuit breaker, AdsGram Bot adapter и 28 ADS contract guards добавлены. PATCH_002 visual/text authority сохранён; owner-approved visual exceptions ограничены ADS scope и зарегистрированы в `FRONTEND_AUTHORITY_MANIFEST.json`.

Current registered surface: `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`, Admin `74/80`, OpenAPI schemas `168`, ORM tables `55`. Single Alembic head `0001` сохранён.

Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались. Последний supplied CI — `85239758056` на `v173.58`; `v173.63` требует нового exact-head CI. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.60 candidate / цикл 1734

Входной HEAD: `EFHC_Bot_v173_59.zip`, SHA-256 `26e1167ea2701a9f397111934c52d83be02380146c6ed6a64239050e1791add0`. Цикл 1734 выполняет owner-directed corrective merge документов, frontend authority и CI guards после того, как цикл 1733 ошибочно поставил часть старых visual architecture expectations выше утверждённого frontend patch.

**Active authority:** `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip` — visual/UX/user-facing text CANON. Bot/main — backend/API/data/business/security authority и донор функций, но не visual donor. CI сообщает несоответствие, однако не выбирает authority: stale visual/text guards обновляются под patch.

Visual/text surfaces PATCH_002 восстановлены. Сохраняются только явно зарегистрированные невизуальные integration seams: provider-neutral/global_id wiring, selected-wallet Withdraw, TypeScript/ref plumbing, required context fields, canonical TON wire naming и native function-union virtualization wrapper. Все остальные frontend patch files должны оставаться byte-exact.

Функции обеих веток удалять нельзя. Неразмещённый main-only `POST /hub/efhc-handoff` и `useHubEfhcHandoff` сохранены как function donor со статусом `OWNER_REVIEW`; PATCH Hub не заменён старым UI. Для любого будущего FUNCTION↔VISUAL конфликта сначала требуется карточка конфликта и решение владельца.

Tests/guards переписаны так, чтобы visual/text expectations следовали PATCH_002, а функциональные guards сохраняли смысл без требования старой DOM/presentation. Добавлен новый fail-closed authority guard. Тесты/CI/build локально не запускались.

Current floor: `312 symbols / 58 modules / 68 files / 138 paths / 143 operations / 39 frontend pages`. Статус `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.59 candidate / цикл 1733

Входной HEAD: `EFHC_Bot_v173_58.zip`, SHA-256 `ca0d50840124418769449df7d57e6d0656427eefee5ae1fa29a8b210b61cff71`, размер `12106717` bytes. GitHub CI `85239758056` (checkout `30f5cfb7b283618094492ecd450a777f001270e9`) проверил `efhc.zip` того же размера. SHA-256 CI payload в логах отсутствует.

Подтверждённые failing gates входного HEAD: Ruff `1`, Mypy `1`, frontend build `exit=2` с 10 TypeScript diagnostics, pytest `57 failed / 1445 passed / 22 skipped / 1 warning`. Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full и npm ci по gate summary завершились `exit=0`.

Cycle 1733 внесён как минимальный regression burn-down после frontend overlay 1732. Исправлены только доказанные классы:

1. Ruff/Mypy: import formatting в `auth_session_routes.py`; explicit Decimal typing в `tasks_service.py`.
2. Frontend build: `GamePageShell` поддерживает forwarded ref; `ShopLayout` снова предоставляет обязательные avatar fields; Observability использует canonical `real_timeseries`; interface no-op variants содержат `EG`; Withdraw hook больше не получает Telegram business selector.
3. Protected frontend restoration: Hub снова использует `useHubEfhcHandoff` и ровно две canonical actions; Admin home не превращён в diagnostics launcher surface; TON transport использует provider `ton` + `ton_wallet_id`; Telegram ID остаётся только UI/provider bootstrap; GlobalHeader, Profile/FAQ/history/language dropdown, BrowserShop public surface, Referrals progression marker, Ukrainian protected translations и protected directory registry восстановлены по active contracts.
4. Generated frontend economic sources: generator TEXT синхронизирован с checked-in `economicUserSeams.ts` и validators для wallet fields, без запуска generator.
5. Stale expectations изменены только по утверждённому CANON 1732: current OpenAPI `138 paths / 143 operations`; Withdraw требует `external_address`; Admin Sale Packages writable; `TonWalletTransaction` compatibility alias сохраняется и не удаляется по принципу `no caller != delete proof`.

Новые bridge API цикла 1732 (`GET /auth/profile-photos`, `GET /tasks/earnings/me`) не удалены. Withdraw selected-wallet contract и writable Sale Packages не откатывались. Function surface не менялся: `312/58/68`, `138 paths / 143 operations`, `39 frontend pages`.

Frontend checksum metadata синхронизированы непосредственно по текущим bytes без запуска build/generator scripts: `.efhc-build-id = efhc-003a38e2705760b9`. Локальные pytest/guards/lint/type/frontend build/Alembic/CI не запускались.

Новый `v173.59` требует exact-head GitHub CI. Нельзя утверждать `CI green`, `tests pass`, `build passes` или `production-ready` до новых логов пользователя. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.58 candidate / цикл 1732

Вход: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`. Задача пользователя: внедрить `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip` как цикл 1732. Patch SHA-256: `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`.

Проверенная применимость patch: 131 изменяемый файл совпал с source SHA текущего HEAD; все 45 новых файлов отсутствовали в `v173.57`; все 176 overlay target SHA совпали до обязательных CANON-adaptation. Overlay = 162 frontend + 14 backend bridge/OpenAPI; standalone/demo/simulation runtime отсутствует.

Функционально перенесён `FRONTEND_v077` production overlay и подключены два недостающих bridge: `GET /auth/profile-photos` поверх verified provider identity metadata текущего `global_id` и `GET /tasks/earnings/me` поверх существующего `task_bonus_log`. Withdraw frontend/backend seam теперь принимает выбранный verified active wallet и сохраняет выбранный адрес; новый wallet lookup адаптирован к string-`global_id` + canonical DB helper. Sale Packages actions подключены к уже существующим service functions; panel lifetime остаётся строго 180 дней; Shop compatibility constructor остаётся alias того же canonical facade.

Current machine surface: `138 OpenAPI paths / 143 operations / 168 schemas / 39 frontend pages`; protected Python/file floor `312 symbols / 58 modules / 68 files`. `GET /meta/health_db` только появился в supplied OpenAPI inventory как уже существующий route current source.

Active NORM adaptation: новые авторские docstring/comments/error messages из patch приведены к русскому инженерному языку; Admin API diagnostics page имеет человекопонятный launcher/title, а raw route/method/JSON остаются только внутри специализированной технической диагностики.

Frontend release artifacts patch не содержал, поэтому они синхронизированы непосредственно по текущим bytes без запуска Node/build/verification scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `public/pwa-build.json` и `release-assets-manifest.json`.

Локальные tests/guards/lint/type/build/Alembic/CI не запускались. Последний exact-head GitHub CI в project evidence — `85157912581` на `v173.56`; exact-head CI `v173.58` обязателен перед любыми утверждениями о qualification. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.57 candidate / цикл 1731

Входной exact-qualified HEAD: `EFHC_Bot_v173_56.zip`, SHA-256 `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`. GitHub CI `85157912581`, checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`, проверил `efhc.zip` размером `11975213` bytes; все canonical gates завершились `exit=0`, pytest: `1502 passed / 22 skipped / 1 warning`.

Цикл 1731 завершает этап 1719–1731 как статический backend/frontend audit + handoff. Runtime/frontend production code в этом цикле не менялся. Current protected floor подтверждён по checked-in source/contract: `135 paths / 140 operations / 38 frontend pages / 312 symbols / 58 modules / 68 files`.

Подтверждённые carry-over задачи, которые **не реализовывались самовольно** в 1731:

1. **Global ID boundary normalization.** Статический AST-аудит production `backend/app/**/*.py` нашёл `375` прямых вызовов `int(...)`, где синтаксис аргумента содержит `global_id`, в `60` файлах. Это не означает 375 независимых runtime-дефектов: каждое место требует классификации как внешняя/service boundary или допустимая физическая BIGINT DB-boundary. Прямое приведение не следует считать каноническим helper; нужна отдельная минимальная миграционная волна по `GLOBAL_IDENTITY_SSOT.md`.
2. **Admin Human Language closure.** Подтверждены видимые технические подписи в `frontend/src/pages/admin/panels.tsx`, `frontend/src/pages/admin/tasks.tsx`, `frontend/src/pages/admin/referrals.tsx` и runtime dashboard-компонентах `AdminOverviewDashboardRuntime`, `AdminPanelsDashboardRuntime`, `AdminTasksReferralsDashboardRuntime`, `AdminObservabilityTimeseriesDashboardRuntime`, `AdminSystemHealthDashboardRuntime`. Нужна отдельная UX/localization волна без изменения API semantics.
3. **Frontend seam review.** В generated `adminSeams.ts` — 66 path constants; 54 имеют прямое именованное использование в текущем TS/TSX source, 12 не имеют прямого constant-name caller. Это **не delete-proof**: compatibility/alias/dynamic use сохраняются до отдельного анализа. Перечень находится в текущем audit-документе.

Документы handoff:
- `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md` — текущий итог цикла 1731 сверху, исторические evidence-разделы ниже сохранены;
- `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md` — current operation/page inventory и protected floor;
- `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md` — этап 1719–1731 закрыт audit/handoff-результатом и содержит carry-over backlog.

Новый кандидат `v173.57` требует следующего exact-head GitHub CI. Нельзя утверждать его CI-green до новых логов пользователя.

---

## Текущая рабочая блокировка — кандидат v173.56 / цикл 1730 continuation

- GitHub CI `85153784574` проверил `efhc.zip` размером `12053999` bytes; размер совпадает с загруженным `EFHC_Bot_v173_55.zip`. Checkout: `f5371d8f896486a2cbffe10584d76e65ebb7d959`.
- SHA-256 входного `EFHC_Bot_v173_55.zip` в рабочей среде: `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`; CI-лог не публикует SHA-256 самого входного `efhc.zip`, поэтому криптографическое равенство payload не утверждается.
- GREEN по предоставленному gate summary: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci и frontend build. FAILED только pytest.
- Pytest: `1 failed / 1501 passed / 22 skipped / 1 warning`; единственный failure — `manifest_sha_mismatch:docs/cycles/WORK_CYCLES_1701-1800.md`.
- Подтверждённая причина: `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv` содержал stale SHA `624741...8601`, тогда как фактический SHA cycle-range документа в v173.55 — `37dfdc83d5040fca169d82c2e2652c2ffeb202928841a8b7f050345139895eb8`. Это manifest drift; runtime/backend/frontend defect данным CI не подтверждён.
- Исправление ограничено cycle history manifest и обязательной current-state/reporting синхронизацией. Business semantics, compatibility surfaces, aliases, migrations и function-preservation floor не меняются.
- Function-preservation floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02259__cycle_1730_exact_head_ci_manifest_drift_followup.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Плановый следующий цикл: `1731 — backend/frontend audit + handoff`; начинать только после exact-head CI кандидата v173.56 без незакрытых failures.

## Текущая рабочая блокировка — кандидат v173.55 / цикл 1730

- GitHub CI `85145865998` проверил `efhc.zip` размером `12046473` bytes; размер совпадает с загруженным `EFHC_Bot_v173_54.zip`. Checkout: `3dd76713f4dea04ebb8d728385eab80f1726e41d`.
- CI-лог не содержит SHA-256 самого `efhc.zip`; принадлежность к `v173.54` дополнительно подтверждается содержимым failures: `TEST_GUARD_MANIFEST.version=v173.54` и новым consolidation document цикла 1729.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci и frontend build. FAILED: Mypy `4`; pytest `3 failed / 1499 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: четыре `no-any-return` на явных `global_id -> BIGINT` DB-boundaries; stale traceability exception list для active plan/consolidation docs; рассинхронизация `TEST_GUARD_MANIFEST` и `IDENTITY_MIGRATION_STATE_CURRENT`.
- String `global_id` contract, решения 1719–1729, compatibility surfaces и alias policy не менялись; нового cleanup не выполнялось.
- Function-preservation floor не изменён: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02258__cycle_1730_exact_head_ci_error_burn_down.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий плановый цикл: `1731 — backend/frontend audit + handoff`; если новый exact-head CI выявит failures, сначала продолжается error burn-down цикла 1730.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущая рабочая блокировка — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.

# ТЕКУЩИЙ HANDOFF — EFHC Bot v173.49 candidate

Завершённый цикл: **1724**. Следующий: **1725 — Admin NFT, VIP и manual claim**.

- Exact-head CI `85001150793` проверил `v173.48`: pytest `2 failed / 1500 passed / 22 skipped`; frontend prebuild остановился на checksum `ru`; Ruff, Mypy, Flake8, Bandit, compileall, Alembic/PostgreSQL и npm ci по предоставленным логам GREEN.
- Подтверждённые CI causes исправлены без расширения scope.
- `/admin/efhc-deposits` объединяет обзор, входящие операции, несопоставленные операции, безопасную повторную обработку, сверку за период и отдельно обозначенное аварийное действие.
- Business owner остаётся `global_id`; `parsed_tg_id` — только provider metadata.
- Произвольная ручная смена финансового статуса запрещена; `pending_manual` исключён из автоматических повторных попыток.
- Active canon: `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
# CONTINUE IN NEW CHAT — EFHC Bot v173.42

Current completed cycle: **1718**. Next: **1719**.

## Exact evidence

- supplied exact-head CI: `84954546920`;
- exact tested archive: `v173.41`;
- archive size: `12135299` bytes;
- green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build;
- failed gates: Mypy (`2`) и pytest (`17 failed / 1485 passed / 22 skipped`);
- confirmed causes patched in `v173.42`;
- `v173.42` ещё не получил exact-head GitHub CI.

## Function recovery plan

- active plan: `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `1719–1728`: десять волн исследования и согласования functions/routes;
- `1729`: итоговая decision matrix и только утверждённые изменения;
- `1730`: exact-head CI qualification/error burn-down;
- `1731`: backend/frontend audit handoff preparation.

## Critical locks

- GitHub CI пользователя — единственный application test/qualification contour; ассистент не запускает локальные tests, guards, lint/type/build/Alembic/CI checks.
- `global_id` остаётся единственным business/account/privileged/audit owner.
- BANK и Admin NFT canons неизменны.
- Отсутствие frontend/Python caller не разрешает удалять route/Admin/compatibility/operational surface.
- Удаление в 1719–1729 возможно только после полного Fail-Closed Delete proof и явного решения пользователя.
- Не объявлять `v173.42` PASS/production-ready до exact-head GitHub CI.


## Cycle 1720 current handoff

- Candidate HEAD: v173.44; next cycle 1721.
- Admin Tasks full editor implemented with fail-closed history preservation.
- Admin Ads provider registry/readiness connected separately; secrets remain server-side.
- `tasks_autorestart` is task-lock maintenance; TON time-based payment watcher is `check_ton_inbox/job_ton_watcher`.
- Status: PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED.