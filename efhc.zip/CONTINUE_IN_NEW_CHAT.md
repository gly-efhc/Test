# Продолжение EFHC после v172.62

## Канонические архивы

- `EFHC_Bot_v172_62.zip` — Development;
- `EFHC_Bot_v172_62_RELEASE.zip` — Release;
- `EFHC_Bot_v172_62_MATRIX_TECHNICAL.zip` — evidence.

## Текущий результат

- Fresh CI exact v172.61: все static, Alembic и frontend gates PASS;
  pytest — `21 failed, 3227 passed, 28 skipped`.
- Все подтверждённые классы ошибок исправлены локально.
- Цикл 1645 локально реализован: callers, watcher, achievements и
  cutover preparation используют canonical `global_id`.
- Alembic lineage: `0001 -> 0002`.
- `0002` не выполняет production cutover.
- Операторский cutover service не подключён к публичному API и не
  запускается автоматически.
- Public UI, Admin UX, screenshot workflow и canonical CI не менялись.

## Следующий обязательный шаг

1. Запустить unchanged main CI exact v172.62.
2. Исправить все подтверждённые ошибки fresh CI.
3. При PASS квалифицировать циклы 1644–1645.
4. Начать цикл 1646: удаление runtime legacy aliases и owner signatures.
5. Production cutover выполнять только по отдельной прямой команде после
   нулевого PostgreSQL preflight.

```text
CURRENT_HEAD_V172_62
CYCLE_1644_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1645_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1644_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```
