# ТЕКУЩИЙ HANDOFF — EFHC Bot v173.45 candidate

Завершённый цикл: **1721**. Следующий: **1722 — Referral ranking и referral integration**.

- Входной exact-head CI: `84968820953` на `v173.44`: pytest `4 failed / 1498 passed / 22 skipped`, Ruff `3`; остальные предоставленные major gates GREEN.
- Подтверждённые CI causes исправлены без локальной повторной проверки.
- По прямому решению пользователя реализован единый Shop Management: Admin Shop Editor + `/browser-shop` + `/shopfront/profile` + глобальные order counters + Force Fulfill по `global_id` + fail-closed history/delete.
- Active Shop canon: `docs/admin/ADMIN_SHOP_MANAGEMENT_CANON.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# CONTINUE IN NEW CHAT — EFHC Bot v173.42

Current completed cycle: **1718**. Next: **1719**.

## Exact evidence

- supplied exact-head CI: `84954546920`;
- exact tested archive: `v173.41`;
- archive size: `12135299` bytes;
- green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build;
- failed gates: Mypy (`2`) и pytest (`17 failed / 1485 passed / 22 skipped`);
- confirmed causes patched in `v173.42`;
- `v173.42` ещё не получил exact-head GitHub CI.

## Function recovery plan

- active plan: `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `1719–1728`: десять волн исследования и согласования functions/routes;
- `1729`: итоговая decision matrix и только утверждённые изменения;
- `1730`: exact-head CI qualification/error burn-down;
- `1731`: backend/frontend audit handoff preparation.

## Critical locks

- GitHub CI пользователя — единственный application test/qualification contour; ассистент не запускает локальные tests, guards, lint/type/build/Alembic/CI checks.
- `global_id` остаётся единственным business/account/privileged/audit owner.
- BANK и Admin NFT canons неизменны.
- Отсутствие frontend/Python caller не разрешает удалять route/Admin/compatibility/operational surface.
- Удаление в 1719–1729 возможно только после полного Fail-Closed Delete proof и явного решения пользователя.
- Не объявлять `v173.42` PASS/production-ready до exact-head GitHub CI.


## Cycle 1720 current handoff

- Candidate HEAD: v173.44; next cycle 1721.
- Admin Tasks full editor implemented with fail-closed history preservation.
- Admin Ads provider registry/readiness connected separately; secrets remain server-side.
- `tasks_autorestart` is task-lock maintenance; TON time-based payment watcher is `check_ton_inbox/job_ton_watcher`.
- Status: PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED.
