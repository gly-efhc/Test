# EFHC Bot v173.00 — цикл 1683

Архивы:

- `EFHC_Bot_v173_00.zip`;
- `EFHC_Bot_v173_00_RELEASE.zip`;
- `EFHC_Bot_v173_00_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_00.zip`.

Цикл 1683 исправляет GitHub CI v172.99, переводит Payment Intents,
withdrawals и прямые EFHC deposits на business owner `global_id`, а
также принудительно переводит не-Telegram тесты на `global_id`.

Полная матрица находится в `reports/generated/`. Текущий actionable
либо review-остаток равен 2170. Business-owner `tg_id` ещё не равен
нулю, поэтому окончательная миграция не закрыта.

Канон цикла 1632 и единая pre-release migration
`0001_initial_release_schema.py` сохраняются. Новую `0002` не создавать.

Следующий цикл: 1684. Осталось семь циклов текущего плана: 1684–1690.

Работать только fix-forward. При наличии пользовательского GitHub CI
использовать его как главный источник repair-pass: исправить первый
causal failure и все независимые причины, не повторяя уже зелёные
этапы без необходимости.

Полную квалификацию выполняет exact-head GitHub CI v173.00. До него
допустим только статус `EXACT_HEAD_CI_REQUIRED`.
