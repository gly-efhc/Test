# EFHC Bot v172.97 — цикл 1680

Архивы цикла:
- `EFHC_Bot_v172_97.zip`;
- `EFHC_Bot_v172_97_RELEASE.zip`;
- `EFHC_Bot_v172_97_MATRIX_TECHNICAL.zip`.

Текущий exact HEAD: `EFHC_Bot_v172_97.zip`.

## Состояние

Цикл 1680 продолжает окончательный переход финансовых контуров на `global_id`. Исправлены все подтверждённые ошибки CI v172.96. Следующая квалификация выполняется exact-head GitHub CI v172.97.

## Следующий цикл

Цикл 1681: referrals, tasks, ranks, achievements, shop и NFT.

Историческая фундаментальная точка: цикл 1632 сохранён в реестре архитектурных решений.
Активная pre-release migration: `0001_initial_release_schema.py`.
