<!-- EFHC_GLOBAL_IDENTITY_CANON_V2 -->
> **Действующий identity-канон EFHC.** `global_id` — главный
> персональный идентификатор и единственный внутренний account/business
> owner. `tg_id` — только Telegram provider subject. Обязательная
> цепочка: `provider + subject → global_id → business runtime`.
> Внешний `global_id` — string ровно из 10 ASCII-цифр;
> `0000000000` запрещён; numeric coercion запрещён.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
# EFHC Bot v173.08 — цикл 1688

Статус: **CURRENT HANDOFF / EXACT_HEAD_CI_REQUIRED**.

## Рабочая база

- Development: `EFHC_Bot_v173_08.zip`.
- Release: `EFHC_Bot_v173_08_RELEASE.zip`.
- Technical matrix: `EFHC_Bot_v173_08_MATRIX_TECHNICAL.zip`.
- Исходный exact-head CI цикла: GitHub run `31122027818`, commit
  `e74ed101de1612fb6ec45ce74a302a94432a7095`.
- Alembic head: только
  `backend/migrations/versions/0001_initial_release_schema.py`.

## Действующий identity-канон

`global_id` — главный персональный идентификатор и единственный
внутренний account/business owner. Внешний контракт — строка ровно из
10 ASCII-цифр; `0000000000` запрещён. Физическая колонка БД —
`efhc_core.users.global_id`.

`tg_id` — только Telegram provider subject. Обязательный путь:

`provider + subject → identity resolution → global_id → business runtime`.

После resolution ORM, SQL, services, routes, frontend, tests и active
documents используют `global_id`. Возврат legacy ownership запрещён.

## Выполненный scope цикла 1688

- Разобраны exact-head CI failures: Ruff, Bandit и pytest.
- Продолжен cutover административного, банковского, withdrawal,
  referral, NFT/VIP, ranks и оставшегося business runtime.
- `users.global_id` закреплён как обязательный owner; ORM aliases
  `user_id/legacy_pk/legacy_runtime_id/telegram_id` удалены.
- Owner FK на `users.tg_id` в business ORM устранены.
- Test-layer переведён на canonical `global_id`; provider-упоминания
  регистрируются построчно отдельным allowlist.
- Active identity documents синхронизированы; исторические материалы
  не имеют приоритета над текущим SSOT.
- Новые idempotency metadata и банковские зеркала создаются только с
  `global_id`; старые Telegram markers доступны лишь как фактический
  historical read-through.

## Граница доказательств

Локально разрешены только compileall, collection, точечные тесты,
machine guards, AST/ZIP/CRC/byte checks. Полный pytest и полный CI
локально не запускались. До нового GitHub CI на exact HEAD статус только
`EXACT_HEAD_CI_REQUIRED`; запрещено объявлять FULL PASS, PRODUCTION
READY или RELEASE READY.

## Следующий цикл

Следующий рабочий цикл: **1689**. По текущему плану остаются циклы
**1689–1690**.
