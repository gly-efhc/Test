# EFHC Bot v173.04 — цикл 1685

Архивы:

- `EFHC_Bot_v173_04.zip`;
- `EFHC_Bot_v173_04_RELEASE.zip`;
- `EFHC_Bot_v173_04_MATRIX_TECHNICAL.zip`.

Главный HEAD: `EFHC_Bot_v173_04.zip`.

Цикл 1685 продолжает fix-forward переход глобальных business-owner
употреблений `tg_id` на canonical `global_id` и исправляет все причины,
подтверждённые exact-head GitHub CI v173.03.

GitHub CI v173.03 имел зелёные Ruff, Mypy, flake8, Bandit, compileall,
Alembic и frontend build. Упал только pytest: 7 ошибок, 3257 пройденных
и 28 пропущенных тестов.

Исправлены два причинных контура:

1. Новые referral reward idempotency keys всегда canonical и основаны на
   `global_id`; legacy Telegram key используется только при найденном
   historical read-through.
2. Payment Intent и Shop Order fixtures больше не создают фиктивный
   dual owner `tg_id + global_id`; новые строки используют только
   реальный canonical `global_id`.

Referral schema, ORM, CRUD, services, routes, frontend и tests используют
обязательные `inviter_global_id`, `invitee_global_id` и `global_id` для
ownership. `tg_id` сохраняется только как Telegram/provider metadata и
historical read-through.

Принудительный переход тестов выполняется семантически. AST guard
запрещает передачу `tg_id` в business services и требует явный
`global_id`. Текущий результат: 0 business-selector нарушений;
зарегистрировано 585 допустимых Telegram/provider/schema/historical
употреблений в тестах.

Полная матрица находится в `reports/generated/`:

- всего identity token-употреблений: `3288`;
- actionable/review остаток: `1760`;
- allowed/preserved: `1528`.

Business-owner `tg_id = 0` ещё не доказан, поэтому миграция не закрыта.

Следующий цикл: 1686. Осталось пять циклов текущего плана: 1686–1690.

## Сохранённый фундамент

Цикл 1632 закрепил физический owner-контур `users.global_id` и
единственную pre-release migration `0001_initial_release_schema.py`.
Новая migration `0002` не создаётся.

## Обязательный канон работы

При наличии полного ZIP пользовательских GitHub CI-логов запрещены
дублирующие полные локальные CI, полный pytest и повтор уже зелёных
этапов. Исправляются первый causal failure и все независимые причины.
Выполняются короткие точечные проверки. Полную квалификацию проводит
следующий exact-head GitHub CI пользователя.

До exact-head CI v173.04 допустим только статус
`EXACT_HEAD_CI_REQUIRED`.
