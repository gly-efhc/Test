<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.11 — продолжение работы

Статус: **CURRENT HANDOFF / EXACT_HEAD_CI_REQUIRED**

- Development: `EFHC_Bot_v173_11.zip`.
- Release: `EFHC_Bot_v173_11_RELEASE.zip`.
- Matrix: `EFHC_Bot_v173_11_MATRIX_TECHNICAL.zip`.
- Завершённый цикл: `1691`.
- Следующий цикл: `1692`.
- Новый конечный диапазон после завершённого плана `1688–1690` пользователем
  не установлен; поэтому количество оставшихся циклов численно не определено.
- Последний входной CI evidence: run `84470060842`, exact-head commit
  `d73a73240ed985198d1df607c02a56f2b9d79c11`.

## Канон identity

`global_id` — единственный внутренний account/business owner.
`tg_id` — только Telegram provider subject, authentication ingress,
provider mapping или delivery metadata. Фиктивная пара
`global_id = tg_id` запрещена.

## Результат цикла 1691

- исправлены причинные ошибки трёх последовательных GitHub CI runs;
- admin logging получает обязательный `actor_global_id`;
- admin withdrawals/bank fixtures и selectors переведены на `global_id`;
- Telegram и TON identity tests используют физический `User.global_id`;
- внешний admin/frontend `global_id` закреплён как строка из 10 цифр;
- удалены active `user_id` alias/backfill/expand модули;
- завершённые reconciliation, shadow validation и read-switch инструменты
  перенесены в `АРТЕФАКТЫ/Код/` с SHA-256;
- compatibility registry заменён на `identity_registry` с нулём aliases;
- financial write owner lock принимает только `global_id`;
- `legacy_tg_id` в active owner contexts заменён на `provider_tg_id`;
- rollback/cutover и PG-0 `0002 → 0003` инструменты архивированы;
- старый tg_id baseline `v172.63` заменён точным provider-boundary V5;
- runtime tg_id surface уменьшена с 131 до 126 файлов и с 1154 до 1107
  употреблений; `business_owner_tg_id = 0`;
- active test-layer не содержит business-service calls через `tg_id`.

Перед продолжением использовать только фактический v173.11 и новый
exact-head GitHub CI.
