## Текущая точка — кандидат v173.90 / цикл 1754 continuation — compatibility restore

- Immutable report: `reports/numbered/reports_02293__cycle_1754_exact_head_ci_v173_89_compatibility_restore.md`, SHA-256 `30d9ab73b46879c2e9e5823086f3813a34ea2ee21330d197cf96d0f7c3127ba7`.
- Exact-head CI `86118458343` для `v173.89`: checkout `36e45906efb6ac9cdf21bc4200bc498506bac234`, archive size `12595048`; единственный failed gate — pytest `1 failed / 1590 passed / 22 skipped / 1 warning`, root cause PATCH_002 hash drift `adminRouteCatalog.ts`.
- По прямому owner decision восстановлены `GET /meta/health_db` (503 при DB failure), `GET /health/db-schema`, fail-closed `POST /skins/buy/{skin_id}` и 4 hidden `/hub/browser-shop-*` compatibility aliases. Repository no-caller search не является достаточным public delete-proof.
- Surface возвращён к `156/162/168`, hidden `8`, mounted `170`; protected `355/66/81`, frontend `39`, ORM `56`, Alembic только `0001`.
- Telegram database backup остаётся удалённым по отдельному owner decision; local encrypted newest-10 + SSH/SFTP export на ПК/смартфон.
- Новый candidate `v173.90` требует exact-head GitHub CI; cycle `1755` не начат.

## Текущая точка — кандидат v173.89 / цикл 1754 continuation — exact-head CI v173.88 burn-down

- Входной Development HEAD `EFHC_Bot_v173_88.zip`: SHA-256 `30051ae09aed848df643ff99dc9f08e9b5cdc48628f15960325307341be4bf1c`, размер `12582603` bytes, `4607` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Exact-head GitHub CI `86108318744`: checkout `2bcd7f61e7803bcc9a2a743fa80c8487d2b161af`, CI `efhc.zip` размер `12582603` bytes; SHA-256 CI payload в supplied logs не опубликован. Failed gates: Flake8 critical, Mypy, Ruff, pytest. Pytest `11 failed / 1580 passed / 22 skipped / 1 warning`; Ruff `9 errors`; Mypy `2 errors`.
- Это continuation цикла `1754`; numbered cycle `1755` не начат. Production causes исправлены: `EFHCError` import, route-cleanup unused imports/import-order residue, unused release variable.
- PATCH_002 восстановлен byte-exact для `AdminSalePackagesPage.tsx`, SHA-256 `6dfad487f83d9ca5d2cb69cff920619135d9e214efaff45dc185c220e1724b6b`; visual/text guard не ослаблялся и owner-approved exception не выдумывался.
- Stale tests/metadata синхронизированы с active CANON: root `VERSION`, canonical `system_routes.health_db`, removed orphan Ads helpers, exact identity review line pointers и current guard/state version. `INSTALL.md` снова содержит `.env.example`, `/opt/efhc/shared/.env`, `chmod 600`; KERNEL timeless prose переведён на русский и ONE VPS DR authority.
- Factual application surface не менялся: `153 OpenAPI paths / 159 public operations / 168 schemas / 4 hidden / 163 mounted`; protected `355/66/81`; frontend pages `39`; ORM `56`; canonical users.global_id FK floor `42`; Alembic head только `0001`. Database backup остаётся local encrypted newest-10 с owner export по SSH/SFTP на ПК/смартфон; Telegram database-backup infrastructure не возвращалась.
- Неподтверждённый/нерешённый item: visible Sale Packages PATCH_002 mutations по-прежнему встречают backend CANON `409 SALE_PACKAGES_NOT_RELEASE_SSOT`; его визуальное решение требует отдельного owner approval и не может быть сделано ради CI.
- Локальные tests/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/PostgreSQL/smoke не запускались. Выполнена только разрешённая static AST/JSON/text/hash verification.
- Immutable report: `reports/numbered/reports_02292__cycle_1754_exact_head_ci_v173_88_continuation.md`, SHA-256 `677e5828bdf5037789b75c97a09fe33b094eb69dc83fbf85655531ff2cd1b583`.
- Candidate `v173.89` требует следующий exact-head GitHub CI. При failures продолжается цикл `1754`; только green qualification разрешает переход к cycle `1755`.

## Текущая точка — кандидат v173.88 / цикл 1754 — route cleanup + DevOps hardening + owner backup override

- Входной Development HEAD `EFHC_Bot_v173_87.zip`: SHA-256 `fc5e18903fb64a7518349df7029a4b5cc2dc8782331dacd2de5475a8275e92a9`, размер `12572495` bytes, `4615` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Exact-head GitHub CI `86004195126`: checkout `f181388c2211f035d18dfc15dcf3b9ba44e15dd4`, CI `efhc.zip` размер `12572495` bytes; SHA-256 CI payload в supplied logs не опубликован. Все canonical gates `exit=0`; pytest `1587 passed / 22 skipped / 1 warning`; Alembic `0001: ok`, `metadata_tables=56`; frontend assets/build verification `PASS`. Цикл `1753` квалифицирован.
- Последнее owner decision supersedes Telegram database-backup части Audit 8/DevOps ТЗ: production DB backup **не отправляется в Telegram**. Backup-specific Telegram transport/scripts/ENV/Local Bot API infrastructure удалены. Canonical recovery — local encrypted newest-10 на единственной production VPS; владелец скачивает выбранный `.enc` + `.sha256` по SSH/SFTP на ПК или смартфон. Обычный EFHC Telegram bot/webhook/admin text notifications остаются отдельным runtime contour.
- Route cleanup удаляет 7 repository-proven dead/retired HTTP surfaces: 4 `/hub/browser-shop-*` aliases, `POST /skins/buy/{skin_id}`, `GET /health/db-schema`, `GET /meta/health_db`. Factual candidate surface: `153 OpenAPI paths / 159 public operations / 168 schemas / 4 hidden / 163 mounted`; canonical `/shopfront/*`, `/api/health/db` и progression skins сохранены.
- Conditional Admin/Ads/duplicate activation backend routes без external traffic proof не удаляются. Sale Packages frontend переведён read-only по существующему fail-closed backend CANON. Route-audit hardening закрывает unauthenticated `/nft/has_vip` provider amplification, raw DB exception leakage, unrestricted Workbench path edit и stale health/observability docs/proofs.
- DevOps hardening: ONE VPS, root `VERSION` SSOT, owner ENV без ручных version labels и без second-host/backup-Telegram fields, `140/140` русских metadata blocks, canonical `/api/health`, explicit update commit/terminal states, race-safe Autopilot release-lock observation-only, isolated encrypted restore drill.
- PostgreSQL schema/financial/identity semantics не менялись: единственный Alembic head `0001_initial_release_schema.py`, ORM `56`, canonical `users.global_id` FK floor `42`; protected floor `355/66/81`; frontend pages `39`; test file inventory `272 architecture / 452 Python`.
- Production access-log/config proof для удалённых public URLs не предоставлен; production rollout этих URL остаётся отдельным gate. Также operational clean-replacement-VPS DR drill и полный browser-shop service-layer decomposition не заявляются выполненными.
- Локальные tests/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/PostgreSQL/smoke не запускались. Выполнена только разрешённая static AST/JSON/CSV/route/OpenAPI/env/archive-source verification.
- Immutable report: `reports/numbered/reports_02291__cycle_1754_route_devops_backup_owner_override.md`, SHA-256 `c75ef9976168776d3665879f84b1f628b20d646e62156bfb9135862f8993a187`.
- Candidate `v173.88` требует следующий exact-head GitHub CI. При failures продолжается цикл `1754`; после green qualification следующий numbered cycle — `1755`.

## Текущая точка — кандидат v173.87 / цикл 1753 — Audit 8 Backup/DR hardening

- Входной Development HEAD `EFHC_Bot_v173_86.zip`: SHA-256 `2322d2e0799fd505e2c4fe56e329bdee4b5a9893a2a98cbc6e35c279d6aa7c4f`, размер `12549983` bytes, `4612` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Новые exact-head GitHub CI-логи для входного `v173.86` в текущем наборе файлов отсутствуют. Доступный `logs_85980628163.zip` относится к ранее квалифицированному `v173.85` и не используется как verifier `v173.86`.
- Цикл `1753` выполняет пересмотренный owner-authority Audit 8 по Autonomous DevOps / Backup / Restore / Disaster Recovery. Подтверждены и исправлены A8-R1…A8-R7: fixed newest-10 local generations, isolated restore drill, fail-closed backup-key lifecycle, manual encrypted Telegram recovery path, backup-aware status, attempts-bounded retry и post-reboot boot timer.
- Canonical backup generation теперь имеет один encrypted recovery artifact: тот же ciphertext сохраняется локально и отправляется владельцу в Telegram; raw dump и незашифрованный bundle являются staging-only material. Telegram outage не расширяет local spool сверх newest 10.
- Production application/backend/frontend/OpenAPI/schema/ORM business surface не изменён. Единственный Alembic head остаётся `0001_initial_release_schema.py`; ORM `56`; canonical `users.global_id` FK floor `42`; PATCH_002 visual/text authority не затронут. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; static test inventory `272 architecture / 452 Python files`.
- Добавлены CI-only guards в существующий architecture test file; локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Выполнена только разрешённая статическая source/AST/manifest/ZIP проверка.
- Candidate `v173.87` требует следующий exact-head GitHub CI. При failures продолжается цикл `1753`; к циклу `1754` переходить только после qualification `v173.87`.

## Текущая точка — кандидат v173.86 / цикл 1752 qualification — exact-head CI v173.85 green

- Входной Development HEAD `EFHC_Bot_v173_85.zip`: SHA-256 `82886c32e62c2d3a2f6e61e8589361036353bff09ec4fff1589d962939029f0e`, размер `12724012` bytes, `4611` ZIP entries; локальная ZIP integrity проверка успешна, duplicates `0`.
- Supplied GitHub CI `85980628163` для `v173.85`: checkout `53f7fc88f92bbc7bb176546122350347b1352c0a`; CI `efhc.zip` имеет размер `12724012` bytes. SHA-256 CI payload в предоставленных логах не опубликован.
- Gate summary полностью успешен: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight, pytest и Ruff имеют `exit=0`. Pytest: `1578 passed / 22 skipped / 1 warning`; Ruff: `All checks passed`; Mypy: `344 source files` без issues; Alembic: `metadata_tables=56`, `0001: ok`; frontend build verify: `PASS`.
- Подтверждённых CI root causes нет; production/backend/frontend/schema/test semantics не меняются. PostgreSQL логи содержат ожидаемые negative-path constraint errors из тестовых сценариев, но gate/pytest завершены успешно, поэтому они не классифицируются как failures.
- Цикл `1752` квалифицирован по входному `v173.85`. Следующий numbered functional cycle — `1753`; его scope в active SSOT не задан и в этой итерации не начинается.
- Этот `v173.86` содержит только qualification/traceability updates и immutable report; functional SSOT/CANON, OpenAPI, ORM и PATCH_002 visual/text authority не изменены. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; canonical `users.global_id` FK floor `42`; static tests `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Новый `v173.86` требует exact-head GitHub CI как новый архив.

## Текущая точка — кандидат v173.85 / цикл 1752 continuation — exact-head CI burn-down v173.84

- Exact-head GitHub CI `85947769920` квалифицирован для входного `v173.84`: checkout `2a7e9d6d1fe2c3fb89b3664246bfd048c36cf046`, CI archive `12537062` bytes. Единственный failing gate — pytest: `4 failed / 1574 passed / 22 skipped / 1 warning`; Alembic/PostgreSQL, Ruff, Mypy, Bandit, compileall, Flake8 critical/full, npm ci и frontend build успешны.
- Два schema failures — stale integration constants `EXPECTED_FK_COUNT=41`; current `0001` и active release state канонически имеют `42` FK на `users.global_id`. Оба expectations синхронизированы на `42`.
- Первый referral failure — stale lookup ненумерованного `REF_ACT_UNIT` и неверного owner в fixture; expectation синхронизирован с canonical inviter-owned `REF_ACT_UNIT:G{inviter_global_id}:N00001`.
- Второй referral failure — boundary fixture создавал `9999` active referrals напрямую, но не моделировал уже закреплённые slots `1..9998`, поэтому allocator корректно начинал с `N00001`. Fixture теперь моделирует prior slot ownership `1..9998`, после чего проверяет `N09999`, `N10000` и отсутствие slot у `10001`-го active referral.
- Production/runtime/DevOps/referral economics не изменялись. Независимые `REF_ACT_UNIT`, `REF_LVL` и нефинансовый Rankings CANON сохранены. ORM floor `56`; global owner FK floor `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.85` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.85` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.84 / цикл 1752 continuation — exact-head CI burn-down v173.83

- Exact-head GitHub CI `85940762760` квалифицирован для входного `v173.83`: checkout `f0456d329f84ed1cd6183c2297188a7e3f626aa2`, CI archive `12529560` bytes. Failing gates: Alembic, Ruff и pytest; Mypy/Bandit/compileall/Flake8/frontend gates успешны.
- Alembic root cause: после Audit 7 таблица `ad_provider_claims` добавила ещё один canonical FK на `users.global_id`, поэтому фактический count `42`, а `0001` validator и его static contract guard оставались на `41`.
- Ruff root cause: только `I001` в новом DevOps architecture guard.
- Независимые pytest drifts: provider-portability gate всё ещё ожидал прямой predeploy `backup_postgres.sh` вместо current `telegram_backup_delivery.sh`; daily backup test ожидал прямой `backup_bundle.sh` вместо delegated Telegram chain; referral Lvl fixture не предоставлял `db.scalar()` для historical key read-through; `INSTALL.md` потерял явный literal `chmod 600`. Остальные DB failures/errors являются следствием failed Alembic setup из supplied run.
- Все подтверждённые причины исправлены без изменения DevOps safety model, referral economics или Audit 7 runtime semantics. ORM floor остаётся `56`; global owner FK floor current `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.84` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.84` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.83 / цикл 1752 — Autonomous DevOps + exact-head CI burn-down

- Exact-head GitHub CI `85876332157` квалифицирован для входного `v173.82`: checkout `78ac7c355be6cc9f6c8215baa647a31960658a27`, CI archive `12480201` bytes. Ruff/Mypy/Bandit/compileall/Flake8/frontend gates успешны; Alembic падает на stale `EXPECTED_TABLE_COUNT=55` при canonical ORM floor `56`, что порождает каскад DB pytest errors. Независимые pytest drifts: Audit-6 revoke SQL literal, Ranks marker, test/current-state version и referral numbered-slot fixture.
- Все подтверждённые CI root causes исправлены без отката Audit 7: database contract = `56`, stale guards/fixture синхронизированы с active CANON.
- Цикл 1752 реализует repository/release часть autonomous DevOps: encrypted Telegram backup, local Bot API integration, status/autopilot/diagnostic, daily/weekly/monthly/post-reboot timers, external-monitor artifact, ENV preflight и safe host prerequisites. Фактическая установка на production/external VPS в этом чате не выполнялась — доступа к VPS нет.
- Referral economics закреплена тремя независимыми контурами: `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`, `REF_LVL:G{inviter_global_id}:L{level}` и нефинансовый referral/ranking display. Historical Lvl keys сохраняются только для idempotent read-through.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.83` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.83` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.82 / цикл 1751 — Unified Deep Audit 7

- Exact-head GitHub CI `85849626798` квалифицировал входной `v173.81`: checkout `ab5591d411da6d87591459f6350b0de0f91189fb`, CI archive `12464501` bytes. Failing gates: Ruff `UP012`, Bandit `B608`, pytest `1 failed / 1566 passed / 22 skipped / 1 warning`; остальные supplied canonical gates завершились успешно.
- Все семь findings A7-R1…A7-R7 подтверждены по current source/SSOT/CANON и исправлены: Energy delta parity; ADS provider single-claim; Admin/Public Tasks atomicity; numbered referral slots; полный paged Ranks + direct find-me; progression-only Skins fail-closed legacy commerce.
- Exchange lifetime model не менялась: `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `271 architecture / 451 Python files`.
- Единственный Alembic head остаётся `0001_initial_release_schema.py`; новая ADS claim table входит в pre-release `Base.metadata.create_all()`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.82` требует exact-head GitHub CI.
- Следующий утверждённый функциональный scope после qualification — цикл `1752`, настройка окружения/автономного DevOps-контура по `EFHC_DevOps_TZ.md`.

## Текущая точка — кандидат v173.81 / цикл 1750

- Exact-head GitHub CI `85840461388` полностью квалифицировал входной `v173.80` (`12452133` bytes, checkout `3a80d8c8f85feff263771ebd0b3c33567d971f1e`); pytest `1563 passed / 22 skipped / 1 warning`, остальные supplied canonical gates `exit=0`.
- Audit 6 A6-01…A6-03 подтверждены по source/SSOT/CANON и исправлены: inactive-account session/RBAC/handoff kill-switch, JWT expected audience, bounded fail-closed TON challenge issuance/cleanup.
- Protected/API/ORM/frontend floor не изменён: `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- После patch локальные tests/CI/guards/build/Alembic/PostgreSQL не запускались. Candidate `v173.81` требует exact-head GitHub CI.
- Следующий функциональный цикл после qualification: `1751`; CI failures нового HEAD имеют приоритет над следующим audit scope.

## Точка продолжения — кандидат v173.80 / цикл 1749 continuation

- Exact-head CI `85837515925` квалифицировал входной `v173.79`: checkout `8c63e2261e39445022f1c18eef2738667fe6bf8c`, CI archive `12447211` bytes.
- Все supplied gates, кроме pytest, успешны. Pytest: `2 failed / 1561 passed / 22 skipped / 1 warning`.
- Исправлены только два CI-confirmed metadata/documentation drift: русскоязычная строка `KERNEL.md` и синхронизация `TEST_GUARD_MANIFEST` с candidate/current-state.
- Production/backend/frontend/API/schema/ORM не изменены; Audit 5 semantics сохранены.
- Candidate `v173.80` требует следующего exact-head GitHub CI.
- Цикл: `1749 continuation`; следующий номер после закрытия — `1750`.

## Точка продолжения — кандидат v173.79 / цикл 1749

- Входной HEAD: `EFHC_Bot_v173_78.zip`, SHA-256 `bca800b6830e11cd605d3d92cf8141c72f8fbff5b7d92a675b80c12e68419607`, `4581` entries.
- Exact-head GitHub CI `85806294354`: checkout `6ff22c5f7cd72dee81a60656eb518fae18fc8a00`, CI archive `12621087` bytes. Failing gates: Ruff `1×SIM102`; pytest `1 failed / 1562 passed / 22 skipped / 1 warning`; остальные supplied canonical gates успешны.
- Исправлены только две подтверждённые причины: nested-if style drift в Audit-5 architecture guard и numbered work-pass label в `ADMIN_VIP_NFT_MANAGEMENT_CANON.md`.
- Audit 5 VIP/NFT production semantics не менялись и не откатывались; frontend visual/text, API, schema, ORM и financial/economy runtime не изменены.
- Protected floor: `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- Локальные tests/CI/guards не запускались. Candidate `v173.79` требует следующего exact-head GitHub CI.
- Завершённый цикл: `1749`. Следующий номер цикла: `1750`; функциональный scope определяется следующей командой владельца после обязательной CI qualification, если будут новые логи.

## Точка продолжения — кандидат v173.77 / цикл 1747

- Exact-head GitHub CI `85713471365` квалифицировал входной `v173.76`: checkout `5bd34ef70b256343f3e42f51eb7f237c16349dad`, CI archive `12416737` bytes. Failing gates: Ruff `1×SIM102`, pytest `4 failed / 1550 passed / 22 skipped`; остальные supplied canonical gates завершились успешно.
- Все пять CI-причин исправлены без отката Audit 4: один style drift нового architecture guard и четыре stale guard/fixture expectations.
- Owner security audit от `v173.75` не применялся как blind patch: findings F-01…F-06 повторно подтверждены на exact source `v173.76` и перенесены минимально поверх HEAD. F-07…F-09 подтверждены как отдельные provider/ops решения без выдумывания contracts.
- Security floor 1747: client-only ad completion не имеет reward authority; Monetag/AdMaven postback требует independent secret; streamed HTTP body cap считает реальные ASGI chunks; security middleware/system locks и сильный `SECRET_KEY` fail-closed в prod/stage; Browser Shop не сохраняет bearer в URL/history; `cryptography` floor `44.0.1`.
- Frontend visual/text PATCH_002 не изменён; Browser Shop изменение зарегистрировано как owner-approved nonvisual security exception.
- Protected floor остаётся `355 / 66 / 81`, OpenAPI `156 / 162 / 168`, mounted operations `170`, frontend `39`, ORM `55`.
- Локальные tests/CI/guards/Ruff/Mypy/Flake8/Bandit/compileall/frontend build/Alembic/PostgreSQL после patch не запускались.
- Неизменяемый отчёт: `reports_02280__cycle_1747_exact_head_ci_security_hardening.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.76 / цикл 1746 — Audit 4/10

- Входной exact HEAD: `EFHC_Bot_v173_75.zip`, SHA-256 `03a81f69e689cde30717df936039276f1d54904c5d4ed3e394de77e350f0b75a`.
- GitHub CI `85694957898` exact-head для `v173.75` полностью успешен до Audit 4: pytest `1549 passed / 22 skipped / 1 warning`, остальные canonical gates успешны.
- Audit 4 исправляет пять подтверждённых defects: authoritative TonConnect ownership, emergency deposit nocommit atomicity, withdrawal repair locking/fingerprint, required Admin audit + post-commit Telegram, stage webhook fail-closed.
- Withdraw V1 payout CANON не расширяется watcher-proof/FSM требованиями. Frontend PATCH_002 visual/text не изменён.
- Protected floor: `355/66/81`, OpenAPI `156/162`, mounted `170`, frontend `39`, ORM `55`, schemas `168`.
- Добавлен CI-only guard Audit 4; локальные tests/CI/guards не запускались.
- Неизменяемый отчёт: `reports_02279__cycle_1746_audit4_ton_withdraw_security_atomicity.md`.
- Следующий verifier — exact-head GitHub CI нового `v173.76`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.71 / цикл 1743 — exact-head CI burn-down после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_70.zip`, SHA-256 `fe70e8d27ad1021c85bc9fa46adde832bd52f3c0cc0a27f9be80445f4b869601`, размер `12452372` bytes.
- Exact-head GitHub CI `85540647405`, checkout `49f522c81c324c02134a4bbed4f200f678d98b72`; CI `efhc.zip` имеет тот же размер `12452372` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, compileall, Flake8 critical/full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Ruff — `7` fixable diagnostics; Mypy — `1` typing error; Bandit — `2` B608 low-confidence findings; pytest — `4 failed / 1545 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: import/lint drift; nullable typing materialized deposit recovery; Panels SQL больше не собирается конкатенацией fixed owner-clause; emergency deposit использует external-event idempotency только по immutable `tx_hash`; stale canonical actor fixture и watcher-CANON assertion синхронизированы; Russian Engineering NORM исправлен в двух строках `KERNEL.md`.
- Обязательный Admin audit остаётся fail-closed и атомарным; audit actor — canonical `users.global_id`. RBAC, Admin NFT, strict financial Idempotency-Key для класса `MUST`, materialized-only deposit recovery и rollback semantics аудита 2/10 не ослаблены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02274`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- Admin authorization разделён: `require_admin` = authentication/read gate; любой state-changing `POST/PUT/PATCH/DELETE` требует `require_admin_write` (минимум Moderator), поэтому `Analyst/auditor → 403`.
- Emergency EFHC deposit принимает только `tx_hash`; amount/MEMO/address/raw facts берутся исключительно из materialized `ton_inbox_logs` под `FOR UPDATE`; отсутствие watcher-записи fail-closed. Money + обязательный actor audit фиксируются одним commit.
- Admin bank money operations используют caller-owned nocommit boundaries: ledger + обязательный `admin_action_log` + notification outbox атомарны; Telegram delivery выполняется после commit.
- Повторный `Idempotency-Key` с другим owner/operation/direction/balance/amount возвращает `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload остаётся read-through.
- Admin NFT principal после центрального gate не проходит whitelist-only повторную авторизацию.
- Panels service синхронизирован с `archived_at`; facade использует `toggle_panel`; HTTP activate/deactivate идут через единый service-layer. Rollback balance type выводится только из исходной ledger-строки.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

# CURRENT CYCLE 1741 — v173.67 candidate

Exact-head CI `85400569189` for input `v173.66` is GREEN on all canonical gates. Cycle 1741 records a static function/route/table audit; runtime/frontend/schema are unchanged. Current candidate `v173.67` changes audit/SSOT/guard files and therefore requires its own exact-head CI.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# CURRENT HANDOFF — EFHC Bot v173.65 candidate / цикл 1739

Входной HEAD: `EFHC_Bot_v173_64.zip`, SHA-256 `9568bc1b8f76aa735d713490597d426f5ebeb00758197d96056273ad97adb934`, размер `12351381` bytes. GitHub CI `85380431378`, checkout `0eaca2cc7c516f595fd44edce89d3bb3c6a60c60`, использовал `efhc.zip` того же размера; SHA-256 CI payload в логах не опубликован.

Все canonical gates кроме pytest завершились `exit=0`. Pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`. Исправлены только подтверждённые stale test/guard/documentation expectations: PostgreSQL FK count `39 → 41` в двух integration tests, exact-fragment identity disposition и Russian Engineering NORM. Production runtime/backend/frontend не изменялся.

Локальные application tests/build/linters/Alembic/CI не запускались. Статус кандидата `v173.65`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---


# CURRENT HANDOFF — EFHC Bot v173.63 candidate / циклы 1735–1737

Входной HEAD: `EFHC_Bot_v173_60.zip`, SHA-256 `03be8f51a4a649f7ebc2e44cc8f9abce88e7ca71a072574654e3b93e0cb36179`. По прямому ТЗ владельца рекламная инфраструктура реализована тремя последовательными циклами 1735–1737 без сокращения scope.

Active CANON: `docs/backend/ADS_MEDIATION_CANON.md`. Production path: `Tasks → frontend AdManager → POST /ads/session → provider registry/fallback → provider confirmation → server AdSession verification → Task reward snapshot → existing tasks_service → EFHCb`. Provider callback не задаёт размер EFHCb. `global_id` остаётся business owner; Telegram subject используется только на provider/Bot boundary.

Configuration: Admin DB override над ENV, encrypted secrets, masked Admin GET, runtime public config без rebuild. `builtin_timer` DEV/CI only. TADS/MyBid зарегистрированы, но fail-closed до точного official cabinet SDK/callback contract; их Widget ID сам по себе не считается proof просмотра.

Admin ADS/Tasks, frontend mediation, 13 locales, analytics/Revenue Optimizer, provider health/circuit breaker, AdsGram Bot adapter и 28 ADS contract guards добавлены. PATCH_002 visual/text authority сохранён; owner-approved visual exceptions ограничены ADS scope и зарегистрированы в `FRONTEND_AUTHORITY_MANIFEST.json`.

Current registered surface: `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`, Admin `74/80`, OpenAPI schemas `168`, ORM tables `55`. Single Alembic head `0001` сохранён.

Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались. Последний supplied CI — `85239758056` на `v173.58`; `v173.63` требует нового exact-head CI. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.60 candidate / цикл 1734

Входной HEAD: `EFHC_Bot_v173_59.zip`, SHA-256 `26e1167ea2701a9f397111934c52d83be02380146c6ed6a64239050e1791add0`. Цикл 1734 выполняет owner-directed corrective merge документов, frontend authority и CI guards после того, как цикл 1733 ошибочно поставил часть старых visual architecture expectations выше утверждённого frontend patch.

**Active authority:** `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip` — visual/UX/user-facing text CANON. Bot/main — backend/API/data/business/security authority и донор функций, но не visual donor. CI сообщает несоответствие, однако не выбирает authority: stale visual/text guards обновляются под patch.

Visual/text surfaces PATCH_002 восстановлены. Сохраняются только явно зарегистрированные невизуальные integration seams: provider-neutral/global_id wiring, selected-wallet Withdraw, TypeScript/ref plumbing, required context fields, canonical TON wire naming и native function-union virtualization wrapper. Все остальные frontend patch files должны оставаться byte-exact.

Функции обеих веток удалять нельзя. Неразмещённый main-only `POST /hub/efhc-handoff` и `useHubEfhcHandoff` сохранены как function donor со статусом `OWNER_REVIEW`; PATCH Hub не заменён старым UI. Для любого будущего FUNCTION↔VISUAL конфликта сначала требуется карточка конфликта и решение владельца.

Tests/guards переписаны так, чтобы visual/text expectations следовали PATCH_002, а функциональные guards сохраняли смысл без требования старой DOM/presentation. Добавлен новый fail-closed authority guard. Тесты/CI/build локально не запускались.

Current floor: `312 symbols / 58 modules / 68 files / 138 paths / 143 operations / 39 frontend pages`. Статус `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.59 candidate / цикл 1733

Входной HEAD: `EFHC_Bot_v173_58.zip`, SHA-256 `ca0d50840124418769449df7d57e6d0656427eefee5ae1fa29a8b210b61cff71`, размер `12106717` bytes. GitHub CI `85239758056` (checkout `30f5cfb7b283618094492ecd450a777f001270e9`) проверил `efhc.zip` того же размера. SHA-256 CI payload в логах отсутствует.

Подтверждённые failing gates входного HEAD: Ruff `1`, Mypy `1`, frontend build `exit=2` с 10 TypeScript diagnostics, pytest `57 failed / 1445 passed / 22 skipped / 1 warning`. Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full и npm ci по gate summary завершились `exit=0`.

Cycle 1733 внесён как минимальный regression burn-down после frontend overlay 1732. Исправлены только доказанные классы:

1. Ruff/Mypy: import formatting в `auth_session_routes.py`; explicit Decimal typing в `tasks_service.py`.
2. Frontend build: `GamePageShell` поддерживает forwarded ref; `ShopLayout` снова предоставляет обязательные avatar fields; Observability использует canonical `real_timeseries`; interface no-op variants содержат `EG`; Withdraw hook больше не получает Telegram business selector.
3. Protected frontend restoration: Hub снова использует `useHubEfhcHandoff` и ровно две canonical actions; Admin home не превращён в diagnostics launcher surface; TON transport использует provider `ton` + `ton_wallet_id`; Telegram ID остаётся только UI/provider bootstrap; GlobalHeader, Profile/FAQ/history/language dropdown, BrowserShop public surface, Referrals progression marker, Ukrainian protected translations и protected directory registry восстановлены по active contracts.
4. Generated frontend economic sources: generator TEXT синхронизирован с checked-in `economicUserSeams.ts` и validators для wallet fields, без запуска generator.
5. Stale expectations изменены только по утверждённому CANON 1732: current OpenAPI `138 paths / 143 operations`; Withdraw требует `external_address`; Admin Sale Packages writable; `TonWalletTransaction` compatibility alias сохраняется и не удаляется по принципу `no caller != delete proof`.

Новые bridge API цикла 1732 (`GET /auth/profile-photos`, `GET /tasks/earnings/me`) не удалены. Withdraw selected-wallet contract и writable Sale Packages не откатывались. Function surface не менялся: `312/58/68`, `138 paths / 143 operations`, `39 frontend pages`.

Frontend checksum metadata синхронизированы непосредственно по текущим bytes без запуска build/generator scripts: `.efhc-build-id = efhc-003a38e2705760b9`. Локальные pytest/guards/lint/type/frontend build/Alembic/CI не запускались.

Новый `v173.59` требует exact-head GitHub CI. Нельзя утверждать `CI green`, `tests pass`, `build passes` или `production-ready` до новых логов пользователя. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.58 candidate / цикл 1732

Вход: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`. Задача пользователя: внедрить `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip` как цикл 1732. Patch SHA-256: `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`.

Проверенная применимость patch: 131 изменяемый файл совпал с source SHA текущего HEAD; все 45 новых файлов отсутствовали в `v173.57`; все 176 overlay target SHA совпали до обязательных CANON-adaptation. Overlay = 162 frontend + 14 backend bridge/OpenAPI; standalone/demo/simulation runtime отсутствует.

Функционально перенесён `FRONTEND_v077` production overlay и подключены два недостающих bridge: `GET /auth/profile-photos` поверх verified provider identity metadata текущего `global_id` и `GET /tasks/earnings/me` поверх существующего `task_bonus_log`. Withdraw frontend/backend seam теперь принимает выбранный verified active wallet и сохраняет выбранный адрес; новый wallet lookup адаптирован к string-`global_id` + canonical DB helper. Sale Packages actions подключены к уже существующим service functions; panel lifetime остаётся строго 180 дней; Shop compatibility constructor остаётся alias того же canonical facade.

Current machine surface: `138 OpenAPI paths / 143 operations / 168 schemas / 39 frontend pages`; protected Python/file floor `312 symbols / 58 modules / 68 files`. `GET /meta/health_db` только появился в supplied OpenAPI inventory как уже существующий route current source.

Active NORM adaptation: новые авторские docstring/comments/error messages из patch приведены к русскому инженерному языку; Admin API diagnostics page имеет человекопонятный launcher/title, а raw route/method/JSON остаются только внутри специализированной технической диагностики.

Frontend release artifacts patch не содержал, поэтому они синхронизированы непосредственно по текущим bytes без запуска Node/build/verification scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `public/pwa-build.json` и `release-assets-manifest.json`.

Локальные tests/guards/lint/type/build/Alembic/CI не запускались. Последний exact-head GitHub CI в project evidence — `85157912581` на `v173.56`; exact-head CI `v173.58` обязателен перед любыми утверждениями о qualification. Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

# CURRENT HANDOFF — EFHC Bot v173.57 candidate / цикл 1731

Входной exact-qualified HEAD: `EFHC_Bot_v173_56.zip`, SHA-256 `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`. GitHub CI `85157912581`, checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`, проверил `efhc.zip` размером `11975213` bytes; все canonical gates завершились `exit=0`, pytest: `1502 passed / 22 skipped / 1 warning`.

Цикл 1731 завершает этап 1719–1731 как статический backend/frontend audit + handoff. Runtime/frontend production code в этом цикле не менялся. Current protected floor подтверждён по checked-in source/contract: `135 paths / 140 operations / 38 frontend pages / 312 symbols / 58 modules / 68 files`.

Подтверждённые carry-over задачи, которые **не реализовывались самовольно** в 1731:

1. **Global ID boundary normalization.** Статический AST-аудит production `backend/app/**/*.py` нашёл `375` прямых вызовов `int(...)`, где синтаксис аргумента содержит `global_id`, в `60` файлах. Это не означает 375 независимых runtime-дефектов: каждое место требует классификации как внешняя/service boundary или допустимая физическая BIGINT DB-boundary. Прямое приведение не следует считать каноническим helper; нужна отдельная минимальная миграционная волна по `GLOBAL_IDENTITY_SSOT.md`.
2. **Admin Human Language closure.** Подтверждены видимые технические подписи в `frontend/src/pages/admin/panels.tsx`, `frontend/src/pages/admin/tasks.tsx`, `frontend/src/pages/admin/referrals.tsx` и runtime dashboard-компонентах `AdminOverviewDashboardRuntime`, `AdminPanelsDashboardRuntime`, `AdminTasksReferralsDashboardRuntime`, `AdminObservabilityTimeseriesDashboardRuntime`, `AdminSystemHealthDashboardRuntime`. Нужна отдельная UX/localization волна без изменения API semantics.
3. **Frontend seam review.** В generated `adminSeams.ts` — 66 path constants; 54 имеют прямое именованное использование в текущем TS/TSX source, 12 не имеют прямого constant-name caller. Это **не delete-proof**: compatibility/alias/dynamic use сохраняются до отдельного анализа. Перечень находится в текущем audit-документе.

Документы handoff:
- `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md` — текущий итог цикла 1731 сверху, исторические evidence-разделы ниже сохранены;
- `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md` — current operation/page inventory и protected floor;
- `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md` — этап 1719–1731 закрыт audit/handoff-результатом и содержит carry-over backlog.

Новый кандидат `v173.57` требует следующего exact-head GitHub CI. Нельзя утверждать его CI-green до новых логов пользователя.

---

## Текущая рабочая блокировка — кандидат v173.56 / цикл 1730 continuation

- GitHub CI `85153784574` проверил `efhc.zip` размером `12053999` bytes; размер совпадает с загруженным `EFHC_Bot_v173_55.zip`. Checkout: `f5371d8f896486a2cbffe10584d76e65ebb7d959`.
- SHA-256 входного `EFHC_Bot_v173_55.zip` в рабочей среде: `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`; CI-лог не публикует SHA-256 самого входного `efhc.zip`, поэтому криптографическое равенство payload не утверждается.
- GREEN по предоставленному gate summary: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci и frontend build. FAILED только pytest.
- Pytest: `1 failed / 1501 passed / 22 skipped / 1 warning`; единственный failure — `manifest_sha_mismatch:docs/cycles/WORK_CYCLES_1701-1800.md`.
- Подтверждённая причина: `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv` содержал stale SHA `624741...8601`, тогда как фактический SHA cycle-range документа в v173.55 — `37dfdc83d5040fca169d82c2e2652c2ffeb202928841a8b7f050345139895eb8`. Это manifest drift; runtime/backend/frontend defect данным CI не подтверждён.
- Исправление ограничено cycle history manifest и обязательной current-state/reporting синхронизацией. Business semantics, compatibility surfaces, aliases, migrations и function-preservation floor не меняются.
- Function-preservation floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02259__cycle_1730_exact_head_ci_manifest_drift_followup.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Плановый следующий цикл: `1731 — backend/frontend audit + handoff`; начинать только после exact-head CI кандидата v173.56 без незакрытых failures.

## Текущая рабочая блокировка — кандидат v173.55 / цикл 1730

- GitHub CI `85145865998` проверил `efhc.zip` размером `12046473` bytes; размер совпадает с загруженным `EFHC_Bot_v173_54.zip`. Checkout: `3dd76713f4dea04ebb8d728385eab80f1726e41d`.
- CI-лог не содержит SHA-256 самого `efhc.zip`; принадлежность к `v173.54` дополнительно подтверждается содержимым failures: `TEST_GUARD_MANIFEST.version=v173.54` и новым consolidation document цикла 1729.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci и frontend build. FAILED: Mypy `4`; pytest `3 failed / 1499 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: четыре `no-any-return` на явных `global_id -> BIGINT` DB-boundaries; stale traceability exception list для active plan/consolidation docs; рассинхронизация `TEST_GUARD_MANIFEST` и `IDENTITY_MIGRATION_STATE_CURRENT`.
- String `global_id` contract, решения 1719–1729, compatibility surfaces и alias policy не менялись; нового cleanup не выполнялось.
- Function-preservation floor не изменён: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02258__cycle_1730_exact_head_ci_error_burn_down.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий плановый цикл: `1731 — backend/frontend audit + handoff`; если новый exact-head CI выявит failures, сначала продолжается error burn-down цикла 1730.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущая рабочая блокировка — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.

# ТЕКУЩИЙ HANDOFF — EFHC Bot v173.49 candidate

Завершённый цикл: **1724**. Следующий: **1725 — Admin NFT, VIP и manual claim**.

- Exact-head CI `85001150793` проверил `v173.48`: pytest `2 failed / 1500 passed / 22 skipped`; frontend prebuild остановился на checksum `ru`; Ruff, Mypy, Flake8, Bandit, compileall, Alembic/PostgreSQL и npm ci по предоставленным логам GREEN.
- Подтверждённые CI causes исправлены без расширения scope.
- `/admin/efhc-deposits` объединяет обзор, входящие операции, несопоставленные операции, безопасную повторную обработку, сверку за период и отдельно обозначенное аварийное действие.
- Business owner остаётся `global_id`; `parsed_tg_id` — только provider metadata.
- Произвольная ручная смена финансового статуса запрещена; `pending_manual` исключён из автоматических повторных попыток.
- Active canon: `docs/admin/ADMIN_TON_DEPOSITS_RECOVERY_CANON.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
# CONTINUE IN NEW CHAT — EFHC Bot v173.42

Current completed cycle: **1718**. Next: **1719**.

## Exact evidence

- supplied exact-head CI: `84954546920`;
- exact tested archive: `v173.41`;
- archive size: `12135299` bytes;
- green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build;
- failed gates: Mypy (`2`) и pytest (`17 failed / 1485 passed / 22 skipped`);
- confirmed causes patched in `v173.42`;
- `v173.42` ещё не получил exact-head GitHub CI.

## Function recovery plan

- active plan: `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`;
- `1719–1728`: десять волн исследования и согласования functions/routes;
- `1729`: итоговая decision matrix и только утверждённые изменения;
- `1730`: exact-head CI qualification/error burn-down;
- `1731`: backend/frontend audit handoff preparation.

## Critical locks

- GitHub CI пользователя — единственный application test/qualification contour; ассистент не запускает локальные tests, guards, lint/type/build/Alembic/CI checks.
- `global_id` остаётся единственным business/account/privileged/audit owner.
- BANK и Admin NFT canons неизменны.
- Отсутствие frontend/Python caller не разрешает удалять route/Admin/compatibility/operational surface.
- Удаление в 1719–1729 возможно только после полного Fail-Closed Delete proof и явного решения пользователя.
- Не объявлять `v173.42` PASS/production-ready до exact-head GitHub CI.


## Cycle 1720 current handoff

- Candidate HEAD: v173.44; next cycle 1721.
- Admin Tasks full editor implemented with fail-closed history preservation.
- Admin Ads provider registry/readiness connected separately; secrets remain server-side.
- `tasks_autorestart` is task-lock maintenance; TON time-based payment watcher is `check_ton_inbox/job_ton_watcher`.
- Status: PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED.