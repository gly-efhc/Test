<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.37 — продолжение работы

Статус: **CYCLES 1712–1713 COMPLETED / POST-MIGRATION CLEANUP PATCH / CYCLE 1714 NEXT**

- Exact qualification anchor: `v173.36`, GitHub CI `84923645231`, checkout `cb915ded036615efaec297689787a3a5053a36e0`, blob `7139f9e65515d4fd553fad0872710d72dc842336`.
- CI: all canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: `global_id` ownership migration QUALIFIED.
- Cycle 1713: retired runtime identity/provider owner aliases, hidden `tg_id` business routes, temporary migration-control/dual-write/read-switch code, dead façades/stubs and no-caller compatibility modules removed.
- Provider boundaries retained only where canonical: Telegram ingress/delivery, TON provider identity, stored memo/deposit/idempotency read-through.
- Current package: `v173.37`; exact-head CI required because cleanup changes runtime/schema.
- Next cycle: `1714 — Alias cleanup qualification`: stale tests/guards/tooling/generated contracts + fresh exact-head CI.
- GitHub CI/full local pytest/frontend build must not be launched locally.
