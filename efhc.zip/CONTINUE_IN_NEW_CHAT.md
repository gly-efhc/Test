# Продолжение EFHC после v172.66

## Единственный HEAD

`EFHC_Bot_v172_66.zip`

Релизный архив: `EFHC_Bot_v172_66_RELEASE.zip`.

## Обязательный канон работы с пользовательскими CI-логами

Если пользователь лично предоставляет полный архив CI-логов,
запрещено тратить время на глупые, бессмысленные и дублирующие
локальные прогоны CI. Нужно работать непосредственно по этим логам:
определить первопричины, исправить все подтверждённые ошибки,
выполнить только короткие точечные проверки изменённого контура и
сразу собрать следующую версию. Полную квалификацию подтверждает
следующий exact-head GitHub CI пользователя.

Запрещены без доказанной необходимости:

- полный локальный CI или полный pytest;
- разбиение всего проекта на test-shards;
- повтор этапов, уже зелёных в переданном run;
- frontend build, если frontend не падал;
- общие проверки «на всякий случай».

Источник правила:
`docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md`.

## Что выполнено

- exact `v172.65` CI разобран до корневых причин;
- повреждающий механический codemod не латается по 181 симптому, а
  пересобран поверх рабочего ядра `v172.64`;
- результаты циклов 1641–1646 и canonical `global_id` ownership
  сохранены;
- временный `global_owner_alias.py` и полный аудит `tg_id` сохранены;
- введён baseline: legacy-слой может только уменьшаться, новые файлы с
  `tg_id` запрещены;
- бизнес-сервисы продолжают использовать canonical `global_id`;
- Telegram provider ingress и историческая совместимость изолированы;
- public visual, Admin UX, screenshot workflow и canonical CI не
  менялись.

## Почему пересобран v172.65

Массовый текстовый codemod заменил семантически разные provider-поля и
business-owner поля одинаковым именем `global_id`. Это создало duplicate
arguments, повреждённые SQL и DTO, Mypy/Ruff/Bandit ошибки,
frontend type conflicts и 181 pytest failure.

Исправление выполняется по методу первых identity-циклов:

1. рабочее canonical-ядро;
2. единый alias-harness;
3. машинный baseline всего legacy-слоя;
4. постепенное уменьшение baseline после exact CI;
5. окончательное удаление aliases после полного PASS.

## Следующая работа

1. Запустить exact `v172.66` main CI.
2. Исправить все PostgreSQL, pytest, Ruff, Flake8, Mypy и Bandit ошибки.
3. Подтвердить Telegram/TON-only equivalence, idempotency и concurrency.
4. Уменьшать compatibility baseline только при подтверждённом отсутствии
   runtime-callers.
5. После полного PASS удалить alias-harness, ORM synonyms, deprecated
   routes и historical compatibility tails.

## Запрещено

- выполнять production cutover без отдельной команды;
- возвращать `tg_id` в business ownership;
- выполнять новый слепой текстовый codemod;
- менять public visual, Admin UX, screenshot workflow или canonical CI;
- объявлять runtime PASS до fresh exact-head CI.

## Сохранённый schema freeze

Историческое доказательство цикла 1632 и базовая миграция
`0001_initial_release_schema.py` сохраняются. Текущая lineage:
`0001 → 0002`. Exact квалификация выполняется неизменённым GitHub CI.
