# AGENTS — FRONTEND ONLY

Любой агент в этом архиве обязан работать по `START_HERE.md` и `docs/AI/FRONTEND_ARCHIVE_LAWS.md`.

Основной `EFHC_Bot_*` archive — read-only contract source. Writable authority — только frontend HEAD. Не изменять backend без прямой owner authorization. Production и standalone синхронизировать и тестировать отдельно. Все owner-visible изменения проходят EAM. Все monetary UI semantics — D8 exact. Patch для основного кода — только по прямой команде владельца.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Постоянное прямое правило OWNER: ни один ENV-файл проекта нельзя удалять без прямого решения OWNER.** Это включает `.env`, `.env.*`, production/development/local profiles, templates/examples, recovery copies и будущие ENV-файлы. Удаление+создание замены, потеря исходного пути при migration/refactor/cleanup/release/update и объявление файла legacy не являются разрешением. `.gitignore`, security concern и наличие defaults также не разрешают удаление.

Cycle0447 прямо разрешает восстанавливать отсутствующие подтверждённые несекретные settings и исправлять их конфликт с OWNER canon в существующей ENV-архитектуре. Существующие значения сохраняются без основания для изменения; секреты не менять, не публиковать и не угадывать. **Application configuration values, numeric settings, public URLs and public blockchain addresses are NOT project secrets.** **EFHC Bank address is public canonical project data and must not be deleted.**

Публичный SSOT: `TON_MAIN_WALLET=UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW` — EFHC Bank / Банк EFHC. Payment receiver не должен создавать другой project-wallet canon. Изменения Cycle0447 выполняются commit/PR, без physical release по прямой OWNER-команде. Существующая fail-closed защита physical mirror остаётся действующей; нового approval/governance-слоя нет. Простой Git deletion guard проверяет потерю ENV-файла, без контроля количества ключей.

Подтверждённая несекретная configuration восстановлена из текущего кода/public profiles/templates. Исторический incident неизвестных утраченных runtime/secret values остаётся `RECOVERY_REQUIRED`: они не объявляются восстановленными. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; physical mirror policy: `release_config/ENV_OWNER_PROTECTION.json`; единственный secret-free ENV canon: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

