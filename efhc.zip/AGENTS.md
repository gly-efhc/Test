<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_TON_PROVIDER_SUBJECT_CANON_V173_23 -->
TON provider subject: `ton_wallet_id` = адрес TON-кошелька. `ton_address` не
является provider-subject alias; generic storage `provider_subject` для
`provider=ton` содержит значение `ton_wallet_id`.

# Обязательное правило пользовательских CI-логов

Если пользователь передал полный архив CI-логов, запрещены полный
локальный CI, полный pytest, test-shards и повторы уже зелёных этапов
без доказанной необходимости. Нужно исправлять failures из переданных
логов, выполнить только короткие точечные проверки и сразу собрать
следующую версию.

Полный канон:
`docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md и docs/AI/TOPIC_READING_ROUTES.md`.

---

# Текущий статус v172.52 — циклы 1636–1637

Fresh GitHub CI `83405061075` проверил exact
`EFHC_Bot_v172_51.zip` размером `12650102` байта. PostgreSQL,
единая migration `0001`, production frontend build и все `102`
route-backed Chromium checks прошли. Красный итог вызвали только
`13` статических/документных pytest guards, один Ruff import-order
finding и один Mypy return-type finding. Runtime, schema, auth и
financial regression не подтверждены.

Цикл `1636` квалифицирован реальным PostgreSQL-прогоном ядра.
В `v172.52` выполнен цикл `1637`:

- Telegram Bot `/start` создаёт новый account только через
  `AccountRegistrationService`;
- raw SQL вставка `users` из referral onboarding удалена;
- `User`, immutable `ReferralLink` и Telegram `UserIdentity`
  создаются атомарно в одной транзакции;
- invalid/missing referral отклоняется до создания account;
- существующий пользователь, включая permanent `0 user`, не может
  получить позднюю referral-привязку;
- WebApp и TON callers не переключались и остаются scope цикла `1639`;
- migration, schema, экономика и шесть нижних маршрутов не менялись.

Visual gate exact `v172.51` прошёл `102/102`, но переданный архив
`ci_artifacts (3).zip` не содержит PNG. Поэтому пользовательская
visual acceptance follow-up цикла `1635` остаётся открытой.

```text
CURRENT_HEAD_V172_52
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_IMPLEMENTED
CYCLE_1637_EXACT_HEAD_CI_REQUIRED
CYCLE_1638_NOT_STARTED
CYCLE_1639_NOT_STARTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---
# Актуализация qualification boundary — v172.39

Fresh CI exact v172.38 прошёл PostgreSQL, Alembic, static, build и
Chromium, но archive filename hygiene выявил mojibake. v172.39
восстанавливает 28 русских имён и исправляет development ZIP builder.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Не создавать migration `0013` и не начинать cycle `1631` до полного
зелёного exact-head CI v172.39.

---

# Актуализация qualification boundary — v172.38

Fresh CI exact v172.37 выявил шесть pytest current-head findings и
`51` admin marker failures. v172.38 исправляет только эти доказанные
расхождения. Local browser proof разрешён исключительно при
`navigator.webdriver` и localhost; production admin authorization
остаётся fail closed на backend.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Не создавать migration `0013` и не начинать cycle `1631` до полного
зелёного exact-head CI v172.38.

---

# Актуализация qualification boundary — v172.37

Fresh exact-head CI v172.36 прошёл все gates, кроме route-backed
Chromium: `51` admin marker failures при HTTP `200` и без browser
errors. Corrective v172.37 меняет только client admin guard: решение
разрешено после завершения Telegram identity bootstrap. Physical rename,
financial semantics, migrations и universal CI не меняются.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.36

Fresh exact-head CI v172.35 доказал cross-provider Chromium session
proof, но общий canonical job остался красным из-за route-backed CSP,
expected-status/admin-build findings и stale historical CI assertions.
Corrective v172.36 не начинает physical rename. До fresh full PASS
цикл `1631` запрещён. Canonical CI hash:
`8c69eca26bc59330e059fb04da9cf2ea43fc7405c048d1196ea06547fe6c9496`.

---

# Актуализация qualification boundary — v172.35

Fresh exact-head CI v172.34 реально запустил Chromium, но audit завершил
работу `exit=1`; поэтому цикл `1631` заблокирован. Corrective v172.35
меняет только test/evidence harness, stale contracts, Ruff и однократно
обновлённый универсальный canonical CI. Production ownership, financial
semantics и migrations не меняются.

```text
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.34

Fresh exact-head CI v172.33 не закрыл цикл `1630`: PostgreSQL/API
negative contract получил wrong DB input profile, а Chromium proof был
пропущен. Corrective v172.34 исправляет только evidence/test harness,
stale contracts и Ruff. Production ownership, financial semantics,
migrations и CI workflows не меняются. Цикл `1631` не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация cross-provider session boundary — v172.33

Current HEAD: `EFHC_Bot_v172_33.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin business API требуют server-side Bearer
session. Raw Telegram `initData` допускается только как credential для
явного `/auth/telegram/session`, а не как business-auth fallback.
Canonical owner остаётся `global_id`; internal legacy `tg_id` selector
до `1631` разрешён только после session → global_id resolution.
Financial write semantics, precision, idempotency и formulas не менялись.
Цикл `1631` не начат. SSOT имеет приоритет при конфликте канона.

---

# Актуализация session-first ownership — v172.32

Current HEAD: `EFHC_Bot_v172_32.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin API используют server-side Bearer
session как primary transport и canonical `global_id` как owner.
Legacy Telegram transport остаётся измеряемой compatibility-веткой.
Frontend owner cache использует `GlobalId`. Financial write semantics,
precision, idempotency и formulas не менялись. Cycle `1630` не начат.
SSOT имеет приоритет над техническими заданиями при конфликте канона.

---

# Актуализация identity ownership — v172.31

Current HEAD: `EFHC_Bot_v172_30.zip`. Alembic head `0011`. Financial read switch использует `global_id`; legacy writes, dual-write, precision, idempotency и formulas неизменны. Cycle `1628` не начат. SSOT имеет приоритет над техническими заданиями при конфликте текущего канона.

---

# Активный scope v172.29

Текущий development HEAD: `v172.29`. Scope — corrective qualification
цикла `1626`. Alembic head `0010`; `0011` отсутствует. Financial shadow
validation обязана получить real PostgreSQL proof до начала `1627`.
Production financial runtime и CI workflow менять нельзя.

---

# Активный scope v172.28

Текущий development HEAD: `v172.28`. Fresh CI `83121417737`
квалифицировал real PostgreSQL `0010`. Текущий package scope — цикл
`1626`, financial shadow validation. Alembic head `0010`; `0011`
отсутствует. Validation read-only; financial read switch и цикл `1627`
не начаты. CI workflow менять нельзя.

---

# Активный scope v172.27

Текущий development HEAD: `v172.27`.
Fresh CI `83098311619` квалифицировал PostgreSQL `0009`.
Текущий package scope — цикл `1625`, non-financial read switch.
Alembic head `0010`; `0011` отсутствует.
Legacy writes и dual-write остаются authoritative transition path.
Financial read switch и цикл `1626` не начаты.

---

# EFHC — активные правила работы

Текущий development HEAD: `v172.26`. Источник кода — только актуальный
development archive. Release и matrix деревья не используются как source.

Текущий scope — corrective qualification цикла `1624`. Fresh CI
`83093436890` подтвердил critical PostgreSQL blocker Alembic `0009`:
telemetry view содержала CTE после `UNION ALL`, что PostgreSQL отвергал.

Канон identity:

- `global_id` — единственный account owner;
- `tg_id`, wallet address и provider subject — provider data;
- физический owner FK — `users.global_id`; прежняя стадия до 1631 историческая;
- отдельная физическая `users.global_id` запрещена;
- legacy runtime ownership остаётся authoritative.

Alembic head: `0009`. `0010` отсутствует. В `v172.26` исправляется
только exact CI corrective scope цикла `1624`; read switch и цикл `1625`
запрещены до fresh exact-HEAD qualification.

GitHub workflow менять нельзя. Полный regression, PostgreSQL, Docker,
frontend production build и Chromium локально не запускаются.

## Compatibility anchors

- AI_ARCHIVE_LAWS
- AI_OPERATOR_RULES_EFHC
- AI_AGENT_SKILLS_EFHC_ADAPTER
- SSOT_INDEX
- ARCHITECTURAL_LOCKS
- Never claim GitHub CI green from local checks
- This compatibility file does not define a second reading order.
