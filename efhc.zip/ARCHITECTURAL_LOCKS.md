## Цикл 1722 — Referral/Ranks отложены до frontend merge — кандидат v173.46

- Referral/Ranks backend contracts сохраняются без изменения semantics.
- Текущий отсутствие frontend caller не разрешает удалять `/ranks/referrals/my-plus-top/me` или `/ranks/referrals/top/me`.
- Полный Referral/Ranks frontend существует в отдельном frontend-контуре пользователя и будет согласован при последующем объединении frontend.
- Статус группы: `DEFERRED_TO_FRONTEND_MERGE`.
- В цикле 1722 разрешён только exact CI repair подтверждённых regressions `v173.45`; инициативный referral/ranks cleanup запрещён.
- Release/ops scripts остаются protected operational surface.

## Цикл 1721 — блокировка сохранности Shop — кандидат v173.45

- Утверждённые пользователем функции Shop являются одной защищённой capability: Admin Editor + внешняя Browser Shop + профиль + заказы + recovery + history.
- Business owner — только `global_id`; старое Shop ownership через `tg_id` возвращать запрещено.
- История товарной карточки и история заказов являются fail-closed поверхностями сохранности.
- Force Fulfill не имеет права повторно начислять уже исполненный EFHC-заказ и обязан использовать BANK/idempotency.
- `/items/set-price` остаётся compatibility API над canonical Shop model; отсутствие отдельного UI не является разрешением на удаление.
- Release/ops scripts остаются защищёнными и не входят в Shop refactoring.
- Для квалификации обязателен exact-head GitHub CI; локальные application tests/builds/guards не запускались.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Cycle 1718 exact-head CI repair + function recovery plan lock — v173.42

- GitHub CI `84954546920` проверил exact archive `v173.41` (`12135299` bytes).
- Green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build.
- Failed gates: Mypy (`2` no-any-return) и pytest (`17 failed, 1485 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: Admin facade typing, Account Registration ordering по active SSOT, stale final-cutover test contracts/fixtures, payment watcher injection contract и новые нарушения Russian engineering language policy.
- Retired `tg_id` ownership, `users.tg_id` fallback, migration-control/read-switch layers не возвращены.
- Подтверждён packaging defect `v173.41`: восстановлены executable modes `50` release/ops scripts и `28` Unicode historical report filenames с неизменным содержимым.
- Создан active план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: 1719–1728 — 10 волн согласования; 1729 — consolidation; 1730 — exact-head CI qualification; 1731 — frontend/audit handoff preparation.
- Локальные application tests/builds/guards/CI не запускались.
- Статус `v173.42`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1719 — Admin Observability и Reports: исследование и согласование`.

## Cycle 1717 exact-head CI + extended function preservation lock — v173.41

- GitHub CI `84948550953` проверил exact archive `v173.40` (`12124946` bytes), checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Failed gates: Ruff (`1` I001) и pytest (`45 failed, 1456 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes; stale final-cutover test contracts не используются для возврата retired `tg_id` ownership/migration-control layers.
- Подтверждённый payment compatibility loss восстановлен на `global_id`: wallet `_confirm_payment_intent`, bank-credit facade и watcher/reconciliation injection seam; external-shop reason приведён к размеру DB-поля.
- По прямому ТЗ продолжен `v171.89` Admin/function/routes/docs audit: восстановлены safe Admin MAIN/BONUS credit facades и NFT-maintenance compatibility wrappers; старые tg-owned Admin CRUD/security authorities не возвращены.
- Active function registry расширен до `259` symbols / `44` modules / `14` required files. Расширенный control test локально **не запускался**.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.41`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1718 — exact-head CI follow-up`.

## Cycle 1716 exact-head CI + function preservation audit lock — v173.40

- GitHub CI `84942802763` проверил exact archive `v173.39` (`12095859` bytes), checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Failed gates: Ruff (`3` I001) и pytest (`61 failed, 1307 passed, 22 skipped, 130 errors`).
- Массовый pytest setup-cluster подтверждён stale test references к retired `efhc_core.identity_migration_control`; production schema не откатывалась, потому что final global_id cutover и GREEN Alembic/PostgreSQL подтверждают retirement transition table.
- По прямому ТЗ пользователя выполнен historical function-preservation audit against `v171.89`, Admin/routes/docs audit и создан fail-closed application function surface manifest + CI control test. Контрольный тест локально **не запускался**.
- Safe compatibility entrypoints восстановлены только там, где они делегируют current canonical implementation и не возвращают `tg_id` ownership. Legacy tg-owned Admin CRUD/migration compatibility не восстанавливалась.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.40`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1717 — exact-head CI follow-up.


## Cycle 1715 exact-head CI repair lock — v173.39

- GitHub CI `84940689623` проверил exact current archive `v173.38` (`11816383` bytes), checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`.
- Green gates на `v173.38`: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` collection errors; test execution не началось).
- Cycle 1715: исправлены только эти подтверждённые причины. Ruff patch ограничен import ordering/placement; четыре CI-failed test locations минимально переведены на уже действующие canonical `global_id`/idempotency interfaces. Retired migration read-switch/control wrappers в production не возвращались.
- Локальные test/lint/type/build/Alembic/CI проверки не запускались. Статус `v173.39`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1716 exact-head CI follow-up.

## Post-migration qualification lock v173.37 / циклы 1712–1713

- GitHub CI `84923645231` проверил byte-exact Development archive `v173.36`.
- Checkout SHA: `cb915ded036615efaec297689787a3a5053a36e0`.
- `efhc.zip`: `11877960` bytes; Git blob SHA-1 `7139f9e65515d4fd553fad0872710d72dc842336` совпадает с локальным `EFHC_Bot_v173_36.zip`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: ownership migration квалифицирована: `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS, exact-head CI GREEN.
- Cycle 1713: выполнен post-migration runtime cleanup. Retired business `tg_id` routes/switches, dual-write/read-switch infrastructure, dead aliases/stubs/test façades и no-caller compatibility modules удалены.
- Сохранены только доказуемые внешние/исторические boundaries: Telegram provider ingress/delivery, TON memo/deposit read-through, historical idempotency replay и bounded stored-data compatibility.
- `v173.37` содержит cleanup patch и требует нового exact-head GitHub CI. Следующий цикл: `1714 — Alias cleanup qualification`.

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Текущий Alembic head `0010`; `0011` отсутствует.
Цикл `1627` запрещён до exact-head real PostgreSQL qualification
financial shadow validation `1626`. Денежные значения, precision и
idempotency не изменяются.

---

# Актуальные блокировки v172.28

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует. Cycle `1626` — только
read-only financial shadow validation. Денежное расхождение должно быть
`0.00000000`; Numeric precision/scale и idempotency semantics неизменны.
Financial read switch запрещён до `1627` и fresh exact-HEAD proof.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# Актуальные блокировки v172.27

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует.
Non-financial reads могут переключаться на `global_id` только при
нулевой telemetry. Legacy writes и dual-write остаются активными.
Financial reads, precision и formulas запрещено менять в `1625`.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# ARCHITECTURAL LOCKS

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими заданиями.

При конфликте требований приоритет имеют действующие architectural locks,
машинные guards и фактический production code; новое ТЗ не отменяет их
неявно и должно изменять канон только отдельным зафиксированным решением.

# EFHC — активные архитектурные блокировки

Текущий пакет: `v172.26`.

Жёстко зафиксировано:

- `global_id` — главный и постоянный account owner;
- `users.user_id` удалён; физическое имя — `users.global_id`;
- отдельная физическая `users.global_id` рядом запрещена;
- Alembic head `0009`, migration `0010` отсутствует;
- legacy runtime ownership остаётся authoritative;
- dual-write conflict/orphan должен завершаться fail closed;
- telemetry только наблюдает shadow state и не делает read switch;
- financial values/precision/idempotency не меняются;
- цикл `1625` запрещён до fresh qualification `v172.26`;
- migration squash запрещён до `1632`;
- CI workflow нельзя менять без прямой команды пользователя.

SSOT имеет приоритет над отдельными техническими заданиями при их
противоречии, если пользователь прямо не изменил канон.

## Security/audit ownership lock v173.24

Privileged действия, server-side admin session и audit ownership используют `global_id` end-to-end. Telegram/TON/другие provider subjects не могут быть privileged owner. Финансовый owner Admin Bank — `global_id`; `tg_id` допускается только для provider delivery/исторического read-through, который не создаёт новый ownership.

## SuperAdmin account reservation v173.27

- `global_id=1313131313` зарезервирован для SuperAdmin EFHC.
- Обычная account registration не имеет права выдавать этот ID.
- Provider ID не даёт SuperAdmin privilege; требуется whitelist + explicit RBAC.
- VIP/NFT не является admin credential.

## Release scripts protection lock — cycle 1719

Release/ops scripts являются защищённым operational surface. До завершения code phase без прямого ТЗ пользователя или конкретного GitHub CI evidence запрещено удалять, переименовывать, реконструировать, упрощать, массово форматировать эти scripts либо менять/терять их executable mode. Автоматические RELEASE/MATRIX archives не создаются. Финальные release archives готовятся после завершения работы с кодом по отдельному решению пользователя.

## Admin Reports/Observability decision lock — cycle 1719

`GET /admin/observability/events` сохраняется только как compatibility stub с причиной `disabled_duplicate` и replacement `/admin/logs/transfers`. Пять domain report routes (`users`, `bank`, `panels`, `withdrawals`, `deposits`) являются действующими Admin capabilities и подключаются к Admin Reports UI. Users ownership — только `global_id`; BANK — только `system_entity=BANK_EFHC` и `bank_balance.key=EFHC_MAIN`.


## ADMIN TASKS EDITOR PRESERVATION LOCK — cycle 1720

- `POST/GET/PATCH/DELETE /admin/tasks[/... ]`, submissions, moderation и maintenance boundary являются защищённой Admin surface.
- Основное удаление задания — деактивация. Physical delete разрешён только при отсутствии submissions, user status, bonus log и completion locks.
- Task `code` после появления истории неизменяем через Admin Editor.
- `tasks_autorestart` и TON `check_ton_inbox` — разные scheduler capabilities; объединять или удалять один как дубль запрещено без отдельного доказательства.
- Admin Ads остаётся отдельным provider contour; секреты ENV не переносятся в браузер.


## REFERRALS / RANKS FRONTEND INTEGRATION LOCK — cycle 1722 continuation

- `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` — защищённая пользовательская frontend capability.
- Ranks сохраняет два независимых mode: `kwh` и `referrals`; их React Query cache keys нельзя объединять.
- Используются только существующие backend routes; новые дублирующие referral/rank endpoints без прямого ТЗ запрещены.
- `global_id` разрешён только как внутренний owner/key и не показывается пользователю вместо username/privacy fallback.
- Referral link, bonus asset, Lvl 1–5 и списки поступают только из реального backend. Mock/offline/demo/simulation данные запрещены.
- Пять social share assets и общие `StatusIndicator`/`BonusEarningsStrip` являются частью сохранённой capability.
- Удаление этих routes/pages/components только из-за отсутствия caller в отдельной сборке запрещено.
