## Текущая точка — кандидат v173.87 / цикл 1753 — Audit 8 Backup/DR hardening

- Входной Development HEAD `EFHC_Bot_v173_86.zip`: SHA-256 `2322d2e0799fd505e2c4fe56e329bdee4b5a9893a2a98cbc6e35c279d6aa7c4f`, размер `12549983` bytes, `4612` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Новые exact-head GitHub CI-логи для входного `v173.86` в текущем наборе файлов отсутствуют. Доступный `logs_85980628163.zip` относится к ранее квалифицированному `v173.85` и не используется как verifier `v173.86`.
- Цикл `1753` выполняет пересмотренный owner-authority Audit 8 по Autonomous DevOps / Backup / Restore / Disaster Recovery. Подтверждены и исправлены A8-R1…A8-R7: fixed newest-10 local generations, isolated restore drill, fail-closed backup-key lifecycle, manual encrypted Telegram recovery path, backup-aware status, attempts-bounded retry и post-reboot boot timer.
- Canonical backup generation теперь имеет один encrypted recovery artifact: тот же ciphertext сохраняется локально и отправляется владельцу в Telegram; raw dump и незашифрованный bundle являются staging-only material. Telegram outage не расширяет local spool сверх newest 10.
- Production application/backend/frontend/OpenAPI/schema/ORM business surface не изменён. Единственный Alembic head остаётся `0001_initial_release_schema.py`; ORM `56`; canonical `users.global_id` FK floor `42`; PATCH_002 visual/text authority не затронут. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; static test inventory `272 architecture / 452 Python files`.
- Добавлены CI-only guards в существующий architecture test file; локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Выполнена только разрешённая статическая source/AST/manifest/ZIP проверка.
- Candidate `v173.87` требует следующий exact-head GitHub CI. При failures продолжается цикл `1753`; к циклу `1754` переходить только после qualification `v173.87`.

## Текущая точка — кандидат v173.86 / цикл 1752 qualification — exact-head CI v173.85 green

- Входной Development HEAD `EFHC_Bot_v173_85.zip`: SHA-256 `82886c32e62c2d3a2f6e61e8589361036353bff09ec4fff1589d962939029f0e`, размер `12724012` bytes, `4611` ZIP entries; локальная ZIP integrity проверка успешна, duplicates `0`.
- Supplied GitHub CI `85980628163` для `v173.85`: checkout `53f7fc88f92bbc7bb176546122350347b1352c0a`; CI `efhc.zip` имеет размер `12724012` bytes. SHA-256 CI payload в предоставленных логах не опубликован.
- Gate summary полностью успешен: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight, pytest и Ruff имеют `exit=0`. Pytest: `1578 passed / 22 skipped / 1 warning`; Ruff: `All checks passed`; Mypy: `344 source files` без issues; Alembic: `metadata_tables=56`, `0001: ok`; frontend build verify: `PASS`.
- Подтверждённых CI root causes нет; production/backend/frontend/schema/test semantics не меняются. PostgreSQL логи содержат ожидаемые negative-path constraint errors из тестовых сценариев, но gate/pytest завершены успешно, поэтому они не классифицируются как failures.
- Цикл `1752` квалифицирован по входному `v173.85`. Следующий numbered functional cycle — `1753`; его scope в active SSOT не задан и в этой итерации не начинается.
- Этот `v173.86` содержит только qualification/traceability updates и immutable report; functional SSOT/CANON, OpenAPI, ORM и PATCH_002 visual/text authority не изменены. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; canonical `users.global_id` FK floor `42`; static tests `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Новый `v173.86` требует exact-head GitHub CI как новый архив.

## Текущая точка — кандидат v173.85 / цикл 1752 continuation — exact-head CI burn-down v173.84

- Exact-head GitHub CI `85947769920` квалифицирован для входного `v173.84`: checkout `2a7e9d6d1fe2c3fb89b3664246bfd048c36cf046`, CI archive `12537062` bytes. Единственный failing gate — pytest: `4 failed / 1574 passed / 22 skipped / 1 warning`; Alembic/PostgreSQL, Ruff, Mypy, Bandit, compileall, Flake8 critical/full, npm ci и frontend build успешны.
- Два schema failures — stale integration constants `EXPECTED_FK_COUNT=41`; current `0001` и active release state канонически имеют `42` FK на `users.global_id`. Оба expectations синхронизированы на `42`.
- Первый referral failure — stale lookup ненумерованного `REF_ACT_UNIT` и неверного owner в fixture; expectation синхронизирован с canonical inviter-owned `REF_ACT_UNIT:G{inviter_global_id}:N00001`.
- Второй referral failure — boundary fixture создавал `9999` active referrals напрямую, но не моделировал уже закреплённые slots `1..9998`, поэтому allocator корректно начинал с `N00001`. Fixture теперь моделирует prior slot ownership `1..9998`, после чего проверяет `N09999`, `N10000` и отсутствие slot у `10001`-го active referral.
- Production/runtime/DevOps/referral economics не изменялись. Независимые `REF_ACT_UNIT`, `REF_LVL` и нефинансовый Rankings CANON сохранены. ORM floor `56`; global owner FK floor `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.85` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.85` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.84 / цикл 1752 continuation — exact-head CI burn-down v173.83

- Exact-head GitHub CI `85940762760` квалифицирован для входного `v173.83`: checkout `f0456d329f84ed1cd6183c2297188a7e3f626aa2`, CI archive `12529560` bytes. Failing gates: Alembic, Ruff и pytest; Mypy/Bandit/compileall/Flake8/frontend gates успешны.
- Alembic root cause: после Audit 7 таблица `ad_provider_claims` добавила ещё один canonical FK на `users.global_id`, поэтому фактический count `42`, а `0001` validator и его static contract guard оставались на `41`.
- Ruff root cause: только `I001` в новом DevOps architecture guard.
- Независимые pytest drifts: provider-portability gate всё ещё ожидал прямой predeploy `backup_postgres.sh` вместо current `telegram_backup_delivery.sh`; daily backup test ожидал прямой `backup_bundle.sh` вместо delegated Telegram chain; referral Lvl fixture не предоставлял `db.scalar()` для historical key read-through; `INSTALL.md` потерял явный literal `chmod 600`. Остальные DB failures/errors являются следствием failed Alembic setup из supplied run.
- Все подтверждённые причины исправлены без изменения DevOps safety model, referral economics или Audit 7 runtime semantics. ORM floor остаётся `56`; global owner FK floor current `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.84` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.84` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.83 / цикл 1752 — Autonomous DevOps + exact-head CI burn-down

- Exact-head GitHub CI `85876332157` квалифицирован для входного `v173.82`: checkout `78ac7c355be6cc9f6c8215baa647a31960658a27`, CI archive `12480201` bytes. Ruff/Mypy/Bandit/compileall/Flake8/frontend gates успешны; Alembic падает на stale `EXPECTED_TABLE_COUNT=55` при canonical ORM floor `56`, что порождает каскад DB pytest errors. Независимые pytest drifts: Audit-6 revoke SQL literal, Ranks marker, test/current-state version и referral numbered-slot fixture.
- Все подтверждённые CI root causes исправлены без отката Audit 7: database contract = `56`, stale guards/fixture синхронизированы с active CANON.
- Цикл 1752 реализует repository/release часть autonomous DevOps: encrypted Telegram backup, local Bot API integration, status/autopilot/diagnostic, daily/weekly/monthly/post-reboot timers, external-monitor artifact, ENV preflight и safe host prerequisites. Фактическая установка на production/external VPS в этом чате не выполнялась — доступа к VPS нет.
- Referral economics закреплена тремя независимыми контурами: `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`, `REF_LVL:G{inviter_global_id}:L{level}` и нефинансовый referral/ranking display. Historical Lvl keys сохраняются только для idempotent read-through.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.83` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.83` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.82 / цикл 1751 — Unified Deep Audit 7

- Exact-head GitHub CI `85849626798` квалифицировал входной `v173.81`: checkout `ab5591d411da6d87591459f6350b0de0f91189fb`, CI archive `12464501` bytes. Failing gates: Ruff `UP012`, Bandit `B608`, pytest `1 failed / 1566 passed / 22 skipped / 1 warning`; остальные supplied canonical gates завершились успешно.
- Все семь findings A7-R1…A7-R7 подтверждены по current source/SSOT/CANON и исправлены: Energy delta parity; ADS provider single-claim; Admin/Public Tasks atomicity; numbered referral slots; полный paged Ranks + direct find-me; progression-only Skins fail-closed legacy commerce.
- Exchange lifetime model не менялась: `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `271 architecture / 451 Python files`.
- Единственный Alembic head остаётся `0001_initial_release_schema.py`; новая ADS claim table входит в pre-release `Base.metadata.create_all()`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.82` требует exact-head GitHub CI.
- Следующий утверждённый функциональный scope после qualification — цикл `1752`, настройка окружения/автономного DevOps-контура по `EFHC_DevOps_TZ.md`.

## Текущая точка — кандидат v173.81 / цикл 1750

- Exact-head GitHub CI `85840461388` полностью квалифицировал входной `v173.80` (`12452133` bytes, checkout `3a80d8c8f85feff263771ebd0b3c33567d971f1e`); pytest `1563 passed / 22 skipped / 1 warning`, остальные supplied canonical gates `exit=0`.
- Audit 6 A6-01…A6-03 подтверждены по source/SSOT/CANON и исправлены: inactive-account session/RBAC/handoff kill-switch, JWT expected audience, bounded fail-closed TON challenge issuance/cleanup.
- Protected/API/ORM/frontend floor не изменён: `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- После patch локальные tests/CI/guards/build/Alembic/PostgreSQL не запускались. Candidate `v173.81` требует exact-head GitHub CI.
- Следующий функциональный цикл после qualification: `1751`; CI failures нового HEAD имеют приоритет над следующим audit scope.

## Цикл 1749 continuation — exact-head CI locks для v173.79

1. CI `85837515925` квалифицирует только входной `v173.79`: checkout `8c63e2261e39445022f1c18eef2738667fe6bf8c`, archive size `12447211` bytes.
2. Единственный failing gate — pytest с двумя служебными drift: Russian Engineering Language NORM и version mismatch `TEST_GUARD_MANIFEST`.
3. Runtime, Audit 5 VIP/NFT, frontend visual/text, OpenAPI, ORM и financial/security semantics не изменяются.
4. Candidate `v173.80` требует отдельного exact-head GitHub CI; результаты `v173.79` нельзя переносить на новый HEAD.
5. Следующий номер цикла после закрытия 1749 — `1750`.

## Цикл 1749 — exact-head CI locks после Audit 5/10

1. CI `85806294354` квалифицирует только входной `v173.78` и подтверждает два failing gates: Ruff `SIM102` + один archive-hygiene pytest failure.
2. CI repair не даёт права менять VIP/NFT runtime: Audit-5 semantics остаются защищёнными.
3. CI-only guard разрешено форматировать без изменения assertions; active CANON не должен содержать служебные numbered work-pass labels вне разрешённых traceability слоёв.
4. Production/backend/frontend/OpenAPI/ORM surface в цикле 1749 не изменяется.
5. Новый `v173.79` требует отдельного exact-head GitHub CI; результаты входного `v173.78` нельзя переносить на него.

## Цикл 1748 — VIP / NFT security & economy locks

1. Exact-head CI `85731080653` является green evidence только для входного `v173.77`; новый `v173.78` требует отдельного exact-head CI.
2. VIP — derived state только из подтверждённого NFT ownership: целевая collection учитывается лишь при `NftAsset.verified == True`.
3. Для одного `global_id` проверяются **все** active verified TON wallet bindings; VIP и Admin NFT агрегируются через `any(...)`, а primary wallet не имеет исключительного NFT authority.
4. Удаление одного кошелька не снимает VIP, пока существует другой допустимый verified binding или legacy fallback; удаление последнего source обязано в той же transaction выставить `is_vip=FALSE`, `vip_since=NULL`, обновить `vip_checked_at`.
5. Batch reconciliation обязан лечить stale `users.is_vip=TRUE` без допустимого wallet source.
6. `scheduler_tick_check_vip_nft()` вызывает полный NFT/VIP проход ровно один раз за тик. Внешний scheduler timeout не является механизмом завершения нормального прохода.
7. `admin_nft_whitelist` остаётся derived cache; право Admin NFT возникает только из фактической проверки любого active verified TON identity и текущего `TON_ADMIN_NFT_IDS`.
8. Frontend visual/text PATCH_002, экономика EFHC и Audit 4 security boundaries не меняются.

## Цикл 1746 — Audit 4/10: security/withdraw transaction locks

- `client public_key` никогда не является authority владения TON address. Wallet binding требует authoritative state-init resolution и совпадение network/address/public key; unresolved authority fail-closed.
- `process_efhc_deposit()` и его idempotency helpers не имеют права выполнять commit. Emergency settlement + Bank credit + required Admin audit фиксируются одним root commit.
- Withdrawal hold/refund repair: current row повторно блокируется `FOR UPDATE` до money primitive; один financial idempotency key всегда использует один canonical `reason` (`withdraw_hold` или `withdraw_refund`).
- Admin withdrawal PAID/REJECTED: status + hold/refund + `AdminLogger.write(required=True)` + outcome/admin outbox — одна DB transaction. Telegram/network delivery запрещена до commit.
- `prod` и `stage` одинаково fail-closed требуют `TELEGRAM_WEBHOOK_SECRET`; local/dev/ci сохраняют разрешённую optional semantics.
- V1 withdrawal payout CANON не получает нового обязательного watcher proof/settlement FSM без отдельного решения владельца.

## Цикл 1745 — continuation-блокировка exact-head CI `v173.74`

- `v173.74` квалифицирован supplied CI `85676568893` по checkout `c418d15377686623fc545e4b27db023e5934085d` и точному archive size `12397023` bytes.
- Ошибочные gates ограничены Ruff `1 I001` и pytest `1`; production runtime, DB schema, OpenAPI, financial semantics и frontend visual/text исправлений не требуют.
- Ruff failure исправляется только перестановкой import groups в CI-указанном Admin RBAC guard.
- Pytest failure исправляется только приведением двух новых строк `KERNEL.md` к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; исторический baseline не расширяется.
- Audit 3 protected floor сохраняется: `355/66/81`, OpenAPI `156/162`, mounted `170`, ORM `55`, schemas `168`, frontend pages `39`.
- Локальные tests/CI/guards не запускать. Следующий verifier — exact-head GitHub CI `v173.75`.

## Cycle 1745 lock — exact-head CI continuation после Audit 3/10

- `v173.73` квалифицирован supplied CI `85671783650` по checkout и точному archive size `12388486` bytes.
- Нельзя удовлетворять stale CI ожидания откатом Audit 3: `purchase_with_efhc` обязан использовать `spend_user_to_bank_bonus_then__main__nocommit`; sale-packages mutations обязаны оставаться `409 SALE_PACKAGES_NOT_RELEASE_SSOT`; удалённый legacy Admin Bank `tg_id` read-through не восстанавливается.
- OpenAPI floor после rollback route: `156 paths / 162 public operations`; Admin generated seam обязан отражать существующий route без visual/text изменения.
- Protected surface остаётся `355 symbols / 66 modules / 81 files`; ORM `55`, schemas `168`, frontend pages `39`.
- Patch цикла 1745 ограничен реальными Ruff/Mypy/pytest causes и manifest/generated drift из supplied CI. Локальные tests/CI не запускать.

## Текущая рабочая блокировка — кандидат v173.73 / цикл 1744 — Audit 3/10: Shop/PaymentIntent/Bank financial consistency

- Входной HEAD: `EFHC_Bot_v173_72.zip`, SHA-256 `0af948145f1f3f1745b09bbab5024c28a3bee3dd341f8beded64dba1150ecb9c`, 4573 ZIP entries; archive integrity clean, все entries `ZIP_DEFLATED`.
- Scope: шесть findings Audit 3/10 пользователя, непосредственно связанный Bank rollback surface и следующий подтверждённый response defect внутри `/shop/order-external` execution path. Все пользовательские findings подтверждены по exact source, DB boundaries и active SSOT/CANON.
- Shop EFHC purchase переведён на caller-owned `spend_user_to_bank_bonus_then__main__nocommit()` и один root commit вместе с `shop_orders`; ошибка любой части откатывает money/order единым rollback.
- `shop_orders` получает pre-release canonical `UNIQUE(global_id, idempotency_key)` в ORM и единственном `0001`; read-through проверяет immutable owner-scoped fingerprint, а EFHC purchase дополнительно сверяет derived ledger keys/payload.
- `ShopPurchaseByEFHCOut` теперь строится из фактического committed order/ledger result; внешний `ShopOrderExternalIn.quantity` сохраняется compatibility field, но канонически допускает только `1`.
- PaymentIntent creation idempotency сравнивает полный immutable fingerprint; mismatch → `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact replay формируется только из persisted DB-row и не продлевает сохранённый expiry.
- `/admin/sale-packages` GET сохранён как compatibility/read surface; mutating create/update/toggle fail-closed отвечают `409 SALE_PACKAGES_NOT_RELEASE_SSOT`, пока release sale authority остаётся `efhc_core.shop_items`.
- Existing Admin Bank rollback выведен в API только после hardening: source `transfer_log_id` блокируется `FOR UPDATE`, допускается только исходная user-side Admin manual ledger operation, amount/direction/`balance_type` выводятся из source row, а deterministic compensation identity `admin_bank_rollback:<transfer_log_id>` не допускает второй reversal с иным HTTP key.
- `/shop/order-external` больше не пытается делать item-assignment в `ShopOrderExternalOut` после commit; финальный response строится новым `ShopOrderExternalOut(order=..., pay=...)`, исключая подтверждённый post-commit Pydantic `TypeError` path.
- Protected floor после добавления canonical rollback API/facade symbol: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted HTTP operations **170**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02276`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.72 / цикл 1743 — exact-head CI burn-down v173.71 после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_71.zip`, SHA-256 `e658dab6a2c05cbf9f4eb15c9b67b2153b8b05077f72c65223ba9b446ca82ab6`, размер `12456075` bytes.
- Exact-head GitHub CI `85571802073`, checkout `d3f3eb541a09954a2bc16266d45abf2c417931f0`; CI `efhc.zip` имеет тот же размер `12456075` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates по предоставленным логам: Alembic, Bandit, compileall, Flake8 full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Flake8 critical — `4` F821; Ruff — `5` diagnostics (`4` F821 + `1` I001); Mypy — `4` name-defined errors; pytest — `1 failed / 1548 passed / 22 skipped / 1 warning`.
- Подтверждённые причины исправлены минимально: восстановлен импорт `require_idempotency_key_header_only` для трёх Admin money routes; из emergency deposit rejection-audit удалён stale `request_ik`, потому что recovery authority остаётся immutable `tx_hash`; исправлен import-order в CI-указанном Admin RBAC guard; stale Bank runtime fixture использует `NULL` для отсутствующего legacy `users.ton_wallet` вместо конфликтующего `''` под `UNIQUE(ton_wallet)`.
- Семантика аудита 2/10 не ослаблена: write RBAC, strict financial Idempotency-Key, materialized-only emergency recovery, global `tx_hash` settlement claim, atomic money + required Admin audit и canonical `users.global_id` actor сохранены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02275`.
- Audit 3/10 не начат: текущий continuation сначала требует exact-head GitHub CI нового `v173.72`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- Admin authorization разделён: `require_admin` = authentication/read gate; любой state-changing `POST/PUT/PATCH/DELETE` требует `require_admin_write` (минимум Moderator), поэтому `Analyst/auditor → 403`.
- Emergency EFHC deposit принимает только `tx_hash`; amount/MEMO/address/raw facts берутся исключительно из materialized `ton_inbox_logs` под `FOR UPDATE`; отсутствие watcher-записи fail-closed. Money + обязательный actor audit фиксируются одним commit.
- Admin bank money operations используют caller-owned nocommit boundaries: ledger + обязательный `admin_action_log` + notification outbox атомарны; Telegram delivery выполняется после commit.
- Повторный `Idempotency-Key` с другим owner/operation/direction/balance/amount возвращает `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload остаётся read-through.
- Admin NFT principal после центрального gate не проходит whitelist-only повторную авторизацию.
- Panels service синхронизирован с `archived_at`; facade использует `toggle_panel`; HTTP activate/deactivate идут через единый service-layer. Rollback balance type выводится только из исходной ledger-строки.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

# ACTIVE CYCLE 1741 — GREEN CI + FULL FUNCTION/ROUTE/TABLE AUDIT LOCK — кандидат v173.67

1. Exact-head CI `85400569189` на входном `v173.66` имеет `exit=0` по всем canonical gates; это green evidence только для входного HEAD.
2. Аудит не разрешает cleanup: `no caller != delete proof`; полный inventory private helpers не является whitelist для удаления.
3. Public HTTP surface остаётся `155 paths / 161 OpenAPI operations`; дополнительно **8 mounted hidden operations** обязаны учитываться отдельно в `SSOT_INTERNAL_ROUTES.csv`. Hidden route нельзя удалить из-за отсутствия в OpenAPI.
4. Четыре `/hub/browser-shop-*` hidden routes — compatibility aliases к canonical `/shopfront/*`; новый frontend должен использовать canonical shopfront, но compatibility aliases сохраняются до отдельного delete-proof.
5. `/meta/metrics`, `/meta/deployment`, `/cron/tick`, `/tg/webhook` — internal/operator boundaries; их отсутствие в OpenAPI является намеренным, а не delete-proof.
6. ORM business inventory: **55 tables = 48 efhc_core + 7 efhc_admin**. Single Alembic head остаётся `0001`; создание `0002+` запрещено без отдельного решения владельца.
7. Protected function floor: `339 symbols / 62 modules / 77 files`; frontend floor: `39 pages`; PATCH_002 visual/text authority и ADS mediation CANON не изменяются.
8. Новый кандидат после audit/docs/guard patch требует отдельного exact-head GitHub CI; локальная application qualification запрещена.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

# ACTIVE EXACT-HEAD CI REPAIR LOCK — v173.65 / цикл 1739

1. Evidence source цикла — GitHub CI `85380431378` на входном `v173.64`; CI archive size `12351381` bytes совпадает с локальным входным HEAD, SHA-256 payload в CI-логах отсутствует.
2. Единственный failing gate входного CI — pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`; остальные canonical gates `exit=0`.
3. Исправлять разрешено только четыре подтверждённых stale expectations: два PostgreSQL FK-count tests, exact-fragment identity disposition и Russian Engineering NORM.
4. Production runtime/backend/frontend, ADS mediation, single-head `0001`, PATCH_002 visual/text CANON и business `global_id` semantics не изменяются.
5. CI/guards не получают новых broad exemptions; provider wire aliases остаются только на уже зарегистрированных boundaries.
6. Локальные tests/guards/lint/type/build/Alembic/CI запрещены; следующий verifier — exact-head GitHub CI кандидата `v173.65`.
7. Function-preservation floor остаётся `339/62/77`, OpenAPI `155/161`, frontend pages `39`, schemas `168`.

# ACTIVE ADS / FRONTEND MERGE LOCK — v173.63 / циклы 1735–1737

1. `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` остаётся абсолютным visual + user-facing text CANON для затронутых frontend surfaces. ADS ТЗ не даёт права возвращать старый Bot UI.
2. Прямое owner-approved исключение ADS scope: разрешены новые элементы Admin ADS/Admin Tasks и runtime ADS-состояния существующей Tasks-страницы; остальные visual/text изменения требуют отдельного согласования владельца.
3. `AdManager` — единственная новая production mediation architecture. Tasks не содержит provider-specific SDK/verification logic; provider adapters не начисляют EFHCb.
4. Reward authority: `Task.bonus_efhc` → immutable session reward snapshot → existing `tasks_service` / canonical bonus path. Callback/provider amount никогда не определяет EFHCb.
5. ADS business owner — `global_id`. `tg_id` допустим только на Telegram/provider boundary, когда этого реально требует provider/Bot API.
6. `Admin DB override → ENV fallback`; secret credential хранится encrypted, frontend получает только public runtime config. Secret plaintext/log/OpenAPI example/analytics запрещены.
7. `builtin_timer` — DEV/CI/diagnostics only и не входит в production monetization fallback. Exhausted real-provider chain → `NO_FILL` без reward.
8. TADS/MyBid reward adapters остаются fail-closed `NOT_SUPPORTED`, пока нет точного официального publisher-cabinet SDK/callback contract. Запрещено придумывать verification contract ради «полноты».
9. Server session, UTC daily limit, provider event dedup, one reward/session, impossible-transition rejection и idempotent reward — обязательные security invariants.
10. Старые `/ads/slot`, `/ads/callback/{provider}`, `showTelegramAd()` и historical `efhc_core.ads` сохраняются как compatibility/historical surfaces; их существование не создаёт вторую production reward architecture.
11. Revenue Optimizer использует фактическую EFHC telemetry (requests/fills/completions/revenue/fallback), не hardcoded рейтинг рекламных сетей.
12. Любое удаление compatibility/provider surface требует отдельного delete-proof; `no caller != delete proof`.
13. Локальные tests/guards/lint/type/build/Alembic/CI не запускать без отдельного разрешения владельца. Новый `v173.63` требует exact-head GitHub CI пользователя.

---

## Cycle 1734 — FRONTEND PATCH AUTHORITY corrective merge lock — кандидат v173.60

- Утверждённый владельцем `PATCH_002` имеет абсолютный приоритет для visual/UX/user-facing text. Старый Bot frontend **не является visual donor**.
- GitHub CI/architecture tests не могут разрешить visual/text rollback. Guard, требующий старую presentation при конфликте с PATCH_002, является stale и мигрируется под patch.
- Функции обеих веток сохраняются: `frontend ∪ main/backend`. Отсутствие функции в patch UI не разрешает удалить её и не разрешает вернуть старый UI; до согласования она остаётся `OWNER_REVIEW` donor либо встраивается без visual/text change.
- Автоматически допустимы только route/API/data/global_id/security/typing/i18n-coverage/generated-metadata изменения без visual/text эффекта. Любое visual/text/layout/CSS/icon/visible-action изменение требует отдельного решения владельца.
- Fail-closed proof: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; только `EXACT_PATCH`, зарегистрированный `NON_VISUAL_INTEGRATION`, `FUNCTION_UNION_NON_VISUAL` или `OWNER_APPROVED_CHANGE`.
- Историческая формулировка цикла 1733 о восстановлении старых Hub/Profile/Header/Admin visual surfaces **SUPERSEDED_BY_OWNER_DECISION_1734** и не является active instruction.
- Локальные application tests/build/CI не запускались; новый exact-head GitHub CI обязателен.

## Cycle 1733 — exact-head CI regression repair lock — кандидат v173.59

- Единственный источник дефектов цикла — GitHub CI `85239758056` на входном `v173.58`; широкие refactor/cleanup/search-for-next-failure запрещены.
- Разрешены только минимальные patches подтверждённых Ruff/Mypy/frontend-build/pytest failures и обязательная синхронизация current-state/release metadata/history.
- Защищённые Hub/Profile/Header/Admin/provider/compatibility surfaces восстанавливаются поверх frontend patch без удаления новых утверждённых bridge/Withdraw/Sale Packages contracts цикла 1732.
- `global_id`, BANK, Payment/Reconciliation, ShopOrder, Admin NFT, Reward Ads, Economy и Alembic CANON не изменяются.
- Новый `v173.59` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.58 / цикл 1732

- Входной Development HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён адресный production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip`, SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`, рассчитанный именно на `v173.57`. Проверено: `131/131` modify source SHA совпали с HEAD, `45/45` add отсутствовали в HEAD; исходные target SHA overlay совпали `176/176`.
- Overlay: `162` frontend-файла и `14` backend bridge/OpenAPI-файлов; standalone/demo/simulation runtime в overlay отсутствует. Frontend contract patch содержит `128` production HTTP contracts: `126` уже существовали, добавлены `GET /auth/profile-photos` и `GET /tasks/earnings/me`.
- Supplied OpenAPI artifact после patch: `138 paths / 143 operations / 168 schemas`. В inventory также появился уже существовавший в source `GET /meta/health_db`; новый runtime route для него в 1732 не создавался. Frontend page floor: `39`. Protected Python/file floor остаётся `312 symbols / 58 modules / 68 files`.
- Новый selected-wallet seam адаптирован к Wallet/global_id CANON: внешний owner остаётся string `global_id`, BIGINT создаётся только через canonical DB-boundary helper. Новый Tasks bridge не добавляет лишний numeric coercion поверх уже разрешённого `NonFinancialReadOwner`.
- Новый Admin diagnostics helper сохранён как техническая диагностика, но его launcher/title приведены к человеческому русскому языку. Новые инженерные docstring/comments/error messages patch приведены к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; технические идентификаторы не переводились.
- Frontend release metadata синхронизированы по фактическим patched bytes без запуска build/generator scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Последний предоставленный exact-head CI остаётся `85157912581` на `v173.56`. Exact-head CI для входного `v173.57` в цикле 1732 не предоставлялся; новый `v173.58` требует отдельного GitHub CI пользователя.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий feature-cycle автоматически не назначается.

## Текущая рабочая блокировка — кандидат v173.57 / цикл 1731

- Exact-head GitHub CI `85157912581` проверил `v173.56`: CI `efhc.zip` размером `11975213` bytes совпадает с загруженным `EFHC_Bot_v173_56.zip`; checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`. SHA-256 загруженного входного HEAD: `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`; CI-лог не публикует SHA-256 самого `efhc.zip`.
- Все canonical gates в предоставленном gate summary имеют `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci, frontend build и pytest. Pytest: `1502 passed / 22 skipped / 1 warning`.
- Цикл 1731 выполнен как статический backend/frontend + SSOT/CANON audit и handoff без запуска локальных tests/guards/lint/type/build/Alembic/CI.
- Подтверждённый protected floor: `312 symbols / 58 modules / 68 files / 135 OpenAPI paths / 140 operations / 38 frontend pages`; отсутствующих зарегистрированных элементов не найдено.
- Runtime/backend/frontend production code в цикле 1731 не изменяется: подтверждённые системные долги вынесены в handoff backlog, destructive cleanup запрещён.
- Синхронизируются только active audit/current-state/function-surface/OpenAPI metadata и обязательная cycle/report документация.
- Статус кандидата v173.57: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий номер feature/audit-цикла не назначается самовольно; сначала требуется exact-head CI нового кандидата, затем работа продолжается по зафиксированному handoff backlog по решению пользователя.

## Cycle 1730 continuation — exact-head CI manifest integrity lock — кандидат v173.56

- Evidence: GitHub CI `85153784574`, checkout `f5371d8f896486a2cbffe10584d76e65ebb7d959`, CI archive size `12053999` bytes; exact local input HEAD `EFHC_Bot_v173_55.zip` имеет SHA-256 `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`.
- Единственный подтверждённый failing gate — pytest; единственный failure: stale SHA для `docs/cycles/WORK_CYCLES_1701-1800.md` в `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`.
- Разрешён только минимальный repair release-history manifest после фактической записи цикла и обязательная синхронизация current-state/report numbering.
- Backend/frontend runtime, routes, compatibility, aliases, Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics не менять.
- Цикл 1731 не начинается до следующего exact-head GitHub CI кандидата `v173.56`.

## Cycle 1730 — exact-head CI qualification lock — кандидат v173.55

- Evidence: GitHub CI `85145865998`, checkout `3dd76713f4dea04ebb8d728385eab80f1726e41d`, CI archive size `12046473` bytes; SHA-256 CI archive в логах отсутствует.
- Подтверждённые failing gates: Mypy (`4` `no-any-return` на явной `global_id -> BIGINT` DB-boundary) и pytest (`3` architecture/current-state failures).
- Разрешены только минимальные исправления этих подтверждённых причин и обязательная синхронизация current-state/reporting документов.
- Запрещены новый alias cleanup, перенос функций, изменение Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics и удаление compatibility surfaces.
- Новый `v173.55` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.
## Цикл 1722 — Referral/Ranks отложены до frontend merge — кандидат v173.46

- Referral/Ranks backend contracts сохраняются без изменения semantics.
- Текущий отсутствие frontend caller не разрешает удалять `/ranks/referrals/my-plus-top/me` или `/ranks/referrals/top/me`.
- Полный Referral/Ranks frontend существует в отдельном frontend-контуре пользователя и будет согласован при последующем объединении frontend.
- Статус группы: `DEFERRED_TO_FRONTEND_MERGE`.
- В цикле 1722 разрешён только exact CI repair подтверждённых regressions `v173.45`; инициативный referral/ranks cleanup запрещён.
- Release/ops scripts остаются protected operational surface.

## Цикл 1721 — блокировка сохранности Shop — кандидат v173.45

- Утверждённые пользователем функции Shop являются одной защищённой capability: Admin Editor + внешняя Browser Shop + профиль + заказы + recovery + history.
- Business owner — только `global_id`; старое Shop ownership через `tg_id` возвращать запрещено.
- История товарной карточки и история заказов являются fail-closed поверхностями сохранности.
- Force Fulfill не имеет права повторно начислять уже исполненный EFHC-заказ и обязан использовать BANK/idempotency.
- `/items/set-price` остаётся compatibility API над canonical Shop model; отсутствие отдельного UI не является разрешением на удаление.
- Release/ops scripts остаются защищёнными и не входят в Shop refactoring.
- Для квалификации обязателен exact-head GitHub CI; локальные application tests/builds/guards не запускались.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Cycle 1718 exact-head CI repair + function recovery plan lock — v173.42

- GitHub CI `84954546920` проверил exact archive `v173.41` (`12135299` bytes).
- Green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build.
- Failed gates: Mypy (`2` no-any-return) и pytest (`17 failed, 1485 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: Admin facade typing, Account Registration ordering по active SSOT, stale final-cutover test contracts/fixtures, payment watcher injection contract и новые нарушения Russian engineering language policy.
- Retired `tg_id` ownership, `users.tg_id` fallback, migration-control/read-switch layers не возвращены.
- Подтверждён packaging defect `v173.41`: восстановлены executable modes `50` release/ops scripts и `28` Unicode historical report filenames с неизменным содержимым.
- Создан active план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: 1719–1728 — 10 волн согласования; 1729 — consolidation; 1730 — exact-head CI qualification; 1731 — frontend/audit handoff preparation.
- Локальные application tests/builds/guards/CI не запускались.
- Статус `v173.42`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1719 — Admin Observability и Reports: исследование и согласование`.

## Cycle 1717 exact-head CI + extended function preservation lock — v173.41

- GitHub CI `84948550953` проверил exact archive `v173.40` (`12124946` bytes), checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Failed gates: Ruff (`1` I001) и pytest (`45 failed, 1456 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes; stale final-cutover test contracts не используются для возврата retired `tg_id` ownership/migration-control layers.
- Подтверждённый payment compatibility loss восстановлен на `global_id`: wallet `_confirm_payment_intent`, bank-credit facade и watcher/reconciliation injection seam; external-shop reason приведён к размеру DB-поля.
- По прямому ТЗ продолжен `v171.89` Admin/function/routes/docs audit: восстановлены safe Admin MAIN/BONUS credit facades и NFT-maintenance compatibility wrappers; старые tg-owned Admin CRUD/security authorities не возвращены.
- Active function registry расширен до `259` symbols / `44` modules / `14` required files. Расширенный control test локально **не запускался**.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.41`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1718 — exact-head CI follow-up`.

## Cycle 1716 exact-head CI + function preservation audit lock — v173.40

- GitHub CI `84942802763` проверил exact archive `v173.39` (`12095859` bytes), checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Failed gates: Ruff (`3` I001) и pytest (`61 failed, 1307 passed, 22 skipped, 130 errors`).
- Массовый pytest setup-cluster подтверждён stale test references к retired `efhc_core.identity_migration_control`; production schema не откатывалась, потому что final global_id cutover и GREEN Alembic/PostgreSQL подтверждают retirement transition table.
- По прямому ТЗ пользователя выполнен historical function-preservation audit against `v171.89`, Admin/routes/docs audit и создан fail-closed application function surface manifest + CI control test. Контрольный тест локально **не запускался**.
- Safe compatibility entrypoints восстановлены только там, где они делегируют current canonical implementation и не возвращают `tg_id` ownership. Legacy tg-owned Admin CRUD/migration compatibility не восстанавливалась.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.40`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1717 — exact-head CI follow-up.


## Cycle 1715 exact-head CI repair lock — v173.39

- GitHub CI `84940689623` проверил exact current archive `v173.38` (`11816383` bytes), checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`.
- Green gates на `v173.38`: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` collection errors; test execution не началось).
- Cycle 1715: исправлены только эти подтверждённые причины. Ruff patch ограничен import ordering/placement; четыре CI-failed test locations минимально переведены на уже действующие canonical `global_id`/idempotency interfaces. Retired migration read-switch/control wrappers в production не возвращались.
- Локальные test/lint/type/build/Alembic/CI проверки не запускались. Статус `v173.39`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1716 exact-head CI follow-up.

## Post-migration qualification lock v173.37 / циклы 1712–1713

- GitHub CI `84923645231` проверил byte-exact Development archive `v173.36`.
- Checkout SHA: `cb915ded036615efaec297689787a3a5053a36e0`.
- `efhc.zip`: `11877960` bytes; Git blob SHA-1 `7139f9e65515d4fd553fad0872710d72dc842336` совпадает с локальным `EFHC_Bot_v173_36.zip`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: ownership migration квалифицирована: `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS, exact-head CI GREEN.
- Cycle 1713: выполнен post-migration runtime cleanup. Retired business `tg_id` routes/switches, dual-write/read-switch infrastructure, dead aliases/stubs/test façades и no-caller compatibility modules удалены.
- Сохранены только доказуемые внешние/исторические boundaries: Telegram provider ingress/delivery, TON memo/deposit read-through, historical idempotency replay и bounded stored-data compatibility.
- `v173.37` содержит cleanup patch и требует нового exact-head GitHub CI. Следующий цикл: `1714 — Alias cleanup qualification`.

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Текущий Alembic head `0010`; `0011` отсутствует.
Цикл `1627` запрещён до exact-head real PostgreSQL qualification
financial shadow validation `1626`. Денежные значения, precision и
idempotency не изменяются.

---

# Актуальные блокировки v172.28

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует. Cycle `1626` — только
read-only financial shadow validation. Денежное расхождение должно быть
`0.00000000`; Numeric precision/scale и idempotency semantics неизменны.
Financial read switch запрещён до `1627` и fresh exact-HEAD proof.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# Актуальные блокировки v172.27

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует.
Non-financial reads могут переключаться на `global_id` только при
нулевой telemetry. Legacy writes и dual-write остаются активными.
Financial reads, precision и formulas запрещено менять в `1625`.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# ARCHITECTURAL LOCKS

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими заданиями.

При конфликте требований приоритет имеют действующие architectural locks,
машинные guards и фактический production code; новое ТЗ не отменяет их
неявно и должно изменять канон только отдельным зафиксированным решением.

# EFHC — активные архитектурные блокировки

Текущий пакет: `v172.26`.

Жёстко зафиксировано:

- `global_id` — главный и постоянный account owner;
- `users.user_id` удалён; физическое имя — `users.global_id`;
- отдельная физическая `users.global_id` рядом запрещена;
- Alembic head `0009`, migration `0010` отсутствует;
- legacy runtime ownership остаётся authoritative;
- dual-write conflict/orphan должен завершаться fail closed;
- telemetry только наблюдает shadow state и не делает read switch;
- financial values/precision/idempotency не меняются;
- цикл `1625` запрещён до fresh qualification `v172.26`;
- migration squash запрещён до `1632`;
- CI workflow нельзя менять без прямой команды пользователя.

SSOT имеет приоритет над отдельными техническими заданиями при их
противоречии, если пользователь прямо не изменил канон.

## Security/audit ownership lock v173.24

Privileged действия, server-side admin session и audit ownership используют `global_id` end-to-end. Telegram/TON/другие provider subjects не могут быть privileged owner. Финансовый owner Admin Bank — `global_id`; `tg_id` допускается только для provider delivery/исторического read-through, который не создаёт новый ownership.

## SuperAdmin account reservation v173.27

- `global_id=1313131313` зарезервирован для SuperAdmin EFHC.
- Обычная account registration не имеет права выдавать этот ID.
- Provider ID не даёт SuperAdmin privilege; требуется whitelist + explicit RBAC.
- VIP/NFT не является admin credential.

## Release scripts protection lock — cycle 1719

Release/ops scripts являются защищённым operational surface. До завершения code phase без прямого ТЗ пользователя или конкретного GitHub CI evidence запрещено удалять, переименовывать, реконструировать, упрощать, массово форматировать эти scripts либо менять/терять их executable mode. Автоматические RELEASE/MATRIX archives не создаются. Финальные release archives готовятся после завершения работы с кодом по отдельному решению пользователя.

## Admin Reports/Observability decision lock — cycle 1719

`GET /admin/observability/events` сохраняется только как compatibility stub с причиной `disabled_duplicate` и replacement `/admin/logs/transfers`. Пять domain report routes (`users`, `bank`, `panels`, `withdrawals`, `deposits`) являются действующими Admin capabilities и подключаются к Admin Reports UI. Users ownership — только `global_id`; BANK — только `system_entity=BANK_EFHC` и `bank_balance.key=EFHC_MAIN`.


## ADMIN TASKS EDITOR PRESERVATION LOCK — cycle 1720

- `POST/GET/PATCH/DELETE /admin/tasks[/... ]`, submissions, moderation и maintenance boundary являются защищённой Admin surface.
- Основное удаление задания — деактивация. Physical delete разрешён только при отсутствии submissions, user status, bonus log и completion locks.
- Task `code` после появления истории неизменяем через Admin Editor.
- `tasks_autorestart` и TON `check_ton_inbox` — разные scheduler capabilities; объединять или удалять один как дубль запрещено без отдельного доказательства.
- Admin Ads остаётся отдельным provider contour; секреты ENV не переносятся в браузер.


## REFERRALS / RANKS FRONTEND INTEGRATION LOCK — cycle 1722 continuation

- `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` — защищённая пользовательская frontend capability.
- Ranks сохраняет два независимых mode: `kwh` и `referrals`; их React Query cache keys нельзя объединять.
- Используются только существующие backend routes; новые дублирующие referral/rank endpoints без прямого ТЗ запрещены.
- `global_id` разрешён только как внутренний owner/key и не показывается пользователю вместо username/privacy fallback.
- Referral link, bonus asset, Lvl 1–5 и списки поступают только из реального backend. Mock/offline/demo/simulation данные запрещены.
- Пять social share assets и общие `StatusIndicator`/`BonusEarningsStrip` являются частью сохранённой capability.
- Удаление этих routes/pages/components только из-за отсутствия caller в отдельной сборке запрещено.
## Admin VIP / NFT lock — цикл 1725

- VIP пользователя нельзя назначать/снимать вручную: это derived state фактической NFT-проверки.
- Admin NFT credential через `TON_ADMIN_NFT_IDS` является независимым путём Admin-доступа и не становится business owner.
- Business actor и audit actor — только `global_id`.
- Historical `submit_manual_vip_nft_claim(tg_id, ...)` запрещено восстанавливать: статус `REPLACED_BY_CANON / DO_NOT_RESTORE`.
- Оплаченный Shop NFT order является единственной заявкой на ручную выдачу; второй claim/order запрещён.
- Ручное решение по выдаче допускается только для ожидающей оплаченной NFT-заявки и обязано сохранять причину и администратора.
- Система не должна выдавать запись Admin-решения за автоматический on-chain mint/transfer.

## Цикл 1728 — Runtime Compatibility lock

- `no caller != delete proof`: отсутствие current caller не является основанием удаления compatibility surface.
- `create_app`, `app.database.get_engine/get_session_factory`, `app.core.decimal_utils.d8` и `order_models.ShopOrder` сохраняются бессрочно как тонкие import/startup/ORM facades и не получают второй runtime.
- `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, `TickContext`, `SchedulerError`, `JobTimeout`, `scheduler_core.tick`, `tasks_maintenance.run_once` — бессрочные compatibility-only surfaces; новый код использует canonical implementation.
- `RBAC.is_superadmin` не является auth-path и может применяться только к уже разрешённому `AdminUser`.
- Подробные комментарии рядом с compatibility-кодом являются частью архитектурного решения и должны читаться до будущего cleanup-аудита.
- Удаление возможно только после отдельного решения пользователя, полного delete-proof и последующего exact-head GitHub CI.
- Active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
## Cycle 1729 — consolidation + alias retirement lock

- Решения 1719–1728 сведены в `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`; новый cleanup из консолидации не выводится автоматически.
- `sql_aliases_core` больше не является transitional resolver: private aliases `core/efhc/efhc-core/admin/efhc-admin/vip_log/vip_status` удалены после delete-proof.
- ENV/provider/wire/history aliases не приравниваются к obsolete runtime aliases и сохраняются без отдельного delete-proof внешних потребителей.
- Бессрочные compatibility surfaces циклов 1726–1728 не являются кандидатами удаления в 1729.
- Следующий цикл 1730 — только exact-head CI qualification/error burn-down; новые функциональные решения запрещены без нового ТЗ.

