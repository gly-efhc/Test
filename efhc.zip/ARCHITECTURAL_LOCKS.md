# ACTIVE EXACT-HEAD CI REPAIR LOCK — v173.65 / цикл 1739

1. Evidence source цикла — GitHub CI `85380431378` на входном `v173.64`; CI archive size `12351381` bytes совпадает с локальным входным HEAD, SHA-256 payload в CI-логах отсутствует.
2. Единственный failing gate входного CI — pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`; остальные canonical gates `exit=0`.
3. Исправлять разрешено только четыре подтверждённых stale expectations: два PostgreSQL FK-count tests, exact-fragment identity disposition и Russian Engineering NORM.
4. Production runtime/backend/frontend, ADS mediation, single-head `0001`, PATCH_002 visual/text CANON и business `global_id` semantics не изменяются.
5. CI/guards не получают новых broad exemptions; provider wire aliases остаются только на уже зарегистрированных boundaries.
6. Локальные tests/guards/lint/type/build/Alembic/CI запрещены; следующий verifier — exact-head GitHub CI кандидата `v173.65`.
7. Function-preservation floor остаётся `339/62/77`, OpenAPI `155/161`, frontend pages `39`, schemas `168`.

# ACTIVE ADS / FRONTEND MERGE LOCK — v173.63 / циклы 1735–1737

1. `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002` остаётся абсолютным visual + user-facing text CANON для затронутых frontend surfaces. ADS ТЗ не даёт права возвращать старый Bot UI.
2. Прямое owner-approved исключение ADS scope: разрешены новые элементы Admin ADS/Admin Tasks и runtime ADS-состояния существующей Tasks-страницы; остальные visual/text изменения требуют отдельного согласования владельца.
3. `AdManager` — единственная новая production mediation architecture. Tasks не содержит provider-specific SDK/verification logic; provider adapters не начисляют EFHCb.
4. Reward authority: `Task.bonus_efhc` → immutable session reward snapshot → existing `tasks_service` / canonical bonus path. Callback/provider amount никогда не определяет EFHCb.
5. ADS business owner — `global_id`. `tg_id` допустим только на Telegram/provider boundary, когда этого реально требует provider/Bot API.
6. `Admin DB override → ENV fallback`; secret credential хранится encrypted, frontend получает только public runtime config. Secret plaintext/log/OpenAPI example/analytics запрещены.
7. `builtin_timer` — DEV/CI/diagnostics only и не входит в production monetization fallback. Exhausted real-provider chain → `NO_FILL` без reward.
8. TADS/MyBid reward adapters остаются fail-closed `NOT_SUPPORTED`, пока нет точного официального publisher-cabinet SDK/callback contract. Запрещено придумывать verification contract ради «полноты».
9. Server session, UTC daily limit, provider event dedup, one reward/session, impossible-transition rejection и idempotent reward — обязательные security invariants.
10. Старые `/ads/slot`, `/ads/callback/{provider}`, `showTelegramAd()` и historical `efhc_core.ads` сохраняются как compatibility/historical surfaces; их существование не создаёт вторую production reward architecture.
11. Revenue Optimizer использует фактическую EFHC telemetry (requests/fills/completions/revenue/fallback), не hardcoded рейтинг рекламных сетей.
12. Любое удаление compatibility/provider surface требует отдельного delete-proof; `no caller != delete proof`.
13. Локальные tests/guards/lint/type/build/Alembic/CI не запускать без отдельного разрешения владельца. Новый `v173.63` требует exact-head GitHub CI пользователя.

---

## Cycle 1734 — FRONTEND PATCH AUTHORITY corrective merge lock — кандидат v173.60

- Утверждённый владельцем `PATCH_002` имеет абсолютный приоритет для visual/UX/user-facing text. Старый Bot frontend **не является visual donor**.
- GitHub CI/architecture tests не могут разрешить visual/text rollback. Guard, требующий старую presentation при конфликте с PATCH_002, является stale и мигрируется под patch.
- Функции обеих веток сохраняются: `frontend ∪ main/backend`. Отсутствие функции в patch UI не разрешает удалить её и не разрешает вернуть старый UI; до согласования она остаётся `OWNER_REVIEW` donor либо встраивается без visual/text change.
- Автоматически допустимы только route/API/data/global_id/security/typing/i18n-coverage/generated-metadata изменения без visual/text эффекта. Любое visual/text/layout/CSS/icon/visible-action изменение требует отдельного решения владельца.
- Fail-closed proof: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; только `EXACT_PATCH`, зарегистрированный `NON_VISUAL_INTEGRATION`, `FUNCTION_UNION_NON_VISUAL` или `OWNER_APPROVED_CHANGE`.
- Историческая формулировка цикла 1733 о восстановлении старых Hub/Profile/Header/Admin visual surfaces **SUPERSEDED_BY_OWNER_DECISION_1734** и не является active instruction.
- Локальные application tests/build/CI не запускались; новый exact-head GitHub CI обязателен.

## Cycle 1733 — exact-head CI regression repair lock — кандидат v173.59

- Единственный источник дефектов цикла — GitHub CI `85239758056` на входном `v173.58`; широкие refactor/cleanup/search-for-next-failure запрещены.
- Разрешены только минимальные patches подтверждённых Ruff/Mypy/frontend-build/pytest failures и обязательная синхронизация current-state/release metadata/history.
- Защищённые Hub/Profile/Header/Admin/provider/compatibility surfaces восстанавливаются поверх frontend patch без удаления новых утверждённых bridge/Withdraw/Sale Packages contracts цикла 1732.
- `global_id`, BANK, Payment/Reconciliation, ShopOrder, Admin NFT, Reward Ads, Economy и Alembic CANON не изменяются.
- Новый `v173.59` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.58 / цикл 1732

- Входной Development HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён адресный production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip`, SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`, рассчитанный именно на `v173.57`. Проверено: `131/131` modify source SHA совпали с HEAD, `45/45` add отсутствовали в HEAD; исходные target SHA overlay совпали `176/176`.
- Overlay: `162` frontend-файла и `14` backend bridge/OpenAPI-файлов; standalone/demo/simulation runtime в overlay отсутствует. Frontend contract patch содержит `128` production HTTP contracts: `126` уже существовали, добавлены `GET /auth/profile-photos` и `GET /tasks/earnings/me`.
- Supplied OpenAPI artifact после patch: `138 paths / 143 operations / 168 schemas`. В inventory также появился уже существовавший в source `GET /meta/health_db`; новый runtime route для него в 1732 не создавался. Frontend page floor: `39`. Protected Python/file floor остаётся `312 symbols / 58 modules / 68 files`.
- Новый selected-wallet seam адаптирован к Wallet/global_id CANON: внешний owner остаётся string `global_id`, BIGINT создаётся только через canonical DB-boundary helper. Новый Tasks bridge не добавляет лишний numeric coercion поверх уже разрешённого `NonFinancialReadOwner`.
- Новый Admin diagnostics helper сохранён как техническая диагностика, но его launcher/title приведены к человеческому русскому языку. Новые инженерные docstring/comments/error messages patch приведены к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; технические идентификаторы не переводились.
- Frontend release metadata синхронизированы по фактическим patched bytes без запуска build/generator scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Последний предоставленный exact-head CI остаётся `85157912581` на `v173.56`. Exact-head CI для входного `v173.57` в цикле 1732 не предоставлялся; новый `v173.58` требует отдельного GitHub CI пользователя.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий feature-cycle автоматически не назначается.

## Текущая рабочая блокировка — кандидат v173.57 / цикл 1731

- Exact-head GitHub CI `85157912581` проверил `v173.56`: CI `efhc.zip` размером `11975213` bytes совпадает с загруженным `EFHC_Bot_v173_56.zip`; checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`. SHA-256 загруженного входного HEAD: `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`; CI-лог не публикует SHA-256 самого `efhc.zip`.
- Все canonical gates в предоставленном gate summary имеют `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci, frontend build и pytest. Pytest: `1502 passed / 22 skipped / 1 warning`.
- Цикл 1731 выполнен как статический backend/frontend + SSOT/CANON audit и handoff без запуска локальных tests/guards/lint/type/build/Alembic/CI.
- Подтверждённый protected floor: `312 symbols / 58 modules / 68 files / 135 OpenAPI paths / 140 operations / 38 frontend pages`; отсутствующих зарегистрированных элементов не найдено.
- Runtime/backend/frontend production code в цикле 1731 не изменяется: подтверждённые системные долги вынесены в handoff backlog, destructive cleanup запрещён.
- Синхронизируются только active audit/current-state/function-surface/OpenAPI metadata и обязательная cycle/report документация.
- Статус кандидата v173.57: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий номер feature/audit-цикла не назначается самовольно; сначала требуется exact-head CI нового кандидата, затем работа продолжается по зафиксированному handoff backlog по решению пользователя.

## Cycle 1730 continuation — exact-head CI manifest integrity lock — кандидат v173.56

- Evidence: GitHub CI `85153784574`, checkout `f5371d8f896486a2cbffe10584d76e65ebb7d959`, CI archive size `12053999` bytes; exact local input HEAD `EFHC_Bot_v173_55.zip` имеет SHA-256 `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`.
- Единственный подтверждённый failing gate — pytest; единственный failure: stale SHA для `docs/cycles/WORK_CYCLES_1701-1800.md` в `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv`.
- Разрешён только минимальный repair release-history manifest после фактической записи цикла и обязательная синхронизация current-state/report numbering.
- Backend/frontend runtime, routes, compatibility, aliases, Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics не менять.
- Цикл 1731 не начинается до следующего exact-head GitHub CI кандидата `v173.56`.

## Cycle 1730 — exact-head CI qualification lock — кандидат v173.55

- Evidence: GitHub CI `85145865998`, checkout `3dd76713f4dea04ebb8d728385eab80f1726e41d`, CI archive size `12046473` bytes; SHA-256 CI archive в логах отсутствует.
- Подтверждённые failing gates: Mypy (`4` `no-any-return` на явной `global_id -> BIGINT` DB-boundary) и pytest (`3` architecture/current-state failures).
- Разрешены только минимальные исправления этих подтверждённых причин и обязательная синхронизация current-state/reporting документов.
- Запрещены новый alias cleanup, перенос функций, изменение Bank/Payment/Shop/NFT/Reward Ads/Referrals/Ranks semantics и удаление compatibility surfaces.
- Новый `v173.55` не считается квалифицированным до следующего exact-head GitHub CI пользователя.

## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.
## Цикл 1722 — Referral/Ranks отложены до frontend merge — кандидат v173.46

- Referral/Ranks backend contracts сохраняются без изменения semantics.
- Текущий отсутствие frontend caller не разрешает удалять `/ranks/referrals/my-plus-top/me` или `/ranks/referrals/top/me`.
- Полный Referral/Ranks frontend существует в отдельном frontend-контуре пользователя и будет согласован при последующем объединении frontend.
- Статус группы: `DEFERRED_TO_FRONTEND_MERGE`.
- В цикле 1722 разрешён только exact CI repair подтверждённых regressions `v173.45`; инициативный referral/ranks cleanup запрещён.
- Release/ops scripts остаются protected operational surface.

## Цикл 1721 — блокировка сохранности Shop — кандидат v173.45

- Утверждённые пользователем функции Shop являются одной защищённой capability: Admin Editor + внешняя Browser Shop + профиль + заказы + recovery + history.
- Business owner — только `global_id`; старое Shop ownership через `tg_id` возвращать запрещено.
- История товарной карточки и история заказов являются fail-closed поверхностями сохранности.
- Force Fulfill не имеет права повторно начислять уже исполненный EFHC-заказ и обязан использовать BANK/idempotency.
- `/items/set-price` остаётся compatibility API над canonical Shop model; отсутствие отдельного UI не является разрешением на удаление.
- Release/ops scripts остаются защищёнными и не входят в Shop refactoring.
- Для квалификации обязателен exact-head GitHub CI; локальные application tests/builds/guards не запускались.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Cycle 1718 exact-head CI repair + function recovery plan lock — v173.42

- GitHub CI `84954546920` проверил exact archive `v173.41` (`12135299` bytes).
- Green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build.
- Failed gates: Mypy (`2` no-any-return) и pytest (`17 failed, 1485 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: Admin facade typing, Account Registration ordering по active SSOT, stale final-cutover test contracts/fixtures, payment watcher injection contract и новые нарушения Russian engineering language policy.
- Retired `tg_id` ownership, `users.tg_id` fallback, migration-control/read-switch layers не возвращены.
- Подтверждён packaging defect `v173.41`: восстановлены executable modes `50` release/ops scripts и `28` Unicode historical report filenames с неизменным содержимым.
- Создан active план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: 1719–1728 — 10 волн согласования; 1729 — consolidation; 1730 — exact-head CI qualification; 1731 — frontend/audit handoff preparation.
- Локальные application tests/builds/guards/CI не запускались.
- Статус `v173.42`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1719 — Admin Observability и Reports: исследование и согласование`.

## Cycle 1717 exact-head CI + extended function preservation lock — v173.41

- GitHub CI `84948550953` проверил exact archive `v173.40` (`12124946` bytes), checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Failed gates: Ruff (`1` I001) и pytest (`45 failed, 1456 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes; stale final-cutover test contracts не используются для возврата retired `tg_id` ownership/migration-control layers.
- Подтверждённый payment compatibility loss восстановлен на `global_id`: wallet `_confirm_payment_intent`, bank-credit facade и watcher/reconciliation injection seam; external-shop reason приведён к размеру DB-поля.
- По прямому ТЗ продолжен `v171.89` Admin/function/routes/docs audit: восстановлены safe Admin MAIN/BONUS credit facades и NFT-maintenance compatibility wrappers; старые tg-owned Admin CRUD/security authorities не возвращены.
- Active function registry расширен до `259` symbols / `44` modules / `14` required files. Расширенный control test локально **не запускался**.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.41`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1718 — exact-head CI follow-up`.

## Cycle 1716 exact-head CI + function preservation audit lock — v173.40

- GitHub CI `84942802763` проверил exact archive `v173.39` (`12095859` bytes), checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Failed gates: Ruff (`3` I001) и pytest (`61 failed, 1307 passed, 22 skipped, 130 errors`).
- Массовый pytest setup-cluster подтверждён stale test references к retired `efhc_core.identity_migration_control`; production schema не откатывалась, потому что final global_id cutover и GREEN Alembic/PostgreSQL подтверждают retirement transition table.
- По прямому ТЗ пользователя выполнен historical function-preservation audit against `v171.89`, Admin/routes/docs audit и создан fail-closed application function surface manifest + CI control test. Контрольный тест локально **не запускался**.
- Safe compatibility entrypoints восстановлены только там, где они делегируют current canonical implementation и не возвращают `tg_id` ownership. Legacy tg-owned Admin CRUD/migration compatibility не восстанавливалась.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.40`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1717 — exact-head CI follow-up.


## Cycle 1715 exact-head CI repair lock — v173.39

- GitHub CI `84940689623` проверил exact current archive `v173.38` (`11816383` bytes), checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`.
- Green gates на `v173.38`: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` collection errors; test execution не началось).
- Cycle 1715: исправлены только эти подтверждённые причины. Ruff patch ограничен import ordering/placement; четыре CI-failed test locations минимально переведены на уже действующие canonical `global_id`/idempotency interfaces. Retired migration read-switch/control wrappers в production не возвращались.
- Локальные test/lint/type/build/Alembic/CI проверки не запускались. Статус `v173.39`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1716 exact-head CI follow-up.

## Post-migration qualification lock v173.37 / циклы 1712–1713

- GitHub CI `84923645231` проверил byte-exact Development archive `v173.36`.
- Checkout SHA: `cb915ded036615efaec297689787a3a5053a36e0`.
- `efhc.zip`: `11877960` bytes; Git blob SHA-1 `7139f9e65515d4fd553fad0872710d72dc842336` совпадает с локальным `EFHC_Bot_v173_36.zip`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: ownership migration квалифицирована: `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS, exact-head CI GREEN.
- Cycle 1713: выполнен post-migration runtime cleanup. Retired business `tg_id` routes/switches, dual-write/read-switch infrastructure, dead aliases/stubs/test façades и no-caller compatibility modules удалены.
- Сохранены только доказуемые внешние/исторические boundaries: Telegram provider ingress/delivery, TON memo/deposit read-through, historical idempotency replay и bounded stored-data compatibility.
- `v173.37` содержит cleanup patch и требует нового exact-head GitHub CI. Следующий цикл: `1714 — Alias cleanup qualification`.

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Текущий Alembic head `0010`; `0011` отсутствует.
Цикл `1627` запрещён до exact-head real PostgreSQL qualification
financial shadow validation `1626`. Денежные значения, precision и
idempotency не изменяются.

---

# Актуальные блокировки v172.28

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует. Cycle `1626` — только
read-only financial shadow validation. Денежное расхождение должно быть
`0.00000000`; Numeric precision/scale и idempotency semantics неизменны.
Financial read switch запрещён до `1627` и fresh exact-HEAD proof.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# Актуальные блокировки v172.27

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует.
Non-financial reads могут переключаться на `global_id` только при
нулевой telemetry. Legacy writes и dual-write остаются активными.
Financial reads, precision и formulas запрещено менять в `1625`.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# ARCHITECTURAL LOCKS

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими заданиями.

При конфликте требований приоритет имеют действующие architectural locks,
машинные guards и фактический production code; новое ТЗ не отменяет их
неявно и должно изменять канон только отдельным зафиксированным решением.

# EFHC — активные архитектурные блокировки

Текущий пакет: `v172.26`.

Жёстко зафиксировано:

- `global_id` — главный и постоянный account owner;
- `users.user_id` удалён; физическое имя — `users.global_id`;
- отдельная физическая `users.global_id` рядом запрещена;
- Alembic head `0009`, migration `0010` отсутствует;
- legacy runtime ownership остаётся authoritative;
- dual-write conflict/orphan должен завершаться fail closed;
- telemetry только наблюдает shadow state и не делает read switch;
- financial values/precision/idempotency не меняются;
- цикл `1625` запрещён до fresh qualification `v172.26`;
- migration squash запрещён до `1632`;
- CI workflow нельзя менять без прямой команды пользователя.

SSOT имеет приоритет над отдельными техническими заданиями при их
противоречии, если пользователь прямо не изменил канон.

## Security/audit ownership lock v173.24

Privileged действия, server-side admin session и audit ownership используют `global_id` end-to-end. Telegram/TON/другие provider subjects не могут быть privileged owner. Финансовый owner Admin Bank — `global_id`; `tg_id` допускается только для provider delivery/исторического read-through, который не создаёт новый ownership.

## SuperAdmin account reservation v173.27

- `global_id=1313131313` зарезервирован для SuperAdmin EFHC.
- Обычная account registration не имеет права выдавать этот ID.
- Provider ID не даёт SuperAdmin privilege; требуется whitelist + explicit RBAC.
- VIP/NFT не является admin credential.

## Release scripts protection lock — cycle 1719

Release/ops scripts являются защищённым operational surface. До завершения code phase без прямого ТЗ пользователя или конкретного GitHub CI evidence запрещено удалять, переименовывать, реконструировать, упрощать, массово форматировать эти scripts либо менять/терять их executable mode. Автоматические RELEASE/MATRIX archives не создаются. Финальные release archives готовятся после завершения работы с кодом по отдельному решению пользователя.

## Admin Reports/Observability decision lock — cycle 1719

`GET /admin/observability/events` сохраняется только как compatibility stub с причиной `disabled_duplicate` и replacement `/admin/logs/transfers`. Пять domain report routes (`users`, `bank`, `panels`, `withdrawals`, `deposits`) являются действующими Admin capabilities и подключаются к Admin Reports UI. Users ownership — только `global_id`; BANK — только `system_entity=BANK_EFHC` и `bank_balance.key=EFHC_MAIN`.


## ADMIN TASKS EDITOR PRESERVATION LOCK — cycle 1720

- `POST/GET/PATCH/DELETE /admin/tasks[/... ]`, submissions, moderation и maintenance boundary являются защищённой Admin surface.
- Основное удаление задания — деактивация. Physical delete разрешён только при отсутствии submissions, user status, bonus log и completion locks.
- Task `code` после появления истории неизменяем через Admin Editor.
- `tasks_autorestart` и TON `check_ton_inbox` — разные scheduler capabilities; объединять или удалять один как дубль запрещено без отдельного доказательства.
- Admin Ads остаётся отдельным provider contour; секреты ENV не переносятся в браузер.


## REFERRALS / RANKS FRONTEND INTEGRATION LOCK — cycle 1722 continuation

- `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` — защищённая пользовательская frontend capability.
- Ranks сохраняет два независимых mode: `kwh` и `referrals`; их React Query cache keys нельзя объединять.
- Используются только существующие backend routes; новые дублирующие referral/rank endpoints без прямого ТЗ запрещены.
- `global_id` разрешён только как внутренний owner/key и не показывается пользователю вместо username/privacy fallback.
- Referral link, bonus asset, Lvl 1–5 и списки поступают только из реального backend. Mock/offline/demo/simulation данные запрещены.
- Пять social share assets и общие `StatusIndicator`/`BonusEarningsStrip` являются частью сохранённой capability.
- Удаление этих routes/pages/components только из-за отсутствия caller в отдельной сборке запрещено.
## Admin VIP / NFT lock — цикл 1725

- VIP пользователя нельзя назначать/снимать вручную: это derived state фактической NFT-проверки.
- Admin NFT credential через `TON_ADMIN_NFT_IDS` является независимым путём Admin-доступа и не становится business owner.
- Business actor и audit actor — только `global_id`.
- Historical `submit_manual_vip_nft_claim(tg_id, ...)` запрещено восстанавливать: статус `REPLACED_BY_CANON / DO_NOT_RESTORE`.
- Оплаченный Shop NFT order является единственной заявкой на ручную выдачу; второй claim/order запрещён.
- Ручное решение по выдаче допускается только для ожидающей оплаченной NFT-заявки и обязано сохранять причину и администратора.
- Система не должна выдавать запись Admin-решения за автоматический on-chain mint/transfer.

## Цикл 1728 — Runtime Compatibility lock

- `no caller != delete proof`: отсутствие current caller не является основанием удаления compatibility surface.
- `create_app`, `app.database.get_engine/get_session_factory`, `app.core.decimal_utils.d8` и `order_models.ShopOrder` сохраняются бессрочно как тонкие import/startup/ORM facades и не получают второй runtime.
- `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, `TickContext`, `SchedulerError`, `JobTimeout`, `scheduler_core.tick`, `tasks_maintenance.run_once` — бессрочные compatibility-only surfaces; новый код использует canonical implementation.
- `RBAC.is_superadmin` не является auth-path и может применяться только к уже разрешённому `AdminUser`.
- Подробные комментарии рядом с compatibility-кодом являются частью архитектурного решения и должны читаться до будущего cleanup-аудита.
- Удаление возможно только после отдельного решения пользователя, полного delete-proof и последующего exact-head GitHub CI.
- Active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
## Cycle 1729 — consolidation + alias retirement lock

- Решения 1719–1728 сведены в `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`; новый cleanup из консолидации не выводится автоматически.
- `sql_aliases_core` больше не является transitional resolver: private aliases `core/efhc/efhc-core/admin/efhc-admin/vip_log/vip_status` удалены после delete-proof.
- ENV/provider/wire/history aliases не приравниваются к obsolete runtime aliases и сохраняются без отдельного delete-proof внешних потребителей.
- Бессрочные compatibility surfaces циклов 1726–1728 не являются кандидатами удаления в 1729.
- Следующий цикл 1730 — только exact-head CI qualification/error burn-down; новые функциональные решения запрещены без нового ТЗ.

