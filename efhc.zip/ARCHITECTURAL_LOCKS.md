<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Post-migration qualification lock v173.37 / циклы 1712–1713

- GitHub CI `84923645231` проверил byte-exact Development archive `v173.36`.
- Checkout SHA: `cb915ded036615efaec297689787a3a5053a36e0`.
- `efhc.zip`: `11877960` bytes; Git blob SHA-1 `7139f9e65515d4fd553fad0872710d72dc842336` совпадает с локальным `EFHC_Bot_v173_36.zip`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: ownership migration квалифицирована: `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS, exact-head CI GREEN.
- Cycle 1713: выполнен post-migration runtime cleanup. Retired business `tg_id` routes/switches, dual-write/read-switch infrastructure, dead aliases/stubs/test façades и no-caller compatibility modules удалены.
- Сохранены только доказуемые внешние/исторические boundaries: Telegram provider ingress/delivery, TON memo/deposit read-through, historical idempotency replay и bounded stored-data compatibility.
- `v173.37` содержит cleanup patch и требует нового exact-head GitHub CI. Следующий цикл: `1714 — Alias cleanup qualification`.

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Текущий Alembic head `0010`; `0011` отсутствует.
Цикл `1627` запрещён до exact-head real PostgreSQL qualification
financial shadow validation `1626`. Денежные значения, precision и
idempotency не изменяются.

---

# Актуальные блокировки v172.28

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует. Cycle `1626` — только
read-only financial shadow validation. Денежное расхождение должно быть
`0.00000000`; Numeric precision/scale и idempotency semantics неизменны.
Financial read switch запрещён до `1627` и fresh exact-HEAD proof.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# Актуальные блокировки v172.27

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует.
Non-financial reads могут переключаться на `global_id` только при
нулевой telemetry. Legacy writes и dual-write остаются активными.
Financial reads, precision и formulas запрещено менять в `1625`.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# ARCHITECTURAL LOCKS

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими заданиями.

При конфликте требований приоритет имеют действующие architectural locks,
машинные guards и фактический production code; новое ТЗ не отменяет их
неявно и должно изменять канон только отдельным зафиксированным решением.

# EFHC — активные архитектурные блокировки

Текущий пакет: `v172.26`.

Жёстко зафиксировано:

- `global_id` — главный и постоянный account owner;
- `users.user_id` удалён; физическое имя — `users.global_id`;
- отдельная физическая `users.global_id` рядом запрещена;
- Alembic head `0009`, migration `0010` отсутствует;
- legacy runtime ownership остаётся authoritative;
- dual-write conflict/orphan должен завершаться fail closed;
- telemetry только наблюдает shadow state и не делает read switch;
- financial values/precision/idempotency не меняются;
- цикл `1625` запрещён до fresh qualification `v172.26`;
- migration squash запрещён до `1632`;
- CI workflow нельзя менять без прямой команды пользователя.

SSOT имеет приоритет над отдельными техническими заданиями при их
противоречии, если пользователь прямо не изменил канон.

## Security/audit ownership lock v173.24

Privileged действия, server-side admin session и audit ownership используют `global_id` end-to-end. Telegram/TON/другие provider subjects не могут быть privileged owner. Финансовый owner Admin Bank — `global_id`; `tg_id` допускается только для provider delivery/исторического read-through, который не создаёт новый ownership.

## SuperAdmin account reservation v173.27

- `global_id=1313131313` зарезервирован для SuperAdmin EFHC.
- Обычная account registration не имеет права выдавать этот ID.
- Provider ID не даёт SuperAdmin privilege; требуется whitelist + explicit RBAC.
- VIP/NFT не является admin credential.
