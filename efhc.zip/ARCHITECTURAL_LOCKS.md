# Текущий статус v172.52 — циклы 1636–1637

Fresh GitHub CI `83405061075` проверил exact
`EFHC_Bot_v172_51.zip` размером `12650102` байта. PostgreSQL,
единая migration `0001`, production frontend build и все `102`
route-backed Chromium checks прошли. Красный итог вызвали только
`13` статических/документных pytest guards, один Ruff import-order
finding и один Mypy return-type finding. Runtime, schema, auth и
financial regression не подтверждены.

Цикл `1636` квалифицирован реальным PostgreSQL-прогоном ядра.
В `v172.52` выполнен цикл `1637`:

- Telegram Bot `/start` создаёт новый account только через
  `AccountRegistrationService`;
- raw SQL вставка `users` из referral onboarding удалена;
- `User`, immutable `ReferralLink` и Telegram `UserIdentity`
  создаются атомарно в одной транзакции;
- invalid/missing referral отклоняется до создания account;
- существующий пользователь, включая permanent `0 user`, не может
  получить позднюю referral-привязку;
- WebApp и TON callers не переключались и остаются scope цикла `1639`;
- migration, schema, экономика и шесть нижних маршрутов не менялись.

Visual gate exact `v172.51` прошёл `102/102`, но переданный архив
`ci_artifacts (3).zip` не содержит PNG. Поэтому пользовательская
visual acceptance follow-up цикла `1635` остаётся открытой.

```text
CURRENT_HEAD_V172_52
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_IMPLEMENTED
CYCLE_1637_EXACT_HEAD_CI_REQUIRED
CYCLE_1638_NOT_STARTED
CYCLE_1639_NOT_STARTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---
# Актуализация qualification boundary — v172.39

v172.39 — corrective-only package цикла `1630`. Разрешённый scope:
восстановление 28 имён evidence files, UTF-8-safe development builder
и archive regression contracts. Запрещены migration `0013`, physical
rename, изменение CI, auth cryptography и financial semantics.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.38

v172.38 — corrective-only package цикла `1630`. Разрешённый scope:
шесть current-head pytest findings и local-only Chromium admin proof.
Запрещены migration `0013`, physical rename, изменение CI, auth
cryptography и financial semantics.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.37

Universal canonical CI и protected frontend workflow неизменны. Fresh
v172.36 CI выявил один browser blocker: `51` admin routes без marker из-за
порядка identity bootstrap. Исправление ограничено `_app.tsx` и
regression-contract. Alembic head остаётся `0012`; `0013`, physical
rename и migration squash запрещены.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.36

Universal CI остаётся единым для последующих циклов. Его два mirror-файла
byte-identical и имеют SHA-256
`8c69eca26bc59330e059fb04da9cf2ea43fc7405c048d1196ea06547fe6c9496`.
Test-only admin allowlist применяется только при CI frontend build для
route-backed Chromium evidence. Production admin authorization, full
pytest, PostgreSQL, Alembic, Mypy, Ruff, Bandit и Gate summary не
ослаблены. Physical rename и migration squash запрещены.

---

# Актуализация qualification boundary — v172.35

До полного exact-head PASS цикла `1630` запрещены physical rename,
compatibility cleanup и migration squash. Alembic head остаётся `0012`;
`0013` отсутствует. Новый canonical CI hash разрешён прямой командой
пользователя; Flake8/Ruff/Mypy/Bandit install commands не изменены.

---

# Актуализация qualification boundary — v172.34

Fresh exact-head CI v172.33 не закрыл цикл `1630`: PostgreSQL/API
negative contract получил wrong DB input profile, а Chromium proof был
пропущен. Corrective v172.34 исправляет только evidence/test harness,
stale contracts и Ruff. Production ownership, financial semantics,
migrations и CI workflows не меняются. Цикл `1631` не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация cross-provider session boundary — v172.33

Current HEAD: `EFHC_Bot_v172_33.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin business API требуют server-side Bearer
session. Raw Telegram `initData` допускается только как credential для
явного `/auth/telegram/session`, а не как business-auth fallback.
Canonical owner остаётся `global_id`; internal legacy `tg_id` selector
до `1631` разрешён только после session → global_id resolution.
Financial write semantics, precision, idempotency и formulas не менялись.
Цикл `1631` не начат. SSOT имеет приоритет при конфликте канона.

---

# Актуализация session-first ownership — v172.32

Current HEAD: `EFHC_Bot_v172_32.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin API используют server-side Bearer
session как primary transport и canonical `global_id` как owner.
Legacy Telegram transport остаётся измеряемой compatibility-веткой.
Frontend owner cache использует `GlobalId`. Financial write semantics,
precision, idempotency и formulas не менялись. Cycle `1630` не начат.
SSOT имеет приоритет над техническими заданиями при конфликте канона.

---

# Актуализация identity ownership — v172.31

Current HEAD: `EFHC_Bot_v172_30.zip`. Alembic head `0011`. Financial read switch использует `global_id`; legacy writes, dual-write, precision, idempotency и formulas неизменны. Cycle `1628` не начат. SSOT имеет приоритет над техническими заданиями при конфликте текущего канона.

---

# Актуальные блокировки v172.29

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Текущий Alembic head `0010`; `0011` отсутствует.
Цикл `1627` запрещён до exact-head real PostgreSQL qualification
financial shadow validation `1626`. Денежные значения, precision и
idempotency не изменяются.

---

# Актуальные блокировки v172.28

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует. Cycle `1626` — только
read-only financial shadow validation. Денежное расхождение должно быть
`0.00000000`; Numeric precision/scale и idempotency semantics неизменны.
Financial read switch запрещён до `1627` и fresh exact-HEAD proof.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# Актуальные блокировки v172.27

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими
заданиями. Guards и фактический production code не отменяются новым
ТЗ неявно.

Текущий Alembic head: `0010`; `0011` отсутствует.
Non-financial reads могут переключаться на `global_id` только при
нулевой telemetry. Legacy writes и dual-write остаются активными.
Financial reads, precision и formulas запрещено менять в `1625`.
Physical rename запрещён до `1631`; squash — до `1632`.

---

# ARCHITECTURAL LOCKS

## SSOT / Приоритет документов

SSOT и architectural locks имеют приоритет над любыми техническими заданиями.

При конфликте требований приоритет имеют действующие architectural locks,
машинные guards и фактический production code; новое ТЗ не отменяет их
неявно и должно изменять канон только отдельным зафиксированным решением.

# EFHC — активные архитектурные блокировки

Текущий пакет: `v172.26`.

Жёстко зафиксировано:

- `global_id` — главный и постоянный account owner;
- `users.user_id` остаётся физическим legacy-именем до `1631`;
- отдельная физическая `users.global_id` рядом запрещена;
- Alembic head `0009`, migration `0010` отсутствует;
- legacy runtime ownership остаётся authoritative;
- dual-write conflict/orphan должен завершаться fail closed;
- telemetry только наблюдает shadow state и не делает read switch;
- financial values/precision/idempotency не меняются;
- цикл `1625` запрещён до fresh qualification `v172.26`;
- migration squash запрещён до `1632`;
- CI workflow нельзя менять без прямой команды пользователя.

SSOT имеет приоритет над отдельными техническими заданиями при их
противоречии, если пользователь прямо не изменил канон.
