import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import {
  brotliCompressSync,
  constants,
  gzipSync,
} from "node:zlib";
import { dirname, join, resolve } from "node:path";

const root = process.cwd();
const projectRoot = resolve(root, "..");
const nextRoot = join(root, ".next");
const manifest = JSON.parse(
  readFileSync(join(nextRoot, "build-manifest.json"), "utf8"),
);
const archiveVersion = process.env.EFHC_RELEASE_VERSION || "v172.86";
const baselineVersion =
  process.env.EFHC_BASELINE_VERSION || "v172.48";
const minimumSupportedSourceVersion =
  process.env.EFHC_MINIMUM_SOURCE_VERSION || "v172.44";
const outputPath = resolve(
  process.env.EFHC_BUDGET_OUTPUT ||
    join(
      projectRoot,
      "reports/generated",
      `frontend_compressed_route_budgets_${archiveVersion}.json`,
    ),
);
const baselinePath = resolve(
  process.env.EFHC_BUDGET_BASELINE ||
    join(
      projectRoot,
      "reports/generated",
      `frontend_compressed_route_budgets_${baselineVersion}.json`,
    ),
);

function limits(route) {
  if (route === "/faq") return { gzip: 300_000, brotli: 250_000 };
  if (route.startsWith("/admin")) {
    return { gzip: 420_000, brotli: 350_000 };
  }
  return { gzip: 420_000, brotli: 370_000 };
}

function readBaseline() {
  if (!existsSync(baselinePath)) return new Map();
  try {
    const value = JSON.parse(readFileSync(baselinePath, "utf8"));
    return new Map((value.rows || []).map((row) => [row.route, row]));
  } catch {
    return new Map();
  }
}

function delta(current, previous) {
  if (!Number.isFinite(previous) || previous <= 0) return null;
  return Number((((current - previous) / previous) * 100).toFixed(2));
}

const baseline = readBaseline();
const rows = [];
for (const [route, files] of Object.entries(manifest.pages || {})) {
  const assets = [...new Set(files)].filter(
    (file) => file.endsWith(".js") || file.endsWith(".css"),
  );
  let raw = 0;
  let gzip = 0;
  let brotli = 0;
  for (const file of assets) {
    const path = join(nextRoot, file);
    const content = readFileSync(path);
    raw += statSync(path).size;
    gzip += gzipSync(content, { level: 9 }).length;
    brotli += brotliCompressSync(content, {
      params: {
        [constants.BROTLI_PARAM_QUALITY]: 5,
      },
    }).length;
  }
  const budget = limits(route);
  const previous = baseline.get(route) || {};
  const gzipDelta = delta(gzip, Number(previous.gzip_bytes));
  const brotliDelta = delta(brotli, Number(previous.brotli_bytes));
  const regression =
    (gzipDelta !== null && gzipDelta > 12) ||
    (brotliDelta !== null && brotliDelta > 12);
  rows.push({
    route,
    assets: assets.length,
    raw_bytes: raw,
    gzip_bytes: gzip,
    brotli_bytes: brotli,
    gzip_budget: budget.gzip,
    brotli_budget: budget.brotli,
    previous_gzip_bytes: previous.gzip_bytes || null,
    previous_brotli_bytes: previous.brotli_bytes || null,
    gzip_delta_percent: gzipDelta,
    brotli_delta_percent: brotliDelta,
    comparison: regression ? "REGRESSION_REVIEW" : "OK",
    status:
      gzip <= budget.gzip && brotli <= budget.brotli
        ? "PASS"
        : "FAIL",
  });
}
rows.sort((left, right) => left.route.localeCompare(right.route));
const failed = rows.filter((row) => row.status === "FAIL");
const review = rows.filter(
  (row) => row.comparison === "REGRESSION_REVIEW",
);
mkdirSync(dirname(outputPath), { recursive: true });
writeFileSync(
  outputPath,
  JSON.stringify(
    {
      schema: "EFHC_FRONTEND_COMPRESSED_ROUTE_BUDGETS_V2",
      archive_version: archiveVersion,
      baseline_archive_version: baselineVersion,
      minimum_supported_source_version: minimumSupportedSourceVersion,
      baseline_available: baseline.size > 0,
      status: failed.length ? "FAILED" : "PASSED",
      routes: rows.length,
      failed_routes: failed.map((row) => row.route),
      regression_review_routes: review.map((row) => row.route),
      rows,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  `EFHC COMPRESSED ROUTE BUDGETS: ${failed.length ? "FAIL" : "PASS"}; ` +
    `routes=${rows.length}; failed=${failed.length}; review=${review.length}`,
);
if (failed.length) process.exit(1);
