import React, { useEffect, useMemo, useState } from "react";

import { AdminPage } from "../../components/admin/AdminPage";
import { AdminRouteHealthStrip } from
  "../../components/admin/AdminRouteHealthStrip";
import {
  AdminPromptModal,
  type AdminPromptField,
} from "../../components/admin/AdminPromptModal";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useT } from "../../hooks/useT";
import {
  adminPath,
  ADMIN_HUB_LINK_CREATE_PATH,
  ADMIN_HUB_LINK_REORDER_PATH,
  ADMIN_HUB_LINK_TOGGLE_PATH,
  ADMIN_HUB_LINK_UPDATE_PATH,
  ADMIN_HUB_LINKS_PATH,
  type AdminHubLink,
  type AdminHubLinkCreateRequest,
  type AdminHubLinkUpdateRequest,
} from "../../lib/api/generated/adminSeams";
import {
  adminSafeLoadError,
  adminUiErrorMessage,
} from "../../lib/adminError";
import {
  useAdminLinkedTransport,
} from "../../queries/useAdminLinkedTransport";

type HubLink = AdminHubLink;

type FormState = Record<string, string>;

function newIdk(prefix: string) {
  const c: any = globalThis.crypto;
  const fallback = `${Date.now()}-${Math.random()}`;
  const uuid = c?.randomUUID ? c.randomUUID() : fallback;
  return `${prefix}:${uuid}`;
}

function linkToForm(link?: HubLink | null): FormState {
  return {
    code: link?.code || "",
    title: link?.title || "",
    subtitle: link?.subtitle || "",
    url: link?.url || "",
    target_kind: link?.target_kind || "external",
    open_mode: link?.open_mode || "external",
    sort_order: String(link?.sort_order ?? 100),
    is_active: String(link?.is_active ?? true),
    icon_key: link?.icon_key || "",
  };
}

export default function AdminHubPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [links, setLinks] = useState<HubLink[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<HubLink | null>(null);
  const [form, setForm] = useState<FormState>(linkToForm());

  const activeCount = useMemo(
    () => links.filter((item) => item.is_active).length,
    [links],
  );

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApiRequest<HubLink[]>(
        ADMIN_HUB_LINKS_PATH,
        "GET",
      );
      setLinks(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  function openCreate() {
    setEditing(null);
    setForm(linkToForm());
    setModalOpen(true);
  }

  function openEdit(link: HubLink) {
    setEditing(link);
    setForm(linkToForm(link));
    setModalOpen(true);
  }

  async function submitLink() {
    const code = form.code.trim();
    const title = form.title.trim();
    const url = form.url.trim();
    const target_kind = form.target_kind.trim();
    const open_mode = form.open_mode.trim();
    const sort_order = Number.parseInt(form.sort_order || "100", 10);
    const is_active = form.is_active !== "false";
    const subtitle = form.subtitle.trim();
    const icon_key = form.icon_key.trim();

    if (!code || !title || !url || !target_kind || !open_mode) {
      setError(t("admin.hub_form_required"));
      return;
    }

    if (!Number.isFinite(sort_order) || sort_order < 0) {
      setError(t("admin.hub_sort_invalid"));
      return;
    }

    const body:
      | AdminHubLinkCreateRequest
      | AdminHubLinkUpdateRequest = {
      ...(editing ? {} : { code }),
      title,
      subtitle: subtitle || null,
      url,
      target_kind,
      open_mode,
      sort_order,
      is_active,
      icon_key: icon_key || null,
    };

    setLoading(true);
    setError(null);
    try {
      if (editing) {
        await adminApiRequest<HubLink>(
          // Guard anchor: adminPath(ADMIN_HUB_LINK_UPDATE_PATH
          adminPath(
            ADMIN_HUB_LINK_UPDATE_PATH,
            { link_id: editing.id },
          ),
          "PUT",
          {
            idempotencyKey: newIdk(`admin-hub-update-${editing.id}`),
            body,
          },
        );
      } else {
        await adminApiRequest<HubLink>(
          ADMIN_HUB_LINK_CREATE_PATH,
          "POST",
          {
            idempotencyKey: newIdk(`admin-hub-create-${code}`),
            body,
          },
        );
      }
      setModalOpen(false);
      setEditing(null);
      setForm(linkToForm());
      await load();
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function toggleLink(link: HubLink) {
    setLoading(true);
    setError(null);
    try {
      await adminApiRequest<HubLink>(
        adminPath(ADMIN_HUB_LINK_TOGGLE_PATH, { link_id: link.id }),
        "POST",
        {
          idempotencyKey: newIdk(`admin-hub-toggle-${link.id}`),
          body: { is_active: !link.is_active },
        },
      );
      await load();
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function reorderLink(link: HubLink, direction: -1 | 1) {
    const sorted = [...links].sort(
      (a, b) => a.sort_order - b.sort_order || a.id - b.id,
    );
    const index = sorted.findIndex((item) => item.id === link.id);
    const swapIndex = index + direction;
    if (index < 0 || swapIndex < 0 || swapIndex >= sorted.length) {
      return;
    }

    const current = sorted[index];
    const swap = sorted[swapIndex];
    const items = [
      { id: current.id, sort_order: swap.sort_order },
      { id: swap.id, sort_order: current.sort_order },
    ];

    setLoading(true);
    setError(null);
    try {
      await adminApiRequest<HubLink[]>(
        ADMIN_HUB_LINK_REORDER_PATH,
        "POST",
        {
          idempotencyKey: newIdk(`admin-hub-reorder-${current.id}`),
          body: { items },
        },
      );
      await load();
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const sortedLinks = [...links].sort(
    (a, b) => a.sort_order - b.sort_order || a.id - b.id,
  );

  const promptFieldsBase: AdminPromptField[] = [
    { key: "code", label: t("admin.hub_code") },
    { key: "title", label: t("admin.hub_title") },
    {
      key: "subtitle",
      label: t("admin.hub_subtitle"),
      type: "textarea",
    },
    { key: "url", label: t("admin.hub_url") },
    {
      key: "target_kind",
      label: t("admin.hub_target_kind"),
    },
    { key: "open_mode", label: t("admin.hub_open_mode") },
    {
      key: "sort_order",
      label: t("admin.hub_sort_order"),
      type: "number",
    },
    { key: "is_active", label: t("admin.hub_is_active_hint") },
    { key: "icon_key", label: t("admin.hub_icon_key") },
  ];

  const promptFields: AdminPromptField[] = promptFieldsBase.map(
    (field): AdminPromptField => ({
      ...field,
      placeholder:
        field.key === "code" && editing
          ? t("admin.hub_code_locked")
          : undefined,
    }),
  );

  return (
    <AdminPage
      title={t("admin.hub")}
      subtitle={t("admin.hub_note")}
      backHref="/admin"
    >
      <AdminRouteHealthStrip
        title="Диагностика маршрута"
        subtitle={
          "Маршруты управления Hub-ссылками доступны " +
          "admin hub page."
        }
        items={[
          {
            label: "list",
            path: ADMIN_HUB_LINKS_PATH,
            tone: "connected",
          },
          {
            label: "create",
            path: ADMIN_HUB_LINK_CREATE_PATH,
            tone: "warning",
          },
          {
            label: "update",
            path: ADMIN_HUB_LINK_UPDATE_PATH,
            tone: "warning",
          },
          {
            label: "toggle",
            path: ADMIN_HUB_LINK_TOGGLE_PATH,
            tone: "warning",
          },
          {
            label: "reorder",
            path: ADMIN_HUB_LINK_REORDER_PATH,
            tone: "warning",
          },
        ]}
      />
      <div className="efhc-admin-kpi-grid">
        <Card title={t("admin.hub_links_summary")}>
          <div
            className="efhc-admin-kpi-grid
            efhc-admin-kpi-grid--compact"
          >
            <div className="efhc-admin-kpi">
              <div className="efhc-admin-kpi_label">
                {t("admin.hub_links_total")}
              </div>
              <div className="efhc-admin-kpi_value tabular-nums">
                {links.length}
              </div>
            </div>
            <div className="efhc-admin-kpi">
              <div className="efhc-admin-kpi_label">
                {t("admin.hub_links_active")}
              </div>
              <div className="efhc-admin-kpi_value tabular-nums">
                {activeCount}
              </div>
            </div>
          </div>
        </Card>
        <Card title={t("admin.hub_links_table")}>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              onClick={() => void load()}
              disabled={loading}
            >
              {loading ? t("common.loading") : t("common.refresh")}
            </Button>
            <Button onClick={openCreate}>
              {t("admin.hub_link_create")}
            </Button>
          </div>
          {error ? (
            <div className="efhc-admin-error mb-2">{error || null}</div>
          ) : null}
          <div className="efhc-admin-table-wrap">
            <table className="efhc-admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>{t("admin.hub_code")}</th>
                  <th>{t("admin.hub_title")}</th>
                  <th>{t("admin.hub_target_kind")}</th>
                  <th>{t("admin.hub_open_mode")}</th>
                  <th>{t("admin.hub_sort_order")}</th>
                  <th>{t("admin.hub_active")}</th>
                  <th>{t("admin.hub_actions")}</th>
                </tr>
              </thead>
              <tbody>
                {sortedLinks.map((link, index) => (
                  <tr key={link.id}>
                    <td>{link.id}</td>
                    <td>{link.code}</td>
                    <td>
                      <div>{link.title}</div>
                      {link.subtitle ? (
                        <div className="text-xs efhc-text-muted">
                          {link.subtitle}
                        </div>
                      ) : null}
                    </td>
                    <td>{link.target_kind}</td>
                    <td>{link.open_mode}</td>
                    <td>{link.sort_order}</td>
                    <td>
                      {link.is_active
                        ? t("common.yes")
                        : t("common.no")}
                    </td>
                    <td>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          variant="secondary"
                          onClick={() => openEdit(link)}
                          disabled={loading}
                        >
                          {t("common.edit")}
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => void toggleLink(link)}
                          disabled={loading}
                        >
                          {link.is_active
                            ? t("admin.hub_disable")
                            : t("admin.hub_enable")}
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => {
                            void reorderLink(link, -1);
                          }}
                          disabled={loading || index === 0}
                        >
                          {t("admin.hub_move_up")}
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => {
                            void reorderLink(link, 1);
                          }}
                          disabled={
                            loading || index === sortedLinks.length - 1
                          }
                        >
                          {t("admin.hub_move_down")}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <AdminPromptModal
        open={modalOpen}
        title={
          editing
            ? t("admin.hub_link_edit")
            : t("admin.hub_link_create")
        }
        submitLabel={
          editing ? t("common.save") : t("admin.hub_link_create")
        }
        fields={promptFields}
        values={editing ? { ...form, code: editing.code } : form}
        busy={loading}
        onChange={(key, value) => {
          if (editing && key === "code") {
            return;
          }
          setForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => {
          setModalOpen(false);
          setEditing(null);
          setForm(linkToForm());
        }}
        onSubmit={() => {
          void submitLink();
        }}
      />
    </AdminPage>
  );
}
