import React from "react";

import { EfhcCoinIcon } from "../../components/icons/EfhcCoin";
import { useT } from "../../hooks/useT";
import { hapticMedium, hapticSoft } from "../../lib/telegram";
import { useHubEfhcHandoff } from "../../queries/useHub";
import { GamePageShell } from "../../components/ui/GameShell";

const VIP_URL = "https://getgems.io/efhc-nft";
const VIP_STAR_PATH = [
  "m20 10.2 3 6.1 6.8 1-4.9 4.7 1.15 6.7",
  "L20 25.5l-6.05 3.2 1.15-6.7-4.9-4.7 6.8-1 3-6.1Z",
].join("");

function openExternal(url: string) {
  if (typeof window === "undefined") return;
  const tg = (globalThis as any)?.Telegram?.WebApp;
  if (typeof tg?.openLink === "function") {
    tg.openLink(url);
    return;
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

function VipCollectionIcon() {
  return (
    <svg
      width="38"
      height="38"
      viewBox="0 0 40 40"
      fill="none"
      aria-hidden="true"
      data-hub-icon="vip-nft-collection"
    >
      <path
        d="M20 4.5 34 13.3l-5.2 18.2H11.2L6 13.3 20 4.5Z"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinejoin="round"
      />
      <path
        d={VIP_STAR_PATH}
        fill="currentColor"
        fillOpacity="0.18"
        stroke="currentColor"
        strokeWidth="1.45"
        strokeLinejoin="round"
      />
      <circle cx="20" cy="20" r="2.25" fill="currentColor" />
    </svg>
  );
}

export default function HubPage() {
  const t = useT();
  const handoff = useHubEfhcHandoff();

  const onTopUp = async () => {
    hapticSoft(true);
    try {
      const out = await handoff.mutateAsync();
      openExternal(out.redirect_url);
    } catch {
      hapticSoft(true);
    }
  };

  const onVipCollection = () => {
    hapticMedium(true);
    openExternal(VIP_URL);
  };

  return (
    <GamePageShell
      className="efhc-hub-page efhc-hub-two-actions"
      data-public-surface="hub"
      data-hub-runtime="two-canonical-actions"
      data-hub-visible-action-count="2"
      data-hub-commerce-copy="forbidden-before-exit"
      data-vip-nft-link-policy="external-getgems"
    >
      <section
        className="efhc-hub-choice-grid"
        aria-label={t("hub.title")}
      >
        <button
          type="button"
          className="efhc-hub-choice"
          data-hub-action="top-up"
          data-hub-handoff-kind="external-top-up"
          disabled={handoff.isPending}
          aria-busy={handoff.isPending}
          onClick={() => {
            if (!handoff.isPending) void onTopUp();
          }}
        >
          <span className="efhc-hub-choice_icon" aria-hidden="true">
            <EfhcCoinIcon size={38} />
          </span>
          <strong>
            {handoff.isPending
              ? t("common.loading")
              : t("hub.action_top_up_efhc")}
          </strong>
        </button>

        <button
          type="button"
          className="efhc-hub-choice"
          data-hub-action="vip-nft"
          onClick={onVipCollection}
        >
          <span className="efhc-hub-choice_icon" aria-hidden="true">
            <VipCollectionIcon />
          </span>
          <strong>{t("hub.action_vip_nft")}</strong>
        </button>
      </section>
    </GamePageShell>
  );
}
