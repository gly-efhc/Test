import {
  normalizeTonConnectTx,
} from "../../lib/ton/tonconnect-normalize";

export { normalizeTonConnectTx };
