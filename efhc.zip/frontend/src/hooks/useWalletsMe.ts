import { useQuery } from "@tanstack/react-query";

import { apiRequest } from "../lib/api";

type WalletItem = {
  id: number;
  wallet_address: string;
  wallet_app: string | null;
  is_primary: boolean;
  is_active: boolean;
  created_at: string;
};

type WalletMeOut = {
  is_connected: boolean;
  wallets: WalletItem[];
};

export function useWalletsMe(tg_id: number | null) {
  return useQuery({
    queryKey: ["wallets_me", tg_id],
    enabled: Boolean(tg_id),
    queryFn: async () => {
      const r = (await apiRequest(
        "/wallets/me",
        "GET",
      )) as WalletMeOut;
      return r;
    },
    staleTime: 10_000,
  });
}
