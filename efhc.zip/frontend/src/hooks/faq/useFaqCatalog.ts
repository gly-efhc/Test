import { useMemo } from "react";
import type { Lang } from "../../lib/i18n";
import { getFaqCatalog } from "../../data/faq";

export function useFaqCatalog(lang: Lang) {
  return useMemo(() => getFaqCatalog(lang), [lang]);
}
