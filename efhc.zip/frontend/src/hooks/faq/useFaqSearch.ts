import { useMemo, useState } from "react";
import type { FaqCatalog } from "../../data/faq/types";
import { searchFaq } from "../../data/faq";

export function useFaqSearch(catalog: FaqCatalog) {
  const [query, setQuery] = useState("");
  const results = useMemo(() => {
    return searchFaq(catalog, query).slice(0, 24);
  }, [catalog, query]);
  return {
    query,
    setQuery,
    clearQuery: () => setQuery(""),
    results,
    hasQuery: Boolean(query.trim()),
  };
}
