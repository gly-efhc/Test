export type PanelsSummary = {
  active_count: number;
  total_generated_by_panels: string;
  nearest_expire_at?: string | null;
};
