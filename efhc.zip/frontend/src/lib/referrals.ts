import { apiRequest } from "./api";

export type ReferralItem = {
  child_tg_id: number;
  username?: string | null;
  is_active: boolean;
};

export type ReferralsPageOut = {
  items: ReferralItem[];
  next_cursor: string | null;
};

export type ReferralsStatsOut = {
  bonus_balance: string;
  referrals_bonus_total: string;
  total_referrals: number;
  active_referrals: number;
  inactive_referrals: number;
  level: number;
  next_level: number | null;
  refs_to_next: number;
  progress: number;
  referral_code: string;
  referral_link: string | null;
};

export async function fetchReferralsStats(
  parent_tg_id: number,
): Promise<ReferralsStatsOut> {
  return await apiRequest<ReferralsStatsOut>(
    `/referrals/stats?parent_tg_id=${parent_tg_id}`,
    "GET",
  );
}

export async function fetchReferralsPage(
  parent_tg_id: number,
  tab: "active" | "inactive",
  cursor: string | null,
): Promise<ReferralsPageOut> {
  const base = tab === "active"
    ? "/referrals/active"
    : "/referrals/inactive";
  const p = new URLSearchParams();
  p.set("parent_tg_id", String(parent_tg_id));
  p.set("limit", "100");
  p.set("sync", "true");
  if (cursor) p.set("cursor", cursor);
  return await apiRequest<ReferralsPageOut>(
    `${base}?${p.toString()}`,
    "GET",
  );
}
