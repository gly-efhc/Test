export type EfhcIntentPurpose =
  | "deposit_efhc"
  | "shop_external";

export function buildEfhcIntentPayload(
  purpose: EfhcIntentPurpose,
  intentId: number,
  tg_id: number,
): string {
  const intent = Number(intentId);
  const user = Number(tg_id);
  if (!Number.isInteger(intent) || intent <= 0) {
    throw new Error("INVALID_INTENT_ID");
  }
  if (!Number.isInteger(user) || user <= 0) {
    throw new Error("INVALID_TG_ID");
  }
  return `EFHC:${purpose}:${intent}:${user}`;
}

export function isCanonicalEfhcIntentPayload(
  value: string,
): boolean {
  return /^EFHC:(deposit_efhc|shop_external):\d+:\d+$/.test(
    String(value || "").trim(),
  );
}
