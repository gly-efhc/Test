import type { TonConnectMessage, TonConnectTx } from "./tx";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

export function normalizeTonConnectMessage(
  raw: unknown,
): TonConnectMessage | null {
  if (!isRecord(raw)) return null;
  const address = String(raw.address || "").trim();
  const amount = String(raw.amount || "").trim();
  const payload = raw.payload == null
    ? undefined
    : String(raw.payload || "").trim();
  if (!address || !amount) return null;
  return { address, amount, payload };
}

export function normalizeTonConnectTx(
  raw: unknown,
): TonConnectTx | null {
  if (!isRecord(raw)) return null;
  const validUntil = Number(raw.validUntil || 0);
  const messagesRaw = Array.isArray(raw.messages)
    ? raw.messages
    : [];
  const messages = messagesRaw
    .map(normalizeTonConnectMessage)
    .filter((x): x is TonConnectMessage => x !== null);
  if (!Number.isFinite(validUntil) || validUntil <= 0) {
    return null;
  }
  if (!messages.length) {
    return null;
  }
  return { validUntil, messages };
}
