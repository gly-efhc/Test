import type { RecipientTarget } from "./recipient";

/** Canonical EFHC request for a TON-compatible wallet transport. */
export type TonWalletMessage = {
  address: string;
  amount: string;
  payload?: string;
  stateInit?: string;
};

export type TonWalletTransaction = {
  validUntil: number;
  messages: TonWalletMessage[];
};

/** @deprecated Compatibility aliases for existing API and tests. */
export type TonConnectMessage = TonWalletMessage;
/**
 * @deprecated Application code uses TonWalletTransaction.
 */
export type TonConnectTx = TonWalletTransaction;

export type JettonTransferPlan = {
  asset: "USDT" | "EFHC";
  decimals: number;
  queryId: bigint;
  amountUnits: bigint;
  payloadText: string;
  recipient: RecipientTarget;
  feeMessageTonAmount: string;
  forwardTonAmount: string;
  senderOwnerAddress: string;
  responseDestination: string;
  jettonMasterAddress: string;
};
