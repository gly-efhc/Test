import { Address, beginCell } from "@ton/core";
import {
  resolveSenderJettonWallet,
} from "./jetton-transfer-builder";
import {
  EFHC_JETTON_DECIMALS,
  EFHC_JETTON_MASTER_ADDRESS,
} from "./constants";
import { parseEfhcJettonD8 } from "./units";
import type { TonConnectTx } from "./tx";

function buildBodyBase64(args: {
  amountUnits: bigint;
  recipientOwnerAddress: string;
  responseDestination: string;
}): string {
  const body = beginCell()
    .storeUint(0x0f8a7ea5, 32)
    .storeUint(0n, 64)
    .storeCoins(args.amountUnits)
    .storeAddress(Address.parse(args.recipientOwnerAddress))
    .storeAddress(Address.parse(args.responseDestination))
    .storeBit(0)
    .storeCoins(0n)
    .storeBit(0)
    .endCell();
  return body.toBoc().toString("base64");
}

export async function buildEfhcWithdrawTonConnectTx(args: {
  endpoint: string;
  senderOwnerAddress: string;
  recipientOwnerAddress: string;
  amountEfhc: string;
  feeMessageTonAmount: string;
}): Promise<TonConnectTx> {
  const senderJettonWallet = await resolveSenderJettonWallet({
    endpoint: args.endpoint,
    ownerAddress: args.senderOwnerAddress,
    jettonMasterAddress: EFHC_JETTON_MASTER_ADDRESS,
  });
  const amountUnits = parseEfhcJettonD8(args.amountEfhc);
  if (amountUnits <= 0n) {
    throw new Error("INVALID_EFHC_WITHDRAW_AMOUNT");
  }
  const payload = buildBodyBase64({
    amountUnits,
    recipientOwnerAddress: args.recipientOwnerAddress,
    responseDestination: args.senderOwnerAddress,
  });
  return {
    validUntil: Math.floor(Date.now() / 1000) + 600,
    messages: [
      {
        address: senderJettonWallet,
        amount: String(args.feeMessageTonAmount || "0"),
        payload,
      },
    ],
  };
}

export const EFHC_WITHDRAW_DECIMALS = EFHC_JETTON_DECIMALS;
