// AUTO-GENERATED FILE. DO NOT EDIT MANUALLY.
// Source: ops/openapi/generate_frontend_seam_types.py

import {
  apiRequest,
  type ApiRequestOptions,
  type HttpMethod,
} from "../../api";

export function adminPath(
  template: string,
  values: Record<string, string | number>,
): string {
  let out = template;
  for (const [key, value] of Object.entries(values)) {
    out = out.replace(
      `{${key}}`,
      encodeURIComponent(String(value)),
    );
  }
  return out;
}

export async function adminApiRequest<T>(
  path: string,
  method: HttpMethod,
  opts: ApiRequestOptions = {},
): Promise<T> {
  return apiRequest<T>(path, method, opts);
}

export const ADMIN_ADS_PROVIDERS_PATH =
  "/admin/ads/providers" as const;
export const ADMIN_BANK_BALANCE_PATH =
  "/admin/bank/balance" as const;
export const ADMIN_BANK_BURN_PATH =
  "/admin/bank/burn" as const;
export const ADMIN_BANK_MINT_PATH =
  "/admin/bank/mint" as const;
export const ADMIN_EFHC_DEPOSITS_PROCESS_PATH =
  "/admin/efhc-deposits/process" as const;
export const ADMIN_EFHC_DEPOSITS_REPROCESS_TX_HASH_PATH =
  "/admin/efhc-deposits/reprocess/{tx_hash}" as const;
export const ADMIN_EFHC_DEPOSITS_RUNTIME_SUMMARY_PATH =
  "/admin/efhc-deposits/runtime-summary" as const;
export const ADMIN_HUB_LINKS_PATH =
  "/admin/hub/links" as const;
export const ADMIN_HUB_LINKS_REORDER_PATH =
  "/admin/hub/links/reorder" as const;
export const ADMIN_HUB_LINKS_LINK_ID_PATH =
  "/admin/hub/links/{link_id}" as const;
export const ADMIN_HUB_LINKS_LINK_ID_TOGGLE_PATH =
  "/admin/hub/links/{link_id}/toggle" as const;
export const ADMIN_LOGS_TRANSFERS_PATH =
  "/admin/logs/transfers" as const;
export const ADMIN_OBSERVABILITY_EVENTS_PATH =
  "/admin/observability/events" as const;
export const ADMIN_OBSERVABILITY_HEALTH_PATH =
  "/admin/observability/health" as const;
export const ADMIN_OBSERVABILITY_SUMMARY_PATH =
  "/admin/observability/summary" as const;
export const ADMIN_OBSERVABILITY_TIMESERIES_PATH =
  "/admin/observability/timeseries" as const;
export const ADMIN_PANELS_PATH =
  "/admin/panels/" as const;
export const ADMIN_PANELS_PANEL_ID_ACTIVATE_PATH =
  "/admin/panels/{panel_id}/activate" as const;
export const ADMIN_PANELS_PANEL_ID_DEACTIVATE_PATH =
  "/admin/panels/{panel_id}/deactivate" as const;
export const ADMIN_REFERRALS_SUMMARY_PATH =
  "/admin/referrals/summary" as const;
export const ADMIN_REPORTS_BANK_PATH =
  "/admin/reports/bank" as const;
export const ADMIN_REPORTS_DEPOSITS_PATH =
  "/admin/reports/deposits" as const;
export const ADMIN_REPORTS_OVERVIEW_PATH =
  "/admin/reports/overview" as const;
export const ADMIN_REPORTS_PANELS_PATH =
  "/admin/reports/panels" as const;
export const ADMIN_REPORTS_USERS_PATH =
  "/admin/reports/users" as const;
export const ADMIN_REPORTS_WITHDRAWALS_PATH =
  "/admin/reports/withdrawals" as const;
export const ADMIN_SALE_PACKAGES_PATH =
  "/admin/sale-packages/" as const;
export const ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH =
  "/admin/sale-packages/{package_id}" as const;
export const ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH =
  "/admin/sale-packages/{package_id}/toggle" as const;
export const ADMIN_SHOP_ITEMS_PATH =
  "/admin/shop/items" as const;
export const ADMIN_SHOP_ITEMS_DELETE_PATH =
  "/admin/shop/items/delete" as const;
export const ADMIN_SHOP_ITEMS_SET_PRICE_PATH =
  "/admin/shop/items/set-price" as const;
export const ADMIN_SHOP_ITEMS_STATUS_PATH =
  "/admin/shop/items/status" as const;
export const ADMIN_SHOP_ITEMS_UPSERT_PATH =
  "/admin/shop/items/upsert" as const;
export const ADMIN_SHOP_ORDER_LEGACY_ORDER_ID_PATH =
  "/admin/shop/order/legacy/{order_id}" as const;
export const ADMIN_SHOP_ORDERS_PATH =
  "/admin/shop/orders" as const;
export const ADMIN_SHOP_ORDERS_USER_LEGACY_TG_ID_PATH =
  "/admin/shop/orders/user/legacy/{tg_id}" as const;
export const ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH =
  "/admin/shop/orders/{order_id}/force-fulfill" as const;
export const ADMIN_TASKS_PATH =
  "/admin/tasks/" as const;
export const ADMIN_TASKS_REFRESH_STATUSES_PATH =
  "/admin/tasks/refresh-statuses" as const;
export const ADMIN_TASKS_SUBMISSIONS_SUBMISSION_ID_MODERATE_PATH =
  "/admin/tasks/submissions/{submission_id}/moderate" as const;
export const ADMIN_TASKS_TASK_ID_PATH =
  "/admin/tasks/{task_id}" as const;
export const ADMIN_TASKS_TASK_ID_SUBS_PATH =
  "/admin/tasks/{task_id}/subs" as const;
export const ADMIN_TEMPLATES_PATH =
  "/admin/templates" as const;
export const ADMIN_TEMPLATES_KEY_PATH =
  "/admin/templates/{key}" as const;
export const ADMIN_TON_RECONCILE_PATH =
  "/admin/ton/reconcile" as const;
export const ADMIN_TRANSFER_PATH =
  "/admin/transfer" as const;
export const ADMIN_USERS_SEARCH_PATH =
  "/admin/users/search" as const;
export const ADMIN_USERS_GLOBAL_ID_PATH =
  "/admin/users/{global_id}" as const;
export const ADMIN_USERS_GLOBAL_ID_ACTIVE_PATH =
  "/admin/users/{global_id}/active" as const;
export const ADMIN_USERS_GLOBAL_ID_VIP_PATH =
  "/admin/users/{global_id}/vip" as const;
export const ADMIN_USERS_GLOBAL_ID_WALLET_RESET_PATH =
  "/admin/users/{global_id}/wallet/reset" as const;
export const ADMIN_WITHDRAWALS_PATH =
  "/admin/withdrawals" as const;
export const ADMIN_WITHDRAWALS_REPAIR_CONSISTENCY_PATH =
  "/admin/withdrawals/repair-consistency" as const;
export const ADMIN_WITHDRAWALS_REQUEST_ID_APPROVE_PATH =
  "/admin/withdrawals/{request_id}/approve" as const;
export const ADMIN_WITHDRAWALS_REQUEST_ID_OUTCOME_PREVIEW_PATH =
  "/admin/withdrawals/{request_id}/outcome-preview" as const;
export const ADMIN_WITHDRAWALS_REQUEST_ID_REJECT_PATH =
  "/admin/withdrawals/{request_id}/reject" as const;
export const ADMIN_WITHDRAW_APPROVE_PATH =
  ADMIN_WITHDRAWALS_REQUEST_ID_APPROVE_PATH;
export const ADMIN_WITHDRAW_REJECT_PATH =
  ADMIN_WITHDRAWALS_REQUEST_ID_REJECT_PATH;
export const ADMIN_WITHDRAW_OUTCOME_PREVIEW_PATH =
  ADMIN_WITHDRAWALS_REQUEST_ID_OUTCOME_PREVIEW_PATH;
export const ADMIN_HUB_LINK_CREATE_PATH = ADMIN_HUB_LINKS_PATH;
export const ADMIN_HUB_LINK_UPDATE_PATH = ADMIN_HUB_LINKS_LINK_ID_PATH;
export const ADMIN_HUB_LINK_TOGGLE_PATH =
  ADMIN_HUB_LINKS_LINK_ID_TOGGLE_PATH;
export const ADMIN_HUB_LINK_REORDER_PATH = ADMIN_HUB_LINKS_REORDER_PATH;
export const ADMIN_REFERRAL_SUMMARY_PATH = ADMIN_REFERRALS_SUMMARY_PATH;

export type AdminReferralSummaryItem = {
  inviter_tg_id: number;
  active_count: number;
  inactive_count: number;
  total_bonus_efhc: string;
  last_invited_at: string | null;
};

export type AdminReferralSummaryResponse = {
  items: AdminReferralSummaryItem[];
  next_cursor: string | null;
};

export type AdminWithdrawalRecord = {
  id: number;
  tg_id: number;
  amount_efhc: string;
  status: string;
  external_address: string | null;
  tx_hash: string | null;
  created_at: string;
  processed_at: string | null;
  error_message: string | null;
  is_vip: boolean;
  payout_asset: string;
  tonconnect_transport_kind: string | null;
  jetton_master_address: string | null;
  jetton_decimals: number | null;
  fee_message_ton_amount: string | null;
};

export type AdminWithdrawRepairOut = {
  ok: boolean;
  auto_fixed_hold: number;
  auto_fixed_refund: number;
};

export type AdminBankMintBurnRequest = {
  amount: string;
  reason: string | null;
  idempotency_key: string;
};

export type AdminHubLink = {
  id: number;
  code: string;
  title: string;
  subtitle: string | null;
  url: string;
  target_kind: string;
  open_mode: string;
  sort_order: number;
  is_active: boolean;
  icon_key: string | null;
  created_at: string;
  updated_at: string;
};

export type AdminHubLinkCreateRequest = {
  code: string;
  title: string;
  subtitle: string | null;
  url: string;
  target_kind: string;
  open_mode: string;
  sort_order: number;
  is_active: boolean;
  icon_key: string | null;
};

export type AdminHubLinkUpdateRequest = {
  title: string;
  subtitle: string | null;
  url: string;
  target_kind: string;
  open_mode: string;
  sort_order: number;
  is_active: boolean;
  icon_key: string | null;
};

export type AdminHubLinkToggleRequest = {
  is_active: boolean;
};

export type AdminHubLinkReorderItem = {
  id: number;
  sort_order: number;
};

export type AdminHubLinkReorderRequest = {
  items: AdminHubLinkReorderItem[];
};

export type AdminBankBalanceResponse = {
  bank_name: string;
  efhc_main: string;
};

export type AdminBankMutationResponse = {
  ok: boolean;
  bank_balance_after: string;
};

export type AdminWithdrawApproveRequest = {
  tx_hash?: string | null;
  payout_ref?: string | null;
  wallet_send_confirmed?: boolean;
  wallet_provider?: string | null;
  sender_wallet_address?: string | null;
  comment_override?: string | null;
  comment_auto_translated?: boolean;
};

export type AdminWithdrawRejectRequest = {
  reason: string;
  comment_override?: string | null;
  comment_auto_translated?: boolean;
};

export type AdminWithdrawActionResponse = {
  ok: boolean;
  result: unknown;
};

export type AdminWithdrawOutcomeComment = {
  text: string;
  template_key?: string | null;
  source: string;
  locale: string;
  manual_override_used?: boolean;
  auto_translated?: boolean;
};

export type AdminWithdrawOutcomePromo = {
  enabled: boolean;
  key?: string | null;
  title?: string | null;
  body?: string | null;
  cta_label?: string | null;
  cta_url?: string | null;
  source?: string | null;
};

export type AdminWithdrawOutcomeBundle = {
  request_id: number;
  tg_id: number;
  outcome_kind: string;
  locale: string;
  comment: AdminWithdrawOutcomeComment;
  promo?: AdminWithdrawOutcomePromo | null;
  top_zone_enabled: boolean;
  metadata: Record<string, unknown>;
};

export type AdminWithdrawOutcomePreviewResponse = {
  request_id: number;
  withdrawal_status: string;
  preview_mode: string;
  bundle: AdminWithdrawOutcomeBundle;
};

export type AdminDomainReportTrendPoint = {
  bucket: string;
  value: number;
};

export type AdminDomainReportResponse = {
  ok: boolean;
  data_kind: 'real_timeseries';
  synthetic: boolean;
  domain: string;
  range_hours: number;
  generated_at: string;
  snapshot: Record<string, number>;
  trend: AdminDomainReportTrendPoint[];
  empty_reason: string | null;
};

export type AdminObservabilitySeriesPoint = {
  ts: string;
  value: string;
  label?: string | null;
};

export type AdminObservabilityTimeseriesResponse = {
  ok: boolean;
  data_kind: 'real_timeseries';
  synthetic: boolean;
  metric:
    | 'users_created'
    | 'panels_created'
    | 'withdrawals_created'
    | 'payment_intents_created'
    | 'efhc_transfer_count'
    | 'efhc_transfer_amount'
    | 'efhc_credit_amount'
    | 'efhc_debit_amount';
  bucket: 'hour' | 'day';
  range_hours: number;
  unit: string;
  source: string;
  points: AdminObservabilitySeriesPoint[];
  empty_reason?: string | null;
};

export type AdminObservabilitySummaryMetric = {
  key: string;
  label: string;
  value: string;
  unit: string;
  source: string;
  data_kind: 'raw' | 'derived';
};

export type AdminObservabilitySummaryResponse = {
  ok: boolean;
  data_kind: 'raw' | 'derived';
  generated_at: string;
  source: string;
  metrics: AdminObservabilitySummaryMetric[];
};

export type AdminObservabilityEvent = {
  id: string;
  type: string;
  severity: 'info' | 'success' | 'warning' | 'danger';
  title: string;
  description?: string | null;
  ts: string;
  route?: string | null;
  source: string;
};

export type AdminObservabilityEventsResponse = {
  ok: boolean;
  data_kind: 'raw';
  source: string;
  items: AdminObservabilityEvent[];
};

