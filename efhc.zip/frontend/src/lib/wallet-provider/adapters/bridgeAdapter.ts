import {
  WalletAdapterUnavailableError,
  WalletUserRejectedError,
  type PreparedWalletProof,
  type WalletAdapter,
  type WalletAdapterId,
  type WalletAdapterSnapshot,
  type WalletBindingResult,
  type WalletSession,
  type WalletTransactionRequest,
  type WalletTransactionResult,
  type WalletView,
} from "../types";

/**
 * Stable EFHC bridge for wallet APIs that are not published yet.
 * official Telegram/GRAM API is mapped inside its adapter only
 * pages never depend on the external API shape directly.
 */
export interface EfhcWalletAdapterBridgeV1 {
  readonly version: "1";
  getSnapshot(): Partial<WalletAdapterSnapshot>;
  subscribe?(listener: () => void): () => void;
  listWallets?(): Promise<WalletView[]>;
  prepareProof?(): Promise<unknown | null>;
  connect(): Promise<WalletSession | void>;
  bindWallet?(args: {
    proofState: unknown | null;
    session: WalletSession | null;
  }): Promise<WalletBindingResult | null>;
  disconnect(): Promise<void>;
  sendTransaction(tx: WalletTransactionRequest): Promise<{
    boc?: string | null;
    traceId?: string | null;
  }>;
  isUserRejected?(error: unknown): boolean;
}

type BridgeResolver = () => EfhcWalletAdapterBridgeV1 | null;

function emptySnapshot(): WalletAdapterSnapshot {
  return {
    available: false,
    restoreSettled: true,
    modalOpened: false,
    session: null,
  };
}

function normalizedSession(
  adapterId: WalletAdapterId,
  session: WalletSession | null | undefined,
): WalletSession | null {
  if (!session?.address) return null;
  return {
    adapterId,
    address: String(session.address),
    providerName: String(session.providerName || adapterId),
    raw: session.raw ?? null,
  };
}

function resolveOrThrow(
  adapterId: WalletAdapterId,
  resolver: BridgeResolver,
): EfhcWalletAdapterBridgeV1 {
  const bridge = resolver();
  if (!bridge || bridge.version !== "1") {
    throw new WalletAdapterUnavailableError(adapterId);
  }
  return bridge;
}

function genericUserRejected(error: unknown): boolean {
  const record = error as {
    code?: string | number;
    name?: string;
    message?: string;
  } | null;
  const text = [record?.code, record?.name, record?.message]
    .map((item) => String(item ?? "").toUpperCase())
    .join(" ");
  return text.includes("USER_REJECT")
    || text.includes("USER DECLINED")
    || text.includes("USER CANCELLED")
    || text.includes("USER CANCELED");
}

export function createBridgeWalletAdapter(args: {
  id: WalletAdapterId;
  label: string;
  resolveBridge: BridgeResolver;
}): WalletAdapter {
  const snapshot = (): WalletAdapterSnapshot => {
    const bridge = args.resolveBridge();
    if (!bridge || bridge.version !== "1") return emptySnapshot();
    try {
      const current = bridge.getSnapshot();
      return {
        available: current.available !== false,
        restoreSettled: current.restoreSettled !== false,
        modalOpened: Boolean(current.modalOpened),
        session: normalizedSession(args.id, current.session),
      };
    } catch {
      return emptySnapshot();
    }
  };

  return {
    id: args.id,
    label: args.label,
    getSnapshot: snapshot,
    subscribe(listener) {
      const bridge = args.resolveBridge();
      const unsubscribeBridge = bridge?.subscribe?.(listener)
        || (() => undefined);
      const eventName = `efhc:wallet-adapter:${args.id}`;
      if (typeof window !== "undefined") {
        window.addEventListener(eventName, listener);
      }
      return () => {
        unsubscribeBridge();
        if (typeof window !== "undefined") {
          window.removeEventListener(eventName, listener);
        }
      };
    },
    async listWallets() {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      const wallets = bridge.listWallets
        ? await bridge.listWallets()
        : [];
      return wallets.map((wallet) => ({
        ...wallet,
        adapterId: args.id,
      }));
    },
    async prepareProof() {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      if (!bridge.prepareProof) return null;
      const value = await bridge.prepareProof();
      return value === null || value === undefined
        ? null
        : { adapterId: args.id, value };
    },
    async connect() {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      await bridge.connect();
    },
    async bindWallet(proofState: PreparedWalletProof | null) {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      if (!bridge.bindWallet) return null;
      if (proofState && proofState.adapterId !== args.id) return null;
      return await bridge.bindWallet({
        proofState: proofState?.value ?? null,
        session: snapshot().session,
      });
    },
    async disconnect() {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      await bridge.disconnect();
    },
    async sendTransaction(
      tx: WalletTransactionRequest,
    ): Promise<WalletTransactionResult> {
      const bridge = resolveOrThrow(args.id, args.resolveBridge);
      try {
        const out = await bridge.sendTransaction(tx);
        return {
          boc: typeof out?.boc === "string" ? out.boc : null,
          traceId:
            typeof out?.traceId === "string" ? out.traceId : null,
          provider: args.id,
        };
      } catch (error) {
        if (
          bridge.isUserRejected?.(error)
          || genericUserRejected(error)
        ) {
          throw new WalletUserRejectedError(args.id);
        }
        throw error;
      }
    },
    isUserRejected(error: unknown) {
      const bridge = args.resolveBridge();
      return error instanceof WalletUserRejectedError
        || Boolean(bridge?.isUserRejected?.(error))
        || genericUserRejected(error);
    },
  };
}
