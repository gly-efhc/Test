import { useEffect, useRef } from "react";
import type { NextRouter } from "next/router";

const APP_BACK_BASE = "__efhcAppBackBaseV1";
const APP_BACK_GUARD = "__efhcAppBackGuardV1";
const APP_BACK_STACK_KEY = "efhc_app_back_stack_v1";
const APP_BACK_GUARD_HASH = "#efhc-app-back-guard";
const MAX_STACK_DEPTH = 48;

type AppHistoryState = Record<string, unknown> & {
  [APP_BACK_BASE]?: boolean;
  [APP_BACK_GUARD]?: boolean;
};

type AndroidBridgeWindow = Window & {
  __EFHC_ANDROID_BACK__?: () => void;
};

function pathWithoutHash(value: string): string {
  const index = value.indexOf("#");
  return index >= 0 ? value.slice(0, index) : value;
}

function readRouteStack(): string[] {
  try {
    const raw = window.sessionStorage.getItem(APP_BACK_STACK_KEY);
    const parsed = JSON.parse(raw || "[]") as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is string => typeof item === "string")
      .map(pathWithoutHash)
      .slice(-MAX_STACK_DEPTH);
  } catch {
    return [];
  }
}

function writeRouteStack(stack: string[]): void {
  try {
    window.sessionStorage.setItem(
      APP_BACK_STACK_KEY,
      JSON.stringify(stack.slice(-MAX_STACK_DEPTH)),
    );
  } catch {
    // Session history is a best-effort navigation aid only.
  }
}

function rememberRoute(value: string): void {
  const route = pathWithoutHash(value);
  const stack = readRouteStack();
  const existing = stack.lastIndexOf(route);
  if (existing >= 0) {
    writeRouteStack(stack.slice(0, existing + 1));
    return;
  }
  writeRouteStack([...stack, route]);
}

function previousRoute(currentValue: string): string {
  const current = pathWithoutHash(currentValue);
  const stack = readRouteStack();
  const index = stack.lastIndexOf(current);
  if (index > 0) return stack[index - 1];
  if (stack.length > 1) return stack[stack.length - 2];
  return "/";
}

export function navigateBackWithinApp(router: NextRouter): void {
  if (typeof window === "undefined") {
    void router.push("/");
    return;
  }
  const current = pathWithoutHash(router.asPath || router.pathname);
  if (current === "/") {
    void router.replace("/", undefined, { scroll: false });
    return;
  }

  const target = previousRoute(current);
  const state = (window.history.state || {}) as AppHistoryState;
  if (state[APP_BACK_GUARD] || window.history.length > 1) {
    router.back();
    return;
  }
  void router.push(target, undefined, { scroll: false });
}

export function useAppBackNavigation(router: NextRouter): void {
  const armingRef = useRef(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    let disposed = false;

    rememberRoute(router.asPath || router.pathname);

    const armGuard = async (): Promise<void> => {
      if (disposed || armingRef.current) return;
      armingRef.current = true;
      try {
        const route = pathWithoutHash(
          router.asPath || router.pathname,
        );
        const baseState = (
          window.history.state || {}
        ) as AppHistoryState;
        window.history.replaceState(
          {
            ...baseState,
            [APP_BACK_BASE]: true,
            [APP_BACK_GUARD]: false,
          },
          "",
          route,
        );
        await router.push(
          `${route}${APP_BACK_GUARD_HASH}`,
          undefined,
          { shallow: true, scroll: false },
        );
        if (disposed) return;
        const guardState = (
          window.history.state || {}
        ) as AppHistoryState;
        window.history.replaceState(
          {
            ...guardState,
            [APP_BACK_BASE]: false,
            [APP_BACK_GUARD]: true,
          },
          "",
          route,
        );
      } finally {
        armingRef.current = false;
      }
    };

    const recoverBaseEntry = (): void => {
      const current = pathWithoutHash(
        router.asPath || router.pathname,
      );
      window.setTimeout(() => {
        if (disposed) return;
        const recovery = current === "/"
          ? Promise.resolve(true)
          : router.replace("/", undefined, { scroll: false });
        void recovery.finally(() => {
          if (!disposed) void armGuard();
        });
      }, 0);
    };

    router.beforePopState(() => {
      const state = (
        window.history.state || {}
      ) as AppHistoryState;
      if (state[APP_BACK_BASE]) {
        recoverBaseEntry();
        return false;
      }
      return true;
    });

    const onRouteChange = (url: string): void => {
      rememberRoute(url);
    };
    router.events.on("routeChangeComplete", onRouteChange);

    const onNativeBack = (event: Event): void => {
      event.preventDefault?.();
      navigateBackWithinApp(router);
    };
    document.addEventListener("backbutton", onNativeBack);

    const bridgeWindow = window as AndroidBridgeWindow;
    const bridgeHandler = (): void => navigateBackWithinApp(router);
    bridgeWindow.__EFHC_ANDROID_BACK__ = bridgeHandler;

    void armGuard();

    return () => {
      disposed = true;
      router.beforePopState(() => true);
      router.events.off("routeChangeComplete", onRouteChange);
      document.removeEventListener("backbutton", onNativeBack);
      if (bridgeWindow.__EFHC_ANDROID_BACK__ === bridgeHandler) {
        delete bridgeWindow.__EFHC_ANDROID_BACK__;
      }
    };
  }, [router]);
}

export const APP_BACK_NAVIGATION_CONTRACT = {
  bridge: "window.__EFHC_ANDROID_BACK__",
  native_event: "backbutton",
  root_fallback: "/",
  storage: "sessionStorage",
} as const;
