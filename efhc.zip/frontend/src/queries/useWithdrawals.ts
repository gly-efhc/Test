import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import {
  cancelWithdrawRequest,
  createWithdrawRequest,
  getWalletBalanceHistory,
  getWithdrawDetail,
  getWithdrawOutcome,
  getWithdrawalsPage,
} from "../services/withdrawals.service";
import type { GlobalId } from "../types/identity";
import { queryKeys } from "./queryKeys";

export function useWithdrawalsPage(args: {
  tg_id: number | null;
  statusFilter: string;
}) {
  const globalId = useAuthOwnerGlobalId();
  return useInfiniteQuery({
    queryKey: queryKeys.withdrawals.list(
      globalId,
      args.statusFilter,
    ),
    enabled: Boolean(globalId),
    initialPageParam: null as string | null,
    queryFn: ({ pageParam, signal }) => getWithdrawalsPage({
      cursor: pageParam,
      statusFilter: args.statusFilter,
      signal,
    }),
    getNextPageParam: (lastPage) => lastPage.next_cursor ?? undefined,
  });
}

export function useWithdrawDetail(requestId: number | null) {
  return useQuery({
    queryKey: queryKeys.withdrawals.detail(requestId),
    enabled: Boolean(requestId),
    queryFn: ({ signal }) => getWithdrawDetail(requestId || 0, signal),
  });
}

export function useWalletBalanceHistory(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  return useQuery({
    queryKey: queryKeys.withdrawals.history(globalId),
    enabled: Boolean(globalId),
    queryFn: ({ signal }) => getWalletBalanceHistory(5, signal),
  });
}

export function useWithdrawOutcome(requestId: number | null) {
  return useQuery({
    queryKey: queryKeys.withdrawals.outcome(requestId),
    enabled: Boolean(requestId),
    queryFn: ({ signal }) => getWithdrawOutcome(requestId || 0, signal),
  });
}

async function invalidateWithdrawQueries(
  queryClient: ReturnType<typeof useQueryClient>,
  globalId: GlobalId | null,
  requestId?: number,
) {
  await Promise.all([
    queryClient.invalidateQueries({
      queryKey: queryKeys.withdrawals.all(globalId),
    }),
    queryClient.invalidateQueries({
      queryKey: queryKeys.snapshot.current(globalId),
    }),
    queryClient.invalidateQueries({
      queryKey: queryKeys.profile.balanceHistory(globalId),
    }),
    queryClient.invalidateQueries({
      queryKey: queryKeys.profile.withdrawHistory(globalId),
    }),
    requestId
      ? queryClient.invalidateQueries({
        queryKey: queryKeys.withdrawals.detail(requestId),
      })
      : Promise.resolve(),
  ]);
}

export function useCreateWithdrawRequest(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createWithdrawRequest,
    onSuccess: async (result) => {
      await invalidateWithdrawQueries(
        queryClient,
        globalId,
        result.id,
      );
    },
  });
}

export function useCancelWithdrawRequest(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: cancelWithdrawRequest,
    onSuccess: async (result) => {
      await invalidateWithdrawQueries(
        queryClient,
        globalId,
        result.id,
      );
    },
  });
}
