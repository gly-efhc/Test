import { useMutation, useQueryClient } from "@tanstack/react-query";

import {
  getShopLauncherResult,
  openShopExternal,
  type ShopLauncherResult,
} from "../lib/portal/shopLauncher";
import {
  createShopLauncherAccess,
  getShopLauncherTruth,
} from "../services/shopLauncher.service";

export function useShopLauncher() {
  const queryClient = useQueryClient();

  return useMutation<ShopLauncherResult, Error, void>({
    mutationFn: async () => {
      const truth = await queryClient.fetchQuery({
        queryKey: ["shop-launcher", "truth"],
        queryFn: getShopLauncherTruth,
        staleTime: 5_000,
      });
      const result = getShopLauncherResult(truth);
      if (result === "wallet_sync_required") {
        if (truth.wallet_sync_url) {
          openShopExternal(truth.wallet_sync_url);
        }
        return result;
      }
      if (result === "telegram_handoff_required") {
        const url = truth.telegram_sync_url || truth.bot_open_url;
        if (url) openShopExternal(url);
        return result;
      }
      if (result === "external_flow_unavailable") {
        return result;
      }
      const access = await createShopLauncherAccess();
      openShopExternal(access.redirect_url);
      return result;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["browser-shop"],
      });
    },
  });
}
