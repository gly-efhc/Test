import { z } from "zod";

import { apiRequest } from "../lib/api";

const TaskCatalogItemSchema = z.object({
  id: z.number(),
  code: z.string(),
  title: z.string(),
  description: z.unknown().optional(),
  bonus_efhc: z.string(),
  is_active: z.boolean().optional().default(true),
  kind: z.string().nullable().optional(),
  meta: z.record(z.unknown()).nullable().optional(),
});

const MyTaskItemSchema = z.object({
  id: z.number(),
  task_id: z.number(),
  status: z.string(),
  progress: z.record(z.unknown()).nullable().optional(),
  bonus_efhc: z.string(),
  can_claim: z.boolean(),
  next_available_at: z.string().nullable().optional(),
});

const TaskCatalogResponseSchema = z.object({
  items: z.array(TaskCatalogItemSchema),
});

const MyTasksResponseSchema = z.object({
  items: z.array(MyTaskItemSchema),
});

const ClaimTaskResponseSchema = z.object({
  ok: z.boolean(),
  tg_id: z.number(),
  task_id: z.number(),
  bonus_efhc: z.string(),
  bonus_balance: z.string(),
  main_balance: z.string(),
  detail: z.string().optional(),
});

const AdSlotResponseSchema = z.object({
  token: z.string(),
  min_view_sec: z.number().optional(),
});

const AdCallbackResponseSchema = z.object({
  ok: z.boolean().optional(),
  bonus_efhc: z.string().optional(),
  replayed: z.boolean().optional(),
  detail: z.string().optional(),
});

export type TaskCatalogItem = z.infer<typeof TaskCatalogItemSchema>;
export type MyTaskItem = z.infer<typeof MyTaskItemSchema>;
export type ClaimTaskResponse = z.infer<typeof ClaimTaskResponseSchema>;
export type AdSlotResponse = z.infer<typeof AdSlotResponseSchema>;
export type AdCallbackResponse = z.infer<
  typeof AdCallbackResponseSchema
>;

export async function getTasksCatalog(): Promise<TaskCatalogItem[]> {
  const raw = await apiRequest<unknown>("/tasks/catalog", "GET");
  return TaskCatalogResponseSchema.parse(raw).items;
}

export async function getMyTasks(): Promise<MyTaskItem[]> {
  const raw = await apiRequest<unknown>("/tasks/my", "GET");
  return MyTasksResponseSchema.parse(raw).items;
}

export async function claimTask(args: {
  taskId: number;
  idempotencyKey: string;
}): Promise<ClaimTaskResponse> {
  const raw = await apiRequest<unknown>("/tasks/claim", "POST", {
    idempotencyKey: args.idempotencyKey,
    body: { task_id: args.taskId },
  });
  return ClaimTaskResponseSchema.parse(raw);
}

export async function getBuiltinAdSlot(
  taskCode: string,
): Promise<AdSlotResponse> {
  const query = new URLSearchParams({
    task_code: taskCode,
    provider: "builtin_timer",
  });
  const raw = await apiRequest<unknown>(
    `/ads/slot?${query.toString()}`,
    "GET",
  );
  return AdSlotResponseSchema.parse(raw);
}

export async function finishBuiltinTimerAd(
  token: string,
): Promise<AdCallbackResponse> {
  const raw = await apiRequest<unknown>(
    "/ads/callback/builtin_timer",
    "POST",
    { body: { token } },
  );
  return AdCallbackResponseSchema.parse(raw);
}
