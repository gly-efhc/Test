import { z } from "zod";

import { apiRequest } from "../lib/api";

export const walletItemSchema = z.object({
  id: z.number().int(),
  wallet_address: z.string().min(1),
  wallet_app: z.string().nullable().optional().transform(
    (value) => value ?? null,
  ),
  is_primary: z.boolean(),
  is_active: z.boolean(),
  created_at: z.string().nullable().optional().transform(
    (value) => value ?? "",
  ),
});

export const walletsMeSchema = z.object({
  is_connected: z.boolean(),
  wallets: z.array(walletItemSchema),
});

export const balanceHistoryItemSchema = z.object({
  id: z.number().int(),
  amount_efhc: z.string().min(1),
  direction: z.enum(["credit", "debit"]),
  balance_type: z.enum(["main", "bonus"]),
  reason: z.string().min(1),
  created_at: z.string().min(1),
});

export const balanceHistoryPageSchema = z.object({
  items: z.array(balanceHistoryItemSchema),
  next_cursor: z.string().nullable(),
});

export const withdrawHistoryItemSchema = z.object({
  id: z.number().int(),
  tg_id: z.number().int(),
  amount: z.string().min(1),
  status: z.string().min(1),
  created_at: z.string().min(1),
  updated_at: z.string().min(1),
});

export const withdrawHistoryPageSchema = z.object({
  items: z.array(withdrawHistoryItemSchema),
  next_cursor: z.string().nullable(),
});

export type WalletItem = z.infer<typeof walletItemSchema>;
export type WalletsMeOut = z.infer<typeof walletsMeSchema>;
export type BalanceHistoryItem = z.infer<
  typeof balanceHistoryItemSchema
>;
export type BalanceHistoryPage = z.infer<
  typeof balanceHistoryPageSchema
>;
export type WithdrawHistoryItem = z.infer<
  typeof withdrawHistoryItemSchema
>;
export type WithdrawHistoryPage = z.infer<
  typeof withdrawHistoryPageSchema
>;

export async function makePrimaryWallet(
  walletId: number | string,
): Promise<unknown> {
  return await apiRequest<unknown>(
    `/wallets/${walletId}/make-primary`,
    "POST",
  );
}

export async function deleteWallet(
  walletId: number | string,
): Promise<unknown> {
  return await apiRequest<unknown>(
    `/wallets/${walletId}`,
    "DELETE",
  );
}

export async function getProfileWallets<
  T = WalletsMeOut,
>(signal?: AbortSignal): Promise<T> {
  const raw = await apiRequest<unknown>("/wallets/me", "GET", {
    signal,
  });
  return walletsMeSchema.parse(raw) as T;
}

export async function getProfileBalanceHistoryPage(args?: {
  cursor?: string | null;
  limit?: number;
  signal?: AbortSignal;
}): Promise<BalanceHistoryPage> {
  const query = new URLSearchParams();
  query.set("limit", String(args?.limit ?? 20));
  if (args?.cursor) query.set("cursor", args.cursor);
  const raw = await apiRequest<unknown>(
    `/wallets/balance-history?${query.toString()}`,
    "GET",
    { signal: args?.signal },
  );
  return balanceHistoryPageSchema.parse(raw);
}

export async function getProfileWithdrawHistoryPage(args?: {
  cursor?: string | null;
  limit?: number;
  signal?: AbortSignal;
}): Promise<WithdrawHistoryPage> {
  const query = new URLSearchParams();
  query.set("limit", String(args?.limit ?? 20));
  if (args?.cursor) query.set("cursor", args.cursor);
  const raw = await apiRequest<unknown>(
    `/withdraw/list/me?${query.toString()}`,
    "GET",
    { signal: args?.signal },
  );
  return withdrawHistoryPageSchema.parse(raw);
}

export async function getProfileBalanceHistory<
  T = BalanceHistoryPage,
>(
  cursor?: string | null,
  signal?: AbortSignal,
): Promise<T> {
  return await getProfileBalanceHistoryPage({
    cursor,
    signal,
  }) as T;
}

export async function getProfileWithdrawHistory<
  T = WithdrawHistoryPage,
>(
  cursor?: string | null,
  signal?: AbortSignal,
): Promise<T> {
  return await getProfileWithdrawHistoryPage({
    cursor,
    signal,
  }) as T;
}
