import type {
  FaqCatalog,
  FaqItem,
  FaqSection,
  FaqSubsection,
} from "../data/faq/types";

type IndexedFaq = {
  answer: string;
  item: FaqItem;
  keywords: string;
  question: string;
  section: FaqSection;
  sectionText: string;
  subsection: FaqSubsection;
  subsectionText: string;
};

type InitMessage = {
  catalog: FaqCatalog;
  type: "INIT";
};

type SearchMessage = {
  id: number;
  query: string;
  type: "SEARCH";
};

let index: IndexedFaq[] = [];

function norm(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function terms(value: string): string[] {
  return norm(value).split(" ").filter(Boolean);
}

function buildIndex(catalog: FaqCatalog): IndexedFaq[] {
  const next: IndexedFaq[] = [];
  for (const section of catalog.sections) {
    for (const subsection of section.subsections) {
      for (const item of subsection.items) {
        next.push({
          answer: norm(item.answer),
          item,
          keywords: norm((item.keywords || []).join(" ")),
          question: norm(item.question),
          section,
          sectionText: norm(section.title),
          subsection,
          subsectionText: norm(subsection.title),
        });
      }
    }
  }
  return next;
}

function search(query: string) {
  const queryTerms = terms(query);
  if (!queryTerms.length) return [];
  return index
    .map((entry) => {
      let score = 0;
      for (const term of queryTerms) {
        if (entry.question.includes(term)) score += 5;
        if (entry.keywords.includes(term)) score += 4;
        if (entry.subsectionText.includes(term)) score += 3;
        if (entry.sectionText.includes(term)) score += 2;
        if (entry.answer.includes(term)) score += 1;
      }
      return {
        item: entry.item,
        score,
        section: entry.section,
        subsection: entry.subsection,
      };
    })
    .filter((entry) => entry.score > 0)
    .sort((left, right) => {
      if (right.score !== left.score) {
        return right.score - left.score;
      }
      return left.item.id.localeCompare(right.item.id);
    })
    .slice(0, 24);
}

self.addEventListener("message", (event: MessageEvent) => {
  const message = event.data as InitMessage | SearchMessage;
  if (message.type === "INIT") {
    index = buildIndex(message.catalog);
    self.postMessage({ size: index.length, type: "READY" });
    return;
  }
  if (message.type === "SEARCH") {
    self.postMessage({
      id: message.id,
      results: search(message.query),
      type: "RESULTS",
    });
  }
});
