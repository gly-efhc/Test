import React from "react";
import { useT } from "../../../hooks/useT";
import { BalanceHistoryLoadMore } from "./BalanceHistoryLoadMore";
import { BalanceHistoryEmptyState } from "./BalanceHistoryEmptyState";
import {
  WithdrawHistoryItem,
  type WithdrawHistoryModel,
} from "./WithdrawHistoryItem";

type Props = {
  items: WithdrawHistoryModel[];
  loading: boolean;
  nextCursor: string | null;
  onLoadMore: () => void;
};

export function WithdrawHistoryList(props: Props) {
  const t = useT();
  if (props.loading && props.items.length === 0) {
    return (
      <div className="text-xs text-[color:var(--tg-hint)]">
        {t("withdraw.loading_items")}
      </div>
    );
  }
  if (!props.loading && props.items.length === 0) {
    return (
      <BalanceHistoryEmptyState
        title={t("withdraw.empty_title")}
        body={t("withdraw.empty_body")}
      />
    );
  }
  return (
    <div className="efhc-history-list">
      {props.items.map((item) => (
        <div className="efhc-native-virtual-item" key={item.id}>
          <WithdrawHistoryItem item={item} />
        </div>
      ))}
      {props.nextCursor ? (
        <BalanceHistoryLoadMore onLoadMore={props.onLoadMore} />
      ) : null}
    </div>
  );
}
