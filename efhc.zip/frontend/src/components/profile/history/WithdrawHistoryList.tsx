import React from "react";
import {
  BalanceHistoryLoadMore,
} from "./BalanceHistoryLoadMore";
import {
  BalanceHistoryEmptyState,
} from "./BalanceHistoryEmptyState";
import {
  WithdrawHistoryItem,
  type WithdrawHistoryModel,
} from "./WithdrawHistoryItem";

type Props = {
  items: WithdrawHistoryModel[];
  loading: boolean;
  nextCursor: string | null;
  onLoadMore: () => void;
};

export function WithdrawHistoryList(props: Props) {
  if (props.loading && props.items.length === 0) {
    return (
      <div className="text-xs text-[color:var(--tg-hint)]">
        Loading...
      </div>
    );
  }
  if (!props.loading && props.items.length === 0) {
    return (
      <BalanceHistoryEmptyState
        title="Заявок на вывод пока нет"
        body={
          "Когда вы создадите заявку на вывод, она появится здесь."
        }
      />
    );
  }
  return (
    <div className="space-y-2">
      {props.items.map((item) => (
        <WithdrawHistoryItem key={item.id} item={item} />
      ))}
      {props.nextCursor ? (
        <BalanceHistoryLoadMore onLoadMore={props.onLoadMore} />
      ) : null}
    </div>
  );
}
