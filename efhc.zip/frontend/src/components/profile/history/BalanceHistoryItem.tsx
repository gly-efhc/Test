import React from "react";
import {
  TelegramStatusBadge,
} from "../../ui/telegram/TelegramStatusBadge";

export type BalanceHistoryModel = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type Props = {
  item: BalanceHistoryModel;
  reasonLabel: (reason: string) => string;
};

function amountPrefix(direction: "credit" | "debit"): string {
  return direction === "credit" ? "+" : "−";
}

function directionLabel(direction: "credit" | "debit"): string {
  return direction === "credit" ? "Пришло" : "Ушло";
}

export function BalanceHistoryItem(props: Props) {
  const { item } = props;
  return (
    <div
      className={[
        "rounded-2xl border px-3 py-3",
        "border-[color:var(--tg-hint)]/20",
        "bg-[var(--tg-secondary-bg)]",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="font-medium break-words">
            {props.reasonLabel(item.reason)}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <TelegramStatusBadge
              label={directionLabel(item.direction)}
              tone={
                item.direction === "credit"
                  ? "connected"
                  : "warning"
              }
            />
            <TelegramStatusBadge
              label={item.balance_type === "bonus" ? "BONUS" : "MAIN"}
              tone={item.balance_type === "bonus" ? "bonus" : "main"}
            />
          </div>
          <div className="mt-2 text-xs text-[color:var(--tg-hint)]">
            {new Date(item.created_at).toLocaleString()}
          </div>
        </div>
        <div className="text-right text-sm font-semibold tabular-nums">
          {amountPrefix(item.direction)}{item.amount_efhc} EFHC
        </div>
      </div>
    </div>
  );
}
