import React from "react";
import {
  TelegramStatusBadge,
} from "../../ui/telegram/TelegramStatusBadge";

type Props = {
  title: string;
  value: string;
  tone: "neutral" | "main" | "bonus";
};

export function BalanceSummaryCard(props: Props) {
  return (
    <div
      className={[
        "rounded-2xl border px-3 py-3",
        "border-[color:var(--tg-hint)]/20",
        "bg-[var(--tg-secondary-bg)]",
      ].join(" ")}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs text-[color:var(--tg-hint)]">
          {props.title}
        </div>
        <TelegramStatusBadge
          label={props.tone === "main"
            ? "MAIN"
            : props.tone === "bonus"
            ? "BONUS"
            : "TOTAL"}
          tone={props.tone}
        />
      </div>
      <div className="mt-2 text-base font-semibold tabular-nums">
        {props.value} EFHC
      </div>
    </div>
  );
}
