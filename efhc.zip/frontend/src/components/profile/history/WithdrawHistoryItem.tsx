import React from "react";
import {
  TelegramStatusBadge,
} from "../../ui/telegram/TelegramStatusBadge";

export type WithdrawHistoryModel = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

type Props = {
  item: WithdrawHistoryModel;
};

function statusTone(status: string):
  | "connected"
  | "warning"
  | "neutral"
  | "bonus"
  | "main" {
  if (status === "PAID") return "connected";
  if (status === "PENDING") return "warning";
  if (status === "REJECTED") return "neutral";
  if (status === "CANCELED") return "neutral";
  return "neutral";
}

function statusLabel(status: string): string {
  if (status === "PENDING") return "Ожидает";
  if (status === "PAID") return "Выплачено";
  if (status === "REJECTED") return "Отклонено";
  if (status === "CANCELED") return "Отменено";
  return status;
}

export function WithdrawHistoryItem(props: Props) {
  const { item } = props;
  return (
    <div
      className={[
        "rounded-2xl border px-3 py-3",
        "border-[color:var(--tg-hint)]/20",
        "bg-[var(--tg-secondary-bg)]",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="font-medium break-words">
            Вывод EFHC #{item.id}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <TelegramStatusBadge label="Вывод" tone="main" />
            <TelegramStatusBadge
              label={statusLabel(item.status)}
              tone={statusTone(item.status)}
            />
          </div>
          <div className="mt-2 text-xs text-[color:var(--tg-hint)]">
            Создано: {new Date(item.created_at).toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
            Обновлено: {new Date(item.updated_at).toLocaleString()}
          </div>
        </div>
        <div className="text-right text-sm font-semibold tabular-nums">
          −{item.amount} EFHC
        </div>
      </div>
    </div>
  );
}
