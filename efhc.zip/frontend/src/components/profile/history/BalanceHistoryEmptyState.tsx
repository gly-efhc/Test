import React from "react";
import {
  TelegramEmptyState,
} from "../../ui/telegram/TelegramEmptyState";

type Props = {
  title?: string;
  body?: string;
};

export function BalanceHistoryEmptyState(props: Props) {
  return (
    <TelegramEmptyState
      title={props.title || "История баланса пока пуста"}
      detail={
        props.body ||
        "Здесь появятся начисления и списания по MAIN и BONUS."
      }
    />
  );
}
