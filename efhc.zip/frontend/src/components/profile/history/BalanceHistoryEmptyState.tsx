import React from "react";
import {
  TelegramEmptyState,
} from "../../ui/telegram/TelegramEmptyState";

export function BalanceHistoryEmptyState() {
  return (
    <TelegramEmptyState
      title="История баланса пока пуста"
      detail={
        "Здесь появятся начисления и списания по MAIN и BONUS."
      }
    />
  );
}
