import React from "react";
import { Button } from "../../ui/Button";

export function BalanceHistoryLoadMore(
  props: { onLoadMore: () => void },
) {
  return (
    <div className="flex justify-center pt-1">
      <Button variant="secondary" onClick={props.onLoadMore}>
        Загрузить ещё
      </Button>
    </div>
  );
}
