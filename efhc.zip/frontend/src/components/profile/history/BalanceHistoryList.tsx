import React from "react";
import {
  BalanceHistoryEmptyState,
} from "./BalanceHistoryEmptyState";
import {
  BalanceHistoryItem,
  type BalanceHistoryModel,
} from "./BalanceHistoryItem";
import { BalanceHistoryLoadMore } from "./BalanceHistoryLoadMore";

type Props = {
  items: BalanceHistoryModel[];
  loading: boolean;
  nextCursor: string | null;
  onLoadMore: () => void;
  reasonLabel: (reason: string) => string;
};

export function BalanceHistoryList(props: Props) {
  if (props.loading && props.items.length === 0) {
    return (
      <div className="text-xs text-[color:var(--tg-hint)]">
        Loading...
      </div>
    );
  }
  if (!props.loading && props.items.length === 0) {
    return <BalanceHistoryEmptyState />;
  }
  return (
    <div className="space-y-2">
      {props.items.map((item) => (
        <BalanceHistoryItem
          key={item.id}
          item={item}
          reasonLabel={props.reasonLabel}
        />
      ))}
      {props.nextCursor ? (
        <BalanceHistoryLoadMore onLoadMore={props.onLoadMore} />
      ) : null}
    </div>
  );
}
