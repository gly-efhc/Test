import React, { useMemo } from "react";
import { TelegramInfoBlock } from "../ui/telegram/TelegramInfoBlock";
import { WalletConnectBanner } from "./wallet/WalletConnectBanner";
import {
  WalletListItem,
  type WalletListItemModel,
} from "./wallet/WalletListItem";
import { WalletPrimaryCard } from "./wallet/WalletPrimaryCard";

type Props = {
  wallets: WalletListItemModel[];
  walletsLoading: boolean;
  walletsError: string | null;
  walletHint?: string | null;
  onConnect: () => void;
  onMakePrimary: (id: number) => void;
  onRemove: (id: number) => void;
};

export function ProfileWalletSection(props: Props) {
  const primaryWallet = useMemo(() => {
    return props.wallets.find((wallet) => wallet.is_primary) || null;
  }, [props.wallets]);
  const isWalletConnected = useMemo(() => {
    return props.wallets.some((wallet) => wallet.is_active);
  }, [props.wallets]);

  return (
    <div className="space-y-3">
      <div className="space-y-1">
        <div className="font-semibold">Wallet</div>
        <div className="text-xs text-[color:var(--tg-hint)]">
          Подключение кошелька и список привязанных адресов.
        </div>
      </div>

      <WalletConnectBanner
        connected={isWalletConnected}
        onConnect={props.onConnect}
      />

      <WalletPrimaryCard wallet={primaryWallet} />

      {props.walletHint ? (
        <TelegramInfoBlock title="Подсказка по Wallet">
          {props.walletHint}
        </TelegramInfoBlock>
      ) : null}

      {props.walletsError ? (
        <div className="text-xs text-[color:var(--tg-hint)]">
          {props.walletsError}
        </div>
      ) : null}

      <div className="space-y-3">
        {props.walletsLoading ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            Loading...
          </div>
        ) : null}
        {props.wallets.map((wallet) => (
          <WalletListItem
            key={wallet.id}
            wallet={wallet}
            onMakePrimary={props.onMakePrimary}
            onRemove={props.onRemove}
          />
        ))}
        {!props.walletsLoading && props.wallets.length === 0 ? (
          <TelegramInfoBlock title="Кошельков пока нет">
            Подключите первый Wallet, чтобы использовать пополнение,
            внешние покупки и вывод.
          </TelegramInfoBlock>
        ) : null}
      </div>
    </div>
  );
}
