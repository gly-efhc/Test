import React, { useMemo } from "react";
import type {
  WalletConnectionPhase,
} from "../../lib/wallet-provider";
import { useT } from "../../hooks/useT";
import { TelegramInfoBlock } from "../ui/telegram/TelegramInfoBlock";
import { WalletConnectBanner } from "./wallet/WalletConnectBanner";
import {
  WalletListItem,
  type WalletListItemModel,
} from "./wallet/WalletListItem";
import { WalletPrimaryCard } from "./wallet/WalletPrimaryCard";
import { TelegramSectionRow } from "../ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../ui/telegram/TelegramStatusBadge";

type TonWalletView = {
  name: string;
  appName: string | null;
  imageUrl: string | null;
  aboutUrl: string | null;
  embedded: boolean;
  injected: boolean;
};

type Props = {
  wallets: WalletListItemModel[];
  walletsLoading: boolean;
  walletsError: string | null;
  walletHint?: string | null;
  sessionConnected: boolean;
  sessionRestoring: boolean;
  tonProofAccepted: boolean;
  connectionPhase: WalletConnectionPhase;
  availableWallets: TonWalletView[];
  onConnect: () => void;
  onDisconnectSession: () => void;
  onMakePrimary: (id: number) => void;
  onRemove: (id: number) => void;
  hapticsEnabled: boolean;
};

export function ProfileWalletSection(props: Props) {
  const t = useT();
  const primaryWallet = useMemo(
    () => props.wallets.find((wallet) => wallet.is_primary) || null,
    [props.wallets],
  );
  const connectedWallet = useMemo(
    () => props.wallets.find((wallet) => wallet.is_active) || null,
    [props.wallets],
  );
  const walletCount = props.wallets.length;
  const recommended = props.availableWallets.slice(0, 3);
  const stateBadge = connectedWallet ? (
    <TelegramStatusBadge
      label={t("wallet.status_connected")}
      tone="connected"
    />
  ) : (
    <TelegramStatusBadge
      label={t("wallet.status_not_connected")}
      tone="inactive"
    />
  );

  return (
    <div
      className="efhc-wallet-trust-section space-y-3"
      data-public-visual-trust="profile-wallet-history-faq"
      data-public-surface="wallet"
      data-wallet-list-only="1305"
    >
      <div className="space-y-1">
        <div className="font-semibold">{t("wallet.title")}</div>
        <div className="text-xs text-[color:var(--tg-hint)]">
          {t("wallet.section_intro")}
        </div>
      </div>

      <div
        className="efhc-wallet-trust-rail"
        data-wallet-trust-rail="connect-primary-proof"
      >
        <span className={props.sessionConnected ? "is-on" : ""}>
          {t("wallet.status_connected")}
        </span>
        <span className={primaryWallet ? "is-on" : ""}>
          {t("wallet.primary_wallet")}
        </span>
        <span className={props.tonProofAccepted ? "is-on" : ""}>
          Ton Proof
        </span>
      </div>

      <TelegramSectionRow
        title={
          connectedWallet
            ? t("wallet.connected_title")
            : t("wallet.required_title")
        }
        subtitle={
          connectedWallet
            ? t("wallet.linked_wallets_count").replace(
                "{count}",
                String(walletCount),
              )
            : t("wallet.connect_hint")
        }
        rightSlot={stateBadge}
        compact
      />

      <WalletConnectBanner
        connected={props.sessionConnected}
        restoring={props.sessionRestoring}
        proofAccepted={props.tonProofAccepted}
        connectionPhase={props.connectionPhase}
        walletHint={props.walletHint}
        recommendedWallets={recommended}
        onConnect={props.onConnect}
        onDisconnectSession={props.onDisconnectSession}
        hapticsEnabled={props.hapticsEnabled}
      />

      <WalletPrimaryCard wallet={primaryWallet} />

      {props.walletsError ? (
        <TelegramInfoBlock
          title={t("wallet.error_title")}
          data-wallet-error-microcopy="safe-1306"
        >
          {t("wallet.error_body")}
        </TelegramInfoBlock>
      ) : null}

      <div className="space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
          {t("wallet.linked_wallets")}
        </div>
        {props.walletsLoading ? (
          <TelegramInfoBlock title={t("wallet.loading_wallets_title")}>
            {t("wallet.loading_wallets_body")}
          </TelegramInfoBlock>
        ) : null}
        {!props.walletsLoading && props.wallets.length === 0 ? (
          <TelegramInfoBlock title={t("wallet.empty_title")}>
            {t("wallet.empty_body")}
          </TelegramInfoBlock>
        ) : null}
        {props.wallets.map((wallet) => (
          <WalletListItem
            key={wallet.id}
            wallet={wallet}
            onMakePrimary={props.onMakePrimary}
            onRemove={props.onRemove}
            hapticsEnabled={props.hapticsEnabled}
          />
        ))}
      </div>
    </div>
  );
}
