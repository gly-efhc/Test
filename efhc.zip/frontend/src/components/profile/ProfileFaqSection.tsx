import React from "react";
import { useRouter } from "next/router";
import type { FaqCatalog } from "../../data/faq/types";
import { getFaqPreviewItems } from "../../data/faq";
import { TelegramActionCard } from "../ui/telegram/TelegramActionCard";
import { TelegramSectionRow } from "../ui/telegram/TelegramSectionRow";

type Props = {
  t: (key: string) => string;
  catalog: FaqCatalog;
};

export function ProfileFaqSection(props: Props) {
  const router = useRouter();
  const faqPreviewItems = React.useMemo(() => {
    return getFaqPreviewItems(
      props.catalog,
      [
        { sectionId: "5", subsectionId: "5.1" },
        { sectionId: "6", subsectionId: "6.1" },
        { sectionId: "7", subsectionId: "7.1" },
      ],
      4,
    );
  }, [props.catalog]);

  return (
    <div className="space-y-3">
      <TelegramActionCard
        title={props.t("faq.title")}
        description={props.t("faq.profile_intro")}
        primaryLabel={props.t("faq.open_full")}
        onPrimary={() => {
          void router.push("/faq");
        }}
        secondaryLabel={props.t("faq.quick_wallet")}
        onSecondary={() => {
          void router.push("/faq?section=5&subsection=5.1");
        }}
      />
      <div className="grid gap-2">
        {faqPreviewItems.map(({ item, section, subsection }) => (
          <TelegramSectionRow
            key={item.id}
            title={item.question}
            subtitle={`${section.title} · ${subsection.title}`}
            onClick={() => {
              void router.push(
                `/faq?section=${section.id}`
                + `&subsection=${subsection.id}`
                + `&item=${item.id}`,
              );
            }}
            compact
          />
        ))}
      </div>
    </div>
  );
}
