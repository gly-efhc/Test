import React from "react";
import { Button } from "../ui/Button";
import { BalanceSummaryCard } from "./history/BalanceSummaryCard";
import { BalanceHistoryList } from "./history/BalanceHistoryList";
import { WithdrawHistoryList } from "./history/WithdrawHistoryList";

type HistoryItem = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type WithdrawItem = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

type Props = {
  totalBalance: string;
  mainBalance: string;
  bonusBalance: string;
  historyItems: HistoryItem[];
  historyLoading: boolean;
  historyError: string | null;
  historyCursor: string | null;
  withdrawItems: WithdrawItem[];
  withdrawLoading: boolean;
  withdrawError: string | null;
  withdrawCursor: string | null;
  onRefresh: () => void;
  onLoadMore: () => void;
  onLoadMoreWithdraw: () => void;
  reasonLabel: (reason: string) => string;
};

export function ProfileHistorySection(props: Props) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-semibold">История баланса</div>
          <div className="text-xs text-[color:var(--tg-hint)]">
            EFHC = EFHCm + EFHCb, затем история движений.
          </div>
        </div>
        <Button variant="secondary" onClick={props.onRefresh}>
          Обновить
        </Button>
      </div>

      <div className="space-y-2">
        <BalanceSummaryCard
          title="EFHC — общий баланс"
          value={props.totalBalance}
          tone="neutral"
        />
        <BalanceSummaryCard
          title="EFHCm — основные"
          value={props.mainBalance}
          tone="main"
        />
        <BalanceSummaryCard
          title="EFHCb — бонусные"
          value={props.bonusBalance}
          tone="bonus"
        />
      </div>

      {props.historyError ? (
        <div className="text-xs text-[color:var(--tg-hint)]">
          {props.historyError}
        </div>
      ) : null}

      <BalanceHistoryList
        items={props.historyItems}
        loading={props.historyLoading}
        nextCursor={props.historyCursor}
        onLoadMore={props.onLoadMore}
        reasonLabel={props.reasonLabel}
      />

      <div className="space-y-2 pt-2">
        <div className="font-semibold">Заявки на вывод</div>
        <div className="text-xs text-[color:var(--tg-hint)]">
          Здесь видны ваши заявки на вывод и их текущий статус.
        </div>
        {props.withdrawError ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.withdrawError}
          </div>
        ) : null}
        <WithdrawHistoryList
          items={props.withdrawItems}
          loading={props.withdrawLoading}
          nextCursor={props.withdrawCursor}
          onLoadMore={props.onLoadMoreWithdraw}
        />
      </div>
    </div>
  );
}
