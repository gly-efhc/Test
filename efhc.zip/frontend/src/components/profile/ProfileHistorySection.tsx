import React from "react";
import { Button } from "../ui/Button";
import { BalanceSummaryCard } from "./history/BalanceSummaryCard";
import { BalanceHistoryList } from "./history/BalanceHistoryList";

type HistoryItem = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type Props = {
  totalBalance: string;
  mainBalance: string;
  bonusBalance: string;
  historyItems: HistoryItem[];
  historyLoading: boolean;
  historyError: string | null;
  historyCursor: string | null;
  onRefresh: () => void;
  onLoadMore: () => void;
  reasonLabel: (reason: string) => string;
};

export function ProfileHistorySection(props: Props) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-semibold">История баланса</div>
          <div className="text-xs text-[color:var(--tg-hint)]">
            Общий, основной и бонусный баланс, затем история.
          </div>
        </div>
        <Button variant="secondary" onClick={props.onRefresh}>
          Обновить
        </Button>
      </div>

      <div className="space-y-2">
        <BalanceSummaryCard
          title="Общий баланс"
          value={props.totalBalance}
          tone="neutral"
        />
        <BalanceSummaryCard
          title="Основной баланс"
          value={props.mainBalance}
          tone="main"
        />
        <BalanceSummaryCard
          title="Бонусный баланс"
          value={props.bonusBalance}
          tone="bonus"
        />
      </div>

      {props.historyError ? (
        <div className="text-xs text-[color:var(--tg-hint)]">
          {props.historyError}
        </div>
      ) : null}

      <BalanceHistoryList
        items={props.historyItems}
        loading={props.historyLoading}
        nextCursor={props.historyCursor}
        onLoadMore={props.onLoadMore}
        reasonLabel={props.reasonLabel}
      />
    </div>
  );
}
