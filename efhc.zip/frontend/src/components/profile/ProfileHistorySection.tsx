import React from "react";
import { useT } from "../../hooks/useT";
import { Button } from "../ui/Button";
import { BalanceSummaryCard } from "./history/BalanceSummaryCard";
import { BalanceHistoryList } from "./history/BalanceHistoryList";
import { WithdrawHistoryList } from "./history/WithdrawHistoryList";

type HistoryItem = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type WithdrawItem = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

type Props = {
  totalBalance: string;
  mainBalance: string;
  bonusBalance: string;
  historyItems: HistoryItem[];
  historyLoading: boolean;
  historyError: string | null;
  historyCursor: string | null;
  withdrawItems: WithdrawItem[];
  withdrawLoading: boolean;
  withdrawError: string | null;
  withdrawCursor: string | null;
  onRefresh: () => void;
  onLoadMore: () => void;
  onLoadMoreWithdraw: () => void;
  reasonLabel: (reason: string) => string;
};

export function ProfileHistorySection(props: Props) {
  // EFHC — общий баланс
  // EFHCm — основные
  // EFHCb — бонусные
  // Заявки на вывод
  const t = useT();
  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="font-semibold">{t("history.title")}</div>
          <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
            {t("history.section_intro")}
          </div>
        </div>
        <Button variant="secondary" onClick={props.onRefresh}>
          {t("common.refresh")}
        </Button>
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <BalanceSummaryCard
          title={t("balances.total_label")}
          value={props.totalBalance}
          tone="neutral"
        />
        <BalanceSummaryCard
          title={t("balances.main_label")}
          value={props.mainBalance}
          tone="main"
        />
        <BalanceSummaryCard
          title={t("balances.bonus_label")}
          value={props.bonusBalance}
          tone="bonus"
        />
      </div>

      <div className="space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
          {t("history.balance_operations")}
        </div>
        {props.historyError ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.historyError}
          </div>
        ) : null}
        <BalanceHistoryList
          items={props.historyItems}
          loading={props.historyLoading}
          nextCursor={props.historyCursor}
          onLoadMore={props.onLoadMore}
          reasonLabel={props.reasonLabel}
        />
      </div>

      <div className="space-y-2 pt-1">
        <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
          {t("history.withdraw_requests")}
        </div>
        <div className="text-xs text-[color:var(--tg-hint)]">
          {t("history.withdraw_intro")}
        </div>
        {props.withdrawError ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.withdrawError}
          </div>
        ) : null}
        <WithdrawHistoryList
          items={props.withdrawItems}
          loading={props.withdrawLoading}
          nextCursor={props.withdrawCursor}
          onLoadMore={props.onLoadMoreWithdraw}
        />
      </div>
    </div>
  );
}
