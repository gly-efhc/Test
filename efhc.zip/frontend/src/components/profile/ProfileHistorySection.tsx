import React, { useMemo } from "react";
import { useT } from "../../hooks/useT";
import { Button } from "../ui/Button";
import { BalanceSummaryCard } from "./history/BalanceSummaryCard";
import { BalanceHistoryList } from "./history/BalanceHistoryList";
import { WithdrawHistoryList } from "./history/WithdrawHistoryList";

type HistoryItem = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type WithdrawItem = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

export type HistoryFilter =
  | "all"
  | "purchases"
  | "exchange"
  | "withdraw"
  | "bonuses"
  | "panels";

type Props = {
  totalBalance: string;
  mainBalance: string;
  bonusBalance: string;
  historyItems: HistoryItem[];
  historyLoading: boolean;
  historyError: string | null;
  historyCursor: string | null;
  withdrawItems: WithdrawItem[];
  withdrawLoading: boolean;
  withdrawError: string | null;
  withdrawCursor: string | null;
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  onRefresh: () => void;
  onLoadMore: () => void;
  onLoadMoreWithdraw: () => void;
  reasonLabel: (reason: string) => string;
};

const FILTERS: HistoryFilter[] = [
  "all",
  "purchases",
  "exchange",
  "withdraw",
  "bonuses",
  "panels",
];

function normalizeFilter(value: string): HistoryFilter {
  return FILTERS.includes(value as HistoryFilter)
    ? (value as HistoryFilter)
    : "all";
}

function matchHistoryFilter(
  item: HistoryItem,
  filter: HistoryFilter,
): boolean {
  const reason = String(item.reason || "");
  if (filter === "all") return true;
  if (filter === "exchange") return reason.includes("exchange");
  if (filter === "withdraw") return reason.includes("withdraw");
  if (filter === "panels") return reason.includes("panel");
  if (filter === "bonuses") {
    return item.balance_type === "bonus"
      || reason.includes("bonus")
      || reason.includes("referral")
      || reason.includes("task")
      || reason.includes("ad_");
  }
  if (filter === "purchases") {
    return reason.includes("shop_purchase")
      || (reason.includes("purchase") && !reason.includes("panel"));
  }
  return true;
}

function filterLabelKey(filter: HistoryFilter): string {
  return `history.filter_${filter}`;
}

export function ProfileHistorySection(props: Props) {
  // EFHC — общий баланс
  // EFHCm — основные
  // EFHCb — бонусные
  // Заявки на вывод
  const t = useT();
  const activeFilter = normalizeFilter(props.activeFilter);
  const filteredHistoryItems = useMemo(
    () => props.historyItems.filter(
      (item) => matchHistoryFilter(item, activeFilter),
    ),
    [activeFilter, props.historyItems],
  );
  const showWithdraws = activeFilter === "all" || activeFilter === "withdraw";

  return (
    <div
      className="efhc-history-trust-section space-y-4"
      data-public-visual-trust="profile-wallet-history-faq"
      data-public-surface="history"
      data-history-account-timeline="1307"
      data-history-data-contract="balance-history-withdraw-me-1308"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="font-semibold">{t("history.title")}</div>
          <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
            {t("history.section_intro")}
          </div>
        </div>
        <Button variant="secondary" onClick={props.onRefresh}>
          {t("common.refresh")}
        </Button>
      </div>

      <div
        className="efhc-history-trust-rail"
        data-history-trust-rail="balances-filters-withdraws"
      >
        <span className={activeFilter === "all" ? "is-active" : ""}>
          {t("history.filter_all")}
        </span>
        <span className={activeFilter === "exchange" ? "is-active" : ""}>
          {t("history.filter_exchange")}
        </span>
        <span className={activeFilter === "withdraw" ? "is-active" : ""}>
          {t("history.filter_withdraw")}
        </span>
      </div>

      <div className="grid gap-2 sm:grid-cols-3">
        <BalanceSummaryCard
          title={t("balances.total_label")}
          value={props.totalBalance}
          tone="neutral"
        />
        <BalanceSummaryCard
          title={t("balances.main_label")}
          value={props.mainBalance}
          tone="main"
        />
        <BalanceSummaryCard
          title={t("balances.bonus_label")}
          value={props.bonusBalance}
          tone="bonus"
        />
      </div>

      <div
        className="efhc-history-filter-row"
        data-history-filters="all-purchases-exchange-withdraw-bonuses-panels"
      >
        {FILTERS.map((filter) => (
          <button
            key={filter}
            type="button"
            className={
              "efhc-history-filter " +
              (activeFilter === filter
                ? "efhc-history-filter--active"
                : "")
            }
            data-history-filter={filter}
            onClick={() => props.onFilterChange(filter)}
          >
            {t(filterLabelKey(filter))}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
          {t("history.balance_operations")}
        </div>
        {props.historyError ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("history.load_error")}
          </div>
        ) : null}
        <BalanceHistoryList
          items={filteredHistoryItems}
          loading={props.historyLoading}
          nextCursor={props.historyCursor}
          onLoadMore={props.onLoadMore}
          reasonLabel={props.reasonLabel}
        />
      </div>

      {showWithdraws ? (
        <div className="space-y-2 pt-1" data-history-withdraws="account">
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
              {t("history.withdraw_requests")}
            </div>
            <Button href="/withdraw" variant="secondary">
              {t("withdraw.title")}
            </Button>
          </div>
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("history.withdraw_intro")}
          </div>
          {props.withdrawError ? (
            <div className="text-xs text-[color:var(--tg-hint)]">
              {t("history.load_error")}
            </div>
          ) : null}
          <WithdrawHistoryList
            items={props.withdrawItems}
            loading={props.withdrawLoading}
            nextCursor={props.withdrawCursor}
            onLoadMore={props.onLoadMoreWithdraw}
          />
        </div>
      ) : null}
    </div>
  );
}
