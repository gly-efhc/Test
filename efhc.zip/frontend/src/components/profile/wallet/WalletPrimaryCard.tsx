import React from "react";
import {
  TelegramInfoBlock,
} from "../../ui/telegram/TelegramInfoBlock";
import {
  TelegramStatusBadge,
} from "../../ui/telegram/TelegramStatusBadge";
import type { WalletListItemModel } from "./WalletListItem";

type Props = {
  wallet: WalletListItemModel | null;
};

export function WalletPrimaryCard(props: Props) {
  return (
    <TelegramInfoBlock title="Основной кошелёк">
      {props.wallet ? (
        <div className="mt-2 space-y-2">
          <div className="break-all text-sm text-[var(--tg-text)]">
            {props.wallet.wallet_address}
          </div>
          <div className="flex flex-wrap gap-2">
            <TelegramStatusBadge label="PRIMARY" tone="primary" />
            <TelegramStatusBadge
              label={props.wallet.is_active ? "CONNECTED" : "INACTIVE"}
              tone={props.wallet.is_active ? "connected" : "inactive"}
            />
          </div>
        </div>
      ) : (
        <div className="mt-1">Основной кошелёк пока не выбран.</div>
      )}
    </TelegramInfoBlock>
  );
}
