import React from "react";
import { useT } from "../../../hooks/useT";
import { Button } from "../../ui/Button";
import { TelegramSectionRow } from "../../ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../ui/telegram/TelegramStatusBadge";
import { hapticSelection, hapticSoft } from "../../../lib/telegram";

export type WalletListItemModel = {
  id: number;
  wallet_address: string;
  wallet_app: string | null;
  is_primary: boolean;
  is_active: boolean;
  created_at: string;
};

type Props = {
  wallet: WalletListItemModel;
  onMakePrimary: (id: number) => void;
  onRemove: (id: number) => void;
  hapticsEnabled: boolean;
};

function shortAddress(address: string): string {
  if (address.length <= 18) return address;
  return `${address.slice(0, 8)}…${address.slice(-8)}`;
}

export function WalletListItem(props: Props) {
  const t = useT();
  const { wallet } = props;
  const badges = (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      {wallet.wallet_app ? (
        <TelegramStatusBadge label={wallet.wallet_app} tone="neutral" />
      ) : null}
      {wallet.is_primary ? (
        <TelegramStatusBadge
          label={t("wallet.primary_badge")}
          tone="primary"
        />
      ) : null}
      <TelegramStatusBadge
        label={
          wallet.is_active
            ? t("wallet.status_connected")
            : t("wallet.status_inactive")
        }
        tone={wallet.is_active ? "connected" : "inactive"}
      />
    </div>
  );

  return (
    <div className="efhc-wallet-item">
      <TelegramSectionRow
        title={shortAddress(wallet.wallet_address)}
        subtitle={new Date(wallet.created_at).toLocaleString()}
        rightSlot={badges}
      />
      <div className="efhc-wallet-item_actions">
        <Button
          variant="secondary"
          disabled={!wallet.is_active || wallet.is_primary}
          onClick={() => {
            hapticSelection(props.hapticsEnabled);
            props.onMakePrimary(wallet.id);
          }}
        >
          {t("wallet.make_primary")}
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            hapticSoft(props.hapticsEnabled);
            props.onRemove(wallet.id);
          }}
        >
          {t("wallet.remove")}
        </Button>
      </div>
    </div>
  );
}
