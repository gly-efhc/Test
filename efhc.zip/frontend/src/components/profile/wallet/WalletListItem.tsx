import React from "react";
import { Button } from "../../ui/Button";
import {
  TelegramSectionRow,
} from "../../ui/telegram/TelegramSectionRow";
import {
  TelegramStatusBadge,
} from "../../ui/telegram/TelegramStatusBadge";

export type WalletListItemModel = {
  id: number;
  wallet_address: string;
  wallet_app: string | null;
  is_primary: boolean;
  is_active: boolean;
  created_at: string;
};

type Props = {
  wallet: WalletListItemModel;
  onMakePrimary: (id: number) => void;
  onRemove: (id: number) => void;
};

function shortAddress(address: string): string {
  if (address.length <= 18) return address;
  return `${address.slice(0, 8)}…${address.slice(-8)}`;
}

export function WalletListItem(props: Props) {
  const { wallet } = props;
  const badges = (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      {wallet.wallet_app ? (
        <TelegramStatusBadge
          label={wallet.wallet_app}
          tone="neutral"
        />
      ) : null}
      {wallet.is_primary ? (
        <TelegramStatusBadge label="PRIMARY" tone="primary" />
      ) : null}
      <TelegramStatusBadge
        label={wallet.is_active ? "CONNECTED" : "INACTIVE"}
        tone={wallet.is_active ? "connected" : "inactive"}
      />
    </div>
  );

  return (
    <div className="space-y-2">
      <TelegramSectionRow
        title={shortAddress(wallet.wallet_address)}
        subtitle={new Date(wallet.created_at).toLocaleString()}
        rightSlot={badges}
      />
      <div className="flex flex-wrap gap-2">
        <Button
          variant="secondary"
          disabled={!wallet.is_active || wallet.is_primary}
          onClick={() => props.onMakePrimary(wallet.id)}
        >
          Make primary
        </Button>
        <Button
          variant="secondary"
          onClick={() => props.onRemove(wallet.id)}
        >
          Remove
        </Button>
      </div>
    </div>
  );
}
