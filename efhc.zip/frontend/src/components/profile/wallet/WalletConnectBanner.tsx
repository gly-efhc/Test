import React from "react";
import {
  TelegramActionCard,
} from "../../ui/telegram/TelegramActionCard";

type Props = {
  connected: boolean;
  onConnect: () => void;
};

export function WalletConnectBanner(props: Props) {
  if (props.connected) {
    return (
      <TelegramActionCard
        title="Кошелёк подключён"
        description={
          "Wallet нужен для пополнения, внешних покупок, "
          + "Lotteries и вывода."
        }
        primaryLabel="Открыть FAQ по Wallet"
        onPrimary={() => {
          window.location.assign("/faq?section=5&subsection=5.1");
        }}
      />
    );
  }
  return (
    <TelegramActionCard
      title="Подключите кошелёк"
      description={
        "Без Wallet недоступны пополнение, внешние покупки "
        + "и вывод."
      }
      primaryLabel="Подключить кошелёк"
      onPrimary={props.onConnect}
      emphasis
    />
  );
}
