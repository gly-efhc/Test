import React from "react";
import { useT } from "../../../hooks/useT";
import { Button } from "../../ui/Button";
import { hapticSelection, hapticSoft } from "../../../lib/telegram";

type WalletView = {
  name: string;
  appName: string | null;
  imageUrl: string | null;
  aboutUrl: string | null;
  embedded: boolean;
  injected: boolean;
};

type Props = {
  connected: boolean;
  restoring: boolean;
  proofAccepted: boolean;
  walletHint?: string | null;
  recommendedWallets: WalletView[];
  onConnect: () => void;
  onDisconnectSession: () => void;
  hapticsEnabled: boolean;
};

export function WalletConnectBanner(props: Props) {
  const t = useT();
  const title = props.connected
    ? t("wallet.session_connected")
    : t("wallet.connect_button");
  const desc = props.restoring
    ? t("wallet.session_restoring")
    : props.connected
      ? t("wallet.connection_ready")
      : t("wallet.connection_needed");

  return (
    <div className="efhc-wallet-card">
      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="efhc-wallet-card__title">{title}</div>
        <div className="efhc-wallet-card__desc">{desc}</div>
        {props.proofAccepted ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("wallet.proof_received")}
          </div>
        ) : null}
        {props.walletHint ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.walletHint}
          </div>
        ) : null}
        {props.recommendedWallets.length ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("wallet.recommended_wallets")}: {props.recommendedWallets
              .map((item) => item.name)
              .join(", ")}
          </div>
        ) : null}
      </div>
      <div className="flex shrink-0 flex-wrap gap-2">
        {props.connected ? (
          <>
            <Button
              variant="secondary"
              onClick={() => {
                hapticSoft(props.hapticsEnabled);
                props.onDisconnectSession();
              }}
            >
              {t("wallet.disconnect_session")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                hapticSelection(props.hapticsEnabled);
                window.location.assign("/faq?section=5&subsection=5.1");
              }}
            >
              {t("wallet.faq_button")}
            </Button>
          </>
        ) : (
          <Button
            onClick={() => {
              hapticSelection(props.hapticsEnabled);
              props.onConnect();
            }}
          >
            {t("wallet.connect_button")}
          </Button>
        )}
      </div>
    </div>
  );
}
