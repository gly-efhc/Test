import React, { useMemo, useState } from "react";
import { Card } from "./ui/Card";
import { Button } from "./ui/Button";
import {
  fromScaledBigint,
  toScaledBigintDown,
} from "../lib/format";

type Props = {
  maxKwh: string;
  onExchange: (amountKwh: string) => Promise<void>;
};

export function ExchangePanel(props: Props) {
  const maxScaled = useMemo(() => {
    return toScaledBigintDown(props.maxKwh || "0", 8);
  }, [props.maxKwh]);
  const [amount, setAmount] = useState("0.00000000");

  function setPct(pct: number) {
    const p = BigInt(Math.max(0, Math.min(100, pct)));
    const scaled = (maxScaled * p) / 100n;
    setAmount(fromScaledBigint(scaled, 8));
  }

  return (
    <Card title="Exchange">
      <div className="text-sm efhc-text-muted">kWh → EFHC (1:1)</div>
      <div className="mt-1 text-xs efhc-text-muted2">
        Max: {fromScaledBigint(maxScaled, 8)}
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2">
        <Button variant="secondary" onClick={() => setPct(25)}>
          25%
        </Button>
        <Button variant="secondary" onClick={() => setPct(50)}>
          50%
        </Button>
        <Button variant="secondary" onClick={() => setPct(100)}>
          100%
        </Button>
      </div>
      <input
        className="efhc-input mt-2 w-full"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        inputMode="decimal"
      />
      <Button className="mt-3 w-full" onClick={() => props.onExchange(amount)}>
        Exchange
      </Button>
    </Card>
  );
}
