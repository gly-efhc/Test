import React from "react";
import { Card } from "./ui/Card";
import { useT } from "../hooks/useT";

type Item = {
  tg_id: number;
  username?: string | null;
  total_generated_kwh: string;
  rank_pos: number;
};

type Props = {
  items: Item[];
};

export function RanksTable(props: Props) {
  const t = useT();
  return (
    <Card title={t("ranks.table_title")}>
      <div className="space-y-2">
        {props.items.length ? props.items.map((item) => (
          <div
            key={item.tg_id}
            className="flex items-center justify-between gap-3 rounded-2xl border border-[color:var(--tg-hint)] p-3"
          >
            <div>
              <div className="text-sm font-semibold">
                #{item.rank_pos} {
                  item.username ? `@${item.username}` : `TG ${item.tg_id}`
                }
              </div>
              <div className="text-xs efhc-text-muted2">
                {item.total_generated_kwh} kWh
              </div>
            </div>
          </div>
        )) : (
          <div className="text-sm efhc-text-muted">
            {t("ranks.table_empty")}
          </div>
        )}
      </div>
    </Card>
  );
}
