import React from "react";
import { Card } from "./ui/Card";

export function RanksTable() {
  return (
    <Card title="Ranks">
      <div className="text-sm efhc-text-muted">TOP-100 + Я</div>
    </Card>
  );
}
