import React, { memo, useMemo } from "react";
import { useRouter } from "next/router";
import { useT } from "../hooks/useT";
import { EfhcCoinIcon } from "./icons/EfhcCoin";
import { TelegramStatusBadge } from "./ui/telegram/TelegramStatusBadge";
import { sumScaledDown } from "../lib/format";

type Props = {
  username: string;
  avatarUrl: string | null;
  level: number;
  isVip: boolean;
  hasActiv: boolean;
  mainBalance: string;
  bonusBalance: string;
  walletConnected: boolean;
  onAvatar: () => void;
  onDeposit: () => void;
  onOpenWallet: () => void;
};

function clampLevel(n: number): number {
  if (!Number.isFinite(n)) return 1;
  return Math.min(12, Math.max(1, Math.floor(n)));
}

export const GlobalHeader = memo(function GlobalHeader(props: Props) {
  const router = useRouter();
  const t = useT();
  const lvl = clampLevel(props.level);

  const total = useMemo(
    () => sumScaledDown(props.mainBalance, props.bonusBalance, 8),
    [props.mainBalance, props.bonusBalance],
  );

  const username = props.username || "TG";

  const onDepositClick = () => {
    if (!props.walletConnected) {
      props.onOpenWallet();
      return;
    }
    props.onDeposit();
  };

  const onHub = () => {
    router.push("/hub").catch(() => undefined);
  };

  return (
    <div className="sticky top-0 z-40 w-full efhc-header-divider">
      <div
        className={
          "flex items-center gap-3 px-3 py-2 " +
          "max-w-xl mx-auto " +
          "bg-[var(--tg-bg)]"
        }
        style={{
          paddingTop: "calc(0.5rem + var(--efhc-safe-top))",
        }}
      >
        <button
          type="button"
          onClick={props.onAvatar}
          className="shrink-0"
          aria-label={t("profile.menu_button")}
        >
          <div
            className={
              "h-10 w-10 rounded-full overflow-hidden " +
              "bg-[var(--tg-secondary-bg)] " +
              "border border-[color:var(--tg-hint)]"
            }
          >
            {props.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={props.avatarUrl}
                alt=""
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full" />
            )}
          </div>
        </button>

        <div className="min-w-0 flex-1">
          <div
            className={
              "text-sm font-semibold truncate " +
              "text-[var(--tg-text)]"
            }
            title={username}
          >
            {username}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            <div
              className={
                "text-xs text-[var(--tg-hint)] " +
                "leading-4"
              }
            >
              LVL {lvl}
            </div>
            {props.hasActiv ? (
              <TelegramStatusBadge
                label={t("profile.activ_badge")}
                tone="active"
              />
            ) : null}
            {props.isVip ? (
              <TelegramStatusBadge
                label={t("profile.vip_badge")}
                tone="vip"
              />
            ) : null}
          </div>
        </div>

        <button
          type="button"
          onClick={props.onAvatar}
          className={
            "h-9 w-9 shrink-0 rounded-2xl efhc-btn-secondary " +
            "text-base font-semibold"
          }
          aria-label={t("profile.menu_button")}
          title={t("profile.menu_button")}
        >
          ☰
        </button>

        <div
          className={
            "ml-auto min-w-0 " +
            "rounded-full px-3 py-2 " +
            "bg-[var(--tg-secondary-bg)] " +
            "border border-[color:var(--tg-hint)] " +
            "efhc-pill-border"
          }
        >
          <div
            className={
              "grid gap-1 min-w-0 " +
              "grid-cols-1 " +
              "min-[360px]:grid-cols-2 " +
              "min-[360px]:items-center"
            }
          >
            <div className="flex items-center gap-2 min-w-0">
              <EfhcCoinIcon size={18} />
              <div className="min-w-0">
                <div
                  className={
                    "text-[10px] font-semibold uppercase " +
                    "tracking-wide text-[var(--tg-hint)]"
                  }
                >
                  Total
                </div>
                <div
                  className={
                    "text-xs leading-4 text-[var(--tg-hint)] " +
                    "truncate"
                  }
                >
                  EFHC
                </div>
              </div>
            </div>

            <div
              className={
                "tabular-nums text-sm font-bold " +
                "text-[var(--tg-text)] " +
                "min-w-0 truncate " +
                "min-[360px]:text-right"
              }
              aria-label="Total EFHC"
              title={total}
            >
              {total}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onDepositClick}
            className="h-9 px-3 rounded-2xl efhc-btn-secondary"
            aria-label="Пополнить"
          >
            Пополнить
          </button>
          <button
            type="button"
            onClick={onHub}
            className="h-9 px-3 rounded-2xl efhc-btn-primary"
            aria-label="Hub"
          >
            Hub
          </button>
        </div>
      </div>
    </div>
  );
});
