import React, { memo, useMemo } from "react";
import { useRouter } from "next/router";
import { useT } from "../hooks/useT";
import { EfhcCoinIcon } from "./icons/EfhcCoin";
import { sumScaledDown } from "../lib/format";

type Props = {
  username: string;
  avatarUrl: string | null;
  level: number;
  isVip: boolean;
  hasActiv: boolean;
  mainBalance: string;
  bonusBalance: string;
  walletConnected: boolean;
  isAdmin: boolean;
  onAvatar: () => void;
  onDeposit: () => void;
  onOpenWallet: () => void;
};

function HeaderActionIcon(props: {
  kind: "admin" | "faq" | "wallet" | "deposit" | "hub";
}) {
  const common = {
    width: 18,
    height: 18,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.9,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };
  if (props.kind === "admin") {
    return (
      <svg {...common}>
        <path d="M4 20v-9l8-5 8 5v9" />
        <path d="M9 20v-6h6v6M8 9h8" />
      </svg>
    );
  }
  if (props.kind === "faq") {
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="M9.8 9a2.4 2.4 0 1 1 3.7 2c-1 .6-1.5 1.1-1.5 2" />
        <path d="M12 17h.01" />
      </svg>
    );
  }
  if (props.kind === "wallet") {
    return (
      <svg {...common}>
        <path d="M4 7.5h13.5A2.5 2.5 0 0 1 20 10v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7.5Z" />
        <path d="M4 8V6a2 2 0 0 1 2-2h10" />
        <path d="M15 12h5v4h-5a2 2 0 0 1 0-4Z" />
      </svg>
    );
  }
  if (props.kind === "deposit") {
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 8v8M8 12h8" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <rect x="4" y="4" width="6" height="6" rx="1.5" />
      <rect x="14" y="4" width="6" height="6" rx="1.5" />
      <rect x="4" y="14" width="6" height="6" rx="1.5" />
      <rect x="14" y="14" width="6" height="6" rx="1.5" />
    </svg>
  );
}

function clampLevel(n: number): number {
  if (!Number.isFinite(n)) return 1;
  return Math.min(12, Math.max(1, Math.floor(n)));
}

function HeaderStatus(props: {
  kind: "activ" | "vip";
  active: boolean;
  label: string;
}) {
  return (
    <span
      className="efhc-game-header_status"
      data-status={props.kind}
      data-active={props.active ? "true" : "false"}
    >
      {props.label}
    </span>
  );
}

export const GlobalHeader = memo(function GlobalHeader(props: Props) {
  const router = useRouter();
  const t = useT();
  const lvl = clampLevel(props.level);

  const total = useMemo(
    () => sumScaledDown(props.mainBalance, props.bonusBalance, 8),
    [props.mainBalance, props.bonusBalance],
  );

  const username = props.username || "TG";
  const balanceDensity =
    total.length >= 19
      ? "very-dense"
      : total.length >= 15
        ? "dense"
        : total.length >= 12
          ? "compact"
          : "normal";

  const onHub = () => {
    router.push("/hub").catch(() => undefined);
  };

  const onFaq = () => {
    router.push("/faq").catch(() => undefined);
  };

  const onAdmin = () => {
    router.push("/admin").catch(() => undefined);
  };

  const onDepositClick = () => {
    props.onDeposit();
  };

  const walletLabel = props.walletConnected
    ? t("wallet.connected_title")
    : t("wallet.connect_button");

  return (
    <div className="sticky top-0 z-40 w-full efhc-header-divider">
      <div className="efhc-game-header">
        <button
          type="button"
          onClick={props.onAvatar}
          className="efhc-game-header_profile"
          aria-label={t("profile.menu_button")}
        >
          <div className="efhc-game-header_avatar">
            {props.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={props.avatarUrl}
                alt=""
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full" />
            )}
          </div>
          <div className="min-w-0 text-left">
            <div
              className={
                "truncate text-sm font-bold text-[var(--tg-text)]"
              }
              title={username}
            >
              {username}
            </div>
            <div className="efhc-game-header_statuses mt-1 flex items-center">
              <span className="text-[11px] text-[var(--tg-hint)]">
                LVL {lvl}
              </span>
              <HeaderStatus
                kind="activ"
                active={props.hasActiv}
                label={t("profile.activ_badge")}
              />
              <HeaderStatus
                kind="vip"
                active={props.isVip}
                label={t("profile.vip_badge")}
              />
            </div>
          </div>
        </button>

        <div
          className="efhc-game-header_balance"
          aria-label={t("common.efhc_balance_aria")}
          title={total}
          data-balance-scope="global-header"
          data-energy-balance-boundary="header-only"
          data-header-balance-label="EFHC"
          data-header-balance-layout="single-line"
          data-header-balance-density={balanceDensity}
        >
          <EfhcCoinIcon size={16} />
          <span
            className="efhc-game-header_balance-value"
            data-header-balance-value={total}
          >
            {total}
          </span>
          <span className="efhc-game-header_balance-unit">EFHC</span>
        </div>

        <div
          className="efhc-game-header_actions"
          data-header-action-layout="balanced-grid"
          data-action-count={props.isAdmin ? "5" : "4"}
        >
          {props.isAdmin ? (
            <button
              type="button"
              onClick={onAdmin}
              className="efhc-header-action efhc-btn-secondary"
              aria-label={t("nav.admin")}
              title={t("nav.admin")}
            >
              <HeaderActionIcon kind="admin" />
              <span>{t("nav.admin")}</span>
            </button>
          ) : null}
          <button
            type="button"
            onClick={onFaq}
            className="efhc-header-action efhc-btn-secondary"
            aria-label={t("faq.title")}
            title={t("faq.title")}
          >
            <HeaderActionIcon kind="faq" />
            <span>{t("faq.title")}</span>
          </button>
          <button
            type="button"
            onClick={props.onOpenWallet}
            className="efhc-header-action efhc-btn-secondary"
            aria-label={walletLabel}
            title={walletLabel}
          >
            <HeaderActionIcon kind="wallet" />
            <span>{t("wallet.title")}</span>
          </button>
          <button
            type="button"
            onClick={onDepositClick}
            className="efhc-header-action efhc-btn-secondary"
            aria-label={t("deposit.direct_title")}
            title={t("deposit.direct_title")}
          >
            <HeaderActionIcon kind="deposit" />
            <span>EFHC</span>
          </button>
          <button
            type="button"
            onClick={onHub}
            className="efhc-header-action efhc-btn-primary"
            aria-label="Hub"
            title="Hub"
          >
            <HeaderActionIcon kind="hub" />
            <span>HUB</span>
          </button>
        </div>
      </div>
    </div>
  );
});

/* WalletGate action marker: Пополнить */
