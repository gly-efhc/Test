import React from "react";
import { Card } from "./ui/Card";

export function PanelsList(props: { count: number }) {
  return (
    <Card title="Panels">
      <div className="text-2xl font-bold">{props.count}</div>
      <div className="text-sm text-gray-600">Active panels</div>
    </Card>
  );
}
