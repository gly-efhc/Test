import React from "react";

export function TelegramInfoBlock(
  props: React.PropsWithChildren<{ title?: string }>,
) {
  return (
    <div
      className={[
        "rounded-2xl border px-4 py-3",
        "border-[color:var(--tg-hint)]/20",
        "bg-[var(--tg-secondary-bg)]/80",
      ].join(" ")}
    >
      {props.title ? (
        <div className="text-sm font-semibold">{props.title}</div>
      ) : null}
      <div className="text-sm text-[color:var(--tg-hint)]">
        {props.children}
      </div>
    </div>
  );
}
