import React from "react";

type Variant = "primary" | "secondary" | "ghost";

export function Button(
  props: React.PropsWithChildren<
    React.ButtonHTMLAttributes<HTMLButtonElement> & {
      variant?: Variant;
    }
  >,
) {
  const { className, variant = "primary", ...rest } = props;
  const base = [
    "rounded-2xl",
    "px-4 py-2",
    "border",
    "text-sm font-semibold",
    "disabled:opacity-50 disabled:cursor-not-allowed",
    "transition",
    "active:scale-[0.99]",
  ].join(" ");
  const v =
    variant === "primary"
      ? "efhc-btn-primary"
      : variant === "secondary"
        ? "efhc-btn-secondary"
        : "efhc-btn-ghost";
  return (
    <button
      {...rest}
      className={`${base} ${v} ${className || ""}`}
    />
  );
}
