import React from "react";

type CardProps = React.PropsWithChildren<
  React.HTMLAttributes<HTMLDivElement> & {
    title?: string;
    highlight?: "energy" | "none";
  }
>;

export function Card(props: CardProps) {
  const {
    children,
    className,
    highlight,
    title,
    ...rest
  } = props;
  const hl = highlight === "energy" ? "efhc-border-energy" : "";
  return (
    <div
      {...rest}
      className={`efhc-card p-4 ${hl} ${className || ""}`}
    >
      {title ? (
        <div className="text-lg font-semibold mb-2">
          {title}
        </div>
      ) : null}
      {children}
    </div>
  );
}
