import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useQueryClient } from "@tanstack/react-query";
import {
  useTonConnectUI,
  useTonWallet,
} from "@tonconnect/ui-react";
import type { Dict, Lang } from "../lib/i18n";
import { tFromDicts } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { ProfileModal } from "./ProfileModal";
import { DepositModal } from "./DepositModal";
import { playSfx } from "../lib/sfx";
import {
  getTelegramWebApp,
  hapticError,
  hapticSelection,
  hapticSuccess,
  hapticTap,
  telegramBackButtonShow,
  telegramConfirm,
} from "../lib/telegram";
import {
  bindTonConnectWallet,
  disconnectTonConnect,
  fetchTonConnectWallets,
  prepareTonProof,
  submitTonProofEnvelope,
  waitTonConnectRestore,
  type PreparedTonProof,
  type TonConnectWalletView,
} from "../lib/tonconnect";
import { GlobalHeader } from "./GlobalHeader";
import { getUserLevel } from "../lib/skins";
import { useWalletsMe } from "../hooks/useWalletsMe";

export type LayoutContextValue = {
  lang: Lang;
  t: (k: string) => string;
  td: (k: string) => string;
  tg_id: number | null;
  isVip: boolean;
  isAdmin: boolean;
  settings: UserSettings;
  setLang: (l: Lang) => void;
  setSettings: (s: UserSettings) => void;
  confirm: (
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ) => Promise<boolean>;
  toast: (msg: string, kind?: "success" | "error" | "info") => void;
  openProfile: (section?: "wallet" | "history") => void;
  openDeposit: () => void;
  openWalletConnect: () => void;
};

export const LayoutContext = React.createContext<LayoutContextValue>({
  lang: "en",
  t: (k) => k,
  td: (k) => k,
  tg_id: null,
  isVip: false,
  isAdmin: false,
  settings: {
    lang: "en",
    theme_mode: "auto",
    avatar_source: "telegram",
    avatar_url: null,
    sfx_enabled: true,
    sfx_volume: 0.6,
    sfx_pack: "default",
    haptics_enabled: true,
    reduce_motion: false,
    hide_balances: false,
    show_decimal_detail: false,
    confirm_actions: true,
    confirm_purchase: true,
    confirm_withdraw: true,
    confirm_convert: true,
    confirm_watch_ad: true,
    toasts_enabled: true,
    important_alerts_only: false,
  },
  setLang: () => undefined,
  setSettings: () => undefined,
  confirm: async () => true,
  toast: () => undefined,
  openProfile: () => undefined,
  openDeposit: () => undefined,
  openWalletConnect: () => undefined,
});

function NavItem(props: {
  href: string;
  active: boolean;
  label: string;
  icon: React.ReactNode;
  onNav: () => void;
}) {
  const activeCls =
    "bg-[var(--tg-button)] text-[var(--tg-button-text)] ";
  const inactiveCls =
    "bg-[var(--tg-secondary-bg)] text-[var(--tg-text)] " +
    "border border-[color:var(--tg-hint)]";
  return (
    <Link
      href={props.href}
      onClick={(event) => {
        props.onNav();
        if (props.active) event.preventDefault();
      }}
      className={
        "flex flex-col items-center justify-center gap-1 px-2 py-2 " +
        "rounded-2xl text-xs font-semibold transition " +
        (props.active ? activeCls : inactiveCls)
      }
    >
      <span className="text-[var(--tg-text)]">{props.icon}</span>
      <span className="leading-none">{props.label}</span>
    </Link>
  );
}

function Icon(props: {
  kind:
    | "energy"
    | "panels"
    | "exchange"
    | "tasks"
    | "referrals"
    | "ranks";
}) {
  const c = "currentColor";
  const base = "w-5 h-5";
  if (props.kind === "energy") {
    return (
      <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
        <path d="M13 2L3 14h7l-1 8 12-16h-7l-1-4z" />
      </svg>
    );
  }
  if (props.kind === "panels") {
    return (
      <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
        <rect x="3" y="3" width="8" height="8" rx="2" />
        <rect x="13" y="3" width="8" height="8" rx="2" />
        <rect x="3" y="13" width="8" height="8" rx="2" />
        <rect x="13" y="13" width="8" height="8" rx="2" />
      </svg>
    );
  }
  if (props.kind === "exchange") {
    return (
      <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
        <path d="M7 7h14l-3-3" />
        <path d="M17 17H3l3 3" />
        <path d="M3 7v6" />
        <path d="M21 17v-6" />
      </svg>
    );
  }
  if (props.kind === "tasks") {
    return (
      <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
        <path d="M9 11l3 3L22 4" />
        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
      </svg>
    );
  }
  if (props.kind === "referrals") {
    return (
      <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
        <path d="M16 11c1.66 0 3-1.79 3-4s-1.34-4-3-4-3 1.79-3 4 1.34 4 3 4z" />
        <path d="M8 11c1.66 0 3-1.79 3-4S9.66 3 8 3 5 4.79 5 7s1.34 4 3 4z" />
        <path d="M16 13c-2.67 0-8 1.34-8 4v4h14v-4c0-2.66-3.33-4-6-4z" />
        <path d="M8 13c-2.67 0-8 1.34-8 4v4h6" />
      </svg>
    );
  }
  return (
    <svg className={base} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
      <path d="M8 21h8" />
      <path d="M12 17v4" />
      <path d="M7 4h10" />
      <path d="M17 4l-1 7a4 4 0 0 1-8 0L7 4" />
    </svg>
  );
}

export function Layout(
  props: React.PropsWithChildren<{
    lang: Lang;
    uiDict: Dict;
    ruDict: Dict;
    descDict: Dict;
    tg_id: number | null;
    telegramName: string;
    telegramAvatarUrl?: string | null;
    snapshot?: {
      profile: {
        username?: string | null;
        is_vip?: boolean;
        has_activ?: boolean;
        main_balance: string;
        bonus_balance: string;
        total_generated_kwh: string;
      };
    } | null;
    isVip: boolean;
    isAdmin: boolean;
    settings: UserSettings;
    setLang: (l: Lang) => void;
    setSettings: (s: UserSettings) => void;
    shopSkinBgUrl?: string | null;
  }>,
) {
  const router = useRouter();
  const t = useMemo(
    () => (k: string) => tFromDicts(k, props.uiDict, props.ruDict),
    [props.uiDict, props.ruDict],
  );
  const td = useMemo(
    () => (k: string) =>
      props.descDict[k] || props.uiDict[k] || props.ruDict[k] || k,
    [props.descDict, props.uiDict, props.ruDict],
  );
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileSection, setProfileSection] = useState<
    "wallet" | "history" | null
  >(null);
  const [depositOpen, setDepositOpen] = useState(false);
  const [walletHint, setWalletHint] = useState<string | null>(null);
  const [availableWallets, setAvailableWallets] = useState<
    TonConnectWalletView[]
  >([]);
  const [proofState, setProofState] = useState<PreparedTonProof | null>(null);
  const [proofAccepted, setProofAccepted] = useState(false);
  const [sessionRestoring, setSessionRestoring] = useState(true);
  const [tonModalOpened, setTonModalOpened] = useState(false);
  const [toasts, setToasts] = useState<
    { id: string; msg: string; kind: "success" | "error" | "info" }[]
  >([]);

  const qc = useQueryClient();
  const [tonConnectUI] = useTonConnectUI();
  const tonWallet = useTonWallet() as any;
  const sessionConnected = Boolean(tonWallet);
  const walletsMe = useWalletsMe(props.tg_id);
  const hasBoundWallet = Boolean(walletsMe.data?.is_connected);
  const walletConnected = hasBoundWallet;

  const avatarUrl =
    props.settings.avatar_source === "custom"
      ? props.settings.avatar_url || null
      : props.settings.avatar_source === "telegram"
        ? props.telegramAvatarUrl || null
        : null;
  const username =
    props.snapshot?.profile?.username || props.telegramName || "";
  const level = getUserLevel(
    props.snapshot?.profile?.total_generated_kwh || "0",
  );

  useEffect(() => {
    if (!tonConnectUI) return;
    let active = true;
    waitTonConnectRestore(tonConnectUI)
      .then((restored) => {
        if (!active) return;
        setSessionRestoring(false);
        if (restored && props.tg_id) {
          qc.invalidateQueries({ queryKey: ["wallets_me", props.tg_id] })
            .catch(() => undefined);
        }
      })
      .catch(() => {
        if (active) setSessionRestoring(false);
      });
    return () => {
      active = false;
    };
  }, [tonConnectUI, qc, props.tg_id]);

  useEffect(() => {
    if (!tonConnectUI) return;
    fetchTonConnectWallets(tonConnectUI)
      .then(setAvailableWallets)
      .catch(() => setAvailableWallets([]));
  }, [tonConnectUI]);

  useEffect(() => {
    if (!tonConnectUI || !props.tg_id) return;
    prepareTonProof(tonConnectUI)
      .then((state) => {
        setProofState(state);
        if (state) setWalletHint(t("wallet.proof_ready"));
      })
      .catch(() => undefined);
  }, [tonConnectUI, props.tg_id, t]);

  useEffect(() => {
    if (!tonConnectUI) return;
    const unsub = tonConnectUI.onStatusChange((wallet: any) => {
      if (props.tg_id) {
        qc.invalidateQueries({ queryKey: ["wallets_me", props.tg_id] })
          .catch(() => undefined);
      }
      submitTonProofEnvelope(wallet, proofState)
        .then(async (out) => {
          if (!out?.accepted) return;
          const bound = await bindTonConnectWallet(wallet)
            .catch(() => null);
          if (!bound?.is_connected) return;
          setTonModalOpened(false);
          restoreTelegramMainButtonAfterTonModal();
          setProofAccepted(true);
          setWalletHint(t("wallet.proof_received"));
          toast(t("wallet.proof_received"), "success");
          if (props.tg_id) {
            qc.invalidateQueries({
              queryKey: ["wallets_me", props.tg_id],
            }).catch(() => undefined);
          }
        })
        .catch(() => undefined);
    });
    return () => {
      try {
        unsub();
      } catch {
        // noop
      }
    };
  }, [tonConnectUI, qc, props.tg_id, proofState, t]);

  useEffect(() => {
    if (!tonConnectUI) return;
    const api = tonConnectUI as any;
    if (typeof api?.onModalStateChange !== "function") {
      return;
    }
    const unsub = api.onModalStateChange((state: any) => {
      const opened = Boolean(
        state?.status === "opened" || state?.open === true,
      );
      setTonModalOpened(opened);
      if (opened) {
        hideTelegramMainButtonForTonModal();
        return;
      }
      restoreTelegramMainButtonAfterTonModal();
    });
    return () => {
      try {
        unsub?.();
      } catch {
        // noop
      }
    };
  }, [depositOpen, tonConnectUI]);

  useEffect(() => {
    if (tonModalOpened) {
      hideTelegramMainButtonForTonModal();
      return;
    }
    restoreTelegramMainButtonAfterTonModal();
  }, [depositOpen, tonModalOpened]);

  useEffect(() => {
    if (!profileOpen && !depositOpen) return;
    const off = telegramBackButtonShow(() => {
      if (depositOpen) {
        setDepositOpen(false);
        return;
      }
      setProfileOpen(false);
    });
    return () => off();
  }, [profileOpen, depositOpen]);

  function toast(
    msg: string,
    kind: "success" | "error" | "info" = "info",
  ) {
    if (!props.settings.toasts_enabled) return;
    if (kind === "success") hapticSuccess(props.settings.haptics_enabled);
    if (kind === "error") hapticError(props.settings.haptics_enabled);
    const id = `${Date.now()}:${Math.random().toString(16).slice(2)}`;
    setToasts((prev) => [...prev, { id, msg, kind }].slice(-4));
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3200);
  }

  async function confirm(
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ): Promise<boolean> {
    if (!props.settings.confirm_actions) return true;
    const gate = {
      purchase: props.settings.confirm_purchase,
      withdraw: props.settings.confirm_withdraw,
      convert: props.settings.confirm_convert,
      watch_ad: props.settings.confirm_watch_ad,
      generic: true,
    }[kind];
    if (!gate) return true;
    return await telegramConfirm(title, detail);
  }

  const bottom = [
    {
      href: "/",
      key: "nav.energy",
      label: t("nav.energy"),
      kind: "energy" as const,
    },
    {
      href: "/panels",
      key: "nav.panels",
      label: t("nav.panels"),
      kind: "panels" as const,
    },
    {
      href: "/exchange",
      key: "nav.exchange",
      label: t("nav.exchange"),
      kind: "exchange" as const,
    },
    {
      href: "/tasks",
      key: "nav.tasks",
      label: t("nav.tasks"),
      kind: "tasks" as const,
    },
    {
      href: "/referrals",
      key: "nav.referrals",
      label: t("nav.referrals"),
      kind: "referrals" as const,
    },
    {
      href: "/ranks",
      key: "nav.ranks",
      label: t("nav.ranks"),
      kind: "ranks" as const,
    },
  ];

  const onTap = (kind: "tap" | "nav") => {
    playSfx(
      kind,
      props.settings.sfx_enabled,
      props.settings.sfx_volume,
    );
    if (kind === "nav") {
      hapticSelection(props.settings.haptics_enabled);
      return;
    }
    hapticTap(props.settings.haptics_enabled);
  };

  function hideTelegramMainButtonForTonModal() {
    try {
      getTelegramWebApp()?.MainButton?.hide?.();
    } catch {
      // noop
    }
  }

  function restoreTelegramMainButtonAfterTonModal() {
    try {
      if (!depositOpen) return;
      getTelegramWebApp()?.MainButton?.show?.();
    } catch {
      // noop
    }
  }

  function openProfile(section?: "wallet" | "history") {
    setProfileSection(section || null);
    setProfileOpen(true);
  }

  async function openWalletConnect() {
    if (!tonConnectUI) return;
    hideTelegramMainButtonForTonModal();
    setTonModalOpened(true);
    const wallets = await fetchTonConnectWallets(tonConnectUI)
      .catch(() => [] as TonConnectWalletView[]);
    setAvailableWallets(wallets);
    if (!proofState) {
      const prepared = await prepareTonProof(tonConnectUI).catch(() => null);
      setProofState(prepared);
    }
    try {
      tonConnectUI.openModal();
    } catch {
      try {
        (tonConnectUI as any)?.connectWallet?.();
      } catch {
        // noop
      }
    }
  }

  async function disconnectWalletSession() {
    await disconnectTonConnect(tonConnectUI).catch(() => undefined);
    if (props.tg_id) {
      qc.invalidateQueries({ queryKey: ["wallets_me", props.tg_id] })
        .catch(() => undefined);
    }
    toast(t("wallet.session_disconnected"), "info");
  }

  function openDeposit() {
    if (!walletConnected) {
      void openWalletConnect();
      return;
    }
    setDepositOpen(true);
  }

  return (
    <LayoutContext.Provider
      value={{
        lang: props.lang,
        t,
        td,
        tg_id: props.tg_id,
        isVip: props.isVip,
        isAdmin: props.isAdmin,
        settings: props.settings,
        setLang: props.setLang,
        setSettings: props.setSettings,
        confirm,
        toast,
        openProfile,
        openDeposit,
        openWalletConnect: () => {
          void openWalletConnect();
        },
      }}
    >
      <div
        className="bg-[var(--tg-bg)] efhc-shell"
        style={{
          minHeight: "var(--tg-viewport-height)",
          paddingBottom: "calc(6rem + var(--efhc-safe-bottom))",
        }}
      >
        <GlobalHeader
          username={username}
          avatarUrl={avatarUrl}
          level={level}
          isVip={props.snapshot?.profile?.is_vip || props.isVip}
          hasActiv={props.snapshot?.profile?.has_activ || false}
          mainBalance={props.snapshot?.profile?.main_balance || "0"}
          bonusBalance={props.snapshot?.profile?.bonus_balance || "0"}
          walletConnected={walletConnected}
          onAvatar={() => {
            onTap("tap");
            openProfile();
          }}
          onDeposit={() => openDeposit()}
          onOpenWallet={() => {
            void openWalletConnect();
          }}
        />

        {router.pathname === "/" && props.shopSkinBgUrl ? (
          <div className="max-w-xl mx-auto px-4 pt-3">
            <div className="efhc-skin-hero">
              <div className="efhc-skin-hero__image">
                <img
                  src={props.shopSkinBgUrl}
                  alt="Active skin"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="efhc-skin-hero__veil" />
            </div>
          </div>
        ) : null}

        <main
          className="max-w-xl mx-auto p-4 efhc-main"
          style={{
            paddingBottom: "calc(6rem + var(--efhc-safe-bottom))",
          }}
        >
          {props.children}
        </main>

        <nav
          className="fixed bottom-0 left-0 right-0 z-30 efhc-nav"
          style={{ paddingBottom: "var(--efhc-safe-bottom)" }}
        >
          <div className="max-w-xl mx-auto p-3">
            <div className="efhc-pill grid grid-cols-6 gap-2 p-2 rounded-3xl">
              {bottom.map((item) => (
                <NavItem
                  key={item.key}
                  href={item.href}
                  active={
                    item.href === "/"
                      ? router.pathname === "/"
                      : router.pathname === item.href ||
                        router.pathname.startsWith(`${item.href}/`)
                  }
                  label={item.label}
                  icon={<Icon kind={item.kind} />}
                  onNav={() => onTap("nav")}
                />
              ))}
            </div>
          </div>
        </nav>

        {toasts.length ? (
          <div className="fixed left-0 right-0 bottom-24 z-40 pointer-events-none">
            <div className="max-w-xl mx-auto px-4 grid gap-2">
              {toasts.map((item) => (
                <div
                  key={item.id}
                  className={
                    "pointer-events-none rounded-2xl px-4 py-3 " +
                    "text-sm backdrop-blur bg-[var(--tg-secondary-bg)] " +
                    "text-[var(--tg-text)] border " +
                    "border-[color:var(--tg-hint)]"
                  }
                >
                  {item.msg}
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <ProfileModal
          open={profileOpen}
          onClose={() => setProfileOpen(false)}
          settings={props.settings}
          setSettings={props.setSettings}
          telegramName={props.telegramName}
          telegramAvatarUrl={props.telegramAvatarUrl}
          isVip={props.isVip}
          hasActiv={props.snapshot?.profile?.has_activ || false}
          isAdmin={props.isAdmin}
          onOpenAdmin={() => {
            setProfileOpen(false);
            void router.push("/admin");
          }}
          initialSection={profileSection}
          walletHint={walletHint}
          onOpenWalletConnect={() => {
            void openWalletConnect();
          }}
          onDisconnectWalletSession={() => {
            void disconnectWalletSession();
          }}
          tonSessionConnected={sessionConnected}
          tonSessionRestoring={sessionRestoring}
          tonProofAccepted={proofAccepted}
          availableWallets={availableWallets}
          mainBalance={props.snapshot?.profile?.main_balance || "0.00000000"}
          bonusBalance={props.snapshot?.profile?.bonus_balance || "0.00000000"}
          tg_id={props.tg_id}
        />

        <DepositModal
          open={depositOpen}
          onClose={() => setDepositOpen(false)}
          tg_id={props.tg_id}
          onRequireWallet={() => {
            void openWalletConnect();
          }}
        />
      </div>
    </LayoutContext.Provider>
  );
}
