import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import type { Lang, Dict } from "../lib/i18n";
import { tFromDicts } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { ProfileModal } from "./ProfileModal";
import { DepositModal } from "./DepositModal";
import { playSfx } from "../lib/sfx";
import {
  hapticImpact,
  hapticNotify,
  telegramBackButtonShow,
  telegramConfirm,
} from "../lib/telegram";
import { GlobalHeader } from "./GlobalHeader";
import { getUserLevel } from "../lib/skins";
import { useWalletsMe } from "../hooks/useWalletsMe";
import { useQueryClient } from "@tanstack/react-query";
import { useTonConnectUI } from "@tonconnect/ui-react";

export type LayoutContextValue = {
  lang: Lang; // descriptions language
  t: (k: string) => string; // UI labels (English for all)
  td: (k: string) => string; // Descriptions (selected language)
  tg_id: number | null;
  isVip: boolean;
  isAdmin: boolean;
  settings: UserSettings;
  setLang: (l: Lang) => void;
  setSettings: (s: UserSettings) => void;
  confirm: (
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ) => Promise<boolean>;
  toast: (msg: string, kind?: "success" | "error" | "info") => void;
  openProfile: (section?: "wallet" | "history") => void;
  openDeposit: () => void;
  openWalletConnect: () => void;
};

export const LayoutContext = React.createContext<LayoutContextValue>({
  lang: "en",
  t: (k) => k,
  td: (k) => k,
  tg_id: null,
  isVip: false,
  isAdmin: false,
  settings: {
    lang: "en",
    theme_mode: "auto",
    avatar_source: "telegram",
    avatar_url: null,
    sfx_enabled: true,
    sfx_volume: 0.6,
    sfx_pack: "default",
    haptics_enabled: true,
    reduce_motion: false,
    hide_balances: false,
    show_decimal_detail: false,
    confirm_actions: true,
    confirm_purchase: true,
    confirm_withdraw: true,
    confirm_convert: true,
    confirm_watch_ad: true,
    toasts_enabled: true,
    important_alerts_only: false,
  },
  setLang: () => undefined,
  setSettings: () => undefined,
  confirm: async () => true,
  toast: () => undefined,
  openProfile: () => undefined,
  openDeposit: () => undefined,
  openWalletConnect: () => undefined,
});

function NavItem(
  props: {
    href: string;
    active: boolean;
    label: string;
    icon: React.ReactNode;
    onNav: () => void;
  },
) {
  const activeCls =
    "bg-[var(--tg-button)] text-[var(--tg-button-text)] ";
  const inactiveCls =
    "bg-[var(--tg-secondary-bg)] text-[var(--tg-text)] " +
    "border border-[color:var(--tg-hint)]";
  return (
    <Link
      href={props.href}
      onClick={(e) => {
        props.onNav();
        if (props.active) e.preventDefault();
      }}
      className={
        "flex flex-col items-center justify-center gap-1 px-2 py-2 " +
        "rounded-2xl text-xs font-semibold transition "
        + (props.active ? activeCls : inactiveCls)
      }
    >
      <span className="text-[var(--tg-text)]">{props.icon}</span>
      <span className="leading-none">{props.label}</span>
    </Link>
  );
}

function Icon(
  props: {
    kind:
      | "energy"
      | "panels"
      | "exchange"
      | "tasks"
      | "referrals"
      | "ranks";
  },
) {
  const c = "currentColor";
  const base = "w-5 h-5";
  if (props.kind === "energy") {
    return (
      <svg
        className={base}
        viewBox="0 0 24 24"
        fill="none"
        stroke={c}
        strokeWidth="2"
      >
        <path d="M13 2L3 14h7l-1 8 12-16h-7l-1-4z" />
      </svg>
    );
  }
  if (props.kind === "panels") {
    return (
      <svg
        className={base}
        viewBox="0 0 24 24"
        fill="none"
        stroke={c}
        strokeWidth="2"
      >
        <rect x="3" y="3" width="8" height="8" rx="2" />
        <rect x="13" y="3" width="8" height="8" rx="2" />
        <rect x="3" y="13" width="8" height="8" rx="2" />
        <rect x="13" y="13" width="8" height="8" rx="2" />
      </svg>
    );
  }
  if (props.kind === "exchange") {
    return (
      <svg
        className={base}
        viewBox="0 0 24 24"
        fill="none"
        stroke={c}
        strokeWidth="2"
      >
        <path d="M7 7h14l-3-3" />
        <path d="M17 17H3l3 3" />
        <path d="M3 7v6" />
        <path d="M21 17v-6" />
      </svg>
    );
  }
  if (props.kind === "tasks") {
    return (
      <svg
        className={base}
        viewBox="0 0 24 24"
        fill="none"
        stroke={c}
        strokeWidth="2"
      >
        <path d="M9 11l3 3L22 4" />
        <path
          d={
            "M21 12v7a2 2 0 0 1-2 2" +
            "H5a2 2 0 0 1-2-2V5" +
            "a2 2 0 0 1 2-2h11"
          }
        />
      </svg>
    );
  }
  if (props.kind === "referrals") {
    return (
      <svg
        className={base}
        viewBox="0 0 24 24"
        fill="none"
        stroke={c}
        strokeWidth="2"
      >
        <path
          d={
            "M16 11c1.66 0 3-1.79" +
            " 3-4s-1.34-4-3-4" +
            "-3 1.79-3 4 1.34 4 3 4z"
          }
        />
        <path
          d={
            "M8 11c1.66 0 3-1.79" +
            " 3-4S9.66 3 8 3" +
            " 5 4.79 5 7s1.34 4 3 4z"
          }
        />
        <path
          d={
            "M16 13c-2.67 0-8 1.34-8" +
            " 4v4h14v-4c0-2.66-3.33-4-6-4z"
          }
        />
        <path d="M8 13c-2.67 0-8 1.34-8 4v4h6" />
      </svg>
    );
  }
  return (
    <svg
      className={base}
      viewBox="0 0 24 24"
      fill="none"
      stroke={c}
      strokeWidth="2"
    >
      <path d="M8 21h8" />
      <path d="M12 17v4" />
      <path d="M7 4h10" />
      <path d="M17 4l-1 7a4 4 0 0 1-8 0L7 4" />
    </svg>
  );
}

export function Layout(
  props: React.PropsWithChildren<{
    lang: Lang;
    uiDict: Dict;
    ruDict: Dict;
    descDict: Dict;
    tg_id: number | null;
    telegramName: string;
    telegramAvatarUrl?: string | null;
    snapshot?: {
      profile: {
        username?: string | null;
        main_balance: string;
        bonus_balance: string;
        total_generated_kwh: string;
      };
    } | null;
    isVip: boolean;
    isAdmin: boolean;
    settings: UserSettings;
    setLang: (l: Lang) => void;
    setSettings: (s: UserSettings) => void;
  }>
) {
  const router = useRouter();
  // UI labels are English for all languages.
  const t = useMemo(
    () => (k: string) => tFromDicts(k, props.uiDict, props.ruDict),
    [props.uiDict, props.ruDict],
  );
  // Descriptions are language-dependent.
  const td = useMemo(
    () => (k: string) =>
      props.descDict[k] ||
      props.uiDict[k] ||
      props.ruDict[k] ||
      k,
    [props.descDict, props.uiDict, props.ruDict]
  );
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileSection, setProfileSection] = useState<
    "wallet" | "history" | null
  >(null);
  const [profileWalletHint, setProfileWalletHint] = useState<
    string | null
  >(null);
  const [depositOpen, setDepositOpen] = useState(false);

  const qc = useQueryClient();
  const [tonConnectUI] = useTonConnectUI();

  const walletsMe = useWalletsMe(props.tg_id);
  const walletConnected = Boolean(walletsMe.data?.is_connected);

  useEffect(() => {
    // After connect/disconnect backend is the source of truth.
    // Refetch /wallets/me on TonConnect status changes.
    if (!tonConnectUI) return;
    const unsub = tonConnectUI.onStatusChange(() => {
      if (!props.tg_id) return;
      qc.invalidateQueries({ queryKey: ["wallets_me", props.tg_id] })
        .catch(() => undefined);
    });
    return () => {
      try {
        unsub();
      } catch {
        // noop
      }
    };
  }, [tonConnectUI, qc, props.tg_id]);

  const avatarUrl =
    props.settings.avatar_source === "custom"
      ? props.settings.avatar_url || null
      : props.settings.avatar_source === "telegram"
        ? props.telegramAvatarUrl || null
        : null;

  const username =
    props.snapshot?.profile?.username || props.telegramName || "";

  const level = getUserLevel(
    props.snapshot?.profile?.total_generated_kwh || "0",
  );

  // Telegram BackButton should close overlays.
  // It should not leave the app.
  useEffect(() => {
    if (!profileOpen && !depositOpen) return;
    const off = telegramBackButtonShow(() => {
      if (depositOpen) {
        setDepositOpen(false);
        return;
      }
      setProfileOpen(false);
    });
    return () => off();
  }, [profileOpen, depositOpen]);

  const [toasts, setToasts] = useState<
    { id: string; msg: string; kind: "success" | "error" | "info" }[]
  >([]);

  function toast(
    msg: string, kind: "success" | "error" | "info" = "info",
  ) {
    if (!props.settings.toasts_enabled) return;
    // Telegram-native feedback for key outcomes.
    if (kind === "success") {
      hapticNotify(props.settings.haptics_enabled, "success");
    }
    if (kind === "error") {
      hapticNotify(props.settings.haptics_enabled, "error");
    }
    const id = `${Date.now()}:${Math.random().toString(16).slice(2)}`;
    setToasts((prev) => [...prev, { id, msg, kind }].slice(-4));
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }

  async function confirm(
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ): Promise<boolean> {
    if (!props.settings.confirm_actions) return true;
    const gate = {
      purchase: props.settings.confirm_purchase,
      withdraw: props.settings.confirm_withdraw,
      convert: props.settings.confirm_convert,
      watch_ad: props.settings.confirm_watch_ad,
      generic: true,
    }[kind];
    if (!gate) return true;
    return await telegramConfirm(title, detail);
  }

  // Canon: 6 tabs, fixed order. Do not change without updating
  // architectural locks.
  const bottom = [
    { href: "/", key: "nav.energy", label: "Energy" },
    { href: "/panels", key: "nav.panels", label: "Panels" },
    { href: "/exchange", key: "nav.exchange", label: "Exchange" },
    { href: "/tasks", key: "nav.tasks", label: "Tasks" },
    { href: "/referrals", key: "nav.referrals", label: "Referrals" },
    { href: "/ranks", key: "nav.ranks", label: "Ranks" },
  ];

  const onTap = (kind: "tap" | "nav") => {
    playSfx(
      kind,
      props.settings.sfx_enabled,
      props.settings.sfx_volume,
    );
    hapticImpact(props.settings.haptics_enabled);
  };

  function openProfile(section?: "wallet" | "history") {
    setProfileSection(section || null);
    if (section === "wallet") {
      setProfileWalletHint(
        "Подключите кошелёк, чтобы пополнить EFHC",
      );
    } else {
      setProfileWalletHint(null);
    }
    setProfileOpen(true);
  }

  function openWalletConnect() {
    // Open TonConnect modal immediately.
    try {
      tonConnectUI.openModal();
    } catch {
      // Best-effort: some versions expose connectWallet().
      try {
        (tonConnectUI as any)?.connectWallet?.();
      } catch {
        // noop
      }
    }
  }

  function openDeposit() {
    if (!walletConnected) {
      openWalletConnect();
      return;
    }
    setDepositOpen(true);
  }

  return (
    <LayoutContext.Provider
      value={{
        lang: props.lang,
        t,
        td,
        tg_id: props.tg_id,
        isVip: props.isVip,
        isAdmin: props.isAdmin,
        settings: props.settings,
        setLang: props.setLang,
        setSettings: props.setSettings,
        confirm,
        toast,
        openProfile,
        openDeposit,
        openWalletConnect,
      }}
    >
      <div
        className="bg-[var(--tg-bg)] efhc-app-frame"
        style={{
          minHeight: "var(--tg-viewport-height)",
          paddingBottom: "calc(6rem + var(--efhc-safe-bottom))",
        }}
      >
        <GlobalHeader
          username={username}
          avatarUrl={avatarUrl}
          level={level}
          mainBalance={props.snapshot?.profile?.main_balance || "0"}
          bonusBalance={props.snapshot?.profile?.bonus_balance || "0"}
          walletConnected={walletConnected}
          onAvatar={() => {
            onTap("tap");
            openProfile();
          }}
          onDeposit={() => openDeposit()}
          onOpenWallet={() => openWalletConnect()}
        />

        <main
  className="max-w-4xl mx-auto p-4"
  style={{
    paddingBottom: "calc(6rem + var(--efhc-safe-bottom))",
  }}
>
  {props.children}
</main>

        <nav
  className="fixed bottom-0 left-0 right-0 z-30 efhc-nav"
  style={{ paddingBottom: "var(--efhc-safe-bottom)" }}
>
          <div className="max-w-4xl mx-auto p-3">
  <div
    className={
      "efhc-pill grid grid-cols-6 gap-2 p-2 rounded-3xl"
    }
  >
            {bottom.map((n) => (
              <NavItem
                key={n.href}
                href={n.href}
                active={n.href === "/"
                  ? router.pathname === "/"
                  : (
                    router.pathname === n.href
                    || router.pathname.startsWith(`${n.href}/`)
                  )}
                label={n.label}
                icon={
                  <Icon
                    kind={
                      n.href === "/"
                        ? "energy"
                        : n.href === "/panels"
                          ? "panels"
                          : n.href === "/exchange"
                            ? "exchange"
                            : n.href === "/tasks"
                              ? "tasks"
                              : n.href === "/referrals"
                                ? "referrals"
                                : "ranks"
                    }
                  />
                }
                onNav={() => onTap("nav")}
              />
            ))}
            </div>
</div>
        </nav>

        {/* Toasts (Telegram-style light feedback) */}
        {toasts.length ? (
          <div
            className={
              "fixed left-0 right-0 bottom-24 z-40 " +
              "pointer-events-none"
            }
          >
            <div className="max-w-4xl mx-auto px-4 grid gap-2">
              {toasts.map((t) => (
                <div
                  key={t.id}
                  className={
                    "pointer-events-none rounded-2xl px-4 py-3 " +
                    "text-sm backdrop-blur " +
                    "bg-[var(--tg-secondary-bg)] " +
                    "text-[var(--tg-text)] " +
                    "border border-[color:var(--tg-hint)]"
                  }
                >
                  {t.msg}
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <ProfileModal
          open={profileOpen}
          onClose={() => setProfileOpen(false)}
          settings={props.settings}
          setSettings={props.setSettings}
          telegramName={props.telegramName}
          telegramAvatarUrl={props.telegramAvatarUrl}
          isVip={props.isVip}
          isAdmin={props.isAdmin}
          onOpenAdmin={() => {
            setProfileOpen(false);
            void router.push("/admin");
          }}
          initialSection={profileSection}
          walletHint={profileWalletHint}
          onOpenWalletConnect={() => openWalletConnect()}
          mainBalance={
            props.snapshot?.profile?.main_balance || "0.00000000"
          }
          bonusBalance={
            props.snapshot?.profile?.bonus_balance || "0.00000000"
          }
        />

        <DepositModal
          open={depositOpen}
          onClose={() => setDepositOpen(false)}
          tg_id={props.tg_id}
          onRequireWallet={() => openWalletConnect()}
        />
      </div>
    </LayoutContext.Provider>
  );
}
