import React from "react";

type LinkItem = { id: string; label: string; onClick: () => void };

export function FaqQuickLinks(props: { items: LinkItem[] }) {
  if (!props.items.length) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {props.items.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={item.onClick}
          className={[
            "rounded-full px-3 py-1.5 text-xs font-semibold",
            "bg-[var(--tg-bg)] text-[var(--tg-text)]",
            "border border-[color:var(--tg-hint)]/20",
          ].join(" ")}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}
