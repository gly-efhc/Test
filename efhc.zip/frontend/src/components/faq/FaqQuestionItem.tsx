import React from "react";
import type { FaqItem } from "../../data/faq/types";
import {
  TelegramAccordionItem,
} from "../ui/telegram/TelegramAccordionItem";
import { FaqKeywordTags } from "./FaqKeywordTags";
import { FaqAnswerText } from "./FaqAnswerText";

type Props = {
  item: FaqItem;
  isOpen: boolean;
  onToggle: () => void;
};

export function FaqQuestionItem(props: Props) {
  return (
    <TelegramAccordionItem
      title={props.item.question}
      isOpen={props.isOpen}
      onToggle={props.onToggle}
      answer={<FaqAnswerText text={props.item.answer} />}
      tags={<FaqKeywordTags tags={props.item.keywords} />}
    />
  );
}
