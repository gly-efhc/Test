import React from "react";
import { TelegramSearchBar } from "../ui/telegram/TelegramSearchBar";

export function FaqSearchBar(
  props: {
    value: string;
    onChange: (value: string) => void;
    placeholder: string;
    resultCount?: number;
    onClear: () => void;
  },
) {
  return <TelegramSearchBar {...props} />;
}
