import React from "react";
import type { FaqCatalog, FaqItem } from "../../data/faq/types";
import { FaqKeywordTags } from "./FaqKeywordTags";
import { FaqAnswerText } from "./FaqAnswerText";

type Props = {
  catalog: FaqCatalog;
  defaultItemId?: string | null;
  openAll?: boolean;
  compactTreeProof?: string;
};

function isDefaultOpen(items: FaqItem[], defaultItemId?: string | null) {
  if (!defaultItemId) return false;
  return items.some((item) => item.id === defaultItemId);
}

export function FaqVerticalTree(props: Props) {
  return (
    <div
      className="efhc-faq-vertical-tree"
      data-faq-visual-trust-tree="profile-wallet-history-faq"
      data-faq-vertical-tree={props.compactTreeProof || "true"}
    >
      {props.catalog.sections.map((section, sectionIndex) => (
        <details
          key={section.id}
          className="efhc-faq-section-node"
          open={props.openAll || sectionIndex === 0}
        >
          <summary>
            <span>{section.id}. {section.title}</span>
            <em>{section.subsections.length}</em>
          </summary>
          <div className="efhc-faq-subsection-stack">
            {section.subsections.map((subsection) => (
              <details
                key={subsection.id}
                className="efhc-faq-subsection-node"
                open={
                  props.openAll || isDefaultOpen(
                    subsection.items,
                    props.defaultItemId,
                  )
                }
              >
                <summary>
                  <span>{subsection.id}. {subsection.title}</span>
                  <em>{subsection.items.length}</em>
                </summary>
                <div className="efhc-faq-question-stack">
                  {subsection.items.map((item) => (
                    <details
                      key={item.id}
                      className="efhc-faq-question-node"
                      open={item.id === props.defaultItemId}
                    >
                      <summary>{item.question}</summary>
                      <div className="efhc-faq-answer-block">
                        <FaqAnswerText text={item.answer} />
                        {item.keywords?.length ? (
                          <FaqKeywordTags tags={item.keywords} />
                        ) : null}
                      </div>
                    </details>
                  ))}
                </div>
              </details>
            ))}
          </div>
        </details>
      ))}
    </div>
  );
}
