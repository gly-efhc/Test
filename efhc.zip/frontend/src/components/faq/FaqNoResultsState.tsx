import React from "react";
import { TelegramEmptyState } from "../ui/telegram/TelegramEmptyState";

export function FaqNoResultsState(
  props: { title: string; detail: string; onReset: () => void },
) {
  return (
    <TelegramEmptyState
      title={props.title}
      detail={props.detail}
      actionLabel="Reset"
      onAction={props.onReset}
    />
  );
}
