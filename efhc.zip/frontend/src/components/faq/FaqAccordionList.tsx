import React from "react";
import type { FaqItem, FaqSubsection } from "../../data/faq/types";
import { FaqQuestionItem } from "./FaqQuestionItem";
import { FaqRelatedQuestions } from "./FaqRelatedQuestions";
import { FaqQuickLinks } from "./FaqQuickLinks";
import { useT } from "../../hooks/useT";

type Props = {
  subsection: FaqSubsection;
  openItemId: string | null;
  relatedTitle: string;
  relatedItems: FaqItem[];
  onOpen: (itemId: string) => void;
  onQuickWallet: () => void;
  onQuickHistory: () => void;
  onQuickPage: (href: string) => void;
};

export function FaqAccordionList(props: Props) {
  const t = useT();
  return (
    <div className="grid gap-3">
      {props.subsection.items.map((item) => (
        <FaqQuestionItem
          key={item.id}
          item={item}
          isOpen={props.openItemId === item.id}
          onToggle={() => props.onOpen(item.id)}
        />
      ))}
      <FaqRelatedQuestions
        title={props.relatedTitle}
        items={props.relatedItems}
        onOpen={props.onOpen}
      />
      <FaqQuickLinks
        items={[
          {
            id: "wallet",
            label: t("wallet.title"),
            onClick: props.onQuickWallet,
          },
          {
            id: "history",
            label: t("history.title"),
            onClick: props.onQuickHistory,
          },
          {
            id: "panels",
            label: t("nav.panels"),
            onClick: () => props.onQuickPage("/panels"),
          },
          {
            id: "exchange",
            label: t("nav.exchange"),
            onClick: () => props.onQuickPage("/exchange"),
          },
          {
            id: "referrals",
            label: t("nav.referrals"),
            onClick: () => props.onQuickPage("/referrals"),
          },
          {
            id: "ranks",
            label: t("nav.ranks"),
            onClick: () => props.onQuickPage("/ranks"),
          },
        ]}
      />
    </div>
  );
}
