import React from "react";
import { Card } from "./ui/Card";

type Item = {
  label: string;
  value: string | number;
};

type Props = {
  title?: string;
  items: Item[];
};

export function AdminCharts(props: Props) {
  return (
    <Card title={props.title || "Admin Charts"}>
      <div className="grid gap-2 sm:grid-cols-2">
        {props.items.map((item) => (
          <div
            key={item.label}
            className="rounded-2xl border border-[color:var(--tg-hint)] p-3"
          >
            <div className="text-xs efhc-text-muted2">{item.label}</div>
            <div className="mt-1 text-lg font-semibold">
              {item.value}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
