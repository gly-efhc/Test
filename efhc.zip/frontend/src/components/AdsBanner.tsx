import React from "react";
import { Card } from "./ui/Card";
import { TelegramInfoBlock } from "./ui/telegram/TelegramInfoBlock";

export function AdsBanner() {
  return (
    <Card title="Ads">
      <TelegramInfoBlock title="Активных кампаний нет">
        Рекламный слот остаётся доступным, но в текущей сборке нет активных
        кампаний для показа.
      </TelegramInfoBlock>
    </Card>
  );
}
