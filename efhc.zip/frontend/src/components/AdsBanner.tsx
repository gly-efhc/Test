import React from "react";
import Link from "next/link";
import { Card } from "./ui/Card";
import { TelegramInfoBlock } from "./ui/telegram/TelegramInfoBlock";

type Props = {
  href?: string;
  title?: string;
  detail?: string;
};

export function AdsBanner(props: Props) {
  const href = props.href || "/tasks";
  return (
    <Card title={props.title || "Ads"}>
      <div className="space-y-3">
        <TelegramInfoBlock title="Активных кампаний нет">
          {props.detail || (
            <>
              Рекламный слот остаётся доступным, но в текущей
              сборке нет активных кампаний для показа.
            </>
          )}
        </TelegramInfoBlock>
        <Link className="efhc-link text-sm" href={href}>
          Открыть задачи и рекламный контур
        </Link>
      </div>
    </Card>
  );
}
