import React, { useContext, useEffect, useMemo } from "react";
import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { Skeleton } from "../ui/Skeleton";
import { EmptyState } from "../ui/EmptyState";
import { useT } from "../../hooks/useT";
import {
  fetchReferralsPage,
  fetchReferralsStats,
} from "../../lib/referrals";
import { LayoutContext } from "../Layout";
import { telegramBackButtonShow } from "../../lib/telegram";

type Props = {
  parent_tg_id: number;
  tab: "active" | "inactive";
};

export function ReferralListPage(props: Props) {
  const t = useT();
  const router = useRouter();
  const ctx = useContext(LayoutContext);

  useEffect(() => {
    const off = telegramBackButtonShow(() => {
      void router.push("/referrals");
    });
    return () => off();
  }, [router]);

  const statsQ = useQuery({
    queryKey: ["refStats", props.parent_tg_id],
    staleTime: 30_000,
    queryFn: async () => {
      return await fetchReferralsStats(props.parent_tg_id);
    },
  });

  const listQ = useInfiniteQuery({
    queryKey: ["refListPage", props.parent_tg_id, props.tab],
    staleTime: 30_000,
    initialPageParam: null as string | null,
    queryFn: async ({ pageParam }) => {
      return await fetchReferralsPage(
        props.parent_tg_id,
        props.tab,
        pageParam,
      );
    },
    getNextPageParam: (last) => last.next_cursor,
  });

  const items = useMemo(() => {
    return (listQ.data?.pages || []).flatMap(
      (page) => page.items || [],
    );
  }, [listQ.data]);

  const title = props.tab === "active"
    ? t("referrals.active_page")
    : t("referrals.inactive_page");
  const activeCount = statsQ.data?.active_referrals ?? 0;
  const inactiveCount = statsQ.data?.inactive_referrals ?? 0;
  const loading = listQ.isFetching && items.length === 0;

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{title}</h1>

      <Card>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant={props.tab === "active" ? "primary" : "secondary"}
            onClick={() => void router.push("/referrals/active")}
          >
            {t("referrals.active")} ({activeCount})
          </Button>
          <Button
            variant={props.tab === "inactive" ? "primary" : "secondary"}
            onClick={() => void router.push("/referrals/inactive")}
          >
            {t("referrals.inactive")} ({inactiveCount})
          </Button>
        </div>
      </Card>

      <Card title={title}>
        <div className="grid gap-2">
          {items.map((item) => (
            <div
              key={item.child_tg_id}
              className={[
                "rounded-2xl p-3 border",
                "border-[color:var(--tg-hint)]",
                "bg-[color:var(--tg-secondary-bg)]/40",
              ].join(" ")}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="font-semibold">
                  {item.username
                    ? `@${item.username}`
                    : `TG ${item.child_tg_id}`}
                </div>
                <Badge>
                  {item.is_active
                    ? t("referrals.active")
                    : t("referrals.inactive")}
                </Badge>
              </div>
            </div>
          ))}

          {loading ? (
            <div className="grid gap-2">
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
            </div>
          ) : null}

          {items.length === 0 && !listQ.isFetching ? (
            <EmptyState
              title={props.tab === "active"
                ? t("referrals.empty_active")
                : t("referrals.empty_inactive")}
              actionLabel={t("common.refresh")}
              onAction={() => {
                void statsQ.refetch();
                void listQ.refetch();
              }}
            />
          ) : null}

          <div className="flex items-center gap-2 mt-2">
            {listQ.hasNextPage ? (
              <Button
                disabled={listQ.isFetching}
                onClick={() => void listQ.fetchNextPage()}
              >
                {listQ.isFetching
                  ? t("common.loading")
                  : t("common.load_more")}
              </Button>
            ) : (
              <span className="text-xs efhc-text-muted2">
                {t("common.end")}
              </span>
            )}
            <Button
              variant="secondary"
              disabled={listQ.isFetching}
              onClick={() => {
                ctx.toast(t("common.refresh"), "info");
                void statsQ.refetch();
                void listQ.refetch();
              }}
            >
              {t("common.refresh")}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
