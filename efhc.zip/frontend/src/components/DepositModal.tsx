import React, { useContext, useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import { useT } from "../hooks/useT";
import { buildEfhcDirectDepositTx } from "../lib/ton/efhc-deposit-transfer";
import {
  useWalletProvider,
  type WalletTransactionPhase,
} from "../lib/wallet-provider";
import { queryKeys } from "../queries/queryKeys";
import {
  useDirectDepositOpen,
  useDirectDepositStatus,
} from "../queries/useDirectDeposit";
import { LayoutContext } from "./Layout";
import { Button } from "./ui/Button";
import { Modal } from "./ui/Modal";
import { TelegramEmptyState } from "./ui/telegram/TelegramEmptyState";
import { TelegramInfoBlock } from "./ui/telegram/TelegramInfoBlock";

function validEfhcAmount(value: string): boolean {
  const normalized = value.trim().replace(",", ".");
  if (!/^\d+(?:\.\d{0,8})?$/.test(normalized)) return false;
  const amount = Number(normalized);
  return Number.isFinite(amount) && amount > 0;
}

export function DepositModal(props: {
  open: boolean;
  onClose: () => void;
  tg_id: number | null;
}) {
  const t = useT();
  const globalId = useAuthOwnerGlobalId();
  const queryClient = useQueryClient();
  const { openWalletConnect } = useContext(LayoutContext);
  const {
    address: walletAddress,
    sendTransaction,
    isUserRejected,
  } = useWalletProvider();
  const [amount, setAmount] = useState("100");
  const [openedAt, setOpenedAt] = useState<string | null>(null);
  const [walletOpened, setWalletOpened] = useState(false);
  const [transactionPhase, setTransactionPhase] = useState<
    WalletTransactionPhase
  >("idle");
  const [error, setError] = useState<string | null>(null);
  const openDeposit = useDirectDepositOpen();
  const statusQ = useDirectDepositStatus(props.tg_id, openedAt);

  const amountValid = useMemo(() => validEfhcAmount(amount), [amount]);
  const confirmed = statusQ.data?.state === "confirmed";

  useEffect(() => {
    if (!confirmed) return;
    void Promise.all([
      queryClient.invalidateQueries({
        queryKey: queryKeys.snapshot.current(globalId),
      }),
      queryClient.invalidateQueries({
        queryKey: queryKeys.profile.balanceHistory(globalId),
      }),
    ]);
  }, [confirmed, globalId, queryClient]);

  useEffect(() => {
    if (props.open) return;
    setOpenedAt(null);
    setWalletOpened(false);
    setTransactionPhase("idle");
    setError(null);
    openDeposit.reset();
  }, [props.open]);

  async function sendDirectEfhcDeposit() {
    if (!globalId || !amountValid) {
      setError(t("deposit.amount_invalid"));
      return;
    }
    if (!walletAddress) {
      setError(t("deposit.wallet_required"));
      openWalletConnect();
      return;
    }
    setError(null);
    setTransactionPhase("signing");
    const startedAt = new Date().toISOString();
    try {
      const out = await openDeposit.mutateAsync();
      const endpoint = process.env.NEXT_PUBLIC_TON_RPC_ENDPOINT
        || "https://toncenter.com/api/v2/jsonRPC";
      const tx = await buildEfhcDirectDepositTx({
        endpoint,
        senderOwnerAddress: walletAddress,
        receiverOwnerAddress: out.receiver_owner_address,
        jettonMasterAddress: out.jetton_master_address,
        amountEfhc: amount,
        payloadText: out.forward_payload_text,
        feeMessageTonAmount: out.fee_message_ton_amount,
        forwardTonAmount: out.forward_ton_amount,
      });
      await sendTransaction(tx);
      setTransactionPhase("signed");
      setOpenedAt(startedAt);
      setWalletOpened(true);
    } catch (caught) {
      if (isUserRejected(caught)) {
        setTransactionPhase("rejected");
        setError(t("wallet.transaction_rejected"));
        return;
      }
      setTransactionPhase("error");
      setError(t("wallet.transaction_failed"));
    }
  }

  return (
    <Modal
      open={props.open}
      onClose={props.onClose}
      title={t("deposit.direct_title")}
    >
      <div
        className="efhc-direct-deposit"
        data-direct-deposit-runtime="efhc-jetton-wallet-reconciliation"
        data-direct-deposit-kind="efhc-jetton-to-efhcm"
        data-direct-deposit-label="direct"
      >
        <TelegramInfoBlock
          title={t("deposit.direct_title")}
          description={t("deposit.direct_description")}
        />

        {!walletOpened ? (
          <label className="efhc-direct-deposit_amount-field">
            <span>{t("deposit.amount_label")}</span>
            <div className="efhc-direct-deposit_amount-control">
              <input
                type="text"
                inputMode="decimal"
                autoComplete="off"
                value={amount}
                data-direct-deposit-amount="efhc-jetton"
                placeholder={t("deposit.amount_placeholder")}
                aria-invalid={!amountValid}
                onChange={(event) => {
                  setAmount(event.target.value);
                  setError(null);
                }}
              />
              <strong>EFHC</strong>
            </div>
            <small>{t("deposit.amount_hint")}</small>
          </label>
        ) : null}

        {!walletAddress && !walletOpened ? (
          <TelegramInfoBlock
            title={t("deposit.wallet_required_title")}
            description={t("deposit.wallet_required")}
          />
        ) : null}

        {transactionPhase === "signing" ? (
          <div
            className="efhc-tonconnect-transaction is-signing"
            role="status"
            aria-live="polite"
            data-tonconnect-transaction="signing"
            data-wallet-transaction="signing"
          >
            <span aria-hidden="true">↻</span>
            <div>
              <strong>{t("wallet.transaction_signing")}</strong>
              <p>{t("wallet.transaction_signing_detail")}</p>
            </div>
          </div>
        ) : null}

        {transactionPhase === "rejected" ? (
          <div
            className="efhc-tonconnect-transaction is-rejected"
            role="status"
            aria-live="polite"
            data-tonconnect-transaction="rejected"
            data-wallet-transaction="rejected"
          >
            <span aria-hidden="true">×</span>
            <div>
              <strong>{t("wallet.transaction_rejected")}</strong>
              <p>{t("wallet.transaction_rejected_detail")}</p>
            </div>
          </div>
        ) : null}

        {error ? (
          <TelegramEmptyState
            title={t("deposit.direct_error_title")}
            detail={error}
          />
        ) : null}

        {walletOpened && !confirmed ? (
          <div
            className="efhc-direct-deposit_status is-checking"
            role="status"
            aria-live="polite"
            data-direct-deposit-status="checking"
          >
            <span className="efhc-direct-deposit_status-icon">↻</span>
            <div>
              <strong>{t("deposit.status_checking_title")}</strong>
              <p>{t("deposit.status_checking_detail")}</p>
            </div>
          </div>
        ) : null}

        {confirmed ? (
          <div
            className="efhc-direct-deposit_status is-confirmed"
            role="status"
            aria-live="polite"
            data-direct-deposit-status="confirmed"
          >
            <span className="efhc-direct-deposit_status-icon">✓</span>
            <div>
              <strong>{t("deposit.status_confirmed_title")}</strong>
              <p>
                {t("deposit.status_confirmed_detail")}
                {statusQ.data?.amount_efhc
                  ? ` ${statusQ.data.amount_efhc} EFHCm`
                  : ""}
              </p>
            </div>
          </div>
        ) : null}

        <div className="efhc-direct-deposit_actions">
          {!walletOpened ? (
            <Button
              variant="primary"
              disabled={
                openDeposit.isPending
                || transactionPhase === "signing"
                || !globalId
                || !amountValid
              }
              data-direct-deposit-action="send-efhc-jetton"
              onClick={() => void sendDirectEfhcDeposit()}
            >
              {transactionPhase === "signing"
                ? t("wallet.transaction_signing")
                : openDeposit.isPending
                  ? t("deposit.opening")
                : walletAddress
                  ? t("deposit.direct_send_efhc")
                  : t("deposit.connect_wallet")}
            </Button>
          ) : !confirmed ? (
            <Button
              variant="primary"
              disabled={statusQ.isFetching}
              data-direct-deposit-action="check-status"
              onClick={() => void statusQ.refetch()}
            >
              {statusQ.isFetching
                ? t("common.loading")
                : t("deposit.status_retry")}
            </Button>
          ) : null}
          <Button variant="secondary" onClick={props.onClose}>
            {confirmed ? t("common.close") : t("common.cancel")}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

/* Direct deposit = EFHC jetton -> EFHCm only. */
