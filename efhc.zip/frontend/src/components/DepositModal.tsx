import React, { useEffect, useMemo, useState } from "react";
import { useTonConnectUI } from "@tonconnect/ui-react";

import { Modal } from "./ui/Modal";
import { Button } from "./ui/Button";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import { useWalletsMe } from "../hooks/useWalletsMe";

type SalePackage = {
  id: number;
  title: string;
  asset: "TON" | "USDT";
  price_asset_d8: string;
  efhc_amount_d8: string;
  is_active?: boolean;
};

type TonConnectTx = {
  validUntil: number;
  messages: { address: string; amount: string; payload?: string }[];
};

type DepositPackagesResponse = {
  items: SalePackage[];
};

type DepositCreateResponse = {
  tonconnect_tx: TonConnectTx | null;
};

export function DepositModal(props: {
  open: boolean;
  onClose: () => void;
  tg_id: number | null;
  onRequireWallet: () => void;
}) {
  const walletsMe = useWalletsMe(props.tg_id);
  const isConnected = Boolean(walletsMe.data?.is_connected);
  const [tonConnectUI] = useTonConnectUI();

  const [packages, setPackages] = useState<SalePackage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [paying, setPaying] = useState(false);
  const [payError, setPayError] = useState<string | null>(null);

  const hasPackages = useMemo(() => packages.length > 0, [packages]);

  useEffect(() => {
    if (!props.open) return;
    setError(null);
    setLoading(true);
    apiRequest<DepositPackagesResponse>("/deposit/packages", "GET")
      .then((r) => {
        const items = r?.items || [];
        setPackages(items);
      })
      .catch(() => {
        setError("Не удалось загрузить пакеты пополнения");
      })
      .finally(() => setLoading(false));
  }, [props.open]);

  async function onPay(pkg: SalePackage) {
    setPayError(null);
    if (!isConnected) {
      props.onClose();
      props.onRequireWallet();
      return;
    }
    setPaying(true);
    try {
      const idk = newIdempotencyKey();
      const r = await apiRequest<DepositCreateResponse>(
        "/deposit/efhc",
        "POST",
        {
        idempotencyKey: idk,
        body: { package_id: pkg.id },
        },
      );
      const tx = r.tonconnect_tx;
      if (!tx) throw new Error("NO_TX");
      await tonConnectUI.sendTransaction(tx);
      props.onClose();
    } catch {
      setPayError("Оплата не отправлена");
    } finally {
      setPaying(false);
    }
  }

  return (
    <Modal
      open={props.open}
      onClose={props.onClose}
      title="Пополнить EFHC"
    >
      <div className="space-y-3">
        {!isConnected ? (
          <div className="efhc-card p-3 space-y-2">
            <div className="font-semibold">Кошелёк не подключён</div>
            <div className="text-sm text-[color:var(--tg-hint)]">
              Подключите кошелёк, чтобы пополнить EFHC.
            </div>
            <Button
              variant="primary"
              onClick={() => {
                props.onClose();
                props.onRequireWallet();
              }}
            >
              Подключить кошелёк
            </Button>
          </div>
        ) : null}

        {error ? (
          <div className="text-sm text-[color:var(--tg-hint)]">
            {error}
          </div>
        ) : null}

        {loading ? (
          <div className="text-sm text-[color:var(--tg-hint)]">
            Загрузка...
          </div>
        ) : null}

        {!loading && !error && !hasPackages ? (
          <div className="text-sm text-[color:var(--tg-hint)]">
            Нет активных пакетов
          </div>
        ) : null}

        <div className="space-y-2">
          {packages.map((p) => (
            <div
              key={p.id}
              className="efhc-card p-3 flex items-center gap-3"
            >
              <div className="min-w-0 flex-1">
                <div className="font-semibold truncate">{p.title}</div>
                <div
                  className={
                    "text-xs text-[color:var(--tg-hint)] " +
                    "tabular-nums"
                  }
                >
                  {p.efhc_amount_d8} EFHC · {p.price_asset_d8} {p.asset}
                </div>
              </div>
              <Button
                variant="primary"
                disabled={paying || !isConnected}
                onClick={() => void onPay(p)}
              >
                Оплатить
              </Button>
            </div>
          ))}
        </div>

        {payError ? (
          <div className="text-sm text-[color:var(--tg-hint)]">
            {payError}
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
