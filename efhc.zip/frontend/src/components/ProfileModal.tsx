import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  useTonWallet,
} from "@tonconnect/ui-react";
import { Modal } from "./ui/Modal";
import { Button } from "./ui/Button";
import { SUPPORTED_LANGS, type Lang } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { resetSettings } from "../lib/settings";
import { openTelegramLink } from "../lib/telegram";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";

type WalletItem = {
  id: number;
  wallet_address: string;
  wallet_app: string | null;
  is_primary: boolean;
  is_active: boolean;
  created_at: string;
};

type WalletsMeResponse = {
  wallets: WalletItem[];
};

function langLabel(l: Lang): string {
  // Short labels; UI is English per requirement.
  const m: Record<string, string> = {
    en: "English",
    ru: "Russian",
    ua: "Ukrainian",
    de: "German",
    fr: "French",
    es: "Spanish",
    it: "Italian",
    tr: "Turkish",
    pl: "Polish",
    da: "Danish",
    hi: "Hindi",
    id: "Indonesian",
    sw: "Swahili",
  };
  return m[l] || l;
}

function langFlag(l: Lang): string {
  // Emoji flags render as images on most platforms.
  // Telegram is included.
  const m: Record<string, string> = {
    en: "🇺🇸",
    ru: "🇷🇺",
    ua: "🇺🇦",
    de: "🇩🇪",
    fr: "🇫🇷",
    es: "🇪🇸",
    it: "🇮🇹",
    tr: "🇹🇷",
    pl: "🇵🇱",
    da: "🇩🇰",
    hi: "🇮🇳",
    id: "🇮🇩",
    sw: "🇰🇪",
  };
  return m[l] || "🏳️";
}

export function ProfileModal(props: {
  open: boolean;
  onClose: () => void;
  settings: UserSettings;
  setSettings: (next: UserSettings) => void;
  telegramName: string;
  telegramAvatarUrl?: string | null;
  isVip: boolean;
  isAdmin: boolean;
  onOpenAdmin: () => void;
  initialSection?: "wallet" | null;
  walletHint?: string | null;
  onOpenWalletConnect: () => void;
}) {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [tmpAvatarPreview, setTmpAvatarPreview] =
    useState<string | null>(null);

  const tonWallet = useTonWallet();
  const [wallets, setWallets] = useState<WalletItem[]>([]);
  const [walletsLoading, setWalletsLoading] = useState<boolean>(false);
  const [walletsError, setWalletsError] = useState<string | null>(null);

  const isWalletConnected = useMemo(() => {
    return wallets.some((w) => w.is_active);
  }, [wallets]);

  const walletBlockRef = useRef<HTMLDivElement | null>(null);

  async function refreshWallets() {
    setWalletsLoading(true);
    setWalletsError(null);
    try {
      const r = await apiRequest<WalletsMeResponse>(
        "/wallets/me",
        "GET",
      );
      setWallets(r.wallets || []);
    } catch {
      setWalletsError("Failed to load wallets");
    } finally {
      setWalletsLoading(false);
    }
  }

  useEffect(() => {
    if (!props.open) return;
    refreshWallets().catch(() => undefined);
  }, [props.open]);

  useEffect(() => {
    if (!props.open) return;
    if (props.initialSection !== "wallet") return;
    window.setTimeout(() => {
      walletBlockRef.current?.scrollIntoView({
        block: "start",
        behavior: "smooth",
      });
    }, 0);
  }, [props.open, props.initialSection]);

  useEffect(() => {
    if (!props.open) return;
    const addr = tonWallet?.account?.address || "";
    if (!addr) return;
    const idk = newIdempotencyKey();
    apiRequest("/wallets/connect", "POST", {
      idempotencyKey: idk,
      body: {
        address: addr,
        wallet_app: tonWallet?.device?.appName || null,
      },
    })
      .then(() => refreshWallets())
      .catch(() => undefined);
  }, [props.open, tonWallet?.account?.address]);

  const currentAvatar = useMemo(() => {
    const custom = props.settings.avatar_source === "custom" ?
      props.settings.avatar_url
      : null;
    const tg = props.settings.avatar_source === "telegram" ?
      props.telegramAvatarUrl
      : null;
    return tmpAvatarPreview || custom || tg || null;
    }, [
    tmpAvatarPreview,
    props.settings.avatar_source,
    props.settings.avatar_url,
    props.telegramAvatarUrl,
  ]);

  function update(patch: Partial<UserSettings>) {
    props.setSettings({ ...props.settings, ...patch });
  }

  async function onPickAvatar(file: File) {
    // Store locally as dataURL (Telegram-only UI; no backend upload
    // contract defined yet).
    const reader = new FileReader();
    reader.onload = () => {
      const url = typeof reader.result === "string" ?
        reader.result
        : null;
      if (!url) return;
      setTmpAvatarPreview(url);
      update({ avatar_source: "custom", avatar_url: url });
    };
    reader.readAsDataURL(file);
  }

  return (
    <Modal
      open={props.open}
      onClose={props.onClose}
      title="Profile & Settings"
    >
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div
            className={
              "w-14 h-14 rounded-2xl "
              + "bg-[var(--tg-secondary-bg)] overflow-hidden "
              + "flex items-center justify-center"
            }
          >
            {currentAvatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={currentAvatar}
                alt="avatar"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-sm text-[color:var(--tg-hint)]">
                No avatar
              </div>
            )}
          </div>
          <div className="flex-1">
            <div className="font-semibold">
              {props.telegramName || "Telegram user"}
            </div>
            <div
              className={
                "text-xs text-[color:var(--tg-hint)] "
                + "flex items-center gap-2"
              }
            >
              {props.isVip ? (
                <span
                  className={
                    "px-2 py-0.5 rounded-xl "
                    + "efhc-status efhc-status-accent"
                  }
                >
                  VIP
                </span>
              ) : null}
              {props.isAdmin ? (
                <span
                  className={
                    "px-2 py-0.5 rounded-xl "
                    + "bg-[var(--tg-secondary-bg)]"
                  }
                >
                  ADMIN
                </span>
              ) : null}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 justify-end">
              <Button
                onClick={() => update({ avatar_source: "telegram" })}
                variant={
                  props.settings.avatar_source === "telegram"
                    ? "primary"
                    : "secondary"
                }
              >
                Telegram avatar
              </Button>
              <Button
                onClick={() => fileRef.current?.click()}
                variant={
                  props.settings.avatar_source === "custom"
                    ? "primary"
                    : "secondary"
                }
              >
                Custom avatar
              </Button>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void onPickAvatar(f);
              }}
            />
            {
              props.settings.avatar_source === "custom" &&
              props.settings.avatar_url ? (

              <div className="mt-2 flex justify-end">
                <Button
                  variant="secondary"
                  onClick={() =>
                    update({
                      avatar_source: "telegram",
                      avatar_url: null,
                    })
                  }
                >
                  Reset to Telegram
                </Button>
              </div>
            ) : null}
          </div>
        </div>

        {/* Wallet */}
        <div
          ref={walletBlockRef}
          className="efhc-card p-3 space-y-3"
        >
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-semibold">Кошелёк</div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Required for deposit, shop external, withdraw,
                lotteries.
              </div>
            </div>
            <Button
              variant={isWalletConnected ? "secondary" : "primary"}
              disabled={isWalletConnected}
              onClick={() => {
                props.onOpenWalletConnect();
              }}
            >
              {isWalletConnected
                ? "Кошелёк подключён"
                : "Подключить кошелёк"}
            </Button>
          </div>

          {props.walletHint ? (
            <div className="text-xs text-[color:var(--tg-hint)]">
              {props.walletHint}
            </div>
          ) : null}

          {walletsError ? (
            <div className="text-xs text-[color:var(--tg-hint)]">
              {walletsError}
            </div>
          ) : null}

          <div className="space-y-2">
            {walletsLoading ? (
              <div className="text-xs text-[color:var(--tg-hint)]">
                Loading...
              </div>
            ) : null}

            {wallets.map((w) => (
              <div
                key={w.id}
                className={
                  "flex items-center gap-2 "
                  + "bg-[var(--tg-secondary-bg)] "
                  + "rounded-2xl px-3 py-2"
                }
              >
                <div className="min-w-0 flex-1">
                  <div
                    className={
                      "text-sm font-medium truncate "
                      + "tabular-nums"
                    }
                  >
                    {w.wallet_address}
                  </div>
                  <div
                    className={
                      "text-xs text-[color:var(--tg-hint)] "
                      + "flex items-center gap-2"
                    }
                  >
                    {w.wallet_app ? <span>{w.wallet_app}</span> : null}
                    {w.is_primary ? (
                      <span className="efhc-status efhc-status-accent">
                        PRIMARY
                      </span>
                    ) : null}
                    {!w.is_active ? <span>inactive</span> : null}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="secondary"
                    disabled={!w.is_active || w.is_primary}
                    onClick={() => {
                      const path = (
                        `/wallets/${w.id}/make-primary`
                      );
                      apiRequest(path, "POST")
                        .then(() => refreshWallets())
                        .catch(() => undefined);
                    }}
                  >
                    Make primary
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => {
                      apiRequest(`/wallets/${w.id}`, "DELETE")
                        .then(() => refreshWallets())
                        .catch(() => undefined);
                    }}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            ))}

            {!walletsLoading && wallets.length === 0 ? (
              <div className="text-xs text-[color:var(--tg-hint)]">
                No wallets linked.
              </div>
            ) : null}
          </div>
        </div>

        {/* Language */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Language</div>
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-medium">Descriptions language</div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Buttons & levels are always English.
              </div>
            </div>
            <div className="flex flex-wrap justify-end gap-2">
              {SUPPORTED_LANGS.map((l) => {
                const active = props.settings.lang === l;
                return (
                  <button
                    key={l}
                    type="button"
                    onClick={() => update({ lang: l })}
                    className={
                      "inline-flex items-center gap-2 px-3 py-1.5 " +
                      "rounded-2xl border text-sm transition " +
                      (active
                        ? (
                          "border-[color:var(--tg-hint)] "
                          + "bg-[var(--tg-button)] "
                          + "text-[color:var(--tg-button-text)]"
                        )
                        : (
                          "border-[color:var(--tg-hint)] "
                          + "bg-[var(--tg-bg)] "
                          + "text-[color:var(--tg-text)] "
                          + "hover:opacity-90"
                        ))
                    }
                    aria-label={`Set language ${langLabel(l)}`}
                  >
                    <span className="text-base leading-none">
                      {langFlag(l)}
                    </span>
                    <span
                      className={
                        "text-xs font-semibold tracking-wide opacity-90"
                      }
                    >
                      {l.toUpperCase()}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Appearance */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Appearance</div>
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-medium">Theme</div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Auto follows Telegram. You can force dark/light here.
              </div>
            </div>
            <select
              value={props.settings.theme_mode}
              onChange={(e) =>
                update({ theme_mode: e.target.value as any })
              }
              className={
                "text-sm border border-[color:var(--tg-hint)] "
                + "rounded-xl px-2 py-1 bg-[var(--tg-bg)]"
              }
            >
              <option value="auto">Auto (Telegram)</option>
              <option value="dark">Dark</option>
              <option value="light">Light</option>
            </select>
          </div>
        </div>

        {/* Sound & Haptics */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Sound & Haptics</div>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">UI sounds</div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Tap, navigation, success/error, rewards.
              </div>
            </div>
            <input
              type="checkbox"
              checked={props.settings.sfx_enabled}
              onChange={(e) =>
                update({ sfx_enabled: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Sound volume</div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={props.settings.sfx_volume}
              onChange={(e) =>
                update({ sfx_volume: Number(e.target.value) })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Sound pack</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Default
                </div>
            </div>
            <select
              value={props.settings.sfx_pack}
              onChange={(e) =>
                update({ sfx_pack: e.target.value as any })
              }
              className={
                "text-sm border border-[color:var(--tg-hint)] "
                + "rounded-xl px-2 py-1 bg-[var(--tg-bg)]"
              }
            >
              <option value="default">Default UI</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Haptics</div>
            <input
              type="checkbox"
              checked={props.settings.haptics_enabled}
              onChange={(e) =>
                update({ haptics_enabled: e.target.checked })
              }
            />
          </div>
        </div>

        {/* Privacy & Display */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Privacy & Display</div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Hide balances</div>
            <input
              type="checkbox"
              checked={props.settings.hide_balances}
              onChange={(e) =>
                update({ hide_balances: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">Show decimal detail</div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Still shows 8 decimals everywhere.
              </div>
            </div>
            <input
              type="checkbox"
              checked={props.settings.show_decimal_detail}
              onChange={(e) =>
                update({ show_decimal_detail: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Reduce motion</div>
            <input
              type="checkbox"
              checked={props.settings.reduce_motion}
              onChange={(e) =>
                update({ reduce_motion: e.target.checked })
              }
            />
          </div>
        </div>

        {/* Confirmations */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Confirmations</div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Confirm actions (master)</div>
            <input
              type="checkbox"
              checked={props.settings.confirm_actions}
              onChange={(e) =>
                update({ confirm_actions: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Confirm purchase</div>
            <input
              type="checkbox"
              checked={props.settings.confirm_purchase}
              onChange={(e) =>
                update({ confirm_purchase: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Confirm withdraw request</div>
            <input
              type="checkbox"
              checked={props.settings.confirm_withdraw}
              onChange={(e) =>
                update({ confirm_withdraw: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">
              Confirm convert (kWh → EFHC)
            </div>
            <input
              type="checkbox"
              checked={props.settings.confirm_convert}
              onChange={(e) =>
                update({ confirm_convert: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Confirm watch ad</div>
            <input
              type="checkbox"
              checked={props.settings.confirm_watch_ad}
              onChange={(e) =>
                update({ confirm_watch_ad: e.target.checked })
              }
            />
          </div>
        </div>

        {/* Notifications */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Notifications</div>
          <div className="flex items-center justify-between">
            <div className="font-medium">In-app toasts</div>
            <input
              type="checkbox"
              checked={props.settings.toasts_enabled}
              onChange={(e) =>
                update({ toasts_enabled: e.target.checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="font-medium">Important alerts only</div>
            <input
              type="checkbox"
              checked={props.settings.important_alerts_only}
              onChange={(e) =>
                update({ important_alerts_only: e.target.checked })
              }
            />
          </div>
        </div>

        {/* Support / Info */}
        <div className="efhc-card p-3 space-y-3">
          <div className="font-semibold">Support & Info</div>
          <div className="grid grid-cols-2 gap-2">
            <Button
  variant="secondary"
  onClick={() =>
    openTelegramLink("https://sites.google.com/view/efhc")
  }
>
  FAQ
</Button>
            <Button
  variant="secondary"
  onClick={() => openTelegramLink("https://t.me/")}
>
  Support chat
</Button>
            <Button
  variant="secondary"
  onClick={() =>
    openTelegramLink("https://sites.google.com/view/efhc")
  }
>
  Terms
</Button>
            <Button
  variant="secondary"
  onClick={() =>
    openTelegramLink("https://sites.google.com/view/efhc")
  }
>
  Privacy
</Button>
          </div>
<div className="text-xs text-[color:var(--tg-hint)]">
  App version is shown in build metadata.
</div>
          <div className="flex justify-end">
            <Button
              variant="secondary"
              onClick={() => {
                props.setSettings(resetSettings());
              }}
            >
              Reset settings
            </Button>
          </div>
        </div>

        {props.isAdmin ? (
          <div className="flex justify-end">
            <Button onClick={props.onOpenAdmin}>Admin Panel</Button>
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
