import React, { useMemo } from "react";
import {
  AdminActionTable,
  AdminChartCard,
  AdminConfirmationBlock,
  AdminEmptyState,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminKpiCard,
  AdminSectionHeader,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

type CatalogItemLike = {
  sku: string;
  code?: string;
  title: string;
  item_type?: string;
  status?: string;
  active?: boolean;
  is_active?: boolean;
  price_ton?: string;
  price_usdt?: string;
  pay_currencies?: string[];
  methods?: Record<string, { price?: string } | undefined> | null;
};

type OrderLike = Record<string, unknown>;

type Props = {
  catalog: CatalogItemLike[];
  orders: OrderLike[];
  selectedCode: string | null;
  activeTab: string;
  paymentLane: string;
  loading: boolean;
  onTabChange: (value: string) => void;
  onPaymentLaneChange: (value: string) => void;
  onSelectCode: (code: string) => void;
  onRefreshOrders: () => void;
  onCreateItem: () => void;
};

function itemCode(item: CatalogItemLike): string {
  return item.code || item.sku;
}

function statusOf(item: CatalogItemLike): string {
  if (item.status) return item.status;
  if (item.active ?? item.is_active) return "live";
  return "hidden";
}

function hasTon(item: CatalogItemLike): boolean {
  return Boolean(item.price_ton || item.methods?.TON?.price);
}

function hasUsdt(item: CatalogItemLike): boolean {
  return Boolean(item.price_usdt || item.methods?.USDT?.price);
}

function orderStatus(row: OrderLike): string {
  return String(row.status || "unknown");
}

function countOrders(orders: OrderLike[], status: string): number {
  return orders.filter((row) => orderStatus(row) === status).length;
}

export function AdminShopWeb3SeparationPanel(props: Props) {
  const liveItems = props.catalog.filter((item) => statusOf(item) === "live");
  const draftItems = props.catalog.filter((item) => statusOf(item) === "draft");
  const hiddenItems = props.catalog.filter((item) => statusOf(item) === "hidden");
  const tonReady = props.catalog.filter(hasTon);
  const usdtPlanned = props.catalog.filter(hasUsdt);
  const pendingOrders = countOrders(props.orders, "PENDING");
  const paidOrders = countOrders(props.orders, "PAID");
  const selectedItem = useMemo(
    () => props.catalog.find((item) => itemCode(item) === props.selectedCode),
    [props.catalog, props.selectedCode],
  );

  const visibleItems = useMemo(
    () => props.catalog.slice(0, 6),
    [props.catalog],
  );

  const liveShare = props.catalog.length
    ? Math.round((liveItems.length / props.catalog.length) * 100)
    : 0;
  const tonShare = props.catalog.length
    ? Math.round((tonReady.length / props.catalog.length) * 100)
    : 0;

  return (
    <section
      className="efhc-admin-shop-web3"
      data-admin-shop-web3-separation-cycle="1339"
      data-admin-sandbox-source="ui-main section-cards; data-table; chart-area-interactive; MaterialM dashboard cards"
    >
      <AdminSectionHeader
        eyebrow="Shop Admin · Web3 separation"
        title="Мобильная панель Shop / Web3 платежей"
        subtitle={
          "Admin управляет карточками и решениями оператора. Web3 payment " +
          "остается отдельной пользовательской дорогой с memo / intent / watcher."
        }
        actions={
          <button
            type="button"
            className="efhc-admin-live-dashboard_live"
            onClick={props.onRefreshOrders}
            disabled={props.loading}
          >
            {props.loading ? "Обновляется" : "Обновить заказы"}
          </button>
        }
      />

      <AdminFilterBar
        groups={[
          {
            label: "Раздел",
            value: props.activeTab,
            options: [
              { key: "catalog", label: "Каталог" },
              { key: "preview", label: "Preview" },
              { key: "orders", label: "Orders" },
              { key: "history", label: "History" },
            ],
            onChange: props.onTabChange,
          },
          {
            label: "Payment lane",
            value: props.paymentLane,
            options: [
              { key: "ton", label: `TON ${tonReady.length}` },
              { key: "usdt", label: `USDT planned ${usdtPlanned.length}` },
              { key: "intent", label: "Intent / memo" },
            ],
            onChange: props.onPaymentLaneChange,
          },
        ]}
      />

      <div className="efhc-admin-shop-web3_kpis">
        <AdminKpiCard
          label="Каталог"
          value={props.catalog.length}
          meta="shop items"
          hint={`${liveItems.length} live · ${hiddenItems.length} hidden`}
          tone="primary"
        />
        <AdminKpiCard
          label="TON-ready"
          value={`${tonShare}%`}
          meta={`${tonReady.length} карточек`}
          hint="активная Web3 дорога"
          tone="success"
        />
        <AdminKpiCard
          label="Draft archive"
          value={draftItems.length}
          meta="архив без hard delete"
          hint="безопасная зона оператора"
          tone="warning"
        />
        <AdminKpiCard
          label="Orders"
          value={props.orders.length}
          meta={`${pendingOrders} pending · ${paidOrders} paid`}
          hint="runtime слой заказов"
          tone="neutral"
        />
      </div>

      <AdminFlowMapCard
        title="Разделение ответственности"
        nodes={[
          {
            label: "1. Admin item",
            value: selectedItem ? itemCode(selectedItem) : "нет выбора",
            hint: selectedItem?.title || "карточка каталога",
            active: Boolean(selectedItem),
          },
          {
            label: "2. Operator action",
            value: props.activeTab,
            hint: "edit / archive / status / order review",
            active: true,
          },
          {
            label: "3. Web3 intent",
            value: props.paymentLane.toUpperCase(),
            hint: "создает пользовательский checkout, не admin UI",
            active: props.paymentLane !== "usdt",
          },
          {
            label: "4. Watcher match",
            value: "memo + amount",
            hint: "credit только по разрешенному intent",
            active: true,
          },
        ]}
      />

      <div className="efhc-admin-shop-web3_grid">
        <AdminChartCard
          title="Состояние каталога"
          subtitle="Мобильный chart-like блок без внешней chart dependency"
          meta={<AdminStatusBadge label="live snapshot" tone="primary" />}
        >
          <div className="efhc-admin-shop-web3_bars" aria-label="Shop status chart">
            <span style={{ height: `${Math.max(10, liveShare)}%` }}>
              live {liveItems.length}
            </span>
            <span style={{ height: `${Math.max(10, 100 - liveShare)}%` }}>
              non-live {hiddenItems.length + draftItems.length}
            </span>
            <span style={{ height: `${Math.max(10, tonShare)}%` }}>
              TON {tonReady.length}
            </span>
          </div>
        </AdminChartCard>

        <AdminChartCard
          title="Быстрый выбор карточки"
          subtitle="List/detail паттерн Песочницы адаптирован под Shop"
          meta={<AdminStatusBadge label="mobile deck" tone="success" />}
        >
          {visibleItems.length ? (
            <div className="efhc-admin-shop-web3_deck">
              {visibleItems.map((item) => {
                const code = itemCode(item);
                const selected = code === props.selectedCode;
                return (
                  <button
                    key={code}
                    type="button"
                    className="efhc-admin-shop-web3_card"
                    data-selected={selected ? "true" : "false"}
                    onClick={() => props.onSelectCode(code)}
                  >
                    <strong>{item.title}</strong>
                    <span>{code} · {item.item_type || "EFHC_PACKAGE"}</span>
                    <small>
                      {statusOf(item)} · TON {hasTon(item) ? "ready" : "—"}
                    </small>
                  </button>
                );
              })}
            </div>
          ) : (
            <AdminEmptyState
              title="Каталог пуст"
              text="Создайте первую карточку через operator action."
            />
          )}
        </AdminChartCard>
      </div>

      <AdminActionTable
        title="Operator / Web3 boundary"
        rows={[
          {
            label: "Admin actions",
            value: "edit, status, archive, delete, force fulfill",
            hint: "только операторская поверхность",
          },
          {
            label: "Web3 user flow",
            value: "checkout, intent, memo, watcher",
            hint: "не превращать в admin raw payload",
          },
          {
            label: "USDT lane",
            value: "planned / disabled until real jetton payload",
            hint: "не включать как live checkout без реализации",
          },
        ]}
      />

      <AdminConfirmationBlock
        title="Канон безопасности платежей"
        text={
          "Свободный платеж с memo не кредитуется. Credit возможен только " +
          "после server-created payment intent и полного watcher match."
        }
        confirmed
      />

      <div className="efhc-admin-shop-web3_actions">
        <button type="button" onClick={props.onCreateItem}>
          Новая карточка
        </button>
        <button type="button" onClick={() => props.onTabChange("orders")}>
          Открыть заказы
        </button>
        <button type="button" onClick={() => props.onTabChange("preview")}>
          Preview витрины
        </button>
      </div>
    </section>
  );
}
