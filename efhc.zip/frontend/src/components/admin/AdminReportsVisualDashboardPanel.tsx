import React, { useMemo, useState } from "react";

import {
  AdminActionTable,
  AdminAreaChart,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminEmptyState,
  AdminErrorState,
  AdminFilterBar,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminPanelInspectorDrawer,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusCard,
  AdminTimeRangePicker,
  AdminTrendCard,
} from "./AdminDashboardUiKit";

type Overview = {
  ok: boolean;
  ts: string;
  counters: Record<string, number>;
  facts?: Record<string, string>;
  notes?: string | null;
};

type ReportScope = "economy" | "users" | "panels";
type ReportMode = "snapshot" | "counters" | "facts";

type MetricPoint = {
  key: string;
  label: string;
  value: number;
  display: string;
};

type Props = {
  overview: Overview | null;
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
};

const SANDBOX_SOURCE = [
  "ui-main chart-area-interactive",
  "section-cards",
  "data-table",
  "MaterialM EarningReports",
].join("; ");

const SCOPE_LABELS: Record<ReportScope, string> = {
  economy: "Экономика",
  users: "Пользователи",
  panels: "Панели",
};

const MODE_LABELS: Record<ReportMode, string> = {
  snapshot: "Snapshot",
  counters: "Counters",
  facts: "Facts",
};

function numberFrom(value: string | number | undefined): number {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }
  const clean = String(value || "0")
    .replace(/\s/g, "")
    .replace(/,/g, ".");
  const parsed = Number(clean);
  return Number.isFinite(parsed) ? parsed : 0;
}

function displayFrom(value: string | number | undefined): string {
  if (value === undefined || value === null || value === "") return "0";
  return String(value);
}

function metric(
  key: string,
  label: string,
  value: string | number | undefined,
): MetricPoint {
  return {
    key,
    label,
    value: numberFrom(value),
    display: displayFrom(value),
  };
}

function buildMetrics(
  overview: Overview | null,
  scope: ReportScope,
): MetricPoint[] {
  const counters = overview?.counters || {};
  const facts = overview?.facts || {};

  if (scope === "users") {
    return [
      metric("users_total", "Всего", counters.users_total),
      metric("users_active", "Активные", counters.users_active),
      metric("users_inactive", "Неактивные", counters.users_inactive),
      metric("users_total_efhc", "EFHC", facts.users_total_efhc),
      metric(
        "users_total_generated_kwh",
        "kWh сгенерировано",
        facts.users_total_generated_kwh,
      ),
    ];
  }

  if (scope === "panels") {
    return [
      metric(
        "panels_total_bought",
        "Куплено",
        facts.panels_total_bought,
      ),
      metric(
        "panels_total_active",
        "Активные",
        facts.panels_total_active,
      ),
      metric(
        "panels_total_archived",
        "Архив",
        facts.panels_total_archived,
      ),
      metric(
        "panels_total_paid_efhc",
        "Списано EFHC",
        facts.panels_total_paid_efhc,
      ),
    ];
  }

  return [
    metric("bank_total_efhc", "Банк EFHC", facts.bank_total_efhc),
    metric("users_total_efhc", "Users EFHC", facts.users_total_efhc),
    metric(
      "users_total_exchanged_kwh",
      "kWh → EFHC",
      facts.users_total_exchanged_kwh,
    ),
    metric(
      "referrals_total_bonus_paid_efhc",
      "Реф. бонусы",
      facts.referrals_total_bonus_paid_efhc,
    ),
    metric(
      "bank_users_balance_diff_efhc",
      "Bank/User diff",
      facts.bank_users_balance_diff_efhc,
    ),
  ];
}

function chartPoints(metrics: MetricPoint[]) {
  return metrics.map((item) => ({
    id: item.key,
    label: item.label,
    value: Math.abs(item.value),
  }));
}

function metricPercent(metricValue: number, total: number): number {
  if (!total) return 0;
  return Math.round((Math.abs(metricValue) / total) * 100);
}

function freshnessLabel(overview: Overview | null): string {
  if (!overview) return "ожидание snapshot";
  if (!overview.ok) return "snapshot с предупреждением";
  return "snapshot свежий";
}

export function AdminReportsVisualDashboardPanel(props: Props) {
  const [scope, setScope] = useState<ReportScope>("economy");
  const [mode, setMode] = useState<ReportMode>("snapshot");
  const [selectedPoint, setSelectedPoint] = useState(0);
  const metrics = useMemo(
    () => buildMetrics(props.overview, scope),
    [props.overview, scope],
  );
  const points = useMemo(() => chartPoints(metrics), [metrics]);
  const selectedIndex = selectedPoint % Math.max(metrics.length, 1);
  const selectedMetric = metrics[selectedIndex];
  const totalValue = metrics.reduce(
    (sum, item) => sum + Math.abs(item.value),
    0,
  );
  const countersCount = Object.keys(
    props.overview?.counters || {},
  ).length;
  const factsCount = Object.keys(props.overview?.facts || {}).length;
  const primaryValue = metrics[0]?.display || "0";
  const secondaryValue = metrics[1]?.display || "0";
  const selectedPercent = metricPercent(
    selectedMetric?.value ?? 0,
    totalValue,
  );

  return (
    <section
      className="efhc-admin-reports-visual"
      data-admin-reports-grafana-like="1482"
      data-admin-reports-no-debug-json="true"
      data-admin-reports-no-raw-payload="true"
      data-admin-reports-no-synthetic="true"
      data-admin-reports-no-write-actions="true"
      data-admin-reports-truth="raw-derived"
      data-admin-reports-visual-cycle="1343"
      data-admin-sandbox-source={SANDBOX_SOURCE}
    >
      <AdminDashboardToolbar
        actions={(
          <AdminRefreshPicker
            disabled={props.loading}
            label="Интервал"
            onRefresh={props.onRefresh}
            refreshLabel={props.loading ? "Обновление" : "Обновить"}
            value="manual"
          />
        )}
        breadcrumb="Admin / Reports"
        freshness={(
          <AdminFreshnessBadge
            freshness={props.overview ? "fresh" : "unknown"}
            label={freshnessLabel(props.overview)}
            updatedAt={props.overview?.ts ?? "нет данных"}
          />
        )}
        subtitle={
          "Grafana-like read-only отчётность: KPI, panels, "
          + "safe inspector и честный derived snapshot."
        }
        timeRange={(
          <AdminTimeRangeControl mode={mode} onChange={setMode} />
        )}
        title="Admin Reports Dashboard"
        updatedAt={props.overview?.ts ?? "ожидание backend overview"}
      />

      <AdminFilterBar
        groups={[
          {
            key: "admin-reports-scope",
            label: "Срез",
            value: scope,
            options: [
              { key: "economy", label: "Экономика" },
              { key: "users", label: "Users" },
              { key: "panels", label: "Panels" },
            ],
            onChange: (value) => {
              setScope(value as ReportScope);
              setSelectedPoint(0);
            },
            querySync: "disabled",
          },
        ]}
      />

      {props.error ? (
        <AdminErrorState title="Ошибка отчёта" text={props.error} />
      ) : null}

      <AdminDashboardGrid>
        <AdminStatusCard
          hint="Данные берутся из существующего read-only endpoint."
          label="Overview API"
          status={props.overview?.ok ? "success" : "stale"}
          tone={props.overview?.ok ? "success" : "warning"}
          value={props.overview?.ok ? "OK" : "ожидание"}
        />
        <AdminTrendCard
          hint="Активный display-only scope."
          label="Срез"
          tone="info"
          value={SCOPE_LABELS[scope]}
        />
        <AdminTrendCard
          hint={metrics[0]?.label || "нет метрики"}
          label="Главная метрика"
          tone="success"
          value={primaryValue}
        />
        <AdminTrendCard
          hint="counters / facts без raw payload."
          label="Поля отчёта"
          tone="neutral"
          value={`${countersCount}/${factsCount}`}
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-reports-visual_grid">
        <AdminPanelChrome
          footer={
            "Derived chart from current overview snapshot. "
            + "No real time-series claim."
          }
          source="/admin/reports/overview"
          status={props.overview ? "success" : "stale"}
          title="Snapshot chart panel"
          tone="info"
          updatedAt={props.overview?.ts ?? "нет snapshot"}
        >
          {props.overview ? (
            <>
              <AdminAreaChart
                ariaLabel="Admin reports derived snapshot area chart"
                emptyLabel="Нет данных"
                label={`${SCOPE_LABELS[scope]} · ${MODE_LABELS[mode]}`}
                points={points}
                source="derived snapshot display"
                unit="snapshot"
              />
              <AdminMiniBarChart
                ariaLabel="Admin reports derived bar chart"
                emptyLabel="Нет данных"
                label="Метрики среза"
                points={points}
                source="overview facts/counters"
                unit="value"
              />
            </>
          ) : (
            <AdminEmptyState
              title="Нет отчёта"
              text="Нажмите обновление, чтобы загрузить snapshot."
            />
          )}
        </AdminPanelChrome>

        <AdminPanelChrome
          footer="Panel inspector показывает только safe summary."
          source="safe inspector"
          status={selectedMetric ? "success" : "empty"}
          title="Panel Inspector"
          tone="neutral"
        >
          <AdminPanelInspectorDrawer
            open={Boolean(selectedMetric)}
            source="sanitized overview metric"
            title="Inspector · selected metric"
          >
            <AdminActionTable
              rows={[
                {
                  label: "Метрика",
                  value: selectedMetric?.label || "—",
                  hint: selectedMetric?.key || "нет ключа",
                },
                {
                  label: "Значение",
                  value: selectedMetric?.display || "0",
                  hint: "read-only snapshot value",
                },
                {
                  label: "Доля",
                  value: `${selectedPercent}%`,
                  hint: "derived display, not money logic",
                },
              ]}
              title="Operator detail"
            />
          </AdminPanelInspectorDrawer>
        </AdminPanelChrome>
      </div>

      <AdminPanelChrome
        footer="Rows are sanitized. Raw payload/debug JSON is hidden."
        source="overview facts/counters"
        status={metrics.length ? "success" : "empty"}
        title="Metric rows"
        tone="success"
      >
        {metrics.length ? (
          <div className="efhc-admin-reports-visual_deck">
            {metrics.map((item, index) => (
              <button
                className="efhc-admin-reports-visual_metric"
                data-selected={
                  index === selectedPoint % metrics.length
                }
                key={item.key}
                onClick={() => setSelectedPoint(index)}
                type="button"
              >
                <span>{item.label}</span>
                <strong>{item.display}</strong>
                <small>{item.key}</small>
              </button>
            ))}
          </div>
        ) : (
          <AdminEmptyState title="Метрик нет" text="Snapshot пуст." />
        )}
      </AdminPanelChrome>

      <AdminPanelChrome
        footer="Reports dashboard is read-only and cannot mutate state."
        source="cycle 1482 truth boundary"
        status="success"
        title="Truth / safety boundary"
        tone="warning"
      >
        <div className="efhc-admin-reports-grafana-boundary">
          <span>raw + derived snapshot</span>
          <span>без synthetic analytics</span>
          <span>без fake time-series</span>
          <span>без raw payload/debug JSON</span>
          <span>без write-flow bypass</span>
        </div>
        <AdminHeatStrip
          ariaLabel="Admin reports safety boundary"
          label="Boundary strip"
          points={[
            {
              id: "truth",
              label: "truth",
              tone: "success",
              value: 1,
            },
            {
              id: "synthetic",
              label: "no synthetic",
              tone: "warning",
              value: 1,
            },
            {
              id: "write",
              label: "no write",
              tone: "info",
              value: 1,
            },
          ]}
          source="cycle 1482 guard"
        />
      </AdminPanelChrome>

      <AdminProgressBar
        ariaLabel="Selected metric share"
        label="Selected metric share"
        max={100}
        showValue
        source="derived from visible metric set"
        value={selectedPercent}
      />
    </section>
  );
}

function AdminTimeRangeControl(props: {
  mode: ReportMode;
  onChange: (value: ReportMode) => void;
}) {
  return (
    <AdminTimeRangePicker
      label="Режим"
      onChange={(value) => props.onChange(value as ReportMode)}
      options={[
        {
          key: "snapshot",
          label: "Snapshot",
          description: "Только текущий backend snapshot",
        },
        {
          key: "counters",
          label: "Counters",
          description: "Счётчики без raw payload",
        },
        {
          key: "facts",
          label: "Facts",
          description: "Факты без fake history",
        },
      ]}
      value={props.mode}
    />
  );
}

export const adminReportsGrafanaLikeDashboardVersion =
  "EFHC_ADMIN_REPORTS_GRAFANA_LIKE_V1";
