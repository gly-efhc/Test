import React, { useMemo } from "react";
import {
  AdminActionTable,
  AdminChartCard,
  AdminConfirmationBlock,
  AdminEmptyState,
  AdminErrorState,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminKpiCard,
  AdminSectionHeader,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

type TaskLike = {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
  bonus_efhc?: string;
  kind: string;
};

type SubmissionLike = {
  id: number;
  task_id: number;
  tg_id: number;
  status: string;
  bonus_efhc?: string | null;
};

type Props = {
  tasks: TaskLike[];
  submissions: SubmissionLike[];
  selectedTaskId: number | null;
  selectedStatus: string;
  loadingTasks: boolean;
  loadingSubmissions: boolean;
  tasksError: string | null;
  submissionsError: string | null;
  operationMessage: string | null;
  taskCursor: string | null;
  submissionsCursor: string | null;
  onSelectTask: (taskId: number) => void;
  onStatusChange: (status: string) => void;
  onRefreshTasks: () => void;
  onRefreshSubmissions: () => void;
  onRefreshStatuses: () => void;
};

function countStatus(items: SubmissionLike[], status: string): number {
  return items.filter((item) => item.status === status).length;
}

function taskKindLabel(kind: string): string {
  const value = kind || "manual";
  if (value === "ad") return "ad task";
  if (value === "manual") return "manual proof";
  return value;
}

function taskTone(active: boolean): "success" | "neutral" {
  return active ? "success" : "neutral";
}

export function AdminTasksCatalogUxPanel(props: Props) {
  const activeTasks = props.tasks.filter((task) => task.is_active);
  const inactiveTasks = props.tasks.filter((task) => !task.is_active);
  const pending = countStatus(props.submissions, "PENDING");
  const approved = countStatus(props.submissions, "APPROVED");
  const rejected = countStatus(props.submissions, "REJECTED");
  const selectedTask = useMemo(
    () => props.tasks.find((task) => task.id === props.selectedTaskId) || null,
    [props.tasks, props.selectedTaskId],
  );
  const visibleTasks = useMemo(() => props.tasks.slice(0, 8), [props.tasks]);
  const activeShare = props.tasks.length
    ? Math.round((activeTasks.length / props.tasks.length) * 100)
    : 0;
  const moderationShare = props.submissions.length
    ? Math.round((pending / props.submissions.length) * 100)
    : 0;

  return (
    <section
      className="efhc-admin-tasks-catalog"
      data-admin-tasks-catalog-ux-cycle="1341"
      data-admin-sandbox-source="ui-main data-table; section-cards; chart-area-interactive; MaterialM dashboard cards"
    >
      <AdminSectionHeader
        eyebrow="Tasks Admin · catalog UX"
        title="Мобильный каталог заданий и очередь модерации"
        subtitle={
          "Сначала оператор выбирает task-карточку, затем управляет " +
          "очередью proof-заявок без route diagnostics на рабочей поверхности."
        }
        actions={
          <button
            type="button"
            className="efhc-admin-live-dashboard_live"
            onClick={props.onRefreshTasks}
            disabled={props.loadingTasks}
          >
            {props.loadingTasks ? "Загрузка" : "Обновить каталог"}
          </button>
        }
      />

      <AdminFilterBar
        groups={[
          {
            label: "Очередь",
            value: props.selectedStatus,
            options: [
              { key: "PENDING", label: `Ожидает ${pending}` },
              { key: "APPROVED", label: `Одобрено ${approved}` },
              { key: "REJECTED", label: `Отклонено ${rejected}` },
              { key: "ALL", label: "Все" },
            ],
            onChange: props.onStatusChange,
          },
        ]}
      />

      <div className="efhc-admin-tasks-catalog_kpis">
        <AdminKpiCard
          label="Задания"
          value={props.tasks.length}
          meta={`${activeTasks.length} активно · ${inactiveTasks.length} неактивно`}
          hint="каталог operator-controlled"
          tone="primary"
        />
        <AdminKpiCard
          label="Active share"
          value={`${activeShare}%`}
          meta="видимость каталога"
          hint="неактивные не удаляются"
          tone="success"
        />
        <AdminKpiCard
          label="Очередь"
          value={props.submissions.length}
          meta={`${pending} pending · ${approved} approved`}
          hint="proof-модерация"
          tone="warning"
        />
        <AdminKpiCard
          label="Выбрано"
          value={selectedTask ? `#${selectedTask.id}` : "нет"}
          meta={selectedTask ? taskKindLabel(selectedTask.kind) : "task deck"}
          hint={selectedTask?.title || "выберите карточку"}
          tone="neutral"
        />
      </div>

      <AdminFlowMapCard
        title="Tasks moderation flow"
        nodes={[
          {
            label: "1. Task card",
            value: selectedTask ? `#${selectedTask.id}` : "нет",
            hint: selectedTask?.title || "выбор задания",
            active: Boolean(selectedTask),
          },
          {
            label: "2. User proof",
            value: props.selectedStatus,
            hint: "proof_text / proof_url",
            active: true,
          },
          {
            label: "3. Moderator decision",
            value: "approve / reject",
            hint: "idempotency key required",
            active: true,
          },
          {
            label: "4. Reward result",
            value: "bonus EFHC",
            hint: "банк и история не обходятся UI",
            active: approved > 0,
          },
        ]}
      />

      <div className="efhc-admin-tasks-catalog_grid">
        <AdminChartCard
          title="Каталог заданий"
          subtitle="Mobile data deck вместо технического списка маршрутов"
          meta={<AdminStatusBadge label="catalog" tone="primary" />}
        >
          {props.tasksError ? (
            <AdminErrorState title="Ошибка каталога" text={props.tasksError} />
          ) : visibleTasks.length ? (
            <div className="efhc-admin-tasks-catalog_deck">
              {visibleTasks.map((task) => {
                const selected = task.id === props.selectedTaskId;
                return (
                  <button
                    key={task.id}
                    type="button"
                    className="efhc-admin-tasks-catalog_card"
                    data-selected={selected ? "true" : "false"}
                    onClick={() => props.onSelectTask(task.id)}
                  >
                    <strong>{task.title}</strong>
                    <span>
                      #{task.id} · {taskKindLabel(task.kind)}
                    </span>
                    <small>
                      {task.bonus_efhc || "0"} EFHC ·{" "}
                      {task.is_active ? "Активно" : "Неактивно"}
                    </small>
                    <AdminStatusBadge
                      label={task.is_active ? "Активно" : "Неактивно"}
                      tone={taskTone(task.is_active)}
                    />
                  </button>
                );
              })}
            </div>
          ) : (
            <AdminEmptyState
              title="Заданий нет"
              text="Каталог пуст или ещё не загружен."
            />
          )}
        </AdminChartCard>

        <AdminChartCard
          title="Состояние очереди"
          subtitle="Интерактивная сводка по текущему фильтру"
          meta={<AdminStatusBadge label="moderation" tone="warning" />}
        >
          {props.submissionsError ? (
            <AdminErrorState
              title="Ошибка очереди"
              text={props.submissionsError}
            />
          ) : (
            <div
              className="efhc-admin-tasks-catalog_bars"
              aria-label="Tasks moderation status chart"
            >
              <span style={{ height: `${Math.max(10, moderationShare)}%` }}>
                pending {pending}
              </span>
              <span style={{ height: `${Math.max(10, approved * 15)}%` }}>
                approved {approved}
              </span>
              <span style={{ height: `${Math.max(10, rejected * 15)}%` }}>
                rejected {rejected}
              </span>
            </div>
          )}
        </AdminChartCard>
      </div>

      <AdminActionTable
        title="Операторские действия"
        rows={[
          {
            label: "Catalog refresh",
            value: props.loadingTasks ? "loading" : "available",
            hint: props.taskCursor
              ? "есть следующая страница"
              : "первая страница",
          },
          {
            label: "Queue refresh",
            value: props.loadingSubmissions ? "loading" : "available",
            hint: props.submissionsCursor
              ? "есть следующая страница"
              : "текущий фильтр",
          },
          {
            label: "Status sync",
            value: "manual operator action",
            hint: "не выполняется фоном из UI без клика",
          },
        ]}
      />

      <div className="efhc-admin-tasks-catalog_actions">
        <button type="button" onClick={props.onRefreshSubmissions}>
          Обновить очередь
        </button>
        <button type="button" onClick={props.onRefreshStatuses}>
          Обновить статусы
        </button>
      </div>

      {props.operationMessage ? (
        <AdminConfirmationBlock
          title="Статус операции"
          text={props.operationMessage}
          confirmed
        />
      ) : null}
    </section>
  );
}
