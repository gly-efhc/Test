import React from "react";

import {
  AdminHeatStrip,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminFreshnessBadge,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

export const adminBankDashboardRuntimeVersion =
  "EFHC_ADMIN_BANK_DASHBOARD_RUNTIME_V1";

type AdminBankTone = "success" | "warning" | "danger" | "neutral";

type TransferLogItem = {
  id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  created_at: string;
};

type BankChartPoint = {
  id: string;
  label: string;
  value: number;
  tone?: "success" | "warning" | "info" | "neutral" | "danger";
};

export type AdminBankDashboardRuntimeProps = {
  bankName: string;
  bankBalance: string;
  usersTotal: string;
  usersMain: string;
  usersBonus: string;
  bankUsersDiff: string;
  bankUsersMatch: string;
  panelsPaid: string;
  exchangedKwh: string;
  ledger: TransferLogItem[];
  updatedAt?: string;
  pendingMode?: string | null;
  pendingIdempotency?: string;
  onRefresh: () => void;
};

const ZERO_D8 = "0.00000000";

function toNumber(value: string | undefined): number {
  if (!value) return 0;
  const parsed = Number(String(value).replace(/,/g, "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function absNumber(value: string | undefined): number {
  return Math.abs(toNumber(value));
}

function human(value: string | number | undefined): string {
  const numberValue = typeof value === "number" ? value : toNumber(value);
  return numberValue.toLocaleString("ru-RU", {
    maximumFractionDigits: 8,
  });
}

function safeLabel(value: string | undefined): string {
  const trimmed = String(value || "").trim();
  return trimmed || "—";
}

function statusTone(match: string): AdminBankTone {
  if (match === "OK") return "success";
  if (!match || match === "no overview") return "warning";
  return "danger";
}

function recentLedgerTone(item: TransferLogItem) {
  if (item.direction === "user_credit") return "warning";
  if (item.direction === "user_debit") return "success";
  return "info";
}

function buildBankChartPoints(
  props: AdminBankDashboardRuntimeProps,
): BankChartPoint[] {
  return [
    {
      id: "bank",
      label: "Банк",
      value: absNumber(props.bankBalance),
      tone: "success",
    },
    {
      id: "users",
      label: "Пользователи",
      value: absNumber(props.usersTotal),
      tone: "info",
    },
    {
      id: "panels",
      label: "Панели",
      value: absNumber(props.panelsPaid),
      tone: "neutral",
    },
    {
      id: "diff",
      label: "Разница",
      value: absNumber(props.bankUsersDiff),
      tone: props.bankUsersMatch === "OK" ? "success" : "warning",
    },
  ];
}

function ledgerDirectionLabel(item: TransferLogItem): string {
  if (item.direction === "user_credit") return "user credit ⇒ bank debit";
  if (item.direction === "user_debit") return "user debit ⇒ bank credit";
  return safeLabel(item.direction);
}

export function AdminBankDashboardRuntime(
  props: AdminBankDashboardRuntimeProps,
) {
  const chartPoints = buildBankChartPoints(props);
  const hasOverview = Boolean(props.bankUsersMatch);
  const matchTone = statusTone(props.bankUsersMatch);
  const source =
    "GET /admin/bank/balance + /admin/reports/overview + " +
    "GET /admin/logs/transfers";
  const operationReady = props.pendingMode
    ? `ожидает подтверждение: ${props.pendingMode}`
    : "нет активного действия";

  return (
    <section
      className="efhc-admin-bank-dashboard-runtime"
      data-admin-bank-dashboard-runtime="1483"
      data-admin-bank-truth="raw-derived"
      data-admin-bank-no-synthetic="true"
      data-admin-bank-no-write-actions="true"
      data-admin-bank-no-raw-payload="true"
      data-admin-bank-no-debug-json="true"
      data-admin-bank-canon="bank-can-go-negative"
    >
      <AdminDashboardToolbar
        title="Bank Dashboard"
        subtitle="Операторский read-only обзор банка EFHC, потоков и ledger."
        breadcrumb="Admin / Bank"
        refresh={(
          <AdminRefreshPicker
            label="Refresh mode"
            onRefresh={props.onRefresh}
            refreshLabel="Обновить"
            value="manual"
          />
        )}
        updatedAt={props.updatedAt || "snapshot"}
        freshness={(
          <AdminFreshnessBadge
            freshness={hasOverview ? "fresh" : "stale"}
            label={hasOverview ? "overview loaded" : "overview pending"}
          />
        )}
        filters={(
          <AdminFilterBar
            groups={[
              {
                key: "bank-scope",
                label: "Срез",
                value: "snapshot",
                options: [
                  { key: "snapshot", label: "Snapshot" },
                  { key: "ledger", label: "Ledger" },
                  { key: "flows", label: "Flows" },
                ],
                onChange: () => undefined,
              },
            ]}
          />
        )}
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Bank actor"
          value={safeLabel(props.bankName)}
          meta="EFHC_MAIN"
          hint="Банковый ключ баланса, не пользовательский кошелёк."
          tone="neutral"
        />
        <AdminKpiCard
          label="Баланс банка"
          value={human(props.bankBalance)}
          meta="банк может быть отрицательным"
          hint="Минус банка не является дефектом сам по себе."
          tone="success"
        />
        <AdminKpiCard
          label="Пользовательские EFHC"
          value={human(props.usersTotal)}
          meta="main + bonus"
          hint="Read-only сверка из overview."
          tone="neutral"
        />
        <AdminKpiCard
          label="Сверка банк/пользователи"
          value={safeLabel(props.bankUsersMatch || "pending")}
          meta={human(props.bankUsersDiff || ZERO_D8)}
          hint="Инцидент — не минус банка, а неканоничная проводка."
          tone={matchTone}
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-bank-dashboard-grid">
        <AdminPanelChrome
          title="Bank / Users / Panels snapshot"
          subtitle="Derived snapshot display; это не real time-series."
          status={hasOverview ? "success" : "stale"}
          tone="info"
          source={source}
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminMiniBarChart
            ariaLabel="Сравнение банка, пользователей, панелей и разницы"
            dataKind="derived"
            points={chartPoints}
            source="derived from current overview snapshot"
            unit="EFHC"
          />
          <div className="efhc-admin-bank-dashboard-bars">
            {chartPoints.map((point) => (
              <div className="efhc-admin-bank-dashboard-row" key={point.id}>
                <span>{point.label}</span>
                <strong>{human(point.value)}</strong>
              </div>
            ))}
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Canonical flow map"
          subtitle="Направления проводок закреплены BANK_CANON."
          status="success"
          tone="success"
          source="docs/SSOT/BANK_CANON.md"
        >
          <AdminFlowMapCard
            title="Bank / Users / Panels / Exchange"
            nodes={[
              {
                label: "Bank",
                value: human(props.bankBalance),
                hint: "EFHC_MAIN; can go negative",
                active: true,
              },
              {
                label: "Users",
                value: human(props.usersTotal),
                hint: "main + bonus; no negative user balances",
              },
              {
                label: "Panels",
                value: human(props.panelsPaid),
                hint: "100 EFHC activation flow",
              },
              {
                label: "Ledger",
                value: String(props.ledger.length),
                hint: "recent transfer rows",
              },
            ]}
          />
        </AdminPanelChrome>
      </div>

      <div className="efhc-admin-bank-dashboard-grid">
        <AdminPanelChrome
          title="Operational status"
          subtitle="Read-only status of dangerous actions and audit boundary."
          status={props.pendingMode ? "stale" : "success"}
          tone={props.pendingMode ? "warning" : "success"}
          source="local UI state + existing guarded action flow"
        >
          <div className="efhc-admin-bank-dashboard-status-grid">
            <AdminStatusBadge
              label={operationReady}
              tone={props.pendingMode ? "warning" : "success"}
            />
            <AdminStatusBadge
              label="mint/burn только через подтверждение"
              tone="warning"
            />
            <AdminStatusBadge
              label="idempotency обязателен"
              tone="primary"
            />
            <AdminStatusBadge
              label="ручной SQL запрещён"
              tone="danger"
            />
          </div>
          <AdminProgressBar
            dataKind="derived"
            label="Ledger sample coverage"
            max={12}
            showValue
            source="GET /admin/logs/transfers?limit=12"
            tone={props.ledger.length ? "success" : "warning"}
            value={Math.min(props.ledger.length, 12)}
          />
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Recent ledger timeline"
          subtitle="Последние проводки без raw payload/debug dump."
          status={props.ledger.length ? "success" : "empty"}
          tone="neutral"
          source="GET /admin/logs/transfers?limit=12"
        >
          <AdminHeatStrip
            ariaLabel="Последние ledger события банка"
            dataKind="raw"
            emptyLabel="Ledger пока пуст"
            points={props.ledger.slice(0, 12).map((item, index) => ({
              id: String(item.id || index),
              label: item.created_at || `ledger ${index + 1}`,
              value: props.ledger.length - index,
              tone: recentLedgerTone(item),
            }))}
            source="recent ledger rows"
          />
          <div className="efhc-admin-bank-dashboard-ledger-preview">
            {props.ledger.slice(0, 4).map((item) => (
              <div key={item.id}>
                <span>{ledgerDirectionLabel(item)}</span>
                <strong>{human(item.amount)}</strong>
                <small>{safeLabel(item.reason)}</small>
              </div>
            ))}
            {!props.ledger.length ? (
              <p>Ledger пока пуст или недоступен для текущей админ-сессии.</p>
            ) : null}
          </div>
        </AdminPanelChrome>
      </div>

      <AdminPanelChrome
        title="Bank safety boundary"
        subtitle="Dashboard усиливает контроль, но не меняет финансовый контур."
        status="success"
        tone="warning"
        source="BANK_CANON + AI_ARCHIVE_LAWS"
      >
        <div className="efhc-admin-bank-dashboard-boundary">
          <span>user credit ⇒ bank debit</span>
          <span>user debit ⇒ bank credit</span>
          <span>bank can go negative</span>
          <span>no raw SQL money updates</span>
          <span>no dashboard write bypass</span>
          <span>no secrets / raw payload / debug JSON</span>
        </div>
      </AdminPanelChrome>
    </section>
  );
}
