import React from "react";
import { LayoutContext } from "../Layout";
import { Button } from "../ui/Button";
import { TelegramInfoBlock } from "../ui/telegram/TelegramInfoBlock";
import {
  TelegramStatusBadge,
} from "../ui/telegram/TelegramStatusBadge";
import { useT } from "../../hooks/useT";

export function AdminPage(
  props: React.PropsWithChildren<{
    title: string;
    subtitle?: string | null;
    backHref?: string;
    actions?: React.ReactNode;
    surfaceBadges?: Array<{
      label: string;
      tone:
        | "primary"
        | "connected"
        | "warning"
        | "neutral"
        | "inactive"
        | "active"
        | "vip";
    }>;
    infoBlock?: {
      title: string;
      description: string;
    } | null;
  }>,
) {
  const t = useT();
  const ctx = React.useContext(LayoutContext);

  if (typeof ctx.isAdmin === "boolean" && !ctx.isAdmin) {
    return (
      <div className="efhc-admin-shell grid gap-4">
        <div className="efhc-admin-header">
          <div className="min-w-0">
            <div className="efhc-admin-eyebrow">EFHC Admin</div>
            <h1 className="text-2xl font-bold leading-tight">
              {props.title}
            </h1>
            <p className="mt-2 text-sm efhc-text-muted">
              Доступ запрещён.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="efhc-admin-shell grid gap-4">
      <div className="efhc-admin-header">
        <div className="min-w-0">
          <div className="efhc-admin-eyebrow">{t("admin.title")}</div>
          <h1 className="text-2xl font-bold leading-tight">
            {props.title}
          </h1>
          {props.subtitle ? (
            <div className="mt-1 text-xs efhc-text-muted">
              {props.subtitle}
            </div>
          ) : null}
          {props.surfaceBadges?.length ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {props.surfaceBadges.map((item) => (
                <TelegramStatusBadge
                  key={`${props.title}-${item.label}`}
                  label={item.label}
                  tone={item.tone}
                />
              ))}
            </div>
          ) : null}
        </div>
        <div className="efhc-admin-actions">
          {props.actions}
          {props.backHref ? (
            <Button href={props.backHref} variant="secondary">
              {t("common.back")}
            </Button>
          ) : null}
        </div>
      </div>
      {props.infoBlock ? (
        <TelegramInfoBlock title={props.infoBlock.title}>
          {props.infoBlock.description}
        </TelegramInfoBlock>
      ) : null}
      {props.children}
    </div>
  );
}
