import React from "react";
import Link from "next/link";
import { Button } from "../ui/Button";

export function AdminPage(
  props: React.PropsWithChildren<{
    title: string;
    subtitle?: string | null;
    backHref?: string;
    actions?: React.ReactNode;
  }>,
) {
  return (
    <div className="grid gap-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold">{props.title}</h1>
          {props.subtitle ? (
            <div className="mt-1 text-xs efhc-text-muted">
              {props.subtitle}
            </div>
          ) : null}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {props.actions}
          {props.backHref ? (
            <Link href={props.backHref}>
              <Button variant="secondary">Back</Button>
            </Link>
          ) : null}
        </div>
      </div>
      {props.children}
    </div>
  );
}
