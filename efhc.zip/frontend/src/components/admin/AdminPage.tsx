import React from "react";
import Link from "next/link";
import { Button } from "../ui/Button";
import { useT } from "../../hooks/useT";

export function AdminPage(
  props: React.PropsWithChildren<{
    title: string;
    subtitle?: string | null;
    backHref?: string;
    actions?: React.ReactNode;
  }>,
) {
  const t = useT();
  return (
    <div className="efhc-admin-shell grid gap-4">
      <div className="efhc-admin-header">
        <div className="min-w-0">
          <div className="efhc-admin-eyebrow">{t("admin.title")}</div>
          <h1 className="text-2xl font-bold leading-tight">{props.title}</h1>
          {props.subtitle ? (
            <div className="mt-1 text-xs efhc-text-muted">
              {props.subtitle}
            </div>
          ) : null}
        </div>
        <div className="efhc-admin-actions">
          {props.actions}
          {props.backHref ? (
            <Link href={props.backHref}>
              <Button variant="secondary">{t("common.back")}</Button>
            </Link>
          ) : null}
        </div>
      </div>
      {props.children}
    </div>
  );
}
