import React, { useMemo, useState } from "react";

import { formatD8ToHuman, sumScaledDown } from "../../lib/format";
import {
  AdminActionTable,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

export const adminWithdrawalsDashboardRuntimeVersion =
  "EFHC_ADMIN_WITHDRAWALS_DASHBOARD_RUNTIME_V1";

type AdminWithdrawalDashboardStatus =
  | "PENDING"
  | "PAID"
  | "REJECTED"
  | "CANCELED"
  | string;

export type AdminWithdrawalsDashboardItem = {
  id: number;
  amount_efhc: string;
  status: AdminWithdrawalDashboardStatus;
  external_address: string | null;
  tx_hash: string | null;
  created_at: string;
  processed_at: string | null;
  error_message: string | null;
  is_vip: boolean;
  payout_asset?: string | null;
  tonconnect_transport_kind?: string | null;
};

export type AdminWithdrawalsDashboardRuntimeProps = {
  items: AdminWithdrawalsDashboardItem[];
  currentItems: AdminWithdrawalsDashboardItem[];
  selected?: AdminWithdrawalsDashboardItem | null;
  activeStatus: string;
  vipOnly: boolean;
  loading?: boolean;
  error?: string | null;
  updatedAt?: string;
  onRefresh: () => void;
};

type WithdrawalScope = "queue" | "final" | "attention" | "vip";

type WithdrawalPoint = {
  id: string;
  label: string;
  value: number;
  tone?: "success" | "warning" | "info" | "neutral" | "danger";
};

const DAY_MS = 24 * 60 * 60 * 1000;
const HOUR_MS = 60 * 60 * 1000;

function countStatus(
  items: AdminWithdrawalsDashboardItem[],
  status: string,
): number {
  return items.filter((item) => item.status === status).length;
}

function humanInt(value: number): string {
  return value.toLocaleString("ru-RU");
}

function sumAmount(items: AdminWithdrawalsDashboardItem[]): string {
  return items.reduce(
    (acc, item) => sumScaledDown(acc, String(item.amount_efhc || "0"), 8),
    "0",
  );
}

function parseTime(value: string | null | undefined): number | null {
  if (!value) return null;
  const ts = Date.parse(value);
  return Number.isFinite(ts) ? ts : null;
}

function ageHours(item: AdminWithdrawalsDashboardItem): number | null {
  const created = parseTime(item.created_at);
  if (created === null) return null;
  return Math.max(0, (Date.now() - created) / HOUR_MS);
}

function humanAge(item: AdminWithdrawalsDashboardItem): string {
  const hours = ageHours(item);
  if (hours === null) return "возраст неизвестен";
  if (hours < 1) return "меньше 1 часа";
  if (hours < 24) return `${Math.floor(hours)} ч`;
  return `${Math.floor(hours / 24)} д`;
}

function averageHandlingHours(
  items: AdminWithdrawalsDashboardItem[],
): number | null {
  const durations = items
    .map((item) => {
      const created = parseTime(item.created_at);
      const processed = parseTime(item.processed_at);
      if (created === null || processed === null) return null;
      if (processed < created) return null;
      return (processed - created) / HOUR_MS;
    })
    .filter((value): value is number => value !== null);
  if (!durations.length) return null;
  const total = durations.reduce((acc, value) => acc + value, 0);
  return total / durations.length;
}

function humanHandling(hours: number | null): string {
  if (hours === null) return "нет backend timestamps";
  if (hours < 1) return "< 1 ч";
  if (hours < 24) return `${Math.round(hours)} ч`;
  return `${Math.round(hours / 24)} д`;
}

function pct(part: number, total: number): number {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

function shortAddress(value: string | null): string {
  if (!value) return "адрес не задан";
  if (value.length <= 18) return value;
  return `${value.slice(0, 8)}…${value.slice(-8)}`;
}

function statusLabel(status: string): string {
  if (status === "PENDING") return "Ожидает";
  if (status === "PAID") return "Выплачено";
  if (status === "REJECTED") return "Отклонено";
  if (status === "CANCELED") return "Отменено";
  return status;
}

function statusTone(status: string) {
  if (status === "PAID") return "success" as const;
  if (status === "PENDING") return "warning" as const;
  if (status === "REJECTED" || status === "CANCELED") {
    return "neutral" as const;
  }
  return "danger" as const;
}

function scopeLabel(scope: WithdrawalScope): string {
  if (scope === "final") return "Финальные";
  if (scope === "attention") return "Внимание";
  if (scope === "vip") return "VIP";
  return "Очередь";
}

function buildStatusPoints(
  pending: number,
  paid: number,
  rejected: number,
  canceled: number,
  attention: number,
): WithdrawalPoint[] {
  return [
    { id: "pending", label: "pending", value: pending, tone: "warning" },
    { id: "paid", label: "paid", value: paid, tone: "success" },
    { id: "rejected", label: "rejected", value: rejected, tone: "neutral" },
    { id: "canceled", label: "canceled", value: canceled, tone: "neutral" },
    { id: "attention", label: "attention", value: attention, tone: "danger" },
  ];
}

function freshnessLabel(props: AdminWithdrawalsDashboardRuntimeProps): string {
  if (props.error) return "ошибка очереди выводов";
  if (props.loading) return "обновление";
  if (!props.items.length) return "queue snapshot empty";
  return "queue snapshot loaded";
}

export function AdminWithdrawalsDashboardRuntime(
  props: AdminWithdrawalsDashboardRuntimeProps,
) {
  const [scope, setScope] = useState<WithdrawalScope>("queue");
  const pending = countStatus(props.items, "PENDING");
  const paid = countStatus(props.items, "PAID");
  const rejected = countStatus(props.items, "REJECTED");
  const canceled = countStatus(props.items, "CANCELED");
  const finalTotal = paid + rejected + canceled;
  const attention = props.items.filter(
    (item) => Boolean(item.error_message) || item.status === "ERROR",
  ).length;
  const vip = props.items.filter((item) => item.is_vip).length;
  const queueTotal = props.items.length;
  const pendingAmount = formatD8ToHuman(
    sumAmount(props.items.filter((item) => item.status === "PENDING")),
  );
  const finalPercent = pct(finalTotal, queueTotal);
  const attentionPercent = pct(attention, queueTotal);
  const handling = averageHandlingHours(
    props.items.filter((item) => item.status !== "PENDING"),
  );
  const pendingUnder24 = props.items.filter((item) => {
    if (item.status !== "PENDING") return false;
    const created = parseTime(item.created_at);
    return created !== null && Date.now() - created < DAY_MS;
  }).length;
  const pending24to72 = props.items.filter((item) => {
    if (item.status !== "PENDING") return false;
    const created = parseTime(item.created_at);
    if (created === null) return false;
    const age = Date.now() - created;
    return age >= DAY_MS && age < DAY_MS * 3;
  }).length;
  const pendingOver72 = props.items.filter((item) => {
    if (item.status !== "PENDING") return false;
    const created = parseTime(item.created_at);
    return created !== null && Date.now() - created >= DAY_MS * 3;
  }).length;
  const selectedLabel = props.selected ? `#${props.selected.id}` : "нет";
  const statusPoints = useMemo(
    () => buildStatusPoints(pending, paid, rejected, canceled, attention),
    [pending, paid, rejected, canceled, attention],
  );
  const recentQueue = props.currentItems.slice(0, 8);
  const scopedItems = props.items.filter((item) => {
    if (scope === "final") return item.status !== "PENDING";
    if (scope === "attention") {
      return Boolean(item.error_message) || item.status === "ERROR";
    }
    if (scope === "vip") return item.is_vip;
    return item.status === "PENDING";
  });
  const freshness = props.error
    ? "stale"
    : props.loading
      ? "unknown"
      : props.items.length
        ? "fresh"
        : "stale";

  return (
    <section
      className="efhc-admin-withdrawals-dashboard-runtime"
      data-admin-withdrawals-dashboard-runtime="1486"
      data-admin-withdrawals-truth="raw-derived"
      data-admin-withdrawals-no-synthetic="true"
      data-admin-withdrawals-no-write-actions="true"
      data-admin-withdrawals-no-raw-payload="true"
      data-admin-withdrawals-no-debug-json="true"
      data-admin-withdrawals-no-secrets="true"
      data-admin-withdrawals-final-status-safe="true"
      data-admin-withdrawals-money-path="read-only"
    >
      <AdminDashboardToolbar
        title="Admin Withdrawals Dashboard"
        subtitle="Read-only очередь выводов; решения остаются в guarded controls."
        breadcrumb="Admin / Withdrawals"
        refresh={
          <AdminRefreshPicker
            disabled={props.loading}
            label="Refresh mode"
            onRefresh={props.onRefresh}
            refreshLabel="Обновить withdrawals"
            value="manual"
          />
        }
        updatedAt={props.updatedAt || "queue snapshot"}
        freshness={
          <AdminFreshnessBadge
            freshness={freshness}
            label={freshnessLabel(props)}
            updatedAt={props.updatedAt || "snapshot"}
          />
        }
        filters={
          <AdminFilterBar
            groups={[
              {
                key: "withdrawal-scope",
                label: "Срез",
                value: scope,
                queryKey: "withdrawal_scope",
                querySync: "safe_display_only",
                onChange: (value) => setScope(value as WithdrawalScope),
                options: [
                  { key: "queue", label: "Очередь" },
                  { key: "final", label: "Финальные" },
                  { key: "attention", label: "Внимание" },
                  { key: "vip", label: "VIP" },
                ],
              },
            ]}
            onReset={() => setScope("queue")}
            resetLabel="Сбросить"
          />
        }
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Pending queue"
          value={humanInt(pending)}
          meta={`${pendingAmount} EFHC`}
          hint="Заявки PENDING из read-only snapshots."
          tone={pending ? "warning" : "neutral"}
        />
        <AdminKpiCard
          label="Final statuses"
          value={humanInt(finalTotal)}
          meta={`${paid} paid · ${rejected} rejected · ${canceled} canceled`}
          hint="Финальные статусы не перезаписываются dashboard-слоем."
          tone={finalTotal ? "success" : "neutral"}
        />
        <AdminKpiCard
          label="Operator attention"
          value={humanInt(attention)}
          meta={`${attentionPercent}% queue`}
          hint="Сигнал из error_message/status, без fake incident history."
          tone={attention ? "danger" : "neutral"}
        />
        <AdminKpiCard
          label="Average handling"
          value={humanHandling(handling)}
          meta={handling === null ? "unknown" : "created → processed"}
          hint="Показывается только если есть реальные timestamps."
          tone={handling === null ? "neutral" : "info"}
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-withdrawals-dashboard-grid">
        <AdminPanelChrome
          title="Withdrawal status distribution"
          subtitle="Derived snapshot display; не real time-series."
          status={props.items.length ? "success" : "stale"}
          tone={attention ? "warning" : "success"}
          source="GET /admin/withdrawals?status=..."
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminMiniBarChart
            ariaLabel="EFHC withdrawals status distribution snapshot"
            dataKind="derived"
            points={statusPoints}
          />
          <div className="efhc-admin-withdrawals-dashboard-status-grid">
            {statusPoints.map((point) => (
              <div
                className="efhc-admin-withdrawals-dashboard-status"
                data-withdrawal-pipeline-status={point.id}
                key={point.id}
              >
                <span>{point.label}</span>
                <strong>{humanInt(point.value)}</strong>
              </div>
            ))}
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Queue age buckets"
          subtitle="Возраст pending-заявок вычисляется из created_at."
          status={pending ? "success" : "empty"}
          tone={pendingOver72 ? "danger" : pending24to72 ? "warning" : "info"}
          source="withdraw_requests.created_at"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminHeatStrip
            ariaLabel="EFHC withdrawals pending age buckets"
            dataKind="derived"
            points={[
              {
                id: "under-24h",
                label: "< 24h",
                value: pendingUnder24,
                tone: "success",
              },
              {
                id: "24-72h",
                label: "24–72h",
                value: pending24to72,
                tone: "warning",
              },
              {
                id: "over-72h",
                label: "> 72h",
                value: pendingOver72,
                tone: "danger",
              },
            ]}
          />
          <AdminProgressBar
            ariaLabel="Share of final withdrawal statuses"
            dataKind="derived"
            label="Доля финальных статусов"
            max={100}
            showValue
            source="derived from status counters"
            tone={finalPercent >= 70 ? "success" : "info"}
            value={finalPercent}
          />
        </AdminPanelChrome>
      </div>

      <div className="efhc-admin-withdrawals-dashboard-grid">
        <AdminPanelChrome
          title="Operator order"
          subtitle="Dashboard показывает порядок, но не выполняет решения."
          status="success"
          tone="info"
          source="withdrawals operator canon"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminFlowMapCard
            title="Безопасная дорожка вывода"
            nodes={[
              {
                label: "1. Очередь",
                value: `${pending} pending`,
                hint: props.vipOnly ? "VIP-filter active" : "all requests",
                active: pending > 0,
              },
              {
                label: "2. Проверка",
                value: selectedLabel,
                hint: "case review + outcome preview",
                active: Boolean(props.selected),
              },
              {
                label: "3. Решение",
                value: "guarded controls",
                hint: "approve/reject/pay остаются ниже",
                active: Boolean(props.selected),
              },
              {
                label: "4. Финал",
                value: `${finalTotal} final`,
                hint: "paid/rejected/canceled",
                active: finalTotal > 0,
              },
            ]}
          />
          <p className="efhc-admin-withdrawals-dashboard-boundary">
            Панель не создаёт новый action path. Выплата, одобрение, отклонение
            и consistency repair остаются в существующих подтверждаемых
            контролах страницы.
          </p>
        </AdminPanelChrome>

        <AdminPanelChrome
          title={`Scoped snapshot: ${scopeLabel(scope)}`}
          subtitle="Display-only срез без URL/business truth sync."
          status={scopedItems.length ? "success" : "empty"}
          tone={
            scope === "attention" && scopedItems.length ? "danger" : "neutral"
          }
          source="client-side derived snapshot"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminActionTable
            title="Сводка выбранного среза"
            rows={[
              {
                label: "Заявок",
                value: humanInt(scopedItems.length),
                hint: "только отображение",
              },
              {
                label: "Сумма",
                value: `${formatD8ToHuman(sumAmount(scopedItems))} EFHC`,
                hint: "derived from amount_efhc",
              },
              {
                label: "VIP",
                value: humanInt(vip),
                hint: "операторская приоритизация",
              },
              {
                label: "Текущий фильтр страницы",
                value: props.activeStatus || "—",
                hint: props.vipOnly ? "VIP only" : "all users",
              },
            ]}
          />
        </AdminPanelChrome>
      </div>

      <AdminPanelChrome
        title="Recent queue snapshot"
        subtitle="Короткая таблица без технических dumps и secrets."
        status={recentQueue.length ? "success" : "empty"}
        tone="neutral"
        source="GET /admin/withdrawals current filter"
        updatedAt={props.updatedAt || "snapshot"}
      >
        {props.error ? (
          <div className="efhc-admin-withdrawals-dashboard-empty">
            Ошибка чтения очереди: {props.error}
          </div>
        ) : recentQueue.length ? (
          <div className="efhc-admin-withdrawals-dashboard-table">
            {recentQueue.map((item) => (
              <div
                className="efhc-admin-withdrawals-dashboard-row"
                key={item.id}
                data-withdrawal-status={item.status}
              >
                <span>#{item.id}</span>
                <strong>{formatD8ToHuman(item.amount_efhc)} EFHC</strong>
                <AdminStatusBadge
                  label={statusLabel(item.status)}
                  tone={statusTone(item.status)}
                />
                <small>{humanAge(item)}</small>
                <small>{shortAddress(item.external_address)}</small>
              </div>
            ))}
          </div>
        ) : (
          <div className="efhc-admin-withdrawals-dashboard-empty">
            В выбранном фильтре нет заявок.
          </div>
        )}
      </AdminPanelChrome>
    </section>
  );
}
