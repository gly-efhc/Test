import React, { useCallback, useEffect, useMemo, useState } from "react";

import {
  ADMIN_OBSERVABILITY_SUMMARY_PATH,
  ADMIN_OBSERVABILITY_TIMESERIES_PATH,
  type AdminObservabilitySummaryResponse,
  type AdminObservabilityTimeseriesResponse,
} from "../../lib/api/generated/adminSeams";
import {
  AdminAreaChart,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFreshnessBadge,
  AdminKpiCard,
  AdminPanelChrome,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";
import { adminSafeLoadError } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

const METRIC_OPTIONS = [
  {
    key: "efhc_transfer_count",
    label: "EFHC события",
    description: "Количество ledger events",
  },
  {
    key: "efhc_transfer_amount",
    label: "EFHC оборот",
    description: "Gross turnover: credit + debit",
  },
  {
    key: "efhc_credit_amount",
    label: "EFHC зачисления",
    description: "Только направление зачисления",
  },
  {
    key: "efhc_debit_amount",
    label: "EFHC списания",
    description: "Только направление списания",
  },
  {
    key: "users_created",
    label: "Новые пользователи",
    description: "users.created_at",
  },
  {
    key: "panels_created",
    label: "Новые панели",
    description: "panels.created_at",
  },
  {
    key: "withdrawals_created",
    label: "Созданные выводы",
    description: "withdraw_requests.created_at",
  },
  {
    key: "payment_intents_created",
    label: "Платёжные намерения",
    description: "payment_intents.created_at",
  },
] as const;

const RANGE_OPTIONS = [
  { key: "24", label: "24 часа" },
  { key: "168", label: "7 дней" },
  { key: "720", label: "30 дней" },
] as const;

const BUCKET_OPTIONS = [
  { key: "hour", label: "час" },
  { key: "day", label: "день" },
] as const;

type MetricKey = typeof METRIC_OPTIONS[number]["key"];
type BucketKey = typeof BUCKET_OPTIONS[number]["key"];
type SnapshotState = {
  summary: AdminObservabilitySummaryResponse | null;
  series: AdminObservabilityTimeseriesResponse | null;
  loading: boolean;
  error: string | null;
  updatedAt: string | null;
};

function parseValue(value: string): number {
  const parsed = Number(String(value || "0").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function valueLabel(value: string | undefined): string {
  if (!value) return "0";
  return value;
}

function metricLabel(metric: string): string {
  return METRIC_OPTIONS.find((item) => item.key === metric)?.label ?? metric;
}

function queryPath(metric: MetricKey, bucket: BucketKey, rangeHours: string) {
  const params = new URLSearchParams({
    metric,
    bucket,
    range_hours: rangeHours,
  });
  return `${ADMIN_OBSERVABILITY_TIMESERIES_PATH}?${params.toString()}`;
}

function summaryValue(
  summary: AdminObservabilitySummaryResponse | null,
  key: string,
): string {
  return summary?.metrics.find((item) => item.key === key)?.value ?? "—";
}

export function AdminObservabilityTimeseriesDashboardRuntime() {
  const adminApiRequest = useAdminLinkedTransport();
  const [metric, setMetric] = useState<MetricKey>("efhc_transfer_count");
  const [bucket, setBucket] = useState<BucketKey>("hour");
  const [rangeHours, setRangeHours] = useState("24");
  const [snapshot, setSnapshot] = useState<SnapshotState>({
    summary: null,
    series: null,
    loading: false,
    error: null,
    updatedAt: null,
  });

  const refresh = useCallback(() => {
    setSnapshot((current) => ({ ...current, loading: true, error: null }));
    void Promise.all([
      adminApiRequest<AdminObservabilitySummaryResponse>(
        ADMIN_OBSERVABILITY_SUMMARY_PATH,
        "GET",
      ),
      adminApiRequest<AdminObservabilityTimeseriesResponse>(
        queryPath(metric, bucket, rangeHours),
        "GET",
      ),
    ])
      .then(([summary, series]) => {
        setSnapshot({
          summary,
          series,
          loading: false,
          error: null,
          updatedAt: new Date().toISOString(),
        });
      })
      .catch((error: unknown) => {
        const message = adminSafeLoadError(error);
        setSnapshot((current) => ({
          ...current,
          loading: false,
          error: message,
          updatedAt: new Date().toISOString(),
        }));
      });
  }, [adminApiRequest, bucket, metric, rangeHours]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const points = useMemo(() => {
    const rawPoints = Array.isArray(snapshot.series?.points)
      ? snapshot.series.points
      : [];
    return rawPoints.map((point) => ({
      id: point.ts,
      label: point.label ?? point.ts,
      value: parseValue(point.value),
    }));
  }, [snapshot.series]);

  const freshness = snapshot.error
    ? "stale"
    : snapshot.loading
      ? "unknown"
      : "fresh";
  const status = snapshot.error
    ? "error"
    : snapshot.loading
      ? "loading"
      : points.length
        ? "success"
        : "empty";

  return (
    <section
      className="efhc-admin-observability-timeseries efhc-dashboard-surface"
      data-admin-observability-timeseries-dashboard="1492"
      data-admin-observability-truth="real_timeseries"
      data-admin-observability-synthetic="false"
      data-admin-observability-no-fake-series="true"
      data-admin-observability-no-write-actions="true"
      data-admin-observability-no-idempotency-key="true"
    >
      <AdminDashboardToolbar
        title="Real Time-Series Dashboard"
        subtitle="Настоящие read-only series из /admin/observability/timeseries. Synthetic runtime data запрещены."
        breadcrumb="Admin / Overview / Observability"
        refresh={(
          <AdminRefreshPicker
            label="Observability refresh"
            onRefresh={refresh}
            refreshLabel="Обновить real series"
          />
        )}
        freshness={(
          <AdminFreshnessBadge
            freshness={freshness}
            label={snapshot.error ? "ошибка" : "real_timeseries"}
          />
        )}
        updatedAt={
          snapshot.updatedAt
            ? `Обновлено: ${snapshot.updatedAt}`
            : "ожидается первая загрузка"
        }
      />

      <AdminFilterBar
        groups={[
          {
            label: "Метрика",
            value: metric,
            options: [...METRIC_OPTIONS],
            onChange: (value) => setMetric(value as MetricKey),
            querySync: "disabled",
          },
          {
            label: "Шаг",
            value: bucket,
            options: [...BUCKET_OPTIONS],
            onChange: (value) => setBucket(value as BucketKey),
            querySync: "disabled",
          },
          {
            label: "Период",
            value: rangeHours,
            options: [...RANGE_OPTIONS],
            onChange: setRangeHours,
            querySync: "disabled",
          },
        ]}
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Ledger events"
          value={summaryValue(snapshot.summary, "efhc_transfer_events_total")}
          meta="исходная сводка"
          hint="количество записей efhc_transfers_log"
          tone="info"
        />
        <AdminKpiCard
          label="EFHC gross turnover"
          value={summaryValue(snapshot.summary, "efhc_transfer_amount_total")}
          meta="credit + debit"
          hint="Это оборот, не чистый баланс."
          tone="warning"
        />
        <AdminKpiCard
          label="Series points"
          value={String(points.length)}
          meta={snapshot.series?.unit ?? "unit pending"}
          hint={snapshot.series?.empty_reason ?? snapshot.series?.source ?? "source pending"}
          tone={points.length ? "success" : "neutral"}
        />
        <AdminKpiCard
          label="Data kind"
          value={snapshot.series?.data_kind ?? "—"}
          meta={snapshot.series?.synthetic === false ? "synthetic=false" : "pending"}
          hint="Runtime chart строится только из backend real_timeseries."
          tone="success"
        />
      </AdminDashboardGrid>

      <AdminPanelChrome
        title={`${metricLabel(metric)} · ${bucket}`}
        subtitle="Grafana-like TimeSeries pattern, но EFHC-owned и только от backend truth."
        status={status}
        source={snapshot.series?.source ?? "GET /admin/observability/timeseries"}
      >
        <AdminAreaChart
          ariaLabel="Real observability time-series"
          dataKind="real_timeseries"
          emptyLabel={snapshot.series?.empty_reason ?? "Нет точек в диапазоне"}
          points={points}
          source={snapshot.series?.source ?? "real_timeseries pending"}
          synthetic={false}
          tone="info"
          unit={snapshot.series?.unit ?? "unit"}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <AdminStatusBadge label="real_timeseries" tone="success" />
          <AdminStatusBadge label="synthetic=false" tone="success" />
          <AdminStatusBadge label="GET only" tone="info" />
          <AdminStatusBadge label="no fake trend" tone="warning" />
        </div>
      </AdminPanelChrome>

      <AdminPanelChrome
        title="Truth hardening boundary"
        subtitle="Старый banking simulator chart удалён с runtime /admin: он строил правдоподобную series из одного snapshot."
        status="success"
        source="cycle 1492 synthetic cleanup"
      >
        <p className="text-sm text-slate-200">
          На этой поверхности нет synthetic runtime series, нет demo/mock rows,
          нет write-actions и нет создания idempotency key. Метрика
          <strong> EFHC gross turnover </strong>
          явно подписана как оборот credit + debit; credit/debit доступны
          отдельными метриками.
        </p>
      </AdminPanelChrome>

      {snapshot.error ? (
        <AdminPanelChrome
          title="Observability load attention"
          subtitle="Ошибка real_timeseries не маскируется synthetic fallback."
          status="error"
          tone="danger"
          source="frontend request state"
        >
          <p className="text-sm text-red-200">{snapshot.error}</p>
        </AdminPanelChrome>
      ) : null}
    </section>
  );
}
