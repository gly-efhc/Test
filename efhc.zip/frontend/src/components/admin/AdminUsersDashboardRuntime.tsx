import React, { useCallback, useMemo, useState } from "react";

import { useLargeAdminFilter } from "../../hooks/admin/useLargeAdminFilter";
import { formatD8ToHuman, sumScaledDown } from "../../lib/format";
import {
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

export const adminUsersDashboardRuntimeVersion =
  "EFHC_ADMIN_USERS_DASHBOARD_RUNTIME_V1";

type UserDashboardItem = {
  username?: string | null;
  is_active: boolean;
  is_vip: boolean;
  ton_wallet?: string | null;
  main_balance: string;
  bonus_balance: string;
  available_kwh: string;
  total_generated_kwh: string;
  last_seen_at?: string | null;
};

type UserSegment = "all" | "active" | "inactive" | "vip" | "wallets";

type ChartPointTone = "success" | "warning" | "info" | "neutral" | "danger";

type UserChartPoint = {
  id: string;
  label: string;
  value: number;
  tone?: ChartPointTone;
};

export type AdminUsersDashboardRuntimeProps = {
  users: UserDashboardItem[];
  selected?: UserDashboardItem | null;
  query: string;
  loading?: boolean;
  error?: string;
  updatedAt?: string;
  onRefresh: () => void;
};

function toNumber(value: string | number | undefined | null): number {
  if (value === null || value === undefined) return 0;
  const parsed = Number(String(value).replace(/,/g, "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function totalD8(
  users: UserDashboardItem[],
  key: keyof Pick<
    UserDashboardItem,
    "main_balance" | "bonus_balance" | "available_kwh" | "total_generated_kwh"
  >,
): string {
  return users.reduce(
    (acc, user) => sumScaledDown(acc, String(user[key] || "0"), 8),
    "0",
  );
}

function userDisplayName(user?: UserDashboardItem | null): string {
  if (!user) return "не выбран";
  const username = String(user.username || "").trim();
  return username ? `@${username}` : "пользователь без username";
}

function freshnessLabel(props: AdminUsersDashboardRuntimeProps): string {
  if (props.error) return "ошибка среза";
  if (props.loading) return "обновление списка";
  if (!props.users.length) return "пустой срез";
  return "срез загружен";
}

function segmentLabel(segment: UserSegment): string {
  if (segment === "active") return "Активные";
  if (segment === "inactive") return "Неактивные";
  if (segment === "vip") return "VIP";
  if (segment === "wallets") return "TON wallets";
  return "Все";
}


function buildStatusPoints(
  activeCount: number,
  inactiveCount: number,
  vipCount: number,
  walletCount: number,
): UserChartPoint[] {
  return [
    {
      id: "active",
      label: "Активные",
      value: activeCount,
      tone: "success",
    },
    {
      id: "inactive",
      label: "Неактивные",
      value: inactiveCount,
      tone: "warning",
    },
    {
      id: "vip",
      label: "VIP",
      value: vipCount,
      tone: "info",
    },
    {
      id: "wallets",
      label: "TON wallets",
      value: walletCount,
      tone: "neutral",
    },
  ];
}

export function AdminUsersDashboardRuntime(
  props: AdminUsersDashboardRuntimeProps,
) {
  const [segment, setSegment] = useState<UserSegment>("all");
  const users = props.users;
  const syncUserFilter = useCallback(
    (user: UserDashboardItem) => {
      if (segment === "active") return user.is_active;
      if (segment === "inactive") return !user.is_active;
      if (segment === "vip") return user.is_vip;
      if (segment === "wallets") return Boolean(user.ton_wallet);
      return true;
    },
    [segment],
  );
  const largeFilter = useLargeAdminFilter(
    users,
    "users",
    { segment },
    syncUserFilter,
  );
  const filteredUsers = largeFilter.filtered;
  const activeCount = users.filter((user) => user.is_active).length;
  const inactiveCount = Math.max(0, users.length - activeCount);
  const vipCount = users.filter((user) => user.is_vip).length;
  const walletCount = users.filter((user) => user.ton_wallet).length;
  const usersMainTotal = totalD8(users, "main_balance");
  const usersBonusTotal = totalD8(users, "bonus_balance");
  const usersTotalBalance = sumScaledDown(usersMainTotal, usersBonusTotal, 8);
  const generatedKwh = totalD8(users, "total_generated_kwh");
  const availableKwh = totalD8(users, "available_kwh");
  const selectedBalance = props.selected
    ? sumScaledDown(props.selected.main_balance, props.selected.bonus_balance, 8)
    : "0";
  const activePercent = users.length
    ? Math.round((activeCount / users.length) * 100)
    : 0;
  const walletPercent = users.length
    ? Math.round((walletCount / users.length) * 100)
    : 0;
  const statusPoints = buildStatusPoints(
    activeCount,
    inactiveCount,
    vipCount,
    walletCount,
  );
  const freshness = props.error
    ? "stale"
    : props.loading
      ? "unknown"
      : users.length
        ? "fresh"
        : "stale";

  return (
    <section
      className="efhc-admin-users-dashboard-runtime"
      data-admin-users-dashboard-runtime="1484"
      data-admin-users-truth="raw-derived"
      data-admin-users-no-synthetic="true"
      data-admin-users-no-write-actions="true"
      data-admin-users-no-raw-payload="true"
      data-admin-users-no-debug-json="true"
      data-admin-users-no-secrets="true"
      data-admin-users-no-raw-tg-id="true"
      data-admin-worker-filter={largeFilter.workerActive ? "active" : "idle"}
    >
      <AdminDashboardToolbar
        title="Admin Users Dashboard"
        subtitle="Read-only срез пользователей, балансов, статусов и operator drill-down."
        breadcrumb="Admin / Users"
        refresh={(
          <AdminRefreshPicker
            label="Refresh mode"
            onRefresh={props.onRefresh}
            refreshLabel="Обновить users"
            value="manual"
          />
        )}
        updatedAt={props.updatedAt || "current search snapshot"}
        freshness={(
          <AdminFreshnessBadge
            freshness={freshness}
            label={freshnessLabel(props)}
            updatedAt={props.updatedAt || "snapshot"}
          />
        )}
        filters={(
          <AdminFilterBar
            groups={[
              {
                key: "users-segment",
                label: "Сегмент",
                value: segment,
                queryKey: "users_segment",
                querySync: "safe_display_only",
                options: [
                  { key: "all", label: "Все" },
                  { key: "active", label: "Активные" },
                  { key: "inactive", label: "Неактивные" },
                  { key: "vip", label: "VIP" },
                  { key: "wallets", label: "TON wallets" },
                ],
                onChange: (value) => setSegment(value as UserSegment),
              },
            ]}
            onReset={() => setSegment("all")}
            resetLabel="Сбросить"
          />
        )}
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Пользователи"
          value={String(users.length)}
          meta={`сегмент: ${segmentLabel(segment)}`}
          hint="Текущий read-only результат поиска."
          tone="neutral"
        />
        <AdminKpiCard
          label="Активные"
          value={String(activeCount)}
          meta={`${activePercent}%`}
          hint="Derived from current user search snapshot."
          tone="success"
        />
        <AdminKpiCard
          label="VIP"
          value={String(vipCount)}
          meta="статус пользователя"
          hint="Отображение статуса без изменения VIP flow."
          tone="info"
        />
        <AdminKpiCard
          label="TON wallets"
          value={String(walletCount)}
          meta={`${walletPercent}%`}
          hint="Привязки кошельков без раскрытия full payload."
          tone="warning"
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-users-dashboard-grid">
        <AdminPanelChrome
          title="User segment distribution"
          subtitle="Derived snapshot display; это не real time-series."
          status={props.error ? "error" : users.length ? "success" : "empty"}
          tone="info"
          source="GET /admin/users/search"
          updatedAt={props.updatedAt || "current search snapshot"}
        >
          <AdminMiniBarChart
            ariaLabel="Распределение пользователей по статусам"
            dataKind="derived"
            points={statusPoints}
            source="derived from current users snapshot"
            unit="users"
          />
          <div className="efhc-admin-users-dashboard-status-grid">
            {statusPoints.map((point) => (
              <span key={point.id}>
                <b>{point.label}</b>
                <strong>{point.value.toLocaleString("ru-RU")}</strong>
              </span>
            ))}
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Balances snapshot"
          subtitle="Main, bonus, kWh и selected-user summary без money action."
          status={users.length ? "success" : "stale"}
          tone="success"
          source="search snapshot + selected detail"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <div className="efhc-admin-users-dashboard-balance-grid">
            <span>
              <b>Main total</b>
              <strong>{formatD8ToHuman(usersMainTotal)}</strong>
            </span>
            <span>
              <b>Bonus total</b>
              <strong>{formatD8ToHuman(usersBonusTotal)}</strong>
            </span>
            <span>
              <b>Total EFHC</b>
              <strong>{formatD8ToHuman(usersTotalBalance)}</strong>
            </span>
            <span>
              <b>Available kWh</b>
              <strong>{formatD8ToHuman(availableKwh)}</strong>
            </span>
            <span>
              <b>Generated kWh</b>
              <strong>{formatD8ToHuman(generatedKwh)}</strong>
            </span>
            <span>
              <b>Selected balance</b>
              <strong>{formatD8ToHuman(selectedBalance)}</strong>
            </span>
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Activity readiness"
          subtitle="Readiness markers for selected users; no fake retention analytics."
          status={users.length ? "success" : "stale"}
          tone="warning"
          source="derived display"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminProgressBar
            label="Active ratio"
            value={activePercent}
            max={100}
            dataKind="derived"
            source="active / total users in current snapshot"
          />
          <AdminProgressBar
            label="Wallet binding ratio"
            value={walletPercent}
            max={100}
            dataKind="derived"
            source="wallets / total users in current snapshot"
          />
          <AdminHeatStrip
            ariaLabel="Users dashboard state strip"
            dataKind="derived"
            points={[
              { id: "search", label: "search", value: users.length, tone: "info" },
              { id: "active", label: "active", value: activeCount, tone: "success" },
              { id: "inactive", label: "inactive", value: inactiveCount, tone: "warning" },
              { id: "selected", label: "selected", value: props.selected ? 1 : 0, tone: "neutral" },
            ]}
            source="derived users snapshot"
          />
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Operator drill-down"
          subtitle="Quick links and selected user boundary without raw payload."
          status="success"
          tone="neutral"
          source="admin users UI"
        >
          <AdminFlowMapCard
            title="User operations map"
            nodes={[
              {
                label: "Search",
                value: String(filteredUsers.length),
                hint: "display-only segment",
              },
              {
                label: "Selected",
                value: userDisplayName(props.selected),
                hint: "username-only dashboard label",
              },
              {
                label: "Bank",
                value: "canonical transfer",
                hint: "money actions stay below guarded form",
              },
              {
                label: "Logs",
                value: "safe drill-down",
                hint: "no raw payload in dashboard",
              },
            ]}
          />
          <div className="efhc-admin-users-dashboard-boundary">
            <AdminStatusBadge label="read-only dashboard" tone="success" />
            <AdminStatusBadge label="no raw payload" tone="warning" />
            <AdminStatusBadge label="no debug JSON" tone="warning" />
            <AdminStatusBadge label="no dashboard write actions" tone="success" />
            <AdminStatusBadge label="TG identifiers stay outside dashboard" tone="neutral" />
          </div>
        </AdminPanelChrome>
      </div>
    </section>
  );
}
