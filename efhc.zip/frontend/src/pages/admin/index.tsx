import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { useT } from "../../hooks/useT";

type Overview = {
  ok: boolean;
  ts: string;
  counters: Record<string, number>;
  notes?: string | null;
};

export default function AdminHome() {
  const t = useT();
  const [ov, setOv] = useState<Overview | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const hasToken = (() => {
    try {
      return Boolean(localStorage.getItem("EFHC_ADMIN_TOKEN"));
    } catch {
      return false;
    }
  })();

  const load = async () => {
    setMsg(null);
    try {
      const r = await apiRequest<Overview>(
        `/admin/reports/overview`,
        "GET",
      );
      setOv(r);
    } catch (e: any) {
      setOv(null);
      setMsg(String(e?.message || e));
    }
  };

  useEffect(() => { load(); }, []);

  const setAdminCreds = () => {
    const id = prompt(
      t("admin.admin_id_prompt"),
      localStorage.getItem("EFHC_ADMIN_ID") || "",
    );
    if (id !== null) localStorage.setItem("EFHC_ADMIN_ID", id);
    const tok = prompt(
      t("admin.admin_token_prompt"),
      localStorage.getItem("EFHC_ADMIN_TOKEN") || "",
    );
    if (tok !== null) localStorage.setItem("EFHC_ADMIN_TOKEN", tok);
    location.reload();
  };

  const reconcile = async () => {
    setMsg(null);
    try {
      const hoursStr = prompt(t("admin.reconcile_hours_prompt"), "6");
      if (!hoursStr) return;
      const last_hours = Math.max(1, Math.min(168, Number(hoursStr)));
      const idk = newIdempotencyKey();
      const r = await apiRequest<any>(`/admin/ton/reconcile`, "POST", {
        idempotencyKey: idk,
        body: { last_hours, limit: 1000 },
      });
      setMsg(JSON.stringify(r, null, 2));
      await load();
    } catch (e: any) {
      setMsg(String(e?.message || e));
    }
  };

  return (
    <div className="grid gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("admin.title")}</h1>
          <div className="text-xs text-gray-500">
            {t("admin.auth_note")}
          </div>
        </div>
        <Button className="bg-white text-black" onClick={setAdminCreds}>
          {hasToken ? t("admin.update_creds") : t("admin.set_creds")}
        </Button>
      </div>

      {msg ? (
        <Card title={t("common.status")}>
          <pre className="text-xs whitespace-pre-wrap">{msg}</pre>
        </Card>
      ) : null}

      <Card title={t("admin.overview")}>
        {ov ? (
          <div className="grid gap-2">
            <div className="text-xs text-gray-500">
              {t("admin.ts")}: {ov.ts}
            </div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(ov.counters || {}).map(([k, v]) => (
                <Badge key={k}>{k}: {v}</Badge>
              ))}
            </div>
            {ov.notes ? (
              <div className="text-xs text-gray-600">{ov.notes}</div>
            ) : null}
          </div>
        ) : (
          <div className="text-sm text-gray-600">
            {t("admin.no_overview")}
          </div>
        )}
        <div className="mt-3 flex gap-2">
          <Button onClick={load}>{t("common.refresh")}</Button>
          <Button
            className="bg-white text-black"
            onClick={reconcile}
          >
            {t("admin.reconcile")}
          </Button>
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card title={t("admin.modules")}>
          <div className="grid gap-2 text-sm">
            <Link className="underline" href="/admin/bank">
              {t("admin.bank")}
            </Link>
            <Link className="underline" href="/admin/shop">
              {t("admin.shop")}
            </Link>
            <Link className="underline" href="/admin/tasks">
              {t("admin.tasks")}
            </Link>
            <Link className="underline" href="/admin/referrals">
              {t("admin.referrals")}
            </Link>
            <Link className="underline" href="/admin/panels">
              {t("admin.panels")}
            </Link>
            <Link className="underline" href="/admin/users">
              {t("admin.users")}
            </Link>
            <Link className="underline" href="/admin/withdrawals">
              {t("admin.withdrawals")}
            </Link>
            <Link className="underline" href="/admin/logs">
              {t("admin.logs")}
            </Link>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            {t("admin.modules_note")}
          </div>
        </Card>

        <Card title={t("admin.transfer")}>
          <div className="text-sm text-gray-700">
            {t("admin.transfer_hint")}
          </div>
          <Link href="/admin/users">
            <Button className="mt-3">
              {t("admin.open_transfer")}
            </Button>
          </Link>
        </Card>
      </div>
    </div>
  );
}
