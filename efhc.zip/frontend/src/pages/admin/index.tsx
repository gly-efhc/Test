import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { useT } from "../../hooks/useT";

type Overview = {
  ok: boolean;
  ts: string;
  counters: Record<string, number>;
  notes?: string | null;
};

export default function AdminHome() {
  const t = useT();
  const [ov, setOv] = useState<Overview | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [credsOpen, setCredsOpen] = useState(false);
  const [reconcileOpen, setReconcileOpen] = useState(false);
  const [creds, setCreds] = useState<Record<string, string>>({
    admin_id: "",
    admin_token: "",
  });
  const [reconcile, setReconcile] = useState<Record<string, string>>({
    last_hours: "6",
  });

  const hasToken = (() => {
    try {
      return Boolean(localStorage.getItem("EFHC_ADMIN_TOKEN"));
    } catch {
      return false;
    }
  })();

  const load = async () => {
    setMsg(null);
    try {
      const r = await apiRequest<Overview>("/admin/reports/overview", "GET");
      setOv(r);
    } catch (e: any) {
      setOv(null);
      setMsg(String(e?.message || e));
    }
  };

  useEffect(() => {
    try {
      setCreds({
        admin_id: localStorage.getItem("EFHC_ADMIN_ID") || "",
        admin_token: localStorage.getItem("EFHC_ADMIN_TOKEN") || "",
      });
    } catch {
      // no-op
    }
    void load();
  }, []);

  function saveCreds() {
    try {
      localStorage.setItem("EFHC_ADMIN_ID", creds.admin_id || "");
      localStorage.setItem("EFHC_ADMIN_TOKEN", creds.admin_token || "");
    } catch {
      // no-op
    }
    setCredsOpen(false);
    location.reload();
  }

  async function runReconcile() {
    setMsg(null);
    try {
      const last_hours = Math.max(
        1,
        Math.min(168, Number(reconcile.last_hours || "6")),
      );
      const idk = newIdempotencyKey();
      const r = await apiRequest<any>("/admin/ton/reconcile", "POST", {
        idempotencyKey: idk,
        body: { last_hours, limit: 1000 },
      });
      setMsg(JSON.stringify(r, null, 2));
      setReconcileOpen(false);
      await load();
    } catch (e: any) {
      setMsg(String(e?.message || e));
    }
  }

  return (
    <AdminPage
      title={t("admin.title")}
      subtitle={t("admin.auth_note")}
      actions={
        <>
          <Button variant="secondary" onClick={() => setReconcileOpen(true)}>
            {t("admin.reconcile")}
          </Button>
          <Button onClick={() => setCredsOpen(true)}>
            {hasToken ? t("admin.update_creds") : t("admin.set_creds")}
          </Button>
        </>
      }
    >
      {msg ? (
        <Card title={t("common.status")}>
          <pre className="efhc-admin-pre">{msg}</pre>
        </Card>
      ) : null}

      <Card title={t("admin.overview")}>
        {ov ? (
          <div className="grid gap-2">
            <div className="text-xs efhc-text-muted">
              {t("admin.ts")}: {ov.ts}
            </div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(ov.counters || {}).map(([k, v]) => (
                <Badge key={k}>{k}: {v}</Badge>
              ))}
            </div>
            {ov.notes ? (
              <div className="text-xs efhc-text-muted">{ov.notes}</div>
            ) : null}
          </div>
        ) : (
          <div className="text-sm efhc-text-muted">{t("admin.no_overview")}</div>
        )}
        <div className="mt-3 flex gap-2">
          <Button onClick={load}>{t("common.refresh")}</Button>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card title={t("admin.modules")}>
          <div className="grid gap-2 text-sm">
            {[
              ["/admin/bank", t("admin.bank")],
              ["/admin/shop", t("admin.shop")],
              ["/admin/tasks", t("admin.tasks")],
              ["/admin/referrals", t("admin.referrals")],
              ["/admin/panels", t("admin.panels")],
              ["/admin/users", t("admin.users")],
              ["/admin/withdrawals", t("admin.withdrawals")],
              ["/admin/logs", t("admin.logs")],
              ["/admin/reports", t("admin.reports")],
              ["/admin/ads", t("admin.ads")],
            ].map(([href, label]) => (
              <Link key={href} className="efhc-admin-link" href={href}>
                {label}
              </Link>
            ))}
          </div>
          <div className="mt-2 text-xs efhc-text-muted">
            {t("admin.modules_note")}
          </div>
        </Card>

        <Card title={t("admin.transfer")}>
          <div className="text-sm efhc-text-muted">{t("admin.transfer_hint")}</div>
          <Link href="/admin/users">
            <Button className="mt-3">{t("admin.open_transfer")}</Button>
          </Link>
        </Card>
      </div>

      <AdminPromptModal
        open={credsOpen}
        title={hasToken ? t("admin.update_creds") : t("admin.set_creds")}
        submitLabel="Save"
        fields={[
          {
            key: "admin_id",
            label: t("admin.admin_id_prompt"),
            placeholder: "Telegram ID",
          },
          {
            key: "admin_token",
            label: t("admin.admin_token_prompt"),
            placeholder: "Admin token",
          },
        ]}
        values={creds}
        onChange={(key, value) => {
          setCreds((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setCredsOpen(false)}
        onSubmit={saveCreds}
      />

      <AdminPromptModal
        open={reconcileOpen}
        title={t("admin.reconcile")}
        submitLabel={t("admin.reconcile")}
        fields={[
          {
            key: "last_hours",
            label: t("admin.reconcile_hours_prompt"),
            placeholder: "6",
            type: "number",
          },
        ]}
        values={reconcile}
        onChange={(key, value) => {
          setReconcile((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setReconcileOpen(false)}
        onSubmit={() => {
          void runReconcile();
        }}
      />
    </AdminPage>
  );
}
