import React, { useCallback, useEffect, useState } from "react";

import { AdminAppButtonGrid } from "../../components/admin/AdminAppButtonGrid";
import { AdminHeroPanel } from "../../components/admin/AdminHeroPanel";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminSectionCard } from "../../components/admin/AdminSectionCard";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { AdminCharts } from "../../components/AdminCharts";
import { AdminTable } from "../../components/AdminTable";
import { Button } from "../../components/ui/Button";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import { useT } from "../../hooks/useT";
import { adminUiErrorMessage } from "../../lib/adminError";
import {
  ADMIN_REPORTS_OVERVIEW_PATH,
  ADMIN_TON_RECONCILE_PATH,
} from "../../lib/api/generated/adminSeams";
import { newIdempotencyKey } from "../../lib/idempotency";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type Overview = {
  ok: boolean;
  ts: string;
  facts?: Record<string, string>;
  notes?: string | null;
};

type AdminModule = {
  href: string;
  label: string;
  note: string;
  state: "live" | "helper" | "draft" | "deferred";
  releaseTier: "core" | "non_core" | "deferred";
};

const RELEASE_VERSION = "v172.87";

const FACT_LABELS: Record<string, string> = {
  panels_total_bought: "Панелей активировано всего",
  panels_total_active: "Активных панелей",
  panels_total_archived: "Архивных панелей",
  panels_total_paid_efhc: "EFHC списано на панели",
  panels_total_paid__main__efhc: "EFHC main списано на панели",
  panels_total_paid_bonus_efhc: "EFHC bonus списано на панели",
  users_total_generated_kwh: "kWh сгенерировано всего",
  users_total_exchanged_kwh: "kWh обменяно в EFHC main",
  users_total__main__efhc: "EFHC main на балансах",
  users_total_bonus_efhc: "EFHC bonus на балансах",
};

const FACT_ORDER = [
  "users_total__main__efhc",
  "users_total_bonus_efhc",
  "users_total_generated_kwh",
  "users_total_exchanged_kwh",
  "panels_total_active",
  "panels_total_bought",
  "panels_total_paid_efhc",
  "panels_total_archived",
  "panels_total_paid__main__efhc",
  "panels_total_paid_bonus_efhc",
];

const CORE_MODULES: AdminModule[] = [
  {
    href: "/admin/users",
    label: "Пользователи",
    note: "Профили, балансы, статусы и операторские действия.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/bank",
    label: "Банк",
    note: "EFHC main/bonus, банк и контроль проводок.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/withdrawals",
    label: "Выводы",
    note: "Заявки на вывод и финальные решения оператора.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/shop",
    label: "Магазин",
    note: "Товары, витрина, пакеты и платёжный контур.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/tasks",
    label: "Задания",
    note: "Каталог заданий, реклама, проверки и начисления.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/reports",
    label: "Отчёты",
    note: "Экономические показатели и контрольные отчёты.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/referrals",
    label: "Рефералы",
    note: "Дерево приглашений, бонусы и операторская проверка.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/panels",
    label: "Панели",
    note: "Активации панелей, генерация и состояние солнечного контура.",
    state: "live",
    releaseTier: "core",
  },
];

const OPERATION_MODULES: AdminModule[] = [
  {
    href: "/admin/hub",
    label: "HUB",
    note: "Управление публичными переходами EFHC и VIP NFT.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/templates",
    label: "Шаблоны",
    note: "Глобальные шаблоны автоответов и системных текстов.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/efhc-deposits",
    label: "Депозиты EFHC",
    note: "Входящие EFHC, ручные исключения и сверка.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/ads",
    label: "Реклама",
    note: "Рекламный контур и рабочие настройки кампаний.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/sale-packages",
    label: "Пакеты",
    note: "Пакеты EFHC, цены, активность и способы оплаты.",
    state: "live",
    releaseTier: "core",
  },
];

function numericFact(value: string | undefined): number {
  if (!value) return 0;
  const parsed = Number(String(value).replace(/,/g, "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

export default function AdminHome() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [overview, setOverview] = useState<Overview | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [reconcileOpen, setReconcileOpen] = useState(false);
  const [reconcile, setReconcile] = useState<Record<string, string>>({
    last_hours: "6",
  });

  const load = useCallback(async () => {
    setMessage(null);
    try {
      const result = await adminApiRequest<Overview>(
        ADMIN_REPORTS_OVERVIEW_PATH,
        "GET",
      );
      setOverview(result);
    } catch (error: unknown) {
      setOverview(null);
      setMessage(adminUiErrorMessage(error, t));
    }
  }, [adminApiRequest, t]);

  useEffect(() => {
    void load();
  }, [load]);

  async function runReconcile() {
    setMessage(null);
    try {
      const lastHours = Math.max(
        1,
        Math.min(168, Number(reconcile.last_hours || "6")),
      );
      await adminApiRequest(ADMIN_TON_RECONCILE_PATH, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: { last_hours: lastHours, limit: 1000 },
      });
      setMessage("Сверка TON выполнена. Релизная сводка обновлена.");
      setReconcileOpen(false);
      await load();
    } catch (error: unknown) {
      setMessage(adminUiErrorMessage(error, t));
    }
  }

  const topFacts = FACT_ORDER.filter(
    (key) => key in (overview?.facts || {}),
  ).slice(0, 6);
  const chartFacts = FACT_ORDER.filter(
    (key) => key in (overview?.facts || {}),
  ).slice(0, 5);

  return (
    <AdminPage
      title="Админ-панель EFHC"
      subtitle="Релизные показатели, рабочие разделы и операторские действия."
      actions={(
        <Button variant="secondary" onClick={() => setReconcileOpen(true)}>
          Сверить TON
        </Button>
      )}
    >
      {message ? (
        <AdminSectionCard title="Статус операции" subtitle={message}>
          <div className="flex justify-end">
            <Button variant="secondary" onClick={load}>
              Обновить данные
            </Button>
          </div>
        </AdminSectionCard>
      ) : null}

      <AdminHeroPanel
        eyebrow="EFHC Release Console"
        title="Релизный центр управления"
        subtitle={
          "Версия, готовность, ключевые показатели и рабочие "
          + "действия текущего релизного кандидата."
        }
        badges={(
          <>
            <TelegramStatusBadge label={RELEASE_VERSION} tone="primary" />
            <TelegramStatusBadge label="Цикл 1635: corrective" tone="warning" />
            <TelegramStatusBadge label="Exact-head CI требуется" />
          </>
        )}
      />

      <div className="grid gap-3 md:grid-cols-4">
        <AdminStatCard
          label="Версия"
          value={RELEASE_VERSION}
          meta="релизный кандидат"
          hint="Следующий релизный пакет после подтверждения CI и PNG."
          tone="neutral"
        />
        <AdminStatCard
          label="Рабочие разделы"
          value={String(CORE_MODULES.length + OPERATION_MODULES.length)}
          meta="доступно в релизе"
          hint="Рабочие разделы текущего релизного состава."
          tone="success"
        />
        <AdminStatCard
          label="Экономическая сводка"
          value={overview?.facts ? String(Object.keys(overview.facts).length) : "—"}
          meta="панели, kWh и EFHC"
          hint="Релизные бизнес-показатели без внутренней диагностики."
          tone="neutral"
        />
        <AdminStatCard
          label="Готовность"
          value="CI + PNG"
          meta="acceptance required"
          hint="Production readiness не объявляется до exact-head проверки."
          tone="warning"
        />
      </div>

      <AdminSectionCard
        title="Основные подразделы"
        subtitle="Пользователи, финансы, панели, задания и отчёты."
      >
        <div data-admin-home-app-grid="release-v172-51">
          <AdminAppButtonGrid items={CORE_MODULES} />
        </div>
      </AdminSectionCard>

      <div className="grid gap-4 lg:grid-cols-2">
        <AdminCharts
          title="Ключевые показатели"
          subtitle="Релизный обзор экономики EFHC."
          items={chartFacts.length ? chartFacts.map((key) => ({
            label: FACT_LABELS[key] || key,
            value: numericFact(overview?.facts?.[key]),
          })) : [
            { label: "Сводка пока не загружена", value: 0 },
          ]}
        />
        <AdminTable
          title="Релизные данные"
          rows={topFacts.map((key) => ({
            label: FACT_LABELS[key] || key,
            value: overview?.facts?.[key] || "—",
          }))}
        />
      </div>

      <AdminSectionCard
        title="Операторские инструменты"
        subtitle="Рабочие действия релизного контура."
      >
        <AdminAppButtonGrid items={OPERATION_MODULES} />
      </AdminSectionCard>

      {!overview && !message ? (
        <TelegramEmptyState
          title="Релизная сводка пока не загружена"
          detail="Нажмите обновить, чтобы запросить рабочие показатели."
          actionLabel={t("common.refresh")}
          onAction={() => void load()}
        />
      ) : null}

      <AdminPromptModal
        open={reconcileOpen}
        title="Сверить TON"
        submitLabel="Запустить сверку"
        fields={[
          {
            key: "last_hours",
            label: "Период проверки, часов",
            placeholder: "6",
            type: "number",
          },
        ]}
        values={reconcile}
        onChange={(key, value) => {
          setReconcile((previous) => ({ ...previous, [key]: value }));
        }}
        onClose={() => setReconcileOpen(false)}
        onSubmit={() => { void runReconcile(); }}
      />
    </AdminPage>
  );
}
