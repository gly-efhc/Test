import React, { useEffect, useState } from "react";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { AdminPage } from "../../components/admin/AdminPage";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

export default function AdminAdsPage() {
  const t = useT();
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>("/admin/ads/providers", "GET");
      setProviders(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage title={t("admin.ads")} backHref="/admin">
      <Card title={t("admin.ads_providers")}>
        <div className="mb-3 flex items-center gap-2">
          <Button onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? <div className="efhc-admin-error mb-2">{error}</div> : null}
        <div className="efhc-admin-table-wrap">
          <table className="efhc-admin-table">
            <thead>
              <tr>
                <th>{t("admin.code")}</th>
                <th>{t("admin.title")}</th>
                <th>{t("admin.active")}</th>
              </tr>
            </thead>
            <tbody>
              {providers.map((p) => (
                <tr key={p.code}>
                  <td>{p.code}</td>
                  <td>{p.title}</td>
                  <td>{p.is_active ? "ON" : "OFF"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </AdminPage>
  );
}
