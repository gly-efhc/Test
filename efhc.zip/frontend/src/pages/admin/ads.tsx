import React, { useEffect, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminRouteHealthStrip } from "../../components/admin/AdminRouteHealthStrip";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useT } from "../../hooks/useT";
import {
  ADMIN_ADS_PROVIDERS_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

export default function AdminAdsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApiRequest<any>(ADMIN_ADS_PROVIDERS_PATH, "GET");
      setProviders(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage
      title={t("admin.ads")}
      backHref="/admin"
      surfaceBadges={[
        { label: "Рабочий раздел", tone: "active" },
        { label: "Провайдеры рекламы", tone: "primary" },
      ]}
      infoBlock={{
        title: "Рекламные провайдеры",
        description: (
          "Управляйте доступными рекламными источниками и их статусом."
        ),
      }}
    >
      <AdminRouteHealthStrip
        title="Состояние рекламного контура"
        subtitle="Проверка доступности подключённых рекламных провайдеров."
        items={[
          { label: "providers", path: "/admin/ads/providers", tone: "connected" },
        ]}
      />
      <Card title={t("admin.ads_providers")}>
        <div className="mb-3 flex items-center gap-2">
          <Button onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? (
          <div className="efhc-admin-error mb-2">{error || null}</div>
        ) : null}
        <div className="efhc-admin-table-wrap">
          <table className="efhc-admin-table">
            <thead>
              <tr>
                <th>{t("admin.code")}</th>
                <th>{t("admin.title")}</th>
                <th>{t("admin.active")}</th>
              </tr>
            </thead>
            <tbody>
              {providers.map((p) => (
                <tr key={p.code}>
                  <td data-label={t("admin.code")}>{p.code}</td>
                  <td data-label={t("admin.title")}>{p.title}</td>
                  <td data-label={t("admin.active")}>
  {p.is_active
    ? t("common.on") || "ON"
    : t("common.off") || "OFF"}
</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </AdminPage>
  );
}
