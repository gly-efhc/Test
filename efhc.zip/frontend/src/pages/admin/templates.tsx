import React, { useEffect, useState } from "react";

import { AdminPage } from "../../components/admin/AdminPage";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import {
  adminPath,
  ADMIN_TEMPLATES_PATH,
  ADMIN_TEMPLATES_KEY_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type TemplateItem = {
  key: string;
  content: string | null;
  description: string;
  updated_at: string;
};

export default function AdminTemplatesPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const [items, setItems] = useState<TemplateItem[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [busyKey, setBusyKey] = useState<string | null>(null);

  async function load(): Promise<void> {
    setLoading(true);
    setMsg(null);
    try {
      const out = await adminApiRequest<TemplateItem[]>(
        ADMIN_TEMPLATES_PATH,
        "GET",
      );
      setItems(out || []);
      setValues(
        Object.fromEntries(
          (out || []).map((item) => [item.key, item.content || ""]),
        ),
      );
    } catch (error) {
      setMsg(adminUiErrorMessage(error));
    } finally {
      setLoading(false);
    }
  }

  async function save(key: string): Promise<void> {
    setBusyKey(key);
    setMsg(null);
    try {
      await adminApiRequest<TemplateItem>(
        adminPath(ADMIN_TEMPLATES_KEY_PATH, { key }),
        "PUT",
        { body: { content: values[key] || "" } },
      );
      setMsg(`Шаблон ${key} сохранён.`);
      await load();
    } catch (error) {
      setMsg(adminUiErrorMessage(error));
    } finally {
      setBusyKey(null);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage
      title="Шаблоны"
      subtitle={
        "Глобальный CMS-слой для системных текстов и автоответов, включая locale-aware variants для moderation path."
      }
      backHref="/admin"
    >
      {msg ? <TelegramInfoBlock title="Статус">{msg}</TelegramInfoBlock> : null}
      {loading && items.length === 0 ? (
        <TelegramInfoBlock title="Загрузка">Читаем системные шаблоны…</TelegramInfoBlock>
      ) : null}
      <TelegramInfoBlock title="Locale-aware шаблоны">
        Для multilingual moderation path используйте ключи вида
        <code> task_reject_fallback.en </code> или
        <code> task_approve_prefix.uk </code>. Базовый ключ без
        суффикса остаётся fallback-слоем.
      </TelegramInfoBlock>
      <div className="grid gap-4 lg:grid-cols-2">
        {items.map((item) => (
          <Card key={item.key} title={item.description}>
            <div className="space-y-3">
              <div className="text-xs efhc-text-muted">{item.key}</div>
              <textarea
                value={values[item.key] || ""}
                onChange={(event) =>
                  setValues((prev) => ({
                    ...prev,
                    [item.key]: event.target.value,
                  }))
                }
                rows={6}
                className="w-full rounded-2xl border bg-[var(--tg-secondary-bg)] p-3 text-sm outline-none"
              />
              <div className="text-xs efhc-text-muted">
                updated_at: {item.updated_at}
              </div>
              <Button
                onClick={() => void save(item.key)}
                disabled={busyKey === item.key}
              >
                {busyKey === item.key ? "Сохранение..." : "Сохранить"}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </AdminPage>
  );
}
