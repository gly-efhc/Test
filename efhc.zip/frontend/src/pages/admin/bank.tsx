import React, { useEffect, useMemo, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminBankDashboardRuntime } from "../../components/admin/AdminBankDashboardRuntime";
import { AdminActionGrid } from "../../components/admin/AdminActionGrid";
import { AdminSectionCard } from "../../components/admin/AdminSectionCard";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { Button } from "../../components/ui/Button";
import {
  ADMIN_LOGS_TRANSFERS_PATH,
  ADMIN_REPORTS_OVERVIEW_PATH,
  ADMIN_BANK_BALANCE_PATH,
  ADMIN_BANK_BURN_PATH,
  ADMIN_BANK_MINT_PATH,
  type AdminBankBalanceResponse,
  type AdminBankMutationResponse,
} from "../../lib/api/generated/adminSeams";
import {
  ensureAdminBankMutationRequest,
  parseAdminBankBalanceResponse,
  parseAdminBankMutationResponse,
} from "../../lib/api/generated/adminSeamValidators";
import { newIdempotencyKey } from "../../lib/idempotency";
import { useT } from "../../hooks/useT";
import {
  formatD8ToHuman,
  sumScaledDown,
  toScaledBigintDown,
} from "../../lib/format";
import {
  TelegramStatusBadge,
} from "../../components/ui/telegram/TelegramStatusBadge";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type PendingMode = "mint" | "burn" | null;
type BankTab = "balance" | "ledger" | "scheme";
type ChartMode = "bank" | "coverage" | "flow";

const BANK_CONFIRM_PHRASE = "ПОДТВЕРЖДАЮ";

type OverviewResponse = {
  ok: boolean;
  facts?: Record<string, string>;
  counters?: Record<string, number>;
  ts?: string;
};

type TransferLogItem = {
  id: number;
  tg_id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  idempotency_key: string;
  created_at: string;
};

type TransferLogsResponse = {
  ok: boolean;
  items: TransferLogItem[];
  next_cursor: string | null;
};

type ChartItem = {
  label: string;
  value: string;
  tone?: "safe" | "warn" | "neutral";
};

function numeric(value: string | undefined): number {
  try {
    const scaled = toScaledBigintDown(value || "0", 8);
    const absolute = scaled < 0n ? -scaled : scaled;
    const whole = absolute / 100000000n;
    const fraction = (absolute % 100000000n) / 100000n;
    const wholeNumber = parseInt(whole.toString(), 10);
    const fractionNumber = parseInt(fraction.toString(), 10) / 1000;
    return wholeNumber + fractionNumber;
  } catch {
    return 0;
  }
}

function shortId(value: string): string {
  if (!value) return "—";
  if (value.length <= 18) return value;
  return `${value.slice(0, 8)}…${value.slice(-6)}`;
}

function chartItemsForMode(
  mode: ChartMode,
  balanceValue: string,
  projectedBalance: string,
  facts: Record<string, string>,
): ChartItem[] {
  if (mode === "coverage") {
    return [
      {
        label: "Банк EFHC",
        value: balanceValue,
        tone: "safe",
      },
      {
        label: "Балансы пользователей",
        value: facts.users_total_efhc || "0.00000000",
        tone: "neutral",
      },
      {
        label: "Разница банк/пользователи",
        value: facts.bank_users_balance_diff_efhc || "0.00000000",
        tone: facts.bank_users_balance_match === "OK" ? "safe" : "warn",
      },
    ];
  }

  if (mode === "flow") {
    return [
      {
        label: "Main EFHC пользователей",
        value: facts.users_total__main__efhc || "0.00000000",
        tone: "neutral",
      },
      {
        label: "Bonus EFHC пользователей",
        value: facts.users_total_bonus_efhc || "0.00000000",
        tone: "neutral",
      },
      {
        label: "EFHC списано на панели",
        value: facts.panels_total_paid_efhc || "0.00000000",
        tone: "safe",
      },
    ];
  }

  return [
    {
      label: "Текущий баланс банка",
      value: balanceValue,
      tone: "safe",
    },
    {
      label: "Расчётный баланс после действия",
      value: projectedBalance,
      tone: "warn",
    },
    {
      label: "Всего EFHC пользователей",
      value: facts.users_total_efhc || "0.00000000",
      tone: "neutral",
    },
  ];
}

function AdminBankVisualChart(props: {
  mode: ChartMode;
  items: ChartItem[];
}) {
  const max = Math.max(...props.items.map((item) => numeric(item.value)), 1);
  return (
    <div
      className="efhc-admin-visual-card"
      data-admin-bank-interactive-chart="sandbox-inspired-1323"
    >
      <div className="efhc-admin-visual-card_head">
        <div>
          <div className="efhc-admin-visual-card_eyebrow">
            Интерактивная диаграмма
          </div>
          <div className="efhc-admin-visual-card_title">
            {props.mode === "coverage"
              ? "Покрытие банка"
              : props.mode === "flow"
                ? "Движение EFHC"
                : "Баланс и прогноз"}
          </div>
        </div>
        <TelegramStatusBadge label="sandbox pattern" tone="primary" />
      </div>
      <div className="efhc-admin-chart-bars">
        {props.items.map((item) => {
          const width = Math.max(
            8,
            Math.round((numeric(item.value) / max) * 100),
          );
          return (
            <div className="efhc-admin-chart-row" key={item.label}>
              <div className="efhc-admin-chart-row_meta">
                <span>{item.label}</span>
                <strong>{formatD8ToHuman(item.value)}</strong>
              </div>
              <div className="efhc-admin-chart-row_track">
                <div
                  className={`efhc-admin-chart-row_bar efhc-admin-chart-row_bar--${item.tone || "neutral"}`}
                  style={{ width: `${width}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AdminBankFlowScheme() {
  return (
    <div
      className="efhc-bank-flow"
      data-admin-bank-interactive-scheme="1323"
    >
      <div className="efhc-bank-flow_node efhc-bank-flow_node--core">
        <strong>EFHC Bank</strong>
        <span>системный банк может уходить в минус</span>
      </div>
      <div className="efhc-bank-flow_line" />
      <div className="efhc-bank-flow_grid">
        <div className="efhc-bank-flow_node">
          <strong>Пользователи</strong>
          <span>main / bonus balances</span>
        </div>
        <div className="efhc-bank-flow_node">
          <strong>Панели</strong>
          <span>activation 100 EFHC</span>
        </div>
        <div className="efhc-bank-flow_node">
          <strong>Exchange</strong>
          <span>kWh → EFHC</span>
        </div>
        <div className="efhc-bank-flow_node">
          <strong>Ledger</strong>
          <span>операторские проводки</span>
        </div>
      </div>
    </div>
  );
}

export default function AdminBankPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [bal, setBal] = useState<AdminBankBalanceResponse | null>(null);
  const [overview, setOverview] = useState<OverviewResponse | null>(null);
  const [ledger, setLedger] = useState<TransferLogItem[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [amount, setAmount] = useState<string>("100.00000000");
  const [reason, setReason] = useState<string>("");
  const [pendingMode, setPendingMode] = useState<PendingMode>(null);
  const [confirmText, setConfirmText] = useState<string>("");
  const [pendingIdk, setPendingIdk] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<BankTab>("balance");
  const [chartMode, setChartMode] = useState<ChartMode>("bank");

  const facts = overview?.facts || {};

  const loadBank = async () => {
    const r = await adminApiRequest<unknown>(ADMIN_BANK_BALANCE_PATH, "GET");
    setBal(parseAdminBankBalanceResponse(r));
  };

  const loadOverview = async () => {
    const r = await adminApiRequest<OverviewResponse>(
      ADMIN_REPORTS_OVERVIEW_PATH,
      "GET",
    );
    setOverview(r);
  };

  const loadLedger = async () => {
    const r = await adminApiRequest<TransferLogsResponse>(
      `${ADMIN_LOGS_TRANSFERS_PATH}?limit=12`,
      "GET",
    );
    setLedger(Array.isArray(r.items) ? r.items : []);
  };

  const load = async () => {
    setMsg(null);
    try {
      await Promise.all([loadBank(), loadOverview(), loadLedger()]);
    } catch (e: any) {
      setMsg(adminUiErrorMessage(e, t));
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const balanceValue = useMemo(
    () => formatD8ToHuman(bal?.efhc_main || "0"),
    [bal],
  );

  const projectedBalance = useMemo(() => {
    try {
      const deltaValue =
        pendingMode === "burn" ? `-${amount || "0"}` : amount || "0";
      return formatD8ToHuman(sumScaledDown(balanceValue, deltaValue, 8));
    } catch {
      return balanceValue;
    }
  }, [amount, balanceValue, pendingMode]);

  const chartItems = useMemo(
    () => chartItemsForMode(chartMode, balanceValue, projectedBalance, facts),
    [balanceValue, chartMode, facts, projectedBalance],
  );

  const amountNumber = useMemo(() => numeric(amount), [amount]);

  const isActionReady = Boolean(
    pendingMode &&
      amountNumber > 0 &&
      reason.trim().length >= 3 &&
      confirmText.trim() === BANK_CONFIRM_PHRASE &&
      pendingIdk,
  );

  const openBankAction = (mode: Exclude<PendingMode, null>) => {
    setPendingMode(mode);
    setConfirmText("");
    setPendingIdk(newIdempotencyKey());
  };

  const closeBankAction = () => {
    setPendingMode(null);
    setConfirmText("");
    setPendingIdk("");
  };

  const doMintBurn = async () => {
    if (!isActionReady || !pendingMode) {
      setMsg("Подтверждение не завершено: проверьте сумму, причину и фразу.");
      return;
    }
    setMsg(null);
    setLoading(true);
    try {
      const idk = pendingIdk || newIdempotencyKey();
      const targetPath = pendingMode === "mint"
        ? ADMIN_BANK_MINT_PATH
        : ADMIN_BANK_BURN_PATH;
      const body = ensureAdminBankMutationRequest({ amount, reason });
      const r = await adminApiRequest<unknown>(targetPath, "POST", {
        idempotencyKey: idk,
        body,
      });
      const parsed = parseAdminBankMutationResponse(
        r,
      ) as AdminBankMutationResponse;
      setMsg(
        `Операция выполнена. Баланс после: ${parsed.bank_balance_after}`,
      );
      closeBankAction();
      await load();
    } catch (e: any) {
      setMsg(adminUiErrorMessage(e, t));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminPage
      title={t("admin.bank")}
      subtitle="Банк EFHC: статистика, интерактивная диаграмма, схема потоков и ledger без debug-мусора."
      backHref="/admin"
      surfaceBadges={[
        { label: "bank ledger", tone: "primary" },
        { label: "statistics", tone: "connected" },
        { label: "operator safe", tone: "warning" },
      ]}
      actions={
        <Button variant="secondary" onClick={() => void load()}>
          {t("common.refresh")}
        </Button>
      }
    >
      <div data-admin-bank-cycle="1323" />
      <div data-admin-bank-action-proof="1324" />

      {msg ? (
        <AdminSectionCard title="Статус операции" subtitle={msg}>
          <div className="flex justify-end">
            <Button variant="secondary" onClick={() => void load()}>
              {t("common.refresh")}
            </Button>
          </div>
        </AdminSectionCard>
      ) : null}

      <div
        className="efhc-admin-kpi-grid"
        data-admin-bank-statistics="1323"
      >
        <AdminStatCard
          label="Банк"
          value={String(bal?.bank_name || "—")}
          meta="system actor"
          hint="Системный EFHC bank account."
          tone="neutral"
        />
        <AdminStatCard
          label="Баланс банка"
          value={balanceValue}
          meta="EFHC main"
          hint="Канон допускает отрицательный банк."
          tone="success"
        />
        <AdminStatCard
          label="Пользовательские балансы"
          value={formatD8ToHuman(facts.users_total_efhc || "0")}
          meta="main + bonus"
          hint="Сверка из overview."
          tone="neutral"
        />
        <AdminStatCard
          label="Разница"
          value={formatD8ToHuman(
            facts.bank_users_balance_diff_efhc || "0",
          )}
          meta={facts.bank_users_balance_match || "no overview"}
          hint="Bank minus users total."
          tone={facts.bank_users_balance_match === "OK" ? "success" : "warning"}
        />
      </div>


      <AdminBankDashboardRuntime
        bankBalance={balanceValue}
        bankName={String(bal?.bank_name || "—")}
        bankUsersDiff={facts.bank_users_balance_diff_efhc || "0.00000000"}
        bankUsersMatch={facts.bank_users_balance_match || "no overview"}
        exchangedKwh={facts.users_total_exchanged_kwh || "0.00000000"}
        ledger={ledger}
        onRefresh={() => {
          void load();
        }}
        panelsPaid={facts.panels_total_paid_efhc || "0.00000000"}
        pendingIdempotency={pendingIdk}
        pendingMode={pendingMode}
        updatedAt={overview?.ts || "snapshot"}
        usersBonus={facts.users_total_bonus_efhc || "0.00000000"}
        usersMain={facts.users_total__main__efhc || "0.00000000"}
        usersTotal={facts.users_total_efhc || "0.00000000"}
      />

      <AdminSectionCard
        title="Визуальная панель банка"
        subtitle="Паттерн взят из песочницы: KPI cards + переключаемая диаграмма + схема потоков. В EFHC он реализован без новых зависимостей."
        actions={
          <div className="efhc-admin-chart-toggle" role="group">
            <button
              type="button"
              aria-pressed={chartMode === "bank"}
              onClick={() => setChartMode("bank")}
            >
              Баланс
            </button>
            <button
              type="button"
              aria-pressed={chartMode === "coverage"}
              onClick={() => setChartMode("coverage")}
            >
              Покрытие
            </button>
            <button
              type="button"
              aria-pressed={chartMode === "flow"}
              onClick={() => setChartMode("flow")}
            >
              Потоки
            </button>
          </div>
        }
      >
        <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
          <AdminBankVisualChart mode={chartMode} items={chartItems} />
          <AdminBankFlowScheme />
        </div>
      </AdminSectionCard>

      <AdminActionGrid
        title="Операторские действия"
        subtitle="Mint/Burn требуют подтверждения. Ledger и статистика находятся отдельно от действий."
        items={[
          {
            label: t("common.refresh"),
            note: "Обновить баланс, overview и ledger.",
            onClick: () => {
              void load();
            },
          },
          {
            label: t("admin.mint"),
            note: "Открыть подтверждение эмиссии в банк.",
            onClick: () => openBankAction("mint"),
          },
          {
            label: t("admin.burn"),
            note: "Открыть подтверждение сжигания EFHC банка.",
            onClick: () => openBankAction("burn"),
            variant: "ghost",
          },
        ]}
      />

      <div className="efhc-admin-surface-tabs" role="tablist">
        <button
          type="button"
          aria-selected={activeTab === "balance"}
          onClick={() => setActiveTab("balance")}
        >
          Баланс
        </button>
        <button
          type="button"
          aria-selected={activeTab === "ledger"}
          onClick={() => setActiveTab("ledger")}
        >
          Ledger
        </button>
        <button
          type="button"
          aria-selected={activeTab === "scheme"}
          onClick={() => setActiveTab("scheme")}
        >
          Схема
        </button>
      </div>

      {activeTab === "balance" ? (
        <AdminSectionCard
          title="Баланс и прогноз"
          subtitle="Здесь оператор видит текущий и расчётный баланс до подтверждения действия."
        >
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="grid gap-3">
              <label className="grid gap-1">
                <span className="text-xs">{t("admin.amount_d8")}</span>
                <input
                  className="w-full efhc-input"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00000000"
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">{t("admin.reason")}</span>
                <input
                  className="w-full efhc-input"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder={t("admin.reason_ph")}
                />
              </label>
            </div>
            <div className="efhc-bank-preview-card">
              <div>
                <span>Текущий баланс</span>
                <strong>{balanceValue}</strong>
              </div>
              <div>
                <span>Расчётный баланс</span>
                <strong>{projectedBalance}</strong>
              </div>
              <div>
                <span>Операция</span>
                <strong>{pendingMode || "не выбрана"}</strong>
              </div>
              <div data-admin-bank-idempotency-proof="prepared-1324">
                <span>Контроль повтора</span>
                <strong>{pendingIdk ? shortId(pendingIdk) : "создаётся при подтверждении"}</strong>
              </div>
            </div>
          </div>
        </AdminSectionCard>
      ) : null}

      {activeTab === "ledger" ? (
        <AdminSectionCard
          title="Ledger последних проводок"
          subtitle="Рабочий ledger последних банковских проводок без debug dump."
          actions={
            <TelegramStatusBadge label="ledger boundary 1323" tone="primary" />
          }
        >
          <div
            className="efhc-admin-ledger-table"
            data-admin-bank-ledger-boundary="1323"
          >
            <div className="efhc-admin-ledger-table_head">
              <span>Время</span>
              <span>Пользователь</span>
              <span>Тип</span>
              <span>Причина</span>
              <span>Сумма</span>
            </div>
            {ledger.length ? ledger.map((item) => (
              <div className="efhc-admin-ledger-row" key={item.id}>
                <span>{item.created_at || "—"}</span>
                <span>{item.tg_id}</span>
                <span>{item.direction}/{item.balance_type}</span>
                <span>{item.reason || "—"}</span>
                <strong>{formatD8ToHuman(item.amount)}</strong>
              </div>
            )) : (
              <div className="efhc-admin-ledger-empty">
                Ledger пока пуст или недоступен для текущей админ-сессии.
              </div>
            )}
          </div>
        </AdminSectionCard>
      ) : null}

      {activeTab === "scheme" ? (
        <AdminSectionCard
          title="Схема потоков EFHC Bank"
          subtitle="Интерактивная схема показывает смысл банка: банк, пользователи, панели, обмен и ledger разделены."
        >
          <AdminBankFlowScheme />
        </AdminSectionCard>
      ) : null}

      <AdminPromptModal
        open={pendingMode !== null}
        title={pendingMode === "mint" ? "Подтвердить mint" : "Подтвердить burn"}
        submitLabel={pendingMode === "mint" ? "Подтвердить mint" : "Подтвердить burn"}
        fields={[
          { key: "summary", label: "Контекст", type: "textarea" },
          { key: "reason", label: t("admin.reason"), type: "textarea" },
          {
            key: "confirm",
            label: `Введите ${BANK_CONFIRM_PHRASE}`,
            placeholder: BANK_CONFIRM_PHRASE,
          },
        ]}
        values={{
          summary: `current bank balance: ${balanceValue}\noperation: ${pendingMode || "—"}\namount: ${amount}\nprojected balance: ${projectedBalance}\nidempotency: ${shortId(pendingIdk)}`,
          reason,
          confirm: confirmText,
        }}
        busy={loading}
        submitDisabled={!isActionReady}
        onChange={(key, value) => {
          if (key === "reason") setReason(value);
          if (key === "confirm") setConfirmText(value);
        }}
        onClose={closeBankAction}
        onSubmit={() => {
          void doMintBurn();
        }}
      />
    </AdminPage>
  );
}
