import React, { useEffect, useMemo, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EfhcCoinIcon } from "../../components/icons/EfhcCoin";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { format8, sumScaledDown } from "../../lib/format";
import { newIdempotencyKey } from "../../lib/idempotency";

type UserItem = {
  tg_id: number;
  username?: string | null;
  is_active: boolean;
  is_vip: boolean;
  ton_wallet?: string | null;
  main_balance: string;
  bonus_balance: string;
  available_kwh: string;
  total_generated_kwh: string;
  last_seen_at?: string | null;
};

type UserDetail = UserItem & {
  created_at: string;
  updated_at: string;
};

function statusClass(isActive: boolean): string {
  return isActive
    ? "efhc-status efhc-status-ok"
    : "efhc-status efhc-status-muted";
}

function userLabel(name?: string | null): string {
  return name ? `@${name}` : "(no username)";
}

export default function AdminUsersPage() {
  const t = useT();
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [selected, setSelected] = useState<UserDetail | null>(null);
  const [busyAction, setBusyAction] = useState("");

  async function loadList(q: string) {
    setLoading(true);
    setErr("");
    try {
      const path = `/admin/users/search?q=${encodeURIComponent(q)}`;
      const data = await apiRequest<UserItem[]>(path, "GET");
      setItems(data || []);
      setSelected(null);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function loadDetail(tg: number) {
    setErr("");
    try {
      const path = `/admin/users/${tg}`;
      const data = await apiRequest<UserDetail>(path, "GET");
      setSelected(data);
    } catch (e: any) {
      setErr(String(e?.message || e));
    }
  }

  async function setVip(tg: number, isVip: boolean) {
    setBusyAction("vip");
    setErr("");
    try {
      await apiRequest<UserDetail>(`/admin/users/${tg}/vip`, "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: { is_vip: isVip },
      });
      await loadList(query);
      await loadDetail(tg);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  async function setActive(tg: number, isActive: boolean) {
    setBusyAction("active");
    setErr("");
    try {
      const path = `/admin/users/${tg}/active`;
      await apiRequest<UserDetail>(path, "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: { is_active: isActive },
      });
      await loadList(query);
      await loadDetail(tg);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  async function resetWallet(tg: number) {
    setBusyAction("wallet");
    setErr("");
    try {
      await apiRequest(`/admin/users/${tg}/wallet/reset`, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: {},
      });
      await loadDetail(tg);
      await loadList(query);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  useEffect(() => {
    void loadList("");
  }, []);

  const balances = useMemo(() => {
    if (!selected) return null;
    const main = String(selected.main_balance ?? "0");
    const bonus = String(selected.bonus_balance ?? "0");
    return {
      main,
      bonus,
      total: sumScaledDown(main, bonus, 8),
    };
  }, [selected]);

  return (
    <AdminPage title={t("admin.users")} backHref="/admin">
      <Card title={t("admin.users")}>
        <div className="grid gap-3">
          <div className="flex flex-col gap-2 md:flex-row">
            <input
              className="efhc-input w-full"
              placeholder="tg_id / username / ton_wallet"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void loadList(query);
              }}
            />
            <Button onClick={() => void loadList(query)}>Search</Button>
          </div>
          {err ? <div className="efhc-admin-error">{err}</div> : null}
          {loading ? (
            <div className="text-sm efhc-text-muted">Loading…</div>
          ) : null}
          <div className="grid gap-3 md:grid-cols-2">
            <div className="grid gap-2">
              <div className="text-xs efhc-text-muted">
                Results: {items.length}
              </div>
              <div className="max-h-[60vh] overflow-auto rounded-2xl">
                <div className="efhc-card">
                  {items.map((u) => (
                    <button
                      key={u.tg_id}
                      className={[
                        "flex w-full items-center justify-between",
                        "border-b border-[color:var(--tg-hint)]",
                        "px-3 py-3 text-left",
                        "hover:bg-[var(--tg-secondary-bg)]/70",
                      ].join(" ")}
                      onClick={() => void loadDetail(u.tg_id)}
                    >
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold">
                          {userLabel(u.username)}
                        </div>
                        <div className="text-xs efhc-text-muted">
                          TG: {u.tg_id}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {u.is_vip ? (
                          <span
                            className="efhc-status efhc-status-accent"
                          >
                            VIP
                          </span>
                        ) : null}
                        <span className={statusClass(u.is_active)}>
                          {u.is_active ? "ACTIVE" : "INACTIVE"}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="grid gap-2">
              <div className="text-xs efhc-text-muted">User card</div>
              {!selected ? (
                <div className="rounded-2xl efhc-card p-4 text-sm">
                  <span className="efhc-text-muted">
                    Select a user from the list.
                  </span>
                </div>
              ) : (
                <div className="grid gap-3 rounded-2xl efhc-card p-4">
                  <div
                    className="flex items-start justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-base font-bold">
                        {userLabel(selected.username)}
                      </div>
                      <div className="text-xs efhc-text-muted">
                        Telegram ID: {selected.tg_id}
                      </div>
                      <div className="mt-1 break-all text-xs">
                        <span className="efhc-text-muted">
                          TON: {selected.ton_wallet || "(not bound)"}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {selected.is_vip ? (
                        <span
                          className="efhc-status efhc-status-accent"
                        >
                          VIP
                        </span>
                      ) : null}
                      <span className={statusClass(selected.is_active)}>
                        {selected.is_active ? "ACTIVE" : "INACTIVE"}
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {[
                      ["Main EFHC", balances?.main || "0"],
                      ["Bonus EFHC", balances?.bonus || "0"],
                      ["Total EFHC", balances?.total || "0"],
                    ].map(([label, value]) => (
                      <div
                        key={label}
                        className="rounded-2xl efhc-pill p-3"
                      >
                        <div className="text-xs efhc-text-muted">
                          {label}
                        </div>
                        <div className="inline-flex items-center gap-2">
                          <EfhcCoinIcon size={18} />
                          <span className="font-semibold">
                            {format8(value)}
                          </span>
                        </div>
                      </div>
                    ))}
                    <div className="rounded-2xl efhc-pill p-3">
                      <div className="text-xs efhc-text-muted">
                        Available kWh
                      </div>
                      <div className="font-semibold">
                        {format8(selected.available_kwh)}
                      </div>
                    </div>
                    <div className="rounded-2xl efhc-pill p-3">
                      <div className="text-xs efhc-text-muted">
                        Total generated kWh
                      </div>
                      <div className="font-semibold">
                        {format8(selected.total_generated_kwh)}
                      </div>
                    </div>
                    <div
                      className="col-span-2 rounded-2xl efhc-pill p-3"
                    >
                      <div className="text-xs efhc-text-muted">
                        Last seen
                      </div>
                      <div className="font-semibold">
                        {selected.last_seen_at
                          ? new Date(
                              selected.last_seen_at,
                            ).toLocaleString()
                          : "-"}
                      </div>
                    </div>
                  </div>
                  <div className="grid gap-2 md:grid-cols-2">
                    <Button
                      disabled={busyAction !== ""}
                      onClick={() =>
                        void setVip(
                          selected.tg_id,
                          !selected.is_vip,
                        )
                      }
                    >
                      {busyAction === "vip"
                        ? "Working…"
                        : selected.is_vip
                          ? "Remove VIP"
                          : "Set VIP"}
                    </Button>
                    <Button
                      variant="secondary"
                      disabled={busyAction !== ""}
                      onClick={() =>
                        void setActive(
                          selected.tg_id,
                          !selected.is_active,
                        )
                      }
                    >
                      {busyAction === "active"
                        ? "Working…"
                        : selected.is_active
                          ? "Deactivate"
                          : "Activate"}
                    </Button>
                    <Button
                      variant="secondary"
                      disabled={
                        busyAction !== "" || !selected.ton_wallet
                      }
                      onClick={() => void resetWallet(selected.tg_id)}
                    >
                      {busyAction === "wallet"
                        ? "Working…"
                        : "Reset TON wallet"}
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => {
                        location.href = "/admin/bank";
                      }}
                    >
                      Go to Bank
                    </Button>
                  </div>
                  <div className="text-xs efhc-text-muted">
                    Admin mutations use tg_id and Idempotency-Key.
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Card>
    </AdminPage>
  );
}
