import React, { useEffect, useMemo, useState } from "react";

import { AdminDetailShell } from "../../components/admin/AdminDetailShell";
import { AdminUsersDashboardRuntime } from "../../components/admin/AdminUsersDashboardRuntime";
import { AdminListShell } from "../../components/admin/AdminListShell";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminSettingsCard } from "../../components/admin/AdminSettingsCard";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { EfhcCoinIcon } from "../../components/icons/EfhcCoin";
import { Button } from "../../components/ui/Button";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import { useT } from "../../hooks/useT";
import { formatD8ToHuman, sumScaledDown } from "../../lib/format";
import { newIdempotencyKey } from "../../lib/idempotency";
import type { GlobalId } from "../../types/identity";
import {
  adminPath,
  ADMIN_USERS_SEARCH_PATH,
  ADMIN_USERS_GLOBAL_ID_PATH,
  ADMIN_USERS_GLOBAL_ID_VIP_PATH,
  ADMIN_USERS_GLOBAL_ID_ACTIVE_PATH,
  ADMIN_USERS_GLOBAL_ID_WALLET_RESET_PATH,
  ADMIN_TRANSFER_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type UserItem = {
  global_id: GlobalId;
  username?: string | null;
  is_active: boolean;
  is_vip: boolean;
  ton_wallet?: string | null;
  main_balance: string;
  bonus_balance: string;
  available_kwh: string;
  total_generated_kwh: string;
  last_seen_at?: string | null;
};

type UserDetail = UserItem & {
  created_at: string;
  updated_at: string;
};

type TransferDirection = "credit" | "debit";
type TransferBalance = "main" | "bonus";

type CorrectionState = {
  direction: TransferDirection;
  balance: TransferBalance;
  amount: string;
  reason: string;
};

function userLabel(name?: string | null): string {
  return name ? `@${name}` : "Пользователь без username";
}

function formatDate(value?: string | null): string {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString();
}

function shortWallet(value?: string | null): string {
  if (!value) return "Не привязан";
  if (value.length <= 16) return value;
  return `${value.slice(0, 8)}…${value.slice(-6)}`;
}

function normalAmount(value: string): string {
  return value.trim().replace(",", ".");
}

export default function AdminUsersPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [selected, setSelected] = useState<UserDetail | null>(null);
  const [busyAction, setBusyAction] = useState("");
  const [operatorConfirmed, setOperatorConfirmed] = useState(false);
  const [correction, setCorrection] = useState<CorrectionState>({
    direction: "credit",
    balance: "main",
    amount: "0.00000000",
    reason: "ADMIN_CORRECTION_MAIN",
  });

  async function loadList(q: string) {
    setLoading(true);
    setErr("");
    try {
      const data = await adminApiRequest<UserItem[] | { items?: UserItem[] }>(
        `${ADMIN_USERS_SEARCH_PATH}?q=${encodeURIComponent(q)}`,
        "GET",
      );
      const nextItems = Array.isArray(data)
        ? data
        : Array.isArray(data?.items)
          ? data.items
          : [];
      setItems(nextItems);
      setSelected(null);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    } finally {
      setLoading(false);
    }
  }

  async function loadDetail(globalId: GlobalId) {
    setErr("");
    try {
      const data = await adminApiRequest<UserDetail>(
        adminPath(ADMIN_USERS_GLOBAL_ID_PATH, { global_id: globalId }),
        "GET",
      );
      setSelected(data);
      setOperatorConfirmed(false);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    }
  }

  async function setVip(globalId: GlobalId, isVip: boolean) {
    setBusyAction("vip");
    setErr("");
    try {
      await adminApiRequest<UserDetail>(adminPath(ADMIN_USERS_GLOBAL_ID_VIP_PATH, { global_id: globalId }), "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: { is_vip: isVip },
      });
      await loadList(query);
      await loadDetail(globalId);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    } finally {
      setBusyAction("");
    }
  }

  async function setActive(globalId: GlobalId, isActive: boolean) {
    setBusyAction("active");
    setErr("");
    try {
      await adminApiRequest<UserDetail>(adminPath(ADMIN_USERS_GLOBAL_ID_ACTIVE_PATH, { global_id: globalId }), "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: { is_active: isActive },
      });
      await loadList(query);
      await loadDetail(globalId);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    } finally {
      setBusyAction("");
    }
  }

  async function resetWallet(globalId: GlobalId) {
    setBusyAction("wallet");
    setErr("");
    try {
      await adminApiRequest(adminPath(ADMIN_USERS_GLOBAL_ID_WALLET_RESET_PATH, { global_id: globalId }), "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: {},
      });
      await loadDetail(globalId);
      await loadList(query);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    } finally {
      setBusyAction("");
    }
  }

  useEffect(() => {
    void loadList("");
  }, []);

  const normalizedAmount = normalAmount(correction.amount);
  const amountNumber = parseFloat(normalizedAmount);
  const canApplyCorrection = Boolean(
    selected &&
      operatorConfirmed &&
      Number.isFinite(amountNumber) &&
      amountNumber > 0 &&
      correction.reason.trim(),
  );

  async function applyCorrection() {
    if (!selected || !canApplyCorrection) return;
    setBusyAction("correction");
    setErr("");
    try {
      await adminApiRequest(ADMIN_TRANSFER_PATH, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: {
          global_id: selected.global_id,
          direction: correction.direction,
          balance: correction.balance,
          amount: normalizedAmount,
          reason: correction.reason.trim(),
        },
      });
      setOperatorConfirmed(false);
      await loadDetail(selected.global_id);
      await loadList(query);
    } catch (e: unknown) {
      const message = adminUiErrorMessage(e, t);
      setErr(message);
    } finally {
      setBusyAction("");
    }
  }

  const balances = useMemo(() => {
    if (!selected) return null;
    const main = String(selected.main_balance ?? "0");
    const bonus = String(selected.bonus_balance ?? "0");
    return { main, bonus, total: sumScaledDown(main, bonus, 8) };
  }, [selected]);

  const activeCount = items.filter((item) => item.is_active).length;
  const vipCount = items.filter((item) => item.is_vip).length;
  const walletCount = items.filter((item) => item.ton_wallet).length;
  const usersMainTotal = useMemo(
    () => items.reduce(
      (acc, item) => sumScaledDown(acc, String(item.main_balance || "0"), 8),
      "0",
    ),
    [items],
  );
  const usersBonusTotal = useMemo(
    () => items.reduce(
      (acc, item) => sumScaledDown(acc, String(item.bonus_balance || "0"), 8),
      "0",
    ),
    [items],
  );
  const usersTotalBalance = useMemo(
    () => sumScaledDown(usersMainTotal, usersBonusTotal, 8),
    [usersBonusTotal, usersMainTotal],
  );

  return (
    <AdminPage title={t("admin.users")} backHref="/admin">
      <div data-admin-users-cycle="1321" data-admin-users-cycle-current="1322" />
      <div data-admin-users-no-route-debug="1322" />
      <TelegramInfoBlock title="Пользователи">
        <div className="mt-2 text-xs opacity-80">
          Рабочий операторский экран: поиск, читаемая таблица, карточка
          пользователя и подтверждаемые действия без debug-вывода.
        </div>
        <div className="mt-3 flex flex-col gap-2 md:flex-row">
          <input
            data-admin-users-search="empty-query-latest-users"
            className="efhc-input w-full"
            placeholder={t("admin.search_users_placeholder")}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void loadList(query);
            }}
          />
          <Button onClick={() => void loadList(query)}>
            {t("common.search") || t("common.refresh")}
          </Button>
        </div>
      </TelegramInfoBlock>

      <div
        className="grid gap-3 md:grid-cols-4"
        data-admin-users-statistics-audit='1321'
        data-admin-users-statistics-readability='1322'
      >
        <AdminStatCard
          label={t("admin.admin_users_stat_results")}
          value={String(items.length)}
          hint={t("admin.results_count")}
        />
        <AdminStatCard
          label={t("admin.admin_users_stat_active")}
          value={String(activeCount)}
          hint={t("common.active")}
        />
        <AdminStatCard
          label={t("admin.admin_users_stat_vip")}
          value={String(vipCount)}
          hint="VIP"
        />
        <AdminStatCard label="Кошельки" value={String(walletCount)} hint="TON" />
      </div>


      <AdminUsersDashboardRuntime
        error={err}
        loading={loading}
        query={query}
        selected={selected}
        updatedAt="current search snapshot"
        users={items}
        onRefresh={() => void loadList(query)}
      />

      {err ? <TelegramEmptyState title="Ошибка user-контура" detail={err || undefined} /> : null}
      {loading && items.length === 0 ? (
        <TelegramEmptyState title={t("common.loading")} />
      ) : null}

      <div className="grid gap-4 md:grid-cols-2">
        <AdminListShell
          title={t("admin.users")}
          subtitle={t("admin.admin_users_list_detail")}
        >
          <div
            className="efhc-admin-table-wrap"
            data-admin-users-readable-table="1322"
          >
            <table className="efhc-admin-table">
              <thead>
                <tr>
                  <th>Пользователь</th>
                  <th>Статусы</th>
                  <th>Балансы</th>
                  <th>Кошелёк</th>
                  <th>Действие</th>
                </tr>
              </thead>
              <tbody>
                {items.map((u) => (
                  <tr key={u.global_id} data-admin-user-row="readable-1322">
                    <td data-label="Пользователь">
                      <div className="font-semibold">{userLabel(u.username)}</div>
                      <div className="text-xs opacity-70">Global ID {u.global_id}</div>
                    </td>
                    <td data-label="Статусы">
                      <div className="flex flex-wrap gap-1.5">
                        {u.is_vip ? (
                          <TelegramStatusBadge label="VIP" tone="vip" />
                        ) : (
                          <TelegramStatusBadge label="VIP off" tone="neutral" />
                        )}
                        <TelegramStatusBadge
                          label={u.is_active ? t("common.active") : t("common.inactive")}
                          tone={u.is_active ? "connected" : "neutral"}
                        />
                      </div>
                    </td>
                    <td data-label="Балансы">
                      <div className="text-xs">
                        main: {formatD8ToHuman(u.main_balance)}
                      </div>
                      <div className="text-xs opacity-75">
                        bonus: {formatD8ToHuman(u.bonus_balance)}
                      </div>
                    </td>
                    <td data-label="Кошелёк">
                      <TelegramStatusBadge
                        label={u.ton_wallet ? "TON" : "нет"}
                        tone={u.ton_wallet ? "connected" : "neutral"}
                      />
                      <div className="mt-1 text-xs opacity-70">
                        {shortWallet(u.ton_wallet)}
                      </div>
                    </td>
                    <td data-label="Действие">
                      <Button
                        variant="secondary"
                        onClick={() => void loadDetail(u.global_id)}
                        aria-label={`Открыть пользователя ${u.global_id}`}
                      >
                        Открыть
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!loading && items.length === 0 ? (
            <TelegramEmptyState
              title={t("admin.select_user_from_list")}
              detail="Список поиска пока пуст."
            />
          ) : null}
        </AdminListShell>

        {!selected ? (
          <TelegramEmptyState
            title={t("admin.select_user_from_list")}
            detail="Выберите пользователя из таблицы слева."
          />
        ) : (
          <>
            <section
              className="efhc-admin-user-risk-summary"
              data-admin-user-risk-summary="facts-only"
            >
              <strong>Security state · без автоматического score</strong>
              <div>
                <TelegramStatusBadge
                  label={selected.ton_wallet
                    ? "Wallet bound"
                    : "Wallet missing"}
                  tone={selected.ton_wallet
                    ? "connected"
                    : "warning"}
                />
                <TelegramStatusBadge
                  label={selected.is_active
                    ? "Active"
                    : "Restricted"}
                  tone={selected.is_active
                    ? "connected"
                    : "warning"}
                />
                <TelegramStatusBadge
                  label={selected.is_vip ? "VIP" : "VIP off"}
                  tone={selected.is_vip ? "vip" : "neutral"}
                />
                <TelegramStatusBadge
                  label={`Last seen ${formatDate(
                    selected.last_seen_at,
                  )}`}
                  tone="neutral"
                />
              </div>
              <small>
                Failed actions и withdrawal hold показываются только
                при наличии подтверждённого backend-контракта.
              </small>
            </section>
            <AdminDetailShell
              title={userLabel(selected.username)}
              subtitle={t("admin.admin_users_detail_detail")}
            >
              <div className="space-y-2">
                <TelegramSectionRow
                  compact
                  title={t("admin.global_id")}
                  subtitle={String(selected.global_id)}
                  rightSlot={(
                    <div className="flex items-center gap-2">
                      <TelegramStatusBadge
                        label={selected.is_vip ? "VIP" : "VIP off"}
                        tone={selected.is_vip ? "vip" : "neutral"}
                      />
                      <TelegramStatusBadge
                        label={selected.is_active ? t("common.active") : t("common.inactive")}
                        tone={selected.is_active ? "connected" : "neutral"}
                      />
                    </div>
                  )}
                />
                <TelegramSectionRow
                  compact
                  title={t("admin.ton_wallet")}
                  subtitle={selected.ton_wallet || t("admin.not_bound")}
                />
                <TelegramSectionRow
                  compact
                  title={t("admin.main_balance")}
                  subtitle={formatD8ToHuman(balances?.main || "0")}
                  rightSlot={<EfhcCoinIcon size={18} />}
                />
                <TelegramSectionRow
                  compact
                  title={t("admin.bonus_balance")}
                  subtitle={formatD8ToHuman(balances?.bonus || "0")}
                  rightSlot={<EfhcCoinIcon size={18} />}
                />
                <TelegramSectionRow
                  compact
                  title={t("admin.total_balance")}
                  subtitle={formatD8ToHuman(balances?.total || "0")}
                  rightSlot={<TelegramStatusBadge label="EFHC" tone="primary" />}
                />
                <TelegramSectionRow
                  compact
                  title="Доступно kWh"
                  subtitle={formatD8ToHuman(selected.available_kwh)}
                />
                <TelegramSectionRow
                  compact
                  title="Всего сгенерировано kWh"
                  subtitle={formatD8ToHuman(selected.total_generated_kwh)}
                />
                <TelegramSectionRow
                  compact
                  title="Последняя активность"
                  subtitle={formatDate(selected.last_seen_at)}
                />
              </div>
              <div
                className="mt-3 grid gap-2 md:grid-cols-2"
                data-admin-users-actions-audit='safe-1321'
                data-admin-users-safe-actions='view-only-1322'
              >
                <Button variant="secondary" href="/admin/bank">
                  Открыть банк
                </Button>
                <Button variant="secondary" href="/admin/logs">
                  Открыть логи
                </Button>
              </div>
              <div
                className="mt-3 grid gap-2 md:grid-cols-2"
                data-admin-users-sensitive-actions="operator-boundary-1322"
              >
                <Button
                  disabled={busyAction !== ""}
                  onClick={() => void setVip(selected.global_id, !selected.is_vip)}
                >
                  {busyAction === "vip"
                    ? t("admin.working")
                    : selected.is_vip
                      ? t("admin.remove_vip")
                      : t("admin.set_vip")}
                </Button>
                <Button
                  variant="secondary"
                  disabled={busyAction !== ""}
                  onClick={() => void setActive(selected.global_id, !selected.is_active)}
                >
                  {busyAction === "active"
                    ? t("admin.working")
                    : selected.is_active
                      ? t("admin.deactivate")
                      : t("admin.activate")}
                </Button>
                <Button
                  variant="secondary"
                  disabled={busyAction !== ""}
                  onClick={() => void resetWallet(selected.global_id)}
                >
                  {busyAction === "wallet"
                    ? t("admin.working")
                    : t("admin.reset_ton_wallet")}
                </Button>
              </div>
            </AdminDetailShell>
            <div data-admin-users-balance-correction="admin-transfer-only-1322">
              <AdminSettingsCard
                title="Корректировка баланса"
                subtitle="Денежное действие выполняется только через canonical /admin/transfer и требует подтверждения оператора."
              >
                <div
                  className="grid gap-2 md:grid-cols-2"
                  data-admin-users-transfer-form="confirmed-1322"
                >
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Направление
                    </span>
                    <select
                      className="efhc-input"
                      value={correction.direction}
                      onChange={(e) => setCorrection((prev) => ({
                        ...prev,
                        direction: e.target.value as TransferDirection,
                      }))}
                    >
                      <option value="credit">Банк → пользователь</option>
                      <option value="debit">Пользователь → банк</option>
                    </select>
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Баланс
                    </span>
                    <select
                      className="efhc-input"
                      value={correction.balance}
                      onChange={(e) => setCorrection((prev) => ({
                        ...prev,
                        balance: e.target.value as TransferBalance,
                      }))}
                    >
                      <option value="main">main</option>
                      <option value="bonus">bonus</option>
                    </select>
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Сумма EFHC
                    </span>
                    <input
                      className="efhc-input"
                      inputMode="decimal"
                      value={correction.amount}
                      onChange={(e) => setCorrection((prev) => ({
                        ...prev,
                        amount: e.target.value,
                      }))}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Причина
                    </span>
                    <input
                      className="efhc-input"
                      value={correction.reason}
                      onChange={(e) => setCorrection((prev) => ({
                        ...prev,
                        reason: e.target.value,
                      }))}
                    />
                  </label>
                </div>
                <label className="mt-3 flex items-start gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={operatorConfirmed}
                    onChange={(e) => setOperatorConfirmed(e.target.checked)}
                  />
                  <span>
                    Я проверил пользователя Global ID {selected.global_id}, направление,
                    баланс, сумму и причину корректировки.
                  </span>
                </label>
                <div className="mt-3 rounded-2xl border border-[color:var(--tg-hint)] p-3 text-xs opacity-90">
                  Preview: {correction.direction === "credit" ? "банк → пользователь" : "пользователь → банк"}; {correction.balance}; {normalizedAmount || "0"} EFHC.
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    onClick={() => void applyCorrection()}
                    disabled={busyAction !== "" || !canApplyCorrection}
                  >
                    {busyAction === "correction"
                      ? t("admin.working")
                      : "Применить корректировку"}
                  </Button>
                </div>
              </AdminSettingsCard>
            </div>
          </>
        )}
      </div>
    </AdminPage>
  );
}
