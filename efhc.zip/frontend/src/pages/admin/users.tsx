import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { format8 } from "../../lib/format";
import { EfhcCoinIcon } from "../../components/icons/EfhcCoin";

type UserItem = {
  tg_id: number;
  username?: string | null;
  is_active: boolean;
  is_vip: boolean;
  ton_wallet?: string | null;
  main_balance: string;
  bonus_balance: string;
  available_kwh: string;
  total_generated_kwh: string;
  last_seen_at?: string | null;
};

type UserDetail = UserItem & {
  created_at: string;
  updated_at: string;
  vip_checked_at?: string | null;
  vip_since?: string | null;
  last_sync_at?: string | null;
};

export default function AdminUsersPage() {
  const t = useT();
  const [q, setQ] = useState<string>("");
  const [items, setItems] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [err, setErr] = useState<string>("");
  const [selected, setSelected] = useState<UserDetail | null>(null);
  const [busyAction, setBusyAction] = useState<string>("");

  async function loadList(query: string) {
    setLoading(true);
    setErr("");
    try {
      const data = await apiRequest<UserItem[]>(
        `/admin/users/search?q=${encodeURIComponent(query)}`,
        "GET",
      );
      setItems(data);
      setSelected(null);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function loadDetail(tg: number) {
    setErr("");
    try {
      const data = await apiRequest<UserDetail>(
        `/admin/users/${tg}`,
        "GET",
      );
      setSelected(data);
    } catch (e: any) {
      setErr(String(e?.message || e));
    }
  }

  async function setVip(tg: number, isVip: boolean) {
    setBusyAction("vip");
    setErr("");
    try {
      const data = await apiRequest<UserDetail>(
        `/admin/users/${tg}/vip`,
        "PATCH",
        {
        idempotencyKey: newIdempotencyKey(),
        body: { is_vip: isVip },
      });
      setSelected(data);
      // refresh list snapshot
      await loadList(q);
      await loadDetail(tg);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  async function setActive(tg: number, isActive: boolean) {
    setBusyAction("active");
    setErr("");
    try {
      const data = await apiRequest<UserDetail>(
        `/admin/users/${tg}/active`,
        "PATCH",
        {
        idempotencyKey: newIdempotencyKey(),
        body: { is_active: isActive },
      });
      setSelected(data);
      await loadList(q);
      await loadDetail(tg);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  async function resetWallet(tg: number) {
    setBusyAction("wallet");
    setErr("");
    try {
      await apiRequest(`/admin/users/${tg}/wallet/reset`, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: {},
      });
      await loadDetail(tg);
      await loadList(q);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyAction("");
    }
  }

  useEffect(() => {
    // initial load
    loadList("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedBalances = useMemo(() => {
    if (!selected) return null;
    const main = Number(selected.main_balance || 0);
    const bonus = Number(selected.bonus_balance || 0);
    const total = main + bonus;
    return { main, bonus, total };
  }, [selected]);

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.users")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
  {t("admin.back")}
</Button>
        </Link>
      </div>

      <Card title={t("admin.users")}>
        <div className="grid gap-3">
          <div
            className="flex flex-col gap-2 md:flex-row md:items-center"
          >
            <input
              className={
                "w-full rounded-xl border border-white/10 " +
                "bg-white/5 px-3 py-2 text-sm outline-none"
              }
              placeholder="tg_id / username / ton_wallet"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") loadList(q);
              }}
            />
            <Button
  className="bg-white text-black"
  onClick={() => loadList(q)}
>
              Search
            </Button>
          </div>

          {err ? (
  <div className="text-sm text-red-400">{err}</div>
) : null}
          {loading ? (
  <div className="text-sm text-gray-400">Loading…</div>
) : null}

          <div className="grid gap-3 md:grid-cols-2">
            <div className="grid gap-2">
              <div className="text-xs text-gray-400">
  Results: {items.length}
</div>
              <div className={
                     "max-h-[60vh] overflow-auto rounded-xl border " +
                     "border-white/10"
                   }>
                {items.map((u) => (
                  <button
                    key={u.tg_id}
                    className={
                      "flex w-full items-center " +
                      "justify-between gap-3 " +

                      "border-b border-white/10 px-3 py-2 text-left " +
                      "hover:bg-white/5"
                    }
                    onClick={() => loadDetail(u.tg_id)}
                  >
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold">
                        {u.username ? (
  `@${u.username}`
) : (
  "(no username)"
)}
                      </div>
                      <div className="text-xs text-gray-400">
  TG: {u.tg_id}
</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {u.is_vip ? (
                        <span
                          className={
                            "rounded-full bg-yellow-500/20 " +
                            "px-2 py-1 text-xs"
                          }
                        >
                          VIP
                        </span>
                      ) : null}
                      {!u.is_active ? (
                        <span
  className="rounded-full bg-red-500/20 px-2 py-1 text-xs"
>
  INACTIVE
</span>
                      ) : null}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid gap-2">
              <div className="text-xs text-gray-400">User card</div>
              {!selected ? (
                <div className={
                       "rounded-xl border border-white/10 " +
                       "p-4 text-sm " +

                       "text-gray-400"
                     }>
                  Select a user from the list.
                </div>
              ) : (
                <div
                  className={
                    "grid gap-3 rounded-xl border " +
                    "border-white/10 p-4"
                  }
                >
                  <div
                    className="flex items-start justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-base font-bold">
                        {selected.username
                          ? `@${selected.username}`
                          : "(no username)"}
                      </div>
                      <div className="text-xs text-gray-400">
                        Telegram ID: {selected.tg_id}
                      </div>
                      {selected.ton_wallet ? (
                        <div
                          className={
                            "mt-1 break-all text-xs " +
                            "text-gray-400"
                          }
                        >
                          TON: {selected.ton_wallet}
                        </div>
                      ) : (
                        <div className="mt-1 text-xs text-gray-500">
                          TON: (not bound)
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                          className={
                            "rounded-full bg-yellow-500/20 " +
                            "px-2 py-1 text-xs"
                          }
                      {!selected.is_active ? (
                        <span
  className="rounded-full bg-red-500/20 px-2 py-1 text-xs"
>
  INACTIVE
</span>
                      ) : (
                        <span
                          className={
                            "rounded-full bg-green-500/20 " +
                            "px-2 py-1 text-xs"
                          }
                        >
                          ACTIVE
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Main EFHC
                      </div>
                      <div
                        className={
                          "font-semibold inline-flex items-center gap-2"
                        }
                      >
                        <EfhcCoinIcon size={18} />
                        <span>{format8(selected.main_balance)}</span>
                      </div>
                    </div>
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Bonus EFHC
                      </div>
                      <div
                        className={
                          "font-semibold inline-flex items-center gap-2"
                        }
                      >
                        <EfhcCoinIcon size={18} />
                        <span>{format8(selected.bonus_balance)}</span>
                      </div>
                    </div>
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Total EFHC
                      </div>
                      <div
                        className={
                          "font-semibold inline-flex items-center gap-2"
                        }
                      >
                        <EfhcCoinIcon size={18} />
                        <span>
                          {format8(selectedBalances?.total || 0)}
                        </span>
                      </div>
                    </div>
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Available kWh
                      </div>
                      <div className="font-semibold">
                        {format8(selected.available_kwh)}
                      </div>
                    </div>
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Total generated kWh
                      </div>
                      <div className="font-semibold">
                        {format8(selected.total_generated_kwh)}
                      </div>
                    </div>
                    <div className="rounded-xl bg-white/5 p-3">
                      <div className="text-xs text-gray-400">
                        Last seen
                      </div>
                      <div className="font-semibold">
                        {selected.last_seen_at
                          ? new Date(selected.last_seen_at)
                              .toLocaleString()
                          : "-"}
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2 md:grid-cols-2">
                    <Button
                      className="bg-white text-black"
                      disabled={busyAction !== ""}
                      onClick={() =>
                        setVip(selected.tg_id, !selected.is_vip)
                      }
                    >
                      {busyAction === "vip"
                        ? "Working…"
                        : selected.is_vip
                          ? "Remove VIP"
                          : "Set VIP"}
                    </Button>

                    <Button
                      className="bg-white text-black"
                      disabled={busyAction !== ""}
                      onClick={() =>
                        setActive(selected.tg_id, !selected.is_active)
                      }
                    >
                      {busyAction === "active"
                        ? "Working…"
                        : selected.is_active
                          ? "Deactivate"
                          : "Activate"}
                    </Button>

                    <Button
                      className="bg-white text-black"
                      disabled={
                        busyAction !== "" || !selected.ton_wallet
                      }
                      onClick={() => resetWallet(selected.tg_id)}
                    >
                      {busyAction === "wallet"
                        ? "Working…"
                        : "Reset TON wallet"}
                    </Button>

                    <Link href="/admin/bank">
                      <Button className="bg-white text-black">
                        Go to Bank
                      </Button>
                    </Link>
                  </div>

                  <div className="text-xs text-gray-500">
                    All admin actions use tg_id only.
                    Mutations require Idempotency-Key.
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
