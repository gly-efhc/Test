import React from "react";
import { Card } from "../../components/ui/Card";
import { AdminPage } from "../../components/admin/AdminPage";

export default function AdminTasksPage() {
  return (
    <AdminPage title="Admin: Tasks" backHref="/admin">
      <Card title="Status">
        <div className="text-sm efhc-text-muted">
          Admin page is temporarily disabled in this build.
        </div>
      </Card>
    </AdminPage>
  );
}
