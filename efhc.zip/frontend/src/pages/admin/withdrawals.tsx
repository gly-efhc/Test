import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";
/* Compatibility marker: Refresh selected case */
/* Compatibility marker: Repair consistency */
import React, { useEffect, useMemo, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminDetailShell } from "../../components/admin/AdminDetailShell";
import { AdminListShell } from "../../components/admin/AdminListShell";
import { AdminWithdrawalsMobileDecisionPanel } from "../../components/admin/AdminWithdrawalsMobileDecisionPanel";
import { AdminWithdrawalsDashboardRuntime } from "../../components/admin/AdminWithdrawalsDashboardRuntime";
import { Button } from "../../components/ui/Button";
import {
  adminPath,
  ADMIN_WITHDRAWALS_PATH,
  ADMIN_WITHDRAW_OUTCOME_PREVIEW_PATH,
  type AdminWithdrawOutcomePreviewResponse,
} from "../../lib/api/generated/adminSeams";
import {
  ensureAdminWithdrawApproveRequest,
  ensureAdminWithdrawRejectRequest,
  parseAdminWithdrawalListResponse,
  parseAdminWithdrawActionResponse,
  parseAdminWithdrawOutcomePreviewResponse,
} from "../../lib/api/generated/adminSeamValidators";
import { useT } from "../../hooks/useT";
import { formatD8ToHuman } from "../../lib/format";
import {
  adminWithdrawOutcomeLabel,
  adminWithdrawStatusLabel,
} from "../../lib/humanLabels";
import { buildEfhcWithdrawTonConnectTx } from "../../lib/ton/efhc-withdraw-transfer";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useWalletProvider } from "../../lib/wallet-provider";

type Withdrawal = ReturnType<typeof parseAdminWithdrawalListResponse>[number];

type PendingAction =
  | { kind: "approve"; item: Withdrawal }
  | { kind: "reject"; item: Withdrawal };

function newIdk(prefix: string) {
  const c: any = globalThis.crypto;
  const fallback = `${Date.now()}-${Math.random()}`;
  const uuid = c?.randomUUID ? c.randomUUID() : fallback;
  return `${prefix}:${uuid}`;
}

function buildWithdrawPayoutRef(provider: string): string {
  const stamp = new Date()
    .toISOString()
    .replace(/[^0-9]/g, "")
    .slice(0, 14);
  return `wallet-send:${provider}:${stamp}`;
}

export default function AdminWithdrawalsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [items, setItems] = useState<Withdrawal[]>([]);
  const [dashboardItems, setDashboardItems] = useState<Withdrawal[]>([]);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [dashboardError, setDashboardError] = useState<string | null>(null);
  const [dashboardUpdatedAt, setDashboardUpdatedAt] = useState<string | null>(
    null,
  );
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("PENDING");
  const [vipOnly, setVipOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<PendingAction | null>(null);
  const {
    address: walletAddress,
    providerName: walletProviderName,
    connect: connectWallet,
    sendTransaction,
  } = useWalletProvider();
  const [payingId, setPayingId] = useState<number | null>(null);
  const [confirmForm, setConfirmForm] = useState<Record<string, string>>({
    reason: "",
  });
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [previewMode, setPreviewMode] = useState<string>("auto");
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [preview, setPreview] =
    useState<AdminWithdrawOutcomePreviewResponse | null>(null);
  const [repairBusy, setRepairBusy] = useState(false);
  const [repairNote, setRepairNote] = useState<string | null>(null);

  const query = useMemo(() => {
    const q = new URLSearchParams();
    if (status) q.set("status", status);
    if (vipOnly) q.set("vip_only", "true");
    q.set("limit", "200");
    q.set("offset", "0");
    return q.toString();
  }, [status, vipOnly]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApiRequest<unknown>(
        `${ADMIN_WITHDRAWALS_PATH}?${query}`,
        "GET",
      );
      setItems(parseAdminWithdrawalListResponse(res));
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function loadDashboardSnapshots() {
    setDashboardLoading(true);
    setDashboardError(null);
    try {
      const statuses = ["PENDING", "PAID", "REJECTED", "CANCELED"];
      const batches = await Promise.all(
        statuses.map(async (nextStatus) => {
          const q = new URLSearchParams();
          q.set("status", nextStatus);
          if (vipOnly) q.set("vip_only", "true");
          q.set("limit", "200");
          q.set("offset", "0");
          const raw = await adminApiRequest<unknown>(
            `${ADMIN_WITHDRAWALS_PATH}?${q.toString()}`,
            "GET",
          );
          return parseAdminWithdrawalListResponse(raw);
        }),
      );
      setDashboardItems(batches.flat());
      setDashboardUpdatedAt(new Date().toISOString());
    } catch (e: any) {
      setDashboardItems([]);
      setDashboardError(adminSafeLoadError(e, t));
    } finally {
      setDashboardLoading(false);
    }
  }

  async function loadPreview(item: Withdrawal, mode: string = previewMode) {
    setPreviewLoading(true);
    setPreviewError(null);
    try {
      const path = ADMIN_WITHDRAW_OUTCOME_PREVIEW_PATH.replace(
        "{request_id}",
        String(item.id),
      );
      const raw = await adminApiRequest<unknown>(
        `${path}?mode=${encodeURIComponent(mode)}`,
        "GET",
      );
      setPreview(parseAdminWithdrawOutcomePreviewResponse(raw));
    } catch (e: any) {
      setPreview(null);
      setPreviewError(adminUiErrorMessage(e, t));
    } finally {
      setPreviewLoading(false);
    }
  }

  async function refreshSelectedCase(requestId: number | null = selectedId) {
    await load();
    await loadDashboardSnapshots();
    const nextId = requestId ?? null;
    if (nextId !== null) {
      setSelectedId(nextId);
      const current = items.find((item) => item.id === nextId);
      if (current) {
        await loadPreview(current, previewMode);
      }
    }
  }

  async function repairConsistency() {
    setRepairBusy(true);
    setRepairNote(null);
    setError(null);
    try {
      const raw = await adminApiRequest<unknown>(
        `${ADMIN_WITHDRAWALS_PATH}/repair-consistency`,
        "POST",
        {
          idempotencyKey: newIdk("admin-withdraw-repair"),
          body: {},
        },
      );
      const out = raw as {
        ok?: boolean;
        auto_fixed_hold?: number;
        auto_fixed_refund?: number;
      };
      setRepairNote(
        `Repair run: hold ${String(out.auto_fixed_hold ?? 0)}, ` +
          `refund ${String(out.auto_fixed_refund ?? 0)}.`,
      );
      await load();
      if (selected) {
        await loadPreview(selected, previewMode);
      }
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setRepairBusy(false);
    }
  }

  useEffect(() => {
    void load();
  }, [query]);

  useEffect(() => {
    void loadDashboardSnapshots();
  }, [vipOnly]);

  useEffect(() => {
    if (!items.length) {
      setSelectedId(null);
      return;
    }
    if (!items.some((item) => item.id === selectedId)) {
      setSelectedId(items[0].id);
    }
  }, [items, selectedId]);

  const selectedSummary = pending
    ? [
        `Заявка: №${pending.item.id}`,
        `Пользователь: ${pending.item.tg_id}`,
        `Сумма: ${formatD8ToHuman(pending.item.amount_efhc)} EFHC`,
        `Кошелёк: ${pending.item.external_address || "—"}`,
        `Статус: ${adminWithdrawStatusLabel(pending.item.status)}`,
      ].join("\n")
    : "";

  const selected = useMemo(
    () => items.find((item) => item.id === selectedId) || null,
    [items, selectedId],
  );

  useEffect(() => {
    if (!selected) {
      setPreview(null);
      return;
    }
    void loadPreview(selected, previewMode);
  }, [selected, previewMode]);

  function openApprove(item: Withdrawal) {
    setPending({ kind: "approve", item });
    setConfirmForm({ reason: "" });
  }

  function openReject(item: Withdrawal) {
    setPending({ kind: "reject", item });
    setConfirmForm({ reason: "" });
  }

  async function payWithWallet(item: Withdrawal) {
    if (!item.external_address) {
      setError("У заявки нет адреса кошелька для выплаты.");
      return;
    }
    if (!walletAddress) {
      try {
        await connectWallet();
      } catch (e: any) {
        setError(adminSafeLoadError(e, t));
      }
      return;
    }
    setPayingId(item.id);
    setError(null);
    try {
      const endpoint =
        process.env.NEXT_PUBLIC_TON_RPC_ENDPOINT ||
        "https://toncenter.com/api/v2/jsonRPC";
      const tx = await buildEfhcWithdrawTonConnectTx({
        endpoint,
        senderOwnerAddress: walletAddress,
        recipientOwnerAddress: item.external_address,
        amountEfhc: item.amount_efhc,
        feeMessageTonAmount: item.fee_message_ton_amount || "50000000",
      });
      const provider = walletProviderName;
      await sendTransaction(tx);
      const approveBody = ensureAdminWithdrawApproveRequest({
        payout_ref: buildWithdrawPayoutRef(provider),
        wallet_send_confirmed: true,
        wallet_provider: provider,
        sender_wallet_address: walletAddress,
      });
      const approveOut = await adminApiRequest<unknown>(
        `${ADMIN_WITHDRAWALS_PATH}/${item.id}/approve`,
        "POST",
        {
          idempotencyKey: newIdk(`admin-withdraw-approve-${item.id}`),
          body: approveBody,
        },
      );
      parseAdminWithdrawActionResponse(approveOut);
      await refreshSelectedCase(item.id);
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setPayingId(null);
    }
  }

  async function submitAction() {
    if (!pending) return;
    const item = pending.item;
    const reason = confirmForm.reason.trim();
    if (pending.kind === "reject" && !reason) return;
    setLoading(true);
    setError(null);
    try {
      if (pending.kind === "approve") {
        const approveBody = ensureAdminWithdrawApproveRequest({
          comment_override: reason || undefined,
          comment_auto_translated: false,
        });
        const approveOut = await adminApiRequest<unknown>(
          `${ADMIN_WITHDRAWALS_PATH}/${item.id}/approve`,
          "POST",
          {
            idempotencyKey: newIdk(`admin-withdraw-approve-${item.id}`),
            body: approveBody,
          },
        );
        parseAdminWithdrawActionResponse(approveOut);
      } else {
        const rejectBody = ensureAdminWithdrawRejectRequest({
          reason,
          comment_override: reason,
          comment_auto_translated: false,
        });
        const rejectOut = await adminApiRequest<unknown>(
          `${ADMIN_WITHDRAWALS_PATH}/${item.id}/reject`,
          "POST",
          {
            idempotencyKey: newIdk(`admin-withdraw-reject-${item.id}`),
            body: rejectBody,
          },
        );
        parseAdminWithdrawActionResponse(rejectOut);
      }
      setPending(null);
      setConfirmForm({ reason: "" });
      await refreshSelectedCase(item.id);
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AdminPage
      title={t("admin.withdrawals")}
      subtitle={
        t("admin.withdrawals_note") +
        " · Outcome preview stays inside the case screen"
      }
      backHref="/admin"
    >
      <AdminWithdrawalsDashboardRuntime
        items={dashboardItems}
        currentItems={items}
        selected={selected}
        activeStatus={status}
        vipOnly={vipOnly}
        loading={dashboardLoading || loading}
        error={dashboardError || error}
        updatedAt={dashboardUpdatedAt || undefined}
        onRefresh={() => {
          void loadDashboardSnapshots();
          void load();
        }}
      />

      <AdminWithdrawalsMobileDecisionPanel
        items={items}
        selected={selected}
        selectedId={selectedId}
        status={status}
        vipOnly={vipOnly}
        loading={loading}
        repairBusy={repairBusy}
        repairNote={repairNote}
        previewMode={previewMode}
        previewLoading={previewLoading}
        preview={preview}
        onStatusChange={setStatus}
        onVipOnlyChange={setVipOnly}
        onSelect={setSelectedId}
        onRefresh={() => {
          void refreshSelectedCase();
        }}
        onRepair={() => {
          void repairConsistency();
        }}
        onPreviewModeChange={setPreviewMode}
      />

      {error ? (
        <TelegramEmptyState
          title={t("admin.admin_withdraw_error_title")}
          detail={error || undefined}
        />
      ) : null}

      {!loading && items.length === 0 ? (
        <TelegramEmptyState
          title={t("admin.admin_withdraw_empty_title")}
          detail={t("admin.admin_withdraw_empty_detail")}
        />
      ) : null}

      {items.length > 0 ? (
        <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
          <AdminListShell
            title={t("admin.withdrawals")}
            subtitle={t("admin.admin_withdraw_list_detail")}
            actions={
              <label className="efhc-admin-toggle px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={vipOnly}
                  onChange={(e) => setVipOnly(e.target.checked)}
                />
                {t("admin.vip_only")}
              </label>
            }
          >
            {items.map((w) => (
              <TelegramSectionRow
                key={w.id}
                title={`#${w.id} · tg_id ${w.tg_id}`}
                subtitle={
                  `${formatD8ToHuman(w.amount_efhc)} EFHC · ` +
                  `${w.external_address || "Кошелёк не указан"}`
                }
                className={
                  selectedId === w.id
                    ? "ring-1 ring-[color:var(--tg-link)]"
                    : ""
                }
                onClick={() => setSelectedId(w.id)}
                rightSlot={
                  <div className="flex items-center gap-2">
                    {w.is_vip ? (
                      <TelegramStatusBadge label="VIP" tone="vip" />
                    ) : null}
                    <TelegramStatusBadge
                      label={adminWithdrawStatusLabel(w.status)}
                      tone={
                        w.status === "PAID"
                          ? "connected"
                          : w.status === "PENDING"
                            ? "warning"
                            : "neutral"
                      }
                    />
                  </div>
                }
              />
            ))}
          </AdminListShell>

          <AdminDetailShell
            title={selected ? `#${selected.id}` : t("admin.withdrawals")}
            subtitle={
              "Правая колонка показывает заявку и предпросмотр результата."
            }
          >
            {selected ? (
              <>
                <TelegramSectionRow
                  compact
                  title="Telegram ID"
                  subtitle={String(selected.tg_id)}
                />
                <TelegramSectionRow
                  compact
                  title="Сумма"
                  subtitle={`${formatD8ToHuman(selected.amount_efhc)} EFHC`}
                  rightSlot={
                    <TelegramStatusBadge
                      label={adminWithdrawStatusLabel(selected.status)}
                      tone="primary"
                    />
                  }
                />
                <TelegramSectionRow
                  compact
                  title="Кошелёк"
                  subtitle={selected.external_address || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="Создано"
                  subtitle={selected.created_at}
                />
                <TelegramSectionRow
                  compact
                  title="Обработано"
                  subtitle={selected.processed_at || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="Хеш транзакции"
                  subtitle={selected.tx_hash || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="Статус раздела"
                  subtitle={selected.error_message || "—"}
                />

                {/* Compatibility marker: Operator regression */}
                <TelegramInfoBlock
                  title="Регрессия оператора"
                  description={
                    "Используйте обновление, предпросмотр и восстановление " +
                    "согласованности в повторных или конфликтных кейсах " +
                    "до второго действия оператора."
                  }
                />

                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    onClick={() => {
                      void refreshSelectedCase(selected.id);
                    }}
                    disabled={loading || previewLoading}
                  >
                    Обновить выбранный кейс
                  </Button>
                </div>

                <TelegramInfoBlock
                  title="Предпросмотр результата"
                  description={
                    "Предпросмотр заявки остаётся прямо внутри /admin/withdrawals " +
                    "по утверждённому канону."
                  }
                >
                  <div className="mt-3 space-y-2">
                    <div className="flex flex-wrap gap-2">
                      {[
                        ["auto", "Авто"],
                        ["success", "Успех"],
                        ["reject", "Отклонение"],
                      ].map(([key, label]) => (
                        <Button
                          key={key}
                          variant={
                            previewMode === key ? "primary" : "secondary"
                          }
                          onClick={() => setPreviewMode(key)}
                          disabled={previewLoading}
                        >
                          {label}
                        </Button>
                      ))}
                    </div>
                    {previewError ? (
                      <TelegramEmptyState
                        title="Предпросмотр недоступен"
                        detail={previewError}
                      />
                    ) : null}
                    {previewLoading ? (
                      <TelegramEmptyState title="Предпросмотр загружается" />
                    ) : null}
                    {preview ? (
                      <>
                        <TelegramSectionRow
                          compact
                          title="Режим"
                          subtitle={
                            preview.preview_mode === "auto"
                              ? "Автоматический"
                              : preview.preview_mode === "success"
                                ? "Успешный"
                                : "Отклонение"
                          }
                          rightSlot={
                            <TelegramStatusBadge
                              label={adminWithdrawOutcomeLabel(
                                preview.bundle.outcome_kind,
                              )}
                              tone={
                                preview.bundle.outcome_kind === "success"
                                  ? "connected"
                                  : "warning"
                              }
                            />
                          }
                        />
                        <TelegramSectionRow
                          compact
                          title="Комментарий"
                          subtitle={preview.bundle.comment.text}
                        />
                        {preview.bundle.top_zone_enabled &&
                        preview.bundle.promo ? (
                          <>
                            <TelegramSectionRow
                              compact
                              title="Заголовок промозоны"
                              subtitle={preview.bundle.promo.title || "—"}
                            />
                            <TelegramSectionRow
                              compact
                              title="CTA промозоны"
                              subtitle={preview.bundle.promo.cta_label || "—"}
                            />
                          </>
                        ) : (
                          <TelegramSectionRow
                            compact
                            title="Промозона"
                            subtitle="Отключено для этого предпросмотра."
                          />
                        )}
                      </>
                    ) : null}
                  </div>
                </TelegramInfoBlock>

                {selected.status === "PENDING" ||
                selected.status === "ERROR" ? (
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => void payWithWallet(selected)}
                      disabled={loading || payingId === selected.id}
                    >
                      {payingId === selected.id ? "Оплата..." : "Оплатить"}
                    </Button>
                    <Button
                      onClick={() => openApprove(selected)}
                      disabled={loading}
                    >
                      Одобрить
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => openReject(selected)}
                      disabled={loading}
                    >
                      Отклонение
                    </Button>
                  </div>
                ) : null}
              </>
            ) : (
              <TelegramEmptyState title="Выберите заявку" />
            )}
          </AdminDetailShell>
        </div>
      ) : null}

      <AdminPromptModal
        open={pending !== null}
        title={
          pending?.kind === "approve"
            ? "Подтвердить одобрение"
            : "Подтвердить отклонение"
        }
        submitLabel={
          pending?.kind === "approve"
            ? "Подтвердить одобрение"
            : "Подтвердить отклонение"
        }
        fields={[
          { key: "summary", label: "Контекст", type: "textarea" },
          {
            key: "reason",
            label:
              pending?.kind === "approve"
                ? "Аудит-заметка"
                : t("admin.reject_reason_prompt"),
            type: "textarea",
          },
        ]}
        values={{
          summary: selectedSummary,
          reason: confirmForm.reason,
        }}
        onChange={(key, value) => {
          if (key === "reason") setConfirmForm({ reason: value });
        }}
        onClose={() => setPending(null)}
        onSubmit={() => {
          void submitAction();
        }}
        busy={Boolean(pending?.kind === "reject" && !confirmForm.reason.trim())}
      />
    </AdminPage>
  );
}
