import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { format8 } from "../../lib/format";

type Withdrawal = {
  id: number;
  tg_id: number;
  amount_efhc: string;
  status: string;
  external_address?: string | null;
  tx_hash?: string | null;
  created_at: string;
  processed_at?: string | null;
  error_message?: string | null;
  is_vip: boolean;
};

function newIdk(prefix: string) {
  const c: any = globalThis.crypto;
  const uuid = c?.randomUUID ? c.randomUUID() : `${Date.now()}-${Math.random()}`;
  return `${prefix}:${uuid}`;
}

export default function AdminWithdrawalsPage() {
  const t = useT();
  const [items, setItems] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("PENDING");
  const [vipOnly, setVipOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rejectId, setRejectId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState<Record<string, string>>({
    reason: "",
  });

  const query = useMemo(() => {
    const q = new URLSearchParams();
    if (status) q.set("status", status);
    if (vipOnly) q.set("vip_only", "true");
    q.set("limit", "200");
    q.set("offset", "0");
    return q.toString();
  }, [status, vipOnly]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(`/admin/withdrawals?${query}`, "GET");
      setItems(Array.isArray(res) ? res : []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [query]);

  async function approve(id: number) {
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(`/admin/withdrawals/${id}/approve`, "POST", {
        idempotencyKey: newIdk(`admin-withdraw-approve-${id}`),
        body: {},
      });
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function reject() {
    if (!rejectId) return;
    const reason = rejectReason.reason.trim();
    if (!reason) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(`/admin/withdrawals/${rejectId}/reject`, "POST", {
        idempotencyKey: newIdk(`admin-withdraw-reject-${rejectId}`),
        body: { reason },
      });
      setRejectId(null);
      setRejectReason({ reason: "" });
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AdminPage title={t("admin.withdrawals")} backHref="/admin">
      <Card title={t("admin.withdrawals")}>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <label className="text-sm">
            {t("admin.filter_status")}
            <select
              className="ml-2 efhc-input text-sm"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="PENDING">PENDING</option>
              <option value="PAID">PAID</option>
              <option value="REJECTED">REJECTED</option>
              <option value="ERROR">ERROR</option>
            </select>
          </label>
          <label className="flex items-center gap-2 rounded-2xl efhc-pill px-3 py-2 text-sm">
            <input
              type="checkbox"
              checked={vipOnly}
              onChange={(e) => setVipOnly(e.target.checked)}
            />
            {t("admin.vip_only")}
          </label>
          <Button onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? <div className="efhc-admin-error mb-2">{error}</div> : null}
        <div className="efhc-admin-table-wrap">
          <table className="efhc-admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>TG</th>
                <th>Amount</th>
                <th>Status</th>
                <th>VIP</th>
                <th>Address</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((w) => (
                <tr key={w.id}>
                  <td>{w.id}</td>
                  <td>{w.tg_id}</td>
                  <td className="tabular-nums">{format8(w.amount_efhc)}</td>
                  <td>{w.status}</td>
                  <td>{w.is_vip ? "VIP" : ""}</td>
                  <td>{w.external_address || ""}</td>
                  <td>{w.created_at}</td>
                  <td>
                    {w.status === "PENDING" || w.status === "ERROR" ? (
                      <div className="flex gap-2">
                        <Button disabled={loading} onClick={() => void approve(w.id)}>
                          {t("admin.approve")}
                        </Button>
                        <Button
                          variant="secondary"
                          disabled={loading}
                          onClick={() => setRejectId(w.id)}
                        >
                          {t("admin.reject")}
                        </Button>
                      </div>
                    ) : (
                      <span className="text-xs efhc-text-muted">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <AdminPromptModal
        open={rejectId !== null}
        title={t("admin.reject")}
        submitLabel={t("admin.reject")}
        fields={[
          {
            key: "reason",
            label: t("admin.reject_reason_prompt") || "Reason",
            type: "textarea",
          },
        ]}
        values={rejectReason}
        busy={loading}
        onChange={(key, value) => {
          setRejectReason((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => {
          setRejectId(null);
          setRejectReason({ reason: "" });
        }}
        onSubmit={() => {
          void reject();
        }}
      />
    </AdminPage>
  );
}
