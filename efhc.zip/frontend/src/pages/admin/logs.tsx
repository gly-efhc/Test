import React, { useEffect, useState } from "react";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { AdminPage } from "../../components/admin/AdminPage";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

type TransferLogItem = {
  id: number;
  tg_id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  idempotency_key: string;
  created_at: string;
};

type TransferLogsOut = {
  ok: boolean;
  items: TransferLogItem[];
  next_cursor?: string | null;
};

export default function AdminLogsPage() {
  const t = useT();
  const [tgId, setTgId] = useState("");
  const [reason, setReason] = useState("");
  const [items, setItems] = useState<TransferLogItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function load(reset: boolean) {
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams();
      if (tgId.trim()) params.set("tg_id", tgId.trim());
      if (reason.trim()) params.set("reason", reason.trim());
      params.set("limit", "100");
      if (!reset && cursor) params.set("cursor", cursor);
      const data = await apiRequest<TransferLogsOut>(
        `/admin/logs/transfers?${params.toString()}`,
        "GET",
      );
      setItems((prev) => (reset ? data.items || [] : [...prev, ...(data.items || [])]));
      setNextCursor(data.next_cursor || null);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    setCursor(null);
    void load(true);
  }, []);

  return (
    <AdminPage title={t("admin.logs")} backHref="/admin">
      <Card title={t("admin.logs")}>
        <div className="grid gap-3">
          <div className="grid gap-2 md:grid-cols-3">
            <input
              className="efhc-input"
              placeholder="tg_id (optional)"
              value={tgId}
              onChange={(e) => setTgId(e.target.value)}
            />
            <input
              className="efhc-input"
              placeholder="reason (optional)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
            <Button
              onClick={() => {
                setCursor(null);
                void load(true);
              }}
            >
              Refresh
            </Button>
          </div>
          {err ? <div className="efhc-admin-error">{err}</div> : null}
          {loading ? <div className="text-sm efhc-text-muted">Loading…</div> : null}
          <div className="efhc-admin-table-wrap">
            <table className="efhc-admin-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>tg_id</th>
                  <th>Amount</th>
                  <th>Type</th>
                  <th>Direction</th>
                  <th>Reason</th>
                  <th>Idempotency</th>
                </tr>
              </thead>
              <tbody>
                {items.map((x) => (
                  <tr key={x.id}>
                    <td>{new Date(x.created_at).toLocaleString()}</td>
                    <td className="font-mono text-xs">{x.tg_id}</td>
                    <td className="font-mono text-xs">{x.amount}</td>
                    <td>{x.balance_type}</td>
                    <td>{x.direction}</td>
                    <td>{x.reason}</td>
                    <td className="break-all font-mono text-[10px]">
                      {x.idempotency_key}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center gap-2">
            <Button
              disabled={!nextCursor || loading}
              onClick={() => {
                if (!nextCursor) return;
                setCursor(nextCursor);
                void load(false);
              }}
            >
              Load more
            </Button>
            <div className="text-xs efhc-text-muted">
              Cursor pagination via cursor_codec SSOT.
            </div>
          </div>
        </div>
      </Card>
    </AdminPage>
  );
}
