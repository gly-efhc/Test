export { default } from "../../features/admin/AdminHubPage";
