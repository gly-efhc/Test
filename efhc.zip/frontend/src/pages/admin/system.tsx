import React from "react";

import { AdminSystemHealthDashboardRuntime } from "../../components/admin/AdminSystemHealthDashboardRuntime";
import {
  AdminFunctionalPageTemplate,
} from "../../components/admin/AdminFunctionalPageTemplate";
import { AdminPage } from "../../components/admin/AdminPage";
import { Button } from "../../components/ui/Button";

export default function AdminSystemPage() {
  return (
    <AdminPage
      title="Система"
      subtitle="Системный раздел операторской панели EFHC."
      backHref="/admin"
      surfaceBadges={[
        { label: "Русский операторский контур", tone: "primary" },
        { label: "Debug только в Diagnostics", tone: "connected" },
      ]}
    >
      <AdminSystemHealthDashboardRuntime />
      <AdminFunctionalPageTemplate
        title="Системный контур"
        subtitle="Замки, правила и состояние системной оболочки."
        stats={[
          { label: "Канонических разделов", value: 8 },
          { label: "Debug-блоков на главной", value: 0 },
          { label: "Нижних меню в Admin", value: 0 },
        ]}
        actions={(
          <div className="flex flex-wrap gap-2">
            <Button href="/admin/diagnostics" variant="secondary">
              Диагностика
            </Button>
            <Button href="/admin/reports" variant="secondary">
              Отчёты
            </Button>
          </div>
        )}
        rows={[
          { label: "Главная Admin", value: "Плитки разделов" },
          { label: "Служебные данные", value: "Diagnostics" },
          { label: "Язык", value: "Русский" },
        ]}
      />
    </AdminPage>
  );
}
