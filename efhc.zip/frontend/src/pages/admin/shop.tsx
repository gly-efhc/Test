import React, { useEffect, useMemo, useRef, useState } from "react";

import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminSectionCard } from "../../components/admin/AdminSectionCard";
import { AdminSettingsCard } from "../../components/admin/AdminSettingsCard";
import { AdminShopWeb3SeparationPanel } from "../../components/admin/AdminShopWeb3SeparationPanel";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { AdminSurfaceTabs } from "../../components/admin/AdminSurfaceTabs";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { adminShopStatusLabel } from "../../lib/humanLabels";
import { newIdempotencyKey } from "../../lib/idempotency";
import { TelegramCategoryPills } from "../../components/ui/telegram/TelegramCategoryPills";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramProductCard } from "../../components/ui/telegram/TelegramProductCard";
import { TelegramSearchBar } from "../../components/ui/telegram/TelegramSearchBar";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import {
  adminPath,
  ADMIN_SHOP_ORDERS_PATH,
  ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH,
  ADMIN_SHOP_ITEMS_PATH,
  ADMIN_SHOP_ORDER_LEGACY_ORDER_ID_PATH,
  ADMIN_SHOP_ORDERS_USER_LEGACY_TG_ID_PATH,
  ADMIN_SHOP_ITEMS_UPSERT_PATH,
  ADMIN_SHOP_ITEMS_STATUS_PATH,
  ADMIN_SHOP_ITEMS_DELETE_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type AdminOrdersResponse = {
  items?: Array<Record<string, unknown>>;
  next_cursor?: string | null;
};

type CatalogItem = {
  id?: number;
  sku: string;
  code?: string;
  title: string;
  description: string | null;
  item_type: string;
  active?: boolean;
  is_active?: boolean;
  status?: string;
  quantity_efhc?: string;
  image_url?: string;
  price_ton?: string;
  price_usdt?: string;
  pay_currencies?: string[];
  created_at?: string | null;
  updated_at?: string | null;
  history_count?: number;
  history_tail?: Array<Record<string, unknown>>;
  methods: Record<string, { price?: string }> | null;
};

type LegacyOrder = {
  order_id: number;
  tg_id?: number | null;
  status: string;
  type: string;
  tx_hash?: string | null;
  memo?: string | null;
};

type ShopEditorState = {
  code: string;
  price_ton: string;
  price_usdt: string;
  is_active: boolean;
  status: string;
  title: string;
  description: string;
  image_url: string;
  item_type: string;
  quantity_efhc: string;
};

type HistoryEntry = {
  id: string;
  at: string;
  title: string;
  detail: string;
  tone: "neutral" | "connected" | "warning" | "primary";
};

const EDITOR_DEFAULT: ShopEditorState = {
  code: "",
  price_ton: "",
  price_usdt: "",
  is_active: true,
  status: "draft",
  title: "",
  description: "",
  image_url: "",
  item_type: "EFHC_PACKAGE",
  quantity_efhc: "",
};

function formatUnknown(value: unknown): string {
  if (value == null) return "—";
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  if (typeof value === "boolean") return value ? "true" : "false";
  return JSON.stringify(value);
}

function statusOf(item: CatalogItem): string {
  return item.status || ((item.active ?? item.is_active) ? "live" : "hidden");
}

function historyId(): string {
  return `${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
}

function toEditor(item: CatalogItem): ShopEditorState {
  return {
    code: item.code || item.sku,
    title: item.title,
    description: item.description || "",
    item_type: item.item_type || "EFHC_PACKAGE",
    quantity_efhc: item.quantity_efhc || "",
    image_url: item.image_url || "",
    price_ton: item.price_ton || item.methods?.TON?.price || "",
    price_usdt: item.price_usdt || item.methods?.USDT?.price || "",
    status: statusOf(item),
    is_active: statusOf(item) === "live",
  };
}

export default function AdminShopPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [orders, setOrders] = useState<Array<Record<string, unknown>>>([]);
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [legacyOrder, setLegacyOrder] = useState<LegacyOrder | null>(null);
  const [legacyUserOrders, setLegacyUserOrders] = useState<LegacyOrder[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [fulfillModalOpen, setFulfillModalOpen] = useState(false);
  const [fulfillForm, setFulfillForm] = useState({ order_id: "", reason: "manual force fulfill" });
  const [orderForm, setOrderForm] = useState({ order_id: "" });
  const [userForm, setUserForm] = useState({ tg_id: "" });
  const [createForm, setCreateForm] = useState({
    code: "",
    title: "",
    description: "",
    item_type: "EFHC_PACKAGE",
    quantity_efhc: "",
    image_url: "",
    price_ton: "",
    price_usdt: "",
    status: "draft",
  });
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortMode, setSortMode] = useState("updated_desc");
  const [selectedSku, setSelectedSku] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("catalog");
  const [paymentLane, setPaymentLane] = useState("ton");
  const [selectedCodes, setSelectedCodes] = useState<string[]>([]);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [deleteQueue, setDeleteQueue] = useState<string[]>([]);
  const [historyByCode, setHistoryByCode] = useState<
    Record<string, HistoryEntry[]>
  >({});
  const [editor, setEditor] = useState<ShopEditorState>(EDITOR_DEFAULT);
  const [editorBaseline, setEditorBaseline] = useState<ShopEditorState | null>(
    null,
  );
  const editorUploadRef = useRef<HTMLInputElement | null>(null);
  const createUploadRef = useRef<HTMLInputElement | null>(null);

  function pushHistory(
    code: string,
    title: string,
    detail: string,
    tone: HistoryEntry["tone"] = "neutral",
  ) {
    const entry: HistoryEntry = {
      id: historyId(),
      at: new Date().toISOString(),
      title,
      detail,
      tone,
    };
    setHistoryByCode((prev) => ({
      ...prev,
      [code]: [entry, ...(prev[code] || [])].slice(0, 20),
    }));
  }

  async function loadOrders() {
    setLoading(true);
    setMessage(null);
    try {
      const res = await adminApiRequest<AdminOrdersResponse>(
        ADMIN_SHOP_ORDERS_PATH,
        "GET",
      );
      setOrders(res.items || []);
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setLoading(false);
    }
  }


  async function forceFulfillOrder() {
    setLoading(true);
    setMessage(null);
    try {
      const orderId = Number(fulfillForm.order_id);
      await adminApiRequest(
        adminPath(ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH, {
          order_id: orderId,
        }),
        "POST",
        {
        body: { reason: fulfillForm.reason.trim() || "manual force fulfill" },
        idempotencyKey: newIdempotencyKey(),
      });
      setFulfillModalOpen(false);
      await loadOrders();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function loadCatalog() {
    try {
      const res = await adminApiRequest<CatalogItem[]>(ADMIN_SHOP_ITEMS_PATH, "GET");
      const normalized = (res || []).map((item) => ({
        ...item,
        active: item.is_active ?? item.active,
        methods: item.methods || {
          TON: item.price_ton ? { price: item.price_ton } : undefined,
          USDT: item.price_usdt ? { price: item.price_usdt } : undefined,
        } as any,
      }));
      setCatalog(normalized);
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    }
  }

  async function loadLegacyOrder() {
    setLoading(true);
    setMessage(null);
    try {
      const orderId = Number(orderForm.order_id || 0);
      const res = await adminApiRequest<LegacyOrder>(
        adminPath(ADMIN_SHOP_ORDER_LEGACY_ORDER_ID_PATH, {
          order_id: orderId,
        }),
        "GET",
      );
      setLegacyOrder(res);
      setOrderModalOpen(false);
      setActiveTab("orders");
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function loadLegacyUserOrders() {
    setLoading(true);
    setMessage(null);
    try {
      const tg_id = Number(userForm.tg_id || 0);
      const res = await adminApiRequest<LegacyOrder[]>(
        adminPath(ADMIN_SHOP_ORDERS_USER_LEGACY_TG_ID_PATH, {
          tg_id,
        }),
        "GET",
      );
      setLegacyUserOrders(res || []);
      setUserModalOpen(false);
      setActiveTab("orders");
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setLoading(false);
    }
  }

  async function saveItemContent(payload?: Partial<ShopEditorState>) {
    const body = {
      code: payload?.code ?? editor.code,
      title: payload?.title ?? editor.title,
      description: payload?.description ?? editor.description,
      item_type: payload?.item_type ?? editor.item_type,
      quantity_efhc: (payload?.quantity_efhc ?? editor.quantity_efhc) || null,
      image_url: (payload?.image_url ?? editor.image_url) || null,
      status: payload?.status ?? editor.status,
      price_ton: (payload?.price_ton ?? editor.price_ton) || null,
      price_usdt: (payload?.price_usdt ?? editor.price_usdt) || null,
      pay_currencies: [
        (payload?.price_ton ?? editor.price_ton) ? "TON" : null,
        (payload?.price_usdt ?? editor.price_usdt) ? "USDT" : null,
      ].filter(Boolean),
    };
    setSaving(true);
    setMessage(null);
    try {
      await adminApiRequest(ADMIN_SHOP_ITEMS_UPSERT_PATH, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body,
      });
      pushHistory(
        body.code,
        "Карточка сохранена",
        [body.title, body.status, body.item_type].join(" · "),
        "connected",
      );
      setMessage("Карточка товара сохранена.");
      await loadCatalog();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setSaving(false);
    }
  }

  async function createItem() {
    await saveItemContent({
      code: createForm.code,
      title: createForm.title,
      description: createForm.description,
      item_type: createForm.item_type,
      quantity_efhc: createForm.quantity_efhc,
      image_url: createForm.image_url,
      status: createForm.status,
      price_ton: createForm.price_ton,
      price_usdt: createForm.price_usdt,
    });
    setCreateModalOpen(false);
  }

  async function saveCurrentItem() {
    await saveItemContent();
  }

  async function saveItemStatus(status: string, code?: string) {
    const itemCode = code || editor.code;
    if (!itemCode) return;
    setSaving(true);
    setMessage(null);
    try {
      await adminApiRequest(ADMIN_SHOP_ITEMS_STATUS_PATH, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: { code: itemCode, status },
      });
      if (itemCode === editor.code) {
        setEditor((prev) => ({
          ...prev,
          status,
          is_active: status === "live",
        }));
      }
      pushHistory(
        itemCode,
        status === "draft" ? "Карточка архивирована" : "Статус обновлён",
        status,
        status === "live" ? "connected" : "warning",
      );
      setMessage(`Статус карточки обновлён: ${status}.`);
      await loadCatalog();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setSaving(false);
    }
  }

  async function deleteItem(code?: string) {
    const itemCode = code || editor.code;
    if (!itemCode) return;
    setSaving(true);
    setMessage(null);
    try {
      await adminApiRequest(ADMIN_SHOP_ITEMS_DELETE_PATH, "POST", {
        idempotencyKey: newIdempotencyKey(),
        body: { code: itemCode },
      });
      pushHistory(
        itemCode,
        "Карточка удалена",
        "Hard delete применён через admin/shop.",
        "warning",
      );
      setDeleteQueue((prev) => prev.filter((x) => x !== itemCode));
      if (selectedSku === itemCode) {
        setSelectedSku(null);
        setEditor(EDITOR_DEFAULT);
        setEditorBaseline(null);
      }
      setSelectedCodes((prev) => prev.filter((x) => x !== itemCode));
      setMessage(`Карточка удалена: ${itemCode}.`);
      await loadCatalog();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setSaving(false);
    }
  }

  function selectItem(item: CatalogItem) {
    const nextEditor = toEditor(item);
    setSelectedSku(item.sku);
    setEditor(nextEditor);
    setEditorBaseline(nextEditor);
    setActiveTab("catalog");
  }

  function toggleSelectedCode(code: string) {
    setSelectedCodes((prev) =>
      prev.includes(code)
        ? prev.filter((x) => x !== code)
        : [...prev, code],
    );
  }

  function toggleDeleteQueue(code: string) {
    setDeleteQueue((prev) =>
      prev.includes(code)
        ? prev.filter((x) => x !== code)
        : [...prev, code],
    );
  }

  async function applyBulkStatus(status: string) {
    if (!selectedCodes.length) return;
    setBulkBusy(true);
    setMessage(null);
    try {
      for (const code of selectedCodes) {
        await adminApiRequest(ADMIN_SHOP_ITEMS_STATUS_PATH, "POST", {
          idempotencyKey: newIdempotencyKey(),
          body: { code, status },
        });
        pushHistory(
          code,
          "Массовый статус",
          `Статус применён к группе: ${status}`,
          status === "live" ? "connected" : "primary",
        );
      }
      setMessage(`Массовый статус completed: ${status}.`);
      await loadCatalog();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setBulkBusy(false);
    }
  }

  async function applyBulkDelete() {
    if (!deleteQueue.length) return;
    setBulkBusy(true);
    setMessage(null);
    try {
      for (const code of deleteQueue) {
        await adminApiRequest(ADMIN_SHOP_ITEMS_DELETE_PATH, "POST", {
          idempotencyKey: newIdempotencyKey(),
          body: { code },
        });
        pushHistory(
          code,
          "Массовое удаление",
          "Карточка удалена из каталога.",
          "warning",
        );
      }
      setSelectedCodes((prev) => prev.filter((x) => !deleteQueue.includes(x)));
      setDeleteQueue([]);
      setMessage("Массовое удаление completed.");
      await loadCatalog();
    } catch (e: any) {
      setMessage(adminUiErrorMessage(e, t));
    } finally {
      setBulkBusy(false);
    }
  }

  function handleDataUrlResult(
    value: string,
    mode: "editor" | "create",
    name: string,
  ) {
    if (mode === "editor") {
      setEditor((prev) => ({ ...prev, image_url: value }));
      if (editor.code) {
        pushHistory(
          editor.code,
          "Изображение upload",
          `Загружен файл ${name}`,
          "primary",
        );
      }
      setMessage(`Изображение загружено: ${name}.`);
      return;
    }
    setCreateForm((prev) => ({ ...prev, image_url: value }));
    setMessage(`Изображение добавлено в новую карточку: ${name}.`);
  }

  function readImageFile(
    file: File,
    mode: "editor" | "create",
  ) {
    const reader = new FileReader();
    reader.onload = () => {
      const value = typeof reader.result === "string" ? reader.result : "";
      if (value) {
        handleDataUrlResult(value, mode, file.name);
      }
    };
    reader.readAsDataURL(file);
  }

  const categories = useMemo(() => {
    const map = new Map<string, number>();
    for (const item of catalog) {
      const key = item.item_type || "other";
      map.set(key, (map.get(key) || 0) + 1);
    }
    return [
      { id: "all", label: t("common.all") || "All", count: catalog.length },
      ...Array.from(map.entries()).map(([id, count]) => ({
        id,
        label: id,
        count,
      })),
    ];
  }, [catalog, t]);

  const filteredCatalog = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = catalog.filter((item) => {
      if (activeCategory !== "all" && item.item_type !== activeCategory) {
        return false;
      }
      if (statusFilter !== "all" && statusOf(item) !== statusFilter) {
        return false;
      }
      if (!q) return true;
      return [item.title, item.description || "", item.sku]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
    const sorted = [...filtered];
    sorted.sort((a, b) => {
      if (sortMode === "title_asc") {
        return a.title.localeCompare(b.title, "ru");
      }
      if (sortMode === "created_desc") {
        return (Date.parse(b.created_at || "") || 0)
          - (Date.parse(a.created_at || "") || 0);
      }
      if (sortMode === "created_asc") {
        return (Date.parse(a.created_at || "") || 0)
          - (Date.parse(b.created_at || "") || 0);
      }
      return (Date.parse(b.updated_at || "") || 0)
        - (Date.parse(a.updated_at || "") || 0);
    });
    return sorted;
  }, [catalog, search, activeCategory, statusFilter, sortMode]);

  const selectedItem = useMemo(() => {
    if (!selectedSku) return null;
    return catalog.find((item) => item.sku === selectedSku) || null;
  }, [catalog, selectedSku]);

  const statLive = catalog.filter((item) => statusOf(item) === "live").length;
  const statHidden = catalog.filter((item) => statusOf(item) === "hidden").length;
  const statDraft = catalog.filter((item) => statusOf(item) === "draft").length;

  const changedFields = useMemo(() => {
    if (!editorBaseline || !editor.code) return [];
    return [
      ["title", editor.title, editorBaseline.title],
      ["description", editor.description, editorBaseline.description],
      ["item_type", editor.item_type, editorBaseline.item_type],
      ["quantity_efhc", editor.quantity_efhc, editorBaseline.quantity_efhc],
      ["image_url", editor.image_url, editorBaseline.image_url],
      ["price_ton", editor.price_ton, editorBaseline.price_ton],
      ["price_usdt", editor.price_usdt, editorBaseline.price_usdt],
      ["status", editor.status, editorBaseline.status],
    ].filter((row) => row[1] !== row[2]);
  }, [editor, editorBaseline]);

  const selectedPersistentHistory = useMemo(() => {
    if (!selectedItem?.history_tail?.length) return [];
    return selectedItem.history_tail.map((entry, idx) => ({
      id: `persistent_${idx}`,
      at: String(entry.at || "—"),
      title: String(entry.action || "backend history"),
      detail: String(entry.detail || "shop item backend trail"),
      tone: "primary" as const,
    }));
  }, [selectedItem]);

  const selectedHistory = [
    ...selectedPersistentHistory,
    ...(editor.code ? historyByCode[editor.code] || [] : []),
  ];

  useEffect(() => {
    void loadOrders();
    void loadCatalog();
  }, []);

  return (
    <AdminPage title="Shop" backHref="/admin">
      <AdminShopWeb3SeparationPanel
        catalog={catalog}
        orders={orders}
        selectedCode={selectedSku}
        activeTab={activeTab}
        paymentLane={paymentLane}
        loading={loading}
        onTabChange={setActiveTab}
        onPaymentLaneChange={setPaymentLane}
        onSelectCode={(code) => {
          const item = catalog.find((entry) => (entry.code || entry.sku) === code);
          if (item) selectItem(item);
        }}
        onRefreshOrders={() => void loadOrders()}
        onCreateItem={() => setCreateModalOpen(true)}
      />

      <div className="grid gap-3 md:grid-cols-4">
        <AdminStatCard
          label="Карточки каталога"
          value={String(catalog.length)}
          hint="Все карточки"
        />
        <AdminStatCard
          label="Live / hidden"
          value={`${statLive} / ${statHidden}`}
          hint="Боевые и скрытые"
        />
        <AdminStatCard
          label="Draft archive"
          value={String(statDraft)}
          hint="Архивный статус"
        />
        <AdminStatCard
          label="Выбрано / очередь удаления"
          value={`${selectedCodes.length} / ${deleteQueue.length}`}
          hint="Массовая очередь оператора"
        />
        <AdminStatCard
          label="Постоянная история"
          value={String(
            catalog.reduce(
              (sum, item) => sum + Number(item.history_count || 0),
              0,
            ),
          )}
          hint="Backend trail in shop_items.extra_json"
        />
      </div>

      <AdminSectionCard
        title="Панель workflow"
        subtitle={
          "EFHC-native operator surface по мотивам donor dashboard " +
          "rhythm и list/detail grammar."
        }
      >
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <div className="space-y-3">
            <AdminSurfaceTabs
              items={[
                { key: "catalog", label: "Каталог" },
                { key: "preview", label: "Предпросмотр split" },
                { key: "history", label: "История" },
                { key: "orders", label: "Заказы" },
              ]}
              activeKey={activeTab}
              onChange={setActiveTab}
            />
            <div className="grid gap-2 md:grid-cols-3">
              <TelegramSectionRow
                compact
                title="Выбранная карточка"
                subtitle={editor.code || "—"}
              />
              <TelegramSectionRow
                compact
                title="Очередь массового статуса"
                subtitle={selectedCodes.join(", ") || "Нет выбранных карточек"}
              />
              <TelegramSectionRow
                compact
                title="Очередь удаления"
                subtitle={deleteQueue.join(", ") || "Очередь удаления пуста"}
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setCreateModalOpen(true)}>Новая карточка</Button>
            <Button
              variant="secondary"
              onClick={() => setOrderModalOpen(true)}
            >
              Legacy order by id
            </Button>
            <Button
              variant="secondary"
              onClick={() => setUserModalOpen(true)}
            >
              Legacy orders by tg_id
            </Button>
          </div>
        </div>
        {message ? (
          <div className="mt-3 text-sm text-[color:var(--tg-link)]">
            {message}
          </div>
        ) : null}
      </AdminSectionCard>

      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-4">
          <AdminSectionCard
            title="Управление каталогом"
            subtitle="Поиск, фильтры, массовые действия, архив и удаление."
          >
            <div className="space-y-3">
              <TelegramSearchBar
                value={search}
                onChange={setSearch}
                placeholder="Поиск по названию / описанию / SKU"
              />
              <div className="grid gap-2 md:grid-cols-[1fr_auto_auto]">
                <TelegramCategoryPills
                  items={categories}
                  activeId={activeCategory}
                  onSelect={setActiveCategory}
                />
                <select
                  className="efhc-input"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">Все статусы</option>
                  <option value="live">Опубликовано</option>
                  <option value="hidden">Скрыто</option>
                  <option value="draft">Архив</option>
                </select>
                <select
                  className="efhc-input"
                  value={sortMode}
                  onChange={(e) => setSortMode(e.target.value)}
                >
                  <option value="updated_desc">Обновление по убыванию</option>
                  <option value="created_desc">Создание по убыванию</option>
                  <option value="created_asc">Создание по возрастанию</option>
                  <option value="title_asc">Название по возрастанию</option>
                </select>
              </div>

              <div className="rounded-2xl border border-[color:var(--tg-hint)]/20 p-3">
                <div className="mb-2 text-sm font-medium">
                  Массовые действия
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    disabled={bulkBusy || !selectedCodes.length}
                    onClick={() => void applyBulkStatus("live")}
                  >
                    Сделать опубликованными
                  </Button>
                  <Button
                    variant="secondary"
                    disabled={bulkBusy || !selectedCodes.length}
                    onClick={() => void applyBulkStatus("hidden")}
                  >
                    Сделать скрытыми
                  </Button>
                  <Button
                    variant="secondary"
                    disabled={bulkBusy || !selectedCodes.length}
                    onClick={() => void applyBulkStatus("draft")}
                  >
                    Архивировать выбранные
                  </Button>
                  <Button
                    variant="secondary"
                    disabled={bulkBusy || !deleteQueue.length}
                    onClick={() => void applyBulkDelete()}
                  >
                    Массовое удаление
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => {
                      setSelectedCodes(filteredCatalog.map((item) => item.sku));
                    }}
                  >
                    Выбрать отфильтрованные
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => {
                      setSelectedCodes([]);
                      setDeleteQueue([]);
                    }}
                  >
                    Очистить выбор
                  </Button>
                </div>
                <div className="mt-2 text-xs text-[color:var(--tg-hint)]">
                  Архив переводит карточку в черновик. Удаление полностью
                  убирает запись.
                </div>
              </div>

              <div className="space-y-2">
                {filteredCatalog.map((item) => {
                  const code = item.code || item.sku;
                  const currentStatus = statusOf(item);
                  return (
                    <div
                      key={item.sku}
                      className="rounded-2xl border border-[color:var(--tg-hint)]/20 p-3"
                    >
                      <div className="mb-2 flex flex-wrap gap-2">
                        <label className="flex items-center gap-2 text-sm">
                          <input
                            type="checkbox"
                            checked={selectedCodes.includes(code)}
                            onChange={() => toggleSelectedCode(code)}
                          />
                          Массовое действие
                        </label>
                        <label className="flex items-center gap-2 text-sm">
                          <input
                            type="checkbox"
                            checked={deleteQueue.includes(code)}
                            onChange={() => toggleDeleteQueue(code)}
                          />
                          Очередь удаления
                        </label>
                      </div>
                      <TelegramSectionRow
                        title={item.title}
                        subtitle={`${code} · ${item.item_type}`}
                        onClick={() => selectItem(item)}
                        rightSlot={
                          <div className="flex items-center gap-2">
                            <TelegramStatusBadge
                              label={adminShopStatusLabel(currentStatus)}
                              tone={
                                currentStatus === "live"
                                  ? "connected"
                                  : currentStatus === "draft"
                                    ? "warning"
                                    : "neutral"
                              }
                            />
                          </div>
                        }
                      />
                    </div>
                  );
                })}
                {!filteredCatalog.length ? (
                  <TelegramEmptyState
                    title="Пустой каталог"
                    detail="Фильтры не дали результатов."
                  />
                ) : null}
              </div>
            </div>
          </AdminSectionCard>
        </div>

        <div className="space-y-4">
          <AdminSettingsCard
            title="Редактор выбранной карточки"
            subtitle="Контент, загрузка изображения, архивирование, удаление и сохранение." 
          >
            {selectedItem ? (
              <>
                <div className="grid gap-2 md:grid-cols-2">
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      SKU / code
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.code}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          code: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Тип позиции
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.item_type}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          item_type: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Название
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.title}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          title: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Quantity EFHC
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.quantity_efhc}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          quantity_efhc: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1 md:col-span-2">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Описание
                    </span>
                    <textarea
                      className="efhc-input min-h-[88px]"
                      value={editor.description}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          description: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Изображение URL / data URL
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.image_url}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          image_url: e.target.value,
                        }));
                      }}
                      placeholder="https://... or data:image/..."
                    />
                  </label>
                  <div className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      Real image upload flow
                    </span>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="secondary"
                        onClick={() => editorUploadRef.current?.click()}
                      >
                        Upload image
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setEditor((prev) => ({ ...prev, image_url: "" }));
                        }}
                      >
                        Clear image
                      </Button>
                    </div>
                    <input
                      ref={editorUploadRef}
                      hidden
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          readImageFile(file, "editor");
                        }
                      }}
                    />
                  </div>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      TON price
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.price_ton}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          price_ton: e.target.value,
                        }));
                      }}
                    />
                  </label>
                  <label className="grid gap-1">
                    <span className="text-xs text-[color:var(--tg-hint)]">
                      USDT price
                    </span>
                    <input
                      className="efhc-input"
                      value={editor.price_usdt}
                      onChange={(e) => {
                        setEditor((prev) => ({
                          ...prev,
                          price_usdt: e.target.value,
                        }));
                      }}
                    />
                  </label>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    onClick={() => void saveCurrentItem()}
                    disabled={saving}
                  >
                    {saving ? t("admin.working") : "Сохранить карточку"}
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => void saveItemStatus("live")}
                    disabled={saving}
                  >
                    Опубликовать
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => void saveItemStatus("hidden")}
                    disabled={saving}
                  >
                    Скрыть
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => void saveItemStatus("draft")}
                    disabled={saving}
                  >
                    Архивировать
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => void deleteItem()}
                    disabled={saving}
                  >
                    Удалить
                  </Button>
                </div>
                <div className="mt-2 text-xs text-[color:var(--tg-hint)]">
                  Архивирование сохраняет запись как черновик, а удаление
                  полностью убирает её отдельным действием.
                </div>
              </>
            ) : (
              <TelegramEmptyState
                title="Выберите карточку"
                detail="Слева выберите товар для управления."
              />
            )}
          </AdminSettingsCard>

          {selectedItem ? (
            <AdminSectionCard
              title="Служебные факты выбранной карточки"
              subtitle="Метаданные и операторская сводка по выбранной карточке."
            >
              <div className="grid gap-2 md:grid-cols-2">
                <TelegramSectionRow
                  compact
                  title="Статус"
                  subtitle={adminShopStatusLabel(editor.status || "draft")}
                  rightSlot={
                    <TelegramStatusBadge
                      label={adminShopStatusLabel(
                        editor.is_active ? "active" : "inactive",
                      )}
                      tone={editor.is_active ? "connected" : "warning"}
                    />
                  }
                />
                <TelegramSectionRow
                  compact
                  title="Тип позиции"
                  subtitle={editor.item_type || "EFHC_PACKAGE"}
                />
                <TelegramSectionRow
                  compact
                  title="Количество EFHC"
                  subtitle={editor.quantity_efhc || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="Изображение"
                  subtitle={editor.image_url ? "Привязано" : "Нет изображения"}
                />
                <TelegramSectionRow
                  compact
                  title="Создано"
                  subtitle={selectedItem.created_at || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="Обновлено"
                  subtitle={selectedItem.updated_at || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="TON"
                  subtitle={editor.price_ton || "—"}
                />
                <TelegramSectionRow
                  compact
                  title="USDT"
                  subtitle={editor.price_usdt || "—"}
                />
              </div>
            </AdminSectionCard>
          ) : null}
        </div>
      </div>

      {activeTab === "preview" && selectedItem ? (
        <div className="grid gap-4 md:grid-cols-2">
          <AdminSectionCard
            title="Мобильный preview"
            subtitle="Компактное восприятие карточки во внешней витрине."
          >
            <TelegramProductCard
              title={editor.title || selectedItem.title}
              description={
                editor.description ||
                selectedItem.description ||
                "Пакет EFHC"
              }
              price={
                editor.price_ton ||
                selectedItem.methods?.TON?.price ||
                "TON planned"
              }
              secondaryPrice={
                editor.price_usdt ||
                selectedItem.methods?.USDT?.price ||
                undefined
              }
              imageUrl={editor.image_url || null}
              badges={[
                { label: selectedItem.item_type, tone: "neutral" },
                {
                  label: editor.status,
                  tone: editor.status === "live" ? "connected" : "warning",
                },
              ]}
              primaryLabel="Предпросмотр"
              onPrimary={() => {}}
            />
          </AdminSectionCard>
          <AdminSectionCard
            title="Desktop preview split"
            subtitle="Более широкая operator/detail подача той же карточки."
          >
            <div className="grid gap-3 md:grid-cols-[160px_1fr]">
              <div className="overflow-hidden rounded-2xl border border-[color:var(--tg-hint)]/20">
                {editor.image_url ? (
                  <img
                    src={editor.image_url}
                    alt={editor.title || selectedItem.title}
                    className="h-40 w-full object-cover"
                  />
                ) : (
                  <div className="flex h-40 items-center justify-center text-sm text-[color:var(--tg-hint)]">
                    Нет изображения
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <TelegramSectionRow
                  compact
                  title={editor.title || selectedItem.title}
                  subtitle={editor.item_type || selectedItem.item_type}
                />
                <TelegramSectionRow
                  compact
                  title="Описание"
                  subtitle={
                    editor.description ||
                    selectedItem.description ||
                    "Пакет EFHC"
                  }
                />
                <TelegramSectionRow
                  compact
                  title="Разделение оплаты"
                  subtitle={`TON ${editor.price_ton || "—"} · USDT ${editor.price_usdt || "—"}`}
                />
                <TelegramSectionRow
                  compact
                  title="Рабочий статус"
                  subtitle={
                    `статус=${adminShopStatusLabel(editor.status)} · ` +
                    `архив=${editor.status === "draft" ? "да" : "нет"}`
                  }
                />
              </div>
            </div>
          </AdminSectionCard>
        </div>
      ) : null}

      {activeTab === "history" ? (
        <div className="grid gap-4 md:grid-cols-2">
          <AdminSectionCard
            title="Field-level история"
            subtitle="Сравнение текущего editor-state с baseline карточки."
          >
            {selectedItem ? (
              changedFields.length ? (
                <div className="space-y-2">
                  {changedFields.map(([field, next, prev]) => (
                    <TelegramSectionRow
                      key={String(field)}
                      compact
                      title={String(field)}
                      subtitle={`${String(prev || "—")} → ${String(next || "—")}`}
                    />
                  ))}
                </div>
              ) : (
                <TelegramEmptyState
                  title="Нет несохранённых изменений"
                  detail="Текущее состояние совпадает с baseline."
                />
              )
            ) : (
              <TelegramEmptyState
                title="Нет выбранной карточки"
                detail="Выберите товар в catalog management."
              />
            )}
          </AdminSectionCard>

          <AdminSectionCard
            title="История действий"
            subtitle="Backend trail + сессионный журнал операций по текущей карточке."
          >
            {selectedHistory.length ? (
              <div className="space-y-2">
                {selectedHistory.map((entry) => (
                  <TelegramSectionRow
                    key={entry.id}
                    compact
                    title={entry.title}
                    subtitle={`${entry.at} · ${entry.detail}`}
                    rightSlot={
                      <TelegramStatusBadge
                        label={entry.tone}
                        tone={entry.tone}
                      />
                    }
                  />
                ))}
              </div>
            ) : (
              <TelegramEmptyState
                title="История пуста"
                detail="Новые upload/save/status/delete действия появятся здесь."
              />
            )}
          </AdminSectionCard>
        </div>
      ) : null}

      {activeTab === "orders" ? (
        <div className="grid gap-4 md:grid-cols-2">
          <AdminSectionCard
            title="Активные admin orders runtime"
            subtitle="Боевой runtime слой текущих shop orders."
          >
            {orders.length ? (
              <div className="space-y-2">
                {orders.slice(0, 10).map((row, idx) => (
                  <TelegramSectionRow
                    key={String(row.id || row.order_id || idx)}
                    compact
                    title={`order ${formatUnknown(row.id || row.order_id || idx)}`}
                    subtitle={`status=${formatUnknown(row.status)} · type=${formatUnknown(row.type)}`}
                    rightSlot={
                      <div className="flex items-center gap-2">
                        <TelegramStatusBadge
                          label={formatUnknown(row.tg_id)}
                          tone="neutral"
                        />
                        <Button
                          variant="secondary"
                          onClick={() => {
                            setFulfillForm({
                              order_id: String(
                                row.id || row.order_id || ""
                              ),
                              reason: "manual force fulfill",
                            });
                            setFulfillModalOpen(true);
                          }}
                        >
                          Force Fulfill
                        </Button>
                      </div>
                    }
                  />
                ))}
              </div>
            ) : (
              <TelegramEmptyState
                title="Нет загруженных admin orders"
                actionLabel="Загрузить"
                onAction={() => void loadOrders()}
              />
            )}
          </AdminSectionCard>
          <AdminSectionCard
            title="Legacy read surface"
            subtitle="Старые read-only точки поиска до полной миграции."
          >
            <div className="space-y-3">
              {legacyOrder ? (
                <TelegramSectionRow
                  compact
                  title={`legacy order ${legacyOrder.order_id}`}
                  subtitle={`status=${legacyOrder.status} · type=${legacyOrder.type}`}
                  rightSlot={
                    <TelegramStatusBadge
                      label={legacyOrder.tx_hash || "no tx"}
                      tone="neutral"
                    />
                  }
                />
              ) : null}
              {legacyUserOrders.slice(0, 5).map((row) => (
                <TelegramSectionRow
                  key={row.order_id}
                  compact
                  title={`order ${row.order_id}`}
                  subtitle={`status=${row.status} · type=${row.type}`}
                  rightSlot={
                    <TelegramStatusBadge
                      label={row.memo || "memo"}
                      tone="neutral"
                    />
                  }
                />
              ))}
              {!legacyOrder && !legacyUserOrders.length ? (
                <TelegramEmptyState
                  title="Legacy lookup idle"
                  detail="Откройте поиск legacy order по id или tg_id."
                />
              ) : null}
            </div>
          </AdminSectionCard>
        </div>
      ) : null}

      <AdminPromptModal
        open={fulfillModalOpen}
        title="Принудительно исполнить заказ"
        submitLabel="Зачислить вручную"
        busy={loading}
        values={fulfillForm}
        fields={[
          { key: "order_id", label: "ID заказа" },
          { key: "reason", label: "Причина" },
        ]}
        onChange={(key, value) => {
          setFulfillForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setFulfillModalOpen(false)}
        onSubmit={() => void forceFulfillOrder()}
      />

      <AdminPromptModal
        open={createModalOpen}
        title="Новая карточка товара"
        submitLabel="Создать"
        busy={saving}
        values={createForm}
        fields={[
          { key: "code", label: "SKU / code" },
          { key: "title", label: "Название" },
          { key: "description", label: "Описание", type: "textarea" },
          { key: "item_type", label: "Тип позиции" },
          { key: "quantity_efhc", label: "EFHC quantity" },
          { key: "image_url", label: "Изображение URL / data URL" },
          { key: "price_ton", label: "TON price" },
          { key: "price_usdt", label: "USDT price" },
          { key: "status", label: "Статус (live/hidden/draft)" },
        ]}
        onChange={(key, value) => {
          setCreateForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setCreateModalOpen(false)}
        onSubmit={() => void createItem()}
      />

      {createModalOpen ? (
        <AdminSectionCard
          title="Загрузка изображения новой карточки"
          subtitle="Реальный upload-flow для новых карточек перед сохранением."
        >
          <div className="flex flex-wrap gap-2">
            <Button
              variant="secondary"
              onClick={() => createUploadRef.current?.click()}
            >
              Upload image for new card
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                setCreateForm((prev) => ({ ...prev, image_url: "" }));
              }}
            >
              Clear image
            </Button>
            <input
              ref={createUploadRef}
              hidden
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  readImageFile(file, "create");
                }
              }}
            />
          </div>
        </AdminSectionCard>
      ) : null}

      <AdminPromptModal
        open={orderModalOpen}
        title="Legacy order by id"
        submitLabel="Загрузить"
        values={orderForm}
        fields={[{ key: "order_id", label: "order_id" }]}
        onChange={(key, value) => setOrderForm({ [key]: value } as any)}
        onClose={() => setOrderModalOpen(false)}
        onSubmit={() => void loadLegacyOrder()}
      />

      <AdminPromptModal
        open={userModalOpen}
        title="Legacy orders by tg_id"
        submitLabel="Загрузить"
        values={userForm}
        fields={[{ key: "tg_id", label: "tg_id" }]}
        onChange={(key, value) => setUserForm({ [key]: value } as any)}
        onClose={() => setUserModalOpen(false)}
        onSubmit={() => void loadLegacyUserOrders()}
      />
    </AdminPage>
  );
}
