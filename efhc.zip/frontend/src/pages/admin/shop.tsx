import React, { useEffect, useState } from "react";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

function newIdk(prefix: string) {
  const c: any = globalThis.crypto;
  const uuid = c?.randomUUID ? c.randomUUID() : `${Date.now()}-${Math.random()}`;
  return `${prefix}:${uuid}`;
}

export default function AdminShopPage() {
  const t = useT();
  const [orders, setOrders] = useState<any[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [priceOpen, setPriceOpen] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({
    code: "",
    price_efhc: "",
    price_ton: "",
    price_usdt: "",
    is_active: "",
  });

  async function load(cursor?: string | null) {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      qs.set("limit", "50");
      if (cursor) qs.set("cursor", cursor);
      const res = await apiRequest<any>(
        `/admin/shop/orders?${qs.toString()}`,
        "GET",
      );
      setOrders(res?.items || []);
      setNextCursor(res?.next_cursor || null);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function setPrice() {
    const code = form.code.trim();
    if (!code) return;
    const body: any = { code };
    if (form.price_efhc.trim()) body.price_efhc = form.price_efhc.trim();
    if (form.price_ton.trim()) body.price_ton = form.price_ton.trim();
    if (form.price_usdt.trim()) body.price_usdt = form.price_usdt.trim();
    if (form.is_active === "true" || form.is_active === "false") {
      body.is_active = form.is_active === "true";
    }
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>("/admin/shop/items/set-price", "POST", {
        idempotencyKey: newIdk(`admin-shop-set-price-${code}`),
        body,
      });
      setPriceOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage title={t("admin.shop")} backHref="/admin">
      <Card title={t("admin.shop_orders")}>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <Button variant="secondary" onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
          <Button variant="secondary" onClick={() => setPriceOpen(true)}>
            {t("admin.set_price")}
          </Button>
          {nextCursor ? (
            <Button
              variant="secondary"
              onClick={() => void load(nextCursor)}
              disabled={loading}
            >
              {t("common.next")}
            </Button>
          ) : null}
        </div>
        {error ? <div className="efhc-admin-error mb-2">{error}</div> : null}
        <div className="efhc-admin-table-wrap">
          <table className="efhc-admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>{t("admin.user")}</th>
                <th>{t("admin.item")}</th>
                <th>{t("admin.status")}</th>
                <th>{t("admin.payment")}</th>
                <th>{t("admin.created")}</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td>{o.id}</td>
                  <td>{o.tg_id || ""}</td>
                  <td>{o.item_code || o.item_id}</td>
                  <td>{o.status}</td>
                  <td>{o.payment_method}</td>
                  <td>{o.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <AdminPromptModal
        open={priceOpen}
        title={t("admin.set_price")}
        submitLabel={t("admin.set_price")}
        fields={[
          { key: "code", label: t("admin.item_code_prompt") || "Item code" },
          {
            key: "price_efhc",
            label: t("admin.price_efhc_prompt") || "price_efhc",
          },
          {
            key: "price_ton",
            label: t("admin.price_ton_prompt") || "price_ton",
          },
          {
            key: "price_usdt",
            label: t("admin.price_usdt_prompt") || "price_usdt",
          },
          {
            key: "is_active",
            label: t("admin.is_active_prompt") || "is_active true/false",
          },
        ]}
        values={form}
        busy={loading}
        onChange={(key, value) => {
          setForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setPriceOpen(false)}
        onSubmit={() => {
          void setPrice();
        }}
      />
    </AdminPage>
  );
}
