import React, { useEffect, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

export default function AdminReportsPage() {
  const t = useT();
  const [overview, setOverview] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        "/admin/reports/overview",
        "GET",
      );
      setOverview(res);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage title={t("admin.reports")} backHref="/admin">
      <Card title={t("admin.overview")}>
        <div className="mb-3 flex items-center gap-2">
          <Button onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? (
          <div className="efhc-admin-error mb-2">{error}</div>
        ) : null}
        <pre className="efhc-admin-pre">
          {overview
            ? JSON.stringify(overview, null, 2)
            : t("common.loading")}
        </pre>
      </Card>
    </AdminPage>
  );
}
