import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

export default function AdminReportsPage() {
  const t = useT();
  const [overview, setOverview] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        "/admin/reports/overview",
        "GET",
      );
      setOverview(res);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const preCls = [
    "text-xs whitespace-pre-wrap break-words",
    "bg-black/10 rounded p-2",
  ].join(" ");

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.reports")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.overview")}>
        <div className="flex items-center gap-2 mb-3">
          <Button
            className="bg-white text-black"
            onClick={load}
            disabled={loading}
          >
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
        </div>
        {error ? (
          <div className="text-sm text-red-500 mb-2">{error}</div>
        ) : null}

        <pre className={preCls}>
          {overview
            ? JSON.stringify(overview, null, 2)
            : t("common.loading")}
        </pre>
      </Card>
    </div>
  );
}
