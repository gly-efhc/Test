import React, { useEffect, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import {
  AdminPromptModal,
} from "../../components/admin/AdminPromptModal";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

function newIdk(prefix: string) {
  const c: any = globalThis.crypto;
  const fallback = `${Date.now()}-${Math.random()}`;
  const uuid = c?.randomUUID ? c.randomUUID() : fallback;
  return `${prefix}:${uuid}`;
}

export default function AdminReferralsPage() {
  const t = useT();
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bonusOpen, setBonusOpen] = useState(false);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [bonusForm, setBonusForm] = useState<Record<string, string>>({
    tg_id: "",
    amount_efhc: "",
    reason: "",
  });
  const [reassignForm, setReassignForm] = useState<
    Record<string, string>
  >({
    child_tg_id: "",
    new_parent_tg_id: "",
  });

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        "/api/admin/referrals/summary?limit=100",
        "GET",
      );
      setSummary(res);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function manualBonus() {
    const tg = bonusForm.tg_id.trim();
    const amount = bonusForm.amount_efhc.trim();
    const reason = bonusForm.reason.trim();
    if (!tg || !amount || !reason) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(
        "/api/admin/referrals/manual-bonus",
        "POST",
        {
          idempotencyKey: newIdk(`admin-ref-bonus-${tg}`),
          body: {
            tg_id: Number(tg),
            amount_efhc: amount,
            reason,
          },
        },
      );
      setBonusOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function reassign() {
    const child = reassignForm.child_tg_id.trim();
    const parent = reassignForm.new_parent_tg_id.trim();
    if (!child || !parent) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>("/api/admin/referrals/reassign", "POST", {
        idempotencyKey: newIdk(`admin-ref-reassign-${child}`),
        body: {
          child_tg_id: Number(child),
          new_parent_tg_id: Number(parent),
        },
      });
      setReassignOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AdminPage title={t("admin.referrals")} backHref="/admin">
      <Card title={t("admin.referrals_summary")}>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <Button onClick={() => void load()} disabled={loading}>
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
          <Button
            variant="secondary"
            onClick={() => setBonusOpen(true)}
          >
            {t("admin.manual_bonus")}
          </Button>
          <Button
            variant="secondary"
            onClick={() => setReassignOpen(true)}
          >
            {t("admin.reassign")}
          </Button>
        </div>

        {error ? (
          <div className="efhc-admin-error mb-2">{error}</div>
        ) : null}

        <pre className="efhc-admin-pre">
          {summary
            ? JSON.stringify(summary, null, 2)
            : t("common.loading")}
        </pre>
      </Card>

      <AdminPromptModal
        open={bonusOpen}
        title={t("admin.manual_bonus")}
        submitLabel={t("admin.manual_bonus")}
        fields={[
          {
            key: "tg_id",
            label: t("admin.user_tg_id_prompt"),
            placeholder: "tg_id",
          },
          {
            key: "amount_efhc",
            label: t("admin.amount_prompt"),
            placeholder: "1.00000000",
          },
          {
            key: "reason",
            label: t("admin.reason_prompt"),
            placeholder: "manual_referral_bonus",
          },
        ]}
        values={bonusForm}
        busy={loading}
        onChange={(key, value) => {
          setBonusForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setBonusOpen(false)}
        onSubmit={() => {
          void manualBonus();
        }}
      />

      <AdminPromptModal
        open={reassignOpen}
        title={t("admin.reassign")}
        submitLabel={t("admin.reassign")}
        fields={[
          {
            key: "child_tg_id",
            label: t("admin.child_tg_id_prompt") || "Child tg_id",
          },
          {
            key: "new_parent_tg_id",
            label: t("admin.parent_tg_id_prompt") || "New parent tg_id",
          },
        ]}
        values={reassignForm}
        busy={loading}
        onChange={(key, value) => {
          setReassignForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setReassignOpen(false)}
        onSubmit={() => {
          void reassign();
        }}
      />
    </AdminPage>
  );
}
