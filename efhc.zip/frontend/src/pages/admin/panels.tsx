import React, { useEffect, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminRouteHealthStrip } from "../../components/admin/AdminRouteHealthStrip";
import { AdminPanelsDashboardRuntime } from "../../components/admin/AdminPanelsDashboardRuntime";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { format8 } from "../../lib/format";
import { newIdempotencyKey } from "../../lib/idempotency";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import {
  adminPath,
  ADMIN_PANELS_PATH,
  ADMIN_PANELS_PANEL_ID_ACTIVATE_PATH,
  ADMIN_PANELS_PANEL_ID_DEACTIVATE_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type PanelItem = { id:number; tg_id:number; is_active:boolean; created_at:string; expires_at?:string|null; archived_at?:string|null; generated_kwh:string };
type PanelsOut = { ok:boolean; items:PanelItem[] };

export default function AdminPanelsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [tgFilter, setTgFilter] = useState("");
  const [onlyActive, setOnlyActive] = useState(false);
  const [items, setItems] = useState<PanelItem[]>([]);
  const [dashboardItems, setDashboardItems] = useState<PanelItem[]>([]);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [dashboardError, setDashboardError] = useState<string | null>(null);
  const [dashboardUpdatedAt, setDashboardUpdatedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);

  async function load() {
    setLoading(true); setErr("");
    try {
      const params = new URLSearchParams();
      if (tgFilter.trim()) params.set("tg_id", tgFilter.trim());
      if (onlyActive) params.set("is_active", "true");
      const data = await adminApiRequest<PanelsOut>(`${ADMIN_PANELS_PATH}?${params.toString()}`, "GET");
      setItems(data.items || []);
    } catch (e:any) { setErr(adminSafeLoadError(e, t)); }
    finally { setLoading(false); }
  }

  async function loadDashboardSnapshots() {
    setDashboardLoading(true);
    setDashboardError(null);
    try {
      const params = new URLSearchParams();
      if (tgFilter.trim()) params.set("tg_id", tgFilter.trim());
      const data = await adminApiRequest<PanelsOut>(`${ADMIN_PANELS_PATH}?${params.toString()}`, "GET");
      setDashboardItems(data.items || []);
      setDashboardUpdatedAt(new Date().toISOString());
    } catch (e:any) {
      setDashboardItems([]);
      setDashboardError(adminSafeLoadError(e, t));
    } finally {
      setDashboardLoading(false);
    }
  }

  async function toggle(panelId:number,toActive:boolean){
    setBusyId(panelId); setErr("");
    try {
      const path = toActive
        ? adminPath(ADMIN_PANELS_PANEL_ID_ACTIVATE_PATH, { panel_id: panelId })
        : adminPath(ADMIN_PANELS_PANEL_ID_DEACTIVATE_PATH, { panel_id: panelId });
      await adminApiRequest(path,"PATCH",{ idempotencyKey:newIdempotencyKey(), body:{} });
      await load();
      await loadDashboardSnapshots();
    } catch(e:any){ setErr(adminSafeLoadError(e, t)); }
    finally { setBusyId(null); }
  }

  useEffect(() => {
    void load();
    void loadDashboardSnapshots();
  }, []);

  return (
    <AdminPage title={t("admin.panels")} backHref="/admin">
      <AdminRouteHealthStrip
        title="Диагностика маршрута"
        subtitle="Список панелей и контуры активации."
        items={[
          { label: "list", path: "/admin/panels", tone: "connected" },
          { label: "activate", path: "/admin/panels/{id}/activate", tone: "warning" },
          { label: "deactivate", path: "/admin/panels/{id}/deactivate", tone: "warning" },
        ]}
      />
      <AdminPanelsDashboardRuntime
        items={dashboardItems}
        currentItems={items}
        activeOnly={onlyActive}
        filterApplied={Boolean(tgFilter.trim())}
        loading={dashboardLoading || loading}
        error={dashboardError || err || null}
        updatedAt={dashboardUpdatedAt || undefined}
        onRefresh={() => {
          void loadDashboardSnapshots();
          void load();
        }}
      />
      <TelegramInfoBlock title={t("admin.panels")}>
        <div className="mt-3 grid gap-2 md:grid-cols-3">
          <input className="efhc-input" placeholder={t("admin.tg_optional") || "tg_id"} value={tgFilter} onChange={(e)=>setTgFilter(e.target.value)} onKeyDown={(e)=>{ if(e.key==='Enter') { void load(); void loadDashboardSnapshots(); } }} />
          <label className="efhc-admin-toggle px-3 py-2 text-sm">
            <input type="checkbox" checked={onlyActive} onChange={(e)=>setOnlyActive(e.target.checked)} />
            {t("admin.only_active") || t("common.active")}
          </label>
          <Button onClick={() => { void load(); void loadDashboardSnapshots(); }}>{t("common.refresh")}</Button>
        </div>
        <div className="mt-3 text-xs">{t("admin.items_count") || "Элементы"}: {items.length}</div>
      </TelegramInfoBlock>

      {err ? <TelegramEmptyState title="Ошибка панелей" detail={err || undefined} /> : null}
      {loading && items.length===0 ? <TelegramEmptyState title={t("common.loading")} /> : null}
      {!loading && items.length===0 ? <TelegramEmptyState title="Панели не найдены" detail="Измените фильтр tg_id или покажите все панели." /> : null}

      {items.length > 0 ? (
        <div className="space-y-2">
          {items.map((p) => (
            <TelegramSectionRow
              key={p.id}
              title={`Panel #${p.id} · tg_id ${p.tg_id}`}
              subtitle={`kWh: ${format8(p.generated_kwh)} · created: ${new Date(p.created_at).toLocaleString()}`}
              rightSlot={
                <div className="flex items-center gap-2">
                  <TelegramStatusBadge label={p.is_active ? "АКТИВНАЯ" : "АРХИВ"} tone={p.is_active ? "connected" : "neutral"} />
                  <Button variant={p.is_active ? "secondary" : "primary"} disabled={busyId === p.id} onClick={(e)=>{ e.stopPropagation(); void toggle(p.id,!p.is_active); }}>
                    {busyId === p.id ? "…" : "Переключить"}
                  </Button>
                </div>
              }
            />
          ))}
        </div>
      ) : null}
    </AdminPage>
  );
}
