import React, { useEffect, useState } from "react";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { AdminPage } from "../../components/admin/AdminPage";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { format8 } from "../../lib/format";

type PanelItem = {
  id: number;
  tg_id: number;
  is_active: boolean;
  created_at: string;
  expires_at?: string | null;
  archived_at?: string | null;
  generated_kwh: string;
};

type PanelsOut = {
  ok: boolean;
  items: PanelItem[];
};

export default function AdminPanelsPage() {
  const t = useT();
  const [tgId, setTgId] = useState("");
  const [onlyActive, setOnlyActive] = useState(false);
  const [items, setItems] = useState<PanelItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams();
      if (tgId.trim()) params.set("tg_id", tgId.trim());
      if (onlyActive) params.set("is_active", "true");
      const data = await apiRequest<PanelsOut>(
        `/admin/panels?${params.toString()}`,
        "GET",
      );
      setItems(data.items || []);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function toggle(panelId: number, toActive: boolean) {
    setBusyId(panelId);
    setErr("");
    try {
      const path = toActive
        ? `/admin/panels/${panelId}/activate`
        : `/admin/panels/${panelId}/deactivate`;
      await apiRequest(path, "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: {},
      });
      await load();
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyId(null);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <AdminPage title={t("admin.panels")} backHref="/admin">
      <Card title={t("admin.panels")}>
        <div className="grid gap-3">
          <div className="grid gap-2 md:grid-cols-3">
            <input
              className="efhc-input"
              placeholder="tg_id (optional)"
              value={tgId}
              onChange={(e) => setTgId(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void load();
              }}
            />
            <label className="flex items-center gap-2 rounded-2xl efhc-pill px-3 py-2 text-sm">
              <input
                type="checkbox"
                checked={onlyActive}
                onChange={(e) => setOnlyActive(e.target.checked)}
              />
              Only active
            </label>
            <Button onClick={() => void load()}>Refresh</Button>
          </div>
          {err ? <div className="efhc-admin-error">{err}</div> : null}
          {loading ? <div className="text-sm efhc-text-muted">Loading…</div> : null}
          <div className="text-xs efhc-text-muted">Items: {items.length}</div>
          <div className="efhc-admin-table-wrap">
            <table className="efhc-admin-table">
              <thead>
                <tr>
                  <th>Panel ID</th>
                  <th>tg_id</th>
                  <th>Status</th>
                  <th>Generated kWh</th>
                  <th>Created</th>
                  <th>Expires</th>
                  <th>Archived</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs">{p.id}</td>
                    <td className="font-mono text-xs">{p.tg_id}</td>
                    <td>
                      <span className={p.is_active ? "efhc-status efhc-status-ok" : "efhc-status efhc-status-muted"}>
                        {p.is_active ? "ACTIVE" : "ARCHIVE"}
                      </span>
                    </td>
                    <td className="font-mono text-xs">{format8(p.generated_kwh)}</td>
                    <td>{new Date(p.created_at).toLocaleString()}</td>
                    <td>{p.expires_at ? new Date(p.expires_at).toLocaleString() : "-"}</td>
                    <td>{p.archived_at ? new Date(p.archived_at).toLocaleString() : "-"}</td>
                    <td>
                      <Button
                        variant={p.is_active ? "secondary" : "primary"}
                        disabled={busyId === p.id}
                        onClick={() => void toggle(p.id, !p.is_active)}
                      >
                        {busyId === p.id ? "…" : p.is_active ? "Deactivate" : "Activate"}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="text-xs efhc-text-muted">
            Canon note: database column name may be tg_id, but the value is Telegram ID.
          </div>
        </div>
      </Card>
    </AdminPage>
  );
}
