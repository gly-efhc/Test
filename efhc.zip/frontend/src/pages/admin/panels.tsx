import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { format8 } from "../../lib/format";

type PanelItem = {
  id: number;
  tg_id: number;
  is_active: boolean;
  created_at: string;
  expires_at?: string | null;
  archived_at?: string | null;
  last_generated_at?: string | null;
  base_gen_per_sec: string;
  generated_kwh: string;
};

type PanelsOut = {
  ok: boolean;
  items: PanelItem[];
};

export default function AdminPanelsPage() {
  const t = useT();
  const [tg_id, set_tg_id] = useState<string>("");
  const [onlyActive, setOnlyActive] = useState<boolean>(false);
  const [items, setItems] = useState<PanelItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [err, setErr] = useState<string>("");
  const [busyId, setBusyId] = useState<number | null>(null);

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams();
      if (tg_id.trim()) params.set("tg_id", tg_id.trim());
      if (onlyActive) params.set("is_active", "true");
      const data = await apiRequest<PanelsOut>(
        `/admin/panels?${params.toString()}`,
        "GET",
      );
      setItems(data.items || []);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  async function toggle(panelId: number, toActive: boolean) {
    setBusyId(panelId);
    setErr("");
    try {
      const path = toActive ?
        `/admin/panels/${panelId}/activate`
        : `/admin/panels/${panelId}/deactivate`;
      await apiRequest(path, "PATCH", {
        idempotencyKey: newIdempotencyKey(),
        body: {},
      });
      await load();
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setBusyId(null);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.panels")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.panels")}>
        <div className="grid gap-3">
          <div className="grid gap-2 md:grid-cols-3">
            <input
              className={
                "rounded-xl border border-white/10 bg-white/5 " +
                "px-3 py-2 text-sm outline-none"
              }
              placeholder="tg_id (optional)"
              value={tg_id}
              onChange={(e) => set_tg_id(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") load();
              }}
            />
            <label
              className={
                "flex items-center gap-2 rounded-xl border " +
                "border-white/10 bg-white/5 px-3 py-2 text-sm"
              }
            >
              <input
                type="checkbox"
                checked={onlyActive}
                onChange={(e) => setOnlyActive(e.target.checked)}
              />
              Only active
            </label>
            <Button className="bg-white text-black" onClick={load}>
              Refresh
            </Button>
          </div>

          {err ? (
            <div className="text-sm text-red-400">{err}</div>
          ) : null}
          {loading ? (
            <div className="text-sm text-gray-400">Loading…</div>
          ) : null}

          <div className="text-xs text-gray-400">
            Items: {items.length}
          </div>
          <div
            className="overflow-auto rounded-xl border border-white/10"
          >
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-xs text-gray-400">
                <tr>
                  <th className="px-3 py-2">Panel ID</th>
                  <th className="px-3 py-2">tg_id</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2">Generated kWh</th>
                  <th className="px-3 py-2">Created</th>
                  <th className="px-3 py-2">Expires</th>
                  <th className="px-3 py-2">Archived</th>
                  <th className="px-3 py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p.id} className="border-t border-white/10">
                    <td className="px-3 py-2 font-mono text-xs">
                      {p.id}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs">
                      {p.tg_id}
                    </td>
                    <td className="px-3 py-2">
                      {p.is_active ? (
                        <span
                          className={
                            "rounded-full bg-green-500/20 " +
                            "px-2 py-1 text-xs"
                          }
                        >
                          ACTIVE
                        </span>
                      ) : (
                        <span
                          className={
                            "rounded-full bg-gray-500/20 " +
                            "px-2 py-1 text-xs"
                          }
                        >
                          ARCHIVE
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs">
                      {format8(p.generated_kwh)}
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {new Date(p.created_at).toLocaleString()}
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {p.expires_at
                        ? new Date(p.expires_at).toLocaleString()
                        : "-"}
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {p.archived_at
                        ? new Date(p.archived_at).toLocaleString()
                        : "-"}
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex gap-2">
                        {p.is_active ? (
                          <Button
                            className="bg-white text-black"
                            disabled={busyId === p.id}
                            onClick={() => toggle(p.id, false)}
                          >
                            {busyId === p.id ? "…" : "Deactivate"}
                          </Button>
                        ) : (
                          <Button
                            className="bg-white text-black"
                            disabled={busyId === p.id}
                            onClick={() => toggle(p.id, true)}
                          >
                            {busyId === p.id ? "…" : "Activate"}
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="text-xs text-gray-500">
            Canon note: database column name may be tg_id,
            but the value is Telegram ID.
          </div>
        </div>
      </Card>
    </div>
  );
}