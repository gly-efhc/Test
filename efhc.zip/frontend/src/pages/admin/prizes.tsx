import React from "react";
import { Card } from "../../components/ui/Card";

export default function AdminPrizesPage() {
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Admin: Lotteries</h1>
      <Card title="Status">
        <div className="text-sm text-[color:var(--tg-hint)]">
          Admin page is temporarily disabled in this build.
        </div>
      </Card>
    </div>
  );
}
