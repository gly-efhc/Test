import React, { useContext, useMemo, useState } from "react";
import { useRouter } from "next/router";

import { LayoutContext } from "../components/Layout";
import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { EmptyState } from "../components/ui/EmptyState";
import {
  GameDetails,
  GameHero,
  GamePageShell,
  GameStat,
  GameStatsGrid,
} from "../components/ui/GameShell";
import { Skeleton } from "../components/ui/Skeleton";
import { ReferralRoster } from "../components/referrals/ReferralRoster";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { formatD8ToHuman } from "../lib/format";
import { publicApiErrorMessage } from "../lib/publicError";
import {
  hapticSelection,
  hapticSoft,
  openTelegramLink,
} from "../lib/telegram";
import { useReferralStats } from "../queries/useReferrals";
import type { ReferralTab } from "../services/referrals.service";

const SHARE_TARGETS = [
  ["telegram", "Telegram"],
  ["whatsapp", "WhatsApp"],
  ["viber", "Viber"],
  ["facebook", "Facebook"],
  ["x", "X"],
] as const;

function buildShareUrl(kind: string, link: string, text: string): string {
  const encodedLink = encodeURIComponent(link);
  const encodedText = encodeURIComponent(text);
  if (kind === "telegram") {
    return `https://t.me/share/url?url=${encodedLink}&text=${encodedText}`;
  }
  if (kind === "whatsapp") {
    return `https://wa.me/?text=${encodeURIComponent(`${text} ${link}`)}`;
  }
  if (kind === "viber") {
    return `viber://forward?text=${encodeURIComponent(`${text} ${link}`)}`;
  }
  if (kind === "facebook") {
    return `https://www.facebook.com/sharer/sharer.php?u=${encodedLink}`;
  }
  return `https://x.com/intent/tweet?url=${encodedLink}&text=${encodedText}`;
}

async function copyText(value: string): Promise<void> {
  if (typeof navigator === "undefined") return;
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
    return;
  }
  const input = document.createElement("textarea");
  input.value = value;
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  input.remove();
}

export default function ReferralsPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const td = useTD();
  const router = useRouter();
  const ctx = useContext(LayoutContext);
  const statsQ = useReferralStats(props.tg_id);
  const [referralTab, setReferralTab] = useState<ReferralTab>("active");

  const stats = statsQ.data;
  const bonusBalance =
    stats?.bonus_balance ?? props.snap?.profile?.bonus_balance ?? "0";
  const referralLink = stats?.referral_link?.trim() || "";
  const progress = useMemo(() => {
    const raw = Number(stats?.progress ?? 0);
    return Math.max(0, Math.min(1, raw));
  }, [stats?.progress]);
  const progressPct = `${(progress * 100).toFixed(2)}%`;
  const canShare = Boolean(referralLink);
  const shareText = t("referrals.share_invite_text").replace(
    "{{link}}",
    referralLink,
  );

  const onCopy = async () => {
    if (!referralLink) return;
    await copyText(referralLink);
    hapticSoft(ctx.settings.haptics_enabled);
    ctx.toast(t("referrals.link_copied"), "success");
  };

  const onShare = (kind: string) => {
    if (!referralLink) return;
    hapticSoft(ctx.settings.haptics_enabled);
    openTelegramLink(buildShareUrl(kind, referralLink, shareText));
  };

  const refresh = () => {
    hapticSelection(ctx.settings.haptics_enabled);
    void statsQ.refetch();
  };

  return (
    <GamePageShell
      className="efhc-referrals-shell"
      data-public-visual-beauty="tasks-referrals-ranks"
      data-public-surface="referrals"
      data-referrals-runtime="react-query-linkage-1558"
    >
      <GameHero
        kicker={t("referrals.game_kicker")}
        title={t("referrals.title")}
        detail={td("desc.referrals.invite_short")}
        icon="↗"
      >
        <GameStatsGrid compact>
          <GameStat
            label={t("referrals.bonus_balance")}
            value={
              statsQ.isLoading
                ? "…"
                : `${formatD8ToHuman(bonusBalance)} ${stats?.bonus_asset ?? "EFHCb"}`
            }
          />
          <GameStat
            label={t("referrals.active")}
            value={stats?.active_referrals ?? 0}
          />
          <GameStat
            label={t("referrals.bonus_total")}
            value={
              statsQ.isLoading
                ? "…"
                : `${formatD8ToHuman(
                    stats?.referrals_bonus_total ?? "0",
                  )} ${stats?.bonus_asset ?? "EFHCb"}`
            }
          />
        </GameStatsGrid>
      </GameHero>

      {statsQ.isError ? (
        <EmptyState
          title={t("referrals.load_error")}
          detail={publicApiErrorMessage(statsQ.error, t)}
          actionLabel={t("common.refresh")}
          onAction={refresh}
        />
      ) : null}

      <Card
        title={t("referrals.invite_title")}
        className="efhc-referrals-invite-card"
        data-referrals-invite-boundary="deep-link-share-1558"
        data-referrals-invite-canon="1295"
      >
        <div className="text-sm efhc-text-muted2">
          {td("desc.referrals.invite_short")}
        </div>
        <div
          className="efhc-referrals-link-card mt-3 rounded-2xl border efhc-pill-border p-3"
          data-referral-link-main="true"
        >
          <div className="break-all text-sm" data-referral-link-value="true">
            {referralLink || t("referrals.browser_link_pending")}
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button
            aria-label={t("referrals.copy_link")}
            data-referral-action="copy-link"
            disabled={!canShare}
            onClick={() => void onCopy()}
          >
            {t("referrals.copy_link")}
          </Button>
          <Button
            aria-label={`${t("referrals.share_link")}: Telegram`}
            data-referral-action="share-primary"
            variant="secondary"
            disabled={!canShare}
            onClick={() => onShare("telegram")}
          >
            {t("referrals.share_link")}
          </Button>
        </div>
        <div
          className="efhc-referrals-share-grid mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5"
          data-referral-share-grid="social"
        >
          {SHARE_TARGETS.map(([kind, label]) => (
            <Button
              key={kind}
              aria-label={`${t("referrals.share_link")}: ${label}`}
              data-referral-action="share-link"
              data-referral-share-kind={kind}
              variant="secondary"
              disabled={!canShare}
              onClick={() => onShare(kind)}
            >
              {label}
            </Button>
          ))}
        </div>
      </Card>

      <Card
        title={t("referrals.level_title")}
        data-referrals-progress-levels="1297"
        data-referrals-achievements="visible"
      >
        {statsQ.isLoading ? (
          <div className="grid gap-3">
            <Skeleton className="h-6" />
            <Skeleton className="h-3" />
          </div>
        ) : (
          <div className="grid gap-3">
            <div className="flex items-center justify-between gap-3">
              <div
                className="text-lg font-bold"
                data-referrals-current-lvl="true"
              >
                Lvl {stats?.level ?? 0}
              </div>
              <Badge>
                {stats?.active_referrals ?? 0}
                {stats?.next_level_min
                  ? ` / ${stats.next_level_min}`
                  : ` / ${stats?.max_active_for_unit_bonus ?? 10000}`}
              </Badge>
            </div>
            <div
              className="efhc-energy-progress-track"
              data-referrals-progress-bar="true"
            >
              <div
                aria-label={t("referrals.level_title")}
                className="efhc-energy-progress-fill"
                data-has-progress={progress > 0 ? "true" : "false"}
                style={{ width: progressPct }}
              />
            </div>
            <div className="text-sm efhc-text-muted2">
              {stats?.next_level === null
                ? t("referrals.max_level")
                : `${t("referrals.to_next")}: ${stats?.refs_to_next ?? 0}`}
            </div>
            <div
              className="rounded-2xl border efhc-pill-border p-3 text-sm"
              data-referral-bonus-wording="1298"
              data-referral-bonus-map="direct-plus-level-cumulative"
            >
              <div className="font-semibold">
                {t("referrals.bonus_rule_title")}
              </div>
              <div className="mt-1 efhc-text-muted2">
                {t("referrals.bonus_rule_active")}
              </div>
            </div>

            <div
              className="grid gap-2"
              data-referrals-level-scale="lvl-1-5"
            >
              {(stats?.level_steps ?? []).map((step) => {
                const reached = (stats?.level ?? 0) >= step.level;
                return (
                  <div
                    key={step.level}
                    className="efhc-referral-level-step rounded-2xl border p-3"
                    data-referral-level-step={step.level}
                    data-referral-level-state={
                      reached ? "reached" : "pending"
                    }
                  >
                    <div className="flex items-center justify-between gap-3">
                      <strong>Lvl {step.level}</strong>
                      <Badge>
                        {step.required_active} {t("referrals.active")}
                      </Badge>
                    </div>
                    <div className="mt-2 grid gap-1 text-xs efhc-text-muted2">
                      <div>
                        {t("referrals.direct_referral_rewards")}: {
                          stats?.unit_bonus_per_active ?? "0.1"
                        } × {step.required_active} = {
                          formatD8ToHuman(step.direct_bonus_total)
                        } {stats?.bonus_asset ?? "EFHCb"}
                      </div>
                      <div>
                        {t("referrals.level_reward")}: +{
                          formatD8ToHuman(step.level_bonus)
                        } {stats?.bonus_asset ?? "EFHCb"}
                      </div>
                      <div>
                        {t("referrals.cumulative_level_rewards")}: {
                          formatD8ToHuman(step.cumulative_level_bonus)
                        } {stats?.bonus_asset ?? "EFHCb"}
                      </div>
                      <div className="font-semibold efhc-text">
                        {t("referrals.cumulative_reward")}: {
                          formatD8ToHuman(step.cumulative_total_reward)
                        } {stats?.bonus_asset ?? "EFHCb"}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div
              className="rounded-2xl border efhc-pill-border p-3"
              data-referrals-full-cycle="10000-plus-lvl-1-5"
            >
              <div className="font-semibold">
                {t("referrals.full_cycle_title")}
              </div>
              <div className="mt-2 grid gap-1 text-sm efhc-text-muted2">
                <div>
                  {t("referrals.full_cycle_direct")}: {
                    formatD8ToHuman(stats?.full_cycle_direct_bonus ?? "1000")
                  } {stats?.bonus_asset ?? "EFHCb"}
                </div>
                <div>
                  {t("referrals.full_cycle_levels")}: {
                    formatD8ToHuman(stats?.full_cycle_level_bonus ?? "1411")
                  } {stats?.bonus_asset ?? "EFHCb"}
                </div>
                <div className="font-bold efhc-text">
                  {t("referrals.full_cycle_total")}: {
                    formatD8ToHuman(stats?.full_cycle_total_bonus ?? "2411")
                  } {stats?.bonus_asset ?? "EFHCb"}
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>

      <Card
        title={
          referralTab === "active"
            ? t("referrals.active_page")
            : t("referrals.inactive_page")
        }
        data-referrals-segments="active-inactive"
        data-referrals-list-mode="segmented-inline"
      >
        <div
          className="efhc-segmented efhc-referrals-tabs mb-3"
          data-referrals-tabs="active-inactive"
        >
          <Button
            variant={referralTab === "active" ? "primary" : "secondary"}
            data-referrals-tab-button="active"
            onClick={() => {
              hapticSelection(ctx.settings.haptics_enabled);
              setReferralTab("active");
            }}
          >
            {t("referrals.active")} ({stats?.active_referrals ?? 0})
          </Button>
          <Button
            variant={
              referralTab === "inactive" ? "primary" : "secondary"
            }
            data-referrals-tab-button="inactive"
            onClick={() => {
              hapticSelection(ctx.settings.haptics_enabled);
              setReferralTab("inactive");
            }}
          >
            {t("referrals.inactive")} ({stats?.inactive_referrals ?? 0})
          </Button>
        </div>
        <div className="mb-3 text-xs efhc-text-muted2">
          {referralTab === "active"
            ? t("referrals.active_page_hint")
            : t("referrals.inactive_page_hint")}
        </div>
        <ReferralRoster tg_id={props.tg_id} tab={referralTab} />
      </Card>

      <GameDetails summary={t("referrals.system_title")}>
        <div className="text-sm efhc-text-muted2">
          {td("desc.referrals.system_short")}
        </div>
        <button
          className="mt-3 text-sm underline"
          onClick={() => void router.push("/faq")}
          type="button"
        >
          {t("referrals.faq_link")}
        </button>
      </GameDetails>
    </GamePageShell>
  );
}
