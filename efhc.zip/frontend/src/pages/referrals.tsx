import React, { useEffect, useMemo, useState } from "react";
import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { Skeleton } from "../components/ui/Skeleton";
import { EmptyState } from "../components/ui/EmptyState";
import { apiRequest } from "../lib/api";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";

type Counters = { total: number; active: number; inactive: number };

type ReferralItem = {
  child_tg_id: number;
  username?: string | null;
  joined_at: string;
  is_active: boolean;
  total_generated_kwh: string;
  panels_count: number;
};

type PageOut = { items: ReferralItem[]; next_cursor: string | null };

type TabKey = "active" | "inactive";

async function fetchCounters(parent_tg_id: number): Promise<Counters> {
  return await apiRequest<Counters>(
    `/referrals/counters?parent_tg_id=${parent_tg_id}`,
    "GET",
  );
}

async function fetchPage(
  parent_tg_id: number,
  tab: TabKey,
  cursor: string | null,
): Promise<PageOut> {
  const base = tab === "active" ?
    "/referrals/active"
    : "/referrals/inactive";
  const p = new URLSearchParams();
  p.set("parent_tg_id", String(parent_tg_id));
  p.set("limit", "100");
  p.set("sync", "true");
  if (cursor) p.set("cursor", cursor);
  return await apiRequest<PageOut>(`${base}?${p.toString()}`, "GET");
}

export default function ReferralsPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const td = useTD();
  const parent_tg_id = props.tg_id;

  const [tab, setTab] = useState<TabKey>("active");

  const countersQ = useQuery({
    queryKey: ["refCounters", parent_tg_id],
    enabled: Boolean(parent_tg_id),
    staleTime: 30_000,
    queryFn: async () => {
      if (!parent_tg_id) throw new Error("tg_id required");
      return await fetchCounters(parent_tg_id);
    },
  });

  const listQ = useInfiniteQuery({
    queryKey: ["refList", parent_tg_id, tab],
    enabled: Boolean(parent_tg_id),
    staleTime: 30_000,
    initialPageParam: null as string | null,
    queryFn: async ({ pageParam }) => {
      if (!parent_tg_id) throw new Error("tg_id required");
      return await fetchPage(parent_tg_id, tab, pageParam);
    },
    getNextPageParam: (last) => last.next_cursor,
  });

  // Reset cache on tab switch (separate caches).
  useEffect(() => {
    void listQ.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, parent_tg_id]);

  const items = useMemo(() => {
    return (listQ.data?.pages || []).flatMap((p) => p.items || []);
  }, [listQ.data]);

  if (!parent_tg_id) {
    return (
      <Card title={t("referrals.title")}>
        <div className="text-sm text-[color:var(--tg-hint)]">
          {td("desc.common.need_telegram_webapp")}
        </div>
      </Card>
    );
  }

  const counters = countersQ.data ?? null;
  const loading = listQ.isFetching && items.length === 0;
  const err = (listQ.error ? String(listQ.error) : null) ||
    (countersQ.error ? String(countersQ.error) : null);

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{t("referrals.title")}</h1>

      <Card title={t("referrals.counters")}>
        <div className="flex items-center gap-3">
          <Badge>
            {t("referrals.total")}: {counters?.total ?? "—"}
          </Badge>
          <Badge>
            {t("referrals.active")}: {counters?.active ?? "—"}
          </Badge>
          <Badge>
            {t("referrals.inactive")}: {counters?.inactive ?? "—"}
          </Badge>
        </div>
        <div
          className={
            "mt-2 text-xs text-[color:var(--tg-hint)] opacity-80"
          }
        >
          {td("desc.referrals.active_rule")}
        </div>
      </Card>

      <Card title={t("referrals.list")}>
        <div className="flex gap-2 mb-3">
          <Button
            variant={tab === "active" ? "primary" : "secondary"}
            onClick={() => setTab("active")}
          >
            {t("referrals.tab_active")}
            {counters ? `(${counters.active})` : ""}
          </Button>
          <Button
            variant={tab === "inactive" ? "primary" : "secondary"}
            onClick={() => setTab("inactive")}
          >
            {t("referrals.tab_inactive")}
            {counters ? `(${counters.inactive})` : ""}
          </Button>
        </div>

        <div className="grid gap-2">
          {items.map((it) => (
            <div
              key={it.child_tg_id}
              className={`rounded-2xl p-3 border
                border-[color:var(--tg-hint)]
                bg-[color:var(--tg-secondary-bg)]/40
              `}
            >
              <div className="flex items-center justify-between">
                <div className="font-semibold">
                  {it.username
                    ? `@${it.username}`
                    : `TG ${it.child_tg_id}`}
                </div>
                {it.is_active ? (
                  <Badge>{t("referrals.active")}</Badge>
                ) : (
                  <Badge>{t("referrals.inactive")}</Badge>
                )}
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                <div>
                  <div className="text-xs efhc-text-muted2">
                    {t("referrals.joined_at")}
                  </div>
                  <div>{it.joined_at}</div>
                </div>
                <div>
                  <div className="text-xs efhc-text-muted2">
                    {t("referrals.panels_count")}
                  </div>
                  <div>{it.panels_count}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs efhc-text-muted2">
                    {t("referrals.total_generated")}
                  </div>
                  <div className={`font-semibold
                  `}>{it.total_generated_kwh}</div>
                </div>
              </div>
            </div>
          ))}

          {loading ? (
            <div className="grid gap-2">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          ) : null}

          {items.length === 0 && !listQ.isFetching ? (
            <EmptyState
              title={t("common.empty")}
              detail={err || td("desc.referrals.active_rule")}
              actionLabel="Refresh"
              onAction={() => void listQ.refetch()}
            />
          ) : null}

          <div className="flex items-center gap-2 mt-2">
            {listQ.hasNextPage ? (
              <Button
                disabled={listQ.isFetching}
                onClick={() => void listQ.fetchNextPage()}
              >
                {listQ.isFetching
                  ? t("common.loading")
                  : t("common.load_more")}
              </Button>
            ) : (
              <span className={`text-xs efhc-text-muted2
              `}>{t("common.end")}</span>
            )}
            <Button
              variant="secondary"
              disabled={listQ.isFetching}
              onClick={() => {
                void countersQ.refetch();
                void listQ.refetch();
              }}
            >
              Refresh
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
