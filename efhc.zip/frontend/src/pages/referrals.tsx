import React, { useContext, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/router";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Skeleton } from "../components/ui/Skeleton";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { format8 } from "../lib/format";
import { fetchReferralsStats } from "../lib/referrals";
import { hapticImpact, openTelegramLink } from "../lib/telegram";

function buildShareUrl(kind: string, link: string): string {
  const text = encodeURIComponent(
    `Join EFHC with my referral link: ${link}`,
  );
  const enc = encodeURIComponent(link);
  if (kind === "telegram") {
    return `https://t.me/share/url?url=${enc}&text=${text}`;
  }
  if (kind === "whatsapp") {
    return `https://wa.me/?text=${text}`;
  }
  if (kind === "viber") {
    return `viber://forward?text=${text}`;
  }
  if (kind === "facebook") {
    return `https://www.facebook.com/sharer/sharer.php?u=${enc}`;
  }
  return `https://x.com/intent/tweet?url=${enc}&text=${text}`;
}

async function copyText(value: string): Promise<void> {
  if (typeof navigator === "undefined") return;
  await navigator.clipboard.writeText(value);
}

export default function ReferralsPage(props: {
  tg_id: number;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const td = useTD();
  const ctx = useContext(LayoutContext);
  const router = useRouter();

  const statsQ = useQuery({
    queryKey: ["refStats", props.tg_id],
    staleTime: 30_000,
    queryFn: async () => {
      return await fetchReferralsStats(props.tg_id);
    },
  });

  const progressPct = useMemo(() => {
    const raw = Number(statsQ.data?.progress ?? 0);
    const clamped = Math.max(0, Math.min(1, raw));
    return `${(clamped * 100).toFixed(2)}%`;
  }, [statsQ.data?.progress]);

  const shareButtons = [
    ["telegram", "Telegram"],
    ["whatsapp", "WhatsApp"],
    ["viber", "Viber"],
    ["facebook", "Facebook"],
    ["x", "X"],
  ] as const;

  const bonusBalance = statsQ.data?.bonus_balance
    ?? props.snap?.profile?.bonus_balance
    ?? "0";
  const referralLink = statsQ.data?.referral_link || "";

  const onCopy = async () => {
    if (!referralLink) return;
    await copyText(referralLink);
    hapticImpact(ctx.settings.haptics_enabled);
    ctx.toast(t("referrals.link_copied"), "success");
  };

  const onShare = (kind: string) => {
    if (!referralLink) return;
    hapticImpact(ctx.settings.haptics_enabled);
    openTelegramLink(buildShareUrl(kind, referralLink));
  };

  return (
    <div className="grid gap-4">
      <section className="efhc-energy-hero p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-2xl font-bold">
              {t("referrals.title")}
            </div>
            <div className="mt-1 text-sm efhc-text-muted2">
              {td("desc.referrals.invite_short")}
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Card className="bg-transparent">
            <div className="text-xs efhc-text-muted2">
              {t("referrals.bonus_balance")}
            </div>
            {statsQ.isLoading ? (
              <Skeleton className="mt-2 h-8" />
            ) : (
              <div
                className={"mt-2 text-2xl font-bold "
                  + "efhc-energy-accent"}
              >
                {format8(bonusBalance)} EFHC
              </div>
            )}
          </Card>

          <Card className="bg-transparent">
            <div className="text-xs efhc-text-muted2">
              {t("referrals.bonus_total")}
            </div>
            {statsQ.isLoading ? (
              <Skeleton className="mt-2 h-8" />
            ) : (
              <div
                className={"mt-2 text-2xl font-bold "
                  + "efhc-energy-accent"}
              >
                {format8(statsQ.data?.referrals_bonus_total || "0")}
                {" "}EFHC
              </div>
            )}
          </Card>
        </div>
      </section>

      <Card title={t("referrals.invite_title")}>
        <div className="text-sm efhc-text-muted2">
          {td("desc.referrals.invite_short")}
        </div>
        <div className="mt-3 rounded-2xl border efhc-pill-border p-3">
          <div className="break-all text-sm">
            {referralLink || "—"}
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
          <Button onClick={() => void onCopy()}>
            {t("referrals.copy_link")}
          </Button>
          {shareButtons.map(([kind, label]) => (
            <Button
              key={kind}
              variant="secondary"
              onClick={() => onShare(kind)}
            >
              {label}
            </Button>
          ))}
        </div>
      </Card>

      <Card title={t("referrals.system_title")}>
        <div className="text-sm efhc-text-muted2">
          {td("desc.referrals.system_short")}
        </div>
        <div className="mt-3">
          <button
            className="text-sm underline"
            onClick={() => void router.push("/faq")}
            type="button"
          >
            {t("referrals.faq_link")}
          </button>
        </div>
      </Card>

      <Card title={t("referrals.level_title")}>
        {statsQ.isLoading ? (
          <div className="grid gap-3">
            <Skeleton className="h-6" />
            <Skeleton className="h-3" />
            <Skeleton className="h-4" />
          </div>
        ) : (
          <>
            <div className="text-sm font-semibold">
              {t("referrals.current_level")}: {statsQ.data?.level ?? 0}
            </div>
            <div className="mt-3 efhc-energy-progress-track">
              <div
                aria-label={t("referrals.level_title")}
                className="efhc-energy-progress-fill"
                style={{ width: progressPct }}
              />
            </div>
            <div className="mt-2 text-sm efhc-text-muted2">
              {statsQ.data?.next_level === null
                ? t("referrals.max_level")
                : `${t("referrals.to_next")}: `
                  + `${statsQ.data?.refs_to_next ?? 0}`}
            </div>
          </>
        )}
      </Card>

      <Card>
        <div className="grid grid-cols-2 gap-2">
          <Button onClick={() => void router.push("/referrals/active")}>
            {t("referrals.active")}
            {" "}({statsQ.data?.active_referrals ?? 0})
          </Button>
          <Button
            variant="secondary"
            onClick={() => void router.push("/referrals/inactive")}
          >
            {t("referrals.inactive")}
            {" "}({statsQ.data?.inactive_referrals ?? 0})
          </Button>
        </div>
      </Card>
    </div>
  );
}
