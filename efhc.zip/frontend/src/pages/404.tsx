import React from "react";
import { EmptyState } from "../components/ui/EmptyState";
import { useT } from "../hooks/useT";

export default function NotFoundPage() {
  const t = useT();
  return (
    <main className="min-h-screen p-4 flex items-center justify-center">
      <div className="max-w-md w-full">
        <EmptyState
          title={t("common.route_not_found_title")}
          detail={t("common.route_not_found_detail")}
          actionLabel={t("common.go_home")}
          onAction={() => window.location.assign("/")}
        />
      </div>
    </main>
  );
}
