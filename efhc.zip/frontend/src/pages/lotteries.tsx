import React, { useContext, useEffect, useMemo, useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import {
  format8,
  toScaledBigintDown,
  fromScaledBigint,
} from "../lib/format";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";

type DrawItem = {
  id: number;
  title: string;
  prize_type: string;
  prize_value: string;
  ticket_price: string;
  total_tickets: number;
  tickets_sold: number;
  status: string;
};

type LatestWinnerItem = {
  lotteries_id: number;
  title: string;
  prize_type: string;
  prize_value: string;
  winning_ticket_id: number;
  winning_ticket_number?: number | null;
  winner_tg_id: number;
  winner_username?: string | null;
  completed_at: string;
};

type LatestWinners = {
  efhc?: LatestWinnerItem | null;
  vip?: LatestWinnerItem | null;
};

type MyTicketsPage = {
  items: number[];
};

function remainingTickets(d: DrawItem): number {
  return Math.max(0, d.total_tickets - d.tickets_sold);
}

function isEfhcDraw(d: DrawItem): boolean {
  return String(d.prize_type || "").toUpperCase() === "EFHC";
}

function isNftDraw(d: DrawItem): boolean {
  return String(d.prize_type || "").toUpperCase() === "NFT";
}

function pct(d: DrawItem): number {
  if (!d.total_tickets) return 0;
  const v = (d.tickets_sold * 100) / d.total_tickets;
  return Math.max(0, Math.min(100, v));
}

function clampInt(x: number, lo: number, hi: number): number {
  const v = Math.trunc(Number.isFinite(x) ? x : lo);
  return Math.max(lo, Math.min(hi, v));
}

function formatWinnerLine(w: LatestWinnerItem): string {
  const uname = w.winner_username ? `@${w.winner_username}` : "";
  const tno = w.winning_ticket_number ?? w.winning_ticket_id;
  return (
    `Draw ${w.lotteries_id} • TG ${w.winner_tg_id} ` +
    `${uname} • Ticket #${tno}`
  );
}

export default function LotteriesPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const { settings, confirm, openWalletConnect } =
    useContext(LayoutContext);
  const tg_id = props.tg_id;
  const snap = props.snap;

  const [draws, setDraws] = useState<DrawItem[]>([]);
  const [myTickets, setMyTickets] = useState<
    Record<number, number[]>
  >({});
  const [latest, setLatest] = useState<LatestWinners | null>(null);

  const [qtyById, setQtyById] = useState<Record<number, number>>({});
  const [busyId, setBusyId] = useState<number | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const efhcDraw = useMemo(() => {
    return draws.find((d) => isEfhcDraw(d));
  }, [draws]);

  const vipDraw = useMemo(() => {
    return draws.find((d) => isNftDraw(d));
  }, [draws]);

  const load = async () => {
    if (!tg_id) return;

    const page = await apiRequest<any>(
      "/api/lotteries?limit=10",
      "GET",
    );
    const list: DrawItem[] = (page?.items || []).map((d: any) => ({
      id: Number(d.id),
      title: String(d.title || "Lotteries"),
      prize_type: String(d.prize_type || ""),
      prize_value: String(d.prize_value || ""),
      ticket_price: String(d.ticket_price || "0"),
      total_tickets: Number(d.total_tickets || 0),
      tickets_sold: Number(d.tickets_sold || 0),
      status: String(d.status || "active"),
    }));
    setDraws(list);

    const w = await apiRequest<any>(
      "/api/lotteries/winners/latest",
      "GET",
    );
    setLatest(w as LatestWinners);

    const ids = list.map((x) => x.id);
    const next: Record<number, number[]> = {};
    for (const id of ids) {
      try {
        const p = await apiRequest<MyTicketsPage>(
          `/api/lotteries/${id}/my-tickets?limit=200`,
          "GET",
        );
        next[id] = Array.isArray(p?.items) ? p.items : [];
      } catch {
        next[id] = [];
      }
    }
    setMyTickets(next);

    setQtyById((prev) => {
      const out: Record<number, number> = { ...prev };
      for (const d of list) {
        if (!out[d.id]) out[d.id] = 1;
      }
      return out;
    });
  };

  useEffect(() => {
    if (!tg_id) return;
    void load();
  }, [tg_id]);

  const balancesScaled = useMemo(() => {
    const b = snap?.profile?.bonus_balance ?? "0";
    const m = snap?.profile?.main_balance ?? "0";
    const bs = toScaledBigintDown(b, 8);
    const ms = toScaledBigintDown(m, 8);
    return bs + ms;
  }, [snap]);

  const buy = async (draw: DrawItem) => {
    if (!tg_id) return;

    const remaining = remainingTickets(draw);
    const maxPerDraw = 10;
    const already = (myTickets[draw.id] || []).length;
    const limitLeft = Math.max(0, maxPerDraw - already);

    const priceScaled = toScaledBigintDown(draw.ticket_price, 8);
    const maxByFunds =
      priceScaled > 0n ? Number(balancesScaled / priceScaled) : 0;
        const can = Math.max(
          0,
          Math.min(limitLeft, remaining, maxByFunds),
        );
    if (can <= 0) return;

    const qRaw = qtyById[draw.id] || 1;
    const q = clampInt(qRaw, 1, can);

    if (isNftDraw(draw)) {
      openWalletConnect();
    }

    const ok = await confirm(
      "purchase",
      "Buy tickets?",
      `Remaining: ${remaining}. You have: ${already}/${maxPerDraw}.`,
    );
    if (!ok) return;

    setBusyId(draw.id);
    setMsg(null);
    try {
      const idk = newIdempotencyKey();
      const url = `/api/lotteries/${draw.id}/buy`;
      const res = await apiRequest<any>(url, "POST", {
        idempotencyKey: idk,
        body: { qty: q },
      });
      setMsg(res?.detail || "OK");
      await load();
    } catch (e: any) {
      setMsg(String(e?.message || e));
      await load();
    } finally {
      setBusyId(null);
    }
  };

  if (!tg_id) {
    return (
      <Card title="Lotteries">
        <div className="text-sm text-[color:var(--tg-text)]">
          Open via Telegram WebApp.
        </div>
      </Card>
    );
  }

  const drawCards: Array<{
    key: string;
    title: string;
    d?: DrawItem | null;
  }> = [
    { key: "EFHC", title: "Lotteries 100 EFHC", d: efhcDraw },
    { key: "VIP", title: "Lotteries VIP NFT EFHC", d: vipDraw },
  ];

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Lotteries</h1>

      {msg ? (
        <Card title="Status">
          <div className="text-sm whitespace-pre-wrap">{msg}</div>
        </Card>
      ) : null}

      <Card title="Winners (latest)">
        <div className="grid gap-3 text-sm">
          <div>
            <div className="text-xs text-[color:var(--tg-hint)]">
              Lotteries 100 EFHC
            </div>
            {latest?.efhc ? (
              <div className="efhc-card p-3">
                <div className="font-semibold">{latest.efhc.title}</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  {formatWinnerLine(latest.efhc)}
                </div>
              </div>
            ) : (
              <div className="text-xs text-[color:var(--tg-hint)]">
                No winner yet
              </div>
            )}
          </div>

          <div>
            <div className="text-xs text-[color:var(--tg-hint)]">
              Lotteries VIP NFT EFHC
            </div>
            {latest?.vip ? (
              <div className="efhc-card p-3">
                <div className="font-semibold">{latest.vip.title}</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  {formatWinnerLine(latest.vip)}
                </div>
              </div>
            ) : (
              <div className="text-xs text-[color:var(--tg-hint)]">
                No winner yet
              </div>
            )}
          </div>
        </div>
      </Card>

      {drawCards.map((x) => {
        const d = x.d;
        if (!d) {
          return (
            <Card key={x.key} title={x.title}>
              <div className="text-sm text-[color:var(--tg-hint)]">
                No active draw
              </div>
            </Card>
          );
        }

        const remaining = remainingTickets(d);
        const already = (myTickets[d.id] || []).length;
        const maxPerDraw = 10;
        const limitLeft = Math.max(0, maxPerDraw - already);

        const priceScaled = toScaledBigintDown(d.ticket_price, 8);
        const maxByFunds =
          priceScaled > 0n ? Number(balancesScaled / priceScaled) : 0;
        const can = Math.max(
          0,
          Math.min(limitLeft, remaining, maxByFunds),
        );

        const qRaw = qtyById[d.id] || 1;
        const q = can > 0 ? clampInt(qRaw, 1, can) : 1;

        const costScaled = priceScaled * BigInt(q);
        const canAfford = balancesScaled >= costScaled;

        const disabled = busyId === d.id || can <= 0 || !canAfford;

        const onMinus = () => {
          setQtyById((prev) => ({
            ...prev,
            [d.id]: clampInt(
              (prev[d.id] || 1) - 1,
              1,
              Math.max(1, can),
            ),
          }));
        };

        const onPlus = () => {
          setQtyById((prev) => ({
            ...prev,
            [d.id]: clampInt(
              (prev[d.id] || 1) + 1,
              1,
              Math.max(1, can),
            ),
          }));
        };

        const costStr = fromScaledBigint(costScaled, 8);

        return (
          <Card key={x.key} title={x.title}>
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold">{d.title}</div>
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    Auto-run after the last ticket is bought.
                    No end timer.
                  </div>
                </div>
                <Badge>{d.status}</Badge>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    Ticket price
                  </div>
                  <div
                    className="font-semibold inline-flex items-center"
                  >
                    <span className="mr-1">
                      <EfhcCoinIcon size={24} />
                    </span>
                    {settings.hide_balances ?
                      "••••••••" :
                      format8(d.ticket_price)}
                    <span className="ml-1">EFHC</span>
                  </div>
                </div>

                <div>
                  <div className="text-xs text-[color:var(--tg-hint)]"
                  >
                    Prize
                  </div>
                  <div className="font-semibold">
                    {d.prize_type} {d.prize_value}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    Progress
                  </div>
                  <div className="font-semibold">
                    {d.tickets_sold} / {d.total_tickets}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    Remaining
                  </div>
                  <div className="font-semibold">{remaining}</div>
                </div>
              </div>

              <div
                className={
                  "h-2 w-full rounded-xl " +
                  "bg-[color:var(--tg-hint)]/30"
                }
              >
                <div
                  className="h-2 rounded-xl bg-[color:var(--tg-accent)]"
                  style={{ width: `${pct(d)}%` }}
                />
              </div>

              <div className="grid gap-2">
                <div className="text-xs text-[color:var(--tg-hint)]">
                  My tickets: {already}/{maxPerDraw}
                </div>
                <div className="text-xs break-words">
                  {(myTickets[d.id] || []).length ? (
                    (myTickets[d.id] || []).join(", ")
                  ) : (
                    <span className="text-[color:var(--tg-hint)]">
                      No tickets yet
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  disabled={busyId === d.id || can <= 0 || q <= 1}
                  onClick={onMinus}
                >
                  -
                </Button>

                <div className="min-w-[4rem] text-center text-sm">
                  {q} / {Math.max(1, can)}
                </div>

                <Button
                  disabled={busyId === d.id || can <= 0 || q >= can}
                  onClick={onPlus}
                >
                  +
                </Button>

                <div
                  className={
                    "ml-auto text-xs " +
                    "text-[color:var(--tg-hint)]"
                  }
                >
                  Cost: {settings.hide_balances ?
                    "••••••••" :
                    format8(costStr)}
                </div>
              </div>

              <Button disabled={disabled} onClick={() => buy(d)}>
                {busyId === d.id ? "Loading…" : "Buy tickets"}
              </Button>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
