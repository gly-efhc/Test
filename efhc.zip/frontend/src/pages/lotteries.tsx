import React, { useContext, useEffect, useMemo, useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { format8 } from "../lib/format";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";
import { useWalletsMe } from "../hooks/useWalletsMe";

type LotteriesItem = {
  id: number;
  title: string;
  prize_type: string;
  prize_value: string;
  ticket_price: string;
  total_tickets: number;
  tickets_sold: number;
  status: string;
};

type LotteriesResult = {
  winner_tg_id: number;
  winning_ticket_id: number;
  completed_at: string;
};

type LotteriesHistoryItem = {
  id: number;
  title: string;
  prize_type: string;
  prize_value: string;
  ticket_price: string;
  total_tickets: number;
  tickets_sold: number;
  status: string;
  created_at: string;
  result?: LotteriesResult | null;
};

export default function LotteriesPage(
  props: {
    tg_id: number | null;
    snap: SyncSnapshot | null;
  },
) {
  const { settings, confirm, openWalletConnect } = useContext(
    LayoutContext,
  );
  const tg_id = props.tg_id;

  const walletsMe = useWalletsMe(tg_id);
  const walletConnected = Boolean(walletsMe.data?.is_connected);

  const [items, setItems] = useState<LotteriesItem[]>([]);
  const [history, setHistory] = useState<LotteriesHistoryItem[]>([]);
  const [qty, setQty] = useState(1);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const current = items.find((x) => x.status === "active") || items[0];

  const remaining = useMemo(() => {
    if (!current) return 0;
    return Math.max(
      0,
      Number(current.total_tickets) - Number(current.tickets_sold),
    );
  }, [current]);

  const maxCanBuy = useMemo(() => {
    if (!current) return 0;
    return Math.max(0, Math.min(10, remaining));
  }, [current, remaining]);

  const load = async () => {
    if (!tg_id) return;
    const page = await apiRequest<any>(
      `/api/lotteries?limit=10`,
      "GET",
    );
    const list: LotteriesItem[] = (page?.items || []).map((d: any) => ({
      id: Number(d.id),
      title: String(d.title || "Item"),
      prize_type: String(d.prize_type || ""),
      prize_value: String(d.prize_value || ""),
      ticket_price: String(d.ticket_price || "0"),
      total_tickets: Number(d.total_tickets || 0),
      tickets_sold: Number(d.tickets_sold || 0),
      status: String(d.status || "active"),
    }));
    setItems(list);

    const h = await apiRequest<any>(
      `/api/lotteries/history?limit=20`,
      "GET",
    );
    setHistory((h?.items || []) as LotteriesHistoryItem[]);
  };

  useEffect(() => {
    if (!tg_id) return;
    void load();
  }, [tg_id]);

  const buy = async () => {
    if (!tg_id || !current) return;
    if (!walletConnected) {
      openWalletConnect();
      return;
    }
    const can = maxCanBuy;
    if (can <= 0) return;
    const q = Math.max(1, Math.min(can, qty));
    const ok = await confirm(
      "purchase",
      "Buy tickets?",
      `You can have up to 10 tickets total. Remaining: ${remaining}.`,
    );
    if (!ok) return;
    setBusy(true);
    setMsg(null);
    try {
      const idk = newIdempotencyKey();
      const url = `/api/lotteries/${current.id}/buy`;
      const res = await apiRequest<any>(url, "POST", {
        idempotencyKey: idk,
        body: { qty: q },
      });
      setMsg(res?.detail || "OK");
      await load();
    } catch (e: any) {
      setMsg(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  if (!tg_id) {
    return (
      <Card title="Lotteries">
        <div className="text-sm text-[color:var(--tg-text)]">
          Open via Telegram WebApp.
        </div>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Lotteries</h1>

      {msg ? (
        <Card title="Status">
          <div className="text-sm whitespace-pre-wrap">{msg}</div>
        </Card>
      ) : null}

      <Card title="Current">
        {!current ? (
          <div className="text-sm text-[color:var(--tg-hint)]">
            No active item
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="font-semibold">{current.title}</div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Auto-run after the last ticket is bought.
                  No end timer.
                </div>
              </div>
              <Badge>{current.status}</Badge>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Ticket price
                </div>
                <div
                  className={
                    "font-semibold inline-flex items-center " +
                    "gap-1"
                  }
                >
                  <EfhcCoinIcon size={24} />
                  {settings.hide_balances ?
                    "••••••••" :
                    format8(current.ticket_price)}
                  EFHC
                </div>
              </div>
              <div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Prize
                </div>
                <div className="font-semibold">
                  {current.prize_type} {current.prize_value}
                </div>
              </div>
              <div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Tickets remaining
                </div>
                <div className="font-semibold">{remaining}</div>
              </div>
              <div>
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Total tickets
                </div>
                <div className="font-semibold">
                  {current.tickets_sold} / {current.total_tickets}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={Math.max(1, maxCanBuy)}
                value={qty}
                onChange={(e) => setQty(Number(e.target.value || 1))}
                className={
                  "border border-[color:var(--tg-hint)] "
                  + "bg-[var(--tg-bg)] rounded-xl px-3 py-2 w-28"
                }
              />
              <Button disabled={busy || maxCanBuy <= 0} onClick={buy}>
                {busy ? "Loading…" : `Buy (max ${maxCanBuy})`}
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Card title="History">
        <div className="space-y-2">
          {history.length === 0 ? (
            <div className="text-sm text-[color:var(--tg-hint)]">
              No items yet
            </div>
          ) : null}
          {history.map((h, idx) => (
            <div
              key={`${h.id}-${idx}`}
              className={
                "efhc-card p-3"
              }
            >
              <div className="flex items-center justify-between">
                <div className="font-semibold">ID {h.id}</div>
                <Badge>{h.status}</Badge>
              </div>
              <div className="text-sm mt-1">{h.title}</div>
              <div className="text-xs text-[color:var(--tg-hint)] mt-1">
                {h.prize_type} {h.prize_value}
              </div>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Tickets: {h.tickets_sold}/{h.total_tickets}
              </div>
              {h.result?.winner_tg_id ? (
                <div className="text-xs text-[color:var(--tg-hint)]">
                  Winner TG: {h.result.winner_tg_id}
                </div>
              ) : null}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
