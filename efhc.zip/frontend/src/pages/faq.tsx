import React, { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { useT } from "../hooks/useT";
import { LayoutContext } from "../components/Layout";
import {
  faqCounts,
  findSection,
  findSubsection,
  getFaqCatalog,
  getRelatedFaqItems,
  searchFaq,
} from "../data/faq";

function searchNorm(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function excerpt(text: string, query: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "";
  const q = searchNorm(query);
  if (!q) return clean;
  const base = searchNorm(clean);
  const pos = base.indexOf(q);
  if (pos < 0) return clean;
  const start = Math.max(0, pos - 56);
  const end = Math.min(clean.length, pos + q.length + 84);
  const part = clean.slice(start, end).trim();
  return `${start > 0 ? "…" : ""}${part}${end < clean.length
    ? "…"
    : ""}`;
}

export default function FaqPage() {
  const t = useT();
  const router = useRouter();
  const ctx = React.useContext(LayoutContext);
  const catalog = useMemo(() => getFaqCatalog(ctx.lang), [ctx.lang]);
  const counts = useMemo(() => faqCounts(catalog), [catalog]);
  const [query, setQuery] = useState<string>("");
  const [sectionId, setSectionId] = useState<string | null>(null);
  const [subsectionId, setSubsectionId] = useState<string | null>(null);
  const [openItemId, setOpenItemId] = useState<string | null>(null);

  const activeSection = useMemo(() => {
    return findSection(catalog, sectionId);
  }, [catalog, sectionId]);

  const activeSubsection = useMemo(() => {
    return findSubsection(catalog, sectionId, subsectionId);
  }, [catalog, sectionId, subsectionId]);

  const relatedItems = useMemo(() => {
    return getRelatedFaqItems(
      catalog,
      openItemId,
      sectionId,
      subsectionId,
      6,
    );
  }, [catalog, openItemId, sectionId, subsectionId]);

  const results = useMemo(() => {
    return searchFaq(catalog, query).slice(0, 24);
  }, [catalog, query]);

  useEffect(() => {
    const rawSection = typeof router.query.section === "string"
      ? router.query.section
      : null;
    const rawSubsection = typeof router.query.subsection === "string"
      ? router.query.subsection
      : null;
    const rawItem = typeof router.query.item === "string"
      ? router.query.item
      : null;

    setSectionId(rawSection);
    setSubsectionId(rawSubsection);
    setOpenItemId(rawItem);
  }, [
    router.query.item,
    router.query.section,
    router.query.subsection,
  ]);

  const openSection = (nextSectionId: string) => {
    setSectionId(nextSectionId);
    setSubsectionId(null);
    setOpenItemId(null);
    void router.push(
      {
        pathname: "/faq",
        query: { section: nextSectionId },
      },
      undefined,
      { shallow: true },
    );
  };

  const openSubsection = (
    nextSectionId: string,
    nextSubsectionId: string,
  ) => {
    setSectionId(nextSectionId);
    setSubsectionId(nextSubsectionId);
    setOpenItemId(null);
    void router.push(
      {
        pathname: "/faq",
        query: {
          section: nextSectionId,
          subsection: nextSubsectionId,
        },
      },
      undefined,
      { shallow: true },
    );
  };

  const openQuestion = (
    nextSectionId: string,
    nextSubsectionId: string,
    nextItemId: string,
  ) => {
    setSectionId(nextSectionId);
    setSubsectionId(nextSubsectionId);
    setOpenItemId((prev) => {
      return prev === nextItemId ? null : nextItemId;
    });
    void router.push(
      {
        pathname: "/faq",
        query: {
          section: nextSectionId,
          subsection: nextSubsectionId,
          item: nextItemId,
        },
      },
      undefined,
      { shallow: true },
    );
  };

  const goToSections = () => {
    setSectionId(null);
    setSubsectionId(null);
    setOpenItemId(null);
    void router.push("/faq", undefined, { shallow: true });
  };

  const goToSubsections = () => {
    if (!activeSection) return;
    setSubsectionId(null);
    setOpenItemId(null);
    void router.push(
      {
        pathname: "/faq",
        query: { section: activeSection.id },
      },
      undefined,
      { shallow: true },
    );
  };

  return (
    <div className="grid gap-4">
      <section className="efhc-energy-hero p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-2xl font-bold">{t("faq.title")}</div>
            <div className="mt-1 text-sm efhc-text-muted2">
              {catalog.title}: {counts.sections} / {counts.subsections}
              {" / "}
              {counts.items}
            </div>
          </div>
        </div>

        <div className="mt-2 text-sm efhc-text-muted2">
          {t("faq.search_scope")}
        </div>

        <div className="mt-4 rounded-2xl border efhc-pill-border p-3">
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t("faq.search_placeholder")}
            className={[
              "w-full bg-transparent outline-none",
              "text-[var(--tg-text)] placeholder:text-",
              "[var(--tg-hint)]",
            ].join(" ")}
          />
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          {catalog.sections.slice(0, 6).map((section) => (
            <button
              key={section.id}
              type="button"
              onClick={() => openSection(section.id)}
              className={[
                "rounded-full px-3 py-1 text-xs font-semibold",
                "border efhc-pill-border",
                sectionId === section.id
                  ? "bg-[var(--tg-button)] text-[var(--tg-button-text)]"
                  : "bg-[var(--tg-secondary-bg)]",
              ].join(" ")}
            >
              {section.id}. {section.title}
            </button>
          ))}
        </div>
      </section>

      {query.trim() ? (
        <Card title={t("faq.search_results")}>
          {results.length ? (
            <div className="grid gap-3">
              {results.map((hit) => (
                <button
                  key={hit.item.id}
                  type="button"
                  className={[
                    "rounded-2xl border efhc-pill-border p-3 text-left",
                    "bg-[var(--tg-secondary-bg)]",
                  ].join(" ")}
                  onClick={() => {
                    openQuestion(
                      hit.section.id,
                      hit.subsection.id,
                      hit.item.id,
                    );
                    setQuery("");
                  }}
                >
                  <div className="text-xs efhc-text-muted2">
                    {hit.section.title} {" -> "}{hit.subsection.title}
                  </div>
                  <div className="mt-1 text-sm font-semibold">
                    {hit.item.question}
                  </div>
                  <div className="mt-2 text-sm efhc-text-muted2">
                    {excerpt(hit.item.answer, query)}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-sm efhc-text-muted2">
              {t("faq.no_matches")}
            </div>
          )}
        </Card>
      ) : null}

      {!query.trim() && !activeSection ? (
        <Card title={t("faq.sections")}>
          <div className="grid gap-3">
            {catalog.sections.map((section) => {
              const itemCount = section.subsections.reduce(
                (sum, subsection) => sum + subsection.items.length,
                0,
              );
              return (
                <button
                  key={section.id}
                  type="button"
                  onClick={() => openSection(section.id)}
                  className={[
                    "rounded-2xl border efhc-pill-border p-4 text-left",
                    "bg-[var(--tg-secondary-bg)]",
                  ].join(" ")}
                >
                  <div className="text-xs efhc-text-muted2">
                    {t("faq.section_label")} {section.id}
                  </div>
                  <div className="mt-1 text-base font-semibold">
                    {section.title}
                  </div>
                  <div className="mt-2 text-sm efhc-text-muted2">
                    {section.subsections.length}
                    {" "}
                    {t("faq.subsections_count")}
                    {" / "}
                    {itemCount}
                    {" "}
                    {t("faq.questions_count")}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>
      ) : null}

      {!query.trim() && activeSection && !activeSubsection ? (
        <Card title={activeSection.title}>
          <div className="mb-3 flex flex-wrap gap-2">
            <Button variant="secondary" onClick={goToSections}>
              {t("faq.back_to_sections")}
            </Button>
          </div>
          <div className="grid gap-3">
            {activeSection.subsections.map((subsection) => (
              <button
                key={subsection.id}
                type="button"
                onClick={() => {
                  openSubsection(activeSection.id, subsection.id);
                }}
                className={[
                  "rounded-2xl border efhc-pill-border p-4 text-left",
                  "bg-[var(--tg-secondary-bg)]",
                ].join(" ")}
              >
                <div className="text-xs efhc-text-muted2">
                  {subsection.id}
                </div>
                <div className="mt-1 text-base font-semibold">
                  {subsection.title}
                </div>
                <div className="mt-2 text-sm efhc-text-muted2">
                  {subsection.items.length}
                  {" "}
                  {t("faq.questions_count")}
                </div>
              </button>
            ))}
          </div>
        </Card>
      ) : null}

      {!query.trim() && activeSection && activeSubsection ? (
        <>
          <Card title={activeSection.title}>
            <div className="flex flex-wrap gap-2">
              <Button variant="secondary" onClick={goToSections}>
                {t("faq.back_to_sections")}
              </Button>
              <Button variant="secondary" onClick={goToSubsections}>
                {t("faq.back_to_subsections")}
              </Button>
            </div>
            <div className="mt-3 text-sm efhc-text-muted2">
              {activeSubsection.id} - {activeSubsection.title}
            </div>
          </Card>

          <div className="grid gap-3">
            {activeSubsection.items.map((item) => {
              const isOpen = openItemId === item.id;
              return (
                <Card key={item.id} className="bg-transparent">
                  <button
                    type="button"
                    className="w-full text-left"
                    onClick={() => {
                      openQuestion(
                        activeSection.id,
                        activeSubsection.id,
                        item.id,
                      );
                    }}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-1 text-sm font-semibold">
                        {item.question}
                      </div>
                      <div className="text-lg leading-none">
                        {isOpen ? "−" : "+"}
                      </div>
                    </div>
                  </button>
                  {isOpen ? (
                    <div className="mt-3 text-sm leading-6">
                      {item.answer}
                    </div>
                  ) : null}
                </Card>
              );
            })}
          </div>

          <Card title={t("faq.related_questions")}>
            <div className="grid gap-2">
              {relatedItems.map((item) => (
                <button
                  key={`rel-${item.id}`}
                  type="button"
                  onClick={() => {
                    openQuestion(
                      activeSection.id,
                      activeSubsection.id,
                      item.id,
                    );
                  }}
                  className={[
                    "rounded-2xl border efhc-pill-border p-3 text-left",
                    "bg-[var(--tg-secondary-bg)]",
                  ].join(" ")}
                >
                  <div className="text-sm">{item.question}</div>
                </button>
              ))}
            </div>
          </Card>
        </>
      ) : null}
    </div>
  );
}
