import React, { useMemo } from "react";
import { useRouter } from "next/router";
import { LayoutContext } from "../components/Layout";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import {
  TelegramCategoryPills,
} from "../components/ui/telegram/TelegramCategoryPills";
import { FaqHeader } from "../components/faq/FaqHeader";
import { FaqSearchBar } from "../components/faq/FaqSearchBar";
import {
  FaqPopularQuestions,
} from "../components/faq/FaqPopularQuestions";
import { FaqSectionList } from "../components/faq/FaqSectionList";
import { FaqSubsectionList } from "../components/faq/FaqSubsectionList";
import { FaqAccordionList } from "../components/faq/FaqAccordionList";
import {
  FaqBreadcrumbHeader,
} from "../components/faq/FaqBreadcrumbHeader";
import { FaqNoResultsState } from "../components/faq/FaqNoResultsState";
import { useT } from "../hooks/useT";
import { useFaqCatalog } from "../hooks/faq/useFaqCatalog";
import { useFaqNavigation } from "../hooks/faq/useFaqNavigation";
import { useFaqSearch } from "../hooks/faq/useFaqSearch";
import {
  faqCounts,
  findSection,
  findSubsection,
  getFaqPreviewItems,
  getRelatedFaqItems,
} from "../data/faq";
import { excerpt } from "../lib/faq/search";

export default function FaqPage() {
  const t = useT();
  const router = useRouter();
  const ctx = React.useContext(LayoutContext);
  const catalog = useFaqCatalog(ctx.lang);
  const counts = useMemo(() => faqCounts(catalog), [catalog]);
  const nav = useFaqNavigation();
  const search = useFaqSearch(catalog);

  const activeSection = useMemo(() => {
    return findSection(catalog, nav.sectionId);
  }, [catalog, nav.sectionId]);
  const activeSubsection = useMemo(() => {
    return findSubsection(catalog, nav.sectionId, nav.subsectionId);
  }, [catalog, nav.sectionId, nav.subsectionId]);
  const relatedItems = useMemo(() => {
    return getRelatedFaqItems(
      catalog,
      nav.openItemId,
      nav.sectionId,
      nav.subsectionId,
      6,
    );
  }, [catalog, nav.openItemId, nav.sectionId, nav.subsectionId]);
  const popular = useMemo(() => {
    return getFaqPreviewItems(
      catalog,
      [
        { sectionId: "1", subsectionId: "1.1" },
        { sectionId: "2", subsectionId: "2.1" },
        { sectionId: "4", subsectionId: "4.1" },
        { sectionId: "5", subsectionId: "5.1" },
        { sectionId: "7", subsectionId: "7.1" },
        { sectionId: "11", subsectionId: "11.1" },
      ],
      6,
    );
  }, [catalog]);

  const subtitle = `${catalog.title}: ${counts.sections} / `
    + `${counts.subsections} / ${counts.items}`;

  return (
    <div className="grid gap-4">
      <FaqHeader
        title={t("faq.title")}
        subtitle={subtitle}
        scope={t("faq.search_scope")}
      />

      <div
        className="sticky top-0 z-20 space-y-3 bg-[var(--tg-bg)] pb-1"
      >
        <FaqSearchBar
          value={search.query}
          onChange={search.setQuery}
          placeholder={t("faq.search_placeholder")}
          resultCount={
            search.hasQuery ? search.results.length : undefined
          }
          onClear={search.clearQuery}
        />
        {!search.hasQuery ? (
          <TelegramCategoryPills
            items={catalog.sections.map((section) => ({
              id: section.id,
              label: section.title,
            }))}
            activeId={nav.sectionId}
            onSelect={nav.openSection}
          />
        ) : null}
      </div>

      {search.hasQuery ? (
        <Card title={t("faq.search_results")}>
          {search.results.length ? (
            <div className="grid gap-3">
              {search.results.map((hit) => (
                <button
                  key={hit.item.id}
                  type="button"
                  className={[
                    "rounded-2xl border p-3 text-left",
                    "border-[color:var(--tg-hint)]/20",
                    "bg-[var(--tg-secondary-bg)]",
                  ].join(" ")}
                  onClick={() => {
                    nav.openQuestion(
                      hit.section.id,
                      hit.subsection.id,
                      hit.item.id,
                    );
                    search.clearQuery();
                  }}
                >
                  <div className="text-xs efhc-text-muted2">
                    {hit.section.title} → {hit.subsection.title}
                  </div>
                  <div className="mt-1 text-sm font-semibold">
                    {hit.item.question}
                  </div>
                  <div className="mt-2 text-sm efhc-text-muted2">
                    {excerpt(hit.item.answer, search.query)}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <FaqNoResultsState
              title={t("faq.no_matches")}
              detail={t("faq.search_scope")}
              onReset={search.clearQuery}
            />
          )}
        </Card>
      ) : null}

      {!search.hasQuery && !activeSection ? (
        <>
          <Card title={t("faq.sections")}>
            <FaqPopularQuestions
              items={popular}
              onOpen={(entry) => {
                nav.openQuestion(
                  entry.section.id,
                  entry.subsection.id,
                  entry.item.id,
                );
              }}
            />
          </Card>
          <Card title={t("faq.sections")}>
            <FaqSectionList
              sections={catalog.sections}
              countLabel={t("faq.subsections_count")}
              questionsLabel={t("faq.questions_count")}
              onOpen={nav.openSection}
            />
          </Card>
        </>
      ) : null}

      {!search.hasQuery && activeSection && !activeSubsection ? (
        <Card title={activeSection.title}>
          <div className="mb-3 flex flex-wrap gap-2">
            <Button variant="secondary" onClick={nav.goToSections}>
              {t("faq.back_to_sections")}
            </Button>
          </div>
          <FaqSubsectionList
            section={activeSection}
            questionsLabel={t("faq.questions_count")}
            onOpen={nav.openSubsection}
          />
        </Card>
      ) : null}

      {!search.hasQuery && activeSection && activeSubsection ? (
        <>
          <Card title={activeSection.title}>
            <FaqBreadcrumbHeader
              parts={[
                t("faq.title"),
                activeSection.title,
                activeSubsection.title,
              ]}
              onBack={nav.goToSubsections}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <Button variant="secondary" onClick={nav.goToSections}>
                {t("faq.back_to_sections")}
              </Button>
              <Button variant="secondary" onClick={nav.goToSubsections}>
                {t("faq.back_to_subsections")}
              </Button>
            </div>
          </Card>
          <FaqAccordionList
            subsection={activeSubsection}
            openItemId={nav.openItemId}
            relatedTitle={t("faq.related_questions")}
            relatedItems={relatedItems}
            onOpen={(itemId) => {
              nav.openQuestion(
                activeSection.id,
                activeSubsection.id,
                itemId,
              );
            }}
            onQuickWallet={() => ctx.openProfile("wallet")}
            onQuickHistory={() => ctx.openProfile("history")}
            onQuickPage={(href) => {
              void router.push(href);
            }}
          />
        </>
      ) : null}
    </div>
  );
}
