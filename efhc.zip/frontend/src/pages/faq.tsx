import React, { useMemo } from "react";
import { LayoutContext } from "../components/Layout";
import { Card } from "../components/ui/Card";
import { FaqHeader } from "../components/faq/FaqHeader";
import { FaqSearchBar } from "../components/faq/FaqSearchBar";
import { FaqNoResultsState } from "../components/faq/FaqNoResultsState";
import { FaqVerticalTree } from "../components/faq/FaqVerticalTree";
import { useT } from "../hooks/useT";
import { useFaqCatalog } from "../hooks/faq/useFaqCatalog";
import { useFaqNavigation } from "../hooks/faq/useFaqNavigation";
import { useFaqSearch } from "../hooks/faq/useFaqSearch";
import { faqCounts } from "../data/faq/utils";
import { excerpt } from "../lib/faq/search";
import { FaqAnswerText } from "../components/faq/FaqAnswerText";

export default function FaqPage() {
  const t = useT();
  const ctx = React.useContext(LayoutContext);
  const faq = useFaqCatalog(ctx.lang);
  const catalog = faq.catalog;
  const counts = useMemo(() => faqCounts(catalog), [catalog]);
  const nav = useFaqNavigation();
  const search = useFaqSearch(catalog);

  const subtitle = t("faq.counts_summary")
    .replace("{sections}", String(counts.sections))
    .replace("{subsections}", String(counts.subsections))
    .replace("{items}", String(counts.items));

  return (
    <div
      key={ctx.lang}
      className="efhc-faq-shell grid gap-3"
      data-public-visual-trust="profile-wallet-history-faq"
      data-public-surface="faq"
      data-faq-compact-tree="1309"
      data-faq-no-horizontal-pills="true"
      data-public-no-admin-diagnostics="true"
      data-public-no-raw-payload="true"
    >
      <FaqHeader
        title={t("faq.title")}
        subtitle={subtitle}
        scope={t("faq.search_scope")}
      />

      <div
        className="efhc-faq-trust-rail"
        data-faq-trust-rail="sections-search-tree"
      >
        <span>{t("faq.sections")}: {counts.sections}</span>
        <span>{t("faq.search_results")}</span>
        <span>{t("faq.search_scope")}</span>
      </div>

      {faq.loading ? (
        <div
          className="efhc-faq-load-progress"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={faq.progress}
        >
          <span style={{ width: `${faq.progress}%` }} />
        </div>
      ) : null}

      <div
        className="efhc-faq-search-index-status"
        data-faq-search-worker={search.workerBacked ? "worker" : "fallback"}
        role="status"
        aria-live="polite"
      >
        {search.indexReady
          ? t("faq.search_index_ready")
          : t("faq.search_index_building")}
      </div>

      <FaqSearchBar
        value={search.query}
        onChange={search.setQuery}
        placeholder={t("faq.search_placeholder")}
        resultCount={
          search.hasQuery ? search.results.length : undefined
        }
        onClear={search.clearQuery}
      />

      {search.hasQuery ? (
        <Card title={t("faq.search_results")}> 
          {search.results.length ? (
            <div className="efhc-faq-search-results">
              {search.results.map((hit) => (
                <details
                  key={hit.item.id}
                  className="efhc-faq-question-node"
                >
                  <summary>{hit.item.question}</summary>
                  <div className="efhc-faq-answer-block">
                    <div className="text-xs efhc-text-muted2">
                      {hit.section.title} → {hit.subsection.title}
                    </div>
                    <FaqAnswerText
                      compact
                      text={excerpt(hit.item.answer, search.query)}
                    />
                  </div>
                </details>
              ))}
            </div>
          ) : (
            <FaqNoResultsState
              title={t("faq.no_matches")}
              detail={t("faq.search_scope")}
              onReset={search.clearQuery}
            />
          )}
        </Card>
      ) : (
        <Card title={t("faq.sections")}>
          <FaqVerticalTree
            catalog={catalog}
            defaultItemId={nav.openItemId}
            compactTreeProof="1309"
          />
        </Card>
      )}
    </div>
  );
}
