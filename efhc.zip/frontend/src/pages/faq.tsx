import React from "react";
import { Card } from "../components/ui/Card";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";

export default function FaqPage() {
  const t = useT();
  const td = useTD();

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{t("faq.title")}</h1>
      <Card title={t("faq.title")}>
        <div className="text-sm efhc-text-muted2">
          {td("desc.faq.soon")}
        </div>
      </Card>
    </div>
  );
}
