import React from "react";
import {
  ReferralListPage,
} from "../../components/referrals/ReferralListPage";

export default function ReferralsActivePage(props: {
  tg_id: number;
}) {
  return <ReferralListPage parent_tg_id={props.tg_id} tab="active" />;
}
