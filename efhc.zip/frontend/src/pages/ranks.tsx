import React, { useEffect, useMemo, useState } from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { Skeleton } from "../components/ui/Skeleton";
import { EmptyState } from "../components/ui/EmptyState";
import { LevelSkinBadge } from "../components/ui/LevelSkinBadge";
import { apiRequest } from "../lib/api";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import {
  USER_LEVEL_SKINS,
  getUserLevel,
} from "../lib/skins";
import type { SyncSnapshot } from "../hooks/useSnapshot";

type RankItem = {
  tg_id: number;
  username?: string | null;
  total_generated_kwh: string;
  rank_pos: number;
  is_vip: boolean;
};

type MyPlusTop = {
  snapshot_at: string;
  me: RankItem;
  top: RankItem[];
  next_cursor: string | null;
};

type TopPage = {
  snapshot_at: string;
  items: RankItem[];
  next_cursor: string | null;
};

function RankRow(props: { it: RankItem }) {
  const it = props.it;
  const rowCls =
    "flex items-center justify-between rounded-2xl p-3 " +
    "border border-[color:var(--tg-hint)] " +
    "bg-[color:var(--tg-secondary-bg)]/40";

  return (
    <div className={rowCls}>
      <div className="flex items-center gap-3">
        <div className="w-10 text-center font-bold efhc-text-gold">
          #{it.rank_pos}
        </div>
        <div>
          <div className="font-semibold">
            {it.username ? `@${it.username}` : `TG ${it.tg_id}`}
          </div>
          <div className="text-xs efhc-text-muted2">
            {it.total_generated_kwh} kWh
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {it.is_vip ? <Badge variant="vip">VIP</Badge> : null}
      </div>
    </div>
  );
}

export default function RanksPage(
  props: {
    tg_id: number | null;
    snap: SyncSnapshot | null;
  },
) {
  const t = useT();
  const td = useTD();
  const tg_id = props.tg_id;
  const [data, setData] = useState<MyPlusTop | null>(null);
  const [more, setMore] = useState<RankItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const totalMine = props.snap?.profile?.total_generated_kwh || "0";
  const myLevel = useMemo(() => getUserLevel(totalMine), [totalMine]);

  const me = data?.me || null;
  const top = data?.top || [];

  const load = async () => {
    if (!tg_id) return;
    setErr(null);
    const p = new URLSearchParams();
    p.set("tg_id", String(tg_id));
    p.set("limit", "50");
    p.set("max_age_minutes", "10");
    try {
      const res = await apiRequest<MyPlusTop>(
        `/ranks/my-plus-top?${p.toString()}`,
        "GET",
      );
      setData(res);
      setCursor(res.next_cursor);
      setMore([]);
    } catch (e: any) {
      setData(null);
      setCursor(null);
      setMore([]);
      setErr(String(e?.message || e));
    }
  };

  const loadMore = async () => {
    if (!tg_id || !cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const p = new URLSearchParams();
      p.set("limit", "100");
      p.set("cursor", cursor);
      const res = await apiRequest<TopPage>(
        `/ranks/top?${p.toString()}`,
        "GET",
      );
      setMore((prev) => [...prev, ...(res.items || [])]);
      setCursor(res.next_cursor);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    load();
  }, [tg_id]);

  if (!tg_id) {
    return (
      <Card title={t("ranks.title")}>
        <div className="text-sm efhc-text-muted">Loading…</div>
      </Card>
    );
  }

  const snapshotAt = data?.snapshot_at ?? "—";

  return (
    <div className="grid gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("ranks.title")}</h1>
          <div className="mt-1">
            <LevelSkinBadge total_generated_kwh={totalMine} compact />
          </div>
          <div className="text-xs efhc-text-muted2">
            {t("ranks.snapshot_at")}: {snapshotAt}
          </div>
        </div>
        <Button variant="secondary" onClick={load}>
          {t("common.refresh")}
        </Button>
      </div>

      <Card title={t("ranks.me")}
      >
        {me ? (
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">
                {me.username ? `@${me.username}` : `TG ${me.tg_id}`}
              </div>
              <div className="text-xs efhc-text-muted2">
                {t("ranks.rank_pos")}: #{me.rank_pos}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {me.is_vip ? <Badge variant="vip">VIP</Badge> : null}
              <Badge>{me.total_generated_kwh} kWh</Badge>
            </div>
          </div>
        ) : (
          <div className="grid gap-2">
            <Skeleton className="h-14" />
          </div>
        )}
      </Card>

      <Card title={t("ranks.top")}>
        {!data ? (
          <div className="grid gap-2">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>
        ) : null}

        {top.map((it) => (
          <RankRow key={`t-${it.rank_pos}`} it={it} />
        ))}
        {more.map((it) => (
          <RankRow key={`m-${it.rank_pos}`} it={it} />
        ))}

        {data && top.length === 0 && more.length === 0 ? (
          <EmptyState
            title={t("common.empty")}
            detail={err || td("desc.ranks.levels_hint")}
            actionLabel={t("common.refresh")}
            onAction={load}
          />
        ) : null}

        <div className="mt-2">
          {cursor ? (
            <Button disabled={loadingMore} onClick={loadMore}>
              {loadingMore
                ? t("common.loading")
                : t("common.load_more")}
            </Button>
          ) : (
            <span className="text-xs efhc-text-muted2">
              {t("common.end")}
            </span>
          )}
        </div>
      </Card>

      <Card title={t("ranks.levels")}>
        <div className="text-sm text-[color:var(--tg-hint)]">
          {td("desc.ranks.levels_hint")}
        </div>
        <div className="mt-3 grid gap-2">
          {USER_LEVEL_SKINS.map((s) => {
            const active = s.level === myLevel;
            const bg =
              "linear-gradient(180deg, var(--tg-button), "
              + "color-mix(in oklab, var(--tg-button) 70%, "
              + "var(--tg-link) 30%))";
            return (
              <div
                key={`lvl-${s.level}`}
                className={
                  "flex items-center justify-between rounded-2xl p-3 " +
                  "border border-[color:var(--tg-hint)] "
                  + "bg-[color:var(--tg-secondary-bg)]/40"
                }
              >
                <div className="flex items-center gap-3">
                  <span
                    className={
                      "w-10 h-10 rounded-2xl border " +
                      "border-[color:var(--tg-hint)]"
                    }
                    style={{ background: bg }}
                    aria-label={`L${s.level}`}
                  />
                  <div>
                    <div className="font-semibold">
                      L{s.level} — {s.name}
                    </div>
                    <div className="text-xs efhc-text-muted2">
                      Min: {s.min_kwh} kWh
                    </div>
                  </div>
                </div>
                {active ? <Badge>Active</Badge> : null}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
