import React, { useContext, useEffect, useMemo, useState } from "react";

import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";
import { EmptyState } from "../components/ui/EmptyState";
import {
  GameHero,
  GameNotice,
  GamePageShell,
  GameStat,
  GameStatsGrid,
} from "../components/ui/GameShell";
import { LayoutContext } from "../components/Layout";
import { Modal } from "../components/ui/Modal";
import { Skeleton } from "../components/ui/Skeleton";
import { formatD8ToHuman } from "../lib/format";
import {
  taskStatusLabel,
  taskStatusVisualState,
} from "../lib/humanLabels";
import { newIdempotencyKey } from "../lib/idempotency";
import { publicApiErrorMessage } from "../lib/publicError";
import {
  hapticError,
  hapticMedium,
  hapticSelection,
  hapticSoft,
  hapticSuccess,
} from "../lib/telegram";
import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import { useT } from "../hooks/useT";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import {
  useBuiltinAdSlot,
  useClaimTask,
  useFinishBuiltinTimerAd,
  useMyTasks,
  useTasksCatalog,
} from "../queries/useTasks";
import type {
  MyTaskItem,
  TaskCatalogItem,
} from "../services/tasks.service";

const READY_AD_STATUSES = new Set([
  "available",
  "not_started",
  "ready",
]);

function isAdTask(item: TaskCatalogItem): boolean {
  return item.kind === "ads" || item.kind === "watch_ad";
}

function isTaskCompleted(status: string | null | undefined): boolean {
  return ["auto_paid", "claimed", "completed", "done"].includes(
    String(status || ""),
  );
}

function canUseTask(
  item: TaskCatalogItem,
  state: MyTaskItem | undefined,
  hasTelegramUser: boolean,
): boolean {
  if (!hasTelegramUser) return true;
  if (isAdTask(item)) {
    return READY_AD_STATUSES.has(String(state?.status || "not_started"));
  }
  return Boolean(state?.can_claim);
}

export default function TasksPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const globalId = useAuthOwnerGlobalId();
  const ctx = useContext(LayoutContext);
  const { lang } = ctx;
  const tg_id = props.tg_id;

  const [busyCode, setBusyCode] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [adOpen, setAdOpen] = useState(false);
  const [adTaskCode, setAdTaskCode] = useState<string | null>(null);
  const [adToken, setAdToken] = useState<string | null>(null);
  const [adMinSec, setAdMinSec] = useState(20);
  const [adSecLeft, setAdSecLeft] = useState(0);

  const catalogQuery = useTasksCatalog();
  const myTasksQuery = useMyTasks(tg_id);
  const claimMutation = useClaimTask(tg_id);
  const adSlotMutation = useBuiltinAdSlot();
  const adFinishMutation = useFinishBuiltinTimerAd(tg_id);

  const fallbackCatalog = useMemo<TaskCatalogItem[]>(
    () => [
      {
        id: -1,
        code: "browser_watch_ad",
        title: t("tasks.demo_watch_ad_title"),
        description: t("tasks.demo_watch_ad_detail"),
        bonus_efhc: "0.01000000",
        is_active: true,
        kind: "watch_ad",
      },
      {
        id: -2,
        code: "browser_daily_energy",
        title: t("tasks.demo_daily_title"),
        description: t("tasks.demo_daily_detail"),
        bonus_efhc: "0.05000000",
        is_active: true,
        kind: "daily",
      },
    ],
    [t],
  );

  const statesByTaskId = useMemo(
    () =>
      new Map(
        (myTasksQuery.data || []).map((item) => [item.task_id, item]),
      ),
    [myTasksQuery.data],
  );

  const rawCatalog = catalogQuery.data || [];
  const catalog =
    rawCatalog.length > 0 ? rawCatalog : !globalId ? fallbackCatalog : [];
  const loading =
    Boolean(globalId) &&
    rawCatalog.length === 0 &&
    (catalogQuery.isFetching || myTasksQuery.isFetching);
  const hasError = Boolean(
    tg_id && (catalogQuery.error || myTasksQuery.error),
  );

  const readyTasks = catalog.filter((item) =>
    canUseTask(item, statesByTaskId.get(item.id), Boolean(globalId)),
  ).length;
  const completedTasks = catalog.filter((item) =>
    isTaskCompleted(statesByTaskId.get(item.id)?.status),
  ).length;

  const descriptionOf = useMemo(
    () => (description: unknown): string => {
      if (!description) return "";
      if (typeof description === "string") return description;
      if (typeof description === "object") {
        const localized = description as Record<string, unknown>;
        return String(localized[lang] || localized.en || localized.ru || "");
      }
      return String(description);
    },
    [lang],
  );

  const kindLabel = (kind: string | null | undefined): string =>
    kind === "ads" || kind === "watch_ad"
      ? t("tasks.kind_watch_ad")
      : t("tasks.kind_default");

  const normalizedStatus = (
    state: MyTaskItem | undefined,
    item: TaskCatalogItem,
  ): string => {
    if (!globalId) return "available";
    if (state?.status) return state.status;
    return isAdTask(item) ? "available" : "not_started";
  };

  const statusClass = (status: string): string => {
    const visualState = taskStatusVisualState(status);
    if (visualState === "done") return "efhc-task-status--done";
    if (visualState === "wait") return "efhc-task-status--wait";
    return "efhc-task-status--ready";
  };

  const buttonLabel = (
    item: TaskCatalogItem,
    state: MyTaskItem | undefined,
    canUse: boolean,
  ): string => {
    if (busyCode === item.code) return t("common.loading");
    const status = normalizedStatus(state, item);
    const visualState = taskStatusVisualState(status);
    if (!canUse) {
      if (visualState === "wait") return t("tasks.button_wait");
      if (visualState === "done") return t("tasks.button_done");
      return t("tasks.button_unavailable");
    }
    return isAdTask(item) ? t("tasks.watch_ad") : t("tasks.claim");
  };

  const helpText = (
    item: TaskCatalogItem,
    state: MyTaskItem | undefined,
    canUse: boolean,
  ): string => {
    if (canUse) {
      return isAdTask(item)
        ? t("tasks.help_watch_ad")
        : t("tasks.help_claim");
    }
    const visualState = taskStatusVisualState(
      normalizedStatus(state, item),
    );
    if (visualState === "wait") return t("tasks.help_cooldown");
    if (visualState === "done") return t("tasks.help_completed");
    return t("tasks.help_unavailable");
  };

  const claim = async (item: TaskCatalogItem): Promise<void> => {
    if (!globalId) {
      const text = t("tasks.claim_ok");
      setMessage(text);
      ctx.toast(text, "success");
      return;
    }
    hapticMedium(ctx.settings.haptics_enabled);
    setBusyCode(item.code);
    setMessage(null);
    try {
      await claimMutation.mutateAsync({
        taskId: item.id,
        idempotencyKey: newIdempotencyKey(),
      });
      const text = t("tasks.claim_ok");
      hapticSuccess(ctx.settings.haptics_enabled);
      setMessage(text);
      ctx.toast(text, "success");
    } catch (error: unknown) {
      const text = publicApiErrorMessage(error, t);
      hapticError(ctx.settings.haptics_enabled);
      setMessage(text);
    } finally {
      setBusyCode(null);
    }
  };

  const watchAd = async (item: TaskCatalogItem): Promise<void> => {
    if (!globalId) {
      setAdTaskCode(item.code);
      setAdToken("browser-demo");
      setAdMinSec(1);
      setAdSecLeft(1);
      setAdOpen(true);
      return;
    }
    hapticMedium(ctx.settings.haptics_enabled);
    setBusyCode(item.code);
    setMessage(null);
    try {
      const slot = await adSlotMutation.mutateAsync(item.code);
      const seconds = Math.max(1, Number(slot.min_view_sec || 20));
      setAdTaskCode(item.code);
      setAdToken(slot.token);
      setAdMinSec(seconds);
      setAdSecLeft(seconds);
      setAdOpen(true);
      hapticSoft(ctx.settings.haptics_enabled);
    } catch (error: unknown) {
      const text = publicApiErrorMessage(error, t);
      hapticError(ctx.settings.haptics_enabled);
      setMessage(text);
    } finally {
      setBusyCode(null);
    }
  };

  useEffect(() => {
    if (!adOpen || adSecLeft <= 0) return;
    const timer = window.setInterval(
      () => setAdSecLeft((value) => Math.max(0, value - 1)),
      1000,
    );
    return () => window.clearInterval(timer);
  }, [adOpen, adSecLeft]);

  const finishAd = async (): Promise<void> => {
    if (!adToken || !adTaskCode) return;
    if (!globalId && adToken === "browser-demo") {
      const text = t("tasks.ad_bonus_ok").replace("{{bonus}}", "0.01");
      hapticSuccess(ctx.settings.haptics_enabled);
      setMessage(text);
      ctx.toast(text, "success");
      setAdOpen(false);
      setAdToken(null);
      setAdTaskCode(null);
      return;
    }
    setBusyCode(adTaskCode);
    try {
      const result = await adFinishMutation.mutateAsync(adToken);
      const bonus = formatD8ToHuman(result.bonus_efhc || "0.01");
      const text = t("tasks.ad_bonus_ok").replace("{{bonus}}", bonus);
      hapticSuccess(ctx.settings.haptics_enabled);
      setMessage(text);
      ctx.toast(text, "success");
      setAdOpen(false);
      setAdToken(null);
      setAdTaskCode(null);
    } catch (error: unknown) {
      const text = publicApiErrorMessage(error, t);
      hapticError(ctx.settings.haptics_enabled);
      setMessage(text);
    } finally {
      setBusyCode(null);
    }
  };

  const refresh = (): void => {
    hapticSelection(ctx.settings.haptics_enabled);
    void catalogQuery.refetch();
    void myTasksQuery.refetch();
  };

  return (
    <GamePageShell
      className="efhc-tasks-shell"
      data-public-visual-beauty="tasks-referrals-ranks"
      data-public-surface="tasks"
      data-tasks-runtime="cycle-1557-react-query"
      data-tasks-earning-boundary="1291"
      data-tasks-ads-action-boundary="1292"
      data-tasks-execution-log-boundary="hidden-1293"
      data-tasks-public-history="forbidden"
      data-tasks-proof-pass="1294"
    >
      <GameHero
        kicker={t("tasks.game_kicker")}
        title={t("tasks.title")}
        detail={t("tasks.hero_detail")}
        icon="✓"
      >
        <GameStatsGrid compact>
          <GameStat
            label={t("tasks.dashboard_total")}
            value={String(catalog.length)}
          />
          <GameStat
            label={t("tasks.dashboard_ready")}
            value={String(readyTasks)}
          />
          <GameStat
            label={t("tasks.dashboard_completed")}
            value={String(completedTasks)}
          />
        </GameStatsGrid>
      </GameHero>

      {message ? (
        <GameNotice title={t("common.status")} detail={message} />
      ) : null}

      {hasError && !loading ? (
        <EmptyState
          title={t("tasks.error_title")}
          detail={t("tasks.empty_detail")}
          actionLabel={t("common.refresh")}
          onAction={refresh}
        />
      ) : null}

      <div
        className="efhc-tasks-grid efhc-compact-list-limit"
        data-tasks-list-card-layout="compact"
      >
        {loading ? (
          <div className="grid gap-2">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        ) : catalog.length === 0 ? (
          <EmptyState
            title={t("tasks.empty_title")}
            detail={t("tasks.empty_detail")}
            actionLabel={t("common.refresh")}
            onAction={refresh}
          />
        ) : (
          catalog.map((item) => {
            const state = statesByTaskId.get(item.id);
            const status = normalizedStatus(state, item);
            const canUse = canUseTask(item, state, Boolean(globalId));
            const adTask = isAdTask(item);
            return (
              <article
                key={item.code}
                className={
                  "efhc-task-card " +
                  (canUse ? "is-ready " : "is-locked ") +
                  (adTask ? "is-ad" : "is-claim")
                }
                data-task-card="earning"
                data-task-code={item.code}
                data-task-status={status}
                data-public-surface="tasks"
              >
                <div className="efhc-task-card_top">
                  <div className="efhc-task-card_text">
                    <h2 className="efhc-task-card_title">{item.title}</h2>
                    <p className="efhc-task-card_desc">
                      {descriptionOf(item.description)}
                    </p>
                  </div>
                  <div
                    className="efhc-task-card_reward"
                    data-task-reward="bonus-efhc"
                  >
                    <Badge>
                      <span className="efhc-task-reward-value">
                        <EfhcCoinIcon size={18} />
                        <span>
                          {formatD8ToHuman(item.bonus_efhc)} EFHC
                        </span>
                      </span>
                    </Badge>
                    <Badge>{kindLabel(item.kind)}</Badge>
                  </div>
                </div>

                <div className="efhc-task-card_state">
                  <span className={`efhc-task-status ${statusClass(status)}`}>
                    {taskStatusLabel(status, t)}
                  </span>
                  {state?.next_available_at ? (
                    <span className="efhc-task-next-time">
                      {t("tasks.next")}: {state.next_available_at}
                    </span>
                  ) : null}
                </div>

                <div
                  className="efhc-task-card_bottom"
                  data-task-action-row="primary"
                >
                  <div className="efhc-task-card_help">
                    {helpText(item, state, canUse)}
                  </div>
                  <Button
                    disabled={!canUse || busyCode === item.code}
                    aria-label={buttonLabel(item, state, canUse)}
                    data-task-action={
                      adTask ? "watch-ad" : "claim-bonus"
                    }
                    data-task-action-opens={
                      adTask ? "ads-direct" : "claim-direct"
                    }
                    onClick={() =>
                      void (adTask ? watchAd(item) : claim(item))
                    }
                  >
                    {buttonLabel(item, state, canUse)}
                  </Button>
                </div>
              </article>
            );
          })
        )}
      </div>

      <Modal
        open={adOpen}
        onClose={() => {
          if (adSecLeft > 0) return;
          setAdOpen(false);
        }}
        title={t("tasks.ad_modal_title")}
      >
        <div
          className="efhc-ad-modal-hint"
          data-tasks-ad-modal="direct-open"
        >
          {t("tasks.ad_modal_hint")} <b>{adMinSec}</b>
          {t("tasks.seconds_suffix")}.
        </div>
        <div className="efhc-ad-countdown" data-ad-countdown="seconds">
          {adSecLeft}
          {t("tasks.seconds_suffix")}
        </div>
        <div className="mt-4">
          <Button
            disabled={adSecLeft > 0 || !adToken || adFinishMutation.isPending}
            onClick={() => void finishAd()}
            className="w-full"
          >
            {adFinishMutation.isPending
              ? t("common.loading")
              : t("tasks.ad_modal_confirm")}
          </Button>
        </div>
        <div className="efhc-ad-modal-bonus-hint">
          {t("tasks.ad_modal_bonus_hint")}
        </div>
      </Modal>
    </GamePageShell>
  );
}
