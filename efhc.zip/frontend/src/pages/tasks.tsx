import React, { useContext, useEffect, useMemo, useState } from "react";
import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { EfhcCoinIcon } from "../components/icons/EfhcCoin";
import { Modal } from "../components/ui/Modal";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { format8 } from "../lib/format";
import { Skeleton } from "../components/ui/Skeleton";
import { EmptyState } from "../components/ui/EmptyState";

type TaskCatalogItem = {
  code: string;
  title: string;
  description: any;
  reward_efhc: string;
  kind: string;
};

type MyTaskItem = {
  code: string;
  status: string;
  next_available_at?: string | null;
};

export default function TasksPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const td = useTD();
  const { lang, confirm } = useContext(LayoutContext);
  const tg_id = props.tg_id;

  const qc = useQueryClient();

  const [busyCode, setBusyCode] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [adOpen, setAdOpen] = useState(false);
  const [adTaskCode, setAdTaskCode] = useState<string | null>(null);
  const [adToken, setAdToken] = useState<string | null>(null);
  const [adMinSec, setAdMinSec] = useState<number>(20);
  const [adSecLeft, setAdSecLeft] = useState<number>(0);

  const catalogQ = useQuery({
    queryKey: ["tasksCatalog"],
    staleTime: 60_000,
    queryFn: async () => {
      const c = await apiRequest<{ items: TaskCatalogItem[] }>(
        `/tasks/catalog`,
        "GET",
      );
      return c.items || [];
    },
  });

  const mineQ = useQuery({
    queryKey: ["tasksMy", tg_id],
    enabled: Boolean(tg_id),
    staleTime: 10_000,
    queryFn: async () => {
      if (!tg_id) throw new Error("tg_id required");
      const m = await apiRequest<{ items: MyTaskItem[] }>(
        `/tasks/my/${tg_id}`,
        "GET",
      );
      return m.items || [];
    },
  });

  const statusOf = (code: string) =>
    (mineQ.data || []).find((x) => x.code === code);

  const claimM = useMutation({
    mutationFn: async (code: string) => {
      if (!tg_id) throw new Error("tg_id required");
      const idk = newIdempotencyKey();
      return await apiRequest<any>(`/tasks/claim/${tg_id}`, "POST", {
        idempotencyKey: idk,
        body: { code },
      });
    },
    onSuccess: async (res) => {
      setMsg(res?.detail || t("tasks.claim_ok"));
      await qc.invalidateQueries({ queryKey: ["tasksMy", tg_id] });
      await qc.invalidateQueries({ queryKey: ["syncSnapshot", tg_id] });
    },
    onError: (e: any) => setMsg(String(e?.message || e)),
  });

  const desc = useMemo(() => {
    return (d: any): string => {
      if (!d) return "";
      if (typeof d === "string") return d;
      if (typeof d === "object") {
        return String(d[lang] || d.en || d.ru || "");
      }
      return String(d);
    };
  }, [lang]);

  const watchAd = async (code: string) => {
    if (!tg_id) return;
    const bonusHint =
      "After confirmation and successful view you will get " +
      "+0.01 EFHC (bonus).";
    const ok = await confirm(
      "watch_ad",
      "Start ad view?",
      bonusHint,
    );
    if (!ok) return;
    setBusyCode(code);
    setMsg(null);
    try {
      const slot = await apiRequest<any>(
        `/ads/slot?task_code=${encodeURIComponent(code)}` +
          `&provider=builtin_timer&tg_id=${tg_id}`,
        "GET",
      );
      setAdTaskCode(code);
      setAdToken(slot.token);
      setAdMinSec(Number(slot.min_view_sec || 20));
      setAdSecLeft(Number(slot.min_view_sec || 20));
      setAdOpen(true);
    } catch (e: any) {
      setMsg(String(e?.message || e));
    } finally {
      setBusyCode(null);
    }
  };

  useEffect(() => {
    if (!adOpen) return;
    if (adSecLeft <= 0) return;
    const id = window.setInterval(
      () => setAdSecLeft((x) => Math.max(0, x - 1)),
      1000,
    );
    return () => window.clearInterval(id);
  }, [adOpen, adSecLeft]);

  const finishAd = async () => {
    if (!adToken || !adTaskCode) return;
    setBusyCode(adTaskCode);
    try {
      const res = await apiRequest<any>(
        `/ads/callback/builtin_timer`,
        "POST",
        {
          body: { token: adToken },
        },
      );
      const reward = format8(res?.reward_bonus_efhc || "0.01");
      setMsg(`OK: +${reward} EFHC (bonus)`);
      setAdOpen(false);
      setAdToken(null);
      setAdTaskCode(null);
      await qc.invalidateQueries({ queryKey: ["tasksMy", tg_id] });
      await qc.invalidateQueries({ queryKey: ["syncSnapshot", tg_id] });
    } catch (e: any) {
      setMsg(String(e?.message || e));
    } finally {
      setBusyCode(null);
    }
  };

  if (!tg_id) {
    return (
      <Card title={t("tasks.title")}>
        <div className="text-sm text-[color:var(--tg-hint)]">
          {td("desc.common.need_telegram_webapp")}
        </div>
      </Card>
    );
  }

  const catalog = catalogQ.data || [];
  const loading =
    (catalogQ.isFetching || mineQ.isFetching) &&
    catalog.length === 0;
  const err =
    (catalogQ.error ? String(catalogQ.error) : null) ||
    (mineQ.error ? String(mineQ.error) : null);

  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{t("tasks.title")}</h1>

      <Card title={t("tasks.how_it_works")}>
        <div className="text-sm text-[color:var(--tg-hint)]">
          {td("desc.tasks.no_separate_ads_page")}
        </div>
        <div
          className={
            "text-xs text-[color:var(--tg-hint)] mt-2 opacity-80"
          }
        >
          {td("desc.tasks.idempotency_note")}
        </div>
      </Card>

      {msg ? (
        <Card title={t("common.status")}>
          <div className="text-sm whitespace-pre-wrap">{msg}</div>
        </Card>
      ) : null}

      <div className="grid gap-3">
        {loading ? (
          <div className="grid gap-2">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
        ) : catalog.length === 0 ? (
          <EmptyState
            title="No tasks available"
            detail={err || "Try again."}
            actionLabel="Refresh"
            onAction={() => {
              void catalogQ.refetch();
              void mineQ.refetch();
            }}
          />
        ) : (
          catalog.map((it) => {
            const st = statusOf(it.code);
            const can = st?.status === "available" || !st;
            const isAds = it.kind === "ads" || it.kind === "watch_ad";
            return (
              <div
                key={it.code}
                className={
                  "border rounded-2xl "
                  + "border-[color:var(--tg-hint)] "
                  + "bg-[var(--tg-secondary-bg)] p-3"
                }
              >
                <div className="flex items-start justify-between gap-3">
	                <div className="min-w-0">
	                  <div className="font-semibold">{it.title}</div>
	                  <div
	                    className="text-xs text-[color:var(--tg-hint)]"
	                  >
	                    {desc(it.description)}
	                  </div>
	                </div>
	                <div className="flex flex-col items-end gap-2">
	                  <Badge>
	                    <span className="inline-flex items-center gap-1">
	                      <EfhcCoinIcon size={20} />
	                      <span>{format8(it.reward_efhc)} EFHC</span>
	                    </span>
	                  </Badge>
	                  <Badge>{String(it.kind || "task")}</Badge>
	                </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div
                    className={
                      "text-xs text-[color:var(--tg-hint)] opacity-70"
                    }
                  >
                    {st?.status
                      ? `${t("tasks.status")}: ${st.status}`
                      : t("tasks.status_unknown")}
                    {st?.next_available_at
                      ? ` • ${t("tasks.next")}: ${st.next_available_at}`
                      : ""}
                  </div>
                  {isAds ? (
                    <Button
                      disabled={!can || busyCode === it.code}
                      onClick={() => watchAd(it.code)}
                    >
                      {busyCode === it.code
                        ? t("common.loading")
                        : "Watch ad"}
                    </Button>
                  ) : (
                    <Button
                      disabled={!can || busyCode === it.code}
                      onClick={() => {
                        setBusyCode(it.code);
                        setMsg(null);
                        claimM
                          .mutateAsync(it.code)
                          .finally(() => setBusyCode(null));
                      }}
                    >
                      {busyCode === it.code
                        ? t("common.loading")
                        : t("tasks.claim")}
                    </Button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      <Modal
        open={adOpen}
        onClose={() => {
          if (adSecLeft > 0) return;
          setAdOpen(false);
        }}
        title="Ad view"
      >
        <div className="text-sm text-[color:var(--tg-hint)]">
          Please keep this screen open. Minimum watch time:{" "}
          <b>{adMinSec}</b>s.
        </div>
        <div className="mt-3 text-2xl font-bold">{adSecLeft}s</div>
        <div className="mt-4">
          <Button
            disabled={adSecLeft > 0 || !adToken}
            onClick={() => void finishAd()}
            className="w-full"
          >
            Confirm view (+0.01 EFHC bonus)
          </Button>
        </div>
        <div
          className={
            "mt-2 text-xs text-[color:var(--tg-hint)] opacity-80"
          }
        >
          Reward goes to bonus balance.
        </div>
      </Modal>
    </div>
  );
}
