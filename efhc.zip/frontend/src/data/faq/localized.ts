import type { Lang } from "../../lib/i18n";

type FaqItemOverride = {
  question?: string;
  answer?: string;

  keywords?: string[];
};

type FaqOverridesByLang = Partial<

  Record<Lang, Record<string, FaqItemOverride>>
>;

const j = (...parts: string[]): string =>
  parts.join(" ");

export const faqItemOverridesByLang: FaqOverridesByLang = {
  en: {
    "5.1-1": {
      question: [
        "What is the Profile /",
        "Settings section?",
      ].join(" "),
      answer: [
        "Profile / Settings is the",
        "place where the user manages",
        "the profile and the bot",
        "parameters. It shows core",
        "statuses and personal",
        "interface settings.",
      ].join(" "),
      keywords: [
        "profile",
        "settings",
      ],
    },
    "5.1-2": {
      question: [
        "What is shown at the top of",
        "Profile / Settings?",
      ].join(" "),
      answer: [
        "The top part shows the",
        "avatar, Telegram name, and",
        "the Activ and VIP statuses",
        "if they are already",
        "available.",
      ].join(" "),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: [
        "What can be configured in",
        "Profile / Settings?",
      ].join(" "),
      answer: [
        "In short: the bot language,",
        "appearance, sound,",
        "vibration, notifications,",
        "action confirmations, and",
        "other interface preferences.",
      ].join(" "),
      keywords: [
        "language",
        "appearance",
        "notifications",
      ],
    },
    "5.1-4": {
      question: [
        "What is inside Support and",
        "Information?",
      ].join(" "),
      answer: [
        "This block contains help,",
        "answers to common questions,",
        "project rules, and other",
        "informational materials.",
      ].join(" "),
      keywords: [
        "support",
        "help",
        "rules",
      ],
    },
    "6.1-1": {
      question: [
        "What is the Wallet section",
        "in Profile / Settings?",
      ].join(" "),
      answer: [
        "In the Wallet section the",
        "user can link one or more",
        "wallets and choose the",
        "primary wallet.",
      ].join(" "),
      keywords: [
        "wallet",
        "primary wallet",
      ],
    },
    "6.1-2": {
      question: [
        "Why is the primary wallet",
        "needed?",
      ].join(" "),
      answer: [
        "The primary wallet is used",
        "where project rules require",
        "a linked wallet for",
        "functions and operations.",
      ].join(" "),
      keywords: [
        "primary",
        "linked wallet",
      ],
    },
    "6.1-3": {
      question: [
        "Can the primary wallet be",
        "changed?",
      ].join(" "),
      answer: [
        "Yes. Another primary wallet",
        "can be selected from the",
        "wallets that are already",
        "linked.",
      ].join(" "),
      keywords: [
        "change wallet",
        "primary",
      ],
    },
    "6.1-4": {
      question: [
        "Can a linked wallet be",
        "removed?",
      ].join(" "),
      answer: [
        "Yes. If a wallet is no",
        "longer needed, its link can",
        "be removed.",
      ].join(" "),
      keywords: [
        "remove wallet",
        "unlink",
      ],
    },
    "6.1-5": {
      question: [
        "What happens if the user",
        "taps a button that needs a",
        "wallet?",
      ].join(" "),
      answer: [
        "If the chosen function",
        "requires a wallet, tapping",
        "that button starts the",
        "wallet linking flow",
        "automatically.",
      ].join(" "),
      keywords: [
        "wallet required",
        "connect wallet",
      ],
    },
    "6.1-6": {
      question: [
        "Does VIP NFT activate",
        "automatically after it",
        "arrives in the wallet?",
      ].join(" "),
      answer: [
        "Yes. VIP logic is based on",
        "the NFT being present in a",
        "linked wallet: the bot",
        "checks the wallet",
        "automatically and updates",
        "the VIP status.",
      ].join(" "),
      keywords: [
        "vip nft",
        "automatic activation",
      ],
    },
    "6.1-7": {
      question: [
        "Does the user need to enable",
        "VIP manually after receiving",
        "NFT?",
      ].join(" "),
      answer: [
        "No. The project logic is",
        "designed for automatic",
        "wallet checks and automatic",
        "VIP status updates after the",
        "NFT is found in the required",
        "collection.",
      ].join(" "),
      keywords: [
        "manual vip",
        "automatic check",
      ],
    },
    "6.1-8": {
      question: [
        "Does one VIP NFT give the",
        "effect while the second and",
        "third do not?",
      ].join(" "),
      answer: [
        "Yes. For the player, having",
        "at least one EFHC VIP NFT is",
        "enough. The second and third",
        "NFT do not add extra",
        "generation boost.",
      ].join(" "),
      keywords: [
        "one nft",
        "vip effect",
      ],
    },
    "7.1-1": {
      question: [
        "What is the bonus balance?",
      ].join(" "),
      answer: [
        "The bonus balance is a",
        "temporary internal balance",
        "of the project. It is",
        "credited from tasks,",
        "referral bonuses, gifts,",
        "lotteries, and other",
        "internal game mechanics. It",
        "cannot be withdrawn",
        "directly.",
      ].join(" "),
      keywords: [
        "bonus balance",
        "internal",
      ],
    },
    "7.1-2": {
      question: [
        "What is the main balance?",
      ].join(" "),
      answer: [
        "The main balance contains",
        "the core EFHC. It is the",
        "result of the game cycle,",
        "and withdrawals are",
        "available from it.",
      ].join(" "),
      keywords: [
        "main balance",
        "withdraw",
      ],
    },
    "7.1-3": {
      question: [
        "What is the difference",
        "between the bonus and main",
        "balances?",
      ].join(" "),
      answer: [
        "The bonus balance is for the",
        "internal life of the game.",
        "The main balance is the",
        "result of the game path that",
        "has already passed through",
        "energy generation and",
        "conversion.",
      ].join(" "),
      keywords: [
        "difference",
        "bonus",
        "main",
      ],
    },
    "7.2-1": {
      question: [
        "Can the bonus balance be",
        "withdrawn directly?",
      ].join(" "),
      answer: [
        "No. The bonus balance cannot",
        "be withdrawn directly. It",
        "must pass through the full",
        "internal game cycle.",
      ].join(" "),
      keywords: [
        "withdraw bonus",
        "direct withdrawal",
      ],
    },
    "7.2-2": {
      question: [
        "What full path does the",
        "bonus balance go through?",
      ].join(" "),
      answer: [
        "The full path is this: bonus",
        "coins are used to buy a",
        "panel, the panel starts",
        "generating energy, the",
        "accumulated energy is",
        "converted into kWh, and then",
        "the energy is converted into",
        "main EFHC. Only after that",
        "does the result appear in",
        "the main balance.",
      ].join(" "),
      keywords: [
        "cycle",
        "panel",
        "kwh",
      ],
    },
    "7.2-3": {
      question: [
        "How does the bonus balance",
        "turn into main EFHC?",
      ].join(" "),
      answer: [
        "The bonus balance is the",
        "starting resource for the",
        "game process. Through panel",
        "purchase, energy generation,",
        "and conversion it turns into",
        "main EFHC.",
      ].join(" "),
      keywords: [
        "convert",
        "main efhc",
      ],
    },
    "7.2-4": {
      question: [
        "In what order are funds",
        "spent in internal expenses?",
      ].join(" "),
      answer: [
        "In all internal project",
        "expenses, funds are spent",
        "from the bonus balance first",
        "and then from the main",
        "balance.",
      ].join(" "),
      keywords: [
        "spending order",
        "bonus first",
        "main second",
      ],
    },
    "7.2-5": {
      question: [
        "What is the simple",
        "difference between total,",
        "bonus, and main balances?",
      ].join(" "),
      answer: [
        "The total balance is",
        "everything together for",
        "understanding overall",
        "purchasing power. The bonus",
        "balance is internal game",
        "energy that starts the game",
        "cycle. The main balance is",
        "the final result that can be",
        "used as the main value and",
        "withdrawn under project",
        "rules.",
      ].join(" "),
      keywords: [
        "total balance",
        "simple explanation",
      ],
    },
    "14.1-1": {
      question: [
        "How does energy exchange",
        "into EFHC work?",
      ].join(" "),
      answer: [
        "Exchange is the conversion",
        "of progress into main EFHC.",
        "The accumulated energy is",
        "turned into the project's",
        "main coins.",
      ].join(" "),
      keywords: [
        "exchange",
        "energy",
      ],
    },
    "14.1-2": {
      question: [
        "What does the rule 1 kWh = 1",
        "EFHC mean?",
      ].join(" "),
      answer: [
        "It is the fixed internal",
        "rate of the project. Each",
        "unit of energy is converted",
        "into an equal amount of",
        "EFHC.",
      ].join(" "),
      keywords: [
        "1 kwh 1 efhc",
        "rate",
      ],
    },
    "14.1-3": {
      question: [
        "Why does the Exchange page",
        "show main coins instead of",
        "the total balance?",
      ].join(" "),
      answer: [
        "Because exchange is tied to",
        "the main value and to the",
        "balance that matters for",
        "this specific operation.",
      ].join(" "),
      keywords: [
        "exchange page",
        "main balance",
      ],
    },
    "14.2-1": {
      question: [
        "How does withdrawal work?",
      ].join(" "),
      answer: [
        "A withdrawal request is",
        "submitted and then processed",
        "as quickly as possible by",
        "the first available",
        "operator.",
      ].join(" "),
      keywords: [
        "withdrawal",
        "request",
      ],
    },
    "14.2-2": {
      question: [
        "Which balance can be used",
        "for withdrawal?",
      ].join(" "),
      answer: [
        "Withdrawal is available only",
        "from the main balance.",
      ].join(" "),
      keywords: [
        "withdraw main",
        "main only",
      ],
    },
    "14.2-3": {
      question: [
        "Why is withdrawal available",
        "only from the main balance?",
      ].join(" "),
      answer: [
        "Because the main balance is",
        "what already belongs to the",
        "player as the result of the",
        "game process or purchased",
        "coins. Bonus coins",
        "participate in the internal",
        "game process and are not a",
        "directly withdrawable",
        "result.",
      ].join(" "),
      keywords: [
        "why main only",
        "bonus not withdrawable",
      ],
    },
    "14.2-4": {
      question: [
        "What is the minimum",
        "withdrawal?",
      ].join(" "),
      answer: [
        "The minimum withdrawal",
        "amount is 10 EFHC.",
      ].join(" "),
      keywords: [
        "minimum withdrawal",
        "10 efhc",
      ],
    },
  },

  de: {
    "5.1-1": {
      question: [
        "Was ist der",
        "Bereich Profil /",
        "Einstellungen?",
      ].join(" "),
      answer: [
        "Profil /",
        "Einstellungen ist",
        "der Bereich, in",
        "dem der Nutzer",
        "sein Profil und",
        "die Bot",
        "Einstellungen",
        "verwaltet. Dort",
        "werden wichtige",
        "Statuswerte und",
        "persönliche",
        "Oberflächenoptionen",
        "angezeigt.",
      ].join(" "),
      keywords: [
        "profil",
        "einstellungen",
      ],
    },
    "5.1-2": {
      question: [
        "Was wird oben in",
        "Profil /",
        "Einstellungen",
        "angezeigt?",
      ].join(" "),
      answer: [
        "Oben werden der",
        "Avatar, der",
        "Telegram Name",
        "sowie die Status",
        "Activ und VIP",
        "angezeigt, wenn",
        "sie bereits",
        "verfügbar sind.",
      ].join(" "),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: [
        "Was kann in Profil",
        "/ Einstellungen",
        "angepasst werden?",
      ].join(" "),
      answer: [
        "Kurz gesagt:",
        "Sprache,",
        "Darstellung, Ton,",
        "Vibration,",
        "Benachrichtigungen,",
        "Aktionsbestätigungen",
        "und weitere",
        "Bedienoptionen.",
      ].join(" "),
      keywords: [
        "sprache",
        "benachrichtigungen",
        "darstellung",
      ],
    },
    "5.1-4": {
      question: [
        "Was befindet sich",
        "im Bereich Support",
        "und Informationen?",
      ].join(" "),
      answer: [
        "Dort liegen Hilfe,",
        "Antworten auf",
        "häufige Fragen,",
        "Projektregeln und",
        "andere",
        "Informationsmaterialien.",
      ].join(" "),
      keywords: [
        "hilfe",
        "support",
        "regeln",
      ],
    },
    "6.1-1": {
      question: [
        "Was ist der Wallet",
        "Bereich in Profil",
        "/ Einstellungen?",
      ].join(" "),
      answer: [
        "Im Wallet Bereich",
        "kann der Nutzer",
        "eine oder mehrere",
        "Wallets verknüpfen",
        "und eine Haupt",
        "Wallet festlegen.",
      ].join(" "),
      keywords: [
        "wallet",
        "haupt wallet",
      ],
    },
    "6.1-2": {
      question: [
        "Wozu dient die",
        "Haupt Wallet?",
      ].join(" "),
      answer: [
        "Die Haupt Wallet",
        "wird dort",
        "verwendet, wo die",
        "Projektregeln für",
        "Funktionen und",
        "Vorgänge eine",
        "verknüpfte Wallet",
        "verlangen.",
      ].join(" "),
      keywords: [
        "haupt wallet",
        "verknüpfte wallet",
      ],
    },
    "6.1-3": {
      question: [
        "Kann die Haupt",
        "Wallet geändert",
        "werden?",
      ].join(" "),
      answer: [
        "Ja. Aus den",
        "bereits",
        "verknüpften",
        "Wallets kann eine",
        "andere Haupt",
        "Wallet ausgewählt",
        "werden.",
      ].join(" "),
      keywords: [
        "wallet ändern",
        "haupt wallet",
      ],
    },
    "6.1-4": {
      question: [
        "Kann eine",
        "verknüpfte Wallet",
        "entfernt werden?",
      ].join(" "),
      answer: [
        "Ja. Wenn eine",
        "Wallet nicht mehr",
        "benötigt wird,",
        "kann ihre",
        "Verknüpfung",
        "entfernt werden.",
      ].join(" "),
      keywords: [
        "wallet entfernen",
        "trennen",
      ],
    },
    "6.1-5": {
      question: [
        "Was passiert, wenn",
        "der Nutzer auf",
        "eine Funktion",
        "tippt, die eine",
        "Wallet braucht?",
      ].join(" "),
      answer: [
        "Wenn die gewählte",
        "Funktion eine",
        "Wallet erfordert,",
        "startet der Bot",
        "den",
        "Verknüpfungsablauf",
        "automatisch.",
      ].join(" "),
      keywords: [
        "wallet erforderlich",
        "wallet verbinden",
      ],
    },
    "6.1-6": {
      question: [
        "Wird VIP NFT",
        "automatisch",
        "aktiviert, nachdem",
        "es in die Wallet",
        "eingegangen ist?",
      ].join(" "),
      answer: [
        "Ja. Die VIP Logik",
        "basiert auf dem",
        "Vorhandensein des",
        "NFT in einer",
        "verknüpften",
        "Wallet. Der Bot",
        "prüft die Wallet",
        "automatisch und",
        "aktualisiert den",
        "VIP Status.",
      ].join(" "),
      keywords: [
        "vip nft",
        "automatisch",
      ],
    },
    "6.1-7": {
      question: [
        "Muss der Nutzer",
        "VIP nach dem",
        "Erhalt des NFT",
        "manuell",
        "aktivieren?",
      ].join(" "),
      answer: [
        "Nein. Die",
        "Projektlogik sieht",
        "automatische",
        "Wallet Prüfungen",
        "und automatische",
        "VIP Updates vor,",
        "sobald das NFT in",
        "der erforderlichen",
        "Kollektion",
        "gefunden wird.",
      ].join(" "),
      keywords: [
        "vip manuell",
        "automatische prüfung",
      ],
    },
    "6.1-8": {
      question: [
        "Wirkt ein VIP NFT,",
        "während das zweite",
        "und dritte keinen",
        "Zusatz geben?",
      ].join(" "),
      answer: [
        "Ja. Für den",
        "Spieler genügt",
        "mindestens ein",
        "EFHC VIP NFT. Das",
        "zweite und dritte",
        "NFT geben keinen",
        "zusätzlichen",
        "Generationsbonus.",
      ].join(" "),
      keywords: [
        "ein nft",
        "vip effekt",
      ],
    },
    "7.1-1": {
      question: [
        "Was ist der",
        "Bonussaldo?",
      ].join(" "),
      answer: [
        "Der Bonussaldo ist",
        "ein temporärer",
        "interner",
        "Projektsaldo. Er",
        "wird aus Aufgaben,",
        "Empfehlungsboni,",
        "Geschenken,",
        "Lotteries und",
        "anderen internen",
        "Mechaniken",
        "gutgeschrieben. Er",
        "kann nicht direkt",
        "ausgezahlt werden.",
      ].join(" "),
      keywords: [
        "bonussaldo",
        "intern",
      ],
    },
    "7.1-2": {
      question: [
        "Was ist der",
        "Hauptsaldo?",
      ].join(" "),
      answer: [
        "Der Hauptsaldo",
        "enthält die",
        "grundlegenden",
        "EFHC. Er ist das",
        "Ergebnis des",
        "Spielzyklus, und",
        "Auszahlungen sind",
        "von ihm aus",
        "möglich.",
      ].join(" "),
      keywords: [
        "hauptsaldo",
        "auszahlung",
      ],
    },
    "7.1-3": {
      question: [
        "Worin liegt der",
        "Unterschied",
        "zwischen Bonus und",
        "Hauptsaldo?",
      ].join(" "),
      answer: [
        "Der Bonussaldo",
        "dient dem internen",
        "Spielleben. Der",
        "Hauptsaldo ist das",
        "Ergebnis des",
        "Spielwegs, das",
        "bereits durch",
        "Energieerzeugung",
        "und Umwandlung",
        "gegangen ist.",
      ].join(" "),
      keywords: [
        "unterschied",
        "bonus",
        "haupt",
      ],
    },
    "7.2-1": {
      question: [
        "Kann der",
        "Bonussaldo direkt",
        "ausgezahlt werden?",
      ].join(" "),
      answer: [
        "Nein. Der",
        "Bonussaldo kann",
        "nicht direkt",
        "ausgezahlt werden.",
        "Er muss den",
        "vollständigen",
        "internen",
        "Spielzyklus",
        "durchlaufen.",
      ].join(" "),
      keywords: [
        "bonus auszahlen",
        "direkte auszahlung",
      ],
    },
    "7.2-2": {
      question: [
        "Welchen",
        "vollständigen Weg",
        "durchläuft der",
        "Bonussaldo?",
      ].join(" "),
      answer: [
        "Der Weg ist so:",
        "Bonus Coins werden",
        "für den Kauf eines",
        "Panels genutzt,",
        "das Panel erzeugt",
        "Energie, die",
        "Energie wird in",
        "kWh und danach in",
        "Haupt EFHC",
        "umgewandelt. Erst",
        "dann erscheint das",
        "Ergebnis im",
        "Hauptsaldo.",
      ].join(" "),
      keywords: [
        "zyklus",
        "panel",
        "kwh",
      ],
    },
    "7.2-3": {
      question: [
        "Wie wird der",
        "Bonussaldo zu",
        "Haupt EFHC?",
      ].join(" "),
      answer: [
        "Der Bonussaldo ist",
        "die Startressource",
        "des",
        "Spielprozesses.",
        "Über Panel Kauf,",
        "Energieerzeugung",
        "und Umwandlung",
        "wird er zu Haupt",
        "EFHC.",
      ].join(" "),
      keywords: [
        "umwandlung",
        "haupt efhc",
      ],
    },
    "7.2-4": {
      question: [
        "In welcher",
        "Reihenfolge werden",
        "Mittel bei",
        "internen Ausgaben",
        "verbraucht?",
      ].join(" "),
      answer: [
        "Bei allen internen",
        "Projektausgaben",
        "werden Mittel",
        "zuerst aus dem",
        "Bonussaldo und",
        "danach aus dem",
        "Hauptsaldo",
        "verwendet.",
      ].join(" "),
      keywords: [
        "verbrauchsreihenfolge",
        "bonus zuerst",
      ],
    },
    "7.2-5": {
      question: [
        "Was ist der",
        "einfache",
        "Unterschied",
        "zwischen Gesamt,",
        "Bonus und",
        "Hauptsaldo?",
      ].join(" "),
      answer: [
        "Der Gesamtsaldo",
        "ist alles zusammen",
        "und zeigt die",
        "gesamte Kaufkraft.",
        "Der Bonussaldo ist",
        "interne",
        "Spielenergie für",
        "den Start des",
        "Zyklus. Der",
        "Hauptsaldo ist das",
        "Endergebnis, das",
        "als Hauptwert",
        "genutzt und nach",
        "den Projektregeln",
        "ausgezahlt werden",
        "kann.",
      ].join(" "),
      keywords: [
        "gesamtsaldo",
        "einfache erklärung",
      ],
    },
    "14.1-1": {
      question: [
        "Wie funktioniert",
        "der Tausch von",
        "Energie in EFHC?",
      ].join(" "),
      answer: [
        "Exchange ist die",
        "Umwandlung von",
        "Fortschritt in",
        "Haupt EFHC. Die",
        "angesammelte",
        "Energie wird in",
        "die Haupt Coins",
        "des Projekts",
        "umgewandelt.",
      ].join(" "),
      keywords: [
        "exchange",
        "energie",
      ],
    },
    "14.1-2": {
      question: [
        "Was bedeutet die",
        "Regel 1 kWh = 1",
        "EFHC?",
      ].join(" "),
      answer: [
        "Das ist der feste",
        "interne Kurs des",
        "Projekts. Jede",
        "Energieeinheit",
        "wird in die",
        "gleiche Menge EFHC",
        "umgewandelt.",
      ].join(" "),
      keywords: [
        "1 kwh 1 efhc",
        "kurs",
      ],
    },
    "14.1-3": {
      question: [
        "Warum zeigt die",
        "Exchange Seite",
        "Haupt Coins und",
        "nicht den",
        "Gesamtsaldo?",
      ].join(" "),
      answer: [
        "Weil Exchange an",
        "den Hauptwert und",
        "an den Saldo",
        "gebunden ist, der",
        "für diese konkrete",
        "Operation zählt.",
      ].join(" "),
      keywords: [
        "exchange seite",
        "hauptsaldo",
      ],
    },
    "14.2-1": {
      question: [
        "Wie funktioniert",
        "die Auszahlung?",
      ].join(" "),
      answer: [
        "Es wird ein",
        "Auszahlungsantrag",
        "erstellt, danach",
        "bearbeitet ihn der",
        "erste verfügbare",
        "Operator so",
        "schnell wie",
        "möglich.",
      ].join(" "),
      keywords: [
        "auszahlung",
        "antrag",
      ],
    },
    "14.2-2": {
      question: [
        "Welcher Saldo kann",
        "für die Auszahlung",
        "verwendet werden?",
      ].join(" "),
      answer: [
        "Auszahlungen sind",
        "nur vom Hauptsaldo",
        "möglich.",
      ].join(" "),
      keywords: [
        "hauptsaldo",
        "auszahlung",
      ],
    },
    "14.2-3": {
      question: [
        "Warum ist die",
        "Auszahlung nur vom",
        "Hauptsaldo",
        "möglich?",
      ].join(" "),
      answer: [
        "Weil der",
        "Hauptsaldo das",
        "ist, was dem",
        "Spieler bereits",
        "als Ergebnis des",
        "Spielprozesses",
        "oder als gekaufte",
        "Coins gehört.",
        "Bonus Coins nehmen",
        "am internen",
        "Spielprozess teil",
        "und sind kein",
        "direkt",
        "auszahlbares",
        "Ergebnis.",
      ].join(" "),
      keywords: [
        "warum hauptsaldo",
        "bonus nicht auszahlbar",
      ],
    },
    "14.2-4": {
      question: [
        "Wie hoch ist die",
        "Mindestauszahlung?",
      ].join(" "),
      answer: [
        "Die",
        "Mindestauszahlung",
        "beträgt 10 EFHC.",
      ].join(" "),
      keywords: [
        "mindestauszahlung",
        "10 efhc",
      ],
    },
  },
  fr: {
    "5.1-1": {
      question: [
        "Qu'est ce que la",
        "section Profil /",
        "Paramètres ?",
      ].join(" "),
      answer: [
        "Profil /",
        "Paramètres est",
        "l'endroit où",
        "l'utilisateur gère",
        "son profil et les",
        "réglages du bot.",
        "On y voit les",
        "statuts clés et",
        "les préférences",
        "personnelles de",
        "l'interface.",
      ].join(" "),
      keywords: [
        "profil",
        "paramètres",
      ],
    },
    "5.1-2": {
      question: [
        "Que voit on en",
        "haut de Profil /",
        "Paramètres ?",
      ].join(" "),
      answer: [
        "La partie",
        "supérieure affiche",
        "l'avatar, le nom",
        "Telegram et les",
        "statuts Activ et",
        "VIP s'ils sont",
        "déjà disponibles.",
      ].join(" "),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: [
        "Que peut on",
        "configurer dans",
        "Profil /",
        "Paramètres ?",
      ].join(" "),
      answer: [
        "En bref : langue,",
        "apparence, son,",
        "vibration,",
        "notifications,",
        "confirmations",
        "d'action et autres",
        "préférences",
        "d'interface.",
      ].join(" "),
      keywords: [
        "langue",
        "notifications",
        "apparence",
      ],
    },
    "5.1-4": {
      question: [
        "Que contient le",
        "bloc Support et",
        "Informations ?",
      ].join(" "),
      answer: [
        "Ce bloc contient",
        "l'aide, les",
        "réponses aux",
        "questions",
        "fréquentes, les",
        "règles du projet",
        "et d'autres",
        "documents",
        "d'information.",
      ].join(" "),
      keywords: [
        "aide",
        "support",
        "règles",
      ],
    },
    "6.1-1": {
      question: [
        "Qu'est ce que la",
        "section Wallet",
        "dans Profil /",
        "Paramètres ?",
      ].join(" "),
      answer: [
        "Dans Wallet,",
        "l'utilisateur peut",
        "lier un ou",
        "plusieurs",
        "portefeuilles et",
        "choisir le",
        "portefeuille",
        "principal.",
      ].join(" "),
      keywords: [
        "wallet",
        "portefeuille principal",
      ],
    },
    "6.1-2": {
      question: [
        "À quoi sert le",
        "portefeuille",
        "principal ?",
      ].join(" "),
      answer: [
        "Le portefeuille",
        "principal est",
        "utilisé là où les",
        "règles du projet",
        "exigent un",
        "portefeuille lié",
        "pour des fonctions",
        "et des opérations.",
      ].join(" "),
      keywords: [
        "principal",
        "portefeuille lié",
      ],
    },
    "6.1-3": {
      question: [
        "Peut on changer le",
        "portefeuille",
        "principal ?",
      ].join(" "),
      answer: [
        "Oui. Un autre",
        "portefeuille",
        "principal peut",
        "être choisi parmi",
        "les portefeuilles",
        "déjà liés.",
      ].join(" "),
      keywords: [
        "changer wallet",
        "principal",
      ],
    },
    "6.1-4": {
      question: [
        "Peut on supprimer",
        "un portefeuille",
        "lié ?",
      ].join(" "),
      answer: [
        "Oui. Si un",
        "portefeuille n'est",
        "plus nécessaire,",
        "son lien peut être",
        "supprimé.",
      ].join(" "),
      keywords: [
        "supprimer wallet",
        "retirer",
      ],
    },
    "6.1-5": {
      question: [
        "Que se passe t il",
        "si l'utilisateur",
        "touche une",
        "fonction qui",
        "demande un wallet",
        "?",
      ].join(" "),
      answer: [
        "Si la fonction",
        "choisie exige un",
        "wallet, le bot",
        "lance",
        "automatiquement le",
        "flux de liaison du",
        "portefeuille.",
      ].join(" "),
      keywords: [
        "wallet requis",
        "lier wallet",
      ],
    },
    "6.1-6": {
      question: [
        "Le VIP NFT",
        "s'active t il",
        "automatiquement",
        "après son arrivée",
        "dans le wallet ?",
      ].join(" "),
      answer: [
        "Oui. La logique",
        "VIP dépend de la",
        "présence du NFT",
        "dans un wallet lié",
        ": le bot vérifie",
        "automatiquement le",
        "wallet et met à",
        "jour le statut",
        "VIP.",
      ].join(" "),
      keywords: [
        "vip nft",
        "activation automatique",
      ],
    },
    "6.1-7": {
      question: [
        "L'utilisateur doit",
        "il activer VIP",
        "manuellement après",
        "avoir reçu le NFT",
        "?",
      ].join(" "),
      answer: [
        "Non. La logique du",
        "projet prévoit des",
        "vérifications",
        "automatiques du",
        "wallet et une mise",
        "à jour automatique",
        "du statut VIP",
        "après détection du",
        "NFT dans la",
        "collection",
        "requise.",
      ].join(" "),
      keywords: [
        "vip manuel",
        "vérification automatique",
      ],
    },
    "6.1-8": {
      question: [
        "Un seul VIP NFT",
        "suffit il alors",
        "que le deuxième et",
        "le troisième",
        "n'ajoutent rien ?",
      ].join(" "),
      answer: [
        "Oui. Pour le",
        "joueur, au moins",
        "un EFHC VIP NFT",
        "suffit. Le",
        "deuxième et le",
        "troisième NFT",
        "n'ajoutent pas de",
        "bonus de",
        "génération.",
      ].join(" "),
      keywords: [
        "un nft",
        "effet vip",
      ],
    },
    "7.1-1": {
      question: [
        "Qu'est ce que le",
        "solde bonus ?",
      ].join(" "),
      answer: [
        "Le solde bonus est",
        "un solde interne",
        "temporaire du",
        "projet. Il est",
        "crédité depuis les",
        "tâches, les bonus",
        "de parrainage, les",
        "cadeaux, les",
        "Lotteries et",
        "d'autres",
        "mécaniques",
        "internes. Il ne",
        "peut pas être",
        "retiré",
        "directement.",
      ].join(" "),
      keywords: [
        "solde bonus",
        "interne",
      ],
    },
    "7.1-2": {
      question: [
        "Qu'est ce que le",
        "solde principal ?",
      ].join(" "),
      answer: [
        "Le solde principal",
        "contient les EFHC",
        "principaux. C'est",
        "le résultat du",
        "cycle de jeu, et",
        "les retraits sont",
        "disponibles depuis",
        "ce solde.",
      ].join(" "),
      keywords: [
        "solde principal",
        "retrait",
      ],
    },
    "7.1-3": {
      question: [
        "Quelle est la",
        "différence entre",
        "le solde bonus et",
        "le solde principal",
        "?",
      ].join(" "),
      answer: [
        "Le solde bonus",
        "sert à la vie",
        "interne du jeu. Le",
        "solde principal",
        "est le résultat du",
        "parcours de jeu",
        "déjà passé par la",
        "génération",
        "d'énergie et la",
        "conversion.",
      ].join(" "),
      keywords: [
        "différence",
        "bonus",
        "principal",
      ],
    },
    "7.2-1": {
      question: [
        "Le solde bonus",
        "peut il être",
        "retiré directement",
        "?",
      ].join(" "),
      answer: [
        "Non. Le solde",
        "bonus ne peut pas",
        "être retiré",
        "directement. Il",
        "doit passer par",
        "tout le cycle",
        "interne du jeu.",
      ].join(" "),
      keywords: [
        "retirer bonus",
        "retrait direct",
      ],
    },
    "7.2-2": {
      question: [
        "Quel chemin",
        "complet suit le",
        "solde bonus ?",
      ].join(" "),
      answer: [
        "Le chemin complet",
        "est le suivant :",
        "les pièces bonus",
        "servent à acheter",
        "un panneau, le",
        "panneau commence à",
        "générer de",
        "l'énergie,",
        "l'énergie",
        "accumulée est",
        "convertie en kWh",
        "puis en EFHC",
        "principaux. Ce",
        "n'est qu'après",
        "cela que le",
        "résultat apparaît",
        "sur le solde",
        "principal.",
      ].join(" "),
      keywords: [
        "cycle",
        "panneau",
        "kwh",
      ],
    },
    "7.2-3": {
      question: [
        "Comment le solde",
        "bonus devient il",
        "des EFHC",
        "principaux ?",
      ].join(" "),
      answer: [
        "Le solde bonus est",
        "la ressource de",
        "départ du",
        "processus de jeu.",
        "Grâce à l'achat du",
        "panneau, à la",
        "génération",
        "d'énergie et à la",
        "conversion, il",
        "devient des EFHC",
        "principaux.",
      ].join(" "),
      keywords: [
        "conversion",
        "efhc principal",
      ],
    },
    "7.2-4": {
      question: [
        "Dans quel ordre",
        "les fonds sont ils",
        "dépensés dans les",
        "dépenses internes",
        "?",
      ].join(" "),
      answer: [
        "Dans toutes les",
        "dépenses internes",
        "du projet, les",
        "fonds sont",
        "utilisés d'abord",
        "depuis le solde",
        "bonus puis depuis",
        "le solde",
        "principal.",
      ].join(" "),
      keywords: [
        "ordre de dépense",
        "bonus d'abord",
      ],
    },
    "7.2-5": {
      question: [
        "Quelle est la",
        "différence simple",
        "entre les soldes",
        "total, bonus et",
        "principal ?",
      ].join(" "),
      answer: [
        "Le solde total",
        "regroupe tout pour",
        "montrer la",
        "puissance d'achat",
        "globale. Le solde",
        "bonus est",
        "l'énergie interne",
        "du jeu qui démarre",
        "le cycle. Le solde",
        "principal est le",
        "résultat final qui",
        "peut servir de",
        "valeur principale",
        "et être retiré",
        "selon les règles",
        "du projet.",
      ].join(" "),
      keywords: [
        "solde total",
        "explication simple",
      ],
    },
    "14.1-1": {
      question: [
        "Comment fonctionne",
        "l'échange",
        "d'énergie en EFHC",
        "?",
      ].join(" "),
      answer: [
        "Exchange est la",
        "conversion du",
        "progrès en EFHC",
        "principaux.",
        "L'énergie",
        "accumulée est",
        "transformée en",
        "pièces principales",
        "du projet.",
      ].join(" "),
      keywords: [
        "exchange",
        "énergie",
      ],
    },
    "14.1-2": {
      question: [
        "Que signifie la",
        "règle 1 kWh = 1",
        "EFHC ?",
      ].join(" "),
      answer: [
        "C'est le taux",
        "interne fixe du",
        "projet. Chaque",
        "unité d'énergie",
        "est convertie en",
        "la même quantité",
        "d'EFHC.",
      ].join(" "),
      keywords: [
        "1 kwh 1 efhc",
        "taux",
      ],
    },
    "14.1-3": {
      question: [
        "Pourquoi la page",
        "Exchange affiche t",
        "elle les pièces",
        "principales et non",
        "le solde total ?",
      ].join(" "),
      answer: [
        "Parce que",
        "l'échange est lié",
        "à la valeur",
        "principale et au",
        "solde qui compte",
        "pour cette",
        "opération précise.",
      ].join(" "),
      keywords: [
        "page exchange",
        "solde principal",
      ],
    },
    "14.2-1": {
      question: [
        "Comment fonctionne",
        "le retrait ?",
      ].join(" "),
      answer: [
        "Une demande de",
        "retrait est créée,",
        "puis elle est",
        "traitée le plus",
        "vite possible par",
        "le premier",
        "opérateur",
        "disponible.",
      ].join(" "),
      keywords: [
        "retrait",
        "demande",
      ],
    },
    "14.2-2": {
      question: [
        "Quel solde peut",
        "être utilisé pour",
        "le retrait ?",
      ].join(" "),
      answer: [
        "Le retrait est",
        "disponible",
        "uniquement depuis",
        "le solde",
        "principal.",
      ].join(" "),
      keywords: [
        "retrait principal",
        "solde principal",
      ],
    },
    "14.2-3": {
      question: [
        "Pourquoi le",
        "retrait est il",
        "disponible",
        "uniquement depuis",
        "le solde principal",
        "?",
      ].join(" "),
      answer: [
        "Parce que le solde",
        "principal est ce",
        "qui appartient",
        "déjà au joueur",
        "comme résultat du",
        "processus de jeu",
        "ou comme pièces",
        "achetées. Les",
        "pièces bonus",
        "participent au",
        "processus interne",
        "et ne constituent",
        "pas un résultat",
        "directement",
        "retirable.",
      ].join(" "),
      keywords: [
        "pourquoi principal",
        "bonus non retirable",
      ],
    },
    "14.2-4": {
      question: [
        "Quel est le",
        "retrait minimal ?",
      ].join(" "),
      answer: [
        "Le montant minimal",
        "du retrait est de",
        "10 EFHC.",
      ].join(" "),
      keywords: [
        "retrait minimal",
        "10 efhc",
      ],
    },
  },
  es: {
    "5.1-1": {
      question: [
        "¿Qué es la sección",
        "Perfil / Ajustes?",
      ].join(" "),
      answer: [
        "Perfil / Ajustes",
        "es el lugar donde",
        "el usuario",
        "gestiona su perfil",
        "y la configuración",
        "del bot. Allí se",
        "muestran los",
        "estados clave y",
        "las preferencias",
        "personales de la",
        "interfaz.",
      ].join(" "),
      keywords: [
        "perfil",
        "ajustes",
      ],
    },
    "5.1-2": {
      question: [
        "¿Qué se muestra en",
        "la parte superior",
        "de Perfil /",
        "Ajustes?",
      ].join(" "),
      answer: [
        "La parte superior",
        "muestra el avatar,",
        "el nombre de",
        "Telegram y los",
        "estados Activ y",
        "VIP si ya están",
        "disponibles.",
      ].join(" "),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: [
        "¿Qué se puede",
        "configurar en",
        "Perfil / Ajustes?",
      ].join(" "),
      answer: [
        "En resumen:",
        "idioma,",
        "apariencia,",
        "sonido, vibración,",
        "notificaciones,",
        "confirmaciones de",
        "acción y otras",
        "preferencias de",
        "interfaz.",
      ].join(" "),
      keywords: [
        "idioma",
        "notificaciones",
        "apariencia",
      ],
    },
    "5.1-4": {
      question: [
        "¿Qué hay dentro de",
        "Soporte e",
        "Información?",
      ].join(" "),
      answer: [
        "Este bloque",
        "contiene ayuda,",
        "respuestas a",
        "preguntas",
        "frecuentes, reglas",
        "del proyecto y",
        "otros materiales",
        "informativos.",
      ].join(" "),
      keywords: [
        "ayuda",
        "soporte",
        "reglas",
      ],
    },
    "6.1-1": {
      question: [
        "¿Qué es la sección",
        "Wallet en Perfil /",
        "Ajustes?",
      ].join(" "),
      answer: [
        "En Wallet el",
        "usuario puede",
        "vincular una o",
        "varias billeteras",
        "y elegir la",
        "billetera",
        "principal.",
      ].join(" "),
      keywords: [
        "wallet",
        "billetera principal",
      ],
    },
    "6.1-2": {
      question: [
        "¿Para qué sirve la",
        "billetera",
        "principal?",
      ].join(" "),
      answer: [
        "La billetera",
        "principal se usa",
        "cuando las reglas",
        "del proyecto",
        "exigen una",
        "billetera",
        "vinculada para",
        "funciones y",
        "operaciones.",
      ].join(" "),
      keywords: [
        "principal",
        "billetera vinculada",
      ],
    },
    "6.1-3": {
      question: [
        "¿Se puede cambiar",
        "la billetera",
        "principal?",
      ].join(" "),
      answer: [
        "Sí. Se puede",
        "elegir otra",
        "billetera",
        "principal entre",
        "las billeteras ya",
        "vinculadas.",
      ].join(" "),
      keywords: [
        "cambiar wallet",
        "principal",
      ],
    },
    "6.1-4": {
      question: [
        "¿Se puede eliminar",
        "una billetera",
        "vinculada?",
      ].join(" "),
      answer: [
        "Sí. Si una",
        "billetera ya no es",
        "necesaria, su",
        "vínculo puede",
        "eliminarse.",
      ].join(" "),
      keywords: [
        "eliminar wallet",
        "desvincular",
      ],
    },
    "6.1-5": {
      question: [
        "¿Qué pasa si el",
        "usuario toca una",
        "función que",
        "necesita una",
        "wallet?",
      ].join(" "),
      answer: [
        "Si la función",
        "elegida requiere",
        "una wallet, el bot",
        "inicia",
        "automáticamente el",
        "flujo de",
        "vinculación de la",
        "billetera.",
      ].join(" "),
      keywords: [
        "wallet requerida",
        "conectar wallet",
      ],
    },
    "6.1-6": {
      question: [
        "¿VIP NFT se activa",
        "automáticamente",
        "después de llegar",
        "a la wallet?",
      ].join(" "),
      answer: [
        "Sí. La lógica VIP",
        "se basa en la",
        "presencia del NFT",
        "en una wallet",
        "vinculada: el bot",
        "revisa la wallet",
        "automáticamente y",
        "actualiza el",
        "estado VIP.",
      ].join(" "),
      keywords: [
        "vip nft",
        "activación automática",
      ],
    },
    "6.1-7": {
      question: [
        "¿El usuario debe",
        "activar VIP",
        "manualmente",
        "después de recibir",
        "el NFT?",
      ].join(" "),
      answer: [
        "No. La lógica del",
        "proyecto prevé",
        "comprobaciones",
        "automáticas de la",
        "wallet y",
        "actualizaciones",
        "automáticas del",
        "estado VIP cuando",
        "el NFT se detecta",
        "en la colección",
        "requerida.",
      ].join(" "),
      keywords: [
        "vip manual",
        "comprobación automática",
      ],
    },
    "6.1-8": {
      question: [
        "¿Un VIP NFT da el",
        "efecto y el",
        "segundo o tercero",
        "no añaden nada?",
      ].join(" "),
      answer: [
        "Sí. Para el",
        "jugador basta con",
        "tener al menos un",
        "EFHC VIP NFT. El",
        "segundo y el",
        "tercero no añaden",
        "una bonificación",
        "extra de",
        "generación.",
      ].join(" "),
      keywords: [
        "un nft",
        "efecto vip",
      ],
    },
    "7.1-1": {
      question: [
        "¿Qué es el saldo",
        "bonus?",
      ].join(" "),
      answer: [
        "El saldo bonus es",
        "un saldo interno",
        "temporal del",
        "proyecto. Se",
        "acredita desde",
        "tareas, bonos de",
        "referidos,",
        "regalos, Lotteries",
        "y otras mecánicas",
        "internas. No puede",
        "retirarse",
        "directamente.",
      ].join(" "),
      keywords: [
        "saldo bonus",
        "interno",
      ],
    },
    "7.1-2": {
      question: [
        "¿Qué es el saldo",
        "principal?",
      ].join(" "),
      answer: [
        "El saldo principal",
        "contiene los EFHC",
        "principales. Es el",
        "resultado del",
        "ciclo del juego y",
        "desde él están",
        "disponibles los",
        "retiros.",
      ].join(" "),
      keywords: [
        "saldo principal",
        "retiro",
      ],
    },
    "7.1-3": {
      question: [
        "¿Cuál es la",
        "diferencia entre",
        "el saldo bonus y",
        "el saldo",
        "principal?",
      ].join(" "),
      answer: [
        "El saldo bonus",
        "sirve para la vida",
        "interna del juego.",
        "El saldo principal",
        "es el resultado",
        "del recorrido del",
        "juego que ya pasó",
        "por la generación",
        "de energía y la",
        "conversión.",
      ].join(" "),
      keywords: [
        "diferencia",
        "bonus",
        "principal",
      ],
    },
    "7.2-1": {
      question: [
        "¿Se puede retirar",
        "el saldo bonus",
        "directamente?",
      ].join(" "),
      answer: [
        "No. El saldo bonus",
        "no puede retirarse",
        "directamente. Debe",
        "pasar por todo el",
        "ciclo interno del",
        "juego.",
      ].join(" "),
      keywords: [
        "retirar bonus",
        "retiro directo",
      ],
    },
    "7.2-2": {
      question: [
        "¿Qué recorrido",
        "completo sigue el",
        "saldo bonus?",
      ].join(" "),
      answer: [
        "El recorrido",
        "completo es este:",
        "las monedas bonus",
        "se usan para",
        "comprar un panel,",
        "el panel empieza a",
        "generar energía,",
        "la energía",
        "acumulada se",
        "convierte en kWh y",
        "luego en EFHC",
        "principales. Solo",
        "después de eso el",
        "resultado aparece",
        "en el saldo",
        "principal.",
      ].join(" "),
      keywords: [
        "ciclo",
        "panel",
        "kwh",
      ],
    },
    "7.2-3": {
      question: [
        "¿Cómo se convierte",
        "el saldo bonus en",
        "EFHC principales?",
      ].join(" "),
      answer: [
        "El saldo bonus es",
        "el recurso inicial",
        "del proceso de",
        "juego. Mediante la",
        "compra del panel,",
        "la generación de",
        "energía y la",
        "conversión, se",
        "transforma en EFHC",
        "principales.",
      ].join(" "),
      keywords: [
        "conversión",
        "efhc principal",
      ],
    },
    "7.2-4": {
      question: [
        "¿En qué orden se",
        "gastan los fondos",
        "en los gastos",
        "internos?",
      ].join(" "),
      answer: [
        "En todos los",
        "gastos internos",
        "del proyecto, los",
        "fondos se gastan",
        "primero desde el",
        "saldo bonus y",
        "después desde el",
        "saldo principal.",
      ].join(" "),
      keywords: [
        "orden de gasto",
        "bonus primero",
      ],
    },
    "7.2-5": {
      question: [
        "¿Cuál es la",
        "diferencia simple",
        "entre los saldos",
        "total, bonus y",
        "principal?",
      ].join(" "),
      answer: [
        "El saldo total es",
        "todo junto para",
        "entender el poder",
        "de compra general.",
        "El saldo bonus es",
        "la energía interna",
        "del juego que",
        "inicia el ciclo.",
        "El saldo principal",
        "es el resultado",
        "final que puede",
        "usarse como valor",
        "principal y",
        "retirarse según",
        "las reglas del",
        "proyecto.",
      ].join(" "),
      keywords: [
        "saldo total",
        "explicación simple",
      ],
    },
    "14.1-1": {
      question: [
        "¿Cómo funciona el",
        "intercambio de",
        "energía a EFHC?",
      ].join(" "),
      answer: [
        "Exchange es la",
        "conversión del",
        "progreso en EFHC",
        "principales. La",
        "energía acumulada",
        "se transforma en",
        "las monedas",
        "principales del",
        "proyecto.",
      ].join(" "),
      keywords: [
        "exchange",
        "energía",
      ],
    },
    "14.1-2": {
      question: [
        "¿Qué significa la",
        "regla 1 kWh = 1",
        "EFHC?",
      ].join(" "),
      answer: [
        "Es la tasa interna",
        "fija del proyecto.",
        "Cada unidad de",
        "energía se",
        "convierte en la",
        "misma cantidad de",
        "EFHC.",
      ].join(" "),
      keywords: [
        "1 kwh 1 efhc",
        "tasa",
      ],
    },
    "14.1-3": {
      question: [
        "¿Por qué la página",
        "Exchange muestra",
        "monedas",
        "principales y no",
        "el saldo total?",
      ].join(" "),
      answer: [
        "Porque Exchange",
        "está ligado al",
        "valor principal y",
        "al saldo que",
        "importa para esa",
        "operación",
        "concreta.",
      ].join(" "),
      keywords: [
        "página exchange",
        "saldo principal",
      ],
    },
    "14.2-1": {
      question: [
        "¿Cómo funciona el",
        "retiro?",
      ].join(" "),
      answer: [
        "Se crea una",
        "solicitud de",
        "retiro y luego el",
        "primer operador",
        "disponible la",
        "procesa lo antes",
        "posible.",
      ].join(" "),
      keywords: [
        "retiro",
        "solicitud",
      ],
    },
    "14.2-2": {
      question: [
        "¿Qué saldo se",
        "puede usar para el",
        "retiro?",
      ].join(" "),
      answer: [
        "El retiro está",
        "disponible solo",
        "desde el saldo",
        "principal.",
      ].join(" "),
      keywords: [
        "retiro principal",
        "solo principal",
      ],
    },
    "14.2-3": {
      question: [
        "¿Por qué el retiro",
        "está disponible",
        "solo desde el",
        "saldo principal?",
      ].join(" "),
      answer: [
        "Porque el saldo",
        "principal es lo",
        "que ya pertenece",
        "al jugador como",
        "resultado del",
        "proceso del juego",
        "o como monedas",
        "compradas. Las",
        "monedas bonus",
        "participan en el",
        "proceso interno y",
        "no son un",
        "resultado",
        "retirable de forma",
        "directa.",
      ].join(" "),
      keywords: [
        "por qué principal",
        "bonus no retirable",
      ],
    },
    "14.2-4": {
      question: [
        "¿Cuál es el retiro",
        "mínimo?",
      ].join(" "),
      answer: [
        "La cantidad mínima",
        "de retiro es 10",
        "EFHC.",
      ].join(" "),
      keywords: [
        "retiro mínimo",
        "10 efhc",
      ],
    },
  },
  ua: {

    "10.1-1": {
      question: [
        "Скільки рівнів досягнень",
        "є в енергетичному прогресі?",
      ].join(" "),
      answer: [
        "В енергетичному прогресі",
        "передбачено 12 рівнів",
        "досягнення.",
      ].join(" "),
      keywords: ["рівні", "прогрес", "ранг"],
    },
    "10.1-2": {
      question: [
        "Що означають рівні",
        "досягнення?",
      ].join(" "),
      answer: [
        "Це рівні, ранги та прогрес",
        "одночасно. Вони показують,",
        "скільки віртуальної енергії",
        "вже згенеровано і як далеко",
        "просунувся гравець на",
        "енергетичному шляху.",
      ].join(" "),
      keywords: ["досягнення", "ранг", "енергетичний шлях"],
    },
    "10.1-3": {
      question: [
        "Чому назви рівнів",
        "пов'язані з екологією та",
        "планетою?",
      ].join(" "),
      answer: [
        "Тому що сама ідея гри",
        "пов'язана з віртуальною",
        "зеленою енергетикою,",
        "мотивацією людей та",
        "символічним внеском в",
        "оздоровлення планети Земля.",
      ].join(" "),
      keywords: ["екологія", "планета", "зелена енергія"],
    },
    "11.1-1": {
      question: [
        "Що означає статус Activ?",
      ].join(" "),
      answer: [
        "Activ — це постійний",
        "активний статус. Він",
        "означає, що гра по-",
        "справжньому почалася,",
        "тому що була куплена хоча",
        "б одна панель.",
      ].join(" "),
      keywords: ["activ", "статус", "панель"],
    },
    "11.1-2": {
      question: [
        "Як отримати Activ?",
      ].join(" "),
      answer: [
        "Щоб отримати Activ,",
        "достатньо купити одну",
        "панель. Після цієї покупки",
        "статус надається на",
        "постійній основі.",
      ].join(" "),
      keywords: ["отримати activ", "купити панель"],
    },
    "11.1-3": {
      question: [
        "Чи треба чекати обміну або",
        "завершення генерації, щоб",
        "отримати Activ?",
      ].join(" "),
      answer: [
        "Ні. Activ з'являється вже",
        "після покупки першої",
        "панелі. Для цього не треба",
        "чекати обміну або",
        "завершення генерації.",
      ].join(" "),
      keywords: ["чекати", "обмін", "генерація"],
    },
    "11.1-4": {
      question: [
        "Activ тимчасовий чи",
        "постійний?",
      ].join(" "),
      answer: [
        "Activ — це постійний",
        "статус.",
      ].join(" "),
      keywords: ["постійний", "activ"],
    },
    "11.1-5": {
      question: [
        "Чи зберігається Activ,",
        "якщо панель пізніше",
        "переходить в Archive?",
      ].join(" "),
      answer: [
        "Так. Навіть якщо панель",
        "пізніше переходить в",
        "Archive, статус Activ",
        "зберігається.",
      ].join(" "),
      keywords: ["archive", "зберігається"],
    },
    "11.1-6": {
      question: [
        "Чому статус Activ",
        "важливий?",
      ].join(" "),
      answer: [
        "Activ допомагає відділяти",
        "реальних гравців від",
        "випадкових реєстрацій,",
        "ботів і ботоферм. Саме за",
        "активних запрошених",
        "нараховуються реферальні",
        "бонуси.",
      ].join(" "),
      keywords: ["важливо", "реферальний бонус"],
    },
    "11.2-1": {
      question: [
        "Коли нараховуються",
        "реферальні бонуси?",
      ].join(" "),
      answer: [
        "Реферальні бонуси",
        "перевіряються ботом",
        "автоматично. Щойно",
        "гравець стає активним,",
        "бонус одразу",
        "нараховується.",
      ].join(" "),
      keywords: ["реферальний бонус", "автоматично"],
    },
    "11.2-2": {
      question: [
        "Що означає активний і",
        "неактивний реферал?",
      ].join(" "),
      answer: [
        "Активний реферал — це",
        "гравець, який уже купив",
        "хоча б одну панель і",
        "отримав статус Activ.",
        "Неактивний реферал — це",
        "той, хто ще не увійшов у",
        "ігровий цикл і поки не дає",
        "права на бонус.",
      ].join(" "),
      keywords: ["активний реферал", "неактивний реферал"],
    },
    "11.2-3": {
      question: [
        "Чому автоматичне",
        "нарахування важливе?",
      ].join(" "),
      answer: [
        "Тому що щойно у",
        "запрошеного загоряється",
        "статус Activ, бот одразу",
        "фіксує цей стан і",
        "автоматично нараховує",
        "запрошувачу і реферальний",
        "бонус, і рейтингове",
        "зростання.",
      ].join(" "),
      keywords: ["автоматичне нарахування", "рейтинг"],
    },
    "11.2-4": {
      question: [
        "Що робити, якщо не",
        "надійшов реферальний",
        "бонус?",
      ].join(" "),
      answer: [
        "Якщо бонус не надійшов,",
        "значить запрошений гравець",
        "ще не став активним",
        "гравцем за правилами",
        "проєкту.",
      ].join(" "),
      keywords: ["бонус не надійшов", "активний гравець"],
    },
    "11.2-5": {
      question: [
        "Чому реферальні бонуси",
        "йдуть тільки за активних",
        "рефералів?",
      ].join(" "),
      answer: [
        "Тому що проєкт винагороджує",
        "не просто саму реєстрацію,",
        "а вхід у реальний ігровий",
        "цикл. Activ підтверджує,",
        "що запрошений справді",
        "почав грати.",
      ].join(" "),
      keywords: ["тільки активні", "ігровий цикл"],
    },
    "11.2-6": {
      question: [
        "Що видно в розділах",
        '"Активні" і "Неактивні"?',
      ].join(" "),
      answer: [
        "Ці розділи потрібні для",
        "розуміння ситуації: хто вже",
        "увійшов в ігровий цикл і",
        "дає право на винагороду, а",
        "хто поки залишається лише",
        "зареєстрованим без",
        "активного статусу.",
      ].join(" "),
      keywords: ["активні", "неактивні"],
    },
    "12.1-1": {
      question: [
        "Навіщо потрібна сторінка",
        "Tasks?",
      ].join(" "),
      answer: [
        "Сторінка Tasks потрібна для",
        "виконання завдань заради",
        "винагороди.",
      ].join(" "),
      keywords: ["tasks", "винагорода"],
    },
    "12.1-2": {
      question: [
        "Що дає виконання",
        "завдань?",
      ].join(" "),
      answer: [
        "Завдання дають бонусні",
        "монети та мотивують брати",
        "участь у житті гравця.",
      ].join(" "),
      keywords: ["бонусні монети", "мотивація"],
    },
    "13.1-1": {
      question: [
        "Навіщо потрібна сторінка",
        "Referrals?",
      ].join(" "),
      answer: [
        "Сторінка Referrals потрібна",
        "для роботи із запрошеними та",
        "розуміння логіки",
        "реферальних бонусів.",
      ].join(" "),
      keywords: ["referrals", "запрошені"],
    },
    "13.1-2": {
      question: [
        "Як називаються розділи на",
        "сторінці Referrals?",
      ].join(" "),
      answer: [
        "На сторінці Referrals",
        "використовуються розділи",
        '"Активні" і "Неактивні".',
      ].join(" "),
      keywords: ["розділи", "активні неактивні"],
    },
    "13.1-3": {
      question: [
        "Що видно на сторінці",
        "Referrals?",
      ].join(" "),
      answer: [
        "На сторінці Referrals видно",
        "список запрошених, окремі",
        "розділи активних і",
        "неактивних рефералів,",
        "кількість активних",
        "запрошених і відомості про",
        "нараховані бонуси.",
      ].join(" "),
      keywords: ["список", "нараховані бонуси"],
    },
    "13.1-4": {
      question: [
        "Що показують",
        '"Активні" і "Неактивні"?',
      ].join(" "),
      answer: [
        "Це допомагає одразу бачити",
        "реальну картину: хто вже",
        "увійшов в ігровий цикл і",
        "приносить винагороду, а хто",
        "ще не дійшов до активного",
        "статусу.",
      ].join(" "),
      keywords: ["реальна картина", "винагорода"],
    },
    "5.1-1": {
      question: [
        "Що таке розділ Профіль /",
        "Налаштування?",
      ].join(" "),
      answer: [
        "Профіль / Налаштування — це",
        "розділ, де користувач керує",
        "профілем і параметрами бота.",
        "Тут видно основні статуси та",
        "доступні персональні",
        "налаштування інтерфейсу.",
      ].join(" "),
      keywords: [
        "профіль",
        "налаштування",
      ],
    },
    "5.1-2": {
      question: [
        "Що відображається у верхній",
        "частині Профілю /",
        "Налаштувань?",
      ].join(" "),
      answer: [
        "У верхній частині Профілю /",
        "Налаштувань відображаються",
        "аватар, ім'я Telegram і",
        "статуси Activ та VIP, якщо",
        "вони вже є.",
      ].join(" "),
      keywords: [
        "аватар",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: [
        "Що можна налаштовувати в",
        "розділі Профіль /",
        "Налаштування?",
      ].join(" "),
      answer: [
        "Коротко: мову бота,",
        "зовнішній вигляд, звук,",
        "вібрацію, сповіщення,",
        "підтвердження дій та інші",
        "параметри інтерфейсу.",
      ].join(" "),
      keywords: [
        "мова",
        "вигляд",
        "сповіщення",
      ],
    },
    "5.1-4": {
      question: [
        "Що знаходиться в розділі",
        "Підтримка та інформація?",
      ].join(" "),
      answer: [
        "У цьому розділі знаходяться",
        "допомога, відповіді на",
        "поширені запитання, правила",
        "проєкту та інші інформаційні",
        "матеріали.",
      ].join(" "),
      keywords: [
        "підтримка",
        "допомога",
        "правила",
      ],
    },
    "6.1-1": {
      question: [
        "Що таке розділ Гаманець у",
        "Профілі / Налаштуваннях?",
      ].join(" "),
      answer: [
        "У розділі гаманця можна",
        "прив'язати один або кілька",
        "гаманців і вибрати основний",
        "гаманець.",
      ].join(" "),
      keywords: [
        "гаманець",
        "основний гаманець",
      ],
    },
    "6.1-2": {
      question: [
        "Навіщо потрібен основний",
        "гаманець?",
      ].join(" "),
      answer: [
        "Основний гаманець",
        "використовується там, де",
        "правила проєкту вимагають",
        "прив'язаний гаманець для",
        "функцій і операцій.",
      ].join(" "),
      keywords: [
        "основний",
        "прив'язаний гаманець",
      ],
    },
    "6.1-3": {
      question: [
        "Чи можна змінити основний",
        "гаманець?",
      ].join(" "),
      answer: [
        "Так. Можна вибрати інший",
        "основний гаманець серед уже",
        "прив'язаних.",
      ].join(" "),
      keywords: [
        "змінити гаманець",
        "основний",
      ],
    },
    "6.1-4": {
      question: [
        "Чи можна видалити",
        "прив'язаний гаманець?",
      ].join(" "),
      answer: [
        "Так. Якщо гаманець більше не",
        "потрібен, його прив'язку",
        "можна видалити.",
      ].join(" "),
      keywords: [
        "видалити гаманець",
        "відв'язати",
      ],
    },
    "6.1-5": {
      question: [
        "Що станеться, якщо натиснути",
        "кнопку, де потрібен",
        "гаманець?",
      ].join(" "),
      answer: [
        "Якщо для вибраної функції",
        "потрібен гаманець,",
        "натискання такої кнопки",
        "автоматично запускає",
        "прив'язку гаманця.",
      ].join(" "),
      keywords: [
        "потрібен гаманець",
        "підключити гаманець",
      ],
    },
    "6.1-6": {
      question: [
        "VIP NFT активується",
        "автоматично після отримання",
        "на гаманець?",
      ].join(" "),
      answer: [
        "Так. Логіка VIP базується на",
        "факті наявності NFT у",
        "прив'язаному гаманці: бот",
        "автоматично перевіряє",
        "гаманець і оновлює",
        "VIP-статус.",
      ].join(" "),
      keywords: [
        "vip nft",
        "автоматична активація",
      ],
    },
    "6.1-7": {
      question: [
        "Чи потрібно вручну вмикати",
        "VIP після отримання NFT?",
      ].join(" "),
      answer: [
        "Ні. Логіка проєкту",
        "розрахована на автоматичну",
        "перевірку гаманця й",
        "автоматичне оновлення",
        "VIP-статусу після виявлення",
        "NFT у потрібній колекції.",
      ].join(" "),
      keywords: [
        "ручний vip",
        "автоматична перевірка",
      ],
    },
    "6.1-8": {
      question: [
        "Один VIP NFT дає ефект, а",
        "другий і третій уже ні?",
      ].join(" "),
      answer: [
        "Так. Для гравця достатньо",
        "наявності хоча б одного EFHC",
        "VIP NFT. Другий і третій NFT",
        "не дають додаткового",
        "підсилення генерації.",
      ].join(" "),
      keywords: [
        "один nft",
        "vip ефект",
      ],
    },
    "7.1-1": {
      question: [
        "Що таке бонусний баланс?",
      ].join(" "),
      answer: [
        "Бонусний баланс — це",
        "тимчасовий внутрішній баланс",
        "проєкту. Він нараховується",
        "за завдання, реферальні",
        "бонуси, подарунки, розіграші",
        "та інші внутрішні ігрові",
        "механіки. Його не можна",
        "вивести напряму.",
      ].join(" "),
      keywords: [
        "бонусний баланс",
        "внутрішній",
      ],
    },
    "7.1-2": {
      question: [
        "Що таке основний баланс?",
      ].join(" "),
      answer: [
        "Основний баланс — це основні",
        "EFHC. Саме в нього",
        "перетворюється результат",
        "ігрового циклу, і саме з",
        "нього доступний вивід.",
      ].join(" "),
      keywords: [
        "основний баланс",
        "вивід",
      ],
    },
    "7.1-3": {
      question: [
        "У чому різниця між бонусним",
        "і основним балансом?",
      ].join(" "),
      answer: [
        "Бонусний баланс потрібен для",
        "внутрішнього життя гри.",
        "Основний баланс — це",
        "результат ігрового шляху,",
        "який уже пройшов через",
        "генерацію енергії та",
        "конвертацію.",
      ].join(" "),
      keywords: [
        "різниця",
        "бонусний",
        "основний",
      ],
    },
    "7.2-1": {
      question: [
        "Чи можна вивести бонусний",
        "баланс напряму?",
      ].join(" "),
      answer: [
        "Ні. Бонусний баланс напряму",
        "не виводиться. Він має",
        "пройти повний внутрішній",
        "ігровий цикл.",
      ].join(" "),
      keywords: [
        "вивід бонусу",
        "прямий вивід",
      ],
    },
    "7.2-2": {
      question: [
        "Який повний шлях проходить",
        "бонусний баланс?",
      ].join(" "),
      answer: [
        "Повний шлях такий: бонусні",
        "монети використовуються на",
        "купівлю панелі, панель",
        "починає генерувати енергію,",
        "накопичена енергія",
        "переводиться в kWh, а потім",
        "енергія конвертується в",
        "основні EFHC. Лише після",
        "цього результат з'являється",
        "в основному балансі.",
      ].join(" "),
      keywords: [
        "цикл",
        "панель",
        "kwh",
      ],
    },
    "7.2-3": {
      question: [
        "Як бонусний баланс",
        "перетворюється на основні",
        "EFHC?",
      ].join(" "),
      answer: [
        "Бонусний баланс є стартовим",
        "ресурсом для ігрового",
        "процесу. Через купівлю",
        "панелі, генерацію енергії та",
        "конвертацію він переходить в",
        "основні EFHC.",
      ].join(" "),
      keywords: [
        "конвертація",
        "основні efhc",
      ],
    },
    "7.2-4": {
      question: [
        "У якому порядку списуються",
        "кошти у внутрішніх витратах?",
      ].join(" "),
      answer: [
        "У всіх внутрішніх витратах",
        "проєкту кошти списуються",
        "спочатку з бонусного",
        "балансу, а потім з",
        "основного.",
      ].join(" "),
      keywords: [
        "порядок списання",
        "спочатку бонусний",
      ],
    },
    "7.2-5": {
      question: [
        "Чим відрізняються загальний,",
        "бонусний та основний баланси",
        "простими словами?",
      ].join(" "),
      answer: [
        "Загальний баланс — це все",
        "разом для розуміння",
        "загальної купівельної сили.",
        "Бонусний баланс — це",
        "внутрішня ігрова енергія для",
        "запуску циклу. Основний",
        "баланс — це вже результат,",
        "який можна використовувати",
        "як основну цінність і",
        "виводити за правилами",
        "проєкту.",
      ].join(" "),
      keywords: [
        "загальний баланс",
        "просте пояснення",
      ],
    },
    "14.1-1": {
      question: [
        "Як працює обмін енергії на",
        "EFHC?",
      ].join(" "),
      answer: [
        "Обмін — це конвертація",
        "прогресу в основні EFHC.",
        "Накопичена енергія",
        "перетворюється на основні",
        "монети проєкту.",
      ].join(" "),
      keywords: [
        "обмін",
        "енергія",
      ],
    },
    "14.1-2": {
      question: [
        "Що означає правило 1 kWh = 1",
        "EFHC?",
      ].join(" "),
      answer: [
        "Це фіксований внутрішній",
        "курс проєкту. Кожна одиниця",
        "енергії конвертується в",
        "рівну кількість EFHC.",
      ].join(" "),
      keywords: [
        "1 kwh 1 efhc",
        "курс",
      ],
    },
    "14.1-3": {
      question: [
        "Чому на сторінці Exchange",
        "відображаються основні",
        "монети, а не загальний",
        "баланс?",
      ].join(" "),
      answer: [
        "Тому що обмін пов'язаний з",
        "основною цінністю і з тим",
        "балансом, який має значення",
        "саме для цієї операції.",
      ].join(" "),
      keywords: [
        "exchange",
        "основний баланс",
      ],
    },
    "14.2-1": {
      question: [
        "Як відбувається вивід?",
      ].join(" "),
      answer: [
        "Оформлюється заявка на",
        "вивід, після чого вона",
        "обробляється максимально",
        "швидко першим вільним",
        "оператором.",
      ].join(" "),
      keywords: [
        "вивід",
        "заявка",
      ],
    },
    "14.2-2": {
      question: [
        "З якого балансу можна робити",
        "вивід?",
      ].join(" "),
      answer: [
        "Вивід доступний тільки з",
        "основного балансу.",
      ].join(" "),
      keywords: [
        "вивід main",
        "лише основний",
      ],
    },
    "14.2-3": {
      question: [
        "Чому вивід доступний тільки",
        "з основного балансу?",
      ].join(" "),
      answer: [
        "Тому що основний баланс — це",
        "те, що вже належить гравцю",
        "як результат ігрового",
        "процесу або куплені монети.",
        "Бонусні монети беруть участь",
        "у внутрішньому ігровому",
        "процесі й не є прямим",
        "результатом для виводу.",
      ].join(" "),
      keywords: [
        "чому лише основний",
        "бонус не виводиться",
      ],
    },
    "14.2-4": {
      question: [
        "Який мінімальний вивід?",
      ].join(" "),
      answer: [
        "Мінімальна сума виводу",
        "становить 10 EFHC.",
      ].join(" "),
      keywords: [
        "мінімальний вивід",
        "10 efhc",
      ],
    },
  },

  it: {
    "5.1-1": {
      question: j(
        "Che cos'è la sezione",
        "Profilo / Impostazioni?",
      ),
      answer: j(
        "Profilo / Impostazioni è la",
        "sezione in cui l'utente",
        "gestisce il profilo e i",
        "parametri del bot. Qui si",
        "vedono gli stati principali",
        "e le impostazioni personali",
        "dell'interfaccia.",
      ),
      keywords: [
        "profilo",
        "impostazioni",
      ],
    },
    "5.1-2": {
      question: j(
        "Cosa viene mostrato nella",
        "parte alta di Profilo /",
        "Impostazioni?",
      ),
      answer: j(
        "Nella parte alta vengono",
        "mostrati l'avatar, il nome",
        "Telegram e gli stati Activ e",
        "VIP, se sono già presenti.",
      ),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: j(
        "Cosa si può configurare in",
        "Profilo / Impostazioni?",
      ),
      answer: j(
        "In breve: la lingua del bot,",
        "l'aspetto, il suono, la",
        "vibrazione, le notifiche, le",
        "conferme delle azioni e altre",
        "preferenze dell'interfaccia.",
      ),
      keywords: [
        "lingua",
        "aspetto",
        "notifiche",
      ],
    },
    "5.1-4": {
      question: j(
        "Che cosa c'è nella sezione",
        "Supporto e informazioni?",
      ),
      answer: j(
        "In questa sezione si trovano",
        "l'aiuto, le risposte alle",
        "domande frequenti, le regole",
        "del progetto e altri",
        "materiali informativi.",
      ),
      keywords: [
        "supporto",
        "aiuto",
        "regole",
      ],
    },
    "6.1-1": {
      question: j(
        "Che cos'è la sezione Wallet",
        "in Profilo / Impostazioni?",
      ),
      answer: j(
        "Nella sezione Wallet è",
        "possibile collegare uno o più",
        "wallet e scegliere il wallet",
        "principale.",
      ),
      keywords: [
        "wallet",
        "wallet principale",
      ],
    },
    "6.1-2": {
      question: j(
        "Perché serve il wallet",
        "principale?",
      ),
      answer: j(
        "Il wallet principale viene",
        "usato dove le regole del",
        "progetto richiedono un wallet",
        "collegato per funzioni e",
        "operazioni.",
      ),
      keywords: [
        "principale",
        "wallet collegato",
      ],
    },
    "6.1-3": {
      question: j(
        "Si può cambiare il wallet",
        "principale?",
      ),
      answer: j(
        "Sì. È possibile scegliere un",
        "altro wallet principale tra",
        "quelli già collegati.",
      ),
      keywords: [
        "cambiare wallet",
        "principale",
      ],
    },
    "6.1-4": {
      question: j(
        "Si può rimuovere un wallet",
        "collegato?",
      ),
      answer: j(
        "Sì. Se un wallet non serve",
        "più, il collegamento può",
        "essere rimosso.",
      ),
      keywords: [
        "rimuovere wallet",
        "scollegare",
      ],
    },
    "6.1-5": {
      question: j(
        "Cosa succede se l'utente",
        "preme un pulsante che richiede",
        "un wallet?",
      ),
      answer: j(
        "Se la funzione scelta richiede",
        "un wallet, premendo quel",
        "pulsante si avvia",
        "automaticamente il flusso di",
        "collegamento del wallet.",
      ),
      keywords: [
        "wallet richiesto",
        "connettere wallet",
      ],
    },
    "6.1-6": {
      question: j(
        "Il VIP NFT si attiva",
        "automaticamente dopo l'arrivo",
        "nel wallet?",
      ),
      answer: j(
        "Sì. La logica VIP si basa",
        "sulla presenza dell'NFT in un",
        "wallet collegato: il bot",
        "controlla il wallet in modo",
        "automatico e aggiorna lo",
        "stato VIP.",
      ),
      keywords: [
        "vip nft",
        "attivazione automatica",
      ],
    },
    "6.1-7": {
      question: j(
        "Bisogna attivare manualmente",
        "il VIP dopo aver ricevuto",
        "l'NFT?",
      ),
      answer: j(
        "No. La logica del progetto è",
        "pensata per controlli",
        "automatici del wallet e per",
        "l'aggiornamento automatico",
        "dello stato VIP dopo che",
        "l'NFT viene trovato nella",
        "collezione richiesta.",
      ),
      keywords: [
        "vip manuale",
        "controllo automatico",
      ],
    },
    "6.1-8": {
      question: j(
        "Un solo VIP NFT dà l'effetto,",
        "mentre il secondo e il terzo",
        "non aggiungono nulla?",
      ),
      answer: j(
        "Sì. Per il giocatore basta",
        "avere almeno un EFHC VIP NFT.",
        "Il secondo e il terzo NFT non",
        "aggiungono ulteriore bonus",
        "alla generazione.",
      ),
      keywords: [
        "un nft",
        "effetto vip",
      ],
    },
    "7.1-1": {
      question: j(
        "Che cos'è il saldo bonus?",
      ),
      answer: j(
        "Il saldo bonus è un saldo",
        "interno temporaneo del",
        "progetto. Viene accreditato da",
        "task, bonus referral, regali,",
        "lotteries e altre meccaniche",
        "interne di gioco. Non può",
        "essere prelevato direttamente.",
      ),
      keywords: [
        "saldo bonus",
        "bonus",
      ],
    },
    "7.1-2": {
      question: j(
        "Che cos'è il saldo principale?",
      ),
      answer: j(
        "Il saldo principale contiene i",
        "principali EFHC. È qui che si",
        "trasforma il risultato del",
        "ciclo di gioco ed è da qui che",
        "il prelievo è disponibile.",
      ),
      keywords: [
        "saldo principale",
        "main",
      ],
    },
    "7.1-3": {
      question: j(
        "Qual è la differenza tra saldo",
        "bonus e saldo principale?",
      ),
      answer: j(
        "Il saldo bonus serve alla vita",
        "interna del gioco. Il saldo",
        "principale è il risultato del",
        "percorso di gioco che ha già",
        "attraversato generazione e",
        "conversione.",
      ),
      keywords: [
        "bonus vs main",
        "differenza",
      ],
    },
    "7.2-1": {
      question: j(
        "Si può prelevare direttamente",
        "il saldo bonus?",
      ),
      answer: j(
        "No. Il saldo bonus non può",
        "essere prelevato direttamente.",
        "Deve passare l'intero ciclo",
        "interno del gioco.",
      ),
      keywords: [
        "prelevare bonus",
        "withdraw bonus",
      ],
    },
    "7.2-2": {
      question: j(
        "Quale percorso completo segue",
        "il saldo bonus?",
      ),
      answer: j(
        "Il percorso è questo: le",
        "monete bonus vengono usate per",
        "comprare un pannello, il",
        "pannello inizia a generare",
        "energia, l'energia accumulata",
        "si trasforma in kWh e poi",
        "viene convertita in EFHC",
        "principali. Solo dopo compare",
        "il risultato nel saldo",
        "principale.",
      ),
      keywords: [
        "ciclo completo",
        "pannello",
        "kwh",
      ],
    },
    "7.2-3": {
      question: j(
        "Come si trasforma il saldo",
        "bonus in EFHC principali?",
      ),
      answer: j(
        "Il saldo bonus è la risorsa di",
        "partenza del processo di",
        "gioco. Attraverso l'acquisto",
        "del pannello, la generazione",
        "di energia e la conversione si",
        "trasforma in EFHC principali.",
      ),
      keywords: [
        "bonus in main",
        "conversione",
      ],
    },
    "7.2-4": {
      question: j(
        "In quale ordine vengono",
        "scalati i fondi nelle spese",
        "interne?",
      ),
      answer: j(
        "In tutte le spese interne del",
        "progetto i fondi vengono",
        "scalati prima dal saldo bonus",
        "e poi dal saldo principale.",
      ),
      keywords: [
        "ordine spesa",
        "bonus poi main",
      ],
    },
    "7.2-5": {
      question: j(
        "Che differenza c'è, in parole",
        "semplici, tra saldo totale,",
        "saldo bonus e saldo",
        "principale?",
      ),
      answer: j(
        "Il saldo totale è tutto",
        "insieme per capire la forza di",
        "acquisto complessiva. Il saldo",
        "bonus è l'energia interna per",
        "avviare il ciclo di gioco. Il",
        "saldo principale è il",
        "risultato che può essere usato",
        "come valore principale e",
        "prelevato secondo le regole.",
      ),
      keywords: [
        "saldo totale",
        "semplice",
      ],
    },
    "14.1-1": {
      question: j(
        "Come funziona Exchange?",
      ),
      answer: j(
        "Exchange converte l'energia",
        "accumulata in EFHC principali",
        "secondo il corso fisso del",
        "progetto: 1 kWh = 1 EFHC.",
      ),
      keywords: [
        "exchange",
        "1 kwh 1 efhc",
      ],
    },
    "14.1-2": {
      question: j(
        "Perché serve Exchange se",
        "l'energia è già stata generata?",
      ),
      answer: j(
        "La generazione da sola crea il",
        "risultato energetico. Exchange",
        "serve per trasformare quel",
        "risultato in EFHC principali.",
      ),
      keywords: [
        "perché exchange",
        "conversione",
      ],
    },
    "14.1-3": {
      question: j(
        "Perché su Exchange si mostra il",
        "saldo principale e non quello",
        "totale?",
      ),
      answer: j(
        "Perché Exchange è legato al",
        "valore principale e al saldo",
        "che conta proprio per questa",
        "operazione.",
      ),
      keywords: [
        "exchange",
        "saldo principale",
      ],
    },
    "14.2-1": {
      question: j(
        "Come avviene il prelievo?",
      ),
      answer: j(
        "Si crea una richiesta di",
        "prelievo e poi essa viene",
        "elaborata il più rapidamente",
        "possibile dal primo operatore",
        "disponibile.",
      ),
      keywords: [
        "prelievo",
        "richiesta",
      ],
    },
    "14.2-2": {
      question: j(
        "Da quale saldo si può fare il",
        "prelievo?",
      ),
      answer: j(
        "Il prelievo è disponibile solo",
        "dal saldo principale.",
      ),
      keywords: [
        "prelievo main",
        "solo principale",
      ],
    },
    "14.2-3": {
      question: j(
        "Perché il prelievo è",
        "disponibile solo dal saldo",
        "principale?",
      ),
      answer: j(
        "Perché il saldo principale è",
        "ciò che appartiene già al",
        "giocatore come risultato del",
        "processo di gioco o come",
        "monete acquistate. Le monete",
        "bonus partecipano al processo",
        "interno del gioco e non sono",
        "un risultato diretto per il",
        "prelievo.",
      ),
      keywords: [
        "perché solo principale",
        "bonus non prelevabile",
      ],
    },
    "14.2-4": {
      question: j(
        "Qual è il prelievo minimo?",
      ),
      answer: j(
        "L'importo minimo di prelievo",
        "è 10 EFHC.",
      ),
      keywords: [
        "prelievo minimo",
        "10 efhc",
      ],
    },
  },
  pl: {
    "5.1-1": {
      question: j(
        "Czym jest sekcja",
        "Profil / Ustawienia?",
      ),
      answer: j(
        "Profil / Ustawienia to sekcja,",
        "w której użytkownik zarządza",
        "profilem i parametrami bota.",
        "Widać tu główne statusy oraz",
        "osobiste ustawienia interfejsu.",
      ),
      keywords: [
        "profil",
        "ustawienia",
      ],
    },
    "5.1-2": {
      question: j(
        "Co jest pokazane w górnej",
        "części Profilu / Ustawień?",
      ),
      answer: j(
        "W górnej części widać awatar,",
        "nazwę Telegram oraz statusy",
        "Activ i VIP, jeśli są już",
        "dostępne.",
      ),
      keywords: [
        "awatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: j(
        "Co można skonfigurować w",
        "Profilu / Ustawieniach?",
      ),
      answer: j(
        "Krótko: język bota, wygląd,",
        "dźwięk, wibracje,",
        "powiadomienia, potwierdzenia",
        "działań i inne preferencje",
        "interfejsu.",
      ),
      keywords: [
        "język",
        "wygląd",
        "powiadomienia",
      ],
    },
    "5.1-4": {
      question: j(
        "Co znajduje się w sekcji",
        "Wsparcie i informacje?",
      ),
      answer: j(
        "W tej sekcji znajdują się",
        "pomoc, odpowiedzi na częste",
        "pytania, zasady projektu i",
        "inne materiały informacyjne.",
      ),
      keywords: [
        "wsparcie",
        "pomoc",
        "zasady",
      ],
    },
    "6.1-1": {
      question: j(
        "Czym jest sekcja Wallet w",
        "Profilu / Ustawieniach?",
      ),
      answer: j(
        "W sekcji Wallet można podłączyć",
        "jeden lub kilka portfeli i",
        "wybrać portfel główny.",
      ),
      keywords: [
        "wallet",
        "główny portfel",
      ],
    },
    "6.1-2": {
      question: j(
        "Po co potrzebny jest główny",
        "portfel?",
      ),
      answer: j(
        "Główny portfel jest używany tam,",
        "gdzie zasady projektu wymagają",
        "podłączonego portfela dla",
        "funkcji i operacji.",
      ),
      keywords: [
        "główny",
        "podłączony portfel",
      ],
    },
    "6.1-3": {
      question: j(
        "Czy można zmienić główny",
        "portfel?",
      ),
      answer: j(
        "Tak. Można wybrać inny główny",
        "portfel spośród już",
        "podłączonych.",
      ),
      keywords: [
        "zmiana portfela",
        "główny",
      ],
    },
    "6.1-4": {
      question: j(
        "Czy można usunąć podłączony",
        "portfel?",
      ),
      answer: j(
        "Tak. Jeśli portfel nie jest już",
        "potrzebny, jego powiązanie",
        "można usunąć.",
      ),
      keywords: [
        "usuń portfel",
        "odłącz",
      ],
    },
    "6.1-5": {
      question: j(
        "Co się stanie, jeśli użytkownik",
        "naciśnie przycisk wymagający",
        "portfela?",
      ),
      answer: j(
        "Jeśli wybrana funkcja wymaga",
        "portfela, naciśnięcie takiego",
        "przycisku automatycznie uruchomi",
        "proces podłączania portfela.",
      ),
      keywords: [
        "wymagany portfel",
        "podłącz portfel",
      ],
    },
    "6.1-6": {
      question: j(
        "Czy VIP NFT aktywuje się",
        "automatycznie po pojawieniu się",
        "w portfelu?",
      ),
      answer: j(
        "Tak. Logika VIP opiera się na",
        "obecności NFT w podłączonym",
        "portfelu: bot automatycznie",
        "sprawdza portfel i aktualizuje",
        "status VIP.",
      ),
      keywords: [
        "vip nft",
        "automatyczna aktywacja",
      ],
    },
    "6.1-7": {
      question: j(
        "Czy trzeba ręcznie włączać VIP",
        "po otrzymaniu NFT?",
      ),
      answer: j(
        "Nie. Logika projektu zakłada",
        "automatyczne sprawdzanie",
        "portfela i automatyczną",
        "aktualizację statusu VIP po",
        "wykryciu NFT w wymaganej",
        "kolekcji.",
      ),
      keywords: [
        "ręczny vip",
        "automatyczne sprawdzenie",
      ],
    },
    "6.1-8": {
      question: j(
        "Czy jeden VIP NFT daje efekt, a",
        "drugi i trzeci już nie?",
      ),
      answer: j(
        "Tak. Dla gracza wystarczy",
        "posiadać co najmniej jeden EFHC",
        "VIP NFT. Drugi i trzeci NFT nie",
        "dają dodatkowego wzmocnienia",
        "generacji.",
      ),
      keywords: [
        "jeden nft",
        "efekt vip",
      ],
    },
    "7.1-1": {
      question: j(
        "Czym jest saldo bonusowe?",
      ),
      answer: j(
        "Saldo bonusowe to tymczasowe",
        "wewnętrzne saldo projektu. Jest",
        "naliczane za zadania, bonusy",
        "referral, prezenty, lotteries i",
        "inne wewnętrzne mechaniki gry.",
        "Nie można go wypłacić bezpośrednio.",
      ),
      keywords: [
        "saldo bonusowe",
        "bonus",
      ],
    },
    "7.1-2": {
      question: j(
        "Czym jest saldo główne?",
      ),
      answer: j(
        "Saldo główne to główne EFHC. To",
        "w nie zamienia się wynik cyklu",
        "gry i właśnie z niego dostępna",
        "jest wypłata.",
      ),
      keywords: [
        "saldo główne",
        "main",
      ],
    },
    "7.1-3": {
      question: j(
        "Jaka jest różnica między saldem",
        "bonusowym a głównym?",
      ),
      answer: j(
        "Saldo bonusowe służy do",
        "wewnętrznego życia gry. Saldo",
        "główne jest wynikiem ścieżki",
        "gry, która przeszła już przez",
        "generację i konwersję.",
      ),
      keywords: [
        "bonus vs main",
        "różnica",
      ],
    },
    "7.2-1": {
      question: j(
        "Czy można wypłacić saldo",
        "bonusowe bezpośrednio?",
      ),
      answer: j(
        "Nie. Salda bonusowego nie można",
        "wypłacić bezpośrednio. Musi ono",
        "przejść pełny wewnętrzny cykl",
        "gry.",
      ),
      keywords: [
        "wypłata bonusu",
        "withdraw bonus",
      ],
    },
    "7.2-2": {
      question: j(
        "Jaką pełną drogę przechodzi",
        "saldo bonusowe?",
      ),
      answer: j(
        "Droga jest taka: monety bonusowe",
        "są używane do zakupu panelu,",
        "panel zaczyna generować energię,",
        "zgromadzona energia zamienia się",
        "w kWh, a następnie energia jest",
        "konwertowana na główne EFHC.",
        "Dopiero potem wynik pojawia się",
        "na saldzie głównym.",
      ),
      keywords: [
        "pełny cykl",
        "panel",
        "kwh",
      ],
    },
    "7.2-3": {
      question: j(
        "Jak saldo bonusowe zamienia się",
        "w główne EFHC?",
      ),
      answer: j(
        "Saldo bonusowe jest zasobem",
        "startowym procesu gry.",
        "Poprzez zakup panelu, generację",
        "energii i konwersję przechodzi",
        "w główne EFHC.",
      ),
      keywords: [
        "bonus na main",
        "konwersja",
      ],
    },
    "7.2-4": {
      question: j(
        "W jakiej kolejności pobierane są",
        "środki przy wydatkach",
        "wewnętrznych?",
      ),
      answer: j(
        "We wszystkich wewnętrznych",
        "wydatkach projektu środki są",
        "pobierane najpierw z salda",
        "bonusowego, a dopiero potem z",
        "głównego.",
      ),
      keywords: [
        "kolejność wydatków",
        "bonus potem main",
      ],
    },
    "7.2-5": {
      question: j(
        "Jaka jest prosta różnica między",
        "saldem całkowitym, bonusowym i",
        "głównym?",
      ),
      answer: j(
        "Saldo całkowite to wszystko",
        "razem dla zrozumienia ogólnej",
        "siły zakupowej. Saldo bonusowe",
        "to wewnętrzna energia do",
        "uruchomienia cyklu gry. Saldo",
        "główne to wynik, którego można",
        "używać jako głównej wartości i",
        "wypłacać zgodnie z zasadami.",
      ),
      keywords: [
        "saldo całkowite",
        "prosto",
      ],
    },
    "14.1-1": {
      question: j(
        "Jak działa Exchange?",
      ),
      answer: j(
        "Exchange konwertuje zgromadzoną",
        "energię na główne EFHC według",
        "stałego kursu projektu: 1 kWh =",
        "1 EFHC.",
      ),
      keywords: [
        "exchange",
        "1 kwh 1 efhc",
      ],
    },
    "14.1-2": {
      question: j(
        "Dlaczego Exchange jest potrzebny,",
        "skoro energia została już",
        "wygenerowana?",
      ),
      answer: j(
        "Sama generacja tworzy wynik",
        "energetyczny. Exchange jest",
        "potrzebny, aby zamienić ten",
        "wynik na główne EFHC.",
      ),
      keywords: [
        "dlaczego exchange",
        "konwersja",
      ],
    },
    "14.1-3": {
      question: j(
        "Dlaczego na Exchange pokazywane",
        "jest saldo główne, a nie",
        "całkowite?",
      ),
      answer: j(
        "Ponieważ Exchange jest związany",
        "z główną wartością i z tym",
        "saldem, które ma znaczenie",
        "właśnie dla tej operacji.",
      ),
      keywords: [
        "exchange",
        "saldo główne",
      ],
    },
    "14.2-1": {
      question: j(
        "Jak przebiega wypłata?",
      ),
      answer: j(
        "Tworzony jest wniosek o",
        "wypłatę, a następnie jest on",
        "przetwarzany możliwie szybko",
        "przez pierwszego wolnego",
        "operatora.",
      ),
      keywords: [
        "wypłata",
        "wniosek",
      ],
    },
    "14.2-2": {
      question: j(
        "Z którego salda można zrobić",
        "wypłatę?",
      ),
      answer: j(
        "Wypłata jest dostępna tylko z",
        "salda głównego.",
      ),
      keywords: [
        "wypłata main",
        "tylko główne",
      ],
    },
    "14.2-3": {
      question: j(
        "Dlaczego wypłata jest dostępna",
        "tylko z salda głównego?",
      ),
      answer: j(
        "Ponieważ saldo główne to to, co",
        "już należy do gracza jako wynik",
        "procesu gry lub kupione monety.",
        "Monety bonusowe uczestniczą w",
        "wewnętrznym procesie gry i nie",
        "są bezpośrednim wynikiem do",
        "wypłaty.",
      ),
      keywords: [
        "dlaczego tylko główne",
        "bonus nie do wypłaty",
      ],
    },
    "14.2-4": {
      question: j(
        "Jaka jest minimalna wypłata?",
      ),
      answer: j(
        "Minimalna kwota wypłaty to",
        "10 EFHC.",
      ),
      keywords: [
        "minimalna wypłata",
        "10 efhc",
      ],
    },
  },
  tr: {
    "5.1-1": {
      question: j(
        "Profil / Ayarlar bölümü",
        "nedir?",
      ),
      answer: j(
        "Profil / Ayarlar, kullanıcının",
        "profili ve bot ayarlarını",
        "yönettiği bölümdür. Burada ana",
        "durumlar ve kişisel arayüz",
        "ayarları görünür.",
      ),
      keywords: [
        "profil",
        "ayarlar",
      ],
    },
    "5.1-2": {
      question: j(
        "Profil / Ayarlar bölümünün üst",
        "kısmında ne gösterilir?",
      ),
      answer: j(
        "Üst kısımda avatar, Telegram",
        "adı ve varsa Activ ile VIP",
        "durumları gösterilir.",
      ),
      keywords: [
        "avatar",
        "telegram",
        "vip",
      ],
    },
    "5.1-3": {
      question: j(
        "Profil / Ayarlar içinde neler",
        "ayarlanabilir?",
      ),
      answer: j(
        "Kısaca: bot dili, görünüm, ses,",
        "titreşim, bildirimler, işlem",
        "onayları ve diğer arayüz",
        "tercihleri.",
      ),
      keywords: [
        "dil",
        "görünüm",
        "bildirimler",
      ],
    },
    "5.1-4": {
      question: j(
        "Destek ve Bilgi bölümünde ne",
        "bulunur?",
      ),
      answer: j(
        "Bu bölümde yardım, sık sorulan",
        "soruların cevapları, proje",
        "kuralları ve diğer bilgi",
        "materyalleri bulunur.",
      ),
      keywords: [
        "destek",
        "yardım",
        "kurallar",
      ],
    },
    "6.1-1": {
      question: j(
        "Profil / Ayarlar içindeki",
        "Wallet bölümü nedir?",
      ),
      answer: j(
        "Wallet bölümünde bir veya daha",
        "fazla cüzdan bağlanabilir ve ana",
        "cüzdan seçilebilir.",
      ),
      keywords: [
        "wallet",
        "ana cüzdan",
      ],
    },
    "6.1-2": {
      question: j(
        "Ana cüzdan neden gereklidir?",
      ),
      answer: j(
        "Ana cüzdan, proje kurallarının",
        "işlevler ve işlemler için bağlı",
        "bir cüzdan istediği yerlerde",
        "kullanılır.",
      ),
      keywords: [
        "ana",
        "bağlı cüzdan",
      ],
    },
    "6.1-3": {
      question: j(
        "Ana cüzdan değiştirilebilir mi?",
      ),
      answer: j(
        "Evet. Zaten bağlı olan",
        "cüzdanlar arasından başka bir",
        "ana cüzdan seçilebilir.",
      ),
      keywords: [
        "cüzdan değiştir",
        "ana",
      ],
    },
    "6.1-4": {
      question: j(
        "Bağlı bir cüzdan kaldırılabilir",
        "mi?",
      ),
      answer: j(
        "Evet. Bir cüzdana artık ihtiyaç",
        "yoksa bağlantısı kaldırılabilir.",
      ),
      keywords: [
        "cüzdan kaldır",
        "bağlantıyı kes",
      ],
    },
    "6.1-5": {
      question: j(
        "Kullanıcı cüzdan gerektiren bir",
        "düğmeye basarsa ne olur?",
      ),
      answer: j(
        "Seçilen işlev bir cüzdan",
        "gerektiriyorsa, o düğmeye",
        "basıldığında cüzdan bağlama",
        "akışı otomatik olarak başlar.",
      ),
      keywords: [
        "cüzdan gerekli",
        "cüzdan bağla",
      ],
    },
    "6.1-6": {
      question: j(
        "VIP NFT cüzdana geldikten sonra",
        "otomatik olarak etkinleşir mi?",
      ),
      answer: j(
        "Evet. VIP mantığı, NFT'nin",
        "bağlı cüzdanda bulunmasına",
        "dayanır: bot cüzdanı otomatik",
        "olarak kontrol eder ve VIP",
        "durumunu günceller.",
      ),
      keywords: [
        "vip nft",
        "otomatik etkinleşme",
      ],
    },
    "6.1-7": {
      question: j(
        "NFT alındıktan sonra VIP'yi",
        "elle açmak gerekir mi?",
      ),
      answer: j(
        "Hayır. Proje mantığı, gerekli",
        "koleksiyonda NFT bulunduğunda",
        "otomatik cüzdan kontrolü ve",
        "otomatik VIP durum güncellemesi",
        "için tasarlanmıştır.",
      ),
      keywords: [
        "manuel vip",
        "otomatik kontrol",
      ],
    },
    "6.1-8": {
      question: j(
        "Bir VIP NFT etki verir de ikinci",
        "ve üçüncü NFT ek katkı sağlamaz",
        "mı?",
      ),
      answer: j(
        "Evet. Oyuncu için en az bir EFHC",
        "VIP NFT yeterlidir. İkinci ve",
        "üçüncü NFT ek üretim artışı",
        "sağlamaz.",
      ),
      keywords: [
        "bir nft",
        "vip etkisi",
      ],
    },
    "7.1-1": {
      question: j(
        "Bonus bakiye nedir?",
      ),
      answer: j(
        "Bonus bakiye, projenin geçici",
        "iç bakiyesidir. Görevler,",
        "referral bonusları, hediyeler,",
        "lotteries ve diğer iç oyun",
        "mekaniklerinden gelir. Doğrudan",
        "çekilemez.",
      ),
      keywords: [
        "bonus bakiye",
        "bonus",
      ],
    },
    "7.1-2": {
      question: j(
        "Ana bakiye nedir?",
      ),
      answer: j(
        "Ana bakiye, ana EFHC'dir. Oyun",
        "döngüsünün sonucu buraya",
        "dönüşür ve çekim de buradan",
        "yapılır.",
      ),
      keywords: [
        "ana bakiye",
        "main",
      ],
    },
    "7.1-3": {
      question: j(
        "Bonus bakiye ile ana bakiye",
        "arasındaki fark nedir?",
      ),
      answer: j(
        "Bonus bakiye oyunun iç yaşamı",
        "için gerekir. Ana bakiye ise",
        "üretim ve dönüşümden geçmiş",
        "oyun yolunun sonucudur.",
      ),
      keywords: [
        "bonus vs main",
        "fark",
      ],
    },
    "7.2-1": {
      question: j(
        "Bonus bakiye doğrudan çekilebilir",
        "mi?",
      ),
      answer: j(
        "Hayır. Bonus bakiye doğrudan",
        "çekilemez. Tam iç oyun",
        "döngüsünden geçmelidir.",
      ),
      keywords: [
        "bonus çekimi",
        "withdraw bonus",
      ],
    },
    "7.2-2": {
      question: j(
        "Bonus bakiye hangi tam yolu",
        "izler?",
      ),
      answer: j(
        "Yol şöyledir: bonus paralar bir",
        "panel satın almak için",
        "kullanılır, panel enerji",
        "üretmeye başlar, biriken enerji",
        "kWh'ye dönüşür ve ardından ana",
        "EFHC'ye çevrilir. Ancak bundan",
        "sonra sonuç ana bakiyede",
        "görünür.",
      ),
      keywords: [
        "tam döngü",
        "panel",
        "kwh",
      ],
    },
    "7.2-3": {
      question: j(
        "Bonus bakiye nasıl ana EFHC'ye",
        "dönüşür?",
      ),
      answer: j(
        "Bonus bakiye, oyun sürecinin",
        "başlangıç kaynağıdır. Panel",
        "satın alma, enerji üretimi ve",
        "dönüşüm yoluyla ana EFHC'ye",
        "döner.",
      ),
      keywords: [
        "bonus ana",
        "dönüşüm",
      ],
    },
    "7.2-4": {
      question: j(
        "İç harcamalarda fonlar hangi",
        "sırayla düşülür?",
      ),
      answer: j(
        "Projedeki tüm iç harcamalarda",
        "fonlar önce bonus bakiyeden,",
        "sonra ana bakiyeden düşülür.",
      ),
      keywords: [
        "harcama sırası",
        "önce bonus sonra main",
      ],
    },
    "7.2-5": {
      question: j(
        "Toplam bakiye, bonus bakiye ve",
        "ana bakiye arasındaki fark basit",
        "bir dille nedir?",
      ),
      answer: j(
        "Toplam bakiye, genel satın alma",
        "gücünü anlamak için her şeyin",
        "toplamıdır. Bonus bakiye, oyun",
        "döngüsünü başlatan iç oyun",
        "enerjisidir. Ana bakiye ise ana",
        "değer olarak kullanılabilen ve",
        "kurallara göre çekilebilen",
        "sonuçtur.",
      ),
      keywords: [
        "toplam bakiye",
        "basit",
      ],
    },
    "14.1-1": {
      question: j(
        "Exchange nasıl çalışır?",
      ),
      answer: j(
        "Exchange, birikmiş enerjiyi",
        "projenin sabit kuruna göre ana",
        "EFHC'ye çevirir: 1 kWh =",
        "1 EFHC.",
      ),
      keywords: [
        "exchange",
        "1 kwh 1 efhc",
      ],
    },
    "14.1-2": {
      question: j(
        "Enerji zaten üretildiyse neden",
        "Exchange gerekir?",
      ),
      answer: j(
        "Üretim tek başına enerji",
        "sonucunu oluşturur. Exchange bu",
        "sonucu ana EFHC'ye çevirmek",
        "için gerekir.",
      ),
      keywords: [
        "neden exchange",
        "dönüşüm",
      ],
    },
    "14.1-3": {
      question: j(
        "Exchange sayfasında neden toplam",
        "bakiye değil ana bakiye",
        "gösterilir?",
      ),
      answer: j(
        "Çünkü Exchange, ana değerle ve",
        "özellikle bu işlem için önemli",
        "olan bakiyeyle ilgilidir.",
      ),
      keywords: [
        "exchange",
        "ana bakiye",
      ],
    },
    "14.2-1": {
      question: j(
        "Çekim nasıl yapılır?",
      ),
      answer: j(
        "Bir çekim talebi oluşturulur ve",
        "ardından ilk müsait operatör",
        "tarafından mümkün olduğunca hızlı",
        "şekilde işlenir.",
      ),
      keywords: [
        "çekim",
        "talep",
      ],
    },
    "14.2-2": {
      question: j(
        "Çekim hangi bakiyeden",
        "yapılabilir?",
      ),
      answer: j(
        "Çekim yalnızca ana bakiyeden",
        "yapılabilir.",
      ),
      keywords: [
        "çekim main",
        "yalnızca ana",
      ],
    },
    "14.2-3": {
      question: j(
        "Çekim neden yalnızca ana",
        "bakiyeden yapılabilir?",
      ),
      answer: j(
        "Çünkü ana bakiye, oyuncuya oyun",
        "sürecinin sonucu veya satın",
        "alınmış paralar olarak zaten ait",
        "olan şeydir. Bonus paralar iç",
        "oyun sürecine katılır ve çekim",
        "için doğrudan sonuç değildir.",
      ),
      keywords: [
        "neden yalnızca ana",
        "bonus çekilemez",
      ],
    },
    "14.2-4": {
      question: j(
        "Minimum çekim nedir?",
      ),
      answer: j(
        "Minimum çekim tutarı 10 EFHC'dir.",
      ),
      keywords: [
        "minimum çekim",
        "10 efhc",
      ],
    },
  },
  da: {
    "5.1-1": {
      question: j(
        "Hvad er",
        "afsnittet Profil /",
        "Indstillinger?",
      ),
      answer: j(
        "Profil / Indstillinger er",
        "stedet, hvor brugeren",
        "styrer profilen og",
        "botens indstillinger.",
        "Her vises vigtige",
        "statusser og personlige",
        "interfacevalg.",
      ),
      keywords: ["profil", "indstillinger"],
    },
    "5.1-2": {
      question: j(
        "Hvad vises øverst i",
        "Profil / Indstillinger?",
      ),
      answer: j(
        "Øverst vises avatar,",
        "Telegram-navn samt",
        "Activ- og VIP-status,",
        "hvis de allerede er",
        "tilgængelige.",
      ),
      keywords: ["avatar", "telegram", "vip"],
    },
    "5.1-3": {
      question: j(
        "Hvad kan indstilles i",
        "Profil / Indstillinger?",
      ),
      answer: j(
        "Kort sagt: botsprog,",
        "udseende, lyd,",
        "vibration, notifikationer,",
        "bekræftelser af handlinger",
        "og andre præferencer for",
        "grænsefladen.",
      ),
      keywords: ["sprog", "udseende", "notifikationer"],
    },
    "5.1-4": {
      question: j(
        "Hvad findes i Support og",
        "Information?",
      ),
      answer: j(
        "Denne blok indeholder",
        "hjælp, svar på ofte",
        "stillede spørgsmål,",
        "projektregler og andet",
        "informationsmateriale.",
      ),
      keywords: ["support", "hjælp", "regler"],
    },
    "6.1-1": {
      question: j(
        "Hvad er Wallet-afsnittet",
        "i Profil /",
        "Indstillinger?",
      ),
      answer: j(
        "I Wallet-afsnittet kan",
        "brugeren tilknytte en",
        "eller flere wallets og",
        "vælge en primær wallet.",
      ),
      keywords: ["wallet", "primær wallet"],
    },
    "6.1-2": {
      question: j(
        "Hvorfor er den primære",
        "wallet nødvendig?",
      ),
      answer: j(
        "Den primære wallet",
        "bruges dér, hvor",
        "projektets regler kræver",
        "en tilknyttet wallet til",
        "funktioner og operationer.",
      ),
      keywords: ["primær", "tilknyttet wallet"],
    },
    "6.1-3": {
      question: j(
        "Kan den primære wallet",
        "ændres?",
      ),
      answer: j(
        "Ja. En anden primær",
        "wallet kan vælges blandt",
        "de wallets, der allerede",
        "er tilknyttet.",
      ),
      keywords: ["ændre wallet", "primær"],
    },
    "6.1-4": {
      question: j(
        "Kan en tilknyttet wallet",
        "fjernes?",
      ),
      answer: j(
        "Ja. Hvis en wallet ikke",
        "længere er nødvendig, kan",
        "dens tilknytning fjernes.",
      ),
      keywords: ["fjern wallet", "frakobl"],
    },
    "6.1-5": {
      question: j(
        "Hvad sker der, hvis",
        "brugeren trykker på en",
        "knap, der kræver en",
        "wallet?",
      ),
      answer: j(
        "Hvis den valgte funktion",
        "kræver en wallet, starter",
        "tilknytningsforløbet",
        "automatisk, når brugeren",
        "trykker på knappen.",
      ),
      keywords: ["wallet kræves", "tilknyt wallet"],
    },
    "6.1-6": {
      question: j(
        "Aktiveres VIP NFT",
        "automatisk, når den",
        "modtages i wallet?",
      ),
      answer: j(
        "Ja. VIP-logikken bygger",
        "på, at NFT'en findes i en",
        "tilknyttet wallet: botten",
        "tjekker automatisk",
        "walleten og opdaterer",
        "VIP-status.",
      ),
      keywords: ["vip nft", "automatisk aktivering"],
    },
    "6.1-7": {
      question: j(
        "Skal brugeren aktivere",
        "VIP manuelt efter at have",
        "modtaget NFT?",
      ),
      answer: j(
        "Nej. Projektets logik er",
        "bygget til automatisk",
        "wallet-kontrol og",
        "automatisk opdatering af",
        "VIP-status, når NFT'en",
        "findes i den krævede",
        "samling.",
      ),
      keywords: ["manuel vip", "automatisk kontrol"],
    },
    "6.1-8": {
      question: j(
        "Giver én VIP NFT effekten,",
        "mens nummer to og tre",
        "ikke gør det?",
      ),
      answer: j(
        "Ja. For spilleren er det",
        "nok at have mindst én",
        "EFHC VIP NFT. Den anden og",
        "tredje NFT giver ikke",
        "ekstra boost til",
        "generering.",
      ),
      keywords: ["én nft", "vip-effekt"],
    },
    "7.1-1": {
      question: j("Hvad er bonusbalancen?"),
      answer: j(
        "Bonusbalancen er en",
        "midlertidig intern balance",
        "i projektet. Den fyldes op",
        "fra opgaver, henvisnings-",
        "bonusser, gaver,",
        "Lotteries og andre interne",
        "spilmekanikker. Den kan",
        "ikke hæves direkte.",
      ),
      keywords: ["bonusbalance", "intern"],
    },
    "7.1-2": {
      question: j("Hvad er hovedbalancen?"),
      answer: j(
        "Hovedbalancen indeholder",
        "de centrale EFHC-mønter.",
        "Det er resultatet af",
        "spilcyklussen, og hævning",
        "er tilgængelig fra den.",
      ),
      keywords: ["hovedbalance", "hævning"],
    },
    "7.1-3": {
      question: j(
        "Hvad er forskellen mellem",
        "bonus- og hovedbalancen?",
      ),
      answer: j(
        "Bonusbalancen bruges til",
        "spillets interne liv.",
        "Hovedbalancen er",
        "resultatet af den vej, som",
        "allerede har passeret",
        "energigenerering og",
        "konvertering.",
      ),
      keywords: ["forskel", "bonus", "hoved"],
    },
    "7.2-1": {
      question: j(
        "Kan bonusbalancen hæves",
        "direkte?",
      ),
      answer: j(
        "Nej. Bonusbalancen kan",
        "ikke hæves direkte. Den",
        "skal gennem hele den",
        "interne spilcyklus.",
      ),
      keywords: ["hæv bonus", "direkte hævning"],
    },
    "7.2-2": {
      question: j(
        "Hvilken fuld vej går",
        "bonusbalancen igennem?",
      ),
      answer: j(
        "Den fulde vej er sådan:",
        "bonusmønter bruges til at",
        "købe et panel, panelet",
        "begynder at generere",
        "energi, den opsamlede",
        "energi omdannes til kWh, og",
        "derefter bliver energien",
        "til EFHC main. Først derefter",
        "vises resultatet på",
        "hovedbalancen.",
      ),
      keywords: ["cyklus", "panel", "kwh"],
    },
    "7.2-3": {
      question: j(
        "Hvordan bliver",
        "bonusbalancen til EFHC",
        "main?",
      ),
      answer: j(
        "Bonusbalancen er start-",
        "ressourcen for spillet.",
        "Gennem køb af panel,",
        "energigenerering og",
        "konvertering bliver den til",
        "EFHC main.",
      ),
      keywords: ["konverter", "efhc main"],
    },
    "7.2-4": {
      question: j(
        "I hvilken rækkefølge bruges",
        "midler ved interne",
        "udgifter?",
      ),
      answer: j(
        "Ved alle interne udgifter i",
        "projektet bruges midler",
        "først fra bonusbalancen og",
        "derefter fra",
        "hovedbalancen.",
      ),
      keywords: ["forbrugsrækkefølge", "bonus først"],
    },
    "7.2-5": {
      question: j(
        "Hvad er den simple",
        "forskel mellem samlet,",
        "bonus og hovedbalance?",
      ),
      answer: j(
        "Den samlede balance er alt",
        "tilsammen for at forstå den",
        "samlede købekraft.",
        "Bonusbalancen er intern",
        "spilenergi, som starter",
        "spilcyklussen. Hovedbalancen",
        "er slutresultatet, som kan",
        "bruges som hovedværdi og",
        "hæves efter projektets",
        "regler.",
      ),
      keywords: ["samlet balance", "simpel forklaring"],
    },
    "14.1-1": {
      question: j(
        "Hvordan fungerer",
        "energiudveksling til EFHC?",
      ),
      answer: j(
        "Exchange er omdannelsen af",
        "fremskridt til EFHC main.",
        "Den opsamlede energi bliver",
        "til projektets hovedmønter.",
      ),
      keywords: ["exchange", "energi"],
    },
    "14.1-2": {
      question: j(
        "Hvad betyder reglen 1 kWh =",
        "1 EFHC?",
      ),
      answer: j(
        "Det er projektets faste",
        "interne kurs. Hver enhed",
        "energi omdannes til samme",
        "mængde EFHC.",
      ),
      keywords: ["1 kwh 1 efhc", "kurs"],
    },
    "14.1-3": {
      question: j(
        "Hvorfor viser Exchange-",
        "siden EFHC main i stedet for",
        "den samlede balance?",
      ),
      answer: j(
        "Fordi exchange er knyttet",
        "til hovedværdien og til den",
        "balance, der er relevant for",
        "denne specifikke",
        "handling.",
      ),
      keywords: ["exchange-side", "hovedbalance"],
    },
    "14.2-1": {
      question: j("Hvordan fungerer hævning?"),
      answer: j(
        "En hæveanmodning sendes og",
        "behandles derefter så",
        "hurtigt som muligt af den",
        "første tilgængelige",
        "operatør.",
      ),
      keywords: ["hævning", "anmodning"],
    },
    "14.2-2": {
      question: j(
        "Hvilken balance kan bruges",
        "til hævning?",
      ),
      answer: j(
        "Hævning er kun tilgængelig",
        "fra hovedbalancen.",
      ),
      keywords: ["hæv fra main", "kun main"],
    },
    "14.2-3": {
      question: j(
        "Hvorfor er hævning kun",
        "tilgængelig fra",
        "hovedbalancen?",
      ),
      answer: j(
        "Fordi hovedbalancen allerede",
        "tilhører spilleren som",
        "resultat af spilprocessen",
        "eller købte mønter.",
        "Bonusmønter deltager i den",
        "interne spilproces og kan",
        "ikke hæves direkte.",
      ),
      keywords: ["hvorfor kun main", "bonus kan ikke hæves"],
    },
    "14.2-4": {
      question: j("Hvad er minimumshævningen?"),
      answer: j(
        "Minimumsbeløbet for hævning",
        "er 10 EFHC.",
      ),
      keywords: ["minimumshævning", "10 efhc"],
    },
  },
  hi: {
    "5.1-1": {
      question: j(
        "प्रोफ़ाइल / सेटिंग्स",
        "सेक्शन क्या है?",
      ),
      answer: j(
        "प्रोफ़ाइल / सेटिंग्स वह",
        "जगह है जहाँ उपयोगकर्ता",
        "अपनी प्रोफ़ाइल और बॉट की",
        "सेटिंग्स संभालता है। यहाँ",
        "मुख्य स्टेटस और व्यक्तिगत",
        "इंटरफ़ेस विकल्प दिखते हैं।",
      ),
      keywords: ["प्रोफ़ाइल", "सेटिंग्स"],
    },
    "5.1-2": {
      question: j(
        "प्रोफ़ाइल / सेटिंग्स के",
        "ऊपर क्या दिखता है?",
      ),
      answer: j(
        "ऊपरी हिस्से में अवतार,",
        "Telegram नाम और Activ व",
        "VIP स्टेटस दिखते हैं, यदि",
        "वे पहले से उपलब्ध हों।",
      ),
      keywords: ["अवतार", "telegram", "vip"],
    },
    "5.1-3": {
      question: j(
        "प्रोफ़ाइल / सेटिंग्स में",
        "क्या बदला जा सकता है?",
      ),
      answer: j(
        "संक्षेप में: बॉट की भाषा,",
        "दिखावट, ध्वनि, कंपन,",
        "नोटिफ़िकेशन, कार्यों की",
        "पुष्टि और दूसरे इंटरफ़ेस",
        "विकल्प।",
      ),
      keywords: ["भाषा", "दिखावट", "नोटिफ़िकेशन"],
    },
    "5.1-4": {
      question: j(
        "Support और Information",
        "ब्लॉक में क्या है?",
      ),
      answer: j(
        "इस ब्लॉक में सहायता, आम",
        "सवालों के जवाब, परियोजना",
        "के नियम और अन्य जानकारी",
        "सामग्री होती है।",
      ),
      keywords: ["support", "मदद", "नियम"],
    },
    "6.1-1": {
      question: j(
        "प्रोफ़ाइल / सेटिंग्स में",
        "Wallet सेक्शन क्या है?",
      ),
      answer: j(
        "Wallet सेक्शन में",
        "उपयोगकर्ता एक या अधिक",
        "वॉलेट जोड़ सकता है और",
        "मुख्य वॉलेट चुन सकता है।",
      ),
      keywords: ["wallet", "मुख्य wallet"],
    },
    "6.1-2": {
      question: j(
        "मुख्य wallet की ज़रूरत",
        "क्यों होती है?",
      ),
      answer: j(
        "मुख्य wallet वहाँ उपयोग",
        "होता है जहाँ परियोजना के",
        "नियमों के अनुसार किसी",
        "फंक्शन या ऑपरेशन के लिए",
        "जुड़ा हुआ wallet ज़रूरी",
        "होता है।",
      ),
      keywords: ["मुख्य", "जुड़ा wallet"],
    },
    "6.1-3": {
      question: j(
        "क्या मुख्य wallet बदला",
        "जा सकता है?",
      ),
      answer: j(
        "हाँ। पहले से जुड़े हुए",
        "wallets में से दूसरा मुख्य",
        "wallet चुना जा सकता है।",
      ),
      keywords: ["wallet बदलें", "मुख्य"],
    },
    "6.1-4": {
      question: j(
        "क्या जुड़े हुए wallet को",
        "हटाया जा सकता है?",
      ),
      answer: j(
        "हाँ। यदि wallet की अब",
        "ज़रूरत नहीं है, तो उसका",
        "लिंक हटाया जा सकता है।",
      ),
      keywords: ["wallet हटाएँ", "unlink"],
    },
    "6.1-5": {
      question: j(
        "अगर उपयोगकर्ता ऐसा बटन",
        "दबाए जिसके लिए wallet",
        "चाहिए तो क्या होगा?",
      ),
      answer: j(
        "यदि चुना गया फ़ंक्शन",
        "wallet माँगता है, तो उस",
        "बटन को दबाने पर wallet",
        "जोड़ने की प्रक्रिया अपने",
        "आप शुरू हो जाती है।",
      ),
      keywords: ["wallet required", "wallet जोड़ें"],
    },
    "6.1-6": {
      question: j(
        "क्या VIP NFT wallet में",
        "आने के बाद अपने आप",
        "सक्रिय हो जाता है?",
      ),
      answer: j(
        "हाँ। VIP लॉजिक linked",
        "wallet में NFT की मौजूदगी",
        "पर आधारित है: बॉट wallet",
        "को अपने आप जाँचता है और",
        "VIP स्टेटस अपडेट करता है।",
      ),
      keywords: ["vip nft", "automatic activation"],
    },
    "6.1-7": {
      question: j(
        "क्या NFT मिलने के बाद",
        "उपयोगकर्ता को VIP मैन्युअली",
        "चालू करना पड़ता है?",
      ),
      answer: j(
        "नहीं। परियोजना की लॉजिक",
        "अपने आप wallet जाँचने और",
        "ज़रूरी collection में NFT",
        "मिलते ही VIP स्टेटस अपडेट",
        "करने के लिए बनाई गई है।",
      ),
      keywords: ["manual vip", "automatic check"],
    },
    "6.1-8": {
      question: j(
        "क्या एक VIP NFT का प्रभाव",
        "होता है और दूसरा-तीसरा",
        "अतिरिक्त लाभ नहीं देते?",
      ),
      answer: j(
        "हाँ। खिलाड़ी के लिए कम से",
        "कम एक EFHC VIP NFT होना",
        "काफ़ी है। दूसरा और तीसरा",
        "NFT अतिरिक्त generation",
        "boost नहीं देते।",
      ),
      keywords: ["one nft", "vip effect"],
    },
    "7.1-1": {
      question: j("बोनस बैलेंस क्या है?"),
      answer: j(
        "बोनस बैलेंस परियोजना का",
        "एक अस्थायी आंतरिक बैलेंस",
        "है। यह tasks, referral",
        "bonuses, gifts, Lotteries",
        "और दूसरी आंतरिक गेम",
        "mechanics से भरता है। इसे",
        "सीधे withdraw नहीं किया",
        "जा सकता।",
      ),
      keywords: ["bonus balance", "internal"],
    },
    "7.1-2": {
      question: j("main balance क्या है?"),
      answer: j(
        "main balance में मुख्य EFHC",
        "होते हैं। यह गेम साइकिल का",
        "परिणाम है और इसी से",
        "withdrawal उपलब्ध है।",
      ),
      keywords: ["main balance", "withdraw"],
    },
    "7.1-3": {
      question: j(
        "bonus और main balance में",
        "क्या अंतर है?",
      ),
      answer: j(
        "bonus balance गेम की",
        "आंतरिक ज़िंदगी के लिए है।",
        "main balance वह परिणाम है",
        "जो energy generation और",
        "conversion से होकर आ चुका",
        "है।",
      ),
      keywords: ["difference", "bonus", "main"],
    },
    "7.2-1": {
      question: j(
        "क्या bonus balance को सीधे",
        "withdraw किया जा सकता है?",
      ),
      answer: j(
        "नहीं। bonus balance को सीधे",
        "withdraw नहीं किया जा सकता।",
        "इसे पूरा internal game",
        "cycle पार करना होता है।",
      ),
      keywords: ["withdraw bonus", "direct withdrawal"],
    },
    "7.2-2": {
      question: j(
        "bonus balance कौन-सा पूरा",
        "रास्ता तय करता है?",
      ),
      answer: j(
        "पूरा रास्ता यह है: bonus",
        "coins से panel खरीदा जाता",
        "है, panel energy generate",
        "करता है, जमा energy kWh में",
        "बदलती है, और फिर energy",
        "main EFHC में बदलती है।",
        "उसके बाद ही परिणाम main",
        "balance में आता है।",
      ),
      keywords: ["cycle", "panel", "kwh"],
    },
    "7.2-3": {
      question: j(
        "bonus balance main EFHC में",
        "कैसे बदलता है?",
      ),
      answer: j(
        "bonus balance गेम प्रक्रिया",
        "का शुरुआती संसाधन है।",
        "panel खरीद, energy",
        "generation और conversion के",
        "माध्यम से यह main EFHC में",
        "बदलता है।",
      ),
      keywords: ["convert", "main efhc"],
    },
    "7.2-4": {
      question: j(
        "आंतरिक खर्चों में धन किस",
        "क्रम में खर्च होता है?",
      ),
      answer: j(
        "परियोजना के सभी आंतरिक",
        "खर्चों में पहले bonus",
        "balance और उसके बाद main",
        "balance से धन खर्च होता",
        "है।",
      ),
      keywords: ["spending order", "bonus first"],
    },
    "7.2-5": {
      question: j(
        "कुल, bonus और main balance",
        "का सरल अंतर क्या है?",
      ),
      answer: j(
        "कुल balance सब कुछ एक साथ",
        "दिखाता है ताकि कुल buying",
        "power समझी जा सके। bonus",
        "balance internal game",
        "energy है जो cycle शुरू",
        "करती है। main balance अंतिम",
        "परिणाम है जिसे मुख्य मूल्य",
        "की तरह उपयोग किया जा सकता",
        "है और परियोजना नियमों के",
        "अनुसार withdraw किया जा",
        "सकता है।",
      ),
      keywords: ["total balance", "simple explanation"],
    },
    "14.1-1": {
      question: j(
        "energy को EFHC में exchange",
        "कैसे किया जाता है?",
      ),
      answer: j(
        "Exchange प्रगति को main EFHC",
        "में बदलने की प्रक्रिया है।",
        "जमा की गई energy परियोजना",
        "के मुख्य coins में बदलती",
        "है।",
      ),
      keywords: ["exchange", "energy"],
    },
    "14.1-2": {
      question: j(
        "1 kWh = 1 EFHC नियम का क्या",
        "मतलब है?",
      ),
      answer: j(
        "यह परियोजना की स्थिर",
        "आंतरिक दर है। energy की हर",
        "इकाई बराबर मात्रा के EFHC",
        "में बदलती है।",
      ),
      keywords: ["1 kwh 1 efhc", "rate"],
    },
    "14.1-3": {
      question: j(
        "Exchange पेज total balance",
        "की जगह main coins क्यों",
        "दिखाता है?",
      ),
      answer: j(
        "क्योंकि exchange मुख्य मूल्य",
        "और उसी balance से जुड़ा है",
        "जो इस विशेष operation के",
        "लिए मायने रखता है।",
      ),
      keywords: ["exchange page", "main balance"],
    },
    "14.2-1": {
      question: j("withdrawal कैसे काम करता है?"),
      answer: j(
        "withdrawal request भेजी",
        "जाती है और फिर पहले",
        "उपलब्ध operator द्वारा जितनी",
        "जल्दी हो सके process की",
        "जाती है।",
      ),
      keywords: ["withdrawal", "request"],
    },
    "14.2-2": {
      question: j(
        "किस balance से withdrawal",
        "किया जा सकता है?",
      ),
      answer: j(
        "withdrawal केवल main",
        "balance से उपलब्ध है।",
      ),
      keywords: ["withdraw main", "main only"],
    },
    "14.2-3": {
      question: j(
        "withdrawal केवल main",
        "balance से ही क्यों उपलब्ध",
        "है?",
      ),
      answer: j(
        "क्योंकि main balance वही है",
        "जो गेम प्रक्रिया या खरीदे",
        "गए coins के परिणाम के रूप",
        "में खिलाड़ी का हो चुका है।",
        "bonus coins internal game",
        "process में भाग लेते हैं और",
        "सीधे withdrawable परिणाम",
        "नहीं हैं।",
      ),
      keywords: ["why main only", "bonus not withdrawable"],
    },
    "14.2-4": {
      question: j("minimum withdrawal कितना है?"),
      answer: j(
        "minimum withdrawal amount",
        "10 EFHC है।",
      ),
      keywords: ["minimum withdrawal", "10 efhc"],
    },
  },
  id: {
    "5.1-1": {
      question: j(
        "Apa itu bagian Profil /",
        "Pengaturan?",
      ),
      answer: j(
        "Profil / Pengaturan adalah",
        "tempat pengguna mengelola",
        "profil dan pengaturan bot.",
        "Di sana ditampilkan status",
        "utama dan preferensi",
        "antarmuka pribadi.",
      ),
      keywords: ["profil", "pengaturan"],
    },
    "5.1-2": {
      question: j(
        "Apa yang ditampilkan di",
        "bagian atas Profil /",
        "Pengaturan?",
      ),
      answer: j(
        "Bagian atas menampilkan",
        "avatar, nama Telegram, dan",
        "status Activ serta VIP jika",
        "sudah tersedia.",
      ),
      keywords: ["avatar", "telegram", "vip"],
    },
    "5.1-3": {
      question: j(
        "Apa yang bisa diatur di",
        "Profil / Pengaturan?",
      ),
      answer: j(
        "Singkatnya: bahasa bot,",
        "tampilan, suara, getaran,",
        "notifikasi, konfirmasi",
        "tindakan, dan preferensi",
        "antarmuka lainnya.",
      ),
      keywords: ["bahasa", "tampilan", "notifikasi"],
    },
    "5.1-4": {
      question: j(
        "Apa yang ada di blok",
        "Dukungan dan Informasi?",
      ),
      answer: j(
        "Blok ini berisi bantuan,",
        "jawaban atas pertanyaan umum,",
        "aturan proyek, dan materi",
        "informasi lainnya.",
      ),
      keywords: ["dukungan", "bantuan", "aturan"],
    },
    "6.1-1": {
      question: j(
        "Apa itu bagian Wallet di",
        "Profil / Pengaturan?",
      ),
      answer: j(
        "Di bagian Wallet pengguna",
        "dapat menautkan satu atau",
        "beberapa wallet dan memilih",
        "wallet utama.",
      ),
      keywords: ["wallet", "wallet utama"],
    },
    "6.1-2": {
      question: j(
        "Mengapa wallet utama",
        "diperlukan?",
      ),
      answer: j(
        "Wallet utama digunakan di",
        "tempat aturan proyek",
        "memerlukan wallet tertaut",
        "untuk fungsi dan operasi.",
      ),
      keywords: ["utama", "wallet tertaut"],
    },
    "6.1-3": {
      question: j(
        "Bisakah wallet utama",
        "diubah?",
      ),
      answer: j(
        "Ya. Wallet utama lain dapat",
        "dipilih dari wallet yang",
        "sudah tertaut.",
      ),
      keywords: ["ubah wallet", "utama"],
    },
    "6.1-4": {
      question: j(
        "Bisakah wallet tertaut",
        "dihapus?",
      ),
      answer: j(
        "Ya. Jika wallet tidak lagi",
        "diperlukan, tautannya dapat",
        "dihapus.",
      ),
      keywords: ["hapus wallet", "lepas tautan"],
    },
    "6.1-5": {
      question: j(
        "Apa yang terjadi jika",
        "pengguna menekan tombol",
        "yang membutuhkan wallet?",
      ),
      answer: j(
        "Jika fungsi yang dipilih",
        "memerlukan wallet, menekan",
        "tombol itu akan otomatis",
        "memulai alur penautan",
        "wallet.",
      ),
      keywords: ["wallet wajib", "hubungkan wallet"],
    },
    "6.1-6": {
      question: j(
        "Apakah VIP NFT aktif",
        "otomatis setelah masuk ke",
        "wallet?",
      ),
      answer: j(
        "Ya. Logika VIP bergantung",
        "pada keberadaan NFT di",
        "wallet yang tertaut: bot",
        "memeriksa wallet secara",
        "otomatis dan memperbarui",
        "status VIP.",
      ),
      keywords: ["vip nft", "aktivasi otomatis"],
    },
    "6.1-7": {
      question: j(
        "Apakah pengguna harus",
        "mengaktifkan VIP secara",
        "manual setelah menerima",
        "NFT?",
      ),
      answer: j(
        "Tidak. Logika proyek dibuat",
        "untuk pemeriksaan wallet",
        "otomatis dan pembaruan",
        "status VIP otomatis setelah",
        "NFT ditemukan dalam koleksi",
        "yang diperlukan.",
      ),
      keywords: ["vip manual", "cek otomatis"],
    },
    "6.1-8": {
      question: j(
        "Apakah satu VIP NFT",
        "memberikan efek, sedangkan",
        "NFT kedua dan ketiga tidak?",
      ),
      answer: j(
        "Ya. Bagi pemain, memiliki",
        "setidaknya satu EFHC VIP NFT",
        "sudah cukup. NFT kedua dan",
        "ketiga tidak menambah boost",
        "generasi tambahan.",
      ),
      keywords: ["satu nft", "efek vip"],
    },
    "7.1-1": {
      question: j("Apa itu saldo bonus?"),
      answer: j(
        "Saldo bonus adalah saldo",
        "internal sementara proyek.",
        "Saldo ini diisi dari task,",
        "bonus referral, hadiah,",
        "Lotteries, dan mekanik game",
        "internal lainnya. Saldo ini",
        "tidak bisa ditarik langsung.",
      ),
      keywords: ["saldo bonus", "internal"],
    },
    "7.1-2": {
      question: j("Apa itu saldo utama?"),
      answer: j(
        "Saldo utama berisi EFHC",
        "utama. Ini adalah hasil",
        "dari siklus permainan, dan",
        "penarikan tersedia dari",
        "saldo ini.",
      ),
      keywords: ["saldo utama", "penarikan"],
    },
    "7.1-3": {
      question: j(
        "Apa perbedaan antara saldo",
        "bonus dan saldo utama?",
      ),
      answer: j(
        "Saldo bonus digunakan untuk",
        "kehidupan internal game.",
        "Saldo utama adalah hasil",
        "jalur permainan yang sudah",
        "melewati generasi energi dan",
        "konversi.",
      ),
      keywords: ["perbedaan", "bonus", "utama"],
    },
    "7.2-1": {
      question: j(
        "Bisakah saldo bonus ditarik",
        "langsung?",
      ),
      answer: j(
        "Tidak. Saldo bonus tidak",
        "bisa ditarik langsung. Saldo",
        "ini harus melewati seluruh",
        "siklus game internal.",
      ),
      keywords: ["tarik bonus", "penarikan langsung"],
    },
    "7.2-2": {
      question: j(
        "Jalur penuh apa yang",
        "dilewati saldo bonus?",
      ),
      answer: j(
        "Jalur penuhnya seperti ini:",
        "koin bonus dipakai untuk",
        "membeli panel, panel mulai",
        "menghasilkan energi, energi",
        "yang terkumpul diubah ke",
        "kWh, lalu energi diubah",
        "menjadi EFHC main. Setelah",
        "itu barulah hasil muncul di",
        "saldo utama.",
      ),
      keywords: ["siklus", "panel", "kwh"],
    },
    "7.2-3": {
      question: j(
        "Bagaimana saldo bonus",
        "berubah menjadi EFHC main?",
      ),
      answer: j(
        "Saldo bonus adalah sumber",
        "awal proses game. Melalui",
        "pembelian panel, generasi",
        "energi, dan konversi, saldo",
        "ini berubah menjadi EFHC",
        "main.",
      ),
      keywords: ["konversi", "efhc main"],
    },
    "7.2-4": {
      question: j(
        "Dalam urutan apa dana",
        "dipakai untuk pengeluaran",
        "internal?",
      ),
      answer: j(
        "Untuk semua pengeluaran",
        "internal proyek, dana",
        "dipakai dari saldo bonus",
        "lebih dulu lalu dari saldo",
        "utama.",
      ),
      keywords: ["urutan pengeluaran", "bonus dulu"],
    },
    "7.2-5": {
      question: j(
        "Apa perbedaan sederhana",
        "antara total, bonus, dan",
        "saldo utama?",
      ),
      answer: j(
        "Saldo total adalah semua",
        "digabung untuk memahami",
        "daya beli keseluruhan.",
        "Saldo bonus adalah energi",
        "game internal yang memulai",
        "siklus game. Saldo utama",
        "adalah hasil akhir yang bisa",
        "dipakai sebagai nilai utama",
        "dan ditarik sesuai aturan",
        "proyek.",
      ),
      keywords: ["saldo total", "penjelasan sederhana"],
    },
    "14.1-1": {
      question: j(
        "Bagaimana pertukaran energi",
        "menjadi EFHC bekerja?",
      ),
      answer: j(
        "Exchange adalah konversi",
        "progres menjadi EFHC main.",
        "Energi yang terkumpul diubah",
        "menjadi koin utama proyek.",
      ),
      keywords: ["exchange", "energi"],
    },
    "14.1-2": {
      question: j(
        "Apa arti aturan 1 kWh = 1",
        "EFHC?",
      ),
      answer: j(
        "Itu adalah kurs internal",
        "tetap proyek. Setiap unit",
        "energi dikonversi menjadi",
        "jumlah EFHC yang sama.",
      ),
      keywords: ["1 kwh 1 efhc", "kurs"],
    },
    "14.1-3": {
      question: j(
        "Mengapa halaman Exchange",
        "menampilkan koin main, bukan",
        "saldo total?",
      ),
      answer: j(
        "Karena exchange terikat pada",
        "nilai utama dan saldo yang",
        "relevan untuk operasi",
        "tertentu ini.",
      ),
      keywords: ["halaman exchange", "saldo utama"],
    },
    "14.2-1": {
      question: j("Bagaimana cara kerja withdrawal?"),
      answer: j(
        "Permintaan withdrawal",
        "dikirim lalu diproses",
        "secepat mungkin oleh operator",
        "pertama yang tersedia.",
      ),
      keywords: ["withdrawal", "permintaan"],
    },
    "14.2-2": {
      question: j(
        "Saldo mana yang dapat",
        "digunakan untuk withdrawal?",
      ),
      answer: j(
        "Withdrawal hanya tersedia",
        "dari saldo utama.",
      ),
      keywords: ["withdraw main", "main only"],
    },
    "14.2-3": {
      question: j(
        "Mengapa withdrawal hanya",
        "tersedia dari saldo utama?",
      ),
      answer: j(
        "Karena saldo utama adalah",
        "yang memang menjadi milik",
        "pemain sebagai hasil proses",
        "game atau koin yang dibeli.",
        "Koin bonus ikut dalam",
        "proses internal game dan",
        "bukan hasil yang bisa",
        "ditarik langsung.",
      ),
      keywords: ["mengapa hanya main", "bonus tidak bisa ditarik"],
    },
    "14.2-4": {
      question: j("Berapa minimum withdrawal?"),
      answer: j(
        "Jumlah minimum withdrawal",
        "adalah 10 EFHC.",
      ),
      keywords: ["minimum withdrawal", "10 efhc"],
    },
  },
  sw: {
    "5.1-1": {
      question: j(
        "Sehemu ya Wasifu /",
        "Mipangilio ni nini?",
      ),
      answer: j(
        "Wasifu / Mipangilio ni",
        "mahali ambapo mtumiaji",
        "anasimamia wasifu wake na",
        "mipangilio ya bot. Hapo",
        "huonyeshwa hali kuu na",
        "chaguo binafsi za",
        "kiolesura.",
      ),
      keywords: ["wasifu", "mipangilio"],
    },
    "5.1-2": {
      question: j(
        "Nini huonyeshwa juu ya",
        "Wasifu / Mipangilio?",
      ),
      answer: j(
        "Juu kuna avatar, jina la",
        "Telegram, na hali za Activ",
        "na VIP kama tayari",
        "zinapatikana.",
      ),
      keywords: ["avatar", "telegram", "vip"],
    },
    "5.1-3": {
      question: j(
        "Nini kinaweza kubadilishwa",
        "katika Wasifu /",
        "Mipangilio?",
      ),
      answer: j(
        "Kwa kifupi: lugha ya bot,",
        "mwonekano, sauti, mtikisiko,",
        "arifa, uthibitisho wa",
        "vitendo, na mapendeleo",
        "mengine ya kiolesura.",
      ),
      keywords: ["lugha", "mwonekano", "arifa"],
    },
    "5.1-4": {
      question: j(
        "Kuna nini kwenye blok ya",
        "Support na Information?",
      ),
      answer: j(
        "Blok hii ina msaada, majibu",
        "ya maswali ya kawaida,",
        "sheria za mradi, na",
        "nyenzo nyingine za taarifa.",
      ),
      keywords: ["msaada", "help", "sheria"],
    },
    "6.1-1": {
      question: j(
        "Sehemu ya Wallet katika",
        "Wasifu / Mipangilio ni",
        "nini?",
      ),
      answer: j(
        "Katika sehemu ya Wallet",
        "mtumiaji anaweza kuunganisha",
        "wallet moja au zaidi na",
        "kuchagua wallet kuu.",
      ),
      keywords: ["wallet", "wallet kuu"],
    },
    "6.1-2": {
      question: j(
        "Kwa nini wallet kuu",
        "inahitajika?",
      ),
      answer: j(
        "Wallet kuu hutumika pale",
        "ambapo sheria za mradi",
        "zinahitaji wallet",
        "iliyounganishwa kwa kazi na",
        "operesheni.",
      ),
      keywords: ["kuu", "wallet iliyounganishwa"],
    },
    "6.1-3": {
      question: j(
        "Je, wallet kuu inaweza",
        "kubadilishwa?",
      ),
      answer: j(
        "Ndiyo. Wallet nyingine kuu",
        "inaweza kuchaguliwa kutoka",
        "kwa wallets ambazo tayari",
        "zimeunganishwa.",
      ),
      keywords: ["badili wallet", "kuu"],
    },
    "6.1-4": {
      question: j(
        "Je, wallet iliyounganishwa",
        "inaweza kuondolewa?",
      ),
      answer: j(
        "Ndiyo. Ikiwa wallet",
        "haihitajiki tena, uunganisho",
        "wake unaweza kuondolewa.",
      ),
      keywords: ["ondoa wallet", "unlink"],
    },
    "6.1-5": {
      question: j(
        "Nini hutokea ikiwa",
        "mtumiaji anabonyeza kitufe",
        "kinachohitaji wallet?",
      ),
      answer: j(
        "Ikiwa kazi iliyochaguliwa",
        "inahitaji wallet, kubonyeza",
        "kitufe hicho huanza moja kwa",
        "moja mchakato wa kuunganisha",
        "wallet.",
      ),
      keywords: ["wallet inahitajika", "unganisha wallet"],
    },
    "6.1-6": {
      question: j(
        "Je, VIP NFT huwashwa",
        "kiotomatiki baada ya kufika",
        "kwenye wallet?",
      ),
      answer: j(
        "Ndiyo. Mantiki ya VIP",
        "hutegemea uwepo wa NFT katika",
        "wallet iliyounganishwa: bot",
        "hukagua wallet kiotomatiki na",
        "kusasisha hali ya VIP.",
      ),
      keywords: ["vip nft", "uwezeshaji wa moja kwa moja"],
    },
    "6.1-7": {
      question: j(
        "Je, mtumiaji anahitaji",
        "kuwasha VIP mwenyewe baada",
        "ya kupokea NFT?",
      ),
      answer: j(
        "Hapana. Mantiki ya mradi",
        "imeundwa kwa ukaguzi wa",
        "wallet wa moja kwa moja na",
        "usasishaji wa hali ya VIP",
        "baada ya NFT kupatikana",
        "katika collection",
        "inayohitajika.",
      ),
      keywords: ["vip ya mikono", "ukaguzi wa moja kwa moja"],
    },
    "6.1-8": {
      question: j(
        "Je, VIP NFT moja hutoa",
        "athari huku ya pili na ya",
        "tatu haziongezi kitu?",
      ),
      answer: j(
        "Ndiyo. Kwa mchezaji, kuwa na",
        "angalau EFHC VIP NFT moja",
        "kunatosha. NFT ya pili na ya",
        "tatu haziongezi boost ya",
        "ziada ya uzalishaji.",
      ),
      keywords: ["nft moja", "athari ya vip"],
    },
    "7.1-1": {
      question: j("Salio la bonus ni nini?"),
      answer: j(
        "Salio la bonus ni salio la",
        "ndani la muda la mradi.",
        "Linaongezwa kutoka tasks,",
        "bonasi za referrals, zawadi,",
        "Lotteries na mekaniki",
        "nyingine za ndani za mchezo.",
        "Haliwezi kutolewa moja kwa",
        "moja.",
      ),
      keywords: ["salio la bonus", "ndani"],
    },
    "7.1-2": {
      question: j("Salio kuu ni nini?"),
      answer: j(
        "Salio kuu lina EFHC kuu.",
        "Hii ni matokeo ya mzunguko",
        "wa mchezo, na withdrawal",
        "inapatikana kutoka humo.",
      ),
      keywords: ["salio kuu", "withdrawal"],
    },
    "7.1-3": {
      question: j(
        "Tofauti ni nini kati ya",
        "salio la bonus na salio",
        "kuu?",
      ),
      answer: j(
        "Salio la bonus ni kwa maisha",
        "ya ndani ya mchezo. Salio kuu",
        "ni matokeo ya njia ya mchezo",
        "ambayo tayari imepita kupitia",
        "uzalishaji wa nishati na",
        "uongeuzi.",
      ),
      keywords: ["tofauti", "bonus", "kuu"],
    },
    "7.2-1": {
      question: j(
        "Je, salio la bonus linaweza",
        "kutolewa moja kwa moja?",
      ),
      answer: j(
        "Hapana. Salio la bonus",
        "haliwezi kutolewa moja kwa",
        "moja. Lazima lipitie",
        "mzunguko mzima wa mchezo wa",
        "ndani.",
      ),
      keywords: ["toa bonus", "utoaji wa moja kwa moja"],
    },
    "7.2-2": {
      question: j(
        "Ni njia gani kamili ambayo",
        "salio la bonus hupitia?",
      ),
      answer: j(
        "Njia kamili ni hii: sarafu za",
        "bonus hutumika kununua panel,",
        "panel huanza kuzalisha",
        "nishati, nishati",
        "iliyokusanywa hubadilishwa",
        "kuwa kWh, kisha nishati",
        "hubadilishwa kuwa EFHC main.",
        "Baada ya hapo ndipo matokeo",
        "huonekana kwenye salio kuu.",
      ),
      keywords: ["mzunguko", "panel", "kwh"],
    },
    "7.2-3": {
      question: j(
        "Salio la bonus hubadilika",
        "vipi kuwa EFHC main?",
      ),
      answer: j(
        "Salio la bonus ni rasilimali",
        "ya kuanzia ya mchakato wa",
        "mchezo. Kupitia ununuzi wa",
        "panel, uzalishaji wa",
        "nishati, na uongofu,",
        "hubadilika kuwa EFHC main.",
      ),
      keywords: ["badili", "efhc main"],
    },
    "7.2-4": {
      question: j(
        "Fedha hutumika kwa mpangilio",
        "gani katika matumizi ya",
        "ndani?",
      ),
      answer: j(
        "Katika matumizi yote ya ndani",
        "ya mradi, fedha hutumika",
        "kwanza kutoka salio la bonus",
        "na kisha kutoka salio kuu.",
      ),
      keywords: ["mpangilio wa matumizi", "bonus kwanza"],
    },
    "7.2-5": {
      question: j(
        "Tofauti rahisi ni ipi kati",
        "ya salio la jumla, bonus na",
        "salio kuu?",
      ),
      answer: j(
        "Salio la jumla ni kila kitu",
        "kwa pamoja ili kuelewa nguvu",
        "ya jumla ya ununuzi. Salio la",
        "bonus ni nishati ya ndani ya",
        "mchezo inayozindua mzunguko.",
        "Salio kuu ni matokeo ya",
        "mwisho yanayoweza kutumika",
        "kama thamani kuu na",
        "kutolewa kulingana na sheria",
        "za mradi.",
      ),
      keywords: ["salio la jumla", "maelezo rahisi"],
    },
    "14.1-1": {
      question: j(
        "Ubadilishanaji wa nishati",
        "kuwa EFHC unafanyaje kazi?",
      ),
      answer: j(
        "Exchange ni ubadilishaji wa",
        "maendeleo kuwa EFHC main.",
        "Nishati iliyokusanywa",
        "hubadilishwa kuwa sarafu kuu",
        "za mradi.",
      ),
      keywords: ["exchange", "nishati"],
    },
    "14.1-2": {
      question: j(
        "Sheria ya 1 kWh = 1 EFHC",
        "inamaanisha nini?",
      ),
      answer: j(
        "Hicho ni kiwango cha ndani",
        "kilichowekwa cha mradi.",
        "Kila kitengo cha nishati",
        "hubadilishwa kuwa kiasi sawa",
        "cha EFHC.",
      ),
      keywords: ["1 kwh 1 efhc", "kiwango"],
    },
    "14.1-3": {
      question: j(
        "Kwa nini ukurasa wa Exchange",
        "unaonyesha main coins badala",
        "ya salio la jumla?",
      ),
      answer: j(
        "Kwa sababu exchange imefungwa",
        "na thamani kuu pamoja na",
        "salio ambalo lina umuhimu kwa",
        "operesheni hii maalum.",
      ),
      keywords: ["ukurasa wa exchange", "salio kuu"],
    },
    "14.2-1": {
      question: j("Withdrawal inafanyaje kazi?"),
      answer: j(
        "Ombi la withdrawal",
        "linawasilishwa na kisha",
        "linashughulikiwa haraka",
        "iwezekanavyo na operator wa",
        "kwanza anayepatikana.",
      ),
      keywords: ["withdrawal", "ombi"],
    },
    "14.2-2": {
      question: j(
        "Ni salio gani linaweza",
        "kutumika kwa withdrawal?",
      ),
      answer: j(
        "Withdrawal inapatikana tu",
        "kutoka salio kuu.",
      ),
      keywords: ["withdraw main", "main only"],
    },
    "14.2-3": {
      question: j(
        "Kwa nini withdrawal",
        "inapatikana tu kutoka salio",
        "kuu?",
      ),
      answer: j(
        "Kwa sababu salio kuu tayari",
        "ni la mchezaji kama matokeo",
        "ya mchakato wa mchezo au",
        "sarafu zilizonunuliwa.",
        "Sarafu za bonus hushiriki",
        "katika mchakato wa ndani wa",
        "mchezo na si matokeo ambayo",
        "yanaweza kutolewa moja kwa",
        "moja.",
      ),
      keywords: ["kwa nini main tu", "bonus haitolewi"],
    },
    "14.2-4": {
      question: j("Withdrawal ya chini ni kiasi gani?"),
      answer: j(
        "Kiasi cha chini cha",
        "withdrawal ni 10 EFHC.",
      ),
      keywords: ["withdrawal ya chini", "10 efhc"],
    },
  },
};


function mergeFaqOverrides(
  lang: Lang,
  overrides: Record<string, FaqItemOverride>,
): void {
  const current = faqItemOverridesByLang[lang];
  if (!current) {
    faqItemOverridesByLang[lang] = overrides;
    return;
  }
  Object.assign(current, overrides);
}


mergeFaqOverrides("en", {
    "10.1-1": {
      question: [
        "How many achievement levels",
        "exist in energy progress?",
      ].join(" "),
      answer: [
        "The energy progress has 12",
        "achievement levels.",
      ].join(" "),
      keywords: ["levels", "progress", "rank"],
    },
    "10.1-2": {
      question: [
        "What do the achievement",
        "levels mean?",
      ].join(" "),
      answer: [
        "These are levels, ranks,",
        "and progress at the same",
        "time. They show how much",
        "virtual energy has already",
        "been generated and how far",
        "the player has advanced on",
        "the energy path.",
      ].join(" "),
      keywords: ["achievement", "rank", "energy path"],
    },
    "10.1-3": {
      question: [
        "Why are level names linked",
        "to ecology and the planet?",
      ].join(" "),
      answer: [
        "Because the idea of the",
        "game is tied to virtual",
        "green energy, motivating",
        "people, and a symbolic",
        "contribution to the healing",
        "of planet Earth.",
      ].join(" "),
      keywords: ["ecology", "planet", "green energy"],
    },
    "11.1-1": {
      question: [
        "What does Activ status",
        "mean?",
      ].join(" "),
      answer: [
        "Activ is a permanent active",
        "status. It means the game",
        "has really started because",
        "at least one panel has been",
        "purchased.",
      ].join(" "),
      keywords: ["activ", "status", "panel"],
    },
    "11.1-2": {
      question: [
        "How do you get Activ?",
      ].join(" "),
      answer: [
        "To get Activ, it is enough",
        "to buy one panel. After",
        "that purchase, the status",
        "is assigned permanently.",
      ].join(" "),
      keywords: ["get activ", "buy panel"],
    },
    "11.1-3": {
      question: [
        "Do you need to wait for",
        "exchange or generation to",
        "finish to get Activ?",
      ].join(" "),
      answer: [
        "No. Activ appears right",
        "after the first panel is",
        "bought. There is no need to",
        "wait for exchange or for",
        "generation to finish.",
      ].join(" "),
      keywords: ["wait", "exchange", "generation"],
    },
    "11.1-4": {
      question: [
        "Is Activ temporary or",
        "permanent?",
      ].join(" "),
      answer: [
        "Activ is a permanent",
        "status.",
      ].join(" "),
      keywords: ["permanent", "activ"],
    },
    "11.1-5": {
      question: [
        "Is Activ kept if the panel",
        "later moves to Archive?",
      ].join(" "),
      answer: [
        "Yes. Even if the panel later",
        "moves to Archive, Activ",
        "status remains.",
      ].join(" "),
      keywords: ["archive", "kept"],
    },
    "11.1-6": {
      question: [
        "Why is Activ status",
        "important?",
      ].join(" "),
      answer: [
        "Activ helps separate real",
        "players from random",
        "registrations, bots, and",
        "bot farms. Referral bonuses",
        "are awarded exactly for",
        "active invited users.",
      ].join(" "),
      keywords: ["important", "referral bonus"],
    },
    "11.2-1": {
      question: [
        "When are referral bonuses",
        "credited?",
      ].join(" "),
      answer: [
        "Referral bonuses are checked",
        "by the bot automatically. As",
        "soon as the player becomes",
        "active, the bonus is",
        "credited right away.",
      ].join(" "),
      keywords: ["referral bonus", "automatic"],
    },
    "11.2-2": {
      question: [
        "What is the difference",
        "between an active and an",
        "inactive referral?",
      ].join(" "),
      answer: [
        "An active referral is a",
        "player who has already",
        "bought at least one panel",
        "and received Activ status.",
        "An inactive referral has not",
        "yet entered the game cycle",
        "and does not yet give the",
        "right to a bonus.",
      ].join(" "),
      keywords: ["active referral", "inactive referral"],
    },
    "11.2-3": {
      question: [
        "Why is automatic bonus",
        "crediting important?",
      ].join(" "),
      answer: [
        "Because as soon as the",
        "invited user gets Activ",
        "status, the bot records this",
        "state and automatically",
        "credits both the referral",
        "bonus and rating growth to",
        "the inviter.",
      ].join(" "),
      keywords: ["automatic credit", "rating growth"],
    },
    "11.2-4": {
      question: [
        "What should you do if the",
        "referral bonus did not",
        "arrive?",
      ].join(" "),
      answer: [
        "If the bonus did not arrive,",
        "it means the invited player",
        "has not yet become an active",
        "player under the project",
        "rules.",
      ].join(" "),
      keywords: ["bonus not arrived", "active player"],
    },
    "11.2-5": {
      question: [
        "Why are referral bonuses",
        "given only for active",
        "referrals?",
      ].join(" "),
      answer: [
        "Because the project rewards",
        "not just registration itself,",
        "but entry into the real game",
        "cycle. Activ confirms that",
        "the invited user has really",
        "started playing.",
      ].join(" "),
      keywords: ["active only", "real game cycle"],
    },
    "11.2-6": {
      question: [
        "What can be seen in the",
        '"Active" and "Inactive"',
        "sections?",
      ].join(" "),
      answer: [
        "These sections help show the",
        "situation clearly: who has",
        "already entered the game",
        "cycle and gives the right to",
        "a reward, and who still",
        "remains only registered",
        "without active status.",
      ].join(" "),
      keywords: ["active section", "inactive section"],
    },
    "12.1-1": {
      question: [
        "Why is the Tasks page",
        "needed?",
      ].join(" "),
      answer: [
        "The Tasks page is needed to",
        "complete tasks for rewards.",
      ].join(" "),
      keywords: ["tasks", "rewards"],
    },
    "12.1-2": {
      question: [
        "What does completing tasks",
        "give?",
      ].join(" "),
      answer: [
        "Tasks give bonus coins and",
        "motivate participation in",
        "the player's activity.",
      ].join(" "),
      keywords: ["bonus coins", "motivation"],
    },
    "13.1-1": {
      question: [
        "Why is the Referrals page",
        "needed?",
      ].join(" "),
      answer: [
        "The Referrals page is needed",
        "to work with invited users",
        "and understand the logic of",
        "referral bonuses.",
      ].join(" "),
      keywords: ["referrals page", "invited users"],
    },
    "13.1-2": {
      question: [
        "What are the sections on the",
        "Referrals page called?",
      ].join(" "),
      answer: [
        "The Referrals page uses the",
        '"Active" and "Inactive"',
        "sections.",
      ].join(" "),
      keywords: ["sections", "active inactive"],
    },
    "13.1-3": {
      question: [
        "What is visible on the",
        "Referrals page?",
      ].join(" "),
      answer: [
        "The Referrals page shows the",
        "list of invited users,",
        "separate sections for active",
        "and inactive referrals, the",
        "number of active invited",
        "users, and information about",
        "credited bonuses.",
      ].join(" "),
      keywords: ["visible", "credited bonuses"],
    },
    "13.1-4": {
      question: [
        "What do Active and",
        "Inactive show?",
      ].join(" "),
      answer: [
        "This helps you immediately",
        "see the real picture: who",
        "has already entered the game",
        "cycle and brings reward, and",
        "who has not yet reached",
        "active status.",
      ].join(" "),
      keywords: ["real picture", "reward"],
    },
});

mergeFaqOverrides("en", {
  "8.1-1": {
    question: "How much does one panel cost?",
    answer: "One panel always costs 100 EFHC.",
    keywords: ["panel", "price", "100 EFHC"],
  },
  "8.1-2": {
    question: "What does buying the first panel give immediately?",
    answer: j(
      "Buying the first panel starts energy generation,",
      "opens the path to progress, the path to main EFHC,",
      "and grants the permanent Activ status.",
    ),
    keywords: ["first panel", "activ", "start"],
  },
  "8.1-3": {
    question: "What does buying a panel give?",
    answer: j(
      "Buying a panel starts the main game cycle:",
      "energy generation, progress growth,",
      "achievement level growth, and the path to",
      "converting results into main EFHC.",
    ),
    keywords: ["panel", "game cycle", "main EFHC"],
  },
  "8.1-4": {
    question: "When does panel generation start?",
    answer: "Generation starts immediately after panel purchase.",
    keywords: ["generation", "start", "panel"],
  },
  "8.1-5": {
    question: "What is panel activation?",
    answer: j(
      "Panel activation is the moment when the panel enters",
      "its active life cycle and starts taking part in",
      "energy generation.",
    ),
    keywords: ["activation", "panel"],
  },
  "8.1-6": {
    question: "What is panel deactivation?",
    answer: j(
      "Panel deactivation is the end of its active life cycle",
      "after the full working term.",
    ),
    keywords: ["deactivation", "panel"],
  },
  "8.1-7": {
    question: "What is the panel lifetime?",
    answer: "Each panel has a 180-day cycle.",
    keywords: ["180 days", "lifetime"],
  },
  "8.1-8": {
    question: "What happens after the 180-day cycle ends?",
    answer: j(
      "After the 180-day cycle ends, the panel is deactivated",
      "and moves to the archive section as a memory of the",
      "participant's energy progress.",
    ),
    keywords: ["archive", "180 days", "deactivation"],
  },
  "8.1-9": {
    question: "What are archived panels?",
    answer: j(
      "Archived panels are the memory of the participant's path.",
      "They show the history of completed panels, record",
      "progress, and no longer participate in generation.",
    ),
    keywords: ["archive", "history", "panels"],
  },
  "8.1-10": {
    question: "Why do archived panels not disappear completely?",
    answer: j(
      "Because they preserve the history of the energy path",
      "and progress memory even after the active cycle ends.",
    ),
    keywords: ["archive", "history"],
  },
  "8.1-11": {
    question: "Which two panel states are shown in the interface?",
    answer: j(
      "The interface has Activ and Archive. Activ are panels",
      "that participate in generation. Archive are panels",
      "that have completed the active cycle and keep the",
      "history of the path.",
    ),
    keywords: ["activ", "archive", "panel states"],
  },
  "8.1-12": {
    question: j(
      "Can you quickly see how many panels are now in Activ",
      "and how many are already in Archive?",
    ),
    answer: j(
      "Yes. The Panels section gives a clear view of Activ",
      "and Archive as two different system states.",
    ),
    keywords: ["activ", "archive", "count"],
  },
  "8.1-13": {
    question: "Is there a limit on active panels?",
    answer: "Yes. The limit is 1000 active panels at the same time.",
    keywords: ["limit", "1000", "active panels"],
  },
  "8.1-14": {
    question: "Are Archive panels counted in the 1000 limit?",
    answer: j(
      "No. Only Activ panels are included in the limit.",
      "Archive panels are not counted.",
    ),
    keywords: ["archive", "limit", "1000"],
  },
  "9.1-1": {
    question: "How does energy generation work?",
    answer: j(
      "After purchase, the panel starts generating energy",
      "according to the project rules. Generation grows over",
      "time and is not credited instantly.",
    ),
    keywords: ["generation", "energy", "time"],
  },
  "9.1-2": {
    question: "How much energy does one panel give in 180 days?",
    answer: j(
      "At the base rate, one panel gives 107.61984000 kWh",
      "in 180 days.",
    ),
    keywords: ["107.61984000", "kWh", "180 days"],
  },
  "9.1-3": {
    question: j(
      "How much energy does one panel give with VIP",
      "in 180 days?",
    ),
    answer: j(
      "With EFHC VIP NFT, one panel gives 115.24032000 kWh",
      "in 180 days.",
    ),
    keywords: ["VIP", "115.24032000", "kWh"],
  },
  "9.1-4": {
    question: "What affects rating and progress?",
    answer: j(
      "Only kWh generation by panels affects rating",
      "and progress.",
    ),
    keywords: ["rating", "progress", "kWh"],
  },
});

mergeFaqOverrides("ua", {
  "8.1-1": {
    question: "Скільки коштує одна панель?",
    answer: "Одна панель завжди коштує 100 EFHC.",
    keywords: ["панель", "ціна", "100 EFHC"],
  },
  "8.1-2": {
    question: "Що дає купівля першої панелі одразу?",
    answer: j(
      "Купівля першої панелі одразу запускає генерацію енергії,",
      "відкриває шлях до прогресу, до основних EFHC,",
      "і надає постійний статус Activ.",
    ),
    keywords: ["перша панель", "activ", "старт"],
  },
  "8.1-3": {
    question: "Що дає купівля панелі?",
    answer: j(
      "Купівля панелі запускає основний ігровий цикл:",
      "генерацію енергії, зростання прогресу,",
      "рівнів досягнень і шлях до конвертації",
      "результату в основні EFHC.",
    ),
    keywords: ["панель", "ігровий цикл", "основні EFHC"],
  },
  "8.1-4": {
    question: "Коли починається генерація панелі?",
    answer: "Генерація починається одразу після купівлі панелі.",
    keywords: ["генерація", "старт", "панель"],
  },
  "8.1-5": {
    question: "Що таке активація панелі?",
    answer: j(
      "Активація панелі - це момент, коли панель входить",
      "в активний життєвий цикл і починає брати участь",
      "у генерації енергії.",
    ),
    keywords: ["активація", "панель"],
  },
  "8.1-6": {
    question: "Що таке деактивація панелі?",
    answer: j(
      "Деактивація панелі - це завершення її активного",
      "життєвого циклу після повного строку роботи.",
    ),
    keywords: ["деактивація", "панель"],
  },
  "8.1-7": {
    question: "Який строк життя панелі?",
    answer: "Кожна панель має 180-денний цикл.",
    keywords: ["180 днів", "строк життя"],
  },
  "8.1-8": {
    question: "Що відбувається після завершення 180-денного циклу?",
    answer: j(
      "Після завершення 180-денного циклу панель",
      "деактивується і переходить до архіву як пам'ять",
      "про енергетичний прогрес учасника.",
    ),
    keywords: ["архів", "180 днів", "деактивація"],
  },
  "8.1-9": {
    question: "Що таке архівні панелі?",
    answer: j(
      "Архівні панелі - це пам'ять про шлях учасника.",
      "Вони показують історію завершених панелей,",
      "фіксують прогрес і більше не беруть участі",
      "у генерації.",
    ),
    keywords: ["архів", "історія", "панелі"],
  },
  "8.1-10": {
    question: "Чому архівні панелі не зникають повністю?",
    answer: j(
      "Тому що вони зберігають історію енергетичного шляху",
      "та пам'ять про прогрес навіть після завершення",
      "активного циклу.",
    ),
    keywords: ["архів", "історія"],
  },
  "8.1-11": {
    question: "Які два стани панелей є в інтерфейсі?",
    answer: j(
      "В інтерфейсі є Activ і Archive. Activ - це панелі,",
      "які беруть участь у генерації. Archive - це панелі,",
      "які вже завершили активний цикл і зберігають",
      "історію шляху.",
    ),
    keywords: ["activ", "archive", "стани панелей"],
  },
  "8.1-12": {
    question: j(
      "Чи можна швидко побачити, скільки панелей зараз",
      "у Activ, а скільки вже в Archive?",
    ),
    answer: j(
      "Так. Розділ Panels дає зрозумілу картину Activ",
      "і Archive як двох різних станів системи.",
    ),
    keywords: ["activ", "archive", "кількість"],
  },
  "8.1-13": {
    question: "Чи є ліміт на активні панелі?",
    answer: "Так. Ліміт становить 1000 одночасно активних панелей.",
    keywords: ["ліміт", "1000", "активні панелі"],
  },
  "8.1-14": {
    question: "Чи враховуються панелі з Archive у ліміті 1000?",
    answer: j(
      "Ні. У ліміт входять лише панелі з Activ.",
      "Панелі з Archive не враховуються.",
    ),
    keywords: ["archive", "ліміт", "1000"],
  },
  "9.1-1": {
    question: "Як працює генерація енергії?",
    answer: j(
      "Після купівлі панель починає генерувати енергію",
      "за правилами проєкту. Генерація йде поступово",
      "в часі, а не нараховується миттєво.",
    ),
    keywords: ["генерація", "енергія", "час"],
  },
  "9.1-2": {
    question: "Скільки енергії дає одна панель за 180 днів?",
    answer: j(
      "За базовою ставкою одна панель дає",
      "107.61984000 kWh за 180 днів.",
    ),
    keywords: ["107.61984000", "kWh", "180 днів"],
  },
  "9.1-3": {
    question: "Скільки енергії дає одна панель із VIP за 180 днів?",
    answer: j(
      "За наявності EFHC VIP NFT одна панель дає",
      "115.24032000 kWh за 180 днів.",
    ),
    keywords: ["VIP", "115.24032000", "kWh"],
  },
  "9.1-4": {
    question: "Що впливає на рейтинг і прогрес?",
    answer: "На рейтинг і прогрес впливає лише генерація kWh панелями.",
    keywords: ["рейтинг", "прогрес", "kWh"],
  },
});


mergeFaqOverrides("en", {
  "15.1-1": {
    question: "What is EFHC VIP NFT?",
    answer: j(
      "EFHC VIP NFT is a club card, a key to the future",
      "EFHC ecosystem, a digital sign of belonging, and",
      "a key to future opportunities, spaces, doors,",
      "pathways, and events.",
    ),
    keywords: ["vip nft", "club card", "ecosystem"],
  },
  "15.1-2": {
    question: "What does owning one EFHC VIP NFT give?",
    answer: j(
      "Owning one EFHC VIP NFT gives increased energy",
      "generation for all of the player's panels.",
    ),
    keywords: ["one nft", "bonus generation"],
  },
  "15.1-3": {
    question: "Do 2 or 3 VIP NFTs give extra player benefits?",
    answer: j(
      "No. For the player, having 2 or 3 VIP NFTs does",
      "not provide extra benefits beyond one VIP NFT.",
    ),
    keywords: ["2 nft", "3 nft", "extra benefits"],
  },
  "15.1-4": {
    question: "Can the player manage VIP NFT freely?",
    answer: j(
      "Yes. EFHC VIP NFT can be transferred, gifted,",
      "or sold.",
    ),
    keywords: ["transfer nft", "gift nft", "sell nft"],
  },
  "15.2-1": {
    question: "Why is the Shop page needed?",
    answer: j(
      "The Shop page is needed to work with the project",
      "store and the entities of the EFHC ecosystem.",
    ),
    keywords: ["shop", "store", "ecosystem"],
  },
  "15.2-2": {
    question: "What can be done in Shop?",
    answer: j(
      "In Shop the user can buy EFHC main coin packages,",
      "EFHC VIP NFT, and other game extras.",
    ),
    keywords: ["buy efhc", "vip nft", "shop"],
  },
  "15.2-3": {
    question: "Why are top-up packages needed?",
    answer: j(
      "This is a convenient way to replenish game coins,",
      "cover a coin deficit, and avoid separate exchange",
      "purchases and transfers: coins can be bought",
      "directly in the bot for TON and USDT.",
    ),
    keywords: ["top up", "ton", "usdt"],
  },
  "15.2-4": {
    question: "Can VIP NFT be bought instead of only won?",
    answer: j(
      "Yes. EFHC VIP NFT can be won and also bought through",
      "the ecosystem mechanisms, including Shop and NFT",
      "marketplaces.",
    ),
    keywords: ["buy vip nft", "shop", "marketplace"],
  },
  "16.1-1": {
    question: "What are Lotteries in EFHC?",
    answer: j(
      "Lotteries are a game opportunity to receive a",
      "valuable prize inside the EFHC ecosystem.",
    ),
    keywords: ["lotteries", "prize", "efhc"],
  },
  "16.1-2": {
    question: "Which Lotteries operate in the project?",
    answer: j(
      "Two active Lotteries run in parallel: the 100 EFHC",
      "Lotteries draw and the EFHC VIP NFT",
      "Lotteries draw.",
    ),
    keywords: ["100 efhc", "vip nft", "lotteries"],
  },
  "16.1-3": {
    question: "How do the 100 EFHC and VIP NFT Lotteries differ?",
    answer: j(
      "They are two different prize types. The 100 EFHC",
      "Lotteries draw gives bonus coins, while the VIP",
      "NFT Lotteries draw gives a digital NFT asset.",
    ),
    keywords: ["bonus coins", "nft asset"],
  },
  "16.2-1": {
    question: "How much does one ticket cost?",
    answer: "One ticket costs 1.00000000 EFHC.",
    keywords: ["ticket", "1 efhc"],
  },
  "16.2-2": {
    question: "How many tickets are used in the 100 EFHC Lotteries?",
    answer: "The 100 EFHC Lotteries use 200 tickets.",
    keywords: ["200 tickets", "100 efhc"],
  },
  "16.2-3": {
    question: "How many tickets are in the EFHC VIP NFT Lotteries?",
    answer: "The EFHC VIP NFT Lotteries use 3000 tickets.",
    keywords: ["3000 tickets", "vip nft"],
  },
  "16.2-4": {
    question: "When do Lotteries start?",
    answer: j(
      "Lotteries start immediately after the final",
      "ticket is sold.",
    ),
    keywords: ["start lotteries", "last ticket"],
  },
  "16.2-5": {
    question: "How is the winner determined?",
    answer: j(
      "After the final ticket is sold, the system runs an",
      "automatic draw, selects a random winning ticket,",
      "and records the winner.",
    ),
    keywords: ["winner", "random ticket", "draw"],
  },
  "16.2-6": {
    question: "What happens after the winner is selected?",
    answer: j(
      "After the automatic winner selection, the current",
      "Lotteries draw closes and a new Lotteries draw is",
      "automatically right away.",
    ),
    keywords: ["new lotteries", "automatic restart"],
  },
  "16.3-1": {
    question: "What is the prize in the 100 EFHC Lotteries?",
    answer: j(
      "In the 100 EFHC Lotteries, the prize is",
      "100.00000000 EFHC to the bonus balance.",
    ),
    keywords: ["100 efhc prize", "bonus balance"],
  },
  "16.3-2": {
    question: "What is the prize in the EFHC VIP NFT Lotteries?",
    answer: "In the EFHC VIP NFT Lotteries, the prize is EFHC VIP NFT.",
    keywords: ["vip nft prize"],
  },
  "16.3-3": {
    question: "Why is a wallet needed for the VIP NFT Lotteries?",
    answer: j(
      "A linked wallet is required not only for taking part",
      "in the VIP NFT Lotteries, but also for the operator",
      "send the NFT prize manually after the win.",
    ),
    keywords: ["wallet", "vip nft", "manual delivery"],
  },
  "16.3-4": {
    question: "How is EFHC VIP NFT delivered after a win?",
    answer: j(
      "After the win, a request is created and an operator",
      "manually sends the prize to the linked crypto wallet",
      "attached to the winning ticket.",
    ),
    keywords: ["operator", "linked wallet", "ticket"],
  },
  "17.1-1": {
    question: "What should I do if a referral bonus has not arrived?",
    answer: j(
      "Referral bonuses are checked automatically by the",
      "bot. If the bonus did not arrive, the invited player",
      "has not become an active player yet.",
    ),
    keywords: ["referral bonus", "not arrived"],
  },
  "17.1-2": {
    question: "What should I do if I do not see the needed balance?",
    answer: j(
      "Open the page that matches the action. The total",
      "balance in the top bar shows all coins together,",
      "while special pages show only the balance relevant",
      "to a specific operation.",
    ),
    keywords: ["needed balance", "top bar", "operation"],
  },
  "17.1-3": {
    question: "What should I do if a panel moved to Archive?",
    answer: j(
      "If a panel moved to Archive, its active life cycle is",
      "finished. Archive panels remain as a memory of the",
      "player's path and are not counted in the active",
      "panel limit.",
    ),
    keywords: ["archive", "panel", "limit"],
  },
  "17.1-4": {
    question: j(
      "What should I do if I pressed a",
      "button without a wallet?",
    ),
    answer: j(
      "If the function requires a wallet, the interface",
      "starts wallet linking automatically. After linking,",
      "the needed action can be repeated.",
    ),
    keywords: ["button", "wallet", "linking"],
  },
});

mergeFaqOverrides("ua", {
  "15.1-1": {
    question: "Що таке EFHC VIP NFT?",
    answer: j(
      "EFHC VIP NFT - це клубна картка, ключ до майбутньої",
      "екосистеми EFHC, цифровий знак належності та ключ",
      "до майбутніх можливостей, просторів, дверей,",
      "проходів і подій.",
    ),
    keywords: ["vip nft", "клубна картка", "екосистема"],
  },
  "15.1-2": {
    question: "Що дає володіння одним EFHC VIP NFT?",
    answer: j(
      "Володіння одним EFHC VIP NFT дає підвищену",
      "генерацію енергії для всіх панелей гравця.",
    ),
    keywords: ["один nft", "бонусна генерація"],
  },
  "15.1-3": {
    question: "Чи дають 2 або 3 VIP NFT додаткові привілеї?",
    answer: j(
      "Ні. Для гравця наявність 2 або 3 VIP NFT не дає",
      "додаткових привілеїв понад одну VIP NFT.",
    ),
    keywords: ["2 nft", "3 nft", "додаткові привілеї"],
  },
  "15.1-4": {
    question: "Чи можна вільно розпоряджатися VIP NFT?",
    answer: j(
      "Так. EFHC VIP NFT можна передавати, дарувати",
      "та продавати.",
    ),
    keywords: ["передати nft", "подарувати nft", "продати nft"],
  },
  "15.2-1": {
    question: "Для чого потрібна сторінка Shop?",
    answer: j(
      "Сторінка Shop потрібна для роботи з магазином",
      "проєкту та сутностями екосистеми EFHC.",
    ),
    keywords: ["shop", "магазин", "екосистема"],
  },
  "15.2-2": {
    question: "Що можна робити в Shop?",
    answer: j(
      "У Shop можна купувати пакети EFHC main coins,",
      "EFHC VIP NFT та інші ігрові бонуси.",
    ),
    keywords: ["купити efhc", "vip nft", "shop"],
  },
  "15.2-3": {
    question: "Навіщо потрібні пакети поповнення?",
    answer: j(
      "Це зручний спосіб поповнити ігрові монети,",
      "закрити дефіцит і не займатися окремими",
      "біржовими покупками та переказами: монети можна",
      "купити прямо в боті за TON та USDT.",
    ),
    keywords: ["поповнення", "ton", "usdt"],
  },
  "15.2-4": {
    question: "Чи можна купити VIP NFT, а не лише виграти?",
    answer: j(
      "Так. EFHC VIP NFT можна не лише виграти, але й",
      "купити через механіки екосистеми, включно з Shop",
      "та NFT-маркетплейсами.",
    ),
    keywords: ["купити vip nft", "shop", "маркетплейс"],
  },
  "16.1-1": {
    question: "Що таке Lotteries в EFHC?",
    answer: j(
      "Lotteries - це ігрова можливість отримати цінний",
      "приз усередині екосистеми EFHC.",
    ),
    keywords: ["lotteries", "приз", "efhc"],
  },
  "16.1-2": {
    question: "Які Lotteries працюють у проєкті?",
    answer: j(
      "У проєкті паралельно працюють два активні",
      "Lotteries: 100 EFHC Lotteries draw і EFHC VIP NFT",
      "Lotteries draw.",
    ),
    keywords: ["100 efhc", "vip nft", "lotteries"],
  },
  "16.1-3": {
    question: "Чим відрізняються 100 EFHC Lotteries та VIP NFT?",
    answer: j(
      "Це два різні типи цінності. У 100 EFHC Lotteries",
      "розігруються бонусні монети, а у VIP NFT Lotteries",
      "призом є цифровий NFT-актив.",
    ),
    keywords: ["бонусні монети", "nft актив"],
  },
  "16.2-1": {
    question: "Скільки коштує один квиток?",
    answer: "Один квиток коштує 1.00000000 EFHC.",
    keywords: ["квиток", "1 efhc"],
  },
  "16.2-2": {
    question: "Скільки квитків у 100 EFHC Lotteries?",
    answer: "У 100 EFHC Lotteries використовується 200 квитків.",
    keywords: ["200 квитків", "100 efhc"],
  },
  "16.2-3": {
    question: "Скільки квитків у EFHC VIP NFT Lotteries?",
    answer: "У EFHC VIP NFT Lotteries використовується 3000 квитків.",
    keywords: ["3000 квитків", "vip nft"],
  },
  "16.2-4": {
    question: "Коли запускаються Lotteries?",
    answer: j(
      "Lotteries запускаються одразу після продажу",
      "останнього квитка.",
    ),
    keywords: ["старт lotteries", "останній квиток"],
  },
  "16.2-5": {
    question: "Як визначається переможець?",
    answer: j(
      "Після продажу останнього квитка система одразу",
      "проводить автоматичний розіграш, обирає",
      "випадковий виграшний квиток і фіксує переможця.",
    ),
    keywords: ["переможець", "випадковий квиток", "розіграш"],
  },
  "16.2-6": {
    question: "Що відбувається після вибору переможця?",
    answer: j(
      "Після автоматичного вибору переможця поточний",
      "Lotteries draw закривається і одразу автоматично",
      "створюється новий Lotteries draw.",
    ),
    keywords: ["нові lotteries", "автостарт"],
  },
  "16.3-1": {
    question: "Який приз у 100 EFHC Lotteries?",
    answer: j(
      "У 100 EFHC Lotteries приз становить",
      "100.00000000 EFHC у bonus balance.",
    ),
    keywords: ["приз 100 efhc", "bonus balance"],
  },
  "16.3-2": {
    question: "Який приз у EFHC VIP NFT Lotteries?",
    answer: "У EFHC VIP NFT Lotteries призом є EFHC VIP NFT.",
    keywords: ["приз vip nft"],
  },
  "16.3-3": {
    question: "Навіщо потрібен wallet для VIP NFT Lotteries?",
    answer: j(
      "Прив'язаний wallet потрібен не лише для участі",
      "у VIP NFT Lotteries, а й для подальшого ручного",
      "надсилання NFT-призу оператором після перемоги.",
    ),
    keywords: ["wallet", "vip nft", "ручна видача"],
  },
  "16.3-4": {
    question: "Як видається EFHC VIP NFT після перемоги?",
    answer: j(
      "Після перемоги створюється заявка, і оператор",
      "у ручному режимі надсилає приз на прив'язаний",
      "криптогаманець, що належить виграшному квитку.",
    ),
    keywords: ["оператор", "прив'язаний wallet", "квиток"],
  },
  "17.1-1": {
    question: "Що робити, якщо не прийшов реферальний бонус?",
    answer: j(
      "Реферальні бонуси перевіряються ботом автоматично.",
      "Якщо бонус не прийшов, запрошений гравець ще не",
      "став активним гравцем.",
    ),
    keywords: ["реферальний бонус", "не прийшов"],
  },
  "17.1-2": {
    question: "Що робити, якщо я не бачу потрібний баланс?",
    answer: j(
      "Потрібно відкрити сторінку, що відповідає дії.",
      "Загальний баланс у верхній панелі показує всі",
      "монети разом, а спеціальні сторінки показують",
      "лише той баланс, який потрібен для конкретної",
      "операції.",
    ),
    keywords: ["потрібний баланс", "верхня панель", "операція"],
  },
  "17.1-3": {
    question: "Що робити, якщо панель перейшла в Archive?",
    answer: j(
      "Якщо панель перейшла в Archive, її активний",
      "життєвий цикл завершено. Панелі з Archive",
      "залишаються як пам'ять про шлях гравця і не",
      "враховуються в ліміті активних панелей.",
    ),
    keywords: ["archive", "панель", "ліміт"],
  },
  "17.1-4": {
    question: "Що робити, якщо натиснув кнопку без wallet?",
    answer: j(
      "Якщо для функції потрібен wallet, інтерфейс",
      "автоматично запускає його прив'язку. Після",
      "прив'язки можна повторити потрібну дію.",
    ),
    keywords: ["кнопка", "wallet", "прив'язка"],
  },
});
