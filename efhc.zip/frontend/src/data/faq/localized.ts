import type { Lang } from "../../lib/i18n";

type FaqItemOverride = {
  question?: string;
  answer?: string;
  keywords?: string[];
};

type FaqOverridesByLang = Partial<
  Record<Lang, Record<string, FaqItemOverride>>
>;

function j(parts: string[]): string {
  return parts.join(" ");
}

function item(
  question: string,
  answer: string,
  keywords: string[],
): FaqItemOverride {
  return { question, answer, keywords };
}

export const faqItemOverridesByLang: FaqOverridesByLang = {
  en: {
    "1.1-1": item(
      "What is the total balance?",
      j([
        "The total balance shows all EFHC you currently have inside",
        "the bot. It is useful for understanding your overall",
        "resources, but it is not the same as the amount available",
        "for withdrawal.",
      ]),
      ["total balance", "all balance", "overall balance"],
    ),
    "1.1-2": item(
      "What is the main balance?",
      j([
        "The main balance is the part of your funds used for key",
        "project actions. It is the balance used for withdrawal.",
      ]),
      ["main balance", "withdraw balance"],
    ),
    "1.1-3": item(
      "What is the bonus balance?",
      j([
        "The bonus balance is the internal part of your funds inside",
        "the bot. It is used for in-bot game actions and purchases,",
        "but it is not used for withdrawal.",
      ]),
      ["bonus balance", "bonus funds"],
    ),
    "1.1-4": item(
      "What is the difference between total, main and bonus balance?",
      j([
        "The total balance is all your funds inside the bot. The main",
        "balance is used for exchange and withdrawal. The bonus",
        "balance is used for internal game actions and purchases.",
      ]),
      ["balance difference", "main", "bonus", "total"],
    ),
    "1.2-1": item(
      "Why can't I withdraw the whole total balance?",
      j([
        "Because the total balance includes both main and bonus EFHC.",
        "Only the main balance is used for withdrawal.",
      ]),
      ["withdraw", "total balance", "why not"],
    ),
    "1.2-2": item(
      "Why can one purchase affect both bonus and main balance?",
      j([
        "Because the bot can use your internal funds step by step for",
        "one action. As a result, one purchase can reduce two",
        "balances at once.",
      ]),
      ["purchase", "two balances", "main and bonus"],
    ),
    "2.1-1": item(
      "What does balance history show?",
      j([
        "Balance history shows changes to your funds: incoming",
        "amounts, spending and other actions that affected your",
        "balance inside the bot.",
      ]),
      ["balance history", "operations", "history"],
    ),
    "2.1-2": item(
      "Which actions appear in balance history?",
      j([
        "The history shows actions that change your main or bonus",
        "balance: rewards, spending, purchases, exchange and other",
        "in-bot actions.",
      ]),
      ["history", "operations", "rewards", "spending"],
    ),
    "2.1-3": item(
      "Why did my balance change?",
      j([
        "Your balance changes after actions inside the bot: purchases,",
        "bonus rewards, energy exchange, withdrawal and other",
        "operations. Balance history helps you see the reason.",
      ]),
      ["balance changed", "why"],
    ),
    "2.1-4": item(
      "How can I understand why funds came in or went out?",
      j([
        "Open balance history and check the operation description. It",
        "shows which action caused the incoming amount or spending.",
      ]),
      ["why", "incoming", "spending", "history"],
    ),
    "3.1-1": item(
      "What is a panel?",
      j([
        "A panel is the basis of your game and energy progress in",
        "EFHC Bot. After purchase it takes part in energy",
        "generation inside the project.",
      ]),
      ["panel", "solar panel"],
    ),
    "3.1-2": item(
      "What does a panel give me?",
      j([
        "A panel gives you energy generation, project progress and a",
        "basis for later exchanging energy into EFHC.",
      ]),
      ["what panel gives", "generation", "progress"],
    ),
    "3.1-3": item(
      "How do I buy a panel?",
      j([
        "Open the Panels section, choose a purchase and confirm it.",
        "After a successful purchase, the panel will appear in your",
        "list.",
      ]),
      ["buy panel", "panels"],
    ),
    "3.1-4": item(
      "What happens if I have several panels?",
      j([
        "If you have several panels, each of them contributes to your",
        "overall progress and increases the amount of energy inside",
        "the project.",
      ]),
      ["several panels", "many panels"],
    ),
    "3.1-5": item(
      "What does panel archive mean?",
      j([
        "A panel archive means that this cycle is no longer in the",
        "active part of the screen, but the panel still remains part",
        "of your progress history.",
      ]),
      ["panel archive", "archive"],
    ),
    "3.2-1": item(
      "How does energy appear?",
      j([
        "Energy appears because of your panels. Panels are what make",
        "energy grow inside the bot.",
      ]),
      ["how energy appears", "energy"],
    ),
    "3.2-2": item(
      "What is available energy?",
      j([
        "Available energy is the part of energy you can use further",
        "within the project mechanics.",
      ]),
      ["available energy", "usable energy"],
    ),
    "3.2-3": item(
      "Why might a panel stop generating?",
      j([
        "Usually it is connected with the panel state, its cycle or",
        "the fact that you are looking at a non-active part of the",
        "screen. Check the Panels section and the current panel",
        "state.",
      ]),
      ["not generating", "panel not working"],
    ),
    "4.1-1": item(
      "What is exchange?",
      j([
        "Exchange is the action where your available energy turns",
        "into EFHC according to the project rules.",
      ]),
      ["exchange", "convert energy"],
    ),
    "4.1-2": item(
      "What happens after exchange?",
      j([
        "After exchange, part of your energy is counted as used and",
        "EFHC are added to your main balance.",
      ]),
      ["after exchange", "main balance"],
    ),
    "4.1-3": item(
      "When do I need exchange first, and when is withdrawal ready?",
      j([
        "If you have energy but not enough funds in your main",
        "balance yet, you need exchange first. Withdrawal is used",
        "for the main balance.",
      ]),
      ["exchange first", "then withdraw"],
    ),
    "4.2-1": item(
      "What is withdrawal?",
      j([
        "Withdrawal is the action that lets a user send EFHC from the",
        "main balance according to the project rules.",
      ]),
      ["withdrawal", "withdraw"],
    ),
    "4.2-2": item(
      "Why can't I withdraw the bonus balance?",
      j([
        "Because the bonus balance is meant for internal game use.",
        "Only the main balance is used for withdrawal.",
      ]),
      ["cannot withdraw bonus", "bonus balance"],
    ),
    "4.2-3": item(
      "Why did my main balance change after a withdrawal request?",
      j([
        "Because after you create a request, that amount is counted",
        "for this action right away and is no longer free for other",
        "actions.",
      ]),
      ["withdrawal request", "balance changed"],
    ),
    "4.2-4": item(
      "Why might withdrawal be unavailable?",
      j([
        "Withdrawal may be unavailable if project conditions are not",
        "met yet, if there is not enough in your main balance or if",
        "no wallet is linked.",
      ]),
      ["withdraw unavailable", "wallet"],
    ),
    "5.1-1": item(
      "Why do I need a wallet?",
      j([
        "A wallet is needed for actions where the project needs",
        "external confirmation and a link to your address. It is also",
        "important for VIP NFT and related actions.",
      ]),
      ["why wallet", "wallet"],
    ),
    "5.1-2": item(
      "How do I connect a wallet?",
      j([
        "Open the Wallet section, choose connect and confirm the",
        "action in a supported wallet app.",
      ]),
      ["connect wallet", "wallet connect"],
    ),
    "5.1-3": item(
      "What is the primary wallet?",
      j([
        "The primary wallet is the wallet the bot uses as the main",
        "one for actions where your chosen address is needed.",
      ]),
      ["primary wallet", "main wallet"],
    ),
    "5.1-4": item(
      "Can I link several wallets?",
      j([
        "Yes. The bot can store several linked wallets and let you",
        "choose the primary one from the connected list.",
      ]),
      ["several wallets", "primary wallet"],
    ),
    "5.1-5": item(
      "What should I do if the wallet does not connect?",
      j([
        "Check that the right wallet app is open, the Telegram Mini",
        "App connection is not interrupted and that you confirm the",
        "connection inside the wallet itself. Then try again.",
      ]),
      ["not connecting", "wallet problem"],
    ),
    "6.1-1": item(
      "What are referrals?",
      j([
        "Referrals are users who came to the project through your",
        "link and then affect your progress according to the referral",
        "system rules.",
      ]),
      ["referrals", "invited users"],
    ),
    "6.1-2": item(
      "How does my referral link work?",
      j([
        "You share your link with a new user. If that user joins the",
        "project through it, they are counted inside your referral",
        "system.",
      ]),
      ["referral link", "invite link"],
    ),
    "6.1-3": item(
      "Who counts as an active referral?",
      j([
        "An active referral is a user who has already completed the",
        "required project condition and is included in your active",
        "referral statistics.",
      ]),
      ["active referral", "referral active"],
    ),
    "6.1-4": item(
      "Who counts as an inactive referral?",
      j([
        "An inactive referral is a user who joined through your link",
        "but has not yet completed the condition for active status.",
      ]),
      ["inactive referral", "referral inactive"],
    ),
    "6.1-5": item(
      "What do the counters on the referrals page show?",
      j([
        "The counters show how many referrals you have in total, how",
        "many of them are active and how that affects your progress",
        "inside the referral system.",
      ]),
      ["counters", "referrals page"],
    ),
    "6.1-6": item(
      "How does progress to the next level work?",
      j([
        "Progress shows how much is still needed for the next step in",
        "your referral line. It helps you quickly see how much is left",
        "until the next level or bonus.",
      ]),
      ["progress", "next level"],
    ),

    "7.1-1": item(
      "What is VIP NFT?",
      j([
        "VIP NFT is a special project NFT that gives a user a VIP",
        "effect according to the EFHC Bot rules.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "What does VIP NFT give me?",
      j([
        "VIP NFT gives special advantages inside the project. In the",
        "interface this is linked to VIP status and the related",
        "project effects.",
      ]),
      ["what vip nft gives", "vip status"],
    ),
    "7.1-3": item(
      "Do I need a linked wallet for VIP NFT?",
      j([
        "Yes. The bot needs a linked wallet to see your VIP NFT and",
        "connect it correctly to your status.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "When does VIP status become active?",
      j([
        "When the bot sees the correct NFT in your linked wallet, the",
        "VIP status is updated automatically according to the project",
        "rules.",
      ]),
      ["vip status", "becomes active"],
    ),
    "7.1-5": item(
      "What should I do if I have the NFT but the status is missing?",
      j([
        "Check that the NFT is in the correct linked wallet and that",
        "this wallet is still current in the bot. Then refresh the",
        "screen and check again.",
      ]),
      ["nft exists", "status missing"],
    ),
    "8.1-1": item(
      "What is Shop?",
      j([
        "Shop is the section where a user can buy in-bot items and",
        "other project things connected with the interface style.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "What can I buy in Shop?",
      j([
        "In Shop you can buy the available project items shown to you",
        "now, such as skins and other suitable elements.",
      ]),
      ["what to buy", "items"],
    ),
    "8.1-3": item(
      "How is buying with EFHC different from buying through Wallet?",
      j([
        "Buying with EFHC uses your funds inside the bot. Buying",
        "through Wallet needs an external confirmation through your",
        "wallet.",
      ]),
      ["buy with efhc", "through wallet"],
    ),
    "8.1-4": item(
      "Why might Shop show nothing?",
      j([
        "This can happen if there are no available items for your",
        "screen right now or if the section is not yet filled with",
        "suitable positions.",
      ]),
      ["shop empty", "nothing shown"],
    ),
    "8.2-1": item(
      "What are skins?",
      j([
        "Skins are visual design elements that change how parts of",
        "the interface look inside the project.",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "How are regular skins different from level designs?",
      j([
        "Regular skins are available purchases or design elements.",
        "Level designs are connected with your progress and open",
        "according to the project rules.",
      ]),
      ["level design", "skins difference"],
    ),
    "8.2-3": item(
      "How do I buy and activate a skin?",
      j([
        "First buy an available skin in Shop, then choose it among",
        "your available designs and activate it in the interface.",
      ]),
      ["buy skin", "activate skin"],
    ),
    "9.1-1": item(
      "How do I top up my balance?",
      j([
        "To top up, open the needed action in the bot and follow the",
        "steps on the screen. If Wallet is needed, the bot will show",
        "you the next step.",
      ]),
      ["top up", "add funds"],
    ),
    "9.1-2": item(
      "When do I need a wallet for a purchase?",
      j([
        "A wallet is needed when the purchase is not only inside the",
        "bot and requires an external confirmation through your",
        "address.",
      ]),
      ["when wallet needed", "purchase"],
    ),
    "9.2-1": item(
      "How does a purchase through Wallet work?",
      j([
        "The bot sends you to the confirmation step in Wallet. After",
        "you confirm it, the system updates the purchase result",
        "inside the project.",
      ]),
      ["purchase through wallet", "wallet buy"],
    ),
    "9.2-2": item(
      "How is an internal purchase different from a Wallet purchase?",
      j([
        "An internal purchase uses your EFHC inside the bot. A Wallet",
        "purchase needs an external confirmation through Wallet.",
      ]),
      ["internal purchase", "through wallet"],
    ),
    "9.2-3": item(
      "What happens after payment?",
      j([
        "After payment, the result should appear in the bot",
        "interface: your balance, purchase or new item is updated",
        "according to the project rules.",
      ]),
      ["after payment", "payment result"],
    ),
    "9.2-4": item(
      "Why don't I see the result right after payment?",
      j([
        "Some operations need a little time before the interface is",
        "updated. If the result is not visible yet, refresh the",
        "screen and check the history or the needed section.",
      ]),
      ["result not visible", "after payment"],
    ),
    "10.1-1": item(
      "What is a level?",
      j([
        "A level shows your personal progress inside the project. It",
        "grows as you move through the game and energy mechanics of",
        "EFHC Bot.",
      ]),
      ["level", "progress"],
    ),
    "10.1-2": item(
      "What is a rank?",
      j([
        "A rank shows your position among other participants on the",
        "Ranks page.",
      ]),
      ["rank", "ranks"],
    ),
    "10.1-3": item(
      "How is a level different from a rank?",
      j([
        "A level shows your personal progress, while a rank shows",
        "your position among other project participants.",
      ]),
      ["rank and level difference"],
    ),
    "10.1-4": item(
      "What does the Ranks page show?",
      j([
        "The Ranks page shows the participant leaderboard and helps",
        "you understand your current place compared with others.",
      ]),
      ["ranks page", "place"],
    ),
    "11.1-1": item(
      "Why can't I withdraw funds?",
      j([
        "Usually this means that withdrawal needs a main balance, a",
        "Wallet or the project conditions for this action are not yet",
        "met.",
      ]),
      ["cannot withdraw", "withdrawal"],
    ),
    "11.1-2": item(
      "Why does the wallet not connect?",
      j([
        "Check that you opened the correct Wallet, the Mini App",
        "connection was not interrupted and the confirmation was done",
        "inside the wallet itself.",
      ]),
      ["wallet not connecting", "wallet problem"],
    ),
    "11.1-3": item(
      "Why is my panel not generating?",
      j([
        "Check the current Panels screen and the panel state. Usually",
        "the reason is the stage of its cycle or that you are looking",
        "at a non-active part of the list.",
      ]),
      ["panel not generating", "panel problem"],
    ),
    "11.1-4": item(
      "Why is VIP status not displayed?",
      j([
        "Check that the correct NFT is in the linked Wallet and that",
        "the bot already sees this wallet as current.",
      ]),
      ["vip missing", "status"],
    ),
    "11.1-5": item(
      "Why didn't I get the bonus?",
      j([
        "First check the balance history and the section connected to",
        "this bonus. If the bonus did not appear right away, refresh",
        "the screen and check the related FAQ question.",
      ]),
      ["bonus missing", "bonus"],
    ),
    "11.1-6": item(
      "Why is my referral inactive?",
      j([
        "This means that the user from your link has not yet completed",
        "the condition required for active status in the referral",
        "system.",
      ]),
      ["inactive referral", "referral inactive"],
    ),
    "11.1-7": item(
      "Why is Shop empty?",
      j([
        "If Shop is empty, it means there are no available items for",
        "your screen right now or the needed positions are not shown",
        "in the store yet.",
      ]),
      ["shop empty", "no items"],
    ),
    "12.1-1": item(
      "How do I search by words in FAQ?",
      j([
        "Open FAQ and enter a clear interface word into the search",
        "bar: for example balance, wallet, panel, exchange or",
        "withdrawal.",
      ]),
      ["search", "faq", "find"],
    ),
    "12.1-2": item(
      "Where should I look for a balance question?",
      j([
        "Look in the Balances and Balance history sections. They",
        "explain what you see in the interface and why your funds",
        "change.",
      ]),
      ["where find balance", "history"],
    ),
    "12.1-3": item(
      "Where should I look for a wallet question?",
      j([
        "Open the Wallet section. It collects questions about",
        "connection, the primary wallet and connection problems.",
      ]),
      ["where find wallet", "wallet"],
    ),
    "12.1-4": item(
      "What should I do if I did not find the answer?",
      j([
        "Try another clear query based on the bot interface or open a",
        "nearby section by meaning. If the question is about Wallet,",
        "history, panels or exchange, search with these words.",
      ]),
      ["answer not found", "another query"],
    ),
    "1.3-1": item(
      "Що таке верхня панель?",
      j([
        "Верхня панель — це головний швидкий інформаційний блок,",
        "який видно на основних сторінках бота.",
      ]),
      ["верхня панель", "top bar"],
    ),
    "1.3-2": item(
      "Що відображається у верхній панелі?",
      j([
        "У верхній панелі можуть відображатися ваше ім'я, аватар,",
        "рівень прогресу, VIP-статус, загальний баланс і швидкі",
        "кнопки на кшталт Поповнити та Shop.",
      ]),
      ["верхня панель", "що видно"],
    ),
    "1.3-3": item(
      j([
        "Чому загальний баланс у верхній панелі не дорівнює сумі",
        "для виведення?",
      ]),
      j([
        "Тому що верхня панель показує загальний обсяг ваших",
        "коштів усередині бота, а для виведення використовується",
        "лише основний баланс.",
      ]),
      ["верхня панель", "загальний баланс"],
    ),
    "1.3-4": item(
      "Що робить кнопка «Поповнити»?",
      j([
        "Кнопка Поповнити відкриває шлях до поповнення або",
        "покупки через гаманець. Якщо для цього потрібен Wallet,",
        "бот спочатку запропонує його підключити.",
      ]),
      ["поповнити", "wallet", "buy"],
    ),
    "1.3-5": item(
      "Що робить кнопка Shop?",
      j([
        "Кнопка Shop відкриває магазин проєкту, де знаходяться",
        "покупки за EFHC і зовнішні пропозиції через гаманець.",
      ]),
      ["shop", "кнопка shop"],
    ),
    "3.3-1": item(
      "Навіщо потрібна сторінка Energy?",
      j([
        "Сторінка Energy потрібна для швидкого розуміння вашого",
        "енергетичного стану та входу в щоденний ігровий цикл.",
      ]),
      ["energy page", "навіщо energy"],
    ),
    "3.3-2": item(
      "Що показує сторінка Energy?",
      j([
        "Сторінка Energy показує ключові показники: прогрес,",
        "генерацію, активні панелі та інші дані, які допомагають",
        "швидко зрозуміти поточний стан.",
      ]),
      ["що показує energy", "energy"],
    ),
    "3.3-3": item(
      "Що показує прогрес-бар на сторінці Energy?",
      j([
        "Прогрес-бар показує ваш шлях до наступного рівня і",
        "допомагає зрозуміти, наскільки далеко ви просунулися в",
        "енергетичному прогресі.",
      ]),
      ["прогрес бар", "energy progress"],
    ),
    "3.3-4": item(
      "Що означає загальна генерація панелей за секунду?",
      j([
        "Це показник того, скільки енергії сумарно дають усі ваші",
        "активні панелі за секунду. Він допомагає швидко",
        "зрозуміти силу вашої поточної системи.",
      ]),
      ["генерація за секунду", "energy rate"],
    ),
    "3.3-5": item(
      "Чому сторінка Energy важлива?",
      j([
        "Тому що вона дає швидкий огляд вашого прогресу,",
        "генерації та активних панелей без зайвих переходів.",
      ]),
      ["чому energy", "важливість energy"],
    ),
    "12.2-1": item(
      "Що таке розділ «Профіль/Налаштування»?",
      j([
        "Це розділ, де видно ваші основні статуси та розташовані",
        "персональні налаштування інтерфейсу бота.",
      ]),
      ["профіль", "налаштування"],
    ),
    "12.2-2": item(
      j([
        "Що відображається у верхній частині",
        "Профілю/Налаштувань?",
      ]),
      j([
        "У верхній частині зазвичай видно ваш аватар, ім'я",
        "Telegram та важливі статуси на кшталт Activ і VIP,",
        "якщо вони вже у вас є.",
      ]),
      ["профіль верх", "activ", "vip"],
    ),
    "12.2-3": item(
      j([
        "Що можна налаштовувати в розділі",
        "«Профіль/Налаштування»?",
      ]),
      j([
        "Там знаходяться мова бота та інші користувацькі",
        "параметри інтерфейсу, які роблять роботу з ботом",
        "зручнішою.",
      ]),
      ["мова бота", "налаштування"],
    ),
    "12.2-4": item(
      "Що знаходиться в розділі «Підтримка та інформація»?",
      j([
        "Там знаходяться допомога, FAQ та інші інформаційні",
        "матеріали, які допомагають краще розуміти проєкт і",
        "інтерфейс бота.",
      ]),
      ["підтримка", "інформація", "faq"],
    ),
  },

  de: {
    "1.1-1": item(
      "Was ist das Gesamtguthaben?",
      j([
        "Das Gesamtguthaben zeigt alle EFHC, die Sie derzeit im",
        "Bot haben. Es hilft beim Gesamtüberblick, ist aber nicht",
        "gleich dem Betrag für die Auszahlung.",
      ]),
      ["Gesamtguthaben", "alle Mittel", "Saldo gesamt"],
    ),
    "1.1-2": item(
      "Was ist das Hauptguthaben?",
      j([
        "Das Hauptguthaben ist der Teil Ihrer Mittel für wichtige",
        "Aktionen im Projekt. Dieses Guthaben wird für",
        "Auszahlungen verwendet.",
      ]),
      ["Hauptguthaben", "Auszahlung"],
    ),
    "1.1-3": item(
      "Was ist das Bonusguthaben?",
      j([
        "Das Bonusguthaben ist der interne Teil Ihrer Mittel im",
        "Bot. Es wird für Spielaktionen und Käufe im Bot genutzt,",
        "aber nicht für Auszahlungen.",
      ]),
      ["Bonusguthaben", "Bonusmittel"],
    ),
    "1.1-4": item(
      "Was ist der Unterschied zwischen Gesamt, Haupt und Bonus?",
      j([
        "Das Gesamtguthaben umfasst alle Mittel im Bot. Das",
        "Hauptguthaben wird für Tausch und Auszahlung genutzt. Das",
        "Bonusguthaben dient internen Aktionen und Käufen.",
      ]),
      ["Unterschied Guthaben", "Haupt", "Bonus", "Gesamt"],
    ),
    "1.2-1": item(
      "Warum kann ich nicht das ganze Gesamtguthaben auszahlen?",
      j([
        "Weil das Gesamtguthaben sowohl Haupt- als auch Bonus-EFHC",
        "enthält. Für Auszahlungen wird nur das Hauptguthaben",
        "verwendet.",
      ]),
      ["Auszahlung", "Gesamtguthaben", "warum nicht"],
    ),
    "1.2-2": item(
      "Warum kann ein Kauf Bonus- und Hauptguthaben betreffen?",
      j([
        "Weil der Bot interne Mittel schrittweise für eine Aktion",
        "nutzen kann. Dadurch kann ein Kauf zwei Guthaben zugleich",
        "verringern.",
      ]),
      ["Kauf", "zwei Guthaben", "Haupt und Bonus"],
    ),
    "2.1-1": item(
      "Was zeigt die Guthabenhistorie?",
      j([
        "Die Guthabenhistorie zeigt Änderungen Ihrer Mittel:",
        "Eingänge, Ausgaben und andere Aktionen, die Ihr Guthaben",
        "im Bot beeinflusst haben.",
      ]),
      ["Guthabenhistorie", "Aktionen", "Historie"],
    ),
    "2.1-2": item(
      "Welche Aktionen erscheinen in der Guthabenhistorie?",
      j([
        "Die Historie zeigt Aktionen, die Haupt- oder",
        "Bonusguthaben ändern: Belohnungen, Ausgaben, Käufe,",
        "Tausch und andere Bot-Aktionen.",
      ]),
      ["Historie", "Aktionen", "Belohnungen", "Ausgaben"],
    ),
    "2.1-3": item(
      "Warum hat sich mein Guthaben geändert?",
      j([
        "Ihr Guthaben ändert sich nach Aktionen im Bot: Käufen,",
        "Bonusbelohnungen, Energietausch, Auszahlung und anderen",
        "Vorgängen. Die Historie zeigt den Grund.",
      ]),
      ["Guthaben geändert", "warum"],
    ),
    "2.1-4": item(
      "Wie erkenne ich, warum Mittel ein- oder ausgingen?",
      j([
        "Öffnen Sie die Guthabenhistorie und prüfen Sie die",
        "Beschreibung der Aktion. Dort sehen Sie, was den Eingang",
        "oder die Ausgabe verursacht hat.",
      ]),
      ["warum", "Eingang", "Ausgabe", "Historie"],
    ),
    "3.1-1": item(
      "Was ist ein Panel?",
      j([
        "Ein Panel ist die Grundlage Ihres Spiel- und",
        "Energiefortschritts im EFHC Bot. Nach dem Kauf nimmt es an",
        "der Energieerzeugung im Projekt teil.",
      ]),
      ["Panel", "Solarpanel"],
    ),
    "3.1-2": item(
      "Was bringt mir ein Panel?",
      j([
        "Ein Panel bringt Ihnen Energieerzeugung, Fortschritt im",
        "Projekt und eine Basis für den späteren Tausch von",
        "Energie in EFHC.",
      ]),
      ["was Panel gibt", "Erzeugung", "Fortschritt"],
    ),
    "3.1-3": item(
      "Wie kaufe ich ein Panel?",
      j([
        "Öffnen Sie den Bereich Panels, wählen Sie den Kauf und",
        "bestätigen Sie ihn. Nach erfolgreichem Kauf erscheint das",
        "Panel in Ihrer Liste.",
      ]),
      ["Panel kaufen", "Panels"],
    ),
    "3.1-4": item(
      "Was passiert, wenn ich mehrere Panels habe?",
      j([
        "Wenn Sie mehrere Panels haben, trägt jedes zu Ihrem",
        "gesamten Fortschritt bei und erhöht die Energiemenge im",
        "Projekt.",
      ]),
      ["mehrere Panels", "viele Panels"],
    ),
    "3.1-5": item(
      "Was bedeutet Panel-Archiv?",
      j([
        "Ein Panel im Archiv bedeutet, dass dieser Zyklus nicht",
        "mehr im aktiven Teil des Bildschirms ist, aber weiter Teil",
        "Ihres Fortschritts bleibt.",
      ]),
      ["Panel-Archiv", "Archiv"],
    ),
    "3.2-1": item(
      "Wie entsteht Energie?",
      j([
        "Energie entsteht durch Ihre Panels. Die Panels sorgen",
        "dafür, dass die Energie im Bot wächst.",
      ]),
      ["wie Energie entsteht", "Energie"],
    ),
    "3.2-2": item(
      "Was ist verfügbare Energie?",
      j([
        "Verfügbare Energie ist der Teil der Energie, den Sie im",
        "Rahmen der Projektmechanik weiter nutzen können.",
      ]),
      ["verfügbare Energie", "nutzbare Energie"],
    ),
    "3.2-3": item(
      "Warum erzeugt ein Panel manchmal nicht?",
      j([
        "Meist hängt das mit dem Status des Panels, seinem Zyklus",
        "oder damit zusammen, dass Sie einen nicht aktiven Teil des",
        "Bildschirms sehen.",
      ]),
      ["erzeugt nicht", "Panel funktioniert nicht"],
    ),
    "4.1-1": item(
      "Was ist der Tausch?",
      j([
        "Der Tausch ist die Aktion, bei der Ihre verfügbare Energie",
        "nach den Projektregeln in EFHC umgewandelt wird.",
      ]),
      ["Tausch", "Energie umwandeln"],
    ),
    "4.1-2": item(
      "Was passiert nach dem Tausch?",
      j([
        "Nach dem Tausch wird ein Teil Ihrer Energie als genutzt",
        "verbucht und EFHC werden Ihrem Hauptguthaben gutgeschrieben.",
      ]),
      ["nach Tausch", "Hauptguthaben"],
    ),
    "4.1-3": item(
      "Wann brauche ich zuerst einen Tausch und wann Auszahlung?",
      j([
        "Wenn Sie Energie haben, aber noch nicht genug im",
        "Hauptguthaben, brauchen Sie zuerst den Tausch. Die",
        "Auszahlung nutzt das Hauptguthaben.",
      ]),
      ["zuerst Tausch", "dann Auszahlung"],
    ),
    "4.2-1": item(
      "Was ist eine Auszahlung?",
      j([
        "Die Auszahlung ist die Aktion, mit der EFHC nach den",
        "Projektregeln aus dem Hauptguthaben gesendet werden.",
      ]),
      ["Auszahlung", "auszahlen"],
    ),
    "4.2-2": item(
      "Warum kann ich das Bonusguthaben nicht auszahlen?",
      j([
        "Weil das Bonusguthaben für interne Aktionen im Bot gedacht",
        "ist. Für Auszahlungen wird nur das Hauptguthaben genutzt.",
      ]),
      ["Bonusguthaben", "nicht auszahlen"],
    ),
    "4.2-3": item(
      "Warum ist die Auszahlung manchmal nicht verfügbar?",
      j([
        "Die Auszahlung ist nicht immer sofort verfügbar, weil sie",
        "vom Zustand Ihres Hauptguthabens und den Regeln der Aktion",
        "abhängt.",
      ]),
      ["Auszahlung nicht verfügbar", "warum"],
    ),
    "4.2-4": item(
      "Warum hat sich mein Hauptguthaben nach der Auszahlung geändert?",
      j([
        "Nach dem Erstellen einer Auszahlung wird der Betrag im",
        "Hauptguthaben sofort für diese Aktion berücksichtigt.",
      ]),
      ["Hauptguthaben geändert", "nach Auszahlung"],
    ),

    "5.1-1": item(
      "Wozu brauche ich eine Wallet?",
      j([
        "Die Wallet wird für Aktionen benötigt, bei denen das",
        "Projekt eine externe Bestätigung und die Verbindung zu",
        "Ihrer Adresse braucht. Sie ist auch für VIP NFT und",
        "ähnliche Aktionen wichtig.",
      ]),
      ["wallet", "wozu wallet"],
    ),
    "5.1-2": item(
      "Wie verbinde ich eine Wallet?",
      j([
        "Öffnen Sie den Bereich Wallet, wählen Sie die Verbindung",
        "und bestätigen Sie die Aktion in einer unterstützten",
        "Wallet-App.",
      ]),
      ["wallet verbinden", "connect wallet"],
    ),
    "5.1-3": item(
      "Was ist die Haupt-Wallet?",
      j([
        "Die Haupt-Wallet ist die Wallet, die der Bot als wichtigste",
        "für Aktionen nutzt, bei denen eine vom Nutzer gewählte",
        "Adresse benötigt wird.",
      ]),
      ["Haupt-Wallet", "primary wallet"],
    ),
    "5.1-4": item(
      "Kann ich mehrere Wallets verbinden?",
      j([
        "Ja. Im Bot können mehrere verbundene Wallets gespeichert",
        "werden, und Sie können daraus eine Haupt-Wallet wählen.",
      ]),
      ["mehrere Wallets", "primary wallet"],
    ),
    "5.1-5": item(
      "Was tun, wenn sich die Wallet nicht verbindet?",
      j([
        "Prüfen Sie, ob eine passende Wallet geöffnet ist, die",
        "Verbindung zur Telegram Mini App besteht und Sie die",
        "Verbindung in der Wallet selbst bestätigen. Versuchen Sie",
        "es danach erneut.",
      ]),
      ["wallet problem", "verbindet nicht"],
    ),
    "6.1-1": item(
      "Was sind Referrals?",
      j([
        "Referrals sind Nutzer, die über Ihren Link in das Projekt",
        "gekommen sind und danach Ihren Fortschritt nach den Regeln",
        "des Referral-Systems beeinflussen.",
      ]),
      ["Referrals", "Einladungen"],
    ),
    "6.1-2": item(
      "Wie funktioniert mein Referral-Link?",
      j([
        "Sie teilen Ihren Link mit einem neuen Nutzer. Wenn er über",
        "diesen Link ins Projekt kommt, wird er in Ihrem",
        "Referral-System berücksichtigt.",
      ]),
      ["Referral-Link", "invite link"],
    ),
    "6.1-3": item(
      "Wer gilt als aktiver Referral?",
      j([
        "Als aktiv gilt ein Referral, der die nötige Bedingung im",
        "Projekt bereits erfüllt hat und in Ihrer aktiven Statistik",
        "erscheint.",
      ]),
      ["aktiver Referral", "active referral"],
    ),
    "6.1-4": item(
      "Wer gilt als inaktiver Referral?",
      j([
        "Ein inaktiver Referral ist ein Nutzer über Ihren Link, der",
        "die Bedingung für den aktiven Status noch nicht erfüllt",
        "hat.",
      ]),
      ["inaktiver Referral", "inactive referral"],
    ),
    "6.1-5": item(
      "Was zeigen die Zähler auf der Referral-Seite?",
      j([
        "Die Zähler zeigen, wie viele Referrals Sie insgesamt haben,",
        "wie viele davon aktiv sind und wie sich das auf Ihren",
        "Fortschritt im Projekt auswirkt.",
      ]),
      ["Referral-Zähler", "Statistik"],
    ),
    "6.1-6": item(
      "Wie funktioniert der Fortschritt bis zur nächsten Stufe?",
      j([
        "Der Fortschritt zeigt, wie viel Ihnen noch für den nächsten",
        "Schritt in Ihrer Referral-Linie fehlt. So sehen Sie schnell,",
        "wie nah Sie der nächsten Stufe oder dem nächsten Bonus sind.",
      ]),
      ["Fortschritt", "nächste Stufe"],
    ),
    "7.1-1": item(
      "Was ist VIP NFT?",
      j([
        "VIP NFT ist ein spezielles NFT des Projekts, das dem",
        "Nutzer einen VIP-Effekt nach den Regeln von EFHC Bot",
        "gibt.",
      ]),
      ["VIP NFT", "VIP"],
    ),
    "7.1-2": item(
      "Was bringt VIP NFT?",
      j([
        "VIP NFT gibt besondere Vorteile im Projekt. In der",
        "Oberfläche ist das mit dem VIP-Status und den zugehörigen",
        "Effekten verbunden.",
      ]),
      ["VIP NFT", "VIP-Status"],
    ),
    "7.1-3": item(
      "Brauche ich eine verbundene Wallet für VIP NFT?",
      j([
        "Ja. Damit der Bot Ihr VIP NFT sehen und korrekt mit dem",
        "Status verknüpfen kann, brauchen Sie eine verbundene",
        "Wallet.",
      ]),
      ["Wallet", "VIP NFT"],
    ),
    "7.1-4": item(
      "Wann wird der VIP-Status aktiv?",
      j([
        "Wenn der Bot das passende NFT in der verbundenen Wallet",
        "sieht, wird der VIP-Status nach den Projektregeln",
        "automatisch aktualisiert.",
      ]),
      ["VIP-Status", "aktiv"],
    ),
    "7.1-5": item(
      "Was tun, wenn das NFT da ist, der Status aber fehlt?",
      j([
        "Prüfen Sie, ob sich das NFT in der richtigen verbundenen",
        "Wallet befindet und diese Wallet im Bot aktuell ist.",
        "Aktualisieren Sie danach den Bildschirm und prüfen Sie den",
        "Status erneut.",
      ]),
      ["NFT", "Status fehlt"],
    ),
    "8.1-1": item(
      "Was ist Shop?",
      j([
        "Shop ist der Bereich, in dem der Nutzer In-Game-Elemente",
        "und Dinge für das Design des Projekts kaufen kann.",
      ]),
      ["Shop", "Store"],
    ),
    "8.1-2": item(
      "Was kann ich im Shop kaufen?",
      j([
        "Im Shop können Sie verfügbare Produkte des Projekts kaufen,",
        "zum Beispiel Skins und andere passende Elemente, die der",
        "Bot aktuell im Shop zeigt.",
      ]),
      ["Shop", "kaufen"],
    ),
    "8.1-3": item(
      "Worin unterscheidet sich Kauf für EFHC vom Wallet-Kauf?",
      j([
        "Ein Kauf für EFHC nutzt Ihre Mittel im Bot. Ein Kauf über",
        "die Wallet ist mit einer externen Bestätigung über Ihre",
        "Wallet verbunden.",
      ]),
      ["EFHC-Kauf", "Wallet-Kauf"],
    ),
    "8.1-4": item(
      "Warum ist im Shop manchmal nichts zu sehen?",
      j([
        "Das ist möglich, wenn für Ihren Bildschirm gerade keine",
        "Produkte verfügbar sind oder der Bereich noch nicht mit",
        "passenden Positionen gefüllt wurde.",
      ]),
      ["Shop leer", "nichts sichtbar"],
    ),
    "8.2-1": item(
      "Was sind Skins?",
      j([
        "Skins sind Elemente des visuellen Designs, die das Aussehen",
        "von Teilen der Oberfläche im Projekt verändern.",
      ]),
      ["Skins", "Design"],
    ),
    "8.2-2": item(
      "Worin unterscheiden sich normale Skins von Level-Designs?",
      j([
        "Normale Skins sind verfügbare Käufe oder Designelemente.",
        "Level-Designs hängen mit Ihrem Fortschritt zusammen und",
        "werden beim Erreichen bestimmter Stufen verfügbar.",
      ]),
      ["Skins", "Level-Designs"],
    ),
    "8.2-3": item(
      "Wie kaufe und aktiviere ich einen Skin?",
      j([
        "Kaufen Sie zuerst einen verfügbaren Skin im Shop, wählen",
        "Sie ihn dann unter Ihren verfügbaren Designs aus und",
        "aktivieren Sie ihn in der Oberfläche.",
      ]),
      ["Skin kaufen", "Skin aktivieren"],
    ),
    "9.1-1": item(
      "Wie fülle ich mein Guthaben auf?",
      j([
        "Öffnen Sie den Bereich für Aufladung oder Kauf und folgen",
        "Sie dem angebotenen Weg. Je nach Bildschirm kann dafür",
        "eine Wallet-Bestätigung nötig sein.",
      ]),
      ["aufladen", "guthaben aufladen"],
    ),
    "9.1-2": item(
      "Wann brauche ich für einen Kauf eine Wallet?",
      j([
        "Eine Wallet ist nötig, wenn der Kauf über eine externe",
        "Zahlung und Bestätigung erfolgt. Für interne Käufe im Bot",
        "ist sie nicht immer erforderlich.",
      ]),
      ["wallet nötig", "kauf wallet"],
    ),
    "9.2-1": item(
      "Wie läuft ein Kauf über die Wallet ab?",
      j([
        "Sie wählen den Kauf im Bot, bestätigen ihn in Ihrer Wallet",
        "und kehren danach zur App zurück. Nach der Bestätigung wird",
        "das Ergebnis im Bot angezeigt.",
      ]),
      ["wallet kauf", "zahlung wallet"],
    ),
    "9.2-3": item(
      "Was passiert nach der Bezahlung?",
      j([
        "Nach erfolgreicher Zahlung aktualisiert der Bot das Ergebnis",
        "der Operation. Manchmal geschieht das sofort, manchmal nach",
        "einer kurzen Verarbeitung.",
      ]),
      ["nach zahlung", "ergebnis"],
    ),
    "10.1-1": item(
      "Was ist ein Level?",
      j([
        "Das Level zeigt Ihren Fortschritt im Projekt. Je mehr Sie",
        "am Spiel- und Energiesystem teilnehmen, desto höher kann",
        "Ihr Level werden.",
      ]),
      ["level", "fortschritt"],
    ),
    "10.1-2": item(
      "Was ist ein Rang?",
      j([
        "Der Rang zeigt Ihre Position im Vergleich zu anderen",
        "Teilnehmern. Er hilft zu verstehen, welchen Platz Sie im",
        "gemeinsamen Fortschritt einnehmen.",
      ]),
      ["rang", "platz"],
    ),
    "10.1-3": item(
      "Worin unterscheidet sich das Level vom Rang?",
      j([
        "Das Level zeigt Ihren persönlichen Fortschritt. Der Rang",
        "zeigt Ihre Position im Vergleich zu anderen Nutzern.",
      ]),
      ["level rang", "unterschied"],
    ),
    "10.1-4": item(
      "Was zeigt die Seite Ranks?",
      j([
        "Die Seite Ranks zeigt Ihre Position und die Plätze anderer",
        "Teilnehmer. So sehen Sie Ihren Fortschritt im Vergleich zur",
        "restlichen Gemeinschaft.",
      ]),
      ["ranks", "rang seite"],
    ),
    "11.1-1": item(
      "Warum kann ich keine Mittel auszahlen?",
      j([
        "Das kann passieren, wenn für die Auszahlung im Moment nicht",
        "genug Main-Guthaben vorhanden ist oder der nötige Schritt im",
        "Bot noch nicht abgeschlossen wurde.",
      ]),
      ["auszahlung nicht möglich", "kein withdraw"],
    ),
    "11.1-2": item(
      "Warum verbindet sich die Wallet nicht?",
      j([
        "Prüfen Sie, ob die Wallet-App geöffnet ist, die Verbindung",
        "bestätigt wurde und ob Ihr Gerät die Verbindung mit dem Bot",
        "nicht blockiert. Versuchen Sie danach die Verbindung erneut.",
      ]),
      ["wallet verbindet nicht", "wallet fehler"],
    ),
    "11.1-3": item(
      "Warum erzeugt meine Panel keine Energie?",
      j([
        "Prüfen Sie den Status Ihrer Panel und ob der Zyklus schon",
        "läuft. Wenn die Panel inaktiv oder archiviert ist, sehen Sie",
        "keine erwartete Erzeugung.",
      ]),
      ["panel erzeugt nicht", "keine energie"],
    ),
    "11.1-4": item(
      "Warum wird der VIP-Status nicht angezeigt?",
      j([
        "Prüfen Sie, ob die richtige Wallet verbunden ist und ob das",
        "NFT in ihr verfügbar ist. Danach öffnen Sie den Bereich noch",
        "einmal und warten kurz auf die Aktualisierung.",
      ]),
      ["vip status", "vip nicht sichtbar"],
    ),
    "11.1-5": item(
      "Warum ist mein Bonus nicht angekommen?",
      j([
        "Prüfen Sie zuerst, ob die Aktion die Bedingungen für den",
        "Bonus erfüllt hat. Manche Boni erscheinen nicht sofort,",
        "sondern nach der Verarbeitung im Bot.",
      ]),
      ["bonus nicht da", "bonus fehlt"],
    ),
    "11.1-6": item(
      "Warum ist mein Referrer inaktiv?",
      j([
        "Ein Referrer bleibt inaktiv, wenn er die nötige Aktion für",
        "die Aktivierung noch nicht ausgeführt hat. In der Regel ist",
        "das mit seinem Fortschritt im Bot verbunden.",
      ]),
      ["inaktiver referrer", "referrer inaktiv"],
    ),
    "11.1-7": item(
      "Warum ist der Shop leer?",
      j([
        "Der Shop kann leer wirken, wenn für Ihren Bildschirm derzeit",
        "keine passenden Angebote angezeigt werden oder der Bereich",
        "noch nicht mit Positionen gefüllt wurde.",
      ]),
      ["shop leer", "nichts im shop"],
    ),
    "12.1-1": item(
      "Wie suche ich im FAQ nach Wörtern?",
      j([
        "Geben Sie in die Suchzeile ein klares Wort aus der",
        "Oberfläche ein, zum Beispiel Balance, Wallet, Panel,",
        "Exchange oder Withdraw.",
      ]),
      ["faq suche", "wortsuche"],
    ),
    "12.1-2": item(
      "Wo finde ich eine Frage zum Guthaben?",
      j([
        "Suchen Sie in den Abschnitten Balances und Balance History.",
        "Dort wird erklärt, was die sichtbaren Werte bedeuten und",
        "warum sie sich ändern.",
      ]),
      ["frage guthaben", "balance history"],
    ),
    "12.1-3": item(
      "Wo finde ich eine Frage zur Wallet?",
      j([
        "Öffnen Sie den Abschnitt Wallet. Dort finden Sie Fragen zur",
        "Verbindung, zur Haupt-Wallet und zu Problemen bei der",
        "Verbindung.",
      ]),
      ["frage wallet", "wallet abschnitt"],
    ),
    "12.1-4": item(
      "Was soll ich tun, wenn ich keine Antwort gefunden habe?",
      j([
        "Versuchen Sie ein anderes klares Wort aus der Oberfläche",
        "oder öffnen Sie einen thematisch nahen Abschnitt. Für Fragen",
        "zu Wallet, History, Panels oder Exchange suchen Sie genau",
        "nach diesen Wörtern.",
      ]),
      ["keine antwort", "anderes wort"],
    ),
  },
  fr: {
    "1.1-1": item(
      "Qu'est-ce que le solde total ?",
      j([
        "Le solde total montre tous les EFHC que vous avez dans le",
        "bot. Il est utile pour voir l'ensemble de vos ressources,",
        "mais ce n'est pas le montant retirable.",
      ]),
      ["solde total", "tous les fonds", "solde global"],
    ),
    "1.1-2": item(
      "Qu'est-ce que le solde principal ?",
      j([
        "Le solde principal est la partie de vos fonds utilisée pour",
        "les actions clés du projet. C'est ce solde qui sert au",
        "retrait.",
      ]),
      ["solde principal", "retrait"],
    ),
    "1.1-3": item(
      "Qu'est-ce que le solde bonus ?",
      j([
        "Le solde bonus est la partie interne de vos fonds dans le",
        "bot. Il sert aux actions et achats internes, mais pas au",
        "retrait.",
      ]),
      ["solde bonus", "fonds bonus"],
    ),
    "1.1-4": item(
      "Quelle est la différence entre total, principal et bonus ?",
      j([
        "Le solde total regroupe tous vos fonds dans le bot. Le",
        "solde principal sert à l'échange et au retrait. Le solde",
        "bonus sert aux actions et achats internes.",
      ]),
      ["différence des soldes", "principal", "bonus", "total"],
    ),
    "1.2-1": item(
      "Pourquoi ne puis-je pas retirer tout le solde total ?",
      j([
        "Parce que le solde total comprend les EFHC principaux et",
        "bonus. Seul le solde principal est utilisé pour le retrait.",
      ]),
      ["retrait", "solde total", "pourquoi"],
    ),
    "1.2-2": item(
      "Pourquoi un achat peut-il toucher bonus et principal ?",
      j([
        "Parce que le bot peut utiliser vos fonds internes étape par",
        "étape pour une même action. Un achat peut donc réduire deux",
        "soldes à la fois.",
      ]),
      ["achat", "deux soldes", "principal et bonus"],
    ),
    "2.1-1": item(
      "Que montre l'historique du solde ?",
      j([
        "L'historique du solde montre les changements de vos fonds :",
        "entrées, dépenses et autres actions ayant affecté votre",
        "solde dans le bot.",
      ]),
      ["historique du solde", "actions", "historique"],
    ),
    "2.1-2": item(
      "Quelles actions apparaissent dans l'historique ?",
      j([
        "L'historique montre les actions qui changent le solde",
        "principal ou bonus : récompenses, dépenses, achats, échange",
        "et autres actions du bot.",
      ]),
      ["historique", "actions", "récompenses", "dépenses"],
    ),
    "2.1-3": item(
      "Pourquoi mon solde a-t-il changé ?",
      j([
        "Votre solde change après des actions dans le bot : achats,",
        "bonus, échange d'énergie, retrait et autres opérations.",
        "L'historique aide à voir la raison.",
      ]),
      ["solde changé", "pourquoi"],
    ),
    "2.1-4": item(
      "Comment savoir pourquoi des fonds sont entrés ou sortis ?",
      j([
        "Ouvrez l'historique du solde et regardez la description de",
        "l'action. Elle montre ce qui a causé l'entrée ou la",
        "dépense.",
      ]),
      ["pourquoi", "entrée", "dépense", "historique"],
    ),
    "3.1-1": item(
      "Qu'est-ce qu'un panneau ?",
      j([
        "Un panneau est la base de votre progression de jeu et",
        "d'énergie dans EFHC Bot. Après l'achat, il participe à la",
        "génération d'énergie du projet.",
      ]),
      ["panneau", "panneau solaire"],
    ),
    "3.1-2": item(
      "Que m'apporte un panneau ?",
      j([
        "Un panneau vous apporte de la génération d'énergie, de la",
        "progression dans le projet et une base pour échanger plus",
        "tard l'énergie en EFHC.",
      ]),
      ["ce que donne un panneau", "génération", "progression"],
    ),
    "3.1-3": item(
      "Comment acheter un panneau ?",
      j([
        "Ouvrez la section Panels, choisissez l'achat et",
        "confirmez-le. Après un achat réussi, le panneau",
        "apparaîtra dans votre liste.",
      ]),
      ["acheter un panneau", "panels"],
    ),
    "3.1-4": item(
      "Que se passe-t-il si j'ai plusieurs panneaux ?",
      j([
        "Si vous avez plusieurs panneaux, chacun contribue à votre",
        "progression générale et augmente la quantité d'énergie dans",
        "le projet.",
      ]),
      ["plusieurs panneaux", "beaucoup de panneaux"],
    ),
    "3.1-5": item(
      "Que signifie l'archive du panneau ?",
      j([
        "Un panneau dans l'archive signifie que ce cycle n'est plus",
        "dans la partie active de l'écran, mais reste dans",
        "l'historique de votre progression.",
      ]),
      ["archive du panneau", "archive"],
    ),
    "3.2-1": item(
      "Comment l'énergie apparaît-elle ?",
      j([
        "L'énergie apparaît grâce à vos panneaux. Ce sont eux qui",
        "font croître l'énergie dans le bot.",
      ]),
      ["comment l'énergie apparaît", "énergie"],
    ),
    "3.2-2": item(
      "Qu'est-ce que l'énergie disponible ?",
      j([
        "L'énergie disponible est la partie de l'énergie que vous",
        "pouvez utiliser ensuite dans les mécaniques du projet.",
      ]),
      ["énergie disponible", "énergie utilisable"],
    ),
    "3.2-3": item(
      "Pourquoi un panneau peut-il ne plus générer ?",
      j([
        "Cela est généralement lié à l'état du panneau, à son cycle",
        "ou au fait que vous regardez une partie non active de",
        "l'écran.",
      ]),
      ["ne génère pas", "panneau ne fonctionne pas"],
    ),
    "4.1-1": item(
      "Qu'est-ce que l'échange ?",
      j([
        "L'échange est l'action par laquelle votre énergie",
        "disponible est convertie en EFHC selon les règles du",
        "projet.",
      ]),
      ["échange", "convertir l'énergie"],
    ),
    "4.1-2": item(
      "Que se passe-t-il après l'échange ?",
      j([
        "Après l'échange, une partie de votre énergie est comptée",
        "comme utilisée et des EFHC sont ajoutés à votre solde",
        "principal.",
      ]),
      ["après l'échange", "solde principal"],
    ),
    "4.1-3": item(
      "Quand faut-il d'abord échanger, puis retirer ?",
      j([
        "Si vous avez de l'énergie mais pas encore assez de fonds",
        "dans le solde principal, il faut d'abord faire l'échange.",
        "Le retrait utilise le solde principal.",
      ]),
      ["d'abord échange", "puis retrait"],
    ),
    "4.2-1": item(
      "Qu'est-ce que le retrait ?",
      j([
        "Le retrait est l'action qui permet d'envoyer des EFHC à",
        "partir du solde principal selon les règles du projet.",
      ]),
      ["retrait", "retirer"],
    ),
    "4.2-2": item(
      "Pourquoi ne puis-je pas retirer le solde bonus ?",
      j([
        "Parce que le solde bonus est destiné aux actions internes",
        "du bot. Seul le solde principal est utilisé pour le",
        "retrait.",
      ]),
      ["solde bonus", "ne pas retirer"],
    ),
    "4.2-3": item(
      "Pourquoi le retrait n'est-il parfois pas disponible ?",
      j([
        "Le retrait n'est pas toujours disponible immédiatement, car",
        "il dépend de l'état de votre solde principal et des règles",
        "de l'opération.",
      ]),
      ["retrait indisponible", "pourquoi"],
    ),
    "4.2-4": item(
      "Pourquoi mon solde principal a-t-il changé après le retrait ?",
      j([
        "Après la création d'un retrait, le montant est tout de",
        "suite pris en compte dans le solde principal pour cette",
        "action.",
      ]),
      ["solde principal changé", "après retrait"],
    ),

    "5.1-1": item(
      "À quoi sert le Wallet ?",
      j([
        "Le Wallet est nécessaire pour les actions où le projet a",
        "besoin d'une confirmation externe et d'un lien avec votre",
        "adresse. Il est aussi important pour VIP NFT et les actions",
        "associées.",
      ]),
      ["wallet", "à quoi sert wallet"],
    ),
    "5.1-2": item(
      "Comment connecter un Wallet ?",
      j([
        "Ouvrez la section Wallet, choisissez la connexion puis",
        "confirmez l'action dans une application de Wallet",
        "compatible.",
      ]),
      ["connecter wallet", "wallet connect"],
    ),
    "5.1-3": item(
      "Qu'est-ce que le Wallet principal ?",
      j([
        "Le Wallet principal est celui que le bot utilise comme",
        "Wallet principal pour les actions où une adresse choisie par",
        "l'utilisateur est nécessaire.",
      ]),
      ["wallet principal", "primary wallet"],
    ),
    "5.1-4": item(
      "Puis-je connecter plusieurs Wallets ?",
      j([
        "Oui. Le bot peut stocker plusieurs Wallets connectés et",
        "vous permettre d'en choisir un comme principal.",
      ]),
      ["plusieurs wallets", "wallet principal"],
    ),
    "5.1-5": item(
      "Que faire si le Wallet ne se connecte pas ?",
      j([
        "Vérifiez qu'un Wallet compatible est ouvert, que la liaison",
        "avec Telegram Mini App n'est pas rompue et que vous",
        "confirmez bien la connexion dans le Wallet.",
        "Ensuite, essayez encore.",
      ]),
      ["wallet problème", "ne se connecte pas"],
    ),
    "6.1-1": item(
      "Que sont les referrals ?",
      j([
        "Les referrals sont les utilisateurs venus dans le projet",
        "grâce à votre lien et qui influencent ensuite votre",
        "progression selon les règles du système de referrals.",
      ]),
      ["referrals", "invitations"],
    ),
    "6.1-2": item(
      "Comment fonctionne mon lien de referral ?",
      j([
        "Vous partagez votre lien avec un nouvel utilisateur. S'il",
        "entre dans le projet grâce à ce lien, il est pris en compte",
        "dans votre système de referrals.",
      ]),
      ["lien referral", "invite link"],
    ),
    "6.1-3": item(
      "Qui est considéré comme referral actif ?",
      j([
        "Un referral est actif lorsqu'il a déjà rempli la condition",
        "requise dans le projet et apparaît dans vos statistiques",
        "actives.",
      ]),
      ["referral actif", "active referral"],
    ),
    "6.1-4": item(
      "Qui est considéré comme referral inactif ?",
      j([
        "Un referral inactif est un utilisateur venu par votre lien",
        "qui n'a pas encore rempli la condition nécessaire pour le",
        "statut actif.",
      ]),
      ["referral inactif", "inactive referral"],
    ),
    "6.1-5": item(
      "Que montrent les compteurs sur la page Referrals ?",
      j([
        "Les compteurs montrent combien de referrals vous avez au",
        "total, combien sont actifs et comment cela influence votre",
        "progression dans le projet.",
      ]),
      ["compteurs referrals", "statistiques"],
    ),
    "6.1-6": item(
      "Comment fonctionne la progression jusqu'au niveau suivant ?",
      j([
        "La progression montre ce qu'il vous manque pour l'étape",
        "suivante dans votre ligne de referrals. Elle aide à voir",
        "rapidement combien il reste jusqu'au prochain niveau ou",
        "bonus.",
      ]),
      ["progression", "niveau suivant"],
    ),
    "7.1-1": item(
      "Qu'est-ce que VIP NFT ?",
      j([
        "VIP NFT est un NFT spécial du projet qui donne à",
        "l'utilisateur un effet VIP selon les règles de EFHC Bot.",
      ]),
      ["VIP NFT", "VIP"],
    ),
    "7.1-2": item(
      "Que donne VIP NFT ?",
      j([
        "VIP NFT donne des avantages spéciaux dans le projet. Dans",
        "l'interface, cela est lié au statut VIP et aux effets",
        "correspondants.",
      ]),
      ["VIP NFT", "statut VIP"],
    ),
    "7.1-3": item(
      "Ai-je besoin d'un Wallet connecté pour VIP NFT ?",
      j([
        "Oui. Pour que le bot voie votre VIP NFT et le relie",
        "correctement au statut, un Wallet connecté est nécessaire.",
      ]),
      ["wallet", "VIP NFT"],
    ),
    "7.1-4": item(
      "Quand le statut VIP devient-il actif ?",
      j([
        "Quand le bot voit le NFT approprié dans le Wallet connecté,",
        "le statut VIP se met à jour automatiquement selon les règles",
        "du projet.",
      ]),
      ["statut VIP", "actif"],
    ),
    "7.1-5": item(
      "Que faire si le NFT existe mais que le statut n'apparaît pas ?",
      j([
        "Vérifiez que le NFT se trouve dans le bon Wallet connecté",
        "et que ce Wallet est bien actuel dans le bot. Ensuite,",
        "actualisez l'écran et vérifiez de nouveau le statut.",
      ]),
      ["NFT", "statut absent"],
    ),
    "8.1-1": item(
      "Qu'est-ce que Shop ?",
      j([
        "Shop est la section où l'utilisateur peut acheter des",
        "éléments internes au jeu et des éléments liés au design du",
        "projet.",
      ]),
      ["shop", "magasin"],
    ),
    "8.1-2": item(
      "Que peut-on acheter dans Shop ?",
      j([
        "Dans Shop, vous pouvez acheter les produits disponibles du",
        "projet, par exemple des skins et d'autres éléments adaptés",
        "que le bot affiche actuellement dans le magasin.",
      ]),
      ["shop", "acheter"],
    ),
    "8.1-3": item(
      "Quelle différence entre achat en EFHC et achat via Wallet ?",
      j([
        "L'achat en EFHC utilise vos fonds internes au bot. L'achat",
        "via Wallet est lié à une confirmation externe dans votre",
        "Wallet.",
      ]),
      ["achat EFHC", "achat wallet"],
    ),
    "8.1-4": item(
      "Pourquoi Shop peut-il être vide ?",
      j([
        "C'est possible s'il n'y a actuellement aucun produit",
        "disponible pour votre écran ou si la section n'est pas",
        "encore remplie avec les bonnes positions.",
      ]),
      ["shop vide", "rien affiché"],
    ),
    "8.2-1": item(
      "Que sont les skins ?",
      j([
        "Les skins sont des éléments visuels qui changent l'apparence",
        "de certaines parties de l'interface dans le projet.",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "Quelle différence entre skins classiques et designs de niveau ?",
      j([
        "Les skins classiques sont des achats disponibles ou des",
        "éléments visuels. Les designs de niveau sont liés à votre",
        "progression et se débloquent à certaines étapes.",
      ]),
      ["skins", "designs de niveau"],
    ),
    "8.2-3": item(
      "Comment acheter et activer un skin ?",
      j([
        "Achetez d'abord un skin disponible dans Shop, puis",
        "choisissez-le parmi vos designs disponibles et activez-le",
        "dans l'interface.",
      ]),
      ["acheter skin", "activer skin"],
    ),
    "9.1-1": item(
      "Comment recharger mon solde ?",
      j([
        "Ouvrez la section de recharge ou d'achat et suivez le",
        "parcours proposé. Selon l'écran, une confirmation dans le",
        "Wallet peut être nécessaire.",
      ]),
      ["recharger", "solde"],
    ),
    "9.1-2": item(
      "Quand faut-il un Wallet pour acheter ?",
      j([
        "Un Wallet est nécessaire quand l'achat passe par un paiement",
        "et une confirmation externes. Pour les achats internes au",
        "bot, il n'est pas toujours requis.",
      ]),
      ["wallet requis", "achat wallet"],
    ),
    "9.2-1": item(
      "Comment se déroule un achat via le Wallet ?",
      j([
        "Vous choisissez l'achat dans le bot, vous le confirmez dans",
        "votre Wallet, puis vous revenez dans l'application. Après la",
        "confirmation, le résultat s'affiche dans le bot.",
      ]),
      ["achat wallet", "paiement wallet"],
    ),
    "9.2-3": item(
      "Que se passe-t-il après le paiement ?",
      j([
        "Après un paiement réussi, le bot met à jour le résultat de",
        "l'opération. Cela peut arriver tout de suite ou après un",
        "court traitement.",
      ]),
      ["après paiement", "résultat"],
    ),
    "10.1-1": item(
      "Qu'est-ce qu'un niveau ?",
      j([
        "Le niveau montre votre progression dans le projet. Plus vous",
        "participez au système de jeu et d'énergie, plus votre niveau",
        "peut monter.",
      ]),
      ["niveau", "progression"],
    ),
    "10.1-2": item(
      "Qu'est-ce qu'un rang ?",
      j([
        "Le rang montre votre position par rapport aux autres",
        "participants. Il aide à comprendre votre place dans la",
        "progression commune.",
      ]),
      ["rang", "position"],
    ),
    "10.1-3": item(
      "Quelle différence entre niveau et rang ?",
      j([
        "Le niveau montre votre progression personnelle. Le rang",
        "montre votre position par rapport aux autres utilisateurs.",
      ]),
      ["niveau rang", "différence"],
    ),
    "10.1-4": item(
      "Que montre la page Ranks ?",
      j([
        "La page Ranks montre votre position et celles des autres",
        "participants. Vous voyez ainsi votre progression par rapport",
        "au reste de la communauté.",
      ]),
      ["ranks", "page rangs"],
    ),
    "11.1-1": item(
      "Pourquoi je ne peux pas retirer des fonds ?",
      j([
        "Cela peut arriver si vous n'avez pas assez de solde main",
        "pour le retrait ou si l'étape nécessaire dans le bot n'est",
        "pas encore terminée.",
      ]),
      ["retrait impossible", "pas de retrait"],
    ),
    "11.1-2": item(
      "Pourquoi le Wallet ne se connecte-t-il pas ?",
      j([
        "Vérifiez que l'application Wallet est ouverte, que la",
        "connexion a bien été confirmée et que votre appareil ne",
        "bloque pas la liaison avec le bot.",
      ]),
      ["wallet ne se connecte pas", "erreur wallet"],
    ),
    "11.1-3": item(
      "Pourquoi ma panel ne génère-t-elle pas d'énergie ?",
      j([
        "Vérifiez le statut de votre panel et si le cycle a déjà",
        "commencé. Si la panel est inactive ou archivée, vous ne",
        "verrez pas la production attendue.",
      ]),
      ["panel ne produit pas", "pas d'énergie"],
    ),
    "11.1-4": item(
      "Pourquoi le statut VIP n'apparaît-il pas ?",
      j([
        "Vérifiez que le bon Wallet est connecté et que le NFT s'y",
        "trouve bien. Ouvrez ensuite la section à nouveau et laissez",
        "un court délai pour la mise à jour.",
      ]),
      ["statut vip", "vip invisible"],
    ),
    "11.1-5": item(
      "Pourquoi mon bonus n'est-il pas arrivé ?",
      j([
        "Vérifiez d'abord que l'action remplissait bien les",
        "conditions du bonus. Certains bonus n'apparaissent pas tout",
        "de suite, mais après le traitement dans le bot.",
      ]),
      ["bonus absent", "bonus manquant"],
    ),
    "11.1-6": item(
      "Pourquoi mon filleul est-il inactif ?",
      j([
        "Un filleul reste inactif tant qu'il n'a pas effectué l'action",
        "requise pour l'activation. Cela dépend généralement de sa",
        "progression dans le bot.",
      ]),
      ["filleul inactif", "inactif"],
    ),
    "11.1-7": item(
      "Pourquoi Shop peut-il être vide ?",
      j([
        "Shop peut sembler vide si aucun produit adapté à votre écran",
        "n'est actuellement disponible ou si la section n'est pas",
        "encore remplie.",
      ]),
      ["shop vide", "rien dans shop"],
    ),
    "12.1-1": item(
      "Comment chercher par mots dans la FAQ ?",
      j([
        "Entrez dans la barre de recherche un mot clair de",
        "l'interface, par exemple balance, Wallet, panel, Exchange ou",
        "Withdraw.",
      ]),
      ["recherche faq", "recherche mot"],
    ),
    "12.1-2": item(
      "Où chercher une question sur le solde ?",
      j([
        "Cherchez dans les sections Balances et History du balance.",
        "Elles expliquent ce que signifient les valeurs visibles et",
        "pourquoi elles changent.",
      ]),
      ["question solde", "history"],
    ),
    "12.1-3": item(
      "Où chercher une question sur le Wallet ?",
      j([
        "Ouvrez la section Wallet. Vous y trouverez les questions sur",
        "la connexion, le Wallet principal et les problèmes de",
        "connexion.",
      ]),
      ["question wallet", "section wallet"],
    ),
    "12.1-4": item(
      "Que faire si je n'ai pas trouvé de réponse ?",
      j([
        "Essayez un autre mot clair vu dans l'interface ou ouvrez une",
        "section proche du sujet. Pour Wallet, History, Panels ou",
        "Exchange, cherchez exactement avec ces mots.",
      ]),
      ["pas de réponse", "autre mot"],
    ),
  },
  es: {
    "1.1-1": item(
      "¿Qué es el saldo total?",
      j([
        "El saldo total muestra todos los EFHC que tiene ahora",
        "dentro del bot. Sirve para ver sus recursos generales,",
        "pero no es igual al monto disponible para retirar.",
      ]),
      ["saldo total", "todos los fondos", "saldo general"],
    ),
    "1.1-2": item(
      "¿Qué es el saldo principal?",
      j([
        "El saldo principal es la parte de sus fondos usada para las",
        "acciones clave del proyecto. Este es el saldo que se usa",
        "para retirar.",
      ]),
      ["saldo principal", "retiro"],
    ),
    "1.1-3": item(
      "¿Qué es el saldo bonus?",
      j([
        "El saldo bonus es la parte interna de sus fondos dentro del",
        "bot. Se usa para acciones y compras internas, pero no para",
        "retirar.",
      ]),
      ["saldo bonus", "fondos bonus"],
    ),
    "1.1-4": item(
      "¿Qué diferencia hay entre total, principal y bonus?",
      j([
        "El saldo total reúne todos sus fondos en el bot. El saldo",
        "principal se usa para intercambio y retiro. El saldo bonus",
        "se usa para acciones y compras internas.",
      ]),
      ["diferencia de saldos", "principal", "bonus", "total"],
    ),
    "1.2-1": item(
      "¿Por qué no puedo retirar todo el saldo total?",
      j([
        "Porque el saldo total incluye EFHC principales y bonus.",
        "Solo el saldo principal se usa para retirar.",
      ]),
      ["retiro", "saldo total", "por qué"],
    ),
    "1.2-2": item(
      "¿Por qué una compra puede tocar bonus y principal?",
      j([
        "Porque el bot puede usar sus fondos internos paso a paso",
        "para una sola acción. Por eso una compra puede reducir dos",
        "saldos a la vez.",
      ]),
      ["compra", "dos saldos", "principal y bonus"],
    ),
    "2.1-1": item(
      "¿Qué muestra el historial de saldo?",
      j([
        "El historial de saldo muestra cambios en sus fondos:",
        "entradas, gastos y otras acciones que afectaron su saldo",
        "dentro del bot.",
      ]),
      ["historial de saldo", "acciones", "historial"],
    ),
    "2.1-2": item(
      "¿Qué acciones aparecen en el historial de saldo?",
      j([
        "El historial muestra acciones que cambian su saldo",
        "principal o bonus: recompensas, gastos, compras,",
        "intercambio y otras acciones del bot.",
      ]),
      ["historial", "acciones", "recompensas", "gastos"],
    ),
    "2.1-3": item(
      "¿Por qué cambió mi saldo?",
      j([
        "Su saldo cambia después de acciones en el bot: compras,",
        "recompensas bonus, intercambio de energía, retiro y otras",
        "operaciones. El historial muestra la causa.",
      ]),
      ["saldo cambió", "por qué"],
    ),
    "2.1-4": item(
      "¿Cómo entiendo por qué entraron o salieron fondos?",
      j([
        "Abra el historial de saldo y revise la descripción de la",
        "acción. Allí verá qué causó la entrada o el gasto.",
      ]),
      ["por qué", "entrada", "gasto", "historial"],
    ),
    "3.1-1": item(
      "¿Qué es un panel?",
      j([
        "Un panel es la base de su progreso de juego y energía en",
        "EFHC Bot. Después de la compra participa en la generación",
        "de energía del proyecto.",
      ]),
      ["panel", "panel solar"],
    ),
    "3.1-2": item(
      "¿Qué me da un panel?",
      j([
        "Un panel le da generación de energía, progreso en el",
        "proyecto y una base para cambiar después la energía por",
        "EFHC.",
      ]),
      ["qué da un panel", "generación", "progreso"],
    ),
    "3.1-3": item(
      "¿Cómo compro un panel?",
      j([
        "Abra la sección Panels, elija la compra y confírmela.",
        "Después de una compra exitosa, el panel aparecerá en su",
        "lista.",
      ]),
      ["comprar panel", "panels"],
    ),
    "3.1-4": item(
      "¿Qué pasa si tengo varios paneles?",
      j([
        "Si tiene varios paneles, cada uno aporta a su progreso",
        "general y aumenta la cantidad de energía dentro del",
        "proyecto.",
      ]),
      ["varios paneles", "muchos paneles"],
    ),
    "3.1-5": item(
      "¿Qué significa el archivo del panel?",
      j([
        "Un panel en archivo significa que ese ciclo ya no está en",
        "la parte activa de la pantalla, pero sigue formando parte",
        "de su historial de progreso.",
      ]),
      ["archivo del panel", "archivo"],
    ),
    "3.2-1": item(
      "¿Cómo aparece la energía?",
      j([
        "La energía aparece gracias a sus paneles. Los paneles son",
        "los que hacen crecer la energía dentro del bot.",
      ]),
      ["cómo aparece la energía", "energía"],
    ),
    "3.2-2": item(
      "¿Qué es la energía disponible?",
      j([
        "La energía disponible es la parte de la energía que puede",
        "usar después dentro de la mecánica del proyecto.",
      ]),
      ["energía disponible", "energía utilizable"],
    ),
    "3.2-3": item(
      "¿Por qué un panel puede dejar de generar?",
      j([
        "Normalmente está relacionado con el estado del panel, su",
        "ciclo o con que está viendo una parte no activa de la",
        "pantalla.",
      ]),
      ["no genera", "panel no funciona"],
    ),
    "4.1-1": item(
      "¿Qué es el intercambio?",
      j([
        "El intercambio es la acción en la que su energía",
        "disponible se convierte en EFHC según las reglas del",
        "proyecto.",
      ]),
      ["intercambio", "convertir energía"],
    ),
    "4.1-2": item(
      "¿Qué pasa después del intercambio?",
      j([
        "Después del intercambio, parte de su energía queda",
        "contada como usada y los EFHC se añaden a su saldo",
        "principal.",
      ]),
      ["después del intercambio", "saldo principal"],
    ),
    "4.1-3": item(
      "¿Cuándo necesito intercambio y cuándo retiro?",
      j([
        "Si tiene energía pero todavía no tiene suficiente en el",
        "saldo principal, primero necesita intercambio. El retiro",
        "usa el saldo principal.",
      ]),
      ["primero intercambio", "luego retiro"],
    ),
    "4.2-1": item(
      "¿Qué es el retiro?",
      j([
        "El retiro es la acción que permite enviar EFHC desde el",
        "saldo principal según las reglas del proyecto.",
      ]),
      ["retiro", "retirar"],
    ),
    "4.2-2": item(
      "¿Por qué no puedo retirar el saldo bonus?",
      j([
        "Porque el saldo bonus está pensado para acciones internas",
        "del bot. Solo el saldo principal se usa para retirar.",
      ]),
      ["saldo bonus", "no retirar"],
    ),
    "4.2-3": item(
      "¿Por qué el retiro a veces no está disponible?",
      j([
        "El retiro no siempre está disponible de inmediato, porque",
        "depende del estado de su saldo principal y de las reglas",
        "de la operación.",
      ]),
      ["retiro no disponible", "por qué"],
    ),
    "4.2-4": item(
      "¿Por qué cambió mi saldo principal tras el retiro?",
      j([
        "Después de crear un retiro, el monto se tiene en cuenta de",
        "inmediato en el saldo principal para esa acción.",
      ]),
      ["saldo principal cambió", "tras retiro"],
    ),

    "5.1-1": item(
      "¿Para qué sirve el Wallet?",
      j([
        "El Wallet es necesario para acciones donde el proyecto",
        "requiere una confirmación externa y un vínculo con su",
        "dirección. También es importante para VIP NFT y acciones",
        "relacionadas.",
      ]),
      ["wallet", "para qué wallet"],
    ),
    "5.1-2": item(
      "¿Cómo conecto un Wallet?",
      j([
        "Abra la sección Wallet, elija la conexión y confirme la",
        "acción en una aplicación de Wallet compatible.",
      ]),
      ["conectar wallet", "wallet connect"],
    ),
    "5.1-3": item(
      "¿Qué es el Wallet principal?",
      j([
        "El Wallet principal es el Wallet que el bot usa como",
        "principal para acciones donde se necesita una dirección",
        "elegida por el usuario.",
      ]),
      ["wallet principal", "primary wallet"],
    ),
    "5.1-4": item(
      "¿Puedo vincular varios Wallets?",
      j([
        "Sí. En el bot puede guardar varios Wallets vinculados y",
        "elegir uno principal entre los ya conectados.",
      ]),
      ["varios wallets", "wallet principal"],
    ),
    "5.1-5": item(
      "¿Qué hago si el Wallet no se conecta?",
      j([
        "Compruebe que tiene abierto un Wallet adecuado, que la",
        "conexión con Telegram Mini App no se interrumpió y que",
        "confirma la conexión dentro del propio Wallet. Después,",
        "inténtelo otra vez.",
      ]),
      ["wallet problema", "no conecta"],
    ),
    "6.1-1": item(
      "¿Qué son los referrals?",
      j([
        "Los referrals son usuarios que llegaron al proyecto por su",
        "enlace y después influyen en su progreso según las reglas",
        "del sistema de referrals.",
      ]),
      ["referrals", "invitaciones"],
    ),
    "6.1-2": item(
      "¿Cómo funciona mi enlace de referral?",
      j([
        "Usted comparte su enlace con un usuario nuevo. Si entra al",
        "proyecto por ese enlace, pasa a contarse dentro de su",
        "sistema de referrals.",
      ]),
      ["enlace referral", "invite link"],
    ),
    "6.1-3": item(
      "¿Quién se considera referral activo?",
      j([
        "Se considera activo al referral que ya cumplió la condición",
        "necesaria dentro del proyecto y aparece en sus estadísticas",
        "activas.",
      ]),
      ["referral activo", "active referral"],
    ),
    "6.1-4": item(
      "¿Quién se considera referral inactivo?",
      j([
        "Un referral inactivo es un usuario que llegó por su enlace",
        "y aún no cumplió la condición necesaria para tener estado",
        "activo.",
      ]),
      ["referral inactivo", "inactive referral"],
    ),
    "6.1-5": item(
      "¿Qué muestran los contadores en la página de Referrals?",
      j([
        "Los contadores muestran cuántos referrals tiene en total,",
        "cuántos de ellos están activos y cómo eso influye en su",
        "progreso dentro del proyecto.",
      ]),
      ["contadores referrals", "estadísticas"],
    ),
    "6.1-6": item(
      "¿Cómo funciona el progreso hasta el siguiente nivel?",
      j([
        "El progreso muestra cuánto le falta para el siguiente paso",
        "en su línea de referrals. Ayuda a entender rápidamente",
        "cuánto falta para el siguiente nivel o bonus.",
      ]),
      ["progreso", "siguiente nivel"],
    ),
    "7.1-1": item(
      "¿Qué es VIP NFT?",
      j([
        "VIP NFT es un NFT especial del proyecto que da al usuario",
        "un efecto VIP según las reglas de EFHC Bot.",
      ]),
      ["VIP NFT", "VIP"],
    ),
    "7.1-2": item(
      "¿Qué da VIP NFT?",
      j([
        "VIP NFT da ventajas especiales dentro del proyecto. En la",
        "interfaz esto está relacionado con el estado VIP y los",
        "efectos correspondientes.",
      ]),
      ["VIP NFT", "estado VIP"],
    ),
    "7.1-3": item(
      "¿Necesito un Wallet conectado para VIP NFT?",
      j([
        "Sí. Para que el bot vea su VIP NFT y lo relacione",
        "correctamente con el estado, necesita un Wallet vinculado.",
      ]),
      ["wallet", "VIP NFT"],
    ),
    "7.1-4": item(
      "¿Cuándo se activa el estado VIP?",
      j([
        "Cuando el bot ve el NFT adecuado en el Wallet vinculado,",
        "el estado VIP se actualiza automáticamente según las reglas",
        "del proyecto.",
      ]),
      ["estado VIP", "activo"],
    ),
    "7.1-5": item(
      "¿Qué hago si el NFT existe pero el estado no aparece?",
      j([
        "Compruebe que el NFT está en el Wallet vinculado correcto y",
        "que ese Wallet sigue siendo el actual en el bot. Después,",
        "actualice la pantalla y revise de nuevo el estado.",
      ]),
      ["NFT", "estado no aparece"],
    ),
    "8.1-1": item(
      "¿Qué es Shop?",
      j([
        "Shop es la sección donde el usuario puede comprar elementos",
        "del juego y cosas relacionadas con el diseño del proyecto.",
      ]),
      ["shop", "tienda"],
    ),
    "8.1-2": item(
      "¿Qué se puede comprar en Shop?",
      j([
        "En Shop puede comprar productos disponibles del proyecto,",
        "por ejemplo skins y otros elementos adecuados que el bot",
        "muestra ahora mismo en la tienda.",
      ]),
      ["shop", "comprar"],
    ),
    "8.1-3": item(
      "¿En qué se diferencia comprar por EFHC y por Wallet?",
      j([
        "La compra por EFHC usa sus fondos dentro del bot. La compra",
        "por Wallet está relacionada con una confirmación",
        "externa en su",
        "Wallet.",
      ]),
      ["compra EFHC", "compra wallet"],
    ),
    "8.1-4": item(
      "¿Por qué Shop puede aparecer vacío?",
      j([
        "Esto puede pasar si ahora no hay productos disponibles para",
        "su pantalla o si la sección todavía no está llena con las",
        "posiciones adecuadas.",
      ]),
      ["shop vacío", "nada visible"],
    ),
    "8.2-1": item(
      "¿Qué son los skins?",
      j([
        "Los skins son elementos visuales que cambian la apariencia",
        "de partes de la interfaz dentro del proyecto.",
      ]),
      ["skins", "diseño"],
    ),
    "8.2-2": item(
      "¿Qué diferencia hay entre skins normales y diseños de nivel?",
      j([
        "Los skins normales son compras disponibles o elementos",
        "visuales. Los diseños de nivel están relacionados con su",
        "progreso y se desbloquean al llegar a ciertas etapas.",
      ]),
      ["skins", "diseños de nivel"],
    ),
    "8.2-3": item(
      "¿Cómo compro y activo un skin?",
      j([
        "Primero compre un skin disponible en Shop, después elíjalo",
        "entre sus diseños disponibles y actívelo en la interfaz.",
      ]),
      ["comprar skin", "activar skin"],
    ),
    "9.1-1": item(
      "¿Cómo recargo mi saldo?",
      j([
        "Abra la sección de recarga o compra y siga el flujo",
        "disponible. Según la pantalla, puede ser necesaria una",
        "confirmación en el Wallet.",
      ]),
      ["recargar", "saldo"],
    ),
    "9.1-2": item(
      "¿Cuándo necesito un Wallet para comprar?",
      j([
        "El Wallet es necesario cuando la compra pasa por un pago y",
        "una confirmación externos. Para compras internas en el bot,",
        "no siempre es obligatorio.",
      ]),
      ["wallet necesario", "compra wallet"],
    ),
    "9.2-1": item(
      "¿Cómo se realiza una compra con Wallet?",
      j([
        "Elige la compra dentro del bot, la confirmas en tu Wallet y",
        "después vuelves a la aplicación. Tras la confirmación, el",
        "resultado aparece en el bot.",
      ]),
      ["compra wallet", "pago wallet"],
    ),
    "9.2-3": item(
      "¿Qué ocurre después del pago?",
      j([
        "Después de un pago exitoso, el bot actualiza el resultado de",
        "la operación. A veces ocurre al instante y a veces tras un",
        "pequeño procesamiento.",
      ]),
      ["después del pago", "resultado"],
    ),
    "10.1-1": item(
      "¿Qué es un nivel?",
      j([
        "El nivel muestra tu progreso dentro del proyecto. Cuanto más",
        "participas en el sistema de juego y energía, más puede subir",
        "tu nivel.",
      ]),
      ["nivel", "progreso"],
    ),
    "10.1-2": item(
      "¿Qué es un rango?",
      j([
        "El rango muestra tu posición frente a otros participantes.",
        "Ayuda a entender qué lugar ocupas en el progreso común.",
      ]),
      ["rango", "posición"],
    ),
    "10.1-3": item(
      "¿En qué se diferencian nivel y rango?",
      j([
        "El nivel muestra tu progreso personal. El rango muestra tu",
        "posición respecto a otros usuarios.",
      ]),
      ["nivel rango", "diferencia"],
    ),
    "10.1-4": item(
      "¿Qué muestra la página Ranks?",
      j([
        "La página Ranks muestra tu posición y los lugares de otros",
        "participantes. Así puedes ver tu progreso frente al resto de",
        "la comunidad.",
      ]),
      ["ranks", "página de rangos"],
    ),
    "11.1-1": item(
      "¿Por qué no puedo retirar fondos?",
      j([
        "Esto puede ocurrir si ahora no tienes suficiente saldo main",
        "para retirar o si el paso necesario dentro del bot aún no ha",
        "terminado.",
      ]),
      ["no puedo retirar", "sin retiro"],
    ),
    "11.1-2": item(
      "¿Por qué no se conecta el Wallet?",
      j([
        "Comprueba que la app del Wallet esté abierta, que la",
        "conexión haya sido confirmada y que tu dispositivo no bloquee",
        "la conexión con el bot.",
      ]),
      ["wallet no conecta", "error wallet"],
    ),
    "11.1-3": item(
      "¿Por qué mi panel no genera energía?",
      j([
        "Revisa el estado de tu panel y si el ciclo ya comenzó. Si la",
        "panel está inactiva o archivada, no verás la producción que",
        "esperabas.",
      ]),
      ["panel no genera", "sin energía"],
    ),
    "11.1-4": item(
      "¿Por qué no aparece el estado VIP?",
      j([
        "Comprueba que esté conectado el Wallet correcto y que el NFT",
        "esté disponible allí. Después abre de nuevo la sección y",
        "espera un poco a que se actualice.",
      ]),
      ["estado vip", "vip no aparece"],
    ),
    "11.1-5": item(
      "¿Por qué no llegó mi bono?",
      j([
        "Primero comprueba que la acción cumplía las condiciones del",
        "bono. Algunos bonos no aparecen al instante, sino después del",
        "procesamiento dentro del bot.",
      ]),
      ["bono no llegó", "bono faltante"],
    ),
    "11.1-6": item(
      "¿Por qué mi referido está inactivo?",
      j([
        "Un referido sigue inactivo si aún no ha realizado la acción",
        "necesaria para activarse. Normalmente esto depende de su",
        "progreso dentro del bot.",
      ]),
      ["referido inactivo", "inactivo"],
    ),
    "11.1-7": item(
      "¿Por qué Shop está vacío?",
      j([
        "Shop puede verse vacío si ahora mismo no hay productos",
        "disponibles para tu pantalla o si la sección todavía no ha",
        "sido rellenada con posiciones adecuadas.",
      ]),
      ["shop vacío", "nada en shop"],
    ),
    "12.1-1": item(
      "¿Cómo busco por palabras en la FAQ?",
      j([
        "Escribe en la barra de búsqueda una palabra clara de la",
        "interfaz, por ejemplo balance, Wallet, panel, Exchange o",
        "Withdraw.",
      ]),
      ["buscar faq", "búsqueda"],
    ),
    "12.1-2": item(
      "¿Dónde busco una pregunta sobre el saldo?",
      j([
        "Búscala en las secciones Balances e History del balance.",
        "Allí se explica qué significan los valores visibles y por",
        "qué cambian.",
      ]),
      ["pregunta saldo", "history"],
    ),
    "12.1-3": item(
      "¿Dónde busco una pregunta sobre el Wallet?",
      j([
        "Abre la sección Wallet. Allí están reunidas las preguntas",
        "sobre conexión, Wallet principal y problemas al conectarlo.",
      ]),
      ["pregunta wallet", "sección wallet"],
    ),
    "12.1-4": item(
      "¿Qué hago si no encontré una respuesta?",
      j([
        "Prueba con otra palabra clara que veas en la interfaz o abre",
        "una sección cercana al tema. Para Wallet, History, Panels o",
        "Exchange, busca exactamente por esas palabras.",
      ]),
      ["sin respuesta", "otra palabra"],
    ),
  },
  ua: {
    "1.1-1": item(
      "Що таке загальний баланс?",
      j([
        "Загальний баланс показує всі EFHC, які зараз є у вас",
        "всередині бота. Він зручний для загального розуміння",
        "ресурсів, але не дорівнює сумі, доступній для виведення.",
      ]),
      ["загальний баланс", "total balance"],
    ),
    "1.1-2": item(
      "Що таке основний баланс?",
      j([
        "Основний баланс — це частина ваших коштів, яка",
        "використовується для ключових дій проєкту. Саме він",
        "використовується для виведення.",
      ]),
      ["основний баланс", "main balance"],
    ),
    "1.1-3": item(
      "Що таке бонусний баланс?",
      j([
        "Бонусний баланс — це внутрішня частина ваших коштів у",
        "боті. Він потрібний для ігрових дій і покупок усередині",
        "проєкту, але не використовується для виведення.",
      ]),
      ["бонусний баланс", "bonus balance"],
    ),
    "1.1-4": item(
      "Чим відрізняються загальний, основний і бонусний баланси?",
      j([
        "Загальний баланс — це всі ваші кошти всередині бота.",
        "Основний баланс потрібний для обміну та виведення.",
        "Бонусний баланс потрібний для внутрішніх ігрових дій і",
        "покупок.",
      ]),
      ["різниця балансів", "main", "bonus", "total"],
    ),
    "1.2-1": item(
      "Чому я не можу вивести весь загальний баланс?",
      j([
        "Тому що загальний баланс включає і основні, і бонусні",
        "EFHC. Для виведення використовується лише основний",
        "баланс.",
      ]),
      ["виведення", "загальний баланс", "чому не можна"],
    ),
    "1.2-2": item(
      "Чому одна покупка може зачіпати і бонусний, і основний баланс?",
      j([
        "Тому що бот може використовувати ваші внутрішні кошти",
        "послідовно для однієї дії. У результаті одна покупка може",
        "зменшити одразу два баланси.",
      ]),
      ["покупка", "два баланси", "main і bonus"],
    ),
    "2.1-1": item(
      "Що показує історія балансу?",
      j([
        "Історія балансу показує зміни ваших коштів: надходження,",
        "списання та інші дії, які вплинули на баланс усередині",
        "бота.",
      ]),
      ["історія балансу", "операції", "history"],
    ),
    "2.1-2": item(
      "Які дії відображаються в історії балансу?",
      j([
        "В історії показуються дії, які змінюють ваш основний або",
        "бонусний баланс: нарахування, списання, покупки, обмін та",
        "інші дії всередині бота.",
      ]),
      ["історія", "операції", "нарахування", "списання"],
    ),
    "2.1-3": item(
      "Чому в мене змінився баланс?",
      j([
        "Баланс змінюється після дій усередині бота: покупок,",
        "бонусних нарахувань, обміну енергії, виведення та інших",
        "операцій. Історія балансу допомагає побачити причину.",
      ]),
      ["змінився баланс", "чому"],
    ),
    "2.1-4": item(
      "Як зрозуміти, за що прийшли або пішли кошти?",
      j([
        "Відкрийте історію балансу й подивіться опис операції. Він",
        "показує, яка дія викликала надходження або списання.",
      ]),
      ["за що", "надходження", "списання", "історія"],
    ),
    "3.1-1": item(
      "Що таке панель?",
      j([
        "Панель — це основа вашого ігрового та енергетичного",
        "прогресу в EFHC Bot. Після покупки вона бере участь у",
        "генерації енергії всередині проєкту.",
      ]),
      ["панель", "panel"],
    ),
    "3.1-2": item(
      "Що дає панель?",
      j([
        "Панель дає вам генерацію енергії, рух у прогресі проєкту і",
        "основу для подальшого обміну енергії на EFHC.",
      ]),
      ["що дає панель", "генерація", "прогрес"],
    ),
    "3.1-3": item(
      "Як купити панель?",
      j([
        "Відкрийте розділ Panels, виберіть покупку і підтвердьте",
        "дію. Після успішної покупки панель з'явиться у вашому",
        "списку.",
      ]),
      ["купити панель", "panels"],
    ),
    "3.1-4": item(
      "Що буде, якщо в мене кілька панелей?",
      j([
        "Якщо у вас кілька панелей, кожна з них бере участь у",
        "вашому загальному прогресі та збільшує обсяг енергії",
        "усередині проєкту.",
      ]),
      ["кілька панелей", "багато панелей"],
    ),
    "3.1-5": item(
      "Що означає архів панелі?",
      j([
        "Архів панелі означає, що цей цикл уже не належить до",
        "активної частини екрана, але сама панель залишається",
        "частиною вашої історії прогресу.",
      ]),
      ["архів панелі", "archive"],
    ),
    "3.2-1": item(
      "Як з'являється енергія?",
      j([
        "Енергія з'являється завдяки вашим панелям. Саме панелі",
        "дають зростання енергії всередині бота.",
      ]),
      ["як з'являється енергія", "energy"],
    ),
    "3.2-2": item(
      "Що таке доступна енергія?",
      j([
        "Доступна енергія — це та частина енергії, яку ви можете",
        "використати далі в межах механіки проєкту.",
      ]),
      ["доступна енергія", "available energy"],
    ),
    "3.2-3": item(
      "Чому панель може не генерувати?",
      j([
        "Зазвичай це пов'язано зі станом панелі, етапом її циклу або",
        "з тим, що ви дивитеся не на активну частину екрана.",
        "Перевірте розділ Panels і поточний стан панелі.",
      ]),
      ["не генерує", "панель не працює"],
    ),
    "4.1-1": item(
      "Що таке обмін?",
      j([
        "Обмін — це дія, під час якої ваша доступна енергія",
        "перетворюється на EFHC за правилами проєкту.",
      ]),
      ["обмін", "exchange"],
    ),
    "4.1-2": item(
      "Що відбувається після обміну?",
      j([
        "Після обміну частина вашої енергії враховується як",
        "використана, а EFHC надходять в основний баланс.",
      ]),
      ["після обміну", "основний баланс"],
    ),
    "4.1-3": item(
      "Коли спочатку потрібен обмін, а коли вже доступне виведення?",
      j([
        "Якщо у вас є енергія, але ще немає потрібної суми на",
        "основному балансі, спочатку потрібен обмін. Виведення",
        "використовується вже для основного балансу.",
      ]),
      ["спочатку обмін", "потім виведення"],
    ),
    "4.2-1": item(
      "Що таке виведення?",
      j([
        "Виведення — це дія, за допомогою якої користувач",
        "надсилає EFHC з основного балансу за правилами проєкту.",
      ]),
      ["виведення", "withdraw"],
    ),
    "4.2-2": item(
      "Чому не можна вивести бонусний баланс?",
      j([
        "Тому що бонусний баланс призначений для внутрішнього",
        "ігрового використання. Для виведення застосовується лише",
        "основний баланс.",
      ]),
      ["не можна вивести бонусний", "bonus balance"],
    ),
    "4.2-3": item(
      "Чому після заявки на виведення в мене змінився основний баланс?",
      j([
        "Тому що після створення заявки ця сума одразу враховується",
        "для цієї дії і більше не вважається вільною для інших",
        "дій.",
      ]),
      ["заявка на виведення", "змінився баланс"],
    ),
    "4.2-4": item(
      "Чому виведення може бути недоступним?",
      j([
        "Виведення може бути недоступним, якщо для нього поки не",
        "вистачає умов проєкту, потрібної суми на основному балансі",
        "або прив'язаного гаманця.",
      ]),
      ["виведення недоступне", "гаманець"],
    ),
    "5.1-1": item(
      "Навіщо потрібен гаманець?",
      j([
        "Гаманець потрібний для дій, де проєкту потрібне зовнішнє",
        "підтвердження та зв'язок із вашою адресою. Він також",
        "важливий для VIP NFT і пов'язаних дій.",
      ]),
      ["навіщо гаманець", "wallet"],
    ),
    "5.1-2": item(
      "Як підключити гаманець?",
      j([
        "Відкрийте розділ Wallet, виберіть підключення і",
        "підтвердьте дію в підтримуваному застосунку гаманця.",
      ]),
      ["підключити гаманець", "wallet connect"],
    ),
    "5.1-3": item(
      "Що таке основний гаманець?",
      j([
        "Основний гаманець — це гаманець, який бот використовує як",
        "головний для дій, де потрібна обрана користувачем адреса.",
      ]),
      ["основний гаманець", "primary wallet"],
    ),
    "5.1-4": item(
      "Чи можна прив'язати кілька гаманців?",
      j([
        "Так. У боті можна зберігати кілька прив'язаних гаманців і",
        "вибирати основний із уже підключених.",
      ]),
      ["кілька гаманців", "primary wallet"],
    ),
    "5.1-5": item(
      "Що робити, якщо гаманець не підключається?",
      j([
        "Перевірте, що у вас відкритий відповідний гаманець,",
        "зв'язок із Telegram Mini App не перерваний і ви",
        "підтверджуєте підключення в самому гаманці. Після цього",
        "спробуйте ще раз.",
      ]),
      ["не підключається", "проблема з гаманцем"],
    ),
    "6.1-1": item(
      "Що таке реферали?",
      j([
        "Реферали — це користувачі, які прийшли в проєкт за вашим",
        "посиланням і далі впливають на ваш прогрес за правилами",
        "реферальної системи.",
      ]),
      ["реферали", "referrals"],
    ),
    "6.1-2": item(
      "Як працює моє реферальне посилання?",
      j([
        "Ви ділитеся своїм посиланням із новим користувачем. Якщо",
        "він приходить у проєкт за ним, він враховується у вашій",
        "реферальній системі.",
      ]),
      ["реферальне посилання", "invite link"],
    ),
    "6.1-3": item(
      "Хто вважається активним рефералом?",
      j([
        "Активним вважається реферал, який уже виконав потрібну",
        "умову всередині проєкту і бере участь у вашій активній",
        "реферальній статистиці.",
      ]),
      ["активний реферал", "active referral"],
    ),
    "6.1-4": item(
      "Хто вважається неактивним рефералом?",
      j([
        "Неактивний реферал — це користувач за вашим посиланням,",
        "який ще не виконав умову для активного статусу.",
      ]),
      ["неактивний реферал", "inactive referral"],
    ),
    "6.1-5": item(
      "Що показують лічильники на сторінці рефералів?",
      j([
        "Лічильники показують, скільки у вас всього рефералів,",
        "скільки з них активні і як це впливає на ваш прогрес",
        "усередині реферальної системи.",
      ]),
      ["лічильники", "сторінка рефералів"],
    ),
    "6.1-6": item(
      "Як працює прогрес до наступного рівня?",
      j([
        "Прогрес показує, скільки ще потрібно для наступного кроку",
        "по вашій реферальній лінії. Він допомагає швидко зрозуміти,",
        "скільки вам залишилося до наступного рівня або бонусу.",
      ]),
      ["прогрес", "наступний рівень"],
    ),

    "7.1-1": item(
      "Що таке VIP NFT?",
      j([
        "VIP NFT — це спеціальний NFT проєкту, який дає",
        "користувачеві VIP-ефект за правилами EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "Що дає VIP NFT?",
      j([
        "VIP NFT дає спеціальні переваги всередині проєкту. В",
        "інтерфейсі це пов'язано з VIP-статусом і відповідними",
        "ефектами проєкту.",
      ]),
      ["що дає vip nft", "vip status"],
    ),
    "7.1-3": item(
      "Чи потрібен прив'язаний Wallet для VIP NFT?",
      j([
        "Так. Щоб бот побачив ваш VIP NFT і правильно пов'язав його",
        "зі статусом, потрібен прив'язаний Wallet.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "Коли VIP-статус стає активним?",
      j([
        "Коли бот бачить потрібний NFT у прив'язаному Wallet,",
        "VIP-статус оновлюється автоматично за правилами проєкту.",
      ]),
      ["vip status", "активується"],
    ),
    "7.1-5": item(
      "Що робити, якщо NFT є, а статус не відображається?",
      j([
        "Перевірте, що NFT знаходиться в потрібному прив'язаному",
        "Wallet і що цей гаманець актуальний у боті. Потім",
        "оновіть екран і перевірте ще раз.",
      ]),
      ["nft є", "статус не видно"],
    ),
    "8.1-1": item(
      "Що таке Shop?",
      j([
        "Shop — це розділ, де користувач може купувати внутрішні",
        "елементи гри та інші речі проєкту, пов'язані з оформленням.",
      ]),
      ["shop", "магазин"],
    ),
    "8.1-2": item(
      "Що можна купити в Shop?",
      j([
        "У Shop можна купувати доступні товари проєкту, які бот",
        "показує зараз: наприклад, скіни та інші відповідні",
        "елементи.",
      ]),
      ["що купити", "товари"],
    ),
    "8.1-3": item(
      "Чим покупка за EFHC відрізняється від покупки через Wallet?",
      j([
        "Покупка за EFHC використовує ваші кошти всередині бота.",
        "Покупка через Wallet пов'язана із зовнішнім",
        "підтвердженням через ваш гаманець.",
      ]),
      ["покупка за efhc", "через wallet"],
    ),
    "8.1-4": item(
      "Чому в Shop може нічого не відображатися?",
      j([
        "Таке можливо, якщо зараз для вашого екрана немає",
        "доступних товарів або розділ ще не заповнений",
        "відповідними позиціями.",
      ]),
      ["shop порожній", "нічого не видно"],
    ),
    "8.2-1": item(
      "Що таке скіни?",
      j([
        "Скіни — це елементи візуального оформлення, які змінюють",
        "вигляд частин інтерфейсу всередині проєкту.",
      ]),
      ["скіни", "skins"],
    ),
    "8.2-2": item(
      "Чим звичайні скіни відрізняються від рівневих оформлень?",
      j([
        "Звичайні скіни — це доступні покупки або елементи",
        "оформлення. Рівневі оформлення пов'язані з вашим",
        "прогресом і відкриваються за правилами проєкту.",
      ]),
      ["рівневі", "оформлення"],
    ),
    "8.2-3": item(
      "Як купити й активувати скін?",
      j([
        "Спочатку купіть доступний скін у Shop, потім виберіть його",
        "серед своїх доступних оформлень і активуйте в інтерфейсі.",
      ]),
      ["купити скін", "активувати скін"],
    ),
    "9.1-1": item(
      "Як поповнити баланс?",
      j([
        "Для поповнення відкрийте потрібну дію в боті та дотримуйтесь",
        "кроків на екрані. Якщо для цього потрібен Wallet, бот сам",
        "підкаже наступний крок.",
      ]),
      ["поповнення", "поповнити баланс"],
    ),
    "9.1-2": item(
      "Коли для покупки потрібен Wallet?",
      j([
        "Wallet потрібен там, де покупка проходить не тільки",
        "всередині бота, а потребує зовнішнього підтвердження через",
        "вашу адресу.",
      ]),
      ["коли потрібен wallet", "покупка"],
    ),
    "9.2-1": item(
      "Як проходить покупка через Wallet?",
      j([
        "Бот переводить вас до кроку підтвердження в Wallet. Після",
        "підтвердження система оновлює результат покупки всередині",
        "проєкту.",
      ]),
      ["покупка через wallet", "wallet buy"],
    ),
    "9.2-2": item(
      "Чим внутрішня покупка відрізняється від покупки через Wallet?",
      j([
        "Внутрішня покупка використовує ваші EFHC усередині бота.",
        "Покупка через Wallet пов'язана із зовнішнім",
        "підтвердженням через гаманець.",
      ]),
      ["внутрішня покупка", "через wallet"],
    ),
    "9.2-3": item(
      "Що відбувається після оплати?",
      j([
        "Після оплати результат має з'явитися в інтерфейсі бота:",
        "баланс, покупка або новий елемент оновлюються за",
        "правилами проєкту.",
      ]),
      ["після оплати", "payment result"],
    ),
    "9.2-4": item(
      "Чому після оплати я не бачу результат одразу?",
      j([
        "Деяким операціям потрібен трохи час, щоб оновитися в",
        "інтерфейсі. Якщо результат не з'явився відразу, оновіть",
        "екран і перевірте історію або потрібний розділ.",
      ]),
      ["не бачу результат", "після оплати"],
    ),
    "10.1-1": item(
      "Що таке рівень?",
      j([
        "Рівень показує ваш особистий прогрес усередині проєкту.",
        "Він зростає в міру руху по ігрових та енергетичних",
        "механіках EFHC Bot.",
      ]),
      ["рівень", "level"],
    ),
    "10.1-2": item(
      "Що таке ранг?",
      j([
        "Ранг показує ваше місце серед інших учасників на сторінці",
        "Ranks.",
      ]),
      ["ранг", "ranks"],
    ),
    "10.1-3": item(
      "Чим рівень відрізняється від рангу?",
      j([
        "Рівень показує ваш особистий прогрес, а ранг — ваше місце",
        "серед інших учасників проєкту.",
      ]),
      ["різниця рангу і рівня"],
    ),
    "10.1-4": item(
      "Що показує сторінка Ranks?",
      j([
        "Сторінка Ranks показує рейтинг учасників і допомагає",
        "зрозуміти ваше поточне місце порівняно з іншими.",
      ]),
      ["сторінка ranks", "місце"],
    ),
    "11.1-1": item(
      "Чому я не можу вивести кошти?",
      j([
        "Зазвичай це означає, що для виведення потрібен основний",
        "баланс, Wallet або ще не виконані умови проєкту для цієї",
        "дії.",
      ]),
      ["не можу вивести", "виведення"],
    ),
    "11.1-2": item(
      "Чому Wallet не підключається?",
      j([
        "Перевірте, що ви відкрили правильний Wallet, зв'язок з",
        "Mini App не перерваний, а підтвердження виконане в самому",
        "гаманці.",
      ]),
      ["wallet не підключається", "wallet problem"],
    ),
    "11.1-3": item(
      "Чому панель не генерує?",
      j([
        "Перевірте поточний екран Panels і стан панелі. Зазвичай",
        "причина пов'язана з етапом її циклу або з тим, що ви",
        "дивитеся не на активну частину списку.",
      ]),
      ["панель не генерує", "panel problem"],
    ),
    "11.1-4": item(
      "Чому не відображається VIP-статус?",
      j([
        "Перевірте, що потрібний NFT знаходиться в прив'язаному",
        "Wallet і що бот уже бачить цей гаманець як актуальний.",
      ]),
      ["vip не видно", "status"],
    ),
    "11.1-5": item(
      "Чому бонус не прийшов?",
      j([
        "Спочатку перевірте історію балансу й розділ, з яким",
        "пов'язаний цей бонус. Якщо бонус не з'явився одразу,",
        "оновіть екран і перевірте пов'язане питання у FAQ.",
      ]),
      ["бонус не прийшов", "bonus"],
    ),
    "11.1-6": item(
      "Чому реферал неактивний?",
      j([
        "Це означає, що користувач за вашим посиланням ще не виконав",
        "умову, потрібну для активного статусу в реферальній",
        "системі.",
      ]),
      ["реферал неактивний", "inactive referral"],
    ),
    "11.1-7": item(
      "Чому в Shop порожньо?",
      j([
        "Якщо в Shop порожньо, значить зараз для вашого екрана немає",
        "доступних товарів або потрібні позиції ще не показані в",
        "магазині.",
      ]),
      ["shop порожній", "no items"],
    ),
    "12.1-1": item(
      "Як шукати за словами у FAQ?",
      j([
        "Відкрийте FAQ і введіть у рядок пошуку зрозуміле слово з",
        "інтерфейсу: наприклад, баланс, Wallet, панель, обмін або",
        "виведення.",
      ]),
      ["пошук", "faq", "знайти"],
    ),
    "12.1-2": item(
      "Де шукати питання про баланс?",
      j([
        "Шукайте його в розділах Баланси та Історія балансу. Вони",
        "пояснюють, що ви бачите в інтерфейсі і чому змінюються",
        "кошти.",
      ]),
      ["де шукати баланс", "історія"],
    ),
    "12.1-3": item(
      "Де шукати питання про Wallet?",
      j([
        "Відкрийте розділ Кошелёк. Там зібрані питання про",
        "підключення, основний гаманець і проблеми при підключенні.",
      ]),
      ["де шукати wallet", "wallet"],
    ),
    "12.1-4": item(
      "Що робити, якщо я не знайшов відповідь?",
      j([
        "Спробуйте інший зрозумілий запит за інтерфейсом бота або",
        "відкрийте близький за змістом розділ. Якщо питання",
        "стосується Wallet, історії, панелей або обміну, шукайте",
        "саме за цими словами.",
      ]),
      ["не знайшов відповідь", "інший запит"],
    ),
  },
  it: {
    "1.1-1": item(
      "Che cos'è il saldo totale?",
      j([
        "Il saldo totale mostra tutti gli EFHC che ora avete nel",
        "bot. È utile per capire le vostre risorse complessive, ma",
        "non coincide con l'importo disponibile per il prelievo.",
      ]),
      ["saldo totale", "tutti i fondi", "saldo generale"],
    ),
    "1.1-2": item(
      "Che cos'è il saldo principale?",
      j([
        "Il saldo principale è la parte dei vostri fondi usata per",
        "le azioni chiave del progetto. È il saldo usato per il",
        "prelievo.",
      ]),
      ["saldo principale", "saldo per prelievo"],
    ),
    "1.1-3": item(
      "Che cos'è il saldo bonus?",
      j([
        "Il saldo bonus è la parte interna dei vostri fondi nel",
        "bot. Si usa per azioni e acquisti interni, ma non per il",
        "prelievo.",
      ]),
      ["saldo bonus", "fondi bonus"],
    ),
    "1.1-4": item(
      "Qual è la differenza tra saldo totale, principale e bonus?",
      j([
        "Il saldo totale comprende tutti i vostri fondi nel bot. Il",
        "saldo principale si usa per scambio e prelievo. Il saldo",
        "bonus si usa per azioni e acquisti interni.",
      ]),
      ["differenza saldi", "principale", "bonus", "totale"],
    ),
    "1.2-1": item(
      "Perché non posso prelevare tutto il saldo totale?",
      j([
        "Perché il saldo totale include sia EFHC principali sia",
        "bonus. Per il prelievo si usa solo il saldo principale.",
      ]),
      ["prelievo", "saldo totale", "perché no"],
    ),
    "1.2-2": item(
      "Perché un acquisto può toccare bonus e saldo principale?",
      j([
        "Perché il bot può usare i vostri fondi interni in modo",
        "sequenziale per una sola azione. Per questo un acquisto può",
        "ridurre due saldi insieme.",
      ]),
      ["acquisto", "due saldi", "bonus e principale"],
    ),
    "2.1-1": item(
      "Che cosa mostra la cronologia del saldo?",
      j([
        "La cronologia del saldo mostra le variazioni dei vostri",
        "fondi: entrate, spese e altre azioni che hanno influito sul",
        "saldo nel bot.",
      ]),
      ["cronologia saldo", "operazioni", "cronologia"],
    ),
    "2.1-2": item(
      "Quali azioni compaiono nella cronologia del saldo?",
      j([
        "La cronologia mostra le azioni che cambiano il saldo",
        "principale o bonus: ricompense, spese, acquisti, scambio e",
        "altre azioni nel bot.",
      ]),
      ["cronologia", "operazioni", "ricompense", "spese"],
    ),
    "2.1-3": item(
      "Perché il mio saldo è cambiato?",
      j([
        "Il saldo cambia dopo le azioni nel bot: acquisti, bonus,",
        "scambio di energia, prelievo e altre operazioni. La",
        "cronologia vi aiuta a capire il motivo.",
      ]),
      ["saldo cambiato", "perché"],
    ),
    "2.1-4": item(
      "Come faccio a capire perché i fondi sono entrati o usciti?",
      j([
        "Aprite la cronologia del saldo e controllate la descrizione",
        "dell'operazione. Mostra quale azione ha causato l'entrata o",
        "la spesa.",
      ]),
      ["perché", "entrata", "spesa", "cronologia"],
    ),
    "3.1-1": item(
      "Che cos'è un pannello?",
      j([
        "Un pannello è la base del tuo progresso di gioco ed energia",
        "in EFHC Bot. Dopo l'acquisto partecipa alla generazione di",
        "energia nel progetto.",
      ]),
      ["pannello", "panel"],
    ),
    "3.1-2": item(
      "Cosa mi dà un pannello?",
      j([
        "Un pannello ti dà generazione di energia, progresso nel",
        "progetto e una base per il successivo scambio di energia in",
        "EFHC.",
      ]),
      ["cosa dà il pannello", "generazione", "progresso"],
    ),
    "3.1-3": item(
      "Come posso acquistare un pannello?",
      j([
        "Apri la sezione Panels, scegli l'acquisto e conferma",
        "l'azione. Dopo un acquisto riuscito, il pannello apparirà",
        "nel tuo elenco.",
      ]),
      ["acquistare pannello", "panels"],
    ),
    "3.1-4": item(
      "Cosa succede se ho più pannelli?",
      j([
        "Se hai più pannelli, ognuno contribuisce al tuo progresso",
        "totale e aumenta la quantità di energia nel progetto.",
      ]),
      ["più pannelli", "molti pannelli"],
    ),
    "3.1-5": item(
      "Cosa significa archivio del pannello?",
      j([
        "L'archivio del pannello significa che questo ciclo non è più",
        "nella parte attiva dello schermo, ma il pannello resta nella",
        "storia del tuo progresso.",
      ]),
      ["archivio pannello", "archivio"],
    ),
    "3.2-1": item(
      "Come appare l'energia?",
      j([
        "L'energia appare grazie ai tuoi pannelli. Sono i pannelli a",
        "far crescere l'energia dentro il bot.",
      ]),
      ["come appare energia", "energia"],
    ),
    "3.2-2": item(
      "Che cos'è l'energia disponibile?",
      j([
        "L'energia disponibile è la parte di energia che puoi usare",
        "ulteriormente nelle meccaniche del progetto.",
      ]),
      ["energia disponibile", "available energy"],
    ),
    "3.2-3": item(
      "Perché un pannello può smettere di generare?",
      j([
        "Di solito è legato allo stato del pannello, al suo ciclo o al",
        "fatto che stai guardando una parte non attiva dello schermo.",
        "Controlla la sezione Panels e lo stato attuale del pannello.",
      ]),
      ["non genera", "pannello non funziona"],
    ),
    "4.1-1": item(
      "Che cos'è lo scambio?",
      j([
        "Lo scambio è l'azione in cui la tua energia disponibile si",
        "trasforma in EFHC secondo le regole del progetto.",
      ]),
      ["scambio", "convertire energia"],
    ),
    "4.1-2": item(
      "Cosa succede dopo lo scambio?",
      j([
        "Dopo lo scambio, una parte della tua energia viene contata",
        "come usata e gli EFHC vengono aggiunti al saldo principale.",
      ]),
      ["dopo scambio", "saldo principale"],
    ),
    "4.1-3": item(
      "Quando serve prima lo scambio e quando il prelievo è pronto?",
      j([
        "Se hai energia ma non ancora abbastanza fondi nel saldo",
        "principale, prima serve lo scambio. Il prelievo usa il",
        "saldo principale.",
      ]),
      ["prima scambio", "poi prelievo"],
    ),
    "4.2-1": item(
      "Che cos'è il prelievo?",
      j([
        "Il prelievo è l'azione che permette all'utente di inviare",
        "EFHC dal saldo principale secondo le regole del progetto.",
      ]),
      ["prelievo", "withdraw"],
    ),
    "4.2-2": item(
      "Perché non posso prelevare il saldo bonus?",
      j([
        "Perché il saldo bonus è destinato all'uso interno del gioco.",
        "Solo il saldo principale viene usato per il prelievo.",
      ]),
      ["non posso prelevare bonus", "saldo bonus"],
    ),
    "4.2-3": item(
      "Perché il saldo principale cambia dopo una richiesta?",
      j([
        "Perché dopo aver creato la richiesta, quell'importo viene",
        "subito considerato per questa azione e non è più libero per",
        "altre operazioni.",
      ]),
      ["richiesta prelievo", "saldo cambiato"],
    ),
    "4.2-4": item(
      "Perché il prelievo può essere non disponibile?",
      j([
        "Il prelievo può non essere disponibile se le condizioni del",
        "progetto non sono ancora soddisfatte, se non hai abbastanza",
        "nel saldo principale o se nessun wallet è collegato.",
      ]),
      ["prelievo non disponibile", "wallet"],
    ),
    "5.1-1": item(
      "Perché mi serve un wallet?",
      j([
        "Un wallet serve per le azioni in cui il progetto richiede una",
        "conferma esterna e un collegamento al tuo indirizzo. È anche",
        "importante per VIP NFT e azioni collegate.",
      ]),
      ["perché wallet", "wallet"],
    ),
    "5.1-2": item(
      "Come collego un wallet?",
      j([
        "Apri la sezione Wallet, scegli il collegamento e conferma",
        "l'azione in un'app wallet supportata.",
      ]),
      ["collegare wallet", "wallet connect"],
    ),
    "5.1-3": item(
      "Che cos'è il wallet principale?",
      j([
        "Il wallet principale è quello che il bot usa come wallet",
        "principale per le azioni in cui serve il tuo indirizzo",
        "scelto.",
      ]),
      ["wallet principale", "primary wallet"],
    ),
    "5.1-4": item(
      "Posso collegare più wallet?",
      j([
        "Sì. Il bot può conservare più wallet collegati e permetterti",
        "di scegliere quello principale dall'elenco connesso.",
      ]),
      ["più wallet", "primary wallet"],
    ),
    "5.1-5": item(
      "Cosa devo fare se il wallet non si collega?",
      j([
        "Controlla che sia aperta l'app wallet corretta, che la",
        "connessione di Telegram Mini App non sia interrotta e che tu",
        "confermi il collegamento nel wallet stesso. Poi riprova.",
      ]),
      ["non si collega", "problema wallet"],
    ),
    "6.1-1": item(
      "Che cosa sono i referral?",
      j([
        "I referral sono utenti che arrivano al progetto tramite il",
        "tuo link e poi influenzano il tuo progresso secondo le regole",
        "del sistema referral.",
      ]),
      ["referral", "utenti invitati"],
    ),
    "6.1-2": item(
      "Come funziona il mio link referral?",
      j([
        "Condividi il tuo link con un nuovo utente. Se entra nel",
        "progetto tramite quel link, viene conteggiato nel tuo sistema",
        "referral.",
      ]),
      ["link referral", "link invito"],
    ),
    "6.1-3": item(
      "Chi è considerato un referral attivo?",
      j([
        "Un referral attivo è un utente che ha già completato la",
        "condizione richiesta dal progetto ed è incluso nelle tue",
        "statistiche attive.",
      ]),
      ["referral attivo", "attivo"],
    ),
    "6.1-4": item(
      "Chi è considerato un referral inattivo?",
      j([
        "Un referral inattivo è un utente arrivato tramite il tuo",
        "link, ma che non ha ancora completato la condizione per lo",
        "stato attivo.",
      ]),
      ["referral inattivo", "inattivo"],
    ),
    "6.1-5": item(
      "Cosa mostrano i contatori nella pagina referrals?",
      j([
        "I contatori mostrano quanti referral hai in totale, quanti",
        "sono attivi e come questo influisce sul tuo progresso nel",
        "sistema referral.",
      ]),
      ["contatori", "pagina referrals"],
    ),
    "6.1-6": item(
      "Come funziona il progresso verso il livello successivo?",
      j([
        "Il progresso mostra quanto manca ancora per il passo",
        "successivo nella tua linea referral. Ti aiuta a vedere",
        "rapidamente quanto resta fino al livello o bonus seguente.",
      ]),
      ["progresso", "livello successivo"],
    ),
    "7.1-1": item(
      "Che cos'è VIP NFT?",
      j([
        "VIP NFT è un NFT speciale del progetto che dà all'utente un",
        "effetto VIP secondo le regole di EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "Cosa mi dà VIP NFT?",
      j([
        "VIP NFT offre vantaggi speciali nel progetto.",
        "Nell'interfaccia",
        "questo è collegato allo stato VIP e ai relativi effetti del",
        "progetto.",
      ]),
      ["cosa dà vip nft", "stato vip"],
    ),
    "7.1-3": item(
      "Serve un wallet collegato per VIP NFT?",
      j([
        "Sì. Il bot ha bisogno di un wallet collegato per vedere il",
        "tuo VIP NFT e associarlo correttamente al tuo stato.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "Quando lo stato VIP diventa attivo?",
      j([
        "Quando il bot vede l'NFT corretto nel wallet collegato, lo",
        "stato VIP viene aggiornato automaticamente secondo le regole",
        "del progetto.",
      ]),
      ["stato vip", "diventa attivo"],
    ),
    "7.1-5": item(
      "Cosa fare se ho l'NFT ma lo stato non appare?",
      j([
        "Controlla che l'NFT sia nel wallet collegato corretto e che",
        "quel wallet sia ancora attuale nel bot. Poi aggiorna lo",
        "schermo e controlla di nuovo.",
      ]),
      ["nft presente", "stato mancante"],
    ),
    "8.1-1": item(
      "Che cos'è Shop?",
      j([
        "Shop è la sezione in cui un utente può acquistare oggetti del",
        "bot e altri elementi del progetto legati allo stile",
        "dell'interfaccia.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "Cosa posso comprare in Shop?",
      j([
        "In Shop puoi acquistare gli oggetti del progetto attualmente",
        "disponibili, come skin e altri elementi adatti.",
      ]),
      ["cosa comprare", "oggetti"],
    ),
    "8.1-3": item(
      "In cosa differisce l'acquisto con EFHC da Wallet?",
      j([
        "L'acquisto con EFHC usa i tuoi fondi dentro il bot.",
        "L'acquisto tramite Wallet richiede una conferma esterna nel",
        "wallet.",
      ]),
      ["acquisto con efhc", "tramite wallet"],
    ),
    "8.1-4": item(
      "Perché Shop può non mostrare nulla?",
      j([
        "Può accadere se in questo momento non ci sono articoli",
        "disponibili per il tuo schermo o se la sezione non è ancora",
        "riempita con posizioni adatte.",
      ]),
      ["shop vuoto", "niente mostrato"],
    ),
    "8.2-1": item(
      "Che cosa sono le skin?",
      j([
        "Le skin sono elementi visivi che cambiano l'aspetto di parti",
        "dell'interfaccia all'interno del progetto.",
      ]),
      ["skin", "design"],
    ),
    "8.2-2": item(
      "In cosa le skin normali differiscono da quelle di livello?",
      j([
        "Le skin normali sono acquisti o elementi di design",
        "disponibili. I design di livello sono legati al tuo progresso",
        "e si sbloccano secondo le regole del progetto.",
      ]),
      ["design di livello", "differenza skin"],
    ),
    "8.2-3": item(
      "Come compro e attivo una skin?",
      j([
        "Prima acquista una skin disponibile in Shop, poi sceglila tra",
        "i tuoi design disponibili e attivala nell'interfaccia.",
      ]),
      ["comprare skin", "attivare skin"],
    ),
    "9.1-1": item(
      "Come ricarico il mio saldo?",
      j([
        "Apri la sezione di ricarica o di acquisto e segui il",
        "flusso disponibile sullo schermo. A seconda del passaggio,",
        "potrebbe essere necessaria una conferma nel Wallet.",
      ]),
      ["ricarica", "saldo"],
    ),
    "9.1-2": item(
      "Quando ho bisogno di un Wallet per un acquisto?",
      j([
        "Il Wallet serve quando l'acquisto richiede un pagamento e",
        "una conferma esterni. Per gli acquisti interni nel bot non",
        "è sempre obbligatorio.",
      ]),
      ["wallet necessario", "acquisto"],
    ),
    "9.2-1": item(
      "Come funziona un acquisto tramite Wallet?",
      j([
        "Scegli l'acquisto nel bot, lo confermi nel Wallet e poi",
        "torni nell'app. Dopo la conferma, il risultato appare nel",
        "bot.",
      ]),
      ["acquisto wallet", "pagamento wallet"],
    ),
    "9.2-2": item(
      "In cosa differisce un acquisto interno da uno con Wallet?",
      j([
        "Un acquisto interno usa i tuoi EFHC nel bot. Un acquisto",
        "tramite Wallet richiede una conferma esterna nel Wallet.",
      ]),
      ["acquisto interno", "wallet"],
    ),
    "9.2-3": item(
      "Cosa succede dopo il pagamento?",
      j([
        "Dopo un pagamento riuscito, il bot aggiorna il risultato",
        "dell'operazione. A volte succede subito, altre volte dopo",
        "una breve elaborazione.",
      ]),
      ["dopo pagamento", "risultato"],
    ),
    "9.2-4": item(
      "Perché non vedo subito il risultato dopo il pagamento?",
      j([
        "Alcune operazioni hanno bisogno di un po' di tempo prima",
        "che l'interfaccia si aggiorni. Aggiorna lo schermo e",
        "controlla la cronologia o la sezione necessaria.",
      ]),
      ["risultato non visibile", "dopo pagamento"],
    ),
    "10.1-1": item(
      "Che cos'è un livello?",
      j([
        "Il livello mostra il tuo progresso personale nel progetto.",
        "Può salire man mano che avanzi nelle meccaniche di gioco ed",
        "energia di EFHC Bot.",
      ]),
      ["livello", "progresso"],
    ),
    "10.1-2": item(
      "Che cos'è un rango?",
      j([
        "Il rango mostra la tua posizione rispetto agli altri",
        "partecipanti nella pagina Ranks.",
      ]),
      ["rango", "ranks"],
    ),
    "10.1-3": item(
      "Qual è la differenza tra livello e rango?",
      j([
        "Il livello mostra il tuo progresso personale, mentre il",
        "rango mostra la tua posizione rispetto agli altri utenti.",
      ]),
      ["differenza livello rango"],
    ),
    "10.1-4": item(
      "Che cosa mostra la pagina Ranks?",
      j([
        "La pagina Ranks mostra la classifica dei partecipanti e ti",
        "aiuta a capire il tuo posto attuale rispetto agli altri.",
      ]),
      ["pagina ranks", "posizione"],
    ),
    "11.1-1": item(
      "Perché non posso prelevare fondi?",
      j([
        "Di solito significa che per il prelievo serve saldo main,",
        "un Wallet oppure che le condizioni del progetto per questa",
        "azione non sono ancora soddisfatte.",
      ]),
      ["non posso prelevare", "prelievo"],
    ),
    "11.1-2": item(
      "Perché il Wallet non si collega?",
      j([
        "Controlla di aver aperto il Wallet corretto, che la",
        "connessione della Mini App non sia stata interrotta e che la",
        "conferma sia stata eseguita nel Wallet.",
      ]),
      ["wallet non si collega", "problema wallet"],
    ),
    "11.1-3": item(
      "Perché la mia panel non genera energia?",
      j([
        "Controlla la schermata Panels e lo stato della panel. Di",
        "solito il motivo dipende dalla fase del suo ciclo o dal",
        "fatto che stai guardando una parte non attiva della lista.",
      ]),
      ["panel non genera", "problema panel"],
    ),
    "11.1-4": item(
      "Perché lo stato VIP non viene mostrato?",
      j([
        "Controlla che l'NFT corretto sia nel Wallet collegato e che",
        "il bot veda già questo Wallet come attuale.",
      ]),
      ["vip non visibile", "stato"],
    ),
    "11.1-5": item(
      "Perché non ho ricevuto il bonus?",
      j([
        "Per prima cosa controlla la cronologia del saldo e la",
        "sezione collegata a questo bonus. Se il bonus non compare",
        "subito, aggiorna lo schermo.",
      ]),
      ["bonus mancante", "bonus"],
    ),
    "11.1-6": item(
      "Perché il mio referral è inattivo?",
      j([
        "Questo significa che l'utente arrivato tramite il tuo link",
        "non ha ancora completato la condizione necessaria per lo",
        "stato attivo nel sistema referral.",
      ]),
      ["referral inattivo", "inattivo"],
    ),
    "11.1-7": item(
      "Perché Shop è vuoto?",
      j([
        "Se Shop è vuoto, significa che al momento non ci sono",
        "articoli disponibili per il tuo schermo o che le posizioni",
        "necessarie non sono ancora mostrate nel negozio.",
      ]),
      ["shop vuoto", "nessun articolo"],
    ),
    "12.1-1": item(
      "Come cerco per parole nella FAQ?",
      j([
        "Apri la FAQ e inserisci nella barra di ricerca una parola",
        "chiara dell'interfaccia, per esempio saldo, Wallet, panel,",
        "Exchange o Withdraw.",
      ]),
      ["ricerca", "faq", "trovare"],
    ),
    "12.1-2": item(
      "Dove devo cercare una domanda sul saldo?",
      j([
        "Cercala nelle sezioni Balances e History del balance. Lì si",
        "spiega che cosa vedi nell'interfaccia e perché i tuoi fondi",
        "cambiano.",
      ]),
      ["dove saldo", "history"],
    ),
    "12.1-3": item(
      "Dove devo cercare una domanda sul Wallet?",
      j([
        "Apri la sezione Wallet. Raccoglie le domande sulla",
        "connessione, sul Wallet principale e sui problemi di",
        "collegamento.",
      ]),
      ["dove wallet", "wallet"],
    ),
    "12.1-4": item(
      "Che cosa devo fare se non ho trovato la risposta?",
      j([
        "Prova un'altra parola chiara basata sull'interfaccia del bot",
        "oppure apri una sezione vicina per significato. Se la",
        "domanda riguarda Wallet, History, Panels o Exchange, usa",
        "proprio queste parole.",
      ]),
      ["risposta non trovata", "altra ricerca"],
    ),
  },
  tr: {
    "1.1-1": item(
      "Toplam bakiye nedir?",
      j([
        "Toplam bakiye, şu anda bot içinde sahip olduğunuz tüm EFHC",
        "miktarını gösterir. Genel kaynaklarınızı anlamak için",
        "yararlıdır, ancak çekilebilir tutarla aynı değildir.",
      ]),
      ["toplam bakiye", "tum fonlar", "genel bakiye"],
    ),
    "1.1-2": item(
      "Ana bakiye nedir?",
      j([
        "Ana bakiye, projenin temel işlemlerinde kullanılan fon",
        "kısmıdır. Çekim için kullanılan bakiye budur.",
      ]),
      ["ana bakiye", "cekim bakiyesi"],
    ),
    "1.1-3": item(
      "Bonus bakiye nedir?",
      j([
        "Bonus bakiye, bot içindeki fonlarınızın dahili kısmıdır.",
        "Bot içi işlemler ve satın almalar için kullanılır, ancak",
        "çekim için kullanılmaz.",
      ]),
      ["bonus bakiye", "bonus fonlar"],
    ),
    "1.1-4": item(
      "Toplam, ana ve bonus bakiye arasındaki fark nedir?",
      j([
        "Toplam bakiye bot içindeki tüm fonlarınızdır. Ana bakiye",
        "değişim ve çekim için kullanılır. Bonus bakiye, bot içi",
        "işlemler ve satın almalar için kullanılır.",
      ]),
      ["bakiye farki", "ana", "bonus", "toplam"],
    ),
    "1.2-1": item(
      "Neden toplam bakiyenin tamamını çekemiyorum?",
      j([
        "Çünkü toplam bakiye hem ana hem bonus EFHC içerir. Çekim",
        "için yalnızca ana bakiye kullanılır.",
      ]),
      ["cekim", "toplam bakiye", "neden olmaz"],
    ),
    "1.2-2": item(
      "Neden bir satın alma bonus ve ana bakiyeyi etkileyebilir?",
      j([
        "Çünkü bot tek bir işlem için dahili fonlarınızı sırayla",
        "kullanabilir. Bu yüzden bir satın alma aynı anda iki",
        "bakiyeyi azaltabilir.",
      ]),
      ["satin alma", "iki bakiye", "ana ve bonus"],
    ),
    "2.1-1": item(
      "Bakiye geçmişi neyi gösterir?",
      j([
        "Bakiye geçmişi fonlarınızdaki değişiklikleri gösterir:",
        "girişler, harcamalar ve bot içindeki bakiyeyi etkileyen",
        "diğer işlemler.",
      ]),
      ["bakiye gecmisi", "islemler", "gecmis"],
    ),
    "2.1-2": item(
      "Bakiye geçmişinde hangi işlemler görünür?",
      j([
        "Geçmiş, ana veya bonus bakiyeyi değiştiren işlemleri",
        "gösterir: ödüller, harcamalar, satın almalar, değişim ve",
        "bot içindeki diğer işlemler.",
      ]),
      ["gecmis", "islemler", "oduller", "harcamalar"],
    ),
    "2.1-3": item(
      "Bakiyem neden değişti?",
      j([
        "Bakiyeniz bot içindeki işlemlerden sonra değişir: satın",
        "almalar, bonus ödülleri, enerji değişimi, çekim ve diğer",
        "işlemler. Bakiye geçmişi nedeni görmenize yardım eder.",
      ]),
      ["bakiye degisti", "neden"],
    ),
    "2.1-4": item(
      "Fonların neden geldiğini veya gittiğini nasıl anlarım?",
      j([
        "Bakiye geçmişini açın ve işlem açıklamasına bakın. Hangi",
        "eylemin girişe ya da harcamaya yol açtığını orada",
        "görebilirsiniz.",
      ]),
      ["neden", "giris", "harcama", "gecmis"],
    ),
    "3.1-1": item(
      "Panel nedir?",
      j([
        "Bir panel, EFHC Bot içindeki oyun ve enerji ilerlemenin",
        "temelidir. Satın alındıktan sonra projedeki enerji üretimine",
        "katılır.",
      ]),
      ["panel", "solar panel"],
    ),
    "3.1-2": item(
      "Panel bana ne kazandırır?",
      j([
        "Panel sana enerji üretimi, projede ilerleme ve enerjiyi daha",
        "sonra EFHC'ye dönüştürmek için bir temel kazandırır.",
      ]),
      ["panel ne verir", "üretim", "ilerleme"],
    ),
    "3.1-3": item(
      "Paneli nasıl satın alırım?",
      j([
        "Panels bölümünü aç, satın almayı seç ve işlemi onayla.",
        "Satın alma başarılı olduktan sonra panel listenizde görünür.",
      ]),
      ["panel satın al", "panels"],
    ),
    "3.1-4": item(
      "Birden fazla panelim olursa ne olur?",
      j([
        "Birden fazla panelin varsa her biri toplam ilerlemene katkı",
        "sağlar ve proje içindeki enerji miktarını artırır.",
      ]),
      ["birden fazla panel", "çok panel"],
    ),
    "3.1-5": item(
      "Panel arşivi ne anlama gelir?",
      j([
        "Panel arşivi, bu döngünün artık ekranın aktif kısmında",
        "olmadığı, ancak panelin ilerleme geçmişinin bir parçası",
        "olarak kaldığı anlamına gelir.",
      ]),
      ["panel arşivi", "arşiv"],
    ),
    "3.2-1": item(
      "Enerji nasıl oluşur?",
      j([
        "Enerji panellerin sayesinde oluşur. Bot içinde enerjinin",
        "büyümesini sağlayan şey panellerdir.",
      ]),
      ["enerji nasıl oluşur", "enerji"],
    ),
    "3.2-2": item(
      "Kullanılabilir enerji nedir?",
      j([
        "Kullanılabilir enerji, proje mekanikleri içinde daha sonra",
        "kullanabileceğin enerji kısmıdır.",
      ]),
      ["kullanılabilir enerji", "available energy"],
    ),
    "3.2-3": item(
      "Bir panel neden üretmeyi durdurabilir?",
      j([
        "Bu genelde panelin durumu, döngüsü veya ekranın aktif olmayan",
        "bir kısmına bakıyor olmanla ilgilidir. Panels bölümünü ve",
        "panelin mevcut durumunu kontrol et.",
      ]),
      ["üretmiyor", "panel çalışmıyor"],
    ),
    "4.1-1": item(
      "Exchange nedir?",
      j([
        "Exchange, kullanılabilir enerjinin proje kurallarına göre",
        "EFHC'ye dönüştüğü işlemdir.",
      ]),
      ["exchange", "enerji dönüştür"],
    ),
    "4.1-2": item(
      "Exchange sonrası ne olur?",
      j([
        "Exchange sonrası enerjinin bir kısmı kullanılmış sayılır ve",
        "EFHC ana bakiyene eklenir.",
      ]),
      ["exchange sonrası", "ana bakiye"],
    ),
    "4.1-3": item(
      "Önce ne zaman exchange gerekir, ne zaman withdraw hazırdır?",
      j([
        "Enerjin varsa ama ana bakiyende henüz yeterli tutar",
        "yoksa önce",
        "exchange gerekir. Withdraw ana bakiye için kullanılır.",
      ]),
      ["önce exchange", "sonra withdraw"],
    ),
    "4.2-1": item(
      "Withdraw nedir?",
      j([
        "Withdraw, kullanıcının proje kurallarına göre ana bakiyeden",
        "EFHC göndermesini sağlayan işlemdir.",
      ]),
      ["withdraw", "çekim"],
    ),
    "4.2-2": item(
      "Bonus bakiyeyi neden çekemiyorum?",
      j([
        "Çünkü bonus bakiye oyun içi kullanım içindir. Çekim için",
        "yalnızca ana bakiye kullanılır.",
      ]),
      ["bonus çekemiyorum", "bonus bakiye"],
    ),
    "4.2-3": item(
      "Withdraw talebinden sonra ana bakiyem neden değişti?",
      j([
        "Çünkü talep oluşturulduktan sonra bu tutar hemen",
        "bu işlem için",
        "ayrılmış sayılır ve başka işlemler için serbest kalmaz.",
      ]),
      ["withdraw talebi", "bakiye değişti"],
    ),
    "4.2-4": item(
      "Withdraw neden kullanılamıyor olabilir?",
      j([
        "Withdraw, proje koşulları henüz sağlanmadıysa, ana bakiyede",
        "yeterli tutar yoksa veya bağlı bir wallet yoksa kullanılamaz.",
      ]),
      ["withdraw kullanılamıyor", "wallet"],
    ),
    "5.1-1": item(
      "Neden bir wallet gerekir?",
      j([
        "Wallet, proje dış onay ve adresinle bağlantı istediğinde",
        "gerekir. VIP NFT ve ilgili işlemler için de önemlidir.",
      ]),
      ["neden wallet", "wallet"],
    ),
    "5.1-2": item(
      "Wallet nasıl bağlanır?",
      j([
        "Wallet bölümünü aç, bağlan seçeneğini seç ve desteklenen bir",
        "wallet uygulamasında işlemi onayla.",
      ]),
      ["wallet bağla", "wallet connect"],
    ),
    "5.1-3": item(
      "Birincil wallet nedir?",
      j([
        "Birincil wallet, seçtiğin adresin gerektiği işlemlerde botun",
        "ana wallet olarak kullandığı wallet'tır.",
      ]),
      ["birincil wallet", "main wallet"],
    ),
    "5.1-4": item(
      "Birden fazla wallet bağlayabilir miyim?",
      j([
        "Evet. Bot birkaç bağlı wallet saklayabilir ve bağlı listeden",
        "birincil olanı seçmene izin verir.",
      ]),
      ["birkaç wallet", "birincil wallet"],
    ),
    "5.1-5": item(
      "Wallet bağlanmıyorsa ne yapmalıyım?",
      j([
        "Doğru wallet uygulamasının açık olduğunu, Telegram Mini App",
        "bağlantısının kesilmediğini ve bağlantıyı wallet içinde",
        "onayladığını kontrol et. Sonra tekrar dene.",
      ]),
      ["bağlanmıyor", "wallet sorunu"],
    ),
    "6.1-1": item(
      "Referral nedir?",
      j([
        "Referral, senin linkin üzerinden projeye gelen ve referral",
        "sistemi kurallarına göre ilerlemeni etkileyen",
        "kullanıcılardır.",
      ]),
      ["referral", "davet edilen kullanıcılar"],
    ),
    "6.1-2": item(
      "Referral linkim nasıl çalışır?",
      j([
        "Linkini yeni bir kullanıcıyla paylaşırsın. Kullanıcı projeye",
        "o linkten girerse referral sisteminde sana yazılır.",
      ]),
      ["referral linki", "davet linki"],
    ),
    "6.1-3": item(
      "Kim aktif referral sayılır?",
      j([
        "Aktif referral, projedeki gerekli koşulu tamamlamış ve aktif",
        "referral istatistiklerine dahil edilen kullanıcıdır.",
      ]),
      ["aktif referral", "referral aktif"],
    ),
    "6.1-4": item(
      "Kim pasif referral sayılır?",
      j([
        "Pasif referral, linkin üzerinden gelen ancak aktif durum için",
        "gerekli koşulu henüz tamamlamamış kullanıcıdır.",
      ]),
      ["pasif referral", "referral pasif"],
    ),
    "6.1-5": item(
      "Referrals sayfasındaki sayaçlar neyi gösterir?",
      j([
        "Sayaçlar toplam referral sayını, kaçının aktif olduğunu ve",
        "bunun referral sistemi içindeki ilerlemeni nasıl etkilediğini",
        "gösterir.",
      ]),
      ["sayaçlar", "referrals sayfası"],
    ),
    "6.1-6": item(
      "Bir sonraki seviyeye ilerleme nasıl çalışır?",
      j([
        "İlerleme, referral çizgindeki bir sonraki adım için ne kadar",
        "kaldığını gösterir. Bir sonraki seviye veya bonusa ne kadar",
        "yakın olduğunu hızlıca görmene yardım eder.",
      ]),
      ["ilerleme", "sonraki seviye"],
    ),
    "7.1-1": item(
      "VIP NFT nedir?",
      j([
        "VIP NFT, EFHC Bot kurallarına göre kullanıcıya VIP etkisi",
        "veren özel bir proje NFT'sidir.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "VIP NFT bana ne kazandırır?",
      j([
        "VIP NFT proje içinde özel avantajlar sağlar. Arayüzde bu, VIP",
        "durumu ve ilgili proje etkileriyle bağlantılıdır.",
      ]),
      ["vip nft ne verir", "vip durumu"],
    ),
    "7.1-3": item(
      "VIP NFT için bağlı bir wallet gerekir mi?",
      j([
        "Evet. Botun VIP NFT'ni görmesi ve onu durumunla doğru şekilde",
        "eşleştirmesi için bağlı bir wallet gerekir.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "VIP durumu ne zaman aktif olur?",
      j([
        "Bot bağlı wallet içinde doğru NFT'yi gördüğünde, VIP durumu",
        "proje kurallarına göre otomatik olarak güncellenir.",
      ]),
      ["vip durumu", "aktif olur"],
    ),
    "7.1-5": item(
      "NFT'im var ama durum görünmüyorsa ne yapmalıyım?",
      j([
        "NFT'nin doğru bağlı wallet içinde olduğunu ve bu wallet'ın",
        "botta hâlâ geçerli olduğunu kontrol et.",
        "Sonra ekranı yenileyip",
        "yeniden kontrol et.",
      ]),
      ["nft var", "durum görünmüyor"],
    ),
    "8.1-1": item(
      "Shop nedir?",
      j([
        "Shop, kullanıcının bot içi öğeler ve arayüz stiliyle ilgili",
        "diğer proje unsurlarını satın alabildiği bölümdür.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "Shop'ta ne satın alabilirim?",
      j([
        "Shop'ta şu anda sana gösterilen mevcut proje öğelerini,",
        "örneğin skinleri ve diğer uygun unsurları satın",
        "alabilirsin.",
      ]),
      ["ne satın alınır", "öğeler"],
    ),
    "8.1-3": item(
      "EFHC ile alım Wallet ile alımdan nasıl farklıdır?",
      j([
        "EFHC ile alım bot içindeki fonlarını kullanır. Wallet ile",
        "alım, wallet üzerinden dış onay gerektirir.",
      ]),
      ["efhc ile alım", "wallet ile"],
    ),
    "8.1-4": item(
      "Shop neden boş görünebilir?",
      j([
        "Şu anda ekranın için uygun öğe yoksa veya bölüm henüz uygun",
        "öğelerle doldurulmadıysa Shop boş görünebilir.",
      ]),
      ["shop boş", "hiçbir şey görünmüyor"],
    ),
    "8.2-1": item(
      "Skin nedir?",
      j([
        "Skinler, proje içinde arayüzün bazı bölümlerinin görünümünü",
        "değiştiren görsel tasarım öğeleridir.",
      ]),
      ["skin", "tasarım"],
    ),
    "8.2-2": item(
      "Normal skinler seviye tasarımlarından nasıl farklıdır?",
      j([
        "Normal skinler satın alınabilen veya kullanılabilen tasarım",
        "öğeleridir. Seviye tasarımları ise ilerlemenle bağlantılıdır",
        "ve proje kurallarına göre açılır.",
      ]),
      ["seviye tasarımı", "skin farkı"],
    ),
    "8.2-3": item(
      "Bir skini nasıl satın alır ve etkinleştiririm?",
      j([
        "Önce Shop'tan uygun bir skin satın al, sonra mevcut",
        "tasarımların arasından seç ve arayüzde etkinleştir.",
      ]),
      ["skin satın al", "skin etkinleştir"],
    ),
    "9.1-1": item(
      "Bakiyemi nasıl yüklerim?",
      j([
        "Yükleme veya satın alma bölümünü açın ve ekrandaki akışı",
        "izleyin. Adıma göre Wallet içinde onay gerekebilir.",
      ]),
      ["bakiye yükleme", "yükleme"],
    ),
    "9.1-2": item(
      "Bir satın alma için ne zaman Wallet gerekir?",
      j([
        "Satın alma dış ödeme ve onay gerektiriyorsa Wallet gerekir.",
        "Bot içindeki dahili alımlarda Wallet her zaman zorunlu",
        "değildir.",
      ]),
      ["wallet gerekli", "satın alma"],
    ),
    "9.2-1": item(
      "Wallet ile satın alma nasıl çalışır?",
      j([
        "Bot içinde satın almayı seçersiniz, Wallet'ta onaylarsınız",
        "ve sonra uygulamaya dönersiniz. Onaydan sonra sonuç botta",
        "görünür.",
      ]),
      ["wallet satın alma", "wallet ödeme"],
    ),
    "9.2-2": item(
      "Dahili satın alma ile Wallet satın alması nasıl farklıdır?",
      j([
        "Dahili satın alma bot içindeki EFHC'nizi kullanır. Wallet",
        "üzerinden satın alma ise dış onay gerektirir.",
      ]),
      ["dahili satın alma", "wallet"],
    ),
    "9.2-3": item(
      "Ödemeden sonra ne olur?",
      j([
        "Başarılı ödemeden sonra bot işlemin sonucunu günceller.",
        "Bazen hemen, bazen kısa bir işlemden sonra görünür.",
      ]),
      ["ödemeden sonra", "sonuç"],
    ),
    "9.2-4": item(
      "Ödemeden hemen sonra neden sonucu görmüyorum?",
      j([
        "Bazı işlemler arayüz güncellenmeden önce kısa bir süreye",
        "ihtiyaç duyar. Ekranı yenileyin ve geçmişi veya ilgili",
        "bölümü kontrol edin.",
      ]),
      ["sonuç görünmüyor", "ödemeden sonra"],
    ),
    "10.1-1": item(
      "Seviye nedir?",
      j([
        "Seviye, proje içindeki kişisel ilerlemenizi gösterir. EFHC",
        "Bot'un oyun ve enerji mekaniklerinde ilerledikçe artabilir.",
      ]),
      ["seviye", "ilerleme"],
    ),
    "10.1-2": item(
      "Sıralama nedir?",
      j([
        "Sıralama, Ranks sayfasında diğer katılımcılara göre",
        "konumunuzu gösterir.",
      ]),
      ["sıralama", "ranks"],
    ),
    "10.1-3": item(
      "Seviye ile sıralama arasındaki fark nedir?",
      j([
        "Seviye kişisel ilerlemenizi, sıralama ise diğer kullanıcılar",
        "arasındaki yerinizi gösterir.",
      ]),
      ["seviye sıralama farkı"],
    ),
    "10.1-4": item(
      "Ranks sayfası ne gösterir?",
      j([
        "Ranks sayfası katılımcı listesini gösterir ve başkalarına",
        "göre mevcut yerinizi anlamanıza yardımcı olur.",
      ]),
      ["ranks sayfası", "yer"],
    ),
    "11.1-1": item(
      "Neden para çekemiyorum?",
      j([
        "Genellikle bu, çekim için main bakiye, bir Wallet veya bu",
        "eylem için proje koşullarının henüz tamamlanmadığı anlamına",
        "gelir.",
      ]),
      ["çekemiyorum", "çekim"],
    ),
    "11.1-2": item(
      "Wallet neden bağlanmıyor?",
      j([
        "Doğru Wallet'ı açtığınızdan, Mini App bağlantısının",
        "kesilmediğinden ve onayın Wallet içinde yapıldığından emin",
        "olun.",
      ]),
      ["wallet bağlanmıyor", "wallet sorunu"],
    ),
    "11.1-3": item(
      "Panelim neden enerji üretmiyor?",
      j([
        "Panels ekranını ve panel durumunu kontrol edin. Genelde",
        "neden, döngünün aşaması veya listenin aktif olmayan bir",
        "kısmına bakıyor olmanızdır.",
      ]),
      ["panel üretmiyor", "panel sorunu"],
    ),
    "11.1-4": item(
      "VIP durumu neden görünmüyor?",
      j([
        "Doğru NFT'nin bağlı Wallet içinde olduğundan ve botun bu",
        "Wallet'ı güncel olarak gördüğünden emin olun.",
      ]),
      ["vip görünmüyor", "durum"],
    ),
    "11.1-5": item(
      "Bonusu neden almadım?",
      j([
        "Önce bakiye geçmişini ve bu bonusla bağlantılı bölümü",
        "kontrol edin. Bonus hemen görünmüyorsa ekranı yenileyin.",
      ]),
      ["bonus gelmedi", "bonus"],
    ),
    "11.1-6": item(
      "Referral'ım neden pasif?",
      j([
        "Bu, bağlantınızdan gelen kullanıcının referral sisteminde",
        "aktif durum için gereken koşulu henüz tamamlamadığı anlamına",
        "gelir.",
      ]),
      ["pasif referral", "pasif"],
    ),
    "11.1-7": item(
      "Shop neden boş?",
      j([
        "Shop boşsa, şu anda ekranınız için uygun ürün yoktur veya",
        "gerekli öğeler henüz mağazada gösterilmiyordur.",
      ]),
      ["shop boş", "ürün yok"],
    ),
    "12.1-1": item(
      "FAQ içinde kelimelerle nasıl arama yaparım?",
      j([
        "FAQ'ı açın ve arama çubuğuna arayüzde gördüğünüz açık bir",
        "kelime yazın: örneğin balance, Wallet, panel, Exchange veya",
        "Withdraw.",
      ]),
      ["arama", "faq", "bul"],
    ),
    "12.1-2": item(
      "Bakiye ile ilgili bir soruyu nerede aramalıyım?",
      j([
        "Onu Balances ve History del balance bölümlerinde arayın.",
        "Bu bölümler arayüzde ne gördüğünüzü ve fonların neden",
        "değiştiğini açıklar.",
      ]),
      ["nerede bakiye", "history"],
    ),
    "12.1-3": item(
      "Wallet ile ilgili bir soruyu nerede aramalıyım?",
      j([
        "Wallet bölümünü açın. Bağlantı, birincil Wallet ve bağlantı",
        "sorunları hakkındaki sorular burada toplanır.",
      ]),
      ["nerede wallet", "wallet"],
    ),
    "12.1-4": item(
      "Cevabı bulamadıysam ne yapmalıyım?",
      j([
        "Bot arayüzüne dayalı başka bir açık kelime deneyin veya",
        "anlamca yakın bir bölümü açın. Soru Wallet, History, Panels",
        "veya Exchange ile ilgiliyse bu kelimeleri kullanın.",
      ]),
      ["cevap yok", "başka arama"],
    ),
  },
  pl: {
    "1.1-1": item(
      "Czym jest saldo całkowite?",
      j([
        "Saldo całkowite pokazuje wszystkie EFHC, które macie teraz",
        "w bocie. Pomaga zrozumieć ogólne zasoby, ale nie jest tym",
        "samym co kwota dostępna do wypłaty.",
      ]),
      ["saldo calkowite", "wszystkie srodki", "saldo ogolne"],
    ),
    "1.1-2": item(
      "Czym jest saldo główne?",
      j([
        "Saldo główne to część waszych środków używana do",
        "kluczowych działań projektu. To właśnie ono bierze udział w",
        "wypłacie.",
      ]),
      ["saldo glowne", "saldo do wyplaty"],
    ),
    "1.1-3": item(
      "Czym jest saldo bonusowe?",
      j([
        "Saldo bonusowe to wewnętrzna część waszych środków w",
        "bocie. Służy do działań i zakupów w projekcie, ale nie do",
        "wypłaty.",
      ]),
      ["saldo bonusowe", "srodki bonusowe"],
    ),
    "1.1-4": item(
      "Czym różni się saldo całkowite od głównego i bonusowego?",
      j([
        "Saldo całkowite obejmuje wszystkie wasze środki w bocie.",
        "Saldo główne służy do wymiany i wypłaty. Saldo bonusowe",
        "służy do działań i zakupów wewnętrznych.",
      ]),
      ["roznica sald", "glowne", "bonusowe", "calkowite"],
    ),
    "1.2-1": item(
      "Dlaczego nie mogę wypłacić całego salda całkowitego?",
      j([
        "Ponieważ saldo całkowite obejmuje zarówno główne, jak i",
        "bonusowe EFHC. Do wypłaty używa się tylko salda głównego.",
      ]),
      ["wyplata", "saldo calkowite", "dlaczego nie"],
    ),
    "1.2-2": item(
      "Dlaczego jeden zakup może dotknąć bonus i saldo główne?",
      j([
        "Bot może wykorzystywać wasze środki wewnętrzne krok po",
        "kroku do jednej operacji. Dlatego jeden zakup może",
        "jednocześnie zmniejszyć dwa salda.",
      ]),
      ["zakup", "dwa salda", "bonus i glowne"],
    ),
    "2.1-1": item(
      "Co pokazuje historia salda?",
      j([
        "Historia salda pokazuje zmiany waszych środków: wpływy,",
        "wydatki i inne działania, które wpłynęły na saldo w",
        "bocie.",
      ]),
      ["historia salda", "operacje", "historia"],
    ),
    "2.1-2": item(
      "Jakie działania pojawiają się w historii salda?",
      j([
        "Historia pokazuje działania, które zmieniają saldo główne",
        "lub bonusowe: nagrody, wydatki, zakupy, wymianę i inne",
        "działania w bocie.",
      ]),
      ["historia", "operacje", "nagrody", "wydatki"],
    ),
    "2.1-3": item(
      "Dlaczego moje saldo się zmieniło?",
      j([
        "Saldo zmienia się po działaniach w bocie: zakupach,",
        "bonusach, wymianie energii, wypłacie i innych operacjach.",
        "Historia salda pomaga zobaczyć przyczynę.",
      ]),
      ["saldo sie zmienilo", "dlaczego"],
    ),
    "2.1-4": item(
      "Jak zrozumieć, za co środki przyszły albo wyszły?",
      j([
        "Otwórzcie historię salda i sprawdźcie opis operacji. Tam",
        "widać, które działanie spowodowało wpływ albo wydatek.",
      ]),
      ["dlaczego", "wplyw", "wydatek", "historia"],
    ),
    "3.1-1": item(
      "Czym jest panel?",
      j([
        "Panel jest podstawą twojego postępu w grze i energii w EFHC",
        "Bot. Po zakupie bierze udział w generowaniu energii w",
        "projekcie.",
      ]),
      ["panel", "solar panel"],
    ),
    "3.1-2": item(
      "Co daje mi panel?",
      j([
        "Panel daje ci generowanie energii, postęp w projekcie i bazę",
        "do późniejszej wymiany energii na EFHC.",
      ]),
      ["co daje panel", "generowanie", "postęp"],
    ),
    "3.1-3": item(
      "Jak kupić panel?",
      j([
        "Otwórz sekcję Panels, wybierz zakup i potwierdź działanie.",
        "Po udanym zakupie panel pojawi się na twojej liście.",
      ]),
      ["kup panel", "panels"],
    ),
    "3.1-4": item(
      "Co się stanie, jeśli mam kilka paneli?",
      j([
        "Jeśli masz kilka paneli, każdy z nich wpływa na twój ogólny",
        "postęp i zwiększa ilość energii w projekcie.",
      ]),
      ["kilka paneli", "wiele paneli"],
    ),
    "3.1-5": item(
      "Co oznacza archiwum panelu?",
      j([
        "Archiwum panelu oznacza, że ten cykl nie znajduje się już w",
        "aktywnej części ekranu, ale panel pozostaje częścią historii",
        "twojego postępu.",
      ]),
      ["archiwum panelu", "archiwum"],
    ),
    "3.2-1": item(
      "Jak pojawia się energia?",
      j([
        "Energia pojawia się dzięki twoim panelom. To właśnie panele",
        "sprawiają, że energia rośnie w bocie.",
      ]),
      ["jak pojawia się energia", "energia"],
    ),
    "3.2-2": item(
      "Czym jest dostępna energia?",
      j([
        "Dostępna energia to ta część energii, którą możesz dalej",
        "wykorzystać w mechanice projektu.",
      ]),
      ["dostępna energia", "available energy"],
    ),
    "3.2-3": item(
      "Dlaczego panel może przestać generować?",
      j([
        "Zwykle jest to związane ze stanem panelu, jego cyklem lub z",
        "tym, że patrzysz na nieaktywną część ekranu. Sprawdź sekcję",
        "Panels i bieżący stan panelu.",
      ]),
      ["nie generuje", "panel nie działa"],
    ),
    "4.1-1": item(
      "Czym jest exchange?",
      j([
        "Exchange to działanie, w którym twoja dostępna energia",
        "zamienia się na EFHC zgodnie z zasadami projektu.",
      ]),
      ["exchange", "zamiana energii"],
    ),
    "4.1-2": item(
      "Co dzieje się po exchange?",
      j([
        "Po exchange część twojej energii jest liczona jako użyta, a",
        "EFHC trafiają na główny balans.",
      ]),
      ["po exchange", "główny balans"],
    ),
    "4.1-3": item(
      "Kiedy najpierw potrzebny jest exchange, a kiedy withdraw?",
      j([
        "Jeśli masz energię, ale jeszcze za mało środków na głównym",
        "balansie, najpierw potrzebny jest exchange. Withdraw dotyczy",
        "głównego balansu.",
      ]),
      ["najpierw exchange", "potem withdraw"],
    ),
    "4.2-1": item(
      "Czym jest withdraw?",
      j([
        "Withdraw to działanie, które pozwala użytkownikowi wysłać",
        "EFHC z głównego balansu zgodnie z zasadami projektu.",
      ]),
      ["withdraw", "wypłata"],
    ),
    "4.2-2": item(
      "Dlaczego nie mogę wypłacić bonusowego balansu?",
      j([
        "Ponieważ bonusowy balans służy do wewnętrznego użycia w grze.",
        "Do wypłaty używany jest tylko główny balans.",
      ]),
      ["nie mogę wypłacić bonusu", "bonusowy balans"],
    ),
    "4.2-3": item(
      "Dlaczego po zleceniu withdraw zmienił się główny balans?",
      j([
        "Ponieważ po utworzeniu zlecenia ta kwota od razu jest liczona",
        "dla tej operacji i nie jest już wolna dla innych działań.",
      ]),
      ["zlecenie withdraw", "balans zmieniony"],
    ),
    "4.2-4": item(
      "Dlaczego withdraw może być niedostępny?",
      j([
        "Withdraw może być niedostępny, jeśli warunki projektu nie są",
        "jeszcze spełnione, jeśli na głównym balansie jest za mało lub",
        "nie masz podłączonego walleta.",
      ]),
      ["withdraw niedostępny", "wallet"],
    ),
    "5.1-1": item(
      "Po co mi wallet?",
      j([
        "Wallet jest potrzebny do działań, w których projekt wymaga",
        "zewnętrznego potwierdzenia i połączenia z twoim adresem.",
        "Jest też ważny dla VIP NFT i powiązanych działań.",
      ]),
      ["po co wallet", "wallet"],
    ),
    "5.1-2": item(
      "Jak podłączyć wallet?",
      j([
        "Otwórz sekcję Wallet, wybierz połączenie i",
        "potwierdź działanie",
        "w obsługiwanej aplikacji walleta.",
      ]),
      ["podłącz wallet", "wallet connect"],
    ),
    "5.1-3": item(
      "Czym jest główny wallet?",
      j([
        "Główny wallet to wallet, którego bot używa jako głównego do",
        "działań, w których potrzebny jest wybrany przez ciebie adres.",
      ]),
      ["główny wallet", "primary wallet"],
    ),
    "5.1-4": item(
      "Czy mogę podłączyć kilka walletów?",
      j([
        "Tak. Bot może przechowywać kilka podłączonych walletów i",
        "pozwala wybrać główny z listy połączonych.",
      ]),
      ["kilka walletów", "primary wallet"],
    ),
    "5.1-5": item(
      "Co zrobić, jeśli wallet się nie łączy?",
      j([
        "Sprawdź, czy otwarta jest właściwa aplikacja walleta, czy",
        "połączenie Telegram Mini App nie zostało przerwane i czy",
        "potwierdzasz połączenie w samym wallecie. Potem spróbuj",
        "ponownie.",
      ]),
      ["nie łączy się", "problem z walletem"],
    ),
    "6.1-1": item(
      "Czym są referral?",
      j([
        "Referral to użytkownicy, którzy przyszli do projektu przez",
        "twój link i potem wpływają na twój postęp zgodnie z zasadami",
        "systemu referral.",
      ]),
      ["referral", "zaproszeni użytkownicy"],
    ),
    "6.1-2": item(
      "Jak działa mój link referral?",
      j([
        "Udostępniasz swój link nowemu użytkownikowi. Jeśli wejdzie do",
        "projektu przez ten link, zostanie uwzględniony w twoim",
        "systemie referral.",
      ]),
      ["link referral", "link zaproszenia"],
    ),
    "6.1-3": item(
      "Kto jest liczony jako aktywny referral?",
      j([
        "Aktywny referral to użytkownik, który spełnił już wymagany",
        "warunek projektu i jest uwzględniany w twoich aktywnych",
        "statystykach referral.",
      ]),
      ["aktywny referral", "referral aktywny"],
    ),
    "6.1-4": item(
      "Kto jest liczony jako nieaktywny referral?",
      j([
        "Nieaktywny referral to użytkownik, który wszedł przez twój",
        "link, ale jeszcze nie spełnił warunku aktywnego statusu.",
      ]),
      ["nieaktywny referral", "referral nieaktywny"],
    ),
    "6.1-5": item(
      "Co pokazują liczniki na stronie referrals?",
      j([
        "Liczniki pokazują, ilu masz referral łącznie, ilu z nich jest",
        "aktywnych i jak wpływa to na twój postęp w systemie referral.",
      ]),
      ["liczniki", "strona referrals"],
    ),
    "6.1-6": item(
      "Jak działa postęp do następnego poziomu?",
      j([
        "Postęp pokazuje, ile jeszcze brakuje do kolejnego kroku w",
        "twojej linii referral. Pomaga szybko zobaczyć, ile zostało do",
        "następnego poziomu lub bonusu.",
      ]),
      ["postęp", "następny poziom"],
    ),
    "7.1-1": item(
      "Czym jest VIP NFT?",
      j([
        "VIP NFT to specjalne NFT projektu, które daje użytkownikowi",
        "efekt VIP zgodnie z zasadami EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "Co daje VIP NFT?",
      j([
        "VIP NFT daje specjalne korzyści w projekcie. W interfejsie",
        "wiąże się to ze statusem VIP i odpowiednimi",
        "efektami projektu.",
      ]),
      ["co daje vip nft", "status vip"],
    ),
    "7.1-3": item(
      "Czy do VIP NFT potrzebny jest podłączony wallet?",
      j([
        "Tak. Bot potrzebuje podłączonego walleta, aby zobaczyć twoje",
        "VIP NFT i poprawnie połączyć je z twoim statusem.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "Kiedy status VIP staje się aktywny?",
      j([
        "Gdy bot widzi właściwe NFT w podłączonym wallecie, status VIP",
        "jest aktualizowany automatycznie zgodnie z zasadami projektu.",
      ]),
      ["status vip", "staje się aktywny"],
    ),
    "7.1-5": item(
      "Co zrobić, jeśli mam NFT, ale statusu nie widać?",
      j([
        "Sprawdź, czy NFT znajduje się we właściwym podłączonym",
        "wallecie i czy ten wallet jest nadal aktualny w bocie. Potem",
        "odśwież ekran i sprawdź ponownie.",
      ]),
      ["mam nft", "brak statusu"],
    ),
    "8.1-1": item(
      "Czym jest Shop?",
      j([
        "Shop to sekcja, w której użytkownik może kupować elementy w",
        "bocie i inne rzeczy projektu związane ze stylem interfejsu.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "Co mogę kupić w Shop?",
      j([
        "W Shop możesz kupować aktualnie dostępne elementy projektu,",
        "takie jak skiny i inne odpowiednie pozycje.",
      ]),
      ["co kupić", "elementy"],
    ),
    "8.1-3": item(
      "Czym zakup za EFHC różni się od zakupu przez Wallet?",
      j([
        "Zakup za EFHC wykorzystuje twoje środki w bocie. Zakup przez",
        "Wallet wymaga zewnętrznego potwierdzenia w twoim wallecie.",
      ]),
      ["zakup za efhc", "przez wallet"],
    ),
    "8.1-4": item(
      "Dlaczego Shop może nic nie pokazywać?",
      j([
        "Może tak być, jeśli obecnie nie ma dostępnych elementów dla",
        "twojego ekranu albo sekcja nie została jeszcze wypełniona",
        "odpowiednimi pozycjami.",
      ]),
      ["shop pusty", "nic nie widać"],
    ),
    "8.2-1": item(
      "Czym są skiny?",
      j([
        "Skiny to wizualne elementy projektu, które zmieniają wygląd",
        "części interfejsu w projekcie.",
      ]),
      ["skiny", "design"],
    ),
    "8.2-2": item(
      "Czym zwykłe skiny różnią się od skinów poziomowych?",
      j([
        "Zwykłe skiny to dostępne zakupy lub elementy wyglądu. Skiny",
        "poziomowe są powiązane z twoim postępem i odblokowują się",
        "zgodnie z zasadami projektu.",
      ]),
      ["skin poziomowy", "różnica skinów"],
    ),
    "8.2-3": item(
      "Jak kupić i aktywować skin?",
      j([
        "Najpierw kup dostępny skin w Shop, potem wybierz go spośród",
        "swoich dostępnych wyglądów i aktywuj w interfejsie.",
      ]),
      ["kup skin", "aktywuj skin"],
    ),
    "9.1-1": item(
      "Jak doładować moje saldo?",
      j([
        "Otwórz sekcję doładowania lub zakupu i postępuj zgodnie z",
        "krokami na ekranie. W zależności od etapu może być potrzebne",
        "potwierdzenie w Wallet.",
      ]),
      ["doładowanie", "saldo"],
    ),
    "9.1-2": item(
      "Kiedy do zakupu potrzebuję Wallet?",
      j([
        "Wallet jest potrzebny wtedy, gdy zakup wymaga zewnętrznej",
        "płatności i potwierdzenia. Przy zakupach wewnętrznych w",
        "bocie nie zawsze jest obowiązkowy.",
      ]),
      ["wallet potrzebny", "zakup"],
    ),
    "9.2-1": item(
      "Jak działa zakup przez Wallet?",
      j([
        "Wybierasz zakup w bocie, potwierdzasz go w Wallet i wracasz",
        "do aplikacji. Po potwierdzeniu wynik pojawia się w bocie.",
      ]),
      ["zakup wallet", "płatność wallet"],
    ),
    "9.2-2": item(
      "Czym różni się zakup wewnętrzny od zakupu przez Wallet?",
      j([
        "Zakup wewnętrzny wykorzystuje twoje EFHC w bocie. Zakup",
        "przez Wallet wymaga zewnętrznego potwierdzenia w Wallet.",
      ]),
      ["zakup wewnętrzny", "wallet"],
    ),
    "9.2-3": item(
      "Co dzieje się po płatności?",
      j([
        "Po udanej płatności bot aktualizuje wynik operacji. Czasem",
        "dzieje się to od razu, a czasem po krótkim przetwarzaniu.",
      ]),
      ["po płatności", "wynik"],
    ),
    "9.2-4": item(
      "Dlaczego nie widzę wyniku od razu po płatności?",
      j([
        "Niektóre operacje potrzebują chwili, zanim interfejs się",
        "zaktualizuje. Odśwież ekran i sprawdź historię lub potrzebną",
        "sekcję.",
      ]),
      ["wynik niewidoczny", "po płatności"],
    ),
    "10.1-1": item(
      "Czym jest poziom?",
      j([
        "Poziom pokazuje twój osobisty postęp w projekcie. Może rosnąć",
        "wraz z postępem w mechanikach gry i energii EFHC Bot.",
      ]),
      ["poziom", "postęp"],
    ),
    "10.1-2": item(
      "Czym jest ranking?",
      j([
        "Ranking pokazuje twoją pozycję względem innych uczestników",
        "na stronie Ranks.",
      ]),
      ["ranking", "ranks"],
    ),
    "10.1-3": item(
      "Czym różni się poziom od rankingu?",
      j([
        "Poziom pokazuje twój osobisty postęp, a ranking twoje",
        "miejsce względem innych użytkowników.",
      ]),
      ["różnica poziom ranking"],
    ),
    "10.1-4": item(
      "Co pokazuje strona Ranks?",
      j([
        "Strona Ranks pokazuje tabelę uczestników i pomaga zrozumieć",
        "twoje obecne miejsce na tle innych.",
      ]),
      ["strona ranks", "miejsce"],
    ),
    "11.1-1": item(
      "Dlaczego nie mogę wypłacić środków?",
      j([
        "Zwykle oznacza to, że do wypłaty potrzebne jest saldo main,",
        "Wallet albo warunki projektu dla tej operacji nie są jeszcze",
        "spełnione.",
      ]),
      ["nie mogę wypłacić", "wypłata"],
    ),
    "11.1-2": item(
      "Dlaczego Wallet się nie łączy?",
      j([
        "Sprawdź, czy otworzyłeś właściwy Wallet, czy połączenie Mini",
        "App nie zostało przerwane i czy potwierdzenie wykonano w",
        "samym Wallet.",
      ]),
      ["wallet nie łączy", "problem wallet"],
    ),
    "11.1-3": item(
      "Dlaczego moja panel nie generuje energii?",
      j([
        "Sprawdź ekran Panels i stan panel. Zwykle powodem jest etap",
        "cyklu albo to, że patrzysz na nieaktywną część listy.",
      ]),
      ["panel nie generuje", "problem panel"],
    ),
    "11.1-4": item(
      "Dlaczego status VIP się nie wyświetla?",
      j([
        "Sprawdź, czy właściwy NFT znajduje się w podłączonym Wallet",
        "i czy bot widzi ten Wallet jako aktualny.",
      ]),
      ["vip niewidoczny", "status"],
    ),
    "11.1-5": item(
      "Dlaczego nie dostałem bonusu?",
      j([
        "Najpierw sprawdź historię salda i sekcję powiązaną z tym",
        "bonusem. Jeśli bonus nie pojawił się od razu, odśwież ekran.",
      ]),
      ["brak bonusu", "bonus"],
    ),
    "11.1-6": item(
      "Dlaczego mój referral jest nieaktywny?",
      j([
        "To oznacza, że użytkownik z twojego linku nie spełnił jeszcze",
        "warunku potrzebnego do aktywnego statusu w systemie",
        "referral.",
      ]),
      ["nieaktywny referral", "nieaktywny"],
    ),
    "11.1-7": item(
      "Dlaczego Shop jest pusty?",
      j([
        "Jeśli Shop jest pusty, oznacza to, że obecnie nie ma",
        "dostępnych pozycji dla twojego ekranu albo potrzebne pozycje",
        "nie są jeszcze pokazane w sklepie.",
      ]),
      ["shop pusty", "brak pozycji"],
    ),
    "12.1-1": item(
      "Jak szukać słów w FAQ?",
      j([
        "Otwórz FAQ i wpisz w polu wyszukiwania jasne słowo z",
        "interfejsu, na przykład balance, Wallet, panel, Exchange lub",
        "Withdraw.",
      ]),
      ["szukanie", "faq", "znajdź"],
    ),
    "12.1-2": item(
      "Gdzie szukać pytania o saldo?",
      j([
        "Szukaj go w sekcjach Balances i History del balance. Te",
        "sekcje wyjaśniają, co widzisz w interfejsie i dlaczego twoje",
        "środki się zmieniają.",
      ]),
      ["gdzie saldo", "history"],
    ),
    "12.1-3": item(
      "Gdzie szukać pytania o Wallet?",
      j([
        "Otwórz sekcję Wallet. Zebrano tam pytania o połączenie,",
        "główny Wallet i problemy z podłączaniem.",
      ]),
      ["gdzie wallet", "wallet"],
    ),
    "12.1-4": item(
      "Co zrobić, jeśli nie znalazłem odpowiedzi?",
      j([
        "Spróbuj innego jasnego słowa z interfejsu bota albo otwórz",
        "sekcję bliską znaczeniem. Jeśli pytanie dotyczy Wallet,",
        "History, Panels lub Exchange, użyj właśnie tych słów.",
      ]),
      ["brak odpowiedzi", "inne wyszukiwanie"],
    ),
  },
  da: {
    "1.1-1": item(
      "Hvad er den samlede saldo?",
      j([
        "Den samlede saldo viser alle EFHC, du lige nu har inde i",
        "botten. Den er praktisk til overblik, men er ikke det samme",
        "som beløbet, der kan hæves.",
      ]),
      ["samlet saldo", "total balance"],
    ),
    "1.1-2": item(
      "Hvad er hovedsaldoen?",
      j([
        "Hovedsaldoen er den del af dine midler, som bruges til",
        "projektets vigtigste handlinger. Det er netop denne saldo,",
        "der bruges ved udbetaling.",
      ]),
      ["hovedsaldo", "main balance"],
    ),
    "1.1-3": item(
      "Hvad er bonussaldoen?",
      j([
        "Bonussaldoen er en intern del af dine midler i botten. Den",
        "bruges til spilhandlinger og køb i projektet, men ikke til",
        "udbetaling.",
      ]),
      ["bonussaldo", "bonus balance"],
    ),
    "1.1-4": item(
      "Hvad er forskellen på samlet, hoved- og bonussaldo?",
      j([
        "Samlet saldo er alle dine midler i botten. Hovedsaldoen",
        "bruges til veksling og udbetaling. Bonussaldoen bruges til",
        "interne handlinger og køb.",
      ]),
      ["saldo forskel", "main", "bonus"],
    ),
    "1.2-1": item(
      "Hvorfor kan jeg ikke hæve hele den samlede saldo?",
      j([
        "Fordi den samlede saldo indeholder både hoved-EFHC og",
        "bonus-EFHC. Kun hovedsaldoen bruges til udbetaling.",
      ]),
      ["udbetaling", "samlet saldo"],
    ),
    "1.2-2": item(
      "Hvorfor kan ét køb påvirke både bonus- og hovedsaldo?",
      j([
        "Botten kan bruge dine interne midler i rækkefølge til én",
        "handling. Derfor kan ét køb reducere to saldi samtidig.",
      ]),
      ["køb", "to saldi"],
    ),
    "2.1-1": item(
      "Hvad viser historikken over saldo?",
      j([
        "Historikken over saldo viser ændringer i dine midler:",
        "indbetalinger, debiteringer og andre bevægelser inde i",
        "botten.",
      ]),
      ["historik", "saldohistorik"],
    ),
    "2.1-2": item(
      "Hvilke handlinger vises i saldohistorikken?",
      j([
        "Historikken viser de vigtigste handlinger, som ændrer dine",
        "saldi: køb, bonusser, veksling, udbetalinger og andre",
        "operationer i projektet.",
      ]),
      ["handlinger", "historik"],
    ),
    "2.1-3": item(
      "Hvorfor har min saldo ændret sig?",
      j([
        "Saldoen ændrer sig, når du udfører en handling i botten,",
        "modtager en bonus eller bruger en del af dine midler i",
        "projektet.",
      ]),
      ["saldo ændret", "hvorfor"],
    ),
    "2.1-4": item(
      "Hvordan ser jeg, hvorfor midler kom ind eller gik ud?",
      j([
        "Åbn historikken over saldo og se på typen af handling,",
        "beløbet og datoen. Det hjælper dig med at forstå, hvorfor",
        "saldoen blev ændret.",
      ]),
      ["hvorfor midler", "historik"],
    ),
    "3.1-1": item(
      "Hvad er et panel?",
      j([
        "Et panel er et element i projektet, som hjælper dig med at",
        "opbygge energidelen af din fremgang i botten.",
      ]),
      ["panel", "hvad er et panel"],
    ),
    "3.1-2": item(
      "Hvad giver et panel?",
      j([
        "Et panel åbner mulighed for at generere energi og deltage",
        "i projektets fremdrift. Det påvirker dine muligheder og din",
        "udvikling i botten.",
      ]),
      ["panel fordel", "energi"],
    ),
    "3.1-3": item(
      "Hvordan køber jeg et panel?",
      j([
        "Åbn sektionen Panels, vælg købet og følg trinnene på",
        "skærmen. Botten viser dig, hvad der skal til for at fuldføre",
        "handlingen.",
      ]),
      ["køb panel", "panels"],
    ),
    "3.1-4": item(
      "Hvad sker der, hvis jeg har flere paneler?",
      j([
        "Flere paneler udvider dine muligheder i energidelen af",
        "projektet. Resultatet ses i din fremdrift og i de værdier,",
        "som botten viser.",
      ]),
      ["flere paneler", "paneler"],
    ),
    "3.1-5": item(
      "Hvad betyder panelarkiv?",
      j([
        "Arkivet viser paneler, som ikke længere er i den aktive del",
        "af skærmen. Det hjælper dig med at skelne mellem aktive og",
        "tidligere paneler.",
      ]),
      ["panel arkiv", "arkiv"],
    ),
    "3.2-1": item(
      "Hvordan opstår energi?",
      j([
        "Energi opstår i projektets paneldel. Når dine paneler",
        "arbejder, viser botten resultatet som den energi, du har",
        "til rådighed.",
      ]),
      ["energi", "hvordan opstår"],
    ),
    "3.2-2": item(
      "Hvad er tilgængelig energi?",
      j([
        "Tilgængelig energi er den del af energien, som du på dette",
        "tidspunkt kan bruge til næste handlinger i botten.",
      ]),
      ["tilgængelig energi", "energi"],
    ),
    "3.2-3": item(
      "Hvorfor kan et panel holde op med at generere?",
      j([
        "Det kan ske, hvis panelet ikke er i aktiv tilstand, eller",
        "hvis den aktuelle fase af dets arbejde er afsluttet. Se",
        "panelets status på skærmen.",
      ]),
      ["panel genererer ikke", "panel status"],
    ),
    "4.1-1": item(
      "Hvad er veksling?",
      j([
        "Veksling er handlingen, hvor din energi omdannes til EFHC",
        "inde i projektet.",
      ]),
      ["veksling", "exchange"],
    ),
    "4.1-2": item(
      "Hvad sker der efter veksling?",
      j([
        "Efter veksling opdaterer botten dine værdier og viser",
        "resultatet i balancerne og de relevante sektioner.",
      ]),
      ["efter veksling", "exchange"],
    ),
    "4.1-3": item(
      "Hvornår skal jeg først veksle, og hvornår kan jeg hæve?",
      j([
        "Hvis du endnu kun har energi, skal du først veksle den til",
        "EFHC. Udbetaling er tilgængelig, når du allerede har det",
        "nødvendige beløb på hovedsaldoen.",
      ]),
      ["veksling før udbetaling", "udbetaling"],
    ),
    "4.2-1": item(
      "Hvad er udbetaling?",
      j([
        "Udbetaling er handlingen, hvor du sender den tilgængelige",
        "del af din hovedsaldo videre via den tilsvarende funktion i",
        "projektet.",
      ]),
      ["udbetaling", "withdraw"],
    ),
    "4.2-2": item(
      "Hvorfor kan jeg ikke hæve bonussaldoen?",
      j([
        "Bonussaldoen er beregnet til interne handlinger i botten og",
        "bruges ikke til udbetaling. Til udbetaling bruges kun",
        "hovedsaldoen.",
      ]),
      ["bonussaldo", "hvorfor ikke"],
    ),
    "4.2-3": item(
      "Hvorfor ændrede min hovedsaldo sig efter en hæveanmodning?",
      j([
        "Efter at du har oprettet en hæveanmodning, tager botten",
        "beløbet i betragtning til denne handling. Derfor ser",
        "hovedsaldoen anderledes ud med det samme.",
      ]),
      ["hæveanmodning", "hovedsaldo"],
    ),
    "4.2-4": item(
      "Hvorfor kan udbetaling være utilgængelig?",
      j([
        "Udbetaling kan være utilgængelig, hvis de nødvendige",
        "betingelser endnu ikke er opfyldt. Se din hovedsaldo og",
        "status for den aktuelle handling.",
      ]),
      ["udbetaling utilgængelig", "withdraw"],
    ),
    "5.1-1": item(
      "Hvorfor har jeg brug for en wallet?",
      j([
        "En wallet er nødvendig til handlinger, hvor projektet kræver",
        "ekstern bekræftelse og en forbindelse til din adresse. Den",
        "er også vigtig for VIP NFT og beslægtede handlinger.",
      ]),
      ["wallet", "hvorfor wallet"],
    ),
    "5.1-2": item(
      "Hvordan forbinder jeg en wallet?",
      j([
        "Åbn sektionen Wallet, vælg forbind og bekræft handlingen i",
        "en understøttet wallet-app.",
      ]),
      ["forbind wallet", "wallet"],
    ),
    "5.1-3": item(
      "Hvad er den primære wallet?",
      j([
        "Den primære wallet er den wallet, som botten bruger som den",
        "vigtigste til handlinger, hvor din valgte adresse er",
        "nødvendig.",
      ]),
      ["primær wallet", "main wallet"],
    ),
    "5.1-4": item(
      "Kan jeg tilknytte flere wallets?",
      j([
        "Ja. Botten kan gemme flere tilknyttede wallets og lade dig",
        "vælge den primære fra listen over forbundne wallets.",
      ]),
      ["flere wallets", "primær wallet"],
    ),
    "5.1-5": item(
      "Hvad gør jeg, hvis wallet ikke forbinder?",
      j([
        "Kontrollér, at den rigtige wallet-app er åben, at Telegram",
        "Mini App-forbindelsen ikke er afbrudt, og at du bekræfter",
        "forbindelsen inde i selve wallet.",
      ]),
      ["forbinder ikke", "wallet problem"],
    ),
    "6.1-1": item(
      "Hvad er referals?",
      j([
        "Referals er brugere, som kom til projektet via dit link og",
        "derefter påvirker din fremdrift efter reglerne i",
        "referralsystemet.",
      ]),
      ["referrals", "inviterede brugere"],
    ),
    "6.1-2": item(
      "Hvordan virker mit referralslink?",
      j([
        "Du deler dit link med en ny bruger. Hvis brugeren går ind i",
        "projektet via det, tælles vedkommende med i dit",
        "referralsystem.",
      ]),
      ["referralslink", "invitelink"],
    ),
    "6.1-3": item(
      "Hvem regnes som en aktiv referral?",
      j([
        "En aktiv referral er en bruger, som allerede har opfyldt",
        "projektets nødvendige betingelse og indgår i din aktive",
        "referralstatistik.",
      ]),
      ["aktiv referral", "referral aktiv"],
    ),
    "6.1-4": item(
      "Hvem regnes som en inaktiv referral?",
      j([
        "En inaktiv referral er en bruger, som kom via dit link, men",
        "endnu ikke har opfyldt betingelsen for aktiv status.",
      ]),
      ["inaktiv referral", "referral inaktiv"],
    ),
    "6.1-5": item(
      "Hvad viser tællerne på referralsiden?",
      j([
        "Tællerne viser, hvor mange referrals du har i alt, hvor",
        "mange af dem der er aktive, og hvordan det påvirker din",
        "fremdrift i referralsystemet.",
      ]),
      ["tællere", "referralside"],
    ),
    "6.1-6": item(
      "Hvordan virker fremdriften til næste niveau?",
      j([
        "Fremdriften viser, hvor meget der stadig mangler til næste",
        "trin i din referral-linje. Det hjælper dig hurtigt med at",
        "se, hvor meget der er tilbage til næste niveau eller bonus.",
      ]),
      ["fremdrift", "næste niveau"],
    ),
    "7.1-1": item(
      "Hvad er VIP NFT?",
      j([
        "VIP NFT er et særligt projekt-NFT, som giver brugeren en",
        "VIP-effekt efter reglerne i EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "Hvad giver VIP NFT mig?",
      j([
        "VIP NFT giver særlige fordele inde i projektet. I",
        "interfacet hænger det sammen med VIP-status og de tilhørende",
        "effekter i projektet.",
      ]),
      ["hvad giver vip nft", "vip status"],
    ),
    "7.1-3": item(
      "Har jeg brug for en tilknyttet wallet til VIP NFT?",
      j([
        "Ja. Botten har brug for en tilknyttet wallet for at kunne se",
        "dit VIP NFT og knytte det korrekt til din status.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "Hvornår bliver VIP-status aktiv?",
      j([
        "Når botten ser det rigtige NFT i din tilknyttede wallet,",
        "opdateres VIP-status automatisk efter projektets regler.",
      ]),
      ["vip status", "bliver aktiv"],
    ),
    "7.1-5": item(
      "Hvad gør jeg, hvis jeg har NFT'et, men status mangler?",
      j([
        "Kontrollér, at NFT'et er i den rigtige tilknyttede wallet,",
        "og at denne wallet stadig er aktuel i botten. Opdater så",
        "skærmen og kontrollér igen.",
      ]),
      ["nft findes", "status mangler"],
    ),
    "8.1-1": item(
      "Hvad er Shop?",
      j([
        "Shop er sektionen, hvor en bruger kan købe genstande i",
        "botten og andre projektdele, der er knyttet til",
        "interfacestilen.",
      ]),
      ["shop", "butik"],
    ),
    "8.1-2": item(
      "Hvad kan jeg købe i Shop?",
      j([
        "I Shop kan du købe de projektgenstande, som vises for dig nu,",
        "for eksempel skins og andre egnede elementer.",
      ]),
      ["hvad købe", "genstande"],
    ),
    "8.1-3": item(
      "Hvordan adskiller køb med EFHC sig fra køb via Wallet?",
      j([
        "Køb med EFHC bruger dine midler inde i botten. Køb via",
        "Wallet kræver ekstern bekræftelse gennem din wallet.",
      ]),
      ["køb med efhc", "via wallet"],
    ),
    "8.1-4": item(
      "Hvorfor viser Shop måske ingenting?",
      j([
        "Det kan ske, hvis der ikke findes tilgængelige genstande til",
        "din skærm lige nu, eller hvis sektionen endnu ikke er fyldt",
        "med passende positioner.",
      ]),
      ["shop tom", "intet vist"],
    ),
    "8.2-1": item(
      "Hvad er skins?",
      j([
        "Skins er visuelle designelementer, som ændrer, hvordan dele",
        "af interfacet ser ud inde i projektet.",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "Hvordan adskiller almindelige skins sig fra niveaudesigns?",
      j([
        "Almindelige skins er tilgængelige køb eller designelementer.",
        "Niveaudesigns er knyttet til din fremdrift og åbnes efter",
        "projektets regler.",
      ]),
      ["niveaudesign", "skins forskel"],
    ),
    "8.2-3": item(
      "Hvordan køber og aktiverer jeg et skin?",
      j([
        "Køb først et tilgængeligt skin i Shop, vælg det derefter",
        "blandt dine tilgængelige design og aktiver det i",
        "interfacet.",
      ]),
      ["køb skin", "aktiver skin"],
    ),
    "9.1-1": item(
      "Hvordan fylder jeg min saldo op?",
      j([
        "Åbn den relevante handling i botten og følg trinnene på",
        "skærmen. Hvis Wallet er nødvendig, viser botten dig næste",
        "skridt.",
      ]),
      ["påfyldning", "fyld saldo op"],
    ),
    "9.1-2": item(
      "Hvornår skal jeg bruge Wallet til et køb?",
      j([
        "Wallet er nødvendig, når købet ikke kun sker inde i",
        "botten, men kræver ekstern bekræftelse via din adresse.",
      ]),
      ["wallet nødvendig", "køb"],
    ),
    "9.2-1": item(
      "Hvordan foregår et køb gennem Wallet?",
      j([
        "Botten sender dig til bekræftelse i Wallet. Efter",
        "bekræftelsen opdateres resultatet af købet i projektet.",
      ]),
      ["køb gennem wallet", "wallet køb"],
    ),
    "9.2-2": item(
      "Hvordan adskiller et internt køb sig fra et køb via Wallet?",
      j([
        "Et internt køb bruger dine EFHC i botten. Et køb via",
        "Wallet kræver ekstern bekræftelse i Wallet.",
      ]),
      ["internt køb", "via wallet"],
    ),
    "9.2-3": item(
      "Hvad sker der efter betaling?",
      j([
        "Efter betaling skal resultatet vises i bottens interface:",
        "saldo, køb eller et nyt element opdateres efter",
        "projektets regler.",
      ]),
      ["efter betaling", "betalingsresultat"],
    ),
    "9.2-4": item(
      "Hvorfor kan jeg ikke se resultatet straks efter betaling?",
      j([
        "Nogle handlinger skal bruge lidt tid på at opdatere i",
        "interfacet. Hvis resultatet ikke vises med det samme,",
        "opdater skærmen og tjek historikken eller den relevante",
        "sektion.",
      ]),
      ["ser ikke resultat", "efter betaling"],
    ),
    "10.1-1": item(
      "Hvad er et niveau?",
      j([
        "Et niveau viser din personlige fremgang i projektet. Det",
        "stiger, når du bevæger dig frem i EFHC Bots spil- og",
        "energimekanikker.",
      ]),
      ["niveau", "level"],
    ),
    "10.1-2": item(
      "Hvad er en rang?",
      j([
        "Rang viser din placering blandt andre deltagere på siden",
        "Ranks.",
      ]),
      ["rang", "ranks"],
    ),
    "10.1-3": item(
      "Hvordan adskiller niveau sig fra rang?",
      j([
        "Niveau viser din personlige fremgang, mens rang viser din",
        "placering blandt andre deltagere i projektet.",
      ]),
      ["forskel på rang og niveau"],
    ),
    "10.1-4": item(
      "Hvad viser siden Ranks?",
      j([
        "Siden Ranks viser deltagernes rangliste og hjælper dig med",
        "at forstå din aktuelle placering i forhold til andre.",
      ]),
      ["ranks side", "placering"],
    ),
    "11.1-1": item(
      "Hvorfor kan jeg ikke hæve midler?",
      j([
        "Det hænger normalt sammen med, at hævning kræver main",
        "balance, Wallet eller at projektets betingelser for denne",
        "handling endnu ikke er opfyldt.",
      ]),
      ["kan ikke hæve", "hævning"],
    ),
    "11.1-2": item(
      "Hvorfor forbinder Wallet ikke?",
      j([
        "Tjek, at du har åbnet den rigtige Wallet, at forbindelsen",
        "til Mini App ikke er afbrudt, og at bekræftelsen er udført",
        "i selve walleten.",
      ]),
      ["wallet forbinder ikke", "wallet problem"],
    ),
    "11.1-3": item(
      "Hvorfor genererer mit panel ikke?",
      j([
        "Tjek den aktuelle Panels-skærm og panelets tilstand.",
        "Årsagen hænger normalt sammen med dets cyklus eller med,",
        "at du ser en ikke-aktiv del af listen.",
      ]),
      ["panel genererer ikke", "panel problem"],
    ),
    "11.1-4": item(
      "Hvorfor vises VIP-status ikke?",
      j([
        "Tjek, at den nødvendige NFT er i den tilknyttede Wallet,",
        "og at botten allerede ser denne wallet som den aktuelle.",
      ]),
      ["vip vises ikke", "status"],
    ),
    "11.1-5": item(
      "Hvorfor kom bonus ikke?",
      j([
        "Tjek først balancehistorikken og den sektion, som bonusen",
        "er knyttet til. Hvis bonusen ikke kom med det samme, så",
        "opdater skærmen og tjek det relaterede spørgsmål i FAQ.",
      ]),
      ["bonus kom ikke", "bonus"],
    ),
    "11.1-6": item(
      "Hvorfor er referral inaktiv?",
      j([
        "Det betyder, at brugeren fra dit link endnu ikke har",
        "opfyldt betingelsen for aktiv status i referralsystemet.",
      ]),
      ["inaktiv referral", "inaktiv"],
    ),
    "11.1-7": item(
      "Hvorfor er Shop tom?",
      j([
        "Hvis Shop er tom, betyder det, at der lige nu ikke er",
        "tilgængelige varer til din skærm, eller at de nødvendige",
        "positioner endnu ikke vises i butikken.",
      ]),
      ["shop tom", "ingen varer"],
    ),
    "12.1-1": item(
      "Hvordan søger jeg efter ord i FAQ?",
      j([
        "Åbn FAQ og skriv et klart ord fra interfacet i søgefeltet,",
        "for eksempel balance, Wallet, panel, Exchange eller",
        "Withdraw.",
      ]),
      ["søgning", "faq", "find"],
    ),
    "12.1-2": item(
      "Hvor finder jeg et spørgsmål om balance?",
      j([
        "Se i sektionerne Balances og Balance History. De forklarer,",
        "hvad du ser i interfacet, og hvorfor dine midler ændrer",
        "sig.",
      ]),
      ["hvor balance", "historik"],
    ),
    "12.1-3": item(
      "Hvor finder jeg et spørgsmål om Wallet?",
      j([
        "Åbn sektionen Wallet. Her finder du spørgsmål om",
        "forbindelse, primær Wallet og problemer med tilslutning.",
      ]),
      ["hvor wallet", "wallet"],
    ),
    "12.1-4": item(
      "Hvad gør jeg, hvis jeg ikke fandt et svar?",
      j([
        "Prøv en anden tydelig forespørgsel fra bottens interface",
        "eller åbn en nærliggende sektion. Hvis spørgsmålet gælder",
        "Wallet, History, Panels eller Exchange, så søg med netop",
        "de ord.",
      ]),
      ["fandt ikke svar", "anden søgning"],
    ),
  },
  hi: {
    "1.1-1": item(
      "कुल बैलेंस क्या होता है?",
      j([
        "कुल बैलेंस आपके सभी EFHC दिखाता है, जो अभी बॉट के अंदर",
        "आपके पास हैं। यह कुल तस्वीर समझने में मदद करता है, लेकिन",
        "निकासी की रकम के बराबर नहीं होता।",
      ]),
      ["कुल बैलेंस", "total balance"],
    ),
    "1.1-2": item(
      "मुख्य बैलेंस क्या होता है?",
      j([
        "मुख्य बैलेंस आपके फंड का वह हिस्सा है, जो प्रोजेक्ट की",
        "मुख्य कार्रवाइयों में उपयोग होता है। निकासी में यही बैलेंस",
        "काम आता है।",
      ]),
      ["मुख्य बैलेंस", "main balance"],
    ),
    "1.1-3": item(
      "बोनस बैलेंस क्या होता है?",
      j([
        "बोनस बैलेंस आपके फंड का अंदरूनी हिस्सा है। यह गेम जैसी",
        "कार्रवाइयों और प्रोजेक्ट के भीतर खरीद के लिए होता है,",
        "लेकिन निकासी में उपयोग नहीं होता।",
      ]),
      ["बोनस बैलेंस", "bonus balance"],
    ),
    "1.1-4": item(
      "कुल, मुख्य और बोनस बैलेंस में क्या फर्क है?",
      j([
        "कुल बैलेंस आपके सभी फंड दिखाता है। मुख्य बैलेंस एक्सचेंज",
        "और निकासी के लिए होता है। बोनस बैलेंस अंदरूनी कार्रवाइयों",
        "और खरीद के लिए होता है।",
      ]),
      ["बैलेंस अंतर", "main", "bonus"],
    ),
    "1.2-1": item(
      "मैं पूरा कुल बैलेंस क्यों नहीं निकाल सकता?",
      j([
        "क्योंकि कुल बैलेंस में मुख्य EFHC और बोनस EFHC दोनों",
        "शामिल होते हैं। निकासी के लिए सिर्फ मुख्य बैलेंस उपयोग",
        "होता है।",
      ]),
      ["निकासी", "कुल बैलेंस"],
    ),
    "1.2-2": item(
      "एक खरीद बोनस और मुख्य दोनों बैलेंस को क्यों छू सकती है?",
      j([
        "बॉट एक ही कार्रवाई के लिए आपके अंदरूनी फंड क्रम से उपयोग",
        "कर सकता है। इसलिए एक खरीद दो बैलेंस को एक साथ घटा सकती",
        "है।",
      ]),
      ["खरीद", "दो बैलेंस"],
    ),
    "2.1-1": item(
      "बैलेंस हिस्ट्री क्या दिखाती है?",
      j([
        "बैलेंस हिस्ट्री आपके फंड में हुए बदलाव दिखाती है: जमा,",
        "कटौती और बॉट के अंदर हुई दूसरी हलचलें।",
      ]),
      ["हिस्ट्री", "बैलेंस हिस्ट्री"],
    ),
    "2.1-2": item(
      "बैलेंस हिस्ट्री में कौन-सी कार्रवाइयाँ दिखती हैं?",
      j([
        "हिस्ट्री मुख्य कार्रवाइयाँ दिखाती है जो आपके बैलेंस बदलती",
        "हैं: खरीद, बोनस, एक्सचेंज, निकासी और प्रोजेक्ट की दूसरी",
        "ऑपरेशन।",
      ]),
      ["कार्रवाइयाँ", "हिस्ट्री"],
    ),
    "2.1-3": item(
      "मेरा बैलेंस क्यों बदला?",
      j([
        "जब आप बॉट में कोई कार्रवाई करते हैं, बोनस पाते हैं या",
        "प्रोजेक्ट के भीतर अपने फंड का उपयोग करते हैं, तब बैलेंस",
        "बदल सकता है।",
      ]),
      ["बैलेंस बदला", "क्यों"],
    ),
    "2.1-4": item(
      "मुझे कैसे पता चले कि पैसे क्यों आए या क्यों गए?",
      j([
        "बैलेंस हिस्ट्री खोलें और कार्रवाई का प्रकार, रकम और तारीख",
        "देखें। इससे समझने में मदद मिलेगी कि बैलेंस क्यों बदला।",
      ]),
      ["पैसे क्यों आए", "हिस्ट्री"],
    ),
    "3.1-1": item(
      "पैनल क्या होता है?",
      j([
        "पैनल प्रोजेक्ट का वह हिस्सा है जो बॉट में आपकी ऊर्जा से",
        "जुड़ी प्रगति बनाने में मदद करता है।",
      ]),
      ["पैनल", "पैनल क्या है"],
    ),
    "3.1-2": item(
      "पैनल क्या देता है?",
      j([
        "पैनल आपको ऊर्जा पैदा करने और प्रोजेक्ट की प्रगति में भाग",
        "लेने का अवसर देता है। यह बॉट में आपकी क्षमताओं और विकास",
        "को प्रभावित करता है।",
      ]),
      ["पैनल फायदा", "ऊर्जा"],
    ),
    "3.1-3": item(
      "मैं पैनल कैसे खरीदूँ?",
      j([
        "Panels सेक्शन खोलें, खरीद चुनें और स्क्रीन पर दिए गए चरणों",
        "का पालन करें। बॉट बताएगा कि कार्रवाई पूरी करने के लिए",
        "क्या चाहिए।",
      ]),
      ["पैनल खरीदें", "panels"],
    ),
    "3.1-4": item(
      "अगर मेरे पास कई पैनल हों तो क्या होता है?",
      j([
        "कई पैनल होने पर प्रोजेक्ट के ऊर्जा हिस्से में आपकी",
        "संभावनाएँ बढ़ती हैं। इसका असर आपकी प्रगति और बॉट द्वारा",
        "दिखाए गए मानों में दिखता है।",
      ]),
      ["कई पैनल", "पैनल"],
    ),
    "3.1-5": item(
      "पैनल आर्काइव का क्या मतलब है?",
      j([
        "आर्काइव उन पैनलों को दिखाता है जो अब सक्रिय हिस्से में",
        "नहीं हैं। इससे आप सक्रिय और पुराने पैनलों में फर्क समझ",
        "सकते हैं।",
      ]),
      ["पैनल आर्काइव", "आर्काइव"],
    ),
    "3.2-1": item(
      "ऊर्जा कैसे बनती है?",
      j([
        "ऊर्जा प्रोजेक्ट के पैनल हिस्से में बनती है। जब आपके",
        "पैनल काम करते हैं, तो बॉट उसका परिणाम उपलब्ध ऊर्जा के",
        "रूप में दिखाता है।",
      ]),
      ["ऊर्जा", "कैसे बनती है"],
    ),
    "3.2-2": item(
      "उपलब्ध ऊर्जा क्या होती है?",
      j([
        "उपलब्ध ऊर्जा वह हिस्सा है जिसे आप इस समय बॉट में अगली",
        "कार्रवाइयों के लिए उपयोग कर सकते हैं।",
      ]),
      ["उपलब्ध ऊर्जा", "ऊर्जा"],
    ),
    "3.2-3": item(
      "पैनल ऊर्जा बनाना क्यों बंद कर सकता है?",
      j([
        "ऐसा तब हो सकता है जब पैनल सक्रिय स्थिति में न हो या उसके",
        "काम का वर्तमान चरण पूरा हो गया हो। स्क्रीन पर उसका स्टेटस",
        "देखें।",
      ]),
      ["पैनल नहीं बना रहा", "पैनल स्टेटस"],
    ),
    "4.1-1": item(
      "एक्सचेंज क्या है?",
      j([
        "एक्सचेंज वह कार्रवाई है जिसमें आपकी ऊर्जा प्रोजेक्ट के",
        "अंदर EFHC में बदली जाती है।",
      ]),
      ["एक्सचेंज", "exchange"],
    ),
    "4.1-2": item(
      "एक्सचेंज के बाद क्या होता है?",
      j([
        "एक्सचेंज के बाद बॉट आपके मान अपडेट करता है और बैलेंस व",
        "संबंधित सेक्शनों में परिणाम दिखाता है।",
      ]),
      ["एक्सचेंज के बाद", "exchange"],
    ),
    "4.1-3": item(
      "पहले एक्सचेंज कब चाहिए और निकासी कब उपलब्ध होती है?",
      j([
        "अगर आपके पास अभी केवल ऊर्जा है, तो पहले उसे EFHC में",
        "बदलना होगा। निकासी तब उपलब्ध होती है जब मुख्य बैलेंस में",
        "ज़रूरी रकम मौजूद हो।",
      ]),
      ["निकासी से पहले एक्सचेंज", "निकासी"],
    ),
    "4.2-1": item(
      "निकासी क्या होती है?",
      j([
        "निकासी वह कार्रवाई है जिसमें आप अपने मुख्य बैलेंस के",
        "उपलब्ध हिस्से को प्रोजेक्ट की संबंधित फ़ंक्शन के जरिए आगे",
        "भेजते हैं।",
      ]),
      ["निकासी", "withdraw"],
    ),
    "4.2-2": item(
      "मैं बोनस बैलेंस क्यों नहीं निकाल सकता?",
      j([
        "बोनस बैलेंस बॉट की अंदरूनी कार्रवाइयों के लिए होता है और",
        "निकासी में उपयोग नहीं होता। निकासी के लिए सिर्फ मुख्य",
        "बैलेंस इस्तेमाल होता है।",
      ]),
      ["बोनस बैलेंस", "क्यों नहीं"],
    ),
    "4.2-3": item(
      "निकासी अनुरोध के बाद मेरा मुख्य बैलेंस क्यों बदला?",
      j([
        "जब आप निकासी अनुरोध बनाते हैं, तो बॉट उस रकम को इस",
        "कार्रवाई के लिए गिनता है। इसलिए मुख्य बैलेंस तुरंत अलग",
        "दिखने लगता है।",
      ]),
      ["निकासी अनुरोध", "मुख्य बैलेंस"],
    ),
    "4.2-4": item(
      "निकासी उपलब्ध क्यों नहीं हो सकती?",
      j([
        "निकासी तब उपलब्ध नहीं होती जब ज़रूरी शर्तें अभी पूरी न",
        "हुई हों। अपना मुख्य बैलेंस और मौजूदा कार्रवाई की स्थिति",
        "देखें।",
      ]),
      ["निकासी उपलब्ध नहीं", "withdraw"],
    ),
    "5.1-1": item(
      "मुझे वॉलेट की ज़रूरत क्यों है?",
      j([
        "वॉलेट उन कामों के लिए चाहिए, जहाँ प्रोजेक्ट को बाहरी",
        "पुष्टि और आपके पते से लिंक चाहिए। यह VIP NFT और उससे",
        "जुड़ी कार्रवाइयों के लिए भी महत्वपूर्ण है।",
      ]),
      ["wallet", "wallet why"],
    ),
    "5.1-2": item(
      "मैं वॉलेट कैसे कनेक्ट करूँ?",
      j([
        "Wallet सेक्शन खोलें, connect चुनें और समर्थित wallet app",
        "में कार्रवाई की पुष्टि करें।",
      ]),
      ["connect wallet", "wallet"],
    ),
    "5.1-3": item(
      "मुख्य वॉलेट क्या है?",
      j([
        "मुख्य वॉलेट वह वॉलेट है, जिसे बॉट उन कार्रवाइयों के लिए",
        "मुख्य मानता है, जहाँ आपके चुने हुए पते की ज़रूरत होती है।",
      ]),
      ["primary wallet", "main wallet"],
    ),
    "5.1-4": item(
      "क्या मैं कई वॉलेट जोड़ सकता हूँ?",
      j([
        "हाँ। बॉट कई जुड़े हुए वॉलेट सहेज सकता है और आपको उनमें से",
        "एक को मुख्य वॉलेट चुनने देता है।",
      ]),
      ["several wallets", "primary wallet"],
    ),
    "5.1-5": item(
      "अगर वॉलेट कनेक्ट नहीं हो रहा तो क्या करूँ?",
      j([
        "जाँचें कि सही wallet app खुली है, Telegram Mini App कनेक्शन",
        "टूटा नहीं है और आपने खुद wallet के अंदर कनेक्शन की पुष्टि",
        "की है। फिर दोबारा कोशिश करें।",
      ]),
      ["not connecting", "wallet problem"],
    ),
    "6.1-1": item(
      "रेफरल क्या हैं?",
      j([
        "रेफरल वे उपयोगकर्ता हैं, जो आपके लिंक से प्रोजेक्ट में आते",
        "हैं और फिर रेफरल सिस्टम के नियमों के अनुसार आपकी प्रगति",
        "को प्रभावित करते हैं।",
      ]),
      ["referrals", "invited users"],
    ),
    "6.1-2": item(
      "मेरा रेफरल लिंक कैसे काम करता है?",
      j([
        "आप अपना लिंक नए उपयोगकर्ता को भेजते हैं। यदि वह उसी लिंक",
        "से प्रोजेक्ट में आता है, तो वह आपके रेफरल सिस्टम में जुड़",
        "जाता है।",
      ]),
      ["referral link", "invite link"],
    ),
    "6.1-3": item(
      "किसे सक्रिय रेफरल माना जाता है?",
      j([
        "सक्रिय रेफरल वह उपयोगकर्ता है, जिसने प्रोजेक्ट की जरूरी",
        "शर्त पूरी कर ली है और अब आपकी सक्रिय रेफरल सांख्यिकी में",
        "शामिल है।",
      ]),
      ["active referral", "referral active"],
    ),
    "6.1-4": item(
      "किसे निष्क्रिय रेफरल माना जाता है?",
      j([
        "निष्क्रिय रेफरल वह उपयोगकर्ता है, जो आपके लिंक से आया,",
        "लेकिन अभी सक्रिय स्थिति की शर्त पूरी नहीं कर पाया है।",
      ]),
      ["inactive referral", "referral inactive"],
    ),
    "6.1-5": item(
      "रेफरल पेज के काउंटर क्या दिखाते हैं?",
      j([
        "काउंटर दिखाते हैं कि आपके कुल कितने रेफरल हैं, उनमें से",
        "कितने सक्रिय हैं और इसका आपकी रेफरल प्रगति पर क्या असर",
        "पड़ता है।",
      ]),
      ["counters", "referrals page"],
    ),
    "6.1-6": item(
      "अगले स्तर तक प्रगति कैसे काम करती है?",
      j([
        "प्रगति दिखाती है कि आपकी रेफरल लाइन के अगले कदम तक अभी",
        "कितना बाकी है। इससे आप जल्दी समझते हैं कि अगले स्तर या",
        "बोनस तक कितनी दूरी बची है।",
      ]),
      ["progress", "next level"],
    ),
    "7.1-1": item(
      "VIP NFT क्या है?",
      j([
        "VIP NFT प्रोजेक्ट का एक विशेष NFT है, जो EFHC Bot के नियमों",
        "के अनुसार उपयोगकर्ता को VIP प्रभाव देता है।",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "VIP NFT मुझे क्या देता है?",
      j([
        "VIP NFT प्रोजेक्ट के अंदर विशेष लाभ देता है। इंटरफ़ेस में",
        "यह VIP status और उससे जुड़े प्रोजेक्ट प्रभावों से जुड़ा",
        "होता है।",
      ]),
      ["what vip nft gives", "vip status"],
    ),
    "7.1-3": item(
      "क्या VIP NFT के लिए जुड़ा हुआ वॉलेट चाहिए?",
      j([
        "हाँ। बॉट को आपका VIP NFT देखने और उसे सही status से जोड़ने",
        "के लिए linked wallet चाहिए।",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "VIP status कब सक्रिय होता है?",
      j([
        "जब बॉट आपके linked wallet में सही NFT देखता है, तब",
        "प्रोजेक्ट नियमों के अनुसार VIP status अपने आप अपडेट होता",
        "है।",
      ]),
      ["vip status", "becomes active"],
    ),
    "7.1-5": item(
      "यदि NFT है, लेकिन status नहीं दिख रहा, तो क्या करूँ?",
      j([
        "जाँचें कि NFT सही linked wallet में है और वही wallet अभी",
        "भी बॉट में current है। फिर स्क्रीन को refresh करके दोबारा",
        "देखें।",
      ]),
      ["nft exists", "status missing"],
    ),
    "8.1-1": item(
      "Shop क्या है?",
      j([
        "Shop वह सेक्शन है, जहाँ उपयोगकर्ता bot के अंदर की चीज़ें",
        "और इंटरफ़ेस स्टाइल से जुड़ी प्रोजेक्ट वस्तुएँ खरीद सकता",
        "है।",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "मैं Shop में क्या खरीद सकता हूँ?",
      j([
        "Shop में आप वे प्रोजेक्ट आइटम खरीद सकते हैं, जो इस समय",
        "आपको दिखाए जा रहे हैं, जैसे skins और अन्य उपयुक्त तत्व।",
      ]),
      ["what to buy", "items"],
    ),
    "8.1-3": item(
      "EFHC से खरीद और Wallet से खरीद में क्या अंतर है?",
      j([
        "EFHC से खरीद आपके bot के अंदर के funds का उपयोग करती है।",
        "Wallet के ज़रिए खरीद के लिए wallet में बाहरी पुष्टि चाहिए।",
      ]),
      ["buy with efhc", "through wallet"],
    ),
    "8.1-4": item(
      "Shop खाली क्यों दिख सकता है?",
      j([
        "ऐसा तब हो सकता है, जब अभी आपकी स्क्रीन के लिए उपलब्ध",
        "आइटम न हों या सेक्शन अभी उपयुक्त वस्तुओं से भरा न गया हो।",
      ]),
      ["shop empty", "nothing shown"],
    ),
    "8.2-1": item(
      "Skins क्या हैं?",
      j([
        "Skins वे visual design elements हैं, जो प्रोजेक्ट के अंदर",
        "इंटरफ़ेस के कुछ हिस्सों का रूप बदलते हैं।",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "सामान्य skins और level designs में क्या अंतर है?",
      j([
        "सामान्य skins उपलब्ध खरीद या डिजाइन तत्व हैं। Level",
        "designs आपकी progress से जुड़े होते हैं और प्रोजेक्ट नियमों",
        "के अनुसार खुलते हैं।",
      ]),
      ["level design", "skins difference"],
    ),
    "8.2-3": item(
      "मैं skin कैसे खरीदूँ और सक्रिय करूँ?",
      j([
        "पहले Shop में उपलब्ध skin खरीदें, फिर उसे अपने उपलब्ध",
        "designs में चुनें और इंटरफ़ेस में activate करें।",
      ]),
      ["buy skin", "activate skin"],
    ),
    "9.1-1": item(
      "मैं अपना बैलेंस कैसे बढ़ाऊँ?",
      j([
        "बॉट में ज़रूरी कार्रवाई खोलें और स्क्रीन पर दिए गए चरणों",
        "का पालन करें। अगर Wallet चाहिए होगा, तो बॉट अगला कदम",
        "दिखा देगा।",
      ]),
      ["बैलेंस बढ़ाना", "टॉप अप"],
    ),
    "9.1-2": item(
      "खरीद के लिए Wallet कब ज़रूरी होता है?",
      j([
        "Wallet तब चाहिए होता है, जब खरीद सिर्फ बॉट के अंदर नहीं",
        "होती, बल्कि आपके पते से बाहरी पुष्टि भी चाहिए होती है।",
      ]),
      ["wallet ज़रूरी", "खरीद"],
    ),
    "9.2-1": item(
      "Wallet के जरिए खरीद कैसे होती है?",
      j([
        "बॉट आपको Wallet में पुष्टि वाले चरण तक ले जाता है।",
        "पुष्टि के बाद खरीद का परिणाम प्रोजेक्ट में अपडेट हो जाता",
        "है।",
      ]),
      ["wallet से खरीद", "wallet buy"],
    ),
    "9.2-2": item(
      "अंदरूनी खरीद और Wallet खरीद में क्या फर्क है?",
      j([
        "अंदरूनी खरीद बॉट के भीतर आपके EFHC का उपयोग करती है।",
        "Wallet के जरिए खरीद में Wallet में बाहरी पुष्टि करनी",
        "पड़ती है।",
      ]),
      ["अंदरूनी खरीद", "wallet से"],
    ),
    "9.2-3": item(
      "भुगतान के बाद क्या होता है?",
      j([
        "भुगतान के बाद परिणाम बॉट के इंटरफ़ेस में दिखना चाहिए:",
        "बैलेंस, खरीद या नया आइटम प्रोजेक्ट के नियमों के अनुसार",
        "अपडेट होता है।",
      ]),
      ["भुगतान के बाद", "payment result"],
    ),
    "9.2-4": item(
      "भुगतान के बाद परिणाम तुरंत क्यों नहीं दिखता?",
      j([
        "कुछ कार्रवाइयों को इंटरफ़ेस में अपडेट होने में थोड़ा समय",
        "लगता है। अगर परिणाम तुरंत न दिखे, तो स्क्रीन रीफ़्रेश",
        "करें और हिस्ट्री या संबंधित सेक्शन देखें।",
      ]),
      ["परिणाम नहीं दिखता", "भुगतान के बाद"],
    ),
    "10.1-1": item(
      "लेवल क्या है?",
      j([
        "लेवल प्रोजेक्ट में आपकी व्यक्तिगत प्रगति दिखाता है। यह",
        "EFHC Bot की गेम और ऊर्जा प्रणाली में आगे बढ़ने के साथ",
        "बढ़ता है।",
      ]),
      ["लेवल", "level"],
    ),
    "10.1-2": item(
      "रैंक क्या है?",
      j([
        "रैंक पेज Ranks पर दूसरे प्रतिभागियों के बीच आपकी जगह",
        "दिखाता है।",
      ]),
      ["रैंक", "ranks"],
    ),
    "10.1-3": item(
      "लेवल और रैंक में क्या अंतर है?",
      j([
        "लेवल आपकी व्यक्तिगत प्रगति दिखाता है, जबकि रैंक प्रोजेक्ट",
        "में दूसरे प्रतिभागियों के बीच आपकी स्थिति दिखाता है।",
      ]),
      ["रैंक और लेवल का अंतर"],
    ),
    "10.1-4": item(
      "Ranks पेज क्या दिखाता है?",
      j([
        "Ranks पेज प्रतिभागियों की सूची दिखाता है और आपको यह",
        "समझने में मदद करता है कि आपकी वर्तमान जगह क्या है।",
      ]),
      ["ranks पेज", "जगह"],
    ),
    "11.1-1": item(
      "मैं फंड्स क्यों नहीं निकाल पा रहा हूँ?",
      j([
        "आमतौर पर इसका मतलब है कि निकासी के लिए main balance,",
        "Wallet या इस कार्रवाई के लिए प्रोजेक्ट की शर्तें अभी पूरी",
        "नहीं हुई हैं।",
      ]),
      ["निकाल नहीं सकता", "withdraw"],
    ),
    "11.1-2": item(
      "Wallet कनेक्ट क्यों नहीं हो रहा?",
      j([
        "जाँचें कि आपने सही Wallet खोला है, Mini App का कनेक्शन",
        "टूटा नहीं है, और पुष्टि Wallet के अंदर ही की गई है।",
      ]),
      ["wallet कनेक्ट नहीं", "wallet problem"],
    ),
    "11.1-3": item(
      "मेरा पैनल ऊर्जा क्यों नहीं बना रहा?",
      j([
        "Panels स्क्रीन और पैनल की स्थिति देखें। वजह आमतौर पर उसके",
        "साइकिल चरण से जुड़ी होती है या आप सूची के गैर-सक्रिय भाग",
        "को देख रहे होते हैं।",
      ]),
      ["पैनल नहीं बना रहा", "panel problem"],
    ),
    "11.1-4": item(
      "VIP स्टेटस क्यों नहीं दिख रहा?",
      j([
        "जाँचें कि ज़रूरी NFT जुड़े हुए Wallet में है और बॉट इस",
        "Wallet को वर्तमान के रूप में देख रहा है।",
      ]),
      ["vip नहीं दिख रहा", "status"],
    ),
    "11.1-5": item(
      "बोनस क्यों नहीं आया?",
      j([
        "पहले बैलेंस हिस्ट्री और उस सेक्शन को देखें जिससे बोनस जुड़ा",
        "है। अगर बोनस तुरंत न दिखे, तो स्क्रीन रीफ़्रेश करें और",
        "FAQ में संबंधित सवाल देखें।",
      ]),
      ["बोनस नहीं आया", "bonus"],
    ),
    "11.1-6": item(
      "मेरा referral निष्क्रिय क्यों है?",
      j([
        "इसका मतलब है कि आपके लिंक से आए उपयोगकर्ता ने referral",
        "सिस्टम में सक्रिय स्थिति के लिए ज़रूरी शर्त अभी पूरी नहीं",
        "की है।",
      ]),
      ["निष्क्रिय referral", "inactive"],
    ),
    "11.1-7": item(
      "Shop खाली क्यों है?",
      j([
        "अगर Shop खाली है, तो इसका मतलब है कि अभी आपकी स्क्रीन के",
        "लिए कोई उपलब्ध आइटम नहीं हैं या ज़रूरी आइटम अभी दुकान में",
        "दिखाए नहीं गए हैं।",
      ]),
      ["shop खाली", "no items"],
    ),
    "12.1-1": item(
      "FAQ में शब्दों से खोज कैसे करूँ?",
      j([
        "FAQ खोलें और सर्च लाइन में इंटरफ़ेस का कोई साफ शब्द लिखें,",
        "जैसे balance, Wallet, panel, Exchange या Withdraw।",
      ]),
      ["खोज", "faq", "find"],
    ),
    "12.1-2": item(
      "बैलेंस वाला सवाल कहाँ ढूँढ़ूँ?",
      j([
        "Balances और Balance History सेक्शन देखें। ये बताते हैं कि",
        "आप इंटरफ़ेस में क्या देख रहे हैं और आपके फंड्स क्यों बदलते",
        "हैं।",
      ]),
      ["बैलेंस कहाँ", "history"],
    ),
    "12.1-3": item(
      "Wallet वाला सवाल कहाँ ढूँढ़ूँ?",
      j([
        "Wallet सेक्शन खोलें। वहाँ कनेक्शन, मुख्य Wallet और जुड़ने",
        "में आने वाली समस्याओं के सवाल मिलेंगे।",
      ]),
      ["wallet कहाँ", "wallet"],
    ),
    "12.1-4": item(
      "अगर मुझे जवाब न मिले तो क्या करूँ?",
      j([
        "बॉट इंटरफ़ेस से कोई दूसरा साफ शब्द आज़माएँ या अर्थ में",
        "करीब सेक्शन खोलें। अगर सवाल Wallet, History, Panels या",
        "Exchange से जुड़ा है, तो उन्हीं शब्दों से खोजें।",
      ]),
      ["जवाब नहीं मिला", "दूसरी खोज"],
    ),
  },
  id: {
    "1.1-1": item(
      "Apa itu saldo total?",
      j([
        "Saldo total menunjukkan semua EFHC yang saat ini Anda miliki",
        "di dalam bot. Ini membantu melihat gambaran umum, tetapi",
        "tidak sama dengan jumlah yang bisa ditarik.",
      ]),
      ["saldo total", "total balance"],
    ),
    "1.1-2": item(
      "Apa itu saldo utama?",
      j([
        "Saldo utama adalah bagian dana Anda yang dipakai untuk",
        "tindakan terpenting di proyek. Saldo inilah yang digunakan",
        "untuk penarikan.",
      ]),
      ["saldo utama", "main balance"],
    ),
    "1.1-3": item(
      "Apa itu saldo bonus?",
      j([
        "Saldo bonus adalah bagian internal dari dana Anda di bot.",
        "Saldo ini digunakan untuk aksi permainan dan pembelian di",
        "proyek, tetapi tidak untuk penarikan.",
      ]),
      ["saldo bonus", "bonus balance"],
    ),
    "1.1-4": item(
      "Apa bedanya saldo total, utama, dan bonus?",
      j([
        "Saldo total adalah semua dana Anda di bot. Saldo utama",
        "dipakai untuk pertukaran dan penarikan. Saldo bonus dipakai",
        "untuk aksi internal dan pembelian.",
      ]),
      ["beda saldo", "main", "bonus"],
    ),
    "1.2-1": item(
      "Mengapa saya tidak bisa menarik seluruh saldo total?",
      j([
        "Karena saldo total mencakup EFHC utama dan bonus. Hanya",
        "saldo utama yang dipakai untuk penarikan.",
      ]),
      ["penarikan", "saldo total"],
    ),
    "1.2-2": item(
      "Mengapa satu pembelian bisa menyentuh bonus dan utama?",
      j([
        "Bot dapat memakai dana internal Anda secara berurutan untuk",
        "satu tindakan. Karena itu satu pembelian bisa mengurangi dua",
        "saldo sekaligus.",
      ]),
      ["pembelian", "dua saldo"],
    ),
    "2.1-1": item(
      "Apa yang ditunjukkan riwayat saldo?",
      j([
        "Riwayat saldo menunjukkan perubahan dana Anda: pemasukan,",
        "pengurangan, dan pergerakan lain di dalam bot.",
      ]),
      ["riwayat", "riwayat saldo"],
    ),
    "2.1-2": item(
      "Tindakan apa yang muncul di riwayat saldo?",
      j([
        "Riwayat menampilkan tindakan utama yang mengubah saldo Anda:",
        "pembelian, bonus, pertukaran, penarikan, dan operasi proyek",
        "lainnya.",
      ]),
      ["tindakan", "riwayat"],
    ),
    "2.1-3": item(
      "Mengapa saldo saya berubah?",
      j([
        "Saldo berubah saat Anda melakukan tindakan di bot, menerima",
        "bonus, atau memakai sebagian dana Anda di dalam proyek.",
      ]),
      ["saldo berubah", "mengapa"],
    ),
    "2.1-4": item(
      "Bagaimana saya tahu mengapa dana masuk atau keluar?",
      j([
        "Buka riwayat saldo lalu lihat jenis tindakan, jumlah, dan",
        "tanggalnya. Itu membantu Anda memahami mengapa saldo",
        "berubah.",
      ]),
      ["mengapa dana", "riwayat"],
    ),
    "3.1-1": item(
      "Apa itu panel?",
      j([
        "Panel adalah elemen proyek yang membantu Anda membangun",
        "bagian energi dari progres Anda di dalam bot.",
      ]),
      ["panel", "apa itu panel"],
    ),
    "3.1-2": item(
      "Apa manfaat panel?",
      j([
        "Panel membuka kemungkinan untuk menghasilkan energi dan ikut",
        "dalam kemajuan proyek. Ini memengaruhi peluang dan",
        "perkembangan Anda di bot.",
      ]),
      ["manfaat panel", "energi"],
    ),
    "3.1-3": item(
      "Bagaimana cara membeli panel?",
      j([
        "Buka bagian Panels, pilih pembelian, lalu ikuti langkah di",
        "layar. Bot akan menunjukkan apa yang diperlukan untuk",
        "menyelesaikan tindakan itu.",
      ]),
      ["beli panel", "panels"],
    ),
    "3.1-4": item(
      "Apa yang terjadi jika saya punya beberapa panel?",
      j([
        "Beberapa panel memperluas peluang Anda di bagian energi",
        "proyek. Hasilnya terlihat pada progres dan nilai yang",
        "ditampilkan bot.",
      ]),
      ["beberapa panel", "panel"],
    ),
    "3.1-5": item(
      "Apa arti arsip panel?",
      j([
        "Arsip menampilkan panel yang tidak lagi berada di bagian",
        "aktif layar. Ini membantu membedakan panel aktif dan panel",
        "sebelumnya.",
      ]),
      ["arsip panel", "arsip"],
    ),
    "3.2-1": item(
      "Bagaimana energi muncul?",
      j([
        "Energi muncul di bagian panel proyek. Saat panel Anda",
        "bekerja, bot menampilkan hasilnya sebagai energi yang",
        "tersedia untuk Anda.",
      ]),
      ["energi", "bagaimana muncul"],
    ),
    "3.2-2": item(
      "Apa itu energi yang tersedia?",
      j([
        "Energi yang tersedia adalah bagian energi yang saat ini bisa",
        "Anda gunakan untuk tindakan berikutnya di bot.",
      ]),
      ["energi tersedia", "energi"],
    ),
    "3.2-3": item(
      "Mengapa panel bisa berhenti menghasilkan?",
      j([
        "Ini bisa terjadi jika panel tidak dalam status aktif atau",
        "jika fase kerjanya saat ini sudah selesai. Lihat status",
        "panel di layar.",
      ]),
      ["panel tidak menghasilkan", "status panel"],
    ),
    "4.1-1": item(
      "Apa itu pertukaran?",
      j([
        "Pertukaran adalah tindakan ketika energi Anda diubah menjadi",
        "EFHC di dalam proyek.",
      ]),
      ["pertukaran", "exchange"],
    ),
    "4.1-2": item(
      "Apa yang terjadi setelah pertukaran?",
      j([
        "Setelah pertukaran, bot memperbarui nilai Anda.",
        "Hasilnya terlihat di saldo dan bagian yang relevan.",
      ]),
      ["setelah pertukaran", "exchange"],
    ),
    "4.1-3": item(
      "Kapan saya harus menukar dulu dan kapan tarik tersedia?",
      j([
        "Jika Anda baru punya energi, Anda perlu menukarnya dulu",
        "menjadi EFHC. Penarikan tersedia saat jumlah yang diperlukan",
        "sudah ada di saldo utama.",
      ]),
      ["tukar sebelum tarik", "penarikan"],
    ),
    "4.2-1": item(
      "Apa itu penarikan?",
      j([
        "Penarikan adalah tindakan ketika Anda mengirim bagian saldo",
        "utama yang tersedia melalui fungsi terkait di dalam proyek.",
      ]),
      ["penarikan", "withdraw"],
    ),
    "4.2-2": item(
      "Mengapa saya tidak bisa menarik saldo bonus?",
      j([
        "Saldo bonus ditujukan untuk tindakan internal di bot dan",
        "tidak digunakan untuk penarikan. Untuk penarikan hanya saldo",
        "utama yang dipakai.",
      ]),
      ["saldo bonus", "mengapa tidak"],
    ),
    "4.2-3": item(
      "Mengapa saldo utama berubah setelah permintaan tarik?",
      j([
        "Setelah Anda membuat permintaan penarikan, bot langsung",
        "memperhitungkan jumlah itu untuk tindakan tersebut. Karena",
        "itu saldo utama langsung terlihat berbeda.",
      ]),
      ["permintaan tarik", "saldo utama"],
    ),
    "4.2-4": item(
      "Mengapa penarikan bisa tidak tersedia?",
      j([
        "Penarikan bisa tidak tersedia jika syarat yang diperlukan",
        "belum terpenuhi. Periksa saldo utama dan status tindakan saat",
        "ini.",
      ]),
      ["penarikan tidak tersedia", "withdraw"],
    ),
    "5.1-1": item(
      "Mengapa saya memerlukan wallet?",
      j([
        "Wallet diperlukan untuk tindakan ketika proyek meminta",
        "konfirmasi eksternal dan kaitan ke alamat Anda. Wallet juga",
        "penting untuk VIP NFT dan tindakan terkait.",
      ]),
      ["wallet", "why wallet"],
    ),
    "5.1-2": item(
      "Bagaimana cara menghubungkan wallet?",
      j([
        "Buka bagian Wallet, pilih connect, lalu konfirmasikan",
        "tindakan di aplikasi wallet yang didukung.",
      ]),
      ["connect wallet", "wallet"],
    ),
    "5.1-3": item(
      "Apa itu wallet utama?",
      j([
        "Wallet utama adalah wallet yang digunakan bot sebagai yang",
        "paling penting untuk tindakan saat alamat pilihan Anda",
        "dibutuhkan.",
      ]),
      ["primary wallet", "main wallet"],
    ),
    "5.1-4": item(
      "Bisakah saya menautkan beberapa wallet?",
      j([
        "Ya. Bot dapat menyimpan beberapa wallet yang tertaut dan",
        "membiarkan Anda memilih salah satunya sebagai wallet utama.",
      ]),
      ["several wallets", "primary wallet"],
    ),
    "5.1-5": item(
      "Apa yang harus saya lakukan jika wallet tidak terhubung?",
      j([
        "Periksa bahwa aplikasi wallet yang benar terbuka, koneksi",
        "Telegram Mini App tidak terputus, dan Anda sudah",
        "mengonfirmasi koneksi di dalam wallet itu sendiri.",
      ]),
      ["not connecting", "wallet problem"],
    ),
    "6.1-1": item(
      "Apa itu referral?",
      j([
        "Referral adalah pengguna yang datang ke proyek melalui link",
        "Anda lalu memengaruhi progres Anda sesuai aturan sistem",
        "referral.",
      ]),
      ["referrals", "invited users"],
    ),
    "6.1-2": item(
      "Bagaimana cara kerja link referral saya?",
      j([
        "Anda membagikan link kepada pengguna baru. Jika pengguna",
        "itu masuk ke proyek melalui link tersebut, dia dihitung di",
        "dalam sistem referral Anda.",
      ]),
      ["referral link", "invite link"],
    ),
    "6.1-3": item(
      "Siapa yang dianggap referral aktif?",
      j([
        "Referral aktif adalah pengguna yang sudah memenuhi syarat",
        "yang diperlukan proyek dan masuk ke statistik referral aktif",
        "Anda.",
      ]),
      ["active referral", "referral active"],
    ),
    "6.1-4": item(
      "Siapa yang dianggap referral tidak aktif?",
      j([
        "Referral tidak aktif adalah pengguna yang masuk melalui",
        "link Anda, tetapi belum memenuhi syarat untuk status aktif.",
      ]),
      ["inactive referral", "referral inactive"],
    ),
    "6.1-5": item(
      "Apa yang ditunjukkan penghitung di halaman referrals?",
      j([
        "Penghitung menunjukkan total referral Anda, berapa banyak",
        "yang aktif, dan bagaimana hal itu memengaruhi progres Anda",
        "di sistem referral.",
      ]),
      ["counters", "referrals page"],
    ),
    "6.1-6": item(
      "Bagaimana progres ke level berikutnya bekerja?",
      j([
        "Progres menunjukkan seberapa banyak yang masih dibutuhkan",
        "untuk langkah berikutnya di jalur referral Anda. Ini",
        "membantu Anda cepat melihat jarak ke level atau bonus",
        "berikutnya.",
      ]),
      ["progress", "next level"],
    ),
    "7.1-1": item(
      "Apa itu VIP NFT?",
      j([
        "VIP NFT adalah NFT khusus proyek yang memberi pengguna efek",
        "VIP sesuai aturan EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "Apa yang diberikan VIP NFT kepada saya?",
      j([
        "VIP NFT memberi keuntungan khusus di dalam proyek. Di",
        "antarmuka, hal ini terkait dengan status VIP dan efek proyek",
        "yang menyertainya.",
      ]),
      ["what vip nft gives", "vip status"],
    ),
    "7.1-3": item(
      "Apakah saya memerlukan wallet tertaut untuk VIP NFT?",
      j([
        "Ya. Bot memerlukan wallet tertaut untuk melihat VIP NFT Anda",
        "dan menghubungkannya dengan benar ke status Anda.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "Kapan status VIP menjadi aktif?",
      j([
        "Ketika bot melihat NFT yang benar di wallet tertaut Anda,",
        "status VIP diperbarui secara otomatis sesuai aturan proyek.",
      ]),
      ["vip status", "becomes active"],
    ),
    "7.1-5": item(
      "Apa yang harus saya lakukan jika NFT ada tetapi status hilang?",
      j([
        "Periksa bahwa NFT berada di wallet tertaut yang benar dan",
        "wallet itu masih menjadi wallet yang aktif di bot. Lalu",
        "segarkan layar dan periksa lagi.",
      ]),
      ["nft exists", "status missing"],
    ),
    "8.1-1": item(
      "Apa itu Shop?",
      j([
        "Shop adalah bagian tempat pengguna dapat membeli item di",
        "dalam bot dan hal proyek lain yang terkait dengan gaya",
        "antarmuka.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "Apa yang bisa saya beli di Shop?",
      j([
        "Di Shop Anda dapat membeli item proyek yang saat ini",
        "ditampilkan kepada Anda, seperti skins dan elemen lain yang",
        "sesuai.",
      ]),
      ["what to buy", "items"],
    ),
    "8.1-3": item(
      "Apa bedanya membeli dengan EFHC dan melalui Wallet?",
      j([
        "Membeli dengan EFHC menggunakan dana Anda di dalam bot.",
        "Membeli melalui Wallet memerlukan konfirmasi eksternal dari",
        "wallet Anda.",
      ]),
      ["buy with efhc", "through wallet"],
    ),
    "8.1-4": item(
      "Mengapa Shop bisa tidak menampilkan apa pun?",
      j([
        "Ini bisa terjadi jika saat ini tidak ada item yang tersedia",
        "untuk layar Anda atau jika bagian itu belum diisi dengan",
        "posisi yang sesuai.",
      ]),
      ["shop empty", "nothing shown"],
    ),
    "8.2-1": item(
      "Apa itu skins?",
      j([
        "Skins adalah elemen desain visual yang mengubah tampilan",
        "bagian tertentu dari antarmuka di dalam proyek.",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "Apa bedanya skins biasa dan desain level?",
      j([
        "Skins biasa adalah pembelian atau elemen desain yang",
        "tersedia. Desain level terkait dengan progres Anda dan",
        "terbuka sesuai aturan proyek.",
      ]),
      ["level design", "skins difference"],
    ),
    "8.2-3": item(
      "Bagaimana cara membeli dan mengaktifkan skin?",
      j([
        "Pertama beli skin yang tersedia di Shop, lalu pilih di",
        "antara desain yang Anda miliki dan aktifkan di antarmuka.",
      ]),
      ["buy skin", "activate skin"],
    ),
    "9.1-1": item(
      "Bagaimana cara menambah saldo saya?",
      j([
        "Buka tindakan yang diperlukan di bot dan ikuti langkah di",
        "layar. Jika Wallet diperlukan, bot akan menunjukkan langkah",
        "berikutnya.",
      ]),
      ["isi saldo", "top up"],
    ),
    "9.1-2": item(
      "Kapan Wallet diperlukan untuk pembelian?",
      j([
        "Wallet diperlukan saat pembelian tidak hanya terjadi di",
        "dalam bot, tetapi juga memerlukan konfirmasi eksternal dari",
        "alamat Anda.",
      ]),
      ["wallet diperlukan", "pembelian"],
    ),
    "9.2-1": item(
      "Bagaimana pembelian melalui Wallet berlangsung?",
      j([
        "Bot membawa Anda ke langkah konfirmasi di Wallet. Setelah",
        "konfirmasi, hasil pembelian diperbarui di dalam proyek.",
      ]),
      ["beli via wallet", "wallet buy"],
    ),
    "9.2-2": item(
      "Apa bedanya pembelian internal dan pembelian lewat Wallet?",
      j([
        "Pembelian internal memakai EFHC Anda di dalam bot. Pembelian",
        "lewat Wallet memerlukan konfirmasi eksternal di Wallet.",
      ]),
      ["pembelian internal", "via wallet"],
    ),
    "9.2-3": item(
      "Apa yang terjadi setelah pembayaran?",
      j([
        "Setelah pembayaran, hasilnya harus muncul di antarmuka bot:",
        "saldo, pembelian, atau elemen baru diperbarui sesuai aturan",
        "proyek.",
      ]),
      ["setelah pembayaran", "payment result"],
    ),
    "9.2-4": item(
      "Mengapa saya tidak langsung melihat hasil setelah membayar?",
      j([
        "Beberapa tindakan membutuhkan sedikit waktu untuk",
        "diperbarui di antarmuka. Jika hasilnya belum muncul, segarkan",
        "layar dan periksa riwayat atau bagian yang diperlukan.",
      ]),
      ["hasil belum terlihat", "setelah bayar"],
    ),
    "10.1-1": item(
      "Apa itu level?",
      j([
        "Level menunjukkan kemajuan pribadi Anda di dalam proyek. Ini",
        "naik seiring kemajuan Anda dalam mekanik game dan energi",
        "EFHC Bot.",
      ]),
      ["level", "kemajuan"],
    ),
    "10.1-2": item(
      "Apa itu rank?",
      j([
        "Rank menunjukkan posisi Anda di antara peserta lain pada",
        "halaman Ranks.",
      ]),
      ["rank", "ranks"],
    ),
    "10.1-3": item(
      "Apa perbedaan level dan rank?",
      j([
        "Level menunjukkan kemajuan pribadi Anda, sedangkan rank",
        "menunjukkan posisi Anda di antara peserta proyek lainnya.",
      ]),
      ["beda level rank"],
    ),
    "10.1-4": item(
      "Apa yang ditampilkan halaman Ranks?",
      j([
        "Halaman Ranks menampilkan peringkat peserta dan membantu",
        "Anda memahami posisi Anda saat ini dibandingkan yang lain.",
      ]),
      ["halaman ranks", "posisi"],
    ),
    "11.1-1": item(
      "Mengapa saya tidak bisa menarik dana?",
      j([
        "Biasanya ini berarti penarikan memerlukan main balance,",
        "Wallet, atau syarat proyek untuk tindakan ini belum",
        "terpenuhi.",
      ]),
      ["tidak bisa tarik", "withdraw"],
    ),
    "11.1-2": item(
      "Mengapa Wallet tidak terhubung?",
      j([
        "Periksa bahwa Anda membuka Wallet yang tepat, koneksi ke",
        "Mini App tidak terputus, dan konfirmasi dilakukan di dalam",
        "wallet itu sendiri.",
      ]),
      ["wallet tidak terhubung", "masalah wallet"],
    ),
    "11.1-3": item(
      "Mengapa panel saya tidak menghasilkan energi?",
      j([
        "Periksa layar Panels saat ini dan status panel. Penyebabnya",
        "biasanya terkait tahap siklusnya atau karena Anda melihat",
        "bagian daftar yang tidak aktif.",
      ]),
      ["panel tidak menghasilkan", "masalah panel"],
    ),
    "11.1-4": item(
      "Mengapa status VIP tidak muncul?",
      j([
        "Periksa bahwa NFT yang diperlukan ada di Wallet yang",
        "terhubung dan bot sudah melihat wallet itu sebagai yang",
        "aktif saat ini.",
      ]),
      ["vip tidak muncul", "status"],
    ),
    "11.1-5": item(
      "Mengapa bonus belum masuk?",
      j([
        "Periksa dulu riwayat saldo dan bagian yang terkait dengan",
        "bonus itu. Jika bonus belum muncul, segarkan layar dan lihat",
        "pertanyaan terkait di FAQ.",
      ]),
      ["bonus belum masuk", "bonus"],
    ),
    "11.1-6": item(
      "Mengapa referral saya tidak aktif?",
      j([
        "Ini berarti pengguna dari tautan Anda belum memenuhi syarat",
        "yang diperlukan untuk status aktif di sistem referral.",
      ]),
      ["referral tidak aktif", "inactive"],
    ),
    "11.1-7": item(
      "Mengapa Shop kosong?",
      j([
        "Jika Shop kosong, artinya saat ini tidak ada item yang",
        "tersedia untuk layar Anda atau item yang dibutuhkan belum",
        "ditampilkan di toko.",
      ]),
      ["shop kosong", "tidak ada item"],
    ),
    "12.1-1": item(
      "Bagaimana cara mencari kata di FAQ?",
      j([
        "Buka FAQ dan masukkan kata antarmuka yang jelas di kolom",
        "pencarian, misalnya balance, Wallet, panel, Exchange, atau",
        "Withdraw.",
      ]),
      ["pencarian", "faq", "cari"],
    ),
    "12.1-2": item(
      "Di mana saya mencari pertanyaan tentang saldo?",
      j([
        "Lihat bagian Balances dan Balance History. Bagian ini",
        "menjelaskan apa yang Anda lihat di antarmuka dan mengapa dana",
        "Anda berubah.",
      ]),
      ["saldo di mana", "riwayat"],
    ),
    "12.1-3": item(
      "Di mana saya mencari pertanyaan tentang Wallet?",
      j([
        "Buka bagian Wallet. Di sana ada pertanyaan tentang koneksi,",
        "Wallet utama, dan masalah saat menghubungkan.",
      ]),
      ["wallet di mana", "wallet"],
    ),
    "12.1-4": item(
      "Apa yang harus saya lakukan jika tidak menemukan jawabannya?",
      j([
        "Coba kata lain yang jelas dari antarmuka bot atau buka",
        "bagian yang dekat maknanya. Jika pertanyaannya tentang",
        "Wallet, History, Panels, atau Exchange, cari dengan kata",
        "itu.",
      ]),
      ["tidak menemukan jawaban", "pencarian lain"],
    ),
  },
  sw: {
    "1.1-1": item(
      "Salio la jumla ni nini?",
      j([
        "Salio la jumla linaonyesha EFHC zote ulizo nazo sasa ndani",
        "ya bot. Linasaidia kuona picha ya jumla, lakini si sawa na",
        "kiasi kinachoweza kutolewa.",
      ]),
      ["salio la jumla", "total balance"],
    ),
    "1.1-2": item(
      "Salio kuu ni nini?",
      j([
        "Salio kuu ni sehemu ya fedha zako inayotumika kwa hatua",
        "muhimu zaidi za mradi. Hili ndilo salio linalotumika kwenye",
        "utoaji.",
      ]),
      ["salio kuu", "main balance"],
    ),
    "1.1-3": item(
      "Salio la bonus ni nini?",
      j([
        "Salio la bonus ni sehemu ya ndani ya fedha zako kwenye bot.",
        "Linatumika kwa hatua za mchezo na manunuzi ndani ya mradi,",
        "lakini si kwa utoaji.",
      ]),
      ["salio la bonus", "bonus balance"],
    ),
    "1.1-4": item(
      "Tofauti ni nini kati ya salio la jumla, kuu na bonus?",
      j([
        "Salio la jumla ni fedha zako zote ndani ya bot. Salio kuu",
        "linatumika kwa ubadilishaji na utoaji. Salio la bonus",
        "linatumika kwa hatua za ndani na manunuzi.",
      ]),
      ["tofauti ya salio", "main", "bonus"],
    ),
    "1.2-1": item(
      "Kwa nini siwezi kutoa salio lote la jumla?",
      j([
        "Kwa sababu salio la jumla linajumuisha EFHC kuu na bonus.",
        "Ni salio kuu pekee linalotumika kwa utoaji.",
      ]),
      ["utoaji", "salio la jumla"],
    ),
    "1.2-2": item(
      "Kwa nini ununuzi mmoja unaweza kugusa bonus na kuu pia?",
      j([
        "Bot inaweza kutumia fedha zako za ndani kwa mpangilio kwa",
        "hatua moja. Ndiyo maana ununuzi mmoja unaweza kupunguza",
        "salio mbili kwa wakati mmoja.",
      ]),
      ["ununuzi", "salio mbili"],
    ),
    "2.1-1": item(
      "Historia ya salio inaonyesha nini?",
      j([
        "Historia ya salio inaonyesha mabadiliko ya fedha zako:",
        "mapato, makato na mwendo mwingine ndani ya bot.",
      ]),
      ["historia", "historia ya salio"],
    ),
    "2.1-2": item(
      "Ni hatua gani zinaonekana kwenye historia ya salio?",
      j([
        "Historia inaonyesha hatua kuu zinazobadilisha salio zako:",
        "manunuzi, bonus, ubadilishaji, utoaji na operesheni nyingine",
        "za mradi.",
      ]),
      ["hatua", "historia"],
    ),
    "2.1-3": item(
      "Kwa nini salio langu limebadilika?",
      j([
        "Salio linaweza kubadilika unapofanya hatua ndani ya bot,",
        "kupokea bonus au kutumia sehemu ya fedha zako ndani ya",
        "mradi.",
      ]),
      ["salio limebadilika", "kwa nini"],
    ),
    "2.1-4": item(
      "Nitajuaje kwa nini fedha ziliingia au zilitoka?",
      j([
        "Fungua historia ya salio uangalie aina ya hatua, kiasi na",
        "tarehe. Hilo litakusaidia kuelewa kwa nini salio",
        "lilibadilika.",
      ]),
      ["kwa nini fedha", "historia"],
    ),
    "3.1-1": item(
      "Paneli ni nini?",
      j([
        "Paneli ni kipengele cha mradi kinachokusaidia kujenga sehemu",
        "ya nishati ya maendeleo yako ndani ya bot.",
      ]),
      ["paneli", "paneli ni nini"],
    ),
    "3.1-2": item(
      "Paneli inatoa nini?",
      j([
        "Paneli inafungua uwezekano wa kuzalisha nishati na kushiriki",
        "katika maendeleo ya mradi. Inaathiri uwezo na ukuaji wako",
        "ndani ya bot.",
      ]),
      ["faida ya paneli", "nishati"],
    ),
    "3.1-3": item(
      "Ninanunuaje paneli?",
      j([
        "Fungua sehemu ya Panels, chagua ununuzi na fuata hatua za",
        "kwenye skrini. Bot itaonyesha kinachohitajika kukamilisha",
        "hatua hiyo.",
      ]),
      ["nunua paneli", "panels"],
    ),
    "3.1-4": item(
      "Nini hutokea nikikuwa na paneli kadhaa?",
      j([
        "Paneli kadhaa huongeza uwezekano wako katika sehemu ya",
        "nishati ya mradi. Matokeo yanaonekana kwenye maendeleo yako",
        "na thamani ambazo bot inaonyesha.",
      ]),
      ["paneli kadhaa", "paneli"],
    ),
    "3.1-5": item(
      "Arki ya paneli ina maana gani?",
      j([
        "Arki inaonyesha paneli ambazo haziko tena kwenye sehemu",
        "inayotumika ya skrini. Hii hukusaidia kutofautisha paneli",
        "zinazotumika na zile za zamani.",
      ]),
      ["arki ya paneli", "arki"],
    ),
    "3.2-1": item(
      "Nishati inapatikanaje?",
      j([
        "Nishati hutokea katika sehemu ya paneli ya mradi. Paneli",
        "zako zikifanya kazi, bot huonyesha matokeo yake kama",
        "nishati inayopatikana kwako.",
      ]),
      ["nishati", "inapatikanaje"],
    ),
    "3.2-2": item(
      "Nishati inayopatikana ni nini?",
      j([
        "Nishati inayopatikana ni sehemu ya nishati ambayo kwa sasa",
        "unaweza kutumia kwa hatua zinazofuata ndani ya bot.",
      ]),
      ["nishati inayopatikana", "nishati"],
    ),
    "3.2-3": item(
      "Kwa nini paneli inaweza kuacha kuzalisha?",
      j([
        "Hili linaweza kutokea ikiwa paneli haiko kwenye hali ya",
        "active au ikiwa hatua yake ya sasa ya kazi",
        "imekamilika. Angalia hali ya paneli kwenye skrini.",
      ]),
      ["paneli haizalishi", "hali ya paneli"],
    ),
    "4.1-1": item(
      "Ubadilishaji ni nini?",
      j([
        "Ubadilishaji ni hatua ambayo nishati yako hugeuzwa kuwa EFHC",
        "ndani ya mradi.",
      ]),
      ["ubadilishaji", "exchange"],
    ),
    "4.1-2": item(
      "Nini hutokea baada ya ubadilishaji?",
      j([
        "Baada ya ubadilishaji, bot husasisha thamani zako na",
        "kuonyesha matokeo kwenye salio na sehemu husika.",
      ]),
      ["baada ya ubadilishaji", "exchange"],
    ),
    "4.1-3": item(
      "Ni lini nibadilishe kwanza na ni lini utoaji unapatikana?",
      j([
        "Ikiwa kwa sasa una nishati tu, lazima kwanza uibadilishe kuwa",
        "EFHC. Utoaji unapatikana pale kiasi kinachohitajika kikiwa",
        "kwenye salio kuu.",
      ]),
      ["badili kabla ya kutoa", "utoaji"],
    ),
    "4.2-1": item(
      "Utoaji ni nini?",
      j([
        "Utoaji ni hatua ambayo unatuma sehemu inayopatikana ya",
        "salio kuu lako kupitia kazi husika ndani ya mradi.",
      ]),
      ["utoaji", "withdraw"],
    ),
    "4.2-2": item(
      "Kwa nini siwezi kutoa salio la bonus?",
      j([
        "Salio la bonus limetengwa kwa hatua za ndani ya bot na",
        "halitumiki kwa utoaji. Kwa utoaji hutumika salio kuu pekee.",
      ]),
      ["salio la bonus", "kwa nini haiwezekani"],
    ),
    "4.2-3": item(
      "Kwa nini salio kuu lilibadilika baada ya ombi la kutoa?",
      j([
        "Baada ya kuunda ombi la kutoa, bot huzingatia kiasi hicho",
        "kwa hatua hiyo. Ndiyo maana salio kuu linaonekana tofauti",
        "mara moja.",
      ]),
      ["ombi la kutoa", "salio kuu"],
    ),
    "4.2-4": item(
      "Kwa nini utoaji unaweza usipatikane?",
      j([
        "Utoaji unaweza usipatikane ikiwa masharti muhimu bado",
        "hayajatimizwa. Angalia salio kuu na hali ya hatua ya sasa.",
      ]),
      ["utoaji haupatikani", "withdraw"],
    ),
    "5.1-1": item(
      "Kwa nini ninahitaji wallet?",
      j([
        "Wallet inahitajika kwa hatua ambazo mradi unahitaji",
        "uthibitisho wa nje na uhusiano na anwani yako. Pia ni muhimu",
        "kwa VIP NFT na hatua zinazohusiana nayo.",
      ]),
      ["wallet", "why wallet"],
    ),
    "5.1-2": item(
      "Ninaunganishaje wallet?",
      j([
        "Fungua sehemu ya Wallet, chagua connect, kisha thibitisha",
        "hatua hiyo ndani ya programu ya wallet inayokubaliwa.",
      ]),
      ["connect wallet", "wallet"],
    ),
    "5.1-3": item(
      "Wallet kuu ni nini?",
      j([
        "Wallet kuu ni wallet ambayo bot hutumia kama ya msingi kwa",
        "hatua ambazo anwani uliyochagua inahitajika.",
      ]),
      ["primary wallet", "main wallet"],
    ),
    "5.1-4": item(
      "Je, ninaweza kuunganisha wallet kadhaa?",
      j([
        "Ndiyo. Bot inaweza kuhifadhi wallet kadhaa zilizounganishwa",
        "na kukuruhusu kuchagua moja kama wallet kuu.",
      ]),
      ["several wallets", "primary wallet"],
    ),
    "5.1-5": item(
      "Nifanye nini ikiwa wallet haiunganishi?",
      j([
        "Angalia kuwa programu sahihi ya wallet imefunguliwa,",
        "muunganisho wa Telegram Mini App haujakatika,",
        "na umethibitisha muunganisho ndani ya wallet",
        "yenyewe.",
      ]),
      ["not connecting", "wallet problem"],
    ),
    "6.1-1": item(
      "Referrals ni nini?",
      j([
        "Referrals ni watumiaji waliokuja kwenye mradi kupitia link",
        "yako na baadaye huathiri maendeleo yako kulingana na sheria",
        "za mfumo wa referral.",
      ]),
      ["referrals", "invited users"],
    ),
    "6.1-2": item(
      "Link yangu ya referral inafanyaje kazi?",
      j([
        "Unashiriki link yako na mtumiaji mpya. Ikiwa mtumiaji huyo",
        "anaingia kwenye mradi kupitia link hiyo, anahesabiwa ndani ya",
        "mfumo wako wa referral.",
      ]),
      ["referral link", "invite link"],
    ),
    "6.1-3": item(
      "Nani anahesabika kama referral active?",
      j([
        "Referral active ni mtumiaji ambaye tayari ametimiza sharti",
        "linalohitajika na mradi na sasa yuko kwenye takwimu zako za",
        "referral active.",
      ]),
      ["active referral", "referral active"],
    ),
    "6.1-4": item(
      "Nani anahesabika kama referral inactive?",
      j([
        "Referral inactive ni mtumiaji aliyekuja kupitia link yako,",
        "lakini bado hajatimiza sharti la status active.",
      ]),
      ["inactive referral", "referral inactive"],
    ),
    "6.1-5": item(
      "Vihesabu kwenye ukurasa wa referrals vinaonyesha nini?",
      j([
        "Vihesabu vinaonyesha referrals zako zote, ni wangapi kati",
        "yao walio active, na jinsi hilo linavyoathiri maendeleo yako",
        "ndani ya mfumo wa referral.",
      ]),
      ["counters", "referrals page"],
    ),
    "6.1-6": item(
      "Maendeleo kwenda level inayofuata yanafanyaje kazi?",
      j([
        "Maendeleo yanaonyesha kiasi kilichobaki hadi hatua inayofuata",
        "kwenye mstari wako wa referral. Hii hukusaidia kuona haraka",
        "kilichobaki hadi level au bonus inayofuata.",
      ]),
      ["progress", "next level"],
    ),
    "7.1-1": item(
      "VIP NFT ni nini?",
      j([
        "VIP NFT ni NFT maalum ya mradi inayompa mtumiaji athari ya",
        "VIP kulingana na sheria za EFHC Bot.",
      ]),
      ["vip nft", "vip"],
    ),
    "7.1-2": item(
      "VIP NFT inanipa nini?",
      j([
        "VIP NFT inatoa faida maalum ndani ya mradi. Kwenye",
        "interface, hii inaunganishwa na VIP status na athari",
        "zinazohusiana nayo kwenye mradi.",
      ]),
      ["what vip nft gives", "vip status"],
    ),
    "7.1-3": item(
      "Je, ninahitaji wallet iliyounganishwa kwa VIP NFT?",
      j([
        "Ndiyo. Bot inahitaji wallet iliyounganishwa ili kuona VIP",
        "NFT yako na kuiunganisha sawasawa na status yako.",
      ]),
      ["wallet", "vip nft"],
    ),
    "7.1-4": item(
      "VIP status huwa active lini?",
      j([
        "Bot inapoona NFT sahihi ndani ya wallet yako iliyounganishwa,",
        "VIP status husasishwa moja kwa moja kulingana na sheria za",
        "mradi.",
      ]),
      ["vip status", "becomes active"],
    ),
    "7.1-5": item(
      "Nifanye nini ikiwa nina NFT lakini status haionekani?",
      j([
        "Angalia kuwa NFT iko kwenye wallet sahihi iliyounganishwa na",
        "kuwa wallet hiyo bado ni ya sasa ndani ya bot. Kisha",
        "refresh screen na uangalie tena.",
      ]),
      ["nft exists", "status missing"],
    ),
    "8.1-1": item(
      "Shop ni nini?",
      j([
        "Shop ni sehemu ambayo mtumiaji anaweza kununua vitu vya ndani",
        "ya bot na vipengele vingine vya mradi vinavyohusiana na",
        "mtindo wa interface.",
      ]),
      ["shop", "store"],
    ),
    "8.1-2": item(
      "Naweza kununua nini ndani ya Shop?",
      j([
        "Ndani ya Shop unaweza kununua vitu vya mradi vinavyoonyeshwa",
        "kwako sasa, kama skins na vipengele vingine vinavyofaa.",
      ]),
      ["what to buy", "items"],
    ),
    "8.1-3": item(
      "Kununua kwa EFHC kunatofautianaje na kununua kupitia Wallet?",
      j([
        "Kununua kwa EFHC hutumia fedha zako zilizo ndani ya bot.",
        "Kununua kupitia Wallet kunahitaji uthibitisho wa nje kupitia",
        "wallet yako.",
      ]),
      ["buy with efhc", "through wallet"],
    ),
    "8.1-4": item(
      "Kwa nini Shop inaweza kuonyesha hakuna kitu?",
      j([
        "Hili linaweza kutokea ikiwa kwa sasa hakuna",
        "vitu vinavyopatikana kwa screen yako au ikiwa",
        "sehemu hiyo bado haijajazwa na",
        "vitu vinavyofaa.",
      ]),
      ["shop empty", "nothing shown"],
    ),
    "8.2-1": item(
      "Skins ni nini?",
      j([
        "Skins ni vipengele vya muundo wa kuona vinavyobadilisha jinsi",
        "sehemu za interface zinavyoonekana ndani ya mradi.",
      ]),
      ["skins", "design"],
    ),
    "8.2-2": item(
      "Skins za kawaida zinatofautianaje na level designs?",
      j([
        "Skins za kawaida ni manunuzi au vipengele vya muundo",
        "vinavyopatikana. Level designs zinahusiana na progress yako",
        "na hufunguliwa kulingana na sheria za mradi.",
      ]),
      ["level design", "skins difference"],
    ),
    "8.2-3": item(
      "Ninanunuaje na kuamilisha skin?",
      j([
        "Kwanza nunua skin inayopatikana ndani ya Shop, kisha ichague",
        "miongoni mwa designs zako zinazopatikana na uiamilishe ndani",
        "ya interface.",
      ]),
      ["buy skin", "activate skin"],
    ),
    "9.1-1": item(
      "Ninawezaje kuongeza salio langu?",
      j([
        "Fungua hatua inayohitajika ndani ya bot na fuata maagizo ya",
        "kwenye skrini. Ikiwa Wallet inahitajika, bot itaonyesha hatua",
        "inayofuata.",
      ]),
      ["ongeza salio", "top up"],
    ),
    "9.1-2": item(
      "Wallet inahitajika lini kwa ununuzi?",
      j([
        "Wallet inahitajika wakati ununuzi haufanyiki tu ndani ya",
        "bot, bali unahitaji uthibitisho wa nje kupitia anwani yako.",
      ]),
      ["wallet inahitajika", "ununuzi"],
    ),
    "9.2-1": item(
      "Ununuzi kupitia Wallet unafanyikaje?",
      j([
        "Bot inakupeleka kwenye hatua ya kuthibitisha ndani ya",
        "Wallet. Baada ya uthibitisho, matokeo ya ununuzi",
        "yanasasishwa kwenye mradi.",
      ]),
      ["nunua kupitia wallet", "wallet buy"],
    ),
    "9.2-2": item(
      "Tofauti ni nini kati ya ununuzi wa ndani na wa Wallet?",
      j([
        "Ununuzi wa ndani hutumia EFHC zako ndani ya bot. Ununuzi",
        "kupitia Wallet unahitaji uthibitisho wa nje ndani ya Wallet.",
      ]),
      ["ununuzi wa ndani", "kupitia wallet"],
    ),
    "9.2-3": item(
      "Nini hutokea baada ya malipo?",
      j([
        "Baada ya malipo, matokeo yanapaswa kuonekana kwenye",
        "kiolesura cha bot: salio, ununuzi au kipengee kipya",
        "husasishwa kulingana na sheria za mradi.",
      ]),
      ["baada ya malipo", "payment result"],
    ),
    "9.2-4": item(
      "Kwa nini sioni matokeo mara moja baada ya kulipa?",
      j([
        "Baadhi ya vitendo vinahitaji muda mfupi kusasishwa kwenye",
        "kiolesura. Ikiwa matokeo hayajaonekana mara moja, pakia upya",
        "skrini na uangalie historia au sehemu inayohitajika.",
      ]),
      ["sioni matokeo", "baada ya malipo"],
    ),
    "10.1-1": item(
      "Level ni nini?",
      j([
        "Level inaonyesha maendeleo yako binafsi ndani ya mradi.",
        "Huongezeka kadri unavyoendelea katika mifumo ya mchezo na",
        "nishati ya EFHC Bot.",
      ]),
      ["level", "maendeleo"],
    ),
    "10.1-2": item(
      "Rank ni nini?",
      j([
        "Rank inaonyesha nafasi yako kati ya washiriki wengine kwenye",
        "ukurasa wa Ranks.",
      ]),
      ["rank", "ranks"],
    ),
    "10.1-3": item(
      "Tofauti ni nini kati ya level na rank?",
      j([
        "Level inaonyesha maendeleo yako binafsi, wakati rank",
        "inaonyesha nafasi yako kati ya washiriki wengine wa mradi.",
      ]),
      ["tofauti ya level na rank"],
    ),
    "10.1-4": item(
      "Ukurasa wa Ranks unaonyesha nini?",
      j([
        "Ukurasa wa Ranks unaonyesha orodha ya washiriki na hukusaidia",
        "kuelewa nafasi yako ya sasa ukilinganisha na wengine.",
      ]),
      ["ukurasa wa ranks", "nafasi"],
    ),
    "11.1-1": item(
      "Kwa nini siwezi kutoa fedha?",
      j([
        "Kwa kawaida hii inamaanisha kuwa utoaji unahitaji main",
        "balance, Wallet au masharti ya mradi kwa hatua hii bado",
        "hayajatimizwa.",
      ]),
      ["siwezi kutoa", "withdraw"],
    ),
    "11.1-2": item(
      "Kwa nini Wallet haiunganishi?",
      j([
        "Angalia kuwa umefungua Wallet sahihi, muunganisho wa Mini",
        "App haujakatika, na uthibitisho umefanywa ndani ya wallet",
        "yenyewe.",
      ]),
      ["wallet haiunganishi", "tatizo la wallet"],
    ),
    "11.1-3": item(
      "Kwa nini paneli yangu haitoi nishati?",
      j([
        "Angalia skrini ya sasa ya Panels na hali ya paneli. Sababu",
        "kwa kawaida huhusiana na hatua ya mzunguko wake au kwa kuwa",
        "unaangalia sehemu isiyo hai ya orodha.",
      ]),
      ["paneli haitoi", "tatizo la paneli"],
    ),
    "11.1-4": item(
      "Kwa nini hali ya VIP haionekani?",
      j([
        "Angalia kuwa NFT inayohitajika iko katika Wallet",
        "iliyounganishwa na bot tayari inaiona wallet hiyo kama ya",
        "sasa.",
      ]),
      ["vip haionekani", "status"],
    ),
    "11.1-5": item(
      "Kwa nini bonus haijafika?",
      j([
        "Kwanza angalia historia ya salio na sehemu inayohusiana na",
        "bonus hiyo. Ikiwa bonus haikuonekana mara moja, pakia upya",
        "skrini na angalia swali husika kwenye FAQ.",
      ]),
      ["bonus haijafika", "bonus"],
    ),
    "11.1-6": item(
      "Kwa nini referral yangu haiko active?",
      j([
        "Hii ina maana kuwa mtumiaji kutoka kwenye kiungo chako bado",
        "hajatimiza sharti la hali ya active katika mfumo wa",
        "referral.",
      ]),
      ["referral inactive", "inactive"],
    ),
    "11.1-7": item(
      "Kwa nini Shop iko tupu?",
      j([
        "Ikiwa Shop iko tupu, ina maana kwamba kwa sasa hakuna vitu",
        "vinavyopatikana kwa skrini yako au vitu vinavyohitajika bado",
        "havijaonyeshwa dukani.",
      ]),
      ["shop tupu", "hakuna vitu"],
    ),
    "12.1-1": item(
      "Natafutaje kwa maneno ndani ya FAQ?",
      j([
        "Fungua FAQ na uandike neno linaloeleweka kutoka kwenye",
        "kiolesura, kwa mfano balance, Wallet, panel, Exchange au",
        "Withdraw.",
      ]),
      ["utafutaji", "faq", "pata"],
    ),
    "12.1-2": item(
      "Nitafute wapi swali kuhusu salio?",
      j([
        "Tazama sehemu za Balances na Balance History. Sehemu hizi",
        "zinaeleza unachoona kwenye kiolesura na kwa nini fedha zako",
        "zinabadilika.",
      ]),
      ["salio wapi", "history"],
    ),
    "12.1-3": item(
      "Nitafute wapi swali kuhusu Wallet?",
      j([
        "Fungua sehemu ya Wallet. Humo kuna maswali kuhusu",
        "muunganisho, Wallet kuu na matatizo ya kuunganisha.",
      ]),
      ["wallet wapi", "wallet"],
    ),
    "12.1-4": item(
      "Nifanye nini ikiwa sijapata jibu?",
      j([
        "Jaribu neno jingine la wazi kutoka kwenye kiolesura cha bot",
        "au fungua sehemu iliyo karibu kwa maana. Ikiwa swali ni la",
        "Wallet, History, Panels au Exchange, tafuta kwa maneno",
        "hayo.",
      ]),
      ["sijapata jibu", "utafutaji mwingine"],
    ),
  },
};

Object.assign((faqItemOverridesByLang.en ??= {}), {
  "3.2-5": item(
    "What does the rule 1 kWh = 1 EFHC mean?",
    j([
      "This rule means that inside project exchange one unit of",
      "available energy corresponds to one EFHC.",
    ]),
    ["1 kwh 1 efhc", "energy exchange"],
  ),
  "3.2-6": item(
    "How much energy does one panel give in 180 days?",
    j([
      "One standard panel gives 1000 kWh of energy over its full",
      "180-day cycle.",
    ]),
    ["1000 kwh", "180 days"],
  ),
  "3.2-7": item(
    "How much energy does a VIP panel give in 180 days?",
    j([
      "A panel with an active VIP effect gives 1200 kWh over the",
      "full 180-day cycle.",
    ]),
    ["1200 kwh", "vip panel"],
  ),
  "4.2-5": item(
    "What is the minimum withdrawal?",
    j([
      "The minimum withdrawal in the project is 10 EFHC from the",
      "main balance.",
    ]),
    ["minimum withdrawal", "10 EFHC"],
  ),
  "6.3-1": item(
    "What is Activ status?",
    j([
      "Activ status shows that you have already entered the active",
      "project cycle and received the basic active participant",
      "status in EFHC.",
    ]),
    ["activ", "active status"],
  ),
  "6.3-2": item(
    "How do I get Activ status?",
    j([
      "Activ status is granted after buying your first panel. From",
      "that moment you are considered an active project",
      "participant.",
    ]),
    ["get activ", "first panel"],
  ),
  "6.3-3": item(
    "Is Activ status temporary or permanent?",
    j([
      "Activ status is permanent. It is not removed simply because",
      "the active panel cycle has ended.",
    ]),
    ["activ permanent", "temporary"],
  ),
  "6.3-4": item(
    "Does Activ status remain if the panel goes to Archive?",
    j([
      "Yes. Once you get Activ status, it stays even if the panel",
      "later moves to Archive.",
    ]),
    ["archive", "activ status"],
  ),
  "6.3-5": item(
    "Why is Activ status important?",
    j([
      "Activ status is important because active users are counted",
      "in several key project mechanics, including referral",
      "logic.",
    ]),
    ["why activ matters", "referrals"],
  ),
  "12.3-1": item(
    "What is EFHC?",
    j([
      "EFHC is Energy for Humanity Coin, a project with game and",
      "energy progress where users move from panels and energy to",
      "growth inside the whole ecosystem.",
    ]),
    ["what is efhc", "energy for humanity coin"],
  ),
  "12.3-2": item(
    "What is the main idea of the EFHC project?",
    j([
      "The main idea is to connect game progress, energy",
      "generation and user growth inside the EFHC Bot ecosystem.",
    ]),
    ["efhc idea", "project meaning"],
  ),
  "12.3-3": item(
    "What is energy progress?",
    j([
      "Energy progress shows how you move through the project via",
      "panels, kWh generation, exchange and growth through levels.",
    ]),
    ["energy progress", "kwh"],
  ),
  "12.3-4": item(
    "What are tasks?",
    j([
      "Tasks are actions inside the project for which the user can",
      "receive a reward according to the Tasks page rules.",
    ]),
    ["tasks", "assignments"],
  ),
  "12.3-5": item(
    "Why do I need the Tasks page?",
    j([
      "The Tasks page shows available tasks, their status and the",
      "rewards you can collect for completed actions.",
    ]),
    ["tasks page", "available tasks"],
  ),
  "12.3-6": item(
    "How do I get a reward for a task?",
    j([
      "Usually you need to complete the task condition and then",
      "claim the reward where the Tasks screen shows it.",
    ]),
    ["task reward", "claim reward"],
  ),
  "12.3-7": item(
    "Why was my task not counted?",
    j([
      "Check whether the required condition was completed and",
      "whether the result appeared on the Tasks page after",
      "refreshing.",
    ]),
    ["task not counted", "tasks"],
  ),
  "12.3-8": item(
    "Where can I see available tasks?",
    j([
      "Available tasks are shown on the Tasks page. You can also",
      "see there which tasks are already completed or available",
      "right now.",
    ]),
    ["where tasks", "available tasks"],
  ),
  "12.3-9": item(
    "Can a task be completed again?",
    j([
      "It depends on the task itself. Some tasks are one-time, and",
      "some may be available again if the Tasks interface says so.",
    ]),
    ["repeat task", "tasks"],
  ),
});

Object.assign((faqItemOverridesByLang.ua ??= {}), {
  "3.2-5": item(
    "Що означає правило 1 kWh = 1 EFHC?",
    j([
      "Це правило означає, що під час внутрішнього обміну одна",
      "одиниця доступної енергії відповідає одному EFHC.",
    ]),
    ["1 kwh 1 efhc", "обмін енергії"],
  ),
  "3.2-6": item(
    "Скільки енергії дає одна панель за 180 днів?",
    j([
      "Одна звичайна панель за повний цикл 180 днів дає 1000 kWh",
      "енергії.",
    ]),
    ["1000 kwh", "180 днів"],
  ),
  "3.2-7": item(
    "Скільки енергії дає панель з VIP за 180 днів?",
    j([
      "Панель з активним VIP-ефектом за повний цикл 180 днів дає",
      "1200 kWh енергії.",
    ]),
    ["1200 kwh", "vip панель"],
  ),
  "4.2-5": item(
    "Який мінімальний вивід?",
    j([
      "Мінімальний вивід у проєкті — 10 EFHC з основного балансу.",
    ]),
    ["мінімальний вивід", "10 EFHC"],
  ),
  "6.3-1": item(
    "Що таке Activ-статус?",
    j([
      "Activ-статус показує, що ви вже увійшли в активний цикл",
      "проєкту та отримали базовий активний статус учасника EFHC.",
    ]),
    ["activ", "активний статус"],
  ),
  "6.3-2": item(
    "Як отримати Activ-статус?",
    j([
      "Activ-статус надається після купівлі першої панелі. З цього",
      "моменту ви вважаєтесь активним учасником проєкту.",
    ]),
    ["отримати activ", "перша панель"],
  ),
  "6.3-3": item(
    "Activ-статус тимчасовий чи постійний?",
    j([
      "Activ-статус постійний. Він не зникає лише через те, що",
      "активний цикл панелі завершився.",
    ]),
    ["activ постійний", "тимчасовий"],
  ),
  "6.3-4": item(
    "Чи зберігається Activ-статус, якщо панель у Archive?",
    j([
      "Так. Після отримання Activ-статусу він зберігається навіть",
      "тоді, коли панель пізніше переходить в Archive.",
    ]),
    ["archive", "activ статус"],
  ),
  "6.3-5": item(
    "Чому Activ-статус важливий?",
    j([
      "Activ-статус важливий, бо саме активні користувачі",
      "враховуються в низці ключових механік проєкту, зокрема в",
      "реферальній логіці.",
    ]),
    ["чому activ важливий", "реферали"],
  ),
  "12.3-1": item(
    "Що таке EFHC?",
    j([
      "EFHC — це Energy for Humanity Coin, проєкт з ігровим та",
      "енергетичним прогресом, де користувач рухається від панелей",
      "та енергії до зростання всередині всієї екосистеми.",
    ]),
    ["що таке efhc", "energy for humanity coin"],
  ),
  "12.3-2": item(
    "У чому головний зміст проєкту EFHC?",
    j([
      "Головний зміст проєкту — поєднати ігровий прогрес,",
      "генерацію енергії та зростання користувача всередині",
      "екосистеми EFHC Bot.",
    ]),
    ["зміст efhc", "ідея проєкту"],
  ),
  "12.3-3": item(
    "Що таке енергетичний прогрес?",
    j([
      "Енергетичний прогрес показує, як ви рухаєтесь у проєкті",
      "через панелі, генерацію kWh, обмін і зростання за рівнями.",
    ]),
    ["енергетичний прогрес", "kwh"],
  ),
  "12.3-4": item(
    "Що таке завдання?",
    j([
      "Завдання — це дії всередині проєкту, за які користувач може",
      "отримати винагороду за правилами сторінки Tasks.",
    ]),
    ["завдання", "tasks"],
  ),
  "12.3-5": item(
    "Навіщо потрібна сторінка Tasks?",
    j([
      "Сторінка Tasks потрібна, щоб бачити доступні завдання,",
      "стежити за їхнім статусом і забирати винагороди.",
    ]),
    ["сторінка tasks", "доступні завдання"],
  ),
})



Object.assign((faqItemOverridesByLang.en ??= {}), {
  "3.1-6": item(
    "How much does one panel cost?",
    j([
      "One panel in EFHC Bot costs 100 EFHC.",
    ]),
    ["panel price", "100 EFHC"],
  ),
  "3.1-7": item(
    "What does buying the first panel give me right away?",
    j([
      "Buying the first panel launches your active project cycle",
      "and starts your path in energy generation.",
    ]),
    ["first panel", "activ status"],
  ),
  "3.1-8": item(
    "When does a panel start generating?",
    j([
      "Generation starts after the panel becomes active in the",
      "project cycle.",
    ]),
    ["panel generation start", "active panel"],
  ),
  "3.1-9": item(
    "How long does one panel work?",
    j([
      "One panel works for a full 180-day cycle.",
    ]),
    ["panel lifetime", "180 days"],
  ),
  "3.1-10": item(
    "Is there a limit on active panels?",
    j([
      "Yes. The project sets a limit of up to 1000 active panels",
      "for one user at the same time.",
    ]),
    ["active panels limit", "1000 panels"],
  ),
  "5.1-6": item(
    "Why do I need a primary wallet?",
    j([
      "A primary wallet is the main wallet the bot uses for key",
      "wallet actions and checks.",
    ]),
    ["primary wallet", "main wallet"],
  ),
  "5.1-7": item(
    "Can I change the primary wallet?",
    j([
      "Yes. If the interface allows it, you can select another",
      "linked wallet as the primary one.",
    ]),
    ["change primary wallet", "wallet"],
  ),
  "5.1-8": item(
    "Can I remove a linked wallet?",
    j([
      "If the wallet management interface allows it, a linked",
      "wallet can be removed from your list.",
    ]),
    ["remove wallet", "unlink wallet"],
  ),
  "5.1-9": item(
    "What happens if I press a button that needs a wallet?",
    j([
      "The bot asks you to connect or choose a wallet before the",
      "action can continue.",
    ]),
    ["wallet required", "connect wallet"],
  ),
  "6.2-1": item(
    "When are referral bonuses credited?",
    j([
      "Referral bonuses are credited when the required referral",
      "condition is met inside the project.",
    ]),
    ["referral bonus", "when credited"],
  ),
  "6.2-2": item(
    "What should I do if a referral bonus did not arrive?",
    j([
      "Check whether the referral became active and whether the",
      "required action was completed according to the rules.",
    ]),
    ["bonus not arrived", "referral"],
  ),
  "6.2-3": item(
    "Why are bonuses given only for active referrals?",
    j([
      "Because the project counts only active referrals for bonus",
      "mechanics and referral progress.",
    ]),
    ["active referrals", "bonus"],
  ),
  "6.2-4": item(
    "What is the basic bonus for one active referral?",
    j([
      "The basic project bonus is 0.5 EFHC for one active",
      "referral.",
    ]),
    ["0.5 EFHC", "active referral bonus"],
  ),
  "6.2-5": item(
    "What are referral progress levels?",
    j([
      "These are referral milestones based on the number of active",
      "referrals. Reaching them gives one-time bonuses.",
    ]),
    ["referral levels", "progress levels"],
  ),
  "6.2-6": item(
    "What does referral progress level 0 mean?",
    j([
      "Level 0 is the starting point. You have not yet reached the",
      "first referral milestone.",
    ]),
    ["referral level 0", "start"],
  ),
  "6.2-7": item(
    "What does referral progress level 1 mean?",
    j([
      "Level 1 means you reached 10 active referrals and receive a",
      "one-time bonus of 1 EFHC.",
    ]),
    ["referral level 1", "10 referrals"],
  ),
  "6.2-8": item(
    "What does referral progress level 2 mean?",
    j([
      "Level 2 means you reached 100 active referrals and receive",
      "a one-time bonus of 10 EFHC.",
    ]),
    ["referral level 2", "100 referrals"],
  ),
  "6.2-9": item(
    "What does referral progress level 3 mean?",
    j([
      "Level 3 means you reached 1000 active referrals and receive",
      "a one-time bonus of 100 EFHC.",
    ]),
    ["referral level 3", "1000 referrals"],
  ),
  "6.2-10": item(
    "What does referral progress level 4 mean?",
    j([
      "Level 4 means you reached 3000 active referrals and receive",
      "a one-time bonus of 300 EFHC.",
    ]),
    ["referral level 4", "3000 referrals"],
  ),
  "6.2-11": item(
    "What does referral progress level 5 mean?",
    j([
      "Level 5 means you reached 10000 active referrals and",
      "receive a one-time bonus of 1000 EFHC.",
    ]),
    ["referral level 5", "10000 referrals"],
  ),
});

Object.assign((faqItemOverridesByLang.ua ??= {}), {
  "3.1-6": item(
    "Скільки коштує одна панель?",
    j([
      "Одна панель у EFHC Bot коштує 100 EFHC.",
    ]),
    ["ціна панелі", "100 EFHC"],
  ),
  "3.1-7": item(
    "Що дає покупка першої панелі одразу?",
    j([
      "Покупка першої панелі запускає ваш активний цикл у",
      "проєкті та відкриває шлях до генерації енергії.",
    ]),
    ["перша панель", "activ статус"],
  ),
  "3.1-8": item(
    "Коли панель починає генерувати?",
    j([
      "Генерація починається після того, як панель стає активною",
      "у циклі проєкту.",
    ]),
    ["початок генерації", "активна панель"],
  ),
  "3.1-9": item(
    "Скільки працює одна панель?",
    j([
      "Одна панель працює повний цикл 180 днів.",
    ]),
    ["строк панелі", "180 днів"],
  ),
  "3.1-10": item(
    "Чи є ліміт на активні панелі?",
    j([
      "Так. У проєкті діє ліміт до 1000 активних панелей для",
      "одного користувача одночасно.",
    ]),
    ["ліміт панелей", "1000 панелей"],
  ),
  "5.1-6": item(
    "Навіщо потрібен основний гаманець?",
    j([
      "Основний гаманець — це головний Wallet, який бот",
      "використовує для ключових wallet-дій і перевірок.",
    ]),
    ["основний гаманець", "main wallet"],
  ),
  "5.1-7": item(
    "Чи можна змінити основний гаманець?",
    j([
      "Так. Якщо інтерфейс це дозволяє, ви можете вибрати інший",
      "прив'язаний Wallet як основний.",
    ]),
    ["змінити основний wallet", "wallet"],
  ),
  "5.1-8": item(
    "Чи можна видалити прив'язаний гаманець?",
    j([
      "Якщо інтерфейс керування Wallet це дозволяє, прив'язаний",
      "гаманець можна прибрати зі списку.",
    ]),
    ["видалити wallet", "відв'язати wallet"],
  ),
  "5.1-9": item(
    "Що буде, якщо натиснути кнопку, де потрібен гаманець?",
    j([
      "Бот попросить підключити або вибрати Wallet перед тим, як",
      "дія зможе продовжитися.",
    ]),
    ["потрібен wallet", "підключити wallet"],
  ),
  "6.2-1": item(
    "Коли нараховуються реферальні бонуси?",
    j([
      "Реферальні бонуси нараховуються, коли всередині проєкту",
      "виконана потрібна умова по рефералу.",
    ]),
    ["реферальний бонус", "коли нараховується"],
  ),
  "6.2-2": item(
    "Що робити, якщо реферальний бонус не прийшов?",
    j([
      "Перевірте, чи став реферал активним і чи була виконана",
      "потрібна дія за правилами проєкту.",
    ]),
    ["бонус не прийшов", "реферал"],
  ),
  "6.2-3": item(
    "Чому бонуси йдуть тільки за активних рефералів?",
    j([
      "Тому що для бонусної механіки та прогресу проєкт рахує",
      "лише активних рефералів.",
    ]),
    ["активні реферали", "бонус"],
  ),
  "6.2-4": item(
    "Який базовий бонус дається за активного реферала?",
    j([
      "Базовий бонус проєкту — 0.5 EFHC за одного активного",
      "реферала.",
    ]),
    ["0.5 EFHC", "бонус за реферала"],
  ),
  "6.2-5": item(
    "Що таке рівні прогресу реферальної системи?",
    j([
      "Це реферальні рубежі за кількістю активних рефералів. За",
      "їх досягнення даються разові бонуси.",
    ]),
    ["рівні рефералів", "прогрес"],
  ),
  "6.2-6": item(
    "Що означає 0 рівень реферального прогресу?",
    j([
      "0 рівень — це стартова точка. Ви ще не досягли першого",
      "реферального рубежу.",
    ]),
    ["0 рівень рефералів", "старт"],
  ),
  "6.2-7": item(
    "Що означає 1 рівень реферального прогресу?",
    j([
      "1 рівень означає, що ви досягли 10 активних рефералів і",
      "отримуєте разовий бонус 1 EFHC.",
    ]),
    ["1 рівень рефералів", "10 рефералів"],
  ),
  "6.2-8": item(
    "Що означає 2 рівень реферального прогресу?",
    j([
      "2 рівень означає, що ви досягли 100 активних рефералів і",
      "отримуєте разовий бонус 10 EFHC.",
    ]),
    ["2 рівень рефералів", "100 рефералів"],
  ),
  "6.2-9": item(
    "Що означає 3 рівень реферального прогресу?",
    j([
      "3 рівень означає, що ви досягли 1000 активних рефералів і",
      "отримуєте разовий бонус 100 EFHC.",
    ]),
    ["3 рівень рефералів", "1000 рефералів"],
  ),
  "6.2-10": item(
    "Що означає 4 рівень реферального прогресу?",
    j([
      "4 рівень означає, що ви досягли 3000 активних рефералів і",
      "отримуєте разовий бонус 300 EFHC.",
    ]),
    ["4 рівень рефералів", "3000 рефералів"],
  ),
  "6.2-11": item(
    "Що означає 5 рівень реферального прогресу?",
    j([
      "5 рівень означає, що ви досягли 10000 активних рефералів",
      "і отримуєте разовий бонус 1000 EFHC.",
    ]),
    ["5 рівень рефералів", "10000 рефералів"],
  ),
})


Object.assign((faqItemOverridesByLang.en ??= {}), {
  "1.3-1": item(
    "What is the top bar?",
    j([
      "The top bar is the main quick info block visible on the",
      "main pages of the bot.",
    ]),
    ["top bar", "header"],
  ),
  "1.3-2": item(
    "What is shown in the top bar?",
    j([
      "The top bar can show your name, avatar, progress level,",
      "VIP status, total balance and quick buttons like Top Up",
      "and Shop.",
    ]),
    ["top bar", "what is shown"],
  ),
  "1.3-3": item(
    "Why is the total balance in the top bar not equal to the",
    "withdrawable amount?",
    ["total balance", "withdrawable amount"],
  ),
  "1.3-4": item(
    "What does the Top Up button do?",
    j([
      "The Top Up button opens the path for adding funds or going",
      "to actions connected with replenishment.",
    ]),
    ["top up", "button"],
  ),
  "1.3-5": item(
    "What does the Shop button do?",
    j([
      "The Shop button takes you to the store section where you",
      "can view available items, skins and offers inside the",
      "project.",
    ]),
    ["shop button", "shop"],
  ),
  "3.3-1": item(
    "Why do I need the Energy page?",
    j([
      "The Energy page helps you quickly understand your current",
      "energy state and enter the daily game cycle.",
    ]),
    ["energy page", "why needed"],
  ),
  "3.3-2": item(
    "What does the Energy page show?",
    j([
      "The Energy page shows key indicators such as progress,",
      "generation, active panels and other data that help you see",
      "your current state quickly.",
    ]),
    ["energy page", "what it shows"],
  ),
  "3.3-3": item(
    "What does the progress bar on the Energy page show?",
    j([
      "It shows your movement in energy progress and helps you",
      "understand how far you are from the next step or level.",
    ]),
    ["progress bar", "energy page"],
  ),
  "3.3-4": item(
    "What does total panel generation per second mean?",
    j([
      "This is the combined current generation of your active",
      "panels. It shows how quickly energy is growing right now.",
    ]),
    ["generation per second", "panels"],
  ),
  "3.3-5": item(
    "Why is the Energy page important?",
    j([
      "It is important because it gathers your progress, energy,",
      "generation and movement through the project in one place.",
    ]),
    ["why energy page matters", "energy"],
  ),
  "8.3-1": item(
    "What are Lotteries in EFHC?",
    j([
      "Lotteries are in-project game events where users buy",
      "tickets and take part in winner selection.",
    ]),
    ["lotteries", "draws"],
  ),
  "8.3-2": item(
    "Which Lotteries exist in the project?",
    j([
      "The project currently has the 100 EFHC Lotteries and the NFT",
      "VIP EFHC Lotteries. They differ by prize type and ticket",
      "count in the draw.",
    ]),
    ["which lotteries", "100 EFHC", "NFT VIP"],
  ),
  "8.3-3": item(
    "What is the difference between the 100 EFHC Lotteries and the",
    "NFT VIP EFHC Lotteries?",
    ["difference lotteries", "100 EFHC", "NFT VIP"],
  ),
  "8.3-4": item(
    "How much does one ticket cost?",
    j([
      "One ticket costs 1 EFHC according to the current project",
      "rules.",
    ]),
    ["ticket price", "1 EFHC"],
  ),
  "8.3-5": item(
    "How many tickets can there be in Lotteries?",
    j([
      "The ticket count depends on the Lotteries type. The standard",
      "EFHC Lotteries have 200 tickets, and the NFT VIP EFHC Lotteries",
      "has 3000 tickets.",
    ]),
    ["ticket count", "200", "3000"],
  ),
  "8.3-6": item(
    "When do Lotteries start?",
    j([
      "Lotteries start as part of the project cycle, and the draw",
      "is triggered when the required ticket limit is reached.",
    ]),
    ["lotteries start", "draw start"],
  ),
  "8.3-7": item(
    "How is the winner determined?",
    j([
      "The winner is determined automatically inside the project",
      "mechanics after the draw reaches the required ticket",
      "amount.",
    ]),
    ["winner", "draw"],
  ),
  "8.3-8": item(
    "What happens after the winner is chosen?",
    j([
      "After the winner is chosen, the prize is assigned according",
      "to the Lotteries type and a new draw cycle can start.",
    ]),
    ["after winner", "prize"],
  ),
  "8.3-9": item(
    "What is the prize in the 100 EFHC Lotteries?",
    j([
      "The prize in these Lotteries is 100 EFHC bonus balance.",
    ]),
    ["100 EFHC prize", "lotteries prize"],
  ),
  "8.3-10": item(
    "What is the prize in the NFT VIP EFHC Lotteries?",
    j([
      "The prize in these Lotteries is one VIP NFT EFHC.",
    ]),
    ["NFT VIP prize", "lotteries prize"],
  ),
  "8.3-11": item(
    "Why is a wallet needed in the NFT Lotteries?",
    j([
      "A wallet is needed because the NFT prize must be linked to",
      "a wallet for correct receipt and display.",
    ]),
    ["wallet needed", "NFT lotteries"],
  ),
  "8.3-12": item(
    "How is the NFT issued after winning?",
    j([
      "After winning, the NFT is assigned to the winner according",
      "to the project's wallet and NFT logic.",
    ]),
    ["NFT issued", "after winning"],
  ),
  "8.3-13": item(
    "Where is the prize shown?",
    j([
      "The result is shown in the relevant project interface and,",
      "for NFT prizes, also through the connected wallet flow.",
    ]),
    ["where prize shown", "result"],
  ),
  "8.3-14": item(
    "Why can't I see the Lotteries result?",
    j([
      "Check whether the draw has finished, whether the result has",
      "already refreshed in the interface and whether a wallet is",
      "required for the prize type.",
    ]),
    ["lotteries result", "not visible"],
  ),
  "8.4-1": item(
    "What is the Ads section?",
    j([
      "The Ads section shows offers or actions that may be useful",
      "to the user inside project scenarios.",
    ]),
    ["ads", "ads section"],
  ),
  "8.4-2": item(
    "What does this section give the user?",
    j([
      "It can give access to offers, actions or transitions linked",
      "to the project interface and its extra opportunities.",
    ]),
    ["ads benefit", "offers"],
  ),
  "8.4-3": item(
    "Why might an offer not be shown?",
    j([
      "An offer may depend on the current scenario, availability or",
      "the state of the interface at this moment.",
    ]),
    ["offer not shown", "ads"],
  ),
  "8.4-4": item(
    "What should I do if I completed an action but no result",
    "appeared?",
    ["action completed", "no result"],
  ),
  "10.2-1": item(
    "What does the Eco Initiate level mean?",
    j([
      "This is the first step in the project: 0 kWh. It means you",
      "have just started your clean energy path and are entering",
      "the EFHC world.",
    ]),
    ["eco initiate", "0 kwh"],
  ),
  "10.2-2": item(
    "What does the Hope Bringer level mean?",
    j([
      "This level starts at 100 kWh. It means your contribution is",
      "already visible and you bring a first sign of positive",
      "change.",
    ]),
    ["hope bringer", "100 kwh"],
  ),
  "10.2-3": item(
    "What does the Energy Seeker level mean?",
    j([
      "This level starts at 300 kWh. It means you are actively",
      "moving forward, collecting energy and strengthening your",
      "role in the project.",
    ]),
    ["energy seeker", "300 kwh"],
  ),
  "10.2-4": item(
    "What does the Nature's Voice level mean?",
    j([
      "This level starts at 600 kWh. It means your progress already",
      "sounds stronger and you become a visible voice of the green",
      "direction.",
    ]),
    ["nature's voice", "600 kwh"],
  ),
  "10.2-5": item(
    "What does the Earth Ally level mean?",
    j([
      "This level starts at 1000 kWh. It means you have already",
      "become a stable ally of the planet through your energy",
      "progress.",
    ]),
    ["earth ally", "1000 kwh"],
  ),
  "10.2-6": item(
    "What does the Climate Fighter level mean?",
    j([
      "This level starts at 2000 kWh. It means your progress now",
      "looks like a real fight for climate improvement.",
    ]),
    ["climate fighter", "2000 kwh"],
  ),
  "10.2-7": item(
    "What does the Green Sentinel level mean?",
    j([
      "This level starts at 3500 kWh. It means you are already a",
      "green guardian who steadily protects the project's clean",
      "energy line.",
    ]),
    ["green sentinel", "3500 kwh"],
  ),
  "10.2-8": item(
    "What does the Planet Defender level mean?",
    j([
      "This level starts at 5000 kWh. It means your role has grown",
      "into the defense of the planet through visible energy",
      "results.",
    ]),
    ["planet defender", "5000 kwh"],
  ),
  "10.2-9": item(
    "What does the Eco Champion level mean?",
    j([
      "This level starts at 7500 kWh. It means you are already one",
      "of the strongest participants in the green progress line.",
    ]),
    ["eco champion", "7500 kwh"],
  ),
  "10.2-10": item(
    "What does the Planet Saver level mean?",
    j([
      "This level starts at 10000 kWh. It means your contribution",
      "has become large enough to look like real planetary help.",
    ]),
    ["planet saver", "10000 kwh"],
  ),
  "10.2-11": item(
    "What does the Green Commander level mean?",
    j([
      "This level starts at 15000 kWh. It means you are already",
      "leading a major stage of clean energy progress inside the",
      "project.",
    ]),
    ["green commander", "15000 kwh"],
  ),
  "10.2-12": item(
    "What does the Guardian of Earth level mean?",
    j([
      "This is the highest level at 20000+ kWh. It means you have",
      "reached the top of the energy path and become a symbol of",
      "the project's maximum green progress.",
    ]),
    ["guardian of earth", "20000 kwh"],
  ),
  "12.2-1": item(
    "What is the Profile/Settings section?",
    j([
      "This section shows your main statuses and contains personal",
      "interface settings of the bot.",
    ]),
    ["profile", "settings"],
  ),
  "12.2-2": item(
    "What is shown in the upper part of Profile/Settings?",
    j([
      "The upper part usually shows your avatar, Telegram name and",
      "important statuses like Activ and VIP if you already have",
      "them.",
    ]),
    ["profile header", "statuses"],
  ),
  "12.2-3": item(
    "What can I configure in Profile/Settings?",
    j([
      "Here you can open wallet-related sections, balance history,",
      "FAQ and other interface options available to the user.",
    ]),
    ["configure profile", "settings"],
  ),
  "12.2-4": item(
    "What is inside Support and Information?",
    j([
      "This area usually contains support-related entries, help",
      "sections and useful information about the bot interface.",
    ]),
    ["support", "information"],
  ),
});

Object.assign((faqItemOverridesByLang.ua ??= {}), {
  "1.3-1": item(
    "Що таке верхня панель?",
    j([
      "Верхня панель — це головний швидкий інформаційний блок,",
      "який видно на основних сторінках бота.",
    ]),
    ["верхня панель", "top bar"],
  ),
  "1.3-2": item(
    "Що відображається у верхній панелі?",
    j([
      "У верхній панелі можуть відображатися ваше ім'я, аватар,",
      "рівень прогресу, VIP-статус, загальний баланс, а також",
      "швидкі кнопки на кшталт Поповнити і Shop.",
    ]),
    ["верхня панель", "що видно"],
  ),
  "1.3-3": item(
    "Чому загальний баланс у верхній панелі не дорівнює сумі",
    "для виводу?",
    ["загальний баланс", "сума для виводу"],
  ),
  "1.3-4": item(
    "Що робить кнопка «Поповнити»?",
    j([
      "Кнопка «Поповнити» відкриває шлях до додавання коштів або",
      "дій, пов'язаних із поповненням.",
    ]),
    ["поповнити", "кнопка"],
  ),
  "1.3-5": item(
    "Що робить кнопка Shop?",
    j([
      "Кнопка Shop переводить у розділ магазину, де можна",
      "переглянути доступні товари, скіни й пропозиції всередині",
      "проєкту.",
    ]),
    ["shop", "кнопка shop"],
  ),
  "3.3-1": item(
    "Навіщо потрібна сторінка Energy?",
    j([
      "Сторінка Energy потрібна для швидкого розуміння вашого",
      "енергетичного стану та входу в щоденний ігровий цикл.",
    ]),
    ["energy page", "сторінка energy"],
  ),
  "3.3-2": item(
    "Що показує сторінка Energy?",
    j([
      "На сторінці Energy видно ключові показники: прогрес,",
      "генерацію, активні панелі та інші дані, які допомагають",
      "швидко зрозуміти поточний стан.",
    ]),
    ["що показує energy", "energy"],
  ),
  "3.3-3": item(
    "Що показує progress bar на сторінці Energy?",
    j([
      "Він показує ваш рух в енергетичному прогресі та допомагає",
      "зрозуміти, наскільки ви близько до наступного кроку або",
      "рівня.",
    ]),
    ["progress bar", "energy"],
  ),
  "3.3-4": item(
    "Що означає загальна генерація панелей за секунду?",
    j([
      "Це сумарна поточна генерація ваших активних панелей. Вона",
      "показує, як швидко зараз зростає енергія.",
    ]),
    ["генерація за секунду", "панелі"],
  ),
  "3.3-5": item(
    "Чому сторінка Energy важлива?",
    j([
      "Вона важлива, бо збирає в одному місці ваш прогрес,",
      "енергію, генерацію та рух по проєкту.",
    ]),
    ["чому energy важлива", "energy"],
  ),
  "8.3-1": item(
    "Що таке розіграші в EFHC?",
    j([
      "Розіграші — це ігрові події всередині проєкту, де",
      "користувачі купують квитки та беруть участь у виборі",
      "переможця.",
    ]),
    ["розіграші", "lotteries"],
  ),
  "8.3-2": item(
    "Які розіграші є в проєкті?",
    j([
      "Зараз у проєкті є розіграш 100 EFHC і розіграш NFT VIP",
      "EFHC. Вони відрізняються типом призу та кількістю квитків",
      "у draw.",
    ]),
    ["які розіграші", "100 EFHC", "NFT VIP"],
  ),
  "8.3-3": item(
    "Чим відрізняються розіграш 100 EFHC і NFT VIP EFHC?",
    j([
      "Вони відрізняються типом призу. В одному розіграші видається",
      "100 EFHC, а в іншому — NFT VIP EFHC.",
    ]),
    ["відмінність розіграшів", "100 EFHC", "NFT VIP"],
  ),
  "8.3-4": item(
    "Скільки коштує один квиток?",
    j([
      "Один квиток коштує 1 EFHC за поточними правилами проєкту.",
    ]),
    ["ціна квитка", "1 EFHC"],
  ),
  "8.3-5": item(
    "Скільки квитків може бути в розіграші?",
    j([
      "Кількість квитків залежить від типу розіграшу. Стандартний",
      "розіграш EFHC має 200 квитків, а NFT VIP EFHC — 3000.",
    ]),
    ["кількість квитків", "200", "3000"],
  ),
  "8.3-6": item(
    "Коли запускається розіграш?",
    j([
      "Розіграш запускається в межах циклу проєкту, а draw",
      "спрацьовує, коли набрано потрібний ліміт квитків.",
    ]),
    ["старт розіграшу", "draw"],
  ),
  "8.3-7": item(
    "Як визначається переможець?",
    j([
      "Переможець визначається автоматично всередині механіки",
      "проєкту після того, як draw набирає потрібну кількість",
      "квитків.",
    ]),
    ["переможець", "draw"],
  ),
  "8.3-8": item(
    "Що відбувається після вибору переможця?",
    j([
      "Після вибору переможця приз нараховується за типом",
      "розіграшу, а далі може стартувати новий цикл draw.",
    ]),
    ["після перемоги", "приз"],
  ),
  "8.3-9": item(
    "Який приз у розіграші 100 EFHC?",
    j([
      "Приз у цьому розіграші — 100 EFHC бонусного балансу.",
    ]),
    ["приз 100 EFHC", "розіграш"],
  ),
  "8.3-10": item(
    "Який приз у розіграші NFT VIP EFHC?",
    j([
      "Приз у цьому розіграші — один VIP NFT EFHC.",
    ]),
    ["приз NFT VIP", "розіграш"],
  ),
  "8.3-11": item(
    "Навіщо в NFT-розіграші потрібен гаманець?",
    j([
      "Гаманець потрібен, бо NFT-приз має бути пов'язаний із",
      "гаманцем для коректного отримання та відображення.",
    ]),
    ["гаманець потрібен", "NFT розіграш"],
  ),
  "8.3-12": item(
    "Як видається NFT після перемоги?",
    j([
      "Після перемоги NFT закріплюється за переможцем відповідно",
      "до логіки гаманця та NFT у проєкті.",
    ]),
    ["видача NFT", "після перемоги"],
  ),
  "8.3-13": item(
    "Де відображається виграш?",
    j([
      "Результат відображається у відповідному інтерфейсі проєкту,",
      "а для NFT-призів — також через пов'язаний сценарій",
      "гаманця.",
    ]),
    ["де виграш", "результат"],
  ),
  "8.3-14": item(
    "Чому я не бачу результат розіграшу?",
    j([
      "Перевірте, чи завершився draw, чи вже оновився результат",
      "в інтерфейсі та чи не потрібен гаманець для цього типу",
      "призу.",
    ]),
    ["результат розіграшу", "не видно"],
  ),
  "8.4-1": item(
    "Що таке розділ Ads?",
    j([
      "Розділ Ads показує пропозиції або дії, які можуть бути",
      "корисні користувачу всередині сценаріїв проєкту.",
    ]),
    ["ads", "розділ ads"],
  ),
  "8.4-2": item(
    "Що дає цей розділ користувачу?",
    j([
      "Цей розділ може давати доступ до пропозицій, дій або",
      "переходів, пов'язаних з інтерфейсом проєкту та його",
      "додатковими можливостями.",
    ]),
    ["що дає ads", "пропозиції"],
  ),
  "8.4-3": item(
    "Чому пропозиція може не відображатися?",
    j([
      "Пропозиція може залежати від поточного сценарію,",
      "доступності або стану інтерфейсу саме зараз.",
    ]),
    ["пропозиція не видно", "ads"],
  ),
  "8.4-4": item(
    "Що робити, якщо дію виконано, а результат не з'явився?",
    j([
      "Перевірте, чи сценарій уже оновився в інтерфейсі, і",
      "поверніться до цього розділу трохи пізніше.",
    ]),
    ["дію виконано", "результат не з'явився"],
  ),
  "10.2-1": item(
    "Що означає рівень Eco Initiate?",
    j([
      "Це перший крок у проєкті: 0 kWh. Він означає, що ви щойно",
      "почали свій шлях чистої енергії та входите у світ EFHC.",
    ]),
    ["eco initiate", "0 kwh"],
  ),
  "10.2-2": item(
    "Що означає рівень Hope Bringer?",
    j([
      "Цей рівень починається зі 100 kWh. Він означає, що ваш",
      "внесок уже помітний і ви приносите перший знак позитивних",
      "змін.",
    ]),
    ["hope bringer", "100 kwh"],
  ),
  "10.2-3": item(
    "Що означає рівень Energy Seeker?",
    j([
      "Цей рівень починається з 300 kWh. Він означає, що ви",
      "активно рухаєтесь уперед, накопичуєте енергію та",
      "посилюєте свою роль у проєкті.",
    ]),
    ["energy seeker", "300 kwh"],
  ),
  "10.2-4": item(
    "Що означає рівень Nature's Voice?",
    j([
      "Цей рівень починається з 600 kWh. Він означає, що ваш",
      "прогрес уже звучить сильніше і ви стаєте помітним голосом",
      "зеленого напряму.",
    ]),
    ["nature's voice", "600 kwh"],
  ),
  "10.2-5": item(
    "Що означає рівень Earth Ally?",
    j([
      "Цей рівень починається з 1000 kWh. Він означає, що ви вже",
      "стали стабільним союзником планети через свій енергетичний",
      "прогрес.",
    ]),
    ["earth ally", "1000 kwh"],
  ),
  "10.2-6": item(
    "Що означає рівень Climate Fighter?",
    j([
      "Цей рівень починається з 2000 kWh. Він означає, що ваш",
      "прогрес уже виглядає як справжня боротьба за поліпшення",
      "клімату.",
    ]),
    ["climate fighter", "2000 kwh"],
  ),
  "10.2-7": item(
    "Що означає рівень Green Sentinel?",
    j([
      "Цей рівень починається з 3500 kWh. Він означає, що ви вже",
      "зелений вартовий, який стабільно захищає лінію чистої",
      "енергії проєкту.",
    ]),
    ["green sentinel", "3500 kwh"],
  ),
  "10.2-8": item(
    "Що означає рівень Planet Defender?",
    j([
      "Цей рівень починається з 5000 kWh. Він означає, що ваша",
      "роль зросла до захисту планети через помітний результат",
      "в енергії.",
    ]),
    ["planet defender", "5000 kwh"],
  ),
  "10.2-9": item(
    "Що означає рівень Eco Champion?",
    j([
      "Цей рівень починається з 7500 kWh. Він означає, що ви вже",
      "є одним із найсильніших учасників зеленої лінії прогресу.",
    ]),
    ["eco champion", "7500 kwh"],
  ),
  "10.2-10": item(
    "Що означає рівень Planet Saver?",
    j([
      "Цей рівень починається з 10000 kWh. Він означає, що ваш",
      "внесок став настільки великим, що виглядає як реальна",
      "допомога планеті.",
    ]),
    ["planet saver", "10000 kwh"],
  ),
  "10.2-11": item(
    "Що означає рівень Green Commander?",
    j([
      "Цей рівень починається з 15000 kWh. Він означає, що ви вже",
      "ведете великий етап прогресу чистої енергії всередині",
      "проєкту.",
    ]),
    ["green commander", "15000 kwh"],
  ),
  "10.2-12": item(
    "Що означає рівень Guardian of Earth?",
    j([
      "Це найвищий рівень на 20000+ kWh. Він означає, що ви",
      "досягли вершини енергетичного шляху та стали символом",
      "максимального зеленого прогресу проєкту.",
    ]),
    ["guardian of earth", "20000 kwh"],
  ),
  "12.2-1": item(
    "Що таке розділ «Профіль/Налаштування»?",
    j([
      "Це розділ, де видно ваші основні статуси та знаходяться",
      "персональні налаштування інтерфейсу бота.",
    ]),
    ["профіль", "налаштування"],
  ),
  "12.2-2": item(
    "Що відображається у верхній частині Профілю/Налаштувань?",
    j([
      "У верхній частині зазвичай видно ваш аватар, ім'я Telegram",
      "і важливі статуси на кшталт Activ та VIP, якщо вони вже",
      "є.",
    ]),
    ["верх профілю", "статуси"],
  ),
  "12.2-3": item(
    "Що можна налаштовувати в Профілі/Налаштуваннях?",
    j([
      "Тут можна відкривати розділи, пов'язані з гаманцем,",
      "історією балансу, FAQ та іншими опціями інтерфейсу,",
      "доступними користувачу.",
    ]),
    ["налаштування профілю", "опції"],
  ),
  "12.2-4": item(
    "Що знаходиться в розділі «Підтримка та інформація»?",
    j([
      "У цій зоні зазвичай є входи до підтримки, довідкових",
      "розділів і корисної інформації про інтерфейс бота.",
    ]),
    ["підтримка", "інформація"],
  ),
});


Object.assign((faqItemOverridesByLang.de ??= {}), {
  "1.3-1": item(
    "Was ist die obere Leiste?",
    j([
      "Die obere Leiste ist der schnelle Haupt-Infoblock, den",
      "Sie auf den wichtigsten Seiten des Bots sehen.",
    ]),
    ["obere Leiste", "Top-Bar"],
  ),
  "1.3-2": item(
    "Was wird in der oberen Leiste angezeigt?",
    j([
      "In der oberen Leiste können Ihr Name, Avatar,",
      "Fortschritt, VIP-Status, Gesamtguthaben und",
      "Schnellbuttons wie Aufladen und Shop erscheinen.",
    ]),
    ["obere Leiste", "sichtbar"],
  ),
  "1.3-3": item(
    j([
      "Warum ist das Gesamtguthaben oben nicht gleich dem",
      "Auszahlungsbetrag?",
    ]),
    j([
      "Weil die obere Leiste alle Ihre Mittel im Bot zeigt,",
      "für die Auszahlung aber nur das Hauptguthaben",
      "verwendet wird.",
    ]),
    ["Gesamtguthaben", "Auszahlung"],
  ),
  "1.3-4": item(
    "Was macht die Schaltfläche „Aufladen“?",
    j([
      "Die Schaltfläche Aufladen öffnet den Weg zur Aufladung",
      "oder zu Käufen über die Wallet. Wenn dafür eine Wallet",
      "nötig ist, fordert der Bot zuerst die Verbindung an.",
    ]),
    ["Aufladen", "Wallet"],
  ),
  "1.3-5": item(
    "Was macht die Shop-Schaltfläche?",
    j([
      "Die Shop-Schaltfläche öffnet den Projekt-Shop mit",
      "Käufen für EFHC und externen Angeboten über die",
      "Wallet.",
    ]),
    ["Shop", "Shop-Schaltfläche"],
  ),
  "3.1-6": item(
    "Wie viel kostet ein Panel?",
    j([
      "Ein Panel kostet im Projekt immer 100 EFHC. Das ist",
      "der Basiseinstieg in den Panel- und Energiezyklus.",
    ]),
    ["Panelpreis", "100 EFHC"],
  ),
  "3.1-7": item(
    "Was bringt der Kauf des ersten Panels sofort?",
    j([
      "Mit dem ersten Panel treten Sie in den aktiven",
      "Projektzyklus ein, erhalten Activ-Status und starten",
      "Ihren Energiepfad.",
    ]),
    ["erstes Panel", "Activ"],
  ),
  "3.1-8": item(
    "Wann beginnt ein Panel zu erzeugen?",
    j([
      "Die Erzeugung beginnt, sobald das Panel aktiv ist und",
      "im Bot nach den Projektregeln zu arbeiten beginnt.",
    ]),
    ["Beginn Erzeugung", "Panel"],
  ),
  "3.1-9": item(
    "Wie lange lebt ein Panel?",
    j([
      "Ein Panel ist für einen Zyklus von 180 Tagen",
      "ausgelegt. In dieser Zeit erzeugt es Energie nach den",
      "Projektregeln.",
    ]),
    ["180 Tage", "Paneldauer"],
  ),
  "3.1-10": item(
    "Gibt es ein Limit für aktive Panels?",
    j([
      "Ja. Im Projekt gibt es ein Limit von 1000 aktiven",
      "Panels pro Nutzer.",
    ]),
    ["Limit Panels", "1000 Panels"],
  ),
  "3.3-1": item(
    "Wozu dient die Energy-Seite?",
    j([
      "Die Energy-Seite hilft Ihnen, Ihren aktuellen",
      "Energiezustand schnell zu verstehen und in den",
      "täglichen Spielzyklus einzusteigen.",
    ]),
    ["Energy-Seite", "wozu"],
  ),
  "3.3-2": item(
    "Was zeigt die Energy-Seite?",
    j([
      "Die Energy-Seite zeigt Fortschritt, Erzeugung, aktive",
      "Panels und weitere Kennzahlen, die den aktuellen",
      "Zustand schnell erklären.",
    ]),
    ["Energy-Seite", "was zeigt"],
  ),
  "3.3-3": item(
    "Was zeigt der Fortschrittsbalken auf der Energy-Seite?",
    j([
      "Der Fortschrittsbalken zeigt Ihren Weg zur nächsten",
      "Stufe und wie weit Sie im Energiefortschritt gekommen",
      "sind.",
    ]),
    ["Fortschrittsbalken", "Energy"],
  ),
  "3.3-4": item(
    "Was bedeutet die gesamte Panel-Erzeugung pro Sekunde?",
    j([
      "Das ist die Energiemenge, die alle Ihre aktiven Panels",
      "zusammen pro Sekunde erzeugen.",
    ]),
    ["Erzeugung pro Sekunde", "Panels"],
  ),
  "3.3-5": item(
    "Warum ist die Energy-Seite wichtig?",
    j([
      "Sie zeigt auf einen Blick den Kern Ihres Fortschritts:",
      "Energie, Panels, Wachstum und den Weg zur nächsten",
      "Stufe.",
    ]),
    ["Energy wichtig", "Fortschritt"],
  ),
  "5.1-6": item(
    "Wozu dient die primäre Wallet?",
    j([
      "Die primäre Wallet ist die Haupt-Wallet, die der Bot",
      "für wichtige Wallet-bezogene Aktionen und",
      "Verknüpfungen verwendet.",
    ]),
    ["primäre Wallet", "Haupt-Wallet"],
  ),
  "5.1-7": item(
    "Kann ich die primäre Wallet ändern?",
    j([
      "Ja. Wenn die Oberfläche es erlaubt, können Sie eine",
      "andere verbundene Wallet als primäre festlegen.",
    ]),
    ["Wallet ändern", "primäre Wallet"],
  ),
  "5.1-8": item(
    "Kann ich eine verbundene Wallet entfernen?",
    j([
      "Wenn die Oberfläche diese Aktion unterstützt, können",
      "Sie eine verknüpfte Wallet trennen und später erneut",
      "verbinden.",
    ]),
    ["Wallet entfernen", "Wallet trennen"],
  ),
  "5.1-9": item(
    j([
      "Was passiert, wenn ich eine Taste drücke, für die eine",
      "Wallet nötig ist?",
    ]),
    j([
      "Der Bot bittet Sie zuerst, eine Wallet zu verbinden",
      "oder die nötige Wallet-Aktion zu bestätigen.",
    ]),
    ["Wallet nötig", "Taste"],
  ),
  "6.2-1": item(
    "Wann werden Empfehlungsboni gutgeschrieben?",
    j([
      "Empfehlungsboni werden gutgeschrieben, wenn die",
      "Bedingungen des Projekts erfüllt sind und der",
      "geworbene Nutzer als aktiv zählt.",
    ]),
    ["Empfehlungsbonus", "aktiv"],
  ),
  "6.2-2": item(
    j([
      "Was soll ich tun, wenn kein Empfehlungsbonus",
      "angekommen ist?",
    ]),
    j([
      "Prüfen Sie zuerst, ob der geworbene Nutzer wirklich",
      "aktiv geworden ist. Öffnen Sie danach Referrals und",
      "die Verlaufseinträge.",
    ]),
    ["Bonus fehlt", "Referrals"],
  ),
  "6.2-3": item(
    "Warum gibt es Boni nur für aktive Referrals?",
    j([
      "Weil das Projekt den aktiven Beitrag zum System",
      "belohnt, nicht nur die Tatsache einer Einladung.",
    ]),
    ["aktive Referrals", "Bonus"],
  ),
  "6.2-4": item(
    "Wie hoch ist der Basisbonus für ein aktives Referral?",
    "Der Basisbonus für ein aktives Referral beträgt 0,25 EFHC.",
    ["0,25 EFHC", "Basisbonus"],
  ),
  "6.2-5": item(
    "Was sind die Fortschrittsstufen des Empfehlungssystems?",
    j([
      "Das sind Stufen 0 bis 5, die Ihren Weg nach der Zahl",
      "aktiver Referrals zeigen.",
    ]),
    ["Stufen Referrals", "0 bis 5"],
  ),
  "6.2-6": item(
    "Was bedeutet Stufe 0 im Referral-Fortschritt?",
    j([
      "Stufe 0 bedeutet den Startpunkt. Sie haben noch keine",
      "Stufe des Referral-Fortschritts erreicht.",
    ]),
    ["Stufe 0 Referrals", "Start"],
  ),
  "6.2-7": item(
    "Was bedeutet Stufe 1 im Referral-Fortschritt?",
    j([
      "Stufe 1 bedeutet, dass Sie 10 aktive Referrals",
      "erreicht haben und einen einmaligen Bonus von 1 EFHC",
      "erhalten.",
    ]),
    ["Stufe 1 Referrals", "10 Referrals"],
  ),
  "6.2-8": item(
    "Was bedeutet Stufe 2 im Referral-Fortschritt?",
    j([
      "Stufe 2 bedeutet, dass Sie 100 aktive Referrals",
      "erreicht haben und einen einmaligen Bonus von 10 EFHC",
      "erhalten.",
    ]),
    ["Stufe 2 Referrals", "100 Referrals"],
  ),
  "6.2-9": item(
    "Was bedeutet Stufe 3 im Referral-Fortschritt?",
    j([
      "Stufe 3 bedeutet, dass Sie 1000 aktive Referrals",
      "erreicht haben und einen einmaligen Bonus von 100 EFHC",
      "erhalten.",
    ]),
    ["Stufe 3 Referrals", "1000 Referrals"],
  ),
  "6.2-10": item(
    "Was bedeutet Stufe 4 im Referral-Fortschritt?",
    j([
      "Stufe 4 bedeutet, dass Sie 3000 aktive Referrals",
      "erreicht haben und einen einmaligen Bonus von 300 EFHC",
      "erhalten.",
    ]),
    ["Stufe 4 Referrals", "3000 Referrals"],
  ),
  "6.2-11": item(
    "Was bedeutet Stufe 5 im Referral-Fortschritt?",
    j([
      "Stufe 5 bedeutet, dass Sie 10000 aktive Referrals",
      "erreicht haben und einen einmaligen Bonus von 1000",
      "EFHC erhalten.",
    ]),
    ["Stufe 5 Referrals", "10000 Referrals"],
  ),
  "6.3-1": item(
    "Was ist der Activ-Status?",
    j([
      "Der Activ-Status zeigt, dass Sie bereits in den",
      "aktiven Projektzyklus eingetreten sind und den",
      "grundlegenden aktiven Teilnehmerstatus von EFHC haben.",
    ]),
    ["Activ-Status", "aktiv"],
  ),
  "6.3-2": item(
    "Wie bekomme ich den Activ-Status?",
    j([
      "Den Activ-Status erhalten Sie nach dem Kauf Ihres",
      "ersten Panels.",
    ]),
    ["Activ bekommen", "erstes Panel"],
  ),
  "6.3-3": item(
    "Ist der Activ-Status vorübergehend oder dauerhaft?",
    j([
      "Der Activ-Status ist dauerhaft. Nach seinem Erhalt",
      "bleibt er dem Nutzer erhalten.",
    ]),
    ["Activ dauerhaft", "Activ Status"],
  ),
  "6.3-4": item(
    "Bleibt der Activ-Status, wenn ein Panel ins Archiv geht?",
    j([
      "Ja. Der Activ-Status bleibt erhalten, auch wenn ein",
      "Panel später in Archive übergeht.",
    ]),
    ["Activ und Archive", "Archiv"],
  ),
  "6.3-5": item(
    "Warum ist der Activ-Status wichtig?",
    j([
      "Der Activ-Status zeigt, dass Sie voll in den",
      "Projektzyklus eingetreten sind, und beeinflusst",
      "mehrere spielbezogene Szenarien.",
    ]),
    ["Activ wichtig", "Status"],
  ),
  "8.3-1": item(
    "Was sind Lotteries in EFHC?",
    j([
      "Lotteries sind Spielereignisse im Projekt, bei denen",
      "Nutzer Tickets kaufen und an der Auswahl des Gewinners",
      "teilnehmen.",
    ]),
    ["Lotteries", "Tickets"],
  ),
  "8.3-2": item(
    "Welche Lotteries gibt es im Projekt?",
    j([
      "Im Projekt gibt es die Lotteries um 100 EFHC und die",
      "Lotteries um ein VIP NFT EFHC.",
    ]),
    ["Arten Lotteries", "100 EFHC"],
  ),
  "8.3-3": item(
    j([
      "Worin unterscheiden sich die 100-EFHC-Lotteries und",
      "die VIP-NFT-Lotteries?",
    ]),
    j([
      "Sie unterscheiden sich im Preis des Gewinns: in der",
      "einen erhalten Sie EFHC, in der anderen ein VIP NFT",
      "EFHC.",
    ]),
    ["Lotteries Unterschied", "VIP NFT"],
  ),
  "8.3-4": item(
    "Wie viel kostet ein Ticket?",
    "Ein Ticket kostet 1 EFHC.",
    ["Ticketpreis", "1 EFHC"],
  ),
  "8.3-5": item(
    "Wie viele Tickets kann eine Lotteries haben?",
    j([
      "Die Lotteries um 100 EFHC hat 200 Tickets. Die",
      "VIP-NFT-Lotteries hat 3000 Tickets.",
    ]),
    ["Anzahl Tickets", "200", "3000"],
  ),
  "8.3-6": item(
    "Wann startet eine Lotteries?",
    j([
      "Eine Lotteries läuft innerhalb ihres Ticket-Pools und",
      "endet, wenn alle Tickets verkauft sind. Danach beginnt",
      "automatisch eine neue Ziehung.",
    ]),
    ["Start Lotteries", "Ziehung"],
  ),
  "8.3-7": item(
    "Wie wird der Gewinner bestimmt?",
    j([
      "Der Gewinner wird automatisch bestimmt, wenn das",
      "letzte Ticket gekauft wurde und die Ziehung ausgelöst",
      "wird.",
    ]),
    ["Gewinner", "automatisch"],
  ),
  "8.3-8": item(
    "Was passiert nach der Gewinnerauswahl?",
    j([
      "Nach der Gewinnerauswahl wird der Preis gutgeschrieben",
      "oder ausgegeben, und der Nutzer sieht das Ergebnis im",
      "Projekt.",
    ]),
    ["nach Gewinner", "Preis"],
  ),
  "8.3-9": item(
    "Welcher Preis gilt in der 100-EFHC-Lotteries?",
    j([
      "Der Preis in der 100-EFHC-Lotteries beträgt 100 EFHC",
      "auf den Bonussaldo.",
    ]),
    ["100 EFHC Preis", "Bonus"],
  ),
  "8.3-10": item(
    "Welcher Preis gilt in der NFT-VIP-EFHC-Lotteries?",
    j([
      "Der Preis in der NFT-VIP-EFHC-Lotteries ist ein VIP",
      "NFT EFHC.",
    ]),
    ["VIP NFT Preis", "NFT Lotteries"],
  ),
  "8.3-11": item(
    "Warum braucht man in der NFT-Lotteries eine Wallet?",
    j([
      "Weil für die Ausgabe eines NFT eine verbundene Wallet",
      "nötig ist, an die der Gewinn gesendet werden kann.",
    ]),
    ["Wallet für NFT", "NFT Gewinn"],
  ),
  "8.3-12": item(
    "Wie wird das NFT nach einem Sieg ausgegeben?",
    j([
      "Nach dem Sieg wird das NFT gemäß den Projektregeln an",
      "die verbundene Wallet des Nutzers ausgegeben.",
    ]),
    ["NFT Ausgabe", "Wallet"],
  ),
  "8.3-13": item(
    "Wo wird ein Gewinn angezeigt?",
    j([
      "Der Gewinn wird in dem Bereich angezeigt, der zum",
      "Preis gehört: im Kontostand, im Wallet-bezogenen Teil",
      "oder im Nutzerstatus.",
    ]),
    ["Gewinn sichtbar", "wo angezeigt"],
  ),
  "8.3-14": item(
    "Warum sehe ich das Lotteries-Ergebnis nicht?",
    j([
      "Aktualisieren Sie den Bildschirm und prüfen Sie den",
      "passenden Bereich. Manchmal braucht die Oberfläche",
      "etwas Zeit, um das Ergebnis anzuzeigen.",
    ]),
    ["Ergebnis fehlt", "Lotteries"],
  ),
  "8.4-1": item(
    "Was ist der Bereich Ads?",
    j([
      "Ads ist ein Nutzerbereich mit Angeboten oder Aktionen,",
      "die zusätzliche Vorteile oder Ergebnisse im Projekt",
      "bringen können.",
    ]),
    ["Ads", "Angebote"],
  ),
  "8.4-2": item(
    "Was bringt dieser Bereich dem Nutzer?",
    j([
      "Er kann zusätzliche Aktionen, Angebote oder",
      "Möglichkeiten eröffnen, die im aktuellen",
      "Projektkontext nützlich sind.",
    ]),
    ["Ads Nutzen", "Angebote"],
  ),
  "8.4-3": item(
    "Warum wird ein Angebot vielleicht nicht angezeigt?",
    j([
      "Manche Angebote hängen von Verfügbarkeit, Region,",
      "Bildschirm oder aktuellem Status innerhalb des",
      "Projekts ab.",
    ]),
    ["Angebot fehlt", "Ads"],
  ),
  "8.4-4": item(
    j([
      "Was tun, wenn die Aktion ausgeführt wurde, das",
      "Ergebnis aber fehlt?",
    ]),
    j([
      "Aktualisieren Sie den Bildschirm und prüfen Sie den",
      "Bereich, mit dem die Aktion verbunden war. Erscheint",
      "nichts, warten Sie kurz und prüfen Sie erneut.",
    ]),
    ["Ergebnis fehlt", "Ads Aktion"],
  ),
  "9.2-2": item(
    j([
      "Worin unterscheidet sich ein interner Kauf von einem",
      "Kauf über die Wallet?",
    ]),
    j([
      "Ein interner Kauf nutzt Ihre EFHC im Bot. Ein Kauf",
      "über die Wallet ist mit einer externen Bestätigung",
      "über die Wallet verbunden.",
    ]),
    ["interner Kauf", "Wallet-Kauf"],
  ),
  "9.2-4": item(
    "Warum sehe ich das Ergebnis nach der Zahlung nicht sofort?",
    j([
      "Manche Aktionen brauchen etwas Zeit, um sich in der",
      "Oberfläche zu aktualisieren. Aktualisieren Sie den",
      "Bildschirm und prüfen Sie Verlauf oder Zielbereich.",
    ]),
    ["Ergebnis nach Zahlung", "nicht sofort"],
  ),
  "10.1-5": item(
    "Wie viele Erfolgsstufen gibt es im Energiefortschritt?",
    j([
      "Im Energiefortschritt des Projekts gibt es 12 Stufen.",
      "Sie zeigen den Weg von den ersten Schritten bis zum",
      "höchsten Punkt des allgemeinen Fortschritts.",
    ]),
    ["12 Stufen", "Energiefortschritt"],
  ),
  "10.1-6": item(
    "Was bedeuten die Erfolgsstufen in einfachen Worten?",
    j([
      "Sie sind zugleich Ihr Energieweg, Ihr Fortschritt und",
      "Ihr Bild im Projekt. Die Stufen zeigen, wie weit Sie",
      "in der Linie der sauberen Energie gekommen sind.",
    ]),
    ["Bedeutung Stufen", "Fortschritt"],
  ),
  "10.1-7": item(
    j([
      "Warum hängen die Stufennamen mit Umwelt und Planet",
      "zusammen?",
    ]),
    j([
      "Weil der gesamte EFHC-Fortschritt mit sauberer",
      "Energie, grünem Wandel und dem Beitrag zur Zukunft des",
      "Planeten verbunden ist.",
    ]),
    ["Stufennamen", "Umwelt"],
  ),
  "10.2-1": item(
    "Was bedeutet die Stufe Eco Initiate?",
    j([
      "0 kWh. Ihr erstes Panel ist installiert und",
      "arbeitsbereit. Sie machen den wichtigsten Schritt, um",
      "unabhängiger Produzent sauberer Energie zu werden.",
    ]),
    ["Eco Initiate", "0 kWh"],
  ),
  "10.2-2": item(
    "Was bedeutet die Stufe Hope Bringer?",
    j([
      "100 kWh. Sie sind nicht mehr nur Teilnehmer, sondern",
      "ein Träger der Hoffnung auf einen grünen Wandel und",
      "den Beginn eines nachhaltigen Weges.",
    ]),
    ["Hope Bringer", "100 kWh"],
  ),
  "10.2-3": item(
    "Was bedeutet die Stufe Energy Seeker?",
    j([
      "300 kWh. Sie suchen Energie nicht nur für sich,",
      "sondern für eine Zukunft, in der saubere Quellen",
      "wichtiger sind als erschöpfbare Ressourcen.",
    ]),
    ["Energy Seeker", "300 kWh"],
  ),
  "10.2-4": item(
    "Was bedeutet die Stufe Nature's Voice?",
    j([
      "600 kWh. Ihr Fortschritt klingt wie die Stimme der",
      "Natur selbst und erinnert daran, dass die Erde Schutz",
      "und Respekt verdient.",
    ]),
    ["Nature's Voice", "600 kWh"],
  ),
  "10.2-5": item(
    "Was bedeutet die Stufe Earth Ally?",
    j([
      "1000 kWh. Sie werden zum Verbündeten der Erde und",
      "beweisen durch Handeln, dass jeder Energiebeitrag den",
      "Zustand des Planeten verändern kann.",
    ]),
    ["Earth Ally", "1000 kWh"],
  ),
  "10.2-6": item(
    "Was bedeutet die Stufe Climate Fighter?",
    j([
      "2000 kWh. Das ist bereits ein deutlicher Beitrag im",
      "Kampf gegen die Klimakrise und für eine sauberere,",
      "sicherere Zukunft.",
    ]),
    ["Climate Fighter", "2000 kWh"],
  ),
  "10.2-7": item(
    "Was bedeutet die Stufe Green Sentinel?",
    j([
      "3500 kWh. Sie werden zum grünen Wächter, der den Weg",
      "nachhaltiger Energie schützt und andere zu sauberem",
      "Fortschritt inspiriert.",
    ]),
    ["Green Sentinel", "3500 kWh"],
  ),
  "10.2-8": item(
    "Was bedeutet die Stufe Planet Defender?",
    j([
      "5000 kWh. Ihr Beitrag erhält spürbares Gewicht und",
      "wird zum Symbol der Verteidigung des Planeten durch",
      "echte Energiehandlungen.",
    ]),
    ["Planet Defender", "5000 kWh"],
  ),
  "10.2-9": item(
    "Was bedeutet die Stufe Eco Champion?",
    j([
      "7500 kWh. Sie erreichen ein Niveau, auf dem Ihr",
      "Fortschritt als Beispiel für Verantwortung, Stabilität",
      "und grünes Wachstum dient.",
    ]),
    ["Eco Champion", "7500 kWh"],
  ),
  "10.2-10": item(
    "Was bedeutet die Stufe Planet Saver?",
    j([
      "10000 kWh. Diese Stufe zeigt, dass Ihr Weg bereits",
      "einer echten Rettung des Planeten durch den Ausbau",
      "sauberer Energie ähnelt.",
    ]),
    ["Planet Saver", "10000 kWh"],
  ),
  "10.2-11": item(
    "Was bedeutet die Stufe Green Commander?",
    j([
      "15000 kWh. Sie führen Ihren Fortschritt wie ein",
      "Kommandeur der grünen Zukunft und zeigen die Kraft",
      "eines systematischen Beitrags.",
    ]),
    ["Green Commander", "15000 kWh"],
  ),
  "10.2-12": item(
    "Was bedeutet die Stufe Guardian of Earth?",
    j([
      "20000+ kWh. Das ist die höchste Stufe des Projekts und",
      "das Symbol eines Nutzers, dessen Energiepfad zum",
      "Schutz der Erde geworden ist.",
    ]),
    ["Guardian of Earth", "20000+ kWh"],
  ),
  "12.1-5": item(
    "Wie benutze ich dieses FAQ?",
    j([
      "Wählen Sie zuerst den Abschnitt nach dem Sinn des",
      "Bildschirms: Balances, Wallet, Panels, Exchange,",
      "Referrals oder Shop. Öffnen Sie dann den passenden",
      "Unterabschnitt und suchen Sie dort die Frage.",
    ]),
    ["FAQ benutzen", "Abschnitte"],
  ),
  "12.1-6": item(
    j([
      "Warum ist das FAQ in Abschnitte und Unterabschnitte",
      "geteilt?",
    ]),
    j([
      "Weil der Bot viele Bildschirme und verschiedene",
      "Aktionen hat. Diese Struktur hilft, schneller eine",
      "Antwort über bekannte Interface-Wörter zu finden.",
    ]),
    ["Abschnitte", "Unterabschnitte"],
  ),
  "12.1-7": item(
    "Was bringen verwandte Fragen unter der Antwort?",
    j([
      "Verwandte Fragen helfen, schnell zu einem nahen Thema",
      "zu wechseln, ohne eine neue Suche zu starten.",
    ]),
    ["verwandte Fragen", "related"],
  ),
  "12.2-1": item(
    "Was ist der Bereich „Profil/Einstellungen“?",
    j([
      "Das ist der Bereich, in dem Sie Ihre Hauptstatus sehen",
      "und persönliche Einstellungen der Bot-Oberfläche",
      "finden.",
    ]),
    ["Profil", "Einstellungen"],
  ),
  "12.2-2": item(
    j([
      "Was wird im oberen Teil von Profil/Einstellungen",
      "angezeigt?",
    ]),
    j([
      "Dort sehen Sie normalerweise Ihre Kerninformationen,",
      "wichtige Status und zentrale Interface-Elemente Ihres",
      "Kontos.",
    ]),
    ["Profil oben", "Status"],
  ),
  "12.2-3": item(
    "Was kann ich im Bereich „Profil/Einstellungen“ anpassen?",
    j([
      "Dort können Sie Sprache, Wallet-bezogene Punkte,",
      "FAQ-Einstiege und andere verfügbare",
      "Interface-Einstellungen verwalten.",
    ]),
    ["anpassen", "Profil"],
  ),
  "12.2-4": item(
    "Was befindet sich im Bereich „Support und Informationen“?",
    j([
      "Dort finden Sie hilfreiche Bereiche mit Erklärungen,",
      "FAQ, Hinweisen und weiteren Informationen zum Projekt",
      "und zur Oberfläche.",
    ]),
    ["Support", "Informationen"],
  ),
});


Object.assign((faqItemOverridesByLang.fr ??= {}), {
  "1.3-1": item(
    "Qu’est-ce que la barre supérieure ?",
    j([
      "La barre supérieure est le bloc principal",
      "d’information rapide visible sur les pages principales",
      "du bot.",
    ]),
    ["barre supérieure", "top bar"],
  ),
  "1.3-2": item(
    "Qu’affiche la barre supérieure ?",
    j([
      "La barre supérieure peut afficher votre nom, avatar,",
      "niveau de progression, statut VIP, solde total et des",
      "boutons rapides comme Recharger et Shop.",
    ]),
    ["barre supérieure", "visible"],
  ),
  "1.3-3": item(
    j([
      "Pourquoi le solde total en haut n’est-il pas égal au",
      "montant retirable ?",
    ]),
    j([
      "Parce que la barre supérieure montre tous vos fonds",
      "dans le bot, tandis que le retrait utilise seulement",
      "le solde principal.",
    ]),
    ["solde total", "retrait"],
  ),
  "1.3-4": item(
    "Que fait le bouton « Recharger » ?",
    j([
      "Le bouton Recharger ouvre le chemin vers",
      "l’approvisionnement ou l’achat via le Wallet. Si un",
      "Wallet est nécessaire, le bot propose d’abord de le",
      "connecter.",
    ]),
    ["recharger", "wallet"],
  ),
  "1.3-5": item(
    "Que fait le bouton Shop ?",
    j([
      "Le bouton Shop ouvre la boutique du projet avec les",
      "achats en EFHC et les offres externes via le Wallet.",
    ]),
    ["shop", "bouton shop"],
  ),
  "3.1-6": item(
    "Combien coûte un panneau ?",
    j([
      "Un panneau coûte toujours 100 EFHC dans le projet.",
      "C’est le prix d’entrée de base dans le cycle des",
      "panneaux et de l’énergie.",
    ]),
    ["prix panneau", "100 EFHC"],
  ),
  "3.1-7": item(
    "Que donne immédiatement l’achat du premier panneau ?",
    j([
      "Avec le premier panneau, vous entrez dans le cycle",
      "actif du projet, recevez le statut Activ et lancez",
      "votre parcours énergétique.",
    ]),
    ["premier panneau", "Activ"],
  ),
  "3.1-8": item(
    "Quand un panneau commence-t-il à produire ?",
    j([
      "La production commence dès que le panneau devient",
      "actif et commence à fonctionner selon les règles du",
      "projet.",
    ]),
    ["début production", "panneau"],
  ),
  "3.1-9": item(
    "Quelle est la durée de vie d’un panneau ?",
    j([
      "Un panneau est prévu pour un cycle de 180 jours.",
      "Pendant cette période, il produit de l’énergie selon",
      "les règles du projet.",
    ]),
    ["180 jours", "durée panneau"],
  ),
  "3.1-10": item(
    "Y a-t-il une limite de panneaux actifs ?",
    j([
      "Oui. Le projet prévoit une limite de 1000 panneaux",
      "actifs par utilisateur.",
    ]),
    ["limite panneaux", "1000 panneaux"],
  ),
  "3.3-1": item(
    "À quoi sert la page Energy ?",
    j([
      "La page Energy aide à comprendre rapidement votre état",
      "énergétique actuel et à entrer dans le cycle de jeu",
      "quotidien.",
    ]),
    ["page Energy", "utilité"],
  ),
  "3.3-2": item(
    "Que montre la page Energy ?",
    j([
      "La page Energy montre la progression, la production,",
      "les panneaux actifs et d’autres indicateurs qui",
      "expliquent rapidement l’état actuel.",
    ]),
    ["page Energy", "affiche"],
  ),
  "3.3-3": item(
    "Que montre la barre de progression sur la page Energy ?",
    j([
      "La barre de progression montre votre chemin vers le",
      "niveau suivant et jusqu’où vous êtes allé dans la",
      "progression énergétique.",
    ]),
    ["barre progression", "Energy"],
  ),
  "3.3-4": item(
    j([
      "Que signifie la production totale des panneaux par",
      "seconde ?",
    ]),
    j([
      "C’est la quantité d’énergie produite chaque seconde",
      "par tous vos panneaux actifs réunis.",
    ]),
    ["production par seconde", "panneaux"],
  ),
  "3.3-5": item(
    "Pourquoi la page Energy est-elle importante ?",
    j([
      "Elle montre d’un coup d’œil le cœur de votre",
      "progression : énergie, panneaux, croissance et chemin",
      "vers le niveau suivant.",
    ]),
    ["Energy importante", "progression"],
  ),
  "5.1-6": item(
    "À quoi sert le Wallet principal ?",
    j([
      "Le Wallet principal est le Wallet principal que le bot",
      "utilise pour les actions importantes liées au Wallet",
      "et aux liaisons.",
    ]),
    ["wallet principal", "wallet"],
  ),
  "5.1-7": item(
    "Puis-je changer le Wallet principal ?",
    j([
      "Oui. Si l’interface le permet, vous pouvez choisir un",
      "autre Wallet connecté comme Wallet principal.",
    ]),
    ["changer wallet", "wallet principal"],
  ),
  "5.1-8": item(
    "Puis-je supprimer un Wallet lié ?",
    j([
      "Si l’interface prend cette action en charge, vous",
      "pouvez détacher un Wallet lié et le reconnecter plus",
      "tard.",
    ]),
    ["supprimer wallet", "détacher"],
  ),
  "5.1-9": item(
    j([
      "Que se passe-t-il si j’appuie sur un bouton qui exige",
      "un Wallet ?",
    ]),
    j([
      "Le bot vous demandera d’abord de connecter un Wallet",
      "ou de confirmer l’action nécessaire via le Wallet.",
    ]),
    ["wallet requis", "bouton"],
  ),
  "6.2-1": item(
    "Quand les bonus de parrainage sont-ils crédités ?",
    j([
      "Les bonus de parrainage sont crédités lorsque les",
      "conditions du projet sont remplies et que",
      "l’utilisateur invité est compté comme actif.",
    ]),
    ["bonus parrainage", "actif"],
  ),
  "6.2-2": item(
    "Que faire si le bonus de parrainage n’est pas arrivé ?",
    j([
      "Vérifiez d’abord que l’utilisateur invité est bien",
      "devenu actif. Ensuite, ouvrez Referrals et",
      "l’historique concerné.",
    ]),
    ["bonus absent", "Referrals"],
  ),
  "6.2-3": item(
    j([
      "Pourquoi les bonus ne concernent-ils que les parrains",
      "actifs ?",
    ]),
    j([
      "Parce que le projet récompense la contribution active",
      "au système, et non le simple fait d’avoir envoyé une",
      "invitation.",
    ]),
    ["parrainages actifs", "bonus"],
  ),
  "6.2-4": item(
    "Quel est le bonus de base pour un parrainage actif ?",
    j([
      "Le bonus de base pour un parrainage actif est de 0,25",
      "EFHC.",
    ]),
    ["0,25 EFHC", "bonus de base"],
  ),
  "6.2-5": item(
    j([
      "Que sont les niveaux de progression du système de",
      "parrainage ?",
    ]),
    j([
      "Ce sont les niveaux 0 à 5 qui montrent votre chemin",
      "selon le nombre de parrainages actifs.",
    ]),
    ["niveaux parrainage", "0 à 5"],
  ),
  "6.2-6": item(
    "Que signifie le niveau 0 de la progression de parrainage ?",
    j([
      "Le niveau 0 est le point de départ. Vous n’avez encore",
      "atteint aucun niveau de progression de parrainage.",
    ]),
    ["niveau 0 parrainage", "départ"],
  ),
  "6.2-7": item(
    "Que signifie le niveau 1 de la progression de parrainage ?",
    j([
      "Le niveau 1 signifie que vous avez atteint 10",
      "parrainages actifs et reçu un bonus unique de 1 EFHC.",
    ]),
    ["niveau 1 parrainage", "10 parrainages"],
  ),
  "6.2-8": item(
    "Que signifie le niveau 2 de la progression de parrainage ?",
    j([
      "Le niveau 2 signifie que vous avez atteint 100",
      "parrainages actifs et reçu un bonus unique de 10 EFHC.",
    ]),
    ["niveau 2 parrainage", "100 parrainages"],
  ),
  "6.2-9": item(
    "Que signifie le niveau 3 de la progression de parrainage ?",
    j([
      "Le niveau 3 signifie que vous avez atteint 1000",
      "parrainages actifs et reçu un bonus unique de 100",
      "EFHC.",
    ]),
    ["niveau 3 parrainage", "1000 parrainages"],
  ),
  "6.2-10": item(
    "Que signifie le niveau 4 de la progression de parrainage ?",
    j([
      "Le niveau 4 signifie que vous avez atteint 3000",
      "parrainages actifs et reçu un bonus unique de 300",
      "EFHC.",
    ]),
    ["niveau 4 parrainage", "3000 parrainages"],
  ),
  "6.2-11": item(
    "Que signifie le niveau 5 de la progression de parrainage ?",
    j([
      "Le niveau 5 signifie que vous avez atteint 10000",
      "parrainages actifs et reçu un bonus unique de 1000",
      "EFHC.",
    ]),
    ["niveau 5 parrainage", "10000 parrainages"],
  ),
  "6.3-1": item(
    "Qu’est-ce que le statut Activ ?",
    j([
      "Le statut Activ montre que vous êtes déjà entré dans",
      "le cycle actif du projet et que vous possédez le",
      "statut actif de base d’un participant EFHC.",
    ]),
    ["statut Activ", "actif"],
  ),
  "6.3-2": item(
    "Comment obtenir le statut Activ ?",
    j([
      "Vous obtenez le statut Activ après l’achat de votre",
      "premier panneau.",
    ]),
    ["obtenir Activ", "premier panneau"],
  ),
  "6.3-3": item(
    "Le statut Activ est-il temporaire ou permanent ?",
    j([
      "Le statut Activ est permanent. Une fois obtenu, il",
      "reste attaché à l’utilisateur.",
    ]),
    ["Activ permanent", "statut Activ"],
  ),
  "6.3-4": item(
    j([
      "Le statut Activ reste-t-il si un panneau passe dans",
      "Archive ?",
    ]),
    j([
      "Oui. Le statut Activ reste acquis même si un panneau",
      "passe plus tard dans Archive.",
    ]),
    ["Activ et Archive", "Archive"],
  ),
  "6.3-5": item(
    "Pourquoi le statut Activ est-il important ?",
    j([
      "Le statut Activ montre que vous êtes pleinement entré",
      "dans le cycle du projet et il influence plusieurs",
      "scénarios de jeu.",
    ]),
    ["Activ important", "statut"],
  ),
  "8.3-1": item(
    "Que sont les Lotteries dans EFHC ?",
    j([
      "Les Lotteries sont des événements de jeu du projet où",
      "les utilisateurs achètent des billets et participent",
      "au choix du gagnant.",
    ]),
    ["Lotteries", "billets"],
  ),
  "8.3-2": item(
    "Quelles Lotteries existe-t-il dans le projet ?",
    j([
      "Le projet propose les Lotteries pour 100 EFHC et les",
      "Lotteries pour un VIP NFT EFHC.",
    ]),
    ["types Lotteries", "100 EFHC"],
  ),
  "8.3-3": item(
    j([
      "Quelle est la différence entre les Lotteries 100 EFHC",
      "et VIP NFT EFHC ?",
    ]),
    j([
      "La différence est le prix final : dans un cas vous",
      "recevez des EFHC, dans l’autre un VIP NFT EFHC.",
    ]),
    ["différence Lotteries", "VIP NFT"],
  ),
  "8.3-4": item(
    "Combien coûte un billet ?",
    "Un billet coûte 1 EFHC.",
    ["prix billet", "1 EFHC"],
  ),
  "8.3-5": item(
    "Combien de billets peut contenir une Lotteries ?",
    j([
      "La Lotteries à 100 EFHC contient 200 billets. La",
      "Lotteries VIP NFT contient 3000 billets.",
    ]),
    ["nombre billets", "200", "3000"],
  ),
  "8.3-6": item(
    "Quand une Lotteries démarre-t-elle ?",
    j([
      "Une Lotteries se déroule dans son pool de billets et",
      "se termine quand tous les billets sont vendus.",
      "Ensuite, un nouveau tirage démarre automatiquement.",
    ]),
    ["début Lotteries", "tirage"],
  ),
  "8.3-7": item(
    "Comment le gagnant est-il déterminé ?",
    j([
      "Le gagnant est déterminé automatiquement lorsque le",
      "dernier billet est acheté et que le tirage est",
      "déclenché.",
    ]),
    ["gagnant", "automatique"],
  ),
  "8.3-8": item(
    "Que se passe-t-il après la sélection du gagnant ?",
    j([
      "Après la sélection du gagnant, le prix est crédité ou",
      "remis, et l’utilisateur voit le résultat dans le",
      "projet.",
    ]),
    ["après gagnant", "prix"],
  ),
  "8.3-9": item(
    "Quel est le prix dans la Lotteries 100 EFHC ?",
    j([
      "Le prix de la Lotteries 100 EFHC est de 100 EFHC sur",
      "le solde bonus.",
    ]),
    ["prix 100 EFHC", "bonus"],
  ),
  "8.3-10": item(
    "Quel est le prix dans la Lotteries NFT VIP EFHC ?",
    "Le prix de la Lotteries NFT VIP EFHC est un VIP NFT EFHC.",
    ["prix VIP NFT", "Lotteries NFT"],
  ),
  "8.3-11": item(
    "Pourquoi faut-il un Wallet dans la Lotteries NFT ?",
    j([
      "Parce que l’émission d’un NFT nécessite un Wallet",
      "connecté auquel le prix pourra être envoyé.",
    ]),
    ["Wallet pour NFT", "gain NFT"],
  ),
  "8.3-12": item(
    "Comment le NFT est-il remis après une victoire ?",
    j([
      "Après la victoire, le NFT est remis au Wallet connecté",
      "de l’utilisateur selon les règles du projet.",
    ]),
    ["remise NFT", "Wallet"],
  ),
  "8.3-13": item(
    "Où le gain est-il affiché ?",
    j([
      "Le gain est affiché dans la zone liée au prix : solde,",
      "partie liée au Wallet ou statut de l’utilisateur.",
    ]),
    ["gain visible", "où affiché"],
  ),
  "8.3-14": item(
    "Pourquoi ne vois-je pas le résultat des Lotteries ?",
    j([
      "Actualisez l’écran et vérifiez la section concernée.",
      "Parfois l’interface a besoin d’un peu de temps pour",
      "afficher le résultat.",
    ]),
    ["résultat absent", "Lotteries"],
  ),
  "8.4-1": item(
    "Qu’est-ce que la section Ads ?",
    j([
      "Ads est une section utilisateur avec des offres ou",
      "actions pouvant donner des avantages ou résultats",
      "supplémentaires dans le projet.",
    ]),
    ["Ads", "offres"],
  ),
  "8.4-2": item(
    "Que donne cette section à l’utilisateur ?",
    j([
      "Elle peut ouvrir des actions supplémentaires, des",
      "offres ou des possibilités utiles dans le contexte",
      "actuel du projet.",
    ]),
    ["utilité Ads", "offres"],
  ),
  "8.4-3": item(
    "Pourquoi une offre peut-elle ne pas s’afficher ?",
    j([
      "Certaines offres dépendent de la disponibilité, de la",
      "région, de l’écran ou du statut actuel dans le projet.",
    ]),
    ["offre absente", "Ads"],
  ),
  "8.4-4": item(
    j([
      "Que faire si l’action a été faite mais que le résultat",
      "n’apparaît pas ?",
    ]),
    j([
      "Actualisez l’écran et vérifiez la section liée à",
      "l’action. Si rien n’apparaît, attendez un peu puis",
      "vérifiez encore.",
    ]),
    ["résultat absent", "action Ads"],
  ),
  "9.2-2": item(
    j([
      "Quelle est la différence entre un achat interne et un",
      "achat via Wallet ?",
    ]),
    j([
      "Un achat interne utilise vos EFHC dans le bot. Un",
      "achat via Wallet est lié à une confirmation externe",
      "par le Wallet.",
    ]),
    ["achat interne", "achat wallet"],
  ),
  "9.2-4": item(
    j([
      "Pourquoi ne vois-je pas le résultat immédiatement",
      "après le paiement ?",
    ]),
    j([
      "Certaines opérations ont besoin d’un peu de temps pour",
      "se mettre à jour dans l’interface. Actualisez l’écran",
      "et vérifiez l’historique ou la section visée.",
    ]),
    ["résultat paiement", "pas immédiat"],
  ),
  "10.1-5": item(
    j([
      "Combien y a-t-il de niveaux de réussite dans la",
      "progression énergétique ?",
    ]),
    j([
      "La progression énergétique du projet comporte 12",
      "niveaux. Ils montrent le chemin des premiers pas",
      "jusqu’au sommet de la progression globale.",
    ]),
    ["12 niveaux", "progression énergétique"],
  ),
  "10.1-6": item(
    "Que signifient simplement les niveaux de réussite ?",
    j([
      "Ils représentent à la fois votre chemin énergétique,",
      "votre progression et votre image dans le projet. Ils",
      "montrent jusqu’où vous êtes allé sur la ligne de",
      "l’énergie propre.",
    ]),
    ["signification niveaux", "progression"],
  ),
  "10.1-7": item(
    j([
      "Pourquoi les noms des niveaux sont-ils liés à",
      "l’écologie et à la planète ?",
    ]),
    j([
      "Parce que toute la progression EFHC est liée à",
      "l’énergie propre, à la transition verte et à la",
      "contribution à l’avenir de la planète.",
    ]),
    ["noms niveaux", "écologie"],
  ),
  "10.2-1": item(
    "Que signifie le niveau Eco Initiate ?",
    j([
      "0 kWh. Votre premier panneau est installé et prêt à",
      "fonctionner. Vous faites le pas principal pour devenir",
      "un producteur indépendant d’énergie propre.",
    ]),
    ["Eco Initiate", "0 kWh"],
  ),
  "10.2-2": item(
    "Que signifie le niveau Hope Bringer ?",
    j([
      "100 kWh. Vous n’êtes plus seulement un participant,",
      "mais un porteur d’espoir pour une transition verte et",
      "le début d’une voie durable.",
    ]),
    ["Hope Bringer", "100 kWh"],
  ),
  "10.2-3": item(
    "Que signifie le niveau Energy Seeker ?",
    j([
      "300 kWh. Vous cherchez l’énergie non seulement pour",
      "vous-même, mais pour un avenir où les sources propres",
      "comptent plus que les ressources épuisables.",
    ]),
    ["Energy Seeker", "300 kWh"],
  ),
  "10.2-4": item(
    "Que signifie le niveau Nature's Voice ?",
    j([
      "600 kWh. Votre progression sonne comme la voix de la",
      "nature elle-même et rappelle que la Terre mérite",
      "protection et respect.",
    ]),
    ["Nature's Voice", "600 kWh"],
  ),
  "10.2-5": item(
    "Que signifie le niveau Earth Ally ?",
    j([
      "1000 kWh. Vous devenez un allié de la Terre et prouvez",
      "par vos actions que chaque contribution énergétique",
      "peut changer l’état de la planète.",
    ]),
    ["Earth Ally", "1000 kWh"],
  ),
  "10.2-6": item(
    "Que signifie le niveau Climate Fighter ?",
    j([
      "2000 kWh. C’est déjà une contribution visible à la",
      "lutte contre la crise climatique et pour un avenir",
      "plus propre et plus sûr.",
    ]),
    ["Climate Fighter", "2000 kWh"],
  ),
  "10.2-7": item(
    "Que signifie le niveau Green Sentinel ?",
    j([
      "3500 kWh. Vous devenez un gardien vert qui protège la",
      "voie de l’énergie durable et inspire les autres vers",
      "un progrès propre.",
    ]),
    ["Green Sentinel", "3500 kWh"],
  ),
  "10.2-8": item(
    "Que signifie le niveau Planet Defender ?",
    j([
      "5000 kWh. Votre contribution prend un poids réel et",
      "devient un symbole de défense de la planète par des",
      "actions énergétiques concrètes.",
    ]),
    ["Planet Defender", "5000 kWh"],
  ),
  "10.2-9": item(
    "Que signifie le niveau Eco Champion ?",
    j([
      "7500 kWh. Vous atteignez un niveau où votre",
      "progression sert d’exemple de responsabilité, de",
      "stabilité et de croissance verte.",
    ]),
    ["Eco Champion", "7500 kWh"],
  ),
  "10.2-10": item(
    "Que signifie le niveau Planet Saver ?",
    j([
      "10000 kWh. Ce niveau montre que votre chemin ressemble",
      "déjà à un véritable sauvetage de la planète grâce au",
      "développement de l’énergie propre.",
    ]),
    ["Planet Saver", "10000 kWh"],
  ),
  "10.2-11": item(
    "Que signifie le niveau Green Commander ?",
    j([
      "15000 kWh. Vous menez votre progression comme un",
      "commandant de l’avenir vert et montrez la force d’une",
      "contribution systématique.",
    ]),
    ["Green Commander", "15000 kWh"],
  ),
  "10.2-12": item(
    "Que signifie le niveau Guardian of Earth ?",
    j([
      "20000+ kWh. C’est le niveau le plus élevé du projet et",
      "le symbole d’un utilisateur dont le chemin énergétique",
      "est devenu la protection de la Terre.",
    ]),
    ["Guardian of Earth", "20000+ kWh"],
  ),
  "12.1-5": item(
    "Comment utiliser cette FAQ ?",
    j([
      "Choisissez d’abord la section selon le sens de l’écran",
      ": Balances, Wallet, Panels, Exchange, Referrals ou",
      "Shop. Ouvrez ensuite la sous-section appropriée et",
      "cherchez la question.",
    ]),
    ["utiliser FAQ", "sections"],
  ),
  "12.1-6": item(
    j([
      "Pourquoi la FAQ est-elle divisée en sections et",
      "sous-sections ?",
    ]),
    j([
      "Parce que le bot contient beaucoup d’écrans et",
      "d’actions. Cette structure aide à trouver plus vite",
      "une réponse avec des mots d’interface familiers.",
    ]),
    ["sections", "sous-sections"],
  ),
  "12.1-7": item(
    "À quoi servent les questions liées sous la réponse ?",
    j([
      "Les questions liées aident à passer rapidement à un",
      "sujet voisin sans lancer une nouvelle recherche.",
    ]),
    ["questions liées", "related"],
  ),
  "12.2-1": item(
    "Qu’est-ce que la section « Profil/Paramètres » ?",
    j([
      "C’est la section où vous voyez vos statuts principaux",
      "et trouvez les réglages personnels de l’interface du",
      "bot.",
    ]),
    ["profil", "paramètres"],
  ),
  "12.2-2": item(
    "Qu’affiche la partie supérieure de Profil/Paramètres ?",
    j([
      "Elle affiche en général vos informations clés, vos",
      "statuts importants et les éléments centraux de",
      "l’interface de votre compte.",
    ]),
    ["profil haut", "statuts"],
  ),
  "12.2-3": item(
    "Que puis-je régler dans « Profil/Paramètres » ?",
    j([
      "Vous pouvez y gérer la langue, les éléments liés au",
      "Wallet, les entrées FAQ et d’autres réglages",
      "disponibles de l’interface.",
    ]),
    ["régler", "profil"],
  ),
  "12.2-4": item(
    "Que contient la section « Support et informations » ?",
    j([
      "Vous y trouverez des espaces utiles avec explications,",
      "FAQ, conseils et autres informations sur le projet et",
      "l’interface.",
    ]),
    ["support", "informations"],
  ),
});


Object.assign((faqItemOverridesByLang.es ??= {}), {
  "1.3-1": item(
    "¿Qué es la barra superior?",
    j([
      "La barra superior es el bloque principal de",
      "información rápida que se ve en las páginas",
      "principales del bot.",
    ]),
    ["barra superior", "top bar"],
  ),
  "1.3-2": item(
    "¿Qué se muestra en la barra superior?",
    j([
      "La barra superior puede mostrar tu nombre, avatar,",
      "nivel de progreso, estado VIP, saldo total y botones",
      "rápidos como Recargar y Shop.",
    ]),
    ["barra superior", "visible"],
  ),
  "1.3-3": item(
    j([
      "¿Por qué el saldo total arriba no es igual al monto",
      "retirable?",
    ]),
    j([
      "Porque la barra superior muestra todos tus fondos",
      "dentro del bot, mientras que para retirar se usa solo",
      "el saldo principal.",
    ]),
    ["saldo total", "retiro"],
  ),
  "1.3-4": item(
    "¿Qué hace el botón «Recargar»?",
    j([
      "El botón Recargar abre el camino para recargar o",
      "comprar mediante Wallet. Si para eso hace falta",
      "Wallet, el bot primero pedirá conectarlo.",
    ]),
    ["recargar", "wallet"],
  ),
  "1.3-5": item(
    "¿Qué hace el botón Shop?",
    j([
      "El botón Shop abre la tienda del proyecto con compras",
      "por EFHC y ofertas externas mediante Wallet.",
    ]),
    ["shop", "botón shop"],
  ),
  "3.1-6": item(
    "¿Cuánto cuesta un panel?",
    j([
      "Un panel siempre cuesta 100 EFHC en el proyecto. Es el",
      "precio base de entrada al ciclo de paneles y energía.",
    ]),
    ["precio panel", "100 EFHC"],
  ),
  "3.1-7": item(
    "¿Qué da de inmediato la compra del primer panel?",
    j([
      "Con el primer panel entras en el ciclo activo del",
      "proyecto, recibes el estado Activ y comienzas tu",
      "camino energético.",
    ]),
    ["primer panel", "Activ"],
  ),
  "3.1-8": item(
    "¿Cuándo empieza a generar un panel?",
    j([
      "La generación empieza cuando el panel queda activo y",
      "comienza a funcionar según las reglas del proyecto.",
    ]),
    ["inicio generación", "panel"],
  ),
  "3.1-9": item(
    "¿Cuál es la vida útil de un panel?",
    j([
      "Un panel está diseñado para un ciclo de 180 días.",
      "Durante ese período genera energía según las reglas",
      "del proyecto.",
    ]),
    ["180 días", "vida panel"],
  ),
  "3.1-10": item(
    "¿Hay un límite de paneles activos?",
    j([
      "Sí. En el proyecto hay un límite de 1000 paneles",
      "activos por usuario.",
    ]),
    ["límite paneles", "1000 paneles"],
  ),
  "3.3-1": item(
    "¿Para qué sirve la página Energy?",
    j([
      "La página Energy ayuda a entender rápidamente tu",
      "estado energético actual y a entrar en el ciclo diario",
      "del juego.",
    ]),
    ["página Energy", "para qué sirve"],
  ),
  "3.3-2": item(
    "¿Qué muestra la página Energy?",
    j([
      "La página Energy muestra progreso, generación, paneles",
      "activos y otros indicadores que explican rápido el",
      "estado actual.",
    ]),
    ["página Energy", "qué muestra"],
  ),
  "3.3-3": item(
    "¿Qué muestra la barra de progreso en la página Energy?",
    j([
      "La barra de progreso muestra tu camino hacia el",
      "siguiente nivel y qué tan lejos has avanzado en el",
      "progreso energético.",
    ]),
    ["barra de progreso", "Energy"],
  ),
  "3.3-4": item(
    "¿Qué significa la generación total de paneles por segundo?",
    j([
      "Es la cantidad de energía que todos tus paneles",
      "activos generan en conjunto cada segundo.",
    ]),
    ["generación por segundo", "paneles"],
  ),
  "3.3-5": item(
    "¿Por qué es importante la página Energy?",
    j([
      "Muestra de un vistazo el núcleo de tu progreso:",
      "energía, paneles, crecimiento y el camino hacia el",
      "siguiente nivel.",
    ]),
    ["Energy importante", "progreso"],
  ),
  "5.1-6": item(
    "¿Para qué sirve la Wallet principal?",
    j([
      "La Wallet principal es la billetera principal que el",
      "bot usa para acciones importantes relacionadas con",
      "Wallet y con las vinculaciones.",
    ]),
    ["wallet principal", "billetera principal"],
  ),
  "5.1-7": item(
    "¿Puedo cambiar la Wallet principal?",
    j([
      "Sí. Si la interfaz lo permite, puedes elegir otra",
      "Wallet conectada como Wallet principal.",
    ]),
    ["cambiar wallet", "wallet principal"],
  ),
  "5.1-8": item(
    "¿Puedo eliminar una Wallet vinculada?",
    j([
      "Si la interfaz admite esta acción, puedes desvincular",
      "una Wallet conectada y volver a conectarla más tarde.",
    ]),
    ["eliminar wallet", "desvincular"],
  ),
  "5.1-9": item(
    "¿Qué pasa si pulso un botón que requiere Wallet?",
    j([
      "El bot te pedirá primero conectar una Wallet o",
      "confirmar la acción necesaria mediante Wallet.",
    ]),
    ["wallet requerida", "botón"],
  ),
  "6.2-1": item(
    "¿Cuándo se acreditan los bonos por referidos?",
    j([
      "Los bonos por referidos se acreditan cuando se cumplen",
      "las condiciones del proyecto y el usuario invitado",
      "cuenta como activo.",
    ]),
    ["bono referido", "activo"],
  ),
  "6.2-2": item(
    "¿Qué hago si no llegó el bono por referido?",
    j([
      "Primero comprueba que el usuario invitado realmente se",
      "volvió activo. Después abre Referrals y el historial",
      "relacionado.",
    ]),
    ["bono faltante", "Referrals"],
  ),
  "6.2-3": item(
    "¿Por qué los bonos solo son para referidos activos?",
    j([
      "Porque el proyecto recompensa la contribución activa",
      "al sistema, no solo el hecho de enviar una invitación.",
    ]),
    ["referidos activos", "bono"],
  ),
  "6.2-4": item(
    "¿Cuál es el bono base por un referido activo?",
    "El bono base por un referido activo es de 0,25 EFHC.",
    ["0,25 EFHC", "bono base"],
  ),
  "6.2-5": item(
    "¿Qué son los niveles de progreso del sistema de referidos?",
    j([
      "Son los niveles del 0 al 5 que muestran tu camino",
      "según el número de referidos activos.",
    ]),
    ["niveles referidos", "0 a 5"],
  ),
  "6.2-6": item(
    "¿Qué significa el nivel 0 del progreso de referidos?",
    j([
      "El nivel 0 es el punto de partida. Aún no has",
      "alcanzado ningún nivel de progreso de referidos.",
    ]),
    ["nivel 0 referidos", "inicio"],
  ),
  "6.2-7": item(
    "¿Qué significa el nivel 1 del progreso de referidos?",
    j([
      "El nivel 1 significa que alcanzaste 10 referidos",
      "activos y recibes un bono único de 1 EFHC.",
    ]),
    ["nivel 1 referidos", "10 referidos"],
  ),
  "6.2-8": item(
    "¿Qué significa el nivel 2 del progreso de referidos?",
    j([
      "El nivel 2 significa que alcanzaste 100 referidos",
      "activos y recibes un bono único de 10 EFHC.",
    ]),
    ["nivel 2 referidos", "100 referidos"],
  ),
  "6.2-9": item(
    "¿Qué significa el nivel 3 del progreso de referidos?",
    j([
      "El nivel 3 significa que alcanzaste 1000 referidos",
      "activos y recibes un bono único de 100 EFHC.",
    ]),
    ["nivel 3 referidos", "1000 referidos"],
  ),
  "6.2-10": item(
    "¿Qué significa el nivel 4 del progreso de referidos?",
    j([
      "El nivel 4 significa que alcanzaste 3000 referidos",
      "activos y recibes un bono único de 300 EFHC.",
    ]),
    ["nivel 4 referidos", "3000 referidos"],
  ),
  "6.2-11": item(
    "¿Qué significa el nivel 5 del progreso de referidos?",
    j([
      "El nivel 5 significa que alcanzaste 10000 referidos",
      "activos y recibes un bono único de 1000 EFHC.",
    ]),
    ["nivel 5 referidos", "10000 referidos"],
  ),
  "6.3-1": item(
    "¿Qué es el estado Activ?",
    j([
      "El estado Activ muestra que ya entraste en el ciclo",
      "activo del proyecto y que tienes el estado activo",
      "básico de participante EFHC.",
    ]),
    ["estado Activ", "activo"],
  ),
  "6.3-2": item(
    "¿Cómo obtengo el estado Activ?",
    j([
      "Obtienes el estado Activ después de comprar tu primer",
      "panel.",
    ]),
    ["obtener Activ", "primer panel"],
  ),
  "6.3-3": item(
    "¿El estado Activ es temporal o permanente?",
    j([
      "El estado Activ es permanente. Una vez obtenido,",
      "permanece con el usuario.",
    ]),
    ["Activ permanente", "estado Activ"],
  ),
  "6.3-4": item(
    "¿Se conserva el estado Activ si un panel pasa a Archive?",
    j([
      "Sí. El estado Activ se conserva aunque un panel pase",
      "más tarde a Archive.",
    ]),
    ["Activ y Archive", "Archive"],
  ),
  "6.3-5": item(
    "¿Por qué es importante el estado Activ?",
    j([
      "El estado Activ muestra que ya entraste por completo",
      "en el ciclo del proyecto y afecta varios escenarios",
      "del juego.",
    ]),
    ["Activ importante", "estado"],
  ),
  "8.3-1": item(
    "¿Qué son las Lotteries en EFHC?",
    j([
      "Las Lotteries son eventos del juego dentro del",
      "proyecto donde los usuarios compran boletos y",
      "participan en la elección del ganador.",
    ]),
    ["Lotteries", "boletos"],
  ),
  "8.3-2": item(
    "¿Qué Lotteries hay en el proyecto?",
    j([
      "En el proyecto existen las Lotteries de 100 EFHC y las",
      "Lotteries de VIP NFT EFHC.",
    ]),
    ["tipos Lotteries", "100 EFHC"],
  ),
  "8.3-3": item(
    j([
      "¿En qué se diferencian las Lotteries de 100 EFHC y VIP",
      "NFT EFHC?",
    ]),
    j([
      "La diferencia está en el premio final: en una recibes",
      "EFHC y en la otra un VIP NFT EFHC.",
    ]),
    ["diferencia Lotteries", "VIP NFT"],
  ),
  "8.3-4": item(
    "¿Cuánto cuesta un boleto?",
    "Un boleto cuesta 1 EFHC.",
    ["precio boleto", "1 EFHC"],
  ),
  "8.3-5": item(
    "¿Cuántos boletos puede tener una Lotteries?",
    j([
      "La Lotteries de 100 EFHC tiene 200 boletos. La",
      "Lotteries VIP NFT tiene 3000 boletos.",
    ]),
    ["cantidad boletos", "200", "3000"],
  ),
  "8.3-6": item(
    "¿Cuándo se inicia una Lotteries?",
    j([
      "Una Lotteries se desarrolla dentro de su grupo de",
      "boletos y termina cuando se venden todos. Después",
      "empieza automáticamente un nuevo sorteo.",
    ]),
    ["inicio Lotteries", "sorteo"],
  ),
  "8.3-7": item(
    "¿Cómo se determina al ganador?",
    j([
      "El ganador se determina automáticamente cuando se",
      "compra el último boleto y se activa el sorteo.",
    ]),
    ["ganador", "automático"],
  ),
  "8.3-8": item(
    "¿Qué pasa después de elegir al ganador?",
    j([
      "Después de elegir al ganador, el premio se acredita o",
      "se entrega y el usuario ve el resultado dentro del",
      "proyecto.",
    ]),
    ["después ganador", "premio"],
  ),
  "8.3-9": item(
    "¿Cuál es el premio en la Lotteries de 100 EFHC?",
    j([
      "El premio en la Lotteries de 100 EFHC es de 100 EFHC",
      "al saldo bonus.",
    ]),
    ["premio 100 EFHC", "bonus"],
  ),
  "8.3-10": item(
    "¿Cuál es el premio en la Lotteries NFT VIP EFHC?",
    "El premio en la Lotteries NFT VIP EFHC es un VIP NFT EFHC.",
    ["premio VIP NFT", "Lotteries NFT"],
  ),
  "8.3-11": item(
    "¿Por qué se necesita Wallet en la Lotteries NFT?",
    j([
      "Porque para emitir un NFT se necesita una Wallet",
      "conectada a la que se pueda enviar el premio.",
    ]),
    ["Wallet para NFT", "premio NFT"],
  ),
  "8.3-12": item(
    "¿Cómo se entrega el NFT después de ganar?",
    j([
      "Después de ganar, el NFT se entrega a la Wallet",
      "conectada del usuario según las reglas del proyecto.",
    ]),
    ["entrega NFT", "Wallet"],
  ),
  "8.3-13": item(
    "¿Dónde se muestra una ganancia?",
    j([
      "La ganancia se muestra en la zona relacionada con el",
      "premio: saldo, parte ligada a Wallet o estado del",
      "usuario.",
    ]),
    ["ganancia visible", "dónde"],
  ),
  "8.3-14": item(
    "¿Por qué no veo el resultado de las Lotteries?",
    j([
      "Actualiza la pantalla y revisa la sección",
      "correspondiente. A veces la interfaz necesita algo de",
      "tiempo para mostrar el resultado.",
    ]),
    ["resultado ausente", "Lotteries"],
  ),
  "8.4-1": item(
    "¿Qué es la sección Ads?",
    j([
      "Ads es una sección de usuario con ofertas o acciones",
      "que pueden dar ventajas o resultados adicionales",
      "dentro del proyecto.",
    ]),
    ["Ads", "ofertas"],
  ),
  "8.4-2": item(
    "¿Qué aporta esta sección al usuario?",
    j([
      "Puede abrir acciones adicionales, ofertas u",
      "oportunidades útiles dentro del contexto actual del",
      "proyecto.",
    ]),
    ["utilidad Ads", "ofertas"],
  ),
  "8.4-3": item(
    "¿Por qué puede no mostrarse una oferta?",
    j([
      "Algunas ofertas dependen de la disponibilidad, la",
      "región, la pantalla o el estado actual dentro del",
      "proyecto.",
    ]),
    ["oferta ausente", "Ads"],
  ),
  "8.4-4": item(
    j([
      "¿Qué hacer si la acción se realizó pero no aparece el",
      "resultado?",
    ]),
    j([
      "Actualiza la pantalla y revisa la sección relacionada",
      "con la acción. Si no aparece nada, espera un poco y",
      "vuelve a revisar.",
    ]),
    ["resultado ausente", "acción Ads"],
  ),
  "9.2-2": item(
    j([
      "¿En qué se diferencia una compra interna de una compra",
      "por Wallet?",
    ]),
    j([
      "Una compra interna usa tus EFHC dentro del bot. Una",
      "compra por Wallet está ligada a una confirmación",
      "externa mediante Wallet.",
    ]),
    ["compra interna", "compra wallet"],
  ),
  "9.2-4": item(
    "¿Por qué no veo el resultado justo después del pago?",
    j([
      "Algunas operaciones necesitan un poco de tiempo para",
      "actualizarse en la interfaz. Actualiza la pantalla y",
      "revisa el historial o la sección necesaria.",
    ]),
    ["resultado pago", "no inmediato"],
  ),
  "10.1-5": item(
    "¿Cuántos niveles de logro hay en el progreso energético?",
    j([
      "En el progreso energético del proyecto hay 12 niveles.",
      "Muestran el camino desde los primeros pasos hasta la",
      "cima del progreso general.",
    ]),
    ["12 niveles", "progreso energético"],
  ),
  "10.1-6": item(
    "¿Qué significan los niveles de logro en palabras simples?",
    j([
      "Son al mismo tiempo tu camino energético, tu progreso",
      "y tu imagen dentro del proyecto. Muestran cuánto has",
      "avanzado en la línea de energía limpia.",
    ]),
    ["significado niveles", "progreso"],
  ),
  "10.1-7": item(
    j([
      "¿Por qué los nombres de los niveles están ligados a la",
      "ecología y al planeta?",
    ]),
    j([
      "Porque todo el progreso de EFHC está ligado a la",
      "energía limpia, a la transición verde y al aporte al",
      "futuro del planeta.",
    ]),
    ["nombres niveles", "ecología"],
  ),
  "10.2-1": item(
    "¿Qué significa el nivel Eco Initiate?",
    j([
      "0 kWh. Tu primer panel está instalado y listo para",
      "trabajar. Das el paso principal para convertirte en un",
      "productor independiente de energía limpia.",
    ]),
    ["Eco Initiate", "0 kWh"],
  ),
  "10.2-2": item(
    "¿Qué significa el nivel Hope Bringer?",
    j([
      "100 kWh. Ya no eres solo un participante, sino un",
      "portador de esperanza para la transición verde y el",
      "comienzo de un camino sostenible.",
    ]),
    ["Hope Bringer", "100 kWh"],
  ),
  "10.2-3": item(
    "¿Qué significa el nivel Energy Seeker?",
    j([
      "300 kWh. Buscas energía no solo para ti, sino para un",
      "futuro donde las fuentes limpias importen más que los",
      "recursos agotables.",
    ]),
    ["Energy Seeker", "300 kWh"],
  ),
  "10.2-4": item(
    "¿Qué significa el nivel Nature's Voice?",
    j([
      "600 kWh. Tu progreso suena como la voz de la propia",
      "naturaleza y recuerda que la Tierra merece protección",
      "y respeto.",
    ]),
    ["Nature's Voice", "600 kWh"],
  ),
  "10.2-5": item(
    "¿Qué significa el nivel Earth Ally?",
    j([
      "1000 kWh. Te conviertes en aliado de la Tierra y",
      "demuestras con acciones que cada aporte energético",
      "puede cambiar el estado del planeta.",
    ]),
    ["Earth Ally", "1000 kWh"],
  ),
  "10.2-6": item(
    "¿Qué significa el nivel Climate Fighter?",
    j([
      "2000 kWh. Ya es una contribución visible en la lucha",
      "contra la crisis climática y por un futuro más limpio",
      "y seguro.",
    ]),
    ["Climate Fighter", "2000 kWh"],
  ),
  "10.2-7": item(
    "¿Qué significa el nivel Green Sentinel?",
    j([
      "3500 kWh. Te conviertes en un guardián verde que",
      "protege el camino de la energía sostenible e inspira a",
      "otros al progreso limpio.",
    ]),
    ["Green Sentinel", "3500 kWh"],
  ),
  "10.2-8": item(
    "¿Qué significa el nivel Planet Defender?",
    j([
      "5000 kWh. Tu aporte adquiere un peso real y se",
      "convierte en símbolo de defensa del planeta mediante",
      "acciones energéticas concretas.",
    ]),
    ["Planet Defender", "5000 kWh"],
  ),
  "10.2-9": item(
    "¿Qué significa el nivel Eco Champion?",
    j([
      "7500 kWh. Alcanzas un nivel en el que tu progreso",
      "sirve de ejemplo de responsabilidad, estabilidad y",
      "crecimiento verde.",
    ]),
    ["Eco Champion", "7500 kWh"],
  ),
  "10.2-10": item(
    "¿Qué significa el nivel Planet Saver?",
    j([
      "10000 kWh. Este nivel muestra que tu camino ya se",
      "parece a un verdadero rescate del planeta a través del",
      "desarrollo de energía limpia.",
    ]),
    ["Planet Saver", "10000 kWh"],
  ),
  "10.2-11": item(
    "¿Qué significa el nivel Green Commander?",
    j([
      "15000 kWh. Diriges tu progreso como un comandante del",
      "futuro verde y muestras la fuerza de una contribución",
      "sistemática.",
    ]),
    ["Green Commander", "15000 kWh"],
  ),
  "10.2-12": item(
    "¿Qué significa el nivel Guardian of Earth?",
    j([
      "20000+ kWh. Es el nivel más alto del proyecto y el",
      "símbolo de un usuario cuyo camino energético se ha",
      "convertido en protección de la Tierra.",
    ]),
    ["Guardian of Earth", "20000+ kWh"],
  ),
  "12.1-5": item(
    "¿Cómo usar este FAQ?",
    j([
      "Primero elige la sección según el sentido de la",
      "pantalla: Balances, Wallet, Panels, Exchange,",
      "Referrals o Shop. Luego abre la subsección adecuada y",
      "busca allí la pregunta.",
    ]),
    ["usar FAQ", "secciones"],
  ),
  "12.1-6": item(
    "¿Por qué el FAQ está dividido en secciones y subsecciones?",
    j([
      "Porque el bot tiene muchas pantallas y acciones",
      "distintas. Esta estructura ayuda a encontrar más",
      "rápido una respuesta con palabras familiares de la",
      "interfaz.",
    ]),
    ["secciones", "subsecciones"],
  ),
  "12.1-7": item(
    j([
      "¿Para qué sirven las preguntas relacionadas bajo la",
      "respuesta?",
    ]),
    j([
      "Las preguntas relacionadas ayudan a pasar rápido a un",
      "tema cercano sin empezar una búsqueda nueva.",
    ]),
    ["preguntas relacionadas", "related"],
  ),
  "12.2-1": item(
    "¿Qué es la sección «Perfil/Ajustes»?",
    j([
      "Es la sección donde ves tus estados principales y",
      "encuentras los ajustes personales de la interfaz del",
      "bot.",
    ]),
    ["perfil", "ajustes"],
  ),
  "12.2-2": item(
    "¿Qué se muestra en la parte superior de Perfil/Ajustes?",
    j([
      "Allí suelen mostrarse tus datos clave, estados",
      "importantes y elementos centrales de la interfaz de tu",
      "cuenta.",
    ]),
    ["perfil arriba", "estados"],
  ),
  "12.2-3": item(
    "¿Qué puedo ajustar en «Perfil/Ajustes»?",
    j([
      "Allí puedes gestionar el idioma, elementos",
      "relacionados con Wallet, entradas FAQ y otros ajustes",
      "disponibles de la interfaz.",
    ]),
    ["ajustar", "perfil"],
  ),
  "12.2-4": item(
    "¿Qué hay en la sección «Soporte e información»?",
    j([
      "Allí encontrarás espacios útiles con explicaciones,",
      "FAQ, consejos y otra información sobre el proyecto y",
      "la interfaz.",
    ]),
    ["soporte", "información"],
  ),
});
