# Updating EFHC

Use complete release archives, never copy individual files over the active
version:

```bash
sudo /opt/efhc/current/scripts/release/update.sh \
  /opt/efhc/packages/EFHC_Bot_vNNN_NN.zip \
  /opt/efhc/packages/EFHC_Bot_vNNN_NN.zip.sha256
```

Intermediate development archive numbers may be skipped. Acceptance is based on
`compatible_source_range`, the installed Alembic revision, a complete cumulative
migration path, target environment preflight and a verified pre-update backup.
See `UPDATE_AND_ROLLBACK.md` for the full contract and recovery procedure.
