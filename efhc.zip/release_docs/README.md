# EFHC Bot — release candidate v172.56

Corrective-пакет цикла `1639` после exact CI `83583696254`.

- Telegram Bot, Telegram WebApp и TON продолжают создавать новые accounts
  только через `AccountRegistrationService`;
- PostgreSQL/Alembic, static/type/security gates и production frontend build
  exact `v172.55` прошли;
- pytest: `3219 passed`, `28 skipped`, один failure в qualification fixture;
- production runtime, schema и financial semantics не менялись;
- fixture теперь явно выполняет `UPDATE users.global_id` через `flush()` до
  вставки `ReferralCode`, сохраняя строгий существующий FK;
- Chromium был корректно пропущен после pytest failure, поэтому fresh PNG
  отсутствуют;
- цикл `1640` не начат.

Fresh exact-head GitHub CI для `EFHC_Bot_v172_56.zip` обязателен.
Production readiness: `false`.

Первый production-запуск выполняется только командой:

```bash
./scripts/release/deploy.sh
```

Do not create database tables manually. Alembic и release bootstrap являются
единственным каноническим путём подготовки базы.
