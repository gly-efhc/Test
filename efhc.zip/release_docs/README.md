<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot release v173.06


Статус пакета: local release candidate, exact-head GitHub CI required,
production release ready = false.

---

# Восстановленный deployment README v171.89

# EFHC production release v171.89

This is a complete provider-independent production archive built from the exact
v171.89 development HEAD. It supports clean installation and cumulative update
from every source version and database revision declared in
`release-manifest.json`.
The v171.89 Activ repair makes `referral_links.activated_at` the sole
activity source. Current panel count remains informational and cannot
reverse the permanent first-panel activation event.


Start with `INSTALL.md` for a clean VPS or `UPDATE_AND_ROLLBACK.md` for an
existing installation. Do not place production `.env`, secrets, database dumps,
logs or user data inside a release directory or ZIP.


The packaged Referrals route preserves immutable first-creation attribution,
`0.1 EFHCb` direct-referral rewards and all five one-time monetary Lvl rewards.
Its public page includes next-Lvl progress, invite/share tools, inline
Active/Inactive tabs and backend-owned cumulative totals (`Lvl 1 = 2 EFHCb`).

This release also repairs the audited referral data boundary: every join and
count uses Telegram `tg_id`, Active/Inactive filtering and cursor pagination run
in PostgreSQL, archived panels preserve permanent activation, user compatibility
routes are self-only, Admin totals include direct and Lvl rewards, and reward
idempotency is re-read after locks for concurrent threshold crossings.

Current evidence boundary: local release candidate. Fresh exact-HEAD GitHub CI
and later real VPS/live acceptance are still required.


Canonical clean-start command:

```bash
./scripts/release/deploy.sh
```

Do not document plain `docker compose up -d` as a complete production bootstrap.

Do not create database tables manually. Alembic migrations and the release
bootstrap are the only supported schema-creation path.

