# EFHC Bot — release candidate v172.52

Пакет закрывает static findings exact `v172.51`, квалифицирует ядро
цикла `1636` и реализует Telegram Bot migration цикла `1637`.

- новый Bot account создаётся через `AccountRegistrationService`;
- `User`, referral attribution и Telegram `UserIdentity` атомарны;
- late referral binding существующего account запрещён;
- WebApp и TON пока используют прежние paths;
- schema, migration `0001`, экономика и public routes не менялись.

Fresh exact-head GitHub CI для `EFHC_Bot_v172_52.zip` обязателен.
Production readiness: `false`.
