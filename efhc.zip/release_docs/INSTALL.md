# Установка EFHC

1. Подготовьте одну production VPS и установите обязательные host prerequisites штатным `scripts/release/install_server.sh`.
2. Возьмите канонический owner-facing шаблон `.env.example`, заполните его по русским комментариям и сохраните production-конфигурацию как `/opt/efhc/shared/.env`. Установите права `chmod 600 /opt/efhc/shared/.env`. Версию EFHC и Docker image tags вручную не вводите: они выводятся из root `VERSION`.
3. Для Telegram runtime нужны только обычные credentials существующего EFHC-бота (`TELEGRAM_BOT_TOKEN`, webhook secret/URL и Admin recipient, если используются уведомления). Backup-specific Telegram credentials и Local Telegram Bot API Server не требуются.
4. Backup key создаётся один раз initial installer. Сразу сохраните отдельную off-VPS копию key; runtime не регенерирует потерянный key.
5. Выполните штатный deploy. Existing production schema перед database-changing operation требует successful локальный encrypted pre-update backup.
6. После установки проверьте canonical `/api/health`, `/api/health/db`, `/api/health/runtime`, backup timer и наличие свежего `.enc` в `/opt/efhc/backups/encrypted`.
7. Для owner off-VPS copy скачайте нужный encrypted backup на ПК или смартфон по SSH/SFTP. Telegram для database backup не используется.

EFHC V1 не требует второй VPS или отдельный monitoring host.
