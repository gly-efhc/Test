# Clean installation

1. Install Docker Engine, the Docker Compose plugin, Python 3, OpenSSL and
   systemd.
2. Copy the verified release ZIP and its external `.sha256` file to
   `/opt/efhc/packages`.
3. Extract the release into `/opt/efhc/releases/TARGET_VERSION`.
4. Prepare the persistent environment file outside the release directory:

```bash
sudo install -d -m 700 /opt/efhc/shared
sudo install -d -m 755 /opt/efhc/releases

sudo cp \
  /opt/efhc/releases/TARGET_VERSION/.env.example \
  /opt/efhc/shared/.env

sudo chown root:root /opt/efhc/shared/.env
sudo chmod 600 /opt/efhc/shared/.env

sudo ln -sfn \
  /opt/efhc/shared/.env \
  /opt/efhc/releases/TARGET_VERSION/.env
```

5. Fill every required value in `/opt/efhc/shared/.env` and run:

```bash
cd /opt/efhc/releases/TARGET_VERSION
sudo ./scripts/release/deploy.sh
```

For a VPS prepared before DNS switch use:

```bash
sudo ./scripts/release/deploy.sh --skip-public-checks --skip-webhook
```

The deploy remains fail-closed for environment, Compose, PostgreSQL, Alembic,
44 ORM tables, seed, backend, scheduler, frontend and proxy local healthchecks.
