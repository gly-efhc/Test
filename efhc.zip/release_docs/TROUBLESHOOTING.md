# Troubleshooting

- `.env permissions ... got 777`: verify the release `.env` is a symlink to
  exactly `/opt/efhc/shared/.env`; the resolved file must be owned by the
  expected user and have mode `600` or `400`.
- `another EFHC update is already running`: inspect the active process holding
  `/opt/efhc/update.lock`; do not remove the lock while an update is active.
- source version rejected: same-version install, downgrade or a source below
  `minimum_supported_source_version` is not allowed. Adjacent numbering is not
  required.
- database revision rejected: compare `efhc_core.alembic_version` with
  `supported_database_revisions` and verify the archive contains the complete
  migration chain to `target_database_revision`.
- checksum failure: do not extract or retry with a different sidecar; replace
  the package from the trusted delivery source.
- migration failure: keep the new release inactive, inspect
  `/opt/efhc/shared/update-state.json` and the matching update log. Do not
  silently restore PostgreSQL or start an incompatible old backend.
- public check pending: complete DNS/HTTPS first, then run `verify_public.sh`
  and `set_telegram_webhook.sh`.
