# Deployment contract

The production chain is:

```text
db → migrate → backend + scheduler → frontend → proxy
```

A clean deploy is started only with `./scripts/release/deploy.sh`. The script
runs environment preflight, Compose validation, build, database health wait,
Alembic upgrade, database validation, idempotent system seed, service health
checks, optional public verification, webhook configuration and final report.

`--skip-public-checks` and `--skip-webhook` are allowed only for pre-DNS VPS
preparation and do not skip local validation. `production_release_ready` remains
false until real clean-start and repeated-deploy acceptance succeeds.
