# Production deployment EFHC

Active deployment authority — существующий Docker Compose release contour. Kubernetes/Helm/Terraform/Ansible не требуются и автоматически не вводятся.

Перед deployment:

1. заполнить persistent `.env` и выполнить `preflight_env.py`;
2. убедиться, что owner `.env` прошёл production preflight;
3. проверить recipient probe;
4. для existing schema обязательно создать и проверить локальный encrypted recovery backup;
5. только затем запускать migrations/start/health/public verification.

`update.sh` для existing production БД блокирует update, если собственный pre-update encrypted backup не был успешно создан и проверен. Опасный rollback, требующий restore БД, автоматически не выполняется.

После deployment проверяются PostgreSQL, backend, scheduler, frontend, proxy, public HTTPS, webhook и затем устанавливаются/обновляются DevOps timers.
