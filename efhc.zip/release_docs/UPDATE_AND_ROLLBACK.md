# EFHC production update and rollback

## 1. Permanent VPS layout

```text
/opt/efhc/
├── current  -> /opt/efhc/releases/<active-version>
├── previous -> /opt/efhc/releases/<previous-version>
├── releases/
├── shared/
│   ├── .env
│   ├── secrets/backup-passphrase
│   ├── logs/
│   └── update-state.json
├── backups/
│   ├── postgres/
│   ├── bundles/
│   └── manifests/
├── packages/
└── update.lock
```

Code is versioned. Environment, secrets, update state, packages and backups are
persistent and are never stored inside a release directory.

## 2. Cumulative compatibility policy

Release archive numbers do not have to be installed one by one. Intermediate
development builds may be skipped. The updater accepts a direct jump only when:

- the installed application is older than the target and not below the target's
  `minimum_supported_source_version`;
- the current PostgreSQL Alembic revision appears in
  `supported_database_revisions`;
- the target archive contains a complete migration chain from the current
  revision to `target_database_revision`;
- the target environment passes fail-closed preflight;
- a verified pre-update PostgreSQL dump is created before database changes.

Same-version installation, downgrade, unsupported database state and incomplete
migration paths are rejected.

## 3. Package placement

```bash
sudo install -d -m 700 /opt/efhc/packages
sudo cp TARGET_RELEASE.zip /opt/efhc/packages/
sudo cp TARGET_RELEASE.zip.sha256 /opt/efhc/packages/
```

The external `.sha256` verifies the ZIP itself. Internal `SHA256SUMS` verifies
all extracted files. Both checks are mandatory.

## 4. Update command

```bash
sudo /opt/efhc/current/scripts/release/update.sh \
  /opt/efhc/packages/TARGET_RELEASE.zip \
  /opt/efhc/packages/TARGET_RELEASE.zip.sha256
```

The updater locks `/opt/efhc/update.lock`, validates the package, extracts into a
private staging directory, validates source and database compatibility, creates
a verified backup, deploys the target without changing `current`, checks all
local services, then switches `previous` and `current` atomically.

Use `--replace-failed-release` only for a previously failed, inactive target
folder after reviewing its state.

## 5. Preparing a new VPS before DNS switch

```bash
sudo ./scripts/release/deploy.sh --skip-public-checks --skip-webhook
```

This skips only DNS-dependent public verification and Telegram webhook setup.
Database validation, migrations, seed, container healthchecks and local API
checks remain mandatory. The report must show:

```text
local_deployment=PASS
public_verification=PENDING
telegram_webhook=PENDING
```

After DNS is switched:

```bash
sudo ./scripts/release/verify_public.sh
sudo ./scripts/release/set_telegram_webhook.sh
```

## 6. Verification

```bash
readlink -f /opt/efhc/current
readlink -f /opt/efhc/previous
cd /opt/efhc/current
docker compose ps
sudo cat /opt/efhc/shared/update-state.json
sudo systemctl status efhc-backup.timer --no-pager
sudo systemctl list-timers efhc-backup.timer --no-pager
```

Update logs are written under `/opt/efhc/shared/logs/`. They must not contain
secrets, tokens, DSNs with passwords or backup passphrases.

## 7. Application rollback

```text
Rollback mode: ONE_STEP_BACK_ONLY
Return forward: update.sh
```

`rollback_release.sh` performs one emergency return to the previous working
application set. Returning forward is performed by running `update.sh` again; a
second rollback invocation must not be used as a forward switch.

```bash
sudo /opt/efhc/current/scripts/release/rollback_release.sh --confirm
```

Rollback changes backend, scheduler, frontend, proxy configuration and release
scripts as one application set. It never automatically restores PostgreSQL.
The target manifest must explicitly permit application rollback without a
database restore. If the migration is not backward-compatible, services remain
stopped and a separate manual database recovery plan is required.

## 8. Backup timer

The systemd service always uses:

```text
WorkingDirectory=/opt/efhc/current
ExecStart=/opt/efhc/current/scripts/release/run_scheduled_backup.sh
```

Backups are written to `/opt/efhc/backups`; the passphrase remains at
`/opt/efhc/shared/secrets/backup-passphrase` and is created only once.

Manual check:

```bash
sudo systemctl start efhc-backup.service
sudo systemctl status efhc-backup.service --no-pager
```

## 9. Cleanup

No release is deleted automatically during update or rollback. Preview cleanup:

```bash
sudo /opt/efhc/current/scripts/release/cleanup_old_releases.sh \
  --keep 3 --dry-run
```

Execute only after reviewing the plan:

```bash
sudo /opt/efhc/current/scripts/release/cleanup_old_releases.sh \
  --keep 3 --confirm
```

`current`, `previous`, packages and backups are never removed by this command.
