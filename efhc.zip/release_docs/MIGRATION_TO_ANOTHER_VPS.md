# Migration to another VPS

1. Скопируйте с old provider точный `EFHC_Bot_vNNN_NN.zip` + `.sha256`,
   canonical `*.tar.gz.enc` + `.enc.sha256`; backup passphrase переносится
   отдельно по owner-controlled каналу.
2. Подготовьте `/opt/efhc/shared`, `/opt/efhc/backups`, `/opt/efhc/packages` и
   `/opt/efhc/releases` на новой VPS.
3. Проверяйте release SHA-256 до extraction. Recovery artifact без корректного
   `.enc.sha256` либо explicit `--expected-sha256` должен быть отклонён.
4. Выполните `recover_encrypted_backup.sh ... --confirm`; проверьте
   `.env.recovered` и validated PostgreSQL dump. Recovery helper не выполняет
   production restore автоматически.
5. Установите production env и существующий backup passphrase с mode `600`.
6. Выполните отдельный fail-closed `restore_postgres.sh <dump> --confirm`.
   Current schema contract: Alembic `0001`, 52 ORM business tables
   (`45 efhc_core + 7 efhc_admin`), 53 physical tables включая
   `efhc_core.alembic_version`.
7. Deploy release с `--skip-public-checks --skip-webhook`, пока DNS ещё у
   прежнего provider.
8. После local verification переключите DNS, выполните public verification и
   установите Telegram webhook.

Процедура не должна зависеть от provider-specific database, control panel или
filesystem feature. Raw dump/plaintext env не являются retained off-provider
backup contract; canonical recovery unit — encrypted `.tar.gz.enc`.
