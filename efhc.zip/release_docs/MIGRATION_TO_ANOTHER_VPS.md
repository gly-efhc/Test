# Migration to another VPS

1. Copy a verified PostgreSQL dump, release ZIP, external checksum and encrypted
   production environment backup off the old provider.
2. Prepare `/opt/efhc/shared`, `/opt/efhc/backups`, `/opt/efhc/packages` and
   `/opt/efhc/releases` on the new VPS.
3. Restore `/opt/efhc/shared/.env` and the existing backup passphrase with mode
   `600`.
4. Restore PostgreSQL fail-closed and validate Alembic head, both schemas and all
   44 ORM tables.
5. Deploy the release using `--skip-public-checks --skip-webhook`.
6. Switch DNS, run public verification and set the Telegram webhook.

The procedure must not depend on a VPS provider-specific database, panel or
filesystem feature.
