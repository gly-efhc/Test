# EFHC DevOps

Active topology: **одна production VPS**. На ней работают PostgreSQL, Backend, Scheduler, Frontend, Proxy, DevOps/Autopilot и local newest-10 encrypted backups. Обязательная вторая VPS/external-monitor host отсутствует.

Canonical health endpoints:

- `/api/health`;
- `/api/health/db`;
- `/api/health/runtime`.

Backup:

- manual/local generation: `/opt/efhc/current/scripts/release/create_encrypted_backup.sh --label manual`;
- daily timer создаёт canonical encrypted `.enc` и сохраняет newest 10;
- database backup в Telegram не выполняется;
- владелец скачивает `.enc`/`.sha256` на ПК или смартфон по SSH/SFTP.

Autopilot имеет bounded restart allowlist только `backend`, `scheduler`, `frontend`, `proxy`. При активном update/rollback OS-level lock любые Autopilot mutations запрещены; разрешены только observation/diagnostics.

Diagnostic bundle не содержит `.env`, backup key/passphrase, Telegram token, API secrets, Authorization headers, private keys, seed phrases и private user data.
