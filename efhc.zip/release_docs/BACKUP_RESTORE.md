# Backup / Restore

## Каноническая модель

EFHC создаёт один canonical encrypted recovery artifact `.tar.gz.enc` на generation. Raw PostgreSQL dump и незашифрованный bundle используются только как staging material и после успешного шифрования не являются retained backups.

Production VPS хранит rolling window **10 последних** encrypted generations в `/opt/efhc/backups/encrypted` вместе с небольшими `.sha256` и `.meta.json` sidecars. Generation 11+ удаляется локально по count, а не по возрасту.

**Database backup в Telegram не используется.** Для backup не нужны `TELEGRAM_BACKUP_CHAT_ID`, `TELEGRAM_API_ID`, `TELEGRAM_API_HASH`, Local Telegram Bot API Server, delivery receipt или retry queue.

## Сохранение на ПК

1. Выберите canonical `.tar.gz.enc` на VPS.
2. Подключитесь к production VPS по SSH/SFTP с owner-controlled учётной записью.
3. Скачайте `.enc` и одноимённый `.enc.sha256` из `/opt/efhc/backups/encrypted` на ПК.
4. Проверьте SHA-256 локального файла.
5. Храните backup passphrase отдельно от backup-файла.

Пример выполняется **на ПК**:

```bash
scp owner@<production-host>:/opt/efhc/backups/encrypted/<точное-имя>.tar.gz.enc ./
scp owner@<production-host>:/opt/efhc/backups/encrypted/<точное-имя>.tar.gz.enc.sha256 ./
```

## Сохранение на смартфон

Используйте SFTP-клиент, подключённый по SSH к production VPS. Скачивайте только выбранные `.tar.gz.enc` и `.enc.sha256` из `/opt/efhc/backups/encrypted`. Никакой отдельный публичный HTTP endpoint для database backup EFHC не поднимает.

## Backup key

Backup passphrase создаётся только при explicit initial installation. Если key отсутствует в уже initialized installation, backup/update fail closed; автоматическая регенерация запрещена. Владелец обязан иметь отдельную off-VPS копию key.

## Manual recovery

`recover_encrypted_backup.sh` принимает `.tar.gz.enc` и fail-closed требует `.enc.sha256` либо explicit `--expected-sha256`; затем проверяет ciphertext checksum, расшифровывает whole bundle, проверяет `MANIFEST.sha256` и PostgreSQL dump через `pg_restore --list`, подготавливает recovered environment и **не выполняет production restore автоматически**.

Production database restore остаётся отдельным ручным fail-closed действием.

## Restore drill

Monthly drill использует latest canonical `.enc`, расшифровывает его во временную директорию и восстанавливает dump в отдельный temporary PostgreSQL container/volume. Production PostgreSQL cluster/volume не является restore target drill.
