# Backup and restore

Persistent paths:

```text
BACKUP_DIR=/opt/efhc/backups
EFHC_BACKUP_PASSPHRASE_FILE=/opt/efhc/shared/secrets/backup-passphrase
```

The passphrase is generated once with mode `600` and is never overwritten,
logged or packaged. PostgreSQL dumps are stored under `backups/postgres`,
bundle outputs under `backups/bundles`, and manifests/checksums under
`backups/manifests`.

Before every database-changing update the updater requires a non-empty dump,
successful `pg_restore --list` and checksum. Restore is a separate explicit,
fail-closed operation; application rollback does not restore the database.
Keep offsite copies of dumps, manifests, release packages, checksums and an
encrypted production environment backup.
