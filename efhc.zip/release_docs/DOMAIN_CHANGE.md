# Domain change

Update only the canonical domain variables in `/opt/efhc/shared/.env`, run the
domain-change/preflight tooling from `/opt/efhc/current`, rebuild affected
public configuration, restart the required services and verify HTTPS, public API
and `/api/tg/webhook`.

For migration before DNS switch deploy with `--skip-public-checks --skip-webhook`.
After DNS resolves to the new VPS run `verify_public.sh`, then
`set_telegram_webhook.sh`. Never introduce `/tg/webhook`; the only production
path is `/api/tg/webhook`.
