#!/usr/bin/env python3
"""
CI linter for docs/audits/audits_index.json.

Rules (SSOT):
- JSON must be valid and match minimal schema expectations.
- audit_id unique.
- topic/status must be allowed.
- md/raw paths must exist.
- superseded links must be consistent.
- ACTIVE uniqueness enforced by (topic, scope_key) if scope_key is set,
  else by topic alone.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED_TOPICS = {
  "db-inventory","db-ssot","routes-inventory","admin-surface",
  "ci-failures","guards-ssot","security","performance","data-migration",
}
ALLOWED_STATUS = {"ACTIVE","SUPERSEDED","ARCHIVED"}

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "docs" / "audits" / "audits_index.json"
SCHEMA = ROOT / "docs" / "audits" / "audits.schema.json"

def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(2)

def warn(msg: str) -> None:
    print(f"WARN: {msg}", file=sys.stderr)

def load_json(p: Path) -> object:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        die(f"Failed to parse JSON {p}: {e}")
    raise AssertionError

def main() -> None:
    if not INDEX.exists():
        die("docs/audits/audits_index.json is missing")

    data = load_json(INDEX)
    if not isinstance(data, dict):
        die("audits_index.json must be a JSON object")

    for k in ("schema_version","generated_at","project","topics","audits"):
        if k not in data:
            die(f"Missing top-level key: {k}")

    topics = data["topics"]
    if not isinstance(topics, list) or not topics:
        die("topics must be a non-empty list")

    unknown_topics = sorted(set(topics) - ALLOWED_TOPICS)
    if unknown_topics:
        die(f"topics contains unknown values: {unknown_topics}")

    audits = data["audits"]
    if not isinstance(audits, list) or not audits:
        die("audits must be a non-empty list")

    ids = []
    by_id = {}
    active_key = {}

    for i, a in enumerate(audits):
        if not isinstance(a, dict):
            die(f"audits[{i}] must be an object")

        for k in ("audit_id","date","version","topic","status","superseded_by",
                  "supersedes","title","summary","files","sources"):
            if k not in a:
                die(f"audit missing key {k}: audits[{i}]")

        aid = a["audit_id"]
        if not isinstance(aid, str) or not aid:
            die(f"Invalid audit_id at audits[{i}]")
        if aid in by_id:
            die(f"Duplicate audit_id: {aid}")

        ids.append(aid)
        by_id[aid] = a

        topic = a["topic"]
        if topic not in topics:
            die(f"audit {aid}: topic {topic} not present in topics[]")

        status = a["status"]
        if status not in ALLOWED_STATUS:
            die(f"audit {aid}: invalid status {status}")

        scope_key = a.get("scope_key")
        if scope_key is not None and not isinstance(scope_key, str):
            die(f"audit {aid}: scope_key must be string or null")

        files = a["files"]
        if not isinstance(files, dict):
            die(f"audit {aid}: files must be object")
        md = files.get("md")
        raw = files.get("raw")
        if not isinstance(md, str) or not md:
            die(f"audit {aid}: files.md must be string")
        md_path = ROOT / md
        if not md_path.exists():
            die(f"audit {aid}: md file missing: {md}")
        if raw is not None:
            if not isinstance(raw, str) or not raw:
                die(f"audit {aid}: files.raw must be string or null")
            raw_path = ROOT / raw
            if not raw_path.exists():
                die(f"audit {aid}: raw file missing: {raw}")

        sources = a["sources"]
        if not isinstance(sources, list) or len(sources) < 1:
            die(f"audit {aid}: sources must be non-empty list")
        for s in sources:
            if not isinstance(s, dict):
                die(f"audit {aid}: source item must be object")
            if "type" not in s or "ref" not in s:
                die(f"audit {aid}: each source needs type/ref")
            if s["type"] not in {"CODE","MIGRATION","SQL","LOG","CI","DOC"}:
                die(f"audit {aid}: bad source type {s['type']}")

        # superseded consistency
        if status == "SUPERSEDED":
            if not a["superseded_by"]:
                die(f"audit {aid}: status SUPERSEDED requires superseded_by")
        else:
            if a["superseded_by"] not in (None, "null"):
                warn(f"audit {aid}: superseded_by should be null for status {status}")

        # ACTIVE uniqueness
        if status == "ACTIVE":
            k = (topic, scope_key) if scope_key else (topic, None)
            if k in active_key:
                die(f"Multiple ACTIVE audits for key {k}: {active_key[k]} and {aid}")
            active_key[k] = aid

    # resolve links
    for aid, a in by_id.items():
        sb = a.get("superseded_by")
        if sb and sb != "null":
            if sb not in by_id:
                die(f"audit {aid}: superseded_by points to missing audit_id {sb}")
            # reverse link
            sup = by_id[sb].get("supersedes", [])
            if aid not in sup:
                die(f"audit {aid}: {sb} must list it in supersedes[]")

        sup_list = a.get("supersedes", [])
        if not isinstance(sup_list, list):
            die(f"audit {aid}: supersedes must be list")
        for old in sup_list:
            if old not in by_id:
                die(f"audit {aid}: supersedes references missing audit {old}")
            old_obj = by_id[old]
            if old_obj.get("superseded_by") != aid:
                die(f"audit {aid}: supersedes {old} but {old}.superseded_by != {aid}")

    print("OK: audits_index.json lint passed")

if __name__ == "__main__":
    main()
