# ops/audits_index_lint.py
# =====================================================================
# EFHC Bot — lint для docs/audits/audits_index.json.
#
# Цели:
# - Проверить формат и обязательные поля.
# - Проверить, что referenced md/raw файлы существуют.
# - Проверить правила SUPERSEDED и уникальность ACTIVE.
# - Проверить валидность ссылок superseded_by.
# =====================================================================

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "docs" / "audits" / "audits_index.json"

ALLOWED_SOURCE_TYPES = {
    "CODE",
    "MIGRATION",
    "SQL",
    "LOG",
    "CI",
    "DOC",
}


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(2)


def warn(msg: str) -> None:
    print(f"WARN: {msg}", file=sys.stderr)


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        die(f"cannot read json {path}: {e}")
    raise AssertionError("unreachable")


def main() -> int:
    if not INDEX.exists():
        die("audits_index.json missing")

    data = load_json(INDEX)
    if not isinstance(data, list) or not data:
        die("audits_index.json must be non-empty list")

    by_id: dict[str, dict[str, Any]] = {}
    active_key: dict[tuple[str, str | None], str] = {}

    for a in data:
        if not isinstance(a, dict):
            die("audit item must be object")

        aid = a.get("audit_id")
        if not isinstance(aid, str) or not aid:
            die("audit_id missing")
        if aid in by_id:
            die(f"duplicate audit_id: {aid}")
        by_id[aid] = a

        topic = a.get("topic")
        if not isinstance(topic, str) or not topic:
            die(f"audit {aid}: topic missing")

        scope_key = a.get("scope_key")
        if scope_key is not None and not isinstance(scope_key, str):
            die(f"audit {aid}: scope_key must be string or null")

        status = a.get("status")
        if status not in {"ACTIVE", "SUPERSEDED", "DEPRECATED"}:
            die(f"audit {aid}: bad status {status}")

        files = a.get("files")
        if not isinstance(files, dict):
            die(f"audit {aid}: files must be object")

        md = files.get("md")
        if not isinstance(md, str) or not md:
            die(f"audit {aid}: files.md missing")
        md_path = ROOT / md
        if not md_path.exists():
            die(f"audit {aid}: md missing: {md}")

        raw = files.get("raw")
        if raw is not None:
            if not isinstance(raw, str) or not raw:
                die(f"audit {aid}: files.raw must be string or null")
            raw_path = ROOT / raw
            if not raw_path.exists():
                die(f"audit {aid}: raw missing: {raw}")

        sources = a.get("sources")
        if not isinstance(sources, list) or not sources:
            die(f"audit {aid}: sources must be non-empty list")
        for s in sources:
            if not isinstance(s, dict):
                die(f"audit {aid}: source item must be object")
            if "type" not in s or "ref" not in s:
                die(f"audit {aid}: each source needs type/ref")
            st = s["type"]
            if st not in ALLOWED_SOURCE_TYPES:
                die(f"audit {aid}: bad source type {st}")

        sb = a.get("superseded_by")
        if status == "SUPERSEDED":
            if not sb or sb == "null":
                die(
                    f"audit {aid}: SUPERSEDED requires superseded_by"
                )
        else:
            if sb not in (None, "null"):
                warn(
                    f"audit {aid}: superseded_by should be null "
                    f"for status {status}"
                )

        if status == "ACTIVE":
            key = (topic, scope_key) if scope_key else (topic, None)
            if key in active_key:
                die(
                    "multiple ACTIVE audits for key "
                    f"{key}: {active_key[key]} and {aid}"
                )
            active_key[key] = aid

    for aid, a in by_id.items():
        sb = a.get("superseded_by")
        if sb and sb != "null" and sb not in by_id:
            die(f"audit {aid}: superseded_by not found: {sb}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
