"""Inventory EFHC localization sources.

This helper is an audit aid. It does not translate text and does not
claim release readiness. It produces deterministic counts for the
manual localization cycles."""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
FRONTEND_SRC = ROOT / "frontend" / "src"
BACKEND_TEXTS = ROOT / "backend" / "app" / "bot" / "texts.py"
FAQ_DIR = FRONTEND_SRC / "data" / "faq"

TOKEN_ALLOW = {
    "EFHC",
    "EFHCm",
    "EFHCb",
    "FAQ",
    "MAX",
    "OK",
    "TON",
    "USDT",
    "VIP",
    "NFT",
    "tg_id",
    "URL",
}

STRING_RE = re.compile(r"(['\\`])([^\\\n]|\\.)*?\1")


def load_locales() -> dict[str, dict[str, str]]:
    data: dict[str, dict[str, str]] = {}
    for path in sorted(LOCALE_DIR.glob("*.json")):
        with path.open(encoding="utf-8") as handle:
            data[path.stem] = json.load(handle)
    return data


def count_bot_texts() -> tuple[int, list[str]]:
    if not BACKEND_TEXTS.exists():
        return 0, []
    tree = ast.parse(BACKEND_TEXTS.read_text(encoding="utf-8"))
    langs: list[str] = []
    total = 0
    for node in ast.walk(tree):
        target = None
        if isinstance(node, ast.Assign):
            target = node.targets[0] if node.targets else None
        if isinstance(node, ast.AnnAssign):
            target = node.target
        if getattr(target, "id", None) != "TEXTS":
            continue
        if isinstance(node.value, ast.Dict):
            pairs = zip(
                node.value.keys,
                node.value.values,
                strict=True,
            )
            for key, value in pairs:
                if isinstance(key, ast.Constant):
                    langs.append(str(key.value))
                if isinstance(value, ast.Dict):
                    total += len(value.keys)
    return total, sorted(langs)


def count_source_strings() -> tuple[int, int]:
    files = 0
    strings = 0
    for path in FRONTEND_SRC.rglob("*"):
        if path.suffix not in {".ts", ".tsx"}:
            continue
        files += 1
        text = path.read_text(encoding="utf-8", errors="ignore")
        strings += len(STRING_RE.findall(text))
    return files, strings


def faq_files() -> list[str]:
    if not FAQ_DIR.exists():
        return []
    items: list[str] = []
    for path in sorted(FAQ_DIR.rglob("*")):
        if path.is_file():
            items.append(str(path.relative_to(ROOT)))
    return items


def main() -> None:
    locales = load_locales()
    en = locales.get("en", {})
    print("# Localization inventory")
    print()
    print("## Locale bundles")
    for lang, data in locales.items():
        identical = 0
        for key, value in data.items():
            if key not in en:
                continue
            if not isinstance(value, str):
                continue
            if value == en[key] and value not in TOKEN_ALLOW:
                identical += 1
        count = len(data)
        print(f"- {lang}: {count} keys; identical_to_en={identical}")
    print()
    print("## Key parity")
    all_keys = set().union(*(set(d) for d in locales.values()))
    for lang, data in locales.items():
        missing = len(all_keys - set(data))
        extra = len(set(data) - set(en)) if en else 0
        print(f"- {lang}: missing={missing}; extra_vs_en={extra}")
    print()
    bot_total, bot_langs = count_bot_texts()
    print("## Backend bot texts")
    print(f"- file: {BACKEND_TEXTS.relative_to(ROOT)}")
    print(f"- languages: {', '.join(bot_langs) or 'none'}")
    print(f"- text entries: {bot_total}")
    print()
    source_files, source_strings = count_source_strings()
    print("## Frontend source strings")
    print(f"- ts/tsx files: {source_files}")
    print(f"- quoted strings: {source_strings}")
    print()
    print("## FAQ path")
    for item in faq_files():
        print(f"- {item}")


if __name__ == "__main__":
    main()
