from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend/public/locale"
I18N_FILE = ROOT / "frontend/src/lib/i18n.ts"


def parse_supported_langs() -> list[str]:
    text = I18N_FILE.read_text(encoding="utf-8")
    marker = "export const SUPPORTED_LANGS: Lang[] = ["
    start = text.index(marker) + len(marker)
    end = text.index("];", start)
    body = text[start:end]
    langs = []
    for raw in body.split(","):
        value = raw.strip().strip('"').strip("'")
        if value:
            langs.append(value)
    return langs


def load(name: str) -> dict[str, str]:
    return json.loads((LOCALE_DIR / name).read_text(encoding="utf-8"))


def main() -> int:
    supported = parse_supported_langs()
    files = sorted(p.stem for p in LOCALE_DIR.glob("*.json"))
    if sorted(supported) != sorted(files):
        raise RuntimeError(
            f"supported langs/files mismatch: {supported} vs {files}"
        )
    ru = load("ru.json")
    ru_keys = set(ru)
    missing_report = []
    for lang in supported:
        data = load(f"{lang}.json")
        keys = set(data)
        missing = sorted(ru_keys - keys)
        extra = sorted(keys - ru_keys)
        if missing or extra:
            missing_report.append((lang, missing, extra))
    if missing_report:
        raise RuntimeError(str(missing_report))
    print(
        "OK: locale files match supported langs and share one keyset."
    )
    print(f"Locale keys: {len(ru_keys)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
