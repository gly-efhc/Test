"""Guard French locale value quality.

This guard is intentionally narrow.
It rejects unapproved English fallbacks in the French locale.
It also rejects Cyrillic locale tails outside language names."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from locale_quality_allowlist import (
    is_allowed_identical,
    load_identical_allowlist,
)

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
EN_PATH = LOCALE_DIR / "en.json"
FR_PATH = LOCALE_DIR / "fr.json"

ACCEPTED_IDENTICAL = {
    "admin.direction",
    "admin.tg_optional",
    "admin.type",
    "admin.actions",
    "admin.admin_density_compact",
    "admin.admin_logs_stat_pagination",
    "admin.burn",
    "admin.hub",
    "admin.hub_actions",
    "admin.hub_code",
    "admin.hub_is_active_hint",
    "admin.hub_url",
    "admin.mint",
    "admin.modules",
    "admin.title",
    "admin.vip",
    "balances.bonus",
    "balances.total",
    "common.actions",
    "common.id",
    "energy.actions",
    "energy.kwh_per_sec_suffix",
    "energy.kwh_suffix_spaced",
    "exchange.max",
    "faq.questions_count",
    "faq.section_label",
    "faq.sections",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.note_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.card_modules",
    "portal.shop_entry.card_mode",
    "portal.web_profile.mode_label",
    "profile.admin_badge",
    "profile.confirmations_title",
    "profile.interface_title",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.notifications_title",
    "profile.telegram_badge",
    "profile.theme_auto",
    "profile.vip_badge",
    "ranks.levels_min_kwh",
    "ranks.top",
    "referrals.total",
    "referrals.total_count_short",
    "shop_ui.skins_title",
    "tasks.status_cooldown",
}

ACCEPTED_CYRILLIC = {
    "profile.lang.ru",
    "profile.lang.uk",
}

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def main() -> None:
    en = flatten(load(EN_PATH))
    fr = flatten(load(FR_PATH))
    exact_values, key_prefixes = load_identical_allowlist()

    unexpected_identical: list[str] = []
    for key, value in fr.items():
        is_unapproved = not is_allowed_identical(
            key, value, ACCEPTED_IDENTICAL, exact_values, key_prefixes
        )
        if key in en and value == en[key] and is_unapproved:
            unexpected_identical.append(f"{key} = {value}")

    cyrillic_tails: list[str] = []
    for key, value in fr.items():
        if key not in ACCEPTED_CYRILLIC and CYRILLIC_RE.search(value):
            cyrillic_tails.append(f"{key} = {value}")

    if unexpected_identical or cyrillic_tails:
        if unexpected_identical:
            print("Unexpected identical French values:")
            for item in unexpected_identical:
                print(f"- {item}")
        if cyrillic_tails:
            print("Unexpected Cyrillic tails in French locale:")
            for item in cyrillic_tails:
                print(f"- {item}")
        raise SystemExit(1)

    print("OK: checked French locale value quality.")
    print(f"Accepted identical keys: {len(ACCEPTED_IDENTICAL)}")
    print(f"Accepted exact values: {len(exact_values)}")
    print(f"Accepted Cyrillic language names: {len(ACCEPTED_CYRILLIC)}")


if __name__ == "__main__":
    main()
