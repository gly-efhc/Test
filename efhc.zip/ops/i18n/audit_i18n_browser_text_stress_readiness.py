"""Browser text stress screenshot-readiness audit.

This script is planning-only. It builds a deterministic route × locale ×
device stress matrix for later browser screenshot capture. It does not
claim screenshots or browser visual verdicts.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
OUTPUT = (
    ROOT
    / "reports"
    / "generated"
    / "i18n_browser_text_stress_readiness_v169_64.json"
)
HARNESS = (
    ROOT
    / "docs"
    / "frontend"
    / "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
)
PLAN_DOC = (
    ROOT
    / "docs"
    / "frontend"
    / "I18N_BROWSER_TEXT_STRESS_SCREENSHOT_READINESS_PLAN.md"
)
AUDIT_DOC = (
    ROOT
    / "docs"
    / "audits"
    / "I18N_BROWSER_TEXT_STRESS_SCREENSHOT_READINESS_AUDIT_V169_64.md"
)

LANGUAGES = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]
DEVICES = [
    {
        "id": "mobile_tma_dark_ru",
        "viewport": "390x844",
        "theme": "dark",
        "shell": "telegram_webapp_mock",
    },
    {
        "id": "mobile_tma_light_en",
        "viewport": "390x844",
        "theme": "light",
        "shell": "telegram_webapp_mock",
    },
    {
        "id": "desktop_pwa_dark_en",
        "viewport": "1280x800",
        "theme": "dark",
        "shell": "browser_pwa",
    },
]
ROUTES = [
    {
        "surface": "Energy",
        "route": "/",
        "slug": "energy",
        "priority": "P0",
        "prefixes": ["energy.", "common."],
    },
    {
        "surface": "Panels",
        "route": "/panels",
        "slug": "panels",
        "priority": "P0",
        "prefixes": ["panels.", "common."],
    },
    {
        "surface": "Exchange",
        "route": "/exchange",
        "slug": "exchange",
        "priority": "P0",
        "prefixes": ["exchange.", "common."],
    },
    {
        "surface": "Tasks",
        "route": "/tasks",
        "slug": "tasks",
        "priority": "P1",
        "prefixes": ["tasks.", "public_engagement.tasks.", "common."],
    },
    {
        "surface": "Referrals",
        "route": "/referrals",
        "slug": "referrals",
        "priority": "P1",
        "prefixes": [
            "referrals.",
            "public_engagement.referrals.",
            "common.",
        ],
    },
    {
        "surface": "Active referrals",
        "route": "/referrals/active",
        "slug": "referrals-active",
        "priority": "P1",
        "prefixes": [
            "referrals.",
            "public_engagement.referrals.",
            "common.",
        ],
    },
    {
        "surface": "Inactive referrals",
        "route": "/referrals/inactive",
        "slug": "referrals-inactive",
        "priority": "P1",
        "prefixes": [
            "referrals.",
            "public_engagement.referrals.",
            "common.",
        ],
    },
    {
        "surface": "Ranks",
        "route": "/ranks",
        "slug": "ranks",
        "priority": "P1",
        "prefixes": ["ranks.", "public_engagement.ranks.", "common."],
    },
    {
        "surface": "Profile",
        "route": "/web-profile",
        "slug": "web-profile",
        "priority": "P1",
        "prefixes": [
            "profile.",
            "wallet.",
            "history.",
            "public_profile_trust.",
            "common.",
        ],
    },
    {
        "surface": "FAQ",
        "route": "/faq",
        "slug": "faq",
        "priority": "P1",
        "prefixes": ["faq.", "common."],
    },
    {
        "surface": "HUB",
        "route": "/hub",
        "slug": "hub",
        "priority": "P0",
        "prefixes": ["hub.", "portal.shop_entry.", "common."],
    },
    {
        "surface": "Browser Shop",
        "route": "/browser-shop",
        "slug": "browser-shop",
        "priority": "P0",
        "prefixes": [
            "portal.browser_shop.",
            "portal.shop_entry.",
            "wallet.",
            "common.",
        ],
    },
    {
        "surface": "Withdraw",
        "route": "/withdraw",
        "slug": "withdraw",
        "priority": "P0",
        "prefixes": ["withdraw.", "wallet.", "common."],
    },
    {
        "surface": "Ads",
        "route": "/ads",
        "slug": "ads",
        "priority": "P2",
        "prefixes": ["ads.", "tasks.", "common."],
    },
]


def load_locale(lang: str) -> dict[str, object]:
    path = LOCALE_DIR / f"{lang}.json"
    if not path.exists():
        raise AssertionError(f"missing locale file: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def string_values_for_prefixes(
    data: dict[str, object], prefixes: Iterable[str]
) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    for key, value in data.items():
        if not isinstance(value, str):
            continue
        if any(key.startswith(prefix) for prefix in prefixes):
            out.append((key, value))
    return out


def score_route(
    data: dict[str, object], prefixes: Iterable[str]
) -> dict[str, object]:
    items = string_values_for_prefixes(data, prefixes)
    if not items:
        return {
            "key_count": 0,
            "max_length": 0,
            "avg_length": 0,
            "longest": [],
        }
    lengths = [(key, value, len(value)) for key, value in items]
    lengths.sort(key=lambda row: row[2], reverse=True)
    return {
        "key_count": len(items),
        "max_length": lengths[0][2],
        "avg_length": round(
            sum(x[2] for x in lengths) / len(lengths), 2
        ),
        "longest": [
            {"key": k, "length": n, "value_preview": v[:140]}
            for k, v, n in lengths[:5]
        ],
    }


def main() -> int:
    locales = {lang: load_locale(lang) for lang in LANGUAGES}
    key_sets = {
        lang: set(data.keys()) for lang, data in locales.items()
    }
    base_keys = key_sets["en"]
    for lang, keys in key_sets.items():
        missing = sorted(base_keys - keys)
        extra = sorted(keys - base_keys)
        if missing or extra:
            raise AssertionError(
                f"locale parity drift for {lang}: "
                f"missing={missing[:5]} extra={extra[:5]}"
            )

    if len(ROUTES) != 14:
        raise AssertionError(
            f"expected 14 public routes, got {len(ROUTES)}"
        )
    if len(DEVICES) != 3:
        raise AssertionError(
            f"expected 3 screenshot devices, got {len(DEVICES)}"
        )
    if set(LANGUAGES) != set(locales):
        raise AssertionError("language matrix drift")

    if not HARNESS.exists():
        raise AssertionError(
            "public screenshot harness document missing"
        )
    harness_text = HARNESS.read_text(encoding="utf-8")
    required_harness_markers = [
        "NO SCREENSHOTS CLAIMED",
        "EFHC_CAPTURE_SCREENSHOTS=1",
        "reports/screenshots/public_ui/",
    ]
    for marker in required_harness_markers:
        if marker not in harness_text:
            raise AssertionError(f"harness marker missing: {marker}")

    matrix = []
    for route in ROUTES:
        route_entry = {
            k: route[k]
            for k in [
                "surface",
                "route",
                "slug",
                "priority",
                "prefixes",
            ]
        }
        route_entry["devices"] = DEVICES
        route_entry["locales"] = {}
        for lang, data in locales.items():
            route_entry["locales"][lang] = score_route(
                data, route["prefixes"]
            )
        matrix.append(route_entry)

    stress_hotspots = []
    for route_entry in matrix:
        per_lang = route_entry["locales"]
        lang, score = max(
            per_lang.items(), key=lambda item: item[1]["max_length"]
        )
        stress_hotspots.append(
            {
                "route": route_entry["route"],
                "slug": route_entry["slug"],
                "highest_max_length_language": lang,
                "max_length": score["max_length"],
                "longest": score["longest"][:3],
            }
        )

    report = {
        "version": "v169_64",
        "cycle": 1384,
        "status": "SCREENSHOT_READINESS_PLAN_ONLY_NO_BROWSER_CAPTURE",
        "languages": LANGUAGES,
        "device_count": len(DEVICES),
        "route_count": len(ROUTES),
        "route_locale_device_combinations": len(ROUTES)
        * len(LANGUAGES)
        * len(DEVICES),
        "matrix": matrix,
        "stress_hotspots": stress_hotspots,
        "claims": {
            "screenshots_captured": False,
            "browser_visual_verdict": False,
            "github_ci_green": False,
            "human_linguistic_certification": False,
        },
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    for doc in [PLAN_DOC, AUDIT_DOC]:
        if not doc.exists():
            raise AssertionError(
                f"expected documentation missing: {doc}"
            )
        text = doc.read_text(encoding="utf-8")
        for marker in [
            "planning-only",
            "no screenshots",
            "not claimed",
        ]:
            if marker.lower() not in text.lower():
                raise AssertionError(
                    f"documentation non-"
                    f"claim marker missing in {doc}: {marker}"
                )

    print(
        "OK: i18n browser text stress screenshot-"
        "readiness matrix generated."
    )
    print(f"Routes: {len(ROUTES)}")
    print(f"Languages: {len(LANGUAGES)}")
    print(f"Devices: {len(DEVICES)}")
    combo_count = len(ROUTES) * len(LANGUAGES) * len(DEVICES)
    print(f"Route×locale×device combinations: {combo_count}")
    print("Screenshots captured: 0 (planning-only)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
