"""Audit Russian locale for silent English-source regressions.

This source-canon guard keeps Russian as the semantic source
for EFHC Bot translations. English-identical values are
allowed only for protected brand, formula and protocol strings.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"

ALLOW_IDENTICAL_KEYS = {
    "admin.hub",
    "admin.hub_url",
    "admin.tg_id",
    "admin.vip",
    "common.id",
    "deposit.truth__path__badge",
    "energy.exchange_action_note",
    "energy.kwh_suffix_spaced",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.payment_state_idle",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.telegram_badge",
    "profile.vip_badge",
    "ranks.filter_kwh",
}

FORBIDDEN_PUBLIC_PREFIXES = (
    "portal.browser_shop.",
    "portal.shop_entry.",
    "public_engagement.",
)


def load(name: str) -> dict[str, object]:
    return json.loads((LOCALE_DIR / name).read_text(encoding="utf-8"))


def main() -> None:
    en = load("en.json")
    ru = load("ru.json")
    offenders: list[str] = []
    for key, en_value in en.items():
        ru_value = ru.get(key)
        if not isinstance(en_value, str) or not isinstance(
            ru_value, str
        ):
            continue
        if not en_value.strip() or en_value != ru_value:
            continue
        if key in ALLOW_IDENTICAL_KEYS:
            continue
        if key.startswith(FORBIDDEN_PUBLIC_PREFIXES):
            offenders.append(f"{key} = {ru_value!r}")
    if offenders:
        raise SystemExit(
            "Russian public locale contains English-"
            "source regressions:\n"
            + "\n".join(offenders)
        )
    print(
        "OK: Russian public locale has no forbidden English-"
        "source regressions"
    )


if __name__ == "__main__":
    main()
