"""Consolidate manual public-locale coverage after cycles 1377-1382.

This audit is a static/source guard for cycle 1383. It verifies that
the manual
translation passes did not leave unexpected English fallback values
or Cyrillic
Russian/Ukrainian tails in the runtime public locale bundles.

It is not a human linguistic certification. It intentionally allows
short UI
abbreviations and protocol/brand values that are canonically
identical across
languages."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)
NON_EN_LANGS = (
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)

# Admin is intentionally Russian/operator-only and is audited separately
# by
# audit_admin_ru_only.py and audit_no_admin_leak.py.
EXCLUDED_KEY_PREFIXES = ("admin.",)

# Key-specific identical values that are acceptable because they are
# universal
# product/UI conventions, not untranslated prose. These are
# intentionally not
# added to the global exact-value allowlist to avoid over-allowing
# single-letter
# values like "d", "h" or "m" across unrelated keys.
ACCEPTED_IDENTICAL_BY_KEY: dict[str, set[str]] = {
    "faq.title": {"FAQ"},
    "common.day_short": {"d"},
    "common.hour_short": {"h"},
    "common.min_short": {"m"},
    # Canonical global status labels stay English in all 13 locales.
    "profile.activ_badge": {"Activ"},
    "profile.active_badge": {"Activ"},
}

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_locale(lang: str) -> dict[str, str]:
    return flatten(load_json(LOCALE_DIR / f"{lang}.json"))


def load_allowlist() -> tuple[set[str], tuple[str, ...]]:
    payload = load_json(ALLOWLIST)
    return set(payload.get("exact_values", [])), tuple(
        payload.get("key_prefixes", [])
    )


def is_excluded_key(
    key: str, allowed_prefixes: tuple[str, ...]
) -> bool:
    return key.startswith(EXCLUDED_KEY_PREFIXES) or any(
        key.startswith(prefix) for prefix in allowed_prefixes
    )


def is_accepted_identical(
    key: str,
    value: str,
    allowed_exact: set[str],
    allowed_prefixes: tuple[str, ...],
) -> bool:
    if is_excluded_key(key, allowed_prefixes):
        return True
    if value in allowed_exact:
        return True
    return value in ACCEPTED_IDENTICAL_BY_KEY.get(key, set())


def main() -> int:
    en = load_locale("en")
    allowed_exact, allowed_prefixes = load_allowlist()

    unexpected_identical: list[str] = []
    cyrillic_tails: list[str] = []
    missing_keys: list[str] = []
    checked_values = 0

    for lang in NON_EN_LANGS:
        locale = load_locale(lang)
        for key, en_value in en.items():
            if key not in locale:
                missing_keys.append(f"{lang}:{key}")
                continue
            if is_excluded_key(key, allowed_prefixes):
                continue
            value = locale[key]
            checked_values += 1
            if value == en_value and not is_accepted_identical(
                key, value, allowed_exact, allowed_prefixes
            ):
                unexpected_identical.append(f"{lang}:{key} = {value}")
            if lang in WAVE3_LANGS and CYRILLIC_RE.search(value):
                cyrillic_tails.append(f"{lang}:{key} = {value}")

    if missing_keys or unexpected_identical or cyrillic_tails:
        if missing_keys:
            print("Missing locale keys:")
            for item in missing_keys[:100]:
                print(f"- {item}")
            if len(missing_keys) > 100:
                print(f"... {len(missing_keys) - 100} more")
        if unexpected_identical:
            print("Unexpected English-identical values:")
            for item in unexpected_identical[:100]:
                print(f"- {item}")
            if len(unexpected_identical) > 100:
                print(f"... {len(unexpected_identical) - 100} more")
        if cyrillic_tails:
            print("Unexpected Cyrillic tails in wave-3 locales:")
            for item in cyrillic_tails[:100]:
                print(f"- {item}")
            if len(cyrillic_tails) > 100:
                print(f"... {len(cyrillic_tails) - 100} more")
        return 1

    print("OK: i18n manual coverage consolidation checked.")
    print(f"Languages checked: {len(NON_EN_LANGS)}")
    print(f"Values checked after exclusions: {checked_values}")
    print("Unexpected English-identical values: 0")
    print("Wave-3 Cyrillic tails: 0")
    print("Human linguistic certification: NOT CLAIMED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
