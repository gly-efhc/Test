"""Guard backend bot text parity.

Checks supported languages, key parity and placeholder parity for
``backend/app/bot/texts.py`` without importing Telegram runtime code.
"""

from __future__ import annotations

from importlib.machinery import SourceFileLoader
from pathlib import Path
from types import ModuleType

ROOT = Path(__file__).resolve().parents[2]
TEXTS_PATH = ROOT / "backend" / "app" / "bot" / "texts.py"


def _load_texts_module() -> ModuleType:
    loader = SourceFileLoader("efhc_bot_texts_guard", str(TEXTS_PATH))
    module = ModuleType(loader.name)
    module.__file__ = str(TEXTS_PATH)
    loader.exec_module(module)
    return module


def main() -> int:
    module = _load_texts_module()
    module.validate_bot_texts()
    langs = list(module.BOT_TEXT_LANGS)
    keys = list(module.BOT_TEXT_KEYS)
    print("OK: checked backend bot text parity.")
    print(f"Languages: {len(langs)}")
    print(f"Keys: {len(keys)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
