"""Guard for Ukrainian locale value quality.

The guard checks that reviewed Ukrainian strings do not
silently fall back to
English values, while allowing approved product/protocol tokens."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST_PATH = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)

ACCEPTED_IDENTICAL_KEYS = {
    "admin.search_users_placeholder",
    "admin.tg_id",
    "admin.tg_optional",
    "admin.hub",
    "admin.hub_is_active_hint",
    "admin.hub_url",
    "admin.vip",
    "common.id",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.memo_label",
    "portal.shop_entry.card_access_value",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.telegram_badge",
    "profile.vip_badge",
}

RUSSIAN_TAIL_MARKERS = (
    "Загруз",
    "Измен",
    "выбор",
    "не найд",
    "Ошибка",
    "Фильтрац",
    "Пагинац",
    "Ключевые",
    "Примеч",
    "Сводные",
    "Счёт",
    "Факты",
    "Системные",
    "Настройки",
    "Плотность",
    "Быстрое",
    "Профиль",
    "кошел",
    "пользовател",
    "Поиск",
    "Найдено",
)


def flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def load_identical_allowlist() -> tuple[set[str], tuple[str, ...]]:
    with ALLOWLIST_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    exact_values = set(payload.get("exact_values", []))
    key_prefixes = tuple(payload.get("key_prefixes", []))
    return exact_values, key_prefixes


def is_allowed_identical(
    key: str,
    value: str,
    exact_values: set[str],
    key_prefixes: tuple[str, ...],
) -> bool:
    if key in ACCEPTED_IDENTICAL_KEYS:
        return True
    if value in exact_values:
        return True
    return any(key.startswith(prefix) for prefix in key_prefixes)


def load_locale(lang: str) -> dict[str, str]:
    path = LOCALE_DIR / f"{lang}.json"
    with path.open("r", encoding="utf-8") as handle:
        return flatten(json.load(handle))


def main() -> int:
    en = load_locale("en")
    uk = load_locale("uk")
    exact_values, key_prefixes = load_identical_allowlist()
    unexpected = []
    for key, value in uk.items():
        if (
            value == en.get(key)
            and not
            is_allowed_identical(key, value, exact_values, key_prefixes)
        ):
            unexpected.append((key, value))

    russian_tails = []
    for key, value in uk.items():
        if any(marker in value for marker in RUSSIAN_TAIL_MARKERS):
            russian_tails.append((key, value))

    if unexpected or russian_tails:
        if unexpected:
            print("Unexpected identical Ukrainian values:")
            for key, value in unexpected:
                print(f"- {key}: {value}")
        if russian_tails:
            print("Possible Russian tails in Ukrainian locale:")
            for key, value in russian_tails:
                print(f"- {key}: {value}")
        return 1

    print("OK: checked Ukrainian locale value quality.")
    print(f"Accepted identical keys: {len(ACCEPTED_IDENTICAL_KEYS)}")
    print(f"Accepted exact values: {len(exact_values)}")
    print("Unexpected identical values: 0")
    print("Russian-tail markers: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
