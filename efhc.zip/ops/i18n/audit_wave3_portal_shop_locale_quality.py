"""Guard wave-3 portal/shop translations.

This audit is intentionally narrow. It verifies that the cycle-1379
wave-3
manual portal/shop pass did not leave unexpected English fallback
values inside
Browser Shop and Shop Entry public UI domains. It does not certify
full human
linguistic quality for the whole locale bundle."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIXES = ("portal.browser_shop.", "portal.shop_entry.")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def load_locale(lang: str) -> dict[str, str]:
    with (LOCALE_DIR / f"{lang}.json").open(
        "r", encoding="utf-8"
    ) as handle:
        return flatten(json.load(handle))


def load_allowed_exact_values() -> set[str]:
    with ALLOWLIST.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return set(payload.get("exact_values", []))


def in_scope(key: str) -> bool:
    return any(key.startswith(prefix) for prefix in PREFIXES)


def main() -> int:
    en = load_locale("en")
    allowed_exact = load_allowed_exact_values()
    portal_keys = sorted(key for key in en if in_scope(key))
    if not portal_keys:
        raise RuntimeError("portal/shop keyset is empty")

    failures: list[str] = []
    cyrillic_tails: list[str] = []
    for lang in WAVE3_LANGS:
        locale = load_locale(lang)
        missing = [key for key in portal_keys if key not in locale]
        if missing:
            failures.append(
                f"{lang}: missing portal/shop keys: {missing[:5]}"
            )
            continue
        identical = [
            key
            for key in portal_keys
            if locale[key] == en[key]
            and locale[key] not in allowed_exact
        ]
        if identical:
            failures.append(
                f"{lang}: unexpected English-identical portal/"
                f"shop values: {identical}"
            )
        tails = [
            key
            for key in portal_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        if tails:
            cyrillic_tails.append(f"{lang}: Cyrillic tails in {tails}")

    if failures or cyrillic_tails:
        for item in failures + cyrillic_tails:
            print(item)
        return 1

    print("OK: wave-3 portal/shop locale quality checked.")
    print(f"Languages: {len(WAVE3_LANGS)}")
    print(f"Domain keys: {len(portal_keys)}")
    print("Unexpected English-identical values: 0")
    print("Cyrillic tails: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
