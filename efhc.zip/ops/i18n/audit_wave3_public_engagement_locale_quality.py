"""Guard wave-3 public_engagement translations.

This audit is intentionally narrow. It verifies that the cycle-1378
wave-3
language pass did not leave English fallback values inside the public
engagement UI domain. It does not certify human linguistic quality
for the
whole locale bundle."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIX = "public_engagement."
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def load_locale(lang: str) -> dict[str, str]:
    with (LOCALE_DIR / f"{lang}.json").open(
        "r", encoding="utf-8"
    ) as handle:
        return flatten(json.load(handle))


def main() -> int:
    en = load_locale("en")
    public_keys = sorted(key for key in en if key.startswith(PREFIX))
    if not public_keys:
        raise RuntimeError("public_engagement keyset is empty")

    failures: list[str] = []
    cyrillic_tails: list[str] = []
    for lang in WAVE3_LANGS:
        locale = load_locale(lang)
        missing = [key for key in public_keys if key not in locale]
        if missing:
            failures.append(
                f"{lang}: missing public_engagement keys: {missing[:5]}"
            )
            continue
        identical = [
            key for key in public_keys if locale[key] == en[key]
        ]
        if identical:
            failures.append(
                f"{lang}: English-identical "
                f"public_engagement values: {identical}"
            )
        tails = [
            key
            for key in public_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        if tails:
            cyrillic_tails.append(f"{lang}: Cyrillic tails in {tails}")

    if failures or cyrillic_tails:
        for item in failures + cyrillic_tails:
            print(item)
        return 1

    print("OK: wave-3 public_engagement locale quality checked.")
    print(f"Languages: {len(WAVE3_LANGS)}")
    print(f"Domain keys: {len(public_keys)}")
    print("English-identical values: 0")
    print("Cyrillic tails: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
