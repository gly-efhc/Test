import re
from pathlib import Path

ROOTS = [Path("docs/SSOT/faq_ssot"), Path("frontend/src/data/faq")]
BANNED = [
    r"buy panel",
    r"panel price",
    r"купить панель",
    r"цена панели",
    r"стоимость панели",
    r"покупка панели",
    r"buy EFHC",
    r"купить EFHC",
]

findings = []
for root in ROOTS:
    files = [root] if root.is_file() else list(root.rglob("*"))
    for path in files:
        if not path.is_file():
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue
        for i, line in enumerate(lines, 1):
            for pat in BANNED:
                if re.search(pat, line, flags=re.I):
                    findings.append(f"{path}:{i}:{line.strip()[:180]}")

print(f"faq_panel_activation_findings: {len(findings)}")
for item in findings[:20]:
    print(item)
