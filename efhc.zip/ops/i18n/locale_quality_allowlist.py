"""Shared allowlist helpers for locale quality guards."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ALLOWLIST = ROOT / "ops/i18n/identical_to_english_allowlist.json"


def load_identical_allowlist() -> tuple[set[str], tuple[str, ...]]:
    if not ALLOWLIST.exists():
        return set(), ()
    payload = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
    exact_values = {
        str(item)
        for item in payload.get("exact_values", [])
    }
    key_prefixes = tuple(
        str(item) for item in payload.get("key_prefixes", [])
    )
    return exact_values, key_prefixes


def is_allowed_identical(
    key: str,
    value: str,
    accepted_keys: set[str],
    exact_values: set[str],
    key_prefixes: tuple[str, ...],
) -> bool:
    if key in accepted_keys:
        return True
    if value in exact_values:
        return True
    return key.startswith(key_prefixes)
