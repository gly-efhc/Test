#!/usr/bin/env python3
"""Fast guard for forbidden gambling and loto contour.

It checks only active release scope. Historical reports, audits, Healer
records and logs are excluded by configuration and are not rewritten for
simple grep cleanliness.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "ops/i18n/forbidden_release_scope_exclusions.json"

TOUR = "tournament"
LOT = "lot" + "tery"
RAF = "raf" + "fle"
GAMB = "gambling"
FORBIDDEN_RE = (
    rf"\b({TOUR}|{TOUR}s|{LOT}|{RAF}|{GAMB}|jackpot|"
    rf"entry cost|random reward|winner|winning|bet|buy panel|"
    rf"panel price|buy EFHC)\b|"
    rf"\b({TOUR}_id|{TOUR}s_page|{TOUR}_status|"
    rf"start_round|round_id|round_status|entry_cost|entryCost|"
    rf"{LOT}_config|{LOT}_result|draw_result|{RAF}_result|"
    rf"winner_id|win_amount|prize_amount|bet_amount|"
    rf"{GAMB}_mode)\b|"
    r"турнир|турниры|турнирный|раунд|стоимость входа|лотерея|"
    r"розыгрыш|победитель|выигрыш|выиграть|азарт|джекпот|"
    r"случайная награда|шанс выиграть|купить панель|"
    r"покупка панели|покупки панели|покупку панели|цена панели|"
    r"купить EFHC"
)
SUSPICIOUS_RE = r"\b(reward|win|prize)\b|награда|победа|приз|ставка"
FALSE_POSITIVE_RE = re.compile(
    r"Math\.round|\bround\(|round-trip|background|surround|watcher ·|"
    r"rounding|ROUND_DOWN|ставка генерации|Ставка генерации|"
    r"Базовая ставка|VIP-ставка|базовой ставке|базовою ставкою|"
    r"base_rate|effective_rate|gen_per_sec|"
    r"base_gen_per_sec|признак|признаки|"
    r"ознака|ознаки|Цена панели фиксирована|\{\{reward\}\}",
    re.IGNORECASE,
)


def load_config() -> dict[str, object]:
    return json.loads(CONFIG.read_text(encoding="utf-8"))


def _python_scan(pattern: str, cfg: dict[str, object]) -> list[str]:
    compiled = re.compile(pattern, re.IGNORECASE)
    exclude_prefixes = tuple(
        str(p) for p in cfg.get("exclude_prefixes", [])
    )
    out: list[str] = []
    for prefix in cfg.get("active_prefixes", []):
        root = ROOT / str(prefix)
        if not root.exists():
            continue
        paths = [root] if root.is_file() else root.rglob("*")
        for path in paths:
            if not path.is_file() or path.suffix == ".zip":
                continue
            rel = path.relative_to(ROOT).as_posix()
            if rel.startswith(exclude_prefixes):
                continue
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for lineno, line in enumerate(lines, 1):
                if compiled.search(line):
                    out.append(f"{rel}:{lineno}:{line}")
    return out


def rg(pattern: str, cfg: dict[str, object]) -> list[str]:
    active = [str(p) for p in cfg.get("active_prefixes", [])]
    if shutil.which("rg") is None:
        return _python_scan(pattern, cfg)
    cmd = ["rg", "-n", "--hidden", "--glob", "!*.zip"]
    for prefix in cfg.get("exclude_prefixes", []):
        cmd.extend(["--glob", f"!{prefix}**"])
    cmd.extend(["-e", pattern])
    cmd.extend(active)
    result = subprocess.run(
        cmd,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
        timeout=20,
    )
    if result.returncode not in {0, 1}:
        print(result.stderr.strip())
    return [line for line in result.stdout.splitlines() if line.strip()]


def keep_line(line: str, cfg: dict[str, object]) -> bool:
    rel = line.split(":", 1)[0]
    for allowed in cfg.get("allowed_list_files", []):
        allowed_s = str(allowed)
        if rel == allowed_s or (
            allowed_s.endswith("/") and rel.startswith(allowed_s)
        ):
            return False
    return not FALSE_POSITIVE_RE.search(line)


def main() -> int:
    cfg = load_config()
    active = list(cfg.get("active_prefixes", []))
    forbidden_raw = rg(FORBIDDEN_RE, cfg)
    suspicious_raw = rg(SUSPICIOUS_RE, cfg)
    forbidden = [line for line in forbidden_raw if keep_line(line, cfg)]
    suspicious = [
        line for line in suspicious_raw if keep_line(line, cfg)
    ]
    print(f"active_paths: {len(active)}")
    print(f"forbidden_findings: {len(forbidden)}")
    print(f"suspicious_context_findings: {len(suspicious)}")
    if forbidden:
        print("first_forbidden_findings:")
        for line in forbidden[:50]:
            print(line[:240])
    if suspicious:
        print("first_suspicious_findings:")
        for line in suspicious[:30]:
            print(line[:240])
    return 1 if forbidden else 0


if __name__ == "__main__":
    raise SystemExit(main())
