const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "../..");
const localeDir = path.join(root, "frontend/public/locale");
const allowlistPath = path.join(
  __dirname,
  "identical_to_english_allowlist.json",
);
const allowlist = JSON.parse(fs.readFileSync(allowlistPath, "utf8"));
const approvedExact = new Set(allowlist.exact_values || []);
const approvedKeyPrefixes = allowlist.key_prefixes || [];

function flatten(value, prefix = "", out = {}) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    for (const [key, nested] of Object.entries(value)) {
      flatten(nested, prefix ? `${prefix}.${key}` : key, out);
    }
    return out;
  }
  out[prefix] = value;
  return out;
}

function isApproved(key, value) {
  const text = String(value).trim();
  if (!text) return true;
  if (approvedExact.has(text)) return true;
  if (approvedKeyPrefixes.some((prefix) => key.startsWith(prefix))) {
    return true;
  }
  if (/^[A-Z0-9_./:-]+$/.test(text)) return true;
  return false;
}

const files = fs.readdirSync(localeDir)
  .filter((name) => name.endsWith(".json"))
  .sort();
const bundles = Object.fromEntries(files.map((name) => {
  const full = path.join(localeDir, name);
  const parsed = JSON.parse(fs.readFileSync(full, "utf8"));
  return [name.replace(/\.json$/, ""), flatten(parsed)];
}));

const en = bundles.en || {};
const findings = [];
for (const [lang, bundle] of Object.entries(bundles)) {
  if (lang === "en") continue;
  for (const [key, value] of Object.entries(bundle)) {
    if (!(key in en)) continue;
    if (String(value).trim() !== String(en[key]).trim()) continue;
    if (isApproved(key, value)) continue;
    findings.push({ lang, key, value });
  }
}

function groupCount(items, field) {
  const out = {};
  for (const item of items) {
    const key = item[field];
    out[key] = (out[key] || 0) + 1;
  }
  return Object.fromEntries(
    Object.entries(out).sort((a, b) => b[1] - a[1]),
  );
}

function keyPrefix(key) {
  return key.split(".")[0] || key;
}

const byPrefix = {};
for (const item of findings) {
  const prefix = keyPrefix(item.key);
  byPrefix[prefix] = (byPrefix[prefix] || 0) + 1;
}

console.log(JSON.stringify({
  checked_locales: Object.keys(bundles).length,
  compared_against: "en",
  approved_exact_values: approvedExact.size,
  approved_key_prefixes: approvedKeyPrefixes.length,
  identical_findings: findings.length,
  by_lang: groupCount(findings, "lang"),
  by_prefix: Object.fromEntries(
    Object.entries(byPrefix).sort((a, b) => b[1] - a[1]),
  ),
  findings: findings.slice(0, 150),
}, null, 2));

if (findings.length > 0) {
  process.exitCode = 1;
}
