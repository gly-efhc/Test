#!/usr/bin/env python3
"""Admin ru-only localization guard."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RU = ROOT / "frontend/public/locale/ru.json"


def flatten(prefix: str, value: object, out: dict[str, object]) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            flatten(f"{prefix}.{key}" if prefix else key, child, out)
    else:
        out[prefix] = value


def main() -> int:
    data = json.loads(RU.read_text(encoding="utf-8"))
    flat: dict[str, object] = {}
    flatten("", data, flat)
    admin_keys = [key for key in flat if key.startswith("admin.")]
    raw = [
        key
        for key, value in flat.items()
        if key.startswith("admin.") and value == key
    ]
    empty = [
        key
        for key, value in flat.items()
        if key.startswith("admin.") and str(value).strip() == ""
    ]
    print(f"admin_ru_keys: {len(admin_keys)}")
    print(f"admin_ru_raw_keys: {len(raw)}")
    print(f"admin_ru_empty_values: {len(empty)}")
    for key in (raw + empty)[:50]:
        print(key)
    return 1 if raw or empty or not admin_keys else 0


if __name__ == "__main__":
    raise SystemExit(main())
