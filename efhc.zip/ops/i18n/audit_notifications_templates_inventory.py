from __future__ import annotations

import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REQUIRED_PATHS = (
    "backend/app/services/admin/admin_notifications.py",
    "backend/app/services/shop_order_notifications_service.py",
    "backend/app/models/system_templates_models.py",
    "backend/app/routes/admin_templates_routes.py",
    "backend/app/services/admin/admin_templates_service.py",
    "backend/app/services/outcome_service.py",
    "backend/app/services/tasks_service.py",
    "frontend/src/pages/admin/templates.tsx",
)
REPORT = (
    ROOT / "docs/audits/LOCALIZATION_NOTIFICATIONS_AND_TEMPLATES.md"
)


def _count(path: Path, needle: str) -> int:
    return path.read_text(encoding="utf-8").count(needle)


def _strict_report_errors() -> list[str]:
    errors: list[str] = []
    if not REPORT.exists():
        rel_report = REPORT.relative_to(ROOT)
        return [f"strict inventory report missing: {rel_report}"]
    text = REPORT.read_text(encoding="utf-8")
    for rel in REQUIRED_PATHS:
        if rel not in text:
            errors.append(f"inventory report does not mention {rel}")
    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Inventory notification/"
            "template localization surfaces. By default "
            "the script runs on a clean checkout without a pre-"
            "generated work-pass "
            "inventory report. Use --"
            "strict to enforce the historical report check."
        )
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help=(
            "Require localization notification/template "
            "inventory report coverage."
        ),
    )
    args = parser.parse_args(argv)

    missing = [
        rel for rel in REQUIRED_PATHS if not (ROOT / rel).exists()
    ]
    if missing:
        print("ERROR: missing inventory paths:")
        for rel in missing:
            print(f"- {rel}")
        return 1

    handlers_root = ROOT / "backend/app/bot/handlers"
    bot_handlers = (
        list(handlers_root.rglob("*.py"))
        if handlers_root.exists()
        else []
    )
    answer_count = sum(
        _count(path, "message.answer") for path in bot_handlers
    )
    callback_count = sum(
        _count(path, "call.answer") for path in bot_handlers
    )

    print("OK: notification/template inventory executed.")
    print(f"Required paths: {len(REQUIRED_PATHS)}")
    print(f"Bot handler files: {len(bot_handlers)}")
    print(f"message.answer occurrences: {answer_count}")
    print(f"call.answer occurrences: {callback_count}")
    print("Required inventory surfaces:")
    for rel in REQUIRED_PATHS:
        print(f"- {rel}")

    if not args.strict:
        if not REPORT.exists():
            print(
                "NOTE: strict work-"
                "pass inventory report is absent; default audit "
                "mode does not require it. Run with --"
                "strict to enforce report coverage."
            )
        return 0

    errors = _strict_report_errors()
    if errors:
        print("STRICT_ERRORS:")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK: strict inventory report coverage checked.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
