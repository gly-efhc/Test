from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


def _render_catalogs_ts(*args, **kwargs):
    from ops.scripts.generate_faq_catalogs_from_ssot import (
        render_catalogs_ts,
    )

    return render_catalogs_ts(*args, **kwargs)


LANGS = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)

FORBIDDEN = {
    "ru": r"купить|покупк|покупательск",
    "en": r"\bbuy\b|\bbought\b|\bpurchase\w*\b|purchasing",
    "uk": r"купити|придбати|покупк",
    "de": r"kaufen|kauf|gekauft|einkauf",
    "fr": r"acheter|achat|achats",
    "es": r"comprar|compra|comprado",
    "it": r"acquist\w*|comprare",
    "tr": r"satın",
    "pl": r"kupić|kupno|zakup\w*|kupion\w*",
    "da": r"køb\w*|købe|købt",
    "hi": r"purchase|purchases|purchased|खरीद",
    "id": r"membeli|pembelian|dibeli",
    "sw": r"kununua|ununuzi|purchase|purchases",
}


def _load(lang: str) -> dict[str, object]:
    path = ROOT / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _assert_structure(lang: str, data: dict[str, object]) -> None:
    sections = data.get("sections")
    if not isinstance(sections, list):
        raise AssertionError(f"{lang}: sections missing")
    if len(sections) != 20:
        raise AssertionError(f"{lang}: expected 20 sections")
    total = 0
    for section in sections:
        items = section.get("items")
        if not isinstance(items, list):
            raise AssertionError(f"{lang}: section items missing")
        total += len(items)
    if total != 250:
        raise AssertionError(f"{lang}: expected 250 Q&A items")


def _assert_markdown(lang: str, data: dict[str, object]) -> None:
    path = ROOT / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.md"
    text = path.read_text(encoding="utf-8")
    if str(data["title"]) not in text:
        raise AssertionError(f"{lang}: markdown title drift")
    sections = data["sections"]
    for section in sections:
        heading = f"## {section['id']}. {section['title']}"
        if heading not in text:
            raise AssertionError(f"{lang}: markdown heading drift")


def _assert_forbidden(lang: str) -> None:
    pattern = re.compile(FORBIDDEN[lang], re.IGNORECASE)
    for suffix in ("json", "md"):
        path = ROOT / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.{suffix}"
        text = path.read_text(encoding="utf-8")
        match = pattern.search(text)
        if match:
            raise AssertionError(
                "forbidden FAQ commerce token "
                f"{lang}: {match.group(0)!r}"
            )


def _assert_runtime_catalog() -> None:
    target = ROOT / "frontend/src/data/faq/catalogs.ts"
    expected = _render_catalogs_ts(ROOT)
    actual = target.read_text(encoding="utf-8")
    if actual != expected:
        raise AssertionError(
            "frontend FAQ catalog is not SSOT-generated"
        )


def main() -> int:
    for lang in LANGS:
        data = _load(lang)
        _assert_structure(lang, data)
        _assert_markdown(lang, data)
        _assert_forbidden(lang)
    _assert_runtime_catalog()
    print("OK: FAQ localization consistency checked.")
    print(f"Languages: {len(LANGS)}")
    print("Sections per language: 20")
    print("Questions per language: 250")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
