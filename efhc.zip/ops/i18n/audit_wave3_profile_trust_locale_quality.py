"""Guard wave-3 profile/public-profile-trust translations.

This audit is intentionally narrow. It verifies that the cycle-1380
wave-3
manual profile/trust pass did not leave unexpected English fallback
values in
public account surfaces. It does not certify full human linguistic
quality for
the whole locale bundle."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
ALLOWLIST = (
    ROOT / "ops" / "i18n" / "identical_to_english_allowlist.json"
)
WAVE3_LANGS = (
    "de",
    "fr",
    "hi",
    "sw",
    "tr",
    "pl",
    "da",
    "it",
    "es",
    "id",
)
PREFIXES = ("profile.", "public_profile_trust.")
CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")
# Global status labels stay canonical English in all locales.
CANONICAL_ENGLISH_KEYS = {
    "profile.activ_badge",
    "profile.active_badge",
}


def flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    values: dict[str, str] = {}
    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            values.update(flatten(value, full_key))
        elif isinstance(value, str):
            values[full_key] = value
    return values


def load_locale(lang: str) -> dict[str, str]:
    with (LOCALE_DIR / f"{lang}.json").open(
        "r", encoding="utf-8"
    ) as handle:
        return flatten(json.load(handle))


def load_allowlist() -> tuple[set[str], tuple[str, ...]]:
    with ALLOWLIST.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    exact_values = set(payload.get("exact_values", []))
    key_prefixes = tuple(payload.get("key_prefixes", []))
    return exact_values, key_prefixes


def in_scope(key: str) -> bool:
    return any(key.startswith(prefix) for prefix in PREFIXES)


def main() -> int:
    en = load_locale("en")
    allowed_exact, allowed_prefixes = load_allowlist()
    profile_keys = sorted(
        key
        for key, value in en.items()
        if in_scope(key)
        and value not in allowed_exact
        and key not in CANONICAL_ENGLISH_KEYS
        and not any(
            key.startswith(prefix) for prefix in allowed_prefixes
        )
    )
    if not profile_keys:
        raise RuntimeError("profile/trust keyset is empty")

    failures: list[str] = []
    cyrillic_tails: list[str] = []
    for lang in WAVE3_LANGS:
        locale = load_locale(lang)
        missing = [key for key in profile_keys if key not in locale]
        if missing:
            failures.append(
                f"{lang}: missing profile/trust keys: {missing[:5]}"
            )
            continue
        identical = [
            key for key in profile_keys if locale[key] == en[key]
        ]
        if identical:
            failures.append(
                f"{lang}: unexpected English-identical profile/"
                f"trust values: {identical}"
            )
        tails = [
            key
            for key in profile_keys
            if CYRILLIC_RE.search(locale[key])
        ]
        if tails:
            cyrillic_tails.append(f"{lang}: Cyrillic tails in {tails}")

    if failures or cyrillic_tails:
        for item in failures + cyrillic_tails:
            print(item)
        return 1

    print("OK: wave-3 profile/trust locale quality checked.")
    print(f"Languages: {len(WAVE3_LANGS)}")
    print(f"Domain keys: {len(profile_keys)}")
    print("Unexpected English-identical values: 0")
    print("Cyrillic tails: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
