"""Guard locale key parity and placeholder parity.

This guard checks every frontend locale bundle against the English
baseline. It does not translate text and does not claim release
readiness. Per-language value-quality guards remain responsible for
unreviewed fallback values."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
BASE_LANG = "en"

PLACEHOLDER_PATTERNS = (
    r"\{\{\s*[^{}]+\s*\}\}",
    r"(?<!\{)\{[A-Za-z0-9_.-]+\}(?!\})",
    r"%\([A-Za-z0-9_.-]+\)[sdif]",
    r"%(?:\d+\$)?[sdif]",
    r"\$\{[A-Za-z0-9_.-]+\}",
    r"\$[A-Za-z_][A-Za-z0-9_]*",
)


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def placeholders(value: str) -> tuple[str, ...]:
    found: set[str] = set()
    for pattern in PLACEHOLDER_PATTERNS:
        found.update(re.findall(pattern, value))
    return tuple(sorted(found))


def load_locales() -> dict[str, dict[str, str]]:
    locales: dict[str, dict[str, str]] = {}
    for path in sorted(LOCALE_DIR.glob("*.json")):
        locales[path.stem] = flatten(load(path))
    return locales


def main() -> None:
    locales = load_locales()
    if BASE_LANG not in locales:
        raise SystemExit("Missing English baseline locale.")

    baseline = locales[BASE_LANG]
    baseline_keys = set(baseline)
    failures: list[str] = []

    for lang, values in sorted(locales.items()):
        keys = set(values)
        missing = sorted(baseline_keys - keys)
        extra = sorted(keys - baseline_keys)
        if missing:
            failures.append(f"{lang}: missing keys: {missing}")
        if extra:
            failures.append(f"{lang}: extra keys: {extra}")

        empty = sorted(
            key for key, value in values.items() if not value
        )
        if empty:
            failures.append(f"{lang}: empty values: {empty}")

        for key in sorted(baseline_keys & keys):
            base_ph = placeholders(baseline[key])
            local_ph = placeholders(values[key])
            if base_ph != local_ph:
                failures.append(
                    f"{lang}: placeholder drift at {key}: "
                    f"{base_ph} != {local_ph}"
                )

    if failures:
        print("Locale parity guard failed:")
        for item in failures:
            print(f"- {item}")
        raise SystemExit(1)

    print("OK: checked all-locale key and placeholder parity.")
    print(f"Languages: {len(locales)}")
    print(f"Baseline keys: {len(baseline_keys)}")
    print("Missing keys: 0")
    print("Extra keys: 0")
    print("Placeholder drift: 0")
    print("Empty values: 0")


if __name__ == "__main__":
    main()
