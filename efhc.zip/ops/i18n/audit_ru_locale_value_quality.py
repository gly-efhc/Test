from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend/public/locale"
ALLOWLIST = ROOT / "ops/i18n/identical_to_english_allowlist.json"

ALLOWED_IDENTICAL = {
    "admin.search_users_placeholder",
    "admin.tg_id",
    "admin.tg_optional",
    "admin.hub",
    "admin.hub_is_active_hint",
    "admin.hub_url",
    "admin.vip",
    "common.id",
    "energy.kwh_suffix_spaced",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.memo_label",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.telegram_badge",
    "profile.vip_badge",
}

MUST_DIFFER = {
    "admin.activate",
    "admin.address",
    "admin.operator_contour_withdraw_detail",
    "common.actions",
    "common.inactive",
    "common.off",
    "common.on",
    "common.search",
    "exchange.max",
    "nav.ranks",
    "ranks.title",
    "referrals.invite_title",
    "tasks.ad_modal_confirm",
    "wallet.disconnect_session",
}


def flatten(value: object, prefix: str = "") -> dict[str, str]:
    out: dict[str, str] = {}
    if not isinstance(value, dict):
        return out
    for key, item in value.items():
        full_key = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(item, dict):
            out.update(flatten(item, full_key))
        elif isinstance(item, str):
            out[full_key] = item
    return out


def load_locale(name: str) -> dict[str, str]:
    path = LOCALE_DIR / name
    return flatten(json.loads(path.read_text(encoding="utf-8")))


def load_allowlist() -> tuple[set[str], tuple[str, ...]]:
    if not ALLOWLIST.exists():
        return set(), ()
    data = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
    exact_values = {str(item) for item in data.get("exact_values", [])}
    key_prefixes = tuple(
        str(item) for item in data.get("key_prefixes", [])
    )
    return exact_values, key_prefixes


def is_allowed_identical(
    key: str,
    value: str,
    exact_values: set[str],
    key_prefixes: tuple[str, ...],
) -> bool:
    if key in ALLOWED_IDENTICAL:
        return True
    if value in exact_values:
        return True
    return key.startswith(key_prefixes)


def main() -> int:
    en = load_locale("en.json")
    ru = load_locale("ru.json")
    exact_values, key_prefixes = load_allowlist()
    blocked: list[str] = []
    for key in sorted(MUST_DIFFER):
        if ru.get(key) == en.get(key):
            blocked.append(f"{key} still equals en.json")
    unexpected = []
    for key, value in sorted(ru.items()):
        if key in en and value == en[key]:
            if is_allowed_identical(
                key, value, exact_values, key_prefixes
            ):
                continue
            unexpected.append(key)
    print("OK: checked RU locale value quality.")
    print(f"Known critical keys: {len(MUST_DIFFER)}")
    print(f"Unexpected identical values: {len(unexpected)}")
    if unexpected:
        print("Unexpected keys:")
        for key in unexpected[:50]:
            print(f"- {key}")
    if blocked:
        raise RuntimeError("; ".join(blocked))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
