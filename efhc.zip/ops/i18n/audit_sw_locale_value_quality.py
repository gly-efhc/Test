"""Guard Swahili locale value quality.

This guard rejects unapproved English fallbacks in the Swahili
locale and
rejects Cyrillic tails except approved language names. It allows only
protocol/product tokens, language names and short technical labels that
are intentionally identical across locales."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from locale_quality_allowlist import (
    is_allowed_identical,
    load_identical_allowlist,
)

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
EN_PATH = LOCALE_DIR / "en.json"
SW_PATH = LOCALE_DIR / "sw.json"

ACCEPTED_IDENTICAL = {
    "admin.burn",
    "admin.hub",
    "admin.hub_is_active_hint",
    "admin.hub_url",
    "admin.mint",
    "admin.search_users_placeholder",
    "admin.tg_optional",
    "admin.state_live",
    "admin.tg_id",
    "admin.vip",
    "common.id",
    "energy.kwh_per_sec_suffix",
    "energy.kwh_suffix_spaced",
    "energy.level_short",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.memo_label",
    "portal.browser_shop.sync_short",
    "portal.web_profile.mode_value",
    "profile.admin_badge",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.telegram_badge",
    "profile.vip_badge",
    "shop_ui.skins_title",
}

ACCEPTED_CYRILLIC = {
    "profile.lang.ru",
    "profile.lang.uk",
}

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def main() -> None:
    en = flatten(load(EN_PATH))
    sw = flatten(load(SW_PATH))
    exact_values, key_prefixes = load_identical_allowlist()

    unexpected_identical: list[str] = []
    for key, value in sw.items():
        is_unapproved = not is_allowed_identical(
            key, value, ACCEPTED_IDENTICAL, exact_values, key_prefixes
        )
        if key in en and value == en[key] and is_unapproved:
            unexpected_identical.append(f"{key} = {value}")

    cyrillic_tails: list[str] = []
    for key, value in sw.items():
        if key in ACCEPTED_CYRILLIC:
            continue
        if CYRILLIC_RE.search(value):
            cyrillic_tails.append(f"{key} = {value}")

    if unexpected_identical or cyrillic_tails:
        if unexpected_identical:
            print("Unexpected identical Swahili values:")
            for item in unexpected_identical:
                print(f"- {item}")
        if cyrillic_tails:
            print("Unexpected Cyrillic tails in Swahili locale:")
            for item in cyrillic_tails:
                print(f"- {item}")
        raise SystemExit(1)

    print("OK: checked Swahili locale value quality.")
    print(f"Accepted identical keys: {len(ACCEPTED_IDENTICAL)}")
    print(f"Accepted exact values: {len(exact_values)}")
    print("Cyrillic tails: 0")


if __name__ == "__main__":
    main()
