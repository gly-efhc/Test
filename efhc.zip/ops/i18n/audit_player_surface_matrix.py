from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PLAYER_PATHS = [
    "frontend/src/pages/ads.tsx",
    "frontend/src/pages/browser-shop.tsx",
    "frontend/src/pages/exchange.tsx",
    "frontend/src/pages/faq.tsx",
    "frontend/src/pages/hub.tsx",
    "frontend/src/pages/index.tsx",
    "frontend/src/pages/panels.tsx",
    "frontend/src/pages/ranks.tsx",
    "frontend/src/pages/referrals.tsx",
    "frontend/src/pages/tasks.tsx",
    "frontend/src/pages/web-profile.tsx",
    "frontend/src/pages/withdraw.tsx",
    "frontend/src/features/browser-shop/BrowserShopPage.tsx",
    "frontend/src/features/hub/HubPage.tsx",
    "frontend/src/features/profile/WebProfilePage.tsx",
    "frontend/src/components/AdsBanner.tsx",
    "frontend/src/components/DepositModal.tsx",
    "frontend/src/components/ExchangePanel.tsx",
    "frontend/src/components/GlobalHeader.tsx",
    "frontend/src/components/ProfileModal.tsx",
    "frontend/src/components/RanksTable.tsx",
    "frontend/src/components/ReferralsTabs.tsx",
    "frontend/src/components/faq/FaqAccordionList.tsx",
    "frontend/src/components/profile/ProfileHistorySection.tsx",
    "frontend/src/components/ui/SurfaceFactsStrip.tsx",
    "frontend/src/components/ui/telegram/TelegramProductCard.tsx",
]


def has_cyrillic(text: str) -> bool:
    return any("А" <= ch <= "я" or ch in "Ёё" for ch in text)


ALLOWED_CYRILLIC_LINES = {
    (
        "frontend/src/components/GlobalHeader.tsx",
        'aria-label="Пополнить"',
    ),
    ("frontend/src/components/GlobalHeader.tsx", "Пополнить"),
}


def is_allowed_cyrillic(rel: str, line: str) -> bool:
    stripped = line.strip()
    return (rel, stripped) in ALLOWED_CYRILLIC_LINES


def main() -> None:
    bad: list[str] = []
    checked = 0
    for rel in PLAYER_PATHS:
        path = ROOT / rel
        if not path.exists():
            continue
        checked += 1
        in_block = False
        for lineno, line in enumerate(path.read_text().splitlines(), 1):
            stripped = line.lstrip()
            if in_block:
                if "*/" in stripped:
                    in_block = False
                continue
            if stripped.startswith("/*"):
                if "*/" not in stripped:
                    in_block = True
                continue
            if stripped.startswith("//"):
                continue
            is_bad = has_cyrillic(line) and not is_allowed_cyrillic(
                rel,
                line,
            )
            if is_bad:
                bad.append(f"{rel}:{lineno}: {line.strip()}")
    if bad:
        raise SystemExit("Player Cyrillic tails:\n" + "\n".join(bad))
    print("OK: checked player-facing surface matrix.")
    print(f"Files checked: {checked}")


if __name__ == "__main__":
    main()
