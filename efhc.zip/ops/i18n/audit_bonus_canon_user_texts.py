#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

FAQ_FILES = list(Path("docs/SSOT/faq_ssot").rglob("*.json"))
LOCALE_FILES = list(Path("frontend/public/locale").glob("*.json"))

PATTERNS = [
    re.compile(r"\brewards?\b", re.I),
    re.compile(r"наград", re.I),
    re.compile(r"\bprize\b", re.I),
    re.compile(r"приз(?!н)", re.I),
    re.compile(r"\bwinner\b", re.I),
    re.compile(r"победител", re.I),
    re.compile(r"\bwinning\b", re.I),
    re.compile(r"выигр", re.I),
]
ALLOWED_SUBSTRINGS = ["признак", "признаки", "ознаки"]


def scan_text(text: str) -> bool:
    low = text.lower()
    if any(s in low for s in ALLOWED_SUBSTRINGS):
        for s in ALLOWED_SUBSTRINGS:
            low = low.replace(s, " ")
        text = low
    text = re.sub(r"\{\{[^}]+\}\}", " ", text)
    return any(p.search(text) for p in PATTERNS)


def main() -> int:
    findings: list[tuple[str, str, str]] = []
    for path in FAQ_FILES:
        data = json.loads(path.read_text(encoding="utf-8"))
        for sec in data.get("sections", []):
            for item in sec.get("items", []):
                for field in ("q", "a"):
                    val = item.get(field, "")
                    if isinstance(val, str) and scan_text(val):
                        findings.append((str(path), field, val[:180]))

    for path in LOCALE_FILES:
        data = json.loads(path.read_text(encoding="utf-8"))
        for key, val in data.items():
            if isinstance(val, str) and scan_text(val):
                findings.append((str(path), key, val[:180]))

    print(f"bonus_canon_findings: {len(findings)}")
    for item in findings[:100]:
        print(" | ".join(item))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
