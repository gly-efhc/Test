#!/usr/bin/env python3
"""Check that user-facing frontend files do not call admin.* keys."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
USER_PREFIXES = [
    "frontend/src/pages/",
    "frontend/src/components/",
    "frontend/src/data/faq/",
]
ADMIN_PATH_PARTS = ["/admin", "Admin"]
PATTERN = re.compile(r"t\(\s*['\"]admin\.")


def main() -> int:
    findings: list[str] = []
    for prefix in USER_PREFIXES:
        base = ROOT / prefix
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if path.suffix not in {".ts", ".tsx", ".js", ".jsx"}:
                continue
            rel = path.relative_to(ROOT).as_posix()
            if any(part in rel for part in ADMIN_PATH_PARTS):
                continue
            text = path.read_text(encoding="utf-8")
            for lineno, line in enumerate(text.splitlines(), start=1):
                if PATTERN.search(line):
                    findings.append(f"{rel}:{lineno}:{line.strip()}")
    print(f"admin_leak_findings: {len(findings)}")
    for item in findings[:50]:
        print(item)
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
