#!/usr/bin/env python3
"""Guard admin/operator critical English UI tail regressions.

This is not a full translation-quality verifier. It protects
the work pass admin/operator matrix by checking hardcoded
phrases that were
already corrected manually.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADMIN_PATHS = [
    ROOT / "frontend/src/pages/admin",
    ROOT / "frontend/src/features/admin",
    ROOT / "frontend/src/components/admin",
]
COMPONENTS = ROOT / "frontend/src/components"
EXTRA_FILES = list(COMPONENTS.glob("Admin*.tsx"))

BANNED_SNIPPETS = [
    "outline-нет",
    "openОтклонение",
    ">Approve<",
    ">Reject<",
    "Approve, reject и контроль статусов",
    "Disconnect session",
    "Invite friends",
    "Selected task",
    "Visible submissions",
    "Submissions Moderation Surface",
    "Proof card",
    "Catalog items",
    "Selected item facts",
    "Force Fulfill order",
    "Order ID",
    "Create card image upload",
    "Admin Charts",
    "Admin Table",
]


def iter_files() -> list[Path]:
    files: list[Path] = []
    for base in ADMIN_PATHS:
        if base.exists():
            files.extend(base.rglob("*.tsx"))
            files.extend(base.rglob("*.ts"))
    files.extend(EXTRA_FILES)
    return sorted(set(files))


def main() -> int:
    failures: list[str] = []
    for file_path in iter_files():
        text = file_path.read_text(encoding="utf-8")
        for snippet in BANNED_SNIPPETS:
            if snippet in text:
                rel = file_path.relative_to(ROOT)
                msg = f"{rel}: banned admin/operator UI tail: {snippet}"
                failures.append(msg)
    if failures:
        print("Admin/operator localization guard failed:")
        for item in failures:
            print(f"- {item}")
        return 1
    print("OK: checked admin/operator surface matrix critical tails.")
    print(f"Files checked: {len(iter_files())}")
    print(f"Banned critical snippets: {len(BANNED_SNIPPETS)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
