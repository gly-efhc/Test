"""Guard Hindi locale value quality.

This guard rejects unapproved English fallbacks in the Hindi locale and
rejects Cyrillic tails except approved language names. It allows only
protocol/product tokens, language names and short technical labels that
are intentionally identical across locales."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from locale_quality_allowlist import (
    is_allowed_identical,
    load_identical_allowlist,
)

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
EN_PATH = LOCALE_DIR / "en.json"
HI_PATH = LOCALE_DIR / "hi.json"

ACCEPTED_IDENTICAL = {
    "admin.admin_token",
    "admin.bonus_balance",
    "admin.hub",
    "admin.hub_icon_key",
    "admin.hub_is_active_hint",
    "admin.hub_open_mode",
    "admin.hub_sort_order",
    "admin.hub_target_kind",
    "admin.hub_url",
    "admin.main_balance",
    "admin.module_note_referrals",
    "admin.module_note_tasks",
    "admin.module_note_withdrawals",
    "admin.operator_contour_title",
    "admin.raw_summary",
    "admin.search_users_placeholder",
    "admin.session_model_title",
    "admin.session_ready",
    "admin.session_setup_required",
    "admin.session_storage_local",
    "admin.tg_id",
    "admin.tg_optional",
    "admin.ton_wallet",
    "admin.ts",
    "admin.vip",
    "admin.withdrawals_status_summary",
    "common.id",
    "energy.kwh_per_sec_suffix",
    "energy.kwh_suffix_spaced",
    "energy.level_short",
    "exchange.max",
    "exchange.rate_hint",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.hub",
    "portal.browser_shop.deposit_title",
    "portal.browser_shop.eyebrow",
    "portal.browser_shop.game_ready",
    "portal.browser_shop.handoff_title",
    "portal.browser_shop.intent_order_label",
    "portal.browser_shop.linked_wallets_title",
    "portal.browser_shop.memo_label",
    "portal.browser_shop.payment_details_title",
    "portal.browser_shop.payment_method_title",
    "portal.browser_shop.ready_packages_title",
    "portal.browser_shop.storefront_mode_title",
    "portal.browser_shop.telegram_profile_title",
    "portal.browser_shop.title",
    "portal.browser_shop.ton_contour_title",
    "portal.browser_shop.ton_price",
    "portal.browser_shop.wallet_label",
    "portal.browser_shop.wallet_title",
    "portal.common.ton_wallet",
    "portal.shop_entry.card_access_value",
    "portal.shop_entry.card_mode",
    "portal.shop_entry.card_mode_value",
    "portal.shop_entry.card_truth_value",
    "portal.shop_entry.eyebrow",
    "portal.shop_entry.title",
    "portal.web_profile.eyebrow",
    "portal.web_profile.mode_label",
    "portal.web_profile.mode_value",
    "portal.web_profile.title",
    "profile.haptic_feedback",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.id",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.modal_title",
    "profile.reason.ad_reward",
    "profile.reason.hub_operation",
    "profile.reason.panel_activation",
    "profile.reason.referral_bonus",
    "profile.reason.task_reward",
    "profile.reason.withdraw_hold",
    "profile.reason.withdraw_payout",
    "profile.reason.withdraw_refund",
    "profile.sound_pack",
    "profile.sound_pack_default",
    "profile.sound_volume",
    "profile.support_chat",
    "profile.telegram_avatar",
    "profile.telegram_badge",
    "profile.telegram_user",
    "profile.terms",
    "profile.toasts_enabled",
    "profile.ui_sounds",
    "profile.vip_badge",
    "referrals.bonus_balance",
    "referrals.counters",
    "referrals.level_title",
    "referrals.link_copied",
    "referrals.max_level",
    "referrals.system_title",
    "shop_ui.activation_failed",
    "shop_ui.deposit_failed",
    "shop_ui.deposit_title",
    "shop_ui.main_screen_artwork",
    "shop_ui.order_failed",
    "shop_ui.payment_cancelled",
    "shop_ui.preview_unavailable",
    "shop_ui.purchase_failed",
    "shop_ui.skin_activated",
    "shop_ui.skin_preview_title",
    "shop_ui.wallet_required",
    "tasks.ad_modal_title",
    "tasks.ad_reward_ok",
    "tasks.status",
    "wallet.linked_wallets_count",
    "wallet.recommended_wallets",
    "wallet.session_connected",
    "wallet.session_disconnected",
    "withdraw.request_number",
}

ACCEPTED_CYRILLIC = {
    "profile.lang.ru",
    "profile.lang.uk",
}

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def main() -> None:
    en = flatten(load(EN_PATH))
    hi = flatten(load(HI_PATH))
    exact_values, key_prefixes = load_identical_allowlist()

    unexpected_identical: list[str] = []
    for key, value in hi.items():
        is_unapproved = not is_allowed_identical(
            key, value, ACCEPTED_IDENTICAL, exact_values, key_prefixes
        )
        if key in en and value == en[key] and is_unapproved:
            unexpected_identical.append(f"{key} = {value}")

    cyrillic_tails: list[str] = []
    for key, value in hi.items():
        if key in ACCEPTED_CYRILLIC:
            continue
        if CYRILLIC_RE.search(value):
            cyrillic_tails.append(f"{key} = {value}")

    if unexpected_identical or cyrillic_tails:
        if unexpected_identical:
            print("Unexpected identical Hindi values:")
            for item in unexpected_identical:
                print(f"- {item}")
        if cyrillic_tails:
            print("Unexpected Cyrillic tails in Hindi locale:")
            for item in cyrillic_tails:
                print(f"- {item}")
        raise SystemExit(1)

    print("OK: checked Hindi locale value quality.")
    print(f"Accepted identical keys: {len(ACCEPTED_IDENTICAL)}")
    print(f"Accepted exact values: {len(exact_values)}")
    print("Cyrillic tails: 0")


if __name__ == "__main__":
    main()
