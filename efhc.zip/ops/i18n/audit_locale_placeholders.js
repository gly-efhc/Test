const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "../..");
const localeDir = path.join(root, "frontend/public/locale");
const tokenRe = /{{\s*([a-zA-Z0-9_]+)\s*}}/g;

function tokens(value) {
  const found = [];
  let match;
  while ((match = tokenRe.exec(String(value)))) {
    found.push(match[1]);
  }
  return [...new Set(found)].sort();
}

const files = fs.readdirSync(localeDir)
  .filter((name) => name.endsWith(".json"))
  .sort();
const bundles = Object.fromEntries(files.map((name) => {
  const full = path.join(localeDir, name);
  const parsed = JSON.parse(fs.readFileSync(full));
  return [name.replace(/\.json$/, ""), parsed];
}));

const en = bundles.en || {};
const problems = [];
for (const [lang, bundle] of Object.entries(bundles)) {
  for (const key of Object.keys(en)) {
    const base = tokens(en[key]);
    const current = tokens(bundle[key] ?? "");
    if (base.join("|") !== current.join("|")) {
      problems.push({ lang, key, expected: base, actual: current });
    }
  }
}

console.log(JSON.stringify({
  checked_locales: Object.keys(bundles).length,
  checked_keys: Object.keys(en).length,
  placeholder_mismatches: problems.length,
  problems: problems.slice(0, 100),
}, null, 2));

if (problems.length > 0) {
  process.exitCode = 1;
}
