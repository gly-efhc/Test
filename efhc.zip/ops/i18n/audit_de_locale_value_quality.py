"""Guard German locale value quality.

This script is intentionally narrow: it checks that the German
locale does
not fall back to English values except for approved tokens
and language names. It also rejects Cyrillic tails outside
language names."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from locale_quality_allowlist import (
    is_allowed_identical,
    load_identical_allowlist,
)

ROOT = Path(__file__).resolve().parents[2]
LOCALE_DIR = ROOT / "frontend" / "public" / "locale"
EN_PATH = LOCALE_DIR / "en.json"
DE_PATH = LOCALE_DIR / "de.json"

ACCEPTED_IDENTICAL = {
    "admin.tg_optional",
    "admin.admin_shell_detail",
    "admin.bank",
    "admin.bank_tid",
    "admin.burn",
    "admin.hub",
    "admin.hub_code",
    "admin.hub_is_active_hint",
    "admin.hub_links_total",
    "admin.hub_url",
    "admin.mint",
    "admin.state_live",
    "admin.title",
    "admin.vip",
    "balances.bonus",
    "common.id",
    "common.status",
    "energy.kwh_per_sec_suffix",
    "energy.kwh_suffix_spaced",
    "energy.level_short",
    "exchange.max",
    "faq.title",
    "hub.efhc_modal_title",
    "hub.title",
    "nav.admin",
    "nav.dashboard",
    "nav.hub",
    "nav.panels",
    "panels.panel_id",
    "portal.browser_shop.card_storefront",
    "portal.browser_shop.card_wallets",
    "portal.browser_shop.memo_label",
    "portal.browser_shop.wallet_label",
    "portal.shop_entry.card_truth",
    "portal.web_profile.card_wallets",
    "portal.web_profile.section_wallets",
    "profile.admin_badge",
    "profile.lang.da",
    "profile.lang.de",
    "profile.lang.en",
    "profile.lang.es",
    "profile.lang.fr",
    "profile.lang.hi",
    "profile.lang.it",
    "profile.lang.pl",
    "profile.lang.ru",
    "profile.lang.sw",
    "profile.lang.tr",
    "profile.lang.uk",
    "profile.telegram_badge",
    "profile.vip_badge",
    "ranks.levels_min_kwh",
    "ranks.top",
    "shop_ui.skins_title",
    "tasks.status",
    "wallet.title",
}

ACCEPTED_CYRILLIC = {
    "profile.lang.ru",
    "profile.lang.uk",
}

CYRILLIC_RE = re.compile(r"[А-Яа-яЁёІіЇїЄєҐґ]")


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def flatten(value: Any, prefix: str = "") -> dict[str, str]:
    result: dict[str, str] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            next_key = f"{prefix}.{key}" if prefix else key
            result.update(flatten(child, next_key))
    elif isinstance(value, str):
        result[prefix] = value
    return result


def main() -> None:
    en = flatten(load(EN_PATH))
    de = flatten(load(DE_PATH))
    exact_values, key_prefixes = load_identical_allowlist()

    unexpected_identical: list[str] = []
    for key, value in de.items():
        same_as_en = key in en and value == en[key]
        is_unapproved = not is_allowed_identical(
            key, value, ACCEPTED_IDENTICAL, exact_values, key_prefixes
        )
        if same_as_en and is_unapproved:
            unexpected_identical.append(f"{key} = {value}")

    cyrillic_tails: list[str] = []
    for key, value in de.items():
        if key not in ACCEPTED_CYRILLIC and CYRILLIC_RE.search(value):
            cyrillic_tails.append(f"{key} = {value}")

    if unexpected_identical or cyrillic_tails:
        if unexpected_identical:
            print("Unexpected identical German values:")
            for item in unexpected_identical:
                print(f"- {item}")
        if cyrillic_tails:
            print("Unexpected Cyrillic tails in German locale:")
            for item in cyrillic_tails:
                print(f"- {item}")
        raise SystemExit(1)

    print("OK: checked German locale value quality.")
    print(f"Accepted identical keys: {len(ACCEPTED_IDENTICAL)}")
    print(f"Accepted exact values: {len(exact_values)}")
    print(f"Accepted Cyrillic language names: {len(ACCEPTED_CYRILLIC)}")


if __name__ == "__main__":
    main()
