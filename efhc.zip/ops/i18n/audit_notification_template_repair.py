from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LANGS = (
    "en",
    "ru",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)
FILES = (
    ROOT / "backend/app/services/shop_order_notifications_service.py",
    ROOT / "backend/app/services/outcome_service.py",
    ROOT / "backend/app/services/tasks_service.py",
)


def _tree(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"))


def _literal_dict(path: Path, name: str) -> dict:
    for node in _tree(path).body:
        if isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name) and target.id == name:
                return ast.literal_eval(node.value)
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    return ast.literal_eval(node.value)
    raise AssertionError(f"{name} not found in {path}")


def _assert_lang_keys(label: str, values: dict[str, str]) -> None:
    missing = [code for code in LANGS if code not in values]
    if missing:
        raise AssertionError(
            f"{label} misses languages: {', '.join(missing)}"
        )
    empty = [code for code in LANGS if not str(values[code]).strip()]
    if empty:
        raise AssertionError(
            f"{label} has empty languages: {', '.join(empty)}"
        )


def main() -> int:
    for path in FILES:
        if not path.exists():
            raise AssertionError(f"missing required file: {path}")
        _tree(path)

    shop_path = ROOT / "backend/app/services"
    shop_path = shop_path / "shop_order_notifications_service.py"
    shop = _literal_dict(shop_path, "_SHOP_ORDER_TEXTS")
    for key, values in shop.items():
        _assert_lang_keys(f"shop order {key}", values)

    outcome = _literal_dict(
        ROOT / "backend/app/services/outcome_service.py",
        "_WITHDRAW_COMMENT_DEFAULTS",
    )
    for key, values in outcome.items():
        _assert_lang_keys(f"withdraw comment {key}", values)

    promo = _literal_dict(
        ROOT / "backend/app/services/outcome_service.py",
        "_WITHDRAW_PROMO_DEFAULTS",
    )
    for key, values in promo.items():
        _assert_lang_keys(f"withdraw promo {key}", values)

    tasks = _literal_dict(
        ROOT / "backend/app/services/tasks_service.py",
        "_TEMPLATE_DEFAULTS",
    )
    for key, values in tasks.items():
        _assert_lang_keys(f"task template {key}", values)

    print("OK: notification/template manual repair checked.")
    print(f"Languages: {len(LANGS)}")
    print(f"Shop notification buckets: {len(shop)}")
    print(f"Withdraw comment buckets: {len(outcome)}")
    print(f"Withdraw promo buckets: {len(promo)}")
    print(f"Task template buckets: {len(tasks)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
