from __future__ import annotations

import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend/src"
REPORT = ROOT / "docs/audits/FRONTEND_HARDCODED_STRINGS.md"
TEXT_RE = re.compile(
    r"(?P<quote>[\"'`])" r"(?P<text>[^\"'`{}<>]{4,})" r"(?P=quote)"
)
SKIP_PARTS = {
    "data",
    "faq",
    "styles",
    "_tests_",
}
TECH_HINTS = (
    "className",
    "import ",
    "from ",
    "href",
    "http",
    "api/",
    "Bearer ",
    "Content-Type",
    "application/",
    "localStorage",
    "sessionStorage",
)
PLAYER_HINTS = (
    "browser-shop",
    "web-profile",
    "profile",
    "withdraw",
    "exchange",
    "panels",
    "tasks",
    "referrals",
    "ranks",
    "hub",
)
REQUIRED_STRICT_MARKERS = (
    "work pass",
    "admin/operator",
    "player-facing",
    "false positives",
)


def _iter_sources() -> list[Path]:
    out: list[Path] = []
    for path in FRONTEND.rglob("*"):
        if path.suffix not in {".ts", ".tsx"}:
            continue
        rel = path.relative_to(FRONTEND)
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        out.append(path)
    return sorted(out)


def _looks_technical(line: str, text: str) -> bool:
    compact = text.strip()
    if not compact:
        return True
    if any(hint in line for hint in TECH_HINTS):
        return True
    if compact.startswith(("/", "#", "@")):
        return True
    if re.fullmatch(r"[a-z0-9_]+(\.[a-z0-9_]+)+", compact):
        return True
    return compact.lower() in {"get", "post", "put", "delete"}


def _bucket(path: Path) -> str:
    rel = str(path.relative_to(ROOT))
    if "/admin/" in rel or rel.endswith("/admin.tsx"):
        return "admin"
    lower = rel.lower()
    if any(hint in lower for hint in PLAYER_HINTS):
        return "player"
    return "shared"


def _collect_hits() -> list[tuple[str, int, str, str]]:
    hits: list[tuple[str, int, str, str]] = []
    for path in _iter_sources():
        rel = str(path.relative_to(ROOT))
        for lineno, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            1,
        ):
            for match in TEXT_RE.finditer(line):
                text = match.group("text").strip()
                if _looks_technical(line, text):
                    continue
                hits.append((rel, lineno, _bucket(path), text))
    return hits


def _validate_strict_report() -> list[str]:
    errors: list[str] = []
    if not REPORT.exists():
        return [f"strict report missing: {REPORT.relative_to(ROOT)}"]
    report_text = REPORT.read_text(encoding="utf-8")
    for required in REQUIRED_STRICT_MARKERS:
        if required not in report_text:
            errors.append(f"strict report misses marker: {required}")
    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Audit candidate hardcoded frontend strings. By default "
            "the script "
            "runs on a clean checkout without external work-"
            "pass artifacts. "
            "Use --strict to require the historical work-"
            "pass report markers."
        )
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help=(
            "Require frontend hardcoded strings report "
            "and marker text."
        ),
    )
    args = parser.parse_args(argv)

    hits = _collect_hits()
    admin = sum(1 for hit in hits if hit[2] == "admin")
    player = sum(1 for hit in hits if hit[2] == "player")
    shared = sum(1 for hit in hits if hit[2] == "shared")

    print("OK: frontend hardcoded string audit executed.")
    print(f"Source files: {len(_iter_sources())}")
    print(f"Candidate hits: {len(hits)}")
    print(f"Admin candidates: {admin}")
    print(f"Player candidates: {player}")
    print(f"Shared candidates: {shared}")
    if hits:
        print("First candidate hits:")
        for rel, lineno, bucket, text in hits[:20]:
            print(f"- {bucket}: {rel}:{lineno}: {text[:120]}")

    if not args.strict:
        if not REPORT.exists():
            print(
                "NOTE: strict work-"
                "pass report is absent; default audit mode "
                "does not require it. Run with --"
                "strict to enforce report markers."
            )
        return 0

    errors = _validate_strict_report()
    if errors:
        print("STRICT_ERRORS:")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK: strict work-pass report markers checked.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
