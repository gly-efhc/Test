#!/usr/bin/env python3
"""Compatibility shim.

The old path is kept so existing local commands do not break.
It does not ban the word game. The active guard checks only the
forbidden gambling, loto, betting, tournament and random financial
contour.
"""

from __future__ import annotations

from audit_forbidden_gambling_chance_contour import main

if __name__ == "__main__":
    raise SystemExit(main())
