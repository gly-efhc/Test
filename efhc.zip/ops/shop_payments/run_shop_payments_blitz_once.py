from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))


async def _run() -> dict[str, object]:
    from app.deps import get_db
    from app.scheduler.shop_payments_sync import run_once
    from app.services.shop_order_notifications_service import (
        dispatch_shop_order_notifications,
    )

    sync_result = await run_once()

    agen = get_db()
    db = await agen.__anext__()
    try:
        notify_result = await dispatch_shop_order_notifications(
            db,
            limit=100,
        )
        await db.commit()
    finally:
        await agen.aclose()

    return {
        "sync": sync_result,
        "notifications": notify_result,
    }


def main() -> None:
    result = asyncio.run(_run())
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
