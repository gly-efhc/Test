from __future__ import annotations

from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    out = root / "reports" / "endpoint_discovery_report.txt"
    out.write_text(
        "Historical compatibility stub. Active route truth "
        "lives in docs/SSOT/ssot_pack and docs/audits/"
        "ROUTE_INVENTORY_FREEZE.md.\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
