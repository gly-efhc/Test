#!/usr/bin/env python3

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TESTS = [
    "tests/architecture/test_economic_audit_guards.py",
    "tests/architecture/test_bank_runtime_invariants.py",
    "tests/architecture/test_exchange_mirror_and_locks.py",
    "tests/architecture/test_withdraw_runtime_invariants.py",
    "tests/architecture/test_shop_spending_order_canon.py",
]


def main() -> int:
    cmd = [sys.executable, "-m", "pytest", "-q", *TESTS]
    print("[EFHC][release-hardening] Running economic subset:")
    for item in TESTS:
        print(f" - {item}")
    completed = subprocess.run(cmd, cwd=ROOT)
    if completed.returncode == 0:
        print(
            "[EFHC][release-hardening] OK: economic subset passed. "
            "This is a narrow local guard, not a GitHub CI replacement."
        )
    else:
        print(
            "[EFHC][release-hardening] FAILED: economic subset has "
            "local guard failures."
        )
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
