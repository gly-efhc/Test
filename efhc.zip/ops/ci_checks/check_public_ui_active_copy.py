#!/usr/bin/env python3
"""Block technical wording that is actually referenced by public UI.

The legacy copy firewall scans the whole locale corpus. This guard
maps public `t("key")` usage to locale values. It also scans visible
JSX text and string attributes. Unused historical keys do not create
noise, while technical copy that can reach a public page fails closed.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

POLICY = Path("ops/policy/public_ui_active_copy.json")
PUBLIC_ROOTS = (
    Path("frontend/src/pages"),
    Path("frontend/src/components"),
    Path("frontend/src/features"),
)
LOCALE_DIR = Path("frontend/public/locale")
TS_EXTS = {".ts", ".tsx", ".js", ".jsx"}
T_KEY_RE = re.compile(r"\bt\(\s*['\"]([^'\"]+)['\"]")
VISIBLE_ATTR_RE = re.compile(
    r"(?:aria-label|alt|detail|label|placeholder|subtitle|text|title)"
    r"\s*=\s*['\"]([^'\"]+)['\"]"
)
JSX_TEXT_RE = re.compile(r">([^<>{}][^<>{}]*)<")


def is_public_source(path: Path) -> bool:
    value = "/" + path.as_posix()
    if path.name.endswith("SandboxPrototype.tsx"):
        return False
    excluded = (
        "/pages/admin/",
        "/components/admin/",
        "/features/admin/",
        "/pages/api/",
        "/__tests__/",
    )
    return not any(part in value for part in excluded)


def source_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for rel in PUBLIC_ROOTS:
        base = root / rel
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if (
                path.is_file()
                and path.suffix in TS_EXTS
                and is_public_source(path.relative_to(root))
            ):
                files.append(path)
    return sorted(files)


def normalized(value: str) -> str:
    return " ".join(value.lower().split())


def scan(root: Path) -> list[str]:
    policy = json.loads((root / POLICY).read_text(encoding="utf-8"))
    phrases = [normalized(item) for item in policy["forbidden_phrases"]]
    files = source_files(root)
    used_keys: dict[str, list[str]] = {}
    findings: list[str] = []
    for path in files:
        text = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(root).as_posix()
        for key in T_KEY_RE.findall(text):
            used_keys.setdefault(key, []).append(rel)
        visible = VISIBLE_ATTR_RE.findall(text) + JSX_TEXT_RE.findall(
            text
        )
        for raw in visible:
            value = normalized(raw)
            if not value or value.startswith(("/", "http")):
                continue
            for phrase in phrases:
                if phrase in value:
                    findings.append(
                        f"{rel}: visible technical phrase "
                        f"{phrase!r}: {raw!r}"
                    )
    locale_dir = root / LOCALE_DIR
    for path in sorted(locale_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        lang = path.stem
        for key, refs in used_keys.items():
            value = data.get(key)
            if not isinstance(value, str):
                continue
            check = normalized(value)
            for phrase in phrases:
                if phrase in check:
                    findings.append(
                        f"locale={lang} key={key} phrase={phrase!r} "
                        f"refs={','.join(refs[:3])}: {value!r}"
                    )
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args(argv)
    findings = scan(Path(args.root).resolve())
    if findings:
        print("ACTIVE PUBLIC COPY GUARD: FAIL")
        print("\n".join(findings[:200]))
        print(f"Total findings: {len(findings)}")
        return 1
    print("ACTIVE PUBLIC COPY GUARD: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
