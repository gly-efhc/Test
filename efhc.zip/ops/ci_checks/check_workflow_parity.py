#!/usr/bin/env python3
"""Keep the visible root CI mirror equal to GitHub's active workflow."""

from pathlib import Path

root = Path(__file__).resolve().parents[2]
mirror = (root / "ci.yml").read_text()
active = (root / ".github/workflows/canon.yml").read_text()
if mirror != active:
    raise SystemExit("ci.yml differs from .github/workflows/canon.yml")
print("EFHC workflow parity: PASS")
