#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

PUBLIC_UI_DIRECT_API_GATE_VERSION = (
    "v171_20_service_api_react_query_gate"
)
CURRENT_CYCLE = 1548
DEFAULT_LIMIT = 200

PUBLIC_ROOTS = (
    "frontend/src/pages",
    "frontend/src/components",
    "frontend/src/features",
    "frontend/src/views",
    "frontend/src/app",
)

EXCLUDED_PARTS = (
    "/admin/",
    "/pages/api/",
    "/__tests__/",
    "/test-utils/",
)

EXCLUDED_PREFIXES = (
    "docs/",
    "reports/",
    "tests/",
    "backend/",
    "migrations/",
    "scripts/",
    "ops/",
    "node_modules/",
    "dist/",
    "build/",
    ".next/",
    "coverage/",
    "frontend/src/lib/api/",
    "frontend/src/services/",
    "frontend/src/queries/",
    "frontend/src/mocks/",
    "frontend/src/test-utils/",
)

EXTENSIONS = {".ts", ".tsx", ".js", ".jsx"}

FORBIDDEN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("direct /api/ endpoint", re.compile(r"[\"'`]\/api\/")),
    ("apiRequest()", re.compile(r"\bapiRequest\s*\(")),
    ("fetch()", re.compile(r"\bfetch\s*\(")),
    ("axios.", re.compile(r"\baxios\.")),
    ("axios()", re.compile(r"\baxios\s*\(")),
    ("XMLHttpRequest", re.compile(r"\bXMLHttpRequest\b")),
    ("EventSource", re.compile(r"\bEventSource\s*\(")),
    ("WebSocket", re.compile(r"\bWebSocket\s*\(")),
)

@dataclass(frozen=True)
class Finding:
    path: str
    line_no: int
    reason: str
    line: str


def _as_posix(path: Path) -> str:
    return path.as_posix().lstrip("./")


def _load_allowlist(root: Path) -> list[dict[str, Any]]:
    path = root / "ops/policy/public_ui_direct_api_allowlist.json"
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise SystemExit("direct API allowlist must be a JSON array")
    for entry in data:
        if not isinstance(entry, dict):
            raise SystemExit(
                "direct API allowlist entries must be objects"
            )
        if not entry.get("path") or not entry.get("reason"):
            raise SystemExit("allowlist entry requires path and reason")
        expires = entry.get("expires_cycle")
        if not isinstance(expires, int):
            raise SystemExit(
                "allowlist entry requires numeric expires_cycle"
            )
        if expires <= CURRENT_CYCLE:
            raise SystemExit(
                "expired direct API allowlist entry: "
                f"{entry.get('path')} expired at cycle {expires}"
            )
    return data


def _is_allowlisted(
    rel_path: str,
    allowlist: list[dict[str, Any]],
) -> bool:
    return any(rel_path == item.get("path") for item in allowlist)


def _is_scannable(rel_path: str, path: Path) -> bool:
    if path.suffix not in EXTENSIONS:
        return False
    if any(rel_path.startswith(prefix) for prefix in EXCLUDED_PREFIXES):
        return False
    normalized = f"/{rel_path}"
    return not any(part in normalized for part in EXCLUDED_PARTS)


def _candidate_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for public_root in PUBLIC_ROOTS:
        base = root / public_root
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            rel_path = _as_posix(path.relative_to(root))
            if _is_scannable(rel_path, path):
                files.append(path)
    return sorted(files)


def _line_is_safe_import(line: str) -> bool:
    return (
        "/lib/api/generated" in line
        or "../lib/api/generated" in line
    )


def scan(root: Path) -> list[Finding]:
    allowlist = _load_allowlist(root)
    findings: list[Finding] = []
    for path in _candidate_files(root):
        rel_path = _as_posix(path.relative_to(root))
        if _is_allowlisted(rel_path, allowlist):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for line_no, line in enumerate(text.splitlines(), start=1):
            if _line_is_safe_import(line):
                continue
            for reason, pattern in FORBIDDEN_PATTERNS:
                if pattern.search(line):
                    findings.append(
                        Finding(
                            rel_path,
                            line_no,
                            reason,
                            line.strip()[:220],
                        )
                    )
    return findings


def render(findings: list[Finding], limit: int = DEFAULT_LIMIT) -> str:
    if not findings:
        return (
            "PUBLIC UI DIRECT API GATE: OK — "
            "public UI does not call API directly."
        )
    lines = ["PUBLIC UI DIRECT API GATE: FAILED"]
    for item in findings[:limit]:
        lines.append(
            f"{item.path}:{item.line_no}: forbidden direct API usage "
            f"({item.reason}): {item.line}"
        )
    if len(findings) > limit:
        lines.append(
            f"... truncated {len(findings) - limit} "
            "additional findings"
        )
    lines.append(f"Total findings: {len(findings)}")
    lines.append(
        "Move API access to frontend/src/services/* "
        "and consume it through "
        "frontend/src/queries/*."
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--report", default="")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    findings = scan(root)
    output = render(findings)
    if args.report:
        report_path = root / args.report
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(output + "\n", encoding="utf-8")
    print(output)
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
