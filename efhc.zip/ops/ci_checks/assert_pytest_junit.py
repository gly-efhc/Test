"""Fail closed on incomplete or skipped required pytest JUnit runs."""

from __future__ import annotations

import argparse
import xml.etree.ElementTree as ET
from pathlib import Path


def _int_attr(node: ET.Element, name: str) -> int:
    raw = node.attrib.get(name, "0")
    try:
        return int(float(raw))
    except ValueError as exc:
        raise SystemExit(f"invalid JUnit {name}={raw!r}") from exc


def _totals(root: ET.Element) -> tuple[int, int, int, int]:
    if root.tag == "testsuite":
        suites = [root]
    else:
        suites = list(root.findall("testsuite"))
        if not suites:
            suites = list(root.findall(".//testsuite"))
    if not suites:
        raise SystemExit("JUnit report contains no testsuite")

    tests = sum(_int_attr(node, "tests") for node in suites)
    failures = sum(_int_attr(node, "failures") for node in suites)
    errors = sum(_int_attr(node, "errors") for node in suites)
    skipped = sum(_int_attr(node, "skipped") for node in suites)
    return tests, failures, errors, skipped


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--min-tests", type=int, required=True)
    parser.add_argument("--max-skipped", type=int, default=0)
    args = parser.parse_args()

    if not args.report.is_file():
        raise SystemExit(f"JUnit report not found: {args.report}")
    root = ET.parse(args.report).getroot()
    tests, failures, errors, skipped = _totals(root)
    summary = (
        f"tests={tests} failures={failures} "
        f"errors={errors} skipped={skipped}"
    )
    print(f"pytest_junit {summary}")
    if tests < args.min_tests:
        message = (
            f"collected {tests} tests; expected at least "
            f"{args.min_tests}"
        )
        raise SystemExit(message)
    if failures or errors:
        raise SystemExit("JUnit report contains failures or errors")
    if skipped > args.max_skipped:
        message = (
            f"skipped {skipped} tests; maximum allowed is "
            f"{args.max_skipped}"
        )
        raise SystemExit(message)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
