#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import tomllib
from pathlib import Path

REQUIRED_DIRS = [
    "skills",
    "agents",
    "commands",
    ".claude/commands",
    ".gemini/commands",
    "references",
]

REQUIRED_FILES = [
    "AGENTS.md",
    "CLAUDE.md",
    "docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md",
    "docs/GENERAL/ORIGINAL_SOURCES/AGENT_SKILLS_UPSTREAM_INDEX.md",
]

AGENTS_ANCHORS = [
    "AI_ARCHIVE_LAWS",
    "AI_OPERATOR_RULES_EFHC",
    "AI_AGENT_SKILLS_EFHC_ADAPTER",
    "SSOT_INDEX",
    "ARCHITECTURAL_LOCKS",
    "Never claim GitHub CI green from local checks",
]

COMMAND_FORBIDDEN_DEFAULTS = [
    "create SPEC.md",
    "write SPEC.md",
    "default SPEC.md",
    "create tasks/plan.md",
    "write tasks/plan.md",
    "default tasks/plan.md",
]

SHIP_FORBIDDEN_CLAIMS = [
    "production-ready without current evidence",
    "release-ready without current evidence",
]

PERSONA_FILES = [
    "agents/code-reviewer.md",
    "agents/security-auditor.md",
    "agents/test-engineer.md",
    "agents/web-performance-auditor.md",
]

BROKEN_PERSONA_LINK = "../docs/agents.md"
EFHC_ADAPTER_LINK = "../docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md"

USING_FORBIDDEN = [
    "even 1% chance",
    "Always check for and use skills first",
    "Never implement directly if a skill applies",
]


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _toml_files(root: Path) -> list[Path]:
    paths: list[Path] = []
    for base in ["commands", ".gemini/commands"]:
        folder = root / base
        if folder.exists():
            paths.extend(sorted(folder.glob("*.toml")))
    return paths


def _commands(root: Path) -> list[Path]:
    paths: list[Path] = []
    for base in ["commands", ".claude/commands", ".gemini/commands"]:
        folder = root / base
        if folder.exists():
            paths.extend(p for p in folder.rglob("*") if p.is_file())
    return sorted(paths)


def validate(root: Path) -> list[str]:
    errors: list[str] = []

    for item in REQUIRED_FILES:
        if not (root / item).is_file():
            errors.append(f"missing required file: {item}")

    for item in REQUIRED_DIRS:
        if not (root / item).is_dir():
            errors.append(f"missing required directory: {item}")

    agents = root / "AGENTS.md"
    if agents.is_file():
        text = _read(agents)
        for anchor in AGENTS_ANCHORS:
            if anchor not in text:
                errors.append(f"AGENTS.md missing anchor: {anchor}")

    adapter = root / "docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md"
    if adapter.is_file():
        text = _read(adapter)
        anchors = [
            "Threshold model",
            "P0",
            "P1",
            "P2",
            "production-ready",
        ]
        for anchor in anchors:
            if anchor not in text:
                errors.append(f"adapter missing anchor: {anchor}")

    using = root / "skills/using-agent-skills/SKILL.md"
    if using.is_file():
        text = _read(using)
        for marker in USING_FORBIDDEN:
            if marker in text:
                errors.append(
                    "using-agent-skills has upstream absolute: "
                    f"{marker}"
                )
        if "EFHC threshold model" not in text:
            errors.append(
                "using-agent-skills missing EFHC threshold model"
            )

    for path in _commands(root):
        text = _read(path)
        rel = path.relative_to(root).as_posix()
        for marker in COMMAND_FORBIDDEN_DEFAULTS:
            if marker in text and "Do not" not in text:
                errors.append(
                    f"{rel} contains forbidden default artifact: "
                    f"{marker}"
                )
        if rel.endswith(("ship.toml", "ship.md")):
            for claim in SHIP_FORBIDDEN_CLAIMS:
                if claim not in text:
                    errors.append(
                        f"{rel} missing ship evidence boundary: "
                        f"{claim}"
                    )

    for path in _toml_files(root):
        rel = path.relative_to(root).as_posix()
        try:
            tomllib.loads(_read(path))
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{rel} is invalid TOML: {exc}")

    for item in PERSONA_FILES:
        path = root / item
        if not path.is_file():
            errors.append(f"missing persona file: {item}")
            continue
        text = _read(path)
        if BROKEN_PERSONA_LINK in text:
            errors.append(
                f"{item} contains broken link: "
                f"{BROKEN_PERSONA_LINK}"
            )
        if EFHC_ADAPTER_LINK not in text:
            errors.append(f"{item} missing EFHC adapter reference")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--json-report", default=None)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    errors = validate(root)
    result = {"status": "fail" if errors else "ok", "errors": errors}
    if args.json_report:
        Path(args.json_report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json_report).write_text(
            json.dumps(result, indent=2),
            encoding="utf-8",
        )
    if errors:
        print("AGENT SKILLS ADAPTER: FAIL")
        for err in errors[:200]:
            print(f"- {err}")
        if len(errors) > 200:
            print(f"... {len(errors) - 200} more")
        return 1
    print(
        "AGENT SKILLS ADAPTER: OK — "
        "EFHC adapter contract is present."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
