#!/usr/bin/env python3
"""Run the exact unique pytest inventory in deterministic batches."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

SUMMARY_KEYS = ("passed", "skipped", "failed", "errors", "xfailed")


def collect_nodes(
    root: Path,
    marker_expression: str | None,
) -> list[str]:
    env = {**os.environ, "PYTHONPATH": "backend"}
    command = [
        sys.executable,
        "-m",
        "pytest",
        "--collect-only",
        "-q",
    ]
    if marker_expression:
        command.extend(["-m", marker_expression])
    result = subprocess.run(
        command,
        cwd=root,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        sys.stderr.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise SystemExit(result.returncode)
    nodes: list[str] = []
    seen: set[str] = set()
    for line in result.stdout.splitlines():
        node = line.strip()
        if "::" not in node or node.startswith("<") or node in seen:
            continue
        seen.add(node)
        nodes.append(node)
    if not nodes:
        raise SystemExit("pytest inventory is empty")
    return nodes


def parse_summary(text: str) -> dict[str, int]:
    counts = {key: 0 for key in SUMMARY_KEYS}
    for key in SUMMARY_KEYS:
        matches = re.findall(rf"(\d+)\s+{key}\b", text)
        if matches:
            counts[key] = int(matches[-1])
    singular = re.findall(r"(\d+)\s+error\b", text)
    if singular:
        counts["errors"] = int(singular[-1])
    return counts


def write_report(
    output: Path,
    nodes: list[str],
    batch_size: int,
    batch_rows: list[dict[str, object]],
    failures: list[dict[str, object]],
    marker_expression: str | None,
) -> dict[str, object]:
    totals = {key: 0 for key in SUMMARY_KEYS}
    accounted_nodes = 0
    for row in batch_rows:
        accounted_nodes += int(row["node_count"])
        for key in SUMMARY_KEYS:
            totals[key] += int(row[key])
    result_count = sum(totals.values())
    complete = accounted_nodes == len(nodes)
    report: dict[str, object] = {
        "schema": "EFHC_FULL_REGRESSION_INVENTORY_V2",
        "inventory": len(nodes),
        "unique_nodes": len(set(nodes)),
        "duplicates": len(nodes) - len(set(nodes)),
        "batch_size": batch_size,
        "marker_expression": marker_expression,
        "batches": sorted(
            batch_rows,
            key=lambda row: int(row["batch"]),
        ),
        "totals": {
            **totals,
            "omitted": max(0, len(nodes) - result_count),
        },
        "failed_batches": failures,
        "completed_nodes": accounted_nodes,
        "status": (
            "PASSED"
            if complete and not failures and result_count == len(nodes)
            else "IN_PROGRESS" if not complete else "FAILED"
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--batch-size", type=int, default=200)
    parser.add_argument(
        "--output",
        default="reports/generated/full_regression_current.json",
    )
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--marker-expression",
        default=None,
        help="pytest -m expression used while collecting the inventory",
    )
    args = parser.parse_args()
    root = Path(args.root).resolve()
    output = root / args.output
    nodes = collect_nodes(root, args.marker_expression)
    previous_rows: list[dict[str, object]] = []
    if args.resume and output.exists():
        previous = json.loads(output.read_text())
        if (
            previous.get("inventory") == len(nodes)
            and previous.get("batch_size") == args.batch_size
            and previous.get("marker_expression")
            == args.marker_expression
        ):
            previous_rows = [
                row
                for row in previous.get("batches", [])
                if int(row.get("returncode", 1)) == 0
            ]
    done_batches = {int(row["batch"]) for row in previous_rows}
    batch_rows = list(previous_rows)
    failures: list[dict[str, object]] = []
    env = {**os.environ, "PYTHONPATH": "backend"}
    for start in range(0, len(nodes), args.batch_size):
        batch = nodes[start : start + args.batch_size]
        index = start // args.batch_size + 1
        if index in done_batches:
            print(f"batch={index} resume=skip")
            continue
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", *batch],
            cwd=root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        text = f"{result.stdout}\n{result.stderr}"
        counts = parse_summary(text)
        row: dict[str, object] = {
            "batch": index,
            "first_node": batch[0],
            "last_node": batch[-1],
            "node_count": len(batch),
            "returncode": result.returncode,
            **counts,
        }
        batch_rows = [
            existing
            for existing in batch_rows
            if int(existing["batch"]) != index
        ]
        batch_rows.append(row)
        if result.returncode != 0:
            failures.append({**row, "tail": text.splitlines()[-160:]})
        report = write_report(
            output,
            nodes,
            args.batch_size,
            batch_rows,
            failures,
            args.marker_expression,
        )
        print(
            f"batch={index} nodes={len(batch)} rc={result.returncode} "
            f"passed={counts['passed']} skipped={counts['skipped']} "
            f"status={report['status']}"
        )
    report = write_report(
        output,
        nodes,
        args.batch_size,
        batch_rows,
        failures,
        args.marker_expression,
    )
    print(
        f"inventory={len(nodes)} completed={report['completed_nodes']} "
        f"status={report['status']} output={output}"
    )
    return 0 if report["status"] == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
