#!/usr/bin/env python3
"""Fail the release when technical copy appears in public UI text.

The scanner is scoped to user-visible copy. It scans locale values,
JSX text nodes and likely visible string attributes. It skips backend,
docs and test internals.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

DEFAULT_POLICY = Path("ops/policy/public_ui_forbidden_copy.json")
MAX_FINDINGS = 200
VISIBLE_ATTRS = {
    "alt",
    "aria-label",
    "detail",
    "label",
    "placeholder",
    "subtitle",
    "text",
    "title",
}
STRING_RE = re.compile(r"(['\"])((?:\\.|(?!\1).)*?)\1")
JSX_TEXT_RE = re.compile(r">([^<>{}][^<>{}]*)<")
ATTR_NAMES_RE = "|".join(
    re.escape(a) for a in sorted(VISIBLE_ATTRS)
)
ATTR_RE = re.compile(
    r"(?:" + ATTR_NAMES_RE + r")"
    r"\s*=\s*(['\"])((?:\\.|(?!\1).)*?)\1"
)


@dataclass(frozen=True)
class Finding:
    path: Path
    line: int
    term: str
    snippet: str


def load_policy(root: Path) -> dict[str, Any]:
    policy_path = root / DEFAULT_POLICY
    with policy_path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def term_pattern(term: str) -> re.Pattern[str]:
    escaped = re.escape(term)
    if re.fullmatch(r"[A-Za-z0-9]+", term):
        escaped = rf"(?<![A-Za-z0-9_]){escaped}(?![A-Za-z0-9_])"
    return re.compile(escaped, re.IGNORECASE)


def iter_scan_files(
    root: Path,
    policy: dict[str, Any],
) -> Iterable[Path]:
    suffixes = set(policy.get("file_extensions", []))
    for rel in policy.get("public_scan_paths", []):
        base = root / rel
        if not base.exists():
            continue
        if base.is_file():
            candidates = [base]
        else:
            candidates = [p for p in base.rglob("*") if p.is_file()]
        for path in candidates:
            if path.suffix not in suffixes:
                continue
            rel_posix = "/" + path.relative_to(root).as_posix()
            if is_technical_zone(rel_posix, policy):
                continue
            yield path


def is_technical_zone(rel_posix: str, policy: dict[str, Any]) -> bool:
    excluded_roots = (
        "/docs/",
        "/reports/generated/",
        "/tests/",
        "/backend/",
        "/migrations/",
        "/scripts/",
        "/ops/",
        "/node_modules/",
        "/dist/",
        "/build/",
        "/.next/",
        "/coverage/",
        "/frontend/src/pages/api/",
    )
    if any(part in rel_posix for part in excluded_roots):
        return True
    return any(
        part in rel_posix
        for part in policy.get("technical_zone_path_parts", [])
    )


def line_of(text: str, needle: str, default: int = 1) -> int:
    idx = text.find(needle)
    if idx < 0:
        return default
    return text.count("\n", 0, idx) + 1


def json_candidates(
    text: str,
    policy: dict[str, Any],
) -> Iterable[tuple[int, str]]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return []
    prefixes = tuple(policy.get("locale_key_prefix_exclusions", []))
    items: list[tuple[int, str]] = []

    def walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key_path:
                    child_key = f"{key_path}.{key}"
                else:
                    child_key = str(key)
                walk(child, child_key)
            return
        if isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{key_path}.{index}")
            return
        if not isinstance(value, str):
            return
        if key_path.startswith(prefixes):
            return
        value_json = json.dumps(value, ensure_ascii=False)
        items.append((line_of(text, value_json), value))

    walk(payload)
    return items


def source_candidates(text: str) -> Iterable[tuple[int, str]]:
    for match in ATTR_RE.finditer(text):
        raw = match.group(2)
        yield text.count("\n", 0, match.start(2)) + 1, unescape_js(raw)
    for match in JSX_TEXT_RE.finditer(text):
        value = " ".join(match.group(1).split())
        if value and likely_visible_literal(value):
            yield text.count("\n", 0, match.start(1)) + 1, value
    for match in STRING_RE.finditer(text):
        raw = match.group(2)
        value = unescape_js(raw)
        if likely_visible_literal(value):
            yield text.count("\n", 0, match.start(2)) + 1, value


def unescape_js(raw: str) -> str:
    try:
        return ast.literal_eval(f'"{raw}"')
    except Exception:
        return raw


def likely_visible_literal(value: str) -> bool:
    value = value.strip()
    if not value:
        return False
    technical_prefixes = ("/", "./", "../", "http", "ws", "#", ".")
    if value.startswith(technical_prefixes):
        return False
    if any(token in value for token in (";", "=>", "=", "||", "&&")):
        return False
    if re.fullmatch(r"[A-Za-z0-9_.:-]+", value):
        return False
    return " " in value or bool(re.search(r"[А-Яа-яІіЇїЄєҐґ]", value))


def scan(root: Path) -> list[Finding]:
    policy = load_policy(root)
    patterns = [
        (term, term_pattern(term))
        for term in policy["forbidden_terms"]
    ]
    findings: list[Finding] = []
    for path in iter_scan_files(root, policy):
        rel = path.relative_to(root)
        text = path.read_text(encoding="utf-8", errors="replace")
        if path.suffix == ".json":
            candidates = json_candidates(text, policy)
        else:
            candidates = source_candidates(text)
        for line, value in candidates:
            for term, pattern in patterns:
                if not pattern.search(value):
                    continue
                snippet = " ".join(value.split())[:160]
                findings.append(Finding(rel, line, term, snippet))
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    findings = scan(root)
    if not findings:
        print(
            "PUBLIC UI COPY GUARD: OK — "
            "forbidden technical copy not found."
        )
        return 0
    print("PUBLIC UI COPY GUARD: FAIL")
    for finding in findings[:MAX_FINDINGS]:
        print(
            f"{finding.path}:{finding.line} forbidden="
            f"'{finding.term}': {finding.snippet!r}"
        )
    if len(findings) > MAX_FINDINGS:
        remaining = len(findings) - MAX_FINDINGS
        print(f"... truncated: {remaining} more findings")
    print(f"Total findings: {len(findings)}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
