"""Fail-closed проверка immutable истории нумерованных отчётов."""
from __future__ import annotations

import csv
import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT_DIR = ROOT / "reports/numbered"
MANIFEST = ROOT / "reports/manifests/REPORTS_NUMBERING_MANIFEST.csv"
PATTERN = re.compile(r"^reports_(\d{5})__")


def check() -> dict[str, object]:
    violations: list[str] = []
    files: dict[int, Path] = {}
    for path in REPORT_DIR.glob("reports_*__*"):
        match = PATTERN.match(path.name)
        if not match:
            continue
        number = int(match.group(1))
        if number in files:
            violations.append(f"duplicate report number {number:05d}")
        files[number] = path
    if files:
        expected = set(range(1, max(files) + 1))
        missing = sorted(expected - set(files))
        if missing:
            violations.append(f"missing report numbers: {missing[:20]}")
    rows: dict[int, dict[str, str]] = {}
    if not MANIFEST.exists():
        violations.append("reports manifest missing")
    else:
        with MANIFEST.open(encoding="utf-8-sig", newline="") as file:
            for row in csv.DictReader(file):
                try:
                    number = int(row["report_number"])
                except (KeyError, ValueError):
                    continue
                rows[number] = row
        for number, path in files.items():
            row = rows.get(number)
            if row is None:
                violations.append(f"manifest row missing: {number:05d}")
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if row.get("sha256") != digest:
                violations.append(f"sha256 mismatch: {number:05d}")
    return {
        "passed": not violations,
        "report_count": len(files),
        "max_report_number": max(files, default=0),
        "violations": violations,
    }


def main() -> int:
    result = check()
    print(result)
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
