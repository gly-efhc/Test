"""Создание следующего immutable нумерованного отчёта EFHC.

Один завершённый пользовательский запрос создаёт один новый numbered report,
а каждый завершённый цикл обязан иметь хотя бы один такой отчёт. История
хранится в ``reports/numbered`` и не участвует в active runtime.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT_DIR = ROOT / "reports/numbered"
MANIFEST = ROOT / "reports/manifests/REPORTS_NUMBERING_MANIFEST.csv"
PATTERN = re.compile(r"^reports_(\d{5})__")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _next_number() -> int:
    numbers = []
    for path in REPORT_DIR.glob("reports_*__*"):
        match = PATTERN.match(path.name)
        if match:
            numbers.append(int(match.group(1)))
    return max(numbers, default=0) + 1


def _slug(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9А-Яа-я_-]+", "_", value.strip())
    return text.strip("_")[:80] or "report"


def create_report(*, cycle: int, title: str, body_file: Path, status: str) -> Path:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    number = _next_number()
    target = REPORT_DIR / f"reports_{number:05d}__cycle_{cycle}_{_slug(title)}.md"
    body = body_file.read_text(encoding="utf-8")
    header = (
        f"# {title}\n\n"
        f"- Report number: `reports_{number:05d}`\n"
        f"- Cycle: `{cycle}`\n"
        f"- Created UTC: `{datetime.now(UTC).isoformat()}`\n"
        f"- Status: `{status}`\n\n"
    )
    target.write_text(header + body.rstrip() + "\n", encoding="utf-8")
    row = {
        "report_number": str(number),
        "old_path": f"generated:cycle:{cycle}:{title}",
        "new_path": str(target.relative_to(ROOT)),
        "sha256": _sha256(target),
        "detected_cycle": str(cycle),
        "detected_date": datetime.now(UTC).date().isoformat(),
        "status": status,
    }
    rows: list[dict[str, str]] = []
    if MANIFEST.exists():
        with MANIFEST.open(encoding="utf-8-sig", newline="") as file:
            rows = list(csv.DictReader(file))
    rows.append(row)
    with MANIFEST.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(row))
        writer.writeheader()
        writer.writerows(rows)
    print(target.relative_to(ROOT))
    return target


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cycle", type=int, required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--body-file", type=Path, required=True)
    parser.add_argument("--status", default="CURRENT_CYCLE_REPORT")
    args = parser.parse_args()
    create_report(
        cycle=args.cycle,
        title=args.title,
        body_file=args.body_file,
        status=args.status,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
