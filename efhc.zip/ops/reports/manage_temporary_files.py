#!/usr/bin/env python3
"""Сканировать и безопасно очищать временные файлы EFHC по machine registry."""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import shutil
import sys
import tempfile
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / "reports/manifests/TEMPORARY_FILES_REGISTRY.json"
PLAN = ROOT / "reports/generated/temp_cleanup_plan.json"
RECEIPT = ROOT / "reports/generated/temp_cleanup_receipt.json"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_registry() -> dict[str, Any]:
    return json.loads(REGISTRY.read_text(encoding="utf-8"))


def _matches(pattern: str, rel: str) -> bool:
    return fnmatch.fnmatch(rel, pattern) or Path(rel).match(pattern)


def scan() -> dict[str, Any]:
    registry = _load_registry()
    # Старый plan/receipt сами являются временными и очищаются перед новым scan.
    for transient in (PLAN, RECEIPT):
        if transient.exists():
            transient.unlink()
    matched: dict[str, dict[str, Any]] = {}
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        for rule in registry["rules"]:
            if any(_matches(pattern, rel) for pattern in rule["patterns"]):
                matched.setdefault(
                    rel,
                    {
                        "path": rel,
                        "rule": rule["id"],
                        "class": rule["class"],
                        "size": path.stat().st_size,
                        "sha256": _sha256(path),
                    },
                )
                break
    result = {
        "schema": "EFHC_TEMPORARY_FILES_SCAN_V1",
        "version": registry["version"],
        "cycle": registry["cycle"],
        "matches": list(matched.values()),
        "match_count": len(matched),
    }
    PLAN.parent.mkdir(parents=True, exist_ok=True)
    PLAN.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def _archive_exact_bytes(archive: Path, items: list[dict[str, Any]]) -> None:
    archive.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip", dir=archive.parent) as tmp:
        temp_path = Path(tmp.name)
    try:
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED) as out:
            if archive.exists():
                with zipfile.ZipFile(archive, "r") as source:
                    for info in source.infolist():
                        out.writestr(info, source.read(info.filename))
            for item in items:
                source_path = ROOT / item["path"]
                out.write(source_path, f"TEMPORARY_FILES/{stamp}/{item['path']}")
            out.writestr(
                f"TEMPORARY_FILES/{stamp}/MANIFEST.json",
                json.dumps(items, ensure_ascii=False, indent=2) + "\n",
            )
        with zipfile.ZipFile(temp_path, "r") as check:
            bad = check.testzip()
            if bad is not None:
                raise RuntimeError(f"archive integrity failed at {bad}")
        temp_path.replace(archive)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def clean(*, execute: bool, archive: Path | None) -> dict[str, Any]:
    plan = scan()
    if not execute:
        return {**plan, "status": "PREVIEW_ONLY"}
    review = [item for item in plan["matches"] if item["class"] == "REVIEW"]
    if review:
        return {**plan, "status": "USER_REVIEW_REQUIRED", "review": review}
    archive_items = [
        item for item in plan["matches"] if item["class"] == "ARCHIVE_THEN_DELETE"
    ]
    if archive_items and archive is None:
        return {**plan, "status": "ARCHIVE_REQUIRED", "archive_required": archive_items}
    if archive_items and archive is not None:
        _archive_exact_bytes(archive, archive_items)
    deleted: list[dict[str, Any]] = []
    for item in plan["matches"]:
        if item["class"] not in {"DELETE_DIRECT", "ARCHIVE_THEN_DELETE"}:
            continue
        path = ROOT / item["path"]
        if path.exists():
            path.unlink()
            deleted.append(item)
    # Удалить опустевшие cache/temp каталоги, но не source directories.
    for directory in sorted(ROOT.rglob("*"), reverse=True):
        if directory.is_dir() and directory.name in {
            "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"
        }:
            shutil.rmtree(directory, ignore_errors=True)
    receipt = {
        "schema": "EFHC_TEMPORARY_FILES_CLEANUP_RECEIPT_V1",
        "status": "EXECUTED",
        "archive": str(archive) if archive is not None else None,
        "deleted": deleted,
        "deleted_count": len(deleted),
    }
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scan", action="store_true")
    parser.add_argument("--clean", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    if args.clean:
        result = clean(execute=args.execute, archive=args.archive)
    else:
        result = scan()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
