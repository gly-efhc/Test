#!/usr/bin/env python3
"""Fail-closed guard для cycle 1704: история, Kernel и RELEASE boundaries."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPORT_PATTERN = re.compile(r"^reports_(\d{5})__")
CANONICAL_CYCLE_RANGES = tuple(
    f"WORK_CYCLES_{start:04d}-{start + 99:04d}.md"
    for start in range(1, 1801, 100)
)
ACTIVE_AUTHORITY = (
    "KERNEL.md",
    "START_HERE.md",
    "CONTRIBUTING.md",
    "README_RELEASE.md",
    "docs/SSOT/SSOT_INDEX.md",
    "docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md",
    "docs/SSOT/DOCUMENT_LAYER_CANON.md",
    "docs/SSOT/EFHC_OPERATOR_KERNEL_SSOT.md",
    "docs/SSOT/GLOBAL_IDENTITY_SSOT.md",
    "docs/SSOT/CURRENT_RELEASE_STATE.md",
    "docs/NORM/ARCHITECTURAL_LOCKS.md",
    "docs/NORM/IMMUTABLE_HISTORY_NORM.md",
    "docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md",
)
FORBIDDEN_ACTIVE_PREFIX = "docs/history/legacy_artifacts/"
FORBIDDEN_RELEASE_PREFIXES = (
    "docs/",
    "reports/",
    "tests/",
    "skills/",
    "agents/",
    "commands/",
    "hooks/",
    "references/",
    "АРТЕФАКТЫ/",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _check_manifest_paths(
    root: Path,
    rows: list[dict[str, str]],
    path_key: str,
    violations: list[str],
) -> None:
    for row in rows:
        rel = row.get(path_key, "")
        path = root / rel
        if not path.is_file():
            violations.append(f"manifest_missing:{rel}")
            continue
        if row.get("sha256") != _sha256(path):
            violations.append(f"manifest_sha_mismatch:{rel}")


def check(root: Path = ROOT, release_zip: Path | None = None) -> dict[str, object]:
    root = root.resolve()
    violations: list[str] = []

    for forbidden in (root / "АРТЕФАКТЫ", root / "docs/history"):
        if forbidden.exists():
            violations.append(f"forbidden_history_root:{forbidden.relative_to(root)}")

    cycle_dir = root / "docs/cycles"
    cycle_names = tuple(sorted(p.name for p in cycle_dir.glob("WORK_CYCLES_*.md")))
    if cycle_names != CANONICAL_CYCLE_RANGES:
        violations.append("canonical_cycle_ranges_mismatch")

    cycle_rows = _csv_rows(root / "reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv")
    if len(cycle_rows) != len(CANONICAL_CYCLE_RANGES):
        violations.append(f"cycle_manifest_count:{len(cycle_rows)}")
    _check_manifest_paths(root, cycle_rows, "archive_path", violations)

    chat_rows = _csv_rows(root / "reports/manifests/CHAT_ARCHIVE_MANIFEST.csv")
    _check_manifest_paths(root, chat_rows, "new_path", violations)

    report_dir = root / "reports/numbered"
    reports: dict[int, Path] = {}
    for path in report_dir.glob("reports_*__*"):
        match = REPORT_PATTERN.match(path.name)
        if match:
            reports[int(match.group(1))] = path
    if not reports:
        violations.append("numbered_reports_empty")
    else:
        maximum = max(reports)
        missing = sorted(set(range(1, maximum + 1)) - set(reports))
        if missing:
            violations.append(f"numbered_reports_gaps:{missing[:20]}")

    report_rows = _csv_rows(root / "reports/manifests/REPORTS_NUMBERING_MANIFEST.csv")
    row_by_number = {
        int(row["report_number"]): row
        for row in report_rows
        if row.get("report_number", "").isdigit()
    }
    for number, path in reports.items():
        row = row_by_number.get(number)
        if row is None:
            violations.append(f"report_manifest_missing:{number:05d}")
        elif row.get("sha256") != _sha256(path):
            violations.append(f"report_manifest_sha_mismatch:{number:05d}")

    for rel in ACTIVE_AUTHORITY:
        path = root / rel
        if not path.is_file():
            violations.append(f"active_authority_missing:{rel}")
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if FORBIDDEN_ACTIVE_PREFIX in text:
            violations.append(f"active_authority_legacy_history_dependency:{rel}")

    file_map = root / "ops/operator_kernel/cache/file_map.json"
    if file_map.is_file():
        data = json.loads(file_map.read_text(encoding="utf-8"))
        for entry in data.get("entries", []):
            rel = str(entry.get("path", ""))
            if rel.startswith(("docs/history/", "АРТЕФАКТЫ/")):
                violations.append(f"kernel_file_map_forbidden:{rel}")
                break

    if release_zip is not None:
        with zipfile.ZipFile(release_zip) as archive:
            names = archive.namelist()
            bad = [
                name
                for name in names
                if name.startswith(FORBIDDEN_RELEASE_PREFIXES)
            ]
            if bad:
                violations.append(f"release_history_leak:{bad[:10]}")

    return {
        "passed": not violations,
        "cycle_range_count": len(cycle_names),
        "chat_manifest_entries": len(chat_rows),
        "numbered_report_count": len(reports),
        "numbered_report_max": max(reports, default=0),
        "violations": violations,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-zip", type=Path)
    args = parser.parse_args()
    result = check(ROOT, args.release_zip)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
