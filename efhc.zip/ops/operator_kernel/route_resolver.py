"""Resolve EFHC task types through routes.yaml primary configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ops.operator_kernel.config_loader import load_routes_config

TONCONNECT_WALLET_UX_RANGE_CLOSURE_REPORT = (
    "reports/generated/tonconnect_wallet_ux_range_closure_v169_54.json"
)

FALLBACK_START_CORE = [
    "START_HERE.md",
    "KERNEL.md",
    "docs/AI/AI_ARCHIVE_LAWS.md",
    "docs/AI/AI_ARCHIVE_LAWS_LOCK.json",
    "docs/SSOT/AI_ARCHIVE_LAWS_CANON.md",
    "docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md",
    "docs/AI/AI_OPERATOR_RULES_EFHC.md",
    "docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md",
    "docs/SSOT/SSOT_INDEX.md",
    "docs/NORM/ARCHITECTURAL_LOCKS.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md",
    "docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md",
    "ops/operator_kernel/cache/file_map.summary.json",
]

FALLBACK_ROUTES: dict[str, dict[str, list[str]]] = {
    "wallet_provider_adapter_work": {
        "docs": [
            "KERNEL.md",
            "docs/SSOT/WALLET_PROVIDER_SSOT.md",
            "docs/NORM/WALLET_PROVIDER_ADAPTER_NORM.md",
            "docs/SSOT/WALLETS_TONCONNECT_SSOT.md",
        ],
        "code_globs": [
            "frontend/src/lib/wallet-provider/**/*",
            "frontend/src/pages/_app.tsx",
            "frontend/src/components/Layout.tsx",
            "frontend/src/components/DepositModal.tsx",
            "frontend/src/features/browser-shop/BrowserShopPage.tsx",
            "frontend/src/pages/admin/withdrawals.tsx",
            "tests/architecture/test_wallet_provider_adapter_layer.py",
        ],
        "restricted": [
            "backend/app/**/*",
            "backend/migrations/**/*",
            "invented unpublished wallet API",
            "live transaction proof claims",
        ],
    },
    "cycle_1574_local_release_candidate_audit": {
        "docs": [
            "KERNEL.md",
            "docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md",
            "docs/SSOT/CURRENT_RELEASE_STATE.md",
            "docs/cycles/WORK_CYCLES.md",
        ],
        "code_globs": [
            "ops/healer/check_critical_delivery_protocol.py",
            "ops/release/live_contour_gate.py",
            "tests/healer/test_critical_delivery_protocol.py",
            (
                "reports/generated/"
                "cycle_1573_external_deferral_v171_65.json"
            ),
        ],
        "restricted": [
            "release-ready claim without evidence",
            "repeated unavailable external checks",
        ],
    },
    "cycle_1573_close_visual_live_proof": {
        "docs": [
            "KERNEL.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/SSOT/WALLETS_TONCONNECT_SSOT.md",
            "docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md",
        ],
        "code_globs": [
            "ops/release/live_contour_gate.py",
            "ops/frontend/route_backed_visual_audit_v171_61.py",
            (
                "tests/architecture/"
                "test_kernel_compound_routing_v171_63.py"
            ),
        ],
        "restricted": [
            "frontend/src/**/*",
            "backend/app/**/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "control_docs_optimization": {
        "docs": [
            "KERNEL.md",
            "docs/AI/AI_DOCS_INDEX.md",
            "docs/SSOT/SSOT_INDEX.md",
            "docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md",
        ],
        "code_globs": [
            "ops/operator_kernel/**/*.py",
            (
                "tests/architecture/"
                "test_control_docs_compaction_v171_63.py"
            ),
        ],
        "restricted": [
            "frontend/**/*",
            "backend/**/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "tonconnect_wallet_ux_range_closure": {
        "docs": [
            (
                "docs/frontend/"
                "TONCONNECT_WALLET_UX_PROOF_AND_RANGE_CLOSURE.md"
            ),
            (
                "docs/audits/"
                "TONCONNECT_WALLET_UX_RANGE_CLOSURE_AUDIT_V169_54.md"
            ),
            TONCONNECT_WALLET_UX_RANGE_CLOSURE_REPORT,
            "docs/SSOT/WALLETS_TONCONNECT_SSOT.md",
            "docs/SSOT/TON_MEMO_SPEC.md",
            "docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md",
            "docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/src/pages/app.tsx",
            "frontend/src/lib/tonconnect.ts",
            "frontend/src/components/Layout.tsx",
            "frontend/src/components/DepositModal.tsx",
            "frontend/src/components/profile/**/*.tsx",
            "frontend/src/features/browser-shop/**/*.tsx",
            (
                "tests/architecture/"
                "test_tonconnect_wallet_ux_range_closure.py"
            ),
        ],
        "restricted": [
            "backend/**/*",
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "telegram_mini_app_shell_polish": {
        "docs": [
            "docs/frontend/TELEGRAM_MINI_APP_SHELL_POLISH.md",
            (
                "docs/audits/"
                "TELEGRAM_MINI_APP_SHELL_POLISH_AUDIT_V169_53.md"
            ),
            (
                "reports/generated/"
                "telegram_mini_app_shell_polish_v169_53.json"
            ),
            "docs/SSOT/TELEGRAM_WEBAPP_INTEGRATION.md",
            "docs/frontend/FRONTEND_SHELL_ARCHITECTURE.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/src/lib/telegram.ts",
            "frontend/src/components/Layout.tsx",
            "frontend/src/pages/app.tsx",
            "frontend/src/styles/globals.css",
            "tests/architecture/test_telegram_mini_app_shell_polish.py",
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "backend/**/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "language_canon_ru_source_lock": {
        "docs": [
            "docs/SSOT/LANGUAGE_CANON_SSOT.md",
            "docs/NORM/LOCALIZATION_WORKFLOW_NORM.md",
            "docs/AI/AI_OPERATOR_RULES_EFHC.md",
            "docs/AI/TOPIC_READING_ROUTES.md",
            "docs/AI/FAQ_READING_POLICY.md",
            "docs/GENERAL/CURRENT_DECISIONS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/public/locale/ru.json",
            "frontend/public/locale/en.json",
            "ops/i18n/audit_ru_translation_source_canon.py",
            "tests/architecture/test_language_canon_ru_source_lock.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "ci_log_repair": {
        "docs": [
            "docs/AI/AI_OPERATOR_RULES_EFHC.md",
            "docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md",
            "docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md",
        ],
        "code_globs": [
            "requirements-test.txt",
            "backend/requirements.txt",
            "tests/**/*.py",
            "ops/**/*.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "faq_semantic_approval_gate": {
        "docs": [
            "docs/frontend/FAQ_SEMANTIC_APPROVAL_GATE.md",
            "docs/audits/FAQ_SEMANTIC_APPROVAL_GATE_AUDIT_V169_51.md",
            "reports/generated/faq_semantic_approval_gate_v169_51.json",
            "docs/GENERAL/CURRENT_DECISIONS.md",
            "docs/SSOT/FAQ_SSOT.md",
            "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json",
            "docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md",
            "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "docs/SSOT/faq_ssot/*/faq_*.json",
            "docs/SSOT/faq_ssot/*/faq_*.md",
            "frontend/src/data/faq/catalogs.ts",
            "tests/architecture/test_faq_catalogs_generated_from_ssot.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "faq_semantic_alignment_repair": {
        "docs": [
            "docs/frontend/FAQ_SEMANTIC_ALIGNMENT_REPAIR.md",
            "docs/audits/FAQ_SEMANTIC_ALIGNMENT_AUDIT_V169_50.md",
            (
                "reports/generated/"
                "faq_semantic_alignment_repair_v169_50.json"
            ),
            "docs/GENERAL/CURRENT_DECISIONS.md",
            "docs/SSOT/FAQ_SSOT.md",
            "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json",
            "docs/SSOT/faq_ssot/FAQ_APPROVAL_REGISTER.md",
            "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "docs/SSOT/faq_ssot/*/faq_*.json",
            "docs/SSOT/faq_ssot/*/faq_*.md",
            "frontend/src/data/faq/catalogs.ts",
            "tests/architecture/test_faq_banned_terms_absent.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "faq_wave3_translation_repair": {
        "docs": [
            "docs/frontend/FAQ_WAVE3_TRANSLATION_STATUS_REPAIR.md",
            "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md",
            "docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md",
            (
                "reports/generated/"
                "faq_wave3_translation_repair_v169_49.json"
            ),
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "docs/SSOT/faq_ssot/*/faq_*.json",
            "docs/SSOT/faq_ssot/*/faq_*.md",
            "frontend/src/data/faq/catalogs.ts",
            (
                "tests/architecture/"
                "test_faq_wave3_translation_status_repair.py"
            ),
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "public_i18n_untranslated_remediation": {
        "docs": [
            "docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md",
            "reports/generated/i18n_audit_summary_v169_45.json",
            "docs/frontend/I18N_CRITICAL_AUDIT_REPAIR_PASS.md",
            (
                "docs/frontend/"
                "PUBLIC_I18N_UNTRANSLATED_KEYS_REMEDIATION.md"
            ),
            "docs/SSOT/LANGUAGE_CANON_SSOT.md",
            "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/public/locale/*.json",
            "frontend/src/lib/i18n.ts",
            "ops/i18n/*.py",
            (
                "tests/architecture/"
                "test_public_i18n_untranslated_remediation.py"
            ),
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "i18n_critical_repair": {
        "docs": [
            "docs/audits/I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md",
            "reports/generated/i18n_audit_summary_v169_45.json",
            "docs/frontend/I18N_CRITICAL_AUDIT_REPAIR_PASS.md",
            "docs/audits/I18N_CRITICAL_REPAIR_AUDIT_V169_47.md",
            "docs/SSOT/LANGUAGE_CANON_SSOT.md",
            "docs/SSOT/faq_ssot/TRANSLATION_STATUS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/src/lib/i18n.ts",
            "frontend/public/locale/*.json",
            "frontend/src/pages/app.tsx",
            "frontend/src/components/ShopLayout.tsx",
            "ops/i18n/*.py",
            "tests/architecture/test_frontend_api_i18n_consistency.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "audit_fixes_implementation": {
        "docs": [
            "docs/audits/TZ_FIXES_AUDIT_v169_35.md",
            "docs/frontend/FRONTEND_AUDIT_FIXES_IMPLEMENTATION.md",
            "docs/admin/ADMIN_AUDIT_FIXES_RECOVERY.md",
            "docs/cycles/WORK_CYCLES.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/src/components/Layout.tsx",
            "frontend/src/features/admin/AdminSalePackagesPage.tsx",
            "frontend/src/pages/admin/efhc-deposits.tsx",
            "frontend/src/pages/*.tsx",
            "frontend/public/sw.js",
            "frontend/public/offline.html",
            "frontend/public/locale/*.json",
            "tests/architecture/test_*guard*.py",
            "tests/frontend/e2e/*.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "admin_recovery_checkpoint": {
        "docs": [
            "docs/cycles/WORK_CYCLES.md",
            (
                "docs/cycles/"
                "WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md"
            ),
            "docs/AI/AI_DOCS_INDEX.md",
            "docs/admin/ADMIN_RECOVERY_CHECKPOINT.md",
            "docs/admin/ADMIN_REGRESSION_PROOF_PASS.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "tests/architecture/test_active_document_surface.py",
            "tests/architecture/test_python_dunder_integrity.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "sandbox_elements_intake": {
        "docs": [
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md",
            "docs/frontend/FRONTEND_SANDBOX_REFERENCE.md",
            "docs/admin/ADMIN_SANDBOX_VISUAL_REFERENCE.md",
            "docs/admin/ADMIN_SANDBOX_PORTING_MAP.md",
        ],
        "code_globs": [
            "frontend/src/pages/**/*.tsx",
            "frontend/src/components/**/*.tsx",
            "tests/architecture/test_active_test_surface.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "admin_regression_proof": {
        "docs": [
            "docs/admin/ADMIN_REGRESSION_PROOF_PASS.md",
            "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md",
            "docs/admin/ADMIN_ROUTES_MAP.md",
            "docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md",
            "docs/NORM/ADMIN_RBAC.md",
        ],
        "code_globs": [
            "frontend/src/pages/admin/**/*.tsx",
            "frontend/src/components/admin/**/*.tsx",
            "backend/app/routes/admin_*.py",
            "tests/architecture/*admin*regression*.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "admin_docs_route_map": {
        "docs": [
            "docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md",
            "docs/admin/ADMIN_ROUTES_MAP.md",
            "docs/GENERAL/ADMIN_PANEL_SPEC.md",
            "docs/NORM/ADMIN_RBAC.md",
            "docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md",
        ],
        "code_globs": [
            "frontend/src/pages/admin/**/*.tsx",
            "frontend/src/components/admin/**/*.tsx",
            "backend/app/routes/admin_*.py",
            "tests/architecture/*admin*route*.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
    "admin_ui_recovery": {
        "docs": [
            "docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md",
            "docs/admin/ADMIN_DASHBOARD_UI_KIT_CANON.md",
        ],
        "code_globs": [
            "frontend/src/pages/admin/**/*.tsx",
            "frontend/src/components/admin/**/*.tsx",
            "backend/app/routes/admin_*.py",
            "backend/app/services/admin/*.py",
            "tests/architecture/*admin*.py",
        ],
        "restricted": [],
    },
    "public_visual_trust_hub_browser_shop_withdraw_ads": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_VISUAL_TRUST_PASS_HUB_BROWSER_"
                "SHOP_WITHDRAW_ADS.md"
            ),
            (
                "docs/frontend/"
                "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
            ),
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "reports/generated/public_visual_trust_pass_v169_46.json",
        ],
        "code_globs": [
            "frontend/src/features/hub/HubPage.tsx",
            "frontend/src/features/browser-shop/BrowserShopPage.tsx",
            "frontend/src/pages/hub.tsx",
            "frontend/src/pages/browser-shop.tsx",
            "frontend/src/pages/withdraw.tsx",
            "frontend/src/pages/ads.tsx",
            "frontend/src/styles/globals.css",
            (
                "tests/architecture/"
                "test_public_visual_trust_pass_hub_"
                "browser_shop_withdraw_"
                "ads.py"
            ),
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_visual_trust_profile_wallet_history_faq": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_VISUAL_TRUST_PASS_PROFILE_WALLET_HISTORY_FAQ.md"
            ),
            (
                "docs/frontend/"
                "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
            ),
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "reports/generated/public_visual_trust_pass_v169_45.json",
        ],
        "code_globs": [
            "frontend/src/features/profile/WebProfilePage.tsx",
            (
                "frontend/src/components/public/"
                "PublicProfileTrustLayer.tsx"
            ),
            "frontend/src/components/profile/ProfileWalletSection.tsx",
            "frontend/src/components/profile/ProfileHistorySection.tsx",
            "frontend/src/pages/web-profile.tsx",
            "frontend/src/pages/faq.tsx",
            "frontend/src/components/faq/FaqVerticalTree.tsx",
            "frontend/src/styles/globals.css",
            (
                "tests/architecture/"
                "test_public_visual_trust_pass_profile_wallet_history_"
                "faq.py"
            ),
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_visual_beauty_tasks_referrals_ranks": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_VISUAL_BEAUTY_PASS_TASKS_REFERRALS_RANKS.md"
            ),
            (
                "docs/frontend/"
                "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
            ),
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "reports/generated/public_visual_beauty_pass_v169_44.json",
        ],
        "code_globs": [
            (
                "frontend/src/components/public/"
                "PublicEngagementPreview.tsx"
            ),
            "frontend/src/pages/tasks.tsx",
            "frontend/src/pages/referrals.tsx",
            "frontend/src/pages/ranks.tsx",
            "frontend/src/styles/globals.css",
            (
                "tests/architecture/"
                "test_public_visual_beauty_pass_"
                "tasks_referrals_ranks.py"
            ),
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_visual_beauty_energy_panels_exchange": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_VISUAL_BEAUTY_PASS_ENERGY_PANELS_EXCHANGE.md"
            ),
            (
                "docs/frontend/"
                "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
            ),
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "reports/generated/public_visual_beauty_pass_v169_43.json",
        ],
        "code_globs": [
            (
                "frontend/src/components/public/"
                "PublicEnergyInteractiveOverview.tsx"
            ),
            (
                "frontend/src/components/public/"
                "PublicPanelsActivationPreview.tsx"
            ),
            (
                "frontend/src/components/public/"
                "PublicExchangeInteractivePreview.tsx"
            ),
            "frontend/src/pages/index.tsx",
            "frontend/src/pages/panels.tsx",
            "frontend/src/pages/exchange.tsx",
            "frontend/src/styles/globals.css",
            (
                "tests/architecture/"
                "test_public_visual_beauty_pass_"
                "energy_panels_exchange.py"
            ),
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_browser_screenshot_evidence": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_BROWSER_SCREENSHOT_EVIDENCE_HARNESS.md"
            ),
            (
                "reports/generated/"
                "public_browser_screenshot_capture_"
                "manifest_v169_42.json"
            ),
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md",
            "docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md",
            (
                "docs/cycles/"
                "WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md"
            ),
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            (
                "tests/frontend/e2e/"
                "test_public_screenshot_capture_manifest.py"
            ),
            (
                "tests/architecture/"
                "test_public_browser_screenshot_evidence_harness.py"
            ),
            "frontend/src/pages/index.tsx",
            "frontend/src/pages/panels.tsx",
            "frontend/src/pages/exchange.tsx",
            "frontend/src/pages/tasks.tsx",
            "frontend/src/pages/referrals.tsx",
            "frontend/src/pages/referrals/*.tsx",
            "frontend/src/pages/ranks.tsx",
            "frontend/src/pages/web-profile.tsx",
            "frontend/src/pages/faq.tsx",
            "frontend/src/pages/hub.tsx",
            "frontend/src/pages/browser-shop.tsx",
            "frontend/src/pages/withdraw.tsx",
            "frontend/src/pages/ads.tsx",
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_range_extension_checkpoint": {
        "docs": [
            (
                "docs/frontend/"
                "PUBLIC_UI_NEXT_RANGE_EXTENSION_CHECKPOINT.md"
            ),
            "docs/cycles/WORK_CYCLES.md",
            (
                "docs/cycles/"
                "WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md"
            ),
            (
                "docs/cycles/"
                "WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md"
            ),
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            (
                "reports/generated/"
                "next_range_extension_checkpoint_v169_41.json"
            ),
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md",
        ],
        "code_globs": [
            (
                "tests/architecture/"
                "test_next_range_extension_checkpoint.py"
            ),
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_ui_screenshot_qa": {
        "docs": [
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/FRONTEND_SCREENSHOT_QA_PROTOCOL.md",
            "docs/frontend/FRONTEND_SCREEN_ACCEPTANCE_CHECKLIST.md",
            "docs/frontend/FRONTEND_VISUAL_CONTRACT.md",
            "docs/frontend/FRONTEND_SHELL_ARCHITECTURE.md",
            "docs/frontend/FRONTEND_SCREEN_REGISTRY.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
            "docs/frontend/FRONTEND_SANDBOX_ELEMENTS_INTAKE_MAP.md",
        ],
        "code_globs": [
            "frontend/src/pages/index.tsx",
            "frontend/src/pages/panels.tsx",
            "frontend/src/pages/exchange.tsx",
            "frontend/src/pages/tasks.tsx",
            "frontend/src/pages/referrals.tsx",
            "frontend/src/pages/referrals/*.tsx",
            "frontend/src/pages/ranks.tsx",
            "frontend/src/pages/web-profile.tsx",
            "frontend/src/pages/faq.tsx",
            "frontend/src/pages/hub.tsx",
            "frontend/src/pages/browser-shop.tsx",
            "frontend/src/pages/withdraw.tsx",
            "frontend/src/pages/ads.tsx",
            "frontend/src/components/**/*.tsx",
            "frontend/public/locale/*.json",
            "tests/architecture/*public*.py",
            "tests/frontend/e2e/*.py",
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_ui_regression_proof": {
        "docs": [
            "docs/frontend/PUBLIC_UI_REGRESSION_PROOF_PASS.md",
            "docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md",
            "docs/frontend/FRONTEND_SCREEN_REGISTRY.md",
            "docs/frontend/FRONTEND_COMPONENT_REGISTRY.md",
            "docs/frontend/FRONTEND_VISUAL_ELEMENTS_REGISTRY.md",
            "docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md",
            "reports/generated/public_ui_regression_proof_v169_40.json",
            "docs/GENERAL/ARCHIVE_NAV_INDEX.md",
        ],
        "code_globs": [
            "frontend/src/pages/index.tsx",
            "frontend/src/pages/panels.tsx",
            "frontend/src/pages/exchange.tsx",
            "frontend/src/pages/tasks.tsx",
            "frontend/src/pages/referrals.tsx",
            "frontend/src/pages/referrals/*.tsx",
            "frontend/src/pages/ranks.tsx",
            "frontend/src/pages/web-profile.tsx",
            "frontend/src/pages/faq.tsx",
            "frontend/src/pages/hub.tsx",
            "frontend/src/pages/browser-shop.tsx",
            "frontend/src/pages/withdraw.tsx",
            "frontend/src/pages/ads.tsx",
            "frontend/src/features/**/*.tsx",
            "backend/app/routes/*_routes.py",
            "tests/architecture/test_public_ui_regression_proof.py",
            "tests/frontend/e2e/*.py",
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "public_ui_interactivity": {
        "docs": [
            (
                "docs/frontend/"
                "FRONTEND_PUBLIC_INTERACTIVITY_"
                "IMPLEMENTATION_PLAN.md"
            ),
            (
                "docs/frontend/"
                "FRONTEND_PUBLIC_INTERACTIVITY_"
                "SANDBOX_AUDIT.md"
            ),
            "docs/frontend/FRONTEND_VISUAL_CONTRACT.md",
        ],
        "code_globs": [
            "frontend/src/pages/index.tsx",
            "frontend/src/pages/panels.tsx",
            "frontend/src/pages/exchange.tsx",
            "frontend/src/components/*.tsx",
            "frontend/src/lib/telegram.ts",
            "tests/architecture/*public*.py",
        ],
        "restricted": [
            "frontend/src/pages/admin/*",
            "ci.yml",
            ".github/workflows/*",
        ],
    },
    "shop_payment_repair": {
        "docs": [
            "docs/SSOT/SHOP_PAYMENTS_EXTERNAL_FLOW_SSOT.md",
            "docs/NORM/BROWSER_SHOP_PAYMENT_FLOW_NORM.md",
            "docs/SSOT/TON_MEMO_SPEC.md",
            "docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md",
        ],
        "code_globs": [
            "backend/app/routes/*shop*.py",
            "backend/app/services/**/*shop*.py",
            "backend/app/models/*shop*.py",
            "frontend/src/**/*shop*.tsx",
            "tests/**/*shop*.py",
        ],
        "restricted": [],
    },
    "frontend_dependency_repair": {
        "docs": [
            (
                "docs/frontend/"
                "FRONTEND_CODE_STANDARD_NEXT16_REACT19_TAILWIND4.md"
            ),
            "docs/backend/BACKEND_DEPENDENCY_RUNTIME_POLICY.md",
        ],
        "code_globs": [
            "frontend/package.json",
            "frontend/package-lock.json",
            "frontend/postcss.config.js",
            "frontend/src/styles/globals.css",
        ],
        "restricted": [],
    },
    "operator_kernel": {
        "docs": [
            "docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md",
            "docs/AI/EFHC_CONTEXT_CAPSULE_PROTOCOL.md",
        ],
        "code_globs": [
            "ops/operator_kernel/**/*.py",
            "ops/operator_kernel/config/*.yaml",
            "tests/architecture/test_operator_kernel_*.py",
        ],
        "restricted": ["ci.yml", ".github/workflows/*"],
    },
}


DEFAULT_ROUTE = {
    "docs": [
        "KERNEL.md",
        "docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md",
        "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md",
        "docs/AI/TOPIC_READING_ROUTES.md",
    ],
    "code_globs": [],
    "restricted": [],
    "allowed_write": [],
    "validation": ["targeted grep", "exact route inspection"],
}


def _list(route: dict[str, Any], *keys: str) -> list[str]:
    out: list[str] = []
    for key in keys:
        value = route.get(key, [])
        if isinstance(value, str):
            value = [value]
        if isinstance(value, list):
            for item in value:
                text = str(item)
                if text not in out:
                    out.append(text)
    return out


def _normalize_config_route(
    route: dict[str, Any],
) -> dict[str, list[str]]:
    docs = _list(route, "required_read", "docs")
    code = _list(
        route,
        "code_globs",
        "frontend",
        "backend",
        "ops",
        "tests",
        "reports",
        "reference",
    )
    allowed = _list(route, "allowed_write")
    restricted = _list(route, "restricted")
    validation = _list(route, "validation")
    return {
        "docs": docs,
        "code_globs": code,
        "allowed_write": allowed,
        "restricted": restricted,
        "validation": validation,
    }


def resolve_route(
    task_type: str,
    root: Path | None = None,
) -> dict[str, object]:
    """Resolve from routes.yaml first, then the Python fallback."""
    config = load_routes_config(root)
    route_name = config["task_type_index"].get(task_type, task_type)
    configured = config["routes"].get(route_name)
    fallback_used = configured is None
    if configured is not None:
        route = _normalize_config_route(configured)
    else:
        route = dict(FALLBACK_ROUTES.get(task_type, DEFAULT_ROUTE))
        route.setdefault("allowed_write", [])
        route.setdefault("validation", [])
    start_core = list(config.get("start_core") or FALLBACK_START_CORE)
    return {
        "task_type": task_type,
        "route_name": (
            route_name if configured is not None else task_type
        ),
        "start_core": start_core,
        "docs": route.get("docs", []),
        "code_globs": route.get("code_globs", []),
        "allowed_write": route.get("allowed_write", []),
        "restricted": route.get("restricted", []),
        "validation": route.get("validation", []),
        "config_source": "ops/operator_kernel/config/routes.yaml",
        "config_loaded": bool(config.get("routes")),
        "config_primary": configured is not None,
        "fallback_used": fallback_used,
        "route_hints": [
            "KERNEL.md",
            "docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md",
            "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md",
        ],
        "forbidden_default_heavy": [
            "ops/operator_kernel/cache/file_map.json full-read",
            "docs/healer/HEALER_ATLAS.md full-read",
            "docs/healer/HEALER_CASEBOOK.md full-read",
            "docs/cycles/*",
            "docs/chats/*",
            "reports/numbered/*",
            "full backend",
            "full frontend",
            "tests/*",
        ],
    }
