"""Select targeted checks for changed files."""

from __future__ import annotations

from pathlib import Path

from ops.operator_kernel.config_loader import load_validation_config

VALIDATION_CONFIG_TEXT = load_validation_config()


def checks_for_file(path: str) -> list[str]:
    p = Path(path)
    checks: list[str] = []
    if path.startswith("backend/app/") and p.suffix == ".py":
        checks.append(f"python -m compileall {path} -q")
    if path.startswith("ops/") and p.suffix == ".py":
        checks.append(f"python -m compileall {path} -q")
    if path.startswith("frontend/") and p.suffix in {".ts", ".tsx"}:
        checks.append("cd frontend && npm run typecheck")
    if path.startswith("docs/") and p.suffix == ".md":
        checks.append("python ops/canon_guard.py")
    if path == "ci.yml" or path.startswith(".github/workflows/"):
        checks.append("BLOCKED: manual CI patch required")
    return checks or ["targeted grep"]


def route_checks(changed_files: list[str]) -> dict[str, object]:
    checks: list[str] = []
    for path in changed_files:
        checks.extend(checks_for_file(path))
    return {
        "verdict_scope": "LOCAL_AUX_CHECK_ONLY",
        "config_source": (
            "ops/operator_kernel/config/validation_routes.yaml"
        ),
        "config_loaded": bool(VALIDATION_CONFIG_TEXT),
        "checks": sorted(set(checks)),
    }
