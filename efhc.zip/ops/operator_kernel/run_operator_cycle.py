"""CLI for the EFHC Operator Kernel."""

# ruff: noqa: E402

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ops.operator_kernel.archive_hygiene import check_tree
from ops.operator_kernel.cache_manager import clear_cache
from ops.operator_kernel.context_capsule import build_context_capsule
from ops.operator_kernel.file_map import build__file__map
from ops.operator_kernel.patch_planner import plan_patch
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task
from ops.operator_kernel.validation_router import route_checks


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True)
    parser.add_argument("--query", default="")
    parser.add_argument("--task-type", default="")
    parser.add_argument("--changed-file", action="append", default=[])
    args = parser.parse_args()
    mode = args.mode
    if mode == "map":
        data = build__file__map(Path.cwd())
        print(f"file_map: {data['files_total']} files")
        return 0
    if mode == "classify":
        print(json.dumps(classify_task(args.query), ensure_ascii=False))
        return 0
    if mode == "route":
        task_type = args.task_type or "archive_orientation"
        print(json.dumps(resolve_route(task_type), ensure_ascii=False))
        return 0
    if mode == "capsule":
        text = build_context_capsule(args.query or "archive task")
        print(f"context_capsule: {len(text)} chars")
        return 0
    if mode == "plan":
        data = plan_patch(args.query, args.changed_file)
        print(json.dumps(data, ensure_ascii=False))
        return 0
    if mode == "targeted-check":
        data = route_checks(args.changed_file)
        print(json.dumps(data, ensure_ascii=False))
        return 0
    if mode == "clean-cache":
        removed = clear_cache(Path.cwd())
        print(f"operator cache cleaned: {removed}")
        return 0
    if mode == "hygiene":
        print(json.dumps(check_tree(Path.cwd()), ensure_ascii=False))
        return 0
    raise SystemExit(f"Unknown mode: {mode}")


if __name__ == "__main__":
    raise SystemExit(main())
