"""Report helpers for EFHC Operator Kernel cycles."""

from __future__ import annotations


def build_cycle_report(
    title: str,
    archive: str,
    changed_files: list[str],
    checks: list[str],
    next_cycle: str,
) -> str:
    lines = [
        f"# {title}",
        "",
        "## 1. Что упало или что задано",
        title,
        "",
        "## 2. Архив",
        archive,
        "",
        "## 3. Что изменено",
    ]
    lines += [f"- {x}" for x in changed_files]
    lines += ["", "## 4. Проверки"]
    lines += [f"- {x}" for x in checks]
    lines += ["", "## 5. Следующий цикл", next_cycle, ""]
    return "\n".join(lines)
