"""Read Operator Kernel configuration without external dependencies."""

from __future__ import annotations

from pathlib import Path
from typing import Any

CONFIG_DIR = Path("ops/operator_kernel/config")
ROUTES_CONFIG_VERSION = "1"

CONFIG_FILES = (
    "routes.yaml",
    "layers.yaml",
    "invariants.yaml",
    "heavy_paths.yaml",
    "tool_registry.yaml",
    "validation_routes.yaml",
)

FALLBACK_HEAVY_PATHS = [
    "docs/audits/",
    "reports/",
    "docs/cycles/",
    "frontend/",
    "backend/",
    "tests/",
]

FALLBACK_LAYERS = {
    "AI": "docs/AI/",
    "SSOT": "docs/SSOT/",
    "NORM": "docs/NORM/",
    "GENERAL": "docs/GENERAL/",
    "AUDIT": "docs/audits/",
    "REPORT": "reports/",
    "CYCLE": "docs/cycles/",
    "BACKEND_RUNTIME": "backend/app/",
    "FRONTEND_RUNTIME": "frontend/",
    "OPS_LAYER": "ops/",
    "TEST_LAYER": "tests/",
}

FALLBACK_TOOLS = {
    "read_file": "read_only",
    "search_archive": "read_only",
    "build__file__map": "read_only_output_cache",
    "classify_task": "read_only_output_cache",
    "resolve_route": "read_only_output_cache",
    "build_context_capsule": "read_only_output_cache",
    "plan_patch": "dry_run",
    "apply_patch": "write",
    "run_targeted_check": "local_aux_check",
    "build_release_zip": "release",
}


def config_path(name: str, root: Path | None = None) -> Path:
    base = root or Path.cwd()
    return base / CONFIG_DIR / name


def _strip_comment(line: str) -> str:
    return line.split("#", 1)[0].rstrip()


def _top_level_scalar(text: str, key: str) -> str | None:
    for raw in text.splitlines():
        line = _strip_comment(raw).strip()
        if not line or line.startswith("-") or raw.startswith(" "):
            continue
        if ":" not in line:
            continue
        current, value = line.split(":", 1)
        if current.strip() == key:
            return value.strip().strip('"').strip("'")
    return None


def _validate_routes_config_text(text: str, path: Path) -> None:
    version = _top_level_scalar(text, "version")
    if version != ROUTES_CONFIG_VERSION:
        raise RuntimeError(
            "Operator Kernel routes.yaml version mismatch: "
            f"expected {ROUTES_CONFIG_VERSION}, "
            f"got {version!r} in {path}"
        )


def read_config_text(name: str, root: Path | None = None) -> str:
    path = config_path(name, root)
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8")
    if name == "routes.yaml":
        _validate_routes_config_text(text, path)
    return text


def load_config_bundle(root: Path | None = None) -> dict[str, str]:
    return {name: read_config_text(name, root) for name in CONFIG_FILES}


def _simple_list(text: str, section: str) -> list[str]:
    items: list[str] = []
    active = False
    for raw in text.splitlines():
        line = _strip_comment(raw)
        if not line.strip():
            continue
        if not raw.startswith(" ") and line.strip() == f"{section}:":
            active = True
            continue
        if (
            active
            and not raw.startswith(" ")
            and not line.lstrip().startswith("-")
        ):
            break
        if active and line.strip().startswith("- "):
            items.append(line.strip()[2:].strip())
    return items


def _simple_mapping(text: str, section: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    active = False
    for raw in text.splitlines():
        line = _strip_comment(raw)
        if not line.strip():
            continue
        if not raw.startswith(" ") and line.strip() == f"{section}:":
            active = True
            continue
        if active and not raw.startswith(" "):
            break
        if active and ":" in line:
            key, value = line.strip().split(":", 1)
            if key and value.strip():
                mapping[key.strip()] = value.strip()
    return mapping


def _scalar(value: str) -> Any:
    value = value.strip().strip('"').strip("'")
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.isdigit():
        return int(value)
    return value


def load_routes_config(root: Path | None = None) -> dict[str, Any]:
    """Parse the routes.yaml subset used by Operator Kernel.

    Supports top-level start_core, routes nested under tasks, and legacy
    top-level route blocks. This keeps runtime stdlib-only while making
    YAML the primary behavioral source.
    """
    text = read_config_text("routes.yaml", root)
    result: dict[str, Any] = {
        "version": ROUTES_CONFIG_VERSION,
        "start_core": [],
        "routes": {},
        "task_type_index": {},
    }
    in_tasks = False
    in_start_core = False
    current_route: str | None = None
    route_indent = -1
    current_field: str | None = None
    field_indent = -1

    for raw in text.splitlines():
        clean = _strip_comment(raw)
        if not clean.strip():
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        stripped = clean.strip()

        if indent == 0:
            if stripped == "start_core:":
                in_start_core = True
                in_tasks = False
                current_route = None
                continue
            if stripped == "tasks:":
                in_tasks = True
                in_start_core = False
                current_route = None
                continue
            if stripped.startswith("- ") and in_start_core:
                result["start_core"].append(stripped[2:].strip())
                continue
            in_start_core = False
            if ":" in stripped:
                key, value = stripped.split(":", 1)
                if key == "version":
                    result["version"] = str(_scalar(value))
                    continue
                # Legacy top-level route.
                if not value.strip():
                    in_tasks = False
                    current_route = key
                    route_indent = 0
                    current_field = None
                    result["routes"].setdefault(current_route, {})
                    continue

        if in_start_core and stripped.startswith("- "):
            result["start_core"].append(stripped[2:].strip())
            continue

        if in_tasks and indent == 2 and stripped.endswith(":"):
            current_route = stripped[:-1].strip()
            route_indent = 2
            current_field = None
            result["routes"].setdefault(current_route, {})
            continue

        if current_route is None or indent <= route_indent:
            continue

        route = result["routes"][current_route]
        if not stripped.startswith("-") and ":" in stripped:
            key, value = stripped.split(":", 1)
            key = key.strip()
            if value.strip():
                route[key] = _scalar(value)
                current_field = None
            else:
                route.setdefault(key, [])
                current_field = key
                field_indent = indent
            continue

        if (
            stripped.startswith("- ")
            and current_field
            and indent >= field_indent
        ):
            value = stripped[2:].strip()
            bucket = route.setdefault(current_field, [])
            if isinstance(bucket, list):
                bucket.append(value)

    for route_name, route in result["routes"].items():
        task_type = str(route.get("task_type") or route_name)
        result["task_type_index"][task_type] = route_name
    return result


def load_heavy_paths(root: Path | None = None) -> tuple[str, ...]:
    items = _simple_list(
        read_config_text("heavy_paths.yaml", root),
        "heavy_paths",
    )
    return tuple(items or FALLBACK_HEAVY_PATHS)


def load_layers(root: Path | None = None) -> dict[str, str]:
    data = _simple_mapping(
        read_config_text("layers.yaml", root),
        "layers",
    )
    return data or dict(FALLBACK_LAYERS)


def load_invariants(root: Path | None = None) -> list[str]:
    return _simple_list(
        read_config_text("invariants.yaml", root),
        "invariants",
    )


def load_tool_modes(root: Path | None = None) -> dict[str, str]:
    text = read_config_text("tool_registry.yaml", root)
    modes: dict[str, str] = {}
    current = ""
    in_tools = False
    for raw in text.splitlines():
        line = _strip_comment(raw)
        if not line.strip():
            continue
        if not raw.startswith(" ") and line.strip() == "tools:":
            in_tools = True
            continue
        if in_tools and not raw.startswith(" "):
            break
        stripped = line.strip()
        if (
            in_tools
            and stripped.endswith(":")
            and not stripped.startswith("mode")
        ):
            current = stripped[:-1]
            continue
        if in_tools and current and stripped.startswith("mode:"):
            modes[current] = stripped.split(":", 1)[1].strip()
    return modes or dict(FALLBACK_TOOLS)


def load_validation_config(root: Path | None = None) -> str:
    return read_config_text("validation_routes.yaml", root)
