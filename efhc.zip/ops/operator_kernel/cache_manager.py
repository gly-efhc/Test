"""Cache helpers for the EFHC Operator Kernel."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CACHE_DIR = Path("ops/operator_kernel/cache")
STATE_DIR = Path("ops/operator_kernel/state")


def ensure_dirs(root: Path | None = None) -> tuple[Path, Path]:
    base = root or Path.cwd()
    cache = base / CACHE_DIR
    state = base / STATE_DIR
    cache.mkdir(parents=True, exist_ok=True)
    state.mkdir(parents=True, exist_ok=True)
    return cache, state


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    path.write_text(text, encoding="utf-8")


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def clear_cache(root: Path | None = None) -> int:
    cache, _ = ensure_dirs(root)
    removed = 0
    for item in cache.iterdir():
        if item.name == "gitkeep":
            continue
        if item.is_file():
            item.unlink()
            removed += 1
    return removed
