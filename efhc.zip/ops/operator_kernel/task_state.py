"""Task state JSONL storage for Operator Kernel."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ops.operator_kernel.cache_manager import ensure_dirs


def append_state(
    record: dict[str, Any],
    root: Path | None = None,
) -> Path:
    base = root or Path.cwd()
    _, state = ensure_dirs(base)
    path = state / "tasks.jsonl"
    item = dict(record)
    item.setdefault("created_at_utc", datetime.now(UTC).isoformat())
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(item, ensure_ascii=False) + "\n")
    return path


def read_states(root: Path | None = None) -> list[dict[str, Any]]:
    base = root or Path.cwd()
    path = base / "ops/operator_kernel/state/tasks.jsonl"
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out
