"""Проектный классификатор задач EFHC Operator Kernel."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TaskRule:
    task_type: str
    signals: tuple[str, ...]
    priority: int = 0
    requires_logs: bool = False
    requires_code_patch: bool = False
    requires_docs_update: bool = True
    requires_release_zip: bool = True


RULES: tuple[TaskRule, ...] = (
    TaskRule(
        "account_registration_center",
        (
            "cycle 1636",
            "цикл 1636",
            "cycle 1637",
            "цикл 1637",
            "cycle 1638",
            "цикл 1638",
            "cycle 1639",
            "цикл 1639",
            "cycle 1640",
            "цикл 1640",
            "единый центр регистрации",
            "accountregistrationservice",
            "account registration service",
            "global_id business ownership",
        ),
        priority=600,
        requires_code_patch=True,
        requires_docs_update=True,
        requires_release_zip=True,
    ),
    TaskRule(
        "public_ui_route_harmony",
        (
            "cycle 1635",
            "цикл 1635",
            "public route harmony",
            "публичная гармонизация маршрутов",
            "мягкие кнопки",
            "адаптивный баланс",
            "route-specific visual",
        ),
        priority=590,
        requires_code_patch=True,
        requires_docs_update=True,
        requires_release_zip=True,
    ),
    TaskRule(
        "chat_qa_public_ui_foundation",
        (
            "cycle 1634",
            "цикл 1634",
            "чаты 40-51",
            "чаты 40–51",
            "аудит вопросов и ответов",
            "мягкая публичная палитра",
            "компактный баланс",
        ),
        priority=580,
        requires_code_patch=True,
        requires_docs_update=True,
        requires_release_zip=True,
    ),
    TaskRule(
        "pre_release_migration_squash",
        (
            "cycle 1632",
            "цикл 1632",
            "schema freeze",
            "migration squash",
            "pre-release migration squash",
            "0001_initial_release_schema",
        ),
        priority=570,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "financial_read_switch",
        (
            "cycle 1627",
            "цикл 1627",
            "financial read switch",
            "financial reconciliation closure",
            "telegram absent owner api",
            "monetary discrepancy 0.00000000",
        ),
        priority=540,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "financial_shadow_validation",
        (
            "cycle 1626",
            "цикл 1626",
            "financial shadow validation",
            "monetary discrepancy 0.00000000",
            "financial telemetry mismatch fallback zero",
            "precision idempotency unchanged",
        ),
        priority=530,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "nonfinancial_read_switch",
        (
            "cycle 1625",
            "цикл 1625",
            "non-financial read switch",
            "nonfinancial read switch",
            "panels energy referrals tasks ranks read switch",
            "provider-neutral nonfinancial reads",
        ),
        priority=520,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "historical_backfill_full_reconciliation",
        (
            "cycle 1623",
            "цикл 1623",
            "historical backfill",
            "full reconciliation",
            "orphan conflict closure",
            "денежное расхождение 0.00000000",
            "unresolved rows = 0",
        ),
        priority=510,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "financial_admin_external_schema_expand",
        (
            "cycle 1622",
            "цикл 1622",
            "financial admin external schema expand",
            "financial/admin/external schema expand",
            "transactions deposits withdrawals wallets",
            "admin actors external events",
        ),
        priority=500,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "nonfinancial_domain_schema_expand",
        (
            "cycle 1621",
            "цикл 1621",
            "non-financial domain schema expand",
            "nonfinancial domain schema expand",
            "panels energy referrals tasks ranks",
        ),
        priority=490,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "frontend_session_first_bootstrap",
        (
            "cycle 1620",
            "цикл 1620",
            "frontend session-first bootstrap",
            "frontend session first bootstrap",
            "hooks query keys provider context skeleton",
            "provider-neutral auth context",
        ),
        priority=480,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "telegram_init_data_session",
        (
            "cycle 1619",
            "цикл 1619",
            "telegram initdata adapter",
            "telegram initdata adapter через identityresolver",
            "identityresolver и session issue",
            "повторный вход открывает тот же account",
        ),
        priority=470,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "ton_auth_session_closure",
        (
            "cycle 1618",
            "цикл 1618",
            "ton auth session logout closure",
            "frontend session transport",
            "ton-only login доказан на postgresql",
            "provider-neutral bearer session",
        ),
        priority=460,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "ton_account_registration",
        (
            "cycle 1617",
            "цикл 1617",
            "existing ton identity binding",
            "ton-only registration",
            "один wallet один global account",
            "фиктивный tg_id отсутствует",
        ),
        priority=450,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "ton_proof_verification",
        (
            "cycle 1616",
            "цикл 1616",
            "ton proof cryptographic verification",
            "ton proof domain timestamp network state-init replay ttl",
            "все vectors и concurrent consumption проходят",
        ),
        priority=440,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "auth_core_postgresql_closure",
        (
            "cycle 1614",
            "цикл 1614",
            "auth-core postgresql integration closure",
            "auth core postgresql integration closure",
            "migrations concurrency logout roles",
            "миграции concurrency logout роли",
            "0 critical skips",
        ),
        priority=430,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "auth_runtime_foundation",
        (
            "cycle 1613",
            "цикл 1613",
            "auth_challenges auth_sessions user_roles",
            "auth challenges auth sessions user roles",
            "auth_challenges",
            "auth_sessions",
            "user_roles",
            "one-time challenge",
            "hashed session",
            "roles по global_id",
            "fastapi auth dependencies",
        ),
        priority=420,
        requires_code_patch=True,
    ),
    TaskRule(
        "transactional_identity_resolver",
        (
            "cycle 1612",
            "цикл 1612",
            "transactional identityresolver",
            "transactional identity resolver",
            "postgresql locks и запрет auto-merge",
            "concurrent resolve детерминирован",
            "conflict fail closed",
        ),
        priority=410,
        requires_code_patch=True,
    ),
    TaskRule(
        "provider_identity_postgresql_package",
        (
            "cycle 1611",
            "цикл 1611",
            "pg-0 test package",
            "pg-0 test_package_prepared_not_executed",
            "migration user_identities",
            "user_identities и constraints",
            "postgresql test package",
        ),
        priority=400,
        requires_code_patch=True,
    ),
    TaskRule(
        "auth_context_contracts_foundation",
        (
            "cycle 1610",
            "цикл 1610",
            "authcontext contracts",
            "auth context contracts",
            "resolver interfaces",
            "security/redaction skeleton",
            "provider-neutral authcontext",
        ),
        priority=390,
        requires_code_patch=True,
    ),
    TaskRule(
        "auth_provider_registry_foundation",
        (
            "cycle 1609",
            "цикл 1609",
            "authprovider и provider registry foundation",
            "auth provider registry foundation",
            "verifiedidentity",
            "provider-neutral auth registry",
        ),
        priority=380,
        requires_code_patch=True,
    ),
    TaskRule(
        "identity_semantic_registry",
        (
            "cycle 1608",
            "цикл 1608",
            "semantic allowlist",
            "compatibility registry",
            "semantic allowlist и compatibility registry",
            "реестр переходных имён идентификаторов",
        ),
        priority=370,
        requires_code_patch=True,
    ),
    TaskRule(
        "cross_language_identity_separation",
        (
            "cycle 1607",
            "цикл 1607",
            "cross-language разделение globalid и telegramid",
            "cross language globalid telegramid",
            "разделение globalid и telegramid",
            "global id telegram id separation",
        ),
        priority=360,
        requires_code_patch=True,
    ),
    TaskRule(
        "global_id_api_contract",
        (
            "cycle 1606",
            "цикл 1606",
            "api-контракт global_id",
            "api contract global_id",
            "global id api contract",
            "backend openapi frontend parity",
        ),
        priority=350,
        requires_code_patch=True,
    ),
    TaskRule(
        "frontend_global_id_string_system",
        (
            "cycle 1605",
            "цикл 1605",
            "frontend globalid string system",
            "frontend global id string system",
            "frontend global_id string",
            "строковая система global id",
            "branded string globalid",
        ),
        priority=340,
        requires_code_patch=True,
    ),
    TaskRule(
        "backend_global_id_type_finalization",
        (
            "cycle 1604",
            "цикл 1604",
            "backend globalid type finalization",
            "backend global id type finalization",
            "завершение backend типов global id",
            "globalid type finalization",
        ),
        priority=330,
        requires_code_patch=True,
    ),
    TaskRule(
        "global_id_canonicalization",
        (
            "cycle 1602",
            "цикл 1602",
            "global id canonicalization",
            "global_id canonicalization",
            "канонизация global id",
            "канон global_id",
            "global identity canon",
        ),
        priority=310,
        requires_code_patch=True,
    ),
    TaskRule(
        "clean_first_boot_release",
        (
            "clean first-boot",
            "clean first boot",
            "чистый первый запуск",
            "первый production-запуск",
            "пустом vps",
            "пустой vps",
            "пустой базы данных",
            "44 orm-таблиц",
            "44 таблицы",
            "alembic upgrade head",
            "one-command deploy",
            "одна команда deploy",
            "efhc_bot_v171_70_release",
            "efhc_bot_v171_71_release",
            "frontend production build",
            "production frontend build",
        ),
        priority=190,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "release_archive_update",
        (
            "release archive через update.sh",
            "update.sh и rollback.sh",
            "полный release archive через update.sh",
            "update.sh",
            "обновление архивом",
            "обновлять архивами",
            "полный release archive",
            "rollback.sh",
            "atomic switch",
            "последующие обновления",
            "патчами или архивами",
        ),
        priority=185,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "provider_independent_release_portability",
        (
            "provider-independent release",
            "provider independent release",
            "не должен зависеть от ovhcloud",
            "не зависеть от ovhcloud",
            "ovhcloud будет только текущей площадкой",
            "docker compose up -d",
            "универсальный docker-compose",
            "универсальный docker compose",
            "перенос на новый vps",
            "быстрый перенос",
            "backup restore",
            "pg_dump pg_restore",
            "циклы 1574-1578",
            "cycles 1574-1578",
        ),
        priority=165,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "wallet_provider_adapter_work",
        (
            "native-wallet adapter",
            "native wallet adapter",
            "walletprovider",
            "wallet provider",
            "wallet in telegram",
            "telegram wallet adapter",
            "native gram wallet",
            "не привязывать приложение только к ton connect",
        ),
        priority=150,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "cycle_1574_local_release_candidate_audit",
        (
            "cycle 1574",
            "local release-candidate audit",
            "local release candidate audit",
            "идём дальше",
            "идем дальше",
            "deferred post-release",
            "выполнить невозможно и идём дальше",
        ),
        priority=135,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "cycle_1573_close_visual_live_proof",
        (
            (
                "efhc_bot_v171_63_cycle_1573_close_"
                "route_backed_visual_and_live_ton_proof"
            ),
            "cycle 1573 close route-backed visual and live ton proof",
            "close route-backed visual and live ton proof",
            "закрыть route-backed visual и live ton proof",
            "последний цикл в этом чате",
        ),
        priority=130,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "control_docs_optimization",
        (
            "оптимизируй kernel",
            "оптимизируй kernel, ssot, канон и ai",
            "удали дубли",
            "объедини",
            "одинаковы по смыслу",
            "противоречащие указания",
            "сократи названия",
            "сколько весят документы",
            "document optimization",
            "control docs optimization",
        ),
        priority=105,
        requires_code_patch=True,
    ),
    TaskRule(
        "tonconnect_wallet_ux_range_closure",
        (
            "tonconnect_wallet_ux_range_closure",
            "tonconnect wallet ux range closure",
            "wallet ux range closure",
        ),
        priority=95,
        requires_code_patch=True,
    ),
    TaskRule(
        "operator_kernel_full_restore",
        (
            "восстанови полный подробный kernel",
            "full detailed kernel",
            "operator kernel full restore",
            "restore kernel",
            "v171.47",
            "navigation only",
            "routes.yaml",
            "route_resolver",
            "task_classifier",
            "file_map summary",
            "canonical anchors",
        ),
        priority=100,
        requires_code_patch=True,
    ),
    TaskRule(
        "canonical_bottom_navigation_guard",
        (
            "нижних 6 кнопок",
            "нижние 6 кнопок",
            "6 bottom buttons",
            "6 canonical buttons",
            "bottom nav",
            "нижняя навигация",
            "нижняя панель",
            "energy panels exchange tasks referrals ranks",
            "проверь канон",
        ),
        priority=90,
        requires_code_patch=True,
    ),
    TaskRule(
        "live_telegram_tonconnect_tonproof_transaction_gate",
        (
            "live telegram",
            "telegram mini app",
            "tonconnect",
            "tonproof",
            "transaction contour",
            "transaction contours",
            "real ton",
            "jetton",
            "wallet signature",
            "live proof",
        ),
        priority=85,
        requires_code_patch=True,
    ),
    TaskRule(
        "frontend_i18n_guarded_work",
        (
            "13 languages",
            "13 языков",
            "active и vip",
            "active and vip",
            "activ и vip",
            "english unchanged",
            "hardcoded text",
            "локализация",
            "translation",
            "i18n",
        ),
        priority=80,
        requires_code_patch=True,
    ),
    TaskRule(
        "frontend_visual_route_backed_work",
        (
            "route-backed visual",
            "route backed visual",
            "page.goto",
            "screenshots",
            "скриншоты",
            "frontend visual",
            "balance panel",
            "overflow",
            "telegram viewport",
            "visual proof",
        ),
        priority=70,
        requires_code_patch=True,
    ),
    TaskRule(
        "ci_logs_repair_or_verification",
        (
            "green logs",
            "зелёные логи",
            "ошибки по логам",
            "логи github ci",
            "ci logs",
            "ci-логи",
            "github ci",
            "logs_",
            "pytest",
            "ruff",
            "mypy",
            "bandit",
            "compileall",
            "typecheck",
            "npm build",
        ),
        priority=65,
        requires_logs=True,
        requires_code_patch=True,
    ),
    TaskRule(
        "archive_build_and_release_boundary",
        (
            "development archive",
            "release archive",
            "screenshots archive",
            "следующий архив",
            "new zip",
            "sequential number",
            "архив",
            "archive",
        ),
        priority=60,
    ),
    TaskRule(
        "frontend_dependency_repair",
        ("next.js", "react", "tailwind", "package.json"),
        requires_code_patch=True,
    ),
    TaskRule(
        "faq_semantic_approval_gate",
        (
            "faq semantic approval",
            "faq ssot",
            "questions and answers",
            "русский faq",
            "semantic gate",
            "1372",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "faq_semantic_alignment_repair",
        (
            "faq semantic",
            "semantic alignment",
            "смысл faq",
            "ssot can regress",
            "questions and answers",
            "1371",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "faq_wave3_translation_repair",
        (
            "faq wave-3",
            "faq translation",
            "translation status",
            "identical faq answers",
            "1371",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_i18n_untranslated_remediation",
        (
            "public i18n untranslated",
            "untranslated keys",
            "translation remediation",
            "identical to english",
            "wallet error",
            "browser shop translation",
            "1370",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "telegram_mini_app_shell_polish",
        (
            "telegram mini app shell",
            "tma shell",
            "viewport",
            "backbutton",
            "safe-area",
            "safe area",
            "telegram theme",
            "1374",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "language_canon_ru_source_lock",
        (
            "russian source",
            "ru source",
            "русский канон",
            "русского языка",
            "перевод с русского",
            "language canon",
            "1373",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "i18n_critical_repair",
        (
            "localization",
            "fallback chain",
            "common.session_expired",
            "language audit",
            "placeholder",
            "tfromdicts",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "audit_fixes_implementation",
        (
            "tz_fixes_audit",
            "fix-01",
            "fix-02",
            "audit fixes",
            "sale packages",
            "offline fallback",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "admin_recovery_checkpoint",
        (
            "admin recovery checkpoint",
            "recovery checkpoint",
            "checkpoint report",
            "work_cycles",
        ),
    ),
    TaskRule(
        "sandbox_elements_intake",
        (
            "sandbox elements",
            "map_element",
            "песочница",
            "telegram mini app template",
            "tonconnect template",
        ),
    ),
    TaskRule(
        "admin_regression_proof",
        (
            "admin regression",
            "regression proof",
            "admin proof matrix",
            "admin route proof",
        ),
    ),
    TaskRule(
        "admin_docs_route_map",
        (
            "admin docs",
            "route map",
            "ssot route",
            "admin routes map",
        ),
    ),
    TaskRule(
        "admin_ui_recovery",
        ("admin", "dashboard", "ui kit", "operator"),
        requires_code_patch=True,
    ),
    TaskRule(
        "admin_screenshot_qa",
        ("admin screenshot", "admin visual proof"),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_visual_trust_hub_browser_shop_withdraw_ads",
        (
            "hub browser shop withdraw ads",
            "hub / browser shop / withdraw / ads",
            "public visual trust hub",
            "browser shop withdraw",
            "1368",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_visual_trust_profile_wallet_history_faq",
        (
            "profile wallet history faq",
            "profile / wallet / history / faq",
            "public visual trust",
            "account trust",
            "1367",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_visual_beauty_tasks_referrals_ranks",
        (
            "tasks referrals ranks",
            "tasks / referrals / ranks",
            "public visual beauty tasks",
            "public engagement visual",
            "1366",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_visual_beauty_energy_panels_exchange",
        (
            "public visual beauty",
            "energy panels exchange",
            "energy / panels / exchange",
            "visual beauty pass",
            "public visual polish",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_browser_screenshot_evidence",
        (
            "public browser screenshot evidence",
            "screenshot evidence harness",
            "capture manifest",
            "efhc_capture_screenshots",
            "1364",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_range_extension_checkpoint",
        (
            "next range extension",
            "range extension checkpoint",
            "1364",
            "1375",
        ),
        requires_code_patch=False,
    ),
    TaskRule(
        "public_ui_regression_proof",
        (
            "public ui regression proof",
            "public regression proof",
            "public ui proof matrix",
            "public page component backend ssot guard",
        ),
        requires_code_patch=False,
    ),
    TaskRule(
        "public_ui_screenshot_qa",
        (
            "public ui screenshot",
            "screenshot qa",
            "visual qa",
            "public screenshot",
            "browser shop screenshot",
            "public ui qa",
            "e2e smoke",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "public_ui_interactivity",
        (
            "public ui",
            "пользователь",
            "interactive",
            "интерактив",
            "engagement",
        ),
        requires_code_patch=True,
    ),
    TaskRule(
        "shop_payment_repair",
        ("shop payment", "web3", "payment separation"),
        requires_code_patch=True,
    ),
    TaskRule(
        "withdraw_repair",
        ("withdraw", "withdrawals", "вывод", "payout"),
        requires_code_patch=True,
    ),
    TaskRule(
        "panels_repair",
        ("panels", "панел", "activation", "countdown"),
        requires_code_patch=True,
    ),
    TaskRule(
        "exchange_repair",
        ("exchange", "обмен", "kwh", "efhc"),
        requires_code_patch=True,
    ),
    TaskRule("faq_repair", ("faq", "locale")),
    TaskRule("tonconnect_wallet_repair", ("generic wallet repair",)),
    TaskRule("cycle_docs_repair", ("cycle", "work_cycles")),
    TaskRule("release_archive_build", ("release zip",)),
    TaskRule(
        "operator_kernel",
        ("operator kernel", "ускор", "capsule"),
        priority=10,
    ),
    TaskRule(
        "full_audit",
        ("full audit", "полный аудит", "аудит"),
        priority=-10,
    ),
)


GENERIC_SIGNALS = {"efhc", "kwh", "cycle", "archive", "архив"}


def _signal_weight(signal: str) -> float:
    low = signal.casefold()
    if low.startswith("efhc_bot_v171_63_cycle_1573_close"):
        return 50.0
    if low in GENERIC_SIGNALS:
        return 0.25
    words = max(1, len(signal.split()))
    return float(min(words, 5))


def classify_task(query: str) -> dict[str, object]:
    text = query.casefold()
    candidates: list[tuple[float, int, TaskRule, list[str]]] = []
    for rule in RULES:
        hits = [
            signal
            for signal in rule.signals
            if signal.casefold() in text
        ]
        score = sum(_signal_weight(signal) for signal in hits)
        if hits:
            candidates.append((score, rule.priority, rule, hits))

    if candidates:
        candidates.sort(
            key=lambda item: (item[0], item[1]),
            reverse=True,
        )
        best_score, _, best, matched = candidates[0]
    else:
        best = next(
            rule for rule in RULES if rule.task_type == "full_audit"
        )
        best_score = 0.0
        matched = []

    secondary: list[str] = []
    secondary_signals: dict[str, list[str]] = {}
    for score, _, rule, hits in candidates[1:]:
        if rule.task_type == best.task_type:
            continue
        if score < 1.0:
            continue
        secondary.append(rule.task_type)
        secondary_signals[rule.task_type] = hits
        if len(secondary) >= 5:
            break

    confidence = (
        0.40
        if best_score <= 0
        else min(0.50 + best_score * 0.08, 0.99)
    )
    return {
        "task_type": best.task_type,
        "confidence": round(confidence, 2),
        "signals": matched,
        "secondary_task_types": secondary,
        "secondary_signals": secondary_signals,
        "requires_logs": best.requires_logs,
        "requires_code_patch": best.requires_code_patch,
        "requires_docs_update": best.requires_docs_update,
        "requires_release_zip": best.requires_release_zip,
    }
