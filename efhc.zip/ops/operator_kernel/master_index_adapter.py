"""Adapter for docs/GENERAL/MASTER_DOCUMENT_INDEX.csv."""

from __future__ import annotations

import csv
from pathlib import Path

INDEX = Path("docs/GENERAL/MASTER_DOCUMENT_INDEX.csv")


def load_master_index(root: Path | None = None) -> list[dict[str, str]]:
    base = root or Path.cwd()
    path = base / INDEX
    if not path.exists():
        return []
    rows: list[dict[str, str]] = []
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.reader(fh)
        for row in reader:
            if not row:
                continue
            rows.append(
                {
                    "path": row[0],
                    "kind": row[1] if len(row) > 1 else "",
                    "topic": row[2] if len(row) > 2 else "",
                }
            )
    return rows


def find_docs_by_topic(
    topic: str,
    root: Path | None = None,
) -> list[dict[str, str]]:
    needle = topic.lower()
    return [
        row
        for row in load_master_index(root)
        if needle in " ".join(row.values()).lower()
    ]


def find_docs_by_layer(
    layer: str,
    root: Path | None = None,
) -> list[dict[str, str]]:
    needle = layer.lower()
    return [
        row
        for row in load_master_index(root)
        if row["path"].lower().startswith(needle)
    ]


def find_stale_entries(root: Path | None = None) -> list[str]:
    base = root or Path.cwd()
    stale: list[str] = []
    for row in load_master_index(base):
        path = row["path"]
        if path and not (base / path).exists():
            stale.append(path)
    return stale


def compare_index_with_actual_files(
    root: Path | None = None,
) -> dict[str, object]:
    stale = find_stale_entries(root)
    return {"stale_entries": stale, "stale_count": len(stale)}
