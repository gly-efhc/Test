"""Dry-run, route-controlled patch planner for EFHC tasks."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task


def _is_manual(path: str) -> bool:
    return path == "ci.yml" or path.startswith(".github/workflows/")


def plan_patch(
    query: str,
    changed_files: Iterable[str] | None = None,
    root: Path | None = None,
) -> dict[str, object]:
    task = classify_task(query)
    route = resolve_route(str(task["task_type"]), root=root)
    changed = list(changed_files or [])
    blocked = [p for p in changed if _is_manual(p)]
    docs_changed = any(
        path.startswith("docs/")
        or path in {"KERNEL.md", "START_HERE.md"}
        for path in changed
    )
    healer_changed = any(
        path.startswith("docs/healer/") or "HEALER" in path
        for path in changed
    )
    return {
        "task_type": task["task_type"],
        "route_name": route["route_name"],
        "affected_files": changed,
        "route_docs": route["docs"],
        "allowed_write": route["allowed_write"],
        "restricted": route["restricted"],
        "blocked_files": blocked,
        "requires_user_ci": bool(blocked),
        "requires_cycle_update": bool(changed),
        "requires_healer_update": healer_changed,
        "requires_canon_guard": docs_changed,
        "cycle_sync_hooks": [
            (
                "docs/cycles/WORK_CYCLES_1321-1350 and current "
                "cycle document selected by route"
            ),
            "docs/GENERAL/CURRENT_DECISIONS.md",
            (
                "docs/healer/HEALER_ATLAS.md only for a confirmed "
                "incident/root cause"
            ),
            "reports/generated/change_cycle_*.md",
        ],
        "allowed_checks": route["validation"] or [
            "targeted grep",
            "compileall affected Python",
            "frontend typecheck if frontend changed",
            "targeted architecture guard",
        ],
        "status": "blocked" if blocked else "planned",
    }
