"""Tool registry for the EFHC Operator Kernel."""

from __future__ import annotations

from ops.operator_kernel.config_loader import load_tool_modes

TOOLS = load_tool_modes()

FALLBACK_TOOLS = {
    "read_file": "read_only",
    "search_archive": "read_only",
    "build__file__map": "read_only_output_cache",
    "classify_task": "read_only_output_cache",
    "resolve_route": "read_only_output_cache",
    "build_context_capsule": "read_only_output_cache",
    "plan_patch": "dry_run",
    "apply_patch": "write",
    "run_targeted_check": "local_aux_check",
    "build_release_zip": "release",
}

if not TOOLS:
    TOOLS = dict(FALLBACK_TOOLS)


def list_tools() -> dict[str, str]:
    return dict(TOOLS)


def is_write_tool(name: str) -> bool:
    return TOOLS.get(name) in {"write", "release"}
