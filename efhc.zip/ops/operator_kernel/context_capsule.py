"""Build bounded, task-specific EFHC context capsules."""

from __future__ import annotations

import re
from pathlib import Path

from ops.operator_kernel.cache_manager import ensure_dirs
from ops.operator_kernel.config_loader import load_invariants
from ops.operator_kernel.route_resolver import resolve_route
from ops.operator_kernel.task_classifier import classify_task

MAX_EXCERPT_FILES = 8
MAX_EXCERPT_LINES = 18
MAX_TOTAL_EXCERPT_CHARS = 12000


def _terms(query: str) -> list[str]:
    found = re.findall(
        r"[\w.-]{4,}",
        query,
        flags=re.UNICODE,
    )
    return [item.casefold() for item in found][:24]


def _excerpt(path: Path, query: str) -> str:
    if (
        not path.exists()
        or not path.is_file()
        or path.stat().st_size > 500_000
    ):
        return ""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (UnicodeDecodeError, OSError):
        return ""
    terms = _terms(query)
    scored: list[tuple[int, int]] = []
    for idx, line in enumerate(lines):
        low = line.casefold()
        score = sum(1 for term in terms if term in low)
        if score:
            scored.append((score, idx))
    selected: set[int] = set()
    for _, idx in sorted(scored, reverse=True)[:6]:
        selected.update(
            range(
                max(0, idx - 1),
                min(len(lines), idx + 2),
            )
        )
    if not selected:
        selected.update(
            i for i, line in enumerate(lines) if line.strip()
        )
    ordered = sorted(selected)[:MAX_EXCERPT_LINES]
    return "\n".join(f"L{i + 1}: {lines[i]}" for i in ordered)


def build_context_capsule(
    query: str,
    root: Path | None = None,
    archive_name: str | None = None,
) -> str:
    base = root or Path.cwd()
    task = classify_task(query)
    route = resolve_route(str(task["task_type"]), root=base)
    secondary_routes = [
        resolve_route(str(task_type), root=base)
        for task_type in task.get("secondary_task_types", [])
    ]

    def merged(key: str) -> list[str]:
        values: list[str] = []
        for current in [route, *secondary_routes]:
            for item in current.get(key, []):
                text = str(item)
                if text not in values:
                    values.append(text)
        return values

    route_docs = merged("docs")
    route_code = merged("code_globs")
    route_allowed = merged("allowed_write")
    route_restricted = merged("restricted")
    route_validation = merged("validation")
    invariants = load_invariants(base)
    archive = archive_name or base.name
    lines = [
        "# EFHC Context Capsule",
        "",
        "## Task",
        query,
        "",
        "## Archive",
        archive,
        "",
        "## Task classification",
        f"- type: {task['task_type']}",
        f"- confidence: {task['confidence']}",
        f"- signals: {', '.join(task['signals']) or 'none'}",
        f"- primary route: {route['route_name']}",
        "- secondary routes: "
        + (
            ", ".join(
                str(item["route_name"])
                for item in secondary_routes
            )
            or "none"
        ),
        "- YAML primary: "
        + str(
            route["config_primary"]
            and all(
                item["config_primary"]
                for item in secondary_routes
            )
        ),
        "",
        "## Active boundary",
        (
            "- use the current KERNEL/START_HERE cycle boundary; "
            "historical capsule state cannot override it"
        ),
        (
            "- local validation retains "
            "LOCAL_AUX_CHECK_ONLY semantics: it proves only the "
            "checks actually run"
        ),
        (
            "- external Docker/Telegram/TON evidence is not inferred"
        ),
        "- development and release archives remain separate",
        (
            "- production_release_ready remains false until the "
            "required external acceptance gates pass"
        ),
        "",
        "## Config invariants",
    ]
    lines += [f"- {item}" for item in invariants[:16]]
    lines += ["", "## Start core"]
    lines += [f"- {item}" for item in route["start_core"]]
    lines += ["", "## Canonical anchors / required reads"]
    lines += [f"- {item}" for item in route_docs]
    lines += ["", "## Runtime/tests/report targets"]
    lines += [f"- {item}" for item in route_code]
    lines += ["", "## Allowed writes"]
    lines += [f"- {item}" for item in route_allowed] or [
        "- route-specific explicit approval required"
    ]
    lines += ["", "## Restricted"]
    lines += [f"- {item}" for item in route_restricted] or [
        "- no additional route restriction"
    ]
    lines += ["", "## Targeted validation"]
    lines += [f"- {item}" for item in route_validation] or [
        "- targeted grep / exact source check"
    ]
    lines += [
        "",
        "## Forbidden checks",
        "- full file_map.json read",
        "- full Healer/history read without explicit route",
        "- full GitHub CI verdict from local run",
        "- silent ci.yml or workflow change",
        "- manual HTML or inherited PNG as application proof",
        "",
        "## Bounded routed excerpts",
    ]
    total = 0
    candidates = [*route_docs, *route_code]
    excerpt_count = 0
    for rel in candidates:
        if any(token in rel for token in "*?[]"):
            continue
        path = base / rel
        excerpt = _excerpt(path, query)
        if not excerpt:
            continue
        remaining = MAX_TOTAL_EXCERPT_CHARS - total
        if remaining <= 0 or excerpt_count >= MAX_EXCERPT_FILES:
            break
        excerpt = excerpt[:remaining]
        lines += [f"### {rel}", "```text", excerpt, "```", ""]
        total += len(excerpt)
        excerpt_count += 1
    if excerpt_count == 0:
        lines.append(
            "- No bounded text excerpt available; open exact routed "
            "files before factual claims."
        )
    text = "\n".join(lines).rstrip() + "\n"
    cache, _ = ensure_dirs(base)
    (cache / "context_capsule_latest.md").write_text(
        text,
        encoding="utf-8",
    )
    return text
