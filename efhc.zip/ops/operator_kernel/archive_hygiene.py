"""Release archive hygiene checks."""

from __future__ import annotations

from pathlib import Path

JUNK_NAMES = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
    ".local_artifacts",
    "node_modules",
    ".next",
    "logs",
}

JUNK_FILE_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".tsbuildinfo",
    ".log",
}

REQUIRED = {
    "docs/SSOT",
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
    "HEALER_ATLAS.md",
    "reports",
}


def check_tree(root: Path | None = None) -> dict[str, object]:
    base = root or Path.cwd()
    junk: list[str] = []
    for path in base.rglob("*"):
        if path.name in JUNK_NAMES:
            junk.append(path.relative_to(base).as_posix())
        if path.is_file() and path.suffix in JUNK_FILE_SUFFIXES:
            junk.append(path.relative_to(base).as_posix())
    missing = [x for x in REQUIRED if not (base / x).exists()]
    return {
        "ok": not junk and not missing,
        "junk": junk,
        "missing": missing,
        "scope": "LOCAL_AUX_CHECK_ONLY",
    }
