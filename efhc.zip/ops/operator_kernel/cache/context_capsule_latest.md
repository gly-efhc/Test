# EFHC Context Capsule

## Task
cycle 1710 CI repair plus Admin NFT VIP collection handler canonicalization

## Archive
efhc_1710

## Task classification
- type: admin_ui_recovery
- confidence: 0.58
- signals: admin
- primary route: admin_ui_recovery
- secondary routes: none
- YAML primary: False

## Active boundary
- use the current KERNEL/START_HERE cycle boundary; historical capsule state cannot override it
- local validation retains LOCAL_AUX_CHECK_ONLY semantics: it proves only the checks actually run
- external Docker/Telegram/TON evidence is not inferred
- development and release archives remain separate
- production_release_ready remains false until the required external acceptance gates pass

## Config invariants
- docs/AI/AI_ARCHIVE_LAWS.md is immutable without user permission
- global_id only
- efhc_core and efhc_admin schemas
- active migration layer is
- 1 EFHC = 1 kWh
- withdraw only from main_balance
- bonus_balance is not withdrawable
- internal spend uses bonus first, then main
- CI files are manual-control without explicit user request
- local checks are not GitHub CI verdicts
- env scrub is not implemented by user condition

## Start core
- START_HERE.md
- KERNEL.md
- docs/AI/AI_ARCHIVE_LAWS.md
- docs/AI/AI_ARCHIVE_LAWS_LOCK.json
- docs/SSOT/AI_ARCHIVE_LAWS_CANON.md
- docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md
- docs/AI/AI_OPERATOR_RULES_EFHC.md
- docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md
- docs/SSOT/SSOT_INDEX.md
- docs/NORM/ARCHITECTURAL_LOCKS.md
- docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md
- docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md
- docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md
- ops/operator_kernel/cache/file_map.summary.json

## Canonical anchors / required reads
- docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md
- docs/admin/ADMIN_DASHBOARD_UI_KIT_CANON.md

## Runtime/tests/report targets
- frontend/src/pages/admin/**/*.tsx
- frontend/src/components/admin/**/*.tsx
- backend/app/routes/admin_*.py
- backend/app/services/admin/*.py
- tests/architecture/*admin*.py

## Allowed writes
- route-specific explicit approval required

## Restricted
- no additional route restriction

## Targeted validation
- targeted grep / exact source check

## Forbidden checks
- full file_map.json read
- full Healer/history read without explicit route
- full GitHub CI verdict from local run
- silent ci.yml or workflow change
- manual HTML or inherited PNG as application proof

## Bounded routed excerpts
### docs/frontend/FRONTEND_ADMIN_UI_KIT_FOUNDATION.md
```text
L241: 
L242: The proof panel uses the shared Admin Dashboard UI Kit primitives and records
L243: sandbox donor-source patterns without copying foreign runtime stacks.
L246: 
L247: The Admin UI Kit is now used for screenshot QA preparation through
L248: `AdminScreenshotQaPreparationPanel`. This extends the proof pass from
L249: work pass into a manual visual QA route.
L252: 
L253: Admin UI Kit adoption is now mapped in
L254: `docs/admin/ADMIN_DOCS_SSOT_ROUTE_MAP.md`. The map links applied
L255: Admin components to pages, backend roads and SSOT/NORM anchors.
```

### docs/admin/ADMIN_DASHBOARD_UI_KIT_CANON.md
```text
L41: 
L42: `frontend/src/components/admin/AdminInteractiveBankDashboard.tsx`
L43: 
L55: 
L56: The Admin UI Kit must keep:
L57: 
L58: - dark Web3/admin surface;
L59: - readable mobile-safe spacing;
L63: - dangerous actions behind explicit confirmation;
L64: - no endpoint/raw payload/debug dump on normal admin surfaces.
L65: 
L67: 
L68: Admin dashboard components must support interactive use:
L69: 
L70: - filter buttons;
L71: - click handlers;
L72: - live refresh / live indicators where relevant;
```
