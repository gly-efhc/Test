# EFHC Context Capsule

## Task
CI logs repair for pytest freezegun

## Archive
EFHC_Bot_v169_15.zip

## Task classification
- type: ci_logs_repair_or_verification
- confidence: 0.74
- signals: ci logs, pytest
- primary route: ci_log_exact_failure_repair
- secondary routes: none
- YAML primary: True

## Active boundary
- use the current KERNEL/START_HERE cycle boundary; historical capsule state cannot override it
- local validation retains LOCAL_AUX_CHECK_ONLY semantics: it proves only the checks actually run
- external Docker/Telegram/TON evidence is not inferred
- development and release archives remain separate
- production_release_ready remains false until the required external acceptance gates pass

## Config invariants
- docs/AI/AI_ARCHIVE_LAWS.md is immutable without user permission
- global_id only
- efhc_core and efhc_admin schemas
- active migration layer is
- 1 EFHC = 1 kWh
- withdraw only from main_balance
- bonus_balance is not withdrawable
- internal spend uses bonus first, then main
- CI files are manual-control without explicit user request
- local checks are not GitHub CI verdicts
- env scrub is not implemented by user condition

## Start core
- START_HERE.md
- KERNEL.md
- docs/AI/AI_ARCHIVE_LAWS.md
- docs/AI/AI_ARCHIVE_LAWS_LOCK.json
- docs/SSOT/AI_ARCHIVE_LAWS_CANON.md
- docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md
- docs/AI/AI_OPERATOR_RULES_EFHC.md
- docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md
- docs/SSOT/SSOT_INDEX.md
- docs/NORM/ARCHITECTURAL_LOCKS.md
- docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md
- docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md
- docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md
- ops/operator_kernel/cache/file_map.summary.json

## Canonical anchors / required reads
- docs/AI/AI_ARCHIVE_LAWS.md
- docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md
- docs/NORM/AI_EXECUTION_BOUNDS_AND_HANDOFF_STANDARD.md

## Runtime/tests/report targets
- exact failing test from supplied log

## Allowed writes
- route-specific explicit approval required

## Restricted
- ci.yml
- .github/workflows/*

## Targeted validation
- reproduce exact failure if possible
- targeted repair check
- bounded wider check with timeout

## Forbidden checks
- full file_map.json read
- full Healer/history read without explicit route
- full GitHub CI verdict from local run
- silent ci.yml or workflow change
- manual HTML or inherited PNG as application proof

## Bounded routed excerpts
### docs/AI/AI_ARCHIVE_LAWS.md
```text
L317:  
L318: - исключать их через `pytest.ini`;
L319:  
L356:   
L357: ## 7. Закон pytest.ini и CI
L358:  
L365:  
L366: - исключать `test_*.py` из pytest;
L367:  
L590:  
L591: Если активные architecture-тесты перенесены в архивную папку и исключены из pytest без полного replacement mapping, это не считается объединением.
L592:  
L601:  
L602: 3. `pytest --collect-only` не подтверждает активность замен;
L603:  
L710:  
L711: - pytest.ini скрывает проверки;
L712:  
```

### docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md
```text
L79: 
L80: - Runtime/CSS repair does not automatically create CANON/SSOT/Healer rules.
L81: - CANON/SSOT/NORM changes occur only when product truth or mandatory procedure changes.
```

### docs/NORM/AI_EXECUTION_BOUNDS_AND_HANDOFF_STANDARD.md
```text
L9: 
L10: - replacing real repair with endless CI/browser/dependency loops;
L11: - using anti-hang rules as an excuse not to run necessary verification.
L14: 
L15: The user has not prohibited CI, pytest, build, typecheck, lint, browser tests or regression.
L16: 
L35: → identify root cause
L36: → bounded repair
L37: → targeted tests/guards
```
