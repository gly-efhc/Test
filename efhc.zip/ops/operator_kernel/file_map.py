"""Build a fast file map for the EFHC archive."""

from __future__ import annotations

import argparse
import hashlib
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from ops.operator_kernel.cache_manager import ensure_dirs, write_json
from ops.operator_kernel.config_loader import (
    load_heavy_paths,
    load_layers,
)

HEAVY_PREFIXES = load_heavy_paths()
LAYER_PREFIXES = load_layers()
FILE_MAP_STALE_DAYS = 7

SKIP_PARTS = {
    ".git",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    "__pycache__",
    "node_modules",
    "ORIGINAL_SOURCES",
    "CHAT_BRANCHES",
    "CHATS",
}

START_CORE = {
    "START_HERE.md",
    "KERNEL.md",
    "docs/AI/AI_ARCHIVE_LAWS.md",
    "docs/AI/AI_ARCHIVE_LAWS_LOCK.json",
    "docs/SSOT/AI_ARCHIVE_LAWS_CANON.md",
    "docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md",
    "docs/AI/AI_OPERATOR_RULES_EFHC.md",
    "docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md",
    "docs/SSOT/SSOT_INDEX.md",
    "docs/NORM/ARCHITECTURAL_LOCKS.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md",
    "docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md",
    "docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md",
    "ops/operator_kernel/cache/file_map.summary.json",
}


def _layer(rel: str) -> str:
    for layer, prefix in LAYER_PREFIXES.items():
        if rel.startswith(prefix):
            return layer
    return "ROOT_OR_MISC"


def _kind(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".md":
        return "markdown"
    if suffix == ".py":
        return "python"
    if suffix in {".ts", ".tsx"}:
        return "typescript"
    if suffix == ".json":
        return "json"
    if suffix in {".yaml", ".yml"}:
        return "yaml"
    if suffix in {".txt", ".lock"}:
        return "text"
    return suffix[1:] if suffix else "file"


def _topics(rel: str) -> list[str]:
    low = rel.lower().replace("_", "-")
    topics: list[str] = []
    keys = (
        "admin",
        "shop",
        "withdraw",
        "frontend",
        "backend",
        "ci",
        "operator",
        "kernel",
        "cycle",
        "report",
        "faq",
        "exchange",
        "panels",
        "ton",
    )
    for key in keys:
        if key in low:
            topics.append(key)
    return topics


def _hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build__file__map(
    root: Path | None = None,
    archive_name: str | None = None,
) -> dict[str, Any]:
    base = root or Path.cwd()
    entries: list[dict[str, Any]] = []
    for path in sorted(base.rglob("*")):
        if path.is_dir():
            continue
        rel = path.relative_to(base).as_posix()
        if rel in {
            "ops/operator_kernel/cache/file_map.json",
            "ops/operator_kernel/cache/file_map.summary.json",
        }:
            continue
        if any(part in SKIP_PARTS for part in path.parts):
            continue
        heavy = rel.startswith(HEAVY_PREFIXES)
        item = {
            "path": rel,
            "layer": _layer(rel),
            "kind": _kind(path),
            "ext": path.suffix,
            "size_bytes": path.stat().st_size,
            "sha256": _hash(path),
            "topics": _topics(rel),
            "heavy": heavy,
            "default_start_core": rel in START_CORE,
        }
        entries.append(item)
    data = {
        "archive_name": archive_name or base.name,
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "files_total": len(entries),
        "entries": entries,
    }
    cache, _ = ensure_dirs(base)
    write_json(cache / "file_map.json", data)
    build_file_map_summary(data, base)
    return data


def build_file_map_summary(
    data: dict[str, Any],
    root: Path | None = None,
) -> dict[str, Any]:
    """Write the bounded startup map; full map remains machine-only."""
    base = root or Path.cwd()
    paths = [str(item["path"]) for item in data.get("entries", [])]

    def pick(terms: tuple[str, ...], limit: int = 24) -> list[str]:
        found = [
            path
            for path in paths
            if any(term in path.casefold() for term in terms)
        ]
        return found[:limit]

    summary = {
        "archive": data.get("archive_name", "EFHC_Bot_v171_63"),
        "purpose": "short startup map for Operator Kernel",
        "generated_at_utc": data.get("generated_at_utc"),
        "files_total": data.get("files_total", 0),
        "do_not_full_read_file_map_json": True,
        "full_map_role": "machine search index only",
        "critical_domains": {
            "operator_kernel": pick(
                ("operator_kernel", "kernel.md"),
                40,
            ),
            "frontend_visual": pick(
                (
                    "frontend_visual",
                    "screenshot",
                    "globalheader",
                    "bottomnav",
                ),
                40,
            ),
            "tonconnect_tonproof": pick(
                ("tonconnect", "tonproof", "wallet"),
                40,
            ),
            "i18n": pick(("i18n", "locale", "language_canon"), 40),
            "ci_logs": pick(("ci_log", "pytest", "validation"), 30),
            "archives": pick(
                ("archive", "handoff", "build_efhc_zip"),
                30,
            ),
        },
    }
    cache, _ = ensure_dirs(base)
    write_json(cache / "file_map.summary.json", summary)
    return summary


def _file_map_cache_path(root: Path | None = None) -> Path:
    base = root or Path.cwd()
    return base / "ops/operator_kernel/cache/file_map.json"


def warn_if_file_map_cache_stale(root: Path | None = None) -> bool:
    """Warn when the generated file map is missing or older than 7 days.

    Returns True when the cache is missing/stale.
    False means the cache is fresh. The warning is intentionally
    console-visible because Operator Kernel is
    part of mandatory Start Core navigation.
    """
    path = _file_map_cache_path(root)
    if not path.exists():
        print(
            "[Operator Kernel] WARNING: "
            "ops/operator_kernel/cache/file_map.json is missing; "
            "run python ops/operator_kernel/file_map.py --refresh",
            file=sys.stderr,
        )
        return True

    modified = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
    age = datetime.now(UTC) - modified
    if age > timedelta(days=FILE_MAP_STALE_DAYS):
        print(
            "[Operator Kernel] WARNING: file_map.json is older than "
            f"{FILE_MAP_STALE_DAYS} days; run "
            "python ops/operator_kernel/file_map.py --refresh",
            file=sys.stderr,
        )
        return True
    return False


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Build or check the EFHC Operator Kernel file map.",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Regenerate ops/operator_kernel/cache/file_map.json.",
    )
    parser.add_argument(
        "--archive-name",
        default=None,
        help="Optional archive name written into the file map.",
    )
    args = parser.parse_args(argv)

    warn_if_file_map_cache_stale(Path.cwd())
    if args.refresh:
        data = build__file__map(
            Path.cwd(),
            archive_name=args.archive_name,
        )
        print(f"file_map refreshed: {data['files_total']} files")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
