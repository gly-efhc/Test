#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
QUERY="${1:-operator kernel refresh}"

cd "${ROOT_DIR}"
python -m ops.operator_kernel.run_operator_cycle --mode clean-cache
python -m ops.operator_kernel.run_operator_cycle --mode map
python -m ops.operator_kernel.run_operator_cycle --mode capsule --query "${QUERY}"
