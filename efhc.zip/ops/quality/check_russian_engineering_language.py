#!/usr/bin/env python3
"""Проверить русскоязычную инженерную доктрину проекта.

Исторические неизменённые файлы допускаются только по зафиксированному
baseline. Любой новый или изменённый тест, отчёт, документ, комментарий
либо docstring обязан быть написан по-русски. Технические имена,
протоколы, пути и фрагменты кода не считаются самостоятельной прозой.
"""

from __future__ import annotations

import argparse
import ast
import io
import json
import re
import tokenize
from collections.abc import Iterable
from pathlib import Path
from typing import Any

КИРИЛЛИЦА = re.compile(r"[А-Яа-яЁё]")
ЛАТИНСКИЕ_СЛОВА = re.compile(r"[A-Za-z]{2,}")
ТЕХНИЧЕСКАЯ_СТРОКА = re.compile(
    r"^[A-Za-z0-9_./:`'\"=<>|+*()\[\]{},;!?@#$%^&~\\-]+$"
)
РАЗРЕШЁННЫЕ_КОММЕНТАРИИ = (
    "noqa",
    "type: ignore",
    "pragma:",
    "coding:",
    "!/usr/bin/env",
)


def _is_english_prose(text: str) -> bool:
    clean = " ".join(text.strip().split())
    if not clean or КИРИЛЛИЦА.search(clean):
        return False
    if any(
        clean.lower().startswith(item)
        for item in РАЗРЕШЁННЫЕ_КОММЕНТАРИИ
    ):
        return False
    if ТЕХНИЧЕСКАЯ_СТРОКА.fullmatch(clean):
        return False
    return len(ЛАТИНСКИЕ_СЛОВА.findall(clean)) >= 3


def _python_violations(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    violations: list[str] = []
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return [f"Невозможно разобрать Python: {exc}"]

    nodes: Iterable[ast.AST] = (
        node
        for node in ast.walk(tree)
        if isinstance(
            node,
            (
                ast.Module,
                ast.ClassDef,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        )
    )
    for node in nodes:
        doc = ast.get_docstring(node, clean=False)
        if doc and _is_english_prose(doc):
            line = getattr(node, "lineno", 1)
            violations.append(f"строка {line}: английский docstring")

    try:
        tokens = tokenize.generate_tokens(io.StringIO(text).readline)
        for token in tokens:
            if token.type != tokenize.COMMENT:
                continue
            comment = token.string.lstrip("#").strip()
            if _is_english_prose(comment):
                violations.append(
                    f"строка {token.start[0]}: английский комментарий"
                )
    except tokenize.TokenError as exc:
        violations.append(f"Ошибка разбора комментариев: {exc}")

    if "tests" in path.parts:
        for node in ast.walk(tree):
            if (
                isinstance(
                    node,
                    (ast.FunctionDef, ast.AsyncFunctionDef),
                )
                and node.name.startswith("test_")
                and not КИРИЛЛИЦА.search(node.name)
            ):
                violations.append(
                    f"строка {node.lineno}: имя теста не на русском"
                )
    return violations


def _markdown_violations(path: Path) -> list[str]:
    violations: list[str] = []
    in_code = False
    for number, raw in enumerate(
        path.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        stripped = raw.strip()
        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if in_code or not stripped:
            continue
        clean = re.sub(r"https?://\S+", "", stripped)
        clean = re.sub(r"`[^`]+`", "", clean)
        clean = clean.lstrip("#>-*0123456789. |")
        if _is_english_prose(clean):
            violations.append(
                f"строка {number}: английский текст документа"
            )
    return violations


def _json_violations(path: Path) -> list[str]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"Некорректный JSON: {exc}"]
    violations: list[str] = []

    def walk(value: Any, location: str) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                key_text = str(key)
                key_is_path = "/" in key_text or "." in key_text
                key_is_enum = (
                    "_" in key_text
                    and key_text.upper() == key_text
                )
                technical_key_names = {
                    "backend_route_file",
                    "backend_route_function",
                }
                if (
                    key_text not in technical_key_names
                    and not key_is_path
                    and not key_is_enum
                    and _is_english_prose(key_text.replace("_", " "))
                ):
                    violations.append(
                        f"{location}: английский ключ «{key_text}»"
                    )
                technical_value_keys = {
                    "файл",
                    "строка_или_объект",
                    "слой",
                    "текущее_поле",
                    "семантика",
                    "целевое_поле",
                    "решение",
                    "цикл_миграции",
                    "риск",
                    "фрагмент_источника",
                    "класс",
                    "поле",
                    "объект",
                    "параметры",
                    "декораторы",
                    "команда_сборки",
                    "команда_выполнения",
                    "команда",
                    "junit",
                    "backend_route_file",
                    "backend_route_function",
                }
                if key_text in technical_value_keys:
                    continue
                walk(item, f"{location}.{key_text}")
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, f"{location}[{index}]")
        elif isinstance(value, str) and _is_english_prose(value):
            violations.append(f"{location}: английское значение")

    walk(data, "корень")
    return violations


def violations(path: Path) -> list[str]:
    """Вернуть русскоязычные описания найденных нарушений."""

    if path.suffix == ".py":
        return _python_violations(path)
    if path.suffix == ".md":
        return _markdown_violations(path)
    if path.suffix == ".json" and "reports" in path.parts:
        return _json_violations(path)
    return []


def _controlled_files(root: Path) -> set[str]:
    result: set[str] = set()
    patterns = (
        "*.md",
        "backend/**/*.py",
        "ops/**/*.py",
        "scripts/**/*.py",
        "tests/**/*.py",
        "reports/**/*.md",
        "reports/**/*.json",
    )
    for pattern in patterns:
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if any(
                part in {
                    "__pycache__",
                    ".pytest_cache",
                    ".mypy_cache",
                    ".ruff_cache",
                }
                for part in path.parts
            ):
                continue
            relative = path.relative_to(root).as_posix()
            generated_machine_prefixes = (
                "reports/generated/russian_engineering_language_",
                "reports/generated/tg_id_final_inventory.",
                "reports/generated/provider_identity_final_inventory.",
                "reports/generated/tg_id_actionable_by_domain.",
                "reports/generated/tg_id_release_inventory.",
                "reports/generated/cycle_1679_1682_progress.",
                "reports/generated/runtime_openapi.",
                "reports/generated/test_tg_id_telegram_allowlist.",
                "reports/generated/cycle_1683_local_checks.",
                "reports/generated/cycle_1685_local_checks.",
                "reports/generated/deposit_watcher.",
                "reports/generated/identity_inventory_comparison_",
                "reports/generated/ci_logs_",
            )
            if relative.startswith(generated_machine_prefixes):
                continue
            result.add(relative)
    return result


def check(root: Path, baseline_path: Path) -> dict[str, Any]:
    """Проверить отсутствие новых англоязычных артефактов."""

    root = root.resolve()
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    historical = {
        (
            item.get("путь")
            or "".join(item.get("путь_фрагменты", []))
        ): int(item["максимум_нарушений"])
        for item in baseline["исторические_исключения"]
    }
    found: dict[str, list[str]] = {}
    controlled = _controlled_files(root)
    for relative in sorted(controlled):
        current = violations(root / relative)
        if not current:
            continue
        allowed_count = historical.get(relative, 0)
        if len(current) <= allowed_count:
            continue
        found[relative] = current[allowed_count:]

    return {
        "схема_отчёта": (
            "EFHC_RUSSIAN_ENGINEERING_LANGUAGE_RESULT_V1"
        ),
        "цикл": 1600,
        "проверено_файлов": len(controlled),
        "исторических_исключений": len(historical),
        "новые_нарушения": found,
        "пройдено": not found,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--baseline",
        type=Path,
        default=Path(
            "ops/quality/russian_engineering_language_baseline.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root, args.baseline)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["пройдено"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
