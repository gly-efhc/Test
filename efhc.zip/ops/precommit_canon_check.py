# -*- coding: utf-8 -*-
# ops/precommit_canon_check.py
# =====================================================================
# Назначение:
# Локальная проверка канона перед коммитом (git hook).
# • длина строк <= 72
# • запрет псевдо-ID (u+id) в исходниках
#
# Важно:
# • Это НЕ замена pytest, а быстрый фильтр.
# • В CI канон закреплён тестами.
# =====================================================================

from __future__ import annotations

import sys
from pathlib import Path


MAX_LEN = 72

EXCLUDE_PARTS = {
    ".git",
    ".next",
    ".pytest_cache",
    "__pycache__",
    "alembic",
    "migrations",
    "node_modules",
    "dist",
    "build",
    "coverage",
    "venv",
    ".venv",
}

SUFFIXES = {
    ".css",
    ".md",
    ".py",
    ".pyi",
    ".sh",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}


def _is_excluded(rel: Path) -> bool:
    parts = set(rel.parts)
    return any(p in parts for p in EXCLUDE_PARTS)


def _iter_files(root: Path):
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        rel = p.relative_to(root)
        if _is_excluded(rel):
            continue
        if p.suffix.lower() not in SUFFIXES:
            continue
        yield p, rel


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    violations: list[str] = []

    for p, rel in _iter_files(root):
        try:
            data = p.read_text(encoding="utf-8", errors="strict")
        except UnicodeDecodeError:
            continue

        for idx, line in enumerate(data.splitlines(), start=1):
            forbidden = "u" + "id"
            if forbidden in line:
                violations.append(f"{rel}:{idx}: запрещено: псевдо-ID")
            ln = len(line)
            if ln > MAX_LEN:
                violations.append(
                    f"{rel}:{idx}: L={ln} > {MAX_LEN}: {line[:80]!r}"
                )

    if violations:
        head = "\n".join(violations[:200])
        more = ""
        if len(violations) > 200:
            more = f"\n... and {len(violations) - 200} more"
        sys.stderr.write(
            "\nPRE-COMMIT CANON CHECK FAILED\n" + head + more + "\n"
        )
        return 1

    print("precommit canon check: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
