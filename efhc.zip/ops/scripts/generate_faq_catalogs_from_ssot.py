from __future__ import annotations

import json
from pathlib import Path

LANGS = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)

APPROVAL_MANIFEST = Path(
    "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json"
)
ALLOWED_APPROVAL_STATUS = {
    "draft",
    "approved",
    "superseded",
    "rejected",
    "implemented",
}
REQUIRED_APPROVAL_FIELDS = {
    "approval_id",
    "status",
    "scope",
    "source_cycle",
    "ru_section_ids",
    "ru_question_ids",
    "change_kind",
    "draft_doc",
    "approved_by_user",
    "approval_basis",
    "rewrite_allowed",
    "runtime_rebuild_allowed",
    "notes",
}


def _load_ssot(root: Path, lang: str) -> dict[str, object]:
    path = root / f"docs/SSOT/faq_ssot/{lang}/faq_{lang}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _load_approval_manifest(root: Path) -> dict[str, object]:
    path = root / APPROVAL_MANIFEST
    return json.loads(path.read_text(encoding="utf-8"))


def validate_generation_preconditions(root: Path) -> None:
    manifest = _load_approval_manifest(root)
    entries = manifest["entries"]
    if int(manifest["entries_total"]) != len(entries):
        raise ValueError("FAQ approval manifest count mismatch")
    if not entries:
        raise ValueError("FAQ approval manifest has no entries")

    for entry in entries:
        if not REQUIRED_APPROVAL_FIELDS.issubset(entry):
            raise ValueError(
                "FAQ approval manifest entry is incomplete"
            )
        status = str(entry["status"])
        if status not in ALLOWED_APPROVAL_STATUS:
            raise ValueError("FAQ approval manifest status is invalid")

    for lang in LANGS:
        ssot = _load_ssot(root, lang)
        sections = ssot["sections"]
        if len(sections) != 20:
            raise ValueError(f"FAQ sections mismatch for {lang}")
        total_items = sum(len(s["items"]) for s in sections)
        if total_items != 250:
            raise ValueError(f"FAQ item count mismatch for {lang}")
        sec13 = next(s for s in sections if int(s["id"]) == 13)
        if str(sec13["title"]) != "Hub":
            raise ValueError(f"FAQ section 13 mismatch for {lang}")


def _build_catalog(root: Path) -> dict[str, object]:
    data: dict[str, object] = {}
    for lang in LANGS:
        ssot = _load_ssot(root, lang)
        sections = []
        for sec_idx, section in enumerate(ssot["sections"], start=1):
            items = []
            for item_idx, item in enumerate(section["items"], start=1):
                items.append(
                    {
                        "id": f"{sec_idx}-{item_idx}",
                        "question": item["q"],
                        "answer": item["a"],
                    }
                )
            sections.append(
                {
                    "id": str(section["id"]),
                    "title": str(section["title"]),
                    "subsections": [
                        {
                            "id": f"{section['id']}.1",
                            "title": str(section["title"]),
                            "items": items,
                        }
                    ],
                }
            )
        data[lang] = {"title": ssot["title"], "sections": sections}
    return data


def _render_ts(value: object, depth: int = 0) -> str:
    pad = "  " * depth
    next_pad = "  " * (depth + 1)
    if isinstance(value, dict):
        lines = ["{"]
        items = list(value.items())
        for idx, (key, item) in enumerate(items, start=1):
            rendered = _render_ts(item, depth + 1)
            suffix = "," if idx < len(items) else ""
            lines.append(f"{next_pad}{key}: {rendered}{suffix}")
        lines.append(f"{pad}}}")
        return "\n".join(lines)
    if isinstance(value, list):
        lines = ["["]
        for idx, item in enumerate(value, start=1):
            rendered = _render_ts(item, depth + 1)
            suffix = "," if idx < len(value) else ""
            rendered_lines = rendered.splitlines()
            lines.append(f"{next_pad}{rendered_lines[0]}")
            for line in rendered_lines[1:]:
                lines.append(f"{next_pad}{line}")
            lines[-1] += suffix
        lines.append(f"{pad}]")
        return "\n".join(lines)
    return json.dumps(value, ensure_ascii=False)


def render_catalogs_ts(root: Path) -> str:
    validate_generation_preconditions(root)
    catalog = _build_catalog(root)
    chunks: list[str] = []
    for lang in LANGS:
        rendered = _render_ts(catalog[lang], 1)
        chunks.append(f"  {lang}: {rendered},")
    header = "// GENERATED FILE. DO NOT EDIT MANUALLY.\n"
    header += (
        "// Source: docs/SSOT/faq_ssot/*/faq_*.json + "
        "docs/SSOT/faq_ssot/FAQ_APPROVAL_MANIFEST.json\n"
    )
    header += 'import type { Lang } from "../../lib/i18n";\n'
    header += 'import type { FaqCatalog } from "./types";\n\n'
    body = "\n".join(chunks)
    start = "export const faqCatalogByLang: "
    start += "Record<Lang, FaqCatalog> = {\n"
    return header + start + body + "\n};\n"


def write_runtime_catalogs(
    root: Path,
    catalog: dict[str, object],
) -> None:
    target_dir = root / "frontend/public/faq"
    target_dir.mkdir(parents=True, exist_ok=True)
    for lang in LANGS:
        target = target_dir / f"{lang}.json"
        payload = json.dumps(
            catalog[lang],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        target.write_text(payload + "\n", encoding="utf-8")


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    validate_generation_preconditions(root)
    catalog = _build_catalog(root)
    target = root / "frontend/src/data/faq/catalogs.ts"
    target.write_text(render_catalogs_ts(root), encoding="utf-8")
    write_runtime_catalogs(root, catalog)


if __name__ == "__main__":
    main()
