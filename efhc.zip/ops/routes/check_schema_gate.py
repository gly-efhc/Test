from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODELS = ROOT / "backend" / "app" / "models"
MIGRATION = (
    ROOT / "backend" / "migrations" / "versions" / "0001_init.py"
)


def build() -> dict[str, object]:
    tables: list[dict[str, str]] = []
    pattern = r"__tablename__\s*=\s*['\"]([^'\"]+)['\"]"
    for file_path in sorted(MODELS.glob("*.py")):
        text = file_path.read_text(
            encoding="utf-8",
            errors="replace",
        )
        for match in re.finditer(pattern, text):
            tables.append(
                {
                    "file": str(file_path.relative_to(ROOT)),
                    "table": match.group(1),
                }
            )
    migration_text = MIGRATION.read_text(
        encoding="utf-8",
        errors="replace",
    )
    metadata_driven = "Base.metadata.create_all" in migration_text
    return {
        "model_table_count": len(tables),
        "metadata_driven_0001": metadata_driven,
        "migration_file": str(MIGRATION.relative_to(ROOT)),
        "tables": tables,
        "boundary": "field-level proof needs a DB-backed check",
    }


if __name__ == "__main__":
    print(json.dumps(build(), ensure_ascii=False, indent=2))
