"""Compare ORM model declarations with the 0001 migration strategy.

This is a static proof helper. It does not import SQLAlchemy. It parses
model table declarations and checks whether 0001 uses metadata-driven
creation plus sanity anchors for important release tables.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODEL_DIR = ROOT / "backend" / "app" / "models"
MIG = ROOT / "backend" / "migrations" / "versions" / "0001_init.py"
OUT = ROOT / "reports" / "generated" / "orm_0001_compare.json"

TABLE_RE = re.compile(r"__tablename__\s*=\s*[\"']([^\"']+)[\"']")
CLASS_RE = re.compile(r"^class\s+(\w+)\(", re.MULTILINE)
IMPORTANT = {
    "users",
    "withdraw_requests",
    "payment_intents",
    "withdraw_outcome_events",
    "outcome_fallback_promos",
    "tasks",
    "task_submissions",
    "user_tasks_status",
    "task_bonus_log",
    "task_complete_lock",
    "efhc_sale_packages",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def collect_models() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for file in sorted(MODEL_DIR.glob("*.py")):
        text = read_text(file)
        tables = TABLE_RE.findall(text)
        classes = CLASS_RE.findall(text)
        for index, table in enumerate(tables):
            cls = classes[index] if index < len(classes) else "unknown"
            rows.append(
                {
                    "table": table,
                    "class": cls,
                    "file": str(file.relative_to(ROOT)),
                }
            )
    return rows


def main() -> None:
    models = collect_models()
    migration = read_text(MIG)
    metadata_driven = "Base.metadata.create_all" in migration
    imports_all = "__import___all__model_modules" in migration
    missing_important = sorted(
        table for table in IMPORTANT if table not in migration
    )
    tables = sorted({row["table"] for row in models})
    data = {
        "models": models,
        "model_table_count": len(tables),
        "migration_file": str(MIG.relative_to(ROOT)),
        "metadata_driven": metadata_driven,
        "imports__all__model_modules": imports_all,
        "important_tables_missing_as_text": missing_important,
        "strategy": (
            "0001 delegates table creation to Base.metadata.create_all"
            if metadata_driven
            else "0001 lacks metadata create_all anchor"
        ),
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "model_table_count": len(tables),
                "metadata_driven": metadata_driven,
                "missing_important": len(missing_important),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
