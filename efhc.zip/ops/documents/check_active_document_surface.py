#!/usr/bin/env python3
"""Завершить с ошибкой при возврате исторического шума в активные слои."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FORBIDDEN_ACTIVE_NAMES = {
    "GLOBAL_IDENTITY_AUTH_SSOT.md",
    "GLOBAL_IDENTITY_MIGRATION_NORM.md",
    "SYSTEM_LOCK_TG_ID.md",
    "USER_IDENTITY_MIGRATION_NORM.md",
    "PROVIDER_IDENTIFIER_NAMING_OPTIONS.md",
    "TZ_global_id_migration.md",
    "TZ_global_id_full_cutover.md",
}
TEMPORARY_NORM_NAME = re.compile(
    r"(?:_V\d|PLAN|AUDIT_FOLLOWUP|REPORT|PROOF|PROTOTYPE|"
    r"BACKLOG|CONFIRMATION|CLOSURE|_TRACE|CANDIDATES|CONSOLIDATION_EXECUTION)",
    re.I,
)
VERSIONED_SSOT = re.compile(r"_V\d", re.I)
REQUIRED = {
    "docs/SSOT/GLOBAL_IDENTITY_SSOT.md",
    "docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md",
    "docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md",
    "docs/SSOT/IDENTITY_GLOSSARY.md",
    "docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md",
    "docs/SSOT/ACCOUNT_SURFACES_SSOT.md",
    "docs/NORM/DATABASE_MIGRATION_INVARIANTS_NORM.md",
    "docs/NORM/EVENT_CONTRACTS_NORM.md",
}


def main() -> int:
    errors: list[str] = []
    for relative in sorted(REQUIRED):
        if not (ROOT / relative).is_file():
            errors.append(f"missing required active document: {relative}")

    for base in (ROOT / "docs/SSOT", ROOT / "docs/NORM"):
        for path in base.rglob("*.md"):
            name = path.name
            relative = path.relative_to(ROOT).as_posix()
            if name in FORBIDDEN_ACTIVE_NAMES:
                errors.append(f"legacy identity document returned: {relative}")
            if base.name == "SSOT" and VERSIONED_SSOT.search(name):
                errors.append(f"versioned SSOT filename: {relative}")
            stable_audit_names = {
                "AUDIT_RULES.md",
                "WITHDRAW_AUDIT_CANON.md",
                "DEPENDENCY_AUDIT_TRIAGE.md",
            }
            if (
                base.name == "NORM"
                and TEMPORARY_NORM_NAME.search(name)
                and name not in stable_audit_names
            ):
                errors.append(f"temporary/event document in NORM: {relative}")

    routes = ROOT / "ops/operator_kernel/config/routes.yaml"
    if routes.exists() and "АРТЕФАКТЫ/" in routes.read_text(encoding="utf-8"):
        errors.append("operator routes reference removed artifacts root")

    if (ROOT / "АРТЕФАКТЫ").exists():
        errors.append("removed artifacts root returned to active HEAD")
    if (ROOT / "docs/history").exists():
        errors.append("externalized artifacts returned through docs/history")

    if errors:
        print("\n".join(errors))
        return 1
    print("ACTIVE_DOCUMENT_SURFACE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
