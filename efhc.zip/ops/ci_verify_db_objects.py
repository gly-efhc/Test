# -*- coding: utf-8 -*-
"""
ops/ci_verify_db_objects.py
================================================================================
Назначение:
  Детерминированная Postgres-only sanity-проверка, что после alembic в БД
  существуют:
    1) обе схемы efhc_core и efhc_admin
    2) ВСЕ обязательные таблицы (fq: <schema>.<table>) согласно SSOT_TABLES_ORM.csv

Использование (CI):
  python ops/ci_verify_db_objects.py

Переменные окружения:
  - PSYCOPG_URL (рекомендуется) или DATABASE_URL
    Важно: psycopg.connect НЕ понимает postgresql+psycopg:// — нужен postgresql://
================================================================================
"""

from __future__ import annotations

import csv
import os
import sys
from pathlib import Path
from typing import Iterable

import psycopg


CANON_SCHEMAS: tuple[str, str] = ("efhc_core", "efhc_admin")


def _normalize_url(url: str) -> str:
    # psycopg.connect не принимает postgresql+psycopg://
    return url.replace("postgresql+psycopg://", "postgresql://")


def _load_required_from_ssot(repo_root: Path) -> list[tuple[str, str]]:
    """Истина списка таблиц = docs/ssot_pack/SSOT_TABLES_ORM.csv.

    Ожидаемый формат колонок: schema, table, ...
    Возвращаем список пар (schema, table), дедуплицированный и отсортированный.
    """
    p = repo_root / "docs" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    if not p.exists():
        raise RuntimeError(f"SSOT missing: {p}")

    pairs: set[tuple[str, str]] = set()
    with p.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            schema = (row.get("schema") or "").strip()
            table = (row.get("table") or "").strip()
            if not schema or not table:
                continue
            pairs.add((schema, table))

    if not pairs:
        raise RuntimeError("SSOT_TABLES_ORM.csv is empty")

    return sorted(pairs)


def _fq(schema: str, table: str) -> str:
    return f"{schema}.{table}"


def _find_table_locations(cur: psycopg.Cursor, table: str) -> list[str]:
    """Возвращает список схем, где реально существует таблица relname=table."""
    cur.execute(
        """
        SELECT n.nspname
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind IN ('r','p') AND c.relname = %s
        ORDER BY n.nspname
        """,
        (table,),
    )
    return [r[0] for r in cur.fetchall()]


def main() -> int:
    url = os.getenv("PSYCOPG_URL") or os.getenv("DATABASE_URL")
    if not url:
        print("ERROR: PSYCOPG_URL or DATABASE_URL is required", file=sys.stderr)
        return 2
    url = _normalize_url(url)

    repo_root = Path(__file__).resolve().parents[1]
    required_pairs = _load_required_from_ssot(repo_root)

    missing: list[str] = []
    misplaced_hints: list[str] = []

    with psycopg.connect(url) as conn:
        with conn.cursor() as cur:
            # 1) Проверка схем (канон)
            for sch in CANON_SCHEMAS:
                cur.execute("SELECT 1 FROM pg_namespace WHERE nspname=%s", (sch,))
                if cur.fetchone() is None:
                    missing.append(f"schema:{sch}")

            # 2) Проверка таблиц (fq)
            for schema, table in required_pairs:
                fq = _fq(schema, table)
                cur.execute("SELECT to_regclass(%s)", (fq,))
                val = cur.fetchone()[0]
                if val is None:
                    missing.append(fq)
                    # Диагностика: есть ли таблица с таким именем в другой схеме?
                    locations = _find_table_locations(cur, table)
                    if locations:
                        misplaced_hints.append(
                            f"HINT: {fq} missing, but table '{table}' exists in schemas: {', '.join(locations)}"
                        )

    if missing:
        print("ERROR: required DB objects missing after alembic:", file=sys.stderr)
        for t in missing:
            print(f" - {t}", file=sys.stderr)
        if misplaced_hints:
            print("---- diagnostics ----", file=sys.stderr)
            for h in misplaced_hints:
                print(h, file=sys.stderr)
        return 2

    print(
        f"OK: all required DB objects exist ({len(required_pairs)} tables / {len(CANON_SCHEMAS)} schemas).\n"
        f"Schemas: {', '.join(CANON_SCHEMAS)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
