# -*- coding: utf-8 -*-
"""
ops/ci_verify_db_objects.py
================================================================================
Назначение:
  Детерминированная Postgres-only sanity-проверка, что после alembic в БД
  существуют ВСЕ обязательные таблицы в 2 схемах (efhc_core + efhc_admin),
  согласно docs/SSOT_DB_SCHEMAS_TABLES.md.

Использование (CI):
  python ops/ci_verify_db_objects.py

Переменные окружения:
  - PSYCOPG_URL (рекомендуется) или DATABASE_URL
    Важно: psycopg.connect НЕ понимает postgresql+psycopg:// — нужен postgresql://
================================================================================
"""
from __future__ import annotations

import os
import sys

import psycopg


REQUIRED = [
    "efhc_core.achievements",
    "efhc_core.admin_action_log",
    "efhc_core.admin_bank_config",
    "efhc_core.admin_role",
    "efhc_core.admin_whitelist",
    "efhc_core.ads",
    "efhc_core.app_settings",
    "efhc_core.bank_state",
    "efhc_core.efhc_transfers_log",
    "efhc_core.idempotency_key",
    "efhc_core.payment_intents",
    "efhc_core.lotteries",
    "efhc_core.lotteries_nft_claims",
    "efhc_core.lotteries_results",
    "efhc_core.lotteries_tickets",
    "efhc_core.lotteries_user_stats",
    "efhc_core.panels",
    "efhc_core.ranks_snapshots",
    "efhc_core.ranks_top_cache",
    "efhc_core.referral_bonus_ledger",
    "efhc_core.referral_links",
    "efhc_core.shop_items",
    "efhc_core.shop_orders",
    "efhc_core.task_submissions",
    "efhc_core.tasks",
    "efhc_core.ton_inbox_logs",
    "efhc_core.user_cosmetics",
    "efhc_core.user_skins",
    "efhc_core.users",
    "efhc_core.wallet_bindings",
    "efhc_core.withdraw_requests",
    "efhc_core.withdrawals",
]


def _normalize_url(url: str) -> str:
    # psycopg.connect не принимает postgresql+psycopg://
    return url.replace("postgresql+psycopg://", "postgresql://")


def main() -> int:
    url = os.getenv("PSYCOPG_URL") or os.getenv("DATABASE_URL")
    if not url:
        print("ERROR: PSYCOPG_URL or DATABASE_URL is required", file=sys.stderr)
        return 2

    url = _normalize_url(url)

    missing: list[str] = []
    with psycopg.connect(url) as conn:
        with conn.cursor() as cur:

        # Канон: схемы должны существовать даже если в efhc_admin нет таблиц.
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_namespace WHERE nspname=%s", ("efhc_core",))
            if cur.fetchone() is None:
                missing.append("schema:efhc_core")
            cur.execute("SELECT 1 FROM pg_namespace WHERE nspname=%s", ("efhc_admin",))
            if cur.fetchone() is None:
                missing.append("schema:efhc_admin")
            for name in REQUIRED:
                cur.execute("SELECT to_regclass(%s)", (name,))
                val = cur.fetchone()[0]
                if val is None:
                    missing.append(name)

    if missing:
        print("ERROR: required tables missing after alembic:", file=sys.stderr)
        for t in missing:
            print(f" - {t}", file=sys.stderr)
        return 2

    print("OK: all required tables exist (2 schemas / 30 tables).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
