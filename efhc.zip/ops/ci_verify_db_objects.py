# -*- coding: utf-8 -*-
"""
ops/ci_verify_db_objects.py
================================================================================
Назначение:
  Детерминированная Postgres-only sanity-проверка, что после alembic в БД
  существуют ВСЕ обязательные таблицы в 2 схемах (efhc_core + efhc_admin),
  согласно docs/SSOT_DB_SCHEMAS_TABLES.md.

Использование (CI):
  python ops/ci_verify_db_objects.py

Переменные окружения:
  - PSYCOPG_URL (рекомендуется) или DATABASE_URL
    Важно: psycopg.connect НЕ понимает postgresql+psycopg:// — нужен postgresql://
================================================================================
"""
from __future__ import annotations

import os
import sys

import csv
from pathlib import Path

import psycopg


def _load_required_from_ssot(repo_root: Path) -> list[str]:
    """Истина списка таблиц = SSOT_TABLES_ORM.csv.

    Формат: schema, table, ...
    Возвращаем fq-имена вида: <schema>.<table>
    """

    p = repo_root / "docs" / "ssot_pack" / "SSOT_TABLES_ORM.csv"
    if not p.exists():
        raise RuntimeError(f"SSOT missing: {p}")
    required: list[str] = []
    with p.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            schema = (row.get("schema") or "").strip()
            table = (row.get("table") or "").strip()
            if not schema or not table:
                continue
            required.append(f"{schema}.{table}")
    if not required:
        raise RuntimeError("SSOT_TABLES_ORM.csv is empty")
    return required


def _normalize_url(url: str) -> str:
    # psycopg.connect не принимает postgresql+psycopg://
    return url.replace("postgresql+psycopg://", "postgresql://")


def main() -> int:
    url = os.getenv("PSYCOPG_URL") or os.getenv("DATABASE_URL")
    if not url:
        print("ERROR: PSYCOPG_URL or DATABASE_URL is required", file=sys.stderr)
        return 2

    url = _normalize_url(url)

    repo_root = Path(__file__).resolve().parents[1]
    required = _load_required_from_ssot(repo_root)

    missing: list[str] = []
    with psycopg.connect(url) as conn:
        # Канон: схемы должны существовать.
        with conn.cursor() as cur:
            for sch in ("efhc_core", "efhc_admin"):
                cur.execute(
                    "SELECT 1 FROM pg_namespace WHERE nspname=%s",
                    (sch,),
                )
                if cur.fetchone() is None:
                    missing.append(f"schema:{sch}")

            for name in required:
                cur.execute("SELECT to_regclass(%s)", (name,))
                val = cur.fetchone()[0]
                if val is None:
                    missing.append(name)

    if missing:
        print("ERROR: required tables missing after alembic:", file=sys.stderr)
        for t in missing:
            print(f" - {t}", file=sys.stderr)
        return 2

    print(f"OK: all required tables exist ({len(required)} tables / 2 schemas).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
