from __future__ import annotations

import argparse
import json
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass
class Check:
    name: str
    url: str
    expect_status: int = 200
    required_text: str | None = None


def fetch(url: str, timeout: float) -> tuple[int, str]:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "efhc-smoke"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(200_000).decode("utf-8", "replace")
            return int(resp.status), body
    except urllib.error.HTTPError as exc:
        body = exc.read(200_000).decode("utf-8", "replace")
        return int(exc.code), body


def run_check(check: Check, timeout: float) -> bool:
    status, body = fetch(check.url, timeout)
    ok = status == check.expect_status
    if check.required_text is not None:
        ok = ok and check.required_text in body
    label = "OK" if ok else "FAIL"
    print(f"[{label}] {check.name}: HTTP {status} {check.url}")
    if not ok:
        preview = body[:500].replace("\n", " ")
        print(
            "      expected="
            f"{check.expect_status} text={check.required_text!r}",
        )
        print(f"      body={preview}")
    return ok


def main() -> int:
    parser = argparse.ArgumentParser(
        description="EFHC local Docker smoke test",
    )
    parser.add_argument("--frontend", default="http://localhost:3000")
    parser.add_argument("--backend", default="http://localhost:8000")
    parser.add_argument("--tg-id", default="0")
    parser.add_argument("--timeout", default=8.0, type=float)
    args = parser.parse_args()

    frontend = args.frontend.rstrip("/")
    backend = args.backend.rstrip("/")
    tg_id = args.tg_id

    checks = [
        Check("backend health", f"{backend}/api/health"),
        Check("backend db health", f"{backend}/api/health/db"),
        Check("frontend home", frontend, required_text="_NEXT_DATA_"),
        Check(
            "frontend faq",
            f"{frontend}/faq",
            required_text="_NEXT_DATA_",
        ),
        Check(
            "frontend admin logs route",
            f"{frontend}/admin/logs",
            required_text="_NEXT_DATA_",
        ),
        Check("frontend ru locale", f"{frontend}/locale/ru.json"),
        Check("pwa manifest", f"{frontend}/manifest.webmanifest"),
        Check(
            "sync snapshot",
            f"{backend}/api/sync/user/{tg_id}?fresh=1",
        ),
        Check("tasks catalog", f"{backend}/api/tasks/catalog"),
        Check(
            "ranks",
            f"{backend}/api/ranks/my-plus-top?tg_id={tg_id}",
        ),
        Check("shopfront", f"{backend}/api/shopfront/catalog"),
    ]

    results = [run_check(check, args.timeout) for check in checks]
    summary = {"passed": sum(results), "total": len(results)}
    print(json.dumps(summary, ensure_ascii=False))
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
