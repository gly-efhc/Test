#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "frontend" / "src"
PAGES = SRC / "pages"
PUBLIC = ROOT / "frontend" / "public"

ROUTE_RE = re.compile(r"href=[{]?['\"](/[^'\"}?#]+)")
PUSH_RE = re.compile(r"push\(['\"](/[^'\"?#]+)")

IGNORE_PREFIXES = (
    "/api/",
    "/_next/",
)

DYNAMIC_OK = {
    "/admin/products/[id]",
}


def route_to_page(route: str) -> Path:
    clean = route.strip().rstrip("/") or "/"
    if clean == "/":
        return PAGES / "index.tsx"
    return PAGES / clean.lstrip("/") / "index.tsx"


def route_exists(route: str) -> bool:
    clean = route.strip().rstrip("/") or "/"
    direct = PAGES / (clean.lstrip("/") + ".tsx")
    index = route_to_page(clean)
    public_asset = PUBLIC / clean.lstrip("/")
    return (
        direct.exists()
        or index.exists()
        or public_asset.exists()
        or clean in DYNAMIC_OK
    )


def main() -> int:
    routes: set[str] = set()
    for path in SRC.rglob("*.tsx"):
        text = path.read_text(encoding="utf-8")
        for pattern in (ROUTE_RE, PUSH_RE):
            for match in pattern.finditer(text):
                route = match.group(1)
                if route.startswith(IGNORE_PREFIXES):
                    continue
                if route.startswith("//"):
                    continue
                routes.add(route.rstrip("/") or "/")

    missing = sorted(
        route for route in routes if not route_exists(route)
    )
    if missing:
        print("Missing frontend routes:")
        for route in missing:
            print(f"- {route}")
        return 1
    print(f"OK frontend routes: {len(routes)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
