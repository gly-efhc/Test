param(
  [string]$LocalUrl = "http://host.docker.internal:3000",
  [string]$LocalBrowserUrl = "http://localhost:3000"
)

Write-Host "EFHC tunnel probe" -ForegroundColor Cyan
Write-Host "1) Local browser URL: $LocalBrowserUrl"
try {
  $local = Invoke-WebRequest $LocalBrowserUrl -UseBasicParsing
  Write-Host "OK local frontend: $($local.StatusCode)" -ForegroundColor Green
} catch {
  Write-Host "FAIL local frontend: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}

Write-Host "2) Docker container -> host frontend: $LocalUrl"
docker run --rm curlimages/curl:8.10.1 -I $LocalUrl
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "3) Docker container -> Cloudflare API visibility"
docker run --rm curlimages/curl:8.10.1 -I https://api.trycloudflare.com/tunnel
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "4) Quick tunnel attempt via cloudflared 2026.4.0"
docker run --rm -it cloudflare/cloudflared:2026.4.0 tunnel `
  --protocol http2 --url $LocalUrl
