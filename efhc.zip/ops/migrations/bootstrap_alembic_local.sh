#!/usr/bin/env bash
set -euo pipefail

python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt

echo "Set DATABASE_URL and SYNC_DATABASE_URL before running Alembic."
echo "Example:"
echo "  export DATABASE_URL=postgresql+asyncpg://user:pass@host/db"
echo "  export SYNC_DATABASE_URL=postgresql://user:pass@host/db"
echo

echo "Then run:"
echo "  alembic -c backend/alembic.ini upgrade head"
