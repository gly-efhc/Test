#!/usr/bin/env python3
"""Статический fail-closed guard release-контракта PostgreSQL 0001."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VERSIONS = ROOT / "backend/migrations/versions"
MIGRATION = VERSIONS / "0001_initial_release_schema.py"
PROOF = ROOT / "ops/db/postgres_release_proof.py"
OUTPUT = ROOT / "reports/generated/postgresql_0001_contract.json"


def audit() -> dict[str, object]:
    migration_files = sorted(
        path.name for path in VERSIONS.glob("*.py") if path.name != "__init__.py"
    )
    migration = MIGRATION.read_text(encoding="utf-8")
    proof = PROOF.read_text(encoding="utf-8")
    errors: list[str] = []

    if migration_files != ["0001_initial_release_schema.py"]:
        errors.append(f"active migrations: {migration_files}")
    required_migration_tokens = (
        'revision = "0001"',
        "down_revision = None",
        "Base.metadata.create_all",
        "_apply_existing_schema_repairs(conn)",
        "_validate_release_identity_schema(conn)",
        "expected 39 global owner FK",
    )
    for token in required_migration_tokens:
        if token not in migration:
            errors.append(f"0001 missing token: {token}")

    owner_fk_pattern = re.compile(
        r"REFERENCES\s+(?:efhc_core\.)?users\s*\(\s*tg_id\s*\)",
        re.IGNORECASE,
    )
    scan_roots = (ROOT / "backend/app", ROOT / "backend/migrations")
    legacy_owner_fk: list[str] = []
    for base in scan_roots:
        for path in sorted(base.rglob("*")):
            if path.suffix not in {".py", ".sql"} or not path.is_file():
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            if owner_fk_pattern.search(text):
                legacy_owner_fk.append(path.relative_to(ROOT).as_posix())
    if legacy_owner_fk:
        errors.append(f"legacy users.tg_id FK references: {legacy_owner_fk}")

    required_proof_tokens = (
        'default=Path("reports/generated")',
        '"table_count": 49',
        '"alembic_version": "0001"',
        "global_id=proof_global_id",
        "postgresql_0001_migration_proof.json",
        "postgresql_0001_backup_restore_proof.json",
    )
    for token in required_proof_tokens:
        if token not in proof:
            errors.append(f"postgres proof missing token: {token}")
    if "request_withdraw(\n                    session,\n                    tg_id=" in proof:
        errors.append("postgres proof invokes business withdraw by tg_id")

    result: dict[str, object] = {
        "schema": "EFHC_POSTGRESQL_0001_CONTRACT_V1",
        "version": "v173.18",
        "cycle": 1699,
        "active_migrations": migration_files,
        "legacy_owner_fk_references": legacy_owner_fk,
        "errors": errors,
        "passed": not errors,
    }
    return result


def main() -> int:
    result = audit()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
