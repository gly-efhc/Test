#!/usr/bin/env python3
"""Run fail-closed PostgreSQL migration and transaction proof."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import importlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from contextlib import suppress
from dataclasses import asdict, dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any
from unittest.mock import patch
from urllib.parse import urlsplit, urlunsplit

import psycopg
from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    async_sessionmaker,
    create_async_engine,
)

_DATABASE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
_PROOF_TG_ID = 15_660_001
_PROOF_IDEMPOTENCY_KEY = "postgres-release-proof-rollback"
_MARKER_USERNAME = "postgres_release_proof"


@dataclass(frozen=True)
class CommandResult:
    command: str
    exit_code: int
    duration_seconds: float
    stdout_tail: str
    stderr_tail: str


def _utc_now() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _database_url(base_url: str, database: str) -> str:
    if not _DATABASE_RE.fullmatch(database):
        raise ValueError(f"unsafe database name: {database!r}")
    parts = urlsplit(base_url)
    return urlunsplit(
        (parts.scheme, parts.netloc, f"/{database}", "", "")
    )


def _psycopg_url(url: str) -> str:
    parts = urlsplit(url)
    scheme = parts.scheme
    if scheme in {
        "postgres",
        "postgresql+psycopg",
        "postgresql+asyncpg",
    }:
        scheme = "postgresql"
    return urlunsplit(
        (scheme, parts.netloc, parts.path, parts.query, "")
    )


def _async_url(url: str) -> str:
    parts = urlsplit(url)
    scheme = parts.scheme
    if scheme in {"postgres", "postgresql", "postgresql+psycopg"}:
        scheme = "postgresql+asyncpg"
    return urlunsplit(
        (scheme, parts.netloc, parts.path, parts.query, "")
    )


def _redacted_url(url: str) -> str:
    parts = urlsplit(url)
    host = parts.hostname or ""
    if parts.port:
        host = f"{host}:{parts.port}"
    user = parts.username or ""
    netloc = f"{user}@{host}" if user else host
    return urlunsplit((parts.scheme, netloc, parts.path, "", ""))


def _tail(value: str, limit: int = 4000) -> str:
    return value[-limit:]


def _run(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
    display: str | None = None,
) -> CommandResult:
    started = time.monotonic()
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    result = CommandResult(
        command=display or " ".join(command),
        exit_code=int(completed.returncode),
        duration_seconds=round(time.monotonic() - started, 3),
        stdout_tail=_tail(completed.stdout),
        stderr_tail=_tail(completed.stderr),
    )
    if result.exit_code != 0:
        raise RuntimeError(
            f"command failed ({result.exit_code}): {result.command}\n"
            f"{result.stderr_tail}"
        )
    return result


def _drop_create_database(admin_url: str, database: str) -> None:
    if not _DATABASE_RE.fullmatch(database):
        raise ValueError(f"unsafe database name: {database!r}")
    with psycopg.connect(
        _psycopg_url(admin_url), autocommit=True
    ) as conn:
        conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            "WHERE datname = %s AND pid <> pg_backend_pid()",
            (database,),
        )
        conn.execute(f'DROP DATABASE IF EXISTS "{database}"')
        conn.execute(f'CREATE DATABASE "{database}"')


def _migration_snapshot(database_url: str) -> dict[str, Any]:
    with psycopg.connect(_psycopg_url(database_url)) as conn:
        server = conn.execute(
            "SELECT current_setting('server_version'), "
            "current_database()"
        ).fetchone()
        schemas = [
            row[0]
            for row in conn.execute(
                "SELECT nspname FROM pg_namespace "
                "WHERE nspname LIKE 'efhc_%' ORDER BY nspname"
            ).fetchall()
        ]
        table_count = conn.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema IN ('efhc_core', 'efhc_admin')"
        ).fetchone()[0]
        alembic_version = conn.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        ).fetchone()[0]
        transaction_ddl = conn.execute(
            "SHOW default_transaction_read_only"
        ).fetchone()[0]
    return {
        "server_version": str(server[0]),
        "database": str(server[1]),
        "schemas": schemas,
        "table_count": int(table_count),
        "alembic_version": str(alembic_version),
        "default_transaction_read_only": str(transaction_ddl),
    }


async def _service_rollback_proof(
    database_url: str, root: Path
) -> dict[str, Any]:
    backend = root / "backend"
    if str(backend) not in sys.path:
        sys.path.insert(0, str(backend))

    os.environ["DATABASE_URL"] = _psycopg_url(database_url)
    os.environ["SYNC_DATABASE_URL"] = _psycopg_url(database_url)
    os.environ["ASYNC_DATABASE_URL"] = _async_url(database_url)
    os.environ["BANK_EFHC"] = "900100"
    os.environ["ENV"] = "test"

    from app.core import config_core

    config_core.get_settings.cache_clear()

    import app.services.transactions_service as transactions_service
    import app.services.withdraw_service as withdraw_service

    transactions_service = importlib.reload(transactions_service)
    withdraw_service = importlib.reload(withdraw_service)

    engine = create_async_engine(_async_url(database_url), future=True)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async with session_factory() as session:
        await session.execute(
            text(
                "DELETE FROM efhc_core.withdraw_requests "
                "WHERE tg_id = :tg"
            ),
            {"tg": _PROOF_TG_ID},
        )
        await session.execute(
            text(
                "DELETE FROM efhc_core.efhc_transfers_log "
                "WHERE tg_id = :tg OR idempotency_key LIKE :prefix"
            ),
            {
                "tg": _PROOF_TG_ID,
                "prefix": f"%{_PROOF_IDEMPOTENCY_KEY}%",
            },
        )
        await session.execute(
            text("DELETE FROM efhc_core.users WHERE tg_id = :tg"),
            {"tg": _PROOF_TG_ID},
        )
        await session.execute(
            text(
                "INSERT INTO efhc_core.users ("
                "tg_id, username, is_vip, is_active, ton_wallet, "
                "main_balance, bonus_balance, total_generated_kwh, "
                "exchanged_kwh_total, created_at, updated_at"
                ") VALUES ("
                ":tg, :username, false, true, :wallet, "
                "'100.00000000', '0.00000000', '0.00000000', "
                "'0.00000000', now(), now()"
                ")"
            ),
            {
                "tg": _PROOF_TG_ID,
                "username": _MARKER_USERNAME,
                "wallet": "proof-wallet-1566",
            },
        )
        await session.commit()

    original = withdraw_service.debit_user_to_bank_nocommit

    async def _fail_after_debit(*args: Any, **kwargs: Any) -> Any:
        await original(*args, **kwargs)
        raise RuntimeError(
            "injected failure after balance and log writes"
        )

    raised = False
    raised_type = ""
    async with session_factory() as session:
        with patch.object(
            withdraw_service,
            "debit_user_to_bank_nocommit",
            _fail_after_debit,
        ):
            try:
                await withdraw_service.request_withdraw(
                    session,
                    tg_id=_PROOF_TG_ID,
                    amount=Decimal("10.00000000"),
                    idempotency_key=_PROOF_IDEMPOTENCY_KEY,
                )
            except RuntimeError as exc:
                raised = True
                raised_type = type(exc).__name__

    async with session_factory() as session:
        balance = (
            await session.execute(
                text(
                    "SELECT main_balance FROM efhc_core.users "
                    "WHERE tg_id = :tg"
                ),
                {"tg": _PROOF_TG_ID},
            )
        ).scalar_one()
        request_count = (
            await session.execute(
                text(
                    "SELECT count(*) FROM efhc_core.withdraw_requests "
                    "WHERE idempotency_key = :idk"
                ),
                {"idk": _PROOF_IDEMPOTENCY_KEY},
            )
        ).scalar_one()
        log_count = (
            await session.execute(
                text(
                    "SELECT count(*) FROM efhc_core.efhc_transfers_log "
                    "WHERE idempotency_key IN (:hold, :mirror)"
                ),
                {
                    "hold": f"{_PROOF_IDEMPOTENCY_KEY}:hold",
                    "mirror": f"mirror:{_PROOF_IDEMPOTENCY_KEY}:hold",
                },
            )
        ).scalar_one()

    await engine.dispose()

    checks = {
        "exception_raised": raised,
        "balance_restored": Decimal(str(balance))
        == Decimal("100.00000000"),
        "withdraw_row_rolled_back": int(request_count) == 0,
        "transfer_logs_rolled_back": int(log_count) == 0,
    }
    if not all(checks.values()):
        raise RuntimeError(f"service rollback proof failed: {checks}")
    return {
        "status": "VERIFIED",
        "injected_failure": (
            "after debit, bank update, and transfer log insert"
        ),
        "raised_type": raised_type,
        "checks": checks,
        "observed": {
            "main_balance": str(balance),
            "withdraw_request_count": int(request_count),
            "transfer_log_count": int(log_count),
        },
    }


def _catalog_payload(database_url: str) -> dict[str, Any]:
    with psycopg.connect(_psycopg_url(database_url)) as conn:
        columns = conn.execute(
            """
            SELECT table_schema, table_name, ordinal_position,
                   column_name,
                   data_type, udt_name, is_nullable,
                   COALESCE(column_default, '')
            FROM information_schema.columns
            WHERE table_schema IN ('efhc_core', 'efhc_admin')
            ORDER BY table_schema, table_name, ordinal_position
            """
        ).fetchall()
        constraints = conn.execute(
            """
            SELECT ns.nspname, cls.relname, con.conname, con.contype,
                   pg_get_constraintdef(con.oid, true)
            FROM pg_constraint con
            JOIN pg_class cls ON cls.oid = con.conrelid
            JOIN pg_namespace ns ON ns.oid = cls.relnamespace
            WHERE ns.nspname IN ('efhc_core', 'efhc_admin')
            ORDER BY ns.nspname, cls.relname, con.conname
            """
        ).fetchall()
        indexes = conn.execute(
            """
            SELECT schemaname, tablename, indexname, indexdef
            FROM pg_indexes
            WHERE schemaname IN ('efhc_core', 'efhc_admin')
            ORDER BY schemaname, tablename, indexname
            """
        ).fetchall()
        tables = conn.execute(
            """
            SELECT table_schema, table_name
            FROM information_schema.tables
            WHERE table_schema IN ('efhc_core', 'efhc_admin')
            ORDER BY table_schema, table_name
            """
        ).fetchall()
        version = conn.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        ).fetchone()[0]
        marker = conn.execute(
            """
            SELECT tg_id, username, main_balance, bonus_balance,
                   ton_wallet
            FROM efhc_core.users WHERE tg_id = %s
            """,
            (_PROOF_TG_ID,),
        ).fetchone()

    def rows(values: list[Any]) -> list[list[str]]:
        return [[str(item) for item in row] for row in values]

    def constraint_rows(values: list[Any]) -> list[list[str]]:
        normalized: list[list[str]] = []
        for row in values:
            fields = [str(item) for item in row]
            definition = fields[-1]
            definition = definition.replace(
                "::character varying::text", "::character varying"
            )
            definition = definition.replace("::text[]", "")
            fields[-1] = definition
            normalized.append(fields)
        return normalized

    return {
        "tables": rows(tables),
        "columns": rows(columns),
        "constraints": constraint_rows(constraints),
        "indexes": rows(indexes),
        "alembic_version": str(version),
        "marker": [str(item) for item in marker] if marker else None,
    }


def _fingerprint(payload: dict[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _restored_rollback_proof(database_url: str) -> dict[str, Any]:
    expected = Decimal("100.00000000")
    with psycopg.connect(_psycopg_url(database_url)) as conn:
        try:
            with conn.transaction():
                conn.execute(
                    "UPDATE efhc_core.users SET main_balance = 77 "
                    "WHERE tg_id = %s",
                    (_PROOF_TG_ID,),
                )
                raise RuntimeError("restore rollback probe")
        except RuntimeError:
            pass
        observed = conn.execute(
            "SELECT main_balance FROM efhc_core.users WHERE tg_id = %s",
            (_PROOF_TG_ID,),
        ).fetchone()[0]
    verified = Decimal(str(observed)) == expected
    if not verified:
        raise RuntimeError(
            "restored database transaction rollback failed"
        )
    return {
        "status": "VERIFIED",
        "expected_balance": str(expected),
        "observed_balance": str(observed),
    }


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--admin-url", required=True)
    parser.add_argument("--database", default="efhc_postgres_proof")
    parser.add_argument(
        "--restore-database", default="efhc_postgres_restore"
    )
    parser.add_argument("--pg-dump", type=Path, required=True)
    parser.add_argument("--pg-restore", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("reports/generated"),
    )
    args = parser.parse_args()

    root = args.root.resolve()
    output_dir = (root / args.output_dir).resolve()
    source_url = _database_url(args.admin_url, args.database)
    restore_url = _database_url(args.admin_url, args.restore_database)
    started_at = _utc_now()
    command_results: list[CommandResult] = []

    _drop_create_database(args.admin_url, args.database)
    migration_env = os.environ.copy()
    migration_env.update(
        {
            "DATABASE_URL": _psycopg_url(source_url),
            "SYNC_DATABASE_URL": _psycopg_url(source_url),
            "ASYNC_DATABASE_URL": _async_url(source_url),
            "ENV": "test",
            "PYTHONPATH": str(root / "backend"),
        }
    )
    command_results.append(
        _run(
            [
                sys.executable,
                "-m",
                "alembic",
                "-c",
                "alembic.ini",
                "upgrade",
                "head",
            ],
            cwd=root / "backend",
            env=migration_env,
            display=(
                "python -m alembic -c backend/alembic.ini upgrade head"
            ),
        )
    )
    migration = _migration_snapshot(source_url)
    expected_migration = {
        "schemas": ["efhc_admin", "efhc_core"],
        "table_count": 48,
        "alembic_version": "0002",
    }
    migration_checks = {
        key: migration[key] == value
        for key, value in expected_migration.items()
    }
    if not all(migration_checks.values()):
        raise RuntimeError(
            f"migration proof failed: {migration_checks}"
        )

    rollback = asyncio.run(_service_rollback_proof(source_url, root))
    source_catalog = _catalog_payload(source_url)
    source_fingerprint = _fingerprint(source_catalog)

    dump_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix="efhc-postgres-proof-",
            suffix=".dump",
            delete=False,
        ) as handle:
            dump_path = Path(handle.name)
        command_results.append(
            _run(
                [
                    str(args.pg_dump),
                    "--format=custom",
                    "--no-owner",
                    "--no-acl",
                    "--file",
                    str(dump_path),
                    _psycopg_url(source_url),
                ],
                cwd=root,
                display="pg_dump --format=custom --no-owner --no-acl "
                "<source_database>",
            )
        )
        dump_sha256 = _sha256(dump_path)
        dump_size = dump_path.stat().st_size

        _drop_create_database(args.admin_url, args.restore_database)
        command_results.append(
            _run(
                [
                    str(args.pg_restore),
                    "--no-owner",
                    "--no-acl",
                    "--exit-on-error",
                    "--dbname",
                    _psycopg_url(restore_url),
                    str(dump_path),
                ],
                cwd=root,
                display=(
                    "pg_restore --no-owner --no-acl "
                    "--exit-on-error "
                    "<restore_database> <dump>"
                ),
            )
        )
        restore_catalog = _catalog_payload(restore_url)
        restore_fingerprint = _fingerprint(restore_catalog)
        fingerprint_match = source_fingerprint == restore_fingerprint
        if not fingerprint_match:
            raise RuntimeError(
                "source/restore catalog fingerprints differ"
            )
        restored_rollback = _restored_rollback_proof(restore_url)
    finally:
        if dump_path is not None:
            with suppress(FileNotFoundError):
                dump_path.unlink()

    migration_report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": "VERIFIED",
        "source_database": _redacted_url(source_url),
        "migration": migration,
        "expected": expected_migration,
        "checks": migration_checks,
        "command": asdict(command_results[0]),
    }
    transaction_report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": "VERIFIED",
        "database_engine": "PostgreSQL",
        "source_database": _redacted_url(source_url),
        "business_service_rollback": rollback,
    }
    backup_report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": "VERIFIED",
        "source_database": _redacted_url(source_url),
        "restore_database": _redacted_url(restore_url),
        "dump": {
            "format": "custom",
            "sha256": dump_sha256,
            "size_bytes": int(dump_size),
            "temporary_dump_deleted": bool(
                dump_path is not None and not dump_path.exists()
            ),
        },
        "catalog": {
            "source_fingerprint": source_fingerprint,
            "restore_fingerprint": restore_fingerprint,
            "match": fingerprint_match,
            "tables": len(source_catalog["tables"]),
            "columns": len(source_catalog["columns"]),
            "constraints": len(source_catalog["constraints"]),
            "indexes": len(source_catalog["indexes"]),
            "marker_restored": restore_catalog["marker"]
            == source_catalog["marker"],
        },
        "restored_database_rollback": restored_rollback,
        "commands": [asdict(item) for item in command_results[1:]],
    }
    summary = {
        "schema_version": 1,
        "started_at": started_at,
        "finished_at": _utc_now(),
        "status": "VERIFIED",
        "migration": migration_report["status"],
        "business_service_rollback": transaction_report["status"],
        "backup_restore": backup_report["status"],
        "limits": [
            (
                "Local isolated PostgreSQL proof; not production "
                "database proof."
            ),
            "No live Telegram, TON, or USDT transaction is asserted.",
        ],
    }

    _write_json(
        output_dir / "postgresql_migration_v171_42.json",
        migration_report,
    )
    _write_json(
        output_dir / "postgresql_transaction_proof_v171_42.json",
        transaction_report,
    )
    _write_json(
        output_dir / "postgresql_backup_restore_v171_42.json",
        backup_report,
    )
    _write_json(
        output_dir / "postgresql_runtime_summary_v171_42.json",
        summary,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
