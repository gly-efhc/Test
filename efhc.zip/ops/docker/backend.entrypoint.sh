#!/usr/bin/env bash
set -euo pipefail

cd /app

if [[ "${DOCKER_WAIT_FOR_DB:-1}" == "1" ]]; then
  python - <<'PY'
import os
import socket
import sys
import time
from urllib.parse import urlparse

url = os.getenv("SYNC_DATABASE_URL") or os.getenv("DATABASE_URL")
if not url:
    print("ERROR: SYNC_DATABASE_URL or DATABASE_URL is required")
    sys.exit(1)

parsed = urlparse(url)
host = parsed.hostname or "db"
port = parsed.port or 5432
deadline = time.time() + int(os.getenv("DOCKER_DB_WAIT_SEC", "60"))

while True:
    try:
        with socket.create_connection((host, port), timeout=2):
            print(f"DB is reachable: {host}:{port}")
            break
    except OSError:
        if time.time() >= deadline:
            print(f"ERROR: DB is not reachable: {host}:{port}")
            sys.exit(1)
        time.sleep(1)
PY
fi

if [[ "${DOCKER_RUN_MIGRATIONS:-0}" == "1" ]]; then
  cd /app/backend
  alembic -c alembic.ini upgrade head
  cd /app
fi

if [[ "$#" -gt 0 ]]; then
  exec "$@"
fi

exec python backend/run.py
