#!/usr/bin/env python3
"""Проверить доступность среды PostgreSQL для указанного HEAD."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
from datetime import UTC, datetime
from pathlib import Path


def build_report(
    *,
    cycle: int,
    source_head: str,
) -> dict[str, object]:
    """Вернуть русскоязычный отчёт доступности среды."""

    if cycle < 1:
        raise ValueError("Номер цикла должен быть положительным")
    if not source_head.strip():
        raise ValueError("Исходный HEAD не может быть пустым")

    commands = {
        name: shutil.which(name) is not None
        for name in (
            "postgres",
            "initdb",
            "pg_ctl",
            "psql",
            "docker",
            "podman",
        )
    }
    modules = {
        name: importlib.util.find_spec(name) is not None
        for name in ("psycopg2", "psycopg", "asyncpg", "pg8000")
    }
    url_present = any(
        os.getenv(name)
        for name in (
            "DATABASE_URL",
            "SYNC_DATABASE_URL",
            "PSYCOPG_URL",
        )
    )
    ready = bool(
        url_present
        and (modules["psycopg2"] or modules["psycopg"])
    )
    return {
        "схема_отчёта": "EFHC_ПРОВЕРКА_СРЕДЫ_POSTGRESQL_V1",
        "цикл": cycle,
        "исходный_архив": source_head,
        "время_utc": datetime.now(UTC).isoformat(),
        "реквизиты_базы_заданы": url_present,
        "команды": commands,
        "модули_python": modules,
        "готово_к_подключению": ready,
        "статус": "ГОТОВО" if ready else "БЛОКИРОВАНО_СРЕДОЙ",
        "пояснение": (
            "Среда готова к read-only подключению"
            if ready
            else (
                "Нет PostgreSQL URL и доступного синхронного драйвера; "
                "локальный PostgreSQL Server также отсутствует"
            )
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cycle", type=int, required=True)
    parser.add_argument("--source-head", required=True)
    args = parser.parse_args()
    report = build_report(
        cycle=args.cycle,
        source_head=args.source_head,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["готово_к_подключению"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
