"""Fail-closed guard действующего identity registry."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path

from app.identity.identity_registry import (
    HISTORICAL_SCOPES,
    IDENTITY_NAME_POLICIES,
    build_identity_registry,
)

FIXTURE = "contracts/identity/identity_registry_v2.json"
RETIRED_ACTIVE_FILES = (
    "backend/app/identity/legacy_alias.py",
    "backend/app/identity/legacy_user_id.py",
    "backend/app/identity/user_id_backfill.py",
    "backend/app/identity/user_id_expand.py",
)


def _mapped_user_columns(root: Path) -> set[str]:
    tree = ast.parse(
        (root / "backend/app/models/user_models.py").read_text(
            encoding="utf-8"
        )
    )
    columns: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.AnnAssign):
            continue
        if not isinstance(node.target, ast.Name):
            continue
        call = node.value
        if (
            isinstance(call, ast.Call)
            and isinstance(call.func, ast.Name)
            and call.func.id == "mapped_column"
        ):
            columns.add(node.target.id)
    return columns


def _retired_imports(root: Path) -> list[dict[str, object]]:
    pattern = re.compile(
        r"app\.identity\.(?:legacy_alias|legacy_user_id|"
        r"user_id_backfill|user_id_expand)"
    )
    findings: list[dict[str, object]] = []
    for base_name in ("backend/app", "api", "frontend/src", "ops"):
        base = root / base_name
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.py")):
            relative = path.relative_to(root).as_posix()
            for number, line in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines(),
                1,
            ):
                if pattern.search(line):
                    findings.append(
                        {
                            "файл": relative,
                            "строка": number,
                            "причина": "retired_identity_import",
                        }
                    )
    return findings


def проверить(root: Path) -> dict[str, object]:
    """Проверить current registry и отсутствие active legacy aliases."""

    root = root.resolve()
    violations: list[dict[str, object]] = []
    expected = build_identity_registry()
    fixture_path = root / FIXTURE
    if not fixture_path.is_file():
        violations.append({"причина": "identity_registry_fixture_missing"})
    else:
        fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
        if fixture != expected:
            violations.append({"причина": "identity_registry_fixture_drift"})

    policies = {policy.name: policy for policy in IDENTITY_NAME_POLICIES}
    if set(policies) != {"global_id", "id", "tg_id"}:
        violations.append(
            {"причина": "identity_name_set_invalid", "имена": sorted(policies)}
        )
    if not policies["global_id"].owner_allowed:
        violations.append({"причина": "global_id_not_owner"})
    if policies["id"].owner_allowed or policies["tg_id"].owner_allowed:
        violations.append({"причина": "non_global_owner_allowed"})

    columns = _mapped_user_columns(root)
    if not {"id", "global_id", "tg_id"}.issubset(columns):
        violations.append(
            {"причина": "required_user_columns_missing", "колонки": sorted(columns)}
        )
    if "user_id" in columns:
        violations.append({"причина": "legacy_user_id_column_present"})

    for relative in RETIRED_ACTIVE_FILES:
        if (root / relative).exists():
            violations.append(
                {"причина": "retired_identity_file_active", "файл": relative}
            )
    violations.extend(_retired_imports(root))

    for scope in HISTORICAL_SCOPES:
        if scope.may_define_current_runtime:
            violations.append(
                {"причина": "historical_scope_controls_runtime", "путь": scope.path_prefix}
            )

    return {
        "схема_отчёта": "EFHC_IDENTITY_REGISTRY_GUARD_V2",
        "цикл": 1702,
        "версия": "v173.27",
        "пройдено": not violations,
        "нарушения": violations,
        "зарегистрировано_имён": len(IDENTITY_NAME_POLICIES),
        "active_compatibility_aliases": 0,
        "business_owner_tg_id": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Проверка identity registry.")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root)
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
