"""Verify UserId value-type adoption boundaries."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA = "EFHC_USER_ID_VALUE_TYPE_PATCH_BOUNDARY_V1"
SKIP_PARTS = {
    ".git",
    ".next",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    "node_modules",
}
PROTECTED_SUFFIXES = {
    ".ini",
    ".js",
    ".jsx",
    ".mako",
    ".py",
    ".sql",
    ".ts",
    ".tsx",
}
LEGACY_CANON_PHRASES = (
    "Единственный идентификатор пользователя в проекте: tg_id",
    "tg_id единственный идентификатор пользователя",
    "tg_id единственный идентификатор.",
)


class _StripDocstrings(ast.NodeTransformer):
    @staticmethod
    def _remove(node: ast.AST) -> ast.AST:
        body = getattr(node, "body", None)
        if (
            isinstance(body, list)
            and body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            node.body = body[1:]  # type: ignore[attr-defined]
        return node

    def visit_Module(self, node: ast.Module) -> ast.AST:  # noqa: N802
        return self.generic_visit(self._remove(node))

    def visit_ClassDef(  # noqa: N802
        self,
        node: ast.ClassDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))

    def visit_FunctionDef(
        self,
        node: ast.FunctionDef,
    ) -> ast.AST:  # noqa: N802
        return self.generic_visit(self._remove(node))

    def visit_AsyncFunctionDef(
        self,
        node: ast.AsyncFunctionDef,
    ) -> ast.AST:  # noqa: N802
        return self.generic_visit(self._remove(node))


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _semantic_sha256(path: Path, kind: str) -> str:
    if kind == "python_ast_without_docstrings":
        tree = ast.parse(path.read_text(encoding="utf-8"))
        tree = _StripDocstrings().visit(tree)
        ast.fix_missing_locations(tree)
        payload = ast.dump(
            tree,
            annotate_fields=True,
            include_attributes=False,
        ).encode("utf-8")
        return _sha256(payload)
    if kind == "exact_bytes":
        return _sha256(path.read_bytes())
    raise ValueError(f"unsupported boundary hash kind: {kind}")


def _protected_files(root: Path, roots: list[str]) -> set[str]:
    result: set[str] = set()
    for relative_root in roots:
        base = root / relative_root
        paths = [base] if base.is_file() else sorted(base.rglob("*"))
        for path in paths:
            if not path.is_file():
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            if path.suffix not in PROTECTED_SUFFIXES:
                continue
            result.add(path.relative_to(root).as_posix())
    return result


def _runtime_identity_imports(root: Path) -> list[str]:
    offenders: list[str] = []
    base = root / "backend/app"
    for path in sorted(base.rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        if relative.startswith("backend/app/identity/"):
            continue
        if set(path.parts) & SKIP_PARTS:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if module.startswith("app.identity"):
                    offenders.append(f"{relative}:{node.lineno}")
            elif isinstance(node, ast.Import):
                if any(
                    alias.name.startswith("app.identity")
                    for alias in node.names
                ):
                    offenders.append(f"{relative}:{node.lineno}")
    return offenders


def _legacy_canon_offenders(root: Path) -> list[str]:
    offenders: list[str] = []
    base = root / "backend/app"
    for path in sorted(base.rglob("*.py")):
        if set(path.parts) & SKIP_PARTS:
            continue
        relative = path.relative_to(root).as_posix()
        for number, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            start=1,
        ):
            if any(token in line for token in LEGACY_CANON_PHRASES):
                offenders.append(
                    f"{relative}:{number}:{line.strip()}"
                )
    return offenders


def check(root: Path, manifest_path: Path) -> dict[str, Any]:
    root = root.resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError(
            "unsupported UserId value-type boundary schema"
        )

    errors: list[str] = []
    expected = {
        item.get("path") or "/".join(item["path_parts"]): item
        for item in data["entries"]
    }
    actual = _protected_files(root, data["protected_roots"])

    missing = sorted(set(expected) - actual)
    unexpected = sorted(actual - set(expected))
    changed: list[str] = []
    for relative, item in expected.items():
        path = root / relative
        if not path.is_file():
            continue
        actual_hash = _semantic_sha256(path, item["kind"])
        expected_hash = item.get("sha256") or "".join(
            item["sha256_parts"]
        )
        if actual_hash != expected_hash:
            changed.append(relative)

    imports = _runtime_identity_imports(root)
    legacy_phrases = _legacy_canon_offenders(root)

    if missing:
        errors.append(f"protected files missing: {missing}")
    if unexpected:
        errors.append(f"new protected runtime files: {unexpected}")
    if changed:
        errors.append(f"protected runtime semantics changed: {changed}")
    if imports:
        errors.append(
            "UserId contract wired into runtime before adoption gate: "
            f"{imports}"
        )
    if legacy_phrases:
        errors.append(
            "active legacy identity canon remains in runtime docs: "
            f"{legacy_phrases}"
        )

    return {
        "schema": "EFHC_USER_ID_VALUE_TYPE_BOUNDARY_RESULT_V1",
        "cycle": data["cycle"],
        "source_head": data["source_head"],
        "target_head": data["target_head"],
        "protected_file_count": len(expected),
        "missing": missing,
        "unexpected": unexpected,
        "semantic_changes": changed,
        "premature_runtime_imports": imports,
        "legacy_canon_offenders": legacy_phrases,
        "passed": not errors,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path(
            "ops/identity/user_id_value_type_patch_boundary.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root, args.manifest)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
