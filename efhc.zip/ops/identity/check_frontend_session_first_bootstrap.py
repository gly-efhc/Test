#!/usr/bin/env python3
"""Причинный static guard frontend session-first foundation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(root: Path, relative: str) -> str:
    return (root / relative).read_text(encoding="utf-8")


def проверить(root: Path = ROOT) -> dict[str, object]:
    """Проверить архитектурные границы текущего frontend scope."""

    root = root.resolve()
    required = (
        "frontend/src/auth/AuthSessionProvider.tsx",
        "frontend/src/hooks/auth/useSessionRestore.ts",
        "frontend/src/hooks/auth/useAuthState.ts",
        "frontend/src/hooks/auth/useProviderState.ts",
        "frontend/src/hooks/auth/useLogout.ts",
        "frontend/src/hooks/auth/useTelegramLogin.ts",
        "frontend/src/hooks/auth/useTonLogin.ts",
        "frontend/src/lib/auth-session-client.ts",
        "frontend/src/lib/telegram-auth.ts",
        "frontend/src/services/authSession.service.ts",
    )
    missing = [item for item in required if not (root / item).is_file()]

    provider = _read(root, "frontend/src/auth/AuthSessionProvider.tsx")
    transport = _read(root, "frontend/src/lib/auth-session.ts")
    client = _read(root, "frontend/src/lib/auth-session-client.ts")
    telegram = _read(root, "frontend/src/lib/telegram-auth.ts")
    auth_service = _read(
        root, "frontend/src/services/authSession.service.ts"
    )
    api = _read(root, "frontend/src/lib/api.ts")
    query_keys = _read(root, "frontend/src/queries/queryKeys.ts")
    app = _read(root, "frontend/src/pages/_app.tsx")

    violations: list[str] = []
    if missing:
        violations.append("missing:" + ",".join(missing))

    common_state_forbidden = (
        "tg_id",
        "provider_subject",
        "wallet_address",
        "localStorage",
    )
    for token in common_state_forbidden:
        if token in provider:
            violations.append(f"provider_state_forbidden:{token}")

    if "sessionStorage" not in transport:
        violations.append("session_storage_missing")
    if "localStorage" in transport:
        violations.append("session_local_storage_forbidden")
    if "parseGlobalId" not in transport:
        violations.append("global_id_parser_missing")

    if "acceptIssuedAuthSession" not in client:
        violations.append("common_session_accept_missing")
    for marker in (
        "requestAuthSessionContext",
        "requestAuthLogout",
    ):
        if marker not in client:
            violations.append(
                f"session_service_boundary_missing:{marker}"
            )

    if "acceptIssuedAuthSession" not in telegram:
        violations.append(
            "telegram_exchange_missing:acceptIssuedAuthSession"
        )
    if "requestTelegramSession" not in telegram:
        violations.append("telegram_service_boundary_missing")
    for marker in (
        '"/auth/session"',
        '"/auth/logout"',
        '"/auth/telegram/session"',
        '"X-Telegram-Init-Data"',
    ):
        if marker not in auth_service:
            violations.append(f"auth_service_exchange_missing:{marker}")
    if "sessionStorage" in telegram or "localStorage" in telegram:
        violations.append(
            "telegram_raw_or_session_storage_direct_access"
        )

    for marker in (
        "getAuthAuthorizationHeader",
        "res.status === 401",
        "clearAuthSession",
    ):
        if marker not in api:
            violations.append(f"api_transport_missing:{marker}")
    for forbidden in (
        "legacyTelegramFallback",
        "recordLegacyTelegramFallback",
        "X-Telegram-Init-Data",
    ):
        if forbidden in api:
            violations.append(
                f"api_transport_fallback_forbidden:{forbidden}"
            )

    for marker in (
        "import type { GlobalId }",
        'session: ["auth", "session"]',
        "owner: (globalId: GlobalId)",
        "provider: (globalId: GlobalId)",
        "resource: (globalId: GlobalId",
    ):
        if marker not in query_keys:
            violations.append(f"query_key_contract_missing:{marker}")

    if "<AuthSessionProvider>" not in app:
        violations.append("app_provider_mount_missing")
    for marker in (
        "telegramBootstrapStarted",
        "useAuthOwnerGlobalId",
    ):
        if marker not in provider:
            violations.append(f"session_full_switch_missing:{marker}")

    versions = root / "backend/migrations/versions"
    migration_files = sorted(
        path.name for path in versions.glob("*.py")
    )
    expected_migrations = [
        "0001_initial_release_schema.py",
    ]
    if migration_files != expected_migrations:
        violations.append("release_migration_lineage_invalid")
    else:
        initial = _read(
            root,
            "backend/migrations/versions/"
            "0001_initial_release_schema.py",
        )
        if 'revision = "0001"' not in initial:
            violations.append("release_base_revision_invalid")
        if "down_revision = None" not in initial:
            violations.append("release_baseline_revision_invalid")

    openapi = json.loads(
        (root / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    paths = openapi.get("paths", {})
    operation_count = sum(
        1
        for item in paths.values()
        if isinstance(item, dict)
        for method in item
        if method.lower() in {
            "get",
            "post",
            "put",
            "patch",
            "delete",
            "options",
            "head",
            "trace",
        }
    )

    return {
        "схема": "EFHC_FRONTEND_SESSION_FIRST_STATIC_GUARD_V1",
        "успех": not violations,
        "нарушения": violations,
        "обязательных_файлов": len(required),
        "отсутствующих_файлов": len(missing),
        "alembic_head": "0001",
        "migration_files": migration_files,
        "openapi_paths": len(paths),
        "openapi_operations": operation_count,
        "session_storage": "sessionStorage",
        "legacy_telegram_fallback": "закрыт_для_business_api",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = проверить(args.root)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if result["успех"] else "FAIL")
        for item in result["нарушения"]:
            print(item)
    return 0 if result["успех"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
