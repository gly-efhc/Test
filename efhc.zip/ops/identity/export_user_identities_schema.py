#!/usr/bin/env python3
"""Экспортировать канонический schema-contract ``user_identities``."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from app.identity.user_identities_storage_contract import (
    USER_IDENTITY_CONSTRAINTS,
    USER_IDENTITY_DEFAULT_TENANT,
    UserIdentityStatus,
    build_user_identities_storage_contract,
)

ROOT = Path(__file__).resolve().parents[2]
CI_FILES = (
    "ci.yml",
    ".github/workflows/canon.yml",
    ".github/workflows/frontend-visual.yml",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_schema_contract(root: Path = ROOT) -> dict[str, Any]:
    """Собрать JSON contract из constants и immutable CI files."""

    storage = build_user_identities_storage_contract()
    return {
        "схема": "EFHC_PROVIDER_IDENTITY_SCHEMA_V2",
        "цикл": 1691,
        "статус": "ACTIVE_RELEASE_SCHEMA",
        "alembic": {
            "предыдущая_revision": None,
            "целевая_revision": "0001",
            "migration": (
                "backend/migrations/versions/"
                "0001_initial_release_schema.py"
            ),
            "класс": "INITIAL_RELEASE",
            "historical_backfill": False,
            "runtime_read_switch": False,
            "financial_ownership_switch": False,
        },
        "таблица": {
            "schema": "efhc_core",
            "name": "user_identities",
            "orm_class": "UserIdentity",
            "orm_file": "backend/app/models/identity_models.py",
            "поля": list(storage["колонки"]),
            "provider_tenant_default": USER_IDENTITY_DEFAULT_TENANT,
            "statuses": [item.value for item in UserIdentityStatus],
        },
        "constraints": {
            "primary_key": USER_IDENTITY_CONSTRAINTS["primary_key"],
            "foreign_key": USER_IDENTITY_CONSTRAINTS["foreign_key"],
            "foreign_key_target": "efhc_core.users.global_id",
            "unique_provider_subject": USER_IDENTITY_CONSTRAINTS[
                "unique_subject"
            ],
            "global_id_range": USER_IDENTITY_CONSTRAINTS[
                "global_id_range"
            ],
            "provider_format": USER_IDENTITY_CONSTRAINTS[
                "provider_format"
            ],
            "provider_not_mock": USER_IDENTITY_CONSTRAINTS[
                "provider_not_mock"
            ],
            "tenant_length": USER_IDENTITY_CONSTRAINTS[
                "tenant_length"
            ],
            "subject_length": USER_IDENTITY_CONSTRAINTS[
                "subject_length"
            ],
            "status": USER_IDENTITY_CONSTRAINTS["status"],
            "verified_at": USER_IDENTITY_CONSTRAINTS["verified_at"],
            "primary_state": USER_IDENTITY_CONSTRAINTS[
                "primary_state"
            ],
            "primary_per_global": USER_IDENTITY_CONSTRAINTS[
                "primary_per_global"
            ],
        },
        "индексы": [
            "ix_user_identities_global_id",
            "ix_user_identities_provider_status",
            USER_IDENTITY_CONSTRAINTS["primary_per_global"],
        ],
        "инварианты": {
            "provider_subject_может_принадлежать_двум_accounts": False,
            "global_id_вычисляется_из_provider_subject": False,
            "создаёт_user": False,
            "создаёт_session": False,
            "auto_merge": False,
            "меняет_financial_data": False,
            "mock_provider_разрешён_в_production": False,
        },
        "ci_workflow_sha256": {
            relative: _sha256(root / relative)
            for relative in CI_FILES
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(
            "contracts/identity/user_identities_schema_v1.json"
        ),
    )
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output
    if not output.is_absolute():
        output = root / output
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = build_schema_contract(root)
    output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
