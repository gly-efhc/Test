#!/usr/bin/env python3
"""Снять read-only telemetry dual-write/shadow-read цикла 1624.

Gate не меняет ownership и не выполняет read switch. Он читает только
PostgreSQL view, созданный migration 0009, и состояние rollback-control.
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Final

EXPECTED_REVISION: Final[str] = "0001"


def _psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def collect(database_url: str) -> dict[str, object]:
    """Вернуть согласованный read-only shadow telemetry snapshot."""

    try:
        import psycopg
    except ModuleNotFoundError as exc:
        raise RuntimeError("psycopg недоступен") from exc

    with (
        psycopg.connect(_psycopg_url(database_url)) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(
            "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ "
            "READ ONLY DEFERRABLE"
        )
        cursor.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        )
        revision_row = cursor.fetchone()
        if revision_row is None:
            raise RuntimeError("Alembic revision не найдена")
        revision = str(revision_row[0])

        cursor.execute(
            """
            SELECT
                dual_write_enabled,
                shadow_read_enabled,
                legacy_authoritative
            FROM efhc_core.identity_migration_control
            WHERE singleton_id = 1
            """
        )
        control_row = cursor.fetchone()
        if control_row is None:
            raise RuntimeError("identity migration control отсутствует")

        cursor.execute(
            """
            SELECT
                scope,
                legacy_rows,
                shadow_rows,
                matched_rows,
                fallback_rows,
                mismatch_rows,
                orphan_rows,
                shadow_only_rows,
                ambiguous_rows
            FROM efhc_core.identity_ownership_shadow_telemetry
            ORDER BY scope
            """
        )
        rows = cursor.fetchall()
        connection.rollback()

    details: list[dict[str, object]] = []
    totals = {
        "legacy_rows": 0,
        "shadow_rows": 0,
        "matched_rows": 0,
        "fallback_rows": 0,
        "mismatch_rows": 0,
        "orphan_rows": 0,
        "shadow_only_rows": 0,
        "ambiguous_rows": 0,
    }
    keys = tuple(totals)
    for row in rows:
        item = {"scope": str(row[0])}
        for index, key in enumerate(keys, start=1):
            value = int(row[index])
            item[key] = value
            totals[key] += value
        details.append(item)

    dual_write_enabled = bool(control_row[0])
    shadow_read_enabled = bool(control_row[1])
    legacy_authoritative = bool(control_row[2])

    hard_failure = any(
        totals[key] != 0
        for key in ("mismatch_rows", "orphan_rows", "ambiguous_rows")
    )
    if (
        revision != EXPECTED_REVISION
        or not shadow_read_enabled
        or not legacy_authoritative
        or hard_failure
    ):
        status = "FAIL"
    elif totals["fallback_rows"] != 0:
        status = "PASS_WITH_FALLBACK"
    else:
        status = "PASS"

    return {
        "статус": status,
        "alembic_revision": revision,
        "dual_write_enabled": dual_write_enabled,
        "shadow_read_enabled": shadow_read_enabled,
        "legacy_authoritative": legacy_authoritative,
        "telemetry": totals,
        "scopes": details,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database-url",
        default=os.getenv("DATABASE_URL")
        or os.getenv("SYNC_DATABASE_URL"),
    )
    parser.add_argument("--json-report")
    args = parser.parse_args()
    if not args.database_url:
        raise SystemExit("DATABASE_URL обязателен")

    report = collect(args.database_url)
    payload = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
    print(payload)
    if args.json_report:
        with open(
            args.json_report,
            "w",
            encoding="utf-8",
        ) as handle:
            handle.write(payload + "\n")
    return 0 if report["статус"] != "FAIL" else 1


if __name__ == "__main__":
    raise SystemExit(main())
