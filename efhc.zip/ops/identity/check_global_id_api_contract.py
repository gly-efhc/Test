"""Fail-closed guard API-контракта ``global_id`` цикла 1606."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
from typing import Any, Final

from ops.identity.export_global_id_api_contract import build_contract

FIXTURE: Final[Path] = Path(
    "contracts/identity/global_id_api_contract_v1.json"
)
BACKEND_CONTRACT: Final[Path] = Path(
    "backend/app/identity/api_contract.py"
)
FRONTEND_CONTRACT: Final[Path] = Path(
    "frontend/src/contracts/global-id.ts"
)
ACTIVE_ROOTS: Final[tuple[str, ...]] = (
    "backend/app/routes",
    "backend/app/schemas",
    "backend/app/services",
    "backend/app/crud",
)
ACTIVE_SYMBOLS: Final[tuple[str, ...]] = (
    "GlobalIdRequest",
    "GlobalIdResponse",
    "PydanticGlobalId",
    "ApiExternalGlobalId",
)


def _schema_is_canonical(schema: dict[str, Any]) -> bool:
    return (
        schema.get("type") == "string"
        and schema.get("format") == "efhc-global-id"
        and schema.get("pattern") == "^[0-9]{10}$"
        and schema.get("minLength") == 10
        and schema.get("maxLength") == 10
        and "integer" not in json.dumps(schema)
    )


def _dto_fields(path: Path) -> dict[str, list[str]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    result: dict[str, list[str]] = {}
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        if not node.name.endswith(("Request", "Response")):
            continue
        fields = [
            item.target.id
            for item in node.body
            if isinstance(item, ast.AnnAssign)
            and isinstance(item.target, ast.Name)
        ]
        result[node.name] = fields
    return result


def _active_runtime_imports(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    for relative_root in ACTIVE_ROOTS:
        base = root / relative_root
        for path in sorted(base.rglob("*.py")):
            source = path.read_text(encoding="utf-8")
            for line_number, line in enumerate(source.splitlines(), 1):
                if any(symbol in line for symbol in ACTIVE_SYMBOLS):
                    findings.append(
                        {
                            "путь": path.relative_to(root).as_posix(),
                            "строка": line_number,
                            "фрагмент": line.strip(),
                        }
                    )
    return findings


def проверить(root: Path) -> dict[str, Any]:
    """Проверить exact tree и вернуть русскоязычный отчёт."""

    violations: list[dict[str, object]] = []
    expected = build_contract()
    fixture_path = root / FIXTURE
    if not fixture_path.is_file():
        violations.append(
            {
                "путь": FIXTURE.as_posix(),
                "причина": "fixture_missing",
            }
        )
        actual: dict[str, Any] = {}
    else:
        actual = json.loads(fixture_path.read_text(encoding="utf-8"))
        if actual != expected:
            violations.append(
                {
                    "путь": FIXTURE.as_posix(),
                    "причина": "fixture_not_reproducible",
                }
            )

    for key in (
        "схема_path_параметра",
        "схема_поля_ответа",
        "схема_pydantic_значения",
    ):
        schema = expected[key]
        if not _schema_is_canonical(schema):
            violations.append(
                {
                    "путь": FIXTURE.as_posix(),
                    "причина": f"noncanonical_{key}",
                }
            )

    backend_path = root / BACKEND_CONTRACT
    fields = _dto_fields(backend_path)
    for class_name in ("GlobalIdRequest", "GlobalIdResponse"):
        if fields.get(class_name) != ["global_id"]:
            violations.append(
                {
                    "путь": BACKEND_CONTRACT.as_posix(),
                    "причина": "backend_dto_field_mismatch",
                    "класс": class_name,
                    "поля": fields.get(class_name),
                }
            )

    frontend_path = root / FRONTEND_CONTRACT
    frontend = (
        frontend_path.read_text(encoding="utf-8")
        if frontend_path.is_file()
        else ""
    )
    required = (
        'GLOBAL_ID_API_FIELD = "global_id"',
        'GLOBAL_ID_OPENAPI_FORMAT = "efhc-global-id"',
        'GLOBAL_ID_OPENAPI_PATTERN = "^[0-9]{10}$"',
        "export type GlobalIdRequestDto",
        "export type GlobalIdResponseDto",
        "decodeGlobalIdRequest",
        "decodeGlobalIdResponse",
        "encodeGlobalIdRequest",
        "encodeGlobalIdResponse",
    )
    for marker in required:
        if marker not in frontend:
            violations.append(
                {
                    "путь": FRONTEND_CONTRACT.as_posix(),
                    "причина": "frontend_contract_marker_missing",
                    "marker": marker,
                }
            )
    if "user_id" in frontend:
        violations.append(
            {
                "путь": FRONTEND_CONTRACT.as_posix(),
                "причина": "undefined_user_id_in_new_dto",
            }
        )

    active = _active_runtime_imports(root)
    if active:
        violations.append(
            {
                "путь": "backend/app",
                "причина": "active_routes_or_dto_wired_too_early",
                "совпадения": active,
            }
        )

    openapi_snapshot = json.loads(
        (root / "backend/openapi/openapi.json").read_text(
            encoding="utf-8",
        )
    )
    isolated_path = expected["изолированный_openapi_path"]
    if isolated_path in openapi_snapshot.get("paths", {}):
        violations.append(
            {
                "путь": "backend/openapi/openapi.json",
                "причина": "isolated_contract_wired_to_active_snapshot",
            }
        )

    migrations = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
    )
    allowed_migration_states = (
        [
            "0001_init.py",
            "0002_users_user_id_expand.py",
        ],
        [
            "0001_initial_release_schema.py",
        ],
    )
    if migrations not in allowed_migration_states:
        violations.append(
            {
                "путь": "backend/migrations/versions",
                "причина": "alembic_lineage_invalid",
                "файлы": migrations,
            }
        )


    return {
        "схема_отчёта": "EFHC_GLOBAL_ID_API_CONTRACT_GATE_V1",
        "цикл": 1606,
        "исходный_head": "EFHC_Bot_v172_02.zip",
        "целевой_head": "EFHC_Bot_v172_03.zip",
        "fixture_воспроизводим": actual == expected,
        "backend_dto_поля": fields,
        "active_routes_переключены": bool(active),
        "историческое_заполнение": False,
        "переключение_чтения": False,
        "переключение_финансового_владения": False,
        "нарушения": violations,
        "пройдено": not violations,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка API-контракта Global ID цикла 1606.",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
