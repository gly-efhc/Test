"""Fail-closed guard действующего API-контракта ``global_id``."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
from typing import Any, Final

from ops.identity.export_global_id_api_contract import build_contract

FIXTURE: Final[Path] = Path("contracts/identity/global_id_api_contract_v1.json")
BACKEND_CONTRACT: Final[Path] = Path("backend/app/identity/api_contract.py")
FRONTEND_CONTRACT: Final[Path] = Path("frontend/src/contracts/global-id.ts")
ACTIVE_ROOTS: Final[tuple[str, ...]] = (
    "backend/app/routes",
    "backend/app/schemas",
)


def _schema_is_canonical(schema: dict[str, Any]) -> bool:
    return (
        schema.get("type") == "string"
        and schema.get("format") == "efhc-global-id"
        and schema.get("pattern") == "^[0-9]{10}$"
        and schema.get("minLength") == 10
        and schema.get("maxLength") == 10
        and "integer" not in json.dumps(schema)
    )


def _dto_fields(path: Path) -> dict[str, list[str]]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    result: dict[str, list[str]] = {}
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        if node.name not in {"GlobalIdRequest", "GlobalIdResponse"}:
            continue
        result[node.name] = [
            item.target.id
            for item in node.body
            if isinstance(item, ast.AnnAssign)
            and isinstance(item.target, ast.Name)
        ]
    return result


def _active_contract_imports(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    for relative_root in ACTIVE_ROOTS:
        for path in sorted((root / relative_root).rglob("*.py")):
            source = path.read_text(encoding="utf-8")
            for line_number, line in enumerate(source.splitlines(), 1):
                if "ApiExternalGlobalId" in line:
                    findings.append(
                        {
                            "путь": path.relative_to(root).as_posix(),
                            "строка": line_number,
                            "фрагмент": line.strip(),
                        }
                    )
    return findings


def _schema_contains_integer(schema: object) -> bool:
    if isinstance(schema, dict):
        if schema.get("type") == "integer":
            return True
        return any(_schema_contains_integer(value) for value in schema.values())
    if isinstance(schema, list):
        return any(_schema_contains_integer(value) for value in schema)
    return False


def _numeric_global_id_schemas(value: object) -> list[str]:
    """Найти любой OpenAPI schema для global_id с numeric branch."""

    findings: list[str] = []

    def walk(node: object, path: tuple[str, ...]) -> None:
        if isinstance(node, dict):
            if node.get("name") == "global_id":
                schema = node.get("schema", {})
                if _schema_contains_integer(schema):
                    findings.append("/".join(path + ("schema",)))
            for key, child in node.items():
                child_path = (*path, str(key))
                if key == "global_id" and _schema_contains_integer(child):
                    findings.append("/".join(child_path))
                walk(child, child_path)
        elif isinstance(node, list):
            for index, child in enumerate(node):
                walk(child, (*path, str(index)))

    walk(value, ())
    return sorted(set(findings))


def _tg_id_response_fields(openapi: dict[str, Any]) -> list[str]:
    """Не допустить Telegram subject как поле API response DTO."""

    findings: list[str] = []
    schemas = openapi.get("components", {}).get("schemas", {})
    if not isinstance(schemas, dict):
        return findings
    for schema_name, schema in schemas.items():
        if not isinstance(schema, dict):
            continue
        properties = schema.get("properties", {})
        if isinstance(properties, dict) and "tg_id" in properties:
            findings.append(str(schema_name))
    return sorted(findings)


def _generated_tg_id_fields(root: Path) -> list[str]:
    findings: list[str] = []
    for relative in (
        "frontend/src/lib/api/generated/economicUserSeams.ts",
        "frontend/src/lib/api/generated/economicUserSeamValidators.ts",
    ):
        path = root / relative
        if not path.is_file():
            findings.append(f"{relative}:missing")
            continue
        for line_number, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            1,
        ):
            if "tg_id:" in line:
                findings.append(f"{relative}:{line_number}")
    return findings


def проверить(root: Path) -> dict[str, Any]:
    violations: list[dict[str, object]] = []
    expected = build_contract()
    fixture_path = root / FIXTURE
    actual = (
        json.loads(fixture_path.read_text(encoding="utf-8"))
        if fixture_path.is_file()
        else {}
    )
    if actual != expected:
        violations.append(
            {"путь": FIXTURE.as_posix(), "причина": "fixture_not_current"}
        )

    for key in (
        "схема_path_параметра",
        "схема_поля_ответа",
        "схема_pydantic_значения",
    ):
        if not _schema_is_canonical(expected[key]):
            violations.append(
                {"путь": FIXTURE.as_posix(), "причина": f"noncanonical_{key}"}
            )

    fields = _dto_fields(root / BACKEND_CONTRACT)
    for class_name in ("GlobalIdRequest", "GlobalIdResponse"):
        if fields.get(class_name) != ["global_id"]:
            violations.append(
                {
                    "путь": BACKEND_CONTRACT.as_posix(),
                    "причина": "backend_dto_field_mismatch",
                    "класс": class_name,
                    "поля": fields.get(class_name),
                }
            )

    frontend = (root / FRONTEND_CONTRACT).read_text(encoding="utf-8")
    for marker in (
        'GLOBAL_ID_API_FIELD = "global_id"',
        'GLOBAL_ID_OPENAPI_FORMAT = "efhc-global-id"',
        'GLOBAL_ID_OPENAPI_PATTERN = "^[0-9]{10}$"',
        "decodeGlobalIdRequest",
        "decodeGlobalIdResponse",
    ):
        if marker not in frontend:
            violations.append(
                {
                    "путь": FRONTEND_CONTRACT.as_posix(),
                    "причина": "frontend_contract_marker_missing",
                    "marker": marker,
                }
            )

    active = _active_contract_imports(root)
    if not active:
        violations.append(
            {"путь": "backend/app", "причина": "active_contract_not_wired"}
        )

    openapi = json.loads(
        (root / "backend/openapi/openapi.json").read_text(encoding="utf-8")
    )
    numeric = _numeric_global_id_schemas(openapi)
    if numeric:
        violations.append(
            {
                "путь": "backend/openapi/openapi.json",
                "причина": "numeric_global_id_schema",
                "совпадения": numeric,
            }
        )

    tg_response_fields = _tg_id_response_fields(openapi)
    if tg_response_fields:
        violations.append(
            {
                "путь": "backend/openapi/openapi.json",
                "причина": "business_tg_id_response_field",
                "совпадения": tg_response_fields,
            }
        )

    generated_tg_fields = _generated_tg_id_fields(root)
    if generated_tg_fields:
        violations.append(
            {
                "путь": "frontend/src/lib/api/generated",
                "причина": "generated_business_tg_id_field",
                "совпадения": generated_tg_fields,
            }
        )

    sync_source = (root / "backend/app/routes/sync_routes.py").read_text(
        encoding="utf-8"
    )
    deprecated_ingress_marked = (
        '"/user/{tg_id}"' in sync_source
        and "deprecated=True" in sync_source
        and "Use /sync/me with current-user auth." in sync_source
    )
    if not deprecated_ingress_marked:
        violations.append(
            {
                "путь": "backend/app/routes/sync_routes.py",
                "причина": "deprecated_telegram_ingress_not_marked",
            }
        )

    migrations = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
    )
    if migrations != ["0001_initial_release_schema.py"]:
        violations.append(
            {
                "путь": "backend/migrations/versions",
                "причина": "single_0001_required",
                "файлы": migrations,
            }
        )

    return {
        "схема_отчёта": "EFHC_GLOBAL_ID_API_CONTRACT_GATE_V2",
        "версия": "v173.18",
        "цикл": 1699,
        "fixture_воспроизводим": actual == expected,
        "backend_dto_поля": fields,
        "active_contract_imports": len(active),
        "numeric_global_id_schemas": numeric,
        "business_tg_id_response_fields": tg_response_fields,
        "generated_business_tg_id_fields": generated_tg_fields,
        "deprecated_telegram_ingress_marked": deprecated_ingress_marked,
        "business_owner": "global_id",
        "provider_subject": "tg_id",
        "нарушения": violations,
        "пройдено": not violations,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка действующего API-контракта Global ID.",
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
