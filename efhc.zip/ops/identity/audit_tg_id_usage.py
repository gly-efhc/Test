"""Сформировать аудит перехода Telegram identity к global_id."""

from __future__ import annotations

import argparse
import ast
import csv
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

TEXT_SUFFIXES = {
    ".env",
    ".example",
    ".ini",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".py",
    ".sh",
    ".sql",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}
SCAN_ROOTS = (
    "backend",
    "frontend",
    "api",
    "ops",
    "tests",
    "docs",
    "scripts",
    "release_docs",
)
SKIP_PARTS = {
    ".git",
    ".mypy_cache",
    ".next",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
}
LEGACY_PROVIDER_TOKEN = "telegram" + "_id"

TRACKED = (
    "tg_id",
    "current_tg_id",
    "get_current_tg_id",
    "request.state.tg_id",
    LEGACY_PROVIDER_TOKEN,
    "inviter_tg_id",
    "invitee_tg_id",
    "moderator_tg_id",
    "added_by_tg_id",
    "granted_by_tg_id",
    "parsed_tg_id",
    "TG:",
)


def _layer(relative: str) -> str:
    if relative.startswith("backend/app/models/"):
        return "ORM_MODEL"
    if relative.startswith("backend/migrations/"):
        return "ALEMBIC_MIGRATION"
    if relative.startswith("backend/app/services/"):
        return "BACKEND_SERVICE"
    if relative.startswith("backend/app/crud/"):
        return "BACKEND_CRUD"
    if relative.startswith("backend/app/routes/"):
        return "FASTAPI_ROUTE"
    if relative.startswith("backend/app/schemas/"):
        return "PYDANTIC_SCHEMA"
    if relative.startswith("backend/app/bot/"):
        return "TELEGRAM_BOT"
    if relative.startswith("backend/app/middleware"):
        return "MIDDLEWARE"
    if relative.startswith("backend/app/integrations/"):
        return "INTEGRATION"
    if "scheduler" in relative:
        return "SCHEDULER"
    if relative.startswith("backend/app/core/"):
        return "BACKEND_CORE"
    if relative.startswith("frontend/"):
        return "FRONTEND"
    if relative.startswith("tests/"):
        return "TEST"
    if relative.startswith("ops/"):
        return "OPS_CI_GUARD"
    if relative.startswith("docs/"):
        return "DOCUMENTATION"
    if relative.startswith("scripts/"):
        return "SCRIPT"
    return relative.split("/", maxsplit=1)[0].upper()


def _classification(
    relative: str,
    source: str,
    token: str,
) -> tuple[str, str, str, str, str]:
    lower_path = relative.casefold()
    lower_source = source.casefold()
    if relative.startswith("tests/"):
        return (
            "TEST_ONLY",
            "UPDATE_TEST",
            "global_id",
            "1594-1700",
            "LOW",
        )
    if relative.startswith("docs/"):
        return (
            "DOCUMENTATION",
            "UPDATE_DOCUMENTATION",
            "global_id",
            "1594-1700",
            "LOW",
        )
    if token == "parsed_tg_id":
        return (
            "SOURCE_EVENT",
            "ADD_RESOLVED_GLOBAL_ID",
            "parsed_tg_id + resolved_global_id",
            "1658",
            "HIGH",
        )
    if "ton_memo" in lower_path or "tg:" in lower_source:
        return (
            "LEGACY_COMPATIBILITY",
            "DUAL_WRITE_TEMPORARILY",
            "global_id",
            "1629-1630",
            "HIGH",
        )
    telegram_specific = (
        "/bot/" in lower_path
        or "telegram_bot_api" in lower_path
        or "telegram_webapp_auth" in lower_path
    )
    if telegram_specific:
        return (
            "TELEGRAM_SPECIFIC",
            "KEEP_TG_ID",
            "tg_id",
            "1641-1650",
            "MEDIUM",
        )
    auth_marker = (
        "request.state.tg_id" in lower_source
        or "get_current_tg_id" in lower_source
        or "current_tg_id" in lower_source
        or "initdata" in lower_source
    )
    if auth_marker:
        return (
            "AUTH_IDENTITY",
            "ADD_RESOLVED_GLOBAL_ID",
            "global_id",
            "1611-1650",
            "HIGH",
        )
    if relative.startswith("backend/app/models/"):
        actor = any(
            marker in token
            for marker in (
                "added_by_",
                "granted_by_",
                "invitee_",
                "inviter_",
                "moderator_",
            )
        )
        if relative.endswith("user_models.py"):
            model_cycle = "1603"
        elif any(
            marker in lower_path
            for marker in (
                "transaction",
                "payment",
                "withdraw",
                "outcome",
            )
        ):
            model_cycle = "1652"
        elif any(
            marker in lower_path
            for marker in ("wallet", "tx_hash_lock")
        ):
            model_cycle = "1653"
        elif any(
            marker in lower_path
            for marker in ("panel", "scheduler")
        ):
            model_cycle = "1654"
        elif any(
            marker in lower_path
            for marker in (
                "referral",
                "task",
                "rank",
                "achievement",
            )
        ):
            model_cycle = "1655"
        elif any(
            marker in lower_path
            for marker in ("shop", "order", "skin", "nft")
        ):
            model_cycle = "1656"
        elif "admin" in lower_path:
            model_cycle = "1657"
        else:
            model_cycle = "1651-1660"
        return (
            "DOMAIN_ACTOR" if actor else "DOMAIN_OWNER",
            "MIGRATE_TO_GLOBAL_ID",
            "global_id",
            model_cycle,
            "CRITICAL",
        )
    domain_layer = any(
        marker in lower_path
        for marker in (
            "/crud/",
            "/routes/",
            "/services/",
            "frontend/src/",
            "scheduler",
        )
    )
    if domain_layer:
        return (
            "DOMAIN_OWNER",
            "MIGRATE_TO_GLOBAL_ID",
            "global_id",
            "1671-1694",
            "HIGH",
        )
    return (
        "AUTH_IDENTITY",
        "ADD_RESOLVED_GLOBAL_ID",
        "global_id",
        "1611-1650",
        "MEDIUM",
    )


def _matches(line: str) -> list[str]:
    matches: list[str] = []
    for token in TRACKED:
        if token == "TG:":
            if token in line:
                matches.append(token)
            continue
        if re.search(rf"\b{re.escape(token)}\b", line):
            matches.append(token)
    return matches


def _iter_text_files(root: Path):
    for scope in SCAN_ROOTS:
        base = root / scope
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            if path.suffix.casefold() not in TEXT_SUFFIXES:
                continue
            yield path


def _usage_rows(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in _iter_text_files(root):
        relative = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        for number, source in enumerate(text.splitlines(), start=1):
            for token in _matches(source):
                category = _classification(relative, source, token)
                semantics, decision, target, cycle, risk = category
                rows.append(
                    {
                        "file": relative,
                        "line_or_object": str(number),
                        "layer": _layer(relative),
                        "current_field": token,
                        "semantics": semantics,
                        "target_field": target,
                        "decision": decision,
                        "cycle": cycle,
                        "risk": risk,
                        "source_excerpt": source.strip()[:500],
                    }
                )
    return rows


def _python_inventory(root: Path) -> dict[str, list[dict[str, Any]]]:
    functions: list[dict[str, Any]] = []
    orm_fields: list[dict[str, Any]] = []
    routes: list[dict[str, Any]] = []
    for path in sorted((root / "backend").rglob("*.py")):
        if set(path.parts) & SKIP_PARTS:
            continue
        relative = path.relative_to(root).as_posix()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(
                node, (ast.FunctionDef, ast.AsyncFunctionDef)
            ):
                params = [
                    item.arg
                    for item in (
                        *node.args.posonlyargs,
                        *node.args.args,
                        *node.args.kwonlyargs,
                    )
                ]
                hits = [
                    item
                    for item in params
                    if "tg_id" in item
                    or item in {"current_tg_id", LEGACY_PROVIDER_TOKEN}
                ]
                if hits:
                    functions.append(
                        {
                            "file": relative,
                            "object": node.name,
                            "line": node.lineno,
                            "parameters": ", ".join(hits),
                            "layer": _layer(relative),
                        }
                    )
                if relative.startswith("backend/app/routes/"):
                    decorators: list[str] = []
                    for decorator in node.decorator_list:
                        try:
                            decorators.append(ast.unparse(decorator))
                        except Exception:
                            continue
                    route_marker = any(
                        f".{method}(" in item
                        for item in decorators
                        for method in (
                            "delete",
                            "get",
                            "patch",
                            "post",
                            "put",
                        )
                    )
                    if route_marker:
                        routes.append(
                            {
                                "file": relative,
                                "object": node.name,
                                "line": node.lineno,
                                "decorators": " ".join(decorators),
                                "uses_tg_id": (
                                    "get_current_tg_id"
                                    in ast.dump(node)
                                    or any(
                                        "tg_id" in item
                                        for item in params
                                    )
                                ),
                            }
                        )
            if not isinstance(node, ast.ClassDef):
                continue
            if not relative.startswith("backend/app/models/"):
                continue
            for statement in node.body:
                name: str | None = None
                if isinstance(
                    statement,
                    ast.AnnAssign,
                ) and isinstance(statement.target, ast.Name):
                    name = statement.target.id
                elif (
                    isinstance(statement, ast.Assign)
                    and len(statement.targets) == 1
                    and isinstance(statement.targets[0], ast.Name)
                ):
                    name = statement.targets[0].id
                tracked_name = (
                    "tg_id" in name
                    or name == LEGACY_PROVIDER_TOKEN
                ) if name else False
                if tracked_name:
                    orm_fields.append(
                        {
                            "file": relative,
                            "class": node.name,
                            "field": name,
                            "line": statement.lineno,
                        }
                    )
    return {
        "orm_fields": orm_fields,
        "service_signatures": functions,
        "routes": routes,
    }


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0]) if rows else ["empty"]
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def build_audit(
    root: Path,
    output: Path,
    *,
    source_head: str,
    baseline_head: str,
    cycle: int,
) -> dict[str, Any]:
    """Сформировать аудит с явно заданным provenance результата."""

    if cycle < 1:
        raise ValueError("Номер цикла должен быть положительным")
    if not source_head.strip():
        raise ValueError("Исходный HEAD не может быть пустым")
    if not baseline_head.strip():
        raise ValueError("Baseline HEAD не может быть пустым")

    rows = _usage_rows(root)
    inventory = _python_inventory(root)
    files = {row["file"] for row in rows}
    by_layer = Counter(row["layer"] for row in rows)
    by_semantics = Counter(row["semantics"] for row in rows)
    by_decision = Counter(row["decision"] for row in rows)
    summary: dict[str, Any] = {
        "schema": "EFHC_GLOBAL_IDENTITY_AUDIT_V3",
        "source_head": source_head,
        "baseline_head": baseline_head,
        "cycle": cycle,
        "total_usage_rows": len(rows),
        "files_with_usage": len(files),
        "orm_fields": len(inventory["orm_fields"]),
        "service_function_signatures": len(
            inventory["service_signatures"]
        ),
        "routes_inventory": len(inventory["routes"]),
        "routes_using_tg_id": sum(
            bool(item["uses_tg_id"])
            for item in inventory["routes"]
        ),
        "real_domain_dependency_rows": sum(
            row["semantics"] in {"DOMAIN_OWNER", "DOMAIN_ACTOR"}
            for row in rows
        ),
        "by_layer": dict(sorted(by_layer.items())),
        "by_semantics": dict(sorted(by_semantics.items())),
        "by_decision": dict(sorted(by_decision.items())),
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "identity_audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (output / "identity_usage_matrix.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    _write_csv(output / "identity_usage_matrix.csv", rows)
    for name, items in inventory.items():
        _write_csv(output / f"{name}.csv", items)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-head", required=True)
    parser.add_argument("--baseline-head", required=True)
    parser.add_argument("--cycle", type=int, required=True)
    args = parser.parse_args()
    summary = build_audit(
        args.root.resolve(),
        args.output.resolve(),
        source_head=args.source_head,
        baseline_head=args.baseline_head,
        cycle=args.cycle,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
