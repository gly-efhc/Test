#!/usr/bin/env python3
"""Проверка financial shadow contracts после schema squash."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def build() -> dict[str, object]:
    migration_dir = ROOT / "backend/migrations/versions"
    files = sorted(path.name for path in migration_dir.glob("*.py"))
    migration = (
        migration_dir / "0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    gate = (
        ROOT
        / "ops/identity/postgresql_financial_shadow_validation_gate.py"
    ).read_text(encoding="utf-8")
    checks = {
        "single_release_migration": files == [
            "0001_initial_release_schema.py",
        ],
        "release_head": (
            'revision = "0001"' in migration
            and "down_revision = None" in migration
        ),
        "financial_control": (
            "financial_read_global_id_enabled" in migration
        ),
        "zero_discrepancy_gate": "monetary_discrepancy" in gate,
        "idempotency_gate": "idempotency_unchanged" in gate,
        "expected_revision": (
            'EXPECTED_REVISION: Final[str] = "0001"' in gate
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    return {
        "passed": not failed,
        "alembic_head": "0001",
        "single_release_migration": files == [
            "0001_initial_release_schema.py",
        ],
        "checks": checks,
        "errors": failed,
    }


def main() -> int:
    report = build()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
