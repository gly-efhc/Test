"""Fail-closed проверка financial identity keys для цикла 1695."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def _text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def _require(
    violations: list[str],
    *,
    rel: str,
    marker: str,
    label: str,
) -> None:
    if marker not in _text(rel):
        violations.append(f"{label}:missing:{rel}")


def _forbid(
    violations: list[str],
    *,
    rel: str,
    marker: str,
    label: str,
) -> None:
    if marker in _text(rel):
        violations.append(f"{label}:forbidden:{rel}")


def check() -> dict[str, Any]:
    violations: list[str] = []

    # Monetary HTTP locks могут разрешить аккаунт через provider
    # identity, но новые keys принадлежат global_id.
    system_locks = "backend/app/core/system_locks.py"
    _require(
        violations,
        rel=system_locks,
        marker="async def _resolve_monetary_global_id(",
        label="monetary_owner_resolution",
    )
    _require(
        violations,
        rel=system_locks,
        marker='fingerprint = f"global:G{int(global_id):010d}"',
        label="monetary_rate_limit_fingerprint",
    )
    _require(
        violations,
        rel=system_locks,
        marker='raw = f"http_ttl|{path}|{owner_token}|{idempotency_key}"',
        label="monetary_ttl_owner_scope",
    )
    _require(
        violations,
        rel=system_locks,
        marker="global_id=int(global_id)",
        label="idempotency_row_owner",
    )
    _forbid(
        violations,
        rel=system_locks,
        marker='fingerprint = f"tg:',
        label="provider_key_creation",
    )
    _forbid(
        violations,
        rel=system_locks,
        marker="def _resolve_rate_limit_tg_id(",
        label="provider_key_resolution",
    )

    # Exchange использует старые provider keys только для historical
    # lookup; новая операция выбирает canonical G-prefixed key.
    exchange = "backend/app/routes/exchange_routes.py"
    compat = "backend/app/identity/idempotency_readthrough.py"
    _require(
        violations,
        rel=exchange,
        marker='f"exchange:G{owner.global_id:010d}:{idk_digest}"',
        label="exchange_canonical_key",
    )
    _require(
        violations,
        rel=exchange,
        marker="choose_idempotency_key_with_history(",
        label="exchange_historical_readthrough",
    )
    _require(
        violations,
        rel=compat,
        marker="selected=canonical",
        label="new_operation_uses_canonical_key",
    )

    # Payment intents и withdrawal state индексируются canonical owner.
    _require(
        violations,
        rel="backend/app/services/payment_intents_service.py",
        marker="ON CONFLICT (global_id, purpose, idempotency_key)",
        label="payment_intent_owner_key",
    )
    _require(
        violations,
        rel="backend/app/services/withdraw_service.py",
        marker="WHERE global_id = :global_id",
        label="withdraw_owner_key",
    )

    # On-chain replay lock сохраняет canonical account owner.
    tx_lock = "backend/app/services/shop_payment_tx_hash_lock_service.py"
    _require(
        violations,
        rel=tx_lock,
        marker="global_id: int",
        label="tx_hash_lock_signature",
    )
    _require(
        violations,
        rel=tx_lock,
        marker='"global_id": int(global_id)',
        label="tx_hash_lock_owner_write",
    )

    # Reconciliation принимает provider ownership только как historical
    # fallback, если persisted snapshot не содержит canonical owner.
    reconciliation = "backend/app/services/payment_reconciliation_service.py"
    _require(
        violations,
        rel=reconciliation,
        marker="historical_provider_owner_only = bool(",
        label="reconciliation_historical_split",
    )

    return {
        "schema": "EFHC_FINANCIAL_IDENTITY_KEYS_V1",
        "cycle": 1695,
        "new_financial_provider_keys": 0 if not violations else None,
        "historical_provider_readthrough": "READ_ONLY_COMPATIBILITY",
        "violations": violations,
        "passed": not violations,
    }


def main() -> int:
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
