"""Построить точный реестр identity-токенов текущего HEAD."""

from __future__ import annotations

import ast
import csv
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "reports" / "generated"
VERSION = "v173.04"
CYCLE = 1685
TOKENS = (
    "tg" + "_id",
    "tg" + "_provider_id",
    "telegram" + "_provider_id",
)
TOKEN_RE = re.compile(
    r"\b(?:" + "|".join(map(re.escape, TOKENS)) + r")\b"
)
EXTENSIONS = {
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".json",
    ".md",
    ".sql",
    ".yml",
    ".yaml",
}
SKIP_PARTS = {
    "node_modules",
    ".next",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}
SCAN_ROOTS = (
    "backend",
    "frontend",
    "tests",
    "contracts",
    "ops",
    "docs",
)
OPEN_STATUSES = {
    "OPEN_CONFIRMED",
    "OPEN_REVIEW",
    "REVIEW_REQUIRED",
}
TELEGRAM_MARKERS = (
    "telegram",
    "initdata",
    "bot api",
    "send_message",
    "membership",
    "provider mapping",
    "webhook",
    "current_tg",
)
IDEMPOTENCY_MARKERS = (
    "idempotency",
    "historical",
    "read-through",
    "read_through",
)
COMPAT_MARKERS = (
    "legacy",
    "compat",
    "deprecated",
    "dual_write",
    "alias",
)
HISTORY_MARKERS = (
    "/history/",
    "/archive/",
    "/audits/",
    "historical",
    "reports/cycles/",
)
PHYSICAL_TG_TABLES = {
    "users",
    "user_identities",
    "admin_whitelist",
    "withdraw_outcome_events",
    "wallet_bindings",
}


def _files() -> list[Path]:
    found: list[Path] = []
    for root_name in SCAN_ROOTS:
        base = ROOT / root_name
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in EXTENSIONS:
                continue
            if any(part in SKIP_PARTS for part in path.parts):
                continue
            if path.resolve() == Path(__file__).resolve():
                continue
            found.append(path)
    return sorted(found)


def _symbols(path: Path) -> list[tuple[int, int, str]]:
    if path.suffix != ".py":
        return []
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return []
    spans: list[tuple[int, int, str]] = []
    node_types = (
        ast.FunctionDef,
        ast.AsyncFunctionDef,
        ast.ClassDef,
    )
    for node in ast.walk(tree):
        if not isinstance(node, node_types):
            continue
        end = int(getattr(node, "end_lineno", node.lineno))
        kind = "class" if isinstance(node, ast.ClassDef) else "function"
        spans.append((int(node.lineno), end, f"{kind}:{node.name}"))
    return spans


def _symbol(
    spans: list[tuple[int, int, str]],
    line_no: int,
) -> str:
    matches = [
        item for item in spans
        if item[0] <= line_no <= item[1]
    ]
    if not matches:
        return "module"
    start, end, name = min(
        matches,
        key=lambda item: (item[1] - item[0], item[0]),
    )
    _ = (start, end)
    return name


def _table(context: str) -> str | None:
    patterns = (
        r"__tablename__\s*=\s*[\"']([^\"']+)",
        r"create_table\(\s*[\"']([^\"']+)",
        r"(?:from|into|update)\s+[\w.]*\.?(\w+)",
    )
    for pattern in patterns:
        match = re.search(pattern, context, flags=re.I)
        if match:
            return str(match.group(1))
    return None


def _allowed_test_locations() -> dict[tuple[str, int], str]:
    path = OUT / "test_tg_id_telegram_allowlist.json"
    if not path.exists():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    result: dict[tuple[str, int], str] = {}
    for item in payload.get("remaining_registered_occurrences", []):
        key = (str(item.get("file", "")), int(item.get("line", 0)))
        result[key] = str(item.get("reason", ""))
    return result


def _classify(
    rel: str,
    line: str,
    context: str,
    token: str,
    table: str | None,
    allowed_test_reason: str | None,
    symbol: str,
) -> tuple[str, str, str, str]:
    low = (line + "\n" + context).lower()
    rel_low = rel.lower()
    if token != TOKENS[0]:
        return (
            "LEGACY_COMPATIBILITY_REMOVE",
            "OPEN_CONFIRMED",
            "Replace forbidden provider alias with canonical tg_id.",
            "HIGH",
        )
    if any(marker in rel_low for marker in HISTORY_MARKERS):
        return (
            "HISTORICAL_EVIDENCE_EXCLUDED",
            "PRESERVE_HISTORICAL",
            "Preserve immutable historical evidence.",
            "HIGH",
        )
    if rel == "backend/app/bot/handlers/referrals_handlers.py":
        return (
            "TELEGRAM_PROVIDER_ALLOWED",
            "ALLOWED_TELEGRAM",
            (
                "Keep Telegram command ingress before "
                "global_id resolution."
            ),
            "HIGH",
        )
    if (
        rel == "backend/app/models/referral_models.py"
        and symbol == "class:ReferralBonusLedger"
    ):
        return (
            "PHYSICAL_TG_ID_ALLOWED",
            "ALLOWED_TELEGRAM",
            (
                "Keep nullable Telegram provider metadata "
                "without ownership."
            ),
            "HIGH",
        )
    if rel == "backend/app/services/referral_service.py":
        historical_symbols = {
            "function:_maybe_reward_active_unit_bonus",
            "function:_sync_inviter_level_rewards",
        }
        provider_symbols = {
            "function:get_or_create_referral_code",
            "function:_create_bot_user_identity",
            "function:_user_exists_after_storage_conflict",
            "function:onboard_user_at_first_creation",
            "class:_ReferralOwner",
            "function:_load_referral_owner",
            "function:on_user_first_panel_activation",
            "function:_award_first_panel_referral_rewards",
        }
        if symbol in historical_symbols:
            return (
                "HISTORICAL_IDEMPOTENCY_READ_THROUGH",
                "PRESERVE_READ_THROUGH",
                "Keep Telegram historical key read-through only.",
                "HIGH",
            )
        if symbol in provider_symbols:
            return (
                "TELEGRAM_PROVIDER_ALLOWED",
                "ALLOWED_TELEGRAM",
                (
                    "Keep nullable Telegram provider metadata "
                    "after global ownership."
                ),
                "HIGH",
            )
    if rel.startswith("tests/"):
        reason = str(allowed_test_reason or "")
        if reason.startswith("Telegram/provider") or reason.startswith(
            "provider metadata fixture"
        ):
            return (
                "TELEGRAM_PROVIDER_ALLOWED",
                "ALLOWED_TELEGRAM",
                "Keep only at the tested Telegram/provider boundary.",
                "HIGH",
            )
        if reason.startswith("historical/schema") or reason.startswith(
            "physical field"
        ):
            return (
                "HISTORICAL_EVIDENCE_EXCLUDED",
                "PRESERVE_HISTORICAL",
                "Keep physical or historical contract evidence.",
                "HIGH",
            )
        return (
            "TEST_FIXTURE_UPDATE",
            "REVIEW_REQUIRED",
            (
                "Review provider fixture; business calls already "
                "require global_id."
            ),
            "MEDIUM",
        )
    if any(marker in low for marker in IDEMPOTENCY_MARKERS):
        return (
            "HISTORICAL_IDEMPOTENCY_READ_THROUGH",
            "PRESERVE_READ_THROUGH",
            "Keep historical key read-through; write canonical key.",
            "MEDIUM",
        )
    if rel.startswith("frontend/"):
        if any(marker in low for marker in TELEGRAM_MARKERS):
            return (
                "TELEGRAM_PROVIDER_ALLOWED",
                "ALLOWED_TELEGRAM",
                "Keep at Telegram adapter boundary.",
                "MEDIUM",
            )
        return (
            "FRONTEND_CONTRACT_MUST_GLOBAL_ID",
            "OPEN_CONFIRMED",
            "Use string global_id for business API ownership.",
            "HIGH",
        )
    if "migrations/" in rel or "/models/" in rel:
        if table in PHYSICAL_TG_TABLES:
            return (
                "PHYSICAL_TG_ID_ALLOWED",
                "ALLOWED_TELEGRAM",
                "Keep physical Telegram provider metadata.",
                "MEDIUM",
            )
        return (
            "PHYSICAL_SCHEMA_MUST_GLOBAL_ID",
            "OPEN_REVIEW",
            "Review FK, index, nullability and owner semantics.",
            "HIGH",
        )
    if any(marker in low for marker in TELEGRAM_MARKERS):
        return (
            "TELEGRAM_PROVIDER_ALLOWED",
            "ALLOWED_TELEGRAM",
            "Keep only at Telegram/provider boundary.",
            "MEDIUM",
        )
    if any(marker in low for marker in COMPAT_MARKERS):
        return (
            "LEGACY_COMPATIBILITY_REMOVE",
            "OPEN_REVIEW",
            "Move callers to global_id, then remove compatibility.",
            "HIGH",
        )
    if "/routes/" in rel or "/schemas/" in rel:
        return (
            "API_CONTRACT_MUST_GLOBAL_ID",
            "OPEN_CONFIRMED",
            "Resolve provider identity before business API call.",
            "HIGH",
        )
    return (
        "BUSINESS_OWNER_MUST_GLOBAL_ID",
        "OPEN_REVIEW",
        "Translate full business contour to global_id.",
        "MEDIUM",
    )


def _rows() -> list[dict[str, Any]]:
    allowed_test_locations = _allowed_test_locations()
    rows: list[dict[str, Any]] = []
    for path in _files():
        rel = path.relative_to(ROOT).as_posix()
        source = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )
        lines = source.splitlines()
        spans = _symbols(path)
        for line_no, line in enumerate(lines, start=1):
            for match in TOKEN_RE.finditer(line):
                start = max(0, line_no - 4)
                end = min(len(lines), line_no + 3)
                context = "\n".join(lines[start:end])
                table = _table(context)
                symbol = _symbol(spans, line_no)
                category, status, action, confidence = _classify(
                    rel,
                    line,
                    context,
                    str(match.group(0)),
                    table,
                    allowed_test_locations.get((rel, line_no)),
                    symbol,
                )
                rows.append(
                    {
                        "file": rel,
                        "line": line_no,
                        "column": int(match.start()) + 1,
                        "symbol": symbol,
                        "token": str(match.group(0)),
                        "fragment": line.strip()[:500],
                        "table": table,
                        "current_semantics": category,
                        "target_semantics": (
                            "Telegram provider metadata"
                            if status == "ALLOWED_TELEGRAM"
                            else "global_id business owner"
                        ),
                        "action": action,
                        "category": category,
                        "status": status,
                        "confidence": confidence,
                    }
                )
    return rows


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(rows[0]) if rows else ["file"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_provider_inventory(rows: list[dict[str, Any]]) -> None:
    counts = Counter(str(row["token"]) for row in rows)
    payload = {
        "version": VERSION,
        "cycle": CYCLE,
        "model": "provider + subject -> global_id",
        "canonical_provider_fields": {
            "telegram": "tg_id",
            "ton": "ton_address",
            "google": "google_id",
            "apple": "apple_id",
            "facebook": "fb_id",
            "discord": "discord_id",
            "github": "github_id",
        },
        "token_counts": dict(counts),
    }
    path = OUT / "provider_identity_final_inventory.json"
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Provider identity inventory",
        "",
        f"Version: `{VERSION}`. Cycle: `{CYCLE}`.",
        "",
        "Canonical model: `provider + subject -> global_id`.",
        "",
    ]
    for name, count in sorted(counts.items()):
        lines.append(f"- `{name}`: **{count}**.")
    md_path = OUT / "provider_identity_final_inventory.md"
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = _rows()
    actionable = [
        row for row in rows if row["status"] in OPEN_STATUSES
    ]
    categories = Counter(str(row["category"]) for row in rows)
    statuses = Counter(str(row["status"]) for row in rows)
    files = Counter(str(row["file"]) for row in actionable)
    summary = {
        "version": VERSION,
        "cycle": CYCLE,
        "total_token_occurrences": len(rows),
        "actionable_or_review": len(actionable),
        "allowed_or_preserved": len(rows) - len(actionable),
        "categories": dict(sorted(categories.items())),
        "statuses": dict(sorted(statuses.items())),
        "items": rows,
        "rows": rows,
    }
    json_path = OUT / "tg_id_final_inventory.json"
    json_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    _write_csv(OUT / "tg_id_final_inventory.csv", rows)
    _write_csv(OUT / "tg_id_open_actions.csv", actionable)
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in actionable:
        domain = str(row["file"]).split("/", 2)[:2]
        key = "/".join(domain)
        grouped.setdefault(key, []).append(row)
    group_path = OUT / "tg_id_actionable_by_domain.json"
    group_path.write_text(
        json.dumps(grouped, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    md = [
        "# Final tg_id inventory",
        "",
        f"Version: `{VERSION}`. Cycle: `{CYCLE}`.",
        "",
        f"- Total: **{len(rows)}**.",
        f"- Actionable or review: **{len(actionable)}**.",
        f"- Allowed or preserved: **{len(rows)-len(actionable)}**.",
        "",
        "## Categories",
        "",
    ]
    for name, count in sorted(categories.items()):
        md.append(f"- `{name}`: **{count}**.")
    md.extend(["", "## Statuses", ""])
    for name, count in sorted(statuses.items()):
        md.append(f"- `{name}`: **{count}**.")
    md.extend(["", "## Top open files", ""])
    for name, count in files.most_common(30):
        md.append(f"- `{name}`: **{count}**.")
    inv_md = OUT / "tg_id_final_inventory.md"
    inv_md.write_text("\n".join(md) + "\n", encoding="utf-8")
    domain_md = ["# Actionable identity queue by domain", ""]
    for name, items in sorted(grouped.items()):
        domain_md.append(f"- `{name}`: **{len(items)}**.")
    path = OUT / "tg_id_actionable_by_domain.md"
    path.write_text(
        "\n".join(domain_md) + "\n",
        encoding="utf-8",
    )
    _write_provider_inventory(rows)
    print(
        json.dumps(
            {
                "version": VERSION,
                "cycle": CYCLE,
                "total": len(rows),
                "actionable": len(actionable),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
