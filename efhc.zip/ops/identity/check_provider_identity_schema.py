#!/usr/bin/env python3
"""Проверка identity schema для единой pre-release baseline 0001."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory

ROOT = Path(__file__).resolve().parents[2]


def build_report(root: Path = ROOT) -> dict[str, object]:
    root = root.resolve()
    migration_dir = root / "backend/migrations/versions"
    migration_path = migration_dir / "0001_initial_release_schema.py"
    source = migration_path.read_text(encoding="utf-8")
    config = Config(str(root / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(root / "backend/migrations"),
    )
    heads = ScriptDirectory.from_config(config).get_heads()
    files = sorted(path.name for path in migration_dir.glob("*.py"))

    checks = {
        "single_head": heads == ["0001"],
        "migration_lineage": files == [
            "0001_initial_release_schema.py",
        ],
        "metadata_create_all": "Base.metadata.create_all" in source,
        "identity_table_required": (
            "efhc_core.user_identities" in source
        ),
        "auth_challenges_required": (
            "efhc_core.auth_challenges" in source
        ),
        "auth_sessions_required": "efhc_core.auth_sessions" in source,
        "user_roles_required": "efhc_core.user_roles" in source,
        "physical_legacy_absent": (
            "users.user_id physical column forbidden" in source
        ),
    }
    errors = [name for name, passed in checks.items() if not passed]
    return {
        "схема": "EFHC_RELEASE_IDENTITY_SCHEMA_GUARD_V1",
        "пройдено": not errors,
        "ошибки": errors,
        "alembic_heads": heads,
        "migration_files": files,
        "postgresql_выполнен_онлайн": False,
        "статус_postgresql": "BLOCKED_BY_ENVIRONMENT_LOCAL",
        "проверки": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = build_report(args.root)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
