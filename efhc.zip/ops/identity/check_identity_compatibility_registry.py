"""Fail-closed guard semantic allowlist и compatibility registry."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path
from typing import Final

from app.identity.compatibility_registry import (
    COMPATIBILITY_ALIASES,
    HISTORICAL_SCOPES,
    IDENTITY_NAME_POLICIES,
    build_identity_compatibility_registry,
)

CYCLE: Final[int] = 1631
TARGET_HEAD: Final[str] = "EFHC_Bot_v172_46.zip"
FIXTURE: Final[str] = (
    "contracts/identity/compatibility_registry_v1.json"
)

PRODUCTION_ROOTS: Final[tuple[str, ...]] = (
    "backend/app",
    "api",
    "frontend/src",
)

LEGACY_IMPORT_ALLOWED: Final[set[str]] = {
    "backend/app/identity/legacy_user_id.py",
}


def _read(root: Path, relative: str) -> str:
    return (root / relative).read_text(encoding="utf-8")


def _model_synonyms(root: Path) -> dict[str, str]:
    source = _read(root, "backend/app/models/user_models.py")
    tree = ast.parse(source)
    result: dict[str, str] = {}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        target: ast.AST
        value: ast.AST | None
        if isinstance(node, ast.Assign):
            if len(node.targets) != 1:
                continue
            target = node.targets[0]
            value = node.value
        else:
            target = node.target
            value = node.value
        if not isinstance(target, ast.Name):
            continue
        if not isinstance(value, ast.Call):
            continue
        if not isinstance(value.func, ast.Name):
            continue
        if value.func.id != "synonym" or len(value.args) != 1:
            continue
        argument = value.args[0]
        if isinstance(argument, ast.Constant) and isinstance(
            argument.value,
            str,
        ):
            result[target.id] = argument.value
    return result


def _mapped_user_columns(root: Path) -> set[str]:
    source = _read(root, "backend/app/models/user_models.py")
    tree = ast.parse(source)
    columns: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.AnnAssign):
            continue
        if not isinstance(node.target, ast.Name):
            continue
        call = node.value
        if not isinstance(call, ast.Call):
            continue
        if (
            isinstance(call.func, ast.Name)
            and call.func.id == "mapped_column"
        ):
            columns.add(node.target.id)
    return columns


def _legacy_import_findings(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    pattern = re.compile(
        r"(?:from|import)\s+app\.identity\.legacy_user_id"
    )
    for relative_root in PRODUCTION_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.py")):
            relative = path.relative_to(root).as_posix()
            if relative in LEGACY_IMPORT_ALLOWED:
                continue
            source = path.read_text(
                encoding="utf-8",
                errors="replace",
            )
            for number, line in enumerate(source.splitlines(), 1):
                if pattern.search(line):
                    findings.append(
                        {
                            "файл": relative,
                            "строка": number,
                            "причина": "legacy_import_in_production",
                        }
                    )
    return findings


def _ambiguous_contract_findings(
    root: Path,
) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    paths = (
        root / "backend/app/identity/api_contract.py",
        root / "frontend/src/contracts/global-id.ts",
    )
    for path in paths:
        source = path.read_text(encoding="utf-8")
        pattern = (
            re.compile(r"^\s*user_id\s*:")
            if path.suffix == ".py"
            else re.compile(r"\buser_id\s*:")
        )
        for number, line in enumerate(source.splitlines(), 1):
            if pattern.search(line):
                findings.append(
                    {
                        "файл": path.relative_to(root).as_posix(),
                        "строка": number,
                        "причина": "ambiguous_user_id_contract",
                    }
                )
    return findings


def проверить(root: Path) -> dict[str, object]:
    """Проверить единый registry и его repository boundaries."""

    violations: list[dict[str, object]] = []
    fixture_path = root / FIXTURE
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    expected = build_identity_compatibility_registry()
    if fixture != expected:
        violations.append(
            {
                "причина": "registry_fixture_drift",
                "файл": FIXTURE,
            }
        )

    names = {policy.name for policy in IDENTITY_NAME_POLICIES}
    if names != {"global_id", "user_id", "id", "tg_id"}:
        violations.append(
            {
                "причина": "identity_name_set_invalid",
                "значения": sorted(names),
            }
        )

    canonical = next(
        item for item in IDENTITY_NAME_POLICIES
        if item.name == "global_id"
    )
    if (
        not canonical.owner_allowed
        or canonical.sunset_cycle is not None
    ):
        violations.append(
            {"причина": "global_id_not_canonical_owner"}
        )

    for policy in IDENTITY_NAME_POLICIES:
        if policy.name != "global_id" and policy.owner_allowed:
            violations.append(
                {
                    "причина": "non_global_owner_allowed",
                    "имя": policy.name,
                }
            )
        if (
            policy.status == "compatibility"
            and policy.sunset_cycle != 1632
        ):
            violations.append(
                {
                    "причина": "compatibility_sunset_invalid",
                    "имя": policy.name,
                }
            )

    synonyms = _model_synonyms(root)
    required_synonyms = {
        "user_id": "global_id",
        "legacy_pk": "id",
        "legacy_runtime_id": "id",
        "telegram_id": "tg_id",
    }
    if synonyms != required_synonyms:
        violations.append(
            {
                "причина": "orm_synonym_registry_mismatch",
                "факт": synonyms,
                "ожидалось": required_synonyms,
            }
        )

    columns = _mapped_user_columns(root)
    if "user_id" in columns:
        violations.append(
            {"причина": "separate_legacy_user_id_column_forbidden"}
        )
    if not {"id", "global_id", "tg_id"}.issubset(columns):
        violations.append(
            {
                "причина": "required_physical_columns_missing",
                "колонки": sorted(columns),
            }
        )

    for alias in COMPATIBILITY_ALIASES:
        if alias.sunset_cycle != 1632:
            violations.append(
                {
                    "причина": "alias_sunset_budget_invalid",
                    "alias": alias.alias,
                }
            )
        if alias.runtime_switch:
            violations.append(
                {
                    "причина": "alias_runtime_switch_forbidden",
                    "alias": alias.alias,
                }
            )

    for scope in HISTORICAL_SCOPES:
        if scope.may_define_current_runtime:
            violations.append(
                {
                    "причина": "historical_scope_controls_runtime",
                    "путь": scope.path_prefix,
                }
            )

    violations.extend(_legacy_import_findings(root))
    violations.extend(_ambiguous_contract_findings(root))

    return {
        "схема_отчёта": (
            "EFHC_IDENTITY_COMPATIBILITY_REGISTRY_GUARD_V1"
        ),
        "цикл": CYCLE,
        "исходный_head": TARGET_HEAD,
        "пройдено": not violations,
        "нарушения": violations,
        "зарегистрировано_имён": len(IDENTITY_NAME_POLICIES),
        "зарегистрировано_aliases": len(COMPATIBILITY_ALIASES),
        "исторических_областей": len(HISTORICAL_SCOPES),
        "цикл_удаления_совместимости": 1632,
        "historical_backfill_выполнен": True,
        "переключение_чтения": True,
        "переключение_финансового_владения": True,
        "physical_rename_выполнен": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка semantic allowlist identity registry."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
