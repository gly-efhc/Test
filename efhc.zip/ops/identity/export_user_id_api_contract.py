"""Export the isolated UserId Pydantic/OpenAPI contract snapshot."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Annotated, Any

from app.identity.legacy_user_id import (
    ApiExternalUserId,
    PydanticUserId,
    UserIdResponse,
)
from fastapi import FastAPI
from fastapi import Path as FastApiPath
from pydantic import TypeAdapter


def build_contract() -> dict[str, Any]:
    """Build a deterministic test-only contract representation."""

    app = FastAPI(title="EFHC UserId contract fixture")

    @app.get(
        "/contract/users/{user_id}",
        response_model=UserIdResponse,
    )
    def read_contract_user(
        user_id: Annotated[
            ApiExternalUserId,
            FastApiPath(description="EFHC system user ID"),
        ],
    ) -> UserIdResponse:
        parsed = TypeAdapter(PydanticUserId).validate_python(user_id)
        return UserIdResponse.from_user_id(parsed)

    openapi = app.openapi()
    operation = openapi["paths"][
        "/contract/users/{user_id}"
    ]["get"]
    parameter = operation["parameters"][0]["schema"]
    response = openapi["components"]["schemas"][
        "UserIdResponse"
    ]["properties"]["user_id"]
    return {
        "schema": "EFHC_USER_ID_API_CONTRACT_V1",
        "source_head": "EFHC_Bot_v171_92.zip",
        "target_head": "EFHC_Bot_v171_93.zip",
        "cycle": 1596,
        "api_contract_prepared": True,
        "active_routes_wired": False,
        "existing_dtos_wired": False,
        "path_parameter_schema": parameter,
        "response_field_schema": response,
        "pydantic_value_schema": TypeAdapter(
            PydanticUserId
        ).json_schema(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = build_contract()
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
