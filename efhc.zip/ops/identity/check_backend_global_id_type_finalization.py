"""Fail-closed guard завершения backend-типов Global ID цикла 1604."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
from typing import Final

CYCLE: Final[int] = 1604
SOURCE_HEAD: Final[str] = "EFHC_Bot_v172_00.zip"
TARGET_HEAD: Final[str] = "EFHC_Bot_v172_01.zip"

LEGACY_TYPE_NAMES: Final[frozenset[str]] = frozenset(
    {
        "UserId",
        "UserIdDisplay",
        "ExternalUserId",
        "ApiExternalUserId",
        "PydanticUserId",
        "InvalidUserId",
        "UserIdRequest",
        "UserIdResponse",
        "format_user_id",
        "parse_user_id",
        "validate_user_id",
        "validate_user_id_display",
        "user_id_from_database",
        "user_id_to_database",
        "is_user_id",
    }
)

CANONICAL_MODULES: Final[tuple[str, ...]] = (
    "backend/app/identity/types.py",
    "backend/app/identity/api_contract.py",
    "backend/app/identity/__init__.py",
)

EXPLICIT_LEGACY_MODULE: Final[str] = (
    "backend/app/identity/legacy_user_id.py"
)


def _defined_names(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in tree.body:
        if isinstance(
            node,
            (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef),
        ):
            names.add(node.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = (
                node.targets
                if isinstance(node, ast.Assign)
                else [node.target]
            )
            for target in targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.ImportFrom):
            names.update(
                alias.asname or alias.name
                for alias in node.names
            )
    return names


def _legacy_imports_in_backend(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    backend = root / "backend/app"
    for path in sorted(backend.rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        if relative == EXPLICIT_LEGACY_MODULE:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            findings.append(
                {
                    "файл": relative,
                    "строка": exc.lineno or 0,
                    "причина": "syntax_error",
                }
            )
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            imported = {alias.name for alias in node.names}
            forbidden = sorted(imported & LEGACY_TYPE_NAMES)
            if forbidden:
                findings.append(
                    {
                        "файл": relative,
                        "строка": node.lineno,
                        "причина": "legacy_type_import_in_backend",
                        "имена": forbidden,
                        "модуль": node.module,
                    }
                )
    return findings


def проверить(root: Path) -> dict[str, object]:
    """Проверить exact tree без изменения БД и runtime ownership."""

    root = root.resolve()
    violations: list[str] = []
    details: dict[str, object] = {}

    missing = [
        relative
        for relative in (*CANONICAL_MODULES, EXPLICIT_LEGACY_MODULE)
        if not (root / relative).is_file()
    ]
    if missing:
        violations.append(
            "отсутствуют обязательные identity-модули: "
            + ", ".join(missing)
        )

    canonical_legacy: dict[str, list[str]] = {}
    for relative in CANONICAL_MODULES:
        path = root / relative
        if not path.is_file():
            continue
        names = sorted(_defined_names(path) & LEGACY_TYPE_NAMES)
        canonical_legacy[relative] = names
        if names:
            violations.append(
                f"{relative} экспортирует legacy type names: {names}"
            )
    details["legacy_имена_в_канонических_модулях"] = canonical_legacy

    backend_imports = _legacy_imports_in_backend(root)
    details["legacy_импорты_backend"] = backend_imports
    if backend_imports:
        violations.append(
            "backend-код импортирует legacy UserId type names вне "
            "явного compatibility-модуля"
        )

    if (root / EXPLICIT_LEGACY_MODULE).is_file():
        legacy_names = _defined_names(root / EXPLICIT_LEGACY_MODULE)
        absent = sorted(LEGACY_TYPE_NAMES - legacy_names)
        details["отсутствующие_legacy_exports"] = absent
        if absent:
            violations.append(
                "явный legacy-модуль неполон: " + ", ".join(absent)
            )

    import app.identity as identity
    from app.identity import (
        GlobalId,
        GlobalIdDisplay,
        IdentityValueError,
        TelegramId,
        format_global_id,
        format_tg_id,
        global_id_from_database,
        global_id_to_database,
        tg_id_from_provider,
        tg_id_to_provider,
    )

    top_level_legacy = sorted(
        name for name in LEGACY_TYPE_NAMES if hasattr(identity, name)
    )
    details["экспорты_legacy_верхнего_уровня"] = top_level_legacy
    if top_level_legacy:
        violations.append(
            "app.identity сохраняет legacy exports: "
            + ", ".join(top_level_legacy)
        )

    global_id = GlobalId(42)
    tg_id = TelegramId(42)
    if format_global_id(global_id) != GlobalIdDisplay("0000000042"):
        violations.append("GlobalId formatting contract нарушен")
    if global_id_from_database(42) != global_id:
        violations.append("GlobalId database input boundary нарушена")
    if global_id_to_database(global_id) != 42:
        violations.append("GlobalId database output boundary нарушена")
    if tg_id_from_provider(42) != tg_id:
        violations.append("TelegramId provider input boundary нарушена")
    if tg_id_to_provider(tg_id) != 42:
        violations.append(
            "TelegramId provider output boundary нарушена"
        )
    if format_tg_id(tg_id) != "42":
        violations.append("TelegramId formatting contract нарушен")

    sample = IdentityValueError("ошибка", code="identity.test")
    if sample.as_dict() != {
        "поле": "identity",
        "код": "identity.test",
        "сообщение": "ошибка",
    }:
        violations.append("машинный payload identity-ошибки нестабилен")

    migrations = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
    )
    details["alembic_versions"] = migrations
    allowed_migration_states = (
        [
            "0001_init.py",
            "0002_users_user_id_expand.py",
        ],
        ["0001_initial_release_schema.py"],
        [
            "0001_initial_release_schema.py",
        ],
    )
    if migrations not in allowed_migration_states:
        violations.append(
            "active Alembic lineage не соответствует историческому "
            "prefix или release schema freeze"
        )


    return {
        "схема_отчёта": "EFHC_BACKEND_GLOBAL_ID_TYPE_FINALIZATION_V1",
        "цикл": CYCLE,
        "исходный_head": SOURCE_HEAD,
        "целевой_head": TARGET_HEAD,
        "пройдено": not violations,
        "нарушения": violations,
        "детали": details,
        "историческое_заполнение": False,
        "переключение_чтения": False,
        "переключение_финансового_владения": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка завершения backend-типов Global ID"
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root)
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
