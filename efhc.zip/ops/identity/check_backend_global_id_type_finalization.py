"""Fail-closed guard финального backend GlobalId contract."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path

LEGACY_TYPE_NAMES = frozenset(
    {
        "UserId",
        "UserIdDisplay",
        "ExternalUserId",
        "ApiExternalUserId",
        "PydanticUserId",
        "InvalidUserId",
        "UserIdRequest",
        "UserIdResponse",
        "format_user_id",
        "parse_user_id",
        "validate_user_id",
        "validate_user_id_display",
        "user_id_from_database",
        "user_id_to_database",
        "is_user_id",
    }
)
CANONICAL_MODULES = (
    "backend/app/identity/types.py",
    "backend/app/identity/api_contract.py",
    "backend/app/identity/__init__.py",
    "backend/app/identity/identity_registry.py",
)
RETIRED_ACTIVE_MODULES = (
    "backend/app/identity/legacy_user_id.py",
    "backend/app/identity/legacy_alias.py",
    "backend/app/identity/user_id_backfill.py",
    "backend/app/identity/user_id_expand.py",
)


def _defined_names(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names)
    return names


def _legacy_imports_in_backend(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    for path in sorted((root / "backend/app").rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            findings.append(
                {"файл": relative, "строка": exc.lineno or 0, "причина": "syntax_error"}
            )
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            imported = {alias.name for alias in node.names}
            forbidden = sorted(imported & LEGACY_TYPE_NAMES)
            if forbidden:
                findings.append(
                    {
                        "файл": relative,
                        "строка": node.lineno,
                        "причина": "legacy_type_import_in_backend",
                        "имена": forbidden,
                        "модуль": node.module,
                    }
                )
    return findings


def проверить(root: Path) -> dict[str, object]:
    """Проверить final GlobalId type surface без legacy runtime modules."""

    root = root.resolve()
    violations: list[str] = []
    details: dict[str, object] = {}

    missing = [relative for relative in CANONICAL_MODULES if not (root / relative).is_file()]
    if missing:
        violations.append("отсутствуют canonical identity-модули: " + ", ".join(missing))

    active_retired = [relative for relative in RETIRED_ACTIVE_MODULES if (root / relative).exists()]
    details["retired_active_modules"] = active_retired
    if active_retired:
        violations.append("retired identity-модули остаются в active backend")

    canonical_legacy: dict[str, list[str]] = {}
    for relative in CANONICAL_MODULES:
        path = root / relative
        if not path.is_file():
            continue
        names = sorted(_defined_names(path) & LEGACY_TYPE_NAMES)
        canonical_legacy[relative] = names
        if names:
            violations.append(f"{relative} экспортирует legacy type names: {names}")
    details["legacy_имена_в_канонических_модулях"] = canonical_legacy

    backend_imports = _legacy_imports_in_backend(root)
    details["legacy_импорты_backend"] = backend_imports
    if backend_imports:
        violations.append("backend-код импортирует retired UserId type names")

    import app.identity as identity
    from app.identity import (
        GlobalId,
        GlobalIdDisplay,
        IdentityValueError,
        TelegramId,
        format_global_id,
        format_tg_id,
        global_id_from_database,
        global_id_to_database,
        tg_id_from_provider,
        tg_id_to_provider,
    )

    top_level_legacy = sorted(name for name in LEGACY_TYPE_NAMES if hasattr(identity, name))
    details["экспорты_legacy_верхнего_уровня"] = top_level_legacy
    if top_level_legacy:
        violations.append("app.identity сохраняет legacy exports")

    global_id = GlobalId(42)
    tg_id = TelegramId(42)
    if format_global_id(global_id) != GlobalIdDisplay("0000000042"):
        violations.append("GlobalId formatting contract нарушен")
    if global_id_from_database(42) != global_id or global_id_to_database(global_id) != 42:
        violations.append("GlobalId database boundary нарушена")
    if tg_id_from_provider(42) != tg_id or tg_id_to_provider(tg_id) != 42:
        violations.append("TelegramId provider boundary нарушена")
    if format_tg_id(tg_id) != "42":
        violations.append("TelegramId formatting contract нарушен")

    sample = IdentityValueError("ошибка", code="identity.test")
    if sample.as_dict() != {
        "поле": "identity",
        "код": "identity.test",
        "сообщение": "ошибка",
    }:
        violations.append("машинный payload identity-ошибки нестабилен")

    migrations = sorted(path.name for path in (root / "backend/migrations/versions").glob("*.py"))
    details["alembic_versions"] = migrations
    if migrations != ["0001_initial_release_schema.py"]:
        violations.append("active Alembic lineage должна содержать только release 0001")

    return {
        "схема_отчёта": "EFHC_BACKEND_GLOBAL_ID_TYPE_FINALIZATION_V2",
        "цикл": 1692,
        "версия": "v173.12",
        "пройдено": not violations,
        "нарушения": violations,
        "детали": details,
        "историческое_заполнение": True,
        "переключение_чтения": True,
        "переключение_финансового_владения": True,
        "legacy_modules_active": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Проверка final backend GlobalId contract")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root)
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
