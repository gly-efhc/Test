#!/usr/bin/env python3
"""Статически проверить Telegram adapter/session цикла 1619."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def проверить(root: Path = ROOT) -> dict[str, object]:
    """Вернуть fail-closed результат без импорта приложения."""

    adapter = (
        root / "backend/app/identity/telegram_init_data.py"
    ).read_text(encoding="utf-8")
    session = (
        root / "backend/app/identity/telegram_auth_session.py"
    ).read_text(encoding="utf-8")
    route = (
        root / "backend/app/routes/auth_telegram_routes.py"
    ).read_text(encoding="utf-8")
    нарушения: list[str] = []
    required = (
        "AuthProvider.TELEGRAM",
        "VerifiedIdentity",
        "PostgreSQLIdentityResolver",
        "resolve_in_transaction",
        "ProcessedExternalEvent",
        "AuthSessionService",
        "X-Telegram-Init-Data",
    )
    combined = "\n".join((adapter, session, route))
    for marker in required:
        if marker not in combined:
            нарушения.append(f"Отсутствует marker: {marker}")
    for forbidden in (
        "global_id = tg_id",
        "global_id=tg_id",
        "telegram" + "_id",
        "migration 0006",
        "auto_merge=True",
    ):
        if forbidden in combined:
            нарушения.append(f"Запрещён marker: {forbidden}")
    return {
        "схема": "EFHC_TELEGRAM_INIT_DATA_SESSION_GUARD_V1",
        "цикл": 1619,
        "статус": "PASS" if not нарушения else "FAIL",
        "нарушения": нарушения,
    }


def main() -> int:
    result = проверить()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["статус"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
