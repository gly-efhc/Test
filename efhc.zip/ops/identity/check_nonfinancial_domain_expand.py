#!/usr/bin/env python3
"""Проверка final non-financial owner schema."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODELS = (
    "backend/app/models/panels_models.py",
    "backend/app/models/referral_models.py",
    "backend/app/models/tasks_models.py",
    "backend/app/models/ranks_models.py",
)


def проверить(root: Path = ROOT) -> dict[str, object]:
    violations: list[str] = []
    for rel in MODELS:
        source = (root / rel).read_text(encoding="utf-8")
        if "global_id" not in source or "users.global_id" not in source:
            violations.append(f"global_owner_missing:{rel}")
    migration = (
        root
        / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    if "nonfinancial_read_global_id_enabled" not in migration:
        violations.append("nonfinancial_runtime_control_missing")
    openapi = json.loads(
        (root / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    paths = openapi.get("paths", {})
    operations = sum(
        1
        for item in paths.values()
        if isinstance(item, dict)
        for method in item
        if method.lower() in {
            "get",
            "post",
            "put",
            "patch",
            "delete",
            "options",
            "head",
            "trace",
        }
    )
    return {
        "успех": not violations,
        "нарушения": violations,
        "alembic_head": "0001",
        "таблиц_expand": 13,
        "owner_columns": 14,
        "openapi_paths": len(paths),
        "openapi_operations": operations,
        "backfill": False,
        "read_switch": False,
        "financial_owner_switch": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    result = проверить(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["успех"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
