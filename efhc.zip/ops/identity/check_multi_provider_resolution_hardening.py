"""Проверка hardening multi-provider resolution цикла 1702."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Final

from app.identity.auth_provider import AuthProvider
from app.identity.identity_resolver import (
    _identity_advisory_lock_key,
    build_identity_resolver_contract,
)
from app.models.auth_models import AuthSession
from app.models.identity_models import UserIdentity
from sqlalchemy import ForeignKeyConstraint, UniqueConstraint

ROOT: Final = Path(__file__).resolve().parents[2]
ACTIVE_PROVIDER_CANON: Final = (
    "telegram",
    "ton",
    "google",
    "apple",
    "facebook",
    "discord",
    "github",
    "mock",
)


def _constraint_columns(constraint: object) -> tuple[str, ...]:
    columns = getattr(constraint, "columns", ())
    return tuple(column.name for column in columns)


def build_report(root: Path = ROOT) -> dict[str, object]:
    """Проверить exact provider canon, collision и session-owner guards."""

    identity_table = UserIdentity.__table__
    session_table = AuthSession.__table__
    unique_sets = {
        _constraint_columns(item)
        for item in identity_table.constraints
        if isinstance(item, UniqueConstraint)
    }
    session_foreign_keys = {
        _constraint_columns(item): tuple(
            element.target_fullname for element in item.elements
        )
        for item in session_table.constraints
        if isinstance(item, ForeignKeyConstraint)
    }
    same_subject = "1702:shared-provider-subject"
    telegram_lock = _identity_advisory_lock_key(
        provider=AuthProvider.TELEGRAM,
        provider_tenant="default",
        provider_subject=same_subject,
    )
    ton_lock = _identity_advisory_lock_key(
        provider=AuthProvider.TON,
        provider_tenant="default",
        provider_subject=same_subject,
    )
    contract = build_identity_resolver_contract()
    hardening = contract.get("hardening_1702", {})
    telegram_source = (
        root / "backend/app/identity/telegram_auth_session.py"
    ).read_text(encoding="utf-8")
    ton_source = (
        root / "backend/app/identity/ton_account_registration.py"
    ).read_text(encoding="utf-8")
    session_source = (
        root / "backend/app/identity/auth_runtime_services.py"
    ).read_text(encoding="utf-8")

    checks = {
        "active_provider_canon": (
            tuple(item.value for item in AuthProvider)
            == ACTIVE_PROVIDER_CANON
        ),
        "provider_subject_unique": (
            ("provider", "provider_tenant", "provider_subject")
            in unique_sets
        ),
        "same_subject_different_provider_distinct": (
            telegram_lock != ton_lock
        ),
        "session_identity_global_fk": (
            session_foreign_keys.get(("identity_id", "global_id"))
            == (
                "efhc_core.user_identities.id",
                "efhc_core.user_identities.global_id",
            )
        ),
        "resolver_contract_one_pair_one_global": (
            hardening.get("one_pair_one_global_id") is True
        ),
        "resolver_contract_no_auto_merge": (
            hardening.get("automatic_account_merge") is False
        ),
        "resolver_contract_session_owner": (
            hardening.get("session_owner") == "global_id"
            and hardening.get("session_identity_owner_match_required")
            is True
        ),
        "telegram_collision_fail_closed": (
            "TG_IDENTITY_ACCOUNT_CONFLICT" in telegram_source
            and "IDENTITY_CONFLICT" in telegram_source
        ),
        "ton_collision_fail_closed": (
            "WALLET_IDENTITY_CONFLICT" in ton_source
            and "_validate_binding_owner" in ton_source
            and "IDENTITY_CONFLICT" in ton_source
        ),
        "session_runtime_matches_identity_global": (
            "UserIdentity.global_id\n                            == AuthSession.global_id"
            in session_source
        ),
    }
    failed = sorted(name for name, passed in checks.items() if not passed)
    return {
        "schema": "EFHC_MULTI_PROVIDER_RESOLUTION_HARDENING_V1",
        "version": "v173.27",
        "cycle": 1703,
        "status": "PASS" if not failed else "FAIL",
        "checks": checks,
        "failed": failed,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = build_report()
    payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
