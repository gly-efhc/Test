#!/usr/bin/env python3
"""Read-only PostgreSQL gate financial read switch цикла 1627."""

from __future__ import annotations

import argparse
import json
import os

from ops.identity.postgresql_financial_shadow_validation_gate import (
    collect as collect_shadow,
)

EXPECTED_REVISION = "0001"


def _psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def collect(database_url: str) -> dict[str, object]:
    """Проверить включённый financial read без изменения БД."""

    shadow = collect_shadow(database_url)
    try:
        import psycopg
    except ModuleNotFoundError as exc:
        raise RuntimeError("psycopg недоступен") from exc

    with (
        psycopg.connect(_psycopg_url(database_url)) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(
            "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ "
            "READ ONLY DEFERRABLE"
        )
        cursor.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        )
        revision_row = cursor.fetchone()
        if revision_row is None:
            raise RuntimeError("Alembic revision не найдена")
        revision = str(revision_row[0])
        cursor.execute(
            """
            SELECT
                financial_read_global_id_enabled,
                financial_read_rollback_ready,
                legacy_authoritative,
                dual_write_enabled,
                shadow_read_enabled,
                nonfinancial_read_global_id_enabled
            FROM efhc_core.identity_migration_control
            WHERE singleton_id = 1
            """
        )
        control = cursor.fetchone()
        if control is None:
            raise RuntimeError("identity migration control отсутствует")
        connection.rollback()

    telemetry = dict(shadow["telemetry"])
    hard_zero = all(
        int(telemetry[key]) == 0
        for key in (
            "fallback_rows",
            "mismatch_rows",
            "orphan_rows",
            "ambiguous_rows",
        )
    )
    control_ok = all(bool(value) for value in control)
    status = "PASS" if all(
        (
            revision == EXPECTED_REVISION,
            control_ok,
            hard_zero,
            shadow["monetary_discrepancy"] == "0.00000000",
            bool(shadow["precision_unchanged"]),
            bool(shadow["idempotency_unchanged"]),
            not shadow["missing_scopes"],
        )
    ) else "FAIL"

    return {
        "статус": status,
        "alembic_revision": revision,
        "financial_read_global_id_enabled": bool(control[0]),
        "financial_read_rollback_ready": bool(control[1]),
        "legacy_authoritative": bool(control[2]),
        "dual_write_enabled": bool(control[3]),
        "shadow_read_enabled": bool(control[4]),
        "nonfinancial_read_global_id_enabled": bool(control[5]),
        "telemetry": telemetry,
        "monetary_discrepancy": shadow["monetary_discrepancy"],
        "precision_unchanged": shadow["precision_unchanged"],
        "idempotency_unchanged": shadow["idempotency_unchanged"],
        "missing_scopes": shadow["missing_scopes"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database-url",
        default=(
            os.getenv("DATABASE_URL")
            or os.getenv("SYNC_DATABASE_URL")
        ),
    )
    parser.add_argument("--json-report")
    args = parser.parse_args()
    if not args.database_url:
        raise SystemExit("DATABASE_URL обязателен")
    report = collect(args.database_url)
    payload = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
    print(payload)
    if args.json_report:
        with open(args.json_report, "w", encoding="utf-8") as handle:
            handle.write(payload + "\n")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
