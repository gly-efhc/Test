#!/usr/bin/env python3
"""Проверить локальное закрытие фундаментального диапазона 1593–1600."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]

ОЖИДАЕМЫЕ_МИГРАЦИИ = (
    "0002_init.py",
    "0002_users_user_id_expand.py",
)
ОЖИДАЕМЫЕ_ЦИКЛЫ = tuple(range(1593, 1601))


def _текст(root: Path, relative: str) -> str:
    return (root / relative).read_text(encoding="utf-8")


def _json(root: Path, relative: str) -> dict[str, Any]:
    return json.loads(_текст(root, relative))


def проверить(root: Path = ROOT) -> dict[str, Any]:
    """Вернуть доказательный вердикт локального закрытия диапазона."""

    нарушения: list[str] = []
    предупреждения: list[str] = []

    миграции = tuple(
        sorted(
            path.name
            for path in (
                root / "backend/migrations/versions"
            ).glob("*.py")
        )
    )
    if миграции[: len(ОЖИДАЕМЫЕ_МИГРАЦИИ)] != ОЖИДАЕМЫЕ_МИГРАЦИИ:
        нарушения.append(
            "Повреждён historical prefix Alembic 0002→0002"
        )

    backfill = _текст(
        root,
        "backend/app/identity/user_id_backfill.py",
    )
    if "BACKFILL_APPLY_ENABLED: Final[bool] = False" not in backfill:
        нарушения.append("Historical backfill не заблокирован")

    model = _текст(root, "backend/app/models/user_models.py")
    for marker in (
        "id: Mapped[int] = mapped_column(",
        "global_id: Mapped[int | None] = mapped_column(",
        'user_id = synonym("global_id")',
        "tg_id: Mapped[int | None] = mapped_column(",
    ):
        if marker not in model:
            нарушения.append(
                "Не подтверждён ожидаемый переходный ORM-контракт"
            )
            break

    deps = _текст(root, "backend/app/deps.py")
    if "get_current_user_id" in deps:
        нарушения.append("Обнаружено преждевременное переключение auth")

    reconciliation = _json(
        root,
        "reports/generated/user_identity_reconciliation_v171_96.json",
    )
    if reconciliation.get("статус") != "БЛОКИРОВАНО_СРЕДОЙ":
        нарушения.append("Потерян честный статус PostgreSQL-шлюза")
    if reconciliation.get("историческое_заполнение_разрешено"):
        нарушения.append("Historical backfill ошибочно разрешён")
    if reconciliation.get("переключение_чтения_выполнено"):
        нарушения.append("Read switch ошибочно отмечен выполненным")

    update_policy = _json(root, "release_config/UPDATE_POLICY.json")
    supported = update_policy.get("supported_database_revisions") or []
    if "0002" not in supported:
        нарушения.append(
            "Historical revision 0002 должна поддерживаться"
        )
    historical_report = _json(
        root,
        "reports/generated/"
        "foundation_range_1593_1600_closure_v171_97.json",
    )
    if historical_report.get("миграционная_фаза") != "EXPAND":
        нарушения.append(
            "Historical phase цикла 1600 должна оставаться EXPAND"
        )

    обязательные_циклы = {
        1593: "WORK_CYCLE_1593_USER_ID_IDENTITY_AUDIT_GUARD.md",
        1594: "WORK_CYCLE_1594_USER_ID_CONTRACT_GUARDS.md",
        1595: "WORK_CYCLE_1595_USER_ID_VALUE_TYPE.md",
        1596: "WORK_CYCLE_1596_EXTERNAL_API_USER_ID_CONTRACT.md",
        1597: "WORK_CYCLE_1597_USERS_USER_ID_EXPAND.md",
        1598: "WORK_CYCLE_1598_USER_ID_LEGACY_ALIAS_HARNESS.md",
        1599: "WORK_CYCLE_1599_POSTGRESQL_RECONCILIATION_GATE.md",
        1600: "WORK_CYCLE_1600_FOUNDATION_RANGE_CLOSURE.md",
    }
    отсутствуют = [
        cycle
        for cycle, name in обязательные_циклы.items()
        if not (root / "docs/cycles" / name).is_file()
    ]
    if отсутствуют:
        нарушения.append(
            "Отсутствуют документы циклов: "
            + ", ".join(str(item) for item in отсутствуют)
        )

    if not (root / "CONTINUE_IN_NEW_CHAT.md").is_file():
        нарушения.append("Отсутствует handoff в новый чат")

    предупреждения.extend(
        (
            "Реальная PostgreSQL reconciliation не выполнена",
            "GitHub CI отложен до готовности основного пакета",
            "Historical backfill и runtime read switch запрещены",
        )
    )

    локально_закрыто = not нарушения
    return {
        "схема_отчёта": "EFHC_ЗАКРЫТИЕ_ДИАПАЗОНА_1593_1600_V1",
        "цикл": 1600,
        "исходный_архив": "EFHC_Bot_v171_96.zip",
        "целевой_архив": "EFHC_Bot_v171_97.zip",
        "диапазон": list(ОЖИДАЕМЫЕ_ЦИКЛЫ),
        "локально_закрыто": локально_закрыто,
        "PostgreSQL_доказательство_получено": False,
        "GitHub_CI_запущен": False,
        "основной_пакет_готов_к_GitHub_CI": False,
        "историческое_заполнение_разрешено": False,
        "переключение_чтения_разрешено": False,
        "финансовый_допуск": "0.00000000",
        "alembic_head": "0001",
        "миграционная_фаза": "EXPAND",
        "следующий_цикл": 1601,
        "следующая_версия": "v171.98",
        "нарушения": нарушения,
        "предупреждения": предупреждения,
        "решение": (
            "ФУНДАМЕНТАЛЬНЫЙ ДИАПАЗОН ЛОКАЛЬНО ЗАКРЫТ; "
            "POSTGRESQL GATE ПЕРЕНЕСЁН КАК ОБЯЗАТЕЛЬНАЯ БЛОКИРОВКА"
            if локально_закрыто
            else "ЗАКРЫТИЕ ДИАПАЗОНА ОТКЛОНЕНО"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["локально_закрыто"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
