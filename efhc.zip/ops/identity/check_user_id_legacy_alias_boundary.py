"""Fail-closed boundary for cycle-1598 alias and backfill harness."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA = "EFHC_USER_ID_LEGACY_ALIAS_BOUNDARY_V1"
SKIP_PARTS = {
    ".git",
    ".next",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    "node_modules",
}
ALLOWED = {"backend/app/models/user_models.py"}
SUFFIXES = {
    ".ini",
    ".js",
    ".json",
    ".jsx",
    ".mako",
    ".py",
    ".sql",
    ".ts",
    ".tsx",
    ".yaml",
    ".yml",
}


class _StripDocstrings(ast.NodeTransformer):
    @staticmethod
    def _remove(node: ast.AST) -> ast.AST:
        body = getattr(node, "body", None)
        if (
            isinstance(body, list)
            and body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            node.body = body[1:]  # type: ignore[attr-defined]
        return node

    def visit_Module(self, node: ast.Module) -> ast.AST:  # noqa: N802
        return self.generic_visit(self._remove(node))

    def visit_ClassDef(  # noqa: N802
        self,
        node: ast.ClassDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))

    def visit_FunctionDef(  # noqa: N802
        self,
        node: ast.FunctionDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))

    def visit_AsyncFunctionDef(  # noqa: N802
        self,
        node: ast.AsyncFunctionDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _digest(path: Path, kind: str) -> str:
    if kind == "python_ast_without_docstrings":
        tree = ast.parse(path.read_text(encoding="utf-8"))
        tree = _StripDocstrings().visit(tree)
        ast.fix_missing_locations(tree)
        payload = ast.dump(
            tree,
            annotate_fields=True,
            include_attributes=False,
        ).encode("utf-8")
        return _sha256(payload)
    return _sha256(path.read_bytes())


def _files(root: Path, roots: list[str]) -> set[str]:
    result: set[str] = set()
    for item in roots:
        base = root / item
        paths = [base] if base.is_file() else sorted(base.rglob("*"))
        for path in paths:
            if not path.is_file():
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            if path.suffix not in SUFFIXES:
                continue
            rel = path.relative_to(root).as_posix()
            if rel in ALLOWED:
                continue
            result.add(rel)
    return result


def check(root: Path, manifest_path: Path) -> dict[str, Any]:
    """Validate the exact no-read-switch boundary."""

    root = root.resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError("unsupported legacy alias boundary schema")

    expected = {
        item.get("path") or "/".join(item["path_parts"]): item
        for item in data["entries"]
    }
    actual = _files(root, data["protected_roots"])
    missing = sorted(set(expected) - actual)
    unexpected = sorted(actual - set(expected))
    changed: list[str] = []
    for rel, item in expected.items():
        path = root / rel
        if not path.is_file():
            continue
        expected_hash = item.get("sha256") or "".join(
            item["sha256_parts"]
        )
        if _digest(path, item["kind"]) != expected_hash:
            changed.append(rel)

    model = (root / "backend/app/models/user_models.py").read_text(
        encoding="utf-8"
    )
    alias = (root / "backend/app/identity/legacy_alias.py").read_text(
        encoding="utf-8"
    )
    harness = (
        root / "backend/app/identity/user_id_backfill.py"
    ).read_text(encoding="utf-8")
    migration = (
        root
        / "backend/migrations/versions/0002_users_user_id_expand.py"
    ).read_text(encoding="utf-8")
    deps = (root / "backend/app/deps.py").read_text(encoding="utf-8")

    required = (
        'legacy_runtime_id = synonym("id")',
        "LEGACY: migration/reconciliation alias only",
        'active_alias="User.legacy_runtime_id"',
        'active_target="User.id"',
        'future_alias="User.id"',
        'future_target="User.user_id"',
        "runtime_read_switch=False",
        "BACKFILL_APPLY_ENABLED: Final[bool] = False",
        "NULL user_id -> users.id",
        "SET user_id = id",
        "tg_id_used_for_mapping",
    )
    renderer = (
        root / "ops/identity/render_user_id_backfill_harness.py"
    ).read_text(encoding="utf-8")
    joined = "\n".join((model, alias, harness, renderer))
    contract_errors = [
        token for token in required if token not in joined
    ]

    forbidden = (
        'legacy_runtime_id = synonym("user_id")',
        'id = synonym("user_id")',
        "tg_id: Mapped[int | None]",
        "get_current_user_id",
        "class AuthContext:\n    user_id",
        "BACKFILL_APPLY_ENABLED: Final[bool] = True",
        "postgres_user_id_backfill_apply_sql()",
    )
    forbidden_sources = "\n".join((model, deps, migration))
    forbidden_found = [
        token for token in forbidden if token in forbidden_sources
    ]

    versions = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
    )
    expected_versions = [
        "0001_init.py",
        "0002_users_user_id_expand.py",
    ]

    errors: list[str] = []
    if missing:
        errors.append(f"protected files missing: {missing}")
    if unexpected:
        errors.append(f"new protected files: {unexpected}")
    if changed:
        errors.append(f"protected semantics changed: {changed}")
    if contract_errors:
        errors.append(
            f"alias/harness contract missing: {contract_errors}"
        )
    if forbidden_found:
        errors.append(f"forbidden read switch found: {forbidden_found}")
    if versions != expected_versions:
        errors.append(f"unexpected migration chain: {versions}")

    return {
        "schema": "EFHC_USER_ID_LEGACY_ALIAS_BOUNDARY_RESULT_V1",
        "cycle": data["cycle"],
        "source_head": data["source_head"],
        "target_head": data["target_head"],
        "protected_file_count": len(expected),
        "missing": missing,
        "unexpected": unexpected,
        "semantic_changes": changed,
        "contract_errors": contract_errors,
        "forbidden_found": forbidden_found,
        "migration_files": versions,
        "runtime_read_switch": False,
        "backfill_executed": False,
        "passed": not errors,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path(
            "ops/identity/user_id_legacy_alias_patch_boundary.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root, args.manifest)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
