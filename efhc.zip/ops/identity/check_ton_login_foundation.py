"""Статический guard TON login foundation цикла 1615."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def check(root: Path = ROOT) -> dict[str, object]:
    """Проверить точные архитектурные markers без импорта приложения."""

    route = (root / "backend/app/routes/auth_ton_routes.py").read_text(
        encoding="utf-8"
    )
    challenge = (
        root / "backend/app/identity/ton_login_challenge.py"
    ).read_text(encoding="utf-8")
    resolver = (
        root / "backend/app/identity/ton_wallet_id_resolver.py"
    ).read_text(encoding="utf-8")
    proof = (
        root / "backend/app/services/tonconnect_proof_service.py"
    ).read_text(encoding="utf-8")
    failures: list[str] = []
    checks = {
        "endpoint": (
            'prefix="/auth/ton"' in route
            and '"/challenge"' in route
        ),
        "без_telegram_dependency": (
            "get_current_tg_id" not in route
            and "TelegramWebApp" not in route
        ),
        "provider": "AuthProvider.TON" in challenge,
        "purpose": '"ton.login"' in challenge,
        "hashed_storage": "AuthChallengeService" in challenge,
        "canonical_resolver": "parse_ton_address" in resolver,
        "shared_parser": "parse_canonical_ton_address" in proof,
        "нет_дублирующего_raw_parser": (
            "def _parse_raw_address" not in proof
        ),
        "нет_migration_0005": not any(
            (root / "backend/migrations/versions").glob("0005*.py")
        ),
    }
    for name, passed in checks.items():
        if not passed:
            failures.append(name)
    return {
        "схема": "EFHC_TON_LOGIN_FOUNDATION_CHECK_V1",
        "цикл": 1615,
        "пройдено": not failures,
        "проверки": checks,
        "нарушения": failures,
    }


def main() -> int:
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
