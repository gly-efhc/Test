#!/usr/bin/env python3
"""Проверка полной классификации документального identity-слоя."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ACTIVE_MARKERS = ("EFHC_GLOBAL_IDENTITY_CANON_V2", "EFHC_GLOBAL_IDENTITY_CANON_V3")
HISTORICAL_MARKER = "EFHC_IDENTITY_HISTORICAL_NOTICE_V2"
IDENTITY_RE = re.compile(
    r"\b(?:global_id|tg_id|user_id|provider\s*\+\s*subject)\b",
    re.I,
)
SCOPES = (
    "docs/",
    "release_docs/",
    "references/",
    "ops/",
    "skills/",
    "reports/generated/",
)
REQUIRED = (
    "docs/SSOT/GLOBAL_IDENTITY_SSOT.md",
    "docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md",
    "docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md",
    "docs/SSOT/IDENTITY_GLOSSARY.md",
)
CANON_MARKERS = (
    "global_id",
    "tg_id",
    "provider + subject",
    "business runtime",
)
FORBIDDEN_ACTIVE_PHRASES = (
    "tg_id — главный персональный",
    "tg_id — главный идентификатор",
    "tg_id является главным",
    "tg_id — единственный внутренний",
    "global_id только планируется",
    "global_id является synonym",
    "users.user_id является текущим owner",
    "business objects могут принадлежать tg_id",
    "migration 0002 является текущей",
)


def _document_paths() -> list[Path]:
    paths: list[Path] = []
    for path in ROOT.rglob("*.md"):
        relative = path.relative_to(ROOT).as_posix()
        if any(
            part in {".git", "node_modules", ".next"}
            for part in path.parts
        ) or relative.startswith("docs/history/"):
            continue
        if path.parent == ROOT or relative.startswith(SCOPES):
            paths.append(path)
    return sorted(paths)


def main() -> int:
    errors: list[str] = []
    active_count = 0
    historical_count = 0

    for relative in REQUIRED:
        text = (ROOT / relative).read_text(encoding="utf-8")
        for marker in CANON_MARKERS:
            if marker not in text:
                errors.append(
                    f"{relative}: missing canonical marker {marker!r}"
                )

    for path in _document_paths():
        relative = path.relative_to(ROOT).as_posix()
        text = path.read_text(
            encoding="utf-8",
            errors="replace",
        )
        if not IDENTITY_RE.search(text):
            continue
        head = "\n".join(text.splitlines()[:24])
        is_historical = HISTORICAL_MARKER in head
        is_active = any(marker in head for marker in ACTIVE_MARKERS)
        if is_historical:
            historical_count += 1
        elif is_active:
            active_count += 1
        else:
            errors.append(
                f"{relative}: identity document is not classified"
            )
            continue

        if is_historical:
            if "GLOBAL_IDENTITY_SSOT.md" not in head:
                errors.append(
                    f"{relative}: historical notice has no current SSOT"
                )
            continue

        if re.search(r"global_id\s*=\s*global_id", text):
            errors.append(
                f"{relative}: corrupted tautology global_id=global_id"
            )
        lowered = text.lower()
        for phrase in FORBIDDEN_ACTIVE_PHRASES:
            if phrase.lower() in lowered:
                errors.append(
                    f"{relative}: forbidden active phrase {phrase!r}"
                )

    if errors:
        print("\n".join(errors))
        return 1
    print(
        "DOCUMENT_IDENTITY_CANON: PASS; "
        f"active={active_count}; historical={historical_count}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
