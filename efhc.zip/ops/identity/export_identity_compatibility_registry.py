"""Экспорт единого compatibility registry идентификаторов."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.identity.compatibility_registry import (
    build_identity_compatibility_registry,
)


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Экспорт semantic allowlist и compatibility "
            "registry."
        )
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = json.dumps(
        build_identity_compatibility_registry(),
        ensure_ascii=False,
        indent=2,
    ) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
