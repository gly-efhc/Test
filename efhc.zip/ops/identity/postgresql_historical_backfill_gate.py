#!/usr/bin/env python3
"""Проверить результат historical backfill цикла 1623.

Gate только читает реальный PostgreSQL. Он не выполняет backfill,
не переключает read path и не исправляет данные. PASS требует:

- Alembic revision ``0008``;
- ``users.user_id`` заполнен и уникален;
- все доказуемые legacy owner mappings разрешены;
- sequence продолжает диапазон GlobalId без коллизии;
- monetary ownership discrepancy строго равен ``0.00000000``.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from decimal import Decimal
from typing import Final

EXPECTED_REVISION: Final[str] = "0008"
MAX_GLOBAL_ID: Final[int] = 9_999_999_999
ZERO_MONEY: Final[str] = "0.00000000"

# Схема, таблица, legacy source и shadow owner.
DIRECT_SPECS: Final[tuple[tuple[str, str, str, str], ...]] = (
    ("efhc_core", "panels", "tg_id", "global_id"),
    ("efhc_core", "panels_archive", "tg_id", "global_id"),
    (
        "efhc_core",
        "referral_links",
        "inviter_tg_id",
        "inviter_global_id",
    ),
    (
        "efhc_core",
        "referral_links",
        "invitee_tg_id",
        "invitee_global_id",
    ),
    (
        "efhc_core",
        "referral_codes",
        "inviter_tg_id",
        "inviter_global_id",
    ),
    (
        "efhc_core",
        "referral_bonus_ledger",
        "tg_id",
        "global_id",
    ),
    ("efhc_core", "task_submissions", "tg_id", "global_id"),
    (
        "efhc_core",
        "task_submissions",
        "moderator_tg_id",
        "moderator_global_id",
    ),
    (
        "efhc_core",
        "user_tasks_status",
        "tg_id",
        "global_id",
    ),
    ("efhc_core", "task_bonus_log", "tg_id", "global_id"),
    ("efhc_core", "task_complete_lock", "tg_id", "global_id"),
    ("efhc_core", "ranks_snapshots", "tg_id", "global_id"),
    ("efhc_core", "ranks_top_cache", "tg_id", "global_id"),
    (
        "efhc_core",
        "ranks_user_snapshots",
        "tg_id",
        "global_id",
    ),
    (
        "efhc_core",
        "efhc_transfers_log",
        "tg_id",
        "global_id",
    ),
    ("efhc_core", "payment_intents", "tg_id", "global_id"),
    ("efhc_core", "withdraw_requests", "tg_id", "global_id"),
    ("efhc_core", "withdrawals", "tg_id", "global_id"),
    (
        "efhc_core",
        "withdraw_outcome_events",
        "tg_id",
        "global_id",
    ),
    ("efhc_core", "wallet_bindings", "tg_id", "global_id"),
    (
        "efhc_core",
        "wallet_connect_idempotency",
        "tg_id",
        "global_id",
    ),
    (
        "efhc_core",
        "wallet_proof_token_uses",
        "tg_id",
        "global_id",
    ),
    ("efhc_core", "tx_hash_locks", "tg_id", "global_id"),
    (
        "efhc_core",
        "ton_inbox_logs",
        "parsed_tg_id",
        "resolved_global_id",
    ),
    ("efhc_admin", "admin_whitelist", "tg_id", "global_id"),
    (
        "efhc_admin",
        "admin_whitelist",
        "added_by_tg_id",
        "added_by_global_id",
    ),
    (
        "efhc_admin",
        "admin_role",
        "granted_by_tg_id",
        "granted_by_global_id",
    ),
)

MONEY_SPECS: Final[tuple[tuple[str, str, str, str, str], ...]] = (
    (
        "efhc_core",
        "efhc_transfers_log",
        "tg_id",
        "global_id",
        "amount",
    ),
    (
        "efhc_core",
        "payment_intents",
        "tg_id",
        "global_id",
        "efhc_amount_d8",
    ),
    (
        "efhc_core",
        "withdraw_requests",
        "tg_id",
        "global_id",
        "amount",
    ),
    (
        "efhc_core",
        "withdrawals",
        "tg_id",
        "global_id",
        "amount_efhc",
    ),
    (
        "efhc_core",
        "referral_bonus_ledger",
        "tg_id",
        "global_id",
        "amount_efhc",
    ),
    (
        "efhc_core",
        "task_submissions",
        "tg_id",
        "global_id",
        "bonus_amount_efhc",
    ),
    (
        "efhc_core",
        "task_bonus_log",
        "tg_id",
        "global_id",
        "amount_bonus_efhc",
    ),
)


def _psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _scalar(cursor, sql: str) -> object:
    cursor.execute(sql)
    row = cursor.fetchone()
    if row is None:
        raise RuntimeError("PostgreSQL не вернул обязательную метрику")
    return row[0]


def _direct_unresolved(cursor) -> tuple[int, dict[str, int]]:
    details: dict[str, int] = {}
    total = 0
    for schema, table, source, target in DIRECT_SPECS:
        relation = f"{schema}.{table}"
        sql = (
            f"SELECT count(*) FROM {relation} d "
            "LEFT JOIN efhc_core.users u "
            f"ON u.tg_id = d.{source} "
            f"WHERE d.{source} IS NOT NULL "
            "AND (u.user_id IS NULL "
            f"OR d.{target} IS DISTINCT FROM u.user_id)"
        )
        count = int(_scalar(cursor, sql))
        details[f"{relation}.{target}"] = count
        total += count
    return total, details


def _scheduler_unresolved(cursor) -> int:
    sql = """
SELECT count(*)
FROM efhc_core.scheduler_task_log s
LEFT JOIN efhc_core.users u
  ON CASE
       WHEN (s.payload ->> 'tg_id') ~ '^[0-9]+$'
       THEN u.tg_id::text = s.payload ->> 'tg_id'
       ELSE false
     END
WHERE s.task_name = 'resync_user_energy'
  AND (
      s.payload IS NULL
      OR (s.payload ->> 'tg_id') IS NULL
      OR (s.payload ->> 'tg_id') !~ '^[0-9]+$'
      OR u.user_id IS NULL
      OR s.global_id IS DISTINCT FROM u.user_id
  )
"""
    return int(_scalar(cursor, sql))


def _admin_action_unresolved(cursor) -> int:
    sql = """
SELECT count(*)
FROM efhc_admin.admin_action_log l
LEFT JOIN efhc_admin.admin_whitelist a ON a.id = l.admin_id
LEFT JOIN efhc_core.users u ON u.tg_id = l.admin_id
WHERE l.admin_id IS NOT NULL
  AND (
      (a.global_id IS NOT NULL AND u.user_id IS NOT NULL
       AND a.global_id <> u.user_id)
      OR coalesce(a.global_id, u.user_id) IS NULL
      OR l.actor_global_id IS DISTINCT FROM
         coalesce(a.global_id, u.user_id)
  )
"""
    return int(_scalar(cursor, sql))


def _admin_idempotency_unresolved(cursor) -> int:
    sql = """
SELECT count(*)
FROM efhc_admin.idempotency_key i
LEFT JOIN efhc_admin.admin_whitelist a ON a.id = i.admin_id
WHERE i.admin_id IS NOT NULL
  AND (
      a.global_id IS NULL
      OR i.global_id IS DISTINCT FROM a.global_id
  )
"""
    return int(_scalar(cursor, sql))


def _money_discrepancy(cursor) -> Decimal:
    discrepancy = Decimal("0")
    for schema, table, source, target, amount in MONEY_SPECS:
        relation = f"{schema}.{table}"
        sql = (
            "SELECT "
            f"coalesce(sum(d.{amount}), 0)::numeric, "
            "coalesce(sum(CASE "
            f"WHEN d.{target} = u.user_id THEN d.{amount} "
            "ELSE 0 END), 0)::numeric "
            f"FROM {relation} d "
            "LEFT JOIN efhc_core.users u "
            f"ON u.tg_id = d.{source} "
            f"WHERE d.{source} IS NOT NULL"
        )
        cursor.execute(sql)
        row = cursor.fetchone()
        if row is None:
            raise RuntimeError("Не получена финансовая метрика")
        legacy = Decimal(row[0])
        shadow = Decimal(row[1])
        discrepancy += abs(legacy - shadow)
    return discrepancy


def collect(database_url: str) -> dict[str, object]:
    """Снять согласованный read-only reconciliation snapshot."""

    try:
        import psycopg
    except ModuleNotFoundError as exc:
        raise RuntimeError("psycopg недоступен") from exc

    with (
        psycopg.connect(_psycopg_url(database_url)) as connection,
        connection.cursor() as cursor,
    ):
            cursor.execute(
                "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ "
                "READ ONLY DEFERRABLE"
            )
            try:
                revision = str(
                    _scalar(
                        cursor,
                        "SELECT version_num FROM "
                        "efhc_core.alembic_version",
                    )
                )
                null_users = int(
                    _scalar(
                        cursor,
                        "SELECT count(*) FROM efhc_core.users "
                        "WHERE user_id IS NULL",
                    )
                )
                duplicates = int(
                    _scalar(
                        cursor,
                        "SELECT count(*) FROM ("
                        "SELECT user_id FROM efhc_core.users "
                        "GROUP BY user_id HAVING count(*) > 1"
                        ") q",
                    )
                )
                out_of_range = int(
                    _scalar(
                        cursor,
                        "SELECT count(*) FROM efhc_core.users "
                        "WHERE user_id < 1 OR user_id > 9999999999",
                    )
                )
                maximum = int(
                    _scalar(
                        cursor,
                        "SELECT coalesce(max(user_id), 0) "
                        "FROM efhc_core.users",
                    )
                )
                cursor.execute(
                    "SELECT last_value, is_called FROM "
                    "efhc_core.users_user_id_seq"
                )
                sequence_row = cursor.fetchone()
                if sequence_row is None:
                    raise RuntimeError("Не прочитана users_user_id_seq")
                last_value = int(sequence_row[0])
                is_called = bool(sequence_row[1])
                next_candidate = (
                    last_value + 1 if is_called else last_value
                )

                direct_total, direct_details = _direct_unresolved(
                    cursor
                )
                scheduler = _scheduler_unresolved(cursor)
                admin_action = _admin_action_unresolved(cursor)
                admin_idempotency = _admin_idempotency_unresolved(
                    cursor
                )
                unresolved = (
                    direct_total
                    + scheduler
                    + admin_action
                    + admin_idempotency
                )
                money = _money_discrepancy(cursor)
                no_inference = {
                    "unmatched_incoming.resolved_global_id": int(
                        _scalar(
                            cursor,
                            "SELECT count(*) FROM "
                            "efhc_core.unmatched_incoming "
                            "WHERE resolved_global_id IS NOT NULL",
                        )
                    ),
                    "processed_external_events.resolved_global_id": int(
                        _scalar(
                            cursor,
                            "SELECT count(*) FROM "
                            "efhc_core.processed_external_events "
                            "WHERE resolved_global_id IS NOT NULL",
                        )
                    ),
                }
            finally:
                cursor.execute("ROLLBACK")

    sequence_ok = (
        maximum < MAX_GLOBAL_ID
        and next_candidate > maximum
        and next_candidate <= MAX_GLOBAL_ID
    )
    money_text = ZERO_MONEY if money == 0 else format(money, "f")
    passed = (
        revision == EXPECTED_REVISION
        and null_users == 0
        and duplicates == 0
        and out_of_range == 0
        and unresolved == 0
        and sequence_ok
        and money_text == ZERO_MONEY
    )
    return {
        "схема": "EFHC_CYCLE_1623_RECONCILIATION_V1",
        "статус": "PASS" if passed else "FAIL",
        "alembic_revision": revision,
        "users_global_id_null": null_users,
        "users_global_id_duplicates": duplicates,
        "users_global_id_out_of_range": out_of_range,
        "maximum_global_id": maximum,
        "sequence_next_candidate": next_candidate,
        "sequence_ok": sequence_ok,
        "unresolved_rows": unresolved,
        "unresolved_direct": direct_details,
        "unresolved_scheduler": scheduler,
        "unresolved_admin_action": admin_action,
        "unresolved_admin_idempotency": admin_idempotency,
        "monetary_discrepancy": money_text,
        "no_inference_informational": no_inference,
        "legacy_authoritative": True,
        "read_switch": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database-url",
        default=os.getenv("DATABASE_URL"),
    )
    parser.add_argument("--output")
    args = parser.parse_args()
    if not args.database_url:
        print("PostgreSQL URL не задан", file=sys.stderr)
        return 3
    try:
        report = collect(args.database_url)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 3
    except Exception as exc:
        print(f"Ошибка reconciliation gate: {exc}", file=sys.stderr)
        return 4
    payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(payload)
    print(payload, end="")
    return 0 if report["статус"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
