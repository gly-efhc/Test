"""Verify the isolated cycle-1596 UserId API contract boundary."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA = "EFHC_USER_ID_API_CONTRACT_PATCH_BOUNDARY_V1"
SKIP_PARTS = {
    ".git",
    ".next",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    "node_modules",
}
PROTECTED_SUFFIXES = {
    ".ini",
    ".js",
    ".json",
    ".jsx",
    ".mako",
    ".py",
    ".sql",
    ".ts",
    ".tsx",
    ".yaml",
    ".yml",
}
API_SYMBOLS = {
    "PydanticUserId",
    "UserIdRequest",
    "UserIdResponse",
}


class _StripDocstrings(ast.NodeTransformer):
    @staticmethod
    def _remove(node: ast.AST) -> ast.AST:
        body = getattr(node, "body", None)
        if (
            isinstance(body, list)
            and body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            node.body = body[1:]  # type: ignore[attr-defined]
        return node

    def visit_Module(self, node: ast.Module) -> ast.AST:  # noqa: N802
        return self.generic_visit(self._remove(node))

    def visit_ClassDef(  # noqa: N802
        self,
        node: ast.ClassDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))

    def visit_FunctionDef(  # noqa: N802
        self,
        node: ast.FunctionDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))

    def visit_AsyncFunctionDef(  # noqa: N802
        self,
        node: ast.AsyncFunctionDef,
    ) -> ast.AST:
        return self.generic_visit(self._remove(node))


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _semantic_sha256(path: Path, kind: str) -> str:
    if kind == "python_ast_without_docstrings":
        tree = ast.parse(path.read_text(encoding="utf-8"))
        tree = _StripDocstrings().visit(tree)
        ast.fix_missing_locations(tree)
        payload = ast.dump(
            tree,
            annotate_fields=True,
            include_attributes=False,
        ).encode("utf-8")
        return _sha256(payload)
    if kind == "exact_bytes":
        return _sha256(path.read_bytes())
    raise ValueError(f"unsupported boundary hash kind: {kind}")


def _protected_files(root: Path, roots: list[str]) -> set[str]:
    result: set[str] = set()
    for relative_root in roots:
        base = root / relative_root
        paths = [base] if base.is_file() else sorted(base.rglob("*"))
        for path in paths:
            if not path.is_file():
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            if path.suffix not in PROTECTED_SUFFIXES:
                continue
            result.add(path.relative_to(root).as_posix())
    return result


def _premature_api_imports(root: Path) -> list[str]:
    offenders: list[str] = []
    base = root / "backend/app"
    for path in sorted(base.rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        if relative.startswith("backend/app/identity/"):
            continue
        if set(path.parts) & SKIP_PARTS:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                names = {alias.name for alias in node.names}
                if names & API_SYMBOLS:
                    offenders.append(f"{relative}:{node.lineno}")
            elif isinstance(node, ast.Import):
                if any(
                    alias.name == "app.identity.api_contract"
                    for alias in node.names
                ):
                    offenders.append(f"{relative}:{node.lineno}")
    return offenders


def check(root: Path, manifest_path: Path) -> dict[str, Any]:
    root = root.resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError("unsupported UserId API boundary schema")

    expected = {
        item.get("path") or "/".join(item["path_parts"]): item
        for item in data["entries"]
    }
    actual = _protected_files(root, data["protected_roots"])
    missing = sorted(set(expected) - actual)
    unexpected = sorted(actual - set(expected))
    changed: list[str] = []
    for relative, item in expected.items():
        path = root / relative
        if not path.is_file():
            continue
        current = _semantic_sha256(path, item["kind"])
        expected_hash = item.get("sha256") or "".join(
            item["sha256_parts"]
        )
        if current != expected_hash:
            changed.append(relative)

    imports = _premature_api_imports(root)
    required_files = {
        "backend/app/identity/api_contract.py",
        "backend/app/identity/types.py",
        "backend/app/identity/__init__.py",
    }
    missing_contract_files = sorted(
        relative
        for relative in required_files
        if not (root / relative).is_file()
    )

    errors: list[str] = []
    if missing:
        errors.append(f"protected files missing: {missing}")
    if unexpected:
        errors.append(f"new protected files: {unexpected}")
    if changed:
        errors.append(f"protected semantics changed: {changed}")
    if imports:
        errors.append(f"premature API contract imports: {imports}")
    if missing_contract_files:
        errors.append(
            "required isolated contract files missing: "
            f"{missing_contract_files}"
        )

    return {
        "schema": "EFHC_USER_ID_API_BOUNDARY_RESULT_V1",
        "cycle": data["cycle"],
        "source_head": data["source_head"],
        "target_head": data["target_head"],
        "protected_file_count": len(expected),
        "missing": missing,
        "unexpected": unexpected,
        "semantic_changes": changed,
        "premature_api_imports": imports,
        "missing_contract_files": missing_contract_files,
        "passed": not errors,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path(
            "ops/identity/"
            "user_id_api_contract_patch_boundary.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root, args.manifest)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
