#!/usr/bin/env python3
"""Проверка final financial/admin/external owner schema."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODELS = (
    "backend/app/models/transactions_models.py",
    "backend/app/models/payment_intents_models.py",
    "backend/app/models/withdraw_models.py",
    "backend/app/models/wallets_models.py",
    "backend/app/models/ton_logs_models.py",
    "backend/app/models/admin_models.py",
)


def проверить(root: Path = ROOT) -> dict[str, object]:
    violations: list[str] = []
    for rel in MODELS:
        source = (root / rel).read_text(encoding="utf-8")
        if "global_id" not in source or "users.global_id" not in source:
            violations.append(f"global_owner_missing:{rel}")
    migration = (
        root
        / "backend/migrations/versions/0001_initial_release_schema.py"
    ).read_text(encoding="utf-8")
    for forbidden in (
        "SET main_balance =",
        "SET bonus_balance =",
        "SET amount =",
        "SET amount_efhc =",
    ):
        if forbidden in migration:
            violations.append(
                f"financial_rewrite_forbidden:{forbidden}"
            )
    openapi = json.loads(
        (root / "backend/openapi/openapi.json").read_text(
            encoding="utf-8"
        )
    )
    paths = openapi.get("paths", {})
    operations = sum(
        1
        for item in paths.values()
        if isinstance(item, dict)
        for method in item
        if method.lower() in {
            "get",
            "post",
            "put",
            "patch",
            "delete",
            "options",
            "head",
            "trace",
        }
    )
    return {
        "успех": not violations,
        "нарушения": violations,
        "alembic_head": "0001",
        "таблиц_expand": 16,
        "owner_actor_columns": 17,
        "openapi_paths": len(paths),
        "openapi_operations": operations,
        "backfill": False,
        "dual_write": False,
        "read_switch": False,
        "financial_owner_switch": False,
        "financial_value_rewrite": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    result = проверить(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["успех"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
