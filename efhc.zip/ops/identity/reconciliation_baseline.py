#!/usr/bin/env python3
"""Совместимый entrypoint Global ID PostgreSQL reconciliation.

Исторический скрипт цикла 1598 заменён делегированием каноническому
read-only gate цикла 1603. Никаких offline или SQLite-подмен нет.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from ops.identity.postgresql_reconciliation_gate import capture


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Снять Global ID reconciliation baseline"
    )
    parser.add_argument(
        "--database-url",
        default=(
            os.getenv("PSYCOPG_URL")
            or os.getenv("SYNC_DATABASE_URL")
            or os.getenv("DATABASE_URL")
        ),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cycle", type=int, default=1603)
    parser.add_argument(
        "--source-head",
        default="EFHC_Bot_v171_99.zip",
    )
    parser.add_argument(
        "--target-head",
        default="EFHC_Bot_v172_00.zip",
    )
    args = parser.parse_args()
    report, exit_code = capture(
        args.database_url,
        cycle=args.cycle,
        source_head=args.source_head,
        target_head=args.target_head,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
