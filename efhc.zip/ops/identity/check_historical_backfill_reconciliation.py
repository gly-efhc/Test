#!/usr/bin/env python3
"""Статический guard historical backfill/reconciliation цикла 1623."""

from __future__ import annotations

import importlib.util
import json
import re
from pathlib import Path
from types import ModuleType
from typing import Any

EXPECTED_DIRECT = 27
EXPECTED_NO_INFERENCE = 2


def _load_migration(path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location("efhc_0008", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Не удалось загрузить migration 0008")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check(root: Path) -> dict[str, Any]:
    path = root / (
        "backend/migrations/versions/"
        "0008_historical_global_id_backfill.py"
    )
    source = path.read_text(encoding="utf-8")
    module = _load_migration(path)
    errors: list[str] = []

    if module.revision != "0008":
        errors.append("revision 0008 не подтверждена")
    if module.down_revision != "0007":
        errors.append("parent 0007 не подтверждён")
    if len(module.TG_BACKFILL_SPECS) != EXPECTED_DIRECT:
        errors.append("неверное число direct backfill mappings")
    if len(module.NO_INFERENCE_TARGETS) != EXPECTED_NO_INFERENCE:
        errors.append("неверное число no-inference targets")

    required = (
        "LOCK TABLE",
        "UPDATE {CORE}.users SET user_id = id",
        "users_user_id_seq",
        "_efhc_1623_before",
        "_efhc_1623_after",
        "monetary discrepancy is not 0.00000000",
        "unresolved=0",
        "legacy remains owner",
    )
    for marker in required:
        if marker not in source:
            errors.append(f"отсутствует marker: {marker}")

    forbidden_patterns = (
        r"UPDATE\s+efhc_core\.users\s+SET\s+main_balance",
        r"UPDATE\s+efhc_core\.users\s+SET\s+bonus_balance",
        r"UPDATE\s+efhc_core\.bank_balance\s+SET\s+balance",
        r"UPDATE\s+efhc_core\.efhc_transfers_log\s+SET\s+amount",
        r"ADD\s+COLUMN\s+global_id",
    )
    for pattern in forbidden_patterns:
        if re.search(pattern, source, flags=re.IGNORECASE):
            errors.append(f"запрещённая операция: {pattern}")

    if "unmatched_incoming" not in source:
        errors.append("нет no-inference marker unmatched_incoming")
    if "processed_external_events" not in source:
        errors.append(
            "нет no-inference marker processed_external_events"
        )

    return {
        "схема": "EFHC_CYCLE_1623_STATIC_GUARD_V1",
        "статус": "PASS" if not errors else "FAIL",
        "revision": module.revision,
        "down_revision": module.down_revision,
        "direct_mappings": len(module.TG_BACKFILL_SPECS),
        "no_inference_targets": len(module.NO_INFERENCE_TARGETS),
        "financial_value_rewrite": False,
        "read_switch": False,
        "dual_write": False,
        "physical_users_global_id": False,
        "errors": errors,
    }


def main() -> int:
    root = Path(__file__).resolve().parents[2]
    report = check(root)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["статус"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
