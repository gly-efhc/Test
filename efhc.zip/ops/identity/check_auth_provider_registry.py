"""Fail-closed guard auth provider registry foundation цикла 1609."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from app.identity import (
    AuthProvider,
    AuthProviderFeatureFlags,
    ProviderAvailability,
    build_auth_provider_registry_contract,
    build_default_provider_registry,
)

PROVIDER_MODULES = (
    "backend/app/identity/auth_errors.py",
    "backend/app/identity/auth_provider.py",
    "backend/app/identity/verified_identity.py",
    "backend/app/identity/provider_registry.py",
)
FORBIDDEN_IMPORT_PREFIXES = (
    "app.models",
    "app.services",
    "app.routes",
    "sqlalchemy",
    "fastapi",
    "alembic",
)


def _imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module)
    return imports


def evaluate(root: Path) -> dict[str, object]:
    """Проверить registry, contract, imports и migration boundary."""

    failures: list[str] = []
    contract_path = (
        root / "contracts/identity/auth_provider_registry_v1.json"
    )
    expected = build_auth_provider_registry_contract()
    try:
        actual = json.loads(contract_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        actual = None
    if actual != expected:
        failures.append("JSON contract не совпадает с registry code")

    import_inventory: dict[str, list[str]] = {}
    for relative in PROVIDER_MODULES:
        imports = sorted(_imports(root / relative))
        import_inventory[relative] = imports
        if any(
            item.startswith(FORBIDDEN_IMPORT_PREFIXES)
            for item in imports
        ):
            failures.append(
                "Provider module импортирует domain/DDL слой: "
                f"{relative}"
            )

    flags = AuthProviderFeatureFlags.from_mappings(
        environment="local"
    )
    registry = build_default_provider_registry(flags)
    snapshot = registry.snapshot()
    if not snapshot:
        failures.append("Default provider registry пуст")
    if any(item.enabled for item in snapshot):
        failures.append("Unfinished provider включён по умолчанию")
    if any(item.provider is AuthProvider.MOCK for item in snapshot):
        failures.append("Mock provider попал в production registry")
    if any(
        item.availability is not ProviderAvailability.DISABLED
        for item in snapshot
    ):
        failures.append("Default provider state не является disabled")

    config = Config(str(root / "backend/alembic.ini"))
    config.set_main_option(
        "script_location",
        str(root / "backend/migrations"),
    )
    script = ScriptDirectory.from_config(config)
    heads = script.get_heads()
    revisions = {item.revision for item in script.walk_revisions()}
    if heads != ["0001"]:
        failures.append(f"Alembic head не равен единственному 0001: {heads}")
    if revisions != {"0001"}:
        failures.append(
            "Active Alembic revisions должны содержать только 0001: "
            f"{sorted(revisions)}"
        )

    return {
        "схема": "EFHC_AUTH_PROVIDER_REGISTRY_GUARD_V1",
        "цикл_основания": 1609,
        "hardening_cycle": 1702,
        "целевой_head": "EFHC_Bot_v173_21.zip",
        "статус": "PASSED" if not failures else "FAILED",
        "ошибки": failures,
        "модули_provider": import_inventory,
        "зарегистрировано_по_умолчанию": len(snapshot),
        "включено_по_умолчанию": sum(
            1 for item in snapshot if item.enabled
        ),
        "mock_в_production_registry": any(
            item.provider is AuthProvider.MOCK for item in snapshot
        ),
        "головы_alembic": heads,
        "ddl_postgresql": False,
        "переключение_domain_ownership": False,
        "финансовые_изменения": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка auth provider registry foundation."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = evaluate(args.root.resolve())
    payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if report["статус"] == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
