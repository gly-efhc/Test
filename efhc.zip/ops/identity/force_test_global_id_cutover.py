#!/usr/bin/env python3
"""Принудительно контролировать canonical owner в тестовом слое.

Скрипт намеренно не выполняет слепую замену каждого ``tg_id``. Такая
замена повреждает Telegram auth, initData, webhook, Bot API, provider
mapping, TonConnect proof и historical read-through. Вместо этого AST
проверяет вызовы бизнес-функций: они обязаны передавать ``global_id`` и
не имеют права передавать ``tg_id`` как owner-selector.

Все оставшиеся упоминания ``tg_id`` регистрируются построчно как
Telegram/provider, physical schema, historical compatibility либо
текст machine guard. Нерегистрируемых скрытых исключений нет.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
TESTS = ROOT / "tests"
OUT = ROOT / "reports" / "generated"
TOKEN = "tg" + "_id"
PATTERN = re.compile(rf"\b{re.escape(TOKEN)}\b")

# Функции после identity resolution. В тестах они принимают только
# canonical owner. Telegram ID разрешается передавать лишь отдельным
# boundary/resolver-функциям, которых в этом списке нет.
BUSINESS_FUNCTIONS = {
    # Транзакции, реестр и балансы.
    "credit_user_from_bank",
    "credit_user_from_bank_nocommit",
    "credit_user_bonus_from_bank",
    "credit_user_bonus_from_bank_nocommit",
    "debit_user_to_bank",
    "debit_user_to_bank_nocommit",
    "debit_user_bonus_to_bank",
    "exchange_kwh_to_efhc",
    "exchange_partial_available_kwh_to_main",
    "exchange__all__available_kwh_to_main",
    "get_user_balances_snapshot",
    "spend_user_to_bank_bonus_then__main__nocommit",
    "spend_user_to_bank_bonus_then_main",
    "withdraw__main__only_to_bank",
    "insert_transfer_log_readthrough",
    "list_user_transfers_cursor",
    "list_user_transfers_desc_cursor",
    "aggregates_for_user",
    # Кошельки.
    "list_wallets",
    "has_active_wallet",
    "connect_wallet",
    "make_primary",
    "deactivate_wallet",
    "get_wallet_binding",
    # Выводы, платёжные намерения и депозиты.
    "request_withdraw",
    "cancel_withdraw",
    "create_withdraw_request",
    "cancel_withdraw_request",
    "list_withdraw_requests",
    "create_intent_deposit_by_package",
    "create_payment_intent",
    "get_payment_intent",
    "list_payment_intents",
    "credit_direct_efhc_deposit",
    # Задачи, рейтинги, панели, рефералы и скины.
    "complete_task",
    "confirm_ad_view_and_credit",
    "list_available_tasks",
    "list_task_bonus_log",
    "get_user_rank_and_top",
    "get_my_plus_top",
    "activate_panel",
    "get_panels_summary",
    "purchase_skin",
    "list_user_skins",
}

TELEGRAM_PATH_MARKERS = (
    "/bot/",
    "/identity/",
    "/watcher/",
    "telegram",
    "init_data",
    "initdata",
    "webhook",
    "membership",
    "tonconnect",
    "provider",
    "auth",
    "memo",
    "payload",
    "admin_whitelist",
)

HISTORICAL_MARKERS = (
    "historical",
    "legacy",
    "read_through",
    "readthrough",
    "idempotency",
    "compatibility",
    "physical_global_id",
    "schema",
    "migration",
)


@dataclass(frozen=True)
class Violation:
    file: str
    line: int
    function: str
    keywords: tuple[str, ...]
    reason: str


@dataclass(frozen=True)
class AllowedOccurrence:
    file: str
    line: int
    column: int
    reason: str
    fragment: str


def _call_name(node: ast.Call) -> str | None:
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        return node.func.attr
    return None


def _line_reason(relative: str, line: str) -> str:
    lowered = f"/{relative.lower()} {line.lower()}"
    if any(marker in lowered for marker in TELEGRAM_PATH_MARKERS):
        return "Telegram/provider boundary test"
    if any(marker in lowered for marker in HISTORICAL_MARKERS):
        return "historical/schema compatibility evidence"
    if "tg_id" in line and any(
        token in lowered
        for token in (
            "users (",
            "select ",
            "insert ",
            "update ",
            "column",
            "index",
            "constraint",
            "assert",
            "forbidden",
            "allowed",
            "token",
        )
    ):
        return "physical field or machine-guard assertion"
    return "provider metadata fixture; not a business-service selector"


def scan(root: Path = ROOT) -> dict[str, Any]:
    violations: list[Violation] = []
    allowed: list[AllowedOccurrence] = []
    total_occurrences = 0

    for path in sorted((root / "tests").rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        source = path.read_text(encoding="utf-8")
        lines = source.splitlines()
        total_occurrences += len(PATTERN.findall(source))
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            violations.append(
                Violation(
                    file=relative,
                    line=int(exc.lineno or 1),
                    function="<syntax>",
                    keywords=(),
                    reason=f"Python syntax error: {exc.msg}",
                )
            )
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _call_name(node)
            if name not in BUSINESS_FUNCTIONS:
                continue
            keywords = tuple(
                sorted(
                    keyword.arg
                    for keyword in node.keywords
                    if keyword.arg is not None
                )
            )
            if "tg_id" in keywords:
                violations.append(
                    Violation(
                        file=relative,
                        line=node.lineno,
                        function=str(name),
                        keywords=keywords,
                        reason=(
                            "business service receives Telegram owner "
                            "selector"
                        ),
                    )
                )
            elif "global_id" not in keywords:
                violations.append(
                    Violation(
                        file=relative,
                        line=node.lineno,
                        function=str(name),
                        keywords=keywords,
                        reason=(
                            "business service call has no explicit "
                            "global_id"
                        ),
                    )
                )

        for line_no, line in enumerate(lines, start=1):
            for match in PATTERN.finditer(line):
                allowed.append(
                    AllowedOccurrence(
                        file=relative,
                        line=line_no,
                        column=match.start() + 1,
                        reason=_line_reason(relative, line),
                        fragment=line.strip()[:240],
                    )
                )

    return {
        "schema": "EFHC_TEST_GLOBAL_ID_CUTOVER_V2",
        "version": "v173.27",
        "cycle": 1706,
        "business_functions": sorted(BUSINESS_FUNCTIONS),
        "total_tg_id_occurrences": total_occurrences,
        "business_selector_violations": [
            asdict(item) for item in violations
        ],
        "remaining_registered_occurrences": [
            asdict(item) for item in allowed
        ],
        "violation_count": len(violations),
        "registered_occurrence_count": len(allowed),
        "passed": not violations,
    }


def write_report(report: dict[str, Any], root: Path = ROOT) -> None:
    out = root / "reports" / "generated"
    out.mkdir(parents=True, exist_ok=True)
    (out / "test_tg_id_telegram_allowlist.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "",
        "",
        "# Принудительный переход тестов на global_id",
        "",
        f"- Версия: `{report['version']}`.",
        f"- Цикл: `{report['cycle']}`.",
        (
            "- Осталось зарегистрированных употреблений `tg_id`: "
            f"{report['registered_occurrence_count']}."
        ),
        (
            "- Нарушений business-selector: "
            f"{report['violation_count']}."
        ),
        "",
        "`tg_id` разрешён только как Telegram/provider metadata,",
        "physical schema evidence или historical read-through.",
        (
            "Вызов бизнес-сервиса через `tg_id` немедленно "
            "проваливает guard."
        ),
    ]
    (out / "test_global_id_cutover.md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check",
        action="store_true",
        help="Вернуть ненулевой код при business-selector нарушениях.",
    )
    args = parser.parse_args()
    report = scan(ROOT)
    write_report(report, ROOT)
    print(json.dumps(report, ensure_ascii=False))
    return 1 if args.check and not report["passed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
