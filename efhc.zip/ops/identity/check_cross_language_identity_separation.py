"""Fail-closed guard разделения GlobalId и TelegramId."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path
from typing import Any, Final

from ops.identity.export_cross_language_identity_contract import (
    build_contract,
)

FIXTURE: Final[Path] = Path(
    "contracts/identity/cross_language_identity_separation_v1.json"
)
BACKEND_TYPES: Final[Path] = Path("backend/app/identity/types.py")
FRONTEND_TYPES: Final[Path] = Path("frontend/src/types/identity.ts")
TELEGRAM_BOUNDARY: Final[Path] = Path("frontend/src/lib/telegram.ts")

GLOBAL_NAMES: Final[set[str]] = {
    "global_id",
    "globalId",
    "resolved_global_id",
    "target_global_id",
    "actor_global_id",
}
TELEGRAM_NAMES: Final[set[str]] = {
    "tg_id",
    "telegram_id",
    "telegramId",
    "chat_id",
}
TELEGRAM_CALL_NAMES: Final[set[str]] = {
    "send_message",
    "sendMessage",
    "get_chat",
    "ban_chat_member",
    "unban_chat_member",
    "answer_callback_query",
    "tg_id_to_provider",
    "telegramIdToProvider",
}

TS_DIRECT_ASSIGNMENT_RE: Final[re.Pattern[str]] = re.compile(
    r"\b(?:tg_id|telegramId|telegram_id)\b[^=\n]*="
    r"[^;\n]*\b(?:global_id|globalId)\b"
    r"|\b(?:global_id|globalId)\b[^=\n]*="
    r"[^;\n]*\b(?:tg_id|telegramId|telegram_id)\b"
)
TS_TELEGRAM_CALL_RE: Final[re.Pattern[str]] = re.compile(
    r"\b(?:telegramIdToProvider|sendTelegramMessage|sendMessage)"
    r"\s*\([^\n)]*\b(?:global_id|globalId)\b"
)


def _name_set(node: ast.AST) -> set[str]:
    return {
        item.id
        for item in ast.walk(node)
        if isinstance(item, ast.Name)
    }


def _target_names(node: ast.AST) -> set[str]:
    names: set[str] = set()
    for item in ast.walk(node):
        if isinstance(item, ast.Name):
            names.add(item.id)
        elif isinstance(item, ast.Attribute):
            names.add(item.attr)
    return names


def _call_name(node: ast.Call) -> str:
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        return node.func.attr
    return ""


def найти_python_смешения(root: Path) -> list[dict[str, Any]]:
    """Найти присваивания и Telegram API calls с GlobalId."""

    findings: list[dict[str, Any]] = []
    base = root / "backend/app"
    for path in sorted(base.rglob("*.py")):
        source = path.read_text(encoding="utf-8")
        try:
            tree = ast.parse(source)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            targets: set[str] = set()
            value: ast.AST | None = None
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    targets.update(_target_names(target))
                value = node.value
            elif isinstance(node, ast.AnnAssign):
                targets.update(_target_names(node.target))
                value = node.value
            if value is not None:
                values = _name_set(value)
                if targets & GLOBAL_NAMES and values & TELEGRAM_NAMES:
                    findings.append(
                        {
                            "путь": path.relative_to(root).as_posix(),
                            "строка": node.lineno,
                            "причина": "telegram_to_global_assignment",
                        }
                    )
                if targets & TELEGRAM_NAMES and values & GLOBAL_NAMES:
                    findings.append(
                        {
                            "путь": path.relative_to(root).as_posix(),
                            "строка": node.lineno,
                            "причина": "global_to_telegram_assignment",
                        }
                    )
            if not isinstance(node, ast.Call):
                continue
            call_name = _call_name(node)
            if call_name not in TELEGRAM_CALL_NAMES:
                continue
            values: set[str] = set()
            for argument in node.args:
                values.update(_name_set(argument))
            for keyword in node.keywords:
                values.update(_name_set(keyword.value))
            if values & GLOBAL_NAMES:
                findings.append(
                    {
                        "путь": path.relative_to(root).as_posix(),
                        "строка": node.lineno,
                        "причина": "global_id_to_telegram_api",
                    }
                )
    return findings


def найти_frontend_смешения(root: Path) -> list[dict[str, Any]]:
    """Найти прямое смешение типов в TypeScript runtime-коде."""

    findings: list[dict[str, Any]] = []
    base = root / "frontend/src"
    for path in sorted(base.rglob("*")):
        if path.suffix not in {".ts", ".tsx"}:
            continue
        for line_number, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(),
            start=1,
        ):
            if TS_DIRECT_ASSIGNMENT_RE.search(line):
                findings.append(
                    {
                        "путь": path.relative_to(root).as_posix(),
                        "строка": line_number,
                        "причина": "typescript_identity_assignment",
                    }
                )
            if TS_TELEGRAM_CALL_RE.search(line):
                findings.append(
                    {
                        "путь": path.relative_to(root).as_posix(),
                        "строка": line_number,
                        "причина": "global_id_to_telegram_api",
                    }
                )
    return findings


def проверить(root: Path) -> dict[str, Any]:
    """Проверить cross-language separation exact tree."""

    violations: list[dict[str, Any]] = []
    fixture_path = root / FIXTURE
    expected = build_contract()
    if not fixture_path.is_file():
        violations.append(
            {
                "путь": FIXTURE.as_posix(),
                "строка": 0,
                "причина": "contract_fixture_missing",
            }
        )
    else:
        actual = json.loads(fixture_path.read_text(encoding="utf-8"))
        if actual != expected:
            violations.append(
                {
                    "путь": FIXTURE.as_posix(),
                    "строка": 0,
                    "причина": "contract_fixture_stale",
                }
            )

    required = {
        BACKEND_TYPES: (
            "class GlobalId:",
            "class TelegramId:",
            'code="global_id.provider_mismatch"',
            'code="tg_id.global_mismatch"',
            "ExternalTelegramId = Annotated[",
        ),
        FRONTEND_TYPES: (
            "export type GlobalId = string &",
            "export type TelegramId = number &",
            "export function parseTelegramId(",
            "export function telegramIdToProvider(",
        ),
        TELEGRAM_BOUNDARY: (
            "id: TelegramId;",
            "const id = telegramIdFromProvider(u.id);",
        ),
    }
    for relative, fragments in required.items():
        path = root / relative
        source = (
            path.read_text(encoding="utf-8")
            if path.is_file()
            else ""
        )
        for fragment in fragments:
            if fragment not in source:
                violations.append(
                    {
                        "путь": relative.as_posix(),
                        "строка": 0,
                        "причина": "required_boundary_missing",
                        "фрагмент": fragment,
                    }
                )

    violations.extend(найти_python_смешения(root))
    violations.extend(найти_frontend_смешения(root))
    return {
        "схема_отчёта": (
            "EFHC_CROSS_LANGUAGE_IDENTITY_SEPARATION_V1"
        ),
        "номинальные_типы_backend": True,
        "брендированные_типы_frontend": True,
        "telegram_граница_типизирована": True,
        "активные_маршруты_переключены": False,
        "postgresql_read_switch_выполнен": False,
        "нарушения": violations,
        "пройдено": not violations,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Проверка разделения GlobalId и TelegramId."
        )
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = json.dumps(
        result,
        ensure_ascii=False,
        indent=2,
    ) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
