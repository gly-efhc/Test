"""Fail-closed проверка cross-layer identity consistency цикла 1705."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Final

from app.identity.auth_provider import AuthProvider
from app.identity.identity_registry import (
    CANONICAL_PROVIDER_SUBJECT_FIELDS,
)
from app.identity.provider_registry import (
    build_auth_provider_registry_contract,
)

ROOT: Final = Path(__file__).resolve().parents[2]
PRODUCTION_PROVIDERS: Final = (
    "telegram",
    "ton",
    "google",
    "apple",
    "facebook",
    "discord",
    "github",
)
CANONICAL_SUBJECTS: Final = {
    "telegram": "tg_id",
    "ton": "ton_wallet_id",
    "google": "google_id",
    "apple": "apple_id",
    "facebook": "fb_id",
    "discord": "discord_id",
    "github": "github_id",
}


def _text(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def build_report() -> dict[str, object]:
    """Проверить identity chain и admin access end-to-end."""

    provider_contract = build_auth_provider_registry_contract()
    openapi = json.loads(_text("backend/openapi/openapi.json"))
    deps = _text("backend/app/deps.py")
    admin_routes = _text("backend/app/routes/admin_routes.py")
    withdrawals = _text("backend/app/routes/admin_withdrawals_routes.py")
    rbac = _text("backend/app/services/admin/admin_rbac.py")
    frontend_app = _text("frontend/src/pages/_app.tsx")
    frontend_admin = _text("frontend/src/lib/admin.ts")
    migration = _text(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    admin_bot_access = _text(
        "backend/app/bot/handlers/admin/admin_access.py"
    )
    admin_bot_sources = "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted(
            (ROOT / "backend/app/bot/handlers/admin").glob("admin_*_handlers.py")
        )
    )

    provider_values = tuple(
        provider.value for provider in AuthProvider if provider.value != "mock"
    )
    access_schema = (
        openapi.get("paths", {})
        .get("/admin/access", {})
        .get("get", {})
    )

    checks = {
        "provider_wire_canon": provider_values == PRODUCTION_PROVIDERS,
        "provider_subject_canon": (
            dict(CANONICAL_PROVIDER_SUBJECT_FIELDS) == CANONICAL_SUBJECTS
            and provider_contract.get("canonical_subject_fields")
            == CANONICAL_SUBJECTS
        ),
        "retired_ton_provider_alias_absent": (
            "ton_wallet" not in provider_values
            and '"ton_address"' not in str(
                provider_contract.get("canonical_subject_fields")
            )
        ),
        "single_alembic_0001": (
            "0001_initial_release_schema.py" in migration
            or "revision = \"0001\"" in migration
        ),
        "admin_backend_session_global_id": (
            "RBAC.resolve_admin" in deps
            and "global_id = int(context.global_id.value)" in deps
            and "context.tg_id" not in deps.split(
                "async def require_admin", 1
            )[1].split("# Health-проверка БД", 1)[0]
        ),
        "admin_explicit_role_required": (
            "Администратору не назначена явная RBAC-роль" in rbac
            and "'superadmin'\n    ) AS role" not in rbac
        ),
        "admin_access_api_present": (
            'router.get("/access"' in admin_routes
            and bool(access_schema)
        ),
        "frontend_admin_server_checked": (
            "fetchAdminAccess" in frontend_app
            and "fetchAdminAccess" in frontend_admin
            and "NEXT_PUBLIC_ADMIN_TG_IDS" not in frontend_app
            and "is_admin_tg_id" not in frontend_app
        ),
        "telegram_admin_commands_resolve_global_id_rbac": (
            "resolve_telegram_subject_global_id" in admin_bot_access
            and "RBAC.resolve_admin" in admin_bot_access
            and "ADMIN_TG_ID" not in admin_bot_access
            and "ADMIN_TG_ID" not in admin_bot_sources
        ),
        "withdrawals_no_role_escalation": (
            'role="SuperAdmin"' not in withdrawals
            and "auth.tg_id" not in withdrawals
            and "id=int(auth.admin_id)" in withdrawals
            and "role=str(auth.role)" in withdrawals
        ),
        "external_admin_global_id_is_string": (
            access_schema.get("responses", {}).get("200") is not None
            and "PydanticGlobalId" in admin_routes
        ),
    }
    failed = sorted(name for name, passed in checks.items() if not passed)
    return {
        "schema": "EFHC_CROSS_LAYER_IDENTITY_CONSISTENCY_V1",
        "version": "v173.27",
        "cycle": 1706,
        "status": "PASS" if not failed else "FAIL",
        "checks": checks,
        "failed": failed,
    }


def main() -> int:
    report = build_report()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
