#!/usr/bin/env python3
"""Проверить provider-neutral business identity surface frontend."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def _text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def check() -> dict[str, Any]:
    violations: list[str] = []
    app = _text("frontend/src/pages/_app.tsx")
    layout = _text("frontend/src/components/Layout.tsx")
    shop_layout = _text("frontend/src/components/ShopLayout.tsx")
    energy = _text("frontend/src/pages/index.tsx")
    keys = _text("frontend/src/queries/queryKeys.ts")

    provider_bootstrap = "telegramProviderId" in app
    if not provider_bootstrap:
        violations.append("telegram_provider_bootstrap:missing")
    if "is_admin_tg_id" in app or "NEXT_PUBLIC_ADMIN_TG_IDS" in app:
        violations.append("admin_provider_subject_gate:forbidden")
    if "fetchAdminAccess" not in app:
        violations.append("admin_server_side_access_check:missing")
    if "tg_id={" in app or "tg_id," in app:
        violations.append("generic_page_provider_prop:forbidden")
    if "tg_id:" in layout or "tg_id:" in shop_layout:
        violations.append("layout_business_context_tg_id:forbidden")
    if "tg_id:" in energy:
        violations.append("energy_business_prop_tg_id:forbidden")
    if "GlobalId" not in keys:
        violations.append("query_keys_string_global_id:missing")

    return {
        "schema": "EFHC_FRONTEND_IDENTITY_FINALIZATION_V1",
        "business_frontend_tg_id_owner": (
            0 if not violations else None
        ),
        "telegram_context": "PROVIDER_UI_BOOTSTRAP_ONLY",
        "violations": violations,
        "passed": not violations,
    }


def main() -> int:
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
