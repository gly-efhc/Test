"""Экспорт machine contract auth provider registry цикла 1609."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.identity import build_auth_provider_registry_contract


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Экспорт contract auth provider registry."
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = build_auth_provider_registry_contract()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
