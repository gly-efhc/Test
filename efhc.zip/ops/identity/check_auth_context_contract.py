#!/usr/bin/env python3
"""Проверка контрактов авторизации и безопасного редактирования."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.identity import build_auth_context_contract


def main() -> int:
    """Сверить active JSON contract с каноническим Python source."""

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--contract",
        default="contracts/identity/auth_context_contract_v1.json",
    )
    parser.add_argument("--output")
    args = parser.parse_args()
    contract_path = Path(args.contract)
    expected = build_auth_context_contract()
    actual = json.loads(contract_path.read_text(encoding="utf-8"))
    passed = actual == expected
    receipt = {
        "схема": "EFHC_AUTH_CONTEXT_GUARD_V1",
        "цикл": 1610,
        "статус": "PASSED" if passed else "FAILED",
        "contract": contract_path.as_posix(),
        "endpoint_зависит_от_tg_id": False,
        "secrets_в_diagnostics": False,
        "database_ddl": False,
    }
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(
                receipt,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
