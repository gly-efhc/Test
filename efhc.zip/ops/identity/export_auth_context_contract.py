#!/usr/bin/env python3
"""Экспортировать canonical AuthContext contract цикла 1610."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.identity import build_auth_context_contract


def main() -> int:
    """Записать JSON contract в указанный файл."""

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="contracts/identity/auth_context_contract_v1.json",
    )
    args = parser.parse_args()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            build_auth_context_contract(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
