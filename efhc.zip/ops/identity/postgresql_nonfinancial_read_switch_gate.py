#!/usr/bin/env python3
"""Read-only PostgreSQL gate non-financial read switch цикла 1625."""

from __future__ import annotations

import argparse
import json
import os
from typing import Final

EXPECTED_REVISION: Final[str] = "0001"
NONFINANCIAL_SCOPES: Final[tuple[str, ...]] = (
    "efhc_core.panels.tg_id->global_id",
    "efhc_core.panels_archive.tg_id->global_id",
    "efhc_core.referral_links.inviter_tg_id->inviter_global_id",
    "efhc_core.referral_links.invitee_tg_id->invitee_global_id",
    "efhc_core.referral_codes.inviter_tg_id->inviter_global_id",
    "efhc_core.referral_bonus_ledger.tg_id->global_id",
    "efhc_core.task_submissions.tg_id->global_id",
    "efhc_core.user_tasks_status.tg_id->global_id",
    "efhc_core.task_bonus_log.tg_id->global_id",
    "efhc_core.task_complete_lock.tg_id->global_id",
    "efhc_core.ranks_snapshots.tg_id->global_id",
    "efhc_core.ranks_top_cache.tg_id->global_id",
    "efhc_core.ranks_user_snapshots.tg_id->global_id",
    "efhc_core.scheduler_task_log.payload.tg_id->global_id",
)


def _psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def collect(database_url: str) -> dict[str, object]:
    """Проверить readiness/read-switch state без изменения БД."""

    try:
        import psycopg
    except ModuleNotFoundError as exc:
        raise RuntimeError("psycopg недоступен") from exc

    with (
        psycopg.connect(_psycopg_url(database_url)) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(
            "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ "
            "READ ONLY DEFERRABLE"
        )
        cursor.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        )
        revision_row = cursor.fetchone()
        if revision_row is None:
            raise RuntimeError("Alembic revision не найдена")
        revision = str(revision_row[0])

        cursor.execute(
            """
            SELECT
                dual_write_enabled,
                shadow_read_enabled,
                legacy_authoritative,
                nonfinancial_read_global_id_enabled,
                nonfinancial_read_rollback_ready
            FROM efhc_core.identity_migration_control
            WHERE singleton_id = 1
            """
        )
        control = cursor.fetchone()
        if control is None:
            raise RuntimeError("identity migration control отсутствует")

        cursor.execute(
            """
            SELECT
                scope,
                fallback_rows,
                mismatch_rows,
                orphan_rows,
                ambiguous_rows
            FROM efhc_core.identity_ownership_shadow_telemetry
            WHERE scope = ANY(%s)
            ORDER BY scope
            """,
            (list(NONFINANCIAL_SCOPES),),
        )
        rows = cursor.fetchall()
        connection.rollback()

    totals = {
        "fallback_rows": 0,
        "mismatch_rows": 0,
        "orphan_rows": 0,
        "ambiguous_rows": 0,
    }
    details: list[dict[str, object]] = []
    for row in rows:
        item = {"scope": str(row[0])}
        for index, key in enumerate(totals, start=1):
            value = int(row[index])
            totals[key] += value
            item[key] = value
        details.append(item)

    dual_write = bool(control[0])
    shadow_read = bool(control[1])
    legacy_authoritative = bool(control[2])
    global_read = bool(control[3])
    rollback_ready = bool(control[4])
    zero_telemetry = all(value == 0 for value in totals.values())
    ready = (
        revision == EXPECTED_REVISION
        and dual_write
        and shadow_read
        and legacy_authoritative
        and global_read
        and rollback_ready
        and zero_telemetry
        and len(details) == len(NONFINANCIAL_SCOPES)
    )
    return {
        "статус": "PASS" if ready else "FAIL",
        "alembic_revision": revision,
        "dual_write_enabled": dual_write,
        "shadow_read_enabled": shadow_read,
        "legacy_authoritative": legacy_authoritative,
        "nonfinancial_read_global_id_enabled": global_read,
        "nonfinancial_read_rollback_ready": rollback_ready,
        "telemetry": totals,
        "scope_count": len(details),
        "scopes": details,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database-url",
        default=os.getenv("DATABASE_URL")
        or os.getenv("SYNC_DATABASE_URL"),
    )
    parser.add_argument("--json-report")
    args = parser.parse_args()
    if not args.database_url:
        raise SystemExit("DATABASE_URL обязателен")
    report = collect(args.database_url)
    payload = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
    print(payload)
    if args.json_report:
        with open(args.json_report, "w", encoding="utf-8") as handle:
            handle.write(payload + "\n")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
