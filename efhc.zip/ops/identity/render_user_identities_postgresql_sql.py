#!/usr/bin/env python3
"""Сформировать и проверить offline PostgreSQL SQL revision ``0003``."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def _relative(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path)


def _offline_environment(root: Path) -> dict[str, str]:
    env = os.environ.copy()
    env["DATABASE_URL"] = (
        "postgresql://offline:offline@localhost:5432/efhc_offline"
    )
    env["SYNC_DATABASE_URL"] = env["DATABASE_URL"]
    env["PYTHONPATH"] = os.pathsep.join(
        [str(root / "backend"), str(root)]
    )
    return env


def _run_alembic(
    root: Path,
    arguments: list[str],
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "-c",
            "alembic.ini",
            *arguments,
            "--sql",
        ],
        cwd=root / "backend",
        env=_offline_environment(root),
        text=True,
        capture_output=True,
        check=False,
    )


def _validate_upgrade(sql: str) -> list[str]:
    errors: list[str] = []
    required = (
        "CREATE TABLE IF NOT EXISTS efhc_core.user_identities",
        "REFERENCES efhc_core.users(user_id)",
        "UNIQUE (provider, provider_tenant, provider_subject)",
        "provider <> 'mock'",
        "uq_user_identities_primary_per_global",
        "UPDATE efhc_core.alembic_version SET version_num='0003'",
        "-- 0003: user_identities created; no backfill",
    )
    for token in required:
        if token not in sql:
            errors.append(f"upgrade SQL не содержит: {token}")
    upper = sql.upper()
    forbidden = (
        "UPDATE EFHC_CORE.USERS",
        "INSERT INTO EFHC_CORE.USERS",
        "DELETE FROM EFHC_CORE.USERS",
        "ALTER TABLE EFHC_CORE.USERS",
        "MAIN_BALANCE =",
        "BONUS_BALANCE =",
        "AVAILABLE_KWH =",
        "TOTAL_GENERATED_KWH =",
        "EXCHANGED_KWH_TOTAL =",
    )
    for token in forbidden:
        if token in upper:
            errors.append(
                f"upgrade SQL содержит запрещённое: {token}"
            )
    return errors


def _validate_downgrade(sql: str) -> list[str]:
    errors: list[str] = []
    required = (
        "DO $$",
        "user_identities is not empty",
        "DROP TABLE efhc_core.user_identities",
        "UPDATE efhc_core.alembic_version SET version_num='0002'",
        "-- 0003 downgrade: empty table only",
    )
    for token in required:
        if token not in sql:
            errors.append(f"downgrade SQL не содержит: {token}")
    if "CASCADE" in sql.upper():
        errors.append("downgrade SQL содержит запрещённый CASCADE")
    return errors


def _clean_sql_output(output: str) -> str:
    """Удалить runtime-log строки из Alembic SQL evidence."""

    log_line = re.compile(
        r"^\d{4}-\d{2}-\d{2}[^|]*\|.*$"
    )
    lines = [
        line
        for line in output.splitlines()
        if not log_line.match(line)
    ]
    return "\n".join(lines).rstrip() + "\n"


def _write_process_evidence(
    process: subprocess.CompletedProcess[str],
    sql_path: Path,
    stderr_path: Path,
) -> str:
    clean_sql = _clean_sql_output(process.stdout)
    sql_path.write_text(clean_sql, encoding="utf-8")
    stderr_path.write_text(process.stderr, encoding="utf-8")
    return clean_sql


def render(root: Path, output_dir: Path) -> dict[str, Any]:
    """Запустить Alembic offline renderer без подключения к БД."""

    root = root.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    upgrade_sql_path = output_dir / (
        "alembic_0002_to_0003_postgresql.sql"
    )
    upgrade_stderr_path = output_dir / (
        "alembic_0002_to_0003_postgresql.stderr.txt"
    )
    downgrade_sql_path = output_dir / (
        "alembic_0003_to_0002_postgresql.sql"
    )
    downgrade_stderr_path = output_dir / (
        "alembic_0003_to_0002_postgresql.stderr.txt"
    )

    upgrade = _run_alembic(root, ["upgrade", "0002:0003"])
    downgrade = _run_alembic(root, ["downgrade", "0003:0002"])
    upgrade_sql = _write_process_evidence(
        upgrade,
        upgrade_sql_path,
        upgrade_stderr_path,
    )
    downgrade_sql = _write_process_evidence(
        downgrade,
        downgrade_sql_path,
        downgrade_stderr_path,
    )

    errors: list[str] = []
    if upgrade.returncode != 0:
        errors.append(
            "Alembic offline upgrade завершился кодом "
            f"{upgrade.returncode}"
        )
    if downgrade.returncode != 0:
        errors.append(
            "Alembic offline downgrade завершился кодом "
            f"{downgrade.returncode}"
        )
    errors.extend(_validate_upgrade(upgrade_sql))
    errors.extend(_validate_downgrade(downgrade_sql))

    result = {
        "схема": "EFHC_USER_IDENTITIES_OFFLINE_SQL_V1",
        "цикл": 1611,
        "версия": "v172.08",
        "статус_pg0": "TEST_PACKAGE_PREPARED_NOT_EXECUTED",
        "диалект": "postgresql",
        "postgresql_выполнен_онлайн": False,
        "код_выхода_upgrade": upgrade.returncode,
        "код_выхода_downgrade": downgrade.returncode,
        "upgrade_sql": _relative(upgrade_sql_path, root),
        "upgrade_stderr": _relative(
            upgrade_stderr_path,
            root,
        ),
        "downgrade_sql": _relative(downgrade_sql_path, root),
        "downgrade_stderr": _relative(
            downgrade_stderr_path,
            root,
        ),
        "historical_backfill": False,
        "данные_users_изменены": False,
        "финансовые_данные_изменены": False,
        "downgrade_fail_closed": True,
        "пройдено": not errors,
        "ошибки": errors,
    }
    report = output_dir / "user_identities_offline_sql_v172_08.json"
    report.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=(
            Path(tempfile.gettempdir())
            / "efhc_cycle_1611_offline_sql"
        ),
    )
    args = parser.parse_args()
    output = args.output_dir
    if not output.is_absolute():
        output = args.root / output
    result = render(args.root, output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["пройдено"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
