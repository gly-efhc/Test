#!/usr/bin/env python3
"""Сформировать русскоязычный аудит перехода к global_id."""

from __future__ import annotations

import argparse
import csv
import json
import tempfile
from pathlib import Path
from typing import Any

from ops.identity.audit_tg_id_usage import build_audit

ПЕРЕВОД_СТОЛБЦОВ = {
    "file": "файл",
    "line_or_object": "строка_или_объект",
    "layer": "слой",
    "current_field": "текущее_поле",
    "semantics": "семантика",
    "target_field": "целевое_поле",
    "decision": "решение",
    "cycle": "цикл_миграции",
    "risk": "риск",
    "source_excerpt": "фрагмент_источника",
    "class": "класс",
    "field": "поле",
    "line": "строка",
    "function": "функция",
    "parameters": "параметры",
    "decorators": "декораторы",
    "path": "путь",
    "methods": "методы",
    "uses_tg_id": "использует_tg_id",
}


def _translate_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        ПЕРЕВОД_СТОЛБЦОВ.get(key, key): value
        for key, value in row.items()
    }


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(rows[0]) if rows else ["пусто"]
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def render(
    root: Path,
    output: Path,
    *,
    source_head: str,
    baseline_head: str,
    cycle: int,
) -> dict[str, Any]:
    """Создать русские JSON и CSV без изменения raw-аудита."""

    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="efhc_identity_audit_"
    ) as raw:
        raw_path = Path(raw)
        summary = build_audit(
            root,
            raw_path,
            source_head=source_head,
            baseline_head=baseline_head,
            cycle=cycle,
        )
        matrix = [
            _translate_row(item)
            for item in json.loads(
                (raw_path / "identity_usage_matrix.json").read_text(
                    encoding="utf-8"
                )
            )
        ]
        orm = [
            _translate_row(item)
            for item in _read_csv(raw_path / "orm_fields.csv")
        ]
        signatures = [
            _translate_row(item)
            for item in _read_csv(raw_path / "service_signatures.csv")
        ]
        routes = [
            _translate_row(item)
            for item in _read_csv(raw_path / "routes.csv")
        ]

    russian_summary = {
        "схема_отчёта": "EFHC_РУССКИЙ_АУДИТ_GLOBAL_ID_V2",
        "исходный_архив": source_head,
        "базовый_архив": baseline_head,
        "цикл": cycle,
        "строк_матрицы": summary["total_usage_rows"],
        "файлов_с_упоминаниями": summary["files_with_usage"],
        "orm_полей": summary["orm_fields"],
        "сервисных_сигнатур": summary[
            "service_function_signatures"
        ],
        "маршрутов": summary["routes_inventory"],
        "маршрутов_с_tg_id": summary["routes_using_tg_id"],
        "реальных_доменных_зависимостей": summary[
            "real_domain_dependency_rows"
        ],
        "по_слоям": summary["by_layer"],
        "по_семантике": summary["by_semantics"],
        "по_решениям": summary["by_decision"],
        "канонический_идентификатор": "global_id",
        "физическое_переходное_поле": "users.global_id",
    }
    (output / "сводка_аудита.json").write_text(
        (
            json.dumps(
                russian_summary,
                ensure_ascii=False,
                indent=2,
            )
            + "\n"
        ),
        encoding="utf-8",
    )
    (output / "матрица_использований.json").write_text(
        json.dumps(matrix, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    _write_csv(output / "матрица_использований.csv", matrix)
    _write_csv(output / "orm_поля.csv", orm)
    _write_csv(output / "сервисные_сигнатуры.csv", signatures)
    _write_csv(output / "маршруты.csv", routes)
    return russian_summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-head", required=True)
    parser.add_argument("--baseline-head", required=True)
    parser.add_argument("--cycle", type=int, required=True)
    args = parser.parse_args()
    result = render(
        args.root.resolve(),
        args.output.resolve(),
        source_head=args.source_head,
        baseline_head=args.baseline_head,
        cycle=args.cycle,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
