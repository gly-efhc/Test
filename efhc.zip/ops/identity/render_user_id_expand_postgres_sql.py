"""Render and validate cycle-1597 PostgreSQL expand SQL."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from app.identity.user_id_expand import (  # noqa: E402
    build_user_id_expand_plan,
    render_postgres_existing_schema_expand_sql,
)


def _display_path(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return str(path)

def _validate_existing_schema_sql(sql: str) -> list[str]:
    errors: list[str] = []
    required = (
        "ADD COLUMN IF NOT EXISTS user_id BIGINT NULL",
        "users_user_id_seq",
        "MAXVALUE 9999999999",
        "OWNED BY efhc_core.users.user_id",
        "ALTER COLUMN user_id SET DEFAULT",
        "ck_users_user_id_range",
        "uq_users_user_id",
    )
    for token in required:
        if token not in sql:
            errors.append(f"existing-schema SQL missing: {token}")
    upper = sql.upper()
    forbidden = (
        "UPDATE EFHC_CORE.USERS SET USER_ID",
        "ALTER COLUMN TG_ID DROP NOT NULL",
        "MAIN_BALANCE =",
        "BONUS_BALANCE =",
        "TOTAL_GENERATED_KWH =",
        "EXCHANGED_KWH_TOTAL =",
    )
    for token in forbidden:
        if token in upper:
            errors.append(f"forbidden expand SQL token: {token}")
    return errors


def _validate_fresh_sql(sql: str) -> list[str]:
    errors: list[str] = []
    required = (
        "ADD COLUMN IF NOT EXISTS user_id BIGINT NULL",
        "users_user_id_seq",
        "ADD CONSTRAINT uq_users_user_id",
        "ADD CONSTRAINT ck_users_user_id_range",
        "UPDATE efhc_core.alembic_version SET version_num='0002'",
    )
    for token in required:
        if token not in sql:
            errors.append(f"fresh SQL missing: {token}")
    return errors


def render(root: Path, output_dir: Path) -> dict[str, Any]:
    root = root.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    existing_sql = render_postgres_existing_schema_expand_sql()
    existing_path = output_dir / (
        "user_id_expand_existing_schema_v171_94.sql"
    )
    existing_path.write_text(existing_sql, encoding="utf-8")

    fresh_path = output_dir / "alembic_fresh_postgresql_v171_94.sql"
    stderr_path = output_dir / (
        "alembic_fresh_postgresql_v171_94.stderr.log"
    )
    env = os.environ.copy()
    env["DATABASE_URL"] = "postgresql://dry:dry@localhost/dry"
    env["SYNC_DATABASE_URL"] = env["DATABASE_URL"]
    env["PYTHONPATH"] = str(root / "backend")
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "-c",
            "alembic.ini",
            "upgrade",
            "0002",
            "--sql",
        ],
        cwd=root / "backend",
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    fresh_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")

    errors = _validate_existing_schema_sql(existing_sql)
    if proc.returncode != 0:
        errors.append(
            "Alembic PostgreSQL offline render failed: "
            f"exit {proc.returncode}"
        )
    else:
        errors.extend(_validate_fresh_sql(proc.stdout))

    plan = build_user_id_expand_plan()
    result: dict[str, Any] = {
        "schema": "EFHC_USER_ID_EXPAND_DRY_RUN_V1",
        "cycle": plan.cycle,
        "source_head": plan.source_head,
        "target_head": plan.target_head,
        "dialect": "postgresql",
        "online_postgresql_executed": False,
        "online_reason": (
            "PostgreSQL server and psycopg are unavailable in the "
            "local execution environment"
        ),
        "alembic_offline_exit_code": proc.returncode,
        "existing_schema_sql": _display_path(existing_path, root),
        "fresh_database_sql": _display_path(fresh_path, root),
        "fresh_database_stderr": (
            _display_path(stderr_path, root)
        ),
        "backfill_performed": plan.backfill_performed,
        "runtime_read_switch": plan.runtime_read_switch,
        "ton_wallet_login_enabled": plan.ton_wallet_login_enabled,
        "passed": not errors,
        "errors": errors,
    }
    report = output_dir / "user_id_expand_dry_run_v171_94.json"
    report.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("reports/generated/cycle_1597"),
    )
    args = parser.parse_args()
    output = args.output_dir
    if not output.is_absolute():
        output = args.root / output
    result = render(args.root, output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
