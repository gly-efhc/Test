#!/usr/bin/env python3
"""Статический guard financial read switch цикла 1627."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def main() -> int:
    migration = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    owner = _read("backend/app/identity/financial_read_switch.py")
    dependency = _read(
        "backend/app/identity/financial_read_dependency.py"
    )
    payment = _read("backend/app/routes/payment_intents_routes.py")
    wallets = _read("backend/app/routes/wallets_routes.py")
    withdraw = _read("backend/app/routes/withdraw_routes.py")
    exchange = _read("backend/app/routes/exchange_routes.py")
    outcome = _read("backend/app/routes/me_routes.py")

    checks = {
        "migration_0001": (
            'revision = "0001"' in migration
            and "down_revision = None" in migration
        ),
        "financial_control": all(
            marker in migration
            for marker in (
                "financial_read_global_id_enabled",
                "financial_read_rollback_ready",
                "financial_read_switched_at",
            )
        ),
        "zero_telemetry_gate": all(
            marker in migration
            for marker in (
                "fallback_rows",
                "mismatch_rows",
                "orphan_rows",
                "ambiguous_rows",
            )
        ),
        "money_zero_gate": (
            "identity_ownership_shadow_telemetry" in migration
            and (
                "UPDATE efhc_core.users SET main_balance"
                not in migration
            )
            and (
                "UPDATE efhc_core.users SET bonus_balance"
                not in migration
            )
        ),
        "provider_neutral_owner": (
            "resolve_financial_read_owner" in owner
            and "get_financial_read_owner" in dependency
            and "context.global_id.value" in dependency
        ),
        "payment_owner": "get_financial_read_owner" in payment,
        "wallet_owner": "get_financial_read_owner" in wallets,
        "withdraw_owner": "get_financial_read_owner" in withdraw,
        "exchange_history_owner": (
            "get_financial_read_owner" in exchange
        ),
        "withdraw_outcome_owner": (
            "get_financial_read_owner" in outcome
        ),
        "no_withdraw_tg_query": (
            "Legacy self-check. Prefer auth user." not in withdraw
        ),
        "no_physical_rename": (
            "users.global_id" in migration
            and "RENAME COLUMN user_id" not in migration
        ),
        "no_financial_write_switch": (
            "request_withdraw(" in withdraw
            and "tg_id=int(current_tg_id)" in withdraw
        ),
    }
    report = {
        "статус": "PASS" if all(checks.values()) else "FAIL",
        "проверки": checks,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
