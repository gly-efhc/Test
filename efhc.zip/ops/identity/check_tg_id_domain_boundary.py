"""Проверить точную Telegram provider-boundary поверхность runtime."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path
from typing import Any

RUNTIME_ROOTS = ("backend/app", "frontend/src")
TEXT_SUFFIXES = {".js", ".jsx", ".py", ".ts", ".tsx"}
SKIP_PARTS = {".git", ".next", "__pycache__", "node_modules"}
IDENTIFIER_RE = re.compile(
    r"\b(?:tg_id|[A-Za-z_][A-Za-z0-9_]*tg_id[A-Za-z0-9_]*|"
    + ("telegram" + "_" + "id") + r")\b"
)
CURRENT_TG_DEP_RE = re.compile(r"\bget_current_tg_id\b")
FORBIDDEN_TEXT_PATTERNS = (
    re.compile(r"\buser_id\s*=\s*tg_id\b"),
    re.compile(r"\btg_id\s*=\s*user_id\b"),
    re.compile(r"\btg_id\s*=\s*global_id\b"),
    re.compile(r"\bglobal_id\s*=\s*tg_id\b"),
    re.compile(r"\b(?:Number|parseInt)\s*\(\s*global_id\s*\)"),
)
CURRENT_VERSION = "v173.27"
CURRENT_CYCLE = 1706

ALLOWED_CATEGORIES = {
    "ADMIN_PROVIDER_DELIVERY",
    "FRONTEND_TELEGRAM_CONTEXT",
    "HISTORICAL_READ_THROUGH_OR_DELIVERY",
    "IDENTITY_GUARD_OR_LOGGING",
    "PROVIDER_BOOTSTRAP_EDGE",
    "PROVIDER_IDENTITY_MAPPING",
    "PROVIDER_INTEGRATION",
    "PROVIDER_LOOKUP_EDGE",
    "PROVIDER_METADATA_CONTRACT",
    "PROVIDER_SEED_METADATA",
    "PROVIDER_STORAGE",
    "TELEGRAM_AUTHENTICATION",
    "TELEGRAM_INGRESS_DELIVERY",
    "TELEGRAM_INGRESS_ROUTE",
}


def _runtime_files(root: Path):
    for relative_root in RUNTIME_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix.casefold() not in TEXT_SUFFIXES:
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            yield path, path.relative_to(root).as_posix()


def _counts(root: Path) -> tuple[dict[str, int], dict[str, int]]:
    identifiers: dict[str, int] = {}
    dependencies: dict[str, int] = {}
    for path, relative in _runtime_files(root):
        source = path.read_text(encoding="utf-8", errors="replace")
        identifier_count = len(IDENTIFIER_RE.findall(source))
        dependency_count = len(CURRENT_TG_DEP_RE.findall(source))
        if identifier_count:
            identifiers[relative] = identifier_count
        if dependency_count:
            dependencies[relative] = dependency_count
    return identifiers, dependencies


def _name_kind(name: str) -> str | None:
    lowered = name.casefold()
    if lowered == "global_id" or lowered.endswith("_global_id"):
        return "global"
    if lowered in {"tg_id", "telegram" + "_" + "id"} or lowered.endswith("_tg_id"):
        return "telegram"
    if lowered == "user_id" or lowered.endswith("_user_id"):
        return "retired_user"
    if lowered in {"wallet_address", "ton_wallet", "canonical_address"}:
        return "wallet"
    return None


def _node_names(node: ast.AST | None) -> set[str]:
    if node is None:
        return set()
    result: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            result.add(child.id)
        elif isinstance(child, ast.Attribute):
            result.add(child.attr)
    return result


def _semantic_mix_offenders(root: Path) -> list[str]:
    offenders: list[str] = []
    for path, relative in _runtime_files(root):
        text = path.read_text(encoding="utf-8", errors="replace")
        for number, line in enumerate(text.splitlines(), start=1):
            if any(pattern.search(line) for pattern in FORBIDDEN_TEXT_PATTERNS):
                offenders.append(f"{relative}:{number}:{line.strip()}")
        if path.suffix.casefold() != ".py":
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                targets = set().union(*(_node_names(item) for item in node.targets))
                values = _node_names(node.value)
            elif isinstance(node, (ast.AnnAssign, ast.NamedExpr)):
                targets = _node_names(node.target)
                values = _node_names(node.value)
            else:
                continue
            target_kinds = {_name_kind(name) for name in targets}
            value_kinds = {_name_kind(name) for name in values}
            if "global" in target_kinds and value_kinds & {"telegram", "retired_user", "wallet"}:
                offenders.append(f"{relative}:{node.lineno}:global_id assigned from provider/retired identity")
            if "telegram" in target_kinds and value_kinds & {"global", "retired_user"}:
                offenders.append(f"{relative}:{node.lineno}:tg_id assigned from account identity")
    return sorted(set(offenders))


def _load(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema") != "EFHC_TG_ID_PROVIDER_BOUNDARY_BASELINE_V5":
        raise ValueError("unsupported tg_id provider-boundary baseline schema")
    return data


def _baseline_errors(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    policy = data.get("policy", {})
    if policy.get("canonical_business_owner") != "global_id":
        errors.append("canonical business owner must be global_id")
    if policy.get("business_owner_tg_id") != 0:
        errors.append("business_owner_tg_id baseline must be zero")
    contract = data.get("global_id_contract", {})
    if contract.get("external_type") != "string" or contract.get("external_pattern") != "^[0-9]{10}$":
        errors.append("external global_id contract must be an ASCII 10-digit string")
    maximum_total = data.get("maximum_runtime_identifier_occurrences")
    previous_total = data.get("previous_runtime_identifier_occurrences")
    if not isinstance(maximum_total, int) or not isinstance(previous_total, int) or maximum_total > previous_total:
        errors.append("tg_id runtime maximum may not grow over the previous measured surface")
    maximum_files = data.get("maximum_tracked_runtime_files")
    previous_files = data.get("previous_tracked_runtime_files")
    if not isinstance(maximum_files, int) or not isinstance(previous_files, int) or maximum_files > previous_files:
        errors.append("tracked tg_id runtime file count may not grow")
    seen: set[str] = set()
    for item in data.get("provider_boundary_files", []):
        path = item.get("path")
        maximum = item.get("max_identifier_occurrences")
        category = item.get("category")
        reason = item.get("reason")
        if not isinstance(path, str) or not path or path in seen:
            errors.append(f"invalid or duplicate provider-boundary path: {path!r}")
            continue
        seen.add(path)
        if not isinstance(maximum, int) or maximum < 1:
            errors.append(f"invalid provider-boundary maximum: {path}")
        if category not in ALLOWED_CATEGORIES:
            errors.append(f"invalid provider-boundary category: {path}")
        if not isinstance(reason, str) or not reason.strip():
            errors.append(f"provider-boundary reason missing: {path}")
    return errors


def check(root: Path, baseline_path: Path) -> dict[str, Any]:
    baseline = _load(baseline_path)
    current_ids, current_deps = _counts(root)
    allowed_ids = {
        item["path"]: int(item["max_identifier_occurrences"])
        for item in baseline.get("provider_boundary_files", [])
    }
    allowed_deps = {
        item["path"]: int(item["max_occurrences"])
        for item in baseline.get("get_current_tg_id_boundary", [])
    }
    errors = _baseline_errors(baseline)
    for path, count in sorted(current_ids.items()):
        maximum = allowed_ids.get(path)
        if maximum is None:
            errors.append(f"new Telegram provider surface: {path}={count}")
        elif count > maximum:
            errors.append(f"Telegram provider surface increased: {path} {count}>{maximum}")
    for path in sorted(set(allowed_ids) - set(current_ids)):
        errors.append(f"stale provider-boundary baseline entry must be removed: {path}")
    for path, count in sorted(current_deps.items()):
        maximum = allowed_deps.get(path)
        if maximum is None:
            errors.append(f"new get_current_tg_id dependency: {path}={count}")
        elif count > maximum:
            errors.append(f"get_current_tg_id increased: {path} {count}>{maximum}")
    for path in sorted(set(allowed_deps) - set(current_deps)):
        errors.append(f"stale get_current_tg_id baseline entry: {path}")
    total = sum(current_ids.values())
    if total > int(baseline["maximum_runtime_identifier_occurrences"]):
        errors.append(f"total runtime tg_id surface increased: {total}>{baseline['maximum_runtime_identifier_occurrences']}")
    if len(current_ids) > int(baseline["maximum_tracked_runtime_files"]):
        errors.append(f"tracked runtime file count increased: {len(current_ids)}>{baseline['maximum_tracked_runtime_files']}")
    semantic = _semantic_mix_offenders(root)
    errors.extend(f"provider/system identity mix: {item}" for item in semantic)
    return {
        "schema": "EFHC_TG_ID_PROVIDER_BOUNDARY_RESULT_V5",
        "version": CURRENT_VERSION,
        "cycle": CURRENT_CYCLE,
        "baseline_provenance": {
            "source_head": baseline["source_head"],
            "target_head": baseline["target_head"],
            "cycle": baseline["cycle"],
        },
        "canonical_business_owner": "global_id",
        "business_owner_tg_id": 0,
        "tracked_runtime_files": len(current_ids),
        "runtime_identifier_occurrences": total,
        "previous_runtime_identifier_occurrences": baseline["previous_runtime_identifier_occurrences"],
        "surface_reduction": baseline["previous_runtime_identifier_occurrences"] - total,
        "get_current_tg_id_files": len(current_deps),
        "semantic_mix_offenders": len(semantic),
        "errors": errors,
        "passed": not errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--baseline", type=Path, default=Path("ops/identity/tg_id_domain_boundary_baseline.json"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root.resolve(), args.baseline.resolve())
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.resolve().write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
