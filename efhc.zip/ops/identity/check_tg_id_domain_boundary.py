"""Reject Telegram-owner growth and identity-space mixing."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path
from typing import Any

LEGACY_PROVIDER_TOKEN = "telegram" + "_id"
LEGACY_PROVIDER_CAMEL = "telegram" + "Id"
TG_PROVIDER_CAMEL = "tg" + "Id"
USER_ID_CAMEL = "user" + "Id"
GLOBAL_ID_CAMEL = "global" + "Id"
WALLET_ADDRESS_CAMEL = "wallet" + "Address"
TON_WALLET_CAMEL = "ton" + "Wallet"
IDENTIFIER_RE = re.compile(
    r"\b(?:tg_id|[A-Za-z_][A-Za-z0-9_]*tg_id"
    rf"[A-Za-z0-9_]*|{LEGACY_PROVIDER_TOKEN})\b"
)
CURRENT_TG_DEP_RE = re.compile(r"\bget_current_tg_id\b")
FORBIDDEN_ALIAS_PATTERNS = (
    re.compile(r"\buser_id\s*=\s*tg_id\b"),
    re.compile(r"\btg_id\s*=\s*user_id\b"),
    re.compile(r"\btg_id\s*=\s*global_id\b"),
    re.compile(r"\buser_id\s*:\s*[^=]+\s*=\s*tg_id\b"),
    re.compile(r"\bglobal_id\s*:\s*[^=]+\s*=\s*tg_id\b"),
)
TS_SYSTEM_ID = (
    rf"(?:user_id|{USER_ID_CAMEL}|"
    rf"global_id|{GLOBAL_ID_CAMEL})"
)
TS_PROVIDER_ID = (
    rf"(?:tg_id|{TG_PROVIDER_CAMEL}|"
    rf"{LEGACY_PROVIDER_TOKEN}|{LEGACY_PROVIDER_CAMEL})"
)
TS_WALLET_ID = (
    rf"(?:wallet_address|{WALLET_ADDRESS_CAMEL}|"
    rf"ton_wallet|{TON_WALLET_CAMEL})"
)
TYPESCRIPT_MIX_PATTERNS = (
    re.compile(rf"\b{TS_SYSTEM_ID}\s*[:=]\s*{TS_PROVIDER_ID}\b"),
    re.compile(rf"\b{TS_PROVIDER_ID}\s*[:=]\s*{TS_SYSTEM_ID}\b"),
    re.compile(rf"\b{TS_SYSTEM_ID}\s*[:=]\s*{TS_WALLET_ID}\b"),
)
RUNTIME_ROOTS = (
    "backend/app",
    "frontend/src",
)
SKIP_PARTS = {
    ".git",
    ".next",
    "__pycache__",
    "node_modules",
}
TEXT_SUFFIXES = {
    ".js",
    ".jsx",
    ".py",
    ".ts",
    ".tsx",
}
ALLOWED_SEMANTIC_CATEGORIES = {
    "AUTH_IDENTITY",
    "DOMAIN_ACTOR",
    "DOMAIN_OWNER",
    "LEGACY_COMPATIBILITY",
    "SOURCE_EVENT",
    "TELEGRAM_SPECIFIC",
}


def _counts(root: Path) -> tuple[dict[str, int], dict[str, int]]:
    identifiers: dict[str, int] = {}
    dependencies: dict[str, int] = {}
    for relative_root in RUNTIME_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.casefold() not in TEXT_SUFFIXES:
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            relative = path.relative_to(root).as_posix()
            source = path.read_text(
                encoding="utf-8",
                errors="replace",
            )
            identifier_count = len(IDENTIFIER_RE.findall(source))
            dependency_count = len(CURRENT_TG_DEP_RE.findall(source))
            if identifier_count:
                identifiers[relative] = identifier_count
            if dependency_count:
                dependencies[relative] = dependency_count
    return identifiers, dependencies


def _item_path(item: dict[str, Any]) -> str:
    path = item.get("path")
    if isinstance(path, str):
        return path
    parts = item.get("path_parts")
    if isinstance(parts, list) and all(
        isinstance(part, str) for part in parts
    ):
        return "/".join(parts)
    raise ValueError("baseline item has no valid path")


def _load(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    supported = {
        "EFHC_TG_ID_BOUNDARY_BASELINE_V1",
        "EFHC_TG_ID_BOUNDARY_BASELINE_V2",
        "EFHC_TG_ID_BOUNDARY_BASELINE_V3",
        "EFHC_TG_ID_BOUNDARY_BASELINE_V4",
    }
    if data.get("schema") not in supported:
        raise ValueError("unsupported tg_id boundary baseline schema")
    return data


def _forbidden_aliases(root: Path) -> list[str]:
    offenders: list[str] = []
    for relative_root in RUNTIME_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.casefold() not in TEXT_SUFFIXES:
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            relative = path.relative_to(root).as_posix()
            text = path.read_text(
                encoding="utf-8",
                errors="replace",
            )
            for number, line in enumerate(
                text.splitlines(),
                start=1,
            ):
                forbidden = any(
                    pattern.search(line)
                    for pattern in FORBIDDEN_ALIAS_PATTERNS
                )
                if forbidden:
                    offenders.append(
                        f"{relative}:{number}:{line.strip()}"
                    )
    return offenders


def _is_user_name(name: str) -> bool:
    return (
        name in {"user_id", "global_id"}
        or name.startswith("user_id_")
        or name.endswith("_user_id")
        or name.startswith("global_id_")
        or name.endswith("_global_id")
    )


def _is_telegram_name(name: str) -> bool:
    return (
        name in {"tg_id", LEGACY_PROVIDER_TOKEN}
        or name.startswith("tg_id_")
        or name.endswith("_tg_id")
    )


def _is_wallet_name(name: str) -> bool:
    return name in {
        "canonical_address",
        "ton_wallet",
        "wallet_address",
    } or name.endswith("_wallet_address")


def _node_names(node: ast.AST | None) -> set[str]:
    if node is None:
        return set()
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            names.add(child.id)
        elif isinstance(child, ast.Attribute):
            names.add(child.attr)
    return names


def _target_names(node: ast.AST | None) -> set[str]:
    return _node_names(node)


def _bad_user_value(names: set[str]) -> bool:
    return any(_is_telegram_name(name) for name in names) or any(
        _is_wallet_name(name) for name in names
    )


def _finding(relative: str, line: int, message: str) -> str:
    return f"{relative}:{line}:{message}"


def _python_mix_offenders(path: Path, relative: str) -> list[str]:
    source = path.read_text(encoding="utf-8", errors="replace")
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    offenders: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            targets = set().union(
                *(_target_names(target) for target in node.targets)
            )
            value_names = _node_names(node.value)
            if any(_is_user_name(name) for name in targets) and (
                _bad_user_value(value_names)
            ):
                offenders.append(
                    _finding(
                        relative,
                            node.lineno,
                            "system id from provider id",
                        )
                )
            if any(_is_telegram_name(name) for name in targets) and any(
                _is_user_name(name) for name in value_names
            ):
                offenders.append(
                    _finding(
                        relative,
                            node.lineno,
                            "provider id from system id",
                        )
                )
        elif isinstance(node, (ast.AnnAssign, ast.NamedExpr)):
            targets = _target_names(node.target)
            value_names = _node_names(node.value)
            if any(_is_user_name(name) for name in targets) and (
                _bad_user_value(value_names)
            ):
                offenders.append(
                    _finding(
                        relative,
                            node.lineno,
                            "system id from provider id",
                        )
                )
            if any(_is_telegram_name(name) for name in targets) and any(
                _is_user_name(name) for name in value_names
            ):
                offenders.append(
                    _finding(
                        relative,
                            node.lineno,
                            "provider id from system id",
                        )
                )
        elif isinstance(node, ast.Call):
            function_names = _node_names(node.func)
            if (
                {"UserId", "GlobalId"} & function_names
                and node.args
                and _bad_user_value(_node_names(node.args[0]))
            ):
                offenders.append(
                    _finding(
                        relative,
                        node.lineno,
                        "GlobalId/UserId from provider data",
                    )
                )
            for keyword in node.keywords:
                if keyword.arg is None:
                    continue
                value_names = _node_names(keyword.value)
                if _is_user_name(keyword.arg) and _bad_user_value(
                    value_names
                ):
                    offenders.append(
                        _finding(
                            relative,
                            node.lineno,
                            "user_id keyword mixed",
                        )
                    )
                if _is_telegram_name(keyword.arg) and any(
                    _is_user_name(name) for name in value_names
                ):
                    offenders.append(
                        _finding(
                            relative,
                            node.lineno,
                            "tg_id keyword mixed",
                        )
                    )
        elif isinstance(node, ast.Dict):
            for key, value in zip(node.keys, node.values, strict=True):
                if not isinstance(key, ast.Constant):
                    continue
                if not isinstance(key.value, str):
                    continue
                value_names = _node_names(value)
                if _is_user_name(key.value) and _bad_user_value(
                    value_names
                ):
                    offenders.append(
                        _finding(
                            relative,
                            node.lineno,
                            "user_id mapping mixed",
                        )
                    )
                if _is_telegram_name(key.value) and any(
                    _is_user_name(name) for name in value_names
                ):
                    offenders.append(
                        _finding(
                            relative,
                            node.lineno,
                            "tg_id mapping mixed",
                        )
                    )
    return offenders


def _semantic_mix_offenders(root: Path) -> list[str]:
    offenders: list[str] = []
    for relative_root in RUNTIME_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.casefold() not in TEXT_SUFFIXES:
                continue
            if set(path.parts) & SKIP_PARTS:
                continue
            relative = path.relative_to(root).as_posix()
            if path.suffix.casefold() == ".py":
                offenders.extend(
                    _python_mix_offenders(path, relative)
                )
                continue
            text = path.read_text(
                encoding="utf-8",
                errors="replace",
            )
            for number, line in enumerate(
                text.splitlines(),
                start=1,
            ):
                if any(
                    pattern.search(line)
                    for pattern in TYPESCRIPT_MIX_PATTERNS
                ):
                    offenders.append(
                        f"{relative}:{number}:identity types mixed"
                    )
    return offenders


def _item_reason(item: dict[str, Any]) -> str:
    reason = item.get("reason")
    if isinstance(reason, str):
        return reason
    parts = item.get("reason_parts", [])
    return " ".join(str(part) for part in parts).strip()


def _baseline_contract_errors(baseline: dict[str, Any]) -> list[str]:
    if baseline.get("schema") not in {
        "EFHC_TG_ID_BOUNDARY_BASELINE_V2",
        "EFHC_TG_ID_BOUNDARY_BASELINE_V3",
        "EFHC_TG_ID_BOUNDARY_BASELINE_V4",
    }:
        return []
    errors: list[str] = []
    expected = {
        "database_type": "BIGINT",
        "external_pattern": r"^\d{10}$",
        "maximum": 9_999_999_999,
        "minimum": 1,
        "zero_allowed": False,
    }
    if baseline.get("schema") == "EFHC_TG_ID_BOUNDARY_BASELINE_V4":
        contract = baseline.get("global_id_contract")
        if contract != expected:
            errors.append(
                "invalid canonical global_id contract"
            )
    else:
        contract = baseline.get("user_id_contract")
        if contract != expected:
            errors.append(
                "invalid historical user_id contract"
            )
    for item in baseline.get("telegram_specific_allowlist", []):
        categories = set(item.get("categories", []))
        if categories != {"TELEGRAM_SPECIFIC"}:
            errors.append(
                "Telegram allowlist category invalid: "
                f"{_item_path(item)}"
            )
        if not _item_reason(item):
            errors.append(
                f"Telegram allowlist reason missing: {_item_path(item)}"
            )
    for item in baseline.get("identity_specific_allowlist", []):
        categories = set(item.get("categories", []))
        if categories != {"AUTH_IDENTITY"}:
            errors.append(
                "Identity allowlist category invalid: "
                f"{_item_path(item)}"
            )
        if not _item_reason(item):
            errors.append(
                f"Identity allowlist reason missing: {_item_path(item)}"
            )
        if not item.get("permanent_identity_scope"):
            errors.append(
                "Identity allowlist must be permanent scope: "
                f"{_item_path(item)}"
            )
    for item in baseline.get("legacy_runtime_baseline", []):
        categories = set(item.get("categories", []))
        valid_categories = categories <= ALLOWED_SEMANTIC_CATEGORIES
        if not categories or not valid_categories:
            errors.append(
                f"legacy semantic category invalid: {_item_path(item)}"
            )
        if not item.get("planned_removal_cycle"):
            errors.append(
                f"legacy sunset cycle missing: {_item_path(item)}"
            )
        if not _item_reason(item):
            errors.append(
                f"legacy reason missing: {_item_path(item)}"
            )
    return errors



def _registry_identity_files(
    root: Path,
) -> tuple[dict[str, int], list[str]]:
    """Прочитать active allowlist из semantic registry."""

    path = root / (
        "contracts/identity/compatibility_registry_v1.json"
    )
    if not path.exists():
        return {}, []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return {}, [f"identity registry unreadable: {error}"]
    allowed: dict[str, int] = {}
    errors: list[str] = []
    for item in data.get("разрешённые_guard_файлы", []):
        file_path = item.get("путь")
        maximum = item.get("максимум_упоминаний")
        semantic = item.get("семантика")
        reason = item.get("причина")
        if not isinstance(file_path, str) or not file_path:
            errors.append("identity registry guard path invalid")
            continue
        if not isinstance(maximum, int) or maximum < 0:
            errors.append(
                f"identity registry guard maximum invalid: {file_path}"
            )
            continue
        if semantic != "AUTH_IDENTITY":
            errors.append(
                f"identity registry guard semantic invalid: {file_path}"
            )
            continue
        if not isinstance(reason, str) or not reason.strip():
            errors.append(
                f"identity registry guard reason missing: {file_path}"
            )
            continue
        allowed[file_path] = maximum
    return allowed, errors

def check(root: Path, baseline_path: Path) -> dict[str, Any]:
    baseline = _load(baseline_path)
    current_ids, current_deps = _counts(root)
    telegram_files = {
        _item_path(item): int(item["max_identifier_occurrences"])
        for item in baseline["telegram_specific_allowlist"]
    }
    identity_files = {
        _item_path(item): int(item["max_identifier_occurrences"])
        for item in baseline.get("identity_specific_allowlist", [])
    }
    registry_files, registry_errors = _registry_identity_files(root)
    identity_files.update(registry_files)
    legacy_files = {
        _item_path(item): int(item["max_identifier_occurrences"])
        for item in baseline["legacy_runtime_baseline"]
    }
    dependency_files = {
        _item_path(item): int(item["max_occurrences"])
        for item in baseline["get_current_tg_id_baseline"]
    }
    allowed_ids = {**legacy_files, **telegram_files, **identity_files}
    errors = _baseline_contract_errors(baseline)
    errors.extend(registry_errors)
    for path, count in sorted(current_ids.items()):
        maximum = allowed_ids.get(path)
        if maximum is None:
            errors.append(
                "new tracked Telegram identifier surface: "
                f"{path}={count}"
            )
        elif count > maximum:
            errors.append(
                f"tracked identifiers increased: {path} "
                f"{count}>{maximum}"
            )
    for path, count in sorted(current_deps.items()):
        maximum = dependency_files.get(path)
        if maximum is None:
            errors.append(
                f"new get_current_tg_id dependency: {path}={count}"
            )
        elif count > maximum:
            errors.append(
                f"get_current_tg_id increased: {path} "
                f"{count}>{maximum}"
            )
    errors.extend(
        f"forbidden tg_id/user_id alias: {item}"
        for item in _forbidden_aliases(root)
    )
    errors.extend(
        f"forbidden provider/system identity mix: {item}"
        for item in _semantic_mix_offenders(root)
    )
    return {
        "schema": "EFHC_TG_ID_BOUNDARY_RESULT_V2",
        "source_head": baseline["source_head"],
        "target_head": baseline.get("target_head"),
        "cycle": baseline["cycle"],
        "telegram_specific_files": len(telegram_files),
        "identity_specific_files": len(identity_files),
        "legacy_runtime_files": len(legacy_files),
        "tracked_runtime_files": len(current_ids),
        "get_current_tg_id_files": len(current_deps),
        "semantic_mix_offenders": len(
            _semantic_mix_offenders(root)
        ),
        "errors": errors,
        "passed": not errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--baseline",
        type=Path,
        default=Path(
            "ops/identity/tg_id_domain_boundary_baseline.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root.resolve(), args.baseline.resolve())
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.resolve().write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
