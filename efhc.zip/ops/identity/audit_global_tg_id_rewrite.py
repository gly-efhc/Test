#!/usr/bin/env python3
"""Полный inventory употреблений ``tg_id`` для global owner rewrite.

Классификация намеренно fail-closed: каждое runtime-употребление,
которое не
попало в узкую provider/schema/history границу, считается business debt.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEXT_SUFFIXES = {
    ".py", ".sql", ".ts", ".tsx", ".js", ".json", ".md", ".yml",
    ".yaml", ".toml",
}
SKIP_PARTS = {".git", ".next", "node_modules", "__pycache__"}

BOUNDARY_CONTRACT = json.loads(
    (
        ROOT
        / "contracts/identity/global_owner_tg_id_boundary_v1.json"
    ).read_text(encoding="utf-8")
)
PROVIDER_PREFIXES = tuple(
    BOUNDARY_CONTRACT["allowed_runtime_prefixes"]
)
PROVIDER_FILES = set(BOUNDARY_CONTRACT["allowed_runtime_files"])
SCHEMA_PREFIXES = tuple(
    BOUNDARY_CONTRACT["physical_schema_prefixes"]
)

HISTORY_PREFIXES = (
    "docs/",
    "reports/generated/",
)
TEST_PREFIXES = ("tests/",)
GENERATED_PREFIXES = (
    "ops/operator_kernel/",
    "frontend/out/",
)


def classify(path: str, line: str) -> str:
    if path.startswith(HISTORY_PREFIXES):
        return "HISTORICAL_EVIDENCE"
    if path.startswith(TEST_PREFIXES):
        return "TEST_COMPATIBILITY"
    if path.startswith(GENERATED_PREFIXES):
        return "GENERATED_CACHE"
    if path.startswith(SCHEMA_PREFIXES):
        return "PHYSICAL_SCHEMA_ALIAS"
    if path in PROVIDER_FILES or path.startswith(PROVIDER_PREFIXES):
        return "PROVIDER_BOUNDARY"
    if "telegram_provider_id" in line and "tg_id" in line:
        return "ALIAS_HARNESS"
    runtime_prefixes = (
        "backend/",
        "api/",
        "app_not_exist/",
        "frontend/",
    )
    if path.startswith(runtime_prefixes):
        return "BUSINESS_RUNTIME_DEBT"
    if path.startswith(("ops/", "contracts/")):
        return "TOOLING_OR_CONTRACT"
    return "OTHER"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    records: list[dict[str, object]] = []
    for file_path in ROOT.rglob("*"):
        if (
            not file_path.is_file()
            or file_path.suffix.lower() not in TEXT_SUFFIXES
        ):
            continue
        if any(part in SKIP_PARTS for part in file_path.parts):
            continue
        relative = file_path.relative_to(ROOT).as_posix()
        if relative == (
            "reports/generated/global_tg_id_rewrite_audit_v172_66.json"
        ):
            continue
        try:
            lines = file_path.read_text(
                encoding="utf-8",
                errors="ignore",
            ).splitlines()
        except OSError:
            continue
        for line_no, line in enumerate(lines, start=1):
            count = len(re.findall(r"\btg_id\b", line))
            if not count:
                continue
            category = classify(relative, line)
            records.append(
                {
                    "path": relative,
                    "line": line_no,
                    "count": count,
                    "category": category,
                    "text": line.strip()[:300],
                }
            )

    counts = Counter()
    file_counts: Counter[str] = Counter()
    for record in records:
        category = str(record["category"])
        count = int(record["count"])
        counts[category] += count
        file_counts[category] += 1

    payload = {
        "schema": "EFHC_GLOBAL_TG_ID_REWRITE_AUDIT_V1",
        "source": "EFHC_Bot_v172_66.zip",
        "target": "EFHC_Bot_v172_66.zip",
        "policy": {
            "business_owner": "global_id",
            "telegram_fact": "telegram_provider_id",
            "legacy_keyword": "tg_id — только временный alias",
        },
        "total_occurrences": sum(counts.values()),
        "total_lines": len(records),
        "counts_by_category": dict(sorted(counts.items())),
        "lines_by_category": dict(sorted(file_counts.items())),
        "records": records,
    }
    output = args.output
    if output is not None:
        output = output.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    summary = {
        "всего_упоминаний": payload["total_occurrences"],
        "всего_строк": payload["total_lines"],
        "по_категориям": payload["counts_by_category"],
        "файл_аудита": str(output) if output is not None else None,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
