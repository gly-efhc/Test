"""Экспорт изолированного API-контракта ``global_id`` цикла 1606."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Annotated, Any, Final

from app.identity.api_contract import (
    GLOBAL_ID_OPENAPI_EXAMPLE,
    GLOBAL_ID_OPENAPI_FORMAT,
    GLOBAL_ID_OPENAPI_SCHEMA,
    ApiExternalGlobalId,
    GlobalIdResponse,
    PydanticGlobalId,
)
from fastapi import FastAPI
from fastapi import Path as FastApiPath
from pydantic import TypeAdapter

CONTRACT_SCHEMA: Final[str] = "EFHC_GLOBAL_ID_API_CONTRACT_V1"
SOURCE_HEAD: Final[str] = "EFHC_Bot_v172_02.zip"
TARGET_HEAD: Final[str] = "EFHC_Bot_v172_03.zip"
CYCLE: Final[int] = 1606
CONTRACT_PATH: Final[str] = "/contract/global-accounts/{global_id}"


def build_contract() -> dict[str, Any]:
    """Построить детерминированный backend/OpenAPI/frontend fixture."""

    app = FastAPI(title="EFHC Global ID contract fixture")

    @app.get(
        CONTRACT_PATH,
        response_model=GlobalIdResponse,
    )
    def read_global_account_contract(
        global_id: Annotated[
            ApiExternalGlobalId,
            FastApiPath(
                description="Канонический Global ID аккаунта EFHC",
            ),
        ],
    ) -> GlobalIdResponse:
        parsed = TypeAdapter(PydanticGlobalId).validate_python(
            global_id,
        )
        return GlobalIdResponse.from_global_id(parsed)

    openapi = app.openapi()
    operation = openapi["paths"][CONTRACT_PATH]["get"]
    parameter = operation["parameters"][0]["schema"]
    response = openapi["components"]["schemas"][
        "GlobalIdResponse"
    ]["properties"]["global_id"]
    request = TypeAdapter(PydanticGlobalId).json_schema()
    return {
        "схема_контракта": CONTRACT_SCHEMA,
        "исходный_head": SOURCE_HEAD,
        "целевой_head": TARGET_HEAD,
        "цикл": CYCLE,
        "поле": "global_id",
        "пример": GLOBAL_ID_OPENAPI_EXAMPLE,
        "openapi_format": GLOBAL_ID_OPENAPI_FORMAT,
        "openapi_pattern": "^[0-9]{10}$",
        "нулевое_значение_запрещено": True,
        "активные_routes_переключены": False,
        "legacy_envelopes_сохранены": True,
        "изолированный_openapi_path": CONTRACT_PATH,
        "схема_path_параметра": parameter,
        "схема_поля_ответа": response,
        "схема_pydantic_значения": request,
        "backend_константа_схемы": GLOBAL_ID_OPENAPI_SCHEMA,
        "frontend_контракт": {
            "модуль": "frontend/src/contracts/global-id.ts",
            "тип_запроса": "GlobalIdRequestDto",
            "тип_ответа": "GlobalIdResponseDto",
            "поле": "global_id",
            "формат": GLOBAL_ID_OPENAPI_FORMAT,
            "шаблон": "^[0-9]{10}$",
            "wire_тип": "string",
        },
        "инварианты": {
            "ведущие_нули_сохраняются": True,
            "javascript_number_запрещён": True,
            "неопределённый_user_id_запрещён": True,
            "историческое_заполнение": False,
            "переключение_чтения": False,
            "переключение_финансового_владения": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Экспорт API-контракта Global ID цикла 1606.",
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = build_contract()
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
