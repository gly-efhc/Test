"""Экспорт действующего API-контракта ``global_id``."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Annotated, Any, Final

from app.identity.api_contract import (
    GLOBAL_ID_OPENAPI_EXAMPLE,
    GLOBAL_ID_OPENAPI_FORMAT,
    GLOBAL_ID_OPENAPI_SCHEMA,
    ApiExternalGlobalId,
    GlobalIdResponse,
    PydanticGlobalId,
)
from fastapi import FastAPI
from fastapi import Path as FastApiPath
from pydantic import TypeAdapter

CONTRACT_SCHEMA: Final[str] = "EFHC_GLOBAL_ID_API_CONTRACT_V2"
VERSION: Final[str] = "v173.12"
CYCLE: Final[int] = 1692
CONTRACT_PATH: Final[str] = "/contract/global-accounts/{global_id}"


def build_contract() -> dict[str, Any]:
    """Построить детерминированный current-contract fixture."""

    app = FastAPI(title="EFHC Global ID contract fixture")

    @app.get(CONTRACT_PATH, response_model=GlobalIdResponse)
    def read_global_account_contract(
        global_id: Annotated[
            ApiExternalGlobalId,
            FastApiPath(description="Канонический Global ID аккаунта EFHC"),
        ],
    ) -> GlobalIdResponse:
        parsed = TypeAdapter(PydanticGlobalId).validate_python(global_id)
        return GlobalIdResponse.from_global_id(parsed)

    openapi = app.openapi()
    operation = openapi["paths"][CONTRACT_PATH]["get"]
    parameter = operation["parameters"][0]["schema"]
    response = openapi["components"]["schemas"]["GlobalIdResponse"][
        "properties"
    ]["global_id"]
    request = TypeAdapter(PydanticGlobalId).json_schema()
    return {
        "схема_контракта": CONTRACT_SCHEMA,
        "версия": VERSION,
        "цикл": CYCLE,
        "поле": "global_id",
        "пример": GLOBAL_ID_OPENAPI_EXAMPLE,
        "openapi_format": GLOBAL_ID_OPENAPI_FORMAT,
        "openapi_pattern": "^[0-9]{10}$",
        "нулевое_значение_запрещено": True,
        "active_routes_use_global_id_contract": True,
        "active_compatibility_aliases": 0,
        "изолированный_openapi_path": CONTRACT_PATH,
        "схема_path_параметра": parameter,
        "схема_поля_ответа": response,
        "схема_pydantic_значения": request,
        "backend_константа_схемы": GLOBAL_ID_OPENAPI_SCHEMA,
        "frontend_контракт": {
            "модуль": "frontend/src/contracts/global-id.ts",
            "тип_запроса": "GlobalIdRequestDto",
            "тип_ответа": "GlobalIdResponseDto",
            "поле": "global_id",
            "формат": GLOBAL_ID_OPENAPI_FORMAT,
            "шаблон": "^[0-9]{10}$",
            "wire_тип": "string",
        },
        "инварианты": {
            "ведущие_нули_сохраняются": True,
            "javascript_number_запрещён": True,
            "json_number_запрещён": True,
            "provider_subject_not_owner": True,
            "physical_owner_column": "users.global_id",
            "single_alembic_head": "0001_initial_release_schema.py",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Экспорт действующего API-контракта Global ID.",
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = build_contract()
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
