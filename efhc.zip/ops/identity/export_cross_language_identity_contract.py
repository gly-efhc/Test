"""Построение cross-language контракта GlobalId и TelegramId."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from app.identity.types import (
    GLOBAL_ID_DIGITS,
    GLOBAL_ID_MAX,
    GLOBAL_ID_MIN,
    GLOBAL_ID_PATTERN_TEXT,
    TG_ID_MAX,
    TG_ID_MIN,
)


def build_contract() -> dict[str, Any]:
    """Вернуть канонический контракт без runtime-переключения."""

    return {
        "схема_контракта": (
            "EFHC_CROSS_LANGUAGE_IDENTITY_SEPARATION_V1"
        ),
        "global_id": {
            "nominal_type": "GlobalId",
            "wire_type": "string",
            "pattern": GLOBAL_ID_PATTERN_TEXT,
            "digits": GLOBAL_ID_DIGITS,
            "minimum": GLOBAL_ID_MIN,
            "maximum": GLOBAL_ID_MAX,
            "zero_forbidden": True,
        },
        "tg_id": {
            "nominal_type": "TelegramId",
            "wire_type": "integer",
            "provider": "telegram",
            "minimum": TG_ID_MIN,
            "maximum": TG_ID_MAX,
        },
        "запреты": [
            "global_id_from_tg_id",
            "tg_id_from_global_id",
            "global_id_to_telegram_api",
            "provider_id_as_domain_owner",
        ],
        "активные_routes_переключены": False,
        "postgresql_read_switch": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Экспорт cross-language контракта GlobalId/TelegramId."
        )
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = json.dumps(
        build_contract(),
        ensure_ascii=False,
        indent=2,
    ) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
