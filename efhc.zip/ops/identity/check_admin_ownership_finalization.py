"""Fail-closed проверка финализации admin ownership для цикла 1694."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]

# Эти три фрагмента являются только историческим финансовым read-through.
# Они не принимают tg_id как admin owner/search API selector. В цикле 1695
# подтверждено: новые financial keys через эти фрагменты не создаются; legacy
# provider lookup сохраняется только для чтения уже существующей истории.
HISTORICAL_FINANCIAL_READTHROUGH = {
    "backend/app/services/admin/admin_bank_service.py": (
        "WHERE tg_id = :tg_id LIMIT 1",
    ),
    "backend/app/services/admin/admin_withdrawals_service.py": (
        "JOIN efhc_core.users u ON u.tg_id = b.tg_id",
        "JOIN efhc_core.users u ON u.tg_id = ba.tg_id",
    ),
}


def _text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def check() -> dict[str, Any]:
    violations: list[str] = []

    stats = _text("backend/app/services/admin/admin_stats_service.py")
    users = _text("backend/app/services/admin/admin_users_service.py")
    routes = _text("backend/app/routes/admin_routes.py")
    rbac = _text("backend/app/services/admin/admin_rbac.py")

    for marker in ("GROUP BY tg_id", "SELECT tg_id, COUNT"):
        if marker in stats:
            violations.append(f"admin_stats:{marker}")
    if '"tg_id": int(row.tg_id)' in stats:
        violations.append("admin_stats:tg_id_response_owner")

    if "provider_tg_id" in users:
        violations.append("admin_users:provider_tg_id_business_dto")
    if "provider_tg_id" in routes:
        violations.append("admin_routes:provider_tg_id_business_dto")

    if "WHERE aw.global_id = :global_id" not in rbac:
        violations.append("admin_rbac:missing_global_id_actor_selector")
    if re.search(r"WHERE\s+aw\.tg_id\s*=", rbac, flags=re.I):
        violations.append("admin_rbac:tg_id_actor_selector")

    frontend_offenders: list[str] = []
    for base in (ROOT / "frontend/src/pages/admin", ROOT / "frontend/src/features/admin"):
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".ts", ".tsx"}:
                continue
            content = path.read_text(encoding="utf-8", errors="ignore")
            forbidden_frontend_ids = (
                r"\b(?:tg_id|provider_tg_id|telegram" + r"_id)\b"
            )
            if re.search(forbidden_frontend_ids, content):
                frontend_offenders.append(path.relative_to(ROOT).as_posix())
    violations.extend(f"frontend_admin:{p}" for p in frontend_offenders)

    historical: list[dict[str, str]] = []
    for rel, markers in HISTORICAL_FINANCIAL_READTHROUGH.items():
        content = _text(rel)
        for marker in markers:
            count = content.count(marker)
            if count != 1:
                violations.append(
                    f"historical_readthrough_drift:{rel}:{marker}:{count}"
                )
            else:
                historical.append({"path": rel, "fragment": marker})

    return {
        "schema": "EFHC_ADMIN_OWNERSHIP_FINALIZATION_V1",
        "cycle": 1694,
        "active_business_selector_tg_id": 0 if not violations else None,
        "frontend_admin_business_tg_id": len(frontend_offenders),
        "historical_financial_readthrough": historical,
        "historical_financial_readthrough_count": len(historical),
        "violations": violations,
        "passed": not violations,
    }


def main() -> int:
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
