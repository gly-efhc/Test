"""Render the cycle-1598 future UserId backfill harness."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.identity.legacy_alias import build_legacy_user_id_alias_plan
from app.identity.user_id_backfill import (
    BACKFILL_APPLY_ENABLED,
    postgres_user_id_backfill_apply_sql,
    postgres_user_id_backfill_preflight_sql,
)


def render(output_dir: Path) -> dict[str, object]:
    """Write render-only SQL and machine-readable metadata."""

    output_dir.mkdir(parents=True, exist_ok=True)
    preflight = output_dir / "user_id_backfill_preflight_v171_95.sql"
    future_apply = (
        output_dir / "user_id_backfill_apply_future_v171_95.sql"
    )
    preflight.write_text(
        postgres_user_id_backfill_preflight_sql(),
        encoding="utf-8",
    )
    future_apply.write_text(
        postgres_user_id_backfill_apply_sql(),
        encoding="utf-8",
    )
    alias = build_legacy_user_id_alias_plan()
    result = {
        "schema": "EFHC_USER_ID_BACKFILL_HARNESS_V1",
        "cycle": 1598,
        "source_head": "EFHC_Bot_v171_94.zip",
        "target_head": "EFHC_Bot_v171_95.zip",
        "apply_enabled": BACKFILL_APPLY_ENABLED,
        "runtime_read_switch": False,
        "database_executed": False,
        "mapping_rule": "NULL users.user_id -> users.id",
        "tg_id_used_for_mapping": False,
        "wallet_used_for_mapping": False,
        "active_alias": alias.active_alias,
        "active_alias_target": alias.active_target,
        "future_alias": alias.future_alias,
        "future_alias_target": alias.future_target,
        "preflight_sql": preflight.as_posix(),
        "future_apply_sql": future_apply.as_posix(),
    }
    metadata = output_dir / "user_id_backfill_harness_v171_95.json"
    metadata.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(
            "reports/generated/user_id_backfill_v171_95"
        ),
    )
    args = parser.parse_args()
    result = render(args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
