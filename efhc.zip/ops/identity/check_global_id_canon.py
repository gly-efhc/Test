"""Fail-closed guard физического ``global_id`` цикла 1631."""

from __future__ import annotations

import argparse
import ast
import json
import re
from pathlib import Path
from typing import Final

CYCLE: Final[int] = 1631
TARGET_HEAD: Final[str] = "EFHC_Bot_v172_46.zip"

PRODUCTION_ROOTS: Final[tuple[str, ...]] = (
    "backend/app",
    "api",
    "frontend/src",
)

PROVIDER_NAMES: Final[set[str]] = {
    "tg_id",
    "telegram_id",
    "tgId",
    "telegramId",
    "wallet_address",
    "walletAddress",
    "ton_wallet",
    "google_id",
    "facebook_id",
    "apple_id",
    "microsoft_id",
    "github_id",
    "email",
    "phone",
    "provider_subject",
}

TEXT_PATTERNS: Final[tuple[re.Pattern[str], ...]] = (
    re.compile(
        r"\bglobal_id\s*=\s*(?:int\s*\(\s*)?"
        r"(?:tg_id|telegram_id|wallet_address|ton_wallet|"
        r"google_id|facebook_id|apple_id|microsoft_id|github_id|"
        r"email|phone|provider_subject)\b"
    ),
    re.compile(
        r"\bglobalId\s*=\s*(?:Number\s*\(\s*)?"
        r"(?:tgId|telegramId|walletAddress|googleId|facebookId|"
        r"appleId|microsoftId|githubId|email|phone|providerSubject)\b"
    ),
    re.compile(
        r"\bGlobalId\s*\(\s*(?:tg_id|telegram_id|wallet_address|"
        r"ton_wallet|google_id|facebook_id|apple_id|microsoft_id|"
        r"github_id|email|phone|provider_subject)\b"
    ),
    re.compile(r"\bglobal_id\s*=\s*(?:user\.)?id\b"),
    re.compile(r"\bglobalId\s*=\s*(?:user\.)?id\b"),
    re.compile(r"\bGlobalId\s*\(\s*(?:user\.)?id\b"),
)


def _target_names(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, (ast.Tuple, ast.List)):
        result: set[str] = set()
        for item in node.elts:
            result.update(_target_names(item))
        return result
    if isinstance(node, ast.Attribute):
        return {node.attr}
    return set()


def _source_names(node: ast.AST) -> set[str]:
    return {
        item.id
        for item in ast.walk(node)
        if isinstance(item, ast.Name)
    } | {
        item.attr
        for item in ast.walk(node)
        if isinstance(item, ast.Attribute)
    }


def найти_смешение_provider_global_id(
    root: Path,
) -> list[dict[str, object]]:
    """Найти прямое либо косвенное provider-to-global смешение."""

    findings: list[dict[str, object]] = []
    for relative_root in PRODUCTION_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix not in {
                ".py",
                ".ts",
                ".tsx",
                ".js",
                ".mjs",
            }:
                continue
            source = path.read_text(encoding="utf-8", errors="replace")
            rel = path.relative_to(root).as_posix()
            for line_number, line in enumerate(source.splitlines(), 1):
                matched = any(
                    pattern.search(line)
                    for pattern in TEXT_PATTERNS
                )
                if matched:
                    findings.append(
                        {
                            "файл": rel,
                            "строка": line_number,
                            "причина": "provider_to_global_assignment",
                            "фрагмент": line.strip(),
                        }
                    )
            if path.suffix != ".py":
                continue
            try:
                tree = ast.parse(source, filename=rel)
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                targets: set[str] = set()
                value: ast.AST | None = None
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        targets.update(_target_names(target))
                    value = node.value
                elif isinstance(node, ast.AnnAssign):
                    targets.update(_target_names(node.target))
                    value = node.value
                is_global_target = bool(
                    {"global_id", "globalId"} & targets
                )
                if value is None or not is_global_target:
                    continue
                sources = _source_names(value)
                if PROVIDER_NAMES & sources:
                    finding = {
                        "файл": rel,
                        "строка": getattr(node, "lineno", 0),
                        "причина": "provider_to_global_ast_assignment",
                        "источники": sorted(PROVIDER_NAMES & sources),
                    }
                    if finding not in findings:
                        findings.append(finding)
    return findings



def найти_новые_legacy_контракты(root: Path) -> list[dict[str, object]]:
    """Запретить новые user_id DTO и FK на локальный users.id."""

    findings: list[dict[str, object]] = []
    allowed_user_id_paths = {
        "backend/app/identity/legacy_user_id.py",
        "backend/app/identity/user_id_backfill.py",
        "backend/app/models/user_models.py",
    }
    for relative_root in PRODUCTION_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix not in {
                ".py", ".ts", ".tsx", ".js", ".mjs"
            }:
                continue
            relative = path.relative_to(root).as_posix()
            source = path.read_text(encoding="utf-8", errors="replace")
            for line_number, line in enumerate(source.splitlines(), 1):
                if re.search(
                    r"ForeignKey\(\s*[\"']users\.id[\"']",
                    line,
                ):
                    findings.append(
                        {
                            "файл": relative,
                            "строка": line_number,
                            "причина": "new_fk_to_local_users_id",
                            "фрагмент": line.strip(),
                        }
                    )
                if (
                    relative not in allowed_user_id_paths
                    and re.search(r"^\s*user_id\s*[:=]", line)
                ):
                    findings.append(
                        {
                            "файл": relative,
                            "строка": line_number,
                            "причина": (
                                "new_undefined_user_id_dto_or_field"
                            ),
                            "фрагмент": line.strip(),
                        }
                    )
    return findings

def проверить(root: Path) -> dict[str, object]:
    """Проверить exact tree на соблюдение канона цикла 1602."""

    violations: list[str] = []
    details: dict[str, object] = {}

    from app.identity.legacy_alias import build_global_id_alias_plan
    from app.models.user_models import User
    from sqlalchemy import inspect

    mapper = inspect(User)
    columns = list(User.__table__.c.keys())
    details["столбцы_users"] = columns
    details["версии_alembic"] = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
    )

    expected_aliases = {
        "user_id": "global_id",
        "legacy_pk": "id",
        "telegram_id": "tg_id",
        "legacy_runtime_id": "id",
    }
    alias_targets: dict[str, str | None] = {}
    for alias, target in expected_aliases.items():
        if alias not in mapper.attrs:
            violations.append(f"отсутствует ORM alias User.{alias}")
            alias_targets[alias] = None
            continue
        actual = getattr(mapper.attrs[alias], "name", None)
        alias_targets[alias] = actual
        if actual != target:
            violations.append(
                f"User.{alias} указывает на {actual!r}, "
                f"ожидался {target!r}"
            )
    details["совместимые_имена_проверены"] = True

    if "global_id" not in columns:
        violations.append("отсутствует физическая users.global_id")
    if "user_id" in columns:
        violations.append(
            "обнаружена отдельная legacy-колонка users.user_id"
        )
    if User.__table__.c.global_id.nullable is not True:
        violations.append(
            "cycle 1631 не должен добавлять NOT NULL автоматически"
        )
    if User.__table__.c.id.primary_key is not True:
        violations.append(
            "users.id преждевременно перестал быть primary key"
        )
    if User.__table__.c.tg_id.nullable is not True:
        violations.append(
            "users.tg_id должна быть nullable с цикла 1617"
        )

    plan = build_global_id_alias_plan()
    details["план_aliases"] = {
        "цикл_создания": plan.cycle_created,
        "физическая_колонка": plan.physical_column,
        "канонический_alias": plan.canonical_alias,
        "каноническая_цель": plan.canonical_target,
        "цикл_физического_переименования": plan.physical_rename_cycle,
        "цикл_удаления_совместимости": plan.compatibility_removal_cycle,
        "переключение_чтения": plan.runtime_read_switch,
        "схема_базы_изменена": plan.database_schema_changed,
    }
    if not plan.runtime_read_switch:
        violations.append("alias plan потерял завершённый read switch")
    if not plan.database_schema_changed:
        violations.append("alias plan не фиксирует physical rename")

    versions = details["версии_alembic"]
    if versions != [
        "0001_initial_release_schema.py",
    ]:
        violations.append(
            "active Alembic lineage должна содержать "
            "единую pre-release baseline 0001"
        )

    required_docs = {
        "docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md": (
            "Главным, постоянным и неизменяемым идентификатором",
            "User.user_id = synonym(\"global_id\")",
            "physical rename",
        ),
        "docs/NORM/GLOBAL_IDENTITY_MIGRATION_NORM.md": (
            "`global_id` / `GlobalId`",
            "users.user_id → users.global_id",
            "reverse compatibility alias",
        ),
        (
            "docs/cycles/"
            "WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md"
        ): (
            "1602",
            "Канон `global_id`",
            "`PG-0`",
        ),
    }
    for relative, tokens in required_docs.items():
        path = root / relative
        if not path.is_file():
            violations.append(
                f"отсутствует канонический документ {relative}"
            )
            continue
        source = path.read_text(encoding="utf-8")
        for token in tokens:
            if token not in source:
                violations.append(
                    f"{relative}: отсутствует marker {token!r}"
                )

    mix = найти_смешение_provider_global_id(root)
    details["смешение_provider_global_id"] = mix
    if mix:
        violations.append(
            "обнаружено provider/local-PK-to-global смешений: "
            f"{len(mix)}"
        )

    legacy_contracts = найти_новые_legacy_контракты(root)
    details["новые_legacy_контракты"] = legacy_contracts
    if legacy_contracts:
        violations.append(
            "обнаружены новые DTO user_id либо FK на "
            "локальный users.id: "
            f"{len(legacy_contracts)}"
        )

    return {
        "схема_отчёта": "EFHC_GLOBAL_ID_CANON_GUARD_V1",
        "цикл": CYCLE,
        "целевой_head": TARGET_HEAD,
        "пройдено": not violations,
        "нарушения": violations,
        "детали": details,
        "физический_global_id": "global_id" in columns,
        "historical_backfill": True,
        "переключение_чтения": True,
        "переключение_финансового_владения": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка physical global_id цикла 1631"
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
