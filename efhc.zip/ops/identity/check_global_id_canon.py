"""Fail-closed guard действующего канона идентичности EFHC.

Цикл 1692 проверяет фактический post-cutover контракт:
``global_id`` — единственный business/account owner, ``tg_id`` — только
Telegram provider subject на ingress/delivery/mapping boundaries.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from collections.abc import Iterable
from pathlib import Path

CYCLE = 1692
TARGET_HEAD = "v173.12"
PRODUCTION_ROOTS = (
    "backend/app",
    "frontend/src",
)
PROVIDER_NAMES = {
    "tg_id",
    "telegram_id",
    "provider_tg_id",
    "wallet_address",
    "ton_wallet_id",
}
TEXT_PATTERNS = (
    re.compile(r"\bglobal_id\s*=\s*(?:int\s*\()?\s*tg_id\b"),
    re.compile(r"\bglobalId\s*=\s*(?:Number\s*\()?\s*tg[_A-Z]?id\b"),
    re.compile(r"\bglobalId\s*=\s*walletAddress\b"),
)


def _iter_sources(root: Path) -> Iterable[tuple[Path, str]]:
    for relative_root in PRODUCTION_ROOTS:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix not in {
                ".py",
                ".ts",
                ".tsx",
                ".js",
                ".mjs",
            }:
                continue
            yield path, path.read_text(
                encoding="utf-8",
                errors="replace",
            )


def _target_names(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, ast.Attribute):
        return {node.attr}
    if isinstance(node, (ast.Tuple, ast.List)):
        names: set[str] = set()
        for item in node.elts:
            names.update(_target_names(item))
        return names
    return set()


def _source_names(node: ast.AST) -> set[str]:
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            names.add(child.id)
        elif isinstance(child, ast.Attribute):
            names.add(child.attr)
    return names


def найти_смешение_provider_global_id(
    root: Path,
) -> list[dict[str, object]]:
    """Найти прямое превращение provider/local values в global_id."""

    findings: list[dict[str, object]] = []
    for path, source in _iter_sources(root):
        rel = path.relative_to(root).as_posix()
        for line_number, line in enumerate(source.splitlines(), 1):
            if any(pattern.search(line) for pattern in TEXT_PATTERNS):
                findings.append(
                    {
                        "файл": rel,
                        "строка": line_number,
                        "причина": "provider_to_global_assignment",
                        "фрагмент": line.strip(),
                    }
                )
        if path.suffix != ".py":
            continue
        try:
            tree = ast.parse(source, filename=rel)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            targets: set[str] = set()
            value: ast.AST | None = None
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    targets.update(_target_names(target))
                value = node.value
            elif isinstance(node, ast.AnnAssign):
                targets.update(_target_names(node.target))
                value = node.value
            if value is None or not (
                {"global_id", "globalId"} & targets
            ):
                continue
            sources = _source_names(value)
            provider_sources = PROVIDER_NAMES & sources
            local_pk_sources = {
                f"{child.value.id}.id"
                for child in ast.walk(value)
                if isinstance(child, ast.Attribute)
                and child.attr == "id"
                and isinstance(child.value, ast.Name)
                and child.value.id in {"user", "account", "owner"}
            }
            provider_sources.update(local_pk_sources)
            if provider_sources:
                finding = {
                    "файл": rel,
                    "строка": getattr(node, "lineno", 0),
                    "причина": "provider_to_global_ast_assignment",
                    "источники": sorted(provider_sources),
                }
                if finding not in findings:
                    findings.append(finding)
    return findings


def найти_новые_legacy_контракты(
    root: Path,
) -> list[dict[str, object]]:
    """Запретить новые ``user_id`` DTO/FK и legacy ORM aliases."""

    findings: list[dict[str, object]] = []
    historical_modules = {
    }
    for path, source in _iter_sources(root):
        relative = path.relative_to(root).as_posix()
        for line_number, line in enumerate(source.splitlines(), 1):
            if re.search(
                r"ForeignKey\(\s*[\"'][^\"']*users\.id[\"']",
                line,
            ):
                findings.append(
                    {
                        "файл": relative,
                        "строка": line_number,
                        "причина": "new_fk_to_local_users_id",
                        "фрагмент": line.strip(),
                    }
                )
            if relative not in historical_modules and re.search(
                r"^\s*user_id\s*[:=]", line
            ):
                findings.append(
                    {
                        "файл": relative,
                        "строка": line_number,
                        "причина": "new_undefined_user_id_dto_or_field",
                        "фрагмент": line.strip(),
                    }
                )
            if relative.endswith("models/user_models.py") and re.search(
                (
                    r"\b(?:user_id|legacy_pk|legacy_runtime_id|"
                    r"telegram_id)\s*=\s*synonym\("
                ),
                line,
            ):
                findings.append(
                    {
                        "файл": relative,
                        "строка": line_number,
                        "причина": "retired_orm_identity_alias",
                        "фрагмент": line.strip(),
                    }
                )
    return findings


def _business_tg_fk_findings(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    models = root / "backend/app/models"
    for path in sorted(models.glob("*_models.py")):
        source = path.read_text(encoding="utf-8", errors="replace")
        rel = path.relative_to(root).as_posix()
        for line_number, line in enumerate(source.splitlines(), 1):
            if re.search(r"users\.tg_id", line):
                findings.append(
                    {
                        "файл": rel,
                        "строка": line_number,
                        "причина": "business_fk_to_provider_subject",
                        "фрагмент": line.strip(),
                    }
                )
    return findings


def _frontend_numeric_findings(root: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    base = root / "frontend/src"
    if not base.exists():
        return findings
    patterns = (
        re.compile(r"\bNumber\s*\(\s*global_id\s*\)"),
        re.compile(r"\bparseInt\s*\(\s*global_id\b"),
        re.compile(r"\+\s*global_id\b"),
    )
    for path in sorted(base.rglob("*")):
        if path.suffix not in {".ts", ".tsx", ".js", ".mjs"}:
            continue
        source = path.read_text(encoding="utf-8", errors="replace")
        for line_number, line in enumerate(source.splitlines(), 1):
            if any(pattern.search(line) for pattern in patterns):
                findings.append(
                    {
                        "файл": path.relative_to(root).as_posix(),
                        "строка": line_number,
                        "причина": "frontend_numeric_global_id",
                        "фрагмент": line.strip(),
                    }
                )
    return findings


def проверить(root: Path) -> dict[str, object]:
    """Проверить exact tree на действующий канон цикла 1688."""

    root = root.resolve()
    violations: list[str] = []
    details: dict[str, object] = {}

    backend_path = str(root / "backend")
    if backend_path not in sys.path:
        sys.path.insert(0, backend_path)
    from app.models.user_models import User
    from sqlalchemy import inspect

    mapper = inspect(User)
    columns = list(User.__table__.c.keys())
    details["столбцы_users"] = columns
    details["версии_alembic"] = sorted(
        path.name
        for path in (root / "backend/migrations/versions").glob("*.py")
        if path.name != "__init__.py"
    )

    if "global_id" not in columns:
        violations.append("отсутствует физическая users.global_id")
    if "user_id" in columns:
        violations.append("физическая users.user_id запрещена")
    if User.__table__.c.global_id.nullable:
        violations.append("users.global_id должна быть NOT NULL")
    if User.__table__.c.id.primary_key is not True:
        violations.append("users.id должен оставаться техническим PK")
    if User.__table__.c.tg_id.nullable is not True:
        violations.append(
            "users.tg_id должна быть nullable provider field"
        )
    for retired in (
        "user_id",
        "legacy_pk",
        "legacy_runtime_id",
        "telegram_id",
    ):
        if retired in mapper.attrs:
            violations.append(
                f"retired ORM alias User.{retired} найден"
            )

    if details["версии_alembic"] != ["0001_initial_release_schema.py"]:
        violations.append(
            "активная Alembic lineage должна содержать только 0001"
        )

    required_docs = {
        "docs/SSOT/GLOBAL_IDENTITY_SSOT.md": (
            "`global_id` — главный",
            "provider + subject",
            "business runtime",
            "0000000000",
        ),
        "docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md": (
            "business-owner tg_id = 0",
            "tests",
            "ACTIVE DOCUMENTS",
        ),
        "docs/SSOT/GLOBAL_IDENTITY_BOUNDARY_LOCK.md": (
            "SYSTEM LOCK / ACTIVE",
            "identity mapping",
            "global_id",
        ),
    }
    for relative, tokens in required_docs.items():
        path = root / relative
        if not path.is_file():
            violations.append(f"отсутствует active document {relative}")
            continue
        source = path.read_text(encoding="utf-8")
        for token in tokens:
            if token not in source:
                violations.append(
                    f"{relative}: отсутствует marker {token!r}"
                )

    mix = найти_смешение_provider_global_id(root)
    legacy_contracts = найти_новые_legacy_контракты(root)
    business_tg_fks = _business_tg_fk_findings(root)
    frontend_numeric = _frontend_numeric_findings(root)
    details["смешение_provider_global_id"] = mix
    details["новые_legacy_контракты"] = legacy_contracts
    details["business_tg_fk"] = business_tg_fks
    details["frontend_numeric_global_id"] = frontend_numeric

    if mix:
        violations.append(
            f"обнаружено provider/local-to-global смешений: {len(mix)}"
        )
    if legacy_contracts:
        violations.append(
            "обнаружено legacy identity contracts: "
            f"{len(legacy_contracts)}"
        )
    if business_tg_fks:
        violations.append(
            "обнаружено owner FK на users.tg_id: "
            f"{len(business_tg_fks)}"
        )
    if frontend_numeric:
        violations.append(
            "обнаружено numeric coercion global_id: "
            f"{len(frontend_numeric)}"
        )

    return {
        "схема_отчёта": "EFHC_GLOBAL_ID_CANON_GUARD_V2",
        "цикл": CYCLE,
        "целевой_head": TARGET_HEAD,
        "пройдено": not violations,
        "нарушения": violations,
        "детали": details,
        "физический_global_id": "global_id" in columns,
        "historical_backfill": True,
        "переключение_чтения": True,
        "переключение_финансового_владения": True,
        "business_owner_tg_id": len(business_tg_fks),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Проверка канона global_id цикла 1688"
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root)
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
