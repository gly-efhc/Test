#!/usr/bin/env python3
"""Статический guard TON account registration цикла 1617."""

from __future__ import annotations

import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVICE = ROOT / "backend/app/identity/ton_account_registration.py"
MIGRATION = (
    ROOT
    / "backend/migrations/versions"
    / "0001_initial_release_schema.py"
)
ROUTE = ROOT / "backend/app/routes/auth_ton_routes.py"
CONTRACT = (
    ROOT
    / "contracts/identity/ton_account_registration_contract_v1.json"
)


def main() -> int:
    """Проверить только статические инварианты цикла 1617."""

    for path in (SERVICE, MIGRATION, ROUTE):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    service = SERVICE.read_text(encoding="utf-8")
    migration = MIGRATION.read_text(encoding="utf-8")
    route = ROUTE.read_text(encoding="utf-8")
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))

    required = (
        "PostgreSQLIdentityResolver",
        "register_or_resolve_in_transaction",
        "User(tg_id=None)",
        'outcome="registered"',
        "FAKE_TG_ID_FORBIDDEN",
    )
    missing = [marker for marker in required if marker not in service]
    if missing:
        message = "Отсутствуют service markers: "
        raise SystemExit(message + ", ".join(missing))

    if 'revision = "0001"' not in migration:
        raise SystemExit("Единая release migration 0001 не найдена")
    model = (ROOT / "backend/app/models/user_models.py").read_text(
        encoding="utf-8"
    )
    if 'tg_id: Mapped[int | None]' not in model:
        raise SystemExit(
            "TON-only nullable tg_id не зафиксирован в ORM"
        )
    if "get_ton_auth_session_service" not in route:
        raise SystemExit(
            "TON auth session service не подключён к endpoint"
        )
    if "await auth_service.login(verified)" not in route:
        raise SystemExit(
            "TON account registration не подключена к login"
        )
    if contract.get("цикл") != 1617:
        raise SystemExit("Неверный цикл machine contract")
    if contract.get("ton_only", {}).get("fake_tg_id") is not False:
        raise SystemExit("Machine contract допускает fake tg_id")
    print("TON_ACCOUNT_REGISTRATION_STATIC_GUARD_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
