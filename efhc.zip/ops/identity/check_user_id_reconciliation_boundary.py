#!/usr/bin/env python3
"""Проверить границу изменений сверки PostgreSQL цикла 1599."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

СХЕМА = "EFHC_USER_ID_RECONCILIATION_BOUNDARY_V1"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(root: Path, manifest_path: Path) -> dict[str, Any]:
    """Проверить отсутствие read switch и финансовых изменений."""

    root = root.resolve()
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != СХЕМА:
        raise ValueError("Неизвестная схема patch boundary")

    expected = {
        (
            item.get("path")
            or "".join(item.get("path_fragments", []))
        ): (
            item.get("sha256")
            or "".join(item.get("sha256_fragments", []))
        )
        for item in data["entries"]
    }
    missing: list[str] = []
    changed: list[str] = []
    for relative, expected_hash in expected.items():
        path = root / relative
        if not path.is_file():
            missing.append(relative)
        elif _sha256(path) != expected_hash:
            changed.append(relative)

    migrations = sorted(
        item.name
        for item in (root / "backend/migrations/versions").glob("*.py")
    )
    expected_migrations = [
        "0001_init.py",
        "0002_users_user_id_expand.py",
    ]

    deps = (root / "backend/app/deps.py").read_text(encoding="utf-8")
    harness = (
        root / "backend/app/identity/user_id_backfill.py"
    ).read_text(encoding="utf-8")
    gate = (
        root / "ops/identity/postgresql_reconciliation_gate.py"
    ).read_text(encoding="utf-8")

    forbidden: list[str] = []
    if "get_current_user_id" in deps:
        forbidden.append(
            "Обнаружен преждевременный get_current_user_id"
        )
    if "BACKFILL_APPLY_ENABLED: Final[bool] = True" in harness:
        forbidden.append("Историческое заполнение включено")
    if "READ ONLY DEFERRABLE" not in gate:
        forbidden.append(
            "Сверка не зафиксирована как только для чтения"
        )
    for token in (
        "UPDATE efhc_core",
        "INSERT INTO efhc_core",
        "DELETE FROM efhc_core",
        "TRUNCATE ",
        "ALTER TABLE ",
    ):
        if token in gate:
            forbidden.append(
                f"В шлюзе найден изменяющий SQL: {token}"
            )

    errors: list[str] = []
    if missing:
        errors.append(f"Отсутствуют защищённые файлы: {missing}")
    if changed:
        errors.append(f"Изменены защищённые файлы: {changed}")
    if migrations != expected_migrations:
        errors.append(f"Неожиданная цепочка миграций: {migrations}")
    errors.extend(forbidden)

    return {
        "схема_отчёта": (
            "EFHC_USER_ID_RECONCILIATION_BOUNDARY_RESULT_V1"
        ),
        "цикл": 1599,
        "исходный_архив": "EFHC_Bot_v171_95.zip",
        "целевой_архив": "EFHC_Bot_v171_96.zip",
        "защищённых_файлов": len(expected),
        "отсутствуют": missing,
        "изменены": changed,
        "миграции": migrations,
        "переключение_чтения_выполнено": False,
        "историческое_заполнение_выполнено": False,
        "финансовые_изменения": False,
        "пройдено": not errors,
        "ошибки": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path(
            "ops/identity/user_id_reconciliation_patch_boundary.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root, args.manifest)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(text, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0 if result["пройдено"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
