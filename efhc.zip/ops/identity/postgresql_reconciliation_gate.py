#!/usr/bin/env python3
"""Выполнить read-only Global ID reconciliation на PostgreSQL.

Шлюз работает только с реальным PostgreSQL-соединением. Он не создаёт
таблицы, не выполняет historical backfill и не переключает runtime
чтение. Все метрики снимаются в одной транзакции ``REPEATABLE READ``,
``READ ONLY``, ``DEFERRABLE`` и завершаются явным ``ROLLBACK``.

Коды возврата:

* ``0`` — реальный PostgreSQL-снимок получен, все проверки пройдены;
* ``2`` — реальный PostgreSQL-снимок получен, обнаружены нарушения;
* ``3`` — PostgreSQL-среда недоступна;
* ``4`` — ошибка исполнения или неполный снимок;
* ``5`` — некорректные provenance-параметры.
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Final, Protocol

from app.identity.reconciliation import evaluate_reconciliation

ОЖИДАЕМАЯ_РЕВИЗИЯ: Final[str] = "0002"
МИНИМАЛЬНАЯ_ВЕРСИЯ_POSTGRESQL: Final[int] = 160000
ФИНАНСОВЫЙ_ДОПУСК: Final[str] = "0.00000000"


@dataclass(frozen=True, slots=True)
class QuerySpec:
    """Одна обязательная метрика согласованного снимка."""

    name: str
    sql: str


class CursorProtocol(Protocol):
    """Минимальный протокол синхронного PostgreSQL cursor."""

    def execute(self, sql: str) -> Any: ...

    def fetchone(self) -> Any: ...


OWNER_REFERENCES: Final[tuple[tuple[str, str, str, str], ...]] = (
    ("efhc_core", "achievements", "tg_id", "achievements.tg_id"),
    ("efhc_core", "panels", "tg_id", "panels.tg_id"),
    ("efhc_core", "panels_archive", "tg_id", "panels_archive.tg_id"),
    ("efhc_core", "payment_intents", "tg_id", "payment_intents.tg_id"),
    ("efhc_core", "ranks_snapshots", "tg_id", "ranks_snapshots.tg_id"),
    ("efhc_core", "ranks_top_cache", "tg_id", "ranks_top_cache.tg_id"),
    (
        "efhc_core",
        "ranks_user_snapshots",
        "tg_id",
        "ranks_user_snapshots.tg_id",
    ),
    (
        "efhc_core",
        "referral_codes",
        "inviter_tg_id",
        "referral_codes.inviter_tg_id",
    ),
    (
        "efhc_core",
        "referral_links",
        "inviter_tg_id",
        "referral_links.inviter_tg_id",
    ),
    (
        "efhc_core",
        "referral_links",
        "invitee_tg_id",
        "referral_links.invitee_tg_id",
    ),
    (
        "efhc_core",
        "referral_bonus_ledger",
        "tg_id",
        "referral_bonus_ledger.tg_id",
    ),
    ("efhc_core", "shop_orders", "tg_id", "shop_orders.tg_id"),
    ("efhc_core", "tx_hash_locks", "tg_id", "tx_hash_locks.tg_id"),
    ("efhc_core", "user_skins", "tg_id", "user_skins.tg_id"),
    (
        "efhc_core",
        "user_cosmetics",
        "tg_id",
        "user_cosmetics.tg_id",
    ),
    (
        "efhc_core",
        "task_submissions",
        "tg_id",
        "task_submissions.tg_id",
    ),
    (
        "efhc_core",
        "task_submissions",
        "moderator_tg_id",
        "task_submissions.moderator_tg_id",
    ),
    (
        "efhc_core",
        "user_tasks_status",
        "tg_id",
        "user_tasks_status.tg_id",
    ),
    (
        "efhc_core",
        "task_bonus_log",
        "tg_id",
        "task_bonus_log.tg_id",
    ),
    (
        "efhc_core",
        "task_complete_lock",
        "tg_id",
        "task_complete_lock.tg_id",
    ),
    (
        "efhc_core",
        "efhc_transfers_log",
        "tg_id",
        "efhc_transfers_log.tg_id",
    ),
    (
        "efhc_core",
        "wallet_bindings",
        "tg_id",
        "wallet_bindings.tg_id",
    ),
    (
        "efhc_core",
        "wallet_connect_idempotency",
        "tg_id",
        "wallet_connect_idempotency.tg_id",
    ),
    (
        "efhc_core",
        "wallet_proof_token_uses",
        "tg_id",
        "wallet_proof_token_uses.tg_id",
    ),
    (
        "efhc_core",
        "withdraw_requests",
        "tg_id",
        "withdraw_requests.tg_id",
    ),
    ("efhc_core", "withdrawals", "tg_id", "withdrawals.tg_id"),
    (
        "efhc_core",
        "withdraw_outcome_events",
        "tg_id",
        "withdraw_outcome_events.tg_id",
    ),
    ("efhc_admin", "admin_whitelist", "tg_id", "admin_whitelist.tg_id"),
    (
        "efhc_admin",
        "admin_whitelist",
        "added_by_tg_id",
        "admin_whitelist.added_by_tg_id",
    ),
    (
        "efhc_admin",
        "admin_role",
        "granted_by_tg_id",
        "admin_role.granted_by_tg_id",
    ),
)

QUERIES: Final[tuple[QuerySpec, ...]] = (
    QuerySpec(
        'версия_postgresql',
        (
            'SELECT '
            "current_setting('server_version_num')::bigint"
        ),
    ),
    QuerySpec(
        'версия_postgresql_текст',
        'SELECT version()',
    ),
    QuerySpec(
        'текущая_база',
        'SELECT current_database()',
    ),
    QuerySpec(
        'текущий_пользователь_бд',
        'SELECT current_user',
    ),
    QuerySpec(
        'режим_только_чтение',
        "SELECT current_setting('transaction_read_only')",
    ),
    QuerySpec(
        'уровень_изоляции',
        "SELECT current_setting('transaction_isolation')",
    ),
    QuerySpec(
        'alembic_revision',
        (
            'SELECT version_num FROM '
            'efhc_core.alembic_version'
        ),
    ),
    QuerySpec(
        'количество_пользователей',
        'SELECT count(*) FROM efhc_core.users',
    ),
    QuerySpec(
        'уникальные_tg_id',
        (
            'SELECT count(DISTINCT tg_id) FROM '
            'efhc_core.users'
        ),
    ),
    QuerySpec(
        'дубликаты_tg_id',
        (
            'SELECT count(*) FROM (SELECT tg_id FROM '
            'efhc_core.users GROUP BY tg_id HAVING count(*) > '
            '1) q'
        ),
    ),
    QuerySpec(
        'global_id_null',
        (
            'SELECT count(*) FROM efhc_core.users WHERE '
            'global_id IS NULL'
        ),
    ),
    QuerySpec(
        'global_id_заполнен',
        (
            'SELECT count(*) FROM efhc_core.users WHERE '
            'global_id IS NOT NULL'
        ),
    ),
    QuerySpec(
        'дубликаты_global_id',
        (
            'SELECT count(*) FROM (SELECT global_id FROM '
            'efhc_core.users WHERE global_id IS NOT NULL GROUP '
            'BY global_id HAVING count(*) > 1) q'
        ),
    ),
    QuerySpec(
        'global_id_вне_диапазона',
        (
            'SELECT count(*) FROM efhc_core.users WHERE '
            'global_id IS NOT NULL AND (global_id < 1 OR global_id '
            '> 9999999999)'
        ),
    ),
    QuerySpec(
        'legacy_pk_вне_диапазона',
        (
            'SELECT count(*) FROM efhc_core.users WHERE id < '
            '1 OR id > 9999999999'
        ),
    ),
    QuerySpec(
        'планируемые_коллизии_global_id',
        (
            'SELECT count(*) FROM efhc_core.users legacy_user '
            'JOIN efhc_core.users assigned_user ON '
            'assigned_user.user_id = legacy_user.id AND '
            'assigned_user.id <> legacy_user.id WHERE '
            'legacy_user.global_id IS NULL'
        ),
    ),
    QuerySpec(
        'максимальный_legacy_pk',
        'SELECT coalesce(max(id), 0) FROM efhc_core.users',
    ),
    QuerySpec(
        'максимальный_global_id',
        (
            'SELECT coalesce(max(global_id), 0) FROM '
            'efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_main_balance',
        (
            'SELECT coalesce(sum(main_balance), 0) FROM '
            'efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_bonus_balance',
        (
            'SELECT coalesce(sum(bonus_balance), 0) FROM '
            'efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_available_kwh',
        (
            'SELECT coalesce(sum(available_kwh), 0) FROM '
            'efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_total_generated_kwh',
        (
            'SELECT coalesce(sum(total_generated_kwh), 0) '
            'FROM efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_exchanged_kwh_total',
        (
            'SELECT coalesce(sum(exchanged_kwh_total), 0) '
            'FROM efhc_core.users'
        ),
    ),
    QuerySpec(
        'нарушения_зеркала_kwh',
        (
            'SELECT count(*) FROM efhc_core.users WHERE '
            'available_kwh <> total_generated_kwh - '
            'exchanged_kwh_total'
        ),
    ),
    QuerySpec(
        'расхождение_финансового_зеркала',
        (
            'SELECT coalesce(sum(available_kwh - '
            '(total_generated_kwh - exchanged_kwh_total)), 0) '
            'FROM efhc_core.users'
        ),
    ),
    QuerySpec(
        'сумма_bank_balance',
        (
            'SELECT coalesce(sum(balance), 0) FROM '
            'efhc_core.bank_balance'
        ),
    ),
    QuerySpec(
        'количество_панелей',
        (
            'SELECT (SELECT count(*) FROM efhc_core.panels) + '
            '(SELECT count(*) FROM efhc_core.panels_archive)'
        ),
    ),
    QuerySpec(
        'сумма_generated_kwh_панелей',
        (
            'SELECT (SELECT coalesce(sum(generated_kwh), 0) '
            'FROM efhc_core.panels) + (SELECT '
            'coalesce(sum(generated_kwh), 0) FROM '
            'efhc_core.panels_archive)'
        ),
    ),
    QuerySpec(
        'количество_транзакций',
        (
            'SELECT count(*) FROM '
            'efhc_core.efhc_transfers_log'
        ),
    ),
    QuerySpec(
        'сумма_транзакций',
        (
            'SELECT coalesce(sum(amount), 0) FROM '
            'efhc_core.efhc_transfers_log'
        ),
    ),
    QuerySpec(
        'количество_выводов',
        'SELECT count(*) FROM efhc_core.withdraw_requests',
    ),
    QuerySpec(
        'сумма_выводов',
        (
            'SELECT coalesce(sum(amount), 0) FROM '
            'efhc_core.withdraw_requests'
        ),
    ),
    QuerySpec(
        'количество_реферальных_связей',
        'SELECT count(*) FROM efhc_core.referral_links',
    ),
    QuerySpec(
        'сумма_реферальных_наград',
        (
            'SELECT coalesce(sum(amount_efhc), 0) FROM '
            'efhc_core.referral_bonus_ledger'
        ),
    ),
    QuerySpec(
        'активные_кошельки',
        (
            'SELECT count(*) FROM efhc_core.wallet_bindings '
            'WHERE is_active'
        ),
    ),
    QuerySpec(
        'подтверждённые_кошельки',
        (
            'SELECT count(*) FROM efhc_core.wallet_bindings '
            'WHERE is_active AND proof_verified'
        ),
    ),
    QuerySpec(
        'дубликаты_кошельков',
        (
            'SELECT count(*) FROM (SELECT wallet_address FROM '
            'efhc_core.wallet_bindings GROUP BY '
            'wallet_address HAVING count(*) > 1) q'
        ),
    ),
    QuerySpec(
        'дубликаты_idempotency',
        (
            'SELECT count(*) FROM (SELECT idempotency_key '
            'FROM efhc_core.efhc_transfers_log GROUP BY '
            'idempotency_key HAVING count(*) > 1) q'
        ),
    ),
    QuerySpec(
        'дубликаты_tx_hash',
        (
            'SELECT count(*) FROM (SELECT tx_hash FROM '
            'efhc_core.withdraw_requests WHERE tx_hash IS NOT '
            'NULL GROUP BY tx_hash HAVING count(*) > 1) q'
        ),
    ),
    QuerySpec(
        'административные_роли',
        'SELECT count(*) FROM efhc_admin.admin_role',
    ),
    QuerySpec(
        'таблица_user_identities_существует',
        (
            "SELECT (to_regclass('efhc_core.user_identities') "
            'IS NOT NULL)::int'
        ),
    ),
)


def _json_value(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        return {
            str(key): _json_value(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    return value


def _sanitize_error(exc: BaseException) -> str:
    """Удалить из ошибки реквизиты подключения."""

    text = f"{type(exc).__name__}: {exc}"
    text = re.sub(
        r"(?i)(password|passwd|user|host|dbname)=\S+",
        r"\1=<скрыто>",
        text,
    )
    text = re.sub(
        r"(?i)postgres(?:ql)?://[^\s]+",
        "postgresql://<скрыто>",
        text,
    )
    return text[:1000]


def _validate_provenance(
    cycle: int,
    source_head: str,
    target_head: str,
) -> None:
    if isinstance(cycle, bool) or cycle <= 0:
        raise ValueError(
            "Номер цикла должен быть положительным целым числом"
        )
    archive_pattern = re.compile(r"^EFHC_Bot_v\d+_\d+\.zip$")
    provenance = (
        ("source_head", source_head),
        ("target_head", target_head),
    )
    for label, value in provenance:
        if not value or not archive_pattern.fullmatch(value):
            raise ValueError(
                f"{label} должен быть точным именем development-архива"
            )
    if source_head == target_head:
        raise ValueError(
            "source_head и target_head не должны совпадать"
        )


def _load_driver() -> tuple[Any | None, str | None, str | None]:
    """Загрузить psycopg 3 либо psycopg2 без ложного fallback."""

    for module_name in ("psycopg", "psycopg2"):
        try:
            module = importlib.import_module(module_name)
        except ImportError:
            continue
        return module, module_name, None
    return None, None, "Модули psycopg и psycopg2 недоступны"


def _normalize_url(database_url: str) -> str:
    return re.sub(
        r"^postgresql\+(?:asyncpg|psycopg2|psycopg)://",
        "postgresql://",
        database_url,
    )


def _fetch_scalar(cursor: CursorProtocol, sql: str) -> Any:
    cursor.execute(sql)
    row = cursor.fetchone()
    return row[0] if row else None


def _capture_orphans(cursor: CursorProtocol) -> dict[str, int]:
    result: dict[str, int] = {}
    for schema, table, column, label in OWNER_REFERENCES:
        sql = (
            f'SELECT count(*) FROM "{schema}"."{table}" d '
            f'WHERE d."{column}" IS NOT NULL AND NOT EXISTS ('
            "SELECT 1 FROM efhc_core.users u "
            f'WHERE u.tg_id = d."{column}")'
        )
        result[label] = int(_fetch_scalar(cursor, sql) or 0)
    return result


def _sequence_next(cursor: CursorProtocol) -> int:
    cursor.execute(
        "SELECT last_value, is_called "
        "FROM efhc_core.users_global_id_seq"
    )
    row = cursor.fetchone()
    if row is None:
        raise RuntimeError(
            "Последовательность users_global_id_seq отсутствует"
        )
    last_value, is_called = row
    return int(last_value) + (1 if bool(is_called) else 0)


def _schema_checks(cursor: CursorProtocol) -> dict[str, Any]:
    return {
        "физическая_колонка_users_global_id": _fetch_scalar(
            cursor,
            "SELECT count(*) FROM information_schema.columns "
            "WHERE table_schema='efhc_core' AND table_name='users' "
            "AND column_name='global_id' AND data_type='bigint' "
            "AND is_nullable='YES'",
        ),
        "legacy_колонка_users_user_id_отсутствует": _fetch_scalar(
            cursor,
            (
                "SELECT (count(*) = 0)::int "
                "FROM information_schema.columns "
                "WHERE table_schema='efhc_core' "
                "AND table_name='users' "
                "AND column_name='user_id'"
            ),
        ),
        "constraint_uq_users_global_id": _fetch_scalar(
            cursor,
            "SELECT count(*) FROM pg_constraint c "
            "JOIN pg_class t ON t.oid=c.conrelid "
            "JOIN pg_namespace n ON n.oid=t.relnamespace "
            "WHERE n.nspname='efhc_core' AND t.relname='users' "
            "AND c.conname='uq_users_global_id'",
        ),
        "constraint_ck_users_global_id_range": _fetch_scalar(
            cursor,
            "SELECT count(*) FROM pg_constraint c "
            "JOIN pg_class t ON t.oid=c.conrelid "
            "JOIN pg_namespace n ON n.oid=t.relnamespace "
            "WHERE n.nspname='efhc_core' AND t.relname='users' "
            "AND c.conname='ck_users_global_id_range'",
        ),
        "sequence_users_global_id_seq": _fetch_scalar(
            cursor,
            (
                "SELECT (to_regclass("
                "'efhc_core.users_global_id_seq') "
                "IS NOT NULL)::int"
            ),
        ),
    }


def _base_report(
    *,
    cycle: int,
    source_head: str,
    target_head: str,
) -> dict[str, Any]:
    return {
        "схема_отчёта": "EFHC_GLOBAL_ID_POSTGRESQL_RECONCILIATION_V2",
        "цикл": cycle,
        "исходный_архив": source_head,
        "целевой_архив": target_head,
        "время_utc": datetime.now(UTC).isoformat(),
        "канонический_идентификатор": "global_id",
        "физическая_колонка": "efhc_core.users.global_id",
        "legacy_контур_владения": "tg_id",
        "реальный_postgresql_выполнен": False,
        "драйвер": None,
        "только_чтение": True,
        "изоляция": (
            "повторяемое чтение; только чтение; "
            "откладываемая проверка"
        ),
        "historical_backfill_выполнен": False,
        "historical_backfill_разрешён": False,
        "dual_write_выполнен": False,
        "read_switch_выполнен": False,
        "financial_ownership_switch_выполнен": False,
        "финансовый_допуск": ФИНАНСОВЫЙ_ДОПУСК,
        "статус": "БЛОКИРОВАНО_СРЕДОЙ",
        "метрики": {},
        "проверки_схемы": {},
        "нарушения": [],
        "предупреждения": [],
        "ошибки": [],
    }


def capture(
    database_url: str | None,
    *,
    cycle: int = 1603,
    source_head: str = "EFHC_Bot_v171_99.zip",
    target_head: str = "EFHC_Bot_v172_00.zip",
) -> tuple[dict[str, Any], int]:
    """Получить согласованный снимок реального PostgreSQL."""

    try:
        _validate_provenance(cycle, source_head, target_head)
    except ValueError as exc:
        report = _base_report(
            cycle=cycle,
            source_head=source_head,
            target_head=target_head,
        )
        report["статус"] = "ОШИБКА_PROVENANCE"
        report["ошибки"].append(str(exc))
        return report, 5

    report = _base_report(
        cycle=cycle,
        source_head=source_head,
        target_head=target_head,
    )
    if not database_url:
        report["ошибки"].append(
            "Не задан DATABASE_URL, SYNC_DATABASE_URL или PSYCOPG_URL"
        )
        return report, 3

    driver, driver_name, driver_error = _load_driver()
    if driver is None:
        report["ошибки"].append(driver_error)
        return report, 3
    report["драйвер"] = driver_name

    connection: Any | None = None
    try:
        connection = driver.connect(_normalize_url(database_url))
        connection.autocommit = False
        cursor = connection.cursor()
        try:
            cursor.execute(
                "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ "
                "READ ONLY DEFERRABLE"
            )
            cursor.execute("SET LOCAL statement_timeout = '120s'")
            cursor.execute("SET LOCAL lock_timeout = '5s'")
            metrics: dict[str, Any] = {}
            for spec in QUERIES:
                metrics[spec.name] = _json_value(
                    _fetch_scalar(cursor, spec.sql)
                )
            metrics["следующий_global_id_sequence"] = (
                _sequence_next(cursor)
            )
            metrics["orphan_записи_legacy_tg_id"] = (
                _capture_orphans(cursor)
            )
            report["проверки_схемы"] = _json_value(
                _schema_checks(cursor)
            )
            report["метрики"] = metrics
            report["реальный_postgresql_выполнен"] = True
        finally:
            connection.rollback()
            cursor.close()
    except Exception as exc:  # noqa: BLE001
        report["статус"] = "ОШИБКА_POSTGRESQL"
        report["ошибки"].append(_sanitize_error(exc))
        return report, 4
    finally:
        if connection is not None:
            connection.close()

    schema_errors: list[str] = []
    for key, raw_value in report["проверки_схемы"].items():
        if int(raw_value or 0) != 1:
            schema_errors.append(
                f"Проверка схемы не пройдена: {key}={raw_value}"
            )

    metrics = report["метрики"]
    if metrics.get("alembic_revision") != ОЖИДАЕМАЯ_РЕВИЗИЯ:
        schema_errors.append(
            f"Alembic revision должна быть {ОЖИДАЕМАЯ_РЕВИЗИЯ}"
        )
    server_version = int(
        metrics.get("версия_postgresql") or 0
    )
    if server_version < МИНИМАЛЬНАЯ_ВЕРСИЯ_POSTGRESQL:
        schema_errors.append("Требуется PostgreSQL 16 или новее")
    if str(metrics.get("режим_только_чтение", "")).lower() != "on":
        schema_errors.append(
            "Транзакция PostgreSQL не подтверждена как read-only"
        )
    isolation = str(
        metrics.get("уровень_изоляции", "")
    ).lower()
    if isolation != "repeatable read":
        schema_errors.append(
            "Уровень изоляции не равен repeatable read"
        )

    try:
        verdict = evaluate_reconciliation(metrics)
    except ValueError as exc:
        report["статус"] = "ОШИБКА_МЕТРИК"
        report["ошибки"].append(str(exc))
        return report, 4

    violations = list(verdict.violations) + schema_errors
    report["нарушения"] = violations
    report["предупреждения"] = list(verdict.warnings)
    report["historical_backfill_разрешён"] = not violations
    report["статус"] = "ГОТОВО" if not violations else "ОТКЛОНЕНО"
    return report, 0 if not violations else 2


def render_sql(*, cycle: int = 1603) -> str:
    """Сформировать независимый PostgreSQL SQL-пакет только чтения."""

    if isinstance(cycle, bool) or cycle <= 0:
        raise ValueError("Номер цикла должен быть положительным")
    lines = [
        f"-- Цикл {cycle}. Global ID reconciliation baseline.",
        (
            "-- Только чтение. Backfill, dual-write и "
            "read switch запрещены."
        ),
        "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ",
        "READ ONLY DEFERRABLE;",
        "SET LOCAL statement_timeout = '120s';",
        "SET LOCAL lock_timeout = '5s';",
        "",
    ]
    for spec in QUERIES:
        lines.extend(
            [f"-- Метрика: {spec.name}", spec.sql.rstrip(";") + ";", ""]
        )
    for schema, table, column, label in OWNER_REFERENCES:
        lines.extend(
            [
                f"-- Legacy orphan baseline: {label}",
                f'SELECT count(*) FROM "{schema}"."{table}" d '
                f'WHERE d."{column}" IS NOT NULL AND NOT EXISTS ('
                "SELECT 1 FROM efhc_core.users u "
                f'WHERE u.tg_id = d."{column}");',
                "",
            ]
        )
    lines.extend(
        [
            "SELECT last_value, is_called",
            "FROM efhc_core.users_global_id_seq;",
            "",
            "ROLLBACK;",
        ]
    )
    return "\n".join(lines) + "\n"


def _database_url() -> str | None:
    return (
        os.getenv("PSYCOPG_URL")
        or os.getenv("SYNC_DATABASE_URL")
        or os.getenv("DATABASE_URL")
    )


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Global ID PostgreSQL reconciliation gate"
    )
    parser.add_argument("--database-url", default=_database_url())
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sql-output", type=Path)
    parser.add_argument("--cycle", type=int, default=1603)
    parser.add_argument(
        "--source-head",
        default="EFHC_Bot_v171_99.zip",
    )
    parser.add_argument(
        "--target-head",
        default="EFHC_Bot_v172_00.zip",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.sql_output:
        args.sql_output.parent.mkdir(parents=True, exist_ok=True)
        args.sql_output.write_text(
            render_sql(cycle=args.cycle),
            encoding="utf-8",
        )

    report, exit_code = capture(
        args.database_url,
        cycle=args.cycle,
        source_head=args.source_head,
        target_head=args.target_head,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
