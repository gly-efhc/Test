"""Fail-closed проверка security/audit identity для цикла 1703."""

from __future__ import annotations

import ast
import inspect
import json
from pathlib import Path
from typing import Final

from app.identity.auth_redaction import AUTH_SENSITIVE_FIELDS
from app.models.admin_models import AdminActionLog
from sqlalchemy import ForeignKey

ROOT: Final = Path(__file__).resolve().parents[2]
_PROVIDER_SUBJECT_FIELDS: Final = {
    "tg_id",
    "ton_wallet_id",
    "google_id",
    "apple_id",
    "fb_id",
    "discord_id",
    "github_id",
}
_FINANCIAL_FUNCTIONS: Final = {
    "credit_user_from_bank",
    "credit_user_bonus_from_bank",
    "debit_user_to_bank",
    "debit_user_bonus_to_bank",
}


def _call_name(node: ast.Call) -> str | None:
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        return node.func.attr
    return None


def _admin_logger_call_violations(root: Path) -> list[str]:
    """Найти admin audit calls без canonical actor или с provider actor."""

    violations: list[str] = []
    for path in sorted((root / "backend/app").rglob("*.py")):
        source = path.read_text(encoding="utf-8")
        if "AdminLogger.write" not in source:
            continue
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            if _call_name(node) != "write":
                continue
            if not isinstance(node.func, ast.Attribute):
                continue
            owner = node.func.value
            if not isinstance(owner, ast.Name) or owner.id != "AdminLogger":
                continue
            keywords = {
                item.arg: item.value
                for item in node.keywords
                if item.arg is not None
            }
            actor = keywords.get("actor_global_id")
            if actor is None:
                violations.append(
                    f"{path.relative_to(root)}:{node.lineno}:missing_actor_global_id"
                )
                continue
            actor_text = ast.unparse(actor)
            if "tg_id" in actor_text or "provider_subject" in actor_text:
                violations.append(
                    f"{path.relative_to(root)}:{node.lineno}:provider_actor={actor_text}"
                )
    return violations


def _admin_bank_owner_violations(root: Path) -> list[str]:
    """Доказать, что Admin Bank financial owner передаётся как global_id."""

    violations: list[str] = []
    targets = (
        root / "backend/app/routes/admin_routes.py",
        root / "backend/app/services/admin/admin_bank_service.py",
    )
    for path in targets:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _call_name(node)
            if name not in _FINANCIAL_FUNCTIONS:
                continue
            keywords = {
                item.arg for item in node.keywords if item.arg is not None
            }
            if "global_id" not in keywords:
                violations.append(
                    f"{path.relative_to(root)}:{node.lineno}:{name}:no_global_id"
                )
            if "tg_id" in keywords:
                violations.append(
                    f"{path.relative_to(root)}:{node.lineno}:{name}:tg_id_owner"
                )
    return violations


def _legacy_admin_provider_runtime_refs(root: Path) -> list[str]:
    """Найти runtime использование legacy provider metadata admin-role actor."""

    needle = "granted_by_" + "tg_id"
    refs: list[str] = []
    for path in sorted((root / "backend/app").rglob("*.py")):
        if path.as_posix().endswith("backend/app/models/admin_models.py"):
            continue
        for line_no, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if needle in line:
                refs.append(f"{path.relative_to(root)}:{line_no}")
    return refs


def _raw_provider_subject_log_refs(root: Path) -> list[str]:
    """Найти логирование raw provider subject в active backend."""

    refs: list[str] = []
    markers = ("tg_id=%s", "provider_subject=%s", "ton_wallet_id=%s")
    for path in sorted((root / "backend/app").rglob("*.py")):
        for line_no, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if any(marker in line for marker in markers):
                refs.append(f"{path.relative_to(root)}:{line_no}")
    return refs


def build_report(root: Path = ROOT) -> dict[str, object]:
    """Собрать доказательство privileged/audit ownership через global_id."""

    security_source = (root / "backend/app/core/security_core.py").read_text(
        encoding="utf-8"
    )
    rbac_source = (
        root / "backend/app/services/admin/admin_rbac.py"
    ).read_text(encoding="utf-8")
    logger_source = (
        root / "backend/app/services/admin/admin_logging.py"
    ).read_text(encoding="utf-8")
    action_fk_targets = {
        fk.target_fullname
        for fk in AdminActionLog.__table__.c.actor_global_id.foreign_keys
        if isinstance(fk, ForeignKey)
    }
    logger_violations = _admin_logger_call_violations(root)
    bank_violations = _admin_bank_owner_violations(root)
    legacy_role_refs = _legacy_admin_provider_runtime_refs(root)
    raw_provider_log_refs = _raw_provider_subject_log_refs(root)
    hub_source = (root / "backend/app/routes/hub_routes.py").read_text(
        encoding="utf-8"
    )
    outcome_source = (
        root / "backend/app/services/outcome_service.py"
    ).read_text(encoding="utf-8")
    deps_source = (root / "backend/app/deps.py").read_text(encoding="utf-8")
    admin_dependency_source = deps_source.split(
        "async def require_admin", 1
    )[1].split("# Health-проверка БД", 1)[0]

    checks = {
        "privileged_jwt_requires_global_id": (
            'payload.get("role") == "ADMIN"' in security_source
            and '_payload_global_id(payload) is not None' in security_source
        ),
        "privileged_jwt_has_no_tg_id_owner_fallback": (
            'payload.get("tg_id")' not in inspect.getsource(
                __import__(
                    "app.core.security_core", fromlist=["_is_bank_admin"]
                )._is_bank_admin
            )
        ),
        "rbac_resolves_admin_by_global_id": (
            "WHERE aw.global_id = :global_id" in rbac_source
            and "async def resolve_admin" in rbac_source
        ),
        "audit_actor_fk_is_global_id": (
            action_fk_targets == {"efhc_core.users.global_id"}
        ),
        "admin_logger_accepts_actor_global_id": (
            "actor_global_id: int | None" in logger_source
            and ":actor_global_id" in logger_source
        ),
        "all_admin_logger_calls_have_global_actor": not logger_violations,
        "admin_bank_financial_owner_is_global_id": not bank_violations,
        "legacy_admin_role_provider_actor_not_used_runtime": not legacy_role_refs,
        "privileged_admin_context_drops_provider_subject": (
            "RBAC.resolve_admin" in admin_dependency_source
            and "global_id=int(admin.global_id)" in admin_dependency_source
            and "admin_id=int(admin.id)" in admin_dependency_source
            and "role=str(admin.role)" in admin_dependency_source
            and "context.tg_id" not in admin_dependency_source
            and "tg_id=context" not in admin_dependency_source
        ),
        "new_handoff_tokens_use_global_id_only": (
            '"global_id": int(owner.global_id)' in hub_source
            and '"tg_id": owner.provider_tg_id' not in hub_source
            and 'def create_withdraw_outcome_web_profile_url' in outcome_source
            and 'global_id: int' in outcome_source
            and '"global_id": int(global_id)' in outcome_source
        ),
        "raw_provider_subject_not_logged": not raw_provider_log_refs,
        "provider_subject_fields_are_redacted": (
            set(AUTH_SENSITIVE_FIELDS) >= _PROVIDER_SUBJECT_FIELDS
            and "provider_subject" in AUTH_SENSITIVE_FIELDS
        ),
    }
    failed = sorted(name for name, ok in checks.items() if not ok)
    return {
        "schema": "EFHC_SECURITY_AUDIT_IDENTITY_V1",
        "version": "v173.27",
        "cycle": 1703,
        "status": "PASS" if not failed else "FAIL",
        "checks": checks,
        "failed": failed,
        "admin_logger_violations": logger_violations,
        "admin_bank_owner_violations": bank_violations,
        "legacy_admin_role_provider_runtime_refs": legacy_role_refs,
        "raw_provider_subject_log_refs": raw_provider_log_refs,
    }


def main() -> int:
    report = build_report()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
