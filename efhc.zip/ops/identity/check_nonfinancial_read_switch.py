#!/usr/bin/env python3
"""Проверка final non-financial global_id read boundary."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def collect() -> dict[str, object]:
    migration = _read(
        "backend/migrations/versions/0001_initial_release_schema.py"
    )
    owner = _read("backend/app/identity/nonfinancial_read_switch.py")
    dependency = _read(
        "backend/app/identity/nonfinancial_read_dependency.py"
    )
    checks = {
        "release_base": 'revision = "0001"' in migration
        and "down_revision = None" in migration,
        "global_read_control": (
            "nonfinancial_read_global_id_enabled" in migration
        ),
        "rollback_ready": (
            "nonfinancial_read_rollback_ready" in migration
        ),
        "legacy_authoritative": "legacy_authoritative" in migration,
        "runtime_owner": "nonfinancial_read_global_id_enabled" in owner,
        "auth_context_required": "require_auth_context" in dependency,
        "global_id_used": "context.global_id.value" in dependency,
        "telegram_fallback_absent": (
            "get_current_tg_id" not in dependency
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    return {
        "схема": "EFHC_FINAL_NONFINANCIAL_READ_GUARD_V1",
        "статус": "PASS" if not failed else "FAIL",
        "alembic_head": "0001",
        "проверки": checks,
        "ошибки": failed,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = collect()
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
