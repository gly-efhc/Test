# Global ID PostgreSQL reconciliation

## Назначение

Контур снимает согласованный read-only снимок реальной PostgreSQL до
historical backfill. Физическая колонка остаётся `users.user_id`, а её
каноническое логическое имя — `global_id`.

## Production snapshot

Передать синхронный PostgreSQL URL через `PSYCOPG_URL`,
`SYNC_DATABASE_URL` либо `DATABASE_URL`, затем выполнить:

```bash
./ops/identity/run_global_id_postgresql_reconciliation.sh
```

Требуется `psycopg` либо `psycopg2`. Код `0` означает только то, что
реальный снимок получен и все проверки пройдены. Код `2` означает
обнаруженные нарушения, `3` — отсутствие среды, `4` — ошибку SQL или
неполный снимок.

## Изолированный smoke

`docker-compose.global-id-reconciliation.yml` допустим только для
проверки запуска PostgreSQL и миграций на пустой временной базе. Такой
результат не доказывает целостность production-данных и не открывает
historical backfill.

## Запреты

Контур не выполняет `INSERT`, `UPDATE`, `DELETE`, `ALTER`, `TRUNCATE`,
backfill, dual-write или read switch. Транзакция всегда завершается
`ROLLBACK`.
