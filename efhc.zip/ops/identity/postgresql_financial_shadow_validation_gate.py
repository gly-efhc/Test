#!/usr/bin/env python3
"""Read-only PostgreSQL gate финансовой shadow validation цикла 1626."""

from __future__ import annotations

import argparse
import json
import os
from decimal import Decimal
from typing import Final

EXPECTED_REVISION: Final[str] = "0001"

FINANCIAL_SCOPES: Final[tuple[str, ...]] = (
    "efhc_core.efhc_transfers_log.tg_id->global_id",
    "efhc_core.payment_intents.tg_id->global_id",
    "efhc_core.withdraw_requests.tg_id->global_id",
    "efhc_core.withdrawals.tg_id->global_id",
    "efhc_core.withdraw_outcome_events.tg_id->global_id",
    "efhc_core.wallet_bindings.tg_id->global_id",
    "efhc_core.wallet_connect_idempotency.tg_id->global_id",
    "efhc_core.wallet_proof_token_uses.tg_id->global_id",
    "efhc_core.tx_hash_locks.tg_id->global_id",
    "efhc_core.ton_inbox_logs.parsed_tg_id->resolved_global_id",
)

MONEY_QUERIES: Final[tuple[tuple[str, str], ...]] = (
    (
        "efhc_transfers_log.amount",
        """
        SELECT
            COALESCE(sum(t.amount) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.efhc_transfers_log t
        LEFT JOIN efhc_core.users legacy ON legacy.tg_id = t.tg_id
        LEFT JOIN efhc_core.users shadow ON shadow.user_id = t.global_id
        """,
    ),
    (
        "payment_intents.amount_asset_d8",
        """
        SELECT
            COALESCE(sum(t.amount_asset_d8) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount_asset_d8) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.payment_intents t
        LEFT JOIN efhc_core.users legacy ON legacy.tg_id = t.tg_id
        LEFT JOIN efhc_core.users shadow ON shadow.user_id = t.global_id
        """,
    ),
    (
        "payment_intents.efhc_amount_d8",
        """
        SELECT
            COALESCE(sum(t.efhc_amount_d8) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.efhc_amount_d8) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.payment_intents t
        LEFT JOIN efhc_core.users legacy ON legacy.tg_id = t.tg_id
        LEFT JOIN efhc_core.users shadow ON shadow.user_id = t.global_id
        """,
    ),
    (
        "withdraw_requests.amount",
        """
        SELECT
            COALESCE(sum(t.amount) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.withdraw_requests t
        LEFT JOIN efhc_core.users legacy ON legacy.tg_id = t.tg_id
        LEFT JOIN efhc_core.users shadow ON shadow.user_id = t.global_id
        """,
    ),
    (
        "withdrawals.amount_efhc",
        """
        SELECT
            COALESCE(sum(t.amount_efhc) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount_efhc) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.withdrawals t
        LEFT JOIN efhc_core.users legacy ON legacy.tg_id = t.tg_id
        LEFT JOIN efhc_core.users shadow ON shadow.user_id = t.global_id
        """,
    ),
    (
        "ton_inbox_logs.amount",
        """
        SELECT
            COALESCE(sum(t.amount) FILTER (
                WHERE legacy.user_id IS NOT NULL
            ), 0),
            COALESCE(sum(t.amount) FILTER (
                WHERE shadow.user_id IS NOT NULL
            ), 0)
        FROM efhc_core.ton_inbox_logs t
        LEFT JOIN efhc_core.users legacy
          ON legacy.tg_id = t.parsed_tg_id
        LEFT JOIN efhc_core.users shadow
          ON shadow.user_id = t.resolved_global_id
        """,
    ),
)

PRECISION_SPECS: Final[tuple[tuple[str, str, int, int], ...]] = (
    ("efhc_transfers_log", "amount", 30, 8),
    ("payment_intents", "amount_asset_d8", 38, 8),
    ("payment_intents", "efhc_amount_d8", 38, 8),
    ("withdraw_requests", "amount", 30, 8),
    ("withdrawals", "amount_efhc", 20, 8),
    ("ton_inbox_logs", "amount", 30, 8),
)

REQUIRED_INDEXES: Final[tuple[str, ...]] = (
    "uq_efhc_transfers_idem_key",
    "uq_payment_intents_idempo",
    "uq_payment_intents_global_idempo",
    "ux_payment_intents_external_tx_hash_nn",
    "uq_withdraw_processing_idempotency_key",
    "uq_withdraw_payout_ref",
    "uq_wallet_connect_idk",
    "uq_wallet_connect_global_idk",
    "uq_wallet_proof_payload_hash",
    "uq_tx_hash_locks_tx_hash",
)


def _psycopg_url(url: str) -> str:
    return (
        url.replace("postgresql+psycopg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .replace("postgresql+asyncpg://", "postgresql://")
    )


def _zero_text(value: Decimal) -> str:
    if value == Decimal("0"):
        return "0.00000000"
    return format(value, "f")


def collect(database_url: str) -> dict[str, object]:
    """Снять неизменяющий финансовый shadow snapshot."""

    try:
        import psycopg
    except ModuleNotFoundError as exc:
        raise RuntimeError("psycopg недоступен") from exc

    placeholders = ", ".join(["%s"] * len(FINANCIAL_SCOPES))
    with (
        psycopg.connect(_psycopg_url(database_url)) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(
            "BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ "
            "READ ONLY DEFERRABLE"
        )
        cursor.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        )
        revision_row = cursor.fetchone()
        if revision_row is None:
            raise RuntimeError("Alembic revision не найдена")
        revision = str(revision_row[0])

        cursor.execute(
            """
            SELECT
                dual_write_enabled,
                shadow_read_enabled,
                legacy_authoritative,
                nonfinancial_read_global_id_enabled
            FROM efhc_core.identity_migration_control
            WHERE singleton_id = 1
            """
        )
        control = cursor.fetchone()
        if control is None:
            raise RuntimeError("identity migration control отсутствует")

        cursor.execute(
            f"""
            SELECT
                scope,
                legacy_rows,
                shadow_rows,
                matched_rows,
                fallback_rows,
                mismatch_rows,
                orphan_rows,
                shadow_only_rows,
                ambiguous_rows
            FROM efhc_core.identity_ownership_shadow_telemetry
            WHERE scope IN ({placeholders})
            ORDER BY scope
            """,
            FINANCIAL_SCOPES,
        )
        telemetry_rows = cursor.fetchall()

        monetary: list[dict[str, object]] = []
        discrepancy = Decimal("0")
        for label, query in MONEY_QUERIES:
            cursor.execute(query)
            row = cursor.fetchone()
            if row is None:
                raise RuntimeError(
                    f"Денежный snapshot отсутствует: {label}"
                )
            legacy_sum = Decimal(row[0])
            shadow_sum = Decimal(row[1])
            delta = legacy_sum - shadow_sum
            discrepancy += abs(delta)
            monetary.append(
                {
                    "контракт": label,
                    "legacy_sum": format(legacy_sum, "f"),
                    "shadow_sum": format(shadow_sum, "f"),
                    "discrepancy": _zero_text(delta),
                }
            )

        precision: list[dict[str, object]] = []
        precision_ok = True
        for (
            table,
            column,
            expected_precision,
            expected_scale,
        ) in PRECISION_SPECS:
            cursor.execute(
                """
                SELECT numeric_precision, numeric_scale
                FROM information_schema.columns
                WHERE table_schema = 'efhc_core'
                  AND table_name = %s
                  AND column_name = %s
                """,
                (table, column),
            )
            row = cursor.fetchone()
            actual = None if row is None else (int(row[0]), int(row[1]))
            expected = (expected_precision, expected_scale)
            ok = actual == expected
            precision_ok = precision_ok and ok
            precision.append(
                {
                    "контракт": f"{table}.{column}",
                    "ожидалось": list(expected),
                    "фактически": list(actual) if actual else None,
                    "pass": ok,
                }
            )

        cursor.execute(
            """
            SELECT indexname
            FROM pg_indexes
            WHERE schemaname IN ('efhc_core', 'efhc_admin')
            """
        )
        existing_indexes = {str(row[0]) for row in cursor.fetchall()}
        missing_indexes = sorted(
            set(REQUIRED_INDEXES) - existing_indexes
        )

        cursor.execute(
            """
            SELECT count(*)
            FROM pg_constraint
            WHERE conrelid = 'efhc_core.withdraw_requests'::regclass
              AND contype = 'u'
              AND pg_get_constraintdef(oid)
                  LIKE 'UNIQUE (idempotency_key)%'
            """
        )
        withdraw_idempotency_unique = int(cursor.fetchone()[0]) == 1
        connection.rollback()

    totals = {
        "legacy_rows": 0,
        "shadow_rows": 0,
        "matched_rows": 0,
        "fallback_rows": 0,
        "mismatch_rows": 0,
        "orphan_rows": 0,
        "shadow_only_rows": 0,
        "ambiguous_rows": 0,
    }
    details: list[dict[str, object]] = []
    keys = tuple(totals)
    seen_scopes: set[str] = set()
    for row in telemetry_rows:
        item: dict[str, object] = {"scope": str(row[0])}
        seen_scopes.add(str(row[0]))
        for index, key in enumerate(keys, start=1):
            value = int(row[index])
            item[key] = value
            totals[key] += value
        details.append(item)

    missing_scopes = sorted(set(FINANCIAL_SCOPES) - seen_scopes)
    hard_zero = all(
        totals[key] == 0
        for key in (
            "fallback_rows",
            "mismatch_rows",
            "orphan_rows",
            "ambiguous_rows",
        )
    )
    controls_ok = all(bool(value) for value in control)
    idempotency_ok = not missing_indexes and withdraw_idempotency_unique
    status = "PASS" if all(
        (
            revision == EXPECTED_REVISION,
            controls_ok,
            not missing_scopes,
            hard_zero,
            discrepancy == Decimal("0"),
            precision_ok,
            idempotency_ok,
        )
    ) else "FAIL"

    return {
        "статус": status,
        "alembic_revision": revision,
        "legacy_authoritative": bool(control[2]),
        "dual_write_enabled": bool(control[0]),
        "shadow_read_enabled": bool(control[1]),
        "nonfinancial_read_global_id_enabled": bool(control[3]),
        "financial_read_switch": False,
        "telemetry": totals,
        "scopes": details,
        "missing_scopes": missing_scopes,
        "monetary": monetary,
        "monetary_discrepancy": _zero_text(discrepancy),
        "precision": precision,
        "precision_unchanged": precision_ok,
        "missing_idempotency_indexes": missing_indexes,
        "withdraw_idempotency_unique": withdraw_idempotency_unique,
        "idempotency_unchanged": idempotency_ok,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database-url",
        default=(
            os.getenv("DATABASE_URL")
            or os.getenv("SYNC_DATABASE_URL")
        ),
    )
    parser.add_argument("--json-report")
    args = parser.parse_args()
    if not args.database_url:
        raise SystemExit("DATABASE_URL обязателен")
    report = collect(args.database_url)
    payload = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
    print(payload)
    if args.json_report:
        with open(args.json_report, "w", encoding="utf-8") as handle:
            handle.write(payload + "\n")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
