"""Fail-closed проверка строковой системы GlobalId во frontend."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

CANONICAL_FILE = Path("frontend/src/types/identity.ts")
SOURCE_SUFFIXES = {".ts", ".tsx"}

NUMBER_FIELD_RE = re.compile(
    r"\b(?:global_id|globalId)\s*\??\s*:"
    r"\s*(?:number|bigint)\b"
)
NUMBER_SCHEMA_RE = re.compile(
    r"\b(?:global_id|globalId)\b[^\n]{0,80}"
    r"(?:z\.number\s*\(|z\.bigint\s*\()"
)
NUMBER_CONVERSION_RE = re.compile(
    r"\b(?:Number|parseInt|parseFloat|BigInt)\s*\("
    r"[^\n)]*\b(?:global_id|globalId)\b"
)
ARITHMETIC_RIGHT_RE = re.compile(
    r"\b(?:global_id|globalId)\b\s*(?:\+\+|--|[+\-*/%])"
)
ARITHMETIC_LEFT_RE = re.compile(
    r"(?:[+\-*/%])\s*\b(?:global_id|globalId)\b"
)
UNSAFE_CAST_RE = re.compile(r"\bas\s+GlobalId\b|<GlobalId>")
UNSAFE_ALIAS_RE = re.compile(
    r"\btype\s+GlobalId\s*=\s*(?:number|bigint)\b"
)


def _frontend_sources(root: Path) -> list[Path]:
    source_root = root / "frontend/src"
    return sorted(
        path
        for path in source_root.rglob("*")
        if path.is_file() and path.suffix in SOURCE_SUFFIXES
    )


def _finding(
    path: Path,
    root: Path,
    line: int,
    reason: str,
) -> dict[str, Any]:
    return {
        "путь": path.relative_to(root).as_posix(),
        "строка": line,
        "причина": reason,
    }


def найти_числовые_global_id(root: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    canonical = root / CANONICAL_FILE
    for path in _frontend_sources(root):
        text = path.read_text(encoding="utf-8")
        for line_number, line in enumerate(
            text.splitlines(),
            start=1,
        ):
            if (
                NUMBER_FIELD_RE.search(line)
                or UNSAFE_ALIAS_RE.search(line)
            ):
                findings.append(
                    _finding(
                        path,
                        root,
                        line_number,
                        "global_id_as_number",
                    )
                )
            if NUMBER_SCHEMA_RE.search(line):
                findings.append(
                    _finding(
                        path,
                        root,
                        line_number,
                        "global_id_numeric_schema",
                    )
                )
            if NUMBER_CONVERSION_RE.search(line):
                findings.append(
                    _finding(
                        path,
                        root,
                        line_number,
                        "global_id_numeric_conversion",
                    )
                )
            if (
                ARITHMETIC_RIGHT_RE.search(line)
                or ARITHMETIC_LEFT_RE.search(line)
            ):
                findings.append(
                    _finding(
                        path,
                        root,
                        line_number,
                        "global_id_arithmetic",
                    )
                )
            if path != canonical and UNSAFE_CAST_RE.search(line):
                findings.append(
                    _finding(
                        path,
                        root,
                        line_number,
                        "unsafe_global_id_cast",
                    )
                )
    return findings


def проверить(root: Path) -> dict[str, Any]:
    canonical = root / CANONICAL_FILE
    violations: list[dict[str, Any]] = []
    if not canonical.is_file():
        violations.append(
            {
                "путь": CANONICAL_FILE.as_posix(),
                "строка": 0,
                "причина": "canonical_frontend_global_id_missing",
            }
        )
        source = ""
    else:
        source = canonical.read_text(encoding="utf-8")

    required_fragments = {
        "branded_string": "export type GlobalId = string &",
        "ascii_pattern": (
            "export const GLOBAL_ID_PATTERN = /^[0-9]{10}$/;"
        ),
        "zero_forbidden": (
            'export const GLOBAL_ID_ZERO = "0000000000";'
        ),
        "parser": (
            "export function parseGlobalId("
            "value: unknown): GlobalId"
        ),
        "api_boundary": (
            "export const globalIdFromApi = parseGlobalId;"
        ),
        "wire_boundary": (
            "export function globalIdToApi("
            "value: GlobalId): string"
        ),
    }
    missing = [
        name
        for name, fragment in required_fragments.items()
        if fragment not in source
    ]
    for name in missing:
        violations.append(
            {
                "путь": CANONICAL_FILE.as_posix(),
                "строка": 0,
                "причина": f"missing_{name}",
            }
        )

    violations.extend(найти_числовые_global_id(root))
    branded = not missing and "string &" in source
    numeric_reasons = {
        "global_id_as_number",
        "global_id_numeric_schema",
        "global_id_numeric_conversion",
    }
    number_forbidden = not any(
        item["причина"] in numeric_reasons
        for item in violations
    )
    arithmetic_forbidden = not any(
        item["причина"] == "global_id_arithmetic"
        for item in violations
    )
    unsafe_cast_forbidden = not any(
        item["причина"] == "unsafe_global_id_cast"
        for item in violations
    )
    return {
        "схема_отчёта": (
            "EFHC_FRONTEND_GLOBAL_ID_STRING_SYSTEM_V1"
        ),
        "канонический_файл": CANONICAL_FILE.as_posix(),
        "проверено_frontend_файлов": len(
            _frontend_sources(root)
        ),
        "global_id_является_branded_string": branded,
        "javascript_number_запрещён": number_forbidden,
        "арифметика_запрещена": arithmetic_forbidden,
        "небезопасные_cast_запрещены": (
            unsafe_cast_forbidden
        ),
        "нарушения": violations,
        "пройдено": not violations,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Проверка строковой системы GlobalId во frontend."
        )
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = проверить(args.root.resolve())
    payload = (
        json.dumps(result, ensure_ascii=False, indent=2)
        + "\n"
    )
    if args.output:
        args.output.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if result["пройдено"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
