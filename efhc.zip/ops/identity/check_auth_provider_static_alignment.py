"""Статически проверить AuthProvider и final release schema."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
from typing import Final

ROOT: Final = Path(__file__).resolve().parents[2]
AUTH_PROVIDER_PATH: Final = (
    ROOT / "backend/app/identity/auth_provider.py"
)
PROVIDER_REGISTRY_PATH: Final = (
    ROOT / "backend/app/identity/provider_registry.py"
)
AUTH_MODELS_PATH: Final = ROOT / "backend/app/models/auth_models.py"
IDENTITY_MODELS_PATH: Final = (
    ROOT / "backend/app/models/identity_models.py"
)
MIGRATION_PATH: Final = (
    ROOT / "backend/migrations/versions/0001_initial_release_schema.py"
)
AUTH_SERVICES_PATH: Final = (
    ROOT / "backend/app/identity/auth_runtime_services.py"
)
REGISTRY_CONTRACT_PATH: Final = (
    ROOT / "contracts/identity/auth_provider_registry_v1.json"
)
AUTH_CONTEXT_CONTRACT_PATH: Final = (
    ROOT / "contracts/identity/auth_context_contract_v1.json"
)
TON_SCHEMA_PATH: Final = ROOT / "backend/app/schemas/auth_ton_schemas.py"
TON_ROUTE_PATH: Final = ROOT / "backend/app/routes/auth_ton_routes.py"
TON_FRONTEND_PATH: Final = ROOT / "frontend/src/lib/ton-auth.ts"
ACTIVE_PROVIDER_CANON: Final[tuple[str, ...]] = (
    "telegram",
    "ton",
    "google",
    "apple",
    "facebook",
    "discord",
    "github",
    "mock",
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _enum_values(path: Path, class_name: str) -> tuple[str, ...]:
    tree = ast.parse(_read(path), filename=str(path))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            values = [
                item.value.value
                for item in node.body
                if isinstance(item, ast.Assign)
                and len(item.targets) == 1
                and isinstance(item.targets[0], ast.Name)
                and item.targets[0].id.isupper()
                and isinstance(item.value, ast.Constant)
                and isinstance(item.value.value, str)
            ]
            return tuple(values)
    raise RuntimeError(f"Класс {class_name} не найден")


def _json(path: Path) -> dict[str, object]:
    payload = json.loads(_read(path))
    if not isinstance(payload, dict):
        raise RuntimeError(
            f"JSON-контракт не является объектом: {path}"
        )
    return payload


def build_report() -> dict[str, object]:
    enum_values = _enum_values(AUTH_PROVIDER_PATH, "AuthProvider")
    registry_contract = _json(REGISTRY_CONTRACT_PATH)
    context_contract = _json(AUTH_CONTEXT_CONTRACT_PATH)
    migration = _read(MIGRATION_PATH)
    provider_registry = _read(PROVIDER_REGISTRY_PATH)
    auth_models = _read(AUTH_MODELS_PATH)
    identity_models = _read(IDENTITY_MODELS_PATH)
    auth_services = _read(AUTH_SERVICES_PATH)
    ton_schema = _read(TON_SCHEMA_PATH)
    ton_route = _read(TON_ROUTE_PATH)
    ton_frontend = _read(TON_FRONTEND_PATH)
    contract_values = tuple(registry_contract["канонические_provider"])
    context_values = tuple(
        context_contract["endpoint_response"]["json_schema"]["$defs"]
        ["AuthProvider"]["enum"]
    )
    checks = {
        "enum_уникален": len(enum_values) == len(set(enum_values)),
        "active_provider_canon_совпадает": (
            enum_values == ACTIVE_PROVIDER_CANON
        ),
        "registry_contract_совпадает": contract_values == enum_values,
        "auth_context_contract_совпадает": (
            context_values == enum_values
        ),
        "registry_итерирует_AuthProvider": (
            "for provider in AuthProvider" in provider_registry
        ),
        "registry_использует_exact_parse": (
            "parse_auth_provider" in provider_registry
        ),
        "registry_mock_только_для_тестов": (
            '"test_only": True' in provider_registry
        ),
        "identity_orm_provider_guard": (
            "provider <> 'mock'" in identity_models
        ),
        "auth_orm_provider_guard": "provider <> 'mock'" in auth_models,
        "release_schema_uses_metadata": (
            "Base.metadata.create_all" in migration
        ),
        "release_schema_imports_models": (
            "from app import models" in migration
        ),
        "challenge_service_nominal_provider": (
            "if not isinstance(provider, AuthProvider):"
            in auth_services
        ),
        "challenge_service_mock_forbidden": (
            "if provider is AuthProvider.MOCK:" in auth_services
        ),
        "retired_ton_provider_alias_удалён": (
            'TON_WALLET' not in _read(AUTH_PROVIDER_PATH)
            and 'Literal["ton_wallet"]' not in ton_schema
            and 'active.get("ton_wallet")' not in ton_route
            and 'provider: "ton_wallet"' not in ton_frontend
        ),
        "ton_provider_wire_каноничен": (
            'TON = "ton"' in _read(AUTH_PROVIDER_PATH)
            and 'Literal["ton"]' in ton_schema
            and 'active.get("ton")' in ton_route
            and 'provider: "ton"' in ton_frontend
        ),
        "ton_provider_subject_каноничен": (
            "ton_wallet_id: StrictStr" in ton_schema
            and "ton_wallet_id: str" in ton_schema
            and "provider_subject: str" not in ton_schema
            and "ton_wallet_id: string" in ton_frontend
            and "provider_subject: string" not in ton_frontend
        ),
    }
    failed = sorted(
        name for name, passed in checks.items() if not passed
    )
    return {
        "схема_отчёта": "EFHC_AUTH_PROVIDER_STATIC_ALIGNMENT_V2",
        "статус": "PASS" if not failed else "FAIL",
        "канонические_provider": list(enum_values),
        "количество_provider": len(enum_values),
        "проверки": checks,
        "ошибки": failed,
        "импорт_приложения": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = build_report()
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
