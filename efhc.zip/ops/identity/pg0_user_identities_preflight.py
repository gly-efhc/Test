"""Read-only PG-0 preflight перед migration ``user_identities``."""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any

import sqlalchemy as sa
from sqlalchemy.engine import Connection

EXPECTED_SCHEMA = "efhc_core"
EXPECTED_PRE_MIGRATION_REVISION = "0002"
EXPECTED_POST_MIGRATION_REVISION = "0003"


@dataclass(frozen=True, slots=True)
class Pg0Result:
    """Детерминированный результат read-only PostgreSQL preflight."""

    passed: bool
    revision: str
    identity_table_state: str
    metrics: dict[str, Any]
    financial_snapshot: dict[str, str | int]
    violations: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        """Сериализовать результат с русскими evidence keys."""

        return {
            "схема": "EFHC_PG0_USER_IDENTITIES_V1",
            "пройдено": self.passed,
            "revision": self.revision,
            "состояние_user_identities": self.identity_table_state,
            "метрики": self.metrics,
            "финансовый_snapshot": self.financial_snapshot,
            "нарушения": list(self.violations),
            "режим": "READ_ONLY",
        }


def _scalar(conn: Connection, sql: str) -> Any:
    return conn.execute(sa.text(sql)).scalar()


def _regclass(conn: Connection, qualified_name: str) -> str | None:
    """Безопасно проверить объект без исключения undefined_table."""

    value = conn.execute(
        sa.text("SELECT to_regclass(:qualified_name)"),
        {"qualified_name": qualified_name},
    ).scalar()
    return None if value is None else str(value)


def _decimal_text(value: object) -> str:
    if value is None:
        return "0.00000000"
    decimal = Decimal(str(value)).quantize(Decimal("0.00000000"))
    return format(decimal, "f")


def _financial_snapshot(conn: Connection) -> dict[str, str | int]:
    row = conn.execute(
        sa.text(
            "SELECT count(*) AS rows, "
            "COALESCE(sum(main_balance), 0) AS main_balance, "
            "COALESCE(sum(bonus_balance), 0) AS bonus_balance, "
            "COALESCE(sum(total_generated_kwh), 0) "
            "AS total_generated_kwh, "
            "COALESCE(sum(exchanged_kwh_total), 0) "
            "AS exchanged_kwh_total, "
            "COALESCE(sum(available_kwh), 0) AS available_kwh "
            "FROM efhc_core.users"
        )
    ).mappings().one()
    return {
        "users_rows": int(row["rows"]),
        "main_balance": _decimal_text(row["main_balance"]),
        "bonus_balance": _decimal_text(row["bonus_balance"]),
        "total_generated_kwh": _decimal_text(
            row["total_generated_kwh"]
        ),
        "exchanged_kwh_total": _decimal_text(
            row["exchanged_kwh_total"]
        ),
        "available_kwh": _decimal_text(row["available_kwh"]),
    }


def collect_pg0(
    conn: Connection,
    *,
    expected_revision: str = EXPECTED_PRE_MIGRATION_REVISION,
) -> Pg0Result:
    """Собрать PG-0 без DDL, DML, locks или изменения данных."""

    violations: list[str] = []
    dialect = str(conn.dialect.name).lower()
    if dialect != "postgresql":
        violations.append(f"dialect_not_postgresql:{dialect}")
    else:
        conn.execute(sa.text("SET TRANSACTION READ ONLY"))
        read_only = str(
            _scalar(conn, "SHOW transaction_read_only") or ""
        ).lower()
        if read_only != "on":
            violations.append("transaction_not_read_only")
        server_version = int(
            _scalar(
                conn,
                "SELECT current_setting('server_version_num')::int",
            )
            or 0
        )
        if server_version < 140000:
            violations.append(
                f"postgresql_version_too_old:{server_version}"
            )

    alembic_table = _regclass(conn, "efhc_core.alembic_version")
    revision = ""
    if alembic_table is None:
        violations.append("alembic_version_table_missing")
    else:
        revision = str(
            _scalar(
                conn,
                "SELECT version_num FROM efhc_core.alembic_version",
            )
            or ""
        )
    if revision != expected_revision:
        violations.append(
            f"revision_expected_{expected_revision}_got_{revision}"
        )

    users_table = _regclass(conn, "efhc_core.users")
    if users_table is None:
        violations.append("users_table_missing")

    columns = {
        str(value)
        for value in conn.execute(
            sa.text(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_schema='efhc_core' "
                "AND table_name='users'"
            )
        ).scalars()
    }
    for name in ("id", "user_id", "tg_id"):
        if name not in columns:
            violations.append(f"users_column_missing:{name}")

    user_id_nullable = str(
        _scalar(
            conn,
            "SELECT is_nullable FROM information_schema.columns "
            "WHERE table_schema='efhc_core' AND table_name='users' "
            "AND column_name='user_id'",
        )
        or ""
    )
    if user_id_nullable != "YES":
        violations.append("users_user_id_must_remain_nullable")

    constraint_names = {
        str(value)
        for value in conn.execute(
            sa.text(
                "SELECT conname FROM pg_constraint "
                "WHERE conrelid=to_regclass('efhc_core.users')"
            )
        ).scalars()
    }
    for name in ("uq_users_user_id", "ck_users_user_id_range"):
        if name not in constraint_names:
            violations.append(f"users_constraint_missing:{name}")

    sequence_row = conn.execute(
        sa.text(
            "SELECT seqmin, seqmax, seqcycle "
            "FROM pg_sequence "
            "WHERE seqrelid=to_regclass('efhc_core.users_user_id_seq')"
        )
    ).mappings().first()
    if sequence_row is None:
        violations.append("users_user_id_sequence_missing")
    else:
        if int(sequence_row["seqmin"]) != 1:
            violations.append("users_user_id_sequence_min_invalid")
        if int(sequence_row["seqmax"]) != 9_999_999_999:
            violations.append("users_user_id_sequence_max_invalid")
        if bool(sequence_row["seqcycle"]):
            violations.append("users_user_id_sequence_must_not_cycle")

    metrics = {
        "users_rows": int(
            _scalar(conn, "SELECT count(*) FROM efhc_core.users") or 0
        ),
        "global_id_null": int(
            _scalar(
                conn,
                "SELECT count(*) FROM efhc_core.users "
                "WHERE user_id IS NULL",
            )
            or 0
        ),
        "global_id_duplicates": int(
            _scalar(
                conn,
                "SELECT count(*) FROM ("
                "SELECT user_id FROM efhc_core.users "
                "WHERE user_id IS NOT NULL GROUP BY user_id "
                "HAVING count(*) > 1"
                ") AS duplicated",
            )
            or 0
        ),
        "global_id_out_of_range": int(
            _scalar(
                conn,
                "SELECT count(*) FROM efhc_core.users "
                "WHERE user_id IS NOT NULL "
                "AND (user_id < 1 OR user_id > 9999999999)",
            )
            or 0
        ),
    }
    if metrics["global_id_duplicates"] != 0:
        violations.append("global_id_duplicates_detected")
    if metrics["global_id_out_of_range"] != 0:
        violations.append("global_id_out_of_range_detected")

    identity_table = _scalar(
        conn,
        "SELECT to_regclass('efhc_core.user_identities')",
    )
    identity_state = "ABSENT"
    if identity_table is not None:
        identity_state = "PRESENT_BEFORE_0003"
        violations.append("user_identities_present_before_0003")

    return Pg0Result(
        passed=not violations,
        revision=revision,
        identity_table_state=identity_state,
        metrics=metrics,
        financial_snapshot=_financial_snapshot(conn),
        violations=tuple(violations),
    )


def database_url_from_env() -> str:
    """Получить sync PostgreSQL URL без раскрытия его в diagnostics."""

    url = (
        os.getenv("PSYCOPG_URL")
        or os.getenv("SYNC_DATABASE_URL")
        or os.getenv("DATABASE_URL")
    )
    if not url:
        raise RuntimeError(
            "PostgreSQL URL отсутствует; PG-0 не выполнен"
        )
    if url.lower().startswith("sqlite"):
        raise RuntimeError("SQLite запрещён для PG-0")
    return url


def main() -> int:
    """CLI для контролируемого CI-запуска read-only preflight."""

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--expected-revision",
        default=EXPECTED_PRE_MIGRATION_REVISION,
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    engine = sa.create_engine(database_url_from_env(), future=True)
    try:
        with engine.connect() as conn:
            result = collect_pg0(
                conn,
                expected_revision=args.expected_revision,
            )
    finally:
        engine.dispose()

    payload = result.to_dict()
    rendered = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
