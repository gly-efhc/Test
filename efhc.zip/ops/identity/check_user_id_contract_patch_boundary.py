"""Verify that the contract patch did not switch ownership."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

SCHEMA = "EFHC_USER_ID_CONTRACT_PATCH_BOUNDARY_V1"
SKIP_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema") != SCHEMA:
        raise ValueError("unsupported UserId patch boundary schema")
    return data


def check(root: Path, manifest_path: Path) -> dict[str, Any]:
    manifest = _load(manifest_path)
    errors: list[str] = []
    files: dict[str, str] = {}
    for item in manifest["protected_file_entries"]:
        relative = "/".join(item["path_parts"])
        expected = "".join(item["sha256_parts"])
        files[relative] = expected
    for relative, expected in sorted(files.items()):
        path = root / relative
        if not path.is_file():
            errors.append(f"protected file missing: {relative}")
            continue
        actual = _sha256(path)
        if actual != expected:
            errors.append(
                f"protected file changed: {relative} "
                f"{actual}!={expected}"
            )
    protected_roots = tuple(manifest["protected_roots"])
    allowed_new = set(manifest["allowed_new_files"])
    expected_paths = set(files)
    for relative_root in protected_roots:
        base = root / relative_root
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file():
                continue
            relative_path = path.relative_to(root)
            if set(relative_path.parts) & SKIP_PARTS:
                continue
            relative = relative_path.as_posix()
            if relative in expected_paths or relative in allowed_new:
                continue
            errors.append(f"unexpected protected file: {relative}")
    return {
        "schema": "EFHC_USER_ID_CONTRACT_PATCH_RESULT_V1",
        "source_head": manifest["source_head"],
        "target_head": manifest["target_head"],
        "cycle": manifest["cycle"],
        "protected_file_count": len(files),
        "allowed_new_files": sorted(allowed_new),
        "errors": errors,
        "passed": not errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path(
            "ops/identity/user_id_contract_patch_boundary.json"
        ),
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check(args.root.resolve(), args.manifest.resolve())
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.resolve().write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
