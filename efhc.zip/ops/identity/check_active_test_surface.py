#!/usr/bin/env python3
"""Fail-closed guard активного test-layer EFHC.

Исторические, version/cycle-specific и artifact-dependent тесты вынесены
в отдельный пользовательский history archive и не находятся в active HEAD. Активные тесты
используют ``global_id`` как business owner; ``tg_id`` разрешён только
на реальной Telegram/provider boundary.
"""

from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
TESTS = ROOT / "tests"
STALE_FILENAME = re.compile(
    r"(?:^|_)(?:v\d+(?:_\d+)*|cycle_?\d+|wave_?\d+|fresh_ci|"
    r"current_release)(?:_|\.|$)",
    re.IGNORECASE,
)
EXTERNAL_NUMERIC_GLOBAL_ID = re.compile(
    r'["\']global_id["\']\s*:\s*(?!["\'])[0-9][0-9_]*'
)
FAKE_PROVIDER_OWNER = re.compile(
    r"\bglobal_id\s*=\s*(?:int\s*\(\s*)?tg_id\b"
)
NEGATIVE_FIXTURE_ALLOWLIST = {
    "tests/architecture/test_auth_context_contracts_foundation.py",
    "tests/architecture/test_auth_provider_registry_foundation.py",
    "tests/architecture/test_cross_language_identity_separation.py",
    "tests/architecture/test_global_id_canon_foundation.py",
}
LEGACY_BUSINESS_KWARGS = {"actor_tg_id", "owner_tg_id", "user_tg_id"}
BUSINESS_OWNER_TABLES = {
    "panels",
    "panels_archive",
    "user_tasks_status",
    "task_bonus_log",
    "task_complete_lock",
    "task_submissions",
    "shop_orders",
    "ranks_snapshots",
    "ranks_top_cache",
    "ranks_user_snapshots",
    "achievements",
    "tx_hash_locks",
}
CREATE_TABLE = re.compile(
    r"CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+"
    r"(?:efhc_core\.)?([a-z_][a-z0-9_]*)\s*\((.*?)\)\s*",
    re.IGNORECASE | re.DOTALL,
)


def _relative(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _iter_active_python() -> list[Path]:
    return sorted(TESTS.rglob("*.py"))


def _call_keyword_violations(path: Path, text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return [
            {
                "file": _relative(path),
                "line": exc.lineno or 0,
                "rule": "TEST_SYNTAX_ERROR",
                "detail": str(exc),
            }
        ]
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        for keyword in node.keywords:
            if keyword.arg in LEGACY_BUSINESS_KWARGS:
                findings.append(
                    {
                        "file": _relative(path),
                        "line": getattr(keyword, "lineno", 0),
                        "rule": "LEGACY_BUSINESS_OWNER_KWARG",
                        "detail": str(keyword.arg),
                    }
                )
    return findings


def _fixture_owner_column_violations(
    path: Path,
    text: str,
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    # Architecture-тесты могут содержать намеренно ошибочные фрагменты,
    # чтобы доказать их отклонение guard-правилами. Business fixtures — нет.
    if "tests/architecture/" in _relative(path):
        return findings
    for match in CREATE_TABLE.finditer(text):
        table = match.group(1).lower()
        body = match.group(2)
        if table not in BUSINESS_OWNER_TABLES:
            continue
        if re.search(r"\btg_id\b", body):
            findings.append(
                {
                    "file": _relative(path),
                    "line": text.count("\n", 0, match.start()) + 1,
                    "rule": "LEGACY_OWNER_COLUMN_IN_FIXTURE",
                    "detail": f"{table}.tg_id",
                }
            )
    return findings


def _manifest_violations() -> list[dict[str, Any]]:
    """Архивные тесты вынесены из active HEAD и проверяются внешним архивом."""
    return []

def audit(root: Path = ROOT) -> dict[str, Any]:
    if root != ROOT:
        raise ValueError("custom root is not supported by this exact-head guard")
    findings: list[dict[str, Any]] = []
    active_files = _iter_active_python()
    for path in active_files:
        rel = _relative(path)
        text = path.read_text(encoding="utf-8", errors="replace")
        if STALE_FILENAME.search(path.name):
            findings.append(
                {
                    "file": rel,
                    "line": 0,
                    "rule": "STALE_TEST_FILENAME",
                    "detail": path.name,
                }
            )
        if "tests/frontend/e2e/" in rel:
            for match in EXTERNAL_NUMERIC_GLOBAL_ID.finditer(text):
                findings.append(
                    {
                        "file": rel,
                        "line": text.count("\n", 0, match.start()) + 1,
                        "rule": "EXTERNAL_GLOBAL_ID_NOT_STRING",
                        "detail": match.group(0),
                    }
                )
            if "ROOT / \"docs/history" in text or "ROOT / 'docs/history" in text:
                findings.append(
                    {
                        "file": rel,
                        "line": 0,
                        "rule": "E2E_WRITES_REPOSITORY_ARTIFACTS",
                        "detail": "use EFHC_TEST_ARTIFACT_DIR",
                    }
                )
        if rel not in NEGATIVE_FIXTURE_ALLOWLIST:
            for match in FAKE_PROVIDER_OWNER.finditer(text):
                findings.append(
                    {
                        "file": rel,
                        "line": text.count("\n", 0, match.start()) + 1,
                        "rule": "FAKE_TG_ID_GLOBAL_ID_PAIR",
                        "detail": match.group(0),
                    }
                )
        findings.extend(_call_keyword_violations(path, text))
        findings.extend(_fixture_owner_column_violations(path, text))
    findings.extend(_manifest_violations())

    pytest_ini = (ROOT / "pytest.ini").read_text(encoding="utf-8")
    if "testpaths = tests" not in pytest_ini:
        findings.append(
            {
                "file": "pytest.ini",
                "line": 0,
                "rule": "PYTEST_TESTPATH_NOT_ISOLATED",
                "detail": "testpaths must be tests",
            }
        )

    return {
        "schema": "EFHC_ACTIVE_TEST_SURFACE_V1",
        "version": "v173.27",
        "cycle": 1706,
        "active_python_files": len(active_files),
        "archived_manifest_entries": 0,
        "violations": findings,
        "violation_count": len(findings),
        "passed": not findings,
    }


def main() -> int:
    result = audit()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
