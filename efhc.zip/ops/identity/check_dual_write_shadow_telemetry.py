#!/usr/bin/env python3
"""Проверка final identity runtime внутри единой release migration."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MIGRATION = (
    ROOT
    / "backend/migrations/versions/0001_initial_release_schema.py"
)


def collect() -> dict[str, object]:
    source = MIGRATION.read_text(encoding="utf-8")
    checks = {
        "revision_0001": 'revision = "0001"' in source,
        "single_parent": "down_revision = None" in source,
        "control_table": "identity_migration_control" in source,
        "dual_write": "dual_write_enabled" in source,
        "shadow_read": "shadow_read_enabled" in source,
        "legacy_authoritative": "legacy_authoritative" in source,
        "telemetry_view": (
            "identity_ownership_shadow_telemetry" in source
        ),
        "conflict_fail_closed": "dual-write conflict" in source,
        "physical_global_id": (
            "users.user_id physical column forbidden" in source
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    return {
        "схема": "EFHC_FINAL_IDENTITY_RUNTIME_GUARD_V1",
        "статус": "PASS" if not failed else "FAIL",
        "alembic_head": "0001",
        "проверки": checks,
        "ошибки": failed,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = collect()
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
