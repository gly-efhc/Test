"""Статический fail-closed guard TON Proof цикла 1616."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def проверить(root: Path = ROOT) -> dict[str, object]:
    """Проверить только новый TON Proof scope без app import."""

    service_path = root / (
        "backend/app/identity/ton_proof_verification.py"
    )
    route_path = root / "backend/app/routes/auth_ton_routes.py"
    schema_path = root / "backend/app/schemas/auth_ton_schemas.py"
    contract_path = root / (
        "contracts/identity/ton_proof_verification_contract_v1.json"
    )
    violations: list[str] = []
    for path in (
        service_path,
        route_path,
        schema_path,
        contract_path,
    ):
        if not path.is_file():
            violations.append(f"Отсутствует {path.relative_to(root)}")

    if violations:
        return {"статус": "FAIL", "нарушения": violations}

    service = service_path.read_text(encoding="utf-8")
    route = route_path.read_text(encoding="utf-8")
    schema = schema_path.read_text(encoding="utf-8")
    contract = json.loads(contract_path.read_text(encoding="utf-8"))

    required_service = (
        "build_ton_proof_message",
        "verify_ton_signature",
        "TonApiStateInitResolver",
        "expected_challenge_id=challenge_id",
        "TIMESTAMP_EXPIRED",
        "TIMESTAMP_IN_FUTURE",
        "STATE_INIT_ADDRESS_MISMATCH",
        "CHALLENGE_NOT_CONSUMABLE",
    )
    for marker in required_service:
        if marker not in service:
            violations.append(f"Service marker отсутствует: {marker}")

    for marker in (
        '"/proof"',
        "TonLoginProofIn",
        "TonLoginProofOut",
        'response.headers["Cache-Control"] = "no-store"',
    ):
        if marker not in route:
            violations.append(f"Route marker отсутствует: {marker}")

    for forbidden in (
        "tg_id",
        "UserIdentity(",
        "GlobalId(",
    ):
        if forbidden in service or forbidden in route:
            violations.append(
                f"Запрещённый side effect marker: {forbidden}"
            )
    if "AuthSessionService" in service:
        violations.append(
            "Verifier не должен выдавать session самостоятельно"
        )

    for marker in (
        'model_config = ConfigDict(extra="forbid")',
        'Literal["-239", "-3"]',
        'validation_alias="lengthBytes"',
    ):
        if marker not in schema:
            violations.append(f"Schema marker отсутствует: {marker}")

    if contract.get("цикл") != 1616:
        violations.append("Contract cycle не равен 1616")
    if contract.get("alembic_head") != "0001":
        violations.append("Alembic head contract не равен 0001")
    if contract.get("migration_0005") is not False:
        violations.append("Contract ошибочно разрешает migration 0005")


    return {
        "статус": "PASS" if not violations else "FAIL",
        "цикл": 1616,
        "проверка_без_импорта_приложения": True,
        "нарушения": violations,
    }


def main() -> int:
    """CLI для Operator Kernel и targeted CI evidence."""

    result = проверить()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["статус"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
