#!/usr/bin/env bash
# Воспроизводимый запуск reconciliation против существующей PostgreSQL.
# Скрипт не запускает миграции и не изменяет данные.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUTPUT="${1:-$ROOT/reports/generated/postgresql_reconciliation_cycle_1603_v172_00.json}"
SQL_OUTPUT="${2:-$ROOT/reports/generated/postgresql_reconciliation_cycle_1603_v172_00.sql}"
DATABASE_URL_VALUE="${PSYCOPG_URL:-${SYNC_DATABASE_URL:-${DATABASE_URL:-}}}"

if [[ -z "$DATABASE_URL_VALUE" ]]; then
  echo "Не задан PSYCOPG_URL, SYNC_DATABASE_URL или DATABASE_URL" >&2
  exit 3
fi

cd "$ROOT"
PYTHONPATH=.:backend python ops/identity/postgresql_reconciliation_gate.py \
  --database-url "$DATABASE_URL_VALUE" \
  --cycle 1603 \
  --source-head EFHC_Bot_v171_99.zip \
  --target-head EFHC_Bot_v172_00.zip \
  --output "$OUTPUT" \
  --sql-output "$SQL_OUTPUT"
