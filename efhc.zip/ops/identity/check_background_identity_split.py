#!/usr/bin/env python3
"""Проверить owner/delivery split в background-контуре."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]


def _text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def check() -> dict[str, Any]:
    violations: list[str] = []
    watcher = _text("backend/app/services/watcher_service.py")
    notifications = _text(
        "backend/app/services/shop_order_notifications_service.py"
    )
    channel = _text("backend/app/identity/notification_channel.py")
    admin_notifications = _text(
        "backend/app/services/admin/admin_notifications.py"
    )

    required = {
        "watcher_owner": (
            watcher,
            "class _WatcherOwner:",
            "global_id: int",
        ),
        "watcher_business_lookup": (
            watcher,
            "def _find_pending_order",
            "global_id",
        ),
        "shop_owner": (
            notifications,
            "SELECT id, global_id, status",
            "global_id=global_id",
        ),
        "delivery_resolution": (
            channel,
            "resolve_verified_telegram_subject",
            "global_id=gid",
        ),
        "admin_owner": (
            admin_notifications,
            "notify_new_withdrawal",
            "global_id: int",
        ),
    }
    for label, (text, first, second) in required.items():
        if first not in text or second not in text:
            violations.append(f"{label}:missing")

    forbidden = {
        "admin_business_tg_owner": (
            admin_notifications,
            "tg_id: int,",
        ),
        "admin_business_tg_payload": (
            admin_notifications,
            '\"tg_id\":',
        ),
        "shop_business_tg_query": (
            notifications,
            "FROM efhc_core.shop_orders WHERE tg_id",
        ),
    }
    for label, (text, marker) in forbidden.items():
        if marker in text:
            violations.append(f"{label}:forbidden")

    return {
        "schema": "EFHC_BACKGROUND_IDENTITY_SPLIT_V1",
        "background_business_state_tg_id": (
            0 if not violations else None
        ),
        "telegram_delivery_boundary": "PRESERVED",
        "violations": violations,
        "passed": not violations,
    }


def main() -> int:
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
