#!/usr/bin/env python3
"""Capture dynamic loading, caching and recovery UI proof."""

from __future__ import annotations

import json
import os
import sys
from collections.abc import Callable
from pathlib import Path
from shutil import which
from typing import Any

from playwright.sync_api import Page, sync_playwright

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tests.frontend.e2e._helpers import (  # noqa: E402
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

SHOTS = (
    ROOT / "reports/screenshots/interaction_load_recovery_1570/recovery"
)
REPORT = ROOT / "reports/generated/load_recovery_visual_v171_46.json"


def chromium_path() -> str:
    explicit = os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
    value = explicit or which("chromium") or which("google-chrome")
    if not value:
        raise RuntimeError("Chromium executable is unavailable")
    return value


def no_overflow(page: Page) -> bool:
    return not bool(
        page.evaluate(
            "document.documentElement.scrollWidth > window.innerWidth"
        )
    )


def screenshot(page: Page, name: str) -> str:
    SHOTS.mkdir(parents=True, exist_ok=True)
    target = SHOTS / name
    page.screenshot(path=str(target), full_page=True)
    if not target.exists() or target.stat().st_size <= 0:
        raise AssertionError(f"Screenshot not created: {name}")
    return str(target.relative_to(ROOT))


def browser_page(
    browser: Any,
    *,
    viewport: dict[str, int] | None = None,
    user_agent: str | None = None,
    reduced_motion: str | None = None,
) -> Page:
    context = browser.new_context(
        viewport=viewport or {"width": 390, "height": 844},
        user_agent=user_agent,
        reduced_motion=reduced_motion,
    )
    page = context.new_page()
    page.set_default_timeout(20_000)
    install_public_fallback(page, tg_id=1001)
    install_common_public_api_mocks(page)
    return page


def record(
    name: str,
    action: Callable[[Page], dict[str, Any]],
    browser: Any,
    **page_options: Any,
) -> dict[str, Any]:
    page = browser_page(browser, **page_options)
    errors: list[str] = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    try:
        result = action(page)
        result.update(
            {
                "name": name,
                "horizontal_overflow": not no_overflow(page),
                "page_errors": errors,
                "status": "OK"
                if no_overflow(page) and not errors
                else "FAILED",
            }
        )
        return result
    except Exception as error:  # noqa: BLE001
        return {
            "name": name,
            "status": "FAILED",
            "error": str(error)[:800],
            "page_errors": errors,
        }
    finally:
        page.context.close()


def shell_progress(page: Page) -> dict[str, Any]:
    page.add_init_script(
        """
        (() => {
          const nativeFetch = window.fetch.bind(window);
          window.fetch = async (...args) => {
            const target = String(args[0] || '');
            if (target.includes('/locale/')) {
              await new Promise((resolve) => setTimeout(resolve, 1800));
            }
            return nativeFetch(...args);
          };
        })();
        """
    )
    goto(page, "/")
    page.wait_for_selector(".efhc-splash-progress")
    value = page.locator(".efhc-splash-progress").inner_text()
    return {
        "route": "/",
        "progress_text": value,
        "screenshot": screenshot(page, "shell_progress_390x844.png"),
    }


def cache_progress(page: Page) -> dict[str, Any]:
    goto(page, "/")
    page.wait_for_selector('[data-energy-mobile-stage="true"]')
    page.evaluate(
        """
        window.dispatchEvent(new CustomEvent('efhc-runtime-progress', {
          detail: {
            channel: 'cache', value: 63, complete: false
          }
        }));
        """
    )
    page.wait_for_selector(".efhc-pwa-cache-progress")
    return {
        "route": "/",
        "progress": 63,
        "screenshot": screenshot(page, "cache_progress_63.png"),
    }


def faq_progress(page: Page) -> dict[str, Any]:
    page.add_init_script(
        """
        (() => {
          const nativeFetch = window.fetch.bind(window);
          window.fetch = async (...args) => {
            const target = String(args[0] || '');
            if (target.includes('/faq/')) {
              await new Promise((resolve) => setTimeout(resolve, 1800));
            }
            return nativeFetch(...args);
          };
        })();
        """
    )
    goto(page, "/faq")
    page.wait_for_selector(".efhc-faq-load-progress")
    value = page.locator(".efhc-faq-load-progress").get_attribute(
        "aria-valuenow"
    )
    return {
        "route": "/faq",
        "progress": value,
        "screenshot": screenshot(page, "faq_lazy_progress.png"),
    }


def financial_update(page: Page) -> dict[str, Any]:
    goto(page, "/withdraw")
    page.wait_for_selector('[data-public-surface="withdraw"]')
    page.wait_for_function(
        "!document.body.innerText.includes('pwa.update_available')"
    )
    page.wait_for_timeout(600)
    page.evaluate(
        "window.dispatchEvent(new Event('efhc-pwa-update-proof'))"
    )
    page.wait_for_selector(".efhc-pwa-update-card")
    body = page.locator(".efhc-pwa-update-card").inner_text()
    return {
        "route": "/withdraw",
        "deferred_copy_visible": True,
        "copy": body,
        "screenshot": screenshot(
            page,
            "financial_update_deferred.png",
        ),
    }


def low_end_android(page: Page) -> dict[str, Any]:
    page.add_init_script(
        """
        Object.defineProperty(navigator, 'deviceMemory', {
          configurable: true, value: 1
        });
        Object.defineProperty(navigator, 'hardwareConcurrency', {
          configurable: true, value: 2
        });
        Object.defineProperty(navigator, 'connection', {
          configurable: true,
          value: { saveData: true, effectiveType: '2g' }
        });
        """
    )
    goto(page, "/")
    page.wait_for_selector('[data-energy-mobile-stage="true"]')
    device = page.evaluate(
        """
        ({
          memory: navigator.deviceMemory,
          cores: navigator.hardwareConcurrency,
          saveData: navigator.connection.saveData,
          network: navigator.connection.effectiveType
        })
        """
    )
    return {
        "route": "/",
        "device": device,
        "screenshot": screenshot(page, "low_end_android_360.png"),
    }


def offline_recovery(page: Page) -> dict[str, Any]:
    goto(page, "/")
    page.wait_for_selector('[data-energy-mobile-stage="true"]')
    page.evaluate(
        """
        Object.defineProperty(navigator, 'onLine', {
          configurable: true, value: false
        });
        window.dispatchEvent(new Event('offline'));
        """
    )
    page.wait_for_selector(".efhc-network-status")
    offline = screenshot(page, "offline_state.png")
    page.evaluate(
        """
        Object.defineProperty(navigator, 'onLine', {
          configurable: true, value: true
        });
        window.dispatchEvent(new Event('online'));
        """
    )
    page.wait_for_timeout(400)
    online_count = page.locator(".efhc-network-status").count()
    online = screenshot(page, "online_recovered.png")
    return {
        "route": "/",
        "offline_screenshot": offline,
        "online_screenshot": online,
        "banner_after_online": online_count,
    }


def update_activation(page: Page) -> dict[str, Any]:
    goto(page, "/")
    page.wait_for_selector('[data-energy-mobile-stage="true"]')
    page.wait_for_function(
        "!document.body.innerText.includes('pwa.update_available')"
    )
    page.wait_for_timeout(600)
    page.evaluate(
        "window.dispatchEvent(new Event('efhc-pwa-update-proof'))"
    )
    page.get_by_role("button", name="Обновить").click()
    page.wait_for_selector(".efhc-pwa-update-applied")
    return {
        "route": "/",
        "screenshot": screenshot(page, "update_applied.png"),
    }


def main() -> None:
    os.environ.setdefault(
        "EFHC_E2E_BASE_URL",
        "http://127.0.0.1:3000",
    )
    android_ua = (
        "Mozilla/5.0 (Linux; Android 10; K) "
        "AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
    )
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=chromium_path(),
            args=["--no-sandbox"],
        )
        try:
            rows = [
                record("shell_progress", shell_progress, browser),
                record("cache_progress", cache_progress, browser),
                record("faq_progress", faq_progress, browser),
                record("financial_update", financial_update, browser),
                record(
                    "low_end_android",
                    low_end_android,
                    browser,
                    viewport={"width": 360, "height": 800},
                    user_agent=android_ua,
                    reduced_motion="reduce",
                ),
                record("offline_recovery", offline_recovery, browser),
                record("update_activation", update_activation, browser),
            ]
        finally:
            browser.close()
    status = (
        "PASSED"
        if all(row.get("status") == "OK" for row in rows)
        else "FAILED"
    )
    report = {
        "schema": "EFHC_LOAD_RECOVERY_VISUAL_V1",
        "cycle": 1570,
        "archive_version": "v171.46",
        "status": status,
        "cases_total": len(rows),
        "cases_ok": sum(row.get("status") == "OK" for row in rows),
        "cases": rows,
        "cache_storage_boundary": (
            "managed Chromium URLBlocklist prevents direct-origin "
            "CacheStorage inspection; service-worker eviction and "
            "repopulation are verified by contract tests"
        ),
        "production_cache": "NOT_ASSERTED_BY_CONTROLLED_BROWSER",
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if status != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
