#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from observability_visual_proof import _record

ROOT = Path(__file__).resolve().parents[2]


def case(
    name: str,
    path: str,
    lang: str,
    marker: str,
    width: int,
    height: int,
) -> dict[str, Any]:
    return {
        "name": name,
        "path": path,
        "lang": lang,
        "marker": marker,
        "width": width,
        "height": height,
    }


CASES: list[dict[str, Any]] = [
    case("energy_360", "/", "ru", ".efhc-energy-page", 360, 800),
    case("energy_390", "/", "ru", ".efhc-energy-page", 390, 844),
    case("energy_430", "/", "de", ".efhc-energy-page", 430, 932),
    case(
        "energy_tablet_768",
        "/",
        "en",
        ".efhc-energy-page",
        768,
        1024,
    ),
    case(
        "panels_390",
        "/panels",
        "ru",
        ".efhc-panels-shell",
        390,
        844,
    ),
    case(
        "profile_390",
        "/web-profile",
        "ru",
        ".efhc-profile-page",
        390,
        844,
    ),
    case(
        "withdraw_390",
        "/withdraw",
        "uk",
        "[data-public-surface='withdraw']",
        390,
        844,
    ),
    case(
        "browser_shop_430",
        "/browser-shop",
        "en",
        "[data-public-surface='browser-shop']",
        430,
        932,
    ),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default="http://127.0.0.1:3000",
    )
    parser.add_argument(
        "--screenshots",
        default=str(
            ROOT / "reports/screenshots/pwa_webview_wcag_1569"
        ),
    )
    parser.add_argument(
        "--report",
        default=str(
            ROOT
            / "reports/generated/"
            "pwa_webview_wcag_visual_v171_45.json"
        ),
    )
    args = parser.parse_args()
    output = Path(args.screenshots).resolve()
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    base_url = args.base_url.rstrip("/")
    for item in CASES:
        print(f"[pwa-visual] {item['name']}", flush=True)
        rows.append(
            _record(
                base_url,
                output,
                item,
                hard_exit=False,
            )
        )
    status = (
        "PASSED"
        if all(row.get("status") == "OK" for row in rows)
        else "FAILED"
    )
    report = {
        "schema": "EFHC_PWA_WEBVIEW_WCAG_VISUAL_V1",
        "cycle": 1569,
        "archive_version": "v171.45",
        "status": status,
        "cases_total": len(rows),
        "cases_ok": sum(
            row.get("status") == "OK" for row in rows
        ),
        "viewports": [360, 390, 430, 768],
        "cases": rows,
        "proof_boundary": {
            "browser_visual": "VERIFIED_LOCALLY",
            "real_telegram_client": "NOT_VERIFIED",
            "service_worker_offline_runtime": (
                "STATIC_AND_BROWSER_POLICY_PROOF"
            ),
        },
    }
    report_path = Path(args.report)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False))
    if report["status"] != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
