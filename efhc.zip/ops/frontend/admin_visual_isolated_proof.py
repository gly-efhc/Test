#!/usr/bin/env python3
"""Capture Admin visual proof in isolated Chromium processes."""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import tempfile
from contextlib import suppress
from pathlib import Path
from typing import Any

from admin_visual_button_click_proof import (
    ADMIN_ROUTES,
    CLICK_PROOF_HREFS,
    ROOT,
)


def _child_command(
    args: argparse.Namespace, kind: str, index: int
) -> list[str]:
    return [
        sys.executable,
        str(Path(__file__).resolve()),
        "--child-kind",
        kind,
        "--child-index",
        str(index),
        "--base-url",
        args.base_url,
        "--screenshots",
        args.screenshots,
    ]


def _run_child(command: list[str], timeout: int = 45) -> dict[str, Any]:
    with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            stdout=output,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            return_code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            return {
                "status": "FAILED",
                "error": f"child proof timed out after {timeout}s",
            }
        output.seek(0)
        text = output.read()
    lines = [line for line in text.splitlines() if line.strip()]
    if return_code != 0 or not lines:
        return {
            "status": "FAILED",
            "error": text[-1000:],
        }
    return json.loads(lines[-1])


def _child_route(args: argparse.Namespace) -> None:
    from admin_visual_button_click_proof import (
        _chromium_path,
        _launch_kwargs,
        _managed_url_blocklist_active,
        _new_page,
        _safe_slug,
        _visit_route,
    )
    from playwright.sync_api import sync_playwright

    route = ADMIN_ROUTES[args.child_index]
    shot = Path(args.screenshots).resolve() / f"{_safe_slug(route)}.png"
    shot.parent.mkdir(parents=True, exist_ok=True)
    set_content_mode = _managed_url_blocklist_active()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            **_launch_kwargs(_chromium_path())
        )
        try:
            context, page = _new_page(
                browser,
                args.base_url.rstrip("/"),
                proxy_local=set_content_mode,
            )
            try:
                result = _visit_route(
                    page,
                    args.base_url.rstrip("/"),
                    route,
                    shot,
                    set_content_mode=set_content_mode,
                )
            finally:
                context.close()
        finally:
            browser.close()
    print(json.dumps(result, ensure_ascii=False))


def _child_click(args: argparse.Namespace) -> None:
    from admin_visual_button_click_proof import (
        _chromium_path,
        _click_record,
        _click_record_loaded_root,
        _launch_kwargs,
        _load_server_document,
        _managed_url_blocklist_active,
        _new_page,
        _wait_for_shell_visual_ready,
    )
    from playwright.sync_api import sync_playwright

    href = CLICK_PROOF_HREFS[args.child_index]
    base_url = args.base_url.rstrip("/")
    set_content_mode = _managed_url_blocklist_active()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            **_launch_kwargs(_chromium_path())
        )
        try:
            context, page = _new_page(
                browser,
                base_url,
                proxy_local=set_content_mode,
            )
            try:
                if set_content_mode:
                    _load_server_document(
                        page,
                        f"{base_url}/admin",
                        base_url,
                        "/admin",
                    )
                    _wait_for_shell_visual_ready(page)
                    result = _click_record_loaded_root(page, href)
                else:
                    result = _click_record(
                        base_url,
                        page,
                        href,
                        set_content_mode=False,
                    )
            finally:
                context.close()
        finally:
            browser.close()
    print(json.dumps(result, ensure_ascii=False))


def _parent(args: argparse.Namespace) -> None:
    routes = []
    clicks = []
    for index, route in enumerate(ADMIN_ROUTES):
        print(f"[isolated-admin-proof] route {route}", flush=True)
        routes.append(_run_child(_child_command(args, "route", index)))
    for index, href in enumerate(CLICK_PROOF_HREFS):
        print(f"[isolated-admin-proof] click {href}", flush=True)
        clicks.append(_run_child(_child_command(args, "click", index)))

    status = "PASSED"
    if not all(row.get("status") == "OK" for row in routes + clicks):
        status = "FAILED"
    report = {
        "schema": "EFHC_ADMIN_VISUAL_ISOLATED_PROOF_V1",
        "cycle": args.cycle,
        "archive_version": args.archive_version,
        "status": status,
        "base_url": args.base_url.rstrip("/"),
        "viewport": "390x844",
        "execution": "one Chromium process per route/action",
        "routes_total": len(routes),
        "routes_ok": sum(row.get("status") == "OK" for row in routes),
        "clicks_total": len(clicks),
        "clicks_ok": sum(row.get("status") == "OK" for row in clicks),
        "screenshots_dir": str(
            Path(args.screenshots).resolve().relative_to(ROOT)
        ),
        "routes": routes,
        "clicks": clicks,
        "proof_boundary": {
            "admin_browser_visual": "VERIFIED_LOCALLY",
            "admin_dom_clicks": "VERIFIED_LOCALLY",
            "live_admin_backend": "NOT_VERIFIED_BY_VISUAL_HARNESS",
            "production_database": "NOT_ASSERTED_BY_VISUAL_HARNESS",
        },
    }
    report_path = Path(args.report).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if status != "PASSED":
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://localhost:3000")
    parser.add_argument(
        "--screenshots",
        default=str(ROOT / "reports/screenshots/admin_visual"),
    )
    parser.add_argument(
        "--report",
        default=str(ROOT / "reports/generated/admin_visual.json"),
    )
    parser.add_argument("--cycle", type=int, default=1566)
    parser.add_argument("--archive-version", default="v171.42")
    parser.add_argument("--child-kind", choices=("route", "click"))
    parser.add_argument("--child-index", type=int)
    args = parser.parse_args()
    if args.child_kind == "route":
        _child_route(args)
        return
    if args.child_kind == "click":
        _child_click(args)
        return
    _parent(args)


if __name__ == "__main__":
    main()
