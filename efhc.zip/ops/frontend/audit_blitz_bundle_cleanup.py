from pathlib import Path

root = Path(__file__).resolve().parents[2] / "frontend/src"
all_files = [
    str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()
]
legacy_tokens = ["lott" + "ery", "raff" + "le", "tourna" + "ment"]
legacy_hits = [
    p for p in all_files if any(k in p.lower() for k in legacy_tokens)
]
for hit in legacy_hits:
    raise SystemExit(
        f"unexpected removed-domain legacy file still present: {hit}"
    )
print("ok: no dead player-facing removed-domain frontend files remain")
