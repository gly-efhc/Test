#!/usr/bin/env python3
"""Run every public route and locale in isolated Chromium processes."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from public_visual_runtime_proof import (
    LANGUAGE_SET,
    PUBLIC_ROUTES,
    ROOT,
)


def run_child(
    index: int,
    lang: str,
    base_url: str,
    screenshots: Path,
) -> dict[str, Any]:
    command = [
        sys.executable,
        str(ROOT / "ops/frontend/public_visual_runtime_proof.py"),
        "--single-route-index",
        str(index),
        "--base-url",
        base_url,
        "--screenshots",
        str(screenshots),
        "--lang",
        lang,
    ]
    with tempfile.TemporaryFile(
        mode="w+t",
        encoding="utf-8",
    ) as output:
        try:
            process = subprocess.run(
                command,
                cwd=ROOT,
                stdout=output,
                stderr=output,
                timeout=55,
                check=False,
            )
        except subprocess.TimeoutExpired:
            return {
                "route": PUBLIC_ROUTES[index]["route"],
                "lang": lang,
                "status": "FAILED",
                "error": "isolated browser proof timeout",
            }
        output.seek(0)
        text = output.read()
    lines = [line for line in text.splitlines() if line.strip()]
    if process.returncode != 0 or not lines:
        return {
            "route": PUBLIC_ROUTES[index]["route"],
            "lang": lang,
            "status": "FAILED",
            "error": text[-1000:],
        }
    return json.loads(lines[-1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default="http://127.0.0.1:3000",
    )
    parser.add_argument(
        "--screenshots",
        default=str(
            ROOT
            / "reports/screenshots"
            / "full_regression_visual/public"
            / "public"
        ),
    )
    parser.add_argument(
        "--report",
        default=str(
            ROOT / "reports/generated/"
            "public_visual_v171_47.json"
        ),
    )
    args = parser.parse_args()
    screenshots = Path(args.screenshots).resolve()
    screenshots.mkdir(parents=True, exist_ok=True)
    route_rows = []
    for index, item in enumerate(PUBLIC_ROUTES):
        print(f"[public-isolated] {item['route']}", flush=True)
        route_rows.append(
            run_child(
                index,
                "ru",
                args.base_url,
                screenshots,
            )
        )
    language_rows = []
    for lang in LANGUAGE_SET:
        if lang == "ru":
            language_rows.append(dict(route_rows[0]))
            continue
        print(f"[public-isolated] / [{lang}]", flush=True)
        language_rows.append(
            run_child(
                0,
                lang,
                args.base_url,
                screenshots,
            )
        )
    all_rows = route_rows + language_rows
    status = (
        "PASSED"
        if all(row.get("status") == "OK" for row in all_rows)
        else "FAILED"
    )
    report = {
        "schema": "EFHC_PUBLIC_VISUAL_ISOLATED_PROOF_V1",
        "cycle": 1571,
        "archive_version": "v171.47",
        "status": status,
        "viewport": "390x844",
        "execution": "one Chromium process per route/locale",
        "routes_total": len(route_rows),
        "routes_ok": sum(
            row.get("status") == "OK" for row in route_rows
        ),
        "languages_total": len(language_rows),
        "languages_ok": sum(
            row.get("status") == "OK" for row in language_rows
        ),
        "routes": route_rows,
        "languages": language_rows,
        "proof_boundary": {
            "public_browser_visual": "VERIFIED_LOCALLY",
            "production_backend": "NOT_VERIFIED_BY_VISUAL_HARNESS",
        },
    }
    report_path = Path(args.report).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if status != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
