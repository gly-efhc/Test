from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import tempfile
from contextlib import suppress
from pathlib import Path
from typing import Any

from admin_visual_button_click_proof import (
    ROOT,
    VISUAL_PROOF_MIN_SETTLE_MS,
    _capture_screenshot,
    _chromium_path,
    _launch_kwargs,
    _route_request,
    _splash_visible,
    _wait_for_shell_visual_ready,
)
from playwright.sync_api import Page, sync_playwright

DEFAULT_REPORT = (
    ROOT / "reports/generated/public_pages_browser_proof_v170_96.json"
)
DEFAULT_SCREENSHOT_DIR = ROOT / "reports/generated/screenshots/public_visual_1520"

PUBLIC_ROUTES = [
    {"route": "/", "surface": "energy", "marker": ".efhc-energy-page"},
    {"route": "/app", "surface": "app", "marker": ".efhc-energy-page"},
    {
        "route": "/exchange",
        "surface": "exchange",
        "marker": ".efhc-exchange-shell",
    },
    {
        "route": "/withdraw",
        "surface": "withdraw",
        "marker": ".efhc-withdraw-trust-shell",
    },
    {
        "route": "/ads",
        "surface": "ads",
        "marker": ".efhc-tasks-shell",
    },
    {
        "route": "/tasks",
        "surface": "tasks",
        "marker": ".efhc-tasks-shell",
    },
    {
        "route": "/referrals",
        "surface": "referrals",
        "marker": ".efhc-referrals-shell",
    },
    {
        "route": "/referrals/active",
        "surface": "referrals-active",
        "marker": "[data-referrals-active-inactive-boundary]",
    },
    {
        "route": "/referrals/inactive",
        "surface": "referrals-inactive",
        "marker": "[data-referrals-active-inactive-boundary]",
    },
    {
        "route": "/ranks",
        "surface": "ranks",
        "marker": ".efhc-ranks-shell",
    },
    {
        "route": "/panels",
        "surface": "panels",
        "marker": ".efhc-panels-shell",
    },
    {
        "route": "/web-profile",
        "surface": "web-profile",
        "marker": ".efhc-profile-page",
    },
    {"route": "/faq", "surface": "faq", "marker": ".efhc-faq-shell"},
    {"route": "/hub", "surface": "hub", "marker": ".efhc-hub-page"},
    {
        "route": "/browser-shop",
        "surface": "browser-shop",
        "marker": "[data-public-surface='browser-shop']",
    },
]

LANGUAGE_SET = [
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
]

ERROR_OVERLAY_MARKERS = (
    "Runtime TypeError",
    "Failed to fetch",
    "Unhandled Runtime Error",
    "Application error",
)
INVALID_VISIBLE_MARKERS = ("undefined", "[object Object]")
RAW_I18N_RE = re.compile(r"\b[a-z][a-z0-9_]*(?:\.[a-z0-9_]+){1,}\b")
ALLOWED_RAW_TOKENS = {"t.me", "ton.org", "api.ton.org"}


def _safe_slug(path: str) -> str:
    return path.strip("/").replace("/", "__") or "energy_root"


def _console_errors(errors: list[str], msg: Any) -> None:
    if msg.type == "error":
        errors.append(str(msg.text))


def _filtered_console_errors(errors: list[str]) -> list[str]:
    return [
        item
        for item in errors
        if "Service Worker registration blocked" not in item
        and "Failed to load resource: net::ERR_FAILED" not in item
        and "A tree hydrated but some attributes" not in item
    ]


def _has_bad_raw_i18n(text: str) -> bool:
    for match in RAW_I18N_RE.finditer(text):
        value = match.group(0)
        if value in ALLOWED_RAW_TOKENS:
            continue
        if value.startswith(("http.", "https.")):
            continue
        return True
    return False


def _visible_error_text(body: str) -> list[str]:
    findings: list[str] = []
    for marker in ERROR_OVERLAY_MARKERS:
        if marker in body:
            findings.append(marker)
    for marker in INVALID_VISIBLE_MARKERS:
        if marker in body:
            findings.append(marker)
    if _has_bad_raw_i18n(body):
        findings.append("raw_i18n_key")
    return findings


def _install_public_fallback(
    page: Page,
    lang: str,
    base_url: str,
) -> None:
    page.add_init_script(
        f"""
        try {{
          window.localStorage.setItem('__efhc_probe__', '1');
          window.localStorage.removeItem('__efhc_probe__');
        }} catch {{
          const values = new Map();
          const storage = {{
            getItem: (key) => values.has(String(key))
              ? values.get(String(key))
              : null,
            setItem: (key, value) => {{
              values.set(String(key), String(value));
            }},
            removeItem: (key) => values.delete(String(key)),
            clear: () => values.clear(),
            key: (index) => Array.from(values.keys())[index] || null,
            get length() {{ return values.size; }}
          }};
          Object.defineProperty(window, 'localStorage', {{
            configurable: true,
            value: storage
          }});
          Object.defineProperty(window, 'sessionStorage', {{
            configurable: true,
            value: storage
          }});
        }}
        if (window.location.origin === 'null') {{
          const NativeURL = window.URL;
          const proofBaseUrl = __PROOF_BASE_URL__;
          class ProofURL extends NativeURL {{
            constructor(url, base) {{
              const safeBase = !base || String(base) === 'null'
                ? proofBaseUrl
                : base;
              super(url, safeBase);
            }}
          }}
          if (NativeURL.createObjectURL) {{
            ProofURL.createObjectURL = NativeURL.createObjectURL.bind(
              NativeURL
            );
          }}
          if (NativeURL.revokeObjectURL) {{
            ProofURL.revokeObjectURL = NativeURL.revokeObjectURL.bind(
              NativeURL
            );
          }}
          window.URL = ProofURL;
          const replaceState = window.history.replaceState.bind(
            window.history
          );
          const pushState = window.history.pushState.bind(
            window.history
          );
          window.history.replaceState = (state, title) => {{
            try {{ replaceState(state, title); }} catch {{
              return undefined;
            }}
          }};
          window.history.pushState = (state, title) => {{
            try {{ pushState(state, title); }} catch {{
              return undefined;
            }}
          }};
        }}
        window.localStorage.setItem('onboarding_v1_seen', '1');
        window.__EFHC_PUBLIC_VISUAL_PROOF__ = true;
        if (navigator.storage) {{
          try {{
            Object.defineProperty(navigator.storage, 'persisted', {{
              configurable: true,
              value: async () => true
            }});
          }} catch {{
            // Проверка маршрута продолжится без этой подсказки.
          }}
        }}
        window.localStorage.setItem(
          'EFHC_USER_SETTINGS_V2',
          JSON.stringify({{
            confirm_actions: false,
            confirm_purchase: false,
            confirm_withdraw: false,
            confirm_convert: false,
            confirm_watch_ad: false,
            haptics_enabled: false,
            sfx_enabled: false,
            toasts_enabled: false,
            hide_balances: false,
            theme_mode: 'dark',
            lang: {json.dumps(lang)}
          }})
        );
        window.Telegram = {{ WebApp: {{}} }};
        window.Telegram.WebApp.initData = '';
        window.Telegram.WebApp.initDataUnsafe = {{}};
        window.Telegram.WebApp.themeParams = {{
          bg_color: '#05070a',
          text_color: '#f7fbff',
          hint_color: '#8aa0b8',
          secondary_bg_color: '#101827',
          button_color: '#35b8ff',
          button_text_color: '#001018'
        }};
        window.Telegram.WebApp.colorScheme = 'dark';
        window.Telegram.WebApp.ready = () => undefined;
        window.Telegram.WebApp.expand = () => undefined;
        window.Telegram.WebApp.showConfirm = async () => true;
        window.Telegram.WebApp.showPopup = (opts, cb) => {{
          if (cb) cb('ok');
        }};
        window.Telegram.WebApp.openLink = (url) => {{
          window.open(url, '_blank', 'noopener,noreferrer');
        }};
        """.replace(
            "__PROOF_BASE_URL__",
            json.dumps(base_url.rstrip("/") + "/"),
        )
    )


def _overflow_ok(page: Page) -> bool:
    return bool(
        page.evaluate(
            "() => document.documentElement.scrollWidth <= "
            "window.innerWidth + 2"
        )
    )


def _base_record(
    item: dict[str, str],
    shot: Path,
    lang: str,
) -> dict[str, Any]:
    return {
        "route": item["route"],
        "page_type": item["surface"],
        "status": "UNKNOWN",
        "lang": lang,
        "screenshot": str(shot.relative_to(ROOT)),
    }


def _evaluate_loaded_page(
    page: Page,
    item: dict[str, str],
    shot: Path,
    lang: str,
    http_status: int | None,
    console_errors: list[str],
    page_errors: list[str],
) -> dict[str, Any]:
    record = _base_record(item, shot, lang)
    try:
        body = (page.locator("body").inner_text() or "").strip()
        visible = _visible_error_text(body)
        filtered_console = _filtered_console_errors(console_errors)
        marker_count = page.locator(item["marker"]).count()
        splash_visible = _splash_visible(page)
        _capture_screenshot(page, shot)
        overflow = not _overflow_ok(page)
        html_lang = page.locator("html").get_attribute("lang")
        locale_data = json.loads(
            (
                ROOT / "frontend/public/locale" / f"{lang}.json"
            ).read_text(encoding="utf-8")
        )
        nav_energy = page.locator('[data-nav-key="nav.energy"]')
        nav_energy_aria = (
            nav_energy.get_attribute("aria-label")
            if nav_energy.count() > 0
            else None
        )
        locale_match = html_lang == lang and (
            nav_energy_aria is None
            or nav_energy_aria == locale_data["nav.energy"]
        )
        ok = (
            http_status == 200
            and not page_errors
            and not filtered_console
            and not visible
            and marker_count >= 1
            and not splash_visible
            and not overflow
            and locale_match
            and shot.exists()
            and shot.stat().st_size > 0
        )
        record.update(
            {
                "status": "OK" if ok else "FAILED",
                "http_status": http_status,
                "navigation_mode": "direct-navigation",
                "html_lang": html_lang,
                "nav_energy_aria": nav_energy_aria,
                "locale_match": locale_match,
                "pageerror_count": len(page_errors),
                "console_error_count": len(filtered_console),
                "console_errors": filtered_console[:20],
                "page_errors": page_errors[:20],
                "error_overlay": bool(visible),
                "visible_findings": visible,
                "root_marker": marker_count,
                "splash_visible": splash_visible,
                "horizontal_overflow": overflow,
                "body_chars": len(body),
                "screenshot_bytes": shot.stat().st_size,
            }
        )
    except Exception as exc:  # noqa: BLE001
        record.update(
            {
                "status": "FAILED",
                "error": str(exc)[:500],
                "console_errors": _filtered_console_errors(
                    console_errors
                )[:20],
                "page_errors": page_errors[:20],
            }
        )
    return record


def _load_proof_page(
    context: Any,
    base_url: str,
    item: dict[str, str],
    shot: Path,
    lang: str,
) -> dict[str, Any]:
    console_errors: list[str] = []
    page_errors: list[str] = []
    page = context.new_page()
    page.set_default_timeout(8_000)
    page.set_default_navigation_timeout(20_000)
    _install_public_fallback(page, lang, base_url)
    page.on("console", lambda msg: _console_errors(console_errors, msg))
    page.on("pageerror", lambda exc: page_errors.append(str(exc)))
    target = f"{base_url}{item['route']}"
    try:
        response = page.goto(
            target,
            wait_until="domcontentloaded",
        )
        http_status = response.status if response else None
        return {
            "page": page,
            "item": item,
            "shot": shot,
            "lang": lang,
            "http_status": http_status,
            "console_errors": console_errors,
            "page_errors": page_errors,
            "load_error": None,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "page": page,
            "item": item,
            "shot": shot,
            "lang": lang,
            "http_status": None,
            "console_errors": console_errors,
            "page_errors": page_errors,
            "load_error": str(exc)[:500],
        }


def _browser_record(
    browser: Any,
    base_url: str,
    item: dict[str, str],
    shot: Path,
    lang: str,
) -> dict[str, Any]:
    context = browser.new_context(
        viewport={"width": 390, "height": 844},
        device_scale_factor=1,
        service_workers="block",
    )
    context.route(
        "**/*",
        lambda route: _route_request(
            route,
            proxy_local=False,
        ),
    )
    loaded = _load_proof_page(
        context,
        base_url,
        item,
        shot,
        lang,
    )
    if loaded["load_error"]:
        record = _base_record(item, shot, lang)
        record.update(
            {
                "status": "FAILED",
                "error": loaded["load_error"],
                "console_errors": _filtered_console_errors(
                    loaded["console_errors"]
                )[:20],
                "page_errors": loaded["page_errors"][:20],
            }
        )
        return record
    page = loaded["page"]
    _wait_for_shell_visual_ready(page)
    return _evaluate_loaded_page(
        page,
        item,
        shot,
        lang,
        loaded["http_status"],
        loaded["console_errors"],
        loaded["page_errors"],
    )


def _single_record(
    base_url: str,
    item: dict[str, str],
    shot: Path,
    lang: str,
) -> dict[str, Any]:
    executable = _chromium_path()
    p = sync_playwright().start()
    browser = p.chromium.launch(**_launch_kwargs(executable))
    return _browser_record(
        browser,
        base_url,
        item,
        shot,
        lang,
    )


def _run_one(
    index: int,
    base_url: str,
    screenshot_dir: Path,
    lang: str,
) -> None:
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    item = PUBLIC_ROUTES[index]
    shot = screenshot_dir / (f"{_safe_slug(item['route'])}__{lang}.png")
    record = _single_record(
        base_url.rstrip("/"),
        item,
        shot,
        lang,
    )
    print(json.dumps(record, ensure_ascii=False), flush=True)
    os._exit(0)


def _proof_jobs() -> list[tuple[int, str]]:
    jobs = [(index, "ru") for index in range(len(PUBLIC_ROUTES))]
    jobs.extend((0, lang) for lang in LANGUAGE_SET if lang != "ru")
    return jobs


def _proof_batches() -> list[list[tuple[int, str]]]:
    jobs = _proof_jobs()
    route_jobs = jobs[: len(PUBLIC_ROUTES)]
    language_jobs = jobs[len(PUBLIC_ROUTES) :]
    batches = [
        route_jobs[offset : offset + 4]
        for offset in range(0, len(route_jobs), 4)
    ]
    batches.extend(
        language_jobs[offset : offset + 4]
        for offset in range(0, len(language_jobs), 4)
    )
    return [batch for batch in batches if batch]


def _batch_records(
    base_url: str,
    screenshot_dir: Path,
    batch_jobs: list[tuple[int, str]],
) -> list[dict[str, Any]]:
    executable = _chromium_path()
    p = sync_playwright().start()
    browser = p.chromium.launch(**_launch_kwargs(executable))
    context = browser.new_context(
        viewport={"width": 390, "height": 844},
        device_scale_factor=1,
        service_workers="block",
    )
    context.route(
        "**/*",
        lambda route: _route_request(
            route,
            proxy_local=False,
        ),
    )
    loaded_batch: list[dict[str, Any]] = []
    for index, lang in batch_jobs:
        item = PUBLIC_ROUTES[index]
        shot = screenshot_dir / (
            f"{_safe_slug(item['route'])}__{lang}.png"
        )
        loaded = _load_proof_page(
            context,
            base_url,
            item,
            shot,
            lang,
            )
        loaded["job_index"] = index
        loaded_batch.append(loaded)
    if loaded_batch:
        loaded_batch[0]["page"].wait_for_timeout(
            VISUAL_PROOF_MIN_SETTLE_MS
        )
    records: list[dict[str, Any]] = []
    for loaded in loaded_batch:
        item = loaded["item"]
        lang = loaded["lang"]
        if loaded["load_error"]:
            record = _base_record(item, loaded["shot"], lang)
            record.update(
                {
                    "status": "FAILED",
                    "error": loaded["load_error"],
                    "console_errors": _filtered_console_errors(
                        loaded["console_errors"]
                    )[:20],
                    "page_errors": loaded["page_errors"][:20],
                }
            )
        else:
            with suppress(Exception):
                loaded["page"].wait_for_function(
                    """
                    () => (
                      document.documentElement.dataset.efhcShell ===
                      'ready'
                    )
                    """,
                    timeout=2_000,
                )
            record = _evaluate_loaded_page(
                loaded["page"],
                item,
                loaded["shot"],
                lang,
                loaded["http_status"],
                        loaded["console_errors"],
                loaded["page_errors"],
            )
        record["job_index"] = loaded["job_index"]
        records.append(record)
    return records


def _run_batch_child(
    batch_index: int,
    base_url: str,
    screenshot_dir: Path,
) -> None:
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    batches = _proof_batches()
    records = _batch_records(
        base_url.rstrip("/"),
        screenshot_dir,
        batches[batch_index],
    )
    print(json.dumps(records, ensure_ascii=False), flush=True)
    os._exit(0)


def _subprocess_batch_records(
    batch_index: int,
    base_url: str,
    screenshot_dir: Path,
) -> list[dict[str, Any]]:
    cmd = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--batch-index",
        str(batch_index),
        "--base-url",
        base_url,
        "--screenshots",
        str(screenshot_dir),
    ]
    timed_out = False
    with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as out:
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            text=True,
            stdout=out,
            stderr=out,
            start_new_session=True,
        )
        try:
            return_code = proc.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timed_out = True
            return_code = -1
        finally:
            # The Playwright driver and Chromium are descendants of the
            # isolated process group. Terminate that group even after
            # the
            # Python child exits so repeated proof batches cannot leak
            # browser processes or exhaust the host.
            with suppress(ProcessLookupError):
                os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                with suppress(subprocess.TimeoutExpired):
                    proc.wait(timeout=2)
        out.seek(0)
        output = out.read()
    if timed_out:
        return [
            {
                "status": "FAILED",
                "error": f"browser proof batch {batch_index} timeout",
                "batch_index": batch_index,
            }
        ]
    if return_code != 0:
        return [
            {
                "status": "FAILED",
                "error": output[-1000:],
                "batch_index": batch_index,
            }
        ]
    lines = [line for line in output.splitlines() if line.strip()]
    if not lines:
        return [
            {
                "status": "FAILED",
                "error": "browser proof batch returned no JSON",
                "batch_index": batch_index,
            }
        ]
    return json.loads(lines[-1])


def _subprocess_record(
    index: int,
    base_url: str,
    screenshot_dir: Path,
    lang: str,
) -> dict[str, Any]:
    cmd = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--single-route-index",
        str(index),
        "--base-url",
        base_url,
        "--screenshots",
        str(screenshot_dir),
        "--lang",
        lang,
    ]
    with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as out:
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                text=True,
                stdout=out,
                stderr=out,
                timeout=45,
                check=False,
                start_new_session=True,
            )
        except subprocess.TimeoutExpired:
            return {
                "route": PUBLIC_ROUTES[index]["route"],
                "page_type": PUBLIC_ROUTES[index]["surface"],
                "lang": lang,
                "status": "FAILED",
                "error": "browser proof child timeout",
            }
        out.seek(0)
        output = out.read()
    if proc.returncode != 0:
        return {
            "route": PUBLIC_ROUTES[index]["route"],
            "page_type": PUBLIC_ROUTES[index]["surface"],
            "lang": lang,
            "status": "FAILED",
            "error": output[-500:],
        }
    lines = [line for line in output.splitlines() if line.strip()]
    if not lines:
        return {
            "route": PUBLIC_ROUTES[index]["route"],
            "page_type": PUBLIC_ROUTES[index]["surface"],
            "lang": lang,
            "status": "FAILED",
            "error": "browser proof child returned no JSON record",
        }
    return json.loads(lines[-1])


def run(
    base_url: str,
    screenshot_dir: Path,
    report_path: Path,
) -> dict[str, Any]:
    screenshot_dir = screenshot_dir.resolve()
    report_path = report_path.resolve()
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    base_url = base_url.rstrip("/")
    batches = _proof_batches()
    batch_total = len(batches)
    results: dict[tuple[int, str], dict[str, Any]] = {}
    batch_dir = ROOT / "reports/generated/public_visual_1570_batches"
    batch_dir.mkdir(parents=True, exist_ok=True)
    for batch_index in range(batch_total):
        print(
            f"[public-proof] batch {batch_index + 1}/{batch_total}",
            flush=True,
        )
        batch_path = batch_dir / f"batch_{batch_index}.json"
        if batch_path.exists():
            batch_records = json.loads(
                batch_path.read_text(encoding="utf-8")
            )
        else:
            batch_records = _subprocess_batch_records(
                batch_index,
                base_url,
                screenshot_dir,
            )
            batch_path.write_text(
                json.dumps(
                    batch_records,
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
        expected_jobs = batches[batch_index]
        if len(batch_records) != len(expected_jobs):
            for index, lang in expected_jobs:
                results[(index, lang)] = {
                    "route": PUBLIC_ROUTES[index]["route"],
                    "page_type": PUBLIC_ROUTES[index]["surface"],
                    "lang": lang,
                    "status": "FAILED",
                    "error": batch_records[0].get(
                        "error",
                        "browser proof batch size mismatch",
                    ),
                }
            continue
        for (index, lang), record in zip(
            expected_jobs,
            batch_records,
            strict=True,
        ):
            results[(index, lang)] = record
            print(
                f"[public-proof] {PUBLIC_ROUTES[index]['route']} "
                f"[{lang}] {record['status']}",
                flush=True,
            )
    rows = [
        results[(index, "ru")] for index in range(len(PUBLIC_ROUTES))
    ]
    language_rows = [
        dict(rows[0]) if lang == "ru" else results[(0, lang)]
        for lang in LANGUAGE_SET
    ]
    all_rows = rows + language_rows
    status = (
        "PASSED"
        if all(row["status"] == "OK" for row in all_rows)
        else "FAILED"
    )
    report: dict[str, Any] = {
        "schema": "EFHC_PUBLIC_PAGES_BROWSER_PROOF_V2",
        "cycle": 1570,
        "archive_version": "v171.46",
        "status": status,
        "base_url": base_url,
        "viewport": "390x844",
        "browser": "chromium",
        "chromium_executable": _chromium_path(),
        "navigation_mode": "direct-navigation",
        "batch_plan": [len(batch) for batch in batches],
        "batches_total": batch_total,
        "routes_total": len(rows),
        "routes_ok": sum(1 for row in rows if row["status"] == "OK"),
        "languages_total": len(language_rows),
        "languages_ok": sum(
            1 for row in language_rows if row["status"] == "OK"
        ),
        "language_set": LANGUAGE_SET,
        "screenshots_dir": str(screenshot_dir.relative_to(ROOT)),
        "routes": rows,
        "languages": language_rows,
        "proof_boundary": {
            "public_pages_browser_visual": "VERIFIED_LOCALLY",
            "runtime_error_guard": "ENFORCED",
            "live_telegram": "NOT_VERIFIED",
            "real_tonconnect": "NOT_VERIFIED",
            "github_ci": "NOT_VERIFIED",
            "release_ready": "NOT_CLAIMED",
        },
    }
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if status != "PASSED":
        payload = json.dumps(
            report,
            ensure_ascii=False,
            indent=2,
        )
        raise SystemExit(payload)
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://localhost:3000")
    parser.add_argument(
        "--screenshots",
        default=str(DEFAULT_SCREENSHOT_DIR),
    )
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    parser.add_argument("--single-route-index", type=int, default=None)
    parser.add_argument("--batch-index", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--lang", default="ru", choices=LANGUAGE_SET)
    args = parser.parse_args()
    if args.batch_index is not None:
        _run_batch_child(
            args.batch_index,
            args.base_url,
            Path(args.screenshots).resolve(),
        )
        return
    if args.single_route_index is not None:
        _run_one(
            args.single_route_index,
            args.base_url,
            Path(args.screenshots).resolve(),
            args.lang,
        )
        return
    report = run(
        args.base_url,
        Path(args.screenshots),
        Path(args.report),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "routes_ok": report["routes_ok"],
                "routes_total": report["routes_total"],
                "languages_ok": report["languages_ok"],
                "languages_total": report["languages_total"],
                "report": str(Path(args.report)),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
