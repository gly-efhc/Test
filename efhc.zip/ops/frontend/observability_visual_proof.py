#!/usr/bin/env python3
"""Capture the security, observability and visual-improvement matrix."""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import tempfile
from contextlib import suppress
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import requests
from admin_visual_button_click_proof import (
    ROOT,
    _capture_screenshot,
    _chromium_path,
    _inject_base_href,
    _launch_kwargs,
    _managed_url_blocklist_active,
    _route_request,
)
from playwright.sync_api import sync_playwright
from public_visual_runtime_proof import _install_public_fallback

VIEWPORTS = (360, 390, 430, 768)
ERROR_STATES = (401, 403, 413, 429)

CASES: list[dict[str, Any]] = [
    *[
        {
            "name": f"privacy_ru_{width}",
            "path": "/web-profile?legal=privacy",
            "lang": "ru",
            "marker": "[data-public-surface='legal-privacy']",
            "width": width,
            "height": 800 if width == 360 else 932,
        }
        for width in VIEWPORTS
    ],
    *[
        {
            "name": f"terms_ru_{width}",
            "path": "/web-profile?legal=terms",
            "lang": "ru",
            "marker": "[data-public-surface='legal-terms']",
            "width": width,
            "height": 800 if width == 360 else 932,
        }
        for width in VIEWPORTS
    ],
    *[
        {
            "name": f"safe_error_{status}_390",
            "path": f"/500?status={status}",
            "lang": "ru",
            "marker": f"[data-safe-error-status='{status}']",
            "width": 390,
            "height": 844,
            "expected_status": 500,
        }
        for status in ERROR_STATES
    ],
    {
        "name": "energy_header_360",
        "path": "/",
        "lang": "ru",
        "marker": ".efhc-energy-page",
        "width": 360,
        "height": 800,
    },
    {
        "name": "profile_trust_390",
        "path": "/web-profile",
        "lang": "ru",
        "marker": ".efhc-profile-page",
        "width": 390,
        "height": 844,
    },
    {
        "name": "withdraw_timeline_390",
        "path": "/withdraw",
        "lang": "ru",
        "marker": "[data-public-surface='withdraw']",
        "width": 390,
        "height": 844,
    },
    {
        "name": "browser_shop_presign_430",
        "path": "/browser-shop",
        "lang": "ru",
        "marker": "[data-public-surface='browser-shop']",
        "width": 430,
        "height": 932,
    },
]


def _load_query_document(
    page: Any,
    target: str,
    base_url: str,
) -> int:
    parsed = urlparse(target)
    document_url = (
        f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    )
    response = requests.get(document_url, timeout=20)
    query = {
        key: values[-1]
        for key, values in parse_qs(parsed.query).items()
        if values
    }
    html = response.text
    legal_value = query.get("legal")
    if legal_value in {"terms", "privacy"}:
        script = (
            "<script>window.__EFHC_LEGAL_PROOF_KIND__="
            + json.dumps(legal_value)
            + ";</script>"
        )
        html = html.replace("</head>", script + "</head>", 1)
    safe_error_status = query.get("status")
    if safe_error_status in {"401", "403", "413", "429", "500"}:
        script = (
            "<script>window.__EFHC_SAFE_ERROR_STATUS__="
            + safe_error_status
            + ";</script>"
        )
        html = html.replace("</head>", script + "</head>", 1)
    page.goto("about:blank", wait_until="load")
    page.set_content(
        _inject_base_href(html, base_url),
        wait_until="domcontentloaded",
        timeout=20_000,
    )
    return response.status_code


def _record(
    base_url: str,
    screenshot_dir: Path,
    case: dict[str, Any],
    *,
    hard_exit: bool = False,
) -> dict[str, Any]:
    console_errors: list[str] = []
    page_errors: list[str] = []
    screenshot = screenshot_dir / f"{case['name']}.png"
    set_content_mode = _managed_url_blocklist_active()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            **_launch_kwargs(_chromium_path())
        )
        try:
            context = browser.new_context(
                viewport={
                    "width": int(case["width"]),
                    "height": int(case["height"]),
                },
                service_workers="block",
            )
            context.route(
                "**/*",
                lambda route: _route_request(
                    route,
                    proxy_local=set_content_mode,
                ),
            )
            page = context.new_page()
            _install_public_fallback(
                page,
                str(case["lang"]),
                base_url,
            )
            page.on(
                "console",
                lambda message: console_errors.append(message.text)
                if message.type == "error"
                else None,
            )
            page.on(
                "pageerror",
                lambda error: page_errors.append(str(error)),
            )
            target = f"{base_url}{case['path']}"
            if set_content_mode:
                status = _load_query_document(
                    page,
                    target,
                    base_url,
                )
            else:
                response = page.goto(
                    target,
                    wait_until="domcontentloaded",
                    timeout=25_000,
                )
                status = response.status if response else 200
            page.wait_for_selector(
                str(case["marker"]),
                timeout=12_000,
            )
            page.wait_for_timeout(1_500)
            _capture_screenshot(page, screenshot)
            overflow = bool(
                page.evaluate(
                    "document.documentElement.scrollWidth > "
                    "window.innerWidth + 2"
                )
            )
            overlay = page.locator(
                "nextjs-portal, [data-nextjs-dialog-overlay]"
            ).count()
            filtered = [
                value
                for value in console_errors
                if "Failed to load resource" not in value
                and "Service Worker" not in value
            ]
            expected_status = int(
                case.get("expected_status", 200)
            )
            ok = (
                status == expected_status
                and not overflow
                and overlay == 0
                and not page_errors
                and not filtered
                and screenshot.stat().st_size > 8_000
            )
            result = {
                **case,
                "status": "OK" if ok else "FAILED",
                "http_status": status,
                "horizontal_overflow": overflow,
                "runtime_overlay": overlay > 0,
                "console_errors": filtered,
                "page_errors": page_errors,
                "screenshot": str(
                    screenshot.relative_to(ROOT)
                ),
                "screenshot_bytes": screenshot.stat().st_size,
            }
            if hard_exit:
                print(
                    json.dumps(result, ensure_ascii=False),
                    flush=True,
                )
                os._exit(0)
            return result
        finally:
            browser.close()


def _child_command(
    args: argparse.Namespace,
    index: int,
) -> list[str]:
    return [
        sys.executable,
        str(Path(__file__).resolve()),
        "--child-index",
        str(index),
        "--base-url",
        args.base_url,
        "--screenshots",
        args.screenshots,
    ]


def _run_child(
    command: list[str],
    timeout: int = 30,
) -> dict[str, Any]:
    with tempfile.TemporaryFile(
        mode="w+t",
        encoding="utf-8",
    ) as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            stdout=output,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            return {
                "status": "FAILED",
                "error": f"proof timed out after {timeout}s",
            }
        output.seek(0)
        text = output.read()
    lines = [line for line in text.splitlines() if line.strip()]
    if code != 0 or not lines:
        return {
            "status": "FAILED",
            "error": text[-1200:],
        }
    return json.loads(lines[-1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default="http://127.0.0.1:3000",
    )
    parser.add_argument(
        "--screenshots",
        default=str(
            ROOT
            / "reports/screenshots/observability_readiness_1568"
        ),
    )
    parser.add_argument(
        "--report",
        default=str(
            ROOT
            / "reports/generated/"
            "observability_visual_matrix_v171_44.json"
        ),
    )
    parser.add_argument("--child-index", type=int)
    args = parser.parse_args()
    screenshot_dir = Path(args.screenshots).resolve()
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    if args.child_index is not None:
        row = _record(
            args.base_url.rstrip("/"),
            screenshot_dir,
            CASES[args.child_index],
            hard_exit=True,
        )
        print(json.dumps(row, ensure_ascii=False))
        if row["status"] != "OK":
            raise SystemExit(1)
        return
    rows = []
    for index, case in enumerate(CASES):
        print(
            f"[observability-proof] {case['name']}",
            flush=True,
        )
        rows.append(_run_child(_child_command(args, index)))
    report = {
        "schema": "EFHC_OBSERVABILITY_VISUAL_PROOF_V1",
        "cycle": 1568,
        "archive_version": "v171.44",
        "status": (
            "PASSED"
            if all(row.get("status") == "OK" for row in rows)
            else "FAILED"
        ),
        "cases_total": len(rows),
        "cases_ok": sum(
            row.get("status") == "OK" for row in rows
        ),
        "required_states": {
            "viewports": list(VIEWPORTS),
            "safe_errors": list(ERROR_STATES),
            "redacted_logs": "admin companion proof",
            "diagnostics": "admin companion proof",
        },
        "execution": "one Chromium process per visual case",
        "cases": rows,
        "proof_boundary": {
            "frontend_visual": "VERIFIED_LOCALLY",
            "production_runtime": "NOT_VERIFIED",
            "github_ci": "NOT_VERIFIED",
        },
    }
    report_path = Path(args.report).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["status"] != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
