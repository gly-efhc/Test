from __future__ import annotations

import argparse
import base64
import json
import os
from contextlib import suppress
from pathlib import Path
from shutil import which
from typing import Any
from urllib.parse import urlparse

import requests

try:
    from playwright.sync_api import Page, Route, sync_playwright
except Exception as exc:  # pragma: no cover
    msg = f"Playwright is required for browser proof: {exc}"
    raise SystemExit(msg) from exc

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_REPORT = (
    ROOT / "reports/generated/generated" / "admin_panel_mvp_visual_v171_40.json"
)
DEFAULT_SCREENSHOT_DIR = ROOT / "reports/generated/screenshots/admin_panel_1564"

ADMIN_ROUTES = [
    "/admin",
    "/admin/users",
    "/admin/tasks",
    "/admin/ads",
    "/admin/panels",
    "/admin/referrals",
    "/admin/shop",
    "/admin/sale-packages",
    "/admin/withdrawals",
    "/admin/efhc-deposits",
    "/admin/diagnostics",
    "/admin/reports",
    "/admin/system",
    "/admin/bank",
    "/admin/hub",
    "/admin/logs",
    "/admin/templates",
]
CLICK_PROOF_HREFS: list[str] = [
    "/admin/users",
    "/admin/tasks",
    "/admin/ads",
    "/admin/panels",
    "/admin/referrals",
    "/admin/shop",
    "/admin/sale-packages",
    "/admin/withdrawals",
    "/admin/efhc-deposits",
    "/admin/diagnostics",
    "/admin/reports",
    "/admin/system",
]

ERROR_OVERLAY_MARKERS = (
    "Runtime TypeError",
    "Failed to fetch",
    "Unhandled Runtime Error",
    "Application error",
)


def _json_response(route: Route, body: Any) -> None:
    route.fulfill(
        status=200,
        content_type="application/json",
        body=json.dumps(body, ensure_ascii=False),
    )


def _metric(
    key: str,
    label: str,
    value: str,
    unit: str,
    data_kind: str,
) -> dict[str, str]:
    return {
        "key": key,
        "label": label,
        "value": value,
        "unit": unit,
        "source": "mock",
        "data_kind": data_kind,
    }


def _mock_observability_summary(route: Route) -> None:
    _json_response(
        route,
        {
            "ok": True,
            "data_kind": "derived",
            "generated_at": "2026-06-16T00:00:00Z",
            "source": "browser-proof-mock",
            "metrics": [
                _metric(
                    "efhc_transfer_events_total",
                    "Ledger events",
                    "4",
                    "events",
                    "raw",
                ),
                _metric(
                    "efhc_transfer_amount_total",
                    "Gross turnover",
                    "100.00000000",
                    "EFHC",
                    "derived",
                ),
                _metric(
                    "efhc_credit_amount_total",
                    "Credits",
                    "80.00000000",
                    "EFHC",
                    "derived",
                ),
                _metric(
                    "efhc_debit_amount_total",
                    "Debits",
                    "20.00000000",
                    "EFHC",
                    "derived",
                ),
            ],
        },
    )


def _mock_observability_timeseries(route: Route) -> None:
    _json_response(
        route,
        {
            "ok": True,
            "data_kind": "real_timeseries",
            "synthetic": False,
            "metric": "efhc_transfer_count",
            "bucket": "hour",
            "range_hours": 24,
            "unit": "events",
            "source": "browser-proof-mock",
            "points": [
                {
                    "ts": "2026-06-16T00:00:00Z",
                    "label": "00:00",
                    "value": "1",
                },
                {
                    "ts": "2026-06-16T01:00:00Z",
                    "label": "01:00",
                    "value": "3",
                },
            ],
            "empty_reason": None,
        },
    )


def _mock_sync_user(route: Route) -> None:
    _json_response(
        route,
        {
            "profile": {
                "global_id": "0000000001",
                "username": "admin_visual",
                "is_vip": False,
                "has_activ": True,
                "main_balance": "100.00000000",
                "bonus_balance": "0.00000000",
                "available_kwh": "100.00000000",
                "total_generated_kwh": "100.00000000",
                "gen_per_sec_base": "0.00000000",
                "gen_per_sec_vip": "0.00000000",
            },
            "panels": {
                "active_count": 1,
                "total_generated_by_panels": "0.00000000",
                "nearest_expire_at": None,
            },
            "exchange_preview": {
                "ok": True,
                "available_kwh": "100.00000000",
                "max_exchangeable_kwh": "100.00000000",
                "rate_kwh_to_efhc": "1.00000000",
            },
            "meta": {
                "server_now_iso": "2026-06-16T00:00:00Z",
                "gen_per_sec_effective": "0.00000000",
            },
        },
    )


def _mock_wallets(route: Route) -> None:
    _json_response(
        route,
        {
            "is_connected": True,
            "wallets": [
                {
                    "id": 1,
                    "wallet_address": "UQadminvisualproof",
                    "wallet_app": "browser-proof",
                    "is_primary": True,
                    "is_active": True,
                    "created_at": "2026-06-16T00:00:00Z",
                }
            ],
        },
    )


def _mock_admin_reports(route: Route) -> None:
    _json_response(
        route,
        {
            "ok": True,
            "ts": "2026-06-16T00:00:00Z",
            "counters": {
                "users": 3,
                "panels": 2,
                "withdrawals_pending": 1,
                "deposits_seen": 4,
            },
            "facts": {
                "users_total__main__efhc": "100.00000000",
                "users_total_bonus_efhc": "10.00000000",
                "users_total_generated_kwh": "100.00000000",
                "panels_total_active": "2",
            },
            "notes": "browser proof mock",
        },
    )


def _mock_admin_users(route: Route) -> None:
    _json_response(
        route,
        [
            {
                "global_id": "0000001001",
                "username": "visual_user",
                "is_active": True,
                "is_vip": False,
                "ton_wallet": "UQvisualwallet",
                "main_balance": "100.00000000",
                "bonus_balance": "5.00000000",
                "available_kwh": "100.00000000",
                "total_generated_kwh": "100.00000000",
                "last_seen_at": "2026-06-16T00:00:00Z",
            }
        ],
    )


def _mock_admin_withdrawals(route: Route) -> None:
    _json_response(
        route,
        {
            "items": [
                {
                    "id": 1,
                    "global_id": "0000001001",
                    "amount": "10.00000000",
                    "status": "PENDING",
                    "created_at": "2026-06-16T00:00:00Z",
                    "updated_at": "2026-06-16T00:00:00Z",
                }
            ],
            "next_cursor": None,
        },
    )


def _mock_admin_hub(route: Route, method: str) -> None:
    body: Any
    if method == "GET":
        body = [
            {
                "id": 1,
                "code": "energy",
                "title": "Energy",
                "subtitle": "Energy dashboard",
                "url": "/",
                "target_kind": "internal",
                "open_mode": "same_view",
                "sort_order": 10,
                "is_active": True,
                "icon_key": "energy",
            }
        ]
    else:
        body = {"ok": True}
    _json_response(route, body)


def _mock_sale_packages(route: Route, method: str) -> None:
    if method != "GET":
        _json_response(route, {"ok": True})
        return
    _json_response(
        route,
        {
            "items": [
                {
                    "id": 1,
                    "code": "starter",
                    "title": "Starter package",
                    "is_active": True,
                    "price_efhc": "10.00000000",
                    "sort_order": 10,
                }
            ],
            "next_cursor": None,
        },
    )


def _mock_admin_default(route: Route, method: str) -> None:
    if method == "GET":
        _json_response(
            route,
            {
                "ok": True,
                "items": [],
                "rows": [],
                "events": [],
                "next_cursor": None,
                "summary": {},
                "status": "mocked_for_browser_proof",
            },
        )
        return
    _json_response(
        route,
        {"ok": True, "status": "mocked_for_browser_proof"},
    )


def _mock_api(route: Route) -> None:
    parsed = urlparse(route.request.url)
    path = parsed.path
    method = route.request.method.upper()

    if path.endswith("/api/health") or path.endswith("/api/healthz"):
        _json_response(route, {"ok": True, "status": "ok"})
        return
    if "/api/admin/observability/summary" in path:
        _mock_observability_summary(route)
        return
    if "/api/admin/observability/timeseries" in path:
        _mock_observability_timeseries(route)
        return
    if "/api/admin/observability/events" in path:
        _json_response(route, {"ok": True, "items": []})
        return
    if "/api/sync/user/" in path:
        _mock_sync_user(route)
        return
    if "/api/wallets/me" in path:
        _mock_wallets(route)
        return
    if "/api/wallets/tonconnect/proof-payload" in path:
        _json_response(
            route,
            {
                "payload": "browser-proof-payload",
                "expires_at": "2026-06-16T00:05:00Z",
            },
        )
        return
    if "/api/skins/my" in path:
        _json_response(
            route,
            {"active_skin": "default", "owned_skins": []},
        )
        return
    if "/api/admin/reports/generated/overview" in path:
        _mock_admin_reports(route)
        return
    if "/api/admin/bank/balance" in path:
        _json_response(
            route,
            {
                "balance": "1000.00000000",
                "updated_at": "2026-06-16T00:00:00Z",
            },
        )
        return
    if "/api/admin/users/search" in path:
        _mock_admin_users(route)
        return
    if "/api/admin/withdrawals" in path:
        _mock_admin_withdrawals(route)
        return
    if "/api/admin/hub/links" in path:
        _mock_admin_hub(route, method)
        return
    if "/api/admin/ads/providers" in path:
        _json_response(
            route,
            [
                {
                    "code": "telegram",
                    "title": "Telegram Ads",
                    "is_active": True,
                },
                {
                    "code": "internal",
                    "title": "EFHC Ads",
                    "is_active": True,
                },
            ],
        )
        return
    if "/api/admin/panels" in path:
        _json_response(
            route,
            {
                "ok": True,
                "items": [
                    {
                        "id": 41,
                        "global_id": "0000001001",
                        "is_active": True,
                        "created_at": "2026-07-20T08:00:00Z",
                        "expires_at": "2026-08-20T08:00:00Z",
                        "archived_at": None,
                        "generated_kwh": "18.50000000",
                    }
                ],
            },
        )
        return
    if "/api/admin/referrals/summary" in path:
        _json_response(
            route,
            {
                "items": [
                    {
                        "inviter_global_id": "0000001001",
                        "active_count": 8,
                        "inactive_count": 3,
                        "total_bonus_efhc": "12.30000000",
                        "last_invited_at": "2026-07-20T08:00:00Z",
                    }
                ],
                "next_cursor": None,
            },
        )
        return
    if "/api/admin/tasks" in path and method == "GET":
        _json_response(
            route,
            {
                "items": [
                    {
                        "id": 1,
                        "title": "Подписаться на канал",
                        "reward_efhc": "0.10000000",
                        "is_active": True,
                        "task_type": "telegram_subscription",
                        "created_at": "2026-07-20T08:00:00Z",
                    }
                ],
                "next_cursor": None,
            },
        )
        return
    if "/api/admin/shop/items" in path and method == "GET":
        _json_response(
            route,
            [
                {
                    "id": 1,
                    "sku": "EFHC-100",
                    "title": "100 EFHCm",
                    "item_type": "package",
                    "price_ton": "1.00000000",
                    "price_usdt": "2.50000000",
                    "is_active": True,
                    "sort_order": 10,
                }
            ],
        )
        return
    if "/api/admin/shop/orders" in path and method == "GET":
        _json_response(
            route,
            {
                "items": [
                    {
                        "id": 91,
                        "global_id": "0000001001",
                        "status": "CONFIRMED",
                        "asset": "TON",
                        "amount": "1.00000000",
                        "created_at": "2026-07-20T08:00:00Z",
                    }
                ],
                "next_cursor": None,
            },
        )
        return
    if "/api/admin/efhc-deposits/runtime-summary" in path:
        _json_response(
            route,
            {
                "total_seen": 12,
                "total_credited": 11,
                "total_rejected": 1,
                "pending_count": 0,
                "last_seen_at": "2026-07-20T08:00:00Z",
                "items": [],
            },
        )
        return
    if "/api/admin/templates" in path and method == "GET":
        _json_response(
            route,
            [
                {
                    "key": "welcome",
                    "content": "Добро пожаловать в EFHC",
                    "description": "Приветствие",
                    "updated_at": "2026-07-20T08:00:00Z",
                }
            ],
        )
        return
    if "/api/admin/sale-packages" in path:
        _mock_sale_packages(route, method)
        return
    if "/api/admin/" in path or path.startswith("/api/admin"):
        _mock_admin_default(route, method)
        return
    if path.startswith("/api/"):
        _json_response(route, {"ok": True, "items": []})
        return
    route.continue_()


def _proxy_local_response(route: Route) -> None:
    request = route.request
    headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower()
        not in {
            "accept-encoding",
            "connection",
            "content-length",
            "host",
        }
    }
    try:
        response = requests.request(
            request.method,
            request.url,
            headers=headers,
            data=request.post_data_buffer,
            timeout=20,
            allow_redirects=True,
        )
    except requests.RequestException:
        route.abort(error_code="failed")
        return
    response_headers = {
        key: value
        for key, value in response.headers.items()
        if key.lower()
        not in {
            "content-encoding",
            "content-length",
            "connection",
            "transfer-encoding",
        }
    }
    route.fulfill(
        status=response.status_code,
        headers=response_headers,
        body=response.content,
    )


def _route_request(
    route: Route,
    *,
    proxy_local: bool = False,
) -> None:
    parsed = urlparse(route.request.url)
    host = parsed.hostname or ""
    allowed_hosts = {"localhost", "127.0.0.1", "::1"}
    if parsed.path.startswith("/api/"):
        _mock_api(route)
        return
    if host == "config.ton.org" and parsed.path == "/wallets-v2.json":
        _json_response(route, [])
        return
    if parsed.scheme in {"http", "https"} and host not in allowed_hosts:
        route.abort()
        return
    if proxy_local and host in allowed_hosts:
        _proxy_local_response(route)
        return
    route.continue_()


def _managed_url_blocklist_active() -> bool:
    policy_root = Path("/etc/chromium/policies/managed")
    if not policy_root.exists():
        return False
    for path in policy_root.glob("*.json"):
        with suppress(Exception):
            data = json.loads(path.read_text(encoding="utf-8"))
            if "*" in data.get("URLBlocklist", []):
                return True
    return False


def _inject_base_href(
    html: str,
    base_url: str,
    proof_path: str | None = None,
) -> str:
    base = f'<base href="{base_url.rstrip("/")}/">'
    proof = ""
    if proof_path:
        encoded = json.dumps(proof_path)
        proof = (
            "<script>window.__EFHC_ADMIN_PROOF_PATH__="
            f"{encoded};</script>"
        )
    if "<head>" in html:
        return html.replace("<head>", f"<head>{base}{proof}", 1)
    return f"{base}{proof}{html}"


def _load_server_document(
    page: Page,
    target: str,
    base_url: str,
    proof_path: str | None = None,
) -> int:
    response = requests.get(target, timeout=20)
    response.raise_for_status()
    page.goto("about:blank", wait_until="load")
    page.set_content(
        _inject_base_href(
            response.text,
            base_url,
            proof_path,
        ),
        wait_until="domcontentloaded",
        timeout=20_000,
    )
    return response.status_code


def _install_admin_fallback(
    page: Page,
    base_url: str,
) -> None:
    script = """
        try {
          window.localStorage.setItem('__efhc_probe__', '1');
          window.localStorage.removeItem('__efhc_probe__');
        } catch {
          const values = new Map();
          const storage = {
            getItem: (key) => values.has(String(key))
              ? values.get(String(key))
              : null,
            setItem: (key, value) => {
              values.set(String(key), String(value));
            },
            removeItem: (key) => values.delete(String(key)),
            clear: () => values.clear(),
            key: (index) => Array.from(values.keys())[index] || null,
            get length() { return values.size; }
          };
          Object.defineProperty(window, 'localStorage', {
            configurable: true,
            value: storage
          });
          Object.defineProperty(window, 'sessionStorage', {
            configurable: true,
            value: storage
          });
        }
        if (window.location.origin === 'null') {
          const NativeURL = window.URL;
          const proofBaseUrl = __PROOF_BASE_URL__;
          class ProofURL extends NativeURL {
            constructor(url, base) {
              const safeBase = !base || String(base) === 'null'
                ? proofBaseUrl
                : base;
              super(url, safeBase);
            }
          }
          if (NativeURL.createObjectURL) {
            ProofURL.createObjectURL = NativeURL.createObjectURL.bind(
              NativeURL
            );
          }
          if (NativeURL.revokeObjectURL) {
            ProofURL.revokeObjectURL = NativeURL.revokeObjectURL.bind(
              NativeURL
            );
          }
          window.URL = ProofURL;
          const replaceState = window.history.replaceState.bind(
            window.history
          );
          const pushState = window.history.pushState.bind(
            window.history
          );
          window.history.replaceState = (state, title) => {
            try { replaceState(state, title); } catch {
              return undefined;
            }
          };
          window.history.pushState = (state, title) => {
            try { pushState(state, title); } catch {
              return undefined;
            }
          };
        }
        if (window.location.pathname.startsWith('/admin')) {
          window.__EFHC_ADMIN_PROOF_PATH__ = window.location.pathname;
        }
        window.localStorage.setItem('onboarding_v1_seen', '1');
        window.localStorage.setItem('EFHC_ADMIN_ID', '1');
        window.localStorage.setItem(
          'EFHC_ADMIN_TOKEN',
          'browser-proof-token'
        );
        const settingsKey = 'EFHC_USER_SETTINGS_V2';
        window.localStorage.setItem(settingsKey, JSON.stringify({
          confirm_actions: false,
          confirm_purchase: false,
          confirm_withdraw: false,
          confirm_convert: false,
          confirm_watch_ad: false,
          haptics_enabled: false,
          sfx_enabled: false,
          toasts_enabled: false,
          hide_balances: false,
          theme_mode: 'dark',
          lang: 'ru'
        }));
        window.Telegram = window.Telegram || { WebApp: {} };
        window.Telegram.WebApp.initData = 'query_id=browser-proof';
        window.Telegram.WebApp.initDataUnsafe = {
          user: {
            id: 1,
            username: 'admin_visual',
            first_name: 'Admin'
          }
        };
        window.Telegram.WebApp.themeParams = {
          bg_color: '#05070a',
          text_color: '#f7fbff',
          hint_color: '#8aa0b8',
          secondary_bg_color: '#101827',
          button_color: '#35b8ff',
          button_text_color: '#001018'
        };
        window.Telegram.WebApp.colorScheme = 'dark';
        window.Telegram.WebApp.ready = () => undefined;
        window.Telegram.WebApp.expand = () => undefined;
        window.Telegram.WebApp.showConfirm = async () => true;
        window.Telegram.WebApp.showPopup = (opts, cb) => {
          if (cb) cb('ok');
        };
        window.Telegram.WebApp.openLink = (url) => {
          window.open(url, '_blank', 'noopener,noreferrer');
        };
        """
    script = script.replace(
        "__PROOF_BASE_URL__",
        json.dumps(base_url),
    )
    page.add_init_script(script)


def _chromium_path() -> str | None:
    return (
        os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
        or which("chromium")
        or which("chromium-browser")
        or which("google-chrome")
    )


def _capture_screenshot(page: Page, path: Path) -> None:
    with suppress(Exception):
        page.evaluate("window.stop && window.stop()")
    client = page.context.new_cdp_session(page)
    payload = client.send(
        "Page.captureScreenshot",
        {"format": "png", "fromSurface": True},
    )
    path.write_bytes(base64.b64decode(payload["data"]))


def _safe_slug(path: str) -> str:
    return path.strip("/").replace("/", "__") or "admin_root"


def _assert_no_error_overlay(body_text: str) -> None:
    for marker in ERROR_OVERLAY_MARKERS:
        msg = f"visible runtime error: {marker}"
        assert marker not in body_text, msg


def _new_page(
    browser: Any,
    base_url: str,
    *,
    proxy_local: bool = False,
):
    context = browser.new_context(
        viewport={"width": 390, "height": 844},
        device_scale_factor=1,
        service_workers="block",
    )
    context.route(
        "**/*",
        lambda route: _route_request(
            route,
            proxy_local=proxy_local,
        ),
    )
    page = context.new_page()
    page.set_default_timeout(8_000)
    page.set_default_navigation_timeout(20_000)
    _install_admin_fallback(page, base_url)
    return context, page


def _append_console_error(errors: list[str], msg: Any) -> None:
    if msg.type == "error":
        errors.append(msg.text)


VISUAL_PROOF_MIN_SETTLE_MS = 2_500
VISUAL_PROOF_READY_TIMEOUT_MS = 5_000


def _splash_visible(page: Page) -> bool:
    return bool(
        page.evaluate(
            """
            () => {
              const logos = Array.from(
                document.querySelectorAll('.efhc-splash-breathe')
              );
              return logos.some((logo) => {
                const shell = logo.closest('[aria-hidden]');
                if (!shell) return false;
                const style = window.getComputedStyle(shell);
                const rect = shell.getBoundingClientRect();
                const opacity = Number.parseFloat(style.opacity || '1');
                return (
                  shell.getAttribute('aria-hidden') !== 'true' &&
                  style.display !== 'none' &&
                  style.visibility !== 'hidden' &&
                  opacity > 0.01 &&
                  rect.width > 0 &&
                  rect.height > 0
                );
              });
            }
            """
        )
    )


def _wait_for_shell_visual_ready(page: Page) -> None:
    # The app keeps SplashScreen mounted until shell boot is ready
    # (SHELL_BOOT_TIMEOUT_MS=1800) and then fades/unmounts it.
    # Visual proof must satisfy both rules:
    # 1) wait for real readiness/splash-hidden state;
    # 2) never capture earlier than VISUAL_PROOF_MIN_SETTLE_MS.
    # The fixed minimum prevents proof screenshots from racing the shell
    # on slow React hydration / Telegram WebView / sandbox runs.
    started_ms = page.evaluate("() => performance.now()")
    with suppress(Exception):
        page.wait_for_function(
            """
            () => (
              document.documentElement.dataset.efhcShell === 'ready'
            )
            """,
            timeout=VISUAL_PROOF_READY_TIMEOUT_MS,
        )
    with suppress(Exception):
        page.wait_for_function(
            """
            () => {
              const logos = Array.from(
                document.querySelectorAll('.efhc-splash-breathe')
              );
              return logos.every((logo) => {
                const shell = logo.closest('[aria-hidden]');
                if (!shell) return true;
                const style = window.getComputedStyle(shell);
                const rect = shell.getBoundingClientRect();
                const opacity = Number.parseFloat(style.opacity || '1');
                return (
                  shell.getAttribute('aria-hidden') === 'true' ||
                  style.display === 'none' ||
                  style.visibility === 'hidden' ||
                  opacity <= 0.01 ||
                  rect.width <= 0 ||
                  rect.height <= 0
                );
              });
            }
            """,
            timeout=VISUAL_PROOF_READY_TIMEOUT_MS,
        )
    with suppress(Exception):
        elapsed_ms = float(
            page.evaluate(
                "(started) => performance.now() - started",
                started_ms,
            )
        )
        remaining_ms = max(
            0,
            VISUAL_PROOF_MIN_SETTLE_MS - int(elapsed_ms),
        )
        if remaining_ms > 0:
            page.wait_for_timeout(remaining_ms)


def _route_record(route_path: str, shot: Path) -> dict[str, Any]:
    return {
        "route": route_path,
        "status": "UNKNOWN",
        "screenshot": str(shot.relative_to(ROOT)),
    }


def _visit_route(
    page: Page,
    base_url: str,
    route_path: str,
    shot: Path,
    *,
    set_content_mode: bool = False,
) -> dict[str, Any]:
    target = f"{base_url}{route_path}"
    record = _route_record(route_path, shot)
    try:
        response = None
        http_status = (
            _load_server_document(
                page,
                target,
                base_url,
                route_path,
            )
            if set_content_mode
            else None
        )
        if not set_content_mode:
            response = page.goto(target, wait_until="domcontentloaded")
            http_status = response.status if response else None
        _wait_for_shell_visual_ready(page)
        splash_visible = _splash_visible(page)
        body_text = (page.locator("body").inner_text() or "").strip()
        assert body_text, f"blank body for {route_path}"
        _assert_no_error_overlay(body_text)
        horizontal_overflow = bool(
            page.evaluate(
                "document.documentElement.scrollWidth > "
                "window.innerWidth"
            )
        )
        assert not horizontal_overflow, (
            f"horizontal overflow for {route_path}"
        )
        shell_count = page.locator(".efhc-admin-shell").count()
        assert shell_count >= 1, f"admin shell missing for {route_path}"
        msg = f"splash overlay still visible for {route_path}"
        assert not splash_visible, msg
        _capture_screenshot(page, shot)
        assert shot.exists() and shot.stat().st_size > 0
        record.update(
            {
                "status": "OK",
                "http_status": http_status,
                "body_chars": len(body_text),
                "buttons": page.locator("button").count(),
                "admin_links": page.locator(
                    'a[href^="/admin"]'
                ).count(),
                "screenshot_bytes": shot.stat().st_size,
                "splash_visible": splash_visible,
                "horizontal_overflow": horizontal_overflow,
            }
        )
    except Exception as exc:  # noqa: BLE001
        record.update({"status": "FAILED", "error": str(exc)[:500]})
    return record


def _click_record(
    base_url: str,
    page: Page,
    href: str,
    *,
    set_content_mode: bool = False,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "from": "/admin",
        "target_href": href,
        "status": "UNKNOWN",
        "click_mode": (
            "dom-link-then-server-html-proxy"
            if set_content_mode
            else "dom-click"
        ),
    }
    try:
        if set_content_mode:
            _load_server_document(
                page,
                f"{base_url}/admin",
                base_url,
                "/admin",
            )
        else:
            page.goto(
                f"{base_url}/admin",
                wait_until="domcontentloaded",
            )
        _wait_for_shell_visual_ready(page)
        locator = page.locator(f'a[href="{href}"]').first
        assert locator.count() == 1, f"admin link not found: {href}"
        if set_content_mode:
            page.evaluate(
                """
                (targetHref) => {
                  const link = document.querySelector(
                    `a[href="${targetHref}"]`
                  );
                  if (!link) return false;
                  link.addEventListener(
                    'click',
                    (event) => {
                      event.preventDefault();
                      event.stopImmediatePropagation();
                      window.__EFHC_ADMIN_CLICKED_HREF__ = targetHref;
                    },
                    { once: true, capture: true }
                  );
                  return true;
                }
                """,
                href,
            )
            locator.click(no_wait_after=True)
            clicked_href = page.evaluate(
                "window.__EFHC_ADMIN_CLICKED_HREF__ || null"
            )
            assert clicked_href == href, (
                f"admin DOM click not observed: {href}"
            )
            _load_server_document(
                page,
                f"{base_url}{href}",
                base_url,
                href,
            )
        else:
            locator.click()
            page.wait_for_load_state("domcontentloaded")
        _wait_for_shell_visual_ready(page)
        if not set_content_mode:
            assert page.url.startswith(f"{base_url}{href}")
        assert page.locator(".efhc-admin-shell").count() >= 1
        msg = f"splash overlay still visible after click: {href}"
        assert not _splash_visible(page), msg
        body_text = (page.locator("body").inner_text() or "").strip()
        assert body_text
        _assert_no_error_overlay(body_text)
        record["status"] = "OK"
        record["final_url"] = (
            f"{base_url}{href}" if set_content_mode else page.url
        )
    except Exception as exc:  # noqa: BLE001
        record.update({"status": "FAILED", "error": str(exc)[:500]})
    return record


def _click_record_loaded_root(
    page: Page,
    href: str,
) -> dict[str, Any]:
    record: dict[str, Any] = {
        "from": "/admin",
        "target_href": href,
        "status": "UNKNOWN",
        "click_mode": "dom-click-navigation-policy-intercepted",
        "target_route_visual": "verified_separately",
    }
    try:
        locator = page.locator(f'a[href="{href}"]').first
        assert locator.count() == 1, f"admin link not found: {href}"
        installed = page.evaluate(
            """
            (targetHref) => {
              const link = document.querySelector(
                `a[href="${targetHref}"]`
              );
              if (!link) return false;
              link.addEventListener(
                'click',
                (event) => {
                  event.preventDefault();
                  event.stopImmediatePropagation();
                  window.__EFHC_ADMIN_CLICKED_HREF__ = targetHref;
                },
                { once: true, capture: true }
              );
              return true;
            }
            """,
            href,
        )
        assert installed is True
        page.evaluate("window.__EFHC_ADMIN_CLICKED_HREF__ = null")
        locator.click(no_wait_after=True)
        clicked_href = page.evaluate(
            "window.__EFHC_ADMIN_CLICKED_HREF__ || null"
        )
        assert clicked_href == href, (
            f"admin DOM click not observed: {href}"
        )
        record.update(
            {
                "status": "OK",
                "clicked_href": clicked_href,
                "final_url": f"proof-route:{href}",
            }
        )
    except Exception as exc:  # noqa: BLE001
        record.update({"status": "FAILED", "error": str(exc)[:500]})
    return record


def _launch_kwargs(executable: str | None) -> dict[str, Any]:
    kwargs: dict[str, Any] = {"headless": True}
    if executable:
        kwargs["executable_path"] = executable
        kwargs["args"] = ["--no-sandbox", "--disable-dev-shm-usage"]
    return kwargs


def run(
    base_url: str,
    screenshot_dir: Path,
    report_path: Path,
) -> dict[str, Any]:
    screenshot_dir = screenshot_dir.resolve()
    report_path = report_path.resolve()
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    base_url = base_url.rstrip("/")
    routes: list[dict[str, Any]] = []
    clicks: list[dict[str, Any]] = []
    console_errors: list[str] = []
    page_errors: list[str] = []
    executable = _chromium_path()
    set_content_mode = _managed_url_blocklist_active()

    with sync_playwright() as p:
        kwargs = _launch_kwargs(executable)
        browser = p.chromium.launch(**kwargs)
        try:
            if set_content_mode:
                context, page = _new_page(
                    browser,
                    base_url,
                    proxy_local=True,
                )
                page.on(
                    "console",
                    lambda msg: _append_console_error(
                        console_errors,
                        msg,
                    ),
                )
                page.on(
                    "pageerror",
                    lambda exc: page_errors.append(str(exc)),
                )
                try:
                    for route_path in ADMIN_ROUTES:
                        print(
                            f"[browser-proof] route {route_path}",
                            flush=True,
                        )
                        shot = (
                            screenshot_dir
                            / f"{_safe_slug(route_path)}.png"
                        )
                        routes.append(
                            _visit_route(
                                page,
                                base_url,
                                route_path,
                                shot,
                                set_content_mode=True,
                            )
                        )
                finally:
                    context.close()

                context, page = _new_page(
                    browser,
                    base_url,
                    proxy_local=True,
                )
                page.on(
                    "console",
                    lambda msg: _append_console_error(
                        console_errors,
                        msg,
                    ),
                )
                page.on(
                    "pageerror",
                    lambda exc: page_errors.append(str(exc)),
                )
                try:
                    _load_server_document(
                        page,
                        f"{base_url}/admin",
                        base_url,
                        "/admin",
                    )
                    _wait_for_shell_visual_ready(page)
                    for href in CLICK_PROOF_HREFS:
                        print(
                            f"[browser-proof] click {href}",
                            flush=True,
                        )
                        clicks.append(
                            _click_record_loaded_root(page, href)
                        )
                finally:
                    context.close()
            else:
                for route_path in ADMIN_ROUTES:
                    print(
                        f"[browser-proof] route {route_path}",
                        flush=True,
                    )
                    context, page = _new_page(
                        browser,
                        base_url,
                        proxy_local=False,
                    )
                    page.on(
                        "console",
                        lambda msg: _append_console_error(
                            console_errors,
                            msg,
                        ),
                    )
                    page.on(
                        "pageerror",
                        lambda exc: page_errors.append(str(exc)),
                    )
                    shot = (
                        screenshot_dir / f"{_safe_slug(route_path)}.png"
                    )
                    try:
                        routes.append(
                            _visit_route(
                                page,
                                base_url,
                                route_path,
                                shot,
                                set_content_mode=False,
                            )
                        )
                    finally:
                        context.close()
                for href in CLICK_PROOF_HREFS:
                    print(
                        f"[browser-proof] click {href}",
                        flush=True,
                    )
                    context, page = _new_page(
                        browser,
                        base_url,
                        proxy_local=False,
                    )
                    try:
                        clicks.append(
                            _click_record(
                                base_url,
                                page,
                                href,
                                set_content_mode=False,
                            )
                        )
                    finally:
                        context.close()
        finally:
            browser.close()

    filtered = [
        item
        for item in console_errors
        if "Service Worker registration blocked" not in item
        and "Failed to load resource: net::ERR_FAILED" not in item
    ]
    status = "PASSED"
    if not all(r["status"] == "OK" for r in routes):
        status = "FAILED"
    if not all(c["status"] == "OK" for c in clicks):
        status = "FAILED"
    if filtered or page_errors:
        status = "FAILED"

    report: dict[str, Any] = {
        "schema": "EFHC_BROWSER_ADMIN_VISUAL_RUNTIME_GUARD_V2",
        "cycle": 1564,
        "archive_version": "v171.40",
        "status": status,
        "scope": "admin_panel_mvp_all_routes_visual_proof",
        "base_url": base_url,
        "browser": "chromium",
        "chromium_executable": executable,
        "navigation_mode": (
            "server-html-proxy"
            if set_content_mode
            else "direct-navigation"
        ),
        "routes_total": len(routes),
        "routes_ok": sum(1 for r in routes if r["status"] == "OK"),
        "clicks_total": len(clicks),
        "clicks_ok": sum(1 for c in clicks if c["status"] == "OK"),
        "screenshots_dir": str(screenshot_dir.relative_to(ROOT)),
        "routes": routes,
        "clicks": clicks,
        "console_errors": filtered[:100],
        "page_errors": page_errors[:100],
        "proof_boundary": {
            "admin_core_browser_visual": "VERIFIED_LOCALLY",
            "runtime_error_guard": "ENFORCED",
            "admin_required_route_clicks": "VERIFIED_LOCALLY",
            "all_admin_routes_visual": "VERIFIED_LOCALLY",
            "live_telegram": "NOT_VERIFIED",
            "real_tonconnect": "NOT_VERIFIED",
            "github_ci": "NOT_VERIFIED",
            "release_ready": "NOT_CLAIMED",
        },
    }
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if status != "PASSED":
        raise SystemExit(
            json.dumps(report, ensure_ascii=False, indent=2)
        )
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default=os.environ.get(
            "EFHC_E2E_BASE_URL",
            "http://localhost:3000",
        ),
    )
    parser.add_argument(
        "--screenshots",
        default=str(DEFAULT_SCREENSHOT_DIR),
    )
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    args = parser.parse_args()
    report = run(
        args.base_url,
        Path(args.screenshots),
        Path(args.report),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "routes_ok": report["routes_ok"],
                "routes_total": report["routes_total"],
                "clicks_ok": report["clicks_ok"],
                "clicks_total": report["clicks_total"],
                "report": str(Path(args.report)),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
