from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from tests.frontend.e2e._helpers import (  # noqa: E402
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

ALL_LANGS = [
    "ru", "en", "uk", "de", "fr", "es", "it",
    "tr", "pl", "da", "hi", "id", "sw",
]
LANGS = (
    [os.environ["EFHC_LANG"]]
    if os.environ.get("EFHC_LANG")
    else ALL_LANGS
)
BASE_URL = "http://127.0.0.1:3015"


def settings_payload(lang: str) -> str:
    return json.dumps({
        "confirm_actions": False,
        "confirm_purchase": False,
        "confirm_withdraw": False,
        "confirm_convert": False,
        "confirm_watch_ad": False,
        "haptics_enabled": False,
        "sfx_enabled": False,
        "toasts_enabled": False,
        "hide_balances": False,
        "theme_mode": "dark",
        "lang": lang,
    })


def check_page(
    page,
    route: str,
    marker: str,
    lang: str,
) -> dict[str, object]:
    goto(page, route)
    page.wait_for_selector(marker, timeout=12_000)
    page.wait_for_function(
        "value => document.documentElement.lang === value",
        arg=lang,
        timeout=12_000,
    )
    page.wait_for_timeout(800)
    metrics = page.evaluate(
        """() => ({
          width: window.innerWidth,
          height: window.innerHeight,
          scrollWidth: document.documentElement.scrollWidth,
          lang: document.documentElement.lang,
          bodyChars: document.body.innerText.trim().length,
          splashVisible: Boolean(
            document.querySelector('[data-splash-visible="true"]')
          ),
          errorOverlay: Boolean(
            document.querySelector('nextjs-portal')
          )
        })"""
    )
    if metrics["scrollWidth"] > metrics["width"]:
        raise AssertionError((route, lang, metrics))
    if metrics["lang"] != lang:
        raise AssertionError((route, lang, metrics))
    if metrics["bodyChars"] <= 0:
        raise AssertionError((route, lang, metrics))
    if metrics["splashVisible"]:
        raise AssertionError((route, lang, metrics))
    if metrics["errorOverlay"]:
        raise AssertionError((route, lang, metrics))
    return metrics


def main() -> None:
    screenshots = (
        ROOT
        / "reports/generated/screenshots/profile_wallet_history_faq_1559"
        / "languages"
    )
    screenshots.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, object]] = []
    executable = (
        shutil.which("chromium")
        or shutil.which("chromium-browser")
    )
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=executable,
            args=["--no-sandbox"] if executable else None,
        )
        try:
            for lang in LANGS:
                page = browser.new_page(
                    viewport={"width": 390, "height": 844},
                )
                page.set_default_timeout(12_000)
                try:
                    install_public_fallback(page)
                    payload = json.dumps(settings_payload(lang))
                    page.add_init_script(
                        f"""
                        (() => {{
                          const value = {payload};
                          localStorage.setItem('efhc_settings', value);
                          localStorage.setItem(
                            'EFHC_USER_SETTINGS_V2',
                            value
                          );
                        }})();
                        """
                    )
                    install_common_public_api_mocks(page)
                    profile_metrics = check_page(
                        page,
                        "/web-profile",
                        "[data-public-surface='web-profile']",
                        lang,
                    )
                    profile_image = (
                        screenshots / f"web-profile__{lang}.png"
                    )
                    page.screenshot(
                        path=str(profile_image),
                        full_page=True,
                    )
                    results.append({
                        "route": "/web-profile",
                        "lang": lang,
                        "status": "PASSED",
                        "screenshot": str(
                            profile_image.relative_to(ROOT)
                        ),
                        "metrics": profile_metrics,
                    })
                    faq_metrics = check_page(
                        page,
                        "/faq",
                        "[data-public-surface='faq']",
                        lang,
                    )
                    faq_image = screenshots / f"faq__{lang}.png"
                    page.screenshot(path=str(faq_image), full_page=True)
                    results.append({
                        "route": "/faq",
                        "lang": lang,
                        "status": "PASSED",
                        "screenshot": str(faq_image.relative_to(ROOT)),
                        "metrics": faq_metrics,
                    })
                finally:
                    page.close()
        finally:
            browser.close()
    report = {
        "cycle": 1559,
        "archive_version": "v171_34",
        "status": "PASSED",
        "checks_total": len(results),
        "checks_ok": sum(
            item["status"] == "PASSED"
            for item in results
        ),
        "languages": LANGS,
        "results": results,
    }
    suffix = os.environ.get("EFHC_LANG") or "all"
    target = ROOT / (
        "reports/generated/"
        f"profile_faq_language_{suffix}_v171_34.json"
    )
    target.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "checks_total": report["checks_total"],
        "checks_ok": report["checks_ok"],
    }))


if __name__ == "__main__":
    main()
