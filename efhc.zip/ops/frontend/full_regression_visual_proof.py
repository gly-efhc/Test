#!/usr/bin/env python3
"""Capture current full-regression and dynamic-cache visual proof."""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import tempfile
from contextlib import suppress
from pathlib import Path
from shutil import which
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tests.frontend.e2e._helpers import (  # noqa: E402
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)

CASES = (
    "energy",
    "cache_progress",
    "storage_persistence",
    "faq_worker",
    "faq_offline_readonly",
    "financial_update",
    "tablet_faq",
)


def chromium_path() -> str:
    explicit = os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
    value = explicit or which("chromium") or which("google-chrome")
    if not value:
        raise RuntimeError("Chromium executable is unavailable")
    return value


def shot(page: Any, directory: Path, name: str) -> str:
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / name
    page.screenshot(path=str(target), full_page=True)
    if not target.exists() or target.stat().st_size <= 0:
        raise AssertionError(f"screenshot missing: {name}")
    return str(target.relative_to(ROOT))


def page_state(page: Any) -> dict[str, Any]:
    overflow = bool(
        page.evaluate(
            "document.documentElement.scrollWidth > window.innerWidth"
        )
    )
    return {
        "horizontal_overflow": overflow,
        "runtime_overlay": page.locator("nextjs-portal").count() > 0,
    }


def run_case(
    case: str,
    base_url: str,
    directory: Path,
) -> dict[str, Any]:
    from playwright.sync_api import sync_playwright

    if case == "tablet_faq":
        viewport = {"width": 768, "height": 1024}
    else:
        viewport = {"width": 390, "height": 844}
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(
        executable_path=chromium_path(),
        args=["--no-sandbox"],
    )
    context = browser.new_context(viewport=viewport)
    page = context.new_page()
    errors: list[str] = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.set_default_timeout(20_000)
    install_public_fallback(page, tg_id=1001)
    install_common_public_api_mocks(page)
    if case == "terms_offline_readonly":
        page.add_init_script(
            "window.__EFHC_LEGAL_PROOF_KIND__='terms';"
        )
    if case == "storage_persistence":
        page.add_init_script(
            """
            Object.defineProperty(navigator, 'storage', {
              configurable: true,
              value: {
                estimate: async () => ({
                  quota: 900 * 1024 * 1024,
                  usage: 12 * 1024 * 1024
                }),
                persisted: async () => false,
                persist: async () => true
              }
            });
            """
        )
    if case in {
        "faq_offline_readonly",
        }:
        page.add_init_script(
            """
            Object.defineProperty(navigator, 'onLine', {
              configurable: true,
              value: false
            });
            """
        )
    if case == "energy":
        goto(page, "/")
        page.wait_for_selector(
            '[data-energy-mobile-stage="true"]'
        )
        name = "energy_final_390.png"
    elif case == "cache_progress":
        goto(page, "/")
        page.wait_for_selector(
            '[data-energy-mobile-stage="true"]'
        )
        page.evaluate(
            """
            window.dispatchEvent(new CustomEvent(
              'efhc-runtime-progress',
              { detail: { channel: 'cache', value: 74 } }
            ));
            """
        )
        page.wait_for_selector(".efhc-pwa-cache-progress")
        name = "dynamic_cache_progress_74.png"
    elif case == "storage_persistence":
        goto(page, "/")
        page.wait_for_selector(".efhc-pwa-storage-card")
        name = "storage_persistence_prompt.png"
    elif case == "faq_worker":
        goto(page, "/faq")
        page.wait_for_selector(".efhc-faq-search-index-status")
        page.locator('input[type="search"]').fill("panel")
        page.wait_for_timeout(500)
        name = "faq_worker_search.png"
    elif case == "faq_offline_readonly":
        goto(page, "/faq")
        page.evaluate(
            "window.dispatchEvent(new Event('offline'))"
        )
        page.wait_for_selector(
            '[data-pwa-offline-mode="public-read-only"]'
        )
        name = "faq_offline_readonly.png"
    elif case == "terms_offline_readonly":
        goto(page, "/web-profile?legal=terms")
        page.evaluate(
            "window.dispatchEvent(new Event('offline'))"
        )
        page.wait_for_selector(
            '[data-pwa-offline-mode="public-read-only"]'
        )
        name = "terms_offline_readonly.png"
    elif case == "financial_update":
        goto(page, "/withdraw")
        page.wait_for_selector(
            '[data-public-surface="withdraw"]'
        )
        page.evaluate(
            "window.dispatchEvent("
            "new Event('efhc-pwa-update-proof'))"
        )
        page.wait_for_selector(".efhc-pwa-update-card")
        name = "financial_update_deferred.png"
    else:
        goto(page, "/faq")
        page.wait_for_selector(".efhc-faq-search-index-status")
        name = "faq_tablet_768.png"
    result = {
        "case": case,
        "route": page.url,
        "screenshot": shot(page, directory, name),
        "page_errors": errors,
        **page_state(page),
    }
    result["status"] = (
        "OK"
        if not errors
        and not result["horizontal_overflow"]
        and not result["runtime_overlay"]
        else "FAILED"
    )
    return result


def child_command(args: argparse.Namespace, index: int) -> list[str]:
    return [
        sys.executable,
        str(Path(__file__).resolve()),
        "--child-index",
        str(index),
        "--base-url",
        args.base_url,
        "--screenshots",
        args.screenshots,
    ]


def run_child(command: list[str]) -> dict[str, Any]:
    with tempfile.TemporaryFile(mode="w+t", encoding="utf-8") as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            stdout=output,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        try:
            return_code = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=5)
            return {"status": "FAILED", "error": "child timeout"}
        output.seek(0)
        text = output.read()
    lines = [line for line in text.splitlines() if line.strip()]
    if return_code != 0 or not lines:
        return {"status": "FAILED", "error": text[-1200:]}
    return json.loads(lines[-1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:3000")
    parser.add_argument(
        "--screenshots",
        default=str(
            ROOT / "reports/screenshots/full_regression_visual/current"
        ),
    )
    parser.add_argument(
        "--report",
        default=str(
            ROOT
            / "reports/generated"
            / "full_regression_visual_v171_47.json"
        ),
    )
    parser.add_argument("--child-index", type=int)
    args = parser.parse_args()
    directory = Path(args.screenshots).resolve()
    if args.child_index is not None:
        result = run_case(
            CASES[args.child_index],
            args.base_url,
            directory,
        )
        print(json.dumps(result, ensure_ascii=False), flush=True)
        os._exit(0)
    rows = []
    for index, case in enumerate(CASES):
        print(f"[full-regression-visual] {case}", flush=True)
        rows.append(run_child(child_command(args, index)))
    report = {
        "schema": "EFHC_FULL_REGRESSION_VISUAL_V1",
        "cycle": 1571,
        "archive_version": "v171.47",
        "status": (
            "PASSED"
            if all(row.get("status") == "OK" for row in rows)
            else "FAILED"
        ),
        "cases_total": len(rows),
        "cases_ok": sum(row.get("status") == "OK" for row in rows),
        "cases": rows,
    }
    target = Path(args.report).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["status"] != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
