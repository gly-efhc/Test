#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import requests
from admin_visual_button_click_proof import (
    ROOT,
    _capture_screenshot,
    _chromium_path,
    _inject_base_href,
    _launch_kwargs,
    _managed_url_blocklist_active,
    _route_request,
)
from playwright.sync_api import sync_playwright
from public_visual_runtime_proof import _install_public_fallback


def _load_query_document(
    page: Any,
    target: str,
    base_url: str,
) -> int:
    parsed = urlparse(target)
    document_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    response = requests.get(document_url, timeout=20)
    response.raise_for_status()
    query = {
        key: values[-1]
        for key, values in parse_qs(parsed.query).items()
        if values
    }
    html = response.text
    legal_value = query.get("legal")
    if legal_value in {"terms", "privacy"}:
        proof_script = (
            "<script>window.__EFHC_LEGAL_PROOF_KIND__="
            + json.dumps(legal_value, ensure_ascii=False)
            + ";</script>"
        )
        html = html.replace("</head>", proof_script + "</head>", 1)
    page.goto("about:blank", wait_until="load")
    page.set_content(
        _inject_base_href(html, base_url),
        wait_until="domcontentloaded",
        timeout=20_000,
    )
    return response.status_code


CASES = [
    {
        "name": "privacy_ru_390",
        "path": "/web-profile?legal=privacy",
        "lang": "ru",
        "marker": "[data-public-surface='legal-privacy']",
        "width": 390,
        "height": 844,
    },
    {
        "name": "terms_ru_390",
        "path": "/web-profile?legal=terms",
        "lang": "ru",
        "marker": "[data-public-surface='legal-terms']",
        "width": 390,
        "height": 844,
    },
    {
        "name": "privacy_de_430",
        "path": "/web-profile?legal=privacy",
        "lang": "de",
        "marker": "[data-public-surface='legal-privacy']",
        "width": 430,
        "height": 932,
    },
    {
        "name": "terms_hi_390",
        "path": "/web-profile?legal=terms",
        "lang": "hi",
        "marker": "[data-public-surface='legal-terms']",
        "width": 390,
        "height": 844,
    },
    {
        "name": "profile_ru_390",
        "path": "/web-profile",
        "lang": "ru",
        "marker": ".efhc-profile-page",
        "width": 390,
        "height": 844,
    },
    {
        "name": "energy_ru_390",
        "path": "/",
        "lang": "ru",
        "marker": ".efhc-energy-page",
        "width": 390,
        "height": 844,
    },
]


def _record(
    base_url: str,
    screenshot_dir: Path,
    case: dict[str, Any],
) -> dict[str, Any]:
    errors: list[str] = []
    page_errors: list[str] = []
    screenshot = screenshot_dir / f"{case['name']}.png"
    set_content_mode = _managed_url_blocklist_active()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            **_launch_kwargs(_chromium_path())
        )
        try:
            context = browser.new_context(
                viewport={
                    "width": int(case["width"]),
                    "height": int(case["height"]),
                },
                service_workers="block",
            )
            context.route(
                "**/*",
                lambda route: _route_request(
                    route,
                    proxy_local=set_content_mode,
                ),
            )
            page = context.new_page()
            _install_public_fallback(
                page,
                str(case["lang"]),
                base_url,
            )
            page.on(
                "console",
                lambda msg: errors.append(msg.text)
                if msg.type == "error"
                else None,
            )
            page.on(
                "pageerror",
                lambda exc: page_errors.append(str(exc)),
            )
            target = f"{base_url}{case['path']}"
            if set_content_mode:
                http_status = _load_query_document(
                    page,
                    target,
                    base_url,
                )
                response = None
            else:
                response = page.goto(
                    target,
                    wait_until="domcontentloaded",
                    timeout=25_000,
                )
                http_status = response.status if response else 200
            page.wait_for_selector(str(case["marker"]), timeout=12_000)
            page.wait_for_timeout(2_000)
            _capture_screenshot(page, screenshot)
            overflow = bool(
                page.evaluate(
                    "document.documentElement.scrollWidth > "
                    "window.innerWidth + 2"
                )
            )
            overlay = page.locator(
                "nextjs-portal, [data-nextjs-dialog-overlay]"
            ).count()
            status = http_status
            body = page.locator("body").inner_text()
            filtered = [
                item
                for item in errors
                if "Failed to load resource" not in item
                and "Service Worker" not in item
            ]
            ok = (
                status == 200
                and not overflow
                and overlay == 0
                and not page_errors
                and not filtered
                and screenshot.stat().st_size > 10_000
            )
            return {
                **case,
                "status": "OK" if ok else "FAILED",
                "http_status": status,
                "horizontal_overflow": overflow,
                "runtime_overlay": overlay > 0,
                "console_errors": filtered,
                "page_errors": page_errors,
                "body_chars": len(body),
                "screenshot": str(screenshot.relative_to(ROOT)),
                "screenshot_bytes": screenshot.stat().st_size,
            }
        finally:
            browser.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:3000")
    parser.add_argument(
        "--screenshots",
        default=str(
            ROOT / "reports/generated/screenshots/security_privacy_legal_1567"
        ),
    )
    parser.add_argument(
        "--report",
        default=str(
            ROOT
            / "reports/generated/security_visual_matrix_v171_43.json"
        ),
    )
    args = parser.parse_args()
    screenshot_dir = Path(args.screenshots).resolve()
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    rows = [
        _record(args.base_url.rstrip("/"), screenshot_dir, case)
        for case in CASES
    ]
    report = {
        "schema": "EFHC_SECURITY_LEGAL_VISUAL_PROOF_V1",
        "cycle": 1567,
        "archive_version": "v171.43",
        "status": (
            "PASSED"
            if all(row["status"] == "OK" for row in rows)
            else "FAILED"
        ),
        "cases_total": len(rows),
        "cases_ok": sum(row["status"] == "OK" for row in rows),
        "screenshots_dir": str(screenshot_dir.relative_to(ROOT)),
        "cases": rows,
        "proof_boundary": {
            "frontend_visual": "VERIFIED_LOCALLY",
            "legal_copy_rendering": "VERIFIED_LOCALLY",
            "production_headers": "SOURCE_AND_LOCAL_RESPONSE_ONLY",
            "live_telegram": "NOT_VERIFIED",
            "github_ci": "NOT_VERIFIED",
        },
    }
    report_path = Path(args.report).resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["status"] != "PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
