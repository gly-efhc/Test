#!/usr/bin/env python3
"""Strict route-backed visual audit for EFHC v171.61.

The script captures only the real running Next.js application. It never
uses manual DOM injection, manual HTML, or component imitation. Missing
build, server, route, or browser capabilities produce a failure instead
of synthetic proof.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from shutil import which
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in os.sys.path:
    os.sys.path.insert(0, str(ROOT))

from playwright.sync_api import Page, sync_playwright  # noqa: E402
from tests.frontend.e2e._helpers import (  # noqa: E402
    install_common_public_api_mocks,
    install_public_fallback,
)


def case(
    name: str,
    path: str,
    marker: str,
    viewport: tuple[int, int],
    *,
    open_settings: bool = False,
) -> dict[str, Any]:
    return {
        "name": name,
        "path": path,
        "marker": marker,
        "viewport": viewport,
        "open_settings": open_settings,
    }


CASES: tuple[dict[str, Any], ...] = (
    case(
        "header_balance_360x800_ru",
        "/",
        ".efhc-game-header",
        (360, 800),
    ),
    case(
        "header_balance_390x844_ru",
        "/",
        ".efhc-game-header",
        (390, 844),
    ),
    case(
        "header_balance_430x932_ru",
        "/",
        ".efhc-game-header",
        (430, 932),
    ),
    case(
        "header_balance_768x1024_ru",
        "/",
        ".efhc-game-header",
        (768, 1024),
    ),
    case(
        "energy_390x844_ru",
        "/",
        ".efhc-energy-page",
        (390, 844),
    ),
    case(
        "panels_390x844_ru",
        "/panels",
        ".efhc-panels-shell",
        (390, 844),
    ),
    case(
        "referrals_390x844_ru",
        "/referrals",
        ".efhc-referrals-shell",
        (390, 844),
    ),
    case(
        "tasks_390x844_ru",
        "/tasks",
        ".efhc-tasks-shell",
        (390, 844),
    ),
    case(
        "exchange_390x844_ru",
        "/exchange",
        ".efhc-exchange-shell",
        (390, 844),
    ),
    case(
        "history_390x844_ru",
        "/web-profile?section=history",
        ".efhc-profile-page",
        (390, 844),
    ),
    case(
        "faq_390x844_ru",
        "/faq",
        ".efhc-faq-shell",
        (390, 844),
    ),
    case(
        "profile_390x844_ru",
        "/web-profile",
        ".efhc-profile-page",
        (390, 844),
    ),
    case(
        "profile_settings_modal_430x932_ru",
        "/web-profile",
        ".efhc-profile-page",
        (430, 932),
        open_settings=True,
    ),
)

SOURCE_PATHS = (
    "frontend/src/components/GlobalHeader.tsx",
    "frontend/src/features/profile/WebProfilePage.tsx",
    "frontend/src/styles/globals.css",
    "frontend/package.json",
    "frontend/package-lock.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(
            lambda: stream.read(1024 * 1024),
            b"",
        ):
            digest.update(chunk)
    return digest.hexdigest()


def chromium_path() -> str:
    value = (
        os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
        or which("chromium")
        or which("google-chrome")
    )
    if not value:
        raise RuntimeError("Chromium executable is unavailable")
    return value


def empty_response(**extra: Any) -> dict[str, Any]:
    return {"items": [], **extra}


def install_extra_mocks(page: Page) -> None:
    page.route(
        "**/api/wallets/withdraw-history**",
        lambda route: route.fulfill(
            status=200,
            json=empty_response(next_cursor=None),
        ),
    )
    page.route(
        "**/api/panels/**",
        lambda route: route.fulfill(
            status=200,
            json=empty_response(active=[], archive=[]),
        ),
    )
    page.route(
        "**/api/tasks/**",
        lambda route: route.fulfill(
            status=200,
            json=empty_response(tasks=[]),
        ),
    )
    page.route(
        "**/api/referrals/**",
        lambda route: route.fulfill(
            status=200,
            json=empty_response(active=[], inactive=[]),
        ),
    )
    exchange = {
        "ok": True,
        "available_kwh": "100.00000000",
        "max_exchangeable_kwh": "100.00000000",
        "rate_kwh_to_efhc": "1.00000000",
    }
    page.route(
        "**/api/exchange/**",
        lambda route: route.fulfill(
            status=200,
            json=exchange,
        ),
    )


def collect_console_error(
    errors: list[str],
    message: Any,
) -> None:
    if message.type == "error":
        errors.append(message.text)


def capture_case(
    browser: Any,
    base_url: str,
    screenshots: Path,
    current: dict[str, Any],
) -> dict[str, Any]:
    width, height = current["viewport"]
    context = browser.new_context(
        viewport={"width": width, "height": height},
        device_scale_factor=1,
        service_workers="block",
    )
    page = context.new_page()
    page.set_default_timeout(15_000)
    page.set_default_navigation_timeout(30_000)
    console_errors: list[str] = []
    page_errors: list[str] = []
    page.on(
        "console",
        lambda message: collect_console_error(
            console_errors,
            message,
        ),
    )
    page.on(
        "pageerror",
        lambda error: page_errors.append(str(error)),
    )
    install_public_fallback(page, tg_id=1001)
    install_common_public_api_mocks(page)
    install_extra_mocks(page)
    target = base_url.rstrip("/") + current["path"]
    output = screenshots / f"{current['name']}.png"
    record: dict[str, Any] = {
        "name": current["name"],
        "path": current["path"],
        "target": target,
        "viewport": {"width": width, "height": height},
        "navigation_mode": "page.goto",
        "screenshot": str(output.relative_to(ROOT)),
    }
    try:
        response = page.goto(
            target,
            wait_until="domcontentloaded",
        )
        record["http_status"] = response.status if response else None
        page.wait_for_selector(
            current["marker"],
            state="visible",
        )
        try:
            ready_check = (
                "() => document.documentElement.dataset."
                "efhcShell === 'ready'"
            )
            page.wait_for_function(
                ready_check,
                timeout=5_000,
            )
        except Exception:
            pass
        if current.get("open_settings"):
            settings_entry = page.locator(
                '[data-profile-settings-entry="profile-modal"]'
            )
            settings_entry.click()
            page.wait_for_selector(
                '[role="dialog"][aria-modal="true"]',
                state="visible",
            )
        page.wait_for_timeout(700)
        output.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        page.screenshot(
            path=str(output),
            full_page=True,
        )
        marker_count = page.locator(current["marker"]).count()
        overlay_count = page.locator("nextjs-portal").count()
        overflow_check = (
            "document.documentElement.scrollWidth > "
            "window.innerWidth + 2"
        )
        overflow = bool(page.evaluate(overflow_check))
        dialog_count = page.locator(
            '[role="dialog"][aria-modal="true"]'
        ).count()
        screenshot_bytes = (
            output.stat().st_size
            if output.exists()
            else 0
        )
        record.update(
            {
                "root_marker_count": marker_count,
                "runtime_overlay_count": overlay_count,
                "horizontal_overflow": overflow,
                "page_errors": page_errors,
                "console_errors": console_errors,
                "settings_dialog_count": dialog_count,
                "screenshot_bytes": screenshot_bytes,
            }
        )
        settings_ok = (
            not current.get("open_settings")
            or dialog_count > 0
        )
        ok = (
            record.get("http_status") == 200
            and marker_count > 0
            and overlay_count == 0
            and not overflow
            and not page_errors
            and not console_errors
            and output.exists()
            and output.stat().st_size > 0
            and settings_ok
        )
        record["status"] = "OK" if ok else "FAILED"
    except Exception as exc:  # noqa: BLE001
        record.update(
            {
                "status": "FAILED",
                "error": str(exc)[:1000],
                "page_errors": page_errors,
                "console_errors": console_errors,
            }
        )
    finally:
        context.close()
    return record


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default="http://127.0.0.1:3000",
    )
    default_shots = ROOT / (
        "reports/screenshots/"
        "cycle_1573_v171_61_route_backed"
    )
    parser.add_argument(
        "--screenshots",
        default=str(default_shots),
    )
    default_report = ROOT / (
        "reports/generated/"
        "route_backed_visual_audit_v171_61.json"
    )
    parser.add_argument(
        "--report",
        default=str(default_report),
    )
    args = parser.parse_args()
    screenshots = Path(args.screenshots).resolve()
    report_path = Path(args.report).resolve()
    source_hashes = {
        rel: sha256(ROOT / rel)
        for rel in SOURCE_PATHS
        if (ROOT / rel).exists()
    }
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=chromium_path(),
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ],
        )
        rows = [
            capture_case(
                browser,
                args.base_url,
                screenshots,
                current,
            )
            for current in CASES
        ]
        browser.close()
    all_ok = all(row["status"] == "OK" for row in rows)
    report = {
        "schema": "EFHC_ROUTE_BACKED_VISUAL_AUDIT_V1",
        "archive_version": "v171.61",
        "cycle": 1573,
        "status": "PASSED" if all_ok else "FAILED",
        "proof_type": "REAL_NEXTJS_ROUTE_BACKED_PAGE_GOTO",
        "manual_html": False,
        "base_url": args.base_url,
        "source_hashes": source_hashes,
        "cases_total": len(rows),
        "cases_ok": sum(
            row["status"] == "OK"
            for row in rows
        ),
        "cases": rows,
    }
    report_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    rendered = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
    )
    report_path.write_text(
        rendered + "\n",
        encoding="utf-8",
    )
    print(rendered)
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
