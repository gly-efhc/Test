from __future__ import annotations

import argparse
import json
import os
from contextlib import suppress
from pathlib import Path
from typing import Any

from admin_visual_button_click_proof import (
    _chromium_path,
    _install_admin_fallback,
    _launch_kwargs,
    _route_request,
    _splash_visible,
    _wait_for_shell_visual_ready,
)
from playwright.sync_api import Page, sync_playwright
from public_visual_runtime_proof import _install_public_fallback

ROOT = Path(__file__).resolve().parents[2]
# Имена output-файлов сохранены ради неизменяемого CI workflow.
# Семантические версия и цикл читаются из release policy/manifest.
MANIFEST = (
    ROOT / "ops/frontend/all_pages_visual_manifest_v171_88.json"
)
DEFAULT_REPORT = (
    ROOT / "reports/generated/all_pages_visual_audit_v171_88.json"
)
DEFAULT_SHOTS = ROOT / "reports/generated/screenshots/all_pages_visual_1591"

SESSION_KEY = "efhc.auth.session.v1"
CROSS_PROVIDER_GLOBAL_ID = "0000001630"

UPDATE_POLICY = ROOT / "release_config/UPDATE_POLICY.json"


def _archive_version() -> str:
    data = json.loads(UPDATE_POLICY.read_text(encoding="utf-8"))
    return str(data["version"])


ERROR_MARKERS = (
    "Runtime TypeError",
    "Unhandled Runtime Error",
    "Application error",
    "[object Object]",
    "undefined is not",
)


def _slug(route: str) -> str:
    return route.strip("/").replace("/", "__") or "root"


def _console_error(errors: list[str], message: Any) -> None:
    if message.type == "error":
        errors.append(str(message.text))


def _filtered_console(
    errors: list[str],
    *,
    expected_status: int,
) -> list[str]:
    ignored = [
        "Service Worker registration blocked",
        "Failed to load resource: net::ERR_FAILED",
        "A tree hydrated but some attributes",
    ]
    if expected_status in {404, 500}:
        ignored.append(
            "Failed to load resource: the server responded with a "
            f"status of {expected_status}"
        )
    return [
        error
        for error in errors
        if not any(marker in error for marker in ignored)
    ]


def _horizontal_overflow(page: Page) -> bool:
    return bool(
        page.evaluate(
            "() => document.documentElement.scrollWidth > "
            "window.innerWidth + 2"
        )
    )


def _record(
    page: Page,
    *,
    base_url: str,
    item: dict[str, Any],
    viewport: dict[str, int | str],
    screenshot: Path,
    kind: str,
) -> dict[str, Any]:
    console_errors: list[str] = []
    page_errors: list[str] = []
    page.on(
        "console",
        lambda message: _console_error(console_errors, message),
    )
    page.on("pageerror", lambda error: page_errors.append(str(error)))
    route = item["route"]
    if kind == "admin":
        _install_admin_fallback(page, base_url)
    else:
        _install_public_fallback(page, "ru", base_url)
    response = page.goto(
        f"{base_url}{route}",
        wait_until="domcontentloaded",
    )
    _wait_for_shell_visual_ready(page)
    body = (page.locator("body").inner_text() or "").strip()
    marker_count = page.locator(item["marker"]).count()
    expected_status = int(item.get("expected_status", 200))
    filtered_console = _filtered_console(
        console_errors,
        expected_status=expected_status,
    )
    visible_errors = [
        marker for marker in ERROR_MARKERS if marker in body
    ]
    overflow = _horizontal_overflow(page)
    splash = _splash_visible(page)
    obstructing_overlays = page.locator(
        "[data-onboarding-tour], "
        "[data-pwa-runtime-status]:not("
        "[data-pwa-runtime-layout='inline-readonly'])"
    ).count()
    screenshot.parent.mkdir(parents=True, exist_ok=True)
    page.screenshot(path=str(screenshot), full_page=True)
    status_code = response.status if response else None
    status_ok = status_code == expected_status
    ok = all(
        (
            status_ok,
            bool(body),
            marker_count >= 1,
            not page_errors,
            not filtered_console,
            not visible_errors,
            not overflow,
            not splash,
            obstructing_overlays == 0,
            screenshot.exists(),
            screenshot.stat().st_size > 0,
        )
    )
    return {
        "route": route,
        "kind": kind,
        "viewport": viewport,
        "status": "OK" if ok else "FAILED",
        "http_status": status_code,
        "expected_http_status": expected_status,
        "body_chars": len(body),
        "marker_count": marker_count,
        "page_errors": page_errors[:20],
        "console_errors": filtered_console[:20],
        "visible_errors": visible_errors,
        "horizontal_overflow": overflow,
        "splash_visible": splash,
        "obstructing_overlays": obstructing_overlays,
        "screenshot": str(screenshot.relative_to(ROOT)),
        "screenshot_bytes": screenshot.stat().st_size,
    }


def _audit_route(
    browser: Any,
    *,
    base_url: str,
    item: dict[str, Any],
    viewport: dict[str, int | str],
    screenshot_dir: Path,
    kind: str,
) -> dict[str, Any]:
    width = int(viewport["width"])
    height = int(viewport["height"])
    context = browser.new_context(
        viewport={"width": width, "height": height},
        device_scale_factor=1,
        service_workers="block",
    )
    context.route(
        "**/*",
        lambda route: _route_request(route, proxy_local=False),
    )
    page = context.new_page()
    page.set_default_timeout(10_000)
    page.set_default_navigation_timeout(25_000)
    shot = screenshot_dir / (
        f"{kind}__{_slug(item['route'])}__{width}x{height}.png"
    )
    try:
        return _record(
            page,
            base_url=base_url,
            item=item,
            viewport=viewport,
            screenshot=shot,
            kind=kind,
        )
    except Exception as exc:  # noqa: BLE001
        with suppress(Exception):
            page.screenshot(path=str(shot), full_page=True)
        return {
            "route": item["route"],
            "kind": kind,
            "viewport": viewport,
            "status": "FAILED",
            "error": str(exc)[:800],
            "screenshot": str(shot.relative_to(ROOT)),
        }
    finally:
        context.close()



def _cross_provider_session_proof(
    browser: Any,
    *,
    base_url: str,
    provider: str,
) -> dict[str, Any]:
    context = browser.new_context(
        viewport={"width": 390, "height": 844},
        device_scale_factor=1,
        service_workers="block",
    )
    context.route(
        "**/*",
        lambda route: _route_request(route, proxy_local=False),
    )
    page = context.new_page()
    page.set_default_timeout(10_000)
    page.set_default_navigation_timeout(25_000)
    token = ("t" if provider == "telegram" else "n") * 40
    credential = {
        "access_token": token,
        "token_type": "Bearer",
        "expires_at": "2030-01-01T00:00:00+00:00",
    }
    _install_public_fallback(page, "ru", base_url)
    page.add_init_script(
        "window.sessionStorage.setItem("
        f"{json.dumps(SESSION_KEY)}, "
        f"{json.dumps(json.dumps(credential))});"
    )
    api_requests: list[dict[str, Any]] = []

    def record_request(request: Any) -> None:
        if "/api/" not in request.url:
            return
        api_requests.append(
            {
                "url": request.url,
                "authorization": request.headers.get(
                    "authorization"
                ),
                "telegram_init_data": request.headers.get(
                    "x-telegram-init-data"
                ),
            }
        )

    def auth_session(route: Any) -> None:
        route.fulfill(
            status=200,
            content_type="application/json",
            body=json.dumps(
                {
                    "global_id": CROSS_PROVIDER_GLOBAL_ID,
                    "provider": provider,
                    "roles": [],
                }
            ),
        )

    page.on("request", record_request)
    page.route("**/api/auth/session", auth_session)
    try:
        with page.expect_request(
            "**/api/auth/session",
            timeout=15_000,
        ) as auth_request_info:
            response = page.goto(
                f"{base_url}/",
                wait_until="domcontentloaded",
            )
        auth_request = auth_request_info.value
        _wait_for_shell_visual_ready(page)
        page.wait_for_timeout(250)
        stored = page.evaluate(
            "() => window.sessionStorage.getItem("
            f"{json.dumps(SESSION_KEY)})"
        )
        auth_requests = [
            item
            for item in api_requests
            if "/api/auth/session" in item["url"]
        ]
        bearer_seen = (
            auth_request.headers.get("authorization")
            == f"Bearer {token}"
        ) and any(
            item["authorization"] == f"Bearer {token}"
            for item in auth_requests
        )
        raw_init_data_seen = any(
            bool(item["telegram_init_data"])
            for item in api_requests
        )
        status_code = response.status if response else None
        ok = all(
            (
                status_code == 200,
                stored is not None,
                bool(auth_requests),
                bearer_seen,
                not raw_init_data_seen,
                page.locator("body").count() == 1,
            )
        )
        return {
            "provider": provider,
            "global_id": CROSS_PROVIDER_GLOBAL_ID,
            "status": "OK" if ok else "FAILED",
            "http_status": status_code,
            "auth_session_requests": len(auth_requests),
            "api_requests": len(api_requests),
            "bearer_seen": bearer_seen,
            "raw_init_data_seen": raw_init_data_seen,
            "session_storage_present": stored is not None,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "provider": provider,
            "global_id": CROSS_PROVIDER_GLOBAL_ID,
            "status": "FAILED",
            "error": str(exc)[:800],
        }
    finally:
        context.close()

def run(
    *,
    base_url: str,
    report_path: Path,
    screenshot_dir: Path,
) -> dict[str, Any]:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    base_url = base_url.rstrip("/")
    results: list[dict[str, Any]] = []
    executable = _chromium_path()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            **_launch_kwargs(executable)
        )
        try:
            for viewport in manifest["viewports"]:
                for kind, key in (
                    ("public", "public_routes"),
                    ("admin", "admin_routes"),
                    ("system", "system_routes"),
                ):
                    for item in manifest[key]:
                        print(
                            "[all-pages-visual] "
                            f"{kind} {item['route']} "
                            f"{viewport['width']}x{viewport['height']}",
                            flush=True,
                        )
                        results.append(
                            _audit_route(
                                browser,
                                base_url=base_url,
                                item=item,
                                viewport=viewport,
                                screenshot_dir=screenshot_dir,
                                kind=kind,
                            )
                        )
            cross_provider_results = [
                _cross_provider_session_proof(
                    browser,
                    base_url=base_url,
                    provider=provider,
                )
                for provider in ("telegram", "ton")
            ]
        finally:
            browser.close()
    failures = [
        result for result in results if result["status"] != "OK"
    ]
    cross_provider_failures = [
        result
        for result in cross_provider_results
        if result["status"] != "OK"
    ]
    report = {
        "schema": "EFHC_ALL_PAGES_ROUTE_BACKED_VISUAL_AUDIT_V1",
        "archive_version": _archive_version(),
        "cycle": 1635,
        "status": (
            "PASSED"
            if not failures and not cross_provider_failures
            else "FAILED"
        ),
        "base_url": base_url,
        "browser": "chromium",
        "chromium_executable": executable,
        "navigation_mode": "real-page-goto",
        "synthetic_html": False,
        "routes": len(
            manifest["public_routes"]
            + manifest["admin_routes"]
            + manifest["system_routes"]
        ),
        "viewports": len(manifest["viewports"]),
        "checks_total": len(results),
        "checks_ok": len(results) - len(failures),
        "checks_failed": len(failures),
        "results": results,
        "cross_provider_session_proof": {
            "status": (
                "PASSED"
                if not cross_provider_failures
                else "FAILED"
            ),
            "same_global_id": CROSS_PROVIDER_GLOBAL_ID,
            "checks_total": len(cross_provider_results),
            "checks_failed": len(cross_provider_failures),
            "results": cross_provider_results,
        },
        "proof_boundary": {
            "route_backed_chromium": (
                "VERIFIED" if not failures else "FAILED"
            ),
            "cross_provider_session_chromium": (
                "VERIFIED"
                if not cross_provider_failures
                else "FAILED"
            ),
            "live_telegram": "NOT_VERIFIED",
            "real_wallet": "NOT_VERIFIED",
            "production_deployment": "NOT_VERIFIED",
        },
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    if failures or cross_provider_failures:
        print(
            json.dumps(
                {
                    "route_failures": failures,
                    "cross_provider_failures": (
                        cross_provider_failures
                    ),
                },
                ensure_ascii=False,
                indent=2,
            ),
            flush=True,
        )
        raise SystemExit(1)
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url",
        default=os.environ.get(
            "EFHC_E2E_BASE_URL",
            "http://127.0.0.1:3000",
        ),
    )
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    parser.add_argument("--screenshots", default=str(DEFAULT_SHOTS))
    args = parser.parse_args()
    report = run(
        base_url=args.base_url,
        report_path=Path(args.report),
        screenshot_dir=Path(args.screenshots),
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks_ok": report["checks_ok"],
                "checks_total": report["checks_total"],
                "cross_provider_session_proof": report[
                    "cross_provider_session_proof"
                ],
                "report": args.report,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
