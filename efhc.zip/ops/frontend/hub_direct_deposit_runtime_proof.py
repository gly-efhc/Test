from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from shutil import which

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tests.frontend.e2e import _helpers as e2e_helpers  # noqa: E402
from tests.frontend.e2e._helpers import (  # noqa: E402
    assert_not_blank,
    goto,
    install_common_public_api_mocks,
    install_public_fallback,
)


def _chromium_path() -> str | None:
    return (
        os.environ.get("EFHC_PLAYWRIGHT_CHROMIUM_PATH")
        or which("chromium")
        or which("chromium-browser")
        or which("google-chrome")
    )


def _capture(page, folder: Path, name: str) -> str:
    target = folder / name
    page.screenshot(path=str(target), full_page=True)
    return str(target.relative_to(ROOT))


def run(base_url: str) -> dict[str, object]:
    os.environ["EFHC_E2E_BASE_URL"] = base_url.rstrip("/")
    e2e_helpers.BASE_URL = base_url.rstrip("/")
    screenshots_dir = (
        ROOT / "reports/screenshots/hub_direct_deposit_1560"
    )
    screenshots_dir.mkdir(parents=True, exist_ok=True)
    state = {"handoff": 0, "direct": 0, "history": 0}
    screenshots: list[str] = []

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=_chromium_path(),
            args=["--no-sandbox"],
        )
        page = browser.new_page(viewport={"width": 390, "height": 844})
        page.set_default_timeout(10_000)
        install_public_fallback(page, tg_id=1001)
        install_common_public_api_mocks(page)
        page.add_init_script(
            """
            window.__efhcOpenedLinks = [];
            window.Telegram = window.Telegram || { WebApp: {} };
            window.Telegram.WebApp = window.Telegram.WebApp || {};
            window.Telegram.WebApp.openLink = (url) => {
              window.__efhcOpenedLinks.push(String(url));
            };
            """
        )

        def handoff(route):
            state["handoff"] += 1
            route.fulfill(
                status=200,
                json={
                    "redirect_url": "https://efhc.example/top-up",
                    "expires_at": "2026-07-19T12:10:00Z",
                    "transport": "external_url",
                    "mode": "signed_token",
                },
            )

        def direct_open(route):
            state["direct"] += 1
            route.fulfill(
                status=200,
                json={
                    "purpose": "direct_deposit",
                    "wallet_open_url": (
                        "ton://transfer/UQPROJECT?text=EFHC%3A1001"
                    ),
                    "memo": "EFHC:1001",
                    "receiver_address": "UQPROJECT",
                    "memo_binding": "tg_id",
                },
            )

        def history(route):
            state["history"] += 1
            items = []
            if state["history"] >= 2:
                items = [
                    {
                        "id": 77,
                        "amount_efhc": "25.00000000",
                        "direction": "credit",
                        "balance_type": "main",
                        "reason": "simple_deposit_auto",
                        "created_at": "2099-01-01T00:00:00Z",
                    }
                ]
            route.fulfill(
                status=200,
                json={"items": items, "next_cursor": None},
            )

        page.route("**/api/hub/efhc-handoff", handoff)
        page.route("**/api/deposit/direct-open", direct_open)
        page.route("**/api/wallets/balance-history**", history)

        goto(page, "/hub")
        assert_not_blank(page)
        page.wait_for_selector('[data-hub-runtime="two-equal-actions"]')
        assert page.locator(".efhc-game-action-card").count() == 2
        screenshots.append(
            _capture(page, screenshots_dir, "hub_390x844_ru.png")
        )

        page.get_by_role("button", name="Пополнить EFHC").click()
        page.wait_for_function(
            "() => window.__efhcOpenedLinks.length === 1"
        )

        page.set_viewport_size({"width": 360, "height": 800})
        goto(page, "/")
        page.get_by_role("button", name="Прямое пополнение").click()
        direct_runtime = (
            '[data-direct-deposit-runtime='
            '"amount-wallet-reconciliation"]'
        )
        page.wait_for_selector(direct_runtime)
        page.locator('[data-direct-deposit-amount="ton"]').fill("1.25")
        screenshots.append(
            _capture(
                page,
                screenshots_dir,
                "direct_deposit_amount_360x800_ru.png",
            )
        )
        page.locator(
            '[data-direct-deposit-action="open-wallet"]'
        ).click()
        page.wait_for_selector(
            '[data-direct-deposit-status="checking"]'
        )
        screenshots.append(
            _capture(
                page,
                screenshots_dir,
                "direct_deposit_checking_360x800_ru.png",
            )
        )
        opened_url = page.evaluate("window.__efhcOpenedLinks.at(-1)")
        assert "text=EFHC%3A1001" in opened_url
        assert "amount=1250000000" in opened_url

        check_button = page.locator(
            '[data-direct-deposit-action="check-status"]'
        )
        if check_button.count():
            check_button.click()
        page.wait_for_selector(
            '[data-direct-deposit-status="confirmed"]'
        )
        page.set_viewport_size({"width": 430, "height": 932})
        screenshots.append(
            _capture(
                page,
                screenshots_dir,
                "direct_deposit_confirmed_430x932_ru.png",
            )
        )

        page.set_viewport_size({"width": 768, "height": 1024})
        goto(page, "/hub")
        page.wait_for_selector('[data-hub-runtime="two-equal-actions"]')
        screenshots.append(
            _capture(page, screenshots_dir, "hub_768x1024_ru.png")
        )

        overflow = page.evaluate(
            "document.documentElement.scrollWidth > window.innerWidth"
        )
        browser.close()

    payload = {
        "cycle": 1560,
        "archive": "v171_35",
        "status": "PASSED",
        "hub_actions": 2,
        "direct_open_posts": state["direct"],
        "handoff_posts": state["handoff"],
        "history_status_calls": state["history"],
        "wallet_url_has_canonical_memo": True,
        "wallet_url_amount_nano": "1250000000",
        "confirmed_credit": "25.00000000 EFHC",
        "viewports": ["360x800", "390x844", "430x932", "768x1024"],
        "horizontal_overflow": bool(overflow),
        "screenshots": screenshots,
    }
    target = ROOT / "reports/generated/hub_direct_deposit_v171_35.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:3020")
    args = parser.parse_args()
    payload = run(args.base_url)
    print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
