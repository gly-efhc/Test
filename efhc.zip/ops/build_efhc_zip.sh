#!/usr/bin/env bash
set -euo pipefail

ZIP_OUT="efhc.zip"

echo "[1/6] CLEAN: remove generated caches and temp files"
find . -type d -name "__pycache__" -prune -exec rm -rf {} + || true
find . -type f \( -name "*.pyc" -o -name "*.pyo" \) -delete || true
rm -rf .pytest_cache .mypy_cache .ruff_cache .cache htmlcov \
  coverage.xml .coverage || true

rm -rf frontend/node_modules frontend/.next frontend/out frontend/.turbo || true
rm -f frontend/npm-debug.log frontend/yarn-error.log || true

find . -type f \( -name "*.new" -o -name "*.new2" -o -name "*.bak" \
  -o -name "*.tmp" -o -name "*~" \) -delete || true

rm -f .DS_Store Thumbs.db || true

echo "[2/6] PRE-PACK GUARD: canon_guard"
python ops/canon_guard.py

echo "[3/6] BUILD: create FLAT zip (no wrapper folder)"
rm -f "${ZIP_OUT}"
zip -r "${ZIP_OUT}" . \
  -x "./.git/*" \
  -x "./frontend/node_modules/*" \
  -x "./frontend/.next/*" \
  -x "./frontend/out/*" \
  -x "./**/__pycache__/*" \
  -x "./**/*.pyc" \
  -x "./**/*.pyo" \
  -x "./.pytest_cache/*" \
  -x "./.mypy_cache/*" \
  -x "./.ruff_cache/*" \
  -x "./.cache/*" \
  -x "./htmlcov/*" \
  -x "./coverage.xml" \
  -x "./.coverage" \
  -x "./**/*.new" \
  -x "./**/*.new2" \
  -x "./**/*.bak" \
  -x "./**/*.tmp" \
  -x "./**/*~"

echo "[4/6] POST-PACK GUARD: anchors exist inside zip"
unzip -l "${ZIP_OUT}" | grep -E "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM\.md" >/dev/null
unzip -l "${ZIP_OUT}" | grep -E "docs/SSOT_INDEX\.md" >/dev/null
unzip -l "${ZIP_OUT}" | grep -E "ops/canon_rules\.yaml" >/dev/null
unzip -l "${ZIP_OUT}" | grep -E "backend/alembic\.ini" >/dev/null

echo "[5/6] POST-PACK GUARD: ensure no forbidden junk inside zip"
if unzip -l "${ZIP_OUT}" | grep -E "__pycache__|\.pytest_cache|node_modules|\.new2?$" >/dev/null; then
  echo "ERROR: zip contains forbidden junk (__pycache__/cache/node_modules/*.new)"
  exit 1
fi

echo "[6/6] DONE: ${ZIP_OUT} is clean and guarded"
