#!/usr/bin/env bash
set -euo pipefail

ZIP_OUT="efhc.zip"
ROOT_DIR="$(pwd -P)"
STAGE_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "${STAGE_DIR}"
}
trap cleanup EXIT

if ! command -v rsync >/dev/null 2>&1; then
  echo "ERROR: rsync is required for staging build" >&2
  exit 1
fi

echo "[1/6] PRE-CHECK: canon_guard on repo root"
python ops/canon_guard.py

echo "[2/6] CLEAN: remove transient junk from repo root"
python ops/cleanup_artifacts.py
rm -rf frontend/node_modules frontend/.next frontend/out frontend/.turbo || true
rm -f frontend/npm-debug.log frontend/yarn-error.log || true
rm -f "${ZIP_OUT}"
rm -rf -- "${ROOT_DIR}/${ZIP_OUT}"

echo "[3/6] STAGE: copy clean repo snapshot without junk"
rsync -a ./ "${STAGE_DIR}/"   --exclude "${ZIP_OUT}"   --exclude ".git/"   --exclude "frontend/node_modules/"   --exclude "frontend/.next/"   --exclude "frontend/out/"   --exclude "frontend/.turbo/"   --exclude "**/__pycache__/"   --exclude "**/*.pyc"   --exclude "**/*.pyo"   --exclude "**/*.tsbuildinfo"   --exclude ".pytest_cache/"   --exclude ".mypy_cache/"   --exclude ".ruff_cache/"   --exclude ".cache/"   --exclude "htmlcov/"   --exclude "coverage.xml"   --exclude ".coverage"   --exclude ".local_artifacts/"   --exclude "reports/screenshots/"   --exclude "reports/evidence/screenshots/"   --exclude "logs/"   --exclude "./logs/*"   --exclude "**/*.log"   --exclude "**/*.new"   --exclude "**/*.new2"   --exclude "**/*.bak"   --exclude "**/*.tmp"   --exclude "**/*~"   --exclude ".DS_Store"   --exclude "Thumbs.db"

echo "[4/6] STAGE CLEANUP: final transient sweep inside staged copy"
python "${STAGE_DIR}/ops/cleanup_artifacts.py" --root "${STAGE_DIR}"

echo "[5/6] BUILD: create FLAT zip from staged snapshot"
rm -rf -- "${ROOT_DIR}/${ZIP_OUT}"
python "${STAGE_DIR}/ops/build_utf8_zip.py" \
  --root "${STAGE_DIR}" \
  --output "/tmp/${ZIP_OUT}"
rm -rf -- "${ROOT_DIR}/${ZIP_OUT}"
mv "/tmp/${ZIP_OUT}" "${ROOT_DIR}/${ZIP_OUT}"

echo "[6/6] POST-PACK GUARD: ensure zip stays clean"
unzip -l "${ROOT_DIR}/${ZIP_OUT}" | grep -E "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM\.md" >/dev/null
unzip -l "${ROOT_DIR}/${ZIP_OUT}" | grep -E "docs/SSOT/SSOT_INDEX\.md" >/dev/null
unzip -l "${ROOT_DIR}/${ZIP_OUT}" | grep -E "ops/canon_rules\.yaml" >/dev/null
unzip -l "${ROOT_DIR}/${ZIP_OUT}" | grep -E "backend/alembic\.ini" >/dev/null
if unzip -l "${ROOT_DIR}/${ZIP_OUT}" | grep -E "__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache|node_modules|\.tsbuildinfo|\.new2?$|(^|/)\.local_artifacts/|(^|/)logs/|(^|/)reports/screenshots/|(^|/)reports/evidence/screenshots/|\.log$" >/dev/null; then
  echo "ERROR: zip contains forbidden junk" >&2
  exit 1
fi

echo "DONE: ${ZIP_OUT} is clean, FLAT, and built from staged snapshot"
