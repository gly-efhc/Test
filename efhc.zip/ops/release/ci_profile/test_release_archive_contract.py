"""CI contract for the minimal production release archive."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pytest
import yaml
from alembic.config import Config
from alembic.script import ScriptDirectory
from app.release.database_contract import (
    EXPECTED_TABLE_COUNT,
    expected_tables,
)
from app.release.route_validation import collect_route_paths


def _project_root() -> Path:
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "backend").is_dir() and (
            parent / "frontend"
        ).is_dir():
            return parent
    raise RuntimeError("EFHC release project root was not found")


ROOT = _project_root()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def test_release_metadata_and_update_policy_match() -> None:
    metadata = json.loads(
        (ROOT / "RELEASE_METADATA.json").read_text(encoding="utf-8")
    )
    policy = json.loads(
        (ROOT / "UPDATE_POLICY.json").read_text(encoding="utf-8")
    )
    assert metadata["schema"] == "EFHC_RELEASE_METADATA_V1"
    assert metadata["version"] == policy["version"]
    archive_version = metadata["version"].replace(".", "_")
    assert metadata["source_head"] == (
        f"EFHC_Bot_{archive_version}.zip"
    )
    assert metadata["update_delivery"] == "FULL_RELEASE_ARCHIVE"
    assert metadata["local_pre_release_scope"] == (
        "LOCAL_RELEASE_CANDIDATE"
    )
    assert metadata["proof_boundary"] == (
        "FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED"
    )
    assert metadata["production_release_ready"] is False
    assert policy["schema"] == "EFHC_RELEASE_UPDATE_POLICY_V4"
    assert policy["update_policy"] == "pre_release_schema_freeze"
    assert policy["database_migration_policy"] == (
        "single_initial_release_schema"
    )
    assert policy["rollback_database_policy"] == (
        "restore_pre_squash_snapshot"
    )
    assert policy["minimum_supported_source_version"]
    assert policy["supported_database_revisions"]
    assert policy["target_database_revision"] in policy[
        "supported_database_revisions"
    ]

    manifest = json.loads(
        (ROOT / "release-manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["schema"] == "EFHC_RELEASE_MANIFEST_V3"
    assert manifest["release_version"] == metadata["version"]
    for key in (
        "update_policy",
        "minimum_supported_source_version",
        "supported_database_revisions",
        "target_database_revision",
        "database_migration_policy",
        "rollback_database_policy",
    ):
        assert manifest[key] == policy[key]


def test_internal_release_manifest_is_complete() -> None:
    manifest = ROOT / "SHA256SUMS"
    assert manifest.is_file()
    listed: set[str] = set()
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, rel = line.split("  ", 1)
        target = ROOT / rel
        assert target.is_file(), rel
        assert _sha256(target) == expected, rel
        listed.add(rel)
    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file()
        and path.name != "SHA256SUMS"
        and not {
            "__pycache__",
            ".pytest_cache",
            ".ruff_cache",
            ".mypy_cache",
            "node_modules",
            ".next",
        }.intersection(path.parts)
        and path.suffix not in {".pyc", ".pyo"}
    }
    assert listed == actual


def test_compose_keeps_production_services_isolated() -> None:
    data = yaml.safe_load(
        (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    )
    services = data["services"]
    assert set(services) == {
        "db",
        "migrate",
        "backend",
        "scheduler",
        "frontend",
        "proxy",
    }
    assert "ports" not in services["db"]
    assert "ports" not in services["backend"]
    assert services["db"].get("env_file") is None
    assert services["proxy"].get("env_file") is None
    assert services["backend"].get("env_file") == [".env"]


def test_release_scripts_are_executable() -> None:
    scripts = ROOT / "scripts" / "release"
    for path in scripts.iterdir():
        if path.suffix in {".sh", ".py"}:
            assert path.stat().st_mode & 0o111, path.name


def test_update_runtime_and_runbook_are_packaged() -> None:
    required = (
        "UPDATE_AND_ROLLBACK.md",
        "scripts/release/update.sh",
        "scripts/release/rollback_release.sh",
        "scripts/release/cleanup_old_releases.sh",
        "scripts/release/install_backup_timer.sh",
        "scripts/release/run_scheduled_backup.sh",
        "scripts/release/safe_extract_release.py",
        "scripts/release/validate_migration_path.py",
    )
    for rel in required:
        assert (ROOT / rel).is_file(), rel


def test_alembic_database_has_all_orm_tables() -> None:
    dsn = os.environ.get("PSYCOPG_URL")
    if not dsn:
        pytest.skip(
            "PSYCOPG_URL is required for the PostgreSQL "
            "acceptance test"
        )

    import psycopg

    expected = expected_tables()
    assert len(expected) == EXPECTED_TABLE_COUNT == 48
    with (
        psycopg.connect(dsn) as connection,
        connection.cursor() as cursor,
    ):
        cursor.execute(
            "SELECT schemaname, tablename FROM pg_tables "
            "WHERE schemaname IN ('efhc_core', 'efhc_admin')"
        )
        actual = {
            (str(schema), str(table))
            for schema, table in cursor.fetchall()
        }
        cursor.execute(
            "SELECT version_num FROM efhc_core.alembic_version"
        )
        database_version = str(cursor.fetchone()[0])
    assert expected <= actual
    config = Config(str(ROOT / "backend" / "alembic.ini"))
    config.set_main_option(
        "script_location",
        str(ROOT / "backend" / "migrations"),
    )
    heads = ScriptDirectory.from_config(config).get_heads()
    assert heads == [database_version]


def test_route_paths_support_nested_fastapi_router_contexts() -> None:
    from fastapi import APIRouter, FastAPI

    leaf = APIRouter(prefix="/leaf")
    leaf.add_api_route("/health", lambda: None, methods=["GET"])
    leaf.add_api_route(
        "/hidden",
        lambda: None,
        methods=["POST"],
        include_in_schema=False,
    )
    parent = APIRouter(prefix="/parent")
    parent.include_router(leaf)
    nested_app = FastAPI()
    nested_app.include_router(parent, prefix="/api")

    assert {
        "/api/parent/leaf/health",
        "/api/parent/leaf/hidden",
    } <= collect_route_paths(nested_app.routes)


def test_required_fastapi_routes_import() -> None:
    from app.main import app

    paths = collect_route_paths(app.routes)
    required = {
        "/api/health",
        "/meta/health_db",
        "/api/tg/webhook",
        "/api/admin/shop/orders",
        "/api/admin/hub/links",
    }
    assert required <= paths


def test_scheduler_registers_all_canonical_jobs() -> None:
    from app.services.scheduler_service import SchedulerService

    scheduler = SchedulerService()
    scheduler.register_defaults(strict=True)
    names = set(scheduler.registered_job_names)
    assert names == {
        "generate_energy",
        "check_ton_inbox",
        "check_vip_nft",
        "archive_panels",
        "update_ranks",
        "tasks_autorestart",
        "ads_rotation",
        "reports_daily",
    }


def test_first_panel_referral_runtime_is_wired_atomically() -> None:
    import ast

    panels_path = ROOT / "backend/app/services/panels_service.py"
    referral_path = ROOT / "backend/app/services/referral_service.py"
    transactions_path = (
        ROOT / "backend/app/services/transactions_service.py"
    )

    panels_tree = ast.parse(panels_path.read_text(encoding="utf-8"))
    activate = next(
        node
        for node in ast.walk(panels_tree)
        if isinstance(node, ast.AsyncFunctionDef)
        and node.name == "activate_panel"
    )
    tx_blocks = [
        node
        for node in ast.walk(activate)
        if isinstance(node, ast.AsyncWith)
        and "bank._tx_context(db)" in ast.unparse(node)
    ]
    assert len(tx_blocks) == 1
    tx_text = ast.unparse(tx_blocks[0])
    assert "current_active == 0" in tx_text
    assert "on_user_first_panel_activation" in tx_text
    assert tx_text.index("_create_panel_records_bulk") < tx_text.index(
        "on_user_first_panel_activation"
    )

    referral_source = referral_path.read_text(encoding="utf-8")
    transactions_source = transactions_path.read_text(encoding="utf-8")
    assert "credit_user_bonus_from_bank_nocommit" in referral_source
    assert (
        "async def credit_user_bonus_from_bank_nocommit"
        in transactions_source
    )
    assert "referral_level_bonus" in referral_source
    assert "REF_LVL:" in referral_source
    assert "_sync_inviter_level_rewards" in referral_source


def test_referral_attribution_is_first_creation_only() -> None:
    referral = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")
    routes = (
        ROOT / "backend/app/routes/referrals_routes.py"
    ).read_text(encoding="utf-8")
    admin = (
        ROOT / "backend/app/routes/admin_referral_routes.py"
    ).read_text(encoding="utf-8")
    user_crud = (
        ROOT / "backend/app/crud/user_crud.py"
    ).read_text(encoding="utf-8")
    me_routes = (
        ROOT / "backend/app/routes/me_routes.py"
    ).read_text(encoding="utf-8")
    transactions = (
        ROOT / "backend/app/services/transactions_service.py"
    ).read_text(encoding="utf-8")

    registration = (
        ROOT / "backend/app/identity/account_registration.py"
    ).read_text(encoding="utf-8")

    assert "onboard_user_at_first_creation" in referral
    assert "existing_user_locked" in referral
    assert "await create_new_account(" in referral
    assert "register_referral_and_reward" not in referral
    onboarding = referral.split(
        "async def onboard_user_at_first_creation", 1
    )[1].split("async def on_user_first_panel_activation", 1)[0]
    assert "ON CONFLICT DO NOTHING" not in onboarding
    assert "user = User(" in registration
    assert '"/bind"' not in routes
    assert '"/attach"' not in routes
    assert '"/reassign"' not in admin
    assert '"/manual-bonus"' not in admin
    assert "async def ensure_user(" not in user_crud
    assert "INSERT INTO" not in user_crud
    assert "user_not_onboarded" in me_routes
    assert "ensure_user" not in me_routes
    assert "_UPSERT_USER_SQL" not in transactions
    assert "user_not_onboarded" in transactions


def test_referrals_page_has_inline_tabs_and_lvl_economics() -> None:
    page = (ROOT / "frontend/src/pages/referrals.tsx").read_text(
        encoding="utf-8"
    )
    service = (
        ROOT / "frontend/src/services/referrals.service.ts"
    ).read_text(encoding="utf-8")
    backend = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")

    for marker in [
        'data-referrals-progress-bar="true"',
        'data-referral-link-main="true"',
        'data-referral-share-grid="social"',
        'data-referrals-tabs="active-inactive"',
        'data-referrals-tab-button="active"',
        'data-referrals-tab-button="inactive"',
        'data-referrals-current-lvl="true"',
        'data-referrals-level-scale="lvl-1-5"',
        "<ReferralRoster",
    ]:
        assert marker in page

    assert 'router.push("/referrals/active")' not in page
    assert 'router.push("/referrals/inactive")' not in page
    assert "level_steps" in service
    assert "cumulative_level_bonus" in service
    assert "cumulative_total_reward" in service
    assert "bonus_asset" in service
    assert "full_cycle_direct_bonus" in service
    assert "full_cycle_level_bonus" in service
    assert "full_cycle_total_bonus" in service
    assert "data-referrals-full-cycle" in page
    assert "EFHCb" in page
    assert "10 × 0.1 + 1 = 2 EFHCb" in backend


def test_referral_runtime_api_and_documentation_contract() -> None:
    service = (
        ROOT / "backend/app/services/referral_service.py"
    ).read_text(encoding="utf-8")
    crud = (
        ROOT / "backend/app/crud/referrals_crud.py"
    ).read_text(encoding="utf-8")
    routes = (
        ROOT / "backend/app/routes/referrals_routes.py"
    ).read_text(encoding="utf-8")
    model = (
        ROOT / "backend/app/models/referral_models.py"
    ).read_text(encoding="utf-8")
    install = (ROOT / "INSTALL.md").read_text(encoding="utf-8")
    update = (ROOT / "UPDATE_AND_ROLLBACK.md").read_text(
        encoding="utf-8"
    )
    policy = json.loads(
        (ROOT / "UPDATE_POLICY.json").read_text(encoding="utf-8")
    )

    for forbidden in (
        "p.tg_id = u.id",
        "p.tg_id = u.u_pk",
        "ReferralLink.is_active",
        "link.activation_bonus_efhc",
    ):
        assert forbidden not in service + crud
    assert "rl.activated_at IS NOT NULL" in service
    assert "panels_count, 0) > 0) AS is_active" not in service
    assert ".with_for_update()" in crud
    assert "ReferralActivationResult" in crud
    assert "UPDATE efhc_core.referral_links" not in service
    assert "activation = await activate_referral(" in service
    admin_users = (
        ROOT / "backend/app/services/admin/admin_users_service.py"
    ).read_text(encoding="utf-8")
    brief = admin_users.split(
        "async def _get_referrals_brief", 1
    )[1].split("class AdminUsersService", 1)[0]
    assert "ReferralLink.activated_at.isnot(None)" in brief
    assert "efhc_core.panels" not in brief
    for typed_bind in (
        "CAST(:cursor_ts AS TIMESTAMPTZ)",
        "CAST(:cursor_id AS BIGINT)",
        "CAST(:want_active AS BOOLEAN)",
        "LIMIT CAST(:fetch_limit AS INTEGER)",
    ):
        assert typed_bind in service
    panels = (
        ROOT / "backend/app/services/panels_service.py"
    ).read_text(encoding="utf-8")
    lock_block = panels.split("async def _lock_user_row", 1)[1].split(
        "async def _load_panel_activation", 1
    )[0]
    lock_sql = lock_block.split(
        "row = await db.execute(", 1
    )[1].split('"""', 1)[1].split('"""', 1)[0]
    assert "FOR UPDATE" in lock_sql
    assert "SKIP LOCKED" not in lock_sql
    assert "referral_active_unit" in service
    assert "referral_level_bonus" in service
    assert "ix_referral_links_inviter_created_invitee" in model
    assert '"/counters/me"' in routes
    assert "status.HTTP_403_FORBIDDEN" in routes
    assert "X-EFHC-Deprecated-Route" in routes
    assert "env.release.example" not in install
    assert ".env.example" in install
    assert "TARGET_RELEASE.zip" in update
    assert "Rollback mode: ONE_STEP_BACK_ONLY" in update
    for removed in (
        "minimum_source_version",
        "automatic_rollback_allowed",
        "requires_database_restore_on_rollback",
    ):
        assert removed not in policy
