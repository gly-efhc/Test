"""Minimal environment for release-archive verification tests."""

from __future__ import annotations

import os


def pytest_configure() -> None:
    """Set non-secret CI defaults before backend modules import."""
    defaults = {
        "APP_ENV": "test",
        "ENVIRONMENT": "test",
        "SECRET_KEY": "ci-only-release-secret-key-32-characters",
        "TELEGRAM_BOT_TOKEN": (
            "ci-only-not-a-real-telegram-token"
        ),
        "TELEGRAM_WEBHOOK_SECRET": "ci-only-webhook-secret",
        "ADMIN_TG_IDS": "[100000001]",
        "BANK_EFHC": "900000000000000001",
        "TON_NETWORK": "mainnet",
        "TON_API_BASE_URL": "https://tonapi.io",
        "TON_API_KEY": "ci-only-ton-api-key",
        "TON_MAIN_WALLET": "0:" + ("11" * 32),
        "TON_WALLET_ADDRESS": "0:" + ("11" * 32),
        "TON_NFT_COLLECTION": "0:" + ("22" * 32),
        "APP_DOMAIN": "app.example.org",
        "API_DOMAIN": "api.example.org",
        "APP_PUBLIC_URL": "https://app.example.org",
        "API_PUBLIC_URL": "https://api.example.org",
        "TELEGRAM_WEBHOOK_PATH": "/api/tg/webhook",
    }
    for name, value in defaults.items():
        os.environ.setdefault(name, value)
