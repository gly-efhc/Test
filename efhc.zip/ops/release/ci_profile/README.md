# Release CI profile

This small profile lets the common EFHC GitHub archive workflow
validate a minimal production release ZIP. It does not replace the
full development test suite. Docker images copy only `backend/` and
`frontend/`; these verification files never enter runtime images.
