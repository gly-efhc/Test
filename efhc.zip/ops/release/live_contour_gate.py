"""Cycle 1573 live Telegram / TonConnect / TonProof proof intake gate.

This gate is deliberately fail-closed. It does not perform live
network work in AI/local archive packaging mode and never records
secret values. It only records whether the operator supplied explicit
evidence artifacts for every required live contour.
"""

from __future__ import annotations

import argparse
import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]

REQUIRED_CONTOURS = (
    "live_telegram",
    "real_tonconnect",
    "real_tonproof",
    "real_transaction",
)

EVIDENCE_ENV = {
    "live_telegram": "EFHC_C1573_LIVE_TELEGRAM_PROOF_JSON",
    "real_tonconnect": "EFHC_C1573_REAL_TONCONNECT_PROOF_JSON",
    "real_tonproof": "EFHC_C1573_REAL_TONPROOF_PROOF_JSON",
    "real_transaction": "EFHC_C1573_REAL_TRANSACTION_PROOF_JSON",
}

FORBIDDEN_SECRET_MARKERS = (
    "Bearer ",
    "xoxb-",
    "bot_token_live_",
    "private_key",
    "mnemonic",
    "seed phrase",
    "postgresql://postgres:",
    "postgresql+asyncpg://postgres:",
)


def _resolve_evidence_path(raw: str | None) -> Path | None:
    if not raw:
        return None
    path = Path(raw)
    if not path.is_absolute():
        path = ROOT / path
    return path


def _read_evidence(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {
            "status": "BLOCKED_MISSING_EVIDENCE_PATH",
            "path_present": False,
            "file_present": False,
            "accepted": False,
            "secret_values_recorded": False,
        }
    if not path.is_file():
        return {
            "status": "BLOCKED_EVIDENCE_FILE_MISSING",
            "path": str(path),
            "path_present": True,
            "file_present": False,
            "accepted": False,
            "secret_values_recorded": False,
        }
    text = path.read_text(encoding="utf-8", errors="replace")
    secret_findings = [
        marker
        for marker in FORBIDDEN_SECRET_MARKERS
        if marker in text
    ]
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        return {
            "status": "BLOCKED_INVALID_JSON",
            "path": str(path),
            "path_present": True,
            "file_present": True,
            "accepted": False,
            "error": str(exc),
            "secret_values_recorded": bool(secret_findings),
        }
    if not isinstance(payload, dict):
        return {
            "status": "BLOCKED_JSON_ROOT_NOT_OBJECT",
            "path": str(path),
            "path_present": True,
            "file_present": True,
            "accepted": False,
            "secret_values_recorded": bool(secret_findings),
        }
    accepted = bool(
        payload.get("accepted") is True
        and not secret_findings
    )
    return {
        "status": (
            "ACCEPTED"
            if accepted
            else "BLOCKED_EVIDENCE_NOT_ACCEPTED"
        ),
        "path": str(path),
        "path_present": True,
        "file_present": True,
        "accepted": accepted,
        "proof_type": payload.get("proof_type", "UNKNOWN"),
        "secret_values_recorded": bool(secret_findings),
    }


def build_report(
    *,
    archive_version: str = "v171.57",
    cycle: int = 1573,
    defer_external: bool = False,
) -> dict[str, Any]:
    contours: dict[str, dict[str, Any]] = {}
    for contour in REQUIRED_CONTOURS:
        env_name = EVIDENCE_ENV[contour]
        evidence_path = _resolve_evidence_path(os.environ.get(env_name))
        evidence = _read_evidence(evidence_path)
        contours[contour] = {
            "env": env_name,
            "executed_by_gate": False,
            **evidence,
        }

    live_proof = {
        contour: bool(data.get("accepted") is True)
        for contour, data in contours.items()
    }
    all_verified = all(live_proof.values())
    blockers = [
        contour.upper() + "_NOT_VERIFIED"
        for contour, verified in live_proof.items()
        if not verified
    ]
    deferred = bool(defer_external and not all_verified)
    cycle_status = (
        "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED"
        if deferred
        else "ACTIVE"
    )
    completion_claim = (
        "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED"
        if deferred
        else "NOT_COMPLETE"
    )
    next_cycle = (
        "1574 — local release-candidate audit"
        if deferred
        else "NONE; cycle 1573 continues."
    )
    return {
        "schema": "EFHC_CYCLE_1573_LIVE_CONTOUR_GATE_V2",
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "archive_version": archive_version,
        "cycle": cycle,
        "cycle_status": cycle_status,
        "completion_claim": completion_claim,
        "next_cycle": next_cycle,
        "local_scope_complete": deferred,
        "external_verification_disposition": (
            "DEFERRED_POST_RELEASE_BY_USER" if deferred else "OPEN"
        ),
        "release_ready": False,
        "mode": "fail_closed_external_live_proof_intake",
        "contours": contours,
        "live_proof": live_proof,
        "all_live_contours_verified": all_verified,
        "blocked_state": (
            None
            if all_verified
            else "DEFERRED_POST_RELEASE_VERIFICATION"
            if deferred
            else "BLOCKED_MISSING_LIVE_EVIDENCE"
        ),
        "blockers": blockers,
        "secret_hygiene": {
            "secret_values_recorded": any(
                bool(data.get("secret_values_recorded"))
                for data in contours.values()
            ),
            "status": "PASS"
            if not any(
                bool(data.get("secret_values_recorded"))
                for data in contours.values()
            )
            else "BLOCKED_SECRET_VALUES_IN_EVIDENCE",
        },
        "non_claims": [
            "LIVE_TELEGRAM_NOT_VERIFIED",
            "REAL_TONCONNECT_NOT_VERIFIED",
            "REAL_TONPROOF_NOT_VERIFIED",
            "REAL_TRANSACTION_NOT_VERIFIED",
            (
                "CYCLE_1573_NOT_FULLY_LIVE_VERIFIED"
                if deferred
                else "CYCLE_1573_NOT_COMPLETE"
            ),
            "NOT_RELEASE_READY",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive-version", default="v171.57")
    parser.add_argument("--cycle", type=int, default=1573)
    parser.add_argument(
        "--defer-external",
        action="store_true",
        help=(
            "Record user-authorized post-release verification "
            "deferral."
        ),
    )
    parser.add_argument(
        "--output",
        default=(
            "reports/generated/"
            "cycle_1573_live_contour_gate_v171_57.json"
        ),
    )
    args = parser.parse_args()
    report = build_report(
        archive_version=args.archive_version,
        cycle=args.cycle,
        defer_external=args.defer_external,
    )
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
