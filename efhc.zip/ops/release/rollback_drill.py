#!/usr/bin/env python3
"""Create a non-mutating rollback drill plan."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--previous-backend-digest", required=True)
    parser.add_argument("--previous-frontend-digest", required=True)
    parser.add_argument("--namespace", default="efhc")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if "sha256:" not in args.previous_backend_digest:
        raise SystemExit("Backend digest must contain sha256:")
    if "sha256:" not in args.previous_frontend_digest:
        raise SystemExit("Frontend digest must contain sha256:")
    namespace = args.namespace
    backend_digest = args.previous_backend_digest
    frontend_digest = args.previous_frontend_digest
    commands = [
        (
            f"kubectl -n {namespace} set image "
            "deployment/efhc-backend "
            f"backend={backend_digest}"
        ),
        (
            f"kubectl -n {namespace} set image "
            "deployment/efhc-frontend "
            f"frontend={frontend_digest}"
        ),
        (
            f"kubectl -n {namespace} rollout status "
            "deployment/efhc-backend --timeout=180s"
        ),
        (
            f"kubectl -n {namespace} rollout status "
            "deployment/efhc-frontend --timeout=180s"
        ),
    ]
    result = {
        "schema": "EFHC_ROLLBACK_DRILL_V1",
        "generated_at": datetime.now(UTC).isoformat(),
        "mode": "PLAN_ONLY_NO_MUTATION",
        "commands": commands,
        "checks": [
            "/api/health/readiness returns 200",
            "alembic head remains 0001",
            "watcher heartbeat is fresh when enabled",
            "public and admin smoke routes render",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
