"""Evaluate the EFHC exact-HEAD local release boundary."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ops.release.provider_portability_gate import validate

ROOT = Path(__file__).resolve().parents[2]
REQUIRED_DOCS = (
    "README_RELEASE.md",
    "docs/SSOT/PROVIDER_INDEPENDENT_DEPLOYMENT_SSOT.md",
    "docs/NORM/PROVIDER_INDEPENDENT_RELEASE_NORM.md",
    "docs/RUNBOOKS/VPS_PORTABILITY_AND_RECOVERY.md",
    "docs/cycles/WORK_CYCLES_1574_1578_RELEASE_PREPARATION.md",
)
EXTERNAL_GATES = (
    "LIVE_VPS_DEPLOYMENT",
    "PUBLIC_DNS_AND_HTTPS",
    "LIVE_TELEGRAM_CLIENT_AND_WEBHOOK",
    "REAL_TONCONNECT_AND_TONPROOF",
    "REAL_TRANSACTION_SETTLEMENT",
    "CROSS_PROVIDER_RESTORE_DRILL",
)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _ci_is_green(payload: dict[str, Any]) -> bool:
    pytest = payload.get("pytest") or {}
    frontend = payload.get("frontend_production_build") or {}
    return bool(
        pytest.get("failed") == 0
        and pytest.get("status") == "PASS"
        and payload.get("ruff") == "PASS"
        and payload.get("mypy") == "PASS"
        and payload.get("bandit") == "PASS"
        and payload.get("compileall") == "PASS"
        and payload.get("postgresql_migrations") == "PASS"
        and frontend.get("status") == "PASS"
        and payload.get("gate_summary") == "PASS"
    )


def _archive_token(version: str) -> str:
    return version.replace(".", "_")


def _current_release(root: Path) -> tuple[str, str]:
    policy_path = root / "release_config/UPDATE_POLICY.json"
    policy = _read_json(policy_path)
    version = str(
        policy.get("release_version") or policy.get("version") or ""
    )
    if not version.startswith("v"):
        raise ValueError(
            "release_config/UPDATE_POLICY.json has no valid version"
        )
    current_head = f"EFHC_Bot_{_archive_token(version)}.zip"
    return version, current_head


def _discover_exact_head_ci(
    root: Path,
    current_head: str,
) -> tuple[Path | None, dict[str, Any], list[dict[str, str]]]:
    generated = root / "reports/generated"
    historical: list[dict[str, str]] = []
    for path in sorted(
        generated.glob("fresh_ci*_intake.json"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    ):
        payload = _read_json(path)
        source_head = str(payload.get("source_head") or "")
        if source_head == current_head and _ci_is_green(payload):
            return path, payload, historical
        if source_head:
            historical.append(
                {
                    "file": path.relative_to(root).as_posix(),
                    "source_head": source_head,
                    "accepted_for_current_head": "false",
                }
            )
    return None, {}, historical


def build_report(root: Path = ROOT) -> dict[str, Any]:
    version, current_head = _current_release(root)
    portability = validate(root, "source")
    ci_path, ci_payload, historical_ci = _discover_exact_head_ci(
        root,
        current_head,
    )
    missing_docs = [
        item for item in REQUIRED_DOCS if not (root / item).is_file()
    ]
    fresh_exact_head_ci = bool(ci_path and _ci_is_green(ci_payload))
    local_checks = {
        "provider_independent_release_contour": bool(
            portability["provider_independent"]
        ),
        "required_release_documents": not missing_docs,
        "development_and_release_archives_separated": True,
        "external_live_gates_explicitly_deferred": True,
        "fresh_exact_head_github_ci": fresh_exact_head_ci,
    }
    base_local_complete = all(
        value
        for key, value in local_checks.items()
        if key != "fresh_exact_head_github_ci"
    )
    exact_head_complete = base_local_complete and fresh_exact_head_ci
    if exact_head_complete:
        status = "LOCAL_PRE_RELEASE_99_PERCENT_COMPLETE"
        readiness_percent = 99
        proof_boundary = "EXACT_HEAD_LOCAL_AND_GITHUB_GATES_COMPLETE"
    elif base_local_complete:
        status = "LOCAL_RELEASE_CANDIDATE"
        readiness_percent = 0
        proof_boundary = "FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED"
    else:
        status = "LOCAL_PRE_RELEASE_INCOMPLETE"
        readiness_percent = 0
        proof_boundary = "LOCAL_RELEASE_CONTRACT_REPAIR_REQUIRED"
    exact_ci_rel = (
        ci_path.relative_to(root).as_posix() if ci_path else None
    )
    return {
        "schema": "EFHC_LOCAL_PRE_RELEASE_EXACT_HEAD_GATE_V2",
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "version": version,
        "source_head": current_head,
        "output_head": current_head,
        "status": status,
        "proof_boundary": proof_boundary,
        "local_pre_release_readiness_percent": readiness_percent,
        "production_release_ready": False,
        "local_checks": local_checks,
        "exact_head_ci_evidence": {
            "required_source_head": current_head,
            "accepted_file": exact_ci_rel,
            "accepted": fresh_exact_head_ci,
        },
        "historical_ci_evidence_ignored": historical_ci,
        "missing_documents": missing_docs,
        "provider_portability": portability,
        "cycles": {
            "1574_1587": "LOCAL_SCOPE_COMPLETE",
            "1588": "EXACT_HEAD_EVIDENCE_GATE_REPAIR",
        },
        "external_gates": list(EXTERNAL_GATES),
        "external_disposition": (
            "DEFERRED_TO_DEPLOYMENT_AND_LIVE_VERIFICATION"
        ),
        "non_claims": [
            "NOT_LIVE_DEPLOYED",
            "NOT_PUBLIC_RELEASED",
            "FRESH_EXACT_HEAD_GITHUB_CI_NOT_VERIFIED"
            if not fresh_exact_head_ci
            else "FRESH_EXACT_HEAD_GITHUB_CI_VERIFIED",
            "LIVE_TELEGRAM_NOT_VERIFIED",
            "REAL_TONPROOF_NOT_VERIFIED",
            "REAL_TRANSACTION_NOT_VERIFIED",
            "CROSS_PROVIDER_RESTORE_NOT_YET_EXECUTED",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=(
            ROOT
            / "reports/generated/local_pre_release_exact_head.json"
        ),
    )
    args = parser.parse_args()
    report = build_report(ROOT)
    output = args.output
    if not output.is_absolute():
        output = ROOT / output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    complete = report["status"] == (
        "LOCAL_PRE_RELEASE_99_PERCENT_COMPLETE"
    )
    return 0 if complete else 2


if __name__ == "__main__":
    raise SystemExit(main())
