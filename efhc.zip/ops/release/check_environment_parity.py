#!/usr/bin/env python3
"""Fail-closed comparison of protected deployment settings."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

PROTECTED_KEYS = (
    "DB_SCHEMA_CORE",
    "DB_SCHEMA_ADMIN",
    "SCHEDULER_ENABLED",
    "REQUEST_BODY_LIMIT_BYTES",
    "CORS_ALLOW_ORIGINS",
    "TON_NETWORK",
)


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise SystemExit(f"Expected JSON object: {path}")
    return value


def compare(
    staging: dict[str, Any],
    production: dict[str, Any],
) -> dict[str, Any]:
    mismatches = []
    for key in PROTECTED_KEYS:
        left = staging.get(key)
        right = production.get(key)
        if left != right:
            mismatches.append(
                {
                    "key": key,
                    "staging": left,
                    "production": right,
                }
            )
    return {
        "ok": not mismatches,
        "protected_keys": list(PROTECTED_KEYS),
        "mismatches": mismatches,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--staging", type=Path, required=True)
    parser.add_argument("--production", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = compare(
        _load(args.staging),
        _load(args.production),
    )
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
