"""Build the minimal provider-independent EFHC release ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import stat
import tempfile
import zipfile
from datetime import UTC, datetime
from pathlib import Path

if __package__:
    from .prepare_frontend_release_assets import prepare_assets
    from .provider_portability_gate import validate
else:
    from prepare_frontend_release_assets import prepare_assets
    from provider_portability_gate import validate

ROOT = Path(__file__).resolve().parents[2]
EXCLUDED_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".next",
    "node_modules",
    ".turbo",
    "out",
    "tests",
    "__tests__",
    "e2e",
    "playwright-report",
}
EXCLUDED_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".log",
    ".zip",
    ".tsbuildinfo",
}

RELEASE_EXCLUDED_RELATIVE_FILES = {
    "backend/app/identity/legacy_user_id.py",
    "backend/app/identity/user_id_backfill.py",
    "backend/app/identity/user_id_expand.py",
}

DOCS = {
    "release_docs/INSTALL.md": "INSTALL.md",
    "release_docs/DEPLOY.md": "DEPLOY.md",
    "release_docs/BACKUP_RESTORE.md": "BACKUP_RESTORE.md",
    "release_docs/DOMAIN_CHANGE.md": "DOMAIN_CHANGE.md",
    "release_docs/MIGRATION_TO_ANOTHER_VPS.md": (
        "MIGRATION_TO_ANOTHER_VPS.md"
    ),
    "release_docs/TROUBLESHOOTING.md": "TROUBLESHOOTING.md",
    "release_docs/UPDATE.md": "UPDATE.md",
    "release_docs/UPDATE_AND_ROLLBACK.md": "UPDATE_AND_ROLLBACK.md",
}



def _archive_version_token(version: str) -> str:
    """Convert semantic release version to canonical archive token."""
    return version.replace(".", "_")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _ignore(_: str, names: list[str]) -> set[str]:
    ignored: set[str] = set()
    for name in names:
        if name in EXCLUDED_DIRS:
            ignored.add(name)
        if Path(name).suffix in EXCLUDED_SUFFIXES:
            ignored.add(name)
        if name.startswith("test_"):
            ignored.add(name)
        if name.endswith((".test.ts", ".test.tsx", ".spec.ts")):
            ignored.add(name)
        if name.endswith((".spec.tsx", ".snap")):
            ignored.add(name)
        if name in {".env", ".env.prod", ".env.production"}:
            ignored.add(name)
    return ignored


def _copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _copy_tree(source: Path, target: Path) -> None:
    shutil.copytree(
        source,
        target,
        ignore=_ignore,
        dirs_exist_ok=True,
    )


def _stage(root: Path, stage: Path, version: str) -> None:
    _copy_tree(root / "backend", stage / "backend")
    for relative in RELEASE_EXCLUDED_RELATIVE_FILES:
        (stage / relative).unlink(missing_ok=True)
    _copy_tree(root / "frontend", stage / "frontend")
    _copy_tree(root / "api", stage / "api")
    _copy_tree(
        root / "scripts/release",
        stage / "scripts/release",
    )
    _copy_file(
        root / "ops/canon_rules.yaml",
        stage / "ops/canon_rules.yaml",
    )
    _copy_file(
        root / "ops/docker/backend.entrypoint.sh",
        stage / "ops/docker/backend.entrypoint.sh",
    )
    mappings = {
        "Dockerfile.backend": "Dockerfile.backend",
        "Dockerfile.frontend": "Dockerfile.frontend",
        "Caddyfile": "Caddyfile",
        "docker-compose.release.yml": "docker-compose.yml",
        "env.release.example": ".env.example",
        ".dockerignore": ".dockerignore",
        "LICENSE": "LICENSE",
        "release_docs/README.md": "README.md",
        "release_config/UPDATE_POLICY.json": "UPDATE_POLICY.json",
    }
    for source, target in mappings.items():
        _copy_file(root / source, stage / target)
    for source, target in DOCS.items():
        _copy_file(root / source, stage / target)
    metadata = {
        "schema": "EFHC_RELEASE_METADATA_V1",
        "version": version,
        "source_head": (
            f"EFHC_Bot_{_archive_version_token(version)}.zip"
        ),
        "built_at_utc": datetime.now(UTC).isoformat(),
        "deployment": "provider_independent_docker_compose",
        "database": "standard_postgresql",
        "local_pre_release_scope": "LOCAL_RELEASE_CANDIDATE",
        "proof_boundary": "FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED",
        "production_release_ready": False,
        "update_delivery": "FULL_RELEASE_ARCHIVE",
        "ci_profile": "NOT_PACKAGED_IN_PRODUCTION_ARCHIVE",
        "full_regression_evidence": "MATRIX_TECHNICAL_ARCHIVE",
        "update_command": (
            "./scripts/release/update.sh TARGET_RELEASE.zip "
            "TARGET_RELEASE.zip.sha256"
        ),
        "rollback_command": (
            "./scripts/release/rollback_release.sh --confirm"
        ),
        "external_gates": [
            "LIVE_VPS_DEPLOYMENT",
            "LIVE_TELEGRAM_CLIENT",
            "REAL_TONCONNECT_AND_TONPROOF",
            "REAL_TRANSACTION_SETTLEMENT",
            "CROSS_PROVIDER_RESTORE_DRILL",
        ],
    }
    (stage / "RELEASE_METADATA.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    policy = json.loads(
        (stage / "UPDATE_POLICY.json").read_text(encoding="utf-8")
    )
    manifest = {
        "schema": "EFHC_RELEASE_MANIFEST_V3",
        "release_version": version,
        "source_head": metadata["source_head"],
        "archive_name": (
            f"EFHC_Bot_{_archive_version_token(version)}_RELEASE.zip"
        ),
        "update_policy": policy.get("update_policy"),
        "clean_install_supported": bool(
            policy.get("clean_install_supported", False)
        ),
        "minimum_supported_source_version": policy.get(
            "minimum_supported_source_version"
        ),
        "supported_database_revisions": policy.get(
            "supported_database_revisions", []
        ),
        "target_database_revision": policy.get(
            "target_database_revision"
        ),
        "database_migration_policy": policy.get(
            "database_migration_policy"
        ),
        "database_migration_class": policy.get(
            "database_migration_class"
        ),
        "rollback_database_policy": policy.get(
            "rollback_database_policy"
        ),
        "rollback_compatibility": policy.get(
            "rollback_compatibility", {}
        ),
    }
    (stage / "release-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _write_manifest(stage: Path) -> None:
    rows: list[str] = []
    for path in sorted(stage.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(stage).as_posix()
        if rel == "SHA256SUMS":
            continue
        rows.append(f"{_sha256(path)}  {rel}")
    (stage / "SHA256SUMS").write_text(
        "\n".join(rows) + "\n",
        encoding="utf-8",
    )


def _zip(stage: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)
    with zipfile.ZipFile(
        output,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in sorted(stage.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(stage).as_posix()
            info = zipfile.ZipInfo.from_file(path, rel)
            info.create_system = 3
            source_mode = path.stat().st_mode
            normalized_mode = (
                0o755 if source_mode & 0o111 else 0o644
            )
            info.external_attr = (
                stat.S_IFREG | normalized_mode
            ) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--version",
        required=True,
    )
    parser.add_argument(
        "--receipt",
        type=Path,
    )
    args = parser.parse_args()
    output = args.output.resolve()
    prepare_assets(ROOT, args.version)
    with tempfile.TemporaryDirectory() as temp:
        stage = Path(temp)
        _stage(ROOT, stage, args.version)
        policy = json.loads(
            (stage / "UPDATE_POLICY.json").read_text(encoding="utf-8")
        )
        if policy.get("version") != args.version:
            raise SystemExit(
                "UPDATE_POLICY.json version must match release version"
            )
        _write_manifest(stage)
        gate = validate(stage, "release")
        if not gate["provider_independent"]:
            print(json.dumps(gate, indent=2))
            return 2
        _zip(stage, output)
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        names = archive.namelist()
        script_modes_ok = all(
            ((info.external_attr >> 16) & 0o111)
            for info in archive.infolist()
            if info.filename.startswith("scripts/release/")
            and info.filename.endswith(".sh")
        )
    checksum_path = Path(str(output) + ".sha256")
    checksum_path.write_text(
        f"{_sha256(output)}  {output.name}\n",
        encoding="utf-8",
    )
    receipt = {
        "schema": "EFHC_RELEASE_ARCHIVE_RECEIPT_V1",
        "archive": output.name,
        "version": args.version,
        "sha256": _sha256(output),
        "size_bytes": output.stat().st_size,
        "zip_integrity": bad is None,
        "file_count": len(names),
        "плоский_корень_проекта": all(
            not name.startswith("EFHC_Bot_")
            for name in names
        ),
        "provider_independent": True,
        "release_scripts_исполняемые": script_modes_ok,
        "production_release_готов": False,
    }
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    if args.receipt:
        receipt_path = args.receipt.resolve()
        receipt_path.parent.mkdir(parents=True, exist_ok=True)
        receipt_path.write_text(
            json.dumps(
                receipt,
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
