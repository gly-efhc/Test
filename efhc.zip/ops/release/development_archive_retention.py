"""Retention-policy для размера development-архива EFHC.

Подробные XLSX и raw-артефакты выносятся в отдельный
matrix/technical archive. Канонические документы, summaries, код и
тесты сохраняются. Перед переносом формируется SHA-256 manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Final

CURRENT_CYCLE: Final[int] = 1620
CURRENT_VERSION: Final[str] = "v172_20"
PREVIOUS_CYCLE: Final[int] = 1619
PREVIOUS_VERSION: Final[str] = "v172_19"


@dataclass(frozen=True, slots=True)
class RemovalRecord:
    """Доказательство удаления воспроизводимого raw-файла."""

    path: str
    bytes: int
    sha256: str
    category: str
    reason: str


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _cycle_from_path(relative: str) -> int | None:
    match = re.search(r"cycle[_/](\d+)", relative)
    if match is None:
        match = re.search(r"cycle_(\d+)", relative)
    return int(match.group(1)) if match else None


def _is_raw_identity_matrix(relative: str) -> bool:
    lower = relative.casefold()
    markers = (
        "identity_usage_matrix.json",
        "identity_usage_matrix.csv",
        "матрица_использований.json",
        "матрица_использований.csv",
        "user_id_tg_id_usage_matrix_",
    )
    return any(marker in lower for marker in markers)


def classify_removal(root: Path, path: Path) -> tuple[str, str] | None:
    """Определить, разрешено ли удалить файл по policy."""

    relative = path.relative_to(root).as_posix()
    name = path.name

    if (
        path.parent == root
        and path.suffix.casefold() == ".xlsx"
        and "full_matrix" in name
    ):
        return (
            "root_xlsx_дубликат",
            "Каноническая копия находится в docs/audits.",
        )

    if (
        relative.startswith("docs/audits/")
        and path.suffix.casefold() == ".xlsx"
        and "full_matrix" in name
    ):
        return (
            "xlsx_в_матричный_архив",
            (
                "Подробная XLSX хранится в отдельном "
                "matrix/technical archive."
            ),
        )

    if relative.startswith(
        f"reports/generated/identity_audit_{CURRENT_VERSION}/"
    ):
        return (
            "текущий_английский_identity_дубликат",
            (
                "Канонический эквивалент хранится в русском "
                "identity audit."
            ),
        )

    if relative.startswith(
        "reports/generated/"
    ) and _is_raw_identity_matrix(relative):
        return (
            "raw_identity_в_матричный_архив",
            (
                "Подробная raw-матрица хранится в отдельном "
                "matrix/technical archive; summary сохранён."
            ),
        )

    if relative.startswith("reports/generated/runtime_logs/"):
        cycle = _cycle_from_path(relative)
        if cycle is not None and cycle < PREVIOUS_CYCLE:
            return (
                "исторический_runtime_log",
                "Итоговая pytest/report summary сохранена.",
            )

    if relative.startswith("reports/generated/junit/"):
        return (
            "исторический_junit",
            "Исторический JUnit заменён итоговой summary и manifest.",
        )

    return None


def build_plan(root: Path) -> list[RemovalRecord]:
    """Сформировать детерминированный cleanup plan."""

    records: list[RemovalRecord] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        classified = classify_removal(root, path)
        if classified is None:
            continue
        category, reason = classified
        records.append(
            RemovalRecord(
                path=path.relative_to(root).as_posix(),
                bytes=path.stat().st_size,
                sha256=_sha256(path),
                category=category,
                reason=reason,
            )
        )
    return records


def apply_plan(root: Path, records: list[RemovalRecord]) -> None:
    """Применить только заранее рассчитанный cleanup plan."""

    for record in records:
        path = root / record.path
        if _sha256(path) != record.sha256:
            raise RuntimeError(
                f"Файл изменился после расчёта retention: {record.path}"
            )
        path.unlink()
    for path in sorted(root.rglob("*"), reverse=True):
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()


def build_report(
    root: Path,
    records: list[RemovalRecord],
    *,
    applied: bool,
) -> dict[str, object]:
    """Сформировать machine report retention-policy."""

    by_category: dict[str, dict[str, int]] = {}
    for record in records:
        item = by_category.setdefault(
            record.category,
            {"файлов": 0, "байт": 0},
        )
        item["файлов"] += 1
        item["байт"] += record.bytes
    return {
        "схема_отчёта": "EFHC_DEVELOPMENT_RETENTION_V2",
        "цикл": CURRENT_CYCLE,
        "версия": CURRENT_VERSION,
        "применено": applied,
        "удалено_или_перенесено_файлов": len(records),
        "освобождено_байт": sum(item.bytes for item in records),
        "по_категориям": by_category,
        "правило_хранения": (
            "Development хранит code/docs/tests/summaries; подробные "
            "XLSX, raw matrices и JUnit хранятся в matrix/technical "
            "archive."
        ),
        "архив_назначения": (
            "EFHC_Bot_v172_20_MATRIX_TECHNICAL.zip"
        ),
        "перемещённые_файлы": [
            {
                "путь": item.path,
                "размер_байт": item.bytes,
                "sha256": item.sha256,
                "категория": item.category,
                "причина": item.reason,
                "архив_назначения": (
                    "EFHC_Bot_v172_20_MATRIX_TECHNICAL.zip"
                ),
            }
            for item in records
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Аудит и cleanup development-архива."
    )
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    records = build_plan(root)
    report = build_report(root, records, applied=args.apply)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    if args.apply:
        apply_plan(root, records)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
