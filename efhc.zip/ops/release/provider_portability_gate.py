"""Validate provider-independent EFHC release contracts."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[2]
PROVIDER_TOKENS = (
    "ovhcloud",
    "vercel",
    "neon.tech",
    "google cloud",
    "cloud run",
)


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _source_layout(root: Path) -> dict[str, Path]:
    return {
        "compose": root / "docker-compose.release.yml",
        "env": root / "env.release.example",
        "backend_dockerfile": root / "Dockerfile.backend",
        "frontend_dockerfile": root / "Dockerfile.frontend",
        "caddy": root / "Caddyfile",
        "scripts": root / "scripts/release",
    }


def _release_layout(root: Path) -> dict[str, Path]:
    return {
        "compose": root / "docker-compose.yml",
        "env": root / ".env.example",
        "backend_dockerfile": root / "Dockerfile.backend",
        "frontend_dockerfile": root / "Dockerfile.frontend",
        "caddy": root / "Caddyfile",
        "scripts": root / "scripts/release",
    }


def _required_scripts(directory: Path) -> list[Path]:
    names = (
        "install_server.sh",
        "deploy.sh",
        "backup_postgres.sh",
        "restore_postgres.sh",
        "restore_drill.sh",
        "change_domain.sh",
        "set_telegram_webhook.sh",
        "post_move_verify.sh",
        "render_public_config.sh",
        "run_scheduled_backup.sh",
        "install_backup_timer.sh",
        "archive_release_for_recovery.sh",
        "extract_recovery_bundle.sh",
        "backup_bundle.sh",
        "sync_offsite.sh",
        "portability_check.sh",
        "rollback_images.sh",
        "update.sh",
        "rollback.sh",
        "rollback_release.sh",
        "cleanup_old_releases.sh",
        "safe_extract_release.py",
        "validate_migration_path.py",
        "preflight_env.py",
    )
    return [directory / name for name in names]


def _compose_checks(path: Path) -> list[str]:
    errors: list[str] = []
    data = yaml.safe_load(_read(path)) or {}
    services = data.get("services") or {}
    required = {
        "db",
        "migrate",
        "backend",
        "scheduler",
        "frontend",
        "proxy",
    }
    missing = sorted(required - set(services))
    if missing:
        errors.append(f"COMPOSE_SERVICES_MISSING:{missing}")
    db = services.get("db") or {}
    image = str(db.get("image") or "")
    if "postgres" not in image.lower():
        errors.append("STANDARD_POSTGRES_IMAGE_MISSING")
    proxy = services.get("proxy") or {}
    ports = {str(item) for item in proxy.get("ports") or []}
    if "80:80" not in ports or "443:443" not in ports:
        errors.append("HTTPS_PROXY_PORTS_MISSING")
    backend = services.get("backend") or {}
    if db.get("env_file"):
        errors.append("DATABASE_FULL_ENV_FORBIDDEN")
    if proxy.get("env_file"):
        errors.append("PROXY_FULL_ENV_FORBIDDEN")
    if not backend.get("env_file"):
        errors.append("BACKEND_ENV_FILE_MISSING")
    migrate = services.get("migrate") or {}
    migrate_env = migrate.get("environment") or {}
    for name in (
        "TELEGRAM_BOT_TOKEN",
        "TELEGRAM_WEBHOOK_SECRET",
        "TON_API_KEY",
        "SECRET_KEY",
        "CRON_SECRET",
    ):
        if name in migrate_env:
            errors.append(f"MIGRATE_UNNEEDED_SECRET:{name}")
    command = " ".join(str(x) for x in migrate.get("command") or [])
    if "app.release.database_bootstrap" not in command:
        errors.append("MIGRATE_BOOTSTRAP_COMMAND_MISSING")
    backend_depends = backend.get("depends_on") or {}
    migrate_dep = backend_depends.get("migrate") or {}
    if migrate_dep.get("condition") != "service_completed_successfully":
        errors.append("BACKEND_MIGRATE_DEPENDENCY_MISSING")
    scheduler = services.get("scheduler") or {}
    if scheduler.get("env_file"):
        errors.append("SCHEDULER_FULL_ENV_FILE_FORBIDDEN")
    frontend = services.get("frontend") or {}
    if frontend.get("env_file"):
        errors.append("FRONTEND_FULL_ENV_FILE_FORBIDDEN")
    scheduler_command = " ".join(
        str(x) for x in scheduler.get("command") or []
    )
    if "scheduler" not in scheduler_command:
        errors.append("SCHEDULER_SERVICE_COMMAND_MISSING")
    if not scheduler.get("healthcheck"):
        errors.append("SCHEDULER_HEALTHCHECK_MISSING")
    if db.get("ports"):
        errors.append("DATABASE_PUBLIC_PORT_FORBIDDEN")
    if backend.get("ports"):
        errors.append("BACKEND_PUBLIC_PORT_FORBIDDEN")
    for name in required:
        service = services.get(name) or {}
        logging = service.get("logging") or {}
        options = logging.get("options") or {}
        if not options.get("max-size") or not options.get("max-file"):
            errors.append(f"DOCKER_LOG_LIMIT_MISSING:{name}")
    return errors


def _dockerfile_checks(layout: dict[str, Path]) -> list[str]:
    errors: list[str] = []
    backend = _read(layout["backend_dockerfile"])
    frontend = _read(layout["frontend_dockerfile"])
    if "USER efhc" not in backend:
        errors.append("BACKEND_NON_ROOT_USER_MISSING")
    if "ops/canon_rules.yaml" not in backend:
        errors.append("BACKEND_RUNTIME_CANON_MISSING")
    if "frontend/public/skins" not in backend:
        errors.append("BACKEND_SKIN_ASSETS_MISSING")
    if "npm run build" not in frontend:
        errors.append("FRONTEND_PRODUCTION_BUILD_MISSING")
    if 'CMD ["npm", "run", "start"]' not in frontend:
        errors.append("FRONTEND_PRODUCTION_START_MISSING")
    if "USER efhc" not in frontend:
        errors.append("FRONTEND_NON_ROOT_USER_MISSING")
    if "EFHC_NEXT_BUILD_TIMEOUT_SECONDS=900" not in frontend:
        errors.append("FRONTEND_BUILD_TIMEOUT_NOT_VPS_SAFE")
    return errors


def _provider_checks(layout: dict[str, Path]) -> list[str]:
    errors: list[str] = []
    runtime = (
        layout["compose"],
        layout["backend_dockerfile"],
        layout["frontend_dockerfile"],
        layout["caddy"],
    )
    for path in runtime:
        text = _read(path).lower()
        for token in PROVIDER_TOKENS:
            if token in text:
                errors.append(
                    f"PROVIDER_LOCK_IN:{path.name}:{token}"
                )
    return errors


def _secret_checks(root: Path) -> list[str]:
    errors: list[str] = []
    forbidden_names = {
        ".env",
        ".env.prod",
        ".env.production",
        "id_rsa",
        "id_ed25519",
    }
    token_pattern = re.compile(
        r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b"
    )
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.name in forbidden_names:
            errors.append(f"FORBIDDEN_SECRET_FILE:{path}")
            continue
        if path.stat().st_size > 2_000_000:
            continue
        text = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )
        if "-----BEGIN PRIVATE KEY-----" in text:
            errors.append(f"PRIVATE_KEY_MARKER:{path}")
        if token_pattern.search(text):
            errors.append(f"TELEGRAM_TOKEN_PATTERN:{path}")
    return errors


def _shell_checks(scripts: list[Path]) -> list[str]:
    errors: list[str] = []
    for path in scripts:
        if not path.stat().st_mode & 0o111:
            errors.append(f"SCRIPT_NOT_EXECUTABLE:{path.name}")
        if path.suffix == ".py":
            try:
                compile(
                    _read(path),
                    str(path),
                    "exec",
                )
            except SyntaxError as exc:
                errors.append(
                    f"PYTHON_SYNTAX:{path.name}:{exc}"
                )
            continue
        result = subprocess.run(
            ["bash", "-n", str(path)],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode:
            errors.append(
                f"SHELL_SYNTAX:{path.name}:{result.stderr.strip()}"
            )
    return errors



def _runtime_safety_checks(root: Path, mode: str) -> list[str]:
    errors: list[str] = []
    runner = root / "backend/run.py"
    scheduler = root / "backend/app/services/scheduler_service.py"
    restore = root / "scripts/release/restore_postgres.sh"
    deploy = root / "scripts/release/deploy.sh"
    installer = root / "scripts/release/install_server.sh"
    for path in (runner, scheduler, restore, deploy, installer):
        if not path.is_file():
            errors.append(f"MISSING_RUNTIME_SAFETY_FILE:{path}")
    if errors:
        return errors
    runner_text = _read(runner)
    scheduler_text = _read(scheduler)
    if "SchedulerService" not in runner_text:
        errors.append("CANONICAL_SCHEDULER_NOT_IN_RUNNER")
    if "register_defaults(strict=True)" not in runner_text:
        errors.append("SCHEDULER_STRICT_REGISTRATION_MISSING")
    for job in (
        "generate_energy",
        "check_ton_inbox",
        "check_vip_nft",
        "archive_panels",
        "update_ranks",
        "tasks_autorestart",
        "ads_rotation",
        "reports_daily",
    ):
        if f'"{job}"' not in scheduler_text:
            errors.append(f"SCHEDULER_JOB_MISSING:{job}")
    restore_text = _read(restore)
    if "trap cleanup EXIT" in restore_text:
        errors.append("RESTORE_UNCONDITIONAL_RESTART_FORBIDDEN")
    if "remain stopped" not in restore_text:
        errors.append("RESTORE_FAIL_CLOSED_MARKER_MISSING")
    deploy_text = _read(deploy)
    order = (
        "compose build --pull migrate frontend",
        "compose up -d db",
        '"${SCRIPT_DIR}/backup_postgres.sh"',
        "run_migrations_once",
        "compose up -d --no-deps backend",
        "compose up -d --no-deps scheduler",
        "compose up -d --no-deps frontend",
        "compose up -d --no-deps proxy",
    )
    try:
        positions = [deploy_text.index(token) for token in order]
    except ValueError:
        errors.append("SAFE_DEPLOY_SEQUENCE_INCOMPLETE")
    else:
        if positions != sorted(positions):
            errors.append("SAFE_DEPLOY_SEQUENCE_INVALID")
    installer_text = _read(installer)
    if "usermod -aG docker" not in installer_text:
        errors.append("DOCKER_USER_GROUP_SETUP_MISSING")

    frontend_root = root / "frontend"
    package_path = frontend_root / "package.json"
    verifier = frontend_root / "scripts/verify-production-assets.mjs"
    asset_manifest = frontend_root / "release-assets-manifest.json"
    build_script = frontend_root / "scripts/build-next-production.mjs"
    prebuild_script = frontend_root / "scripts/prebuild.mjs"
    for path in (
        package_path,
        verifier,
        asset_manifest,
        build_script,
        prebuild_script,
    ):
        if not path.is_file():
            errors.append(
                f"FRONTEND_RELEASE_FILE_MISSING:{path.name}"
            )
    if package_path.is_file():
        package = json.loads(_read(package_path))
        scripts_map = package.get("scripts") or {}
        if "postbuild" in scripts_map:
            errors.append("FRONTEND_POSTBUILD_GATE_FORBIDDEN")
        if "verify-production-assets.mjs" not in str(
            scripts_map.get("prebuild", "")
        ) and prebuild_script.is_file():
            prebuild_text = _read(prebuild_script)
            if "verify-production-assets.mjs" not in prebuild_text:
                errors.append("FRONTEND_ASSET_VERIFY_NOT_IN_PREBUILD")
    if prebuild_script.is_file():
        prebuild_text = _read(prebuild_script)
        if "generate_faq_catalogs_from_ssot.py" in prebuild_text:
            errors.append("FRONTEND_RUNTIME_FAQ_GENERATOR_FORBIDDEN")
    if build_script.is_file():
        build_text = _read(build_script)
        if "Math.max(600" not in build_text:
            errors.append("FRONTEND_BUILD_TIMEOUT_BELOW_600")
    if asset_manifest.is_file():
        try:
            manifest = json.loads(_read(asset_manifest))
        except json.JSONDecodeError:
            errors.append("FRONTEND_RELEASE_ASSET_MANIFEST_INVALID")
        else:
            if manifest.get("schema") != (
                "EFHC_FRONTEND_RELEASE_ASSETS_V1"
            ):
                errors.append(
                    "FRONTEND_RELEASE_ASSET_MANIFEST_SCHEMA"
                )

    migration = (
        root
        / "backend/migrations/versions/0001_initial_release_schema.py"
    )
    migration_text = _read(migration)
    if "SSOT_TABLES_ORM.csv" in migration_text:
        errors.append("MIGRATION_DOCUMENT_DEPENDENCY_FORBIDDEN")
    if "expected_tables()" not in migration_text:
        errors.append("ORM_MIGRATION_CONTRACT_MISSING")
    env_path = (
        root / "env.release.example"
        if mode == "source"
        else root / ".env.example"
    )
    env_text = _read(env_path)
    for token in (
        "TELEGRAM_WEBHOOK_PATH=/api/tg/webhook",
        "TON_API_BASE_URL=https://tonapi.io",
        "TON_MAIN_WALLET=",
        "TON_NFT_COLLECTION=",
        "TON_WALLET_ADDRESS=",
    ):
        if token not in env_text:
            errors.append(f"ENV_CONTRACT_MISSING:{token}")
    if "/tg/webhook" in env_text.replace(
        "/api/tg/webhook",
        "",
    ):
        errors.append("LEGACY_WEBHOOK_PATH_PRESENT")

    settings_path = root / "backend/app/core/config_core.py"
    settings_text = _read(settings_path)
    for name in (
        "CHECK_TON_INBOX_INTERVAL_SEC",
        "CHECK_TON_INBOX_TIMEOUT_SEC",
        "TON_WATCHER_POLL_LIMIT",
        "TON_WATCHER_RETRY_LIMIT",
        "TON_RECONCILE_EVERY_TICKS",
        "TON_RECONCILE_HOURS",
    ):
        if f"{name}: int = Field(" not in settings_text:
            errors.append(f"SCHEDULER_SETTING_MISSING:{name}")

    routes_path = root / "backend/app/routes/__init__.py"
    routes_text = _read(routes_path)
    required_routes_anchor = (
        "REQUIRED_PRODUCTION_ROUTES = "
        "frozenset(ROUTERS_EXPECTED)"
    )
    if required_routes_anchor not in routes_text:
        errors.append("ALL_PRODUCTION_ROUTES_NOT_REQUIRED")
    if "OPTIONAL_PRODUCTION_ROUTES" not in routes_text:
        errors.append("OPTIONAL_ROUTE_SET_NOT_EXPLICIT")
    if "existing_schema" not in deploy_text:
        errors.append("PERSISTENT_VOLUME_BACKUP_DETECTION_MISSING")
    if "verified pre-update backup" not in deploy_text:
        errors.append("PREUPDATE_BACKUP_GATE_MISSING")

    update = root / "scripts/release/update.sh"
    rollback = root / "scripts/release/rollback_release.sh"
    extractor = root / "scripts/release/safe_extract_release.py"
    migration_validator = root / (
        "scripts/release/validate_migration_path.py"
    )
    release_lib = root / "scripts/release/lib.sh"
    policy = root / (
        "release_config/UPDATE_POLICY.json"
        if mode == "source"
        else "UPDATE_POLICY.json"
    )
    for path in (
        update,
        rollback,
        extractor,
        migration_validator,
        release_lib,
        policy,
    ):
        if not path.is_file():
            errors.append(f"UPDATE_CONTRACT_FILE_MISSING:{path.name}")
    if (
        update.is_file()
        and extractor.is_file()
        and release_lib.is_file()
    ):
        update_text = _read(update)
        extractor_text = _read(extractor)
        lib_text = _read(release_lib)
        modular_guards = {
            "safe_extract_release.py": update_text,
            "validate_migration_path.py": update_text,
            "flock -n": update_text,
            "deploy.sh": update_text,
            "atomic_symlink": update_text,
            "update-state.json": update_text,
            "SHA-256 mismatch": extractor_text + lib_text,
            "mv -Tf": lib_text,
            "supported_database_revisions": update_text,
            "target_database_revision": update_text,
            "CREATE_PREUPDATE_BACKUP": update_text,
        }
        for token, text in modular_guards.items():
            if token not in text:
                errors.append(f"UPDATE_GUARD_MISSING:{token}")
    if rollback.is_file():
        rollback_text = _read(rollback)
        for token in (
            "application_rollback_supported",
            "database_restore_required",
            "rollback_images.sh",
            "atomic_symlink",
            "database_restored",
        ):
            if token not in rollback_text:
                errors.append(f"ROLLBACK_GUARD_MISSING:{token}")
    if policy.is_file():
        try:
            update_policy = json.loads(_read(policy))
        except json.JSONDecodeError:
            errors.append("UPDATE_POLICY_INVALID_JSON")
        else:
            if update_policy.get("archive_mode") != (
                "FULL_RELEASE_ARCHIVE"
            ):
                errors.append("UPDATE_POLICY_NOT_FULL_ARCHIVE")
            if update_policy.get("database_migration_class") not in {
                "BACKWARD_COMPATIBLE",
                "REQUIRES_DATABASE_RESTORE",
                "IRREVERSIBLE_WITHOUT_MANUAL_PLAN",
                "CONTROLLED_REVERSIBLE_SCHEMA_RENAME",
                "PRE_RELEASE_MIGRATION_SQUASH",
                "GLOBAL_ID_CUTOVER_PREPARATION",
            }:
                errors.append("UPDATE_POLICY_MIGRATION_CLASS_INVALID")
            policy_mode = update_policy.get("update_policy")
            migration_mode = update_policy.get(
                "database_migration_policy"
            )
            allowed_modes = {
                (
                    "compatible_source_range",
                    "cumulative_forward",
                ),
                (
                    "pre_release_schema_freeze",
                    "single_initial_release_schema",
                ),
                (
                    "pre_release_schema_freeze",
                    "cumulative_release_migrations",
                ),
            }
            if (policy_mode, migration_mode) not in allowed_modes:
                errors.append("UPDATE_POLICY_MODE_INVALID")
            if not update_policy.get(
                "minimum_supported_source_version"
            ):
                errors.append("UPDATE_POLICY_MINIMUM_SOURCE_MISSING")
            if not update_policy.get("supported_database_revisions"):
                errors.append(
                    "UPDATE_POLICY_DATABASE_REVISIONS_MISSING"
                )
            if not update_policy.get("target_database_revision"):
                errors.append(
                    "UPDATE_POLICY_TARGET_DATABASE_REVISION_MISSING"
                )
    return errors


def _release_purity_checks(root: Path) -> list[str]:
    """Проверить отсутствие tests и CI evidence в production ZIP."""

    errors: list[str] = []
    forbidden_exact = {
        "requirements-test.txt",
        "pytest.ini",
        "pyproject.toml",
        ".flake8",
        "RELEASE_CI_PROFILE.json",
    }
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        rel = relative.as_posix()
        lower_name = path.name.casefold()
        if relative.parts and relative.parts[0] in {
            "tests",
            "test",
            "e2e",
        }:
            errors.append(f"RELEASE_TEST_CONTENT_FORBIDDEN:{rel}")
        elif path.name in forbidden_exact:
            errors.append(f"RELEASE_TEST_TOOLING_FORBIDDEN:{rel}")
        elif lower_name.startswith("test_") or lower_name.endswith(
            (".test.ts", ".test.tsx", ".spec.ts", ".spec.tsx")
        ):
            errors.append(f"RELEASE_TEST_FILE_FORBIDDEN:{rel}")
    return errors


def validate(root: Path, mode: str) -> dict[str, Any]:
    layout = (
        _source_layout(root)
        if mode == "source"
        else _release_layout(root)
    )
    required = list(layout.values())[:-1]
    scripts = _required_scripts(layout["scripts"])
    required.extend(scripts)
    missing = [
        str(path.relative_to(root))
        for path in required
        if not path.exists()
    ]
    errors = [f"MISSING:{item}" for item in missing]
    if not missing:
        errors.extend(_compose_checks(layout["compose"]))
        errors.extend(_dockerfile_checks(layout))
        errors.extend(_provider_checks(layout))
        errors.extend(_shell_checks(scripts))
        errors.extend(_runtime_safety_checks(root, mode))
    if mode == "release":
        errors.extend(_secret_checks(root))
        errors.extend(_release_purity_checks(root))
    return {
        "schema": "EFHC_PROVIDER_PORTABILITY_GATE_V1",
        "mode": mode,
        "root": str(root),
        "provider_independent": not errors,
        "errors": errors,
        "required_files": len(required),
        "external_live_proof": "DEFERRED_POST_RELEASE_BY_USER",
        "production_release_ready": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(
        "--mode",
        choices=("source", "release"),
        default="source",
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    report = validate(root, args.mode)
    payload = json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
    )
    print(payload)
    if args.output:
        output = args.output
        if not output.is_absolute():
            output = ROOT / output
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(payload + "\n", encoding="utf-8")
    return 0 if report["provider_independent"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
