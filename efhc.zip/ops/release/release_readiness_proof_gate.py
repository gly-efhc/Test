"""Release readiness proof gate for external evidence.

The gate is fail-closed. It records local archive proof, but it must not
claim release readiness without external live evidence.
"""

from __future__ import annotations

import argparse
import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
ADMIN_VISUAL_REPORT = (
    "reports/generated/browser_admin_visual_runtime_guard_v170_96.json"
)
PUBLIC_VISUAL_REPORT = (
    "reports/generated/public_pages_browser_proof_v170_96.json"
)
I18N_CLOSURE_REPORT = (
    "reports/generated/frontend_i18n_visual_closure_v170_96.json"
)
LOCAL_REQUIRED_REPORTS = {
    "admin_visual_runtime": ADMIN_VISUAL_REPORT,
    "public_pages_visual": PUBLIC_VISUAL_REPORT,
    "frontend_i18n_visual_closure": I18N_CLOSURE_REPORT,
}

LIVE_TELEGRAM_ENV = (
    "EFHC_LIVE_BASE_URL",
    "EFHC_LIVE_TWA_URL",
    "TELEGRAM_BOT_TOKEN",
    "TELEGRAM_WEBHOOK_SECRET",
)

REAL_TONCONNECT_ENV = (
    "EFHC_LIVE_BASE_URL",
    "NEXT_PUBLIC_TON_RPC_ENDPOINT",
    "TON_WALLET",
    "PAYMENTS_RECEIVER_ADDRESS",
)

OPTIONAL_REAL_TONCONNECT_ENV = (
    "TON_API_KEY",
    "TON_API_BASE_URL",
)

FORBIDDEN_SECRET_SUBSTRINGS = (
    "xoxb-",
    "bot_token_live_",
    "postgresql://postgres:",
    "postgresql+asyncpg://postgres:",
    "Bearer ",
)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"status": "MISSING"}
    except json.JSONDecodeError as exc:
        return {"status": "INVALID_JSON", "error": str(exc)}


def _env_presence(names: tuple[str, ...]) -> dict[str, bool]:
    return {name: bool(os.environ.get(name)) for name in names}


def _status_from_env(required: dict[str, bool]) -> str:
    if all(required.values()):
        return "READY_FOR_MANUAL_EXTERNAL_PROOF"
    return "BLOCKED_MISSING_ENV"


def _local_report_status(path: str) -> dict[str, Any]:
    report_path = ROOT / path
    payload = _read_json(report_path)
    status = str(payload.get("status", "UNKNOWN"))
    if status in {"PASSED", "DONE_LOCALLY"}:
        gate_status = "PASSED"
    elif status in {"MISSING", "INVALID_JSON"}:
        gate_status = status
    else:
        gate_status = "PRESENT_NOT_PASSED"
    return {
        "path": path,
        "gate_status": gate_status,
        "reported_status": status,
    }


def _scan_for_committed_secret_markers() -> list[str]:
    findings: list[str] = []
    roots = [ROOT / "env.prod.example", ROOT / "env.example"]
    for path in roots:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for marker in FORBIDDEN_SECRET_SUBSTRINGS:
            if marker in text:
                findings.append(f"{path.name}:{marker}")
    return findings


def build_report(
    *,
    cycle: int = 1521,
    input_head: str = "v170.96",
    output_target: str = "v170.97",
    fresh_ci_status: str = "NOT_PROVIDED_FOR_V170_96",
) -> dict[str, Any]:
    local_reports = {
        name: _local_report_status(path)
        for name, path in LOCAL_REQUIRED_REPORTS.items()
    }
    live_telegram_env = _env_presence(LIVE_TELEGRAM_ENV)
    real_tonconnect_env = _env_presence(REAL_TONCONNECT_ENV)
    optional_tonconnect = _env_presence(OPTIONAL_REAL_TONCONNECT_ENV)
    live_telegram_status = _status_from_env(live_telegram_env)
    real_tonconnect_status = _status_from_env(real_tonconnect_env)
    local_ok = all(
        item["gate_status"] == "PASSED"
        for item in local_reports.values()
    )
    committed_secrets = _scan_for_committed_secret_markers()
    external_ok = (
        live_telegram_status == "READY_FOR_MANUAL_EXTERNAL_PROOF"
        and real_tonconnect_status == "READY_FOR_MANUAL_EXTERNAL_PROOF"
    )
    release_blockers = []
    if not local_ok:
        release_blockers.append("LOCAL_REQUIRED_REPORTS_NOT_ALL_PASSED")
    if not external_ok:
        release_blockers.append("LIVE_EXTERNAL_PROOF_NOT_EXECUTED")
    if committed_secrets:
        release_blockers.append("COMMITTED_SECRET_MARKER_RISK")
    release_blockers.append("FRESH_GITHUB_CI_PROOF_NOT_PROVIDED")
    return {
        "schema": "EFHC_LIVE_RELEASE_READINESS_GATE_V1",
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "cycle": cycle,
        "input_head": input_head,
        "output_target": output_target,
        "mode": "fail_closed_external_proof_gate",
        "local_reports": local_reports,
        "live_telegram_proof": {
            "status": live_telegram_status,
            "required_env_present": live_telegram_env,
            "executed": False,
            "secret_values_recorded": False,
        },
        "real_tonconnect_proof": {
            "status": real_tonconnect_status,
            "required_env_present": real_tonconnect_env,
            "optional_env_present": optional_tonconnect,
            "executed": False,
            "secret_values_recorded": False,
        },
        "fresh_github_ci_proof": {
            "status": fresh_ci_status,
            "executed": False,
        },
        "secret_hygiene": {
            "committed_secret_marker_findings": committed_secrets,
            "status": "PASS" if not committed_secrets else "REVIEW",
        },
        "release_ready": False,
        "release_readiness_status": "NOT_RELEASE_READY",
        "release_blockers": release_blockers,
        "forbidden_claims": [
            "GITHUB_CI_GREEN",
            "LIVE_TELEGRAM_VERIFIED",
            "REAL_TONCONNECT_VERIFIED",
            "RELEASE_READY",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cycle", type=int, default=1521)
    parser.add_argument("--input-head", default="v170.96")
    parser.add_argument("--output-target", default="v170.97")
    parser.add_argument(
        "--fresh-ci-status",
        default="NOT_PROVIDED_FOR_V170_96",
    )
    parser.add_argument(
        "--output",
        default=(
            "reports/generated/"
            "live_release_readiness_gate_v170_97.json"
        ),
    )
    args = parser.parse_args()
    report = build_report(
        cycle=args.cycle,
        input_head=args.input_head,
        output_target=args.output_target,
        fresh_ci_status=args.fresh_ci_status,
    )
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
