#!/usr/bin/env python3
"""Validate a rollback archive before any deployment mutation."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

REQUIRED = (
    "KERNEL.md",
    "backend/migrations/versions/0001_initial_release_schema.py",
    "frontend/package-lock.json",
    "ops/k8s/backend-deployment.yaml",
)
FORBIDDEN_PARTS = (
    "node_modules/",
    ".next/",
    "__pycache__/",
    ".pytest_cache/",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_archive(path: Path) -> dict[str, object]:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        names = set(archive.namelist())
    missing = [item for item in REQUIRED if item not in names]
    forbidden = [
        item
        for item in names
        if any(part in item for part in FORBIDDEN_PARTS)
    ]
    return {
        "ok": bad is None and not missing and not forbidden,
        "sha256": _sha256(path),
        "zip_test": bad or "OK",
        "records": len(names),
        "missing": missing,
        "forbidden": forbidden[:50],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = inspect_archive(args.archive)
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
