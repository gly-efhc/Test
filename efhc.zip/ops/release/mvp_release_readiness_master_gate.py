"""Validate the EFHC MVP release-readiness master plan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_PLAN = (
    ROOT / "reports/generated/"
    "mvp_release_readiness_master_plan_v171_46.json"
)
ALLOWED_STATUSES = {"VERIFIED", "PARTIAL", "OPEN", "EXTERNAL"}


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_plan(data: dict[str, Any]) -> dict[str, Any]:
    domains = list(data.get("domains") or [])
    items = [item for domain in domains for item in domain["items"]]
    domain_points = sum(int(domain["weight"]) for domain in domains)
    item_points = sum(int(item["points"]) for item in items)
    verified_points = sum(
        int(item["points"])
        for item in items
        if item["status"] == "VERIFIED"
    )
    critical_open = [
        str(item["id"])
        for item in items
        if bool(item["critical"]) and item["status"] != "VERIFIED"
    ]
    invalid_statuses = sorted(
        {
            str(item["status"])
            for item in items
            if item["status"] not in ALLOWED_STATUSES
        }
    )
    duplicate_ids = sorted(
        {
            str(item["id"])
            for item in items
            if sum(1 for row in items if row["id"] == item["id"]) > 1
        }
    )
    required = data["target"]
    score_ok = verified_points >= int(
        required["readiness_points_required"]
    )
    ready_99 = (
        score_ok
        and not critical_open
        and bool(required["no_open_p0"])
        and bool(required["no_mvp_blocking_p1"])
        and bool(required["fresh_github_ci_required"])
        and bool(required["live_telegram_required"])
        and bool(required["real_tonconnect_required"])
        and bool(required["archive_hygiene_required"])
    )
    errors: list[str] = []
    if data.get("schema") != (
        "EFHC_MVP_RELEASE_READINESS_MASTER_PLAN_V1"
    ):
        errors.append("INVALID_SCHEMA")
    if domain_points != 100:
        errors.append("DOMAIN_POINTS_NOT_100")
    if item_points != 100:
        errors.append("ITEM_POINTS_NOT_100")
    if invalid_statuses:
        errors.append("INVALID_STATUS")
    if duplicate_ids:
        errors.append("DUPLICATE_ITEM_ID")
    if (
        data.get("baseline", {}).get("verified_evidence_points")
        != verified_points
    ):
        errors.append("BASELINE_SCORE_DRIFT")
    return {
        "plan_valid": not errors,
        "errors": errors,
        "domain_points": domain_points,
        "item_points": item_points,
        "verified_evidence_points": verified_points,
        "critical_items_not_verified": critical_open,
        "invalid_statuses": invalid_statuses,
        "duplicate_ids": duplicate_ids,
        "release_ready_99_percent": ready_99,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--require-99", action="store_true")
    args = parser.parse_args()
    path = args.plan
    if not path.is_absolute():
        path = ROOT / path
    report = validate_plan(_read(path))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["plan_valid"]:
        return 2
    if args.require_99 and not report["release_ready_99_percent"]:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
