"""Generate immutable frontend assets before release packaging."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

LANGUAGES = (
    "ru",
    "en",
    "uk",
    "de",
    "fr",
    "es",
    "it",
    "tr",
    "pl",
    "da",
    "hi",
    "id",
    "sw",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def prepare_assets(root: Path, version: str) -> dict[str, object]:
    """Generate FAQ/PWA files and their embedded integrity manifest."""
    root = root.resolve()
    frontend = root / "frontend"
    generator = root / "ops/scripts/generate_faq_catalogs_from_ssot.py"
    node = shutil.which("node")
    if not generator.is_file():
        raise RuntimeError(f"FAQ generator is missing: {generator}")
    if not node:
        raise RuntimeError("Node.js is required for release packaging")

    subprocess.run(
        [sys.executable, str(generator)],
        cwd=root,
        check=True,
    )
    subprocess.run(
        [node, "scripts/generate-pwa-build.mjs"],
        cwd=frontend,
        check=True,
    )

    relative_paths = [
        Path("src/data/faq/catalogs.ts"),
        Path("public/pwa-build.json"),
        Path(".efhc-build-id"),
    ]
    relative_paths.extend(
        Path("public/faq") / f"{language}.json"
        for language in LANGUAGES
    )
    relative_paths.extend(
        Path("public/locale") / f"{language}.json"
        for language in LANGUAGES
    )

    files: dict[str, list[str]] = {}
    for relative in relative_paths:
        path = frontend / relative
        if not path.is_file():
            raise RuntimeError(
                "required frontend asset missing: "
                + str(relative)
            )
        digest = _sha256(path)
        files[relative.as_posix()] = [digest[:32], digest[32:]]

    payload: dict[str, object] = {
        "schema": "EFHC_FRONTEND_RELEASE_ASSETS_V1",
        "version": version,
        "generated_at": "release_packaging",
        "runtime_dependencies": ["nodejs"],
        "packaging_source": "canonical FAQ source (development only)",
        "files": dict(sorted(files.items())),
    }
    manifest = frontend / "release-assets-manifest.json"
    manifest.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--version", required=True)
    args = parser.parse_args()
    payload = prepare_assets(args.root, args.version)
    print(
        json.dumps(
            {
                "status": "PASS",
                "version": args.version,
                "files": len(payload["files"]),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
