#!/usr/bin/env python3
"""Собирает development ZIP.

Все не-ASCII имена записываются с переносимым UTF-8-флагом.
"""

from __future__ import annotations

import argparse
import stat
import zipfile
from pathlib import Path

MOJIBAKE_MARKERS = (
    "Γ",
    "╬",
    "├",
    "┬",
    "╞",
    "╢",
    "╣",
    "╜",
    "╨",
    "╤",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def validate_path(root: Path, path: Path) -> str:
    rel = path.relative_to(root).as_posix()
    if any(marker in rel for marker in MOJIBAKE_MARKERS):
        raise ValueError(
            f"Повреждённое имя файла: {rel}"
        )
    if path.is_symlink():
        raise ValueError(
            f"Символическая ссылка запрещена: {rel}"
        )
    mode = path.lstat().st_mode
    if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
        raise ValueError(
            f"Специальный файл запрещён: {rel}"
        )
    return rel


def build_archive(root: Path, output: Path) -> None:
    root = root.resolve(strict=True)
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)

    paths = sorted(root.rglob("*"), key=lambda item: item.as_posix())
    with zipfile.ZipFile(
        output,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        strict_timestamps=False,
    ) as archive:
        for path in paths:
            rel = validate_path(root, path)
            if path.is_dir():
                info = zipfile.ZipInfo.from_file(path, f"{rel}/")
                info.compress_type = zipfile.ZIP_STORED
                archive.writestr(info, b"")
                continue
            info = zipfile.ZipInfo.from_file(path, rel)
            info.compress_type = zipfile.ZIP_DEFLATED
            with path.open("rb") as source:
                archive.writestr(info, source.read())

    verify_archive(output)


def verify_archive(output: Path) -> None:
    with zipfile.ZipFile(output) as archive:
        names: set[str] = set()
        for info in archive.infolist():
            if info.filename in names:
                raise ValueError(
                    f"Повтор имени в ZIP: {info.filename}"
                )
            names.add(info.filename)
            if (
                any(ord(char) > 127 for char in info.filename)
                and not info.flag_bits & 0x800
            ):
                raise ValueError(
                    "Нет UTF-8-флага у имени: " + info.filename
                )
            if any(
                marker in info.filename for marker in MOJIBAKE_MARKERS
            ):
                raise ValueError(
                    "Mojibake-имя попало в ZIP: "
                    + info.filename
                )
        broken = archive.testzip()
        if broken is not None:
            raise ValueError(f"CRC не прошёл для: {broken}")


def main() -> int:
    args = parse_args()
    build_archive(args.root, args.output)
    print(f"UTF-8 ZIP собран и проверен: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
