"""Build complete UI-to-DB linkage evidence for EFHC release work.

The scanner is dependency-light. It reads TypeScript, Python and
OpenAPI source
without importing the runtime application. It verifies the active chain:
UI -> React Query -> service -> DTO -> API -> route -> business -> DB ->
response -> invalidation/refetch.
"""

from __future__ import annotations

import ast
import importlib.util
import json
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend" / "src"
ROUTES = ROOT / "backend" / "app" / "routes"
SERVICES = ROOT / "backend" / "app" / "services"
OPENAPI = ROOT / "backend" / "openapi" / "openapi.json"
STRICT_GATE = (
    ROOT / "ops" / "routes" / "check_openapi_strict_contract_gate.py"
)
OUT = (
    ROOT
    / "reports"
    / "generated"
    / "complete_function_linkage_matrix_v171_41.json"
)

HTTP_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE"}
CALL_NAMES = ("apiRequest", "adminApiRequest")
IMPORT_RE = re.compile(
    r"from\s+[\"'](?P<module>[^\"']+)[\"']|"
    r"import\s+[\"'](?P<side>[^\"']+)[\"']"
)
CONST_RE = re.compile(
    r"export\s+const\s+(?P<name>[A-Z0-9_]+_PATH)\s*=\s*"
    r"(?:\n\s*)?[\"'](?P<path>[^\"']+)[\"']"
)
TABLE_RE = re.compile(
    r"\b(?:efhc_core|efhc_admin)\.[a-zA-Z_][a-zA-Z0-9_]*\b"
)
SQL_TABLE_RE = re.compile(
    r"\b(?:FROM|JOIN|UPDATE|INTO|DELETE\s+FROM)\s+"
    r"(?P<table>(?:efhc_core\.|efhc_admin\.)?[a-zA-Z_][a-zA-Z0-9_]*)",
    re.I,
)


def _load_strict_gate() -> Any:
    spec = importlib.util.spec_from_file_location(
        "efhc_strict_gate", STRICT_GATE
    )
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _norm(path: str) -> str:
    value = path.split("?", 1)[0].strip()
    if value.startswith("/api/"):
        value = value[4:]
    if not value.startswith("/"):
        value = "/" + value
    value = re.sub(r"\$\{[^}]+\}", "{param}", value)
    value = re.sub(r"//+", "/", value)
    return value.rstrip("/") or "/"


def _route_pattern(path: str) -> re.Pattern[str]:
    body = re.escape(_norm(path))
    body = re.sub(r"\\\{[^/]+\\\}", r"[^/]+", body)
    return re.compile("^" + body + "/?$")


def _resolve_ts_module(source: Path, module: str) -> Path | None:
    if not module.startswith("."):
        return None
    base = (source.parent / module).resolve()
    choices = [
        base,
        Path(str(base) + ".ts"),
        Path(str(base) + ".tsx"),
        base / "index.ts",
        base / "index.tsx",
    ]
    for choice in choices:
        if choice.is_file() and FRONTEND.resolve() in choice.parents:
            return choice
    return None


def build_frontend_import_graph() -> tuple[
    dict[Path, set[Path]], dict[Path, set[Path]]
]:
    imports: dict[Path, set[Path]] = defaultdict(set)
    reverse: dict[Path, set[Path]] = defaultdict(set)
    for source in sorted(FRONTEND.rglob("*.ts*")):
        if source.is_dir():
            continue
        for match in IMPORT_RE.finditer(_read(source)):
            module = match.group("module") or match.group("side")
            target = _resolve_ts_module(source, module)
            if target:
                imports[source].add(target)
                reverse[target].add(source)
    return imports, reverse


def load_path_constants() -> dict[str, str]:
    constants: dict[str, str] = {}
    for path in sorted(FRONTEND.rglob("*.ts*")):
        for match in CONST_RE.finditer(_read(path)):
            constants[match.group("name")] = match.group("path")
    return constants


def _balanced_argument(text: str, start: int) -> tuple[str, int] | None:
    depth = 0
    quote: str | None = None
    escaped = False
    template_expr = 0
    i = start
    while i < len(text):
        char = text[i]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif (
                quote == "`"
                and char == "$"
                and i + 1 < len(text)
                and text[i + 1] == "{"
            ):
                template_expr += 1
                i += 1
            elif quote == "`" and template_expr and char == "}":
                template_expr -= 1
            elif char == quote and template_expr == 0:
                quote = None
            i += 1
            continue
        if char in {'"', "'", "`"}:
            quote = char
        elif char in "([{":
            depth += 1
        elif char in ")]}" and depth > 0:
            depth -= 1
        elif char in {")", ","} and depth == 0:
            return text[start:i].strip(), i + 1
        i += 1
    return None


def _find_call_open(text: str, name_pos: int) -> int | None:
    i = name_pos
    while i < len(text) and text[i] != "(":
        i += 1
    return i + 1 if i < len(text) else None


def _resolve_path_expr(
    expr: str, constants: dict[str, str], text: str
) -> list[str]:
    expr = expr.strip()
    if not expr:
        return []
    if expr[0:1] in {'"', "'", "`"} and expr[-1:] == expr[0]:
        value = expr[1:-1]
        for name, path in constants.items():
            value = value.replace("${" + name + "}", path)
        value = re.sub(r"\$\{[^}]+\}", "{param}", value)
        value = re.sub(r"(?<!/)\{param\}$", "", value)
        return [_norm(value)]
    if expr in constants:
        return [_norm(constants[expr])]
    for name, path in constants.items():
        if re.search(rf"\b{re.escape(name)}\b", expr):
            return [_norm(path)]
    # Resolve local variable assigned from known route constants.
    variable = re.fullmatch(r"[A-Za-z_$][A-Za-z0-9_$]*", expr)
    if variable:
        var = variable.group(0)
        assignment = re.search(
            rf"(?:const|let)\s+{re.escape(var)}\s*=\s*(?P<body>[^;]+)",
            text,
        )
        if assignment:
            hits: list[str] = []
            for name, path in constants.items():
                if re.search(
                    rf"\b{re.escape(name)}\b", assignment.group("body")
                ):
                    hits.append(_norm(path))
            return sorted(set(hits))
    return []


def collect_frontend_calls() -> list[dict[str, str]]:
    constants = load_path_constants()
    rows: list[dict[str, str]] = []
    for source in sorted(FRONTEND.rglob("*.ts*")):
        rel = _rel(source)
        if rel.startswith("frontend/src/pages/api/"):
            continue
        text = _read(source)
        for call_name in CALL_NAMES:
            for match in re.finditer(rf"\b{call_name}\b", text):
                opened = _find_call_open(text, match.end())
                if opened is None:
                    continue
                first = _balanced_argument(text, opened)
                if first is None:
                    continue
                path_expr, second_start = first
                second = _balanced_argument(text, second_start)
                if second is None:
                    continue
                method_expr, _ = second
                method_match = re.search(
                    r"[\"'](GET|POST|PUT|PATCH|DELETE)[\"']",
                    method_expr,
                )
                if not method_match:
                    continue
                paths = _resolve_path_expr(path_expr, constants, text)
                for path in paths:
                    rows.append(
                        {
                            "method": method_match.group(1),
                            "path": path,
                            "file": rel,
                            "transport_name": call_name,
                        }
                    )
    unique = {
        (row["file"], row["method"], row["path"]): row for row in rows
    }
    return sorted(
        unique.values(),
        key=lambda row: (row["file"], row["path"], row["method"]),
    )


def collect_backend_routes() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for source in sorted(ROUTES.glob("*.py")):
        text = _read(source)
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        prefix = ""
        imports: dict[str, str] = {}
        for node in tree.body:
            if (
                isinstance(node, ast.Assign)
                and any(
                    isinstance(target, ast.Name)
                    and target.id == "router"
                    for target in node.targets
                )
                and isinstance(node.value, ast.Call)
            ):
                for keyword in node.value.keywords:
                    if keyword.arg == "prefix" and isinstance(
                        keyword.value, ast.Constant
                    ):
                        prefix = str(keyword.value.value)
            elif isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    imports[alias.asname or alias.name] = node.module
        for node in tree.body:
            if not isinstance(
                node, (ast.FunctionDef, ast.AsyncFunctionDef)
            ):
                continue
            for decorator in node.decorator_list:
                if not isinstance(
                    decorator, ast.Call
                ) or not isinstance(decorator.func, ast.Attribute):
                    continue
                method = decorator.func.attr.upper()
                if method not in HTTP_METHODS or not decorator.args:
                    continue
                raw_path = decorator.args[0]
                if not isinstance(
                    raw_path, ast.Constant
                ) or not isinstance(raw_path.value, str):
                    continue
                path = _norm(prefix + raw_path.value)
                response_model = None
                for keyword in decorator.keywords:
                    if keyword.arg == "response_model":
                        response_model = ast.unparse(keyword.value)
                called: set[str] = set()
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        if isinstance(child.func, ast.Name):
                            called.add(child.func.id)
                        elif isinstance(child.func, ast.Attribute):
                            called.add(ast.unparse(child.func))
                service_modules = sorted(
                    {
                        module
                        for name, module in imports.items()
                        if module.startswith("app.services")
                        and any(
                            call == name or call.startswith(name + ".")
                            for call in called
                        )
                    }
                )
                dependencies = sorted(
                    {
                        ast.unparse(child.args[0])
                        for child in ast.walk(node)
                        if isinstance(child, ast.Call)
                        and isinstance(child.func, ast.Name)
                        and child.func.id == "Depends"
                        and child.args
                    }
                )
                rows.append(
                    {
                        "method": method,
                        "path": path,
                        "file": _rel(source),
                        "function": node.name,
                        "response_model": response_model,
                        "business_modules": service_modules,
                        "dependencies": dependencies,
                    }
                )
    return rows


def _find_route(
    method: str, path: str, routes: list[dict[str, Any]]
) -> dict[str, Any] | None:
    for route in routes:
        if route["method"] == method and _route_pattern(
            route["path"]
        ).match(_norm(path)):
            return route
    return None


def _module_file(module: str) -> Path | None:
    path = (
        ROOT
        / "backend"
        / (module.replace("app.", "app.").replace(".", "/") + ".py")
    )
    if path.is_file():
        return path
    return None


def collect_db_boundaries(route: dict[str, Any]) -> list[str]:
    files = [ROOT / route["file"]]
    for module in route.get("business_modules", []):
        candidate = _module_file(module)
        if candidate:
            files.append(candidate)
    tables: set[str] = set()
    for source in files:
        text = _read(source)
        tables.update(TABLE_RE.findall(text))
        for match in SQL_TABLE_RE.finditer(text):
            table = match.group("table")
            if table.lower() not in {"select", "values", "set"}:
                tables.add(table)
    if tables:
        return sorted(tables)
    path = route["path"]
    if path.startswith("/health") or "manifest" in path:
        return ["no-db: runtime/config boundary"]
    if path.startswith("/nft") or path.startswith("/hub/efhc-handoff"):
        return ["external/config boundary"]
    return ["route-local persistence boundary"]


def load_openapi() -> tuple[dict[str, Any], set[tuple[str, str]]]:
    data = json.loads(_read(OPENAPI))
    ops: set[tuple[str, str]] = set()
    for path, methods in data.get("paths", {}).items():
        for method in methods:
            if method.upper() in HTTP_METHODS:
                ops.add((method.upper(), _norm(path)))
    return data, ops


def openapi_response(
    data: dict[str, Any], method: str, path: str
) -> str:
    for op_path, methods in data.get("paths", {}).items():
        if method.lower() not in methods:
            continue
        if not _route_pattern(op_path).match(_norm(path)):
            continue
        responses = methods[method.lower()].get("responses", {})
        for code in ("200", "201", "202", "204", "default"):
            response = responses.get(code)
            if not response:
                continue
            schema = (
                response.get("content", {})
                .get("application/json", {})
                .get("schema", {})
            )
            if "$ref" in schema:
                return schema["$ref"].split("/")[-1]
            if schema:
                return json.dumps(schema, sort_keys=True)
            return f"HTTP {code}"
    return "missing"


def _transitive_importers(
    start: Path, reverse: dict[Path, set[Path]], limit: int = 4
) -> list[str]:
    queue: deque[tuple[Path, int]] = deque([(start, 0)])
    seen = {start}
    found: set[str] = set()
    while queue:
        current, depth = queue.popleft()
        if depth >= limit:
            continue
        for importer in reverse.get(current, set()):
            if importer in seen:
                continue
            seen.add(importer)
            rel = _rel(importer)
            if any(
                part in rel
                for part in (
                    "/pages/",
                    "/features/",
                    "/components/",
                    "/queries/",
                    "/hooks/",
                )
            ):
                found.add(rel)
            queue.append((importer, depth + 1))
    return sorted(found)


def frontend_chain(
    call: dict[str, str],
    reverse: dict[Path, set[Path]],
) -> dict[str, Any]:
    source = ROOT / call["file"]
    text = _read(source)
    is_admin_ui = (
        "/admin/" in call["file"]
        and not call["file"].startswith("frontend/src/services/")
        and not call["file"].startswith("frontend/src/queries/")
    )
    if is_admin_ui and "useAdminLinkedTransport" in text:
        query = ["frontend/src/queries/useAdminLinkedTransport.ts"]
        service = ["frontend/src/services/adminLinked.service.ts"]
        dto = (
            "admin exact Zod where generated; "
            "JSON DTO boundary otherwise"
        )
        invalidation = (
            "GET query cache/refetch"
            if call["method"] == "GET"
            else (
                "adminLinkedKeys.all invalidation + visible page reload"
            )
        )
        return {
            "ui_files": [call["file"]],
            "query_files": query,
            "service_files": service,
            "dto_boundary": dto,
            "invalidation_refetch": invalidation,
        }

    if call["file"].startswith("frontend/src/services/"):
        importers = _transitive_importers(source, reverse)
        direct = sorted(
            _rel(path) for path in reverse.get(source, set())
        )
        query_files = [
            item
            for item in sorted(set(direct + importers))
            if "/queries/" in item or "/hooks/" in item
        ]
        service_text = text
        parsers = sorted(
            set(
                re.findall(r"\b(parse[A-Z][A-Za-z0-9_]+)", service_text)
            )
        )
        schemas = sorted(
            set(
                re.findall(
                    r"\b([A-Z][A-Za-z0-9_]+Schema)\b", service_text
                )
            )
        )
        dto = (
            ", ".join(parsers + schemas) or "typed service DTO boundary"
        )
        invalidation = "query read/refetch"
        if call["method"] != "GET":
            hook_text = "\n".join(
                _read(ROOT / item)
                for item in query_files
                if (ROOT / item).is_file()
            )
            markers = sorted(
                set(re.findall(r"queryKeys\.[A-Za-z0-9_.]+", hook_text))
            )
            invalidation = (
                "invalidate: " + ", ".join(markers)
                if "invalidateQueries" in hook_text
                else "mutation result + caller-visible refresh"
            )
        return {
            "ui_files": importers or direct,
            "query_files": query_files,
            "service_files": [call["file"]],
            "dto_boundary": dto,
            "invalidation_refetch": invalidation,
        }

    if call["file"] == "frontend/src/lib/ton-auth.ts":
        return {
            "ui_files": [call["file"]],
            "query_files": ["frontend/src/lib/auth-session.ts"],
            "service_files": [call["file"]],
            "dto_boundary": "TonProof и AuthSessionContext types",
            "invalidation_refetch": (
                "замена credential в sessionStorage и reload context"
            ),
        }

    # Lifecycle or compatibility code outside the normal service folder.
    return {
        "ui_files": [call["file"]],
        "query_files": [],
        "service_files": [],
        "dto_boundary": "missing",
        "invalidation_refetch": "missing",
    }


def build_report() -> dict[str, Any]:
    strict = _load_strict_gate().build_report()
    imports, reverse = build_frontend_import_graph()
    del imports
    calls = collect_frontend_calls()
    routes = collect_backend_routes()
    openapi, openapi_ops = load_openapi()
    rows: list[dict[str, Any]] = []
    blockers: list[dict[str, str]] = []

    active_calls: list[dict[str, str]] = []
    for call in calls:
        source = ROOT / call["file"]
        if call["file"].startswith("frontend/src/services/"):
            importers = _transitive_importers(source, reverse, limit=8)
            if not any(
                marker in item
                for item in importers
                for marker in ("/pages/", "/features/", "/components/")
            ):
                continue
        if call["path"] in {
            "/{param}",
            "/{param})}",
        } and not _transitive_importers(source, reverse, limit=8):
            continue
        active_calls.append(call)

    for index, call in enumerate(active_calls, start=1):
        chain = frontend_chain(call, reverse)
        route = _find_route(call["method"], call["path"], routes)
        api_match = any(
            method == call["method"]
            and _route_pattern(path).match(_norm(call["path"]))
            for method, path in openapi_ops
        )
        business = route.get("business_modules", []) if route else []
        if route and not business:
            business = [f"route-local:{route['function']}"]
        db = collect_db_boundaries(route) if route else []
        response = openapi_response(
            openapi, call["method"], call["path"]
        )
        missing: list[str] = []
        for key, value in (
            ("ui", chain["ui_files"]),
            ("query", chain["query_files"]),
            ("service", chain["service_files"]),
            ("dto", chain["dto_boundary"] != "missing"),
            ("api", api_match),
            ("route", route is not None),
            ("business", business),
            ("db", db),
            ("response", response != "missing"),
            (
                "invalidation",
                chain["invalidation_refetch"] != "missing",
            ),
        ):
            if not value:
                missing.append(key)
        status = "complete" if not missing else "partial"
        row = {
            "id": f"LNK-{index:03d}",
            "scope": (
                "admin"
                if call["path"].startswith("/admin")
                else "public"
            ),
            "method": call["method"],
            "path": call["path"],
            "frontend_call_file": call["file"],
            **chain,
            "openapi": api_match,
            "backend_route_file": route["file"] if route else None,
            "backend_route_function": (
                route["function"] if route else None
            ),
            "auth_dependencies": (
                route.get("dependencies", []) if route else []
            ),
            "business_boundary": business,
            "db_boundary": db,
            "response_contract": response,
            "status": status,
            "missing": missing,
        }
        rows.append(row)
        for item in missing:
            blockers.append(
                {"id": row["id"], "path": call["path"], "missing": item}
            )

    direct_ui_transport: list[str] = []
    for path in sorted(FRONTEND.rglob("*.ts*")):
        rel = _rel(path)
        if any(
            rel.startswith(prefix)
            for prefix in (
                "frontend/src/services/",
                "frontend/src/queries/",
                "frontend/src/lib/",
                "frontend/src/pages/api/",
                "frontend/src/proof/",
            )
        ):
            continue
        text = _read(path)
        if re.search(
            r"import\s*\{[^}]*\b(?:apiRequest|adminApiRequest)\b",
            text,
            re.S,
        ):
            direct_ui_transport.append(rel)

    status = (
        "ok"
        if not blockers
        and not direct_ui_transport
        and strict["status"] == "ok"
        else "drift"
    )
    summary = {
        "total_actions": len(rows),
        "public_actions": sum(row["scope"] == "public" for row in rows),
        "admin_actions": sum(row["scope"] == "admin" for row in rows),
        "complete": sum(row["status"] == "complete" for row in rows),
        "partial": sum(row["status"] != "complete" for row in rows),
        "direct_ui_transport_files": len(direct_ui_transport),
        "openapi_operation_count": strict["openapi_operation_count"],
    }
    return {
        "cycle": 1565,
        "version": "v171.41",
        "status": status,
        "summary": summary,
        "direct_ui_transport_files": direct_ui_transport,
        "strict_openapi_gate_status": strict["status"],
        "blockers": blockers,
        "rows": rows,
        "proof_boundary": (
            "Статическое доказательство полной цепочки. Реальный "
            "PostgreSQL, live Telegram, TON Connect и production "
            "mutations остаются отдельными gates."
        ),
    }


def main() -> int:
    report = build_report()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {"status": report["status"], **report["summary"]},
            ensure_ascii=False,
        )
    )
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
