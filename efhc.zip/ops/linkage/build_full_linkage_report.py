"""Full static linkage report for EFHC Bot cycle 1448.

This is a dependency-light scanner. It does not import the runtime app.
It validates the repaired linkage class:
backend routes, OpenAPI, frontend calls, DB raw refs and UI states.
"""

from __future__ import annotations

import importlib.util
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
GATE = ROOT / "ops/routes/check_openapi_strict_contract_gate.py"
REPORT = ROOT / "reports/generated/full_linkage_report_v170_24.json"
BACKEND = ROOT / "backend/app"
FRONTEND = ROOT / "frontend/src"
OPENAPI = ROOT / "backend/openapi/openapi.json"

MONEY_TABLE_MARKERS = (
    "efhc_admin.efhc_mint_burn",
    "efhc_core.internal_tx",
    "efhc_admin.bank_balances",
    "efhc_core.user_wallets",
)

BANK_BALANCE_WRITE_RE = re.compile(
    r"UPDATE\s+(?:efhc_core\.)?bank_balance\b",
    re.I,
)
USER_BALANCE_WRITE_RE = re.compile(
    r"UPDATE\s+(?:efhc_core\.)?users\b(?P<body>.*?)(?:WHERE|RETURNING)",
    re.I | re.S,
)
USER_BALANCE_COLUMNS = (
    "main_balance",
    "bonus_balance",
    "available_kwh",
)

API_RE = re.compile(
    r"(?:apiRequest|adminApiRequest)"
    r"(?:<[^>]+>)?\(\s*([`\"'])(?P<path>.*?)(?<!\\)\1"
    r"\s*,\s*([`\"'])(?P<method>GET|POST|PUT|PATCH|DELETE)",
    re.S,
)

CRITICAL_UI = {
    "admin_bank": {
        "file": "frontend/src/pages/admin/bank.tsx",
        "loading": ["loading", "busy={loading}"],
        "error": ["setMsg", "catch"],
        "empty": ["ledger-empty", "пока пуст"],
    },
    "admin_reports": {
        "file": "frontend/src/pages/admin/reports.tsx",
        "loading": ["loading", "setLoading"],
        "error": ["error", "setError"],
        "empty": ["AdminReportsVisualDashboardPanel"],
    },
    "admin_deposits": {
        "file": "frontend/src/pages/admin/efhc-deposits.tsx",
        "loading": ["loading", "busy={loading}"],
        "error": ["error", "setError"],
        "empty": ["empty", "!result"],
    },
    "admin_hub": {
        "file": "frontend/src/features/admin/AdminHubPage.tsx",
        "loading": ["loading", "setLoading"],
        "error": ["error", "setError"],
        "empty": ["links.length", "admin.hub_empty"],
    },
    "admin_users": {
        "file": "frontend/src/pages/admin/users.tsx",
        "loading": ["loading", "setLoading"],
        "error": ["err", "setErr"],
        "empty": ["TelegramEmptyState", "items.length === 0"],
    },
    "admin_shop": {
        "file": "frontend/src/pages/admin/shop.tsx",
        "loading": ["loading", "setLoading"],
        "error": ["message", "setMessage"],
        "empty": ["TelegramEmptyState", "История пуста"],
    },
    "withdraw": {
        "file": "frontend/src/pages/withdraw.tsx",
        "loading": ["loading", "historyLoading"],
        "error": ["error", "detailError"],
        "empty": ["EmptyState", "items.length === 0"],
    },
    "tasks": {
        "file": "frontend/src/pages/tasks.tsx",
        "loading": ["loading", "isLoading"],
        "error": ["error", "tasks.error_title"],
        "empty": ["EmptyState", "tasks.empty_title"],
    },
    "referrals": {
        "file": "frontend/src/pages/referrals.tsx",
        "loading": ["isLoading", "statsQ.isLoading"],
        "error": ["errorText", "referrals.load_error"],
        "empty": ["EmptyState", "referrals.empty"],
    },
    "exchange": {
        "file": "frontend/src/pages/exchange.tsx",
        "loading": ["isPending", "interactive_loading"],
        "error": ["previewError", "publicApiErrorMessage"],
        "empty": ["TelegramEmptyState", "empty"],
    },
}


def _load_gate() -> Any:
    spec = importlib.util.spec_from_file_location("efhc_gate", GATE)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


def _all_text_files(base: Path) -> list[Path]:
    out: list[Path] = []
    for path in base.rglob("*"):
        if path.is_file() and path.suffix in {".py", ".ts", ".tsx"}:
            out.append(path)
    return sorted(out)


def _rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


def scan_raw_table_refs() -> dict[str, list[str]]:
    hits: dict[str, list[str]] = {
        marker: [] for marker in MONEY_TABLE_MARKERS
    }
    for path in _all_text_files(BACKEND):
        rel = _rel(path)
        text = path.read_text(encoding="utf-8", errors="replace")
        for marker in MONEY_TABLE_MARKERS:
            if marker in text:
                hits[marker].append(rel)
    return {key: value for key, value in hits.items() if value}


def scan_direct_balance_writes() -> list[dict[str, str]]:
    allowed = {
        "backend/app/services/transactions_service.py",
        "backend/migrations/versions/0001_initial_release_schema.py",
    }
    rows: list[dict[str, str]] = []
    for path in _all_text_files(ROOT / "backend"):
        rel = _rel(path)
        if rel in allowed:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in BANK_BALANCE_WRITE_RE.finditer(text):
            rows.append({"file": rel, "marker": match.group(0)})
        for match in USER_BALANCE_WRITE_RE.finditer(text):
            body = match.group("body")
            if any(col in body for col in USER_BALANCE_COLUMNS):
                rows.append(
                    {"file": rel, "marker": "UPDATE users balance"}
                )
    return rows


def scan_frontend_api_calls() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for path in _all_text_files(FRONTEND):
        rel = _rel(path)
        if rel.startswith("frontend/src/pages/api/"):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in API_RE.finditer(text):
            rows.append(
                {
                    "file": rel,
                    "method": match.group("method"),
                    "path": match.group("path"),
                }
            )
    return rows


def check_ui_states() -> list[dict[str, str]]:
    missing: list[dict[str, str]] = []
    for name, cfg in CRITICAL_UI.items():
        text = (ROOT / cfg["file"]).read_text(
            encoding="utf-8",
            errors="replace",
        )
        for state in ("loading", "error", "empty"):
            tokens = cfg[state]
            if not any(token in text for token in tokens):
                missing.append(
                    {
                        "surface": name,
                        "state": state,
                        "file": cfg["file"],
                    }
                )
    return missing


def check_admin_hub_seam_contract() -> dict[str, Any]:
    seam = (
        ROOT / "frontend/src/lib/api/generated/adminSeams.ts"
    ).read_text(encoding="utf-8", errors="replace")
    page = (
        ROOT / "frontend/src/features/admin/AdminHubPage.tsx"
    ).read_text(encoding="utf-8", errors="replace")
    required = [
        "ADMIN_HUB_LINKS_PATH",
        "ADMIN_HUB_LINK_CREATE_PATH",
        "ADMIN_HUB_LINK_UPDATE_PATH",
        "ADMIN_HUB_LINK_TOGGLE_PATH",
        "ADMIN_HUB_LINK_REORDER_PATH",
        "AdminHubLink",
    ]
    missing = [token for token in required if token not in seam]
    raw_literals = [
        token
        for token in (
            '"/admin/hub/links"',
            "'/admin/hub/links'",
            "`/admin/hub/links/",
        )
        if token in page
    ]
    imported = [token for token in required if token in page]
    return {
        "missing_generated_tokens": missing,
        "raw_admin_hub_api_literals": raw_literals,
        "page_imported_tokens": imported,
    }


def build_report() -> dict[str, Any]:
    gate = _load_gate()
    gate_report = gate.build_report()
    raw_refs = scan_raw_table_refs()
    direct_writes = scan_direct_balance_writes()
    ui_missing = check_ui_states()
    frontend_calls = gate.collect_frontend_calls()
    admin_hub_seam = check_admin_hub_seam_contract()
    openapi = json.loads(OPENAPI.read_text(encoding="utf-8"))
    op_count = sum(len(v) for v in openapi.get("paths", {}).values())

    blockers: list[str] = []
    if gate_report.get("status") != "ok":
        blockers.append("openapi_gate")
    if raw_refs:
        blockers.append("raw_legacy_money_table_refs")
    if direct_writes:
        blockers.append("direct_balance_writes")
    if ui_missing:
        blockers.append("critical_ui_state_gap")
    if admin_hub_seam["missing_generated_tokens"]:
        blockers.append("admin_hub_seam_missing")
    if admin_hub_seam["raw_admin_hub_api_literals"]:
        blockers.append("admin_hub_raw_api_literals")

    status = "ok" if not blockers else "drift"
    return {
        "cycle": "1448",
        "version": "v170.24",
        "status": status,
        "blockers": blockers,
        "openapi_operation_count": op_count,
        "frontend_api_call_count": len(frontend_calls),
        "critical_ui_surfaces": sorted(CRITICAL_UI),
        "critical_ui_state_missing": ui_missing,
        "admin_hub_seam_contract": admin_hub_seam,
        "raw_legacy_money_table_refs": raw_refs,
        (
            "direct_balance_writes_outside_"
            "canonical_service"
        ): direct_writes,
        "openapi_gate_status": gate_report.get("status"),
        "missing_frontend_backend": gate_report.get(
            "missing_frontend_backend",
            [],
        ),
        "missing_frontend_openapi": gate_report.get(
            "missing_frontend_openapi",
            [],
        ),
        "admin_unmarked": gate_report.get("admin_unmarked", []),
        "note": (
            "Static architecture guard. Live CI, browser and FastAPI "
            "runtime proof are separate release gates."
        ),
    }


def main() -> int:
    report = build_report()
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
