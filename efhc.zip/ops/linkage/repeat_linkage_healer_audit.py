from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
VERSION = "v170.20"
CYCLE = 1444


def _read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def _json(path: str) -> dict[str, Any]:
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def _contains(path: str, needle: str) -> bool:
    return needle in _read(path)


def _not_contains_any(paths: list[str], needles: list[str]) -> bool:
    for path in paths:
        text = _read(path)
        for needle in needles:
            if needle in text:
                return False
    return True


def _finding_statuses() -> list[dict[str, Any]]:
    openapi_gate = _json(
        "reports/generated/openapi_strict_contract_gate_v170_18.json"
    )
    full_linkage = _json(
        "reports/generated/full_linkage_report_v170_19.json"
    )
    statuses: list[dict[str, Any]] = []

    def add(
        fid: str,
        title: str,
        status: str,
        evidence: list[str],
    ) -> None:
        statuses.append(
            {
                "id": fid,
                "title": title,
                "repeat_audit_status": status,
                "evidence": evidence,
            }
        )

    f001_ok = _not_contains_any(
        [
            "backend/app/services/admin/admin_bank_service.py",
            "backend/app/routes/admin_routes.py",
        ],
        [
            "efhc_admin.efhc_mint_burn",
            "efhc_core.internal_tx",
            " efhc_mint_burn",
            " internal_tx",
        ],
    ) and _contains(
        "backend/app/services/admin/admin_bank_service.py",
        "transactions_service",
    )
    add(
        "F-001",
        (
            "Admin bank mint/burn uses canonical bank/"
            "transaction service surfaces"
        ),
        "REPEAT_AUDIT_PASSED_LOCAL" if f001_ok else "STILL_OPEN",
        [
            "backend/app/services/admin/admin_bank_service.py",
            "backend/app/services/transactions_service.py",
            "tests/architecture/test_admin_bank_ssot_repair.py",
        ],
    )

    watcher = _read("backend/app/services/watcher_service.py")
    f002_ok = (
        "wallet_bindings" in watcher
        and "proof_verified" in watcher
        and "is_active" in watcher
        and "efhc_core.user_wallets" not in watcher
        and "users.ton_wallet" not in watcher
    )
    add(
        "F-002",
        "Deposit watcher uses canonical wallet_bindings SSOT",
        "REPEAT_AUDIT_PASSED_LOCAL" if f002_ok else "STILL_OPEN",
        [
            "backend/app/services/watcher_service.py",
            (
                "tests/architecture/"
                "test_deposit_watcher_wallet_ssot_repair.py"
            ),
        ],
    )

    admin_routes = _read("backend/app/routes/admin_routes.py")
    f003_ok = (
        "efhc_core.bank_balance" in admin_routes
        and "efhc_admin.bank_balances" not in admin_routes
    )
    add(
        "F-003",
        "Admin reports overview reads canonical bank_balance",
        "REPEAT_AUDIT_PASSED_LOCAL" if f003_ok else "STILL_OPEN",
        [
            "backend/app/routes/admin_routes.py",
            "tests/architecture/test_admin_reports_bank_ssot_repair.py",
        ],
    )

    f004_ok = (
        (ROOT / "backend/app/routes/admin_hub_routes.py").exists()
        and "/admin/hub" in _read(
            "backend/app/routes/admin_hub_routes.py"
        )
        and "/admin/shop/admin/hub" not in _read(
            "backend/app/routes/admin_shop_routes.py"
        )
        and "hub_router" not in _read(
            "backend/app/routes/admin_shop_routes.py"
        )
    )
    add(
        "F-004",
        "Admin Hub uses standalone /admin/hub/* route prefix",
        "REPEAT_AUDIT_PASSED_LOCAL" if f004_ok else "STILL_OPEN",
        [
            "backend/app/routes/admin_hub_routes.py",
            "backend/app/routes/admin_shop_routes.py",
            "tests/architecture/test_admin_hub_route_prefix_repair.py",
        ],
    )

    reset_route = _read("backend/app/routes/admin_users_routes.py")
    wallets_service = _read("backend/app/services/wallets_service.py")
    f005_ok = (
        "admin_reset_wallet_bindings" in reset_route
        and "admin_reset_wallet_bindings" in wallets_service
        and "wallet_bindings" in wallets_service
        and "is_active" in wallets_service
        and "is_primary" in wallets_service
        and "ton_wallet = NULL" in reset_route
    )
    add(
        "F-005",
        (
            "Admin wallet reset clears legacy field and "
            "deactivates canonical wallet_bindings"
        ),
        "REPEAT_AUDIT_PASSED_LOCAL" if f005_ok else "STILL_OPEN",
        [
            "backend/app/routes/admin_users_routes.py",
            "backend/app/services/wallets_service.py",
            (
                "tests/architecture/"
                "test_admin_wallet_reset_semantic_repair.py"
            ),
        ],
    )

    f006_ok = openapi_gate.get("status") == "ok" and not any(
        openapi_gate.get(key)
        for key in [
            "missing_openapi",
            "dead_openapi",
            "missing_frontend_backend",
            "missing_frontend_openapi",
            "missing_seam_openapi",
            "admin_unmarked",
            "money_internal_leaks",
        ]
    )
    add(
        "F-006",
        "OpenAPI static contract gate has no dead/missing route drift",
        (
            "REPEAT_AUDIT_PASSED_LOCAL_STATIC_"
            "PENDING_LIVE_FASTAPI_PROOF"
            if f006_ok
            else "STILL_OPEN"
        ),
        [
            "backend/openapi/openapi.json",
            (
                "reports/generated/"
                "openapi_strict_contract_gate_v170_18.json"
            ),
            (
                "tests/architecture/"
                "test_openapi_rebuild_strict_contract_gate.py"
            ),
        ],
    )

    f007_ok = (
        full_linkage.get("status") == "ok"
        and not full_linkage.get("critical_ui_state_missing")
    )
    add(
        "F-007",
        (
            "Critical frontend API surfaces have loading/"
            "error/empty state guards"
        ),
        "REPEAT_AUDIT_PASSED_LOCAL" if f007_ok else "STILL_OPEN",
        [
            "reports/generated/full_linkage_report_v170_19.json",
            (
                "tests/architecture/"
                "test_full_linkage_architecture_and_ui_states.py"
            ),
        ],
    )

    f008_ok = (
        full_linkage.get("status") == "ok"
        and not full_linkage.get("missing_frontend_backend")
    )
    add(
        "F-008",
        (
            "Frontend API calls are guarded against missing "
            "backend route drift"
        ),
        "REPEAT_AUDIT_PASSED_LOCAL" if f008_ok else "STILL_OPEN",
        [
            "reports/generated/full_linkage_report_v170_19.json",
            (
                "tests/architecture/"
                "test_full_linkage_architecture_and_ui_states.py"
            ),
        ],
    )
    return statuses


def _healer_status() -> dict[str, Any]:
    from ops.healer.loader import load_atlas, load_casebook

    atlas_raw, cards = load_atlas(ROOT / "atlas.json")
    casebook_raw, cases = load_casebook(ROOT / "casebook.json")
    return {
        "status": "ok",
        "atlas_version": atlas_raw.get(
            "atlas_version",
            atlas_raw.get("version", "unknown"),
        ),
        "casebook_version": casebook_raw.get(
            "casebook_version",
            casebook_raw.get("version", "unknown"),
        ),
        "cards_total": len(cards),
        "cases_total": len(cases),
        "loader_compatibility": (
            "strict dataclass boundary with historical-card defaults"
        ),
    }


def build_report() -> dict[str, Any]:
    findings = _finding_statuses()
    blockers = [
        item
        for item in findings
        if item["repeat_audit_status"] == "STILL_OPEN"
    ]
    live_proof_pending = [
        item
        for item in findings
        if "PENDING_LIVE" in item["repeat_audit_status"]
    ]
    return {
        "version": VERSION,
        "cycle": CYCLE,
        "title": "Linkage repeat audit + HEALER tail reconciliation",
        "source_head": "v170.19 / cycle 1443",
        "status": "ok" if not blockers else "blocked",
        "release_ready": False,
        "release_ready_reason": (
            "Local repeat audit passed, but GitHub CI/full pytest/"
            "frontend build/browser/live Telegram/TonConnect/"
            "release audit proofs are separate gates."
        ),
        "findings": findings,
        "blockers": blockers,
        "live_proof_pending": live_proof_pending,
        "healer": _healer_status(),
        "next_cycles": [
            (
                "1445 — CI/log proof and residual audit-tail "
                "closure if fresh logs are supplied"
            ),
            "1446 — Release gate preparation audit after CI/log proof",
        ],
        "sandbox_policy": (
            "Песочница used only as reference/navigation layer; "
            "no runtime code transferred."
        ),
    }


def main() -> int:
    report = build_report()
    out = ROOT / (
        "reports/generated/"
        "linkage_repeat_audit_healer_tail_v170_20.json"
    )
    out.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
