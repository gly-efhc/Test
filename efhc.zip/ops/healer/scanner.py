from __future__ import annotations

from pathlib import Path

from .matcher import confirm_symptom
from .models import Finding, ScanContext, Symptom

TEXT_EXTS = {
    ".py",
    ".md",
    ".yml",
    ".yaml",
    ".json",
    ".ts",
    ".tsx",
}
SKIP_PARTS = {
    ".git",
    ".next",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
}


def iter_files(repo_root: Path):
    for path in repo_root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_EXTS:
            continue
        if any(part in SKIP_PARTS for part in path.parts):
            continue
        yield path


def scan_repo(ctx: ScanContext) -> list[Finding]:
    findings: list[Finding] = []
    for path in iter_files(ctx.repo_root):
        rel = path.relative_to(ctx.repo_root).as_posix()
        text = path.read_text(encoding="utf-8", errors="ignore")
        for idx, line in enumerate(text.splitlines(), start=1):
            symptom = Symptom(
                symptom_id=f"{rel}:{idx}",
                source="repo_scan",
                file_path=rel,
                line_no=idx,
                excerpt=line.strip(),
                raw_text=line,
                timestamp="scan",
            )
            match = confirm_symptom(ctx, symptom)
            if match is None:
                continue
            findings.append(
                Finding(
                    heal_id=match.card.heal_id,
                    file_path=rel,
                    line_no=idx,
                    excerpt=line.strip()[:72],
                    reason=match.card.confirmation_rule,
                    docs_checked=match.docs_checked,
                    case_ids=match.case_ids,
                )
            )
    return findings
