from __future__ import annotations

from pathlib import Path

from .loader import load_atlas, load_casebook
from .models import ScanContext
from .report import write_memory_snapshot, write_scan_report
from .scanner import scan_repo


def main() -> int:
    repo_root = Path(__file__).resolve().parents[2]
    atlas_raw, cards = load_atlas(repo_root / "atlas.json")
    case_raw, cases = load_casebook(repo_root / "casebook.json")
    atlas_version = str(
        atlas_raw.get(
            "atlas_version",
            atlas_raw.get("version", "unknown"),
        )
    )
    casebook_version = str(
        case_raw.get(
            "casebook_version",
            case_raw.get("version", "unknown"),
        )
    )
    ctx = ScanContext(
        repo_root=repo_root,
        cards=cards,
        casebook=cases,
        head_source=repo_root.name,
        log_source="healer_offline_memory",
        extra={
            "atlas_version": atlas_version,
            "casebook_version": casebook_version,
        },
    )
    findings = scan_repo(ctx)
    docs_checked = sorted(
        {
            "atlas.json",
            "casebook.json",
            "HEALER_ATLAS.md",
            "docs/healer/HEALER_CASEBOOK.md",
            "docs/healer/HEALER_RULES.md",
            "docs/healer/HEALER_WORKFLOW.md",
        }
    )
    out_dir = repo_root / "ops" / "healer"
    write_scan_report(
        out_dir,
        atlas_version,
        ctx.head_source,
        docs_checked,
        findings,
        [],
    )
    write_memory_snapshot(
        out_dir,
        casebook_version,
        cases,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
