from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import HealerCard, HealerCase

REQUIRED_FIELDS = [
    "heal_id",
    "name",
    "category",
    "severity",
    "zone",
    "symptom_patterns",
    "doc_checks",
    "exceptions",
    "confirmation_rule",
    "treatment_status",
    "root_cause",
    "treatment",
    "forbidden_actions",
    "verification",
    "prevention",
    "where_to_look",
    "sources",
]

CASE_REQUIRED_FIELDS = [
    "case_id",
    "heal_id",
    "title",
    "status",
    "archive_version",
    "symptom_excerpt",
    "zones",
    "related_files",
    "root_cause",
    "applied_fix",
    "forbidden_fix",
    "verification_done",
    "where_else_to_check",
    "recurrence_note",
    "knowledge_sources",
]


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def _require(raw: dict[str, Any], key: str) -> Any:
    if key not in raw:
        raise KeyError(f"Missing required healer field: {key}")
    return raw[key]


def _default_card_value(raw: dict[str, Any], key: str) -> Any:
    """Return a safe compatibility value for older Healer Atlas cards.

    The archive contains both strict protocolized Healer cards
    and older compact cards. Cycle 1444 keeps the strict
    dataclass boundary but lets the loader normalize historical
    cards instead of crashing before scan/audit. This is a
    tooling adapter, not a runtime/business rule.
    """

    if key in raw:
        return raw[key]
    if key in {
        "exceptions",
        "root_cause",
        "treatment",
        "forbidden_actions",
        "verification",
        "prevention",
        "where_to_look",
        "sources",
        "casebook_refs",
        "case_refs",
        "related_reports",
        "related_registry_entries",
        "path_patterns",
    }:
        return []
    if key == "confirmation_basis":
        return raw.get(
            "confirmation_basis",
            "compatibility-normalized historical Healer card",
        )
    if key == "card_status":
        return raw.get("card_status", raw.get("status", "confirmed"))
    if key == "medical_maturity":
        return raw.get("medical_maturity", "historical")
    if key == "action_priority":
        return raw.get("action_priority", "observe")
    if key == "times_seen":
        return raw.get("times_seen", 1)
    if key in {"first_seen", "last_seen"}:
        return raw.get(key, "unknown")
    if key == "treatment_status":
        return raw.get(
            "treatment_status",
            raw.get("status", "confirmed"),
        )
    raise KeyError(f"Missing required healer field: {key}")


def _default_case_value(raw: dict[str, Any], key: str) -> Any:
    """Return a safe value for older Healer Casebook cases."""

    if key in raw:
        return raw[key]
    if key in {
        "zones",
        "related_files",
        "applied_fix",
        "forbidden_fix",
        "verification_done",
        "where_else_to_check",
        "knowledge_sources",
        "origin_sources",
        "treatment_history",
    }:
        if key == "verification_done" and "guards" in raw:
            return raw.get("guards", [])
        return []
    if key == "symptom_excerpt":
        return raw.get("title", "")
    if key == "root_cause":
        return raw.get("confirmation_basis", "historical Healer case")
    if key == "recurrence_note":
        return "compatibility-normalized historical Healer case"
    if key == "status":
        return raw.get(
            "treatment_status",
            raw.get("card_status", "confirmed"),
        )
    if key == "treatment_status":
        return raw.get("status", "confirmed")
    if key == "card_status":
        return raw.get("status", "confirmed")
    if key == "medical_maturity":
        return "historical"
    if key == "action_priority":
        return "observe"
    if key == "case_role":
        return "historical_case"
    if key == "confirmation_basis":
        return raw.get(
            "confirmation_basis",
            "compatibility-normalized historical Healer case",
        )
    if key == "last_seen_in":
        return raw.get("archive_version", "")
    if key == "first_recorded_in":
        return raw.get("archive_version", "")
    if key == "result":
        return raw.get("status", "")
    raise KeyError(f"Missing required healer case field: {key}")


def _normalize_card(raw_card: dict[str, Any]) -> HealerCard:
    for key in ("heal_id", "name", "category", "severity", "zone"):
        _require(raw_card, key)
    where_to_look = _as_list(
        _default_card_value(raw_card, "where_to_look")
    )
    path_patterns = _as_list(
        _default_card_value(raw_card, "path_patterns")
    )
    if not path_patterns:
        path_patterns = where_to_look or ["**/*"]
    return HealerCard(
        heal_id=str(_default_card_value(raw_card, "heal_id")),
        name=str(_default_card_value(raw_card, "name")),
        category=str(_default_card_value(raw_card, "category")),
        severity=str(_default_card_value(raw_card, "severity")),
        zone=str(_default_card_value(raw_card, "zone")),
        symptom_patterns=_as_list(
            _default_card_value(raw_card, "symptom_patterns")
        ),
        doc_checks=_as_list(
            _default_card_value(raw_card, "doc_checks")
        ),
        exceptions=_as_list(
            _default_card_value(raw_card, "exceptions")
        ),
        confirmation_rule=str(
            _default_card_value(raw_card, "confirmation_rule")
        ),
        confirmation_basis=str(
            _default_card_value(raw_card, "confirmation_basis")
        ),
        card_status=str(_default_card_value(raw_card, "card_status")),
        treatment_status=str(
            _default_card_value(raw_card, "treatment_status")
        ),
        medical_maturity=str(
            _default_card_value(raw_card, "medical_maturity")
        ),
        action_priority=str(
            _default_card_value(raw_card, "action_priority")
        ),
        root_cause=str(_default_card_value(raw_card, "root_cause")),
        treatment=_as_list(_default_card_value(raw_card, "treatment")),
        forbidden_actions=_as_list(
            _default_card_value(raw_card, "forbidden_actions")
        ),
        verification=_as_list(
            _default_card_value(raw_card, "verification")
        ),
        prevention=_as_list(
            _default_card_value(raw_card, "prevention")
        ),
        where_to_look=where_to_look,
        sources=_as_list(_default_card_value(raw_card, "sources")),
        first_seen=str(_default_card_value(raw_card, "first_seen")),
        last_seen=str(_default_card_value(raw_card, "last_seen")),
        times_seen=int(_default_card_value(raw_card, "times_seen")),
        casebook_refs=_as_list(
            _default_card_value(raw_card, "casebook_refs")
        ),
        case_refs=_as_list(_default_card_value(raw_card, "case_refs")),
        related_reports=_as_list(
            _default_card_value(raw_card, "related_reports")
        ),
        related_registry_entries=_as_list(
            _default_card_value(raw_card, "related_registry_entries")
        ),
        path_patterns=path_patterns,
    )


def _normalize_case(raw_case: dict[str, Any]) -> HealerCase:
    for key in ("case_id", "heal_id", "title", "archive_version"):
        _require(raw_case, key)
    return HealerCase(
        case_id=str(_default_case_value(raw_case, "case_id")),
        heal_id=str(_default_case_value(raw_case, "heal_id")),
        title=str(_default_case_value(raw_case, "title")),
        status=str(_default_case_value(raw_case, "status")),
        archive_version=str(
            _default_case_value(raw_case, "archive_version")
        ),
        symptom_excerpt=str(
            _default_case_value(raw_case, "symptom_excerpt")
        ),
        zones=_as_list(_default_case_value(raw_case, "zones")),
        related_files=_as_list(
            _default_case_value(raw_case, "related_files")
        ),
        root_cause=str(_default_case_value(raw_case, "root_cause")),
        applied_fix=_as_list(
            _default_case_value(raw_case, "applied_fix")
        ),
        forbidden_fix=_as_list(
            _default_case_value(raw_case, "forbidden_fix")
        ),
        verification_done=_as_list(
            _default_case_value(raw_case, "verification_done")
        ),
        where_else_to_check=_as_list(
            _default_case_value(raw_case, "where_else_to_check")
        ),
        recurrence_note=str(
            _default_case_value(raw_case, "recurrence_note")
        ),
        knowledge_sources=_as_list(
            _default_case_value(raw_case, "knowledge_sources")
        ),
        origin_sources=_as_list(
            _default_case_value(raw_case, "origin_sources")
        ),
        first_recorded_in=str(
            _default_case_value(raw_case, "first_recorded_in")
        ),
        treatment_history=_as_list(
            _default_case_value(raw_case, "treatment_history")
        ),
        result=str(_default_case_value(raw_case, "result")),
        treatment_status=str(
            _default_case_value(raw_case, "treatment_status")
        ),
        card_status=str(_default_case_value(raw_case, "card_status")),
        medical_maturity=str(
            _default_case_value(raw_case, "medical_maturity")
        ),
        action_priority=str(
            _default_case_value(raw_case, "action_priority")
        ),
        case_role=str(_default_case_value(raw_case, "case_role")),
        confirmation_basis=str(
            _default_case_value(raw_case, "confirmation_basis")
        ),
        last_seen_in=str(_default_case_value(raw_case, "last_seen_in")),
    )


def load_atlas(
    atlas_path: Path,
) -> tuple[dict[str, Any], list[HealerCard]]:
    raw = json.loads(atlas_path.read_text(encoding="utf-8"))
    cards = [_normalize_card(card) for card in raw["cards"]]
    return raw, cards


def load_casebook(
    casebook_path: Path,
) -> tuple[dict[str, Any], list[HealerCase]]:
    raw = json.loads(casebook_path.read_text(encoding="utf-8"))
    cases = [_normalize_case(item) for item in raw["cases"]]
    return raw, cases
