from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from .matcher import confirm_symptom
from .models import Finding, ScanContext, Symptom, UnknownFinding


def audit_log_text(
    ctx: ScanContext,
    log_text: str,
    log_source: str,
) -> tuple[list[Finding], list[UnknownFinding]]:
    findings: list[Finding] = []
    unknowns: list[UnknownFinding] = []
    stamp = datetime.now(UTC).isoformat()
    for idx, line in enumerate(log_text.splitlines(), start=1):
        if not line.strip():
            continue
        symptom = Symptom(
            symptom_id=f"log:{idx}",
            source=log_source,
            file_path=log_source,
            line_no=idx,
            excerpt=line.strip(),
            raw_text=line,
            timestamp=stamp,
        )
        match = confirm_symptom(ctx, symptom)
        if match is None:
            unknowns.append(
                UnknownFinding(
                    symptom_id=symptom.symptom_id,
                    source=log_source,
                    file_path=log_source,
                    raw_excerpt=line[:72],
                    suggested_category="unknown_runtime_case",
                    why_not_confirmed=("No casebook match."),
                    docs_checked=["docs/healer/HEALER_CASEBOOK.md"],
                    timestamp=stamp,
                )
            )
            continue
        findings.append(
            Finding(
                heal_id=match.card.heal_id,
                file_path=log_source,
                line_no=idx,
                excerpt=line[:72],
                reason=match.card.confirmation_rule,
                docs_checked=match.docs_checked,
                case_ids=match.case_ids,
            )
        )
    return findings, unknowns


def audit_log_file(
    ctx: ScanContext,
    log_path: Path,
) -> tuple[list[Finding], list[UnknownFinding]]:
    text = log_path.read_text(encoding="utf-8", errors="ignore")
    return audit_log_text(ctx, text, log_path.as_posix())
