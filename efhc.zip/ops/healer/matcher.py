from __future__ import annotations

import re

from .docs_index import resolve_doc_checks
from .exceptions import is_exception
from .models import HealerCard, MatchResult, ScanContext, Symptom


def _pattern_match(card: HealerCard, symptom: Symptom) -> bool:
    for pattern in card.symptom_patterns:
        if pattern in symptom.raw_text:
            return True
        try:
            if re.search(pattern, symptom.raw_text):
                return True
        except re.error:
            continue
    return False


def __path__match(card: HealerCard, file_path: str) -> bool:
    if not card.path_patterns:
        return True
    for pattern in card.path_patterns:
        if pattern.endswith("/**") and file_path.startswith(
            pattern[:-3],
        ):
            return True
        if pattern.endswith("/*") and file_path.startswith(
            pattern[:-1],
        ):
            return True
        if pattern in file_path or file_path.startswith(pattern):
            return True
    return False


def _case_ids_for(ctx: ScanContext, heal_id: str) -> list[str]:
    return [
        item.case_id for item in ctx.casebook if item.heal_id == heal_id
    ]


def confirm_symptom(
    ctx: ScanContext,
    symptom: Symptom,
) -> MatchResult | None:
    for card in ctx.cards:
        if not _pattern_match(card, symptom):
            continue
        if not __path__match(card, symptom.file_path):
            continue
        docs_checked = resolve_doc_checks(
            ctx.repo_root,
            card.doc_checks,
        )
        if not docs_checked:
            continue
        if is_exception(
            card.exceptions,
            symptom.file_path,
            symptom.excerpt,
        ):
            continue
        case_ids = _case_ids_for(ctx, card.heal_id)
        if not case_ids:
            continue
        return MatchResult(
            card=card,
            score=1.0,
            docs_checked=docs_checked,
            case_ids=case_ids,
        )
    return None
