from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class HealerCard:
    heal_id: str
    name: str
    category: str
    severity: str
    zone: str
    symptom_patterns: list[str]
    doc_checks: list[str]
    exceptions: list[str]
    confirmation_rule: str
    card_status: str
    treatment_status: str
    medical_maturity: str
    action_priority: str
    confirmation_basis: str
    root_cause: str
    treatment: list[str]
    forbidden_actions: list[str]
    verification: list[str]
    prevention: list[str]
    where_to_look: list[str]
    sources: list[str]
    first_seen: str
    last_seen: str
    times_seen: int
    casebook_refs: list[str]
    case_refs: list[str]
    related_reports: list[str]
    related_registry_entries: list[str]
    path_patterns: list[str]


@dataclass(frozen=True)
class HealerCase:
    case_id: str
    heal_id: str
    title: str
    status: str
    archive_version: str
    symptom_excerpt: str
    zones: list[str]
    related_files: list[str]
    root_cause: str
    applied_fix: list[str]
    forbidden_fix: list[str]
    verification_done: list[str]
    where_else_to_check: list[str]
    recurrence_note: str
    knowledge_sources: list[str]
    origin_sources: list[str]
    first_recorded_in: str
    treatment_history: list[str]
    result: str
    treatment_status: str
    card_status: str
    medical_maturity: str
    action_priority: str
    case_role: str
    confirmation_basis: str
    last_seen_in: str


@dataclass(frozen=True)
class Finding:
    heal_id: str
    file_path: str
    line_no: int
    excerpt: str
    reason: str
    docs_checked: list[str]
    case_ids: list[str]

    @property
    def pointer(self) -> str:
        return f"{self.file_path}:{self.line_no}"


@dataclass(frozen=True)
class UnknownFinding:
    symptom_id: str
    source: str
    file_path: str
    raw_excerpt: str
    suggested_category: str
    why_not_confirmed: str
    docs_checked: list[str]
    timestamp: str


@dataclass(frozen=True)
class ScanContext:
    repo_root: Path
    cards: list[HealerCard]
    casebook: list[HealerCase]
    head_source: str
    log_source: str
    extra: dict[str, Any]


@dataclass(frozen=True)
class Symptom:
    symptom_id: str
    source: str
    file_path: str
    line_no: int
    excerpt: str
    raw_text: str
    timestamp: str


@dataclass(frozen=True)
class MatchResult:
    card: HealerCard
    score: float
    docs_checked: list[str]
    case_ids: list[str]


@dataclass(frozen=True)
class LookupResult:
    heal_id: str
    disease_name: str
    confidence: float
    case_ids: list[str]
    treatment: list[str]
    forbidden_actions: list[str]
    where_else_to_check: list[str]
