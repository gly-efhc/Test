from __future__ import annotations

from glob import glob
from pathlib import Path


def resolve_doc_checks(
    repo_root: Path,
    doc_checks: list[str],
) -> list[str]:
    found: list[str] = []
    for item in doc_checks:
        matches = glob(str(repo_root / item), recursive=True)
        if matches:
            rels = [
                Path(path)
                .resolve()
                .relative_to(repo_root.resolve())
                .as_posix()
                for path in matches
                if Path(path).exists()
            ]
            found.extend(sorted(set(rels)))
            continue
        direct = repo_root / item
        if direct.exists():
            found.append(item)
    return sorted(set(found))
