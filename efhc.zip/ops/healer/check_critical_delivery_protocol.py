from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class ProtocolViolation(RuntimeError):
    """Raised when a delivery cannot be truthfully released."""


@dataclass(frozen=True)
class DeliveryInputs:
    root: Path
    version: str
    cycle: int
    main_archive: Path
    screenshots_archive: Path | None
    manifest: Path | None
    report: Path
    generated_report: Path
    screenshot_mode: str
    ui_change: bool
    heal_id: str
    case_id: str
    receipt_out: Path


CONTROL_DOCS = (
    "docs/AI/READING_ENTRYPOINT.md",
    "KERNEL.md",
    "CONTINUE_IN_NEW_CHAT.md",
    "docs/NORM/RELEASE_PROOF_STATUS.md",
    "docs/cycles/WORK_CYCLES.md",
    "docs/cycles/WORK_CYCLES_1501-1600_FUTURE_RANGE_PLAN.md",
    "reports/REPORTS_INDEX.md",
)

REQUIRED_ARCHIVE_FILES = (
    "AGENTS.md",
    "KERNEL.md",
    "CONTINUE_IN_NEW_CHAT.md",
    "HEALER_ATLAS.md",
    "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
    "atlas.json",
    "casebook.json",
    "docs/AI/READING_ENTRYPOINT.md",
    "docs/healer/HEALER_ATLAS.md",
    "docs/NORM/RELEASE_PROOF_STATUS.md",
    "docs/cycles/WORK_CYCLES.md",
    "reports/REPORTS_INDEX.md",
)

FORBIDDEN_ARCHIVE_PARTS = (
    "/node_modules/",
    "/.next/",
    "/__pycache__/",
    "/.pytest_cache/",
    "/.ruff_cache/",
    "/.mypy_cache/",
)

FORBIDDEN_PROOF_WORDS = (
    "synthetic",
    "mock",
    "fabricated",
    "generated imitation",
)


def _read_text(path: Path) -> str:
    if not path.is_file():
        raise ProtocolViolation(f"missing required file: {path}")
    return path.read_text(encoding="utf-8", errors="strict")


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(_read_text(path))
    except json.JSONDecodeError as exc:
        raise ProtocolViolation(f"invalid JSON: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ProtocolViolation(f"JSON root must be an object: {path}")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalise_zip_name(name: str) -> str:
    return name.replace("\\", "/").lstrip("./")


def validate_head_sync(inputs: DeliveryInputs) -> None:
    expected_version = inputs.version
    expected_cycle = f"cycle {inputs.cycle}"
    for relative in CONTROL_DOCS:
        path = inputs.root / relative
        top = "\n".join(_read_text(path).splitlines()[:90]).lower()
        if expected_version.lower() not in top:
            raise ProtocolViolation(
                f"HEAD sync failed: {relative} does not declare "
                f"{expected_version} in its current section"
            )
        if expected_cycle not in top:
            raise ProtocolViolation(
                f"cycle sync failed: {relative} does not declare "
                f"{expected_cycle} in its current section"
            )


def validate_healer_triple_write(inputs: DeliveryInputs) -> None:
    atlas = _read_json(inputs.root / "atlas.json")
    casebook = _read_json(inputs.root / "casebook.json")
    cards = atlas.get("cards")
    cases = casebook.get("cases")
    if not isinstance(cards, list) or not isinstance(cases, list):
        raise ProtocolViolation(
            "Healer atlas/casebook arrays are missing"
        )
    if atlas.get("cards_total") != len(cards):
        raise ProtocolViolation("atlas cards_total is out of sync")
    if casebook.get("cases_total") != len(cases):
        raise ProtocolViolation("casebook cases_total is out of sync")

    card = next(
        (
            item
            for item in cards
            if item.get("heal_id") == inputs.heal_id
        ),
        None,
    )
    case = next(
        (
            item
            for item in cases
            if item.get("case_id") == inputs.case_id
        ),
        None,
    )
    if card is None:
        raise ProtocolViolation(
            f"missing Healer card: {inputs.heal_id}"
        )
    if case is None:
        raise ProtocolViolation(
            f"missing Healer case: {inputs.case_id}"
        )
    if case.get("heal_id") != inputs.heal_id:
        raise ProtocolViolation(
            "Healer case is linked to the wrong card"
        )
    if card.get("severity") not in {"P0", "CRITICAL"}:
        raise ProtocolViolation(
            "critical delivery incident is not P0/CRITICAL"
        )
    if card.get("action_priority") != "immediate":
        raise ProtocolViolation(
            "critical delivery incident is not immediate"
        )
    if card.get("medical_maturity") != "fully_protocolized":
        raise ProtocolViolation(
            "critical delivery incident lacks full protocol"
        )
    if inputs.case_id not in card.get("casebook_refs", []):
        raise ProtocolViolation("Healer card lacks casebook reference")

    required_text_files = (
        "HEALER_ATLAS.md",
        "docs/healer/HEALER_ATLAS.md",
        "docs/healer/HEALER_CASEBOOK.md",
        "EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md",
    )
    for relative in required_text_files:
        text = _read_text(inputs.root / relative)
        if inputs.heal_id not in text or inputs.case_id not in text:
            raise ProtocolViolation(
                f"Healer triple-write incomplete: {relative} lacks "
                f"{inputs.heal_id}/{inputs.case_id}"
            )


def validate_cycle_claims(inputs: DeliveryInputs) -> None:
    payload = _read_json(inputs.generated_report)
    if payload.get("archive_version") != inputs.version:
        raise ProtocolViolation(
            "generated report version does not match target"
        )
    if int(payload.get("cycle", -1)) != inputs.cycle:
        raise ProtocolViolation(
            "generated report cycle does not match target"
        )

    cycle_status = str(payload.get("cycle_status", "")).upper()
    allowed_cycle_statuses = {
        "ACTIVE",
        "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED",
    }
    if cycle_status not in allowed_cycle_statuses:
        raise ProtocolViolation("unsupported cycle status")

    live_proof = payload.get("live_proof")
    if not isinstance(live_proof, dict):
        raise ProtocolViolation(
            "generated report lacks live_proof object"
        )
    required_live = (
        "live_telegram",
        "real_tonconnect",
        "real_tonproof",
        "real_transaction",
    )
    live_values = {
        key: bool(live_proof.get(key))
        for key in required_live
    }
    all_live_verified = all(live_values.values())

    if inputs.cycle == 1573 and not all_live_verified:
        next_cycle = str(payload.get("next_cycle", ""))
        completion_claim = str(
            payload.get("completion_claim", "")
        ).upper()
        disposition = str(
            payload.get("external_verification_disposition", "")
        ).upper()
        local_scope_complete = (
            payload.get("local_scope_complete") is True
        )
        release_ready = payload.get("release_ready") is True
        explicit_deferral = (
            cycle_status == "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED"
            and completion_claim
            == "LOCAL_SCOPE_COMPLETE_EXTERNAL_DEFERRED"
            and disposition == "DEFERRED_POST_RELEASE_BY_USER"
            and local_scope_complete
            and not release_ready
        )

        if "1574" in next_cycle and not explicit_deferral:
            raise ProtocolViolation(
                "cycle 1573 cannot advance without live proof or "
                "explicit user-authorized post-release deferral"
            )
        if "1574" not in next_cycle and completion_claim not in {
            "NOT_COMPLETE",
            "ACTIVE_NOT_COMPLETE",
        }:
            raise ProtocolViolation(
                "cycle 1573 must state NOT_COMPLETE unless explicit "
                "deferral applies"
            )
        if explicit_deferral and "1574" not in next_cycle:
            raise ProtocolViolation(
                "explicit cycle 1573 deferral must identify cycle "
                "1574 as next"
            )

    report_text = _read_text(inputs.report).lower()
    if inputs.version.lower() not in report_text:
        raise ProtocolViolation(
            "change report does not identify target version"
        )
    if f"cycle {inputs.cycle}" not in report_text:
        raise ProtocolViolation(
            "change report does not identify target cycle"
        )
    if inputs.cycle == 1573 and not all_live_verified:
        forbidden_claims = (
            "cycle 1573 — complete",
            "cycle 1573 is complete",
            "цикл 1573 завершён полностью",
            "цикл 1573 выполнен полностью",
            "live telegram verified",
            "real tonconnect verified",
            "real tonproof verified",
            "real transaction verified",
            "status: release-ready",
            "is release-ready",
            "status: production-ready",
            "is production-ready",
        )
        if any(claim in report_text for claim in forbidden_claims):
            raise ProtocolViolation(
                "change report makes an unsupported completion/live/"
                "release claim"
            )


def validate_screenshot_provenance(
    inputs: DeliveryInputs,
) -> dict[str, Any] | None:
    if inputs.screenshot_mode == "none":
        if inputs.ui_change:
            raise ProtocolViolation(
                "UI change requires screenshot evidence"
            )
        if (
            inputs.manifest is not None
            or inputs.screenshots_archive is not None
        ):
            raise ProtocolViolation(
                "screenshot mode none has unexpected artifacts"
            )
        return None

    if inputs.manifest is None or inputs.screenshots_archive is None:
        raise ProtocolViolation(
            "screenshot mode requires manifest and archive"
        )
    payload = _read_json(inputs.manifest)
    if payload.get("archive_version") != inputs.version:
        raise ProtocolViolation("screenshot manifest version mismatch")
    if int(payload.get("cycle", -1)) != inputs.cycle:
        raise ProtocolViolation("screenshot manifest cycle mismatch")

    proof_text = " ".join(
        str(payload.get(key, ""))
        for key in ("proof_type", "proof_method", "status", "note")
    ).lower()
    if any(word in proof_text for word in FORBIDDEN_PROOF_WORDS):
        raise ProtocolViolation(
            "synthetic/mock screenshots cannot be app proof"
        )

    files = payload.get("files")
    if not isinstance(files, list) or not files:
        raise ProtocolViolation("screenshot manifest has no files")
    fresh_count = int(payload.get("fresh_cycle_png_count", -1))
    if inputs.screenshot_mode == "fresh":
        if not inputs.ui_change:
            raise ProtocolViolation(
                "fresh screenshot mode requires UI change"
            )
        if fresh_count <= 0:
            raise ProtocolViolation(
                "fresh screenshot mode has no fresh PNG"
            )
        if payload.get("inherited_from"):
            raise ProtocolViolation(
                "fresh screenshot mode cannot be inherited"
            )
    elif inputs.screenshot_mode == "inherited":
        if inputs.ui_change:
            raise ProtocolViolation(
                "inherited screenshots cannot prove a UI change"
            )
        if fresh_count != 0:
            raise ProtocolViolation(
                "inherited screenshot mode must have zero fresh PNG"
            )
        if not payload.get("inherited_from"):
            raise ProtocolViolation(
                "inherited screenshot mode lacks source version"
            )
        if payload.get("ui_change") is not False:
            raise ProtocolViolation(
                "inherited screenshot manifest must state "
                "ui_change=false"
            )
    else:
        raise ProtocolViolation(
            "unsupported screenshot mode: "
            f"{inputs.screenshot_mode}"
        )
    return payload


def validate_main_archive(inputs: DeliveryInputs) -> dict[str, Any]:
    archive = inputs.main_archive
    expected_name = (
        f"EFHC_Bot_{inputs.version.replace('.', '_')}.zip"
    )
    if archive.name != expected_name:
        raise ProtocolViolation(
            f"unexpected main archive name: {archive.name}"
        )
    if not archive.is_file():
        raise ProtocolViolation(f"missing main archive: {archive}")
    with zipfile.ZipFile(archive) as handle:
        bad = handle.testzip()
        if bad is not None:
            raise ProtocolViolation(
                f"main ZIP integrity failure: {bad}"
            )
        names = {
            _normalise_zip_name(name)
            for name in handle.namelist()
        }
        for required in REQUIRED_ARCHIVE_FILES:
            if required not in names:
                raise ProtocolViolation(
                    f"main archive lacks required file: {required}"
                )
        for name in names:
            padded = f"/{name}"
            if any(part in padded for part in FORBIDDEN_ARCHIVE_PARTS):
                raise ProtocolViolation(
                    f"main archive contains junk: {name}"
                )
            if name.lower().endswith(".zip"):
                raise ProtocolViolation(
                    f"main archive contains nested ZIP: {name}"
                )
            if name.startswith("reports/screenshots/"):
                raise ProtocolViolation(
                    "main archive contains technical screenshot: "
                    f"{name}"
                )
    return {
        "name": archive.name,
        "sha256": _sha256(archive),
        "size_bytes": archive.stat().st_size,
        "zip_integrity": "OK",
    }


def validate_screenshot_archive(
    inputs: DeliveryInputs,
    manifest: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if manifest is None:
        return None
    archive = inputs.screenshots_archive
    assert archive is not None
    expected_name = (
        f"EFHC_Bot_{inputs.version.replace('.', '_')}_Screenshots.zip"
    )
    if archive.name != expected_name:
        raise ProtocolViolation(
            f"unexpected screenshot archive name: {archive.name}"
        )
    if not archive.is_file():
        raise ProtocolViolation(
            f"missing screenshot archive: {archive}"
        )

    expected_files = {
        str(item["path"]): item for item in manifest.get("files", [])
    }
    with zipfile.ZipFile(archive) as handle:
        bad = handle.testzip()
        if bad is not None:
            raise ProtocolViolation(
                f"screenshot ZIP integrity failure: {bad}"
            )
        names = {
            _normalise_zip_name(name)
            for name in handle.namelist()
            if not name.endswith("/")
        }
        png_names = {
            name
            for name in names
            if name.lower().endswith(".png")
        }
        if png_names != set(expected_files):
            missing = sorted(set(expected_files) - png_names)
            extra = sorted(png_names - set(expected_files))
            raise ProtocolViolation(
                "screenshot archive/manifest mismatch: "
                f"missing={missing}, extra={extra}"
            )
        for name, item in expected_files.items():
            data = handle.read(name)
            digest = hashlib.sha256(data).hexdigest()
            if digest != item.get("sha256"):
                raise ProtocolViolation(
                    f"screenshot SHA mismatch: {name}"
                )
            if len(data) != int(item.get("size_bytes", -1)):
                raise ProtocolViolation(
                    f"screenshot size mismatch: {name}"
                )
    return {
        "name": archive.name,
        "sha256": _sha256(archive),
        "size_bytes": archive.stat().st_size,
        "zip_integrity": "OK",
        "png_count": len(expected_files),
        "mode": inputs.screenshot_mode,
    }


def run_gate(inputs: DeliveryInputs) -> dict[str, Any]:
    validate_head_sync(inputs)
    validate_healer_triple_write(inputs)
    validate_cycle_claims(inputs)
    cycle_payload = _read_json(inputs.generated_report)
    manifest = validate_screenshot_provenance(inputs)
    main_meta = validate_main_archive(inputs)
    screenshot_meta = validate_screenshot_archive(inputs, manifest)

    receipt = {
        "schema": "EFHC_CRITICAL_DELIVERY_RECEIPT_V1",
        "gate_status": "PASS",
        "release_permission": "USER_DELIVERY_ALLOWED",
        "archive_version": inputs.version,
        "cycle": inputs.cycle,
        "cycle_status": cycle_payload.get("cycle_status", "UNKNOWN"),
        "external_verification_disposition": cycle_payload.get(
            "external_verification_disposition", "OPEN"
        ),
        "release_ready": bool(
            cycle_payload.get("release_ready") is True
        ),
        "ui_change": inputs.ui_change,
        "screenshot_mode": inputs.screenshot_mode,
        "healer_card": inputs.heal_id,
        "healer_case": inputs.case_id,
        "main_archive": main_meta,
        "screenshots_archive": screenshot_meta,
        "required_user_delivery": [
            "clickable main archive link",
            "clickable screenshot archive link when present",
            "visible screenshots in chat when requested",
            "change report and exact non-claims",
        ],
        "blocked_claims": [
            "full/live cycle completion without required evidence",
            (
                "cycle advancement without evidence or explicit "
                "user deferral"
            ),
            "live Telegram without evidence",
            "real TonConnect/TonProof without evidence",
            "real transaction without evidence",
            "release-ready without evidence",
        ],
    }
    inputs.receipt_out.parent.mkdir(parents=True, exist_ok=True)
    inputs.receipt_out.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return receipt


def parse_args() -> DeliveryInputs:
    parser = argparse.ArgumentParser(
        description="Fail-closed Healer delivery protocol gate."
    )
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--cycle", type=int, required=True)
    parser.add_argument("--main-archive", type=Path, required=True)
    parser.add_argument("--screenshots-archive", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--generated-report", type=Path, required=True)
    parser.add_argument(
        "--screenshot-mode",
        choices=("fresh", "inherited", "none"),
        required=True,
    )
    parser.add_argument(
        "--ui-change",
        choices=("yes", "no"),
        required=True,
    )
    parser.add_argument("--heal-id", required=True)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--receipt-out", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()

    def resolve_from_root(path: Path | None) -> Path | None:
        if path is None or path.is_absolute():
            return path
        return root / path

    return DeliveryInputs(
        root=root,
        version=args.version,
        cycle=args.cycle,
        main_archive=args.main_archive.resolve(),
        screenshots_archive=(
            args.screenshots_archive.resolve()
            if args.screenshots_archive is not None
            else None
        ),
        manifest=resolve_from_root(args.manifest),
        report=resolve_from_root(args.report) or root,
        generated_report=(
            resolve_from_root(args.generated_report) or root
        ),
        screenshot_mode=args.screenshot_mode,
        ui_change=args.ui_change == "yes",
        heal_id=args.heal_id,
        case_id=args.case_id,
        receipt_out=args.receipt_out.resolve(),
    )


def main() -> int:
    inputs = parse_args()
    try:
        receipt = run_gate(inputs)
    except ProtocolViolation as exc:
        print(f"CRITICAL_DELIVERY_PROTOCOL: BLOCKED_PROTOCOL: {exc}")
        return 1
    print(
        "CRITICAL_DELIVERY_PROTOCOL: PASS: "
        f"{receipt['archive_version']} / cycle {receipt['cycle']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
