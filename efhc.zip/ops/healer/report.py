from __future__ import annotations

import json
from pathlib import Path

from .models import Finding, HealerCase, UnknownFinding


def _finding_dict(item: Finding) -> dict[str, object]:
    return {
        "heal_id": item.heal_id,
        "file": item.file_path,
        "line": item.line_no,
        "excerpt": item.excerpt,
        "reason": item.reason,
        "docs_checked": item.docs_checked,
        "case_ids": item.case_ids,
    }


def _unknown_dict(item: UnknownFinding) -> dict[str, object]:
    return {
        "symptom_id": item.symptom_id,
        "source": item.source,
        "file_path": item.file_path,
        "raw_excerpt": item.raw_excerpt,
        "suggested_category": item.suggested_category,
        "why_not_confirmed": item.why_not_confirmed,
        "docs_checked": item.docs_checked,
        "timestamp": item.timestamp,
    }


def _case_dict(item: HealerCase) -> dict[str, object]:
    return {
        "case_id": item.case_id,
        "heal_id": item.heal_id,
        "title": item.title,
        "status": item.status,
        "archive_version": item.archive_version,
        "zones": item.zones,
        "related_files": item.related_files,
    }


def write_scan_report(
    out_dir: Path,
    atlas_version: str,
    head_source: str,
    docs_checked: list[str],
    findings: list[Finding],
    unknowns: list[UnknownFinding],
) -> None:
    payload = {
        "timestamp": "generated",
        "source_archive": head_source,
        "docs_checked": docs_checked,
        "atlas_version": atlas_version,
        "findings": [_finding_dict(item) for item in findings],
        "unknown_findings": [_unknown_dict(item) for item in unknowns],
        "findings_total": len(findings),
        "unknown_total": len(unknowns),
        "confirmed_diseases": sorted(
            {item.heal_id for item in findings}
        ),
        "recommended_treatment": [item.reason for item in findings],
    }
    (out_dir / "_last_scan_report.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# EFHC Healer Scan Report",
        "",
        f"Source archive: {head_source}",
        f"Atlas version: {atlas_version}",
        f"Findings total: {len(findings)}",
        f"Unknown total: {len(unknowns)}",
        "",
    ]
    for item in findings:
        lines.append(f"- {item.heal_id} — {item.pointer}")
    (out_dir / "_last_scan_report.md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )
    (out_dir / "_unknown_findings.json").write_text(
        json.dumps(
            [_unknown_dict(item) for item in unknowns],
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def write_memory_snapshot(
    out_dir: Path,
    casebook_version: str,
    cases: list[HealerCase],
) -> None:
    payload = {
        "casebook_version": casebook_version,
        "cases_total": len(cases),
        "known_cases": [_case_dict(item) for item in cases],
    }
    (out_dir / "_last_memory_snapshot.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# EFHC Healer Memory Snapshot",
        "",
        f"Casebook version: {casebook_version}",
        f"Cases total: {len(cases)}",
        "",
    ]
    for item in cases[:20]:
        lines.append(f"- {item.case_id} — {item.title}")
    (out_dir / "_last_memory_snapshot.md").write_text(
        "\n".join(lines) + "\n",
        encoding="utf-8",
    )
