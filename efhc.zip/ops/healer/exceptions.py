from __future__ import annotations

from pathlib import Path


def is_exception(
    rules: list[str],
    rel_path: str,
    line: str,
) -> bool:
    low_path = rel_path.lower()
    suffix = Path(rel_path).suffix.lower()
    low_line = line.lower()
    for rule in rules:
        key = rule.lower().strip()
        if key == "path:docs/*" and low_path.startswith("docs/"):
            return True
        if key == "path:backend/migrations/*" and low_path.startswith(
            "backend/migrations/"
        ):
            return True
        if key == "path:tests/*" and low_path.startswith("tests/"):
            return True
        if key == "filekind:markdown_examples" and suffix == ".md":
            return True
        if key == "domain:ssot_tables" and "ssot" in low_path:
            return True
        if key.startswith("line:"):
            needle = key.split(":", 1)[1]
            if needle and needle in low_line:
                return True
    return False
