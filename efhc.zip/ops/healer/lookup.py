from __future__ import annotations

from .matcher import confirm_symptom
from .models import LookupResult, ScanContext, Symptom


def lookup_symptom(
    ctx: ScanContext,
    symptom_text: str,
    file_path: str = "lookup/input.txt",
) -> LookupResult | None:
    symptom = Symptom(
        symptom_id="lookup:1",
        source="lookup",
        file_path=file_path,
        line_no=1,
        excerpt=symptom_text[:72],
        raw_text=symptom_text,
        timestamp="lookup",
    )
    match = confirm_symptom(ctx, symptom)
    if match is None:
        return None
    related = [
        item
        for item in ctx.casebook
        if item.heal_id == match.card.heal_id
    ]
    where_else = sorted(
        {path for item in related for path in item.where_else_to_check}
    )
    return LookupResult(
        heal_id=match.card.heal_id,
        disease_name=match.card.name,
        confidence=match.score,
        case_ids=match.case_ids,
        treatment=match.card.treatment,
        forbidden_actions=match.card.forbidden_actions,
        where_else_to_check=where_else,
    )
