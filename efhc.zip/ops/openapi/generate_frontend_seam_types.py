from __future__ import annotations

import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "frontend/src/lib/api/generated/adminSeams.ts"
OPENAPI = ROOT / "backend/openapi/openapi.json"

MODEL_SOURCES = {
    "AdminReferralSummaryItem": (
        ROOT / "backend/app/routes/admin_referral_routes.py",
        "SummaryItem",
    ),
    "AdminReferralSummaryResponse": (
        ROOT / "backend/app/routes/admin_referral_routes.py",
        "SummaryResponse",
    ),
    "AdminWithdrawalRecord": (
        (
            ROOT / "backend/app/services/admin/"
            "admin_withdrawals_service.py"
        ),
        "WithdrawalRecord",
    ),
    "AdminWithdrawRepairOut": (
        ROOT / "backend/app/routes/admin_withdrawals_routes.py",
        "WithdrawRepairOut",
    ),
    "AdminBankMintBurnRequest": (
        ROOT / "backend/app/services/admin/admin_bank_service.py",
        "MintBurnRequest",
    ),
    "AdminHubLink": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminOut",
    ),
    "AdminHubLinkCreateRequest": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminCreateIn",
    ),
    "AdminHubLinkUpdateRequest": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminUpdateIn",
    ),
    "AdminHubLinkToggleRequest": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminToggleIn",
    ),
    "AdminHubLinkReorderItem": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminReorderItem",
    ),
    "AdminHubLinkReorderRequest": (
        ROOT / "backend/app/schemas/hub_admin_schemas.py",
        "HubLinkAdminReorderIn",
    ),
}

MANUAL_TYPES = {
    "AdminBankBalanceResponse": (
        "export type AdminBankBalanceResponse = {\n"
        "  bank_name: string;\n"
        "  efhc_main: string;\n"
        "};\n"
    ),
    "AdminBankMutationResponse": (
        "export type AdminBankMutationResponse = {\n"
        "  ok: boolean;\n"
        "  bank_balance_after: string;\n"
        "};\n"
    ),
    "AdminWithdrawApproveRequest": (
        "export type AdminWithdrawApproveRequest = {\n"
        "  tx_hash?: string | null;\n"
        "  payout_ref?: string | null;\n"
        "  wallet_send_confirmed?: boolean;\n"
        "  wallet_provider?: string | null;\n"
        "  sender_wallet_address?: string | null;\n"
        "  comment_override?: string | null;\n"
        "  comment_auto_translated?: boolean;\n"
        "};\n"
    ),
    "AdminWithdrawRejectRequest": (
        "export type AdminWithdrawRejectRequest = {\n"
        "  reason: string;\n"
        "  comment_override?: string | null;\n"
        "  comment_auto_translated?: boolean;\n"
        "};\n"
    ),
    "AdminWithdrawActionResponse": (
        "export type AdminWithdrawActionResponse = {\n"
        "  ok: boolean;\n"
        "  result: unknown;\n"
        "};\n"
    ),

    "AdminWithdrawOutcomePreviewResponse": (
        "export type AdminWithdrawOutcomeComment = {\n"
        "  text: string;\n"
        "  template_key?: string | null;\n"
        "  source: string;\n"
        "  locale: string;\n"
        "  manual_override_used?: boolean;\n"
        "  auto_translated?: boolean;\n"
        "};\n\n"
        "export type AdminWithdrawOutcomePromo = {\n"
        "  enabled: boolean;\n"
        "  key?: string | null;\n"
        "  title?: string | null;\n"
        "  body?: string | null;\n"
        "  cta_label?: string | null;\n"
        "  cta_url?: string | null;\n"
        "  source?: string | null;\n"
        "};\n\n"
        "export type AdminWithdrawOutcomeBundle = {\n"
        "  request_id: number;\n"
        "  tg_id: number;\n"
        "  outcome_kind: string;\n"
        "  locale: string;\n"
        "  comment: AdminWithdrawOutcomeComment;\n"
        "  promo?: AdminWithdrawOutcomePromo | null;\n"
        "  top_zone_enabled: boolean;\n"
        "  metadata: Record<string, unknown>;\n"
        "};\n\n"
        "export type AdminWithdrawOutcomePreviewResponse = {\n"
        "  request_id: number;\n"
        "  withdrawal_status: string;\n"
        "  preview_mode: string;\n"
        "  bundle: AdminWithdrawOutcomeBundle;\n"
        "};\n"
    ),
    "AdminDomainReportResponse": (
        "export type AdminDomainReportTrendPoint = {\n"
        "  bucket: string;\n"
        "  value: number;\n"
        "};\n\n"
        "export type AdminDomainReportResponse = {\n"
        "  ok: boolean;\n"
        "  data_kind: 'real_timeseries';\n"
        "  synthetic: boolean;\n"
        "  domain: string;\n"
        "  range_hours: number;\n"
        "  generated_at: string;\n"
        "  snapshot: Record<string, number>;\n"
        "  trend: AdminDomainReportTrendPoint[];\n"
        "  empty_reason: string | null;\n"
        "};\n"
    ),
    "AdminObservabilityContracts": (
        "export type AdminObservabilitySeriesPoint = {\n"
        "  ts: string;\n"
        "  value: string;\n"
        "  label?: string | null;\n"
        "};\n\n"
        "export type AdminObservabilityTimeseriesResponse = {\n"
        "  ok: boolean;\n"
        "  data_kind: 'real_timeseries';\n"
        "  synthetic: boolean;\n"
        "  metric:\n"
        "    | 'users_created'\n"
        "    | 'panels_created'\n"
        "    | 'withdrawals_created'\n"
        "    | 'payment_intents_created'\n"
        "    | 'efhc_transfer_count'\n"
        "    | 'efhc_transfer_amount'\n"
        "    | 'efhc_credit_amount'\n"
        "    | 'efhc_debit_amount';\n"
        "  bucket: 'hour' | 'day';\n"
        "  range_hours: number;\n"
        "  unit: string;\n"
        "  source: string;\n"
        "  points: AdminObservabilitySeriesPoint[];\n"
        "  empty_reason?: string | null;\n"
        "};\n\n"
        "export type AdminObservabilitySummaryMetric = {\n"
        "  key: string;\n"
        "  label: string;\n"
        "  value: string;\n"
        "  unit: string;\n"
        "  source: string;\n"
        "  data_kind: 'raw' | 'derived';\n"
        "};\n\n"
        "export type AdminObservabilitySummaryResponse = {\n"
        "  ok: boolean;\n"
        "  data_kind: 'raw' | 'derived';\n"
        "  generated_at: string;\n"
        "  source: string;\n"
        "  metrics: AdminObservabilitySummaryMetric[];\n"
        "};\n\n"
        "export type AdminObservabilityEvent = {\n"
        "  id: string;\n"
        "  type: string;\n"
        "  severity: 'info' | 'success' | 'warning' | 'danger';\n"
        "  title: string;\n"
        "  description?: string | null;\n"
        "  ts: string;\n"
        "  route?: string | null;\n"
        "  source: string;\n"
        "};\n\n"
        "export type AdminObservabilityEventsResponse = {\n"
        "  ok: boolean;\n"
        "  data_kind: 'raw';\n"
        "  source: string;\n"
        "  items: AdminObservabilityEvent[];\n"
        "};\n"
    ),
}

PATH_EXPORTS = {
    "ADMIN_ADS_PROVIDERS_PATH": "/admin/ads/providers",
    "ADMIN_BANK_BALANCE_PATH": "/admin/bank/balance",
    "ADMIN_BANK_BURN_PATH": "/admin/bank/burn",
    "ADMIN_BANK_MINT_PATH": "/admin/bank/mint",
    "ADMIN_EFHC_DEPOSITS_PROCESS_PATH": "/admin/efhc-deposits/process",
    "ADMIN_EFHC_DEPOSITS_REPROCESS_TX_HASH_PATH": (
        "/admin/efhc-deposits/reprocess/{tx_hash}"
    ),
    "ADMIN_EFHC_DEPOSITS_RUNTIME_SUMMARY_PATH": (
        "/admin/efhc-deposits/runtime-summary"
    ),
    "ADMIN_HUB_LINKS_PATH": "/admin/hub/links",
    "ADMIN_HUB_LINKS_REORDER_PATH": "/admin/hub/links/reorder",
    "ADMIN_HUB_LINKS_LINK_ID_PATH": "/admin/hub/links/{link_id}",
    "ADMIN_HUB_LINKS_LINK_ID_TOGGLE_PATH": (
        "/admin/hub/links/{link_id}/toggle"
    ),
    "ADMIN_LOGS_TRANSFERS_PATH": "/admin/logs/transfers",
    "ADMIN_OBSERVABILITY_EVENTS_PATH": "/admin/observability/events",
    "ADMIN_OBSERVABILITY_HEALTH_PATH": "/admin/observability/health",
    "ADMIN_OBSERVABILITY_SUMMARY_PATH": "/admin/observability/summary",
    "ADMIN_OBSERVABILITY_TIMESERIES_PATH": (
        "/admin/observability/timeseries"
    ),
    "ADMIN_PANELS_PATH": "/admin/panels/",
    "ADMIN_PANELS_PANEL_ID_ACTIVATE_PATH": (
        "/admin/panels/{panel_id}/activate"
    ),
    "ADMIN_PANELS_PANEL_ID_DEACTIVATE_PATH": (
        "/admin/panels/{panel_id}/deactivate"
    ),
    "ADMIN_REFERRALS_SUMMARY_PATH": "/admin/referrals/summary",
    "ADMIN_REPORTS_BANK_PATH": "/admin/reports/bank",
    "ADMIN_REPORTS_DEPOSITS_PATH": "/admin/reports/deposits",
    "ADMIN_REPORTS_OVERVIEW_PATH": "/admin/reports/overview",
    "ADMIN_REPORTS_PANELS_PATH": "/admin/reports/panels",
    "ADMIN_REPORTS_USERS_PATH": "/admin/reports/users",
    "ADMIN_REPORTS_WITHDRAWALS_PATH": "/admin/reports/withdrawals",
    "ADMIN_SALE_PACKAGES_PATH": "/admin/sale-packages/",
    "ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH": (
        "/admin/sale-packages/{package_id}"
    ),
    "ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH": (
        "/admin/sale-packages/{package_id}/toggle"
    ),
    "ADMIN_SHOP_ITEMS_PATH": "/admin/shop/items",
    "ADMIN_SHOP_ITEMS_DELETE_PATH": "/admin/shop/items/delete",
    "ADMIN_SHOP_ITEMS_SET_PRICE_PATH": "/admin/shop/items/set-price",
    "ADMIN_SHOP_ITEMS_STATUS_PATH": "/admin/shop/items/status",
    "ADMIN_SHOP_ITEMS_UPSERT_PATH": "/admin/shop/items/upsert",
    "ADMIN_SHOP_ORDER_LEGACY_ORDER_ID_PATH": (
        "/admin/shop/order/legacy/{order_id}"
    ),
    "ADMIN_SHOP_ORDERS_PATH": "/admin/shop/orders",
    "ADMIN_SHOP_ORDERS_USER_LEGACY_TG_ID_PATH": (
        "/admin/shop/orders/user/legacy/{tg_id}"
    ),
    "ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH": (
        "/admin/shop/orders/{order_id}/force-fulfill"
    ),
    "ADMIN_TASKS_PATH": "/admin/tasks/",
    "ADMIN_TASKS_REFRESH_STATUSES_PATH": (
        "/admin/tasks/refresh-statuses"
    ),
    "ADMIN_TASKS_SUBMISSIONS_SUBMISSION_ID_MODERATE_PATH": (
        "/admin/tasks/submissions/{submission_id}/moderate"
    ),
    "ADMIN_TASKS_TASK_ID_PATH": "/admin/tasks/{task_id}",
    "ADMIN_TASKS_TASK_ID_SUBS_PATH": "/admin/tasks/{task_id}/subs",
    "ADMIN_TEMPLATES_PATH": "/admin/templates",
    "ADMIN_TEMPLATES_KEY_PATH": "/admin/templates/{key}",
    "ADMIN_TON_RECONCILE_PATH": "/admin/ton/reconcile",
    "ADMIN_TRANSFER_PATH": "/admin/transfer",
    "ADMIN_USERS_SEARCH_PATH": "/admin/users/search",
    "ADMIN_USERS_GLOBAL_ID_PATH": "/admin/users/{global_id}",
    "ADMIN_USERS_GLOBAL_ID_ACTIVE_PATH": (
        "/admin/users/{global_id}/active"
    ),
    "ADMIN_USERS_GLOBAL_ID_VIP_PATH": "/admin/users/{global_id}/vip",
    "ADMIN_USERS_GLOBAL_ID_WALLET_RESET_PATH": (
        "/admin/users/{global_id}/wallet/reset"
    ),
    "ADMIN_WITHDRAWALS_PATH": "/admin/withdrawals",
    "ADMIN_WITHDRAWALS_REPAIR_CONSISTENCY_PATH": (
        "/admin/withdrawals/repair-consistency"
    ),
    "ADMIN_WITHDRAWALS_REQUEST_ID_APPROVE_PATH": (
        "/admin/withdrawals/{request_id}/approve"
    ),
    "ADMIN_WITHDRAWALS_REQUEST_ID_OUTCOME_PREVIEW_PATH": (
        "/admin/withdrawals/{request_id}/outcome-preview"
    ),
    "ADMIN_WITHDRAWALS_REQUEST_ID_REJECT_PATH": (
        "/admin/withdrawals/{request_id}/reject"
    ),
}

# Stable aliases kept for existing frontend pages/tests while the full
# admin seam migration is completed in tracked frontend-only cycles.
PATH_EXPORT_ALIASES = {
    "ADMIN_WITHDRAW_APPROVE_PATH": (
        "ADMIN_WITHDRAWALS_REQUEST_ID_APPROVE_PATH"
    ),
    "ADMIN_WITHDRAW_REJECT_PATH": (
        "ADMIN_WITHDRAWALS_REQUEST_ID_REJECT_PATH"
    ),
    "ADMIN_WITHDRAW_OUTCOME_PREVIEW_PATH": (
        "ADMIN_WITHDRAWALS_REQUEST_ID_OUTCOME_PREVIEW_PATH"
    ),
    "ADMIN_HUB_LINK_CREATE_PATH": "ADMIN_HUB_LINKS_PATH",
    "ADMIN_HUB_LINK_UPDATE_PATH": "ADMIN_HUB_LINKS_LINK_ID_PATH",
    "ADMIN_HUB_LINK_TOGGLE_PATH": (
        "ADMIN_HUB_LINKS_LINK_ID_TOGGLE_PATH"
    ),
    "ADMIN_HUB_LINK_REORDER_PATH": "ADMIN_HUB_LINKS_REORDER_PATH",
    "ADMIN_REFERRAL_SUMMARY_PATH": "ADMIN_REFERRALS_SUMMARY_PATH",
}


def ann_to_ts(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return {
            "int": "number",
            "float": "number",
            "str": "string",
            "bool": "boolean",
            "Any": "unknown",
            "Decimal": "string",
            "datetime": "string",
        }.get(
            node.id,
            {
                "SummaryItem": "AdminReferralSummaryItem",
                "HubLinkAdminReorderItem": (
                    "AdminHubLinkReorderItem"
                ),
            }.get(
                node.id,
                node.id,
            ),
        )
    if isinstance(node, ast.Constant):
        if node.value is None:
            return "null"
        if isinstance(node.value, str):
            return repr(node.value)
    if isinstance(node, ast.Subscript):
        base = ann_to_ts(node.value)
        sub = node.slice
        if base in {"list", "List"}:
            return f"{ann_to_ts(sub)}[]"
        if base in {"dict", "Dict"}:
            return "Record<string, unknown>"
        if base == "Literal":
            if isinstance(sub, ast.Tuple):
                vals = [ann_to_ts(elt) for elt in sub.elts]
            else:
                vals = [ann_to_ts(sub)]
            return " | ".join(vals)
        return "unknown"
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        return f"{ann_to_ts(node.left)} | {ann_to_ts(node.right)}"
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Tuple):
        return " | ".join(ann_to_ts(elt) for elt in node.elts)
    return "unknown"


def extract_model(path: Path, class_name: str) -> str:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            fields = []
            for item in node.body:
                if isinstance(item, ast.AnnAssign) and isinstance(
                    item.target, ast.Name
                ):
                    fields.append(
                        (item.target.id, ann_to_ts(item.annotation))
                    )
            return "\n".join(f"  {name}: {ts};" for name, ts in fields)
    raise RuntimeError(f"Model {class_name} not found in {path}")


def validate_paths() -> None:
    spec = json.loads(OPENAPI.read_text(encoding="utf-8"))
    normalized = {
        p[4:] if p.startswith("/api/") else p
        for p in spec.get("paths", {})
    }
    missing = [
        value
        for value in PATH_EXPORTS.values()
        if value not in normalized
    ]
    if missing:
        raise RuntimeError(
            f"Missing seam paths in openapi snapshot: {missing}"
        )


def main() -> None:
    validate_paths()
    parts = [
        "// AUTO-GENERATED FILE. DO NOT EDIT MANUALLY.\n",
        "// Source: ops/openapi/generate_frontend_seam_types.py\n\n",
        "import {\n"
        "  apiRequest,\n"
        "  type ApiRequestOptions,\n"
        "  type HttpMethod,\n"
        "} from \"../../api\";\n\n",
        "export function adminPath(\n"
        "  template: string,\n"
        "  values: Record<string, string | number>,\n"
        "): string {\n"
        "  let out = template;\n"
        "  for (const [key, value] of Object.entries(values)) {\n"
        "    out = out.replace(\n"
        "      `{${key}}`,\n"
        "      encodeURIComponent(String(value)),\n"
        "    );\n"
        "  }\n"
        "  return out;\n"
        "}\n\n",
        "export async function adminApiRequest<T>(\n"
        "  path: string,\n"
        "  method: HttpMethod,\n"
        "  opts: ApiRequestOptions = {},\n"
        "): Promise<T> {\n"
        "  return apiRequest<T>(path, method, opts);\n"
        "}\n\n",
    ]
    for key, value in PATH_EXPORTS.items():
        parts.append(f'export const {key} =\n  "{value}" as const;\n')
    for alias, target in PATH_EXPORT_ALIASES.items():
        line = f"export const {alias} = {target};"
        if len(line) <= 72:
            parts.append(line + "\n")
        else:
            parts.append(f"export const {alias} =\n  {target};\n")
    parts.append("\n")
    for alias, (path, class_name) in MODEL_SOURCES.items():
        body = extract_model(path, class_name)
        parts.append(f"export type {alias} = {{\n{body}\n}};\n\n")
    for _, text in MANUAL_TYPES.items():
        parts.append(text + "\n")
    OUT.write_text("".join(parts), encoding="utf-8")


if __name__ == "__main__":
    main()
