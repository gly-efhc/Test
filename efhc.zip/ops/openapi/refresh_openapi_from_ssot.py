"""Compatibility wrapper for the current OpenAPI snapshot rebuild.

Cycle 1442 moved the active rebuild source from stale hand-maintained
SSOT-only rows to backend route source parsing. Keep this
historical command
working by delegating to the current contract snapshot rebuilder.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    from ops.routes.rebuild_openapi_contract_snapshot import (
        main as rebuild_main,
    )

    return int(rebuild_main())


if __name__ == "__main__":
    raise SystemExit(main())
