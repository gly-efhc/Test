# api/index.py
# =====================================================================
# Назначение кода:
#   Точка входа FastAPI для деплоя на Vercel
#   (Python Serverless Function).
#   Vercel ожидает переменную `app` (ASGI-приложение).
#
# Канон/инварианты:
#   • Приложение EFHC — единый FastAPI app из backend/app/main.py.
#   • Никаких long-polling циклов в serverless.
#     Telegram работает через webhook.
# =====================================================================

from __future__ import annotations

import sys
from pathlib import Path

# Гарантируем, что корень репозитория и backend в sys.path.
ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
for entry in (ROOT, BACKEND):
    entry_str = str(entry)
    if entry_str not in sys.path:
        sys.path.insert(0, entry_str)

from app.core.env_loader import load_env_files  # noqa: E402

# Загружаем .env best-effort (локально) до импорта app.
# В Vercel ENV имеет приоритет.
load_env_files()

from app.main import app  # noqa: E402

__all__ = ["app"]
