# -*- coding: utf-8 -*-
# api/index.py
# =====================================================================
# Назначение кода:
#   Точка входа FastAPI для деплоя на Vercel
#   (Python Serverless Function).
#   Vercel ожидает переменную `app` (ASGI-приложение).
#
# Канон/инварианты:
#   • Приложение EFHC — единый FastAPI app из backend/app/main.py.
#   • Никаких long-polling циклов в serverless.
#     Telegram работает через webhook.
# =====================================================================

from __future__ import annotations

import sys
from pathlib import Path

# Гарантируем, что корень репозитория в sys.path (важно для Vercel).
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


from backend.app.core.env_loader import load_env_files  # noqa: E402

# Загружаем .env best-effort (локально).
# В Vercel ENV имеет приоритет.
load_env_files()

from backend.app.main import app  # noqa: E402

