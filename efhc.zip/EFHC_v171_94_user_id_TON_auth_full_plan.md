# EFHC Bot v171_94
## Полный план перехода `tg_id` → канонический `user_id` с первым входом через TON Connect

> Локальные номера `0–15` являются макрофазами, а не номерами
> проекта. Фундамент выполняется в циклах `1593–1600`; подробный
> roadmap закреплён на циклы `1601–1700`.

**Исходный архив цикла:** `EFHC_Bot_v171_93.zip`  
**Исходный SHA-256:** `e8a85d26cb517d7e5d62c9ab55e98284da5f3a00e7009b68ede8a42356090954`  
**Цикл актуализации:** `1596`  
**Архив результата:** `EFHC_Bot_v171_93.zip`  
**Стратегия:** `EXPAND → BACKFILL → DUAL WRITE → READ SWITCH → VALIDATE → CONTRACT`

## Статус цикла 1596

Завершена подготовка внешнего API/Pydantic-контракта:

- `PydanticUserId` принимает canonical string или validated `UserId`;
- `ApiExternalUserId` подготовлен для будущих path/query параметров;
- `UserIdRequest` и `UserIdResponse` запрещают лишние поля;
- OpenAPI фиксирует `type: string`, `pattern: ^[0-9]{{10}}$` и
  `format: efhc-user-id`;
- int, `TelegramId`, zero и Unicode digits отклоняются;
- active routes, existing DTO, ORM, Alembic, AuthContext, services,
  frontend ownership и финансовый runtime не переключены;
- реальная доменная зависимость от `tg_id` остаётся `2054` строк;
- PostgreSQL reconciliation не выполнен из-за отсутствия DB URL.

Следующий цикл: `1597 — users.user_id expand migration design and
PostgreSQL dry-run`.

---

# 1. Итоговое архитектурное решение

## 1.1. Канон имён

- системный пользователь во всех доменных моделях, API, сервисах, логах и интерфейсе: `user_id`;
- Telegram user ID везде, где речь именно о Telegram: `tg_id`;
- адрес TON-кошелька: `wallet_address`;
- внешний способ входа: `provider`;
- идентификатор пользователя у провайдера: `provider_subject`.

Запрещено считать `tg_id` и `user_id` взаимозаменяемыми.

## 1.2. Канон `user_id`

Целевое состояние базы (не реализовано через цикл 1595):

```text
users.user_id BIGINT PRIMARY KEY
CHECK (user_id BETWEEN 1 AND 9999999999)
```

Во внешнем API и frontend:

```text
0000000001
0000000002
...
9999999999
```

То есть физически в PostgreSQL хранится число, а каноническое представление наружу — строка длиной 10 цифр.

Обязательные helpers:

```python
UserId = immutable nominal value object

def format_user_id(value: UserId) -> UserIdDisplay:
    return value.display

def parse_user_id(value: object) -> UserId:
    # strict ten ASCII digits; zero is forbidden
    ...
```

Frontend хранит `user_id` только как `string`.

## 1.3. Допустимые алиасы

Разрешены временно:

1. `User.id` → ORM alias к `User.user_id`;
2. legacy `get_current_tg_id()` как Telegram-specific adapter поверх `AuthContext`;
3. временный приём legacy API-параметров с немедленным разрешением через `IdentityResolver`;
4. dual-write `user_id + tg_id` на переходном этапе.

Запрещены:

1. `tg_id = user_id`;
2. alias функции, где параметр называется `tg_id`, но содержит системный ID;
3. сохранение TON-only пользователя под фиктивным Telegram ID;
4. автоматическое вычисление `user_id` из `tg_id`;
5. использование wallet address как `user_id`.

---

# 2. Фактический аудит архива

| Область | Результат |
|---|---:|
| Точные упоминания `tg_id` в `backend/app` | 2 448 |
| Backend-файлы | 133 |
| Упоминания в сервисах | 1 498 |
| Упоминания в маршрутах | 398 |
| Упоминания в CRUD | 134 |
| Упоминания в bot | 116 |
| Упоминания в ORM-моделях | 89 |
| ORM-поля `tg_id`-семейства | 32 |
| Таблицы с такими ORM-полями | 29 |
| Аннотированные DTO/ORM/dataclass-поля | 117 в 59 файлах |
| Функции с `tg_id`-параметрами | 336 в 78 файлах |
| `Depends(get_current_tg_id)` | 54 применения в 16 файлах |
| Frontend | 375 упоминаний в 62 файлах |
| Тесты | 712 упоминаний в 107 файлах |
| Документация | 1 105 упоминаний в 267 файлах |

Вывод: задача имеет высокую сложность, но до публичного запуска остаётся контролируемой. Простая массовая замена текста недопустима.

---

# 3. Целевая модель данных

## 3.1. `users`

```text
users
────────────────────────────────────────
user_id              BIGINT PK
status               VARCHAR
primary_locale       VARCHAR NULL
last_authenticated_at TIMESTAMPTZ NULL
created_at
updated_at
```

Legacy `tg_id` на первом этапе становится nullable и перестаёт быть SSOT. В финале удаляется из `users`.

## 3.2. `user_identities`

```text
id
user_id FK users.user_id
provider
provider_subject
provider_tenant
is_verified
is_login_enabled
is_primary
provider_metadata
verified_at
last_used_at
created_at
updated_at
revoked_at
UNIQUE(provider, provider_tenant, provider_subject)
```

Примеры:

```text
0000000001 | telegram  | 123456789
0000000001 | ton_wallet| 0:abc...
0000000001 | google    | OIDC-sub
```

## 3.3. Auth-таблицы

- `auth_sessions`;
- `auth_challenges`;
- `user_roles`;
- `auth_audit_events` либо существующий общий audit-контур.

## 3.4. Кошелёк

Разделить:

- `user_identities(provider='ton_wallet')` — право входа;
- `wallet_bindings.user_id` — финансовая привязка кошелька.

---

# 4. Полная ORM-матрица

| Таблица | Legacy-поле | Целевое поле | Решение |
|---|---|---|---|
| `achievements` | `tg_id` | `user_id` | MIGRATE |
| `admin_whitelist` | `tg_id` | `user_id` | MIGRATE |
| `admin_whitelist` | `added_by_tg_id` | `added_by_user_id` | MIGRATE |
| `admin_role` | `granted_by_tg_id` | `granted_by_user_id` | MIGRATE |
| `withdraw_outcome_events` | `tg_id` | `user_id` | MIGRATE |
| `panels` | `tg_id` | `user_id` | MIGRATE |
| `panels_archive` | `tg_id` | `user_id` | MIGRATE |
| `payment_intents` | `tg_id` | `user_id` | MIGRATE |
| `ranks_snapshots` | `tg_id` | `user_id` | MIGRATE |
| `ranks_top_cache` | `tg_id` | `user_id` | MIGRATE |
| `ranks_user_snapshots` | `tg_id` | `user_id` | MIGRATE |
| `referral_codes` | `inviter_tg_id` | `inviter_user_id` | MIGRATE |
| `referral_links` | `inviter_tg_id` | `inviter_user_id` | MIGRATE |
| `referral_links` | `invitee_tg_id` | `invitee_user_id` | MIGRATE |
| `referral_bonus_ledger` | `tg_id` | `user_id` | MIGRATE |
| `shop_orders` | `tg_id` | `user_id` | MIGRATE |
| `tx_hash_locks` | `tg_id` | `user_id` | MIGRATE |
| `user_skins` | `tg_id` | `user_id` | MIGRATE |
| `user_cosmetics` | `tg_id` | `user_id` | MIGRATE |
| `task_submissions` | `tg_id` | `user_id` | MIGRATE |
| `task_submissions` | `moderator_tg_id` | `moderator_user_id` | MIGRATE |
| `user_tasks_status` | `tg_id` | `user_id` | MIGRATE |
| `task_bonus_log` | `tg_id` | `user_id` | MIGRATE |
| `task_complete_lock` | `tg_id` | `user_id` | MIGRATE |
| `ton_inbox_logs` | `parsed_tg_id` | `parsed_tg_id + resolved_user_id` | KEEP_SOURCE |
| `efhc_transfers_log` | `tg_id` | `user_id` | MIGRATE |
| `users` | `tg_id` | `user_id` | MIGRATE |
| `wallet_bindings` | `tg_id` | `user_id` | MIGRATE |
| `wallet_connect_idempotency` | `tg_id` | `user_id` | MIGRATE |
| `wallet_proof_token_uses` | `tg_id` | `user_id` | MIGRATE |
| `withdraw_requests` | `tg_id` | `user_id` | MIGRATE |
| `withdrawals` | `tg_id` | `user_id` | MIGRATE |

---

# 5. Первый способ авторизации: TON Connect

## 5.1. Поток входа

```text
GET/POST auth challenge
→ одноразовый nonce
→ TonConnect setConnectRequestParameters
→ wallet ton_proof
→ backend cryptographic verification
→ canonical wallet address
→ IdentityResolver
→ existing/new user_id
→ auth session
→ AuthContext
```

## 5.2. Endpoints

```text
POST /api/auth/v1/ton/challenge
POST /api/auth/v1/ton/verify
GET  /api/auth/v1/session
POST /api/auth/v1/logout
POST /api/auth/v1/logout-all
```

`purpose`:

```text
login
link
confirm_wallet
change_wallet
step_up
```

## 5.3. Политика создания аккаунта

- если `ton_wallet` identity существует — открыть тот же `user_id`;
- если адрес есть в проверенной активной `wallet_bindings` старого пользователя — связать с существующим `user_id`;
- если адрес новый — создать `users + user_identity + wallet_binding` одной транзакцией;
- если найден конфликт — не объединять автоматически;
- legacy `users.ton_wallet` использовать только как источник сверки, не как доказательство владения.



## 5.3.1. Каноническая таблица решений TON login

| Состояние после валидного TON Proof | Решение |
|---|---|
| `EXISTING_TON_IDENTITY` | Открыть связанный существующий `user_id` |
| `VERIFIED_LEGACY_WALLET_BINDING` | Создать identity для того же существующего `user_id` |
| `NEW_VERIFIED_TON_WALLET` | Атомарно создать новый `users`, новый `user_id`, identity и binding |
| Кошелёк принадлежит другому user | `WALLET_IDENTITY_CONFLICT`, без merge |
| Только frontend connection, proof отсутствует | Не авторизовывать |

```text
create_new_user_id = true
automatic_account_merge = false
wallet_address_is_user_id = false
wallet_connection_is_proof = false
```

Создание нового системного пользователя через TON-кошелёк является
каноническим сценарием. Оно включается только после auth core,
`user_identities`, challenges, sessions, verified-wallet backfill и
поддержки TON-only пользователя без обязательного `tg_id`.

## 5.4. Важное изменение текущего proof-кода

Сейчас challenge подписан с `tg_id`, а проверка требует уже известный `tg_id`. Для независимого входа необходимо заменить это на:

```text
challenge_id
purpose
nonce
domain
expires_at
optional current_user_id для link/step_up
```

Для `purpose=login` текущий пользователь отсутствует.

---

# 6. Модульное auth-ядро

```text
backend/app/auth/
├── context.py
├── gateway.py
├── resolver.py
├── sessions.py
├── challenges.py
├── registry.py
├── errors.py
├── schemas.py
└── providers/
    ├── base.py
    ├── ton_connect.py
    ├── telegram_webapp.py
    └── disabled.py
```

Интерфейс провайдера:

```python
class AuthProvider(Protocol):
    name: str

    async def start(self, request, purpose, user_id=None):
        ...

    async def verify(self, request, payload) -> VerifiedIdentity:
        ...
```

`VerifiedIdentity` не создаёт пользователя и не выполняет финансовые операции. Это делает `IdentityResolver`.

## 6.1. AuthContext

```python
@dataclass(frozen=True)
class AuthContext:
    user_id: int
    user_id_display: str
    provider: str
    provider_subject: str
    identity_id: int
    session_id: str
    roles: frozenset[str]
    tg_id: int | None = None
    wallet_address: str | None = None
```

---

# 7. Карта изменения слоёв

| Слой | Что меняется |
|---|---|
| Models | `users.user_id`, новые auth-таблицы, `user_id` во всех owner/actor связях |
| Migrations | expand/backfill/constraints/contract отдельными ревизиями |
| Dependencies | `get_current_auth_context`, `get_current_user_id`, роли по `user_id` |
| Middleware | Telegram только подтверждает `tg_id`, затем resolver возвращает `user_id` |
| Services | все доменные сигнатуры получают `user_id` |
| CRUD/SQL | joins/locks/idempotency по `user_id` |
| Routes | `/me` без ID; административные пути `{user_id}` |
| Schemas | `user_id` string(10); `tg_id` только Telegram DTO |
| Frontend | AuthProvider/session; query keys по `user_id`; убрать ownership по Telegram |
| Bot | Telegram update даёт `tg_id`; перед domain service выполнить resolve |
| Scheduler | payload хранит `user_id`; legacy payload parser временно читает `tg_id` |
| TON memo | новые memo содержат `user_id`; legacy `TG:` parser остаётся |
| Notifications | сервис получает `user_id`, затем ищет Telegram identity |
| Admin/RBAC | роли и акторы по `user_id` |
| Logs | основной context `user_id`; `tg_id` — дополнительный provider field |
| Tests | миграционные, auth, financial regression, E2E |
| CI | запрет новых доменных `tg_id`, allowlist Telegram/source файлов |

---

# 8. 16 макрофаз реализации

| Фаза | Макрофаза | Канонические циклы |
|---:|---|---:|
| A | Аудит и архитектурный замок | `1593–1600` |
| B | Канонический user_id | `1601–1610` |
| C | Identity/Auth ядро | `1611–1620` |
| D | TON Connect как первый вход | `1621–1630` |
| E | Frontend TON session-first | `1631–1640` |
| F | Telegram как адаптер совместимости | `1641–1650` |
| G | Expand доменной схемы | `1651–1660` |
| H | Backfill и reconciliation | `1661–1670` |
| I | Dual-write compatibility | `1671–1673` |
| J | Финансовый контур | `1674–1680` |
| K | Панели и энергия | `1681–1682` |
| L | Рефералы, задания, ранги | `1683–1685` |
| M | Shop, NFT, skins и memo | `1686–1688` |
| N | Admin/RBAC/notifications | `1689–1690` |
| O | API/frontend/global read switch | `1691–1697` |
| P | Contract, qualification, handoff | `1698–1700` |

Подробное содержание каждого цикла определяется документом
`docs/cycles/WORK_CYCLES_1601-1700_USER_ID_MODULAR_AUTH_PLAN.md`.

## Обязательная последовательность

Макрофазы B–F образуют первый authentication foundation:

```text
user_id
→ auth core
→ TON Connect login
→ server session
```

Telegram не удаляется: он переводится в адаптер в соответствующей Telegram-adapter волне.

---

# 9. Backfill

## 9.1. Telegram identities

```sql
INSERT INTO user_identities(user_id, provider, provider_subject, is_verified)
SELECT user_id, 'telegram', tg_id::text, true
FROM users
WHERE tg_id IS NOT NULL
ON CONFLICT DO NOTHING;
```

## 9.2. TON identities

Backfill допустим только для:

```text
wallet_bindings.is_active = true
wallet_bindings.proof_verified = true
wallet_address уникален
```

## 9.3. Домен

Каждая legacy-строка получает `user_id` через:

```text
legacy tg_id
→ user_identities(provider='telegram')
→ user_id
```

Нельзя создавать фиктивных пользователей для orphan-записей.

---

# 10. Dual-write

Правило:

```text
user_id — SSOT
tg_id — compatibility shadow
```

Legacy `tg_id` вычисляется сервером через identity registry. Клиент не передаёт доверенный owner `tg_id`.

Если у пользователя нет Telegram identity:

- новые user_id-aware функции работают;
- legacy функция должна быть недоступна или использовать nullable `tg_id`;
- запрещено подставлять фиктивное значение.

---

# 11. API-канон

Новые ответы:

```json
{
  "user_id": "0000000001"
}
```

Telegram-профиль:

```json
{
  "user_id": "0000000001",
  "telegram": {
    "tg_id": 123456789,
    "username": "..."
  }
}
```

Новые общие маршруты не принимают `tg_id` владельца.

Legacy admin routes:

```text
/admin/users/{tg_id}
```

заменяются на:

```text
/admin/users/{user_id}
```

Поиск администратора может отдельно поддерживать фильтр `tg_id`.

---

# 12. Изменение memo и внешних событий

Новый memo:

```text
EFHC|UID:0000000001|...
```

Legacy:

```text
EFHC<tg_id>
SKU:...|TG:<tg_id>
```

временно продолжает разбираться, после чего `tg_id` разрешается через identity registry.

В `ton_inbox_logs.parsed_tg_id` поле остаётся как исходный атрибут события. Дополнительно записывается `resolved_user_id`.

---

# 13. Главные риски и решения

| Риск | Решение |
|---|---|
| Дубликат TON и Telegram аккаунта | backfill проверенных wallet identities до открытия TON login |
| TON-only user не проходит legacy NOT NULL tg_id | `users.tg_id` nullable на foundation-этапе; domain expand до открытия соответствующих функций |
| Ошибка alias | запрет `tg_id ≡ user_id`; типы `UserId` и `TelegramId` |
| Двойное начисление | idempotency переносится на `user_id`, reconciliation до/после |
| Смена владельца панелей | только backfill по identity map, без пересоздания |
| Потеря админских прав | backfill whitelist → user_roles |
| Telegram-уведомление TON-only пользователю | optional Telegram identity; нейтральный канал/отсутствие уведомления |
| Replay ton_proof | одноразовый challenge, consumed_at, TTL, domain |
| Merge аккаунтов | отдельный сервис, не входит в первый этап |
| Поломка frontend | session-first AuthProvider и поэкранное переключение |

---

# 14. Критерии завершения

1. `user_id` — единственный owner key.
2. Формат UI/API — ровно 10 цифр.
3. Вход TON Connect создаёт или открывает системный аккаунт.
4. Telegram initData открывает тот же аккаунт через identity resolver.
5. Один wallet не принадлежит двум `user_id`.
6. Балансы, kWh, панели, транзакции и рефералы совпадают до 8 знаков.
7. `tg_id` остаётся только:
   - в Telegram adapters;
   - в identity registry/provider metadata;
   - в Telegram API;
   - в source/legacy logs.
8. Все новые провайдеры подключаются через registry и adapter без изменения экономики.
9. Legacy fallback и dual-write mismatch равны нулю.
10. Exact-HEAD CI, integration и financial regression suites зелёные.

---

# 15. Самые затронутые backend-файлы

| Файл | Упоминаний | Действие |
|---|---:|---|
| `backend/app/services/transactions_service.py` | 194 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/tasks_service.py` | 100 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/nft_check_service.py` | 93 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/wallets_service.py` | 92 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/withdraw_service.py` | 76 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/shop_service.py` | 75 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/admin/admin_panels_service.py` | 69 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/admin/admin_users_service.py` | 69 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/panels_service.py` | 65 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/admin/admin_withdrawals_service.py` | 64 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/energy_service.py` | 60 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/ranks_service.py` | 53 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/payment_intents_service.py` | 49 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/routes/admin_users_routes.py` | 47 | API: AuthContext/user_id; Telegram-specific tg_id только явно |
| `backend/app/services/watcher_service.py` | 47 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/routes/hub_routes.py` | 44 | API: AuthContext/user_id; Telegram-specific tg_id только явно |
| `backend/app/services/skins_service.py` | 44 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/admin/admin_bank_service.py` | 43 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/routes/ranks_routes.py` | 42 | API: AuthContext/user_id; Telegram-specific tg_id только явно |
| `backend/app/services/outcome_service.py` | 41 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/integrations/ton_memo.py` | 38 | PROTOCOL: новый memo по user_id; legacy tg_id parser оставить |
| `backend/app/services/exchange_service.py` | 34 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/referral_service.py` | 34 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/efhc_deposits_service.py` | 30 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/services/orders_service.py` | 29 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |
| `backend/app/integrations/ads_providers.py` | 28 | TOKEN CONTRACT: подписывать user_id; tg_id только provider metadata |
| `backend/app/bot/texts.py` | 26 | BOT ADAPTER: tg_id для Telegram API; доменную логику вызывать по user_id |
| `backend/app/crud/ranks_crud.py` | 26 | CRUD: выборки/FK/locks перевести на user_id |
| `backend/app/deps.py` | 26 | AUTH KERNEL: AuthContext, get_current_user_id; legacy adapter |
| `backend/app/services/payment_reconciliation_service.py` | 25 | DOMAIN: сигнатуры/SQL/ownership перевести на user_id |

Полный реестр всех 133 backend-файлов, 62 frontend-файлов, 107 тестовых файлов и 267 документов вынесен в XLSX-матрицу.
