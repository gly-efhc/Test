# EFHC — ПОЛНАЯ РАБОЧАЯ СХЕМА ПРИЛОЖЕНИЯ

Статус: **CURRENT / FRONTEND_v636 / FRONTEND_ADMIN_CYCLE_0412**  
Назначение: единая корневая карта фактической рабочей архитектуры EFHC Frontend + Backend.  
Источник истины для кода: текущий GitHub `main` под прямым решением OWNER и активными SSOT/CANON/NORM.  

Этот документ описывает **как приложение реально собрано и связано сейчас**. Он не заменяет предметные SSOT/CANON/NORM и не переносит бизнес-правила из исходного кода. Точные HTTP endpoints определяются canonical `backend/app/routes/*.py` и current `backend/openapi/openapi.json`; ORM/migration authority находится в `backend/app/models/*` и `backend/migrations/versions/0001_initial_release_schema.py`, а текущие контракты отдельных доменов — в активных SSOT/NORM.

---

## 1. Архитектура одним взглядом

```mermaid
flowchart TD
    U1[Telegram Mini App user]
    U2[Browser / PWA user]
    TG[Telegram WebApp SDK]
    NX[Next.js 16 / React 19 frontend]
    SHELL[_app.tsx application shell]
    AUTH[AuthSessionProvider]
    WALLET[WalletProvider / TON Connect adapters]
    RQ[TanStack React Query]
    PAGE[Pages / Components]
    FSVC[Frontend services + validators]
    API[frontend/src/lib/api.ts]
    PROXY[Next rewrites /api -> backend]
    FAST[FastAPI app.main:app]
    MW[Security / CORS / observability middleware]
    ROUTES[app.routes aggregate router]
    IDENT[Identity + auth layer]
    SVC[Domain services]
    CRUD[CRUD / repositories / SQL boundaries]
    DB[(PostgreSQL: efhc_core + efhc_admin)]
    SCH[SchedulerService]
    JOBS[Energy / TON watcher / ranks / tasks / ads / reports / retention jobs]
    TON[TON / TON Connect / Jetton / NFT boundaries]
    TGBOT[Telegram Bot / webhook]
    ADS[External ad providers]

    U1 --> TG --> NX
    U2 --> NX
    NX --> SHELL
    SHELL --> WALLET
    SHELL --> RQ
    SHELL --> AUTH
    SHELL --> PAGE
    PAGE --> RQ --> FSVC --> API --> PROXY --> FAST
    AUTH --> API
    WALLET --> FSVC
    FAST --> MW --> ROUTES
    ROUTES --> IDENT
    ROUTES --> SVC
    IDENT --> DB
    SVC --> CRUD --> DB
    SVC --> DB
    SCH --> JOBS --> SVC
    JOBS --> DB
    JOBS --> TON
    ROUTES --> TON
    ROUTES --> TGBOT
    ROUTES --> ADS
```

Главная цепочка пользовательского запроса:

`страница React → query/hook → frontend service → apiRequest → /api → Next proxy → FastAPI route → auth/dependency → domain service → CRUD/SQLAlchemy → PostgreSQL → response validator → React Query cache → UI`.

Главная цепочка фоновой работы:

`backend runner / cron tick → SchedulerService → registered job → domain service → database/external chain → idempotent/reconciled result`.

---

## 2. Корневая рабочая структура репозитория

| Путь | Роль | Runtime authority |
|---|---|---|
| `frontend/` | Production Next.js/React приложение, UI, client auth, wallet provider, services, queries, PWA, standalone build tooling | **Да** |
| `backend/` | Production FastAPI backend, Telegram bot, identity/auth, routes, services, CRUD, models, migrations, scheduler, OpenAPI | **Да** |
| `backend/openapi/openapi.json` | Current machine HTTP contract, derived from canonical backend route decorators | **Derived contract, не вторая реализация** |
| `backend/app/models/` + `backend/migrations/versions/0001_initial_release_schema.py` | Canonical ORM/migration authority | **Да** |
| `demo/` | Sandbox/demo/standalone evidence и прототипы | Только demo |
| `_import/` | Постоянная OWNER-protected transfer boundary для repository update/staging; не runtime authority | **Нет** |
| `docs/` | SSOT/CANON/NORM/process/current roadmap | Authority документации по назначению |
| `reports/` | Нумерованные отчёты и release/cycle provenance | История/доказательства, не runtime |
| `ops/` | Operator Kernel, release/report/check tooling | Process/tooling |
| `skills/` | Активная Skill architecture и manifests | Process/tooling |
| `.github/workflows/` | CI, security, import, release automation | CI/control plane |
| `APPLICATION_WORKING_SCHEMA.md` | Эта текущая причинно-следственная карта приложения | **Главная архитектурная навигация** |

Ключевой закон структуры: исполняемый backend существует **один раз** — в `backend/`. Root projections `routes/` и `tables/` удалены в Cycle0428 после доказанной materialization/parity; навигация и машинный контракт берутся из canonical backend source и `backend/openapi/openapi.json`, а не из второй root-копии.

---

## 3. Frontend: runtime и точки входа

### 3.1. Технологический слой

Production frontend находится в `frontend/`:

- Next.js 16 Pages Router;
- React 19;
- TypeScript;
- TanStack React Query;
- Telegram WebApp SDK;
- TON Connect через единый wallet-provider abstraction;
- Zod/runtime validators для сетевых payloads;
- PWA/service-worker и browser fallback;
- theme/interface customization layer.

Основная точка сборки приложения — `frontend/src/pages/_app.tsx`.

### 3.2. Порядок application providers

Фактическая оболочка строится так:

```text
Next App
└── WalletProvider
    └── QueryClientProvider
        └── AuthSessionProvider
            └── InterfaceCustomizationProvider
                └── AppInner
                    ├── ShopLayout -> browser-shop
                    └── Layout -> основной Mini App / Admin guard / остальные страницы
```

`WalletProvider` является единым application-facing wallet root. Страницы не должны напрямую владеть TON Connect SDK.

`AuthSessionProvider` владеет восстановлением server-side session, Telegram login, TON Proof login и logout.

`QueryClientProvider` владеет сетевым cache/refetch слоем для domain queries.

`InterfaceCustomizationProvider` владеет пользовательской настройкой интерфейса поверх общей theme architecture.

### 3.3. Основные пользовательские поверхности

| Surface | Frontend route/source | Основной data owner |
|---|---|---|
| Energy / Home | `pages/index.tsx` | current sync snapshot |
| Panels | `pages/panels.tsx` | `queries/usePanels.ts` → `services/panels.service.ts` |
| Exchange | `pages/exchange.tsx` | `queries/useExchange.ts` → `services/exchange.service.ts` |
| Tasks | `pages/tasks.tsx` | `queries/useTasks.ts` → `services/tasks.service.ts` + ad flow |
| Referrals | `pages/referrals.tsx` | `queries/useReferrals.ts` → `services/referrals.service.ts` |
| Ranks | `pages/ranks.tsx` | `queries/useRanks.ts` → `services/ranks.service.ts` |
| Withdraw | `pages/withdraw.tsx` | `queries/useWithdrawals.ts` → `services/withdrawals.service.ts` |
| Hub | `pages/hub.tsx` | `queries/useHub.ts` → `services/hub.service.ts` |
| Browser Shop | `pages/browser-shop.tsx` | `queries/useBrowserShop.ts` → `services/browserShop.service.ts` |
| Profile / wallets | shared Layout/profile surfaces | `queries/useProfile.ts`, `useWalletsMe`, TON linkage |
| Ads | page/components/task integration | `lib/ads/AdManager.ts` |
| FAQ | `pages/faq.tsx` | local approved FAQ corpus + search worker |
| Web profile | `pages/web-profile.tsx` | profile service/query layer |
| Admin | protected `/admin*` surfaces | server-authoritative admin access + admin service layer |

Bottom Navigation product boundary remains: `Energy / Panels / Exchange / Tasks / Referrals / Ranks`.

### 3.4. Snapshot / boot data

После auth основной пользовательский snapshot загружается через:

```text
useSnapshot()
  -> services/snapshot.service.ts
  -> POST /api/sync/me?fresh=1
  -> backend sync route
  -> profile + panels + exchange preview + sync metadata
```

Snapshot является общим boot/read model для оболочки. Если `global_id` отсутствует, shell использует browser preview/fallback snapshot и не маскирует его под live user state.

### 3.5. Frontend network boundary

Единый low-level client: `frontend/src/lib/api.ts`.

Правила:

1. относительный business path нормализуется к `/api/...`;
2. current Bearer session добавляется автоматически;
3. `Telegram initData` **не** отправляется с каждым business request;
4. idempotent write передаёт `Idempotency-Key`;
5. request tracing может передавать `X-Request-ID`;
6. `401` при активной credential инвалидирует локальную session;
7. JSON/error payload проходит централизованную обработку.

Next.js `frontend/next.config.js` проксирует к backend:

- `/api/:path*`;
- `/health`;
- `/meta/:path*`;
- `/openapi.json`;
- `/docs/:path*`;
- `/redoc`.

Target задаётся через `NEXT_PUBLIC_API_PROXY_TARGET`; production container default boundary — backend service on port 8000.

---

## 4. Identity и authentication

### 4.1. Канонический пользователь

Business owner приложения — provider-neutral `global_id`. Telegram ID, TON wallet identity и другие provider subjects являются identity inputs/bindings, но не заменяют canonical account owner.

Backend identity layer находится в `backend/app/identity/`.

### 4.2. Telegram login

```text
Telegram WebApp
  -> getTelegramInitData()
  -> AuthSessionProvider.loginTelegram()
  -> completeTelegramSessionLogin()
  -> POST /api/auth/telegram
  -> validate Telegram initData
  -> identity/account registration or resolution
  -> server-side auth session issue
  -> credential stored in browser sessionStorage
  -> GET /api/auth/session
  -> provider-neutral AuthContext(global_id, provider, roles)
```

Referral `start_param` захватывается до login и входит в first-creation attribution path; после успешного login очищается.

### 4.3. TON Proof login

TON identity может аутентифицировать пользователя отдельным provider path:

```text
TON proof request
  -> POST /api/auth/ton/proof
  -> cryptographic/provider verification
  -> identity resolution / registration
  -> server-side auth session
  -> same provider-neutral AuthContext
```

После выдачи session дальнейший business API снова работает через Bearer session, а не через повторную пересылку proof.

### 4.4. Session lifetime на frontend

Client credential хранится в `sessionStorage` под current auth-session key. Она содержит access token, Bearer token type и expiry. Current user context не доверяется из локальных Telegram полей: frontend получает его от `/auth/session`.

Logout вызывает server-side revoke и затем очищает client session.

---

## 5. Wallet / TON Connect architecture

### 5.1. Wallet provider abstraction

`frontend/src/lib/wallet-provider/` — единый wallet transport layer.

Текущие adapters:

1. `tonconnect` — основной TON Connect adapter;
2. `telegram_wallet` — adapter boundary;
3. `native_gram_wallet` — adapter boundary.

Adapter selection и live connection — UI/runtime state. Они не являются сами по себе permanent backend binding.

### 5.2. TON Connect chain

```text
Wallet UI
  -> WalletProvider
  -> TonConnectAdapter
  -> GET /api/wallets/tonconnect/proof-payload
  -> wallet returns ton_proof
  -> POST /api/wallets/tonconnect/check-proof
  -> verified proof envelope
  -> POST /api/wallets/connect + Idempotency-Key
  -> WalletService
  -> canonical TON address + proof replay/idempotency guards
  -> wallet_bindings
```

Backend wallet endpoints дополнительно обслуживают:

- список bindings `/wallets/me`;
- balance history;
- make-primary;
- deactivate/remove binding.

Канонический принцип: **live wallet session и saved wallet binding независимы**. `wallet_app` — metadata; account ownership остаётся address/global_id-centric.

---

## 6. Frontend domain access pattern

Для обычного domain feature используется одинаковая цепочка:

```text
Page/Component
  -> React Query hook in frontend/src/queries/
  -> typed domain service in frontend/src/services/
  -> generated seam/validator or local Zod parser
  -> apiRequest()
  -> FastAPI endpoint
```

Основные пары:

| Query layer | Service layer | Backend domain |
|---|---|---|
| `usePanels` | `panels.service` | panels |
| `useExchange` | `exchange.service` | exchange / transactions |
| `useTasks` | `tasks.service` | tasks / task bonuses |
| `useReferrals` | `referrals.service` | referrals / referral ledger |
| `useRanks` | `ranks.service` | ranks |
| `useWithdrawals` | `withdrawals.service` | withdraw / outcome / wallet history |
| `useProfile` | `profile.service` | profile / auth photos / wallets / history |
| `useBrowserShop` | `browserShop.service` | shopfront / shop / payment intents |
| `useShopLauncher` | `shopLauncher.service` | hub + shop launcher truth |
| `useHub` | `hub.service` | hub links / EFHC handoff |
| `useSkins` | `skins.service` | skins / cosmetics |
| `useDirectDeposit` | `directDeposit.service` | EFHC direct deposit |
| `useTonConnectLinkage` | TON/wallet services | wallet proof/binding |
| admin query seams | admin services | protected `/admin/*` |

Generated economic seams/validators are the frontend contract layer for high-risk financial endpoints. Они не заменяют backend business logic.

---

## 7. Backend process topology

### 7.1. Основное FastAPI приложение

Главная ASGI application: `backend/app/main.py` → `app.main:app`.

Startup sequence:

1. загрузка settings из ENV;
2. production safety guards;
3. application `lifespan`;
4. `assert_system_locks()`;
5. DB preflight в prod/stage;
6. FSM background GC;
7. middleware stack;
8. route aggregation;
9. exception handlers;
10. readiness/health surface.

### 7.2. Middleware/security boundary

На FastAPI уровне подключаются:

- Request observability;
- Correlation ID;
- Trusted Host при конфигурации;
- Security Headers;
- CORS;
- central security middleware installer;
- centralized exception handlers.

Production запрещает insecure user-id header mode. Stage/staging запрещает real-funds mode. Secrets/configuration поступают через ENV/settings, а не из hardcoded source.

### 7.3. Route aggregation

`backend/app/routes/__init__.py` — единственный aggregator HTTP route modules. `app.main` вызывает:

```text
register_routes(app, prefix=settings.API_PREFIX)
```

Default `API_PREFIX` = `/api`.

Production route modules fail closed: если mandatory module не загрузился, startup не должен тихо продолжать работу.

Точный текущий machine HTTP contract: `backend/openapi/openapi.json`; реализация маршрутов: `backend/app/routes/*.py`.

Основные public/domain route families:

- user / me / profile history;
- panels;
- exchange;
- ranks;
- referrals;
- shop / shopfront;
- hub;
- deposit;
- payment intents;
- auth session / Telegram / TON;
- wallets;
- skins;
- withdraw;
- tasks;
- ads;
- NFT;
- sync;
- system / health / cron / webhook.

Admin family находится в отдельных `/admin/*` route modules и защищена server-side authorization/RBAC.

---

## 8. Backend internal layers

### 8.1. Routes

`backend/app/routes/`

Ответственность: HTTP method/path, input/output schema, dependency/auth boundary, вызов service. Денежная бизнес-логика не должна жить в route aggregator.

### 8.2. Schemas/contracts

`backend/app/schemas/` и `backend/app/contracts/`

Ответственность:

- API request/response models;
- domain payload contracts;
- admin/public separation;
- financial/shop/withdraw contract boundaries.

### 8.3. Identity

`backend/app/identity/`

Ответственность:

- provider-neutral `global_id`;
- provider identities;
- Telegram auth;
- TON auth;
- auth challenges/sessions;
- referral ingress at account creation;
- authorization dependencies/context.

### 8.4. Services

`backend/app/services/`

Business/domain owners включают:

- energy generation/accounting;
- panels;
- exchange;
- transactions;
- deposits;
- payment intents and reconciliation;
- shop/orders;
- referrals;
- ranks;
- tasks;
- withdrawals/outcomes;
- wallets/TON proof;
- NFT checks;
- skins;
- ads/provider analytics;
- hub;
- reports;
- financial retention;
- watcher transport/reconciliation;
- admin services/RBAC.

Service layer является главным owner бизнес-процесса между HTTP boundary и persistence/external integrations.

### 8.5. CRUD

`backend/app/crud/`

CRUD modules инкапсулируют повторяемые data-access операции для users, panels, referrals, shop, tasks, transactions, wallets и admin domain. Часть сложных финансовых сервисов использует явный SQL непосредственно в service boundary, когда требуется atomic/idempotent transaction behavior.

### 8.6. Core

`backend/app/core/`

Общие инфраструктурные owners:

- settings/env;
- async DB engine/session;
- security;
- logging/correlation;
- exceptions;
- system locks;
- async task ownership;
- decimal/financial utility boundaries;
- runtime observability.

---

## 9. PostgreSQL и migration schema

### 9.1. Database boundary

Backend использует PostgreSQL. Канонические schemas:

- `efhc_core` — user/product/financial/runtime data;
- `efhc_admin` — admin-specific schema boundary.

Async runtime DB access идёт через canonical database/session helpers. Alembic использует Postgres-only migration environment.

### 9.2. Migration authority

`backend/migrations/`:

- `alembic.ini`;
- `env.py`;
- `versions/0001_initial_release_schema.py`;
- safe migration helpers.

Текущая release migration строит полный clean schema baseline. ORM authority находится в `backend/app/models/*`, а release-migration authority — в `backend/migrations/versions/0001_initial_release_schema.py`; root inventory-копия удалена после parity proof.

### 9.3. Текущие persistent domains

**Accounts / identity / auth:** `users`, `user_identities`, `user_roles`, `auth_challenges`, `auth_sessions`.

**Wallets / TON / transaction tracking:** `wallet_bindings`, `wallet_connect_idempotency`, `wallet_proof_token_uses`, `ton_inbox_logs`, `unmatched_incoming`, `efhc_transfers_log`, `processed_external_events`.

**Balances / bank / idempotency:** `bank_balance`, `bank_metrics_snapshot`, `idempotency_key`.

**Panels / energy:** `panels`, `achievements`.

**Exchange/payment/shop:** `payment_intents`, `shop_items`, `shop_orders`, `tx_hash_locks`, `efhc_sale_packages`.

**Withdraw:** `withdraw_requests`, `withdrawals`, `withdraw_outcome_events`, `outcome_fallback_promos`.

**Referrals:** `referral_codes`, `referral_links`, `referral_bonus_ledger`.

**Tasks:** `tasks`, `task_submissions`, `user_tasks_status`, `task_bonus_log`, `task_complete_lock`.

**Ads:** `ads`, `ad_provider_configs`, `ad_sessions`, `ad_daily_counters`, `ad_events`, `ad_provider_claims`, `ad_admin_audit_log`, `ad_provider_daily_metrics`.

**Skins / cosmetics:** `user_skins`, `user_cosmetics`.

**Hub / settings / templates / scheduler:** `hub_links`, `app_settings`, `system_templates`, `scheduler_task_log`.

**Admin:** `admin_whitelist`, `admin_nft_whitelist`, `admin_role`, `admin_action_log`, `admin_notifications`.

Для точного набора колонок и source class всегда используется canonical `backend/app/models/*` вместе с release migration `backend/migrations/versions/0001_initial_release_schema.py`, а не этот обзорный текст.

---

## 10. Scheduler и фоновые процессы

Канонический owner — `backend/app/services/scheduler_service.py`.

### 10.1. Два режима

**Long-running runtime**

```text
backend/run.py
  -> preflight
  -> Uvicorn app.main:app
  -> SchedulerService.register_defaults(strict=True)
  -> SchedulerService.start()
```

**Serverless**

```text
HTTP /cron/tick
  -> SchedulerService.run_single_tick()
```

При `SERVERLESS=true` long-running scheduler start запрещён.

### 10.2. Текущий canonical default job set

- `generate_energy`;
- `check_ton_inbox`;
- `check_vip_nft`;
- `archive_panels`;
- `update_ranks`;
- `tasks_autorestart`;
- `ads_rotation`;
- `ads_reward_reconciliation`;
- `ads_revenue_importer` — daily gate;
- `reports_daily` — daily gate;
- `financial_retention` — daily gate.

Scheduler не является owner денежной формулы. Он будит domain jobs; idempotency и accounting остаются в БД/services.

---

## 11. Telegram bot boundary

`backend/app/bot/` содержит Telegram bot transport: bot initialization, handlers для start/profile/balance/panels/exchange/ranks/referrals/tasks/withdraw/ads/hub/admin, keyboards, middlewares, FSM и WebApp-related handlers.

Bot и Mini App используют общую backend/domain модель, но являются разными presentation/transport surfaces. Serverless architecture не запускает long-polling внутри HTTP handler; Telegram production path рассчитан на webhook boundary.

---

## 12. Ключевые бизнес-потоки end-to-end

### 12.1. Открытие приложения

```text
Telegram Mini App / Browser
  -> Next _app
  -> Telegram/PWA/theme/settings bootstrap
  -> AuthSessionProvider
  -> session restore or Telegram login
  -> global_id resolved
  -> useSnapshot
  -> POST /api/sync/me?fresh=1
  -> current user read model
  -> Layout + page
```

### 12.2. Panels activation

`Panels page → usePanelActivation → panels.service → POST activation + Idempotency-Key → panels route → panels service/transactions → DB transaction → query invalidation/refetch`.

### 12.3. Exchange

`Exchange page → preview query → user confirm → POST convert + Idempotency-Key → exchange service → transaction/accounting → updated balances/snapshot`.

### 12.4. Tasks + rewarded ads

`Tasks page → catalog/my/earnings queries → optional AdManager session → task claim + Idempotency-Key → tasks service → task locks/bonus ledger/transactions → refreshed state`.

### 12.5. Withdraw

`Withdraw page → verified active wallet → eligibility/ad state where applicable → POST request + Idempotency-Key → withdraw service → hold/request persistence → scheduler/execution/reconciliation → outcome/history`.

### 12.6. Browser Shop

`Browser Shop → ShopLayout → browserShop service → shopfront/catalog/order/payment endpoints → payment intent/shop order services → reconciliation → order state`.

### 12.7. TON watcher

`Scheduler tick → check_ton_inbox → watcher/TON transport → chain event parse → dedupe/reconciliation → transaction/deposit/payment service → DB update`.

---

## 13. Финансовые safety boundaries

Для state-changing финансовых операций архитектура разделяет:

1. HTTP request authentication;
2. canonical `global_id` ownership;
3. validated request schema;
4. `Idempotency-Key` для повторяемых write requests;
5. domain service;
6. DB transaction/locks/dedupe;
7. external-chain reconciliation;
8. outcome/history representation.

Критические примеры: exchange, panel activation, deposits, payment intents/shop payments, wallet binding, task rewards, withdrawals, external TON events.

Frontend никогда не является source of truth денежного результата: он инициирует операцию и отображает server response/current read model.

---

## 14. Health / observability

Backend имеет basic liveness, DB health, DB schema/readiness, runtime health, deployment metadata и bounded metrics. Detailed runtime/metrics защищены соответствующим admin/token boundary. Readiness проверяет не только доступность DB, но и migration/runtime critical state.

Frontend дополнительно имеет error boundary, network/runtime status, PWA runtime status, web-vitals/image-format telemetry и request/correlation ID support.

---

## 15. Demo / standalone boundary

`demo/` не является production source authority. Он содержит standalone/demo artifacts, sandbox prototypes, demo-specific authority notes и TonConnect E2E sandbox guard.

Production изменения сначала принадлежат `frontend/`/`backend/`. Demo используется для изолированной проверки и не должен становиться вторым production implementation.

Root `FRONTEND_vNNN.html` и `SHOP_vNNN.html` — physical release artifacts, а не отдельная ветка product logic.

---

## 16. CI / source / release / deploy control plane

### 16.1. GitHub

Локальный chat workspace — основной mutable engineering workspace. GitHub `main` — repository source/history/CI authority под OWNER/SSOT/CANON/NORM и синхронизируется bounded пакетами.

Основные workflows:

- `CI FAST` — frontend typecheck/current regression + backend compile;
- `CI FULL` — frontend regression/assets/build + backend compile/tests;
- `Security` — secret guard;
- `Import archive` — безопасное распределение входного physical archive;
- `RELEASE` — release packaging/integrity artifact;
- TON Connect SDK update workflow — отдельный controlled dependency path.

### 16.2. Physical release

Physical release остаётся immutable provenance artifact: `FRONTEND_vNNN.zip`, `FRONTEND_vNNN.html`, `SHOP_vNNN.html`. Новый material cycle создаёт новую release identity; старый ZIP не перезаписывается.

### 16.3. Railway

Railway — runtime/deploy control plane. В текущем source tree нет основания считать Railway проектной SSOT: deploy configuration/secret state находится вне кода. Изменение runtime/deploy производится только по прямой OWNER-authority.

### 16.4. Linear / Atlassian / EFHC CODE

- Linear — work-state, не source truth;
- Atlassian — knowledge/work management при явном использовании;
- EFHC CODE — независимый read-only Guardian, не второй Kernel и не замена GitHub CI.

---

## 17. Source authority и provenance

Порядок authority:

```text
Direct OWNER decision
  > active SSOT / CANON / NORM
  > accepted GitHub main
  > exact-head CI evidence
  > immutable physical release
  > work-management state
```

`_import/` — постоянная transfer boundary. Она сохраняется в workspace и full physical release; после materialization рабочий код читается из canonical project paths, а не из payload внутри `_import/`.

---

## 18. Что является точным machine inventory

| Вопрос | Exact source |
|---|---|
| Какие HTTP endpoints существуют | `backend/openapi/openapi.json` + `backend/app/routes/*.py` |
| Какие ORM tables/classes существуют | `backend/app/models/*` + `backend/migrations/versions/0001_initial_release_schema.py` |
| Как endpoint реально реализован | `backend/app/routes/*.py` |
| Где бизнес-логика | `backend/app/services/*.py` |
| Где persistence | `backend/app/models/*.py`, `backend/app/crud/*.py` |
| Как создаётся schema | `backend/migrations/` |
| Как frontend вызывает API | `frontend/src/services/`, `frontend/src/queries/`, `frontend/src/lib/api.ts` |
| Как строится frontend shell | `frontend/src/pages/_app.tsx` |
| Как устроен wallet transport | `frontend/src/lib/wallet-provider/`, `frontend/src/lib/tonconnect.ts` |
| Как устроена auth identity | `frontend/src/auth/`, `frontend/src/lib/*auth*`, `backend/app/identity/`, `backend/app/routes/auth_*` |
| Как запускается backend | `backend/app/main.py`, `backend/run.py`, `api/index.py` |
| Как запускаются фоновые jobs | `backend/app/services/scheduler_service.py`, `backend/app/scheduler/` |
| Какие current документы authoritative | `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md` |

---

## 19. Правило чтения кода для следующих циклов

Нельзя путать **scope изменения** и **scope понимания**.

Если OWNER разрешил изменить один frontend element, изменяется только этот разрешённый scope. Но перед изменением необходимо проследить всю materially-connected chain, если она влияет на результат:

```text
UI owner
-> hook/query
-> frontend service
-> API contract
-> backend route
-> identity/auth dependency
-> domain service
-> CRUD/model/table/migration
-> scheduler/external integration, если участвует
-> regression/CI boundary
```

То есть: **bounded mutation, full connected understanding**.

Это правило предотвращает повторение ситуации, когда локально меняется один файл, а настоящая причина или контракт находится в другом слое приложения.

---

## 20. Ограничения этой схемы

Этот документ не должен дублировать весь source code, становиться вторым API/OpenAPI или DB schema, переписывать financial formulas, заменять SSOT/CANON/NORM, описывать несуществующий deploy state или превращать historical files в current authority.

При расхождении с фактическим code path сначала проверяется current OWNER/SSOT/CANON/NORM и текущий GitHub source. После подтверждённого архитектурного изменения эта схема должна быть currentized в том же material cycle.

---

## 21. Краткая карта ответственности

```text
OWNER                         -> конечная проектная authority
SSOT/CANON/NORM               -> правила и инварианты
GitHub main                   -> рабочий source
frontend/pages/components     -> presentation
frontend/queries/services     -> client data orchestration/contracts
frontend/lib/api              -> HTTP boundary
frontend/wallet-provider      -> wallet transport abstraction
backend/routes                -> HTTP/API boundary
backend/identity              -> account/auth ownership
backend/services              -> business logic owner
backend/crud/models           -> persistence layer
backend/migrations            -> release DB schema
PostgreSQL                    -> persistent state
backend/scheduler             -> background orchestration
Telegram/TON/ad providers     -> external systems
GitHub Actions                -> CI/release checks
Railway                       -> runtime/deploy plane
physical ZIP/HTML             -> immutable release/provenance
backend/openapi + models/migration -> canonical machine/navigation authority
reports                       -> immutable cycle provenance
```

**Current architecture entrypoint:** `APPLICATION_WORKING_SCHEMA.md`.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

