# EFHC Bot — local release candidate v173.06

Статус: `LOCAL_RELEASE_CANDIDATE`; `EXACT_HEAD_CI_REQUIRED`;
`production_release_ready = false`.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.


Документ v171.89 ниже сохранён как исходное описание продуктовых возможностей,
но его Telegram-owner формулировки исторические и заменены `global_id`.

---

# EFHC Bot — production release candidate v171.89

The v171.89 release is a complete provider-independent Docker Compose
package built from the exact v171.89 development HEAD. It supports both
clean VPS installation and cumulative archive-based update of an
existing EFHC instance.

This release also repairs exact failures found by fresh v171.86 development CI: PostgreSQL bind parameters are explicitly typed, same-user monetary operations serialize with blocking `FOR UPDATE`, the panel-balance expectation matches the canonical 100 EFHC price, and integration imports satisfy Ruff.

This release consolidates the permanent Activ status on one runtime
source of truth: `referral_links.activated_at IS NOT NULL`. Public
counters/lists, Admin referral summary and Admin user detail no longer
derive activity from current panel rows. `panels_count` is display-only,
so archive, expiry or future physical deletion cannot clear Activ.

This release makes referral attribution immutable at first PostgreSQL
user creation. A genuinely new user with a valid system-generated invite
code is created together with `referral_links` in one transaction. A new
user without a code becomes a permanent 0 user and produces no referral
reward. Existing users cannot be attached, reattached or reassigned.

Public bind/attach routes, Admin inviter reassignment and Admin manual
referral payout are absent. Automatic monetary rewards remain canonical:
one `0.1 EFHCb` payment after each direct invitee activates the first
panel, plus one-time Lvl rewards `10→1`, `100→10`, `1000→100`,
`3000→300`, `10000→1000 EFHCb`.

Profile and money services fail closed for a missing player instead of
silently creating a 0 user. First-panel debit, panel creation, referral
activation, the direct reward and all newly reached Lvl rewards remain
atomic and idempotent. The Referrals page includes next-Lvl progress,
invite/share tools, inline Active/Inactive lists and backend-owned
cumulative Lvl economics; Lvl 1 is `10 × 0.1 + 1 = 2 EFHCb`.

Production layout keeps application versions under `/opt/efhc/releases`
and persistent environment, secrets, logs, backups and packages outside
release directories. `current` is activated atomically only after
successful deployment and local healthchecks; `previous` remains the
prior working application set.

Updates do not require adjacent archive numbers. Read `INSTALL.md`,
`DEPLOY.md`, `BACKUP_RESTORE.md` and `UPDATE_AND_ROLLBACK.md` inside the
release archive.

This release also repairs the audited referral data boundary: every join
and count uses Telegram `tg_id`, Active/Inactive filtering and cursor
pagination run in PostgreSQL, archived panels preserve permanent
activation, user compatibility routes are self-only, Admin totals
include direct and Lvl rewards, and reward idempotency is re-read after
locks for concurrent threshold crossings.

Status: `LOCAL_RELEASE_CANDIDATE`; fresh exact-HEAD GitHub CI and later
real VPS and live Telegram/TON verification are required.
`production_release_ready` is false.

