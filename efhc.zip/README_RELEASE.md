<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.14 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `EXACT_HEAD_CI_REQUIRED`  
`production_release_ready = false`

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- `docs/history/`, `reports/` и `tests/` не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.

Входной GitHub CI run `84704272282`, commit
`02667638d2b423fbc733a8e32a88b44996a3ba6e`, подтвердил 11 pytest failures
на предыдущем HEAD. Все 11 причин исправлены локально в v173.14 и требуют
нового exact-head GitHub CI для квалификации.
