<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_TON_PROVIDER_SUBJECT_CANON_V173_23 -->
TON provider subject: `ton_wallet_id` = адрес TON-кошелька. `ton_address` не
является provider-subject alias; generic storage `provider_subject` для
`provider=ton` содержит значение `ton_wallet_id`.

# EFHC Bot v173.36 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `PREDECESSOR_v173.35_EXACT_HEAD_GREEN / CURRENT_v173.36_EXACT_HEAD_REQUIRED`  
`production_release_ready = false`

GitHub CI `84921131844` проверил byte-exact `v173.35` (`ffdc369b3eaaf65eacbac48f31e7e7743458434e`): все canonical gates
exit=0, pytest `1498 passed / 22 skipped / 1 warning`. В цикле 1711 runtime/
schema/business code не изменялся; `v173.36` обновляет только status/version/package
surface, поэтому exact-head claim для собственных байтов `v173.36` не делается.
Следующий цикл — 1712 Qualification milestone.

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- Development-only `docs/`, `reports/`, `tests/`, skills/agents/commands/hooks/references и внешний history archive не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.
