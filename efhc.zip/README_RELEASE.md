<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_TON_PROVIDER_SUBJECT_CANON_V173_23 -->
TON provider subject: `ton_wallet_id` = адрес TON-кошелька. `ton_address` не
является provider-subject alias; generic storage `provider_subject` для
`provider=ton` содержит значение `ton_wallet_id`.

# EFHC Bot v173.29 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `EXACT_HEAD_CI_REQUIRED`  
`production_release_ready = false`

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- Development-only `docs/`, `reports/`, `tests/`, skills/agents/commands/hooks/references и внешний history archive не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.

Последний предоставленный GitHub CI run `84865747522`, commit
`6d5002fbce58579f2c09f28f60762a15184d4510`, подтвердил единственный failing gate pytest: `1494 passed / 3 failed / 22 skipped`;
Ruff и остальные показанные gates прошли. Три причинных расхождения исправлены в этом release candidate.
Цикл 1706 остаётся IN PROGRESS; следующий exact-head GitHub CI обязателен
для его закрытия и последующей qualification.
