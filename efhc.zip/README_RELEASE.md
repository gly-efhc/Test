
## Текущее состояние разработки — кандидат v173.50 / цикл 1725

Admin VIP/NFT использует фактическую проверку владения NFT; ручное назначение VIP больше не является рабочим поведением. Оплаченный Shop NFT order — единственная заявка на ручную выдачу и обрабатывается через очередь Admin Shop. `submit_manual_vip_nft_claim` имеет статус `REPLACED_BY_CANON / DO_NOT_RESTORE`. Требуется следующий exact-head GitHub CI.

> Current Development HEAD candidate: `v173.49`; completed cycle 1724; next exact-head GitHub CI required.

# EFHC Bot v173.42 — exact-head CI repair + function recovery plan candidate

Status: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`  
Последний supplied exact-head CI: `84954546920` на `v173.41`, archive size `12135299` bytes.

Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy `2` errors; pytest `17 failed / 1485 passed / 22 skipped`. В текущем HEAD внесены только подтверждённые repairs. `global_id` ownership, BANK и Admin NFT canons не ослаблялись.

Packaging metadata `v173.41` исправлена: executable modes и исторические Unicode filenames восстановлены. `production_release_ready=false`. Следующий этап — exact-head GitHub CI пользователя и цикл 1719 по плану согласования функций.
