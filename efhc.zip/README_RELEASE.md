<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.12 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `EXACT_HEAD_CI_REQUIRED`  
`production_release_ready = false`

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- `АРТЕФАКТЫ/` и `tests/` не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.

Последний входной GitHub CI относится к commit
`a107ad26b08060304b1025e4094472333a5bb9d2`; новый v173.12 требует
нового exact-head GitHub CI.
