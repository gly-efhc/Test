## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.

## Текущее состояние разработки — кандидат v173.50 / цикл 1725

Admin VIP/NFT использует фактическую проверку владения NFT; ручное назначение VIP больше не является рабочим поведением. Оплаченный Shop NFT order — единственная заявка на ручную выдачу и обрабатывается через очередь Admin Shop. `submit_manual_vip_nft_claim` имеет статус `REPLACED_BY_CANON / DO_NOT_RESTORE`. Требуется следующий exact-head GitHub CI.

> Current Development HEAD candidate: `v173.49`; completed cycle 1724; next exact-head GitHub CI required.

# EFHC Bot v173.42 — exact-head CI repair + function recovery plan candidate

Status: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`  
Последний supplied exact-head CI: `84954546920` на `v173.41`, archive size `12135299` bytes.

Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy `2` errors; pytest `17 failed / 1485 passed / 22 skipped`. В текущем HEAD внесены только подтверждённые repairs. `global_id` ownership, BANK и Admin NFT canons не ослаблялись.

Packaging metadata `v173.41` исправлена: executable modes и исторические Unicode filenames восстановлены. `production_release_ready=false`. Следующий этап — exact-head GitHub CI пользователя и цикл 1719 по плану согласования функций.