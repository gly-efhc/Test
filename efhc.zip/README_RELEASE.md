# CURRENT HEAD — кандидат v174.42 / цикл 1791 corrective re-audit по утверждённому ТЗ

- Входной exact candidate: `v174.41`, SHA-256 `baf1ab7b318c69988a4079d8aef022092e4a0499579058e99431cf58903b9a2c`. Owner-approved ТЗ повторного аудита SHA-256 `7f17d680a06cca5cc581a27a0cf1577d5c0a51e9cbe1c3184ad40ae0969b75e8` фиксирует только подтверждённые defects и запрещает менять бизнес-экономику, FAQ authority и frozen schema.
- Ранее зафиксированный exact-head GREEN anchor остаётся `v174.40` по GitHub CI `87088984879`; GREEN **не наследуется** текущим `v174.42`.
- Release-blocking Telegram repair: dedupe marker больше не коммитится до business processing; dedupe storage failure fail-closed; JSON валидируется до marker; webhook владеет единственным root transaction; cancellation/error вызывают rollback; compensating DELETE удалён; `/start` unexpected onboarding errors пробрасываются; onboarding core transaction-neutral и использует savepoint.
- Security/error repair: 17 broad internal 5xx exception disclosures закрыты stable error codes; canonical `app.main:app` применяет `TrustedHostMiddleware`, когда allowlist настроен; active wallet TonConnect proof использует configured-domain-first canonical resolver и не считает request Host production authority.
- Validation/lifecycle repair: raw `Idempotency-Key` валидируется до hash (`<=128`, control chars forbidden); scheduler operational values имеют positive bounds и backoff ordering; logging всегда заполняет `tg_id`; PWA снимает `updatefound/statechange`; serverless VIP tick использует explicit `db_session()` context.
- Добавлены regression/integration test sources, включая real dedupe helper, cancellation/fail-closed cases и PostgreSQL concurrent duplicate/root transaction scenarios. Локально эти tests не запускались; результат должен подтвердить fresh exact-head GitHub CI.
- Frozen migration `0001` и FAQ runtime/FAQ duplicate-control content не менялись. `0002+` не создана. FAQ остаётся самостоятельным checked-in release asset.
- Frontend visual/UX/text authority FRONTEND_v146 не изменён. PWA runtime lifecycle source изменён non-visual; release metadata синхронизированы статически: authority `INTEGRATED_FRONTEND_SOURCE_v174.42_FRONTEND_v146`, controlled entries `195`, source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`, PWA `efhc-acecaa494ab54fe4`.
- Immutable report: `02360`; следующий `02361`. Canonical handoff: `EFHC_Bot_v174_42.zip`. Статус: **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.

> **Historical boundary:** нижележащие прежние CURRENT/owner-lock snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.41 / цикл 1791 exact-head GREEN + полный функциональный аудит

- GitHub CI `87088984879` полностью квалифицировал exact `v174.40`: archive SHA-256 `1db0f401b2fb286bb7b20a2f826b805c53dce2e9f88f11a52b853fd2e1c637ae`, checkout `c6af814d328d63b60b9f2953d63e0c368a333dba`; все recorded gate exits `0`; pytest `1670 passed / 22 skipped / 1 warning`; frontend production build и PostgreSQL/Alembic PASS. `v174.40` зафиксирован как **EXACT-HEAD GREEN**.
- По прямому owner order открыт цикл `1791` и выполнен полный статический аудит зарегистрированной application surface и всех финансово/security/ops-critical mutation contours. Public surface сохранён: `160 paths / 166 operations / 169 schemas`; hidden `8`; mounted `174`; registered protected Python surface `371 symbols / 70 modules / 86 files`; frontend product pages `39`.
- Подтверждённые repairs нового candidate: watcher P0 `trusted time → 180-day barrier → replay → mutation → ledger`; readiness принимает только authorized migration `0001`; `/cron/tick` в prod/stage регистрирует scheduler jobs strict; encrypted recovery требует ciphertext SHA-256; production update/release contour использует канонический `EFHC_Bot_vNNN_NN.zip` без `_RELEASE`.
- DR/VPS runbooks и current application-function authority синхронизированы с exact source. Referral leaderboard public routes отмечены retired при сохранённой referral economy; Skins — progression-only, `/skins/buy/{skin_id}` остаётся fail-closed compatibility `409 SKIN_COMMERCE_DISABLED`.
- Database schema не менялась: ORM `52 = 45 core + 7 admin`, frozen `0001` сохранён, `0002+` отсутствует. Schema lock — governance lock на неутверждённый DDL, не runtime table/CRUD lock.
- FRONTEND_v146 runtime bytes не менялись. Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.41_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ/locale/PWA остаются standalone checked-in release assets.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI после audit repairs не запускались. Поэтому `v174.41` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**, а не GREEN.
- Immutable report: `02359`; следующий `02360`. Canonical handoff: `EFHC_Bot_v174_41.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.40 / цикл 1790 CI qualification hygiene

- GitHub CI `87074955772` проверил exact `v174.39`: SHA-256 `1c260f385c545cef65d329dd17c766e391133554cedca4d4a58491df5f3de872`, checkout `89ad260f71296de0cb71efde2871ab248e9b8e90`. GREEN все recorded gates кроме pytest; pytest `1 failed / 1669 passed / 22 skipped / 1 warning`.
- Единственный confirmed defect — два английских docstring в development-only FAQ duplicate-control verifier. Исправлены только docstring; runtime/frontend/backend/schema semantics не менялись.
- FAQ остаётся самостоятельным checked-in release asset; SSOT — duplicate control only, без runtime write. Release packaging остаётся application-byte verify-only.
- Важно: database/schema lock — это governance lock на неутверждённые DDL/schema/migration changes, **не** runtime lock таблиц и **не** запрет CRUD. Существующие 52 таблицы работают штатно. Frozen `0001` и запрет `0002+` сохраняются до отдельного direct owner decision о schema unlock/change.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.40_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. Frontend controlled bytes не менялись.
- Локальные project tests/guards/lint/type/build/Alembic/PostgreSQL/CI не запускались. Candidate `v174.40` требует следующего exact-head GitHub CI.
- Immutable report: `02358`; следующий `02359`. Canonical handoff: `EFHC_Bot_v174_40.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.39 / цикл 1790 release-asset independence + CI qualification repair

- GitHub CI `87062684580` проверил exact `v174.38`: SHA-256 `3f1c7627ae5f91ecb4ba182506a7ba57e3c88309b5b72507689e2d67e3c9cd75`, checkout `61b6bd10c6bffc9a008274a79aec52db3408ce07`. GREEN: Development HEAD SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures классифицированы как qualification-only: hardcoded frontend authority предыдущей версии и два legacy-term guards, ошибочно сканировавшие current control-plane/evidence summaries. Runtime/backend/frontend product behavior этим CI не опровергнут.
- Прямое owner decision цикла 1790: checked-in frontend FAQ является самостоятельным production release asset; FAQ SSOT остаётся только дублирующим контролем и не может генерировать или переписывать runtime FAQ.
- Release packaging переведён в verify-only application-asset mode: `build_release_archive.py` проверяет заранее готовые FAQ/locale/PWA assets и не запускает FAQ/PWA generators. Packaging создаёт только собственные release metadata/checksums в staging.
- Dependency audit: frontend prebuild уже verify-only; OpenAPI/API/backend/schema runtime не генерируются из docs/SSOT при release packaging; development generators остаются вне packaging.
- Database migration lock остаётся active: frozen `0001_initial_release_schema.py`; `0002+`/schema expansion только по отдельному direct owner decision. В cycle 1790 schema не менялась.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.39_FRONTEND_v146`; entries `195`; source lock `c030ff97189b46cabaa2f6bc7cea28832b6de0c05ce972e2d9bd86cfe6141c7c`; PWA `efhc-67d8046a258e1879`. FAQ content Q/A bytes не менялись; изменён только authority header и release-control metadata.
- Локальные tests/build/CI/Alembic/PostgreSQL не запускались. Candidate `v174.39` требует следующего exact-head GitHub CI.
- Immutable report: `02357`; следующий `02358`. Canonical handoff: `EFHC_Bot_v174_39.zip`; descriptive archive suffixes и owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.38 / цикл 1789 continuation CI qualification repair

- GitHub CI `86992003426` проверил exact `v174.37`: SHA-256 `b8fb3fa6ca22f99d4ad1054f7cad8c2b65e6db8cb51071dad9b060295b97bd2d`, checkout `7384e8284dbde416086a13bd23de7136be585681`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 pytest failures repaired только в qualification layer: stale Admin history literal → current functional contract; FAQ test function name → Russian engineering policy; stale `current_cycle` → current state key `cycle`. Approved FRONTEND_v146 runtime не откатывался.
- FAQ current parity: `13 × 250/250` SSOT↔runtime. Runtime/prebuild SSOT-independent; release packaging пока SSOT-generating. Standalone verify-only FAQ packaging — **RECOMMENDATION, не owner decision**, поэтому release scripts не менялись.
- Routes/schema audit: `160 paths / 166 public ops / 8 hidden / 174 mounted`; OpenAPI `169 schemas`; ORM/frozen migration exact `52 = 45 core + 7 admin`. Migration lock остаётся active: `0001` frozen; `0002+` только по direct owner decision.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.38_FRONTEND_v146`; entries `195`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`. Backend routes/services, frozen `0001`, FAQ runtime и release scripts cycle continuation не менялись.
- Локальные tests/build/CI не запускались. Candidate `v174.38` требует следующего exact-head GitHub CI.
- Immutable report: `02356`; следующий `02357`. Canonical handoff: `EFHC_Bot_v174_38.zip`; descriptive suffixes/owner-facing sidecars запрещены.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.37 / цикл 1789 CI qualification repair

- GitHub CI `86988434882` проверил exact предыдущий `v174.36`: SHA-256 `4d5ada1cadac43f0efb36d8e374b4e612b495588da27d70bce2595ee45727e77`, checkout `9ea7355f2f498cdb1cd91dd6ab29cd36fcf13f0b`. GREEN: SHA, Flake8, Ruff, Mypy, Bandit, compileall, PostgreSQL/Alembic и frontend build; RED только pytest `3 failed / 1666 passed / 22 skipped / 1 warning`.
- Все 3 failures — stale qualification guards относительно approved FRONTEND_v146: Admin copy literal заменён функциональным EFHCb/EFHCm selector contract; FAQ historical translation literals заменены current SSOT↔runtime parity; HI history registry expectation `7 -> 13`. Runtime/frontend patch не откатывался.
- FAQ delta FRONTEND_v146 велик только в `hi/id/sw`; остальные 10 языков Q/A не изменены. Cycle 1789 не меняет FAQ runtime content.
- Release audit: frontend runtime/prebuild отвязан от Python/docs/SSOT, но release packaging всё ещё намеренно генерирует FAQ из SSOT через `build_release_archive.py -> prepare_frontend_release_assets.py -> generate_faq_catalogs_from_ssot.py`. Release scripts не менялись.
- Current frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.37_FRONTEND_v146`; source lock `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA build id `efhc-1466a8410f8c50ab`. Frozen `0001`, backend/API/financial semantics unchanged.
- Локальные tests/build/CI не запускались. Candidate `v174.37` требует следующего exact-head GitHub CI.
- Immutable report: `02355`; следующий `02356`. Canonical handoff: `EFHC_Bot_v174_37.zip`, без descriptive suffix и sidecars.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD snapshots являются историей и не переопределяют этот первый блок.

# CURRENT RELEASE HANDOFF — v174.36 / cycle 1788

- Canonical handoff filename: `EFHC_Bot_v174_36.zip`; descriptive archive suffixes are forbidden by archive naming CANON.
- Source CI `86966635485` tested previous `v174.35` SHA `3858f0859222e5edef5a37c7617ca399b315f3086105d92d9e462160dbc7ad6f`; repair is candidate-only until next exact-head GitHub CI.
- Approved FRONTEND_v146 is preserved. Authority: `INTEGRATED_FRONTEND_SOURCE_v174.36_FRONTEND_v146` / `b3d525d9c6646693ecb5c63e1fe48d01782be5e0ee1690e8d7dcac599fa63e89`; PWA `efhc-1466a8410f8c50ab`.
- No local full tests/build/CI were executed.

# CURRENT HEAD — кандидат v174.35 / цикл 1788 FRONTEND_v146 runtime integration

- Прямой owner order 2026-08-18 открыл цикл `1788` и supersedes прежний «0 future cycles» только для этого exact scope.
- Physical HEAD: `v174.35`. Supplied FRONTEND_v146 patch SHA-256 `19e7b087da7ce017013fa025bcbba29bdeca708c565008d2610139df56d87ebf` применён к `74` frontend paths; patch после установки удалён; `VERSION` остаётся `v174.35`.
- Integrated frontend authority: `INTEGRATED_FRONTEND_SOURCE_v174.35_FRONTEND_v146`; source lock `216fde318f26eb220c43bf6c4f6dacc0439af138fdac62e3719ca5351a0d1c3f`; PWA build id `efhc-aa086fd20c4cc2f2`.
- Frontend согласован с current backend/API: Admin provider lookup использует existing `GET /admin/users/resolve-provider`; backend/frozen `0001`/BANK/P0/financial semantics patch не меняет.
- Latest available exact-head GREEN evidence остаётся `v174.33`, GitHub CI `86661926957`, SHA-256 `ae5dc9fb2657957b40560cbb350aad435168532c575a2c492ba703f3635f4a5f`, checkout `4855c1f86a329978eae6e2fdd92059ba953a4e9f`. Это не квалифицирует `v174.35`.
- Новые GitHub CI logs фактически не приложены к handoff; CI-derived failures/repairs не утверждаются. PENDING question: `QA-2026-08-18-CI1788-P01`.
- Static-only verification: patch applicability, changed JSON parse, locale parity, API seam/source alignment и deterministic metadata hashes. Локальные pytest/Ruff/Mypy/Bandit/Flake8/npm build/Alembic/PostgreSQL/CI не запускались.
- Immutable report: `02353`; следующий `02354`. Создан `docs/cycles/WORK_CYCLES_1801-1900.md` как future range container; автоматически утверждённых cycles после `1788`: `0`.

> **Historical boundary:** нижележащие прежние CURRENT/CURRENT HEAD/CURRENT RELEASE STATE snapshots являются историей и не переопределяют этот первый блок.

# CURRENT HEAD — кандидат v174.34 / цикл 1787 historical Q/A + document audit continuation

- Exact-head GitHub CI `86661926957` полностью квалифицировал `v174.33`: SHA-256 `ae5dc9fb2657957b40560cbb350aad435168532c575a2c492ba703f3635f4a5f`, checkout `4855c1f86a329978eae6e2fdd92059ba953a4e9f`; все gate exits `0`; pytest `1664 passed / 22 skipped / 1 warning`; Ruff/Mypy/Bandit/Flake8/PostgreSQL/Alembic/frontend build GREEN. Подтверждённых CI failures нет.
- Цикл `1787` продолжен прямым owner order как archive/Q&A/document consolidation. Production/backend/frontend/OpenAPI/financial semantics не меняются.
- Полностью проверены все `35` доступных numbered transcripts в `docs/chats/`; найдено `58` явных Q/A-маркеров в `9` чатах. Доказуемые owner decisions восстановлены в append-only `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`; неполные `Да/Нет` без исходного вопроса и вопрос без доказанного ответа не превращаются в owner CANON.
- Recovery evidence: `docs/audits/Q_A_CHAT_RECOVERY_AUDIT.md` + `reports/generated/Q_A_CHAT_RECOVERY_AUDIT_v174_34.json`.
- Документный drift исправлен: chat README/count, transcript recovery protocol, Q/A recovery law, current SSOT/handoff/reports/manifests. Исторические numbered chats/reports не переписываются.
- Immutable report: `02352`; следующий report: `02353`. После `1787` автоматически утверждённых future functional cycles: `0`; следующий обязательный verifier — exact-head GitHub CI `v174.34`.
- Локальные pytest/Ruff/Mypy/Bandit/Flake8/npm/Alembic/PostgreSQL не запускались.

> **Historical boundary:** все расположенные ниже блоки с прежними заголовками `CURRENT`/`CURRENT HEAD`/`CURRENT RELEASE STATE`/`TEST GUARD MANIFEST`/`OWNER LOCK` являются неизменяемыми снимками прошлых кандидатов и не переопределяют первый блок этого файла.

# CURRENT HEAD — кандидат v174.33 / циклы 1786–1787

- Exact-head GitHub CI `86656504640` полностью квалифицировал `v174.32`: SHA-256 `fbff4bf915c24103b7f439f1b7f945a6a54857b89d562193d6988b545439804c`, checkout `8aa2fdc22f8e09292cf71a766ef6c9fe868b08a2`; все gate exits `0`; pytest `1664 passed / 22 skipped / 1 warning`; frontend latest-dependencies build PASS. Подтверждённых CI failures нет.
- Циклы `1786–1787` открыты прямым owner order. `1786` — Shop operator decomposition без дублирования backend: `Магазин` остаётся каталогом/общим обзором; отдельная плитка `Товары` не создаётся; `Заказы` → `/admin/shop?module=orders`; `Выдача / VIP NFT` → `/admin/shop?module=nft`; одна reserve-плитка остаётся свободной.
- `1787` — archive/Q&A/SSOT consolidation: append-only Q/A register, current decisions, Kernel/handoff/active SSOT, cycle/report records и transcript `docs/chats/58.md` актуализированы по решениям текущего чата. Исторические immutable reports не переписываются.
- Financial/backend/OpenAPI semantics не дублируются и не меняются; frozen `0001`, P0 `<180d`, BANK и owner-approved `ci_github.yml` сохраняются.
- Immutable report: `02351`; следующий report: `02352`. После `1787` автоматически утверждённых future functional cycles: `0`; следующий обязательный verifier — exact-head GitHub CI `v174.33`.
- Локальные pytest/Ruff/Mypy/Bandit/Flake8/npm/Alembic/PostgreSQL не запускались.

# EFHC Bot v173.42 — exact-head CI repair + function recovery plan candidate

Status: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`  
Последний supplied exact-head CI: `84954546920` на `v173.41`, archive size `12135299` bytes.

Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy `2` errors; pytest `17 failed / 1485 passed / 22 skipped`. В текущем HEAD внесены только подтверждённые repairs. `global_id` ownership, BANK и Admin NFT canons не ослаблялись.

Packaging metadata `v173.41` исправлена: executable modes и исторические Unicode filenames восстановлены. `production_release_ready=false`. Следующий этап — exact-head GitHub CI пользователя и цикл 1719 по плану согласования функций.

## Текущая точка — кандидат v174.23 / циклы 1774–1776

- Входной HEAD: `EFHC_Bot_v174_22.zip`, SHA-256
  `bed53b4ef5f1c332bd7aa682e0e2d4f2fbb9437f3487be13adbc45aa7446017a`,
  размер `12982903` bytes, `4681` entries.
- GitHub CI `86601931863` вычислил тот же SHA-256 для `efhc.zip`;
  checkout `c7e2c66b92a6374426b5035c0c7ab15806bccc93`.
- Основной контур GREEN: Flake8, Mypy, Bandit, compileall, PostgreSQL,
  frozen Alembic `52 ORM / 53 physical / 0001: ok`, frontend latest build
  `routes=33 / manifest=40`.
- RED только qualification: Ruff `I001` в retention architecture test и
  pytest manifest count `277` против фактических `278`.
- Candidate `v174.23` исправляет оба drift. Financial runtime, BANK/ledger,
  P0 180-day barrier, frozen `0001`, internal canonical CI и API не меняются.
- Цикл `1775` staged foundation функционально завершён; `1776` открыт как
  physical partition blocker contract без DDL/DROP.
- Generated dependency graph:
  `reports/generated/FINANCIAL_PARTITION_DEPENDENCY_GRAPH_v174_23.json`.
- `1774` остаётся qualification-tail до полного exact-head green.
- Следующий функциональный цикл: `1777`.
- Следующий immutable report после `02341`: `02342`.
