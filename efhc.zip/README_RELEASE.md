# ТЕКУЩИЙ RELEASE STATUS — v174.66 / цикл 1806

- Входной exact-head CI `87917878179` проверил `v174.65` SHA-256 `b070a03c6e474809aede2c68945283875eeee34620cc92f63a8a4f1d979cf13b`, checkout `d1e98c63e4ade94a8bb7ac74b7fd92d1297e1d64`.
- Подтверждённые RED `v174.65`: Ruff `5`, Mypy `12`, pytest `1`; все их root causes исправлены в текущем source.
- GREEN gates `v174.65`: Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build.
- `v174.66` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.65 / цикл 1805

- Основа: physical `EFHC_Bot_v174_64.zip`, SHA-256 `913e34cacf4ba7d95bb37214d8c1b3ee2589a615389f455781c0a11b91da6a5e`.
- Source repair: подтверждённые elapsed/access/financial/scheduler обходы `ApplicationClock` переведены на `app.lib.time.utcnow()`.
- Financial retention: пороги `180/370/400` и deletion logic неизменны; service/foundation byte-exact относительно входа.
- Добавлен architecture regression source; локальные qualification suites не запускались.
- Последний exact-head GREEN: `v174.62`, CI `87895142054`.
- `v174.65` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
