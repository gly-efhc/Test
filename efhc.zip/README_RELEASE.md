# ТЕКУЩИЙ RELEASE STATUS — v174.65 / цикл 1805

- Основа: physical `EFHC_Bot_v174_64.zip`, SHA-256 `913e34cacf4ba7d95bb37214d8c1b3ee2589a615389f455781c0a11b91da6a5e`.
- Source repair: подтверждённые elapsed/access/financial/scheduler обходы `ApplicationClock` переведены на `app.lib.time.utcnow()`.
- Financial retention: пороги `180/370/400` и deletion logic неизменны; service/foundation byte-exact относительно входа.
- Добавлен architecture regression source; локальные qualification suites не запускались.
- Последний exact-head GREEN: `v174.62`, CI `87895142054`.
- `v174.65` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
