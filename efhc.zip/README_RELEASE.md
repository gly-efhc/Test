## Текущая рабочая блокировка — кандидат v173.79 / цикл 1749

- Exact-head CI `85806294354` проверил входной `v173.78` (`12621087` bytes, checkout `6ff22c5f7cd72dee81a60656eb518fae18fc8a00`).
- Failing gates: Ruff `1×SIM102`; pytest `1 failed / 1562 passed / 22 skipped / 1 warning`. Остальные supplied canonical gates `exit=0`.
- Исправлены только guard/document drifts; production/backend/frontend/API/schema/ORM не менялись. Audit 5 VIP/NFT semantics сохранены.
- Protected floor: `355 symbols / 66 modules / 81 files / 156 paths / 162 operations / 39 frontend pages`; schemas `168`, ORM `55`.
- Локальные tests/CI/build не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1750`, после exact-head qualification нового кандидата либо по следующему утверждённому audit scope владельца.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.

## Текущее состояние разработки — кандидат v173.50 / цикл 1725

Admin VIP/NFT использует фактическую проверку владения NFT; ручное назначение VIP больше не является рабочим поведением. Оплаченный Shop NFT order — единственная заявка на ручную выдачу и обрабатывается через очередь Admin Shop. `submit_manual_vip_nft_claim` имеет статус `REPLACED_BY_CANON / DO_NOT_RESTORE`. Требуется следующий exact-head GitHub CI.

> Current Development HEAD candidate: `v173.49`; completed cycle 1724; next exact-head GitHub CI required.

# EFHC Bot v173.42 — exact-head CI repair + function recovery plan candidate

Status: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`  
Последний supplied exact-head CI: `84954546920` на `v173.41`, archive size `12135299` bytes.

Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy `2` errors; pytest `17 failed / 1485 passed / 22 skipped`. В текущем HEAD внесены только подтверждённые repairs. `global_id` ownership, BANK и Admin NFT canons не ослаблялись.

Packaging metadata `v173.41` исправлена: executable modes и исторические Unicode filenames восстановлены. `production_release_ready=false`. Следующий этап — exact-head GitHub CI пользователя и цикл 1719 по плану согласования функций.