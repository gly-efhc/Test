<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

# EFHC Bot v173.10 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `EXACT_HEAD_CI_REQUIRED`  
`production_release_ready = false`

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- Alembic head — только `0001_initial_release_schema.py`.
- Папка `АРТЕФАКТЫ/` не включается в production RELEASE.
- Исторические release claims не определяют статус текущего HEAD.

Новый exact-head GitHub CI обязателен перед любым объявлением readiness.
