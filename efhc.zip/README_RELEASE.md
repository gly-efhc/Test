<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

<!-- EFHC_TON_PROVIDER_SUBJECT_CANON_V173_23 -->
TON provider subject: `ton_wallet_id` = адрес TON-кошелька. `ton_address` не
является provider-subject alias; generic storage `provider_subject` для
`provider=ton` содержит значение `ton_wallet_id`.

# EFHC Bot v173.26 — local release candidate

Статус: `LOCAL_RELEASE_CANDIDATE`  
Qualification: `EXACT_HEAD_CI_REQUIRED`  
`production_release_ready = false`

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- Development-only `docs/`, `reports/`, `tests/`, skills/agents/commands/hooks/references и внешний history archive не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.

Входной GitHub CI run `84704272282`, commit
`02667638d2b423fbc733a8e32a88b44996a3ba6e`, подтвердил 11 pytest failures
на предыдущем HEAD. Текущий v173.26 включает завершение cycle 1704 и corrective 1705; exact-head GitHub CI после этих изменений обязателен для квалификации.
