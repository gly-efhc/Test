# ТЕКУЩИЙ HEAD — v174.73 / cycle 1813 / document language regression protection + Healer

- Physical input: `EFHC_Bot_v174_72.zip`.
- OWNER CANON: human-readable `documents`, `reports`, `cycles` и owner-facing `chat` используют Russian descriptive prose, сохраняя `technical terms` и `concepts` на English.
- `Document language policy` не является `source code style policy`; она не регулирует `source code`, `identifiers`, `test names`, `comments`, `docstrings`, `types`, `properties`, `machine literals`, `API/SQL/protocol` names.
- Permanent marker: `EFHC_DOCUMENT_LANGUAGE_SCOPE_CANON_V1`. Machine CANON фиксирует `source_code_in_scope: false` и `code_rename_for_document_language: forbidden`.
- Permanent architecture guard: `tests/architecture/test_document_language_scope_canon.py`.
- Healer disease: `HEAL-0127 / CASE-0140`, category `governance_language_scope_regression`, severity `P1`.
- Direct OWNER permission использована для amendment `AI_ARCHIVE_LAWS`; lock SHA синхронизирован.
- Runtime/backend/frontend/schema/business semantics не менялись. Последний подтверждённый exact-head GREEN остаётся `v174.69` / CI `88066448299`; `v174.73` требует fresh exact-head GitHub CI.
- Immutable report `02392`; следующий `02393`.
- Полные local qualification suites не запускать.

> Historical blocks ниже являются evidence и не переопределяют current OWNER CANON.

# ТЕКУЩИЙ HEAD — v174.72 / цикл 1812 / исправление области русскоязычной политики

- Physical input: `EFHC_Bot_v174_71.zip`.
- OWNER correction: команда «все отчёты в чате и архиве на русском языке» относится только к человекочитаемым документам, отчётам и сообщениям в чате.
- Программный код полностью исключён из этой языковой политики: она не задаёт язык identifiers, имён test-функций, docstring, comments, API/SQL/protocol/machine literals и иных code artifacts.
- Подтверждена первопричина: legacy `ops/quality/check_russian_engineering_language.py` сканировал `backend/**/*.py`, `ops/**/*.py`, `scripts/**/*.py`, `tests/**/*.py` и отдельно запрещал нерусские имена `test_*`; именно поэтому policy затрагивала код.
- Guard исправлен по OWNER scope: теперь он контролирует только Markdown/текстовые документы и текущие человекочитаемые reports; программные source directories не квалифицируются по языку.
- Active NORM переписан под документную область. Добавлен regression contract: английские Python docstring/comment/test name допустимы, новый английский README остаётся нарушением документной политики.
- Исторические смешанные/русские code identifiers не переименовываются массово: язык больше не является причиной менять code/node IDs.
- Runtime/backend/frontend/business/schema semantics не менялись. Последний подтверждённый exact-head GREEN остаётся `v174.69` / CI `88066448299`; `v174.72` требует следующего exact-head GitHub CI.
- Immutable report `02391`; следующий `02392`.
- Локальные полные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами прежних состояний и не переопределяют текущую OWNER-норму.

# CURRENT HEAD — v174.71 / цикл 1811 / CI `88284991086` + FRONTEND_v196 mini-audit repair

- Physical input: `EFHC_Bot_v174_70.zip`, SHA-256 `56db5d7d024e5c0700132b16133e35062e34eb46bcd56ccdf9593638922590c3`.
- CI `88284991086` доказан exact-head для `v174.70`: checkout `01c8b2874dbf7cd22d7d754f1b97c92a020f390b`, logs SHA-256 `71273d053fb9cafc47079cb5efe0ddf689591ffb45f83c851c3aaffe1b5ffe0c`.
- Gate matrix исходного HEAD: `10/12 GREEN`; RED — pytest `14 failed / 1749 passed / 22 skipped / 1 warning` и frontend production build с `3` TypeScript diagnostics. Ruff, Mypy, Flake8, Bandit, compileall, PostgreSQL/Alembic и npm install — GREEN.
- Исправлены только подтверждённые CI причины: missing `Button` import, Admin Shop nullable editor contract, два unsafe raw-error render shape, stale frontend/admin/withdraw tests и machine compatibility marker после FRONTEND_v195 consolidation.
- Mini-audit `FRONTEND_MAIN_SYNC_AUDIT_v196.md` SHA-256 `45a13d5bc5bd3987c61200aec3104b4ada02dfb1e7de97684c8d1a9cc8131915` разобран полностью как входное evidence: заявленные `25` diff имеют disposition; отдельно подтверждён main defect `identity.ts` — `12` кириллических program property identifiers заменены на `field/code/message`. Архив/patch FRONTEND_v196 не предоставлялся, поэтому byte-exact authority FRONTEND_v196 не утверждается; текущая authority остаётся FRONTEND_v195 + подтверждённые main repairs.
- OWNER withdrawal rule: после успешного wallet send + сохранённого `payout-evidence` frontend сразу вызывает `mark-paid`; если evidence/ответ не зафиксирован, оператор нажимает `Оплачено`, и без evidence открывается manual recovery с обязательной причиной. Отдельная кнопка `Оплачено` сохраняется.
- Внешние deposit/withdraw/Browser Shop остаются D2 business boundary; TON D9 / USDT D6 — только native atomic transport.
- Backend/schema/frozen `0001` не менялись. Последний полностью GREEN exact-head остаётся `v174.69` / CI `88066448299`; `v174.70` не GREEN.
- Frontend authority `211/211`, source-lock `30bd3f8ed09dea22f54dbc121a7fa36efda9be766a79a5180c94f48ad7b95fcf`; PWA build-id `efhc-d7cd1db33319cb2a`; release assets `29/29`.
- Immutable report `02390`; следующий `02391`. `v174.71` — candidate / next exact-head GitHub CI required.
- Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# CURRENT HEAD — v174.70 / цикл 1810 / FRONTEND_v195 reconciliation

- Physical input: `EFHC_Bot_v174_69.zip`, SHA-256 `a6095e4da727f232f2a715c3e7d1ebad9b1fd7e2842c5b2eb0bf11df7f59cfd0`.
- Exact-head CI `88066448299` проверил `v174.69`: checkout `91065a41ba9450359ddded5f2643196c74f448d0`, все `12/12` gates GREEN, pytest `1760 passed / 22 skipped / 1 warning`, frontend build PASS.
- `v174.69` — последний полностью GREEN exact-head.
- Owner patch `FRONTEND_v195` интегрирован с обязательным higher-CANON overlay: Bank snapshot refresh/export, Shop D2/`0.00` disabled и checked-in FAQ authority; PaymentIntent frontend transport принят из FRONTEND_v195 при неизменной backend native-atomic settlement authority.
- Внешний EFHC deposit/withdraw и Browser Shop остаются D2 business boundary; TON D9 / USDT D6 — только native atomic transport representation уже утверждённой внешней суммы.
- Подтверждённые compile-level donor defects исправлены; backend/schema не изменялись.
- При подтверждённом frontend↔financial/security CANON conflict требуется прямое OWNER clarification; оператор не выбирает сторону самостоятельно.
- Frontend authority `211/211`, source-lock `cb62c557bcd3583c4481e32053a642bd9455344f003255e69aee6ec72408588f`; PWA build-id `efhc-2149972a23ae2dbe`; release assets `29/29`.
- Immutable report `02389`; следующий `02390`. `v174.70` — candidate / next exact-head GitHub CI required.
- Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩИЙ RELEASE STATUS — v174.69 / цикл 1809

- Exact-head CI `88039356151` квалифицировал `v174.68` полностью GREEN: SHA-256 `e5a27a508c66e65f7fd7a37965dacf04cd16e519433472ca91ea343c151974f5`, checkout `3689d3158d76d8d9e8e77767bc7b7f8702d0b424`, `12/12` gates GREEN, pytest `1760 passed / 22 skipped / 1 warning`.
- ApplicationClock regression tests уже существуют с `v174.65`: `5` test-функций, из них `3` динамических clock-jump tests. Новый duplicate test не требуется.
- Runtime/frontend/test source в цикле 1809 не менялись; выполнена только evidence/governance/release closure.
- `v174.69` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.68 / цикл 1808

- CI `88034310249` доказан exact-head для `v174.67`: SHA-256 `b386cb38023b7b9d022b9008f82665ac6ab93e091c37f7bff35147267395e695`, checkout `3b9809f5d3424d8724ca801428aba5c6a91a7bfd`; supplied logs SHA-256 `3e8efec8c1ec6deb68fc5da17d4162ef65fb6bb7108b7b316b801571f864fe37`.
- GREEN: Development SHA, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build. RED только pytest: `1 failed / 1759 passed / 22 skipped / 1 warning`.
- Единственная причина — numbered work-pass label в `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; guard корректен, test не ослаблялся.
- Repair только qualification/governance metadata; frontend/runtime source, financial/security invariants и schema не менялись.
- Последний полностью GREEN exact-head: `v174.66` / CI `87928232215`. `v174.68` — candidate / next exact-head GitHub CI required.
- Immutable report `02387`; следующий `02388`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩИЙ RELEASE STATUS — v174.67 / цикл 1807

- Exact-head CI `87928232215` проверил `v174.66` SHA-256 `ad06f32010608ac9b350f8fa35b2bccdca4e89503ac975c8c62523e7bd801c89`, checkout `15aeb2e019dac699ee1a959a256997a4d1ea23ca`; `12/12` gate exit-файлов равны `0`.
- `v174.66` теперь полностью подтверждённый exact-head GREEN: Ruff/Mypy/Bandit/Flake8/PostgreSQL/Alembic/pytest/frontend GREEN; pytest `1760 passed / 22 skipped / 1 warning`.
- Текущий source repair ограничен четырьмя финансовыми timestamp bypasses ApplicationClock и расширением существующего regression guard.
- `v174.67` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.66 / цикл 1806

- Входной exact-head CI `87917878179` проверил `v174.65` SHA-256 `b070a03c6e474809aede2c68945283875eeee34620cc92f63a8a4f1d979cf13b`, checkout `d1e98c63e4ade94a8bb7ac74b7fd92d1297e1d64`.
- Подтверждённые RED `v174.65`: Ruff `5`, Mypy `12`, pytest `1`; все их root causes исправлены в текущем source.
- GREEN gates `v174.65`: Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build.
- `v174.66` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.65 / цикл 1805

- Основа: physical `EFHC_Bot_v174_64.zip`, SHA-256 `913e34cacf4ba7d95bb37214d8c1b3ee2589a615389f455781c0a11b91da6a5e`.
- Source repair: подтверждённые elapsed/access/financial/scheduler обходы `ApplicationClock` переведены на `app.lib.time.utcnow()`.
- Financial retention: пороги `180/370/400` и deletion logic неизменны; service/foundation byte-exact относительно входа.
- Добавлен architecture regression source; локальные qualification suites не запускались.
- Последний exact-head GREEN: `v174.62`, CI `87895142054`.
- `v174.65` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
