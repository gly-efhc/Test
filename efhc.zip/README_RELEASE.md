## Текущая точка — кандидат v173.85 / цикл 1752 continuation — exact-head CI burn-down v173.84

- Exact-head GitHub CI `85947769920` квалифицирован для входного `v173.84`: checkout `2a7e9d6d1fe2c3fb89b3664246bfd048c36cf046`, CI archive `12537062` bytes. Единственный failing gate — pytest: `4 failed / 1574 passed / 22 skipped / 1 warning`; Alembic/PostgreSQL, Ruff, Mypy, Bandit, compileall, Flake8 critical/full, npm ci и frontend build успешны.
- Два schema failures — stale integration constants `EXPECTED_FK_COUNT=41`; current `0001` и active release state канонически имеют `42` FK на `users.global_id`. Оба expectations синхронизированы на `42`.
- Первый referral failure — stale lookup ненумерованного `REF_ACT_UNIT` и неверного owner в fixture; expectation синхронизирован с canonical inviter-owned `REF_ACT_UNIT:G{inviter_global_id}:N00001`.
- Второй referral failure — boundary fixture создавал `9999` active referrals напрямую, но не моделировал уже закреплённые slots `1..9998`, поэтому allocator корректно начинал с `N00001`. Fixture теперь моделирует prior slot ownership `1..9998`, после чего проверяет `N09999`, `N10000` и отсутствие slot у `10001`-го active referral.
- Production/runtime/DevOps/referral economics не изменялись. Независимые `REF_ACT_UNIT`, `REF_LVL` и нефинансовый Rankings CANON сохранены. ORM floor `56`; global owner FK floor `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.85` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.85` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.84 / цикл 1752 continuation — exact-head CI burn-down v173.83

- Exact-head GitHub CI `85940762760` квалифицирован для входного `v173.83`: checkout `f0456d329f84ed1cd6183c2297188a7e3f626aa2`, CI archive `12529560` bytes. Failing gates: Alembic, Ruff и pytest; Mypy/Bandit/compileall/Flake8/frontend gates успешны.
- Alembic root cause: после Audit 7 таблица `ad_provider_claims` добавила ещё один canonical FK на `users.global_id`, поэтому фактический count `42`, а `0001` validator и его static contract guard оставались на `41`.
- Ruff root cause: только `I001` в новом DevOps architecture guard.
- Независимые pytest drifts: provider-portability gate всё ещё ожидал прямой predeploy `backup_postgres.sh` вместо current `telegram_backup_delivery.sh`; daily backup test ожидал прямой `backup_bundle.sh` вместо delegated Telegram chain; referral Lvl fixture не предоставлял `db.scalar()` для historical key read-through; `INSTALL.md` потерял явный literal `chmod 600`. Остальные DB failures/errors являются следствием failed Alembic setup из supplied run.
- Все подтверждённые причины исправлены без изменения DevOps safety model, referral economics или Audit 7 runtime semantics. ORM floor остаётся `56`; global owner FK floor current `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.84` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.84` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.83 / цикл 1752 — Autonomous DevOps + exact-head CI burn-down

- Exact-head GitHub CI `85876332157` квалифицирован для входного `v173.82`: checkout `78ac7c355be6cc9f6c8215baa647a31960658a27`, CI archive `12480201` bytes. Ruff/Mypy/Bandit/compileall/Flake8/frontend gates успешны; Alembic падает на stale `EXPECTED_TABLE_COUNT=55` при canonical ORM floor `56`, что порождает каскад DB pytest errors. Независимые pytest drifts: Audit-6 revoke SQL literal, Ranks marker, test/current-state version и referral numbered-slot fixture.
- Все подтверждённые CI root causes исправлены без отката Audit 7: database contract = `56`, stale guards/fixture синхронизированы с active CANON.
- Цикл 1752 реализует repository/release часть autonomous DevOps: encrypted Telegram backup, local Bot API integration, status/autopilot/diagnostic, daily/weekly/monthly/post-reboot timers, external-monitor artifact, ENV preflight и safe host prerequisites. Фактическая установка на production/external VPS в этом чате не выполнялась — доступа к VPS нет.
- Referral economics закреплена тремя независимыми контурами: `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`, `REF_LVL:G{inviter_global_id}:L{level}` и нефинансовый referral/ranking display. Historical Lvl keys сохраняются только для idempotent read-through.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.83` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.83` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.82 / цикл 1751 — Unified Deep Audit 7

- Exact-head GitHub CI `85849626798` квалифицировал входной `v173.81`: checkout `ab5591d411da6d87591459f6350b0de0f91189fb`, CI archive `12464501` bytes. Failing gates: Ruff `UP012`, Bandit `B608`, pytest `1 failed / 1566 passed / 22 skipped / 1 warning`; остальные supplied canonical gates завершились успешно.
- Все семь findings A7-R1…A7-R7 подтверждены по current source/SSOT/CANON и исправлены: Energy delta parity; ADS provider single-claim; Admin/Public Tasks atomicity; numbered referral slots; полный paged Ranks + direct find-me; progression-only Skins fail-closed legacy commerce.
- Exchange lifetime model не менялась: `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `271 architecture / 451 Python files`.
- Единственный Alembic head остаётся `0001_initial_release_schema.py`; новая ADS claim table входит в pre-release `Base.metadata.create_all()`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.82` требует exact-head GitHub CI.
- Следующий утверждённый функциональный scope после qualification — цикл `1752`, настройка окружения/автономного DevOps-контура по `EFHC_DevOps_TZ.md`.

## Текущая точка — кандидат v173.81 / цикл 1750

- Exact-head GitHub CI `85840461388` полностью квалифицировал входной `v173.80` (`12452133` bytes, checkout `3a80d8c8f85feff263771ebd0b3c33567d971f1e`); pytest `1563 passed / 22 skipped / 1 warning`, остальные supplied canonical gates `exit=0`.
- Audit 6 A6-01…A6-03 подтверждены по source/SSOT/CANON и исправлены: inactive-account session/RBAC/handoff kill-switch, JWT expected audience, bounded fail-closed TON challenge issuance/cleanup.
- Protected/API/ORM/frontend floor не изменён: `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- После patch локальные tests/CI/guards/build/Alembic/PostgreSQL не запускались. Candidate `v173.81` требует exact-head GitHub CI.
- Следующий функциональный цикл после qualification: `1751`; CI failures нового HEAD имеют приоритет над следующим audit scope.

## Текущая рабочая блокировка — кандидат v173.80 / цикл 1749 continuation

- Exact-head CI `85837515925` проверил входной `v173.79` (`12447211` bytes, checkout `8c63e2261e39445022f1c18eef2738667fe6bf8c`).
- Единственный failing gate: pytest `2 failed / 1561 passed / 22 skipped / 1 warning`; Ruff/Mypy и остальные supplied canonical gates успешны.
- Исправления только служебные: Russian Engineering Language drift в `KERNEL.md` и version drift `TEST_GUARD_MANIFEST`. Runtime/backend/frontend/API/schema/ORM не менялись.
- Candidate `v173.80` требует exact-head GitHub CI. Следующий номер цикла после закрытия 1749 — `1750`.

## Текущая рабочая блокировка — кандидат v173.79 / цикл 1749

- Exact-head CI `85806294354` проверил входной `v173.78` (`12621087` bytes, checkout `6ff22c5f7cd72dee81a60656eb518fae18fc8a00`).
- Failing gates: Ruff `1×SIM102`; pytest `1 failed / 1562 passed / 22 skipped / 1 warning`. Остальные supplied canonical gates `exit=0`.
- Исправлены только guard/document drifts; production/backend/frontend/API/schema/ORM не менялись. Audit 5 VIP/NFT semantics сохранены.
- Protected floor: `355 symbols / 66 modules / 81 files / 156 paths / 162 operations / 39 frontend pages`; schemas `168`, ORM `55`.
- Локальные tests/CI/build не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1750`, после exact-head qualification нового кандидата либо по следующему утверждённому audit scope владельца.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущее состояние разработки — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.

## Текущее состояние разработки — кандидат v173.50 / цикл 1725

Admin VIP/NFT использует фактическую проверку владения NFT; ручное назначение VIP больше не является рабочим поведением. Оплаченный Shop NFT order — единственная заявка на ручную выдачу и обрабатывается через очередь Admin Shop. `submit_manual_vip_nft_claim` имеет статус `REPLACED_BY_CANON / DO_NOT_RESTORE`. Требуется следующий exact-head GitHub CI.

> Current Development HEAD candidate: `v173.49`; completed cycle 1724; next exact-head GitHub CI required.

# EFHC Bot v173.42 — exact-head CI repair + function recovery plan candidate

Status: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`  
Последний supplied exact-head CI: `84954546920` на `v173.41`, archive size `12135299` bytes.

Supplied CI: Alembic/PostgreSQL, Flake8, Bandit, `compileall`, Ruff и frontend production build GREEN; Mypy `2` errors; pytest `17 failed / 1485 passed / 22 skipped`. В текущем HEAD внесены только подтверждённые repairs. `global_id` ownership, BANK и Admin NFT canons не ослаблялись.

Packaging metadata `v173.41` исправлена: executable modes и исторические Unicode filenames восстановлены. `production_release_ready=false`. Следующий этап — exact-head GitHub CI пользователя и цикл 1719 по плану согласования функций.