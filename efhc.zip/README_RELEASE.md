# ТЕКУЩИЙ RELEASE STATUS — v174.68 / цикл 1808

- CI `88034310249` доказан exact-head для `v174.67`: SHA-256 `b386cb38023b7b9d022b9008f82665ac6ab93e091c37f7bff35147267395e695`, checkout `3b9809f5d3424d8724ca801428aba5c6a91a7bfd`; supplied logs SHA-256 `3e8efec8c1ec6deb68fc5da17d4162ef65fb6bb7108b7b316b801571f864fe37`.
- GREEN: Development SHA, Flake8 critical/full, Ruff, Mypy, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build. RED только pytest: `1 failed / 1759 passed / 22 skipped / 1 warning`.
- Единственная причина — numbered work-pass label в `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; guard корректен, test не ослаблялся.
- Repair только qualification/governance metadata; frontend/runtime source, financial/security invariants и schema не менялись.
- Последний полностью GREEN exact-head: `v174.66` / CI `87928232215`. `v174.68` — candidate / next exact-head GitHub CI required.
- Immutable report `02387`; следующий `02388`. Локальные qualification suites не запускать.

> Исторические блоки ниже являются доказательствами и не переопределяют этот первый блок.

# ТЕКУЩИЙ RELEASE STATUS — v174.67 / цикл 1807

- Exact-head CI `87928232215` проверил `v174.66` SHA-256 `ad06f32010608ac9b350f8fa35b2bccdca4e89503ac975c8c62523e7bd801c89`, checkout `15aeb2e019dac699ee1a959a256997a4d1ea23ca`; `12/12` gate exit-файлов равны `0`.
- `v174.66` теперь полностью подтверждённый exact-head GREEN: Ruff/Mypy/Bandit/Flake8/PostgreSQL/Alembic/pytest/frontend GREEN; pytest `1760 passed / 22 skipped / 1 warning`.
- Текущий source repair ограничен четырьмя финансовыми timestamp bypasses ApplicationClock и расширением существующего regression guard.
- `v174.67` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.66 / цикл 1806

- Входной exact-head CI `87917878179` проверил `v174.65` SHA-256 `b070a03c6e474809aede2c68945283875eeee34620cc92f63a8a4f1d979cf13b`, checkout `d1e98c63e4ade94a8bb7ac74b7fd92d1297e1d64`.
- Подтверждённые RED `v174.65`: Ruff `5`, Mypy `12`, pytest `1`; все их root causes исправлены в текущем source.
- GREEN gates `v174.65`: Flake8 critical/full, Bandit, compileall, PostgreSQL preflight, Alembic, npm install, frontend build.
- `v174.66` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
- Локальные qualification suites не запускались.

> Исторические release-блоки ниже являются evidence.

# ТЕКУЩИЙ RELEASE STATUS — v174.65 / цикл 1805

- Основа: physical `EFHC_Bot_v174_64.zip`, SHA-256 `913e34cacf4ba7d95bb37214d8c1b3ee2589a615389f455781c0a11b91da6a5e`.
- Source repair: подтверждённые elapsed/access/financial/scheduler обходы `ApplicationClock` переведены на `app.lib.time.utcnow()`.
- Financial retention: пороги `180/370/400` и deletion logic неизменны; service/foundation byte-exact относительно входа.
- Добавлен architecture regression source; локальные qualification suites не запускались.
- Последний exact-head GREEN: `v174.62`, CI `87895142054`.
- `v174.65` — **CANDIDATE / NEXT EXACT-HEAD GITHUB CI REQUIRED**.
