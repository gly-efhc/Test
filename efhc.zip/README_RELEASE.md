# EFHC Bot v173.37 — post-migration cleanup candidate

Status: `POST_MIGRATION_RUNTIME_CLEANUP_PATCHED / EXACT_HEAD_CI_REQUIRED`  
Qualification anchor: `v173.36 EXACT-HEAD GREEN`  
GitHub CI: `84923645231` / checkout `cb915ded036615efaec297689787a3a5053a36e0` / blob `7139f9e65515d4fd553fad0872710d72dc842336`

Cycle 1712 qualified the `global_id` migration on exact `v173.36`. Cycle 1713 removed retired active-runtime aliases, stubs and temporary migration controls. `v173.37` itself has not been exact-head CI tested. `production_release_ready=false`. Next: cycle 1714.

## Release invariants

- Release собирается из точного Development HEAD.
- Внутренний owner — только `global_id`; внешний контракт — строка из 10 цифр.
- Provider IDs не используются как business ownership.
- `business_owner_tg_id = 0`.
- Alembic head — только `0001_initial_release_schema.py`.
- Development-only `docs/`, `reports/`, `tests/`, skills/agents/commands/hooks/references и внешний history archive не включаются в production RELEASE.
- Исторические claims не квалифицируют текущий HEAD.
