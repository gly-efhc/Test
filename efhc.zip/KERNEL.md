<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Identity-stage interpretation lock v173.06

Любые нижние блоки с `users.user_id`, Alembic `0002`, pre-read-switch или
legacy-authoritative ownership являются историческими cycle snapshots. Они не
могут переопределять current canon: `users.global_id` — physical owner, `tg_id`
— Telegram provider subject, один Alembic head — `0001_initial_release_schema.py`.

# Текущий статус v173.02 — цикл 1685

Цикл исправляет критическое повреждение v173.01 и продолжает
fix-forward переход referral/identity-resolution контура на
единственного business owner `global_id`.

GitHub CI v173.01 не завершился: pytest дошёл до 94%, показал три
реферальных падения, после чего PostgreSQL удерживал блокировки
`referral_links/users` до принудительной отмены job по лимиту времени.
Причина находилась в изменениях цикла 1684: чрезмерный test codemod
создал `provider_provider_tg_id`, рассинхронизировал provider fixtures,
оставил старые referral SQL/test contracts и допустил lock cascade.
GitHub infrastructure не является причиной сбоя.

В v173.02 повреждённые provider-имена и fixtures восстановлены, а
принудительный переход тестов контролируется семантическим AST-guard:
вызовов business services через `tg_id` — `0`. Telegram/provider,
physical schema и historical read-through употребления сохраняются
только как построчно зарегистрированные исключения.

Referral domain переведён по цепочке schema → ORM → CRUD → services →
routes → frontend → tests. `referral_links`, `referral_codes` и
`referral_bonus_ledger` используют обязательный `global_id` как owner;
Telegram-поля остаются nullable provider metadata без business FK,
unique или self-check. Concurrent Telegram `/start` сериализуется
advisory transaction lock до проверки и создания аккаунта.

Текущая матрица содержит `3349` identity token-употреблений. Из них
`1764` открыто либо требует symbol-level решения, `1585` разрешено или
сохранено. За цикл actionable/review-остаток сокращён на `117`.
Миграция не завершена.

```text
CURRENT_HEAD_V173_02
CI_FAILURES_CORRECTED_LOCALLY
CRITICAL_CI_TIMEOUT_CAUSE_REPAIRED_LOCALLY
REFERRALS_GLOBAL_OWNER_CUTOVER
REFERRAL_PHYSICAL_SCHEMA_GLOBAL_OWNER
SEMANTIC_TEST_GLOBAL_ID_CUTOVER
TEST_BUSINESS_SELECTOR_VIOLATIONS_ZERO
TG_ID_FINAL_MATRIX_UPDATED
BUSINESS_OWNER_TG_ID_NOT_ZERO
NEXT_CYCLE_1686
REMAINING_PLAN_CYCLES_5
EXACT_HEAD_CI_REQUIRED
```

---

# Утверждённый канон провайдеров — 2026-08-05

```text
Telegram → tg_id
TON      → ton_address
Google   → google_id
Apple    → apple_id
Facebook → fb_id
Discord  → discord_id
GitHub   → github_id
provider + subject → global_id
```

`global_id` — единственный business owner. Один `global_id` может иметь несколько provider identities. После identity resolution весь business runtime использует только `global_id`.

SSOT: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
Причинность: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
NORM: `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.
Следующий цикл: реализация канона в runtime, ORM, API, migration, tests и guards.

---

# Текущий статус v172.70 — исправление CI и продолжение циклов 1641–1646

Fresh CI run `30944313472`, commit `02667638d2b423fbc733a8e32a88b44996a3ba6e`, подтвердил зелёные Alembic, Flake8, Mypy, Bandit, compileall, PostgreSQL diagnostic и frontend build. Исправлены 2 Ruff errors и 2 pytest failures. Tasks read API переведён на canonical `global_id` signatures с централизованным legacy alias boundary. Полный inventory `tg_id` сохранён в `docs/history/legacy_artifacts/reports/generated/`.

```text
CURRENT_HEAD_V172_67
CI_FAILURES_CORRECTED_LOCALLY
TASKS_READ_OWNER_BATCH_IMPLEMENTED
TG_ID_GLOBAL_INVENTORY_GENERATED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.66 — безопасная пересборка global owner

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как доказательства и не переопределяют v172.66.

Fresh main CI run `30937377315` exact v172.65 подтвердил Alembic,
Flake8, compileall, PostgreSQL diagnostic и `npm ci`. Он выявил
механическое повреждение массового codemod:

- Ruff: 9 ошибок;
- Mypy: 22 ошибки;
- Bandit: 1 ошибка;
- frontend build: ошибки TypeScript;
- pytest: `181 failed, 3080 passed, 28 skipped`.


Обязательный процесс работы с пользовательскими CI-логами закреплён в
`docs/history/legacy_artifacts/docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md`. При наличии полного
архива логов запрещены бессмысленные дублирующие полные локальные CI,
pytest-shards и повторы уже зелёных этапов. Разрешены только проверки,
непосредственно связанные с подтверждёнными failures.

Корневая причина — слепая замена семантически разных provider-полей и
business-owner полей одинаковым именем `global_id`. Она создала
duplicate arguments, повреждённые SQL, DTO и frontend contracts.

В v172.66 выполнена controlled rebase пересборка:

- рабочее runtime-ядро циклов 1641–1646 восстановлено из v172.64;
- canonical бизнес-владелец остаётся `global_id`;
- временный `global_owner_alias.py` сохранён как единая граница;
- Telegram provider ingress и физические legacy-поля изолированы;
- compatibility baseline заморожен: он может только уменьшаться;
- новые runtime-файлы с `tg_id` запрещены machine guard;
- ошибки Ruff/Mypy/frontend из повреждённого codemod устранены возвратом
  корректных реализаций;
- Bandit `B101` устранён без `assert`;
- точечный набор всех 90 test-файлов, упавших в переданном CI,
  прошёл: `384 passed, 90 skipped`;
- test collection: `3358 tests`;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_66
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1646_RUNTIME_KERNEL_RESTORED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
TG_ID_COMPATIBILITY_BASELINE_FROZEN
TG_ID_COMPATIBILITY_MAY_ONLY_DECREASE
MECHANICAL_BIG_BANG_CODEMOD_REJECTED
USER_PROVIDED_CI_LOGS_REPAIR_CANON_LOCKED
EXACT_CI_FAILURE_SET_TARGETED_PASS
EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.65 — Global Owner Big-Bang Rewrite

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.65.

Выполнен глобальный аудит всех `tg_id` и массовый switch бизнес-runtime
на canonical `global_id` по методу первых identity-циклов.

- изменено 158 runtime-файлов;
- введён единый `global_owner_alias.py`;
- Telegram provider fact имеет каноническое имя `tg_id`;
- `User.tg_id` хранит только внешний Telegram ID и не является business owner;
- business runtime debt вне allowlist равен нулю;
- provider/schema/history/test употребления сохранены контролируемо;
- backend compileall завершён успешно;
- функциональные тесты, PostgreSQL и static CI намеренно отложены на
  следующую фазу;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_65
APPROVED_PLAN_1640_1665_LOCKED
GLOBAL_TG_ID_AUDIT_COMPLETE
BUSINESS_RUNTIME_BULK_REWRITE_COMPLETE
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
BUSINESS_RUNTIME_TG_ID_DEBT_ZERO_BY_BOUNDARY_GUARD
GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR
FUNCTIONAL_TEST_QUALIFICATION_NOT_STARTED
RUNTIME_NOT_QUALIFIED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.64 — циклы 1641–1646

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.64.

Fresh main CI run `30927024899` exact v172.63 подтвердил Alembic,
Ruff, Flake8, Bandit, compileall, PostgreSQL diagnostic и production
frontend build. Mypy нашёл одну nullable-selector ошибку. Pytest
завершился результатом `5 failed, 3251 passed, 28 skipped`.

В v172.64 локально исправлено:

- Exchange selector получил явное type narrowing для Mypy;
- cutover tests используют `efhc_core.alembic_version` и реальное
  shadow mismatch вместо записи в read-only telemetry view;
- nullable Tasks cursor имеет явный PostgreSQL `TEXT` cast;
- clean-schema contract приведён к фактическим 40 FK после `0002`;
- concurrency reset восстанавливает обязательный migration-control row;
- Alembic `0002` поддерживает offline SQL generation;
- проведён полный аудит legacy aliases;
- удалены четыре финансовых `*_by_tg_id` wrappers без runtime-callers;
- удалён мёртвый Payment Intent alias `STATUS_SENT`;
- provider-ingress и активные compatibility seams сохранены;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline и Admin UX не изменялись;
- production cutover не выполнялся.

```text
CURRENT_HEAD_V172_64
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1646_ALIAS_AUDIT_COMPLETE
CYCLE_1646_SAFE_ALIAS_REMOVAL_STARTED
CYCLE_1646_EXACT_HEAD_CI_REQUIRED
CYCLE_1647_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.63 — коррекция циклов 1641–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.63.

Fresh main CI run `30921046975` exact v172.62 подтвердил Flake8,
Mypy, compileall, PostgreSQL diagnostic и production frontend build.
Alembic остановился на schema guard: ожидалось 38 FK на
`users.global_id`, фактически после Achievements их стало 39. Ruff нашёл
четыре unused Referral imports, Bandit — четыре dynamic SQL boundary.
Pytest завершился результатом `32 failed, 3094 passed, 28 skipped` и
`130 errors`; основная часть errors была каскадом незавершённого Alembic.

В v172.63 локально исправлено:

- schema validator и architecture contract приведены к фактическим 39 FK;
- четыре unused Referral imports удалены;
- cutover, Admin backend и Exchange используют фиксированные SQL/ORM;
- post-cutover read control поддерживает полный режим `0001 -> 0002`;
- readiness признаёт обе поддерживаемые revisions: `0001` и `0002`;
- переходные compatibility seams сохранены до циклов 1646–1647;
- HTTP self-routes продолжают использовать canonical `global_id`;
- прямые legacy-вызовы тестов не публикуют `tg_id` в новых HTTP API;
- wallet gate и Withdraw используют canonical owner;
- line-72 и identity-boundary guards исправлены без роста legacy scope;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline не изменён;
- production cutover не выполнялся.

Локальная полная проверка текущего дерева:

- полный pytest: `3107 passed, 252 skipped`;
- architecture registry: `2507 passed, 6 skipped`;
- domain sweep циклов 1641–1645: `126 passed, 97 skipped`;
- test collection: `3348 tests`;
- backend compileall: `PASS`.

```text
CURRENT_HEAD_V172_63
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLES_1641_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.62 — циклы 1644–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.62.

Fresh main CI run `30869292077` exact v172.61 подтвердил Ruff, Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic `0001` и
production frontend build. Pytest завершился результатом
`21 failed, 3227 passed, 28 skipped`.

В v172.62 локально исправлено:

- nullable Referral idempotency parameter получил явный PostgreSQL cast;
- Tasks JSON expression приведён к единому JSONB contract;
- concurrency fixtures больше не сохраняют пустую строку `ton_wallet`;
- stale architecture baselines и запрещённый identifier alias устранены;
- cycle 1644 guards приведены к canonical Tasks/Ranks/Wallet ownership;
- текущие user routes, bot handlers и service callers используют
  canonical `global_id` после server-side identity resolution;
- `/sync/me`, Exchange, Panels, Tasks, Ranks, Withdrawals и Payment
  Intents больше не требуют Telegram ID как business owner;
- Payment Intent watcher принимает canonical token `G##########` и
  TON-only wallet binding;
- Achievements и referral codes подготовлены к обязательному `global_id`;
- добавлена Alembic revision `0002` для cutover preparation;
- добавлен изолированный операторский preflight/cutover/rollback service;
- migration `0002` не переключает production flags автоматически;
- public UI, Admin UX, screenshot workflow и canonical main CI не менялись.

```text
CURRENT_HEAD_V172_62
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1644_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1645_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1644_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.61 — циклы 1643–1644

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.61.

Fresh main CI run `30870996170` exact v172.60 подтвердил Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic и production
frontend build. Ruff остановился на одном SIM117. Pytest завершился
результатом `36 failed, 3210 passed, 28 skipped`.

В v172.61 локально исправлено:

- duplicate seed обязательного `identity_migration_control` заменён
  идемпотентным `ON CONFLICT DO NOTHING`;
- nullable Referral SQL parameter получил явный `BIGINT` cast;
- bank mirror отделён от пользовательского owner и больше не создаёт
  orphan provider mapping;
- Admin, Panel и Payment Intent fixtures приведены к реальному identity
  contract без ослабления production dual-write triggers;
- цикл 1644 переводит Tasks, ad rewards, Ranks, Leaderboard и Wallet reads
  на canonical `global_id`;
- TON-only account поддержан в task reward, wallet reads и rankings;
- Telegram join/proof/connect остаются provider-specific operations;
- ranks snapshot включает всех active owners и хранит nullable `tg_id`;
- visual, Admin UX, screenshot workflow, canonical main CI и production
  cutover flags не изменялись.

```text
CURRENT_HEAD_V172_61
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1643_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1644_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1643_1644_EXACT_HEAD_CI_REQUIRED
CYCLE_1645_NOT_STARTED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.60 — циклы 1641–1643

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.60.

Fresh main CI run `30864230797` exact v172.59 подтвердил Alembic,
PostgreSQL diagnostic, compileall, Flake8 и production frontend build. Он
выявил четыре реальные группы ошибок: отсутствие обязательного singleton
после test-TRUNCATE, static/type/security нарушения, потерянный повторный
idempotency read-through и legacy referral fixtures без shadow global_id.

В v172.60 локально исправлено:

- test infrastructure восстанавливает обязательный
  `identity_migration_control` после очистки схемы;
- production resolver не ослаблен и не создаёт control row автоматически;
- Ruff, Mypy, Bandit и русскоязычные engineering-policy причины устранены;
- post-lock idempotency read-through возвращён в transaction entrypoints;
- цикл 1643 переводит referral reward ownership на canonical `global_id`;
- исторические referral rows читаются по `tg_id` только при
  `global_id IS NULL`;
- `REF_ACT_UNIT`, `REF_LVL` и exchange keys получили canonical
  `G##########` форму с compatibility read-through старых ключей;
- до cutover новые операции сохраняют legacy key при
  `legacy_authoritative=TRUE`, после cutover выбирают canonical key;
- visual, Admin, screenshot workflow, canonical main CI и production flags
  не изменялись.

```text
CURRENT_HEAD_V172_60
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1641_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1642_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1643_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1643_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.59 — циклы 1641–1642

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.59.

По прямой команде пользователя работа продолжена без screenshot-контура.
Frontend, Admin и screenshot workflow не изменялись. Изменения ограничены
каноническим финансовым владельцем и доменными сервисами.

Выполнено локально:

- денежные entrypoints принимают `global_id` или временный `tg_id`;
- каждая операция нормализуется до canonical `global_id`;
- ledger dual-write сохраняет `global_id` и nullable provider `tg_id`;
- idempotency read-through един для обоих selector;
- TON-only account поддержан в транзакциях без Telegram ID;
- Panels переведены на canonical owner;
- Withdraw request, hold, cancel и refund используют `global_id`;
- новые Payment Intents создаются по canonical owner;
- payload поддерживает legacy Telegram token и `G##########`;
- provider-колонки финансовых таблиц подготовлены как nullable;
- migration-control и production cutover flags не переключались.

Открытые границы:

- watcher ещё должен получить canonical payload owner в цикле callers;
- referral idempotency нормализуется отдельно;
- legacy aliases удаляются только в утверждённых cleanup-циклах;
- PostgreSQL, полный pytest и static gates требует exact-head CI.

```text
CURRENT_HEAD_V172_59
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.58 — цикл 1640 visual corrective

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.58.

Пользователь полностью утвердил план циклов 1640–1665 и потребовал немедленно
удалить неутверждённый декоративный слой v172.51. v172.58 является
селективным visual rollback поверх v172.57: backend/global_id foundation не
откатывается.

Выполнено:

- `EFHC_Bot_v172_50.zip` закреплён как public visual baseline;
- удалены premium dock, halo, многослойные тени, active lift и separators;
- восстановлен простой `KwhIcon`;
- удалён Energy marker поверх progress bar;
- восстановлена исходная profile topbar;
- полностью удалён поздний 336-строчный CSS override layer;
- сохранены `navigateBackWithinApp()`, profile sections, safe-area и QA attrs;
- добавлен architecture guard против возврата отклонённых tokens;
- утверждённый план записан в
  `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_1640_1665_APPROVED_PLAN.md`.
- рабочий screenshot workflow run `30855423325` закреплён без переписывания.

Не изменялись schema, migrations, financial formulas, global_id write-side
foundation, canonical main CI и production cutover flags.

```text
CURRENT_HEAD_V172_58
APPROVED_PLAN_1640_1665_LOCKED
PUBLIC_VISUAL_BASELINE_V172_50_LOCKED
V172_51_DECORATIVE_LAYER_REMOVED
CYCLE_1639_SCREENSHOT_CAPTURE_PASS_102_OF_102_EXACT_V172_56
CYCLE_1639_VISUAL_ACCEPTANCE_FAILED_AND_CORRECTED_LOCALLY
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.57 — цикл 1640

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены только как evidence и не переопределяют v172.57.

Директива пользователя изменила порядок работы: visual screenshots остаются
отдельной незакрытой evidence-задачей, но больше не блокируют развитие
`global_id` business ownership.

Подтверждено для базового exact v172.56:

- main GitHub CI PASS;
- PostgreSQL 16 и canonical Alembic `0001` PASS;
- pytest: `3220 passed`, `28 skipped`;
- Flake8, Ruff, Mypy, Bandit, compileall и frontend build PASS.

В v172.57 реализован фундамент цикла 1640:

- новый `resolve_and_lock_financial_write_owner()`;
- ровно один selector: `global_id` или `tg_id`;
- результат всегда нормализуется до canonical `global_id`;
- строка `users` блокируется через `FOR UPDATE`;
- write path требует `dual_write_enabled`;
- TON-only owner разрешён без `legacy_tg_id`;
- read/write используют единый loader migration control;
- завершён audit idempotency ownership;
- выявлены три Telegram-coupled key path для исправления в циклах 1641/1643.

Application services массово ещё не переключены. Schema/migration/finance
semantics в v172.57 не изменялись.

```text
CURRENT_HEAD_V172_57
CYCLE_1639_EXACT_HEAD_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_IDEMPOTENCY_AUDIT_COMPLETE
CYCLE_1640_LOCAL_TESTS_PASS
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
CYCLE_1642_NOT_STARTED
CYCLE_1643_NOT_STARTED
CYCLE_1644_NOT_STARTED
CYCLE_1645_NOT_STARTED
CYCLE_1646_NOT_STARTED
CYCLE_1647_NOT_STARTED
CYCLE_1648_NOT_STARTED
CYCLE_1649_NOT_STARTED
CYCLE_1650_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.56 — цикл 1639 corrective

Fresh GitHub CI `83583696254` проверил exact `v172.55`:

- размер: `12670026` байт;
- SHA-256: `cb90140a7aab41f3e9cd7210a517ab032c056db80b7dafecd0ccbe5afbe774f1`;
- PostgreSQL, Alembic `0001`, Flake8, Ruff, Mypy, Bandit, compileall и
  production frontend build: PASS;
- pytest: `3219 passed`, `28 skipped`, один PostgreSQL failure;
- Chromium: корректно пропущен после обязательного pytest failure;
- CI artifacts успешно загружены; fresh PNG отсутствуют.

Единственный failure находился в qualification fixture
`test_межпровайдерный_cycle_не_создаётся_late_binding`: fixture назначал
TON-first пользователю `tg_id` и в той же транзакции добавлял
`ReferralCode`, но не задавал явную точку flush. Поскольку ORM relationship
между этими операциями отсутствует, SQLAlchemy мог отправить INSERT кода до
UPDATE `users.tg_id`, и строгий PostgreSQL FK корректно отклонял запись.

`v172.56` исправляет только порядок qualification fixture:

- после назначения `b_user.tg_id` выполняется `await session.flush()`;
- затем вставляется `ReferralCode`;
- существующий FK `referral_codes_inviter_tg_id_fkey` не ослабляется;
- production registration code, ORM models, migration `0001`, referral
  attribution, locks, sessions, financial logic и public UI не меняются;
- цикл `1640` не начат.

```text
CURRENT_HEAD_V172_56
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_RUNTIME_QUALIFIED
CYCLE_1638_REFERRAL_TRANSPORT_RUNTIME_QUALIFIED
CYCLE_1639_ALL_PROVIDER_CALLERS_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
---
# Актуальный kernel status — v172.39 corrective

Fresh CI `83288192546` прошёл все gates, кроме одного pytest contract
архивной гигиены. Причина — повреждение 28 русских имён при цепочке
Info-ZIP → Python extraction → повторная упаковка. v172.39 является
только corrective package цикла `1630`; physical rename не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Universal CI неизменяем. Alembic head `0012`; migration `0013`
отсутствует. Следующий gate — полный exact-head CI v172.39.

---

# Актуальный kernel status — v172.38 corrective

Fresh CI `83283286008` проверил exact v172.37. Все database,
static, security и build gates прошли, но pytest и общий Chromium
gate остались красными. v172.38 является только corrective package
цикла `1630`; physical rename не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Universal CI неизменяем. Alembic head `0012`; migration `0013`
отсутствует. Следующий gate — полный exact-head CI v172.38.

---

# Актуальный kernel status — v172.37 corrective

Fresh CI `83263164491` квалифицировал exact v172.36 по всем gates,
кроме общего route-backed Chromium audit. Единственный finding:
`51` admin marker failures (`17 × 3`), при HTTP `200` и нулевых
page/console errors. Исправлен порядок Telegram identity bootstrap в
`frontend/src/pages/_app.tsx`; universal CI, migrations и financial
runtime не изменены.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Primary Operator Kernel route остаётся `ci_log_exact_failure_repair`.
Alembic head `0012`; `0013` отсутствует.

---

# Актуальный kernel status — v172.36 corrective

```text
CYCLE_1630_CROSS_PROVIDER_SESSION_CHROMIUM_PROOF_PASS
CYCLE_1630_ROUTE_BACKED_VISUAL_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83255023989` на exact v172.35 подтвердил PostgreSQL,
Alembic `0012`, static/type/security gates, frontend build и отдельный
Telegram/TON cross-provider Chromium proof. Общий route-backed browser
gate выявил CSP/status/admin-build findings; pytest выявил stale
historical current-CI assertions. Corrective v172.36 исправляет только
эти доказанные findings. Primary route остаётся
`cross_provider_e2e_fallback_closure`; `0013` отсутствует.

---

# Актуальный kernel status — v172.35 corrective

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83240274364` на exact v172.34 выполнил real PostgreSQL и
real Chromium, но Chromium audit завершился `exit=1`. Corrective v172.35
исправляет только доказанные tests/lint findings, ожидание auth request,
browser failure diagnostics и canonical CI embedding. Alembic head —
`0012`; `0013` отсутствует. Primary route остаётся
`cross_provider_e2e_fallback_closure`.

---

# Актуальный kernel status — v172.34 corrective

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83236222987` не дал exit gate цикла `1630`: corrected
cross-provider API test не дошёл до assertion из-за test DB dependency,
а Chromium E2E был пропущен. В `v172.34` harness исправлен, visual proof
встроен в существующий route-backed Chromium audit без изменения
workflow. Current Alembic head — `0012`; migration `0013` отсутствует.
Primary route остаётся `cross_provider_e2e_fallback_closure`.

---

# Актуальный kernel status — v172.33

```text
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_EXACT_HEAD_PASS
CYCLE_1629_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1630_CROSS_PROVIDER_E2E_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83193385549` на exact v172.32 не выявил critical blocker.
Simple pytest/Mypy/TypeScript findings исправлены. Цикл `1630` закрывает
business-auth fallback на raw Telegram `initData`, сохраняет explicit
Telegram session exchange и проверяет Telegram/TON sessions одного
`global_id` через PostgreSQL/API/Chromium contracts. Alembic head
`0012`; `0013` отсутствует. Primary Operator Kernel route:
`cross_provider_e2e_fallback_closure`. Current development HEAD:
`EFHC_Bot_v172_33.zip`.

---

# Актуальный kernel status — v172.32

```text
CYCLE_1628_EXTENDED_DOMAIN_OWNER_EXACT_HEAD_PASS
CYCLE_1628_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_PACKAGE_READY
CYCLE_1629_EXACT_HEAD_CI_REQUIRED
CYCLE_1630_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83181651259` на exact v172.31 применил real PostgreSQL `0012`.
Fail-closed `owner conflict` был ожидаемым negative contract, но старый
harness ловил неверный класс исключения. Cleanup двух payment tests
удалял canonical migration control. Эти и остальные локальные findings
исправлены без изменения production semantics. Alembic head остаётся
`0012`; `0013` отсутствует. Cycle `1629` делает server-side Bearer
session primary transport для common/admin API, сохраняет измеряемый
legacy fallback и переводит frontend owner cache на `GlobalId`.
Primary Operator Kernel route: `session_first_full_switch`.
Current canonical development HEAD: `EFHC_Bot_v172_32.zip`.

---

# Актуальный kernel status — v172.31

```text
CYCLE_1627_FINANCIAL_READ_SWITCH_EXACT_HEAD_PASS
CYCLE_1627_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1628_PACKAGE_READY
CYCLE_1628_EXACT_HEAD_CI_REQUIRED
CYCLE_1629_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83164293703` на exact v172.30 доказал real PostgreSQL `0011`,
financial global reads, rollback, legacy-authoritative dual-write, zero
telemetry и точное `0.00000000`. Остались только simple test/lint
findings, исправленные в v172.31. Alembic code head теперь `0012`, parent
`0011`; migration ограничена Shop/NFT/cosmetics schema gaps. Primary
Operator Kernel route: `extended_domain_owner_migration`. Current
canonical development HEAD: `EFHC_Bot_v172_31.zip`.

---

# Актуальный kernel status — v172.30

```text
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_EXACT_HEAD_PASS
CYCLE_1627_FINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1627_EXACT_HEAD_CI_REQUIRED
CYCLE_1628_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83151379137` квалифицировал real PostgreSQL financial shadow
validation цикла `1626`; единственный failure был release marker.
Alembic code head теперь `0011`, parent `0010`. `0011` включает только
financial owner read switch после нулевой telemetry и точного денежного
равенства. Legacy writes и dual-write остаются активными. Primary route:
`financial_read_switch`. Current canonical development HEAD:
`EFHC_Bot_v172_30.zip`.

---

# Актуальный kernel status — v172.29

```text
CYCLE_1625_POSTGRESQL_0010_PASS
CYCLE_1626_CI_FINDINGS_CORRECTED_IN_V172_29
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_REQUALIFICATION_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83144620488` подтвердил real PostgreSQL `0010`, но не
квалифицировал financial shadow validation: integration fixture упал до
вызова reconciliation gate из-за отсутствующих обязательных timestamps.
Corrective package не начинает `1627`. Alembic head остаётся `0010`;
`0011` отсутствует. Primary route: `ci_log_exact_failure_repair`.
Current canonical development HEAD: `EFHC_Bot_v172_29.zip`.

---

# Актуальный kernel status — v172.28

```text
CYCLE_1625_POSTGRESQL_0010_PASS_CI_FINDINGS_CORRECTED
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_PACKAGE_READY
CYCLE_1626_EXACT_HEAD_CI_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83121417737` доказал real PostgreSQL `0010`.
Alembic code head остаётся `0010`; `0011` отсутствует.
Cycle `1626` — только financial shadow validation: read-only telemetry,
точное денежное сравнение, precision/idempotency proof. Financial read
switch `1627` запрещён до fresh exact-HEAD qualification.

Primary route: `financial_shadow_validation`.
Current canonical development HEAD: `EFHC_Bot_v172_28.zip`.

---

# Актуальный kernel status — v172.27

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83098311619` доказал real PostgreSQL `0009`.
Alembic code head теперь `0010`, parent `0009`.
`0010` включает только управляемый non-financial read switch.
Legacy writes и dual-write остаются активными. Financial read switch
запрещён до циклов `1626–1627`.

---

# ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER

Current canonical development HEAD: `EFHC_Bot_v172_26.zip`.
Route-backed dispatch использует canonical anchors из Operator Kernel.
Development и release контуры разделены.

# Актуальный kernel status — v172.26

```text
CYCLE_1624_CRITICAL_POSTGRESQL_0009_BLOCKER_CONFIRMED
CYCLE_1624_CORRECTIVE_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Primary route: `ci_log_exact_failure_repair`.
Fresh CI input: run `83093436890` на exact `v172.25`.
Alembic code head: `0009`, parent `0008`.
Legacy ownership authoritative; read switch отсутствует.

---

# Актуальный статус — corrective cycle 1619, v172.19

```text
CYCLE_1619_CRITICAL_CI_BLOCKER_CONFIRMED
CORRECTIVE_PACKAGE_READY
CYCLE_1620_NOT_STARTED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82961004593` выполнен на exact input HEAD
`EFHC_Bot_v172_18.zip` размером `11933560` байт. PostgreSQL profile,
PSQL preflight, Alembic upgrade до `0005`, flake8, Ruff, Bandit,
compileall, `npm ci` и frontend production build прошли. Mypy выявил
одну потерю типа в `TelegramInitDataAdapter.verify_subject`, а pytest —
три локальных нарушения identity/language guards. Поскольку Mypy finding
находится на authentication boundary, переход к циклу `1620` запрещён.

`v172.19` является corrective-only package. Исправлены только exact CI
findings: fail-closed строковое сужение provider subject, error codes с
каноническим `TG_ID`, self-trigger static guard и русское значение в
machine registry. Telegram HMAC, replay/session semantics, PostgreSQL,
Alembic, frontend и финансовая логика не изменялись. Migration `0006`
отсутствует. Цикл `1620` не начат.
---

# Актуальный статус — цикл 1618, v172.17

```text
CYCLE_1617_POSTGRESQL_ALEMBIC_MYPY_BANDIT_FRONTEND_PASS_ON_V172_16
CYCLE_1617_CONFIRMED_CI_ERRORS_FIXED_IN_V172_17
CYCLE_1618_TON_AUTH_SESSION_LOGOUT_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1619_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82943922606` выполнен на exact HEAD
`EFHC_Bot_v172_16.zip`. PostgreSQL preflight, Alembic upgrade до
`0005`, Mypy, Bandit, compileall, flake8 и frontend build прошли.
В `v172.17` исправляются только подтверждённые причины общего red gate:
один Ruff `I001` и одиннадцать устаревших identity/architecture tests.

Цикл `1618` добавляет атомарную выдачу hashed server-side session после
успешного TON Proof, `GET /api/auth/session`, `POST /api/auth/logout` и
изолированный frontend bearer transport через `sessionStorage`. Raw token
возвращается один раз и не хранится в PostgreSQL. `global_id` остаётся
строкой из десяти ASCII-цифр на внешней границе. Migration `0006` не
создаётся; Alembic head остаётся `0005`. Telegram adapter цикла `1619` не
начат.

---

# Актуальный статус — цикл 1617, v172.16

```text
CYCLE_1616_CONFIRMED_CI_ERRORS_FIXED_IN_V172_16
CYCLE_1617_TON_ACCOUNT_REGISTRATION_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1618_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Run `82923200235` выполнен на exact HEAD `EFHC_Bot_v172_15.zip`.
PostgreSQL preflight, Alembic upgrade до `0004`, Bandit, compileall,
flake8 и frontend build прошли. Исправлены только подтверждённые CI
ошибки: три Ruff `I001`, две Mypy boundary errors и десять pytest failures.

Цикл `1617` добавляет ограниченную EXPAND migration `0005`, nullable
`users.tg_id`, `wallet_bindings.global_id` и transactional TON account
registration. Один wallet может принадлежать только одному `global_id`.
Новый TON-only account создаётся без фиктивного `tg_id`; session не
выдаётся. Цикл `1618` не начат.

# Актуальный статус — цикл 1616, v172.15

```text
CYCLE_1615_RUNTIME_STATIC_POSTGRESQL_FRONTEND_PASS_ON_V172_14
CYCLE_1615_EIGHT_CONFIRMED_CI_ERRORS_FIXED_IN_V172_15
CYCLE_1616_TON_PROOF_VERIFICATION_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1617_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82909483300` выполнен на exact HEAD
`EFHC_Bot_v172_14.zip`. PostgreSQL preflight, Alembic upgrade до
`0004`, Bandit, compileall, flake8 и frontend build прошли. CI
подтвердил три Ruff findings, одну Mypy error и четыре architecture
failures. В `v172.15` исправлены только эти восемь причин.

Цикл `1616` добавляет provider-neutral `POST /api/auth/ton/proof` и
fail-closed проверку TON Connect v2 proof: domain, timestamp, network,
state-init, authoritative public key, Ed25519 signature, challenge TTL
и atomic replay protection по exact challenge ID. Proof verification
не создаёт account, identity или session и не зависит от Telegram.
Alembic head остаётся `0004`; migration `0005` отсутствует.

Похожие tests объединены параметризацией и общими cryptographic
fixtures без удаления отдельных failure vectors. Локально проверяется
только изменённый scope с жёстким timeout. Реальный PostgreSQL, полный
pytest, frontend build и итоговый integration run выполняет
существующий канонический GitHub CI. CI workflow не изменяется.

---

# Актуальный статус — цикл 1615, v172.14

```text
CYCLE_1614_POSTGRESQL_STATIC_FRONTEND_PASS_ON_V172_13
CYCLE_1614_FOUR_ARCHITECTURE_CORRECTIONS_INCLUDED
CYCLE_1615_TON_CHALLENGE_AND_ADDRESS_FOUNDATION_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1616_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82897904509` выполнен на exact HEAD
`EFHC_Bot_v172_13.zip`. PostgreSQL preflight, Alembic upgrade до `0004`,
Ruff, Mypy, Bandit, compileall, flake8 и frontend build прошли. Pytest:
`2974 passed`, `20 skipped`, `4 failed`, `1 warning`. Четыре ошибки относятся
только к retention-version reports, русскоязычным machine keys и устаревшему
roadmap marker; runtime, migration, PostgreSQL и financial defects не выявлены.

`v172.14` исправляет только эти четыре подтверждённые причины и реализует
цикл `1615`: отдельный `POST /api/auth/ton/challenge` без Telegram context,
hashed one-time challenge через `auth_challenges`, строгий canonical TON
address resolver и единый address parser для будущего TON Proof. Endpoint не
создаёт account, identity или session и не проверяет подпись — cryptographic
verification остаётся циклом `1616`. Alembic head остаётся `0004`; migration
`0005` отсутствует. Полный regression, PostgreSQL и frontend build выполняет
канонический GitHub CI.

---

# Актуальный статус — цикл 1614, v172.13

```text
CYCLE_1613_REAL_POSTGRESQL_ALEMBIC_0004_EXECUTED
CYCLE_1614_INTEGRATION_CLOSURE_PACKAGE_READY
EXACT_HEAD_CI_REQUIRED
CYCLE_1615_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82888503300` выполнен на exact HEAD
`EFHC_Bot_v172_12.zip`. PostgreSQL preflight, Alembic upgrade до `0004`,
Mypy, compileall, flake8 и frontend build прошли. Исправлены только
подтверждённые ошибки: три Ruff `I001`, два Bandit `B105`, шесть
architecture/document contracts и два PostgreSQL integration tests.

Текущий source HEAD: `EFHC_Bot_v172_13.zip`. Цикл `1614` закрывает
только auth-core PostgreSQL evidence: migration `0004`, concurrency,
logout и roles. Alembic head остаётся `0004`; migration `0005`, TON Proof,
public auth endpoints, Telegram switch, ownership и financial changes
отсутствуют. Полный regression и реальный PostgreSQL выполняет только
канонический GitHub CI. Цикл `1615` до fresh exact-HEAD PASS не начинается.

---

# Актуальный статус — цикл 1613, v172.12

```text
CYCLE_1612_FUNCTIONAL_POSTGRESQL_STATIC_GATES_PASS
CYCLE_1612_HANDOFF_MARKER_FIX_INCLUDED
CYCLE_1613_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## Операционный канон реализации циклов

Главная цель — последовательная реализация roadmap, а не повторный аудит неизменённого кода. Обязательная последовательность:

```text
реализация текущего цикла → локальная проверка изменённого scope → архивы → канонический CI GitHub → точечное исправление подтверждённых ошибок → закрытие цикла → следующий цикл
```

Правила исполнения:

1. Перед каждой проверкой фиксируется причинный scope по списку новых и изменённых файлов.
2. Проверяются только новые/изменённые файлы и непосредственно зависящие от них контракты и tests.
3. PASS не повторяется, пока не изменился связанный файл или его зависимость.
4. Повторный запуск разрешён только из-за изменения связанного файла/зависимости, конкретной ошибки CI, доказанного противоречия либо финальной проверки нового архива.
5. Общий аудит, соседние подсистемы и полный импорт приложения без конкретного дефекта запрещены. Enum, модели, константы и отдельные contracts проверяются AST/текстовым анализом или узкими tests.
6. Каждая команда имеет жёсткий timeout. Зависший процесс немедленно останавливается и заменяется статическим анализом или узкой проверкой.
7. PostgreSQL, полный pytest, frontend build, Chromium E2E и итоговая интеграция выполняются существующим каноническим CI GitHub. CI workflow без прямой команды не меняется.
8. Ведётся machine-readable реестр: `CHECK_ID`, exact HEAD, scope, result, связанные файлы, причина запуска и допустимое условие повторения.
9. Формулировки «для уверенности», «ещё раз проверю» и «проверю соседние контракты» не являются основанием для запуска.
10. Следующий цикл не начинается до реализации, упаковки и необходимого CI-подтверждения текущего цикла.

Для цикла `1613` scope ограничен migration `0004`, новыми auth-моделями, services, dependencies и непосредственно связанными tests. `AuthProvider`, migration `0003` и неизменённые identity-контракты после подтверждённого PASS повторно не проверяются без нового факта.


Канонический source HEAD: `EFHC_Bot_v172_12.zip`.

GitHub CI run `82865834601` выполнен на exact HEAD
`EFHC_Bot_v172_11.zip` размером `11 666 314` байт. PostgreSQL preflight,
Alembic `0001 → 0002 → 0003`, Ruff, Mypy, Bandit, compileall, flake8 и
frontend build прошли. Pytest: `2942 passed`, `20 skipped`, `1 failed`,
`1 warning`. Единственная ошибка — в `CONTINUE_IN_NEW_CHAT.md` отсутствовал
обязательный marker `EFHC_Bot_v172_11_RELEASE.zip`; code, migration,
PostgreSQL и financial defects не выявлены. Исправление включено в `v172.12`.

Цикл `1613` добавляет только provider-neutral auth-core foundation:
`auth_challenges`, `auth_sessions`, `user_roles`, migration `0004`,
транзакционные services и FastAPI dependencies. Challenge и session token
хранятся только как namespaced SHA-256 hashes; challenge потребляется
атомарно один раз; роли принадлежат только `global_id`; malformed/inactive
session завершается `401`, отсутствие роли — `403`.

Запрещены и отсутствуют: account/identity creation, public login endpoint,
TON Proof, Telegram login switch, auto-merge, backfill, read switch,
ownership switch и любые financial changes. Alembic code head: `0004`.
Цикл `1614` не начат. Полный regression и реальный PostgreSQL выполняются
пользователем только через существующий GitHub CI.

---

# Цикл 1612 — transactional IdentityResolver, v172.11

```text
CYCLE_1611_EXACT_HEAD_PASS
CYCLE_1612_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Канонический GitHub CI run `82850316409` выполнен на exact HEAD
`EFHC_Bot_v172_10.zip`: все gates PASS, pytest — `2918 passed`,
`20 skipped`, `0 failed`, `0 errors`, `1 warning`. Цикл `1611`
закрыт.

В цикле `1612` реализован `PostgreSQLIdentityResolver`: вход только
`VerifiedIdentity`, transaction-scoped `pg_advisory_xact_lock` для
lookup-key, `SELECT FOR UPDATE` для существующей строки и fail-closed
outcomes `resolved/not_found/conflict`. Resolver не создаёт account,
identity, session или role, не выполняет auto-merge и не меняет
финансовые данные. Alembic head остаётся `0003`; migration `0004`
отсутствует.

Локально выполняются только короткие причинные проверки. Реальный
PostgreSQL, полный regression, Docker и Chromium выполняет пользователь
через существующий канонический GitHub CI. До fresh exact-HEAD PASS на
`v172.11` цикл `1613` не начинается.

Следующий цикл: `1613`, только после закрытия `1612`.

---

# Актуализация цикла 1611 после CI run 82837535263 — v172.10

```text
V172_10_CI_CORRECTION_PACKAGE_READY
V172_09_REAL_POSTGRESQL_AND_STATIC_EVIDENCE_RECORDED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Run `82837535263` выполнен на development archive `v172.09` размером
`11 566 965` байт. PostgreSQL preflight, Alembic `0001 → 0002 → 0003`,
Mypy, Bandit, compileall, flake8, frontend `npm ci` и production build
прошли. Gate остановили один Ruff `I001` и двенадцать архитектурных tests,
связанных только с active documentation, version-budget contracts и
русскоязычными machine reports.

`v172.10` исправляет эти причины поверх чистого `v172.09`. Migration `0003`,
`user_identities` constraints, CI workflow и financial/domain owner files не
изменяются. Полный regression локально не выполняется; требуется fresh
exact-HEAD CI GitHub на `EFHC_Bot_v172_10.zip`.

Цикл `1612` не начинается до полного PASS. Активный roadmap заканчивается
циклом `1633`; migration squash выполняется только в цикле `1632` с gate
`PRE_RELEASE_MIGRATION_SQUASH_PASS`.

---

# Цикл 1611 — корректирующий exact-HEAD пакет v172.09

Статус:

```text
V172_09_STATIC_CI_FIX_PACKAGE_READY
V172_08_REAL_POSTGRESQL_EVIDENCE_RECORDED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Исходный development HEAD: `EFHC_Bot_v172_08.zip`.
Исправленный development HEAD: `EFHC_Bot_v172_09.zip`.
Релизный кандидат: `EFHC_Bot_v172_09_RELEASE.zip`.
Технический архив: `EFHC_Bot_v172_09_MATRIX_TECHNICAL.zip`.

Канонический GitHub CI run `82789912844` доказал на точном `v172.08`:
реальный PostgreSQL, `PG-0` preflight, Alembic upgrade `0001 → 0002 → 0003`,
`compileall`, flake8, полный pytest (`2918 passed`, `20 skipped`, `0 failed`,
`0 errors`), `npm ci` и frontend build. Expected PostgreSQL errors из negative
constraint tests являются доказательством fail-closed constraints, а не падением.
Общий gate остановили только Ruff, Mypy и Bandit.

В `v172.09` причинно исправлены все `50` findings Ruff, две ошибки Mypy и два
ложных `B105` Bandit. Migration `0003`, ORM/storage semantics
`user_identities`, финансовые и доменные owner-файлы не изменены. Пять
небезопасных Ruff `UP042` не применялись: историческая `str, Enum` семантика
сохранена и подавлена только точечными `# noqa: UP042`.

Run `82791721379` классифицирован как `WRONG_INPUT_ARCHIVE_PROFILE`: в
канонический development CI ошибочно передан `_RELEASE.zip`. Отсутствие
`requirements-test.txt` в release archive является нормой. Release purity не
ослабляется; tests, test dependencies и CI evidence в release не добавляются.

Exact-HEAD CI на `v172.09` ещё не выполнялся. До fresh PASS цикл `1611` не
закрыт, а цикл `1612` запрещено начинать. Канонические CI workflow не
изменялись.

Локально разрешены только короткие причинные проверки изменённой области.
Полный regression, PostgreSQL, Docker и Chromium в среде чата не запускаются;
зависшая или неподдерживаемая проверка прекращается со статусом `NOT RUN` либо
`BLOCKED_BY_ENVIRONMENT`. Полные tests выполняет пользователь через
существующий GitHub CI.

Активный roadmap заканчивается циклом `1633`. Цикл `1632` зарезервирован только
для schema freeze и pre-release migration squash в единый
`0001_initial_release_schema.py`; exit gate —
`PRE_RELEASE_MIGRATION_SQUASH_PASS`. Финальная exact-HEAD release qualification
перенесена в цикл `1633`.

Следующее действие: запустить существующий канонический GitHub CI только на
`EFHC_Bot_v172_09.zip`. `_RELEASE.zip` в development CI не передавать.

---

# Цикл 1611 — user_identities schema и PostgreSQL test package

Статус: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_08.zip`.
Релизный кандидат: `EFHC_Bot_v172_08_RELEASE.zip`.
Технический архив: `EFHC_Bot_v172_08_MATRIX_TECHNICAL.zip`.

Подготовлен provider-neutral storage foundation для внешних identities:
ORM-модель `UserIdentity`, канонический storage-contract, Alembic
revision `0003`, read-only `PG-0` preflight и PostgreSQL integration
package. Таблица `efhc_core.user_identities` связывает проверенный
`(provider, provider_tenant, provider_subject)` ровно с одним
логическим `global_id`; физический FK переходного этапа направлен на
`efhc_core.users.user_id`.

Migration `0003` является только `EXPAND`: она не выполняет backfill,
не изменяет `users` и финансовые таблицы, не создаёт аккаунты или
sessions, не включает runtime resolver и не переключает ownership.
Duplicate provider subject, недопустимый provider, `mock` в production,
несогласованные verification timestamps и более одной primary identity
на один account блокируются constraints.

По прямому указанию пользователя PostgreSQL в среде чата не
устанавливался и не запускался. Канонические GitHub CI workflows не
создавались и не изменялись. Поэтому реальный `PG-0 PASS`, применение
migration на PostgreSQL и PostgreSQL constraint/concurrency proof не
заявляются. Цикл 1612 остаётся заблокированным до контролируемого запуска
существующего CI GitHub и получения `PG-0 PASS`.

# Цикл 1611 — migration user_identities и PostgreSQL test package

Статус: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_08.zip`.
Релизный кандидат: `EFHC_Bot_v172_08_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_08_MATRIX_TECHNICAL.zip`.

Подготовлена линейная Alembic revision `0003`, ORM-модель
`UserIdentity`, точный storage contract, fail-closed constraints,
read-only PG-0 preflight и PostgreSQL integration tests. Таблица
`efhc_core.user_identities` связывает проверенный provider subject с
исторической удалённой колонкой `users.user_id`; текущий owner — `users.global_id`, которая представляет
канонический `global_id` до physical rename цикла 1631.

Миграция является только `EXPAND`: не выполняет backfill, не изменяет
`users`, финансовые таблицы, balances, kWh или ownership, не создаёт
account/session и не подключает runtime `IdentityResolver`. Duplicate
provider/tenant/subject, неизвестный `global_id`, production `mock`,
некорректный verification state и более одной primary identity на
account закрываются PostgreSQL constraints.

PostgreSQL в среде чата не устанавливался и не запускался. Канонические
CI workflow не создавались и не изменялись; их исходные SHA-256
зафиксированы contract guard. Реальный PG-0, upgrade/downgrade и
constraint tests подготовлены, но не исполнены. До их контролируемого
запуска нельзя заявлять `PG-0 PASS` или начинать runtime resolver цикла
1612.

Следующее действие: `Необходимо запустить канонический CI GitHub`.
До подтверждённого PostgreSQL PASS цикл 1612 заблокирован.

# Цикл 1610 — AuthContext contracts и resolver interfaces

Статус: `LOCAL_AUTH_CONTEXT_CONTRACTS_READY / PG-0_REQUIRED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_07.zip`.
Релизный кандидат: `EFHC_Bot_v172_07_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_07_MATRIX_TECHNICAL.zip`.

Создан provider-neutral контракт `AuthContext`, который формируется
только из nominal `GlobalId` и `VerifiedIdentity`. Внутренний контекст
не содержит `tg_id`, wallet address, raw proof, token или initData.
Безопасный endpoint response содержит только `global_id`, `provider` и
детерминированный набор `roles`; provider subject и session reference
во внешний контракт не попадают.

Добавлены fail-closed interfaces будущего `IdentityResolver` со
статусами `resolved`, `not_found` и `conflict`. Они не выполняют lookup
в БД, не создают account/session, не присваивают `global_id` и не
поддерживают auto-merge. Security/redaction skeleton рекурсивно скрывает
provider subject, session reference, proof, tokens, initData, nonce и
другие credentials в diagnostics и общем logging filter.

Operator Kernel получил exact primary route цикла 1610. Legacy
`backend/app/deps.py::AuthContext(tg_id, is_admin)` и действующие routes
намеренно не переключались. Alembic head остаётся `0002`; PostgreSQL
DDL/data, backfill, ownership и экономика не изменялись. Следующий цикл:
`1611 — реальный PG-0 и migration user_identities`. После цикла 1610
остаётся `22` обязательных цикла `1611–1632`. GitHub CI пока не запускать.

# Цикл 1609 — AuthProvider и provider registry foundation

Статус: `LOCAL_PROVIDER_REGISTRY_READY / PG-0_REQUIRED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_06.zip`.
Релизный кандидат: `EFHC_Bot_v172_06_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_06_MATRIX_TECHNICAL.zip`.

Создан provider-neutral фундамент авторизации: строгий `AuthProvider`,
закрытый результат `VerifiedIdentity`, fail-closed provider registry,
раздельные runtime/test feature flags, стабильные machine error codes и
test-only mock adapter. Неподдержанный, незарегистрированный либо
выключенный provider не активируется. `VerifiedIdentity` не содержит
`global_id`, не создаёт пользователя или session и не меняет domain.

Все production providers зарегистрированы как reserved/disabled до
появления проверенных adapters в последующих циклах. Mock provider
разрешён только в `ENV=ci`. Добавлен exact Operator Kernel route цикла
1609; устаревший заголовок accelerated roadmap исправлен без изменения
исторических документов.

Alembic head остаётся `0002`; migration, PostgreSQL DDL/data, backfill,
read switch, ownership и экономика не изменялись. Реальный `PG-0` не
выполнен. Следующий цикл: `1610 — AuthContext contracts, resolver
interfaces и security/redaction skeleton без DDL`. После цикла 1609
остаётся `23` обязательных цикла `1610–1632`. GitHub CI пока не запускать.

# Цикл 1608 — semantic allowlist и compatibility registry

Статус: `LOCAL_IDENTITY_REGISTRY_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_05.zip`.
Release candidate: `EFHC_Bot_v172_05_RELEASE.zip`.
Matrix/technical archive: `EFHC_Bot_v172_05_MATRIX_TECHNICAL.zip`.

Создан единый semantic registry для `global_id`, физического
LEGACY-имени `user_id`, локального `id`, Telegram provider `tg_id`,
разрешённых compatibility aliases и исторических областей. Registry
является единственным active allowlist для новых identity guards;
временные aliases имеют sunset budget до цикла `1631`.

Причина двукратного роста development-архива доказана: накопление
исторических XLSX, raw identity JSON/CSV, JUnit/XML, collection-списков
и runtime logs. Код и production assets не являлись причиной роста.
Поставка разделена на три архива: компактный development HEAD, чистый
release и отдельный matrix/technical archive со всеми подробными XLSX,
текущим raw-аудитом, JUnit и индексом перемещений.

Alembic, PostgreSQL data, ownership и экономика не переключались.
Следующий цикл: `1609 — AuthProvider и provider registry foundation`.
После цикла 1608 остаётся `24` обязательных цикла `1609–1632`.
GitHub CI пока не запускать.

# Цикл 1607 — Cross-language разделение GlobalId и TelegramId

Статус: `LOCAL_CROSS_LANGUAGE_IDENTITY_SEPARATION_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_04.zip`.
Release candidate: `EFHC_Bot_v172_04_RELEASE.zip`.

Backend `GlobalId` и `TelegramId` остаются отдельными nominal value
objects. Frontend получил несовместимые branded-типы: строковый
`GlobalId` и числовой provider-only `TelegramId`. Telegram WebApp
boundary проверяет `user.id` до передачи в приложение. Прямое и
косвенное смешение, а также передача `global_id` в Telegram API
блокируются compile/runtime/AST guards.

Активные routes, Alembic, backfill, ownership и экономика не
переключались. Реальный PostgreSQL `PG-0` остаётся обязательным.

Roadmap ускорен: прежние 94 плановых слота были избыточной
safety-maximal декомпозицией. После цикла 1607 остаётся 25 обязательных
циклов `1608–1632`; `1633–1700` являются только условным резервом.

Следующий цикл: `1608 — semantic allowlist и compatibility registry`.
GitHub CI пока не запускать.

# Цикл 1606 — API-контракт global_id

Статус: `LOCAL_GLOBAL_ID_API_CONTRACT_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_03.zip`.
Release candidate: `EFHC_Bot_v172_03_RELEASE.zip`.

Создан единый изолированный контракт
`backend DTO ↔ OpenAPI fixture ↔ frontend DTO`. Поле `global_id`
передаётся только строкой из десяти ASCII-цифр с format
`efhc-global-id`; ведущие нули сохраняются, `0000000000` отклоняется.
Действующие LEGACY routes и DTO не переключались.

Alembic head остаётся `0002`; historical backfill, runtime read switch
и financial ownership switch не выполнялись. Реальный PostgreSQL
`PG-0` по-прежнему обязателен до цикла 1613.

Следующий цикл: `1607 — Cross-language разделение GlobalId и TelegramId`.
После завершения 1606 до цикла 1700 остаётся `94` цикла.
GitHub CI пока не запускать.

# Цикл 1605 — Frontend GlobalId string system

Статус: `LOCAL_FRONTEND_GLOBAL_ID_STRING_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_02.zip`.
Release candidate: `EFHC_Bot_v172_02_RELEASE.zip`.

Frontend `GlobalId` закреплён как branded string из десяти ASCII-цифр.
`0000000000`, JavaScript number/BigInt, numeric conversion, arithmetic и
unsafe casts запрещены fail-closed guard. Текущий Telegram-specific
`tg_id: number` не заменялся механически. Alembic, данные, экономика,
backfill, dual-write и read switch не изменены.

Roadmap оптимизирован по code/data линиям и gates `PG-0…PG-4`.
Следующий цикл: `1606 — API-контракт global_id`.
Следующая изменённая версия: `v172.03`.

# Цикл 1604 — Backend GlobalId type finalization

Статус: `LOCAL_BACKEND_TYPES_FINALIZED / POSTGRESQL_PROOF_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_01.zip`.
Release candidate: `EFHC_Bot_v172_01_RELEASE.zip`.

Канонический пакет `app.identity` экспортирует только `GlobalId`,
`TelegramId` и связанные канонические контракты. Историческое семейство `UserId` и модуль
`app.identity.legacy_user_id` перенесены в `docs/history/code_archive/`; active
backend пакет экспортирует только канонические `GlobalId` и provider
identity types. Возврат legacy type names запрещён.

Закреплены явные границы `GlobalId ↔ database` и
`TelegramId ↔ provider`, стабильные машинные коды ошибок и русские
сообщения. Alembic остаётся `0002`; historical backfill, dual-write,
runtime read switch и financial ownership switch не выполнялись.

Реальный PostgreSQL proof всё ещё отсутствует. Следующий цикл:
`1605 — Frontend GlobalId string system`. GitHub CI пока не запускать.

# Цикл 1603 — Global ID PostgreSQL reconciliation baseline

Статус: `GATE_PREPARED / REAL_POSTGRESQL_BLOCKED_BY_ENVIRONMENT`.
Development HEAD: `EFHC_Bot_v172_00.zip`.
Release candidate: `EFHC_Bot_v172_00_RELEASE.zip`.

Подготовлен воспроизводимый read-only PostgreSQL gate для канонического
`global_id` над физической EXPAND-колонкой `users.user_id`. Gate требует
реальное синхронное PostgreSQL-соединение, снимает один согласованный
снимок в транзакции `REPEATABLE READ READ ONLY DEFERRABLE` и всегда
выполняет `ROLLBACK`.

В текущей среде реальный PostgreSQL запуск заблокирован: отсутствуют
PostgreSQL Server, клиентские binaries, Docker/Podman, синхронный driver
и PostgreSQL URL; установка через APT не состоялась из-за недоступного
DNS/mirror. Статус не повышается до PASSED. Historical backfill,
dual-write, read switch и financial ownership switch не выполнялись.

Следующий цикл: `1604 — Backend GlobalId type finalization`.
Следующая изменённая версия: `v172.01`.

# Цикл 1602 — канонизация Global ID

Статус: `GLOBAL_ID_CANON_ACTIVE / POSTGRESQL_PROOF_REQUIRED`.
Current HEAD на входе: `EFHC_Bot_v171_98.zip`.
Целевой changed HEAD: `EFHC_Bot_v171_99.zip`.

`global_id` является главным неизменяемым идентификатором единого
аккаунта EFHC. Физическая EXPAND-колонка временно называется
`users.user_id`; новый код использует `GlobalId` и `User.global_id`.
Отдельная колонка `global_id` не создаётся. `id` остаётся локальным PK,
а `tg_id` — Telegram provider ID. Historical backfill, runtime read
switch, financial ownership switch и GitHub CI в цикле 1602 запрещены.

Активные источники:

- `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`;
- `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`;
- `docs/history/legacy_artifacts/docs/cycles/WORK_CYCLES_1601-1632_ACCELERATED_GLOBAL_ID_AUTH_PLAN.md`.

# Цикл 1601 — открытие диапазона и приёмка фундамента

Статус: `LOCAL_FOUNDATION_ACCEPTED / POSTGRESQL_PROOF_REQUIRED`.
Development HEAD: `EFHC_Bot_v171_98.zip`.
Release candidate: `EFHC_Bot_v171_98_RELEASE.zip`.

Независимо подтверждены SHA-256, ZIP entries, CRC и безопасная
распаковка `v171.89` и `v171.97`. Diff `v171.89 → v171.97` не выявил
скрытого runtime read switch, historical backfill либо изменения
финансового ownership. Alembic остаётся на линейной цепочке
`0001 → 0002`, `users.id` остаётся primary key, а `users.user_id` —
nullable EXPAND-полем.

Исправлен дефект provenance: генераторы identity-аудита и PostgreSQL
preflight теперь обязаны получать точные `source_head`, `baseline_head`
и номер цикла, поэтому новый evidence не может молча наследовать
метаданные циклов 1598–1599.

Реальная PostgreSQL reconciliation по-прежнему не выполнена: в среде
нет PostgreSQL URL, синхронного драйвера, `psql`, PostgreSQL Server,
Docker или Podman. Historical backfill, runtime read switch и
финансовый switch запрещены. GitHub CI не запускается: основной
интегрированный auth-пакет ещё не готов.

Следующий цикл: `1602 — независимый reconciliation baseline`.
Следующая изменённая версия: `v171.99`.

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон `1593–1600` локально закрыт: зафиксированы аудит
идентификаторов, строгий `UserId`, внешний строковый API-контракт,
nullable EXPAND `users.user_id`, LEGACY alias, backfill harness и
read-only PostgreSQL reconciliation gate.

Реальная PostgreSQL-сверка недоступна в текущей среде. Historical
backfill, runtime read switch и изменение финансового ownership
остаются запрещёнными. Финансовый допуск — `0.00000000`.

GitHub CI не запускается по указанию пользователя. Основной пакет
изменений ещё не готов. Команда `запусти тесты CI GitHub` будет выдана
только после интеграции auth core, TON Proof login, Telegram adapter и
необходимых PostgreSQL-контуров.

Все новые и изменяемые тесты, отчёты, документы, docstring и авторские
комментарии оформляются на русском языке. Технические идентификаторы и
внешние протоколы не переводятся.

Следующий цикл: `1601`.
Следующая изменённая версия: `v171.98`.

# EFHC Bot Operator Kernel

# Operator Kernel

Status: ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER.
Archive: `v171.97`.
Cycle: `1600 — FOUNDATION RANGE CLOSURE / NO READ SWITCH`.

## 1. Current HEAD

- Current canonical development HEAD: `EFHC_Bot_v171_97.zip`.
- Input development HEAD: `EFHC_Bot_v171_96.zip`.
- Current production release candidate: `EFHC_Bot_v171_97_RELEASE.zip`.
- Preserved forensic baseline: `EFHC_Bot_v171_47.zip`.
- Preserved baseline Kernel:
  `docs/AI/PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md`.
- Exact route: `user_id_foundation_range_closure`; fallback is not used.
- Current cycle: `1600 — FOUNDATION RANGE CLOSURE — LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL PROOF REQUIRED`.
- Status: `LOCAL_RELEASE_CANDIDATE /
  FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED /
  NOT LIVE PRODUCTION READY`.
- Exact v171.89 development and release GitHub CI are green and remain
  the inherited input proof. Они не доказывают изменённые архивы v171.97.
- Target system/domain owner is `UserId` / `user_id`; Telegram
  provider identity is `TelegramId` / `tg_id`. Cycle 1597 adds only nullable `users.user_id`, sequence and Alembic `0002`. Existing rows stay NULL; routes, DTOs, AuthContext and ownership reads remain legacy.
- Cycle 1598 adds only the explicit bounded alias
  `User.legacy_runtime_id -> User.id` and a pure render-only backfill
  harness. The future `User.id -> User.user_id` compatibility alias is
  inactive. No database backfill, AuthContext switch, route switch or
  financial/domain read switch occurs.
- Future historical-row mapping is deterministic:
  `NULL users.user_id -> users.id`. Existing non-null `user_id` values
  are preserved. `tg_id`, wallet address and provider subject never
  derive `user_id`.
- Active direct referral means the permanent `Activ` activation flag:
  `referral_links.activated_at IS NOT NULL`. The flag is set exactly
  once by `activate_referral()` at the first panel activation and is
  never re-evaluated from current panel count or panel existence.
  Archive, expiry or future physical panel deletion cannot clear it;
  `panels_count` is display-only.
- Cycle 1592 correction: the former wording "has ever created a panel"
  was ambiguous and previously allowed runtime consumers to derive
  Activ from current `panels` rows instead of the activation flag.
- Active/Inactive filtering and `(invited_at, invitee_tg_id)` cursor pagination execute in PostgreSQL before ordering.
- `/me` referral routes use authenticated TG ID only. Deprecated routes are self-only, reject foreign TG IDs with `403` and expose the deprecation header.
- Admin referral totals include both `referral_active_unit` and `referral_level_bonus`.
- ETag depends on owner, filter, cursor, limit and dataset mutation state.
- Direct and Lvl reward idempotency is re-read after row locks to avoid concurrent late unique-key conflicts.
- Real PostgreSQL runtime and API integration tests are a distinct mandatory CI stage.
- Invalid supplied referral code fails before user creation; no-invite creates a permanent 0 user.
- Referral economics remain `1 000 + 1 411 = 2 411 EFHCb`.
- Alembic is now a linear `0001 -> 0002` chain; head is `0002`. The ORM table count remains 44.
- The local pre-release gate now rejects stale CI evidence fail-closed. Fresh exact-HEAD GitHub CI, PostgreSQL integration, frontend build, Docker clean deploy/update/rollback and VPS/live proof remain open.
- Next changed archive after delivery of v171.97: `EFHC_Bot_v171_98.zip`.
- PostgreSQL performance proof parses `EXPLAIN (FORMAT JSON)` nodes and accepts only the canonical referral and panel index sets.
- Complete frontend inventory is 15 public, 17 Admin and two safe system routes, protected by a machine visual manifest.
- Visual readiness requires real `page.goto()` proof at 360, 390 and 430 px; synthetic HTML is forbidden.

## 2. Kernel role

Operator Kernel is the active operational dispatch layer of EFHC Bot.

It is not only navigation.

It must:

1. identify the user task by EFHC-specific keywords;
2. map keywords to canonical task types;
3. route the task to exact files and documents;
4. show where each rule is fixed in CANON / SSOT / NORM / AI / HEALER;
5. prevent full archive reading when a precise route exists;
6. prevent canonical drift in UI, economy, navigation, i18n, Telegram, TonConnect, TonProof, transactions and release evidence;
7. define the patch boundary before edits;
8. require targeted validation;
9. require route-backed screenshots for frontend work;
10. require green local logs or an exact failure boundary before development archive delivery;
11. distinguish local checks from fresh exact-HEAD GitHub CI;
12. create the next sequential archive.

Kernel may be detailed operationally, but it must not duplicate the full text of CANON, SSOT, NORM, Healer history, cycle history or reports. It stores keywords, route summaries, boundaries, proof gates and exact anchors.

## 3. Working tree / archive source rule

Every new chat or execution session begins from the latest canonical ZIP supplied by the user:

```text
latest canonical ZIP
→ verify exact name and ZIP integrity
→ unpack once into the current-session working tree
→ read START_HERE and this Kernel
→ resolve the exact route
→ edit only the current working tree
→ validate the bounded change
→ build the next sequential ZIP
→ deliver it to the user
```

The ChatGPT sandbox is temporary. A previous `/mnt/data` workspace is not persistent HEAD. Historical archives are forensic references only and never replace the latest canonical HEAD.

## 4. Mandatory startup route

The only startup order is defined by `START_HERE.md`:

1. `START_HERE.md`;
2. `KERNEL.md`;
3. `docs/AI/AI_ARCHIVE_LAWS.md`;
4. `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`;
5. `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`;
6. `docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md`;
7. `docs/AI/AI_OPERATOR_RULES_EFHC.md`;
8. `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`;
9. `docs/SSOT/SSOT_INDEX.md`;
10. `docs/NORM/ARCHITECTURAL_LOCKS.md`;
11. `docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md`;
12. `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`;
13. `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`;
14. `ops/operator_kernel/config/routes.yaml` through the runtime resolver;
15. `ops/operator_kernel/cache/file_map.summary.json`;
16. exact route files returned by Kernel;
17. exact source files before edit;
18. exact tests and validation route;
19. no more than the latest two task-relevant entries from each docs/history/legacy_artifacts/reports/audits/cycles/logs layer unless the user or a forensic route requires older history.

Do not full-read `file_map.json`, `HEALER_ATLAS.md`, `HEALER_CASEBOOK.md`, `atlas.json` or `casebook.json` during ordinary startup. Use `file_map.summary.json`, `docs/healer/HEALER_CAPSULE.md` and exact routed cases. Full Healer/history reading is reserved for an explicit regression or forensic route.

## 5. Kernel-first rule

Before opening broad project areas, run the task through:

```text
user request
→ task_classifier.py
→ task type
→ routes.yaml
→ route_resolver.py
→ canonical anchors
→ required_read
→ allowed_write
→ validation
→ context capsule
```

If a precise route exists, full archive reading is forbidden. If classification is ambiguous, preserve the current task as primary, expose secondary signals and choose the smallest safe route. A fallback must include Kernel and route hints; it must not silently become `full_audit`.

## 6. Key project keywords and triggers

Compact trigger groups:

| Keyword group | Canonical task type | Runtime route |
|---|---|---|
| `cycle 1594`, `UserId contract`, `negative identity guards`, `type foundation` | `user_id_contract_foundation` | `user_id_contract_foundation` |
| `user_id`, `tg_id`, `identity resolver`, `AuthContext`, `TON Proof login` | `user_id_identity_migration` | `user_id_identity_migration` |
| `frontend`, `visual`, `UI`, `UX`, `screenshots`, `скриншоты`, `route-backed`, `page.goto`, `overflow` | `frontend_visual_route_backed_work` | `frontend_visual_route_backed_recovery` |
| `bottom nav`, `нижняя навигация`, `нижние кнопки`, `6 buttons`, `Energy`, `Panels`, `Exchange`, `Tasks`, `Referrals`, `Ranks` | `canonical_bottom_navigation_guard` | `frontend_canonical_navigation_guard` |
| `Native-wallet adapter`, `WalletProvider`, `Wallet in Telegram`, `Native Gram Wallet`, `не привязывать только к TonConnect` | `wallet_provider_adapter_work` | `wallet_provider_adapter_layer` |
| `clean first-boot`, `чистый первый запуск`, `пустой VPS`, `44 tables`, `Alembic head`, `one-command deploy`, `v171.71 RELEASE` | `clean_first_boot_release` | `clean_first_boot_release_candidate` |
| `provider-independent release`, `OVHcloud`, `Docker Compose`, `new VPS`, `backup restore`, `pg_dump pg_restore`, `cycles 1574-1578` | `provider_independent_release_portability` | `provider_independent_release_portability` |
| `Telegram`, `Telegram Mini App`, `live Telegram`, `TonConnect`, `TonProof`, `wallet`, `transaction contour`, `real TON`, `Jetton` | `live_telegram_tonconnect_tonproof_transaction_gate` | `cycle_1573_live_telegram_transaction_contours` |
| `cycle 1574`, `local RC audit`, `release candidate audit`, `идём дальше`, `deferred post-release` | `cycle_1574_local_release_candidate_audit` | `cycle_1574_local_release_candidate_audit` |
| `i18n`, `13 languages`, `локализация`, `Activ`, `VIP`, `hardcoded text`, `translation` | `frontend_i18n_guarded_work` | `i18n_public_surface_guard` |
| `logs`, `green logs`, `GitHub CI`, `pytest`, `ruff`, `mypy`, `bandit`, `compileall`, `typecheck`, `npm build` | `ci_logs_repair_or_verification` | `ci_log_exact_failure_repair` |
| `archive`, `архив`, `new zip`, `development archive`, `release archive`, `screenshots archive`, `sequential number` | `archive_build_and_release_boundary` | `archive_numbering_and_release_gate` |
| `kernel`, `Operator Kernel`, `routes.yaml`, `route_resolver`, `task_classifier`, `file_map`, `context capsule`, `anchors`, `v171.47` | `operator_kernel_full_restore` | `operator_kernel_full_restore_from_v171_47` |

The authoritative full table is `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`.

## 7. Keyword → task type → route → canonical anchors map

The operational sequence is:

```text
keyword group
→ task type
→ configured route name
→ exact canonical anchors
→ exact runtime files
→ allowed patch surface
→ targeted validation
→ evidence and archive boundary
```

The authoritative domain map is `docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md`. `routes.yaml` is the primary runtime route source. Hardcoded Python routes are bootstrap/fallback compatibility only.

## 8. Current active cycle boundary

- Cycles 1574-1595: `COMPLETE locally`.
- Current stage: `USERS.USER_ID NULLABLE EXPAND / ALEMBIC 0002`.
- Current status: `LOCAL_RELEASE_CANDIDATE /
  FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.
- Exact route: `user_id_api_contract`.
- Fallback: `false`.
- Source HEAD: `EFHC_Bot_v171_91.zip`.
- Value contract: immutable `UserId`, `TelegramId`, validated
  `UserIdDisplay`, strict external parser and explicit DB boundaries.
- Identity boundary: `21` Telegram-specific files, `179` legacy runtime
  files and zero provider/system semantic mix offenders.
- Patch boundary: `481` runtime/schema/frontend files protected by
  Python semantic hashes or exact bytes.
- Production code outside `backend/app/identity` has zero imports of the
  new value types.
- ORM, Alembic, AuthContext, routes, services, schemas, frontend
  ownership and financial data remain unchanged.
- PostgreSQL reconciliation is not claimed by this no-data cycle.
- Next cycle: `1597 — users.user_id expand migration design`.

## 9. Canonical UI boundary

The public UI may not be redesigned, simplified, reordered or renamed without direct user instruction and a matching CANON/SSOT/NORM route.

Canonical bottom navigation is exactly six bottom buttons in fixed order:

1. `Energy`;
2. `Panels`;
3. `Exchange`;
4. `Tasks`;
5. `Referrals`;
6. `Ranks`.

Do not rename, remove, reorder, replace or change the routes/icons of these six buttons without direct user instruction and synchronized CANON/SSOT/NORM updates.

Global Header, balance panel, status indicators, avatar/profile entry, layout proportions and responsive behavior are protected by frontend visual anchors and screenshot proof. Product labels, routes and economic values are never changed by visual preference alone.

## 10. Frontend visual proof boundary

Any frontend visual change requires:

1. exact changed route/component identification;
2. applicable frontend CANON/NORM/SSOT anchors;
3. targeted typecheck/build when dependencies are available;
4. a real running frontend;
5. browser navigation with `page.goto()`;
6. HTTP, route and app-root checks;
7. page-error and critical console-error checks;
8. horizontal-overflow check;
9. fresh PNG for affected routes/viewports;
10. screenshots shown to the user and delivered in a separate companion archive when requested.

Manual HTML, `page.set_content`, synthetic/mock imitation, inherited PNG and component-only demos are not application proof.

## 11. Telegram / TonConnect / TonProof / transaction boundary

Telegram, TonConnect, TonProof and transaction work uses the wallet/withdraw SSOT anchors. The route `cycle_1573_live_telegram_transaction_contours` remains the external release/post-release evidence intake route and no longer blocks unrelated development cycles after explicit user-authorized deferral.

Local code and tests may prove implementation boundaries. They cannot prove:

- a live Telegram client interaction;
- a real wallet signature;
- a real TonProof signature;
- a real TON/Jetton transfer;
- a real transaction hash;
- production HTTPS behavior.

Those remain `UNVERIFIED_LIVE_BOUNDARY` until real external evidence exists.

## 12. Money-flow / wallet / withdraw boundary

Money-flow, wallet ownership, exchange, deposit, direct deposit, shop checkout and withdraw changes are high-risk. They require:

- an explicit route and patch scope;
- exact SSOT/NORM anchors;
- idempotency and atomicity review;
- anti-double-spend and ownership checks;
- targeted backend tests;
- frontend confirmation/error-state checks where affected;
- no invented live proof.

The invariant `1 EFHC = 1 kWh` cannot be changed without direct user instruction and synchronized canonical updates.

## 13. I18N boundary

The project has 13 supported languages. I18N work must:

- route through `i18n_public_surface_guard`;
- read the language/localization anchors;
- scan changed surfaces for hardcoded strings;
- preserve permanent English account-status labels `Activ` and `VIP` in all 13 locales; generic/tab term `Active` remains distinct;
- validate locale differences and fallback behavior;
- create visual proof for affected routes when UI output changes.

A translation repair may not change product meaning, economic values, routes or UI structure.

## 14. Admin boundary

Admin work must remain separated from player-facing UI and APIs. Admin permissions, confirmations and audit trails are protected. Admin routes/components cannot be exposed to public navigation. User-facing changes must not be introduced as a side effect of admin work.

## 14A. AI operational memory boundary

- `docs/AI/` is the active operational brain of the AI, not cycle history.
- `AI_TEMPORARY_MEMORY_PENDING.md` contains only unresolved or immediately actionable items.
- Approved decisions are transferred to CANON / SSOT / NORM and then removed from temporary memory.
- Historical snapshots are stored under `docs/history/` and are not default-read.
- Reports, audits and cycles stay in the archive, but ordinary familiarization is limited to the latest two relevant entries per layer.

## 15. Healer / regression boundary

Use `docs/healer/HEALER_CAPSULE.md` as the short startup entry. Read full Atlas/Casebook only through an explicit Healer/regression route.

A Healer update requires:

- established incident;
- root cause;
- violated rule;
- affected versions/files;
- corrective action;
- preventive guard;
- independent test/evidence;
- residual risk.

Healer cannot prove its own cure. Kernel demotion, route drift and keyword loss are protected by the three v171.62 Healer guards.

## 16. CI / logs / validation boundary

- Read the exact supplied error before repair.
- Run targeted verification first.
- Broad tests/builds are allowed when relevant, with timeout and saved output. GitHub CI job timeout is 10 minutes (user-approved range: 5–10 minutes).
- Do not loop a hanging command.
- Do not delete, skip, archive or weaken a protection test to obtain green status.
- A local pass is `LOCAL_AUX_CHECK_ONLY`.
- Never claim fresh GitHub CI green without a fresh exact-HEAD GitHub log.
- If a command cannot run, record the exact blocked boundary and continue with safe independent work.

## 17. Screenshots boundary

Screenshots are mandatory evidence for frontend visual work and are local user-facing proof. PNG is not a mandatory GitHub CI input. Screenshot scripts may be guarded for `page.goto`, app-root, errors and provenance, but historical PNG hashes cannot be the only blocking CI criterion.

## 18. Archive numbering / development-release archive boundary

- Every changed pass creates the next sequential development ZIP.
- Archive names receive no unsolicited prefixes or suffix pollution.
- Development archive and release archive are separate artifacts.
- Frontend screenshots are delivered in a separate companion ZIP when required.
- Main development ZIP excludes screenshot PNG, nested ZIP, `node_modules`, `.next`, caches, temporary builds, secrets and unnecessary runtime logs.
- Missing live proof blocks release claims, not honest development archive delivery.

## 19. Patch permission boundary

Every patch must identify:

1. task type and route;
2. active truth anchors;
3. exact files to read;
4. exact files allowed to change;
5. restricted/manual-control files;
6. targeted tests;
7. evidence/report requirements.

No file may be changed merely because it is nearby. Each runtime diff must answer which confirmed regression or explicit task requirement it addresses.

## 20. Forbidden drift list

Forbidden:

1. demoting Kernel to navigation-only;
2. removing project keyword groups;
3. removing canonical anchors or route map;
4. treating `routes.yaml` as dead configuration;
5. using only hardcoded Python routes as active truth;
6. ignoring EFHC-specific keywords in `task_classifier.py`;
7. forcing full-read of `file_map.json`;
8. forcing full Healer Atlas/Casebook read for every task;
9. accepting frontend work without real route-backed proof;
10. claiming GitHub CI green without a fresh exact log;
11. claiming release-ready without live Telegram, TonConnect/TonProof and transaction evidence;
12. changing the six canonical bottom buttons without direct instruction;
13. changing economy/wallet/money-flow without high-risk route validation;
14. mixing development and release archives;
15. copying historical Current HEAD blocks into active Kernel;
16. updating CANON/SSOT/NORM to justify an unauthorized runtime change.

## 21. Active truth hierarchy

1. Direct current user instruction.
2. Factual content of the latest canonical HEAD.
3. AI Archive Laws and lock.
4. Active CANON.
5. Active SSOT.
6. Active NORM and Architectural Locks.
7. Active AI execution documents.
8. Fresh runtime evidence and logs.
9. Healer, cycles and reports.
10. Historical archives and preserved references.

A report, generated JSON, manifest or Healer entry cannot self-certify the behavior it is intended to prove.

## 22. Reference boundary

- `v171.63` is the input tree for the current governance synchronization pass.
- `v171.47` is a preserved forensic baseline, not current HEAD.
- `docs/AI/PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md` is reference evidence.
- Historical docs/history/legacy_artifacts/reports/audits/cycles remain history and cannot override current direct instruction or active truth. Without explicit request, read only the latest two relevant entries per layer.
- Runtime and guards are restored by confirmed requirements, not blind file copying.

## 23. Compact compatibility anchors

Legacy navigation tokens remain searchable as compatibility pointers, not active historical state:

- `ACTIVE_DASHBOARD_COMPONENT_CONTRACT`;
- `ACTIVE_MINI_CHARTS_FOUNDATION`;
- `ACTIVE_SIMULATION_DASHBOARD_UI_KIT_FOUNDATION`;
- `ACTIVE_ADMIN_DASHBOARD_UI_KIT_FOUNDATION`;
- `ACTIVE_GRAFANA_REFERENCE_MAP_FOR_DASHBOARD_DIRECTION`;
- `ACTIVE_ENERGY_DASHBOARD_VISUAL_QA`;
- `DASHBOARD_TOOLBAR_FOUNDATION`;
- `ENERGY_DASHBOARD_RUNTIME_PORT`;
- `PANEL_CHROME_FOUNDATION`;
- `VARIABLES_FILTERS_SYSTEM`;
- `WalletBinding`;
- `PACK-02 tails cleanup`;
- `crypto_wallets` is not active wallet-binding storage;
- `Kernel lock: Withdraw V1 payout canon`;
- `GitHub CI Rerun Proof`;
- `live Telegram proof`.

The exact destination is resolved by `routes.yaml`, `file_map.summary.json`, route map and the relevant SSOT/NORM.


## 23A. Historical compatibility route anchors

Canonical archive lineage: `v171.64 → v171.65 → v171.66 → v171.67`.
These entries are searchable routing pointers, not alternate Current HEAD
blocks and not mandatory startup reads.

- historical route: `v171_31 / v171.31`, cycle `1556`;
- `DASHBOARD_COMPONENT_CONTRACT.md`;
- `v170.31 / dashboard visual kernel`;
- `v170.32 / sandbox dashboard inventory`;
- `v170.33 / Grafana Visual Pattern Map`;
- `v170.34 / Dashboard Design Tokens Foundation`;
- `GRAFANA_EFHC_ELEMENT_USAGE_MAP`;
- `GRAFANA_PATTERN_MAP_COMPLETION.md`;
- `DASHBOARD_TOOLBAR_FOUNDATION` / `DashboardToolbar.tsx`;
- `ENERGY_DASHBOARD_RUNTIME_PORT` / `EnergyDashboardRuntime.tsx`;
- `ENERGY_DASHBOARD_SANDBOX_PROTOTYPE`;
- `Energy Dashboard Visual QA`;
- `PANEL_CHROME_FOUNDATION` / `PanelChrome.tsx`;
- `MINI_CHARTS_FOUNDATION` / `MiniCharts.tsx`;
- `VARIABLES_FILTERS_SYSTEM` / `DashboardFilters.tsx`;
- `SimulationDashboardUiKit.tsx`;
- `Dashboard UI Kit Consolidation QA`;
- `Panels Portfolio Sandbox Prototype`;
- `Real Time-Series Backend Contracts`;
- `Synthetic Data Cleanup / Truth Hardening`;
- `Visual Performance / Bundle Safety`;
- `WITHDRAW_ADMIN_TONCONNECT_SSOT.md`;
- `WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md`.

The exact destination is still resolved by `routes.yaml`, the short file
map and the current SSOT/NORM. Historical labels cannot override current
runtime architecture such as the `WalletProvider` adapter boundary.

Additional historical guard pointers:

- `EFHC_Bot_v171_64.zip`;
- `EFHC_Bot_v171_65.zip`;
- `compaction`;
- `AdminDashboardUiKit.tsx`;
- `EnergyDashboardSandboxPrototype.tsx`;
- `PANELS_PORTFOLIO_SANDBOX_PROTOTYPE`;
- `WITHDRAW_FLOW_NORM.md`;
- `test_dashboard_toolbar_foundation.py`;
- `test_energy_dashboard_runtime_port.py`;
- `test_energy_dashboard_visual_qa.py`;
- `test_grafana_pattern_map_completion.py`;
- `test_mini_charts_foundation.py`;
- `test_panel_chrome_foundation.py`;
- `test_variables_filters_system.py`.

## 24. Runtime route resolver requirement

`ops/operator_kernel/route_resolver.py` must use `ops/operator_kernel/config/routes.yaml` as the primary runtime source. A change to configured route data must change resolution behavior without a Python route edit. Hardcoded routes may exist only as bootstrap/fallback compatibility and must be reported as fallback usage.

## 25. File map freshness requirement

Refresh command: `python ops/operator_kernel/file_map.py --refresh`.

- `file_map.summary.json` is the short startup map.
- `file_map.json` is a machine index, not a full-read AI document.
- Refresh `file_map.json` after all file changes.
- Refresh summary from the final map.
- A stale/missing map must be reported, not silently treated as current.

## 26. Context capsule requirement

A context capsule must contain:

- user task and archive;
- task classification and route;
- active cycle boundary;
- required rules/invariants;
- canonical anchors;
- exact selected files;
- bounded relevant excerpts;
- allowed writes and restricted files;
- targeted validation;
- proof and archive boundary.

A capsule is not merely a list of paths and may not include the full archive by default.

## 27. Release/readiness claim boundary

`release-ready`, `production-ready`, `GitHub CI green`, `live Telegram verified`, `TonConnect verified`, `TonProof verified` and `transaction verified` are evidence claims. They require fresh evidence for the exact claimed scope.

Current verdict:

```text
LOCAL_RELEASE_CANDIDATE
FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED
NOT LIVE PRODUCTION READY
```

A historical green CI run, repair report or local completeness percentage is
not evidence for a later HEAD. The release gate must compare the evidence
`source_head` with the exact current development archive and fail closed on any
mismatch. Deferred external proof remains explicitly unverified.

Mandatory external gates remain:

- live VPS deployment and HTTPS;
- live Telegram client and webhook;
- real TonConnect and TonProof;
- controlled deposit, Browser Shop and withdrawal settlement;
- restore on a second provider and DNS switch rehearsal.

## 28. Current identity migration boundary

The current stage expands the physical user_id column without changing
runtime ownership:

```text
canonical JSON value = string
pattern = ^[0-9]{10}$
PydanticUserId input = canonical string or validated UserId
PydanticUserId storage = UserId
PydanticUserId output = canonical ten-digit string
ApiExternalUserId = scalar path/query preparation
```

The following remain unchanged and protected:

```text
users.id INTEGER primary key
users.tg_id BIGINT unique not null
AuthContext.tg_id
active routes and current Pydantic DTOs
all domain and financial ownership reads
Alembic head 0001
```

Cycle-1596 enforcement includes the exact route
`user_id_api_contract`, OpenAPI contract tests and the protected
runtime/API manifest. That historical stage was followed by the
expand migration design and PostgreSQL dry-run.

The current factual source is `EFHC_Bot_v171_95.zip`. Fresh
exact-HEAD GitHub CI for v171.95 remains required.

## 29. v171.71 clean-first-boot release contract

The only canonical first production command is:

```text
./scripts/release/deploy.sh
```

The release dependency chain is:

```text
db healthy
→ migrate completed successfully
→ backend + scheduler healthy
→ frontend healthy
→ proxy healthy
```

The migrate service must create both canonical schemas, apply Alembic
head, validate exactly 44 ORM tables and insert only idempotent system
data. It must not read documentation files. A failed migration prevents
all application services from being considered deployed.

The external remaining gate is a real no-cache Docker build and clean
VPS run followed by a repeated deploy. Until that proof exists,
`production_release_ready` remains false.


## Historical guard route anchors retained for active validation

- `test_energy_dashboard_sandbox_prototype.py`;
- `PanelsPortfolioSandboxPrototype.tsx`;
- `test_panels_portfolio_sandbox_prototype.py`;
- `WITHDRAW_AUDIT_CANON.md`.


## 30. Cumulative full-release archive update contract


Production не устанавливает каждый промежуточный development number.
Release может обновляться напрямую с любой объявленной поддерживаемой
предыдущей production version. Updater отклоняет same-version install,
downgrade, source старше minimum manifest, неподдерживаемую Alembic revision,
неполный cumulative migration path, неверное target environment или отсутствие
проверенного pre-update backup перед изменением БД. Alembic применяет все
пропущенные revisions по порядку; соседство application archives не требуется.

Production update использует полный cumulative release archive, а не
пофайловую перезапись. Канонический маршрут:

```text
current release update.sh
→ external SHA-256
→ safe extraction + internal SHA256SUMS
→ RELEASE_METADATA + UPDATE_POLICY
→ source-range and cumulative migration compatibility
→ target deploy.sh
→ healthchecks
→ atomic /opt/efhc/current switch
```

Application rollback разрешён только когда `rollback_compatibility` явно
разрешает его без database restore. Восстановление БД всегда является отдельной
явной операцией.

## Cycle 1597 current identity migration boundary

- Физическая колонка того периода: `efhc_core.users.user_id BIGINT NULL`.
- Выделение: независимая последовательность `users_user_id_seq`.
- Диапазон: `1..9999999999`; уникальность для ненулевых значений.
- Существующие строки: без backfill в цикле 1597.
- Legacy primary key: `users.id` оставался primary key.
- Telegram key: `users.tg_id` тогда оставался `NOT NULL`.
- Runtime read/write ownership в том цикле не менялся.
- TON Login был спроектирован, но не включён.
- Проверенный TON wallet должен был разрешать существующего пользователя.
- Новый проверенный TON wallet мог атомарно создать новый `user_id`.
- Подключение wallet без корректного TON Proof не является аутентификацией.
- Автоматическое объединение двух существующих аккаунтов запрещено.
- Следующий этап: LEGACY alias и migration harness.
## Текущая граница миграции identity

- Активный alias: `User.legacy_runtime_id -> User.id`.
- Будущий alias: `User.id -> User.user_id`, неактивен.
- Будущий backfill: `NULL users.user_id -> users.id`.
- Уже назначенные значения `users.user_id` сохраняются.
- Backfill planner остаётся чистым и детерминированным.
- PostgreSQL SQL только рендерится; выполнение на БД отключено.
- `tg_id`, wallet и provider subject не используются для вычисления `user_id`.
- Alembic head остаётся `0002`; новая revision отсутствует.
- Runtime domain и financial reads остаются неизменными.
- Следующий цикл: `1599 — PostgreSQL reconciliation gate`.

## Актуализация цикла 1677

Текущий изменённый HEAD: `v172.96`. Исправлены подтверждённые CI-сбои v172.93; следующий обязательный шаг — exact-head GitHub CI.
