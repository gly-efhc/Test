## Текущая точка — кандидат v174.29 / qualification-refinement циклов 1783–1784

- Exact-head GitHub CI `86632433214` криптографически проверил `v174.28`: SHA-256 `52d87d762d810d292a8680324692146279319b5975f02c6f0e36175f1f2eea16`. Основной runtime/schema/frontend контур GREEN; pytest `2 failed / 1661 passed / 22 skipped / 1 warning`, оба failure относятся к stale architecture counts.
- `1783`: единый `/admin/users` контур по Global ID дополнен блоком «Балансы и история пользователя». Канонические EFHCm/EFHCb balances уже существовали; новый read-only `GET /admin/users/{global_id}/history` повторно использует тот же `list_profile_history_page()` и keyset максимум `50`.
- Публичный `/profile/history` остаётся session-owner-bound; Admin не подменяет пользовательскую сессию. Нового ledger, balance source или финансовой semantics не создаётся. Send/take/paid panel activation остаются как в `v174.28`; бесплатная Admin-активация панели запрещена.
- Static authority синхронизирована: OpenAPI `159/165/168`, Admin paths/seams `77/77`, `SSOT_ROUTES` `159/165`, application surface contract exact.
- `1784` не получает speculative index/schema changes. После `1784` осталось `0` плановых functional cycles; следующий шаг — exact-head GitHub CI `v174.29`, новый цикл `1785` автоматически не создаётся.
- Immutable report `02347`; следующий report `02348`.

## Текущая точка — кандидат v174.28 / циклы 1783–1784

- Exact-head CI `86624660035` проверил `v174.27` по SHA-256 `835289b0a4a2d50176d5c8481b0b2553e939751580ae5c71111869e6d7d1a4c3`. Основной runtime/schema/frontend контур GREEN; pytest имел 3 qualification-only failure.
- `1783`: единый Admin user-action contour по Global ID — отправить, забрать, платно активировать панель. Free admin panel create/reactivate запрещены.
- `1784`: статический retention/index/performance audit завершён без speculative schema changes.
- После `1784` осталось 0 плановых functional cycles. Следующий шаг — exact-head GitHub CI `v174.28`.
- Immutable report `02346`; следующий `02347`.

# CURRENT HEAD — v174.27 / qualification-repair + цикл 1783 owner-decision gate

- Exact-head GitHub CI `86619160930` проверил `v174.26`: checkout `bdf429d8256109bcb7efb616bb647581f22b9bd4`, SHA-256 `2058455d91a93645b700690c5ab703f6f52ccfa376a0dcdb69f23c7cc997495b` полностью совпал с Development HEAD.
- GREEN gates: Flake8 critical/full, Mypy, compileall, PostgreSQL preflight и frozen Alembic. RED gates: Ruff `I001`, Bandit `B608`, frontend TypeScript build и pytest `11 failed / 1651 passed / 22 skipped / 1 warning`.
- Candidate `v174.27` исправляет подтверждённые CI defects без изменения frozen `0001`, P0 `<180d` barrier, BANK semantics и physical schema. Local execution не выполняется; следующий verifier — exact-head GitHub CI `v174.27`.
- Циклы `1778–1782` остаются candidate до GREEN qualification. Цикл `1783` открыт только как audit/owner-decision gate; финансовая реализация не меняется до 10 ответов владельца. Цикл `1784` не начат.
- Owner correction: понятия `Admin prize-panel` в active CANON больше нет. `1783` = единый user-centric admin action surface по Global ID: BANK→user перевод EFHCb/EFHCm и canonical paid panel activation за средства пользователя.
- Current immutable report: `02345`; next `02346`.

## Текущая точка — кандидат v174.25 / цикл 1777 Simple Financial Retention

- Exact-head GitHub CI `86603967868` криптографически квалифицировал `v174.23`: SHA-256 `3c138eaa0be729f899ea1b6f75d65883f5c4e03b4049b2fd1decf7d6e065c73b`; все gates GREEN, pytest `1653 passed / 22 skipped / 1 warning`, Alembic `52 ORM / 53 physical / 0001: ok`, latest frontend build PASS. Подтверждённых CI ошибок нет.
- Цикл `1774` закрыт; `1775` и `1776` квалифицированы. По прямому решению владельца 2026-08-16 прежний physical monthly partitioning target циклов `1777–1779` отменён как избыточно сложный и не соответствующий цели упрощения/экономии.
- Цикл `1777` теперь — **Simple Financial Retention policy/planner**: обычные PostgreSQL tables сохраняют текущие PK/FK/UNIQUE; `PARTITION BY`, monthly partitions, composite PK ради partition key, month-aware FK и `DROP PARTITION` не вводятся.
- P0 execution invariant не меняется: `trusted age < 180 days` потенциально исполним; `trusted age >= 180 days` → `EXPIRED / NO CREDIT` до replay/idempotency и money mutation.
- Для шести approved financial-history tables retention clock = server-side `created_at`: `age >= 370 days` → delete-eligible **независимо от lifecycle status**; cleanup запускается только когда oldest history достигает `>=400 days`, после чего удаляется history `<= now_utc - 370 days`.
- Candidate `v174.25` реализует только pure age-based planner и architecture guards. Production `DELETE`, scheduler activation и physical replay cleanup не выполняются до следующего staged cycle/CI.
- Active retention SSOT: `docs/SSOT/FINANCIAL_RETENTION_CANON.md`. Старый `FINANCIAL_RETENTION_PARTITION_CANON.md` сохранён только как SUPERSEDED engineering history.
- Immutable report: `02343`. Следующий cycle: `1778` — bounded batch DELETE runner. После текущего `1777` остаются `1778–1784`, то есть 7 плановых циклов.

## Решение владельца 2026-08-16 — продолжать при GREEN основном контуре

Последнее прямое решение владельца: если основной runtime/financial/schema/frontend контур GREEN, qualification-only failures не должны останавливать дальнейшую разработку. Qualification-tail исправляется параллельно следующему staged functional scope. Это решение не разрешает destructive financial DROP/replay cleanup без CI foundation и не ослабляет P0 180-day barrier. Для текущего состояния: цикл `1774` остаётся qualification-tail, цикл `1775` открыт staged-параллельно.

## Текущая точка — кандидат v174.21 / цикл 1774, exact-head v174.20 CI repair + verification-integrity lock

- GitHub CI `86566046574` криптографически квалифицировал payload `v174.20`: checkout `f79e121b25638dc970ba779fd23c0b3b5047d751`, CI `efhc.zip` size `12947160` bytes и SHA-256 `54469a34839c3d57d54247611bd876f3f5bd43facce7bd21240d60c6795afd33` точно совпали с Development HEAD. SHA gate завершился `exit=0`.
- Green gates: Flake8 critical/full, Ruff `0.16.3`, Mypy `2.3.1` (`344 source files`), Bandit, compileall, PostgreSQL preflight, frozen Alembic `metadata_tables=52 / tables_in_schemas=53 / 0001: ok`, latest npm dependency installation.
- Pytest: `1 failed / 1638 passed / 22 skipped / 1 warning`. Единственный failure — stale architecture guard ожидал прежний non-relative TON alias `src/...`, тогда как TypeScript 7 repair требует `./src/...`.
- Frontend build: latest set включал `typescript@7.0.2` и `zod@4.4.3`; пять однопараметрических `z.record(...)` дали `TS2554`, а `BrowserShopCatalogItem.methods` дополнительно потерял требуемый value type. Candidate `v174.21` переводит эти пять records на явную форму `z.record(z.string(), valueSchema)` и синхронизирует generator source; runtime contract остаётся string-keyed record.
- Owner-approved внешний harness зафиксирован exact-файлом root `ci_github.yml`, SHA-256 `acf92728ab457e01b31895d1dbafaa5c6232a86f2ba58727d853a3d7329bf8a9`: Actions `@v7`, latest direct dependencies, fail-closed SHA-256 Development HEAD publication. Internal `ci.yml` / `.github/workflows/canon.yml` не изменяются.
- По прямому решению владельца введён owner-locked verification-integrity contract: перед каждым ответом повторно проверять все существенные данные по конечному источнику; перед handoff файла обязательно reopen exact final path -> verify -> SHA/size -> claim. Инцидент текущего чата с двукратной выдачей неверного `ci_github.yml` как якобы проверенного зафиксирован в `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md` и report `02339`.
- Financial runtime, P0 180-day barrier, BANK/ledger, identity, frozen `0001`, DB schema и API не менялись. Retention/partitioning остаются заблокированы до полного green exact-head CI `v174.21`.
- Immutable report: `02339`; цикл `1774` остаётся открытым.

### LOCK — verification integrity / final read-back

- Перед любым owner-facing ответом все существенные данные ответа повторно сверяются с exact final source; память и ранее заявленное состояние доказательством не являются.
- Перед передачей любого файла обязателен read-back exact конечного path после последней записи, затем structure/marker verification, SHA-256 и size.
- Для GitHub CI выводы делаются только после повторного чтения exact run/log + Gate Summary; для ZIP handoff — после финальной ZIP/content/mode qualification.
- Нарушение `write -> reopen -> verify -> hash/size -> claim -> handoff` является verification-integrity regression. Полный owner-locked contract и инцидент: `docs/chats/CURRENT_CHAT_VERIFICATION_RULES.md`.


## Текущая точка — кандидат v174.20 / цикл 1774, latest-dependency CI qualification repair

- GitHub CI `86563906491` проверил `v174.19`: checkout `c2a8539ee249d717885dc711cbc9062030f4698e`, CI `efhc.zip` size `12934781` bytes совпадает с Development HEAD. Этот run выполнен промежуточной версией внешнего harness без SHA-256 шага, поэтому криптографическая идентичность payload не утверждается.
- Owner-approved внешний GitHub Test harness переведён на `actions/checkout@v7`, `actions/setup-python@v7`, `actions/setup-node@v7`, `actions/upload-artifact@v7` и latest-dependency policy. В Development HEAD он зафиксирован как root `ci_github.yml`; SHA-256 файла `e62fe7a730c6b93c69edb7ca87cd9dbd41b5f7784eacf6629a9188c54e7e30ce`. Внутренние `ci.yml` и `.github/workflows/canon.yml` не изменяются и остаются byte-equal.
- Backend/security/schema qualification на latest Python dependencies green: Ruff, Mypy, Bandit, Flake8, compileall, PostgreSQL preflight, Alembic `52 ORM / 53 physical / 0001: ok`, pytest `1639 passed / 22 skipped / 1 warning`.
- Единственный red gate — frontend build. Latest npm installation дала `typescript@7.0.2`; TypeScript остановил `tsconfig.json` на `TS5102` (`baseUrl` удалён) и `TS5090` (non-relative `paths` target).
- Repair `v174.20` минимален: `frontend/tsconfig.json` больше не использует `baseUrl`, а `@tonconnect/ui-react` указывает на relative target `./src/lib/vendor/tonconnect-ui-react-compat.tsx`. Financial runtime, backend, frozen `0001`, ORM/API и P0 barrier не меняются.
- Окончательный `ci_github.yml` дополнительно пишет SHA-256 `efhc.zip` в лог, Step Summary и `ci_artifacts/03a_efhc_zip_sha256.txt`, поэтому следующий run сможет дать cryptographically exact payload qualification.
- Physical replay cleanup и monthly financial partitioning остаются заблокированы до полного green exact-head CI нового candidate. Report `02338`; цикл `1774` остаётся открытым.

## Текущая точка — кандидат v174.19 / цикл 1774, финальный qualification repair P0 barrier

- GitHub CI `86560117373` проверил `v174.18`: checkout `2ae3b139126e0a4cac8fbeb616a99d994f07dcf8`, CI archive size `12930868` bytes совпадает с Development HEAD; SHA-256 CI payload в логах не опубликован, поэтому криптографическая идентичность payload не утверждается.
- Все runtime/security/schema/frontend gates green. Pytest: `1 failed / 1638 passed / 22 skipped / 1 warning`.
- Единственный failure — устаревший `EXPECTED_SHA256` architecture-test для уже byte-equal `ci.yml` и `.github/workflows/canon.yml`. Фактический SHA обоих файлов: `3de3471dd25773fcb3060102541473e46f5d44fde008421d7dad31c61c889d96`.
- 180-day P0 barrier/replay qualification, deep frozen-schema/Alembic qualification, Ruff/Mypy/Bandit/Flake8 и frontend build в supplied CI failures не дали.
- Candidate `v174.19` меняет только canonical CI hash expectation и traceability/authority metadata. Financial runtime, frozen `0001`, ORM/API/frontend и retention semantics не меняются.
- Physical replay cleanup и monthly financial partitioning по-прежнему не активируются до полного green exact-head CI `v174.19`; static dependency contract шести approved history tables сохранён.
- Report `02337`; цикл `1774` остаётся открытым.

## Текущая точка — кандидат v174.18 / цикл 1774, qualification repair + partition preflight

- GitHub CI `86557392563` проверил `v174.17`: checkout `8e5dd9441f14e13d13ec27a4f62921f989dc0cc0`, CI archive size `12923471` bytes совпадает; SHA CI payload не опубликован, поэтому криптографическая идентичность payload не утверждается.
- Зелёные проверки: Ruff, Mypy, Bandit, Flake8, compileall, PostgreSQL preflight, frozen Alembic smoke `52/53/0001: ok`, npm/frontend. Pytest: `3 failed / 1636 passed / 22 skipped / 1 warning`.
- Три failures: workflow mirror mismatch в CI payload; одна историческая англоязычная строка `START_HERE.md`; deep physical comparator ошибочно ожидал CHECK для PostgreSQL native ENUM `admin_role`.
- Candidate `v174.18` не меняет financial runtime или frozen `0001`: workflow mirror в Development HEAD byte-equal, historical heading переведён, physical comparator исключает только type-bound pseudo-CHECK native ENUM и отдельно fail-closed сверяет PostgreSQL ENUM type + labels.
- P0 180-day barrier/replay suite в данном CI не дал failures; retention физически не сокращается до полного green exact-head CI.
- Выполнен static partition preflight шести утверждённых financial history tables: прямой `PARTITION BY created_at` требует переноса глобальной idempotency/replay authority из удаляемой history и month-aware referential integrity для `withdraw_requests ↔ withdraw_outcome_events`. Реализация остаётся заблокированной до green barrier qualification.
- Report `02336`; цикл `1774` открыт.

## Текущая точка — кандидат v174.17 / цикл 1774, P0 barrier qualification repair

- GitHub CI `86555575826` проверил `v174.16`: checkout `110423e7b2eaaa5a32f928c0cd1eef082edd610b`, CI archive size `12916932` bytes совпадает; SHA CI payload не опубликован.
- Green: Ruff, Mypy, Bandit, Flake8, compileall, PostgreSQL preflight, frozen Alembic smoke `52/53/0001: ok`, npm/frontend. Pytest: `8 failed / 1626 passed / 22 skipped / 1 warning`.
- Восемь failures сведены к четырём причинам: несинхронный `ci.yml`/`.github/workflows/canon.yml`; хрупкий static guard reconciliation; три watcher transport mocks со wall-clock/canonical-clock race; physical-parity comparator требовал отдельный UNIQUE, полностью совпадающий с composite PRIMARY KEY `wallet_connect_idempotency`.
- `v174.17` не меняет financial runtime или frozen `0001`: workflow mirrors синхронизированы; P0 static guard проверяет фактический двухслойный контур `time-check → acquire/claim → повторный require до INSERT`; PostgreSQL replay suite расширен negative evidence/replay tests; physical comparator сохраняет строгую проверку, но нормализует избыточный UNIQUE=PK.
- В canonical workflow добавлен отдельный `P0 financial execution barrier qualification` exit-gate. Retention/monthly partitions не сокращаются до green exact-head CI этого barrier. Report `02335`; цикл `1774` открыт.

## Текущая точка — кандидат v174.16 / цикл 1774, P0 barrier + Alembic hardening

- GitHub CI `86553398408` проверил `v174.15`: checkout `8e13dc8809592b4edd5a09827642118fd8eabe79`, CI archive size `12997543` bytes совпадает; SHA CI payload не опубликован.
- Green: Ruff, Mypy, Bandit, Flake8, compileall, PostgreSQL preflight, frozen Alembic `52/53/0001: ok`, npm/frontend. Pytest: `1 failed / 1620 passed / 22 skipped / 1 warning`.
- Единственный failure — test-only wall-clock/canonical-clock race до confirm-failure branch; production 180-day barrier не ослабляется.
- `v174.16`: добавлены строгие P0 boundary/rejuvenation/anomaly tests, real PostgreSQL tx_hash replay proof и full physical frozen-0001 qualification по tables/columns/types/PK/UNIQUE/FK/CHECK/indexes.
- Replay retention/monthly partitions не сокращаются до green exact-head CI этого усиленного barrier. Report `02334`; цикл `1774` открыт.

## Текущая точка — кандидат v174.15 / цикл 1774, qualification repair 180-day financial barrier

- GitHub CI `86550681430` проверил `v174.14`: checkout `064a5914079769648a00337747d8fe49b2ce8a69`, CI `efhc.zip` size `12900768` bytes совпадает с Development HEAD; SHA-256 CI payload в supplied logs не опубликован.
- Green gates: frozen Alembic/PostgreSQL `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`; Mypy, Bandit, Flake8 critical/full, compileall, PostgreSQL preflight, npm ci и frontend build PASS (`routes=33`, `manifest=40`).
- Красные проверки: Ruff — 1 нарушение порядка импортов; pytest — `11 failed / 1610 passed / 22 skipped / 1 warning`.
- Pytest failures сведены к трём подтверждённым причинам: watcher test mocks возвращали старый `None` вместо пары time-evidence; постоянный compatibility facade `wallets_service._confirm_payment_intent` не принимал новые optional `trusted_operation_at/server_first_seen_at`; два USDT success-path tests использовали заведомо истёкший Unix `utime=1`.
- Repair `v174.15`: compatibility facade принимает и передаёт time-evidence без breaking change старых callers; watcher/USDT tests используют свежую trusted time authority; Ruff import-order исправлен. Строгий `age >= 180 days -> EXPIRED / NO CREDIT` не ослаблен.
- Retention/partitioning в repair не включены: сначала требуется green exact-head CI barrier. Frozen `0001`, table surface `52 ORM / 53 physical`, OpenAPI `154/160/168`, frontend и destructive scope не меняются.
- Immutable report: `02333`. Цикл `1774` остаётся открытым; следующий verifier — exact-head GitHub CI `v174.15`.

## Текущая точка — кандидат v174.14 / staged циклы 1773+1774, 180-day external financial barrier

- `v174.13` остаётся qualification repair цикла `1773`; exact-head GitHub CI на него ещё не предоставлен. Последний CI `86541701491` проверял `v174.12`: frozen `0001` Alembic PASS `52 ORM / 53 physical / 0001: ok`, оставались три pytest policy/traceability failures, исправленные в `v174.13`.
- По прямому решению владельца цикл `1774` открыт как staged functional continuation: внешнее событие может впервые изменить EFHC только при `trusted age < 180 days`; `age >= 180 days` → `EXPIRED / NO CREDIT` до replay/idempotency и до денежной мутации.
- Двойная временная authority: `trusted_operation_at` из проверенного внешнего источника + сохранённый `server_first_seen_at`. Более новое first-seen не может «омолодить» старую операцию. Клиентское время authority не является.
- Watcher reprocess использует сохранённый `ton_inbox_logs.trusted_operation_at`, а не `created_at`/текущее время. Canonical PaymentIntent reconciliation, direct watcher settlement, materialized/Admin deposit recovery, tx-hash claim и external Shop Admin force-fulfill закрыты тем же barrier.
- В `v174.14` replay/idempotency retention **не сокращён** и monthly partitions ещё не включены. После green barrier целевой retention: external replay/tx-hash — 180 суток; detailed financial history — текущий месяц + 12 предыдущих месячных partitions, затем DROP.
- Утверждённые будущие financial partitions: `efhc_transfers_log`, `payment_intents`, `shop_orders`, `withdraw_requests`, `withdraw_outcome_events`, `ton_inbox_logs`. `users` balances и `BANK_EFHC` — FOREVER; unresolved `unmatched_incoming` не удаляется календарным DROP.
- Frozen `0001` остаётся единственной migration и сохраняет 52 application tables; добавлены только time-evidence columns. Static parity: `52/52`, `45 core + 7 admin`, column drift `0`, indexes `40/40`.
- Pre-retention schema checkpoint: `reports/generated/GREENFIELD_SCHEMA_CHECKPOINT_PRE_FINANCIAL_RETENTION_v174_13.json`; это immutable structural snapshot, не production-data dump.
- Immutable report: `02332`. Следующий verifier — exact-head GitHub CI `v174.14`; локальные execution tests/build/Alembic/PostgreSQL не запускать.

## Текущая точка — кандидат v174.13 / цикл 1773, qualification repair frozen 0001

- GitHub CI `86541701491` проверил `v174.12`: checkout `3df85f44ec41a394863d16fdcfb163e63ebfc881`, archive size `12962065` bytes совпадает; SHA CI payload не опубликован.
- Frozen `0001` Alembic PASS: `metadata_tables=52`, `tables_in_schemas=53`, `0001: ok`. Ruff/Mypy/Bandit/Flake8/compileall/PostgreSQL preflight/npm ci/frontend build также PASS.
- Единственный red gate — pytest: `3 failed / 1610 passed / 22 skipped / 1 warning`.
- Repair: exact-line identity disposition синхронизирован; provider portability gate переведён со stale `expected_tables()` на frozen `RELEASE_METADATA` contract. `0001`, runtime/API/ORM/schema semantics не менялись.
- Владелец утвердил frozen `RELEASE_METADATA` как окончательную форму `0001`.
- Immutable report: `02331`. Цикл `1773` остаётся открытым до нового exact-head GitHub CI.

## Текущая точка — кандидат v174.12 / цикл 1773, qualification repair frozen 0001

- GitHub CI `86540554973` проверил `v174.11`: checkout `552d87f7b9a6ce4fc55c34dfcefdedbecf60b614`, CI `efhc.zip` size `12865817` bytes совпадает с Development HEAD; SHA-256 CI payload в supplied logs не опубликован.
- Green gates: Mypy, Bandit, Flake8 critical/full, compileall, PostgreSQL preflight, npm ci и frontend build. Red gates: Alembic, pytest и Ruff.
- Alembic root cause подтверждён: frozen snapshot таблицы `scheduler_task_log` потерял все 11 колонок, потому что static freeze/comparator учитывал `mapped_column(...)`, но не legacy `Column(...)`. В результате FK на `global_id` создавался до самой колонки и migration падала с `ConstraintColumnNotFoundError`.
- Repair восстанавливает в frozen `0001` точный column surface `scheduler_task_log` и расширяет static comparator на `mapped_column` + `Column`; после repair статический parity: `52/52` таблицы, zero column drift, `45 core + 7 admin`, `40/40` module-level indexes.
- Ruff `SIM102` в `ops/routes/compare_orm_0001.py` исправлен без изменения contract.
- Runtime backend/frontend/API, ORM-модели, identity/economy semantics и target physical schema не меняются. Цикл `1773` остаётся открытым до нового exact-head GitHub CI.
- Owner decisions зафиксированы: XLSX разрешено реализовать через `openpyxl`; expired/revoked auth sessions retention — 14 дней; admin/security audit online retention — 3 года. Формат final `0001` и partition granularity пока ожидают решения владельца.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.
- Immutable report: `02330`.

## Текущая точка — v174.10 traceability handoff / цикл 1772 закрыт

- GitHub CI `86531880820` полностью квалифицировал `v174.09`: checkout `b86090d52a3e41da7d8fb3c33030dcdc01a3eec3`, CI `efhc.zip` size `12843832` bytes совпадает с Development HEAD; SHA-256 CI payload в supplied logs не опубликован, поэтому криптографическая идентичность payload отдельно не заявляется.
- Все canonical gates завершились `exit=0`: pytest `1613 passed / 22 skipped / 1 warning`; Ruff, Mypy, Bandit, Flake8 critical/full, compileall, PostgreSQL preflight, npm ci и frontend build — PASS.
- Clean Greenfield schema подтверждена full exact-head CI: `metadata_tables=52`, `tables_in_schemas=53`, `create_all_done`, `0001: ok`. Текущий physical owner — `users.global_id`; retired `users.id/tg_id/ton_wallet`, `panels_archive` и три `ranks_*` не возвращались.
- HTTP/OpenAPI surface остаётся `154 paths / 160 public operations / 168 schemas`; referral economy и public `/panels/archive` сохранены.
- `v174.10` не содержит runtime/schema/frontend изменений относительно green `v174.09` и является только traceability handoff. Цикл `1772` закрыт; следующий функциональный цикл — `1773`.
- Qualification report: `02328`; следующий numbered report — `02329`. Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.08 / цикл 1772, qualification repair clean 0001

- GitHub CI `86520558176` проверил `v174.07`: checkout `abe9436858581b5be08cdfbffcb2100123e798a1`, CI `efhc.zip` size `12827456` bytes совпадает с Development HEAD. SHA-256 CI payload в supplied logs не опубликован.
- Green gates: Mypy, Bandit, Flake8 critical/full, compileall, PostgreSQL preflight, npm ci, frontend build. Red gates: Alembic, Ruff, pytest.
- Alembic root cause: clean `0001` ошибочно требовал retired metadata-name `uq_payment_intents_idempo`, хотя canonical payment-intent ownership уже использует `uq_payment_intents_global_idempo`. Из-за rollback clean schema не создавалась, что каскадно породило PostgreSQL pytest failures/errors.
- Ruff: 3 import-format violations и 1 `SIM300`; исправлены без изменения runtime semantics.
- Независимые pytest drifts после owner-approved physical retirement: 8 architecture/contract guards всё ещё ожидали legacy `users.tg_id/ton_wallet`, historical read-through count, старый provider collision marker или старый TON machine contract. Guards синхронизированы с `user_identities`/`wallet_bindings`/physical `global_id`; retired columns не возвращались.
- HTTP surface, 52-table target, owner-approved retirements, 13 P0 BIGINT targets, referral economy и public `/panels/archive` не менялись. Цикл `1772` остаётся открытым до нового exact-head GitHub CI.
- Candidate `v174.08`; report `02326`; следующий numbered report — `02327`. Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.07 / циклы 1768–1772, Greenfield identity/schema consolidation

- Green parent `v174.06` квалифицирован GitHub CI `86497534419`: checkout `8e762d5df1c757bf56f840072cbb5ea2884a0605`, CI `efhc.zip` size `12808308` bytes совпадает с Development HEAD; все canonical gates `exit=0`; pytest `1612 passed / 22 skipped / 1 warning`; Alembic `metadata_tables=56`, `0001: ok`; frontend build PASS. SHA-256 CI payload не опубликован.
- Цикл `1767` закрыт. По прямому owner approval выполнены только разрешённые retirements: отдельная `panels_archive`; три legacy `ranks_*` tables; два referral leaderboard routes/UI; `users.id`, `users.tg_id`, `users.ton_wallet` после перевода consumers. Referral economy и public `/panels/archive` сохранены.
- `users.global_id` теперь физический `BIGINT PRIMARY KEY` и единственный user/account owner. Provider identities находятся в `user_identities`, TON ownership — в active verified `wallet_bindings`. Current ranking хранится в `users.rank_position/rank_score_kwh/rank_calculated_at`.
- Все 13 сохраняемых P0 lifetime-ID targets Greenfield V8 объявлены `BIGINT` в ORM/clean initial schema; bounded Skin/catalog/counter/provider identifiers не переводятся механически. До exact-head PostgreSQL/Alembic CI это static physical candidate.
- Единственный `0001_initial_release_schema.py` переписан как clean ORM-driven initial schema первого production launch. Это не in-place migration уже применённой БД. `0002+` не создавалась.
- Static candidate surface: `52 ORM tables`; OpenAPI `154 paths / 160 public operations / 168 schemas`; hidden operations `8`, ожидаемый mounted surface `168`. Эти значения ещё не квалифицированы GitHub CI.
- Candidate `v174.07` находится в цикле `1772`; следующий numbered report после серии — `02326`. Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.06 / цикл 1767, daily ranking semantics

- GitHub CI `86487945415` полностью квалифицировал `v174.05`: checkout `8ebf2eb764236fea37748b6dd7b1c36d32ac3a57`, CI `efhc.zip` size `12798170` bytes совпадает с Development HEAD; все canonical gates `exit=0`; pytest `1611 passed / 22 skipped / 1 warning`; Alembic `metadata_tables=56`, `0001: ok`; frontend build PASS. SHA-256 CI payload в logs не опубликован.
- Цикл `1766` закрыт. Schema reconciliation подтвердил, что destructive rewrite `0001` нельзя делать механически по partial target DDL; отдельные удаления остаются под owner lock.
- Цикл `1767` внедряет недеструктивную часть Greenfield Ranking: persistent DB claim `ranks.last_daily_claim_date`, business boundary `02:00 UTC`, canonical `DENSE_RANK` по `users.total_generated_kwh`, только active users.
- Public kWh ranking reads больше не запускают global refresh по `force_refresh/max_age_minutes`; compatibility query parameters сохраняются, но read-path читает сохранённый snapshot. Initial/live fallback не создаёт DB snapshot.
- Canonical rank rows читаются из `ranks_snapshots`, где ties допустимы. `ranks_top_cache` не удалён и сохраняется как compatibility storage с уникальным ordinal position, потому что его current schema запрещает duplicate `rank_position`.
- DB schema, ORM tables/columns/FK, Alembic `0001`, HTTP routes и frontend не меняются. Полный schema-wide 64-bit cutover ещё не заявляется: `global_id` уже BIGINT и wire lifetime IDs decimal-string, но current `0001` всё ещё содержит technical INTEGER PK.
- Candidate `v174.06` требует exact-head GitHub CI. Следующий numbered report после cycle report `02319` — `02320`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.05 / цикл 1766, Greenfield schema reconciliation

- GitHub CI `86473947926` полностью квалифицировал `v174.04`: checkout `606bbc2afbf661a141821edaefafbf4d17f491b5`, CI `efhc.zip` size `12787577` bytes совпадает с Development HEAD; все canonical gates `exit=0`; pytest `1611 passed / 22 skipped / 1 warning`; Alembic `metadata_tables=56`, `0001: ok`; frontend build PASS. SHA-256 CI payload в logs не опубликован.
- Цикл `1765` закрыт. Lifetime PostgreSQL IDs квалифицированы как decimal strings на JSON/OpenAPI/frontend boundary при внутреннем backend `int/BIGINT`.
- Цикл `1766` выполнил только static Greenfield schema reconciliation. Current baseline: `56 ORM tables = 49 core + 7 admin`; supplied `001_TARGET_GREENFIELD_SCHEMA.sql` содержит только `13 CREATE TABLE` и не является полным replacement manifest.
- Подтверждены blockers для механического rewrite: target DDL не содержит `efhc_admin`, не создаёт требуемые ranking fields в `users`, а `transfer_annotations.transfer_id` не имеет referential FK model к partitioned ledger. Current `tx_hash_locks` уже является permanent global tx replay authority, поэтому параллельный replay registry не создаётся автоматически.
- Ни одна table/column/FK/route не удалена и не добавлена; ORM и `0001_initial_release_schema.py` не менялись. Active DB SSOT factual count исправлен `55→56` по green CI evidence.
- Для следующего destructive schema stage требуется отдельное owner `удалять` по конкретным compatibility objects. Candidate `v174.05` требует новый exact-head GitHub CI. Следующий numbered report — `02318`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.04 / цикл 1765, qualification repair lifetime-ID boundary

- GitHub CI `86468008605` проверил `v174.03`: checkout `22a774ef4ea7dcefe6aebb9978f9eb7951c6c551`; CI `efhc.zip` size `12781309` bytes совпадает с Development HEAD. SHA-256 CI payload в supplied logs не опубликован, поэтому криптографическая идентичность payload не заявляется.
- Green gates: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, npm ci, PostgreSQL preflight. Alembic: `metadata_tables=56`, `0001: ok`. Red gates: Ruff, Mypy, pytest и frontend build. Pytest: `1 failed / 1610 passed / 22 skipped / 1 warning`.
- Подтверждённые причины относятся к незавершённому lifetime-ID cutover: два import-order нарушения, три Mypy `no-any-return`, stale pytest expectation numeric withdrawal ID и девять TypeScript несовместимостей `DbId`/`number`. Исправления сохраняют canonical decimal-string API boundary и не возвращают JavaScript `Number` для PostgreSQL lifetime IDs.
- Локальный worker request ID возвращён к `number`, потому что это transient UI correlation ID, а не DB lifetime identifier. Дополнительно синхронизирован `sync.meta.fallback_task_id`, который backend уже объявляет `ApiLifetimeId`.
- HTTP routes, DB tables/columns/FK и Alembic не менялись; `0001_initial_release_schema.py` остаётся byte-exact. Цикл `1765` остаётся открытым до green exact-head GitHub CI candidate `v174.04`. Следующий numbered report — `02316`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.03 / цикл 1765, lifetime-ID decimal-string boundary

- GitHub CI `86429486220` полностью квалифицировал входной `v174.02`: checkout `b58fac81b13920ac3b426e350f4e81383b079e38`, CI `efhc.zip` size `12765836` bytes совпадает с Development HEAD; все canonical gates `exit=0`; pytest `1607 passed / 22 skipped / 1 warning`; Alembic `metadata_tables=56`; frontend build `PASS`. SHA-256 CI payload в supplied logs не опубликован, поэтому криптографическая идентичность payload не заявляется.
- Цикл `1764` закрыт по supplied green evidence. Функциональный цикл `1765` реализует согласованный `GREENFIELD_CANON`: PostgreSQL lifetime IDs остаются Python `int` внутри backend, а JSON/OpenAPI canonical representation становится decimal string. Legacy positive safe/integer input временно принимается для backward-compatible перехода.
- Frontend использует branded `DbId` и Zod decoder с legacy safe-integer fallback; преобразование lifetime ID через JavaScript `Number` запрещено. Telegram provider IDs и bounded Skin IDs остаются числовыми и не смешиваются с DB lifetime identifiers.
- HTTP route counts, DB tables/columns/FK и Alembic не меняются; `0001_initial_release_schema.py` должен оставаться byte-exact. Destructive cleanup не выполняется.
- Candidate `v174.03` требует следующий exact-head GitHub CI. Следующий numbered report после cycle report `02314` — `02315`.

## Текущая точка — кандидат v174.02 / цикл 1764, исправление language-policy после CI v174.01

- GitHub CI `86427265753` проверил `v174.01`: checkout `0887fa97092346608aaa87326cdd5068cd87b772`; CI `efhc.zip` имеет размер `12760212` bytes, совпадающий с Development HEAD. SHA-256 CI payload в логах не опубликован, поэтому криптографическая идентичность payload не заявляется.
- Все canonical gates, кроме pytest, завершились с `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, npm ci/build, PostgreSQL preflight и Ruff. Alembic: `metadata_tables=56`, `0001: ok`; frontend build: `PASS`, `routes=33`, `manifest=40`.
- Pytest: `1 failed / 1606 passed / 22 skipped / 1 warning`. Единственная причина — architecture guard русскоязычной инженерной документации обнаружил три английские narrative-строки в `CONTINUE_IN_NEW_CHAT.md`, `KERNEL.md` и `START_HERE.md`.
- Исправлены только эти три подтверждённые строки и обязательная qualification/release traceability. Runtime/backend/frontend business code, HTTP surface, DB schema, migration `0001`, ledger/identity, Ads, Browser Shop и Greenfield V8 решения не менялись.
- Candidate `v174.02` остаётся в цикле `1764` до следующего green exact-head GitHub CI. После green qualification следующий функциональный цикл — `1765`, и работа по `GREENFIELD_CANON.md` продолжается staged-этапами. Следующий numbered report после этого repair — `02313`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.01 / цикл 1764 qualification repair после CI v174.00

- GitHub CI `86423645892` проверил `v174.00`: checkout `ab4b4c8a0bc33b0cd68448931ef8d882364a9ca0`, CI `efhc.zip` size `12754836` bytes совпал с Development HEAD; SHA-256 CI payload в логах не опубликован.
- Green: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, npm ci. Alembic: `metadata_tables=56`, `0001: ok`. Red: Ruff `1`, Mypy `5`, pytest `3 failed / 1604 passed / 22 skipped / 1 warning`, frontend build.
- Исправлены только подтверждённые причины: формат import в NFT service; typed casts на новых ApplicationClock/VIP seams; active SSOT получил стабильное имя `docs/SSOT/GREENFIELD_CANON.md`; новые test names приведены к русскоязычной engineering policy; stale core-math guard синхронизирован с ApplicationClock; frontend `performance.now()` квантуется через `Math.floor` перед `BigInt`.
- Owner-approved Greenfield runtime решения не откатывались. HTTP surface, DB schema, Alembic `0001`, identity owner, ledger/Ads/Browser Shop/backup policy не менялись.
- Текущий qualification candidate: `v174.01`, цикл `1764` остаётся открытым до green exact-head CI. Следующий функциональный цикл после qualification — `1765`; следующий numbered report после этого repair — `02312`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались.

## Текущая точка — кандидат v174.00 / циклы 1758–1764 — Greenfield V8 staged implementation

- Green exact-head parent: `v173.99`, local SHA-256 `c69fce6e5557a14013498721b3827986d63ca537ae56b82458a6c636078b2a8b`, size `12728258`; GitHub CI `86407754528`, checkout `84850d6ef9cdb48ac35cfdc82e58c442c8e12aba`, все canonical gates `exit=0`, pytest `1601 passed / 22 skipped / 1 warning`, Alembic `metadata_tables=56`, `0001: ok`, frontend build PASS. SHA CI payload не опубликован.
- Цикл `1757` закрыт green. Greenfield V8 source audit SHA-256 `fd62eedaa68bb69b0aa3f4ec7e0e1549b6bb16a4088468dd8146ce2bb7f27d09` принят как owner-approved target; active repository CANON: `docs/SSOT/GREENFIELD_CANON.md`.
- Выполнено семь staged cycles `1758–1764`: monotonic ApplicationClock/frontend elapsed clock; explicit wallet physical detach + 24h proof/7d connect windows; BASE↔VIP checkpoint-before-flag; expired panel non-reactivation + serialized active ceiling; History feasibility без ложного `50+50+50`; regression guards; независимый V8 audit.
- HTTP surface не менялся: `156 paths / 162 public operations / 168 schemas / 8 hidden / 170 mounted`. ORM tables остаются `56`, canonical `users.global_id` FK floor `42`, Alembic только `0001_initial_release_schema.py`.
- Не выполнены и не выдаются за выполненные: BIGINT/string wire cutover, rewrite `0001`, ranking current-only storage/job 02:00 UTC, unified 50-logical History + CSV/XLSX, destructive ranking/archive cleanup, Admin user-centric BANK transfer + paid panel activation, physical sharding.
- `v174.00` — candidate, а не green release. Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались. Следующий verifier — exact-head GitHub CI; после qualification следующий функциональный цикл `1765`, следующий report `02311`.

## Текущая точка — кандидат v173.99 / цикл 1757 continuation — CI repair после v173.98

- Входной кандидат: `EFHC_Bot_v173_98.zip`, локальный SHA-256 `da5feb3afde4f72c674049825d70613292a27c7e5d25a028da228822e2e549d5`, размер `12723179` bytes, `4628` ZIP entries.
- GitHub CI `86400509670`: checkout `e28406f410689a9aaf3f7351aaead784cbfe0e23`; CI `efhc.zip` имеет тот же размер `12723179` bytes. SHA-256 CI payload в логах не опубликован, поэтому криптографическая идентичность не утверждается.
- Все supplied canonical gates, кроме pytest, green. Alembic: `metadata_tables=56`, `0001: ok`. Frontend release-assets `PASS` (`files=29`), build verify `PASS` (`routes=33`, `manifest=40`). Pytest: `2 failed / 1599 passed / 22 skipped / 1 warning`.
- Подтверждённые причины pytest только metadata/traceability: numbered work-pass narrative в `backend/openapi/openapi_manifest.json`; mismatch `docs/testing/TEST_GUARD_MANIFEST.json` против `reports/current/IDENTITY_MIGRATION_STATE_CURRENT.json`. Runtime/backend/frontend/DB behavior этими failures не опровергнут, но весь HEAD не квалифицирован green.
- Исправление ограничено этими двумя CI causes и обязательной release/report traceability: OpenAPI counts/routes не меняются; identity semantics не меняются; current cycle остаётся `1757`.
- FRONTEND_v118 остаётся внедрённым normal source authority; внешних `.patch`, `.diff` и patch-package ZIP в рабочем HEAD нет. Offline Demo не возвращён.
- Root candidate после repair: `v173.99`. Локальные execution tests/build/Alembic/PostgreSQL не запускались; требуется новый exact-head GitHub CI.

## Текущая точка — кандидат v173.98 / цикл 1757 — owner-approved FRONTEND_v118 integration

- Входной Development HEAD: `EFHC_Bot_v173_97.zip`, SHA-256 `a5500c166cad30049de0aa197913e87b740affcaa0588f015a1d763fcf726e15`, размер `12697182` bytes, `4623` ZIP entries. Функциональный parent `v173.96` остаётся последним green exact-head CI (`86315641419`, checkout `dfcd2f31f423fae550991941313f843cef0a3e59`).
- Новый frontend patch квалифицирован против exact `v173.97`: patch SHA-256 `1b79c323d1c867c57b609961566d17920fb351723004e7613218f8ecc1151400`, patch ZIP SHA-256 `0db32761aba2eaf62666e278cc988a86eb5ca19e80dc8827d48d24902068e59e`, `30` changed paths, `backend_files_changed=0`; embedded patch и отдельный patch byte-identical.
- По прямому решению владельца FRONTEND_v118 внедрён в normal source. Основное изменение — банковский History operation center с balance/exchange/withdraw data; 13 locales синхронизированы. Existing API surfaces `/wallets/balance-history`, `/exchange/history`, `/withdraw/list/me` переиспользуются; новых backend routes нет.
- Hard delete/function-union lock соблюдён: `matchHistoryFilter` не удалён, а сохранён как nonvisual helper и переиспользован; `BalanceHistoryList.tsx` и `WithdrawHistoryList.tsx` остаются в repository. Owner-approved видимый ProfileModal surface применяется как в patch; underlying `hide_balances` setting/model и locale keys не удалены.
- Offline Demo/Simulation не перенесён. Current Ads `/ads/session*`/AdManager/provider runtime, Browser Shop security handoff, money/ledger/identity, PostgreSQL schema и Alembic не менялись.
- В рабочем HEAD после merge нет внешних `.patch`, `.diff` или patch-package ZIP; normal source и `FRONTEND_AUTHORITY_MANIFEST.json` являются authority. PWA build id и release-assets manifest пересчитаны статически из итогового frontend source; root `VERSION=v173.98`.
- Static verification: исходные patch base hashes `30/30` совпали, initial patched hashes `30/30` совпали с patch manifest; после nonvisual function-union authority hashes пересинхронизированы. JSON parsing, file-set/API literal compare и patch absence выполнены статически.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/npm build/Next build/Alembic/PostgreSQL не запускались. Candidate `v173.98` требует следующий exact-head GitHub CI; цикл `1757` остаётся открытым до qualification.

## Текущая точка — v173.97 traceability handoff / цикл 1756 квалифицирован exact-head CI v173.96

- Входной HEAD: `EFHC_Bot_v173_96.zip`, SHA-256 `25db5983d2980e7cd74bec4cf4f95add8a5dd0e9e316e2b00bf942aac4e2a39d`, размер `12690851` bytes, `4622` ZIP entries.
- Exact-head GitHub CI `86315641419`: checkout `dfcd2f31f423fae550991941313f843cef0a3e59`; CI `efhc.zip` имеет тот же размер `12690851` bytes. SHA-256 CI payload в логах не опубликован, поэтому криптографическое равенство отдельно не утверждается.
- Все canonical gates завершились с `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, npm ci/build, pytest и Ruff. Pytest: `1601 passed / 22 skipped / 1 warning`. Frontend: release assets `PASS` (`files=29`), build verify `PASS` (`routes=33`, `manifest=40`).
- Подтверждённых CI root causes для исправления нет. PostgreSQL duplicate/check-constraint записи в shutdown log относятся к negative-path тестовым сценариям и не классифицируются как production defect при полностью green pytest/gates.
- Цикл `1756` квалифицирован. Runtime/backend/frontend/DB/migrations этой qualification-итерацией не менялись.
- В рабочем HEAD нет `.patch`, `.diff` или patch-package ZIP. `ops/operator_kernel/patch_planner.py` — штатный инструмент Operator Kernel, а не patch payload. После принятия patch интегрированный normal source остаётся единственным active authority.
- `v173.97` создаётся только для фиксации qualification/report history. Как новый архив он требует exact-head GitHub CI, если будет использоваться как HEAD. Следующий плановый функциональный цикл — `1757`, готовый к новым аудитам и patch-входам по действующим owner rules.

## Текущая точка — кандидат v173.96 / цикл 1756 continuation — exact-head CI v173.95

- Входной HEAD: `EFHC_Bot_v173_95.zip`, SHA-256 `5c48f1ff731aa91420a293ad5870b402d557f583680a7d4b8838232213aa0da5`, размер `12685846` bytes, `4621` ZIP entries.
- Exact-head GitHub CI `86309553724`: checkout `12067b1bfd9a80fb78ed8053194c4d8b6c2b7259`; CI `efhc.zip` имеет тот же размер `12685846` bytes. SHA-256 CI payload в логах не опубликован.
- Pytest полностью green: `1601 passed / 22 skipped / 1 warning`. Единственный failed gate — frontend build (`exit=2`) с двумя TypeScript errors.
- Подтверждённые исправления: из `DepositModal` удалён stale обязательный `tg_id` prop, который не использовался после global_id Direct Deposit cutover; в `AdminPage` option `placement` исправлен на действующий `dotsPlacement`.
- Маршруты, backend business runtime, Ads, Offline Demo policy, PostgreSQL schema и Alembic не менялись этой итерацией. Работа с внешними patch-артефактами остаётся закрытой: active authority — интегрированный normal source.
- Локальные pytest/Ruff/Mypy/Flake8/Bandit/npm build/Alembic/PostgreSQL не запускались. Candidate `v173.96` требует следующий exact-head GitHub CI.
- До green qualification продолжается цикл `1756`; следующий плановый цикл после qualification — `1757`.

## Текущая точка — кандидат v173.95 / цикл 1756 continuation — exact-head CI v173.94

- Входной HEAD: `EFHC_Bot_v173_94.zip`, SHA-256 `91545d75f6bc04692f3c1a1be52b969aaf9df6b0990cc83d8817d7d49d042789`, размер `12768003` bytes, `4620` ZIP entries.
- Exact-head GitHub CI `86301791487`: checkout `9bef846bb1a4e71f91215cdccbfe4c2e44898812`; CI `efhc.zip` имеет тот же размер `12768003` bytes. SHA-256 CI payload в логах не опубликован.
- Failing gates: pytest и frontend build. Pytest: `4 failed / 1597 passed / 22 skipped / 1 warning`. Frontend build завершился на prebuild release-assets verification с checksum mismatch `.efhc-build-id`.
- Подтверждённые причины исправлены адресно: textual numbered-cycle marker удалён из OpenAPI manifest; source-only frontend authority wording синхронизирован; исправлены 13 новых нарушений русскоязычной инженерной нормы; `current_cycle` синхронизирован на `1756`; release-assets manifest получил актуальные checksums `.efhc-build-id` и `public/pwa-build.json`.
- Owner decision по patch завершён: внешний patch — только временный вход для интеграции; после merge он удаляется из рабочего HEAD. Current integrated normal source остаётся единственным frontend visual/text authority.
- Offline Demo/Simulation остаётся удалённым из main application. Основной Ads runtime остаётся прежним; в этой continuation-итерации Ads/backend/DB/business runtime не менялись.
- Локальные pytest/Ruff/Mypy/Flake8/Bandit/npm build/Alembic/PostgreSQL не запускались. Candidate `v173.95` требует следующий exact-head GitHub CI.
- До green qualification продолжается цикл `1756`; следующий плановый цикл после qualification — `1757`.

## Текущая точка — кандидат v173.94 / цикл 1756 — Offline Demo удалён, frontend authority перенесён в normal source

- Input HEAD: `EFHC_Bot_v173_93.zip`, SHA-256 `81863f98d3a035bce16680a87939a5c4474b183481c7968b389560c1876c02a1`, entries `4632`.
- Новые exact-head GitHub CI logs для `v173.93` в текущем задании не предоставлены; новых CI failures не выдумывать и green qualification `v173.93` не заявлять.
- По прямому owner decision Offline Demo/Simulation удалён из main application: нет `?demo=1`, fake auth/API, simulation bridge, demo PWA cache или `dev-workbench`.
- Ads main runtime сохраняется как до frontend patch; simulation layer больше не может подменять Ads/API.
- Принятый frontend patch больше не является active artifact/authority: текущий approved normal source и `FRONTEND_AUTHORITY_MANIFEST.json` являются единственным visual/text source authority.
- DB/backend route/economy schema не менялись: OpenAPI `156/162/168`, hidden `8`, mounted `170`, ORM `56`, Alembic только `0001`, global_id FK floor `42`.
- Static test inventory: `274 architecture / 454 Python files`. Локальные execution tests/build/Alembic/PostgreSQL не запускались.
- Candidate `v173.94` требует следующий exact-head GitHub CI.

## Текущая точка — кандидат v173.93 / цикл 1755 continuation — exact-head CI v173.92 + owner-approved FRONTEND_v113 integration

- Input `EFHC_Bot_v173_92.zip`: SHA-256 `d250add0ed72e168863147c68abae48adb56895aeecac786a05841bbb2246dcf`, size `12646696`, entries `4612`.
- Exact-head CI `86149216397`: checkout `b7102d843a36a227c70a03d7c7e45a94941fcd70`, CI archive size `12646696`; SHA-256 CI ZIP в logs не опубликован. Все supplied gates, кроме pytest, green; pytest `2 failed / 1594 passed / 22 skipped / 1 warning`. Оба failures — только numbered test filename hygiene.
- CI correction: `test_security_cycle1755_contract.py` переименован в timeless `test_security_handoff_health_contract.py`; security behavior не изменён.
- Владелец полностью утвердил visual/text/language supplied `FRONTEND_v113_TO_v173_92` patch. SHA-256 patch `40a9fa4b49ea7aa6158e51711a0ab30559ee97e50031e9729362bc8bf7b25c64`. Patch интегрирован прямо в normal source; runtime overlay отсутствует.
- Function-union сохраняет current v173.92 backend/security/economy и Ads `/ads/session*` provider runtime. Внутренне противоречивое удаление используемых `tasks.ad_*` locale keys не принято: 13 current Ads runtime keys сохранены во всех 13 locales, чтобы текущий Tasks flow не показывал raw i18n keys. Остальные owner-approved языковые изменения применены.
- Direct Deposit metadata синхронизирована с canonical owner: `memo_binding=global_id`, memo `EFHC:GID:<global_id>`; monetary flow/schema не менялись.
- Owner-approved frontend patch retires только два старых Energy Dashboard visual components; backend Energy/economy не менялся.
- Offline Demo/Simulation из patch интегрирован без самостоятельного изменения policy. Возможность `?demo=1` на production domain остаётся OWNER_DECISION_PENDING и не считается production-qualified решением. `dev-workbench` остаётся gated/default-404 development surface.
- Factual application floor: protected `355/66/81`; OpenAPI `156/162/168`; hidden `8`; mounted `170`; production frontend pages `39`; ORM `56`; global_id FK floor `42`; Alembic только `0001`; static tests `274 architecture / 454 Python files`.
- Immutable report: `reports/numbered/reports_02296__cycle_1755_frontend_v113_integration_exact_head_ci_v173_92.md`, SHA-256 `6decfdbe9f54b76972aa2dde5dc9a4f306d8f6aefa3ed2cec03b890d57c1de6f`.
- Локальные pytest/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/PostgreSQL не запускались. Candidate `v173.93` требует exact-head GitHub CI. При failures продолжается цикл `1755`; после green qualification следующий numbered cycle — `1756`.

## Текущая точка — кандидат v173.92 / цикл 1755 — security policy + Browser Shop handoff + health hardening

- Input `EFHC_Bot_v173_91.zip`: SHA-256 `a509d7fad9f6723c0ddcf24471f53b85bef2d47afe565d8a83d6636dc9819143`, size `12629257`, entries `4610`.
- Exact-head CI `86137836409`: checkout `ac8eac684549a53929883b077ac2a41c28365687`, CI archive size `12629257`; SHA-256 input ZIP в логах не опубликован. Все canonical gates green; pytest `1593 passed / 22 skipped / 1 warning`. Цикл `1754` квалифицирован.
- Цикл `1755` рассматривает supplied Codex Security audit без удаления/восстановления routes/functions/tables. `SECURITY.md` синхронизирован с active Admin NFT CANON; обычный VIP NFT не даёт Admin, special Admin NFT остаётся вторым canonical credential после server-side session.
- Browser Shop: новые handoff links используют URL fragment, current read API — `X-EFHC-Handoff`; legacy query token остаётся только backward-compatible input. Telegram preview tokenized link выключен. Полный one-time exchange НЕ заявлен реализованным и требует отдельного owner review.
- Health routes сохранены: `/meta/health_db` — strict DB 503 probe; `/api/health/db-schema` — DevOps schema 503 probe; detailed `/api/health/runtime` защищён Admin/metrics gate; raw DB exceptions наружу не выдаются.
- Owner rules: никаких deletions без понятного объяснения и явного подтверждения; DB schema freeze — новые tables/columns/FK/migrations только после owner review; accepted frontend patch интегрируется в обычный source, а patch artifact остаётся provenance/visual authority, не runtime overlay.
- Application floor без удаления: protected `355/66/81`; OpenAPI `156/162/168`; hidden `8`; mounted `170`; frontend pages `39`; ORM `56`; Alembic только `0001`.
- Immutable report: `reports/numbered/reports_02295__cycle_1755_security_policy_handoff_health_hardening.md`, SHA-256 `745b01e867eecfa95a18be2035722862d42fa9b97ea0aa7da565de1037c504ab`.
- Локальные execution tests/lint/type/build/Alembic/PostgreSQL не запускались. Candidate `v173.92` требует exact-head GitHub CI.

## Текущая точка — кандидат v173.91 / цикл 1754 continuation — CI repair + полный change-authority audit

- Input `EFHC_Bot_v173_90.zip`: SHA-256 `7a0980b886d43a49eb77efba782bca624d88af350252669d334d783ae2c34e84`, size `12606599`, entries `4609`, ZIP integrity clean.
- Exact-head CI `86127461152`: checkout `25ddf1b8f7f56c7486dcfda9c61ee55aa67e7c8b`, CI archive size `12606599`; SHA-256 CI payload не опубликован. Failed gates: Ruff (`1 I001`) и pytest (`3 failed / 1590 passed / 22 skipped / 1 warning`).
- Исправления строго по логам и без удаления/восстановления runtime surfaces: import-order `main.py`, два exact identity line pointers, один русскоязычный historical text drift и stale Tasks guard, который теперь проверяет отсутствие использования compatibility Ads helpers активным Tasks-контуром, а не их физическое отсутствие.
- Проведён полный статический аудит `v173.85 -> v173.90`: migration `0001` неизменна; ORM `56` (`49 core + 7 admin`); OpenAPI `156/162/168`, hidden `8`, mounted `170`; protected `355/66/81`; frontend protected pages `39`; весь `frontend/src` в `v173.90` byte-identical `v173.87`; PATCH_002 EXACT_PATCH `131/131` без mismatch.
- Никаких новых delete/restore решений по результатам аудита не применено. Все спорные routes/CANON/backend/frontend/DevOps вопросы вынесены владельцу: ровно 10 вопросов находятся в immutable report 02294.
- Immutable report: `reports/numbered/reports_02294__cycle_1754_exact_head_ci_v173_90_full_change_audit.md`, SHA-256 `49d07daed4bc8b44822ce7573da5fb6c832be7eda9292a5cfac0f1041ebdf5fd`.
- Candidate `v173.91` требует exact-head GitHub CI; cycle `1755` не начинается до green qualification.

## Текущая точка — кандидат v173.90 / цикл 1754 continuation — compatibility restore

- Immutable report: `reports/numbered/reports_02293__cycle_1754_exact_head_ci_v173_89_compatibility_restore.md`, SHA-256 `30d9ab73b46879c2e9e5823086f3813a34ea2ee21330d197cf96d0f7c3127ba7`.
- Exact-head CI `86118458343` для `v173.89`: checkout `36e45906efb6ac9cdf21bc4200bc498506bac234`, archive size `12595048`; единственный failed gate — pytest `1 failed / 1590 passed / 22 skipped / 1 warning`, root cause PATCH_002 hash drift `adminRouteCatalog.ts`.
- По прямому owner decision восстановлены `GET /meta/health_db` (503 при DB failure), `GET /health/db-schema`, fail-closed `POST /skins/buy/{skin_id}` и 4 hidden `/hub/browser-shop-*` compatibility aliases. Repository no-caller search не является достаточным public delete-proof.
- Surface возвращён к `156/162/168`, hidden `8`, mounted `170`; protected `355/66/81`, frontend `39`, ORM `56`, Alembic только `0001`.
- Telegram database backup остаётся удалённым по отдельному owner decision; local encrypted newest-10 + SSH/SFTP export на ПК/смартфон.
- Новый candidate `v173.90` требует exact-head GitHub CI; cycle `1755` не начат.

## Текущая точка — кандидат v173.89 / цикл 1754 continuation — exact-head CI v173.88 burn-down

- Входной Development HEAD `EFHC_Bot_v173_88.zip`: SHA-256 `30051ae09aed848df643ff99dc9f08e9b5cdc48628f15960325307341be4bf1c`, размер `12582603` bytes, `4607` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Exact-head GitHub CI `86108318744`: checkout `2bcd7f61e7803bcc9a2a743fa80c8487d2b161af`, CI `efhc.zip` размер `12582603` bytes; SHA-256 CI payload в supplied logs не опубликован. Failed gates: Flake8 critical, Mypy, Ruff, pytest. Pytest `11 failed / 1580 passed / 22 skipped / 1 warning`; Ruff `9 errors`; Mypy `2 errors`.
- Это continuation цикла `1754`; numbered cycle `1755` не начат. Production causes исправлены: `EFHCError` import, route-cleanup unused imports/import-order residue, unused release variable.
- PATCH_002 восстановлен byte-exact для `AdminSalePackagesPage.tsx`, SHA-256 `6dfad487f83d9ca5d2cb69cff920619135d9e214efaff45dc185c220e1724b6b`; visual/text guard не ослаблялся и owner-approved exception не выдумывался.
- Stale tests/metadata синхронизированы с active CANON: root `VERSION`, canonical `system_routes.health_db`, removed orphan Ads helpers, exact identity review line pointers и current guard/state version. `INSTALL.md` снова содержит `.env.example`, `/opt/efhc/shared/.env`, `chmod 600`; KERNEL timeless prose переведён на русский и ONE VPS DR authority.
- Factual application surface не менялся: `153 OpenAPI paths / 159 public operations / 168 schemas / 4 hidden / 163 mounted`; protected `355/66/81`; frontend pages `39`; ORM `56`; canonical users.global_id FK floor `42`; Alembic head только `0001`. Database backup остаётся local encrypted newest-10 с owner export по SSH/SFTP на ПК/смартфон; Telegram database-backup infrastructure не возвращалась.
- Неподтверждённый/нерешённый item: visible Sale Packages PATCH_002 mutations по-прежнему встречают backend CANON `409 SALE_PACKAGES_NOT_RELEASE_SSOT`; его визуальное решение требует отдельного owner approval и не может быть сделано ради CI.
- Локальные tests/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/PostgreSQL/smoke не запускались. Выполнена только разрешённая static AST/JSON/text/hash verification.
- Immutable report: `reports/numbered/reports_02292__cycle_1754_exact_head_ci_v173_88_continuation.md`, SHA-256 `677e5828bdf5037789b75c97a09fe33b094eb69dc83fbf85655531ff2cd1b583`.
- Candidate `v173.89` требует следующий exact-head GitHub CI. При failures продолжается цикл `1754`; только green qualification разрешает переход к cycle `1755`.

## Текущая точка — кандидат v173.88 / цикл 1754 — route cleanup + DevOps hardening + owner backup override

- Входной Development HEAD `EFHC_Bot_v173_87.zip`: SHA-256 `fc5e18903fb64a7518349df7029a4b5cc2dc8782331dacd2de5475a8275e92a9`, размер `12572495` bytes, `4615` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Exact-head GitHub CI `86004195126`: checkout `f181388c2211f035d18dfc15dcf3b9ba44e15dd4`, CI `efhc.zip` размер `12572495` bytes; SHA-256 CI payload в supplied logs не опубликован. Все canonical gates `exit=0`; pytest `1587 passed / 22 skipped / 1 warning`; Alembic `0001: ok`, `metadata_tables=56`; frontend assets/build verification `PASS`. Цикл `1753` квалифицирован.
- Последнее owner decision supersedes Telegram database-backup части Audit 8/DevOps ТЗ: production DB backup **не отправляется в Telegram**. Backup-specific Telegram transport/scripts/ENV/Local Bot API infrastructure удалены. Canonical recovery — local encrypted newest-10 на единственной production VPS; владелец скачивает выбранный `.enc` + `.sha256` по SSH/SFTP на ПК или смартфон. Обычный EFHC Telegram bot/webhook/admin text notifications остаются отдельным runtime contour.
- Route cleanup удаляет 7 repository-proven dead/retired HTTP surfaces: 4 `/hub/browser-shop-*` aliases, `POST /skins/buy/{skin_id}`, `GET /health/db-schema`, `GET /meta/health_db`. Factual candidate surface: `153 OpenAPI paths / 159 public operations / 168 schemas / 4 hidden / 163 mounted`; canonical `/shopfront/*`, `/api/health/db` и progression skins сохранены.
- Conditional Admin/Ads/duplicate activation backend routes без external traffic proof не удаляются. Sale Packages frontend переведён read-only по существующему fail-closed backend CANON. Route-audit hardening закрывает unauthenticated `/nft/has_vip` provider amplification, raw DB exception leakage, unrestricted Workbench path edit и stale health/observability docs/proofs.
- DevOps hardening: ONE VPS, root `VERSION` SSOT, owner ENV без ручных version labels и без second-host/backup-Telegram fields, `140/140` русских metadata blocks, canonical `/api/health`, explicit update commit/terminal states, race-safe Autopilot release-lock observation-only, isolated encrypted restore drill.
- PostgreSQL schema/financial/identity semantics не менялись: единственный Alembic head `0001_initial_release_schema.py`, ORM `56`, canonical `users.global_id` FK floor `42`; protected floor `355/66/81`; frontend pages `39`; test file inventory `272 architecture / 452 Python`.
- Production access-log/config proof для удалённых public URLs не предоставлен; production rollout этих URL остаётся отдельным gate. Также operational clean-replacement-VPS DR drill и полный browser-shop service-layer decomposition не заявляются выполненными.
- Локальные tests/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/PostgreSQL/smoke не запускались. Выполнена только разрешённая static AST/JSON/CSV/route/OpenAPI/env/archive-source verification.
- Immutable report: `reports/numbered/reports_02291__cycle_1754_route_devops_backup_owner_override.md`, SHA-256 `c75ef9976168776d3665879f84b1f628b20d646e62156bfb9135862f8993a187`.
- Candidate `v173.88` требует следующий exact-head GitHub CI. При failures продолжается цикл `1754`; после green qualification следующий numbered cycle — `1755`.

## Текущая точка — кандидат v173.87 / цикл 1753 — Audit 8 Backup/DR hardening

- Входной Development HEAD `EFHC_Bot_v173_86.zip`: SHA-256 `2322d2e0799fd505e2c4fe56e329bdee4b5a9893a2a98cbc6e35c279d6aa7c4f`, размер `12549983` bytes, `4612` ZIP entries; duplicates `0`, ZIP integrity успешна, все entries `ZIP_DEFLATED`.
- Новые exact-head GitHub CI-логи для входного `v173.86` в текущем наборе файлов отсутствуют. Доступный `logs_85980628163.zip` относится к ранее квалифицированному `v173.85` и не используется как verifier `v173.86`.
- Цикл `1753` выполняет пересмотренный owner-authority Audit 8 по Autonomous DevOps / Backup / Restore / Disaster Recovery. Подтверждены и исправлены A8-R1…A8-R7: fixed newest-10 local generations, isolated restore drill, fail-closed backup-key lifecycle, manual encrypted Telegram recovery path, backup-aware status, attempts-bounded retry и post-reboot boot timer.
- Canonical backup generation теперь имеет один encrypted recovery artifact: тот же ciphertext сохраняется локально и отправляется владельцу в Telegram; raw dump и незашифрованный bundle являются staging-only material. Telegram outage не расширяет local spool сверх newest 10.
- Production application/backend/frontend/OpenAPI/schema/ORM business surface не изменён. Единственный Alembic head остаётся `0001_initial_release_schema.py`; ORM `56`; canonical `users.global_id` FK floor `42`; PATCH_002 visual/text authority не затронут. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; static test inventory `272 architecture / 452 Python files`.
- Добавлены CI-only guards в существующий architecture test file; локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Выполнена только разрешённая статическая source/AST/manifest/ZIP проверка.
- Candidate `v173.87` требует следующий exact-head GitHub CI. При failures продолжается цикл `1753`; к циклу `1754` переходить только после qualification `v173.87`.

## Текущая точка — кандидат v173.86 / цикл 1752 qualification — exact-head CI v173.85 green

- Входной Development HEAD `EFHC_Bot_v173_85.zip`: SHA-256 `82886c32e62c2d3a2f6e61e8589361036353bff09ec4fff1589d962939029f0e`, размер `12724012` bytes, `4611` ZIP entries; локальная ZIP integrity проверка успешна, duplicates `0`.
- Supplied GitHub CI `85980628163` для `v173.85`: checkout `53f7fc88f92bbc7bb176546122350347b1352c0a`; CI `efhc.zip` имеет размер `12724012` bytes. SHA-256 CI payload в предоставленных логах не опубликован.
- Gate summary полностью успешен: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight, pytest и Ruff имеют `exit=0`. Pytest: `1578 passed / 22 skipped / 1 warning`; Ruff: `All checks passed`; Mypy: `344 source files` без issues; Alembic: `metadata_tables=56`, `0001: ok`; frontend build verify: `PASS`.
- Подтверждённых CI root causes нет; production/backend/frontend/schema/test semantics не меняются. PostgreSQL логи содержат ожидаемые negative-path constraint errors из тестовых сценариев, но gate/pytest завершены успешно, поэтому они не классифицируются как failures.
- Цикл `1752` квалифицирован по входному `v173.85`. Следующий numbered functional cycle — `1753`; его scope в active SSOT не задан и в этой итерации не начинается.
- Этот `v173.86` содержит только qualification/traceability updates и immutable report; functional SSOT/CANON, OpenAPI, ORM и PATCH_002 visual/text authority не изменены. Protected floor `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; canonical `users.global_id` FK floor `42`; static tests `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL не запускались. Новый `v173.86` требует exact-head GitHub CI как новый архив.

## Текущая точка — кандидат v173.85 / цикл 1752 continuation — exact-head CI burn-down v173.84

- Exact-head GitHub CI `85947769920` квалифицирован для входного `v173.84`: checkout `2a7e9d6d1fe2c3fb89b3664246bfd048c36cf046`, CI archive `12537062` bytes. Единственный failing gate — pytest: `4 failed / 1574 passed / 22 skipped / 1 warning`; Alembic/PostgreSQL, Ruff, Mypy, Bandit, compileall, Flake8 critical/full, npm ci и frontend build успешны.
- Два schema failures — stale integration constants `EXPECTED_FK_COUNT=41`; current `0001` и active release state канонически имеют `42` FK на `users.global_id`. Оба expectations синхронизированы на `42`.
- Первый referral failure — stale lookup ненумерованного `REF_ACT_UNIT` и неверного owner в fixture; expectation синхронизирован с canonical inviter-owned `REF_ACT_UNIT:G{inviter_global_id}:N00001`.
- Второй referral failure — boundary fixture создавал `9999` active referrals напрямую, но не моделировал уже закреплённые slots `1..9998`, поэтому allocator корректно начинал с `N00001`. Fixture теперь моделирует prior slot ownership `1..9998`, после чего проверяет `N09999`, `N10000` и отсутствие slot у `10001`-го active referral.
- Production/runtime/DevOps/referral economics не изменялись. Независимые `REF_ACT_UNIT`, `REF_LVL` и нефинансовый Rankings CANON сохранены. ORM floor `56`; global owner FK floor `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.85` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.85` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.84 / цикл 1752 continuation — exact-head CI burn-down v173.83

- Exact-head GitHub CI `85940762760` квалифицирован для входного `v173.83`: checkout `f0456d329f84ed1cd6183c2297188a7e3f626aa2`, CI archive `12529560` bytes. Failing gates: Alembic, Ruff и pytest; Mypy/Bandit/compileall/Flake8/frontend gates успешны.
- Alembic root cause: после Audit 7 таблица `ad_provider_claims` добавила ещё один canonical FK на `users.global_id`, поэтому фактический count `42`, а `0001` validator и его static contract guard оставались на `41`.
- Ruff root cause: только `I001` в новом DevOps architecture guard.
- Независимые pytest drifts: provider-portability gate всё ещё ожидал прямой predeploy `backup_postgres.sh` вместо current `telegram_backup_delivery.sh`; daily backup test ожидал прямой `backup_bundle.sh` вместо delegated Telegram chain; referral Lvl fixture не предоставлял `db.scalar()` для historical key read-through; `INSTALL.md` потерял явный literal `chmod 600`. Остальные DB failures/errors являются следствием failed Alembic setup из supplied run.
- Все подтверждённые причины исправлены без изменения DevOps safety model, referral economics или Audit 7 runtime semantics. ORM floor остаётся `56`; global owner FK floor current `42`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.84` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.84` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.83 / цикл 1752 — Autonomous DevOps + exact-head CI burn-down

- Exact-head GitHub CI `85876332157` квалифицирован для входного `v173.82`: checkout `78ac7c355be6cc9f6c8215baa647a31960658a27`, CI archive `12480201` bytes. Ruff/Mypy/Bandit/compileall/Flake8/frontend gates успешны; Alembic падает на stale `EXPECTED_TABLE_COUNT=55` при canonical ORM floor `56`, что порождает каскад DB pytest errors. Независимые pytest drifts: Audit-6 revoke SQL literal, Ranks marker, test/current-state version и referral numbered-slot fixture.
- Все подтверждённые CI root causes исправлены без отката Audit 7: database contract = `56`, stale guards/fixture синхронизированы с active CANON.
- Цикл 1752 реализует repository/release часть autonomous DevOps: encrypted Telegram backup, local Bot API integration, status/autopilot/diagnostic, daily/weekly/monthly/post-reboot timers, external-monitor artifact, ENV preflight и safe host prerequisites. Фактическая установка на production/external VPS в этом чате не выполнялась — доступа к VPS нет.
- Referral economics закреплена тремя независимыми контурами: `REF_ACT_UNIT:G{inviter_global_id}:N{reward_no:05d}`, `REF_LVL:G{inviter_global_id}:L{level}` и нефинансовый referral/ranking display. Historical Lvl keys сохраняются только для idempotent read-through.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `272 architecture / 452 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.83` требует exact-head GitHub CI.
- Следующий numbered cycle после qualification — `1753`; если exact-head CI `v173.83` содержит failures, сначала выполняется continuation/burn-down текущего цикла 1752.

## Текущая точка — кандидат v173.82 / цикл 1751 — Unified Deep Audit 7

- Exact-head GitHub CI `85849626798` квалифицировал входной `v173.81`: checkout `ab5591d411da6d87591459f6350b0de0f91189fb`, CI archive `12464501` bytes. Failing gates: Ruff `UP012`, Bandit `B608`, pytest `1 failed / 1566 passed / 22 skipped / 1 warning`; остальные supplied canonical gates завершились успешно.
- Все семь findings A7-R1…A7-R7 подтверждены по current source/SSOT/CANON и исправлены: Energy delta parity; ADS provider single-claim; Admin/Public Tasks atomicity; numbered referral slots; полный paged Ranks + direct find-me; progression-only Skins fail-closed legacy commerce.
- Exchange lifetime model не менялась: `available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`.
- Protected floor остаётся `355/66/81`; OpenAPI `156/162/168`; mounted `170`; frontend pages `39`; ORM tables `56`; static test inventory `271 architecture / 451 Python files`.
- Единственный Alembic head остаётся `0001_initial_release_schema.py`; новая ADS claim table входит в pre-release `RELEASE_METADATA.create_all()`.
- Локальные tests/CI/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/PostgreSQL после patch не запускались. Candidate `v173.82` требует exact-head GitHub CI.
- Следующий утверждённый функциональный scope после qualification — цикл `1752`, настройка окружения/автономного DevOps-контура по `EFHC_DevOps_TZ.md`.

## Текущая точка — кандидат v173.81 / цикл 1750

- Exact-head GitHub CI `85840461388` полностью квалифицировал входной `v173.80` (`12452133` bytes, checkout `3a80d8c8f85feff263771ebd0b3c33567d971f1e`); pytest `1563 passed / 22 skipped / 1 warning`, остальные supplied canonical gates `exit=0`.
- Audit 6 A6-01…A6-03 подтверждены по source/SSOT/CANON и исправлены: inactive-account session/RBAC/handoff kill-switch, JWT expected audience, bounded fail-closed TON challenge issuance/cleanup.
- Protected/API/ORM/frontend floor не изменён: `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- После patch локальные tests/CI/guards/build/Alembic/PostgreSQL не запускались. Candidate `v173.81` требует exact-head GitHub CI.
- Следующий функциональный цикл после qualification: `1751`; CI failures нового HEAD имеют приоритет над следующим audit scope.

## Точка продолжения — кандидат v173.80 / цикл 1749 continuation — exact-head CI burn-down v173.79

- Входной HEAD: `EFHC_Bot_v173_79.zip`, SHA-256 `cec9e53bffe178dc1273fb00ac8ed8786a425b1b57078092b9583456ca5b3485`, размер `12447211` bytes, `4582` ZIP entries.
- Exact-head GitHub CI `85837515925`: checkout `8c63e2261e39445022f1c18eef2738667fe6bf8c`; CI `efhc.zip` имеет тот же размер `12447211` bytes. SHA-256 CI payload в supplied logs не опубликован.
- Успешные supplied gates: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Ruff, Mypy (`344` source files), npm ci и frontend build. Единственный failing gate — pytest: `2 failed / 1561 passed / 22 skipped / 1 warning`.
- Pytest root causes: одна новая англоязычная строка `KERNEL.md`, запрещённая active `RUSSIAN_ENGINEERING_LANGUAGE_NORM`, и generated test-guard manifest drift `v173.78 != v173.79`.
- Исправлено только: CI-указанная строка `KERNEL.md` приведена к русскому инженерному тексту; `TEST_GUARD_MANIFEST` синхронизирован с candidate/current-state `v173.80` в рамках continuation цикла 1749.
- Production/backend/frontend/API/OpenAPI/schema/ORM и Audit 5 VIP/NFT semantics не изменяются. Protected floor остаётся `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`; test inventory `269 architecture / 449 Python files`.
- Локальные tests/CI/guards/Ruff/Mypy/Flake8/Bandit/compileall/frontend build/Alembic/PostgreSQL после patch не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий номер цикла после закрытия 1749: `1750`.

## Точка продолжения — кандидат v173.79 / цикл 1749 — exact-head CI burn-down после Audit 5/10

- Source authority: exact `v173.78`, SHA-256 `bca800b6830e11cd605d3d92cf8141c72f8fbff5b7d92a675b80c12e68419607`.
- Supplied exact-head GitHub CI `85806294354`: checkout `6ff22c5f7cd72dee81a60656eb518fae18fc8a00`, archive size `12621087` bytes. Подтверждены только Ruff `SIM102` в Audit-5 guard и один archive-hygiene pytest failure; остальные supplied canonical gates `exit=0`.
- Исправления 1749 guard/document-only: nested `if` объединён без semantic change; numbered work-pass label удалён из active Admin VIP/NFT CANON без изменения его норм.
- Audit 5 runtime сохраняется: last-wallet stale VIP reset, single-pass scheduler, strict NFT `verified=true`, multi-wallet VIP/Admin-NFT aggregation.
- Production/backend/frontend/API/schema/ORM не менялись. Protected floor `355/66/81`, OpenAPI `156/162/168`, mounted `170`, frontend `39`, ORM `55`.
- Новый candidate `v173.79` локально не тестируется; обязательный verifier — следующий exact-head GitHub CI пользователя.

## Точка продолжения — кандидат v173.78 / цикл 1748 — Audit 5/10 VIP / NFT

- Входной HEAD: `EFHC_Bot_v173_77.zip`, SHA-256 `2f806c81eb61e35fc754aecfae44df2fd504f7f1726f36839030826ab45e58e1`, размер `12429806` bytes, `4579` ZIP entries.
- Exact-head GitHub CI `85731080653` квалифицировал входной `v173.77`: checkout `815cceef2db2820c2e23fe825d6eecfc76a1d58e`; все canonical gates завершились `exit=0`; pytest `1559 passed / 22 skipped / 1 warning`; Ruff и Mypy clean.
- Audit 5/10: A5-01…A5-04 подтверждены по exact source и active VIP/NFT/Admin-NFT/energy CANON. Возврата Audit 4 не обнаружено.
- VIP wallet source теперь означает все active verified `wallet_bindings`; legacy `users.ton_wallet` используется только при отсутствии таких bindings. VIP/Admin NFT агрегируются по всем допустимым кошелькам одного `global_id`.
- Удаление последнего допустимого wallet source атомарно снимает `is_vip`, очищает `vip_since` и обновляет `vip_checked_at`; reconciliation отдельно исправляет накопившийся stale `is_vip=TRUE` без wallet source.
- NFT из целевой коллекции учитывается только при authoritative provider state `verified=true`; cache сохраняет этот state, а legacy cache без него не считается доказательством.
- VIP/NFT scheduler tick выполняет ровно один полный `check__all__users_once()` и не повторяет весь проход до timeout.
- Protected floor остаётся `355 / 66 / 81`, OpenAPI `156 / 162 / 168`, mounted operations `170`, frontend `39`, ORM `55`.
- Добавлен один CI-only Audit-5 guard; локальные tests/CI/guards/Ruff/Mypy/Flake8/Bandit/compileall/frontend build/Alembic/PostgreSQL после patch не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Точка продолжения — кандидат v173.77 / цикл 1747

- Exact-head GitHub CI `85713471365` квалифицировал входной `v173.76`: checkout `5bd34ef70b256343f3e42f51eb7f237c16349dad`, CI archive `12416737` bytes. Failing gates: Ruff `1×SIM102`, pytest `4 failed / 1550 passed / 22 skipped`; остальные supplied canonical gates завершились успешно.
- Все пять CI-причин исправлены без отката Audit 4: один style drift нового architecture guard и четыре stale guard/fixture expectations.
- Owner security audit от `v173.75` не применялся как blind patch: findings F-01…F-06 повторно подтверждены на exact source `v173.76` и перенесены минимально поверх HEAD. F-07…F-09 подтверждены как отдельные provider/ops решения без выдумывания contracts.
- Security floor 1747: client-only ad completion не имеет reward authority; Monetag/AdMaven postback требует independent secret; streamed HTTP body cap считает реальные ASGI chunks; security middleware/system locks и сильный `SECRET_KEY` fail-closed в prod/stage; Browser Shop не сохраняет bearer в URL/history; `cryptography` floor `44.0.1`.
- Frontend visual/text PATCH_002 не изменён; Browser Shop изменение зарегистрировано как owner-approved nonvisual security exception.
- Protected floor остаётся `355 / 66 / 81`, OpenAPI `156 / 162 / 168`, mounted operations `170`, frontend `39`, ORM `55`.
- Локальные tests/CI/guards/Ruff/Mypy/Flake8/Bandit/compileall/frontend build/Alembic/PostgreSQL после patch не запускались.
- Неизменяемый отчёт: `reports_02280__cycle_1747_exact_head_ci_security_hardening.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.76 / цикл 1746 — Audit 4/10 security/withdraw atomicity

- Входной HEAD: `EFHC_Bot_v173_75.zip`, SHA-256 `03a81f69e689cde30717df936039276f1d54904c5d4ed3e394de77e350f0b75a`, размер `12490289` bytes, `4576` ZIP entries.
- Exact-head GitHub CI `85694957898` квалифицировал входной `v173.75`: checkout `d15c2675d009ddc625754fec79e5c129cfe4f337`; pytest `1549 passed / 22 skipped / 1 warning`; Ruff, Mypy, Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full и frontend build завершились успешно.
- Audit 4/10: все пять findings подтверждены по exact source и active SSOT/CANON; локальные tests/CI/guards не запускались.
- TON wallet binding больше не допускает client-key-only proof: HTTP proof требует `state_init`, TON chain id и public key; authoritative key/address берутся через canonical TonAPI state-init resolver, wire network обязан совпасть с configured `TON_NETWORK`.
- Emergency EFHC recovery сохраняет idempotency response без commit; settlement/money + `AdminLogger.write(required=True)` фиксируются только root Admin transaction.
- Withdrawal repair/approve/reject используют `FOR UPDATE`, canonical `withdraw_hold`/`withdraw_refund` fingerprints и только `*_nocommit` money primitives до root commit. Финансовый Admin audit обязателен; outcome/admin notification outbox сохраняется до commit, Telegram отправляется только после него.
- `/admin/withdrawals/repair-consistency` использует actor identity и строгий `Idempotency-Key`; повтор с иным `scan_minutes`/`batch_limit` или owner возвращает `IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`.
- `TELEGRAM_WEBHOOK_SECRET` обязателен для `prod` и `stage`; `/tg/webhook` имеет независимый fail-closed guard при пустом секрете в защищённом окружении.
- Withdraw V1 CANON не расширен blockchain-watcher proof/FSM требованиями: Audit 4 меняет только transaction/audit/idempotency/notification boundaries.
- Protected/API/ORM/frontend surface не сокращается: `355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages`; mounted HTTP operations `170`; ORM `55`; OpenAPI schemas `168`.
- Добавлен CI-only guard `tests/architecture/test_security_financial_audit4_contract.py`; frontend visual/text PATCH_002 не изменяется.
- Неизменяемый отчёт: `reports_02279__cycle_1746_audit4_ton_withdraw_security_atomicity.md`.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая execution-блокировка — v173.75 / цикл 1745 — exact-head CI continuation

- Точный source authority: `v173.74`, SHA-256 `9de753932226e7e30dc889be90c9bf9bd5b1953df1ddbca91edc50e789e17788`, 4575 файлов.
- Supplied exact-head CI `85676568893` квалифицирован по checkout `c418d15377686623fc545e4b27db023e5934085d` и точному размеру CI archive `12397023` bytes.
- Реальные failures ограничены Ruff `1 I001` и pytest `1` по `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; Mypy и остальные canonical gates из supplied logs завершились успешно.
- Исправляется только подтверждённый import-order drift и две CI-указанные новые англоязычные строки инженерного документа. Production Audit 3 semantics не меняются.
- Локальные application tests/CI запрещены; следующий verifier — exact-head GitHub CI нового `v173.75`.
- Неизменяемый отчёт: `reports_02278__cycle_1745_exact_head_ci_v173_74_continuation.md`.

## Текущий execution lock — v173.74 / цикл 1745 — exact-head CI burn-down Audit 3/10

- Source authority: exact `v173.73`, SHA-256 `99edf85f030547f91393ed59f517482395d1ad2a65cd4d7b0fb22597184a77e3`.
- Supplied exact-head CI: `85671783650`, checkout `4c93db3f030000940bcfa401bac765dc138248e3`, CI archive size `12388486` bytes.
- Failing gates ограничены Ruff `5 I001`, Mypy `3`, pytest `10`; остальные supplied canonical gates завершились успешно.
- Stale guards не имеют authority вернуть committing Shop spend, writable non-SSOT sale-packages или legacy `tg_id` ownership/read-through. Audit 3 financial/security semantics являются protected floor.
- Разрешён только минимальный patch подтверждённых CI причин; frontend PATCH_002 visual/text не менять; compatibility не удалять без delete-proof.
- Локальные application tests/CI запрещены; следующий verifier — exact-head GitHub CI нового `v173.74`.
- Immutable report: `reports_02277__cycle_1745_exact_head_ci_audit3_burn_down.md`.

## Текущая рабочая блокировка — кандидат v173.73 / цикл 1744 — Audit 3/10: Shop/PaymentIntent/Bank financial consistency

- Входной HEAD: `EFHC_Bot_v173_72.zip`, SHA-256 `0af948145f1f3f1745b09bbab5024c28a3bee3dd341f8beded64dba1150ecb9c`, 4573 ZIP entries; archive integrity clean, все entries `ZIP_DEFLATED`.
- Scope: шесть findings Audit 3/10 пользователя, непосредственно связанный Bank rollback surface и следующий подтверждённый response defect внутри `/shop/order-external` execution path. Все пользовательские findings подтверждены по exact source, DB boundaries и active SSOT/CANON.
- Shop EFHC purchase переведён на caller-owned `spend_user_to_bank_bonus_then__main__nocommit()` и один root commit вместе с `shop_orders`; ошибка любой части откатывает money/order единым rollback.
- `shop_orders` получает pre-release canonical `UNIQUE(global_id, idempotency_key)` в ORM и единственном `0001`; read-through проверяет immutable owner-scoped fingerprint, а EFHC purchase дополнительно сверяет derived ledger keys/payload.
- `ShopPurchaseByEFHCOut` теперь строится из фактического committed order/ledger result; внешний `ShopOrderExternalIn.quantity` сохраняется compatibility field, но канонически допускает только `1`.
- PaymentIntent creation idempotency сравнивает полный immutable fingerprint; mismatch → `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact replay формируется только из persisted DB-row и не продлевает сохранённый expiry.
- `/admin/sale-packages` GET сохранён как compatibility/read surface; mutating create/update/toggle fail-closed отвечают `409 SALE_PACKAGES_NOT_RELEASE_SSOT`, пока release sale authority остаётся `efhc_core.shop_items`.
- Existing Admin Bank rollback выведен в API только после hardening: source `transfer_log_id` блокируется `FOR UPDATE`, допускается только исходная user-side Admin manual ledger operation, amount/direction/`balance_type` выводятся из source row, а deterministic compensation identity `admin_bank_rollback:<transfer_log_id>` не допускает второй reversal с иным HTTP key.
- `/shop/order-external` больше не пытается делать item-assignment в `ShopOrderExternalOut` после commit; финальный response строится новым `ShopOrderExternalOut(order=..., pay=...)`, исключая подтверждённый post-commit Pydantic `TypeError` path.
- Protected floor после добавления canonical rollback API/facade symbol: **355 symbols / 66 modules / 81 files / 156 OpenAPI paths / 162 public operations / 39 frontend pages**; mounted HTTP operations **170**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02276`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.72 / цикл 1743 — exact-head CI burn-down v173.71 после аудита 2/10

- Входной HEAD: `EFHC_Bot_v173_71.zip`, SHA-256 `e658dab6a2c05cbf9f4eb15c9b67b2153b8b05077f72c65223ba9b446ca82ab6`, размер `12456075` bytes.
- Exact-head GitHub CI `85571802073`, checkout `d3f3eb541a09954a2bc16266d45abf2c417931f0`; CI `efhc.zip` имеет тот же размер `12456075` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates по предоставленным логам: Alembic, Bandit, compileall, Flake8 full, npm ci, frontend build и PostgreSQL preflight.
- Ошибочные gates: Flake8 critical — `4` F821; Ruff — `5` diagnostics (`4` F821 + `1` I001); Mypy — `4` name-defined errors; pytest — `1 failed / 1548 passed / 22 skipped / 1 warning`.
- Подтверждённые причины исправлены минимально: восстановлен импорт `require_idempotency_key_header_only` для трёх Admin money routes; из emergency deposit rejection-audit удалён stale `request_ik`, потому что recovery authority остаётся immutable `tx_hash`; исправлен import-order в CI-указанном Admin RBAC guard; stale Bank runtime fixture использует `NULL` для отсутствующего legacy `users.ton_wallet` вместо конфликтующего `''` под `UNIQUE(ton_wallet)`.
- Семантика аудита 2/10 не ослаблена: write RBAC, strict financial Idempotency-Key, materialized-only emergency recovery, global `tx_hash` settlement claim, atomic money + required Admin audit и canonical `users.global_id` actor сохранены.
- Protected floor без изменений: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report (неизменяемый отчёт): `reports_02275`.
- Audit 3/10 не начат: текущий continuation сначала требует exact-head GitHub CI нового `v173.72`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.70 / цикл 1743 — security audit 2/10

- Входной HEAD: `EFHC_Bot_v173_69.zip`, SHA-256 `d8bd8ffe570e4d7af47cce21a243e54aa7c6ff8dd2763d02ba2ee8ce899ce87f`, размер `12429259` bytes.
- Scope: семь подтверждённых findings аудита 2/10; произвольный cleanup/refactor не выполняется.
- Admin authorization разделён: `require_admin` = authentication/read gate; любой state-changing `POST/PUT/PATCH/DELETE` требует `require_admin_write` (минимум Moderator), поэтому `Analyst/auditor → 403`.
- Emergency EFHC deposit принимает только `tx_hash`; amount/MEMO/address/raw facts берутся исключительно из materialized `ton_inbox_logs` под `FOR UPDATE`; отсутствие watcher-записи fail-closed. Money + обязательный actor audit фиксируются одним commit.
- Admin bank money operations используют caller-owned nocommit boundaries: ledger + обязательный `admin_action_log` + notification outbox атомарны; Telegram delivery выполняется после commit.
- Повторный `Idempotency-Key` с другим owner/operation/direction/balance/amount возвращает `409 IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`; exact payload остаётся read-through.
- Admin NFT principal после центрального gate не проходит whitelist-only повторную авторизацию.
- Panels service синхронизирован с `archived_at`; facade использует `toggle_panel`; HTTP activate/deactivate идут через единый service-layer. Rollback balance type выводится только из исходной ledger-строки.
- Protected floor: **354 symbols / 66 modules / 81 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**, OpenAPI schemas **168**.
- Frontend PATCH_002 visual/text CANON не изменён. Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Immutable report: `reports_02273`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.69 / цикл 1742 — exact-head CI burn-down

- Входной HEAD: `EFHC_Bot_v173_68.zip`, SHA-256 `89f6601c1eb21958cf49e4013b006675c02e108bd675abf315211d0234cdb0e7`, размер `12423369` bytes.
- Exact-head GitHub CI `85494080104`, checkout `c26d756731522adbf009d792f1885e79313e2835`; CI `efhc.zip` имеет тот же размер `12423369` bytes. SHA-256 CI payload в логах не опубликован.
- Успешные gates: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build и PostgreSQL preflight.
- Failing gates: Ruff — `1` I001 import-order; pytest — `7 failed / 1533 passed / 22 skipped / 1 warning`.
- Подтверждённые исправления continuation 1742: Ruff import-order; traceability exception для immutable audit evidence 1741; timeless комментарий `0001`; financial-identity guard приведён к canonical `owner_db`; Russian Engineering NORM в `ton_memo`; lifecycle tests больше не требуют несуществующий `wallets_service.STATUS_PENDING_MANUAL`; watcher accounting SSOT/tests синхронизированы с fail-closed `CONFIRMED + different tx_hash` semantics.
- Финансовые исправления аудита 1/10 не откатываются: legacy BUY/SKU MEMO остаётся `pending_manual`, PaymentIntent требует live `PENDING`, global `tx_hash` settlement lock остаётся единственным settlement claim.
- Protected floor не изменяется: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; ORM tables **55**.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.68 / цикл 1742

- Входной HEAD: `EFHC_Bot_v173_67.zip`, SHA-256 `d594424e7ff88eb4b3366019de7d6efd62064debd91f411784dfe69fa456c4aa`, размер `12398809` bytes.
- Scope цикла 1742 ограничен тремя подтверждёнными дефектами финансового аудита 1/10 по входящим платежам; произвольный cleanup/refactor не выполняется.
- CRITICAL legacy `BUY:EFHC` / `SKU:EFHC` MEMO больше не является settlement/reward authority: `qty` из пользовательского MEMO не может определять размер начисления. Без canonical PaymentIntent подтверждения такой входящий платёж переводится только в `pending_manual`; `credit_user_from_bank` и `PAID_AUTO` из legacy SKU-ветки запрещены.
- PaymentIntent после `FOR UPDATE` принимает новый settlement только при `status=PENDING` и `expires_at > now`; уже `CONFIRMED` допускается только как идемпотентный read-through того же самого `tx_hash`. Другой `tx_hash`, expired/canceled/unknown status fail-closed.
- `efhc_core.tx_hash_locks` расширен до единственного глобального immutable on-chain settlement claim для PaymentIntent, watcher direct/nomemo и Admin recovery. `intent_id` nullable только потому, что direct/admin settlement не обязан иметь PaymentIntent; unique `tx_hash` остаётся глобальным.
- Business idempotency keys сохраняются как второй слой, но не могут позволить повторно начислить одну blockchain-транзакцию через другой processing namespace.
- Active financial CANON: `docs/payments/ONCHAIN_SETTLEMENT_TX_HASH_CANON.md`, `docs/SSOT/PAYMENT_INTENT_SSOT.md`, `docs/NORM/PAYMENT_INTENT_FLOW_NORM.md`, `docs/SSOT/TON_MEMO_SPEC.md`.
- Registered protected floor после добавления общего settlement service: **342 symbols / 63 modules / 78 files / 155 OpenAPI paths / 161 operations / 39 frontend pages**; HTTP surface не изменяется. ORM tables остаются **55**; single Alembic head остаётся `0001_initial_release_schema.py`.
- Добавлены/актуализированы CI-only regression guards для трёх findings; локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус кандидата: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Последний green CI `85400569189` относится к `v173.66`, не к этому кандидату.

## Текущая рабочая блокировка — кандидат v173.67 / цикл 1741

- Входной HEAD: `EFHC_Bot_v173_66.zip`, SHA-256 `b93479b92ba84c288168f825e40bc1f42707f8cde8c1adb2749c25128d7088a6`, размер `12353514` bytes.
- Exact-head GitHub CI `85400569189`, checkout `78f0c2aa96101b95161754a4c8eaa0e0bbe31c76`; CI `efhc.zip` имеет тот же размер `12353514` bytes. SHA-256 CI payload в логах не опубликован.
- Gate summary: **все canonical gates exit=0** — Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight, pytest и Ruff. Pytest: `1534 passed / 22 skipped / 1 warning`; Mypy: `344 source files`; Ruff: `All checks passed`; Bandit: `No issues identified`; Alembic: `metadata_tables=55`, `0001: ok`; frontend build verify: `PASS`.
- Цикл 1741 выполняет статический аудит функций/routes/tables без исполнения production-модулей: `345` production Python files, `1815` function definitions, protected floor `339/62/77` без missing; `161/161` OpenAPI↔route SSOT operations; `55/55` ORM↔table/migration SSOT.
- Обнаружен и исправляется только SSOT/guard drift: table SSOT `48 → 55 (48 core + 7 admin)` и hidden-route inventory `2 → 8`. Runtime/backend/frontend/schema/экономика/ADS/PATCH_002 не изменяются.
- Полный статический evidence: `docs/audits/APPLICATION_FUNCTION_ROUTE_TABLE_AUDIT_1741.md` + `.json`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус нового кандидата: `AUDIT/SSOT PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`; зелёный CI относится к входному `v173.66`.

## Текущая рабочая блокировка — кандидат v173.66 / цикл 1740

- Входной HEAD: `EFHC_Bot_v173_65.zip`, SHA-256 `33a9e31d5c098091889e8bd782c79b026ef4e28fd91d1bd2735e0833e5f3f4c5`, размер `12348905` bytes.
- GitHub CI пользователя `85386896242`, checkout `d01a440b86a8ac2f062f7b88cbf2e252b8fbb615`; CI `efhc.zip` имеет тот же размер `12348905` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied canonical gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `1 failed / 1533 passed / 22 skipped / 1 warning`. Единственный подтверждённый failure — Russian Engineering Language NORM: английское имя одной test-function в `tests/architecture/test_browser_shop_mvp_cut_lock.py`.
- Исправление 1740: изменено только имя этой test-function на русскоязычное; test semantics, production runtime/backend/frontend, ADS mediation, schema, routes, PATCH_002 visual/text CANON и business `global_id` semantics не изменялись.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.65 / цикл 1739

- Входной HEAD: `EFHC_Bot_v173_64.zip`, SHA-256 `9568bc1b8f76aa735d713490597d426f5ebeb00758197d96056273ad97adb934`, размер `12351381` bytes.
- GitHub CI пользователя `85380431378`, checkout `0eaca2cc7c516f595fd44edce89d3bb3c6a60c60`; CI `efhc.zip` имеет тот же размер `12351381` bytes. SHA-256 CI payload в логах не опубликован.
- Все supplied gates кроме pytest завершились `exit=0`: Alembic, Bandit, compileall, Flake8 critical/full, Mypy, npm ci, frontend build, PostgreSQL preflight и Ruff.
- Pytest: `4 failed / 1530 passed / 22 skipped / 1 warning`. Подтверждены только четыре stale test/guard/documentation expectations; production runtime/backend/frontend defect этим CI не подтверждён.
- Исправления 1739: два PostgreSQL integration expectations `39 → 41`; exact-fragment identity disposition перенесён на актуальную строку negative guard; подтверждённые новые Russian Engineering NORM нарушения русифицированы без изменения test semantics.
- Frontend PATCH_002, ADS runtime, schema, routes, business semantics, `global_id` ownership и function-preservation floor в цикле 1739 не изменяются.
- Protected function surface остаётся `339 symbols / 62 modules / 77 files / 155 paths / 161 operations / 39 frontend pages`; checked-in OpenAPI `168 schemas`.
- Локальные pytest/guards/Ruff/Mypy/Bandit/Flake8/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.63 / циклы 1735–1737

- Входной Development HEAD: `EFHC_Bot_v173_60.zip`, SHA-256 `03be8f51a4a649f7ebc2e44cc8f9abce88e7ca71a072574654e3b93e0cb36179`.
- По прямому ТЗ владельца большая ADS-задача разделена без сокращения scope на три последовательных цикла: `1735 — AdManager core / DB / session / security / daily limit`, `1736 — provider adapters / frontend AdManager / Admin ADS + Tasks`, `1737 — analytics / Revenue Optimizer / Telegram Bot / guards / SSOT / handoff`.
- Active ADS CANON: `docs/backend/ADS_MEDIATION_CANON.md`. `Tasks` не знает provider-specific SDK; provider подтверждает рекламное событие, `AdManager` владеет server session/fallback/verification, `Task.bonus_efhc` задаёт reward snapshot, существующий `tasks_service` выполняет единственное EFHCb начисление.
- Production mediation использует расширяемый registry. Реализованы adapters для AdsGram, Monetag, RichAds, AdMaven, Adexium; TADS/MyBid зарегистрированы fail-closed и не могут привести к EFHCb до подтверждённого publisher-cabinet SDK/callback contract. `builtin_timer` сохранён только DEV/CI/diagnostics и исключён из production provider registry.
- Конфигурация: `Admin DB override → ENV fallback`; пустое значение = отсутствует; обязательный credential отсутствует → provider пропускается без падения приложения. Secrets шифруются с `ADS_SECRETS_ENCRYPTION_KEY`, Admin GET получает только mask; decrypted secrets не передаются frontend.
- Новые server-owned сущности: provider config, ad session, UTC daily counter, append-only ad events, Admin ADS audit log, provider daily metrics. Существующая `efhc_core.ads` сохранена отдельным историческим/routing contour и не переиспользована как provider config.
- Новый mediation API: `/ads/session*` + provider postbacks; старые `/ads/slot` и `/ads/callback/{provider}` сохранены compatibility-only. Runtime frontend получает только public provider config и не использует `NEXT_PUBLIC_*` credentials.
- Daily reward limit concurrency-safe по `global_id + task_code + UTC_date`; одна session может получить максимум один reward; provider callback не определяет EFHCb; reward snapshot фиксируется при старте session; повторные callback/client-complete не создают второй бонус.
- Frontend PATCH_002 остаётся абсолютным visual/text authority. User Tasks layout не реконструирован; ADS ТЗ разрешает новые runtime states. Admin ADS/Admin Tasks изменены в пределах прямого owner-approved ADS scope. Все 13 locale-файлов сохраняют исходные PATCH_002 значения и получают одинаковое покрытие новых ADS keys.
- Admin ADS: provider configuration, masked credentials, enable/disable/priority/GEO/language, health, provider tests без EFHCb, dashboard, Revenue Optimizer. Admin Tasks `watch_ad`: provider, reward, daily limit, fallback, format, placement, schedule, preview/test.
- Analytics считает provider attempts по append-only `ad_events`, поэтому no-fill/error оператора A не исчезает после fallback к B; revenue хранится отдельно по фактически показавшему provider. Optimizer ранжирует по наблюдаемому revenue/request, а не по жёстко заданному CPM/«кто платит больше».
- `/ads` Telegram Bot использует universal WebApp Tasks flow; AdsGram bot-native adapter допускается на Telegram provider boundary и не создаёт второй EFHCb accounting path. `showTelegramAd()` сохранён compatibility capability probe и возвращает `unsupported`, reward через него невозможен.
- Single Alembic head сохранён: новые pre-release tables входят в existing `0001_initial_release_schema.py` через canonical Base metadata; `0002+` не создавался и Alembic локально не запускался.
- Current registered function surface: `339 critical symbols / 62 modules / 77 protected files / 155 OpenAPI paths / 161 operations / 39 frontend pages`; Admin HTTP surface: `74 paths / 80 operations`; checked-in OpenAPI schema inventory: `168` schemas.
- Добавлен ADS contract guard с 28 обязательными сценариями ТЗ; test/guard files обновлены под mediation CANON, но локально не выполнялись и collection не запускался.
- Последний предоставленный GitHub CI относится к `v173.58` (`85239758056`) и содержал failures, исправлявшиеся в циклах 1733–1734. Exact-head CI для `v173.60` и нового кандидата `v173.63` не предоставлялся. Нельзя утверждать `tests pass`, `build passes`, `CI green` или `production-ready` для `v173.63`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

---

## Текущая рабочая блокировка — кандидат v173.60 / цикл 1734

- Входной Development HEAD: `EFHC_Bot_v173_59.zip`, SHA-256 `26e1167ea2701a9f397111934c52d83be02380146c6ed6a64239050e1791add0`.
- Решением владельца исправлена ошибочная интерпретация цикла 1733: `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip` (SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`) является **абсолютным visual + user-facing text CANON** для затронутых frontend surfaces. CI/architecture guard не имеет права возвращать старый Bot UI поверх утверждённого patch.
- Merge authority: frontend patch задаёт UI/UX/visual/text; current backend/CANON задаёт API, routes, data, security, identity, economy и business semantics; функции обеих веток образуют union и не удаляются.
- Visual/text surfaces, ошибочно возвращённые в 1733, восстановлены к PATCH_002. Старый Bot frontend не используется как visual donor. Допустимые отличия от patch ограничены зарегистрированными `NON_VISUAL_INTEGRATION` / `FUNCTION_UNION_NON_VISUAL` seams.
- Active merge CANON: `docs/frontend/FRONTEND_BACKEND_MERGE_CANON.md`; machine visual lock: `docs/frontend/FRONTEND_AUTHORITY_MANIFEST.json`; guard migration: `docs/testing/FRONTEND_LEGACY_GUARD_MIGRATION.json`.
- Старые CI guards мигрированы: visual/text expectations следуют PATCH_002, functional/contract/security meaning сохраняется без требования старой presentation-разметки. Добавлен fail-closed `tests/architecture/test_frontend_patch_authority_contract.py`.
- Locale key coverage проверено статическим сравнением ключей: все 13 active locale-файлов содержат одинаковые `1596` ключей; пользовательские тексты PATCH_002 не заменяются без отдельного решения владельца.
- Function surface не меняется: `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались. Кандидат `v173.60` требует нового exact-head GitHub CI.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.59 / цикл 1733

- Входной Development HEAD: `EFHC_Bot_v173_58.zip`, SHA-256 `ca0d50840124418769449df7d57e6d0656427eefee5ae1fa29a8b210b61cff71`, размер `12106717` bytes.
- GitHub CI пользователя `85239758056`, checkout `30f5cfb7b283618094492ecd450a777f001270e9`; CI `efhc.zip` имеет размер `12106717` bytes, точно совпадающий с входным HEAD по размеру. SHA-256 CI payload в логах не опубликован, поэтому криптографическое равенство payload не утверждается.
- Gate summary: FAILED `Ruff=1`, `Mypy=1`, `frontend build=2`, `pytest=1`; GREEN `Alembic/PostgreSQL`, `Bandit`, `compileall`, `Flake8 critical/full`, `npm ci`. Pytest: `57 failed / 1445 passed / 22 skipped / 1 warning`.
- Подтверждённые lint/type/build causes: один Ruff `I001` в `auth_session_routes.py`, один Mypy `no-any-return` в `tasks_service.py`, десять TypeScript diagnostics в frontend shell/context/observability/interface/withdraw surfaces.
- Pytest failures классифицированы по active CANON/SSOT: production overlay цикла 1732 перезаписал ряд ранее защищённых frontend-инвариантов; они восстановлены минимально. Stale test expectations изменены только там, где цикл 1732 действительно утвердил новый контракт: OpenAPI `138/143`, selected-wallet Withdraw с `external_address`, writable Admin Sale Packages и бессрочный wallet compatibility alias.
- Восстановлены защищённые Hub/Profile/FAQ/History/GlobalHeader/Admin-home/provider-neutral identity/TON naming/protected-directory/uk-locale/Referrals invariants без отката двух bridge API и утверждённых возможностей цикла 1732.
- Function surface не менялся: `312 symbols / 58 modules / 68 protected files / 138 OpenAPI paths / 143 operations / 39 frontend pages`.
- Frontend release metadata синхронизированы по фактическим bytes без запуска Node/build/generator/verification scripts: `.efhc-build-id = efhc-003a38e2705760b9`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались. Все внесённые исправления требуют нового exact-head GitHub CI кандидата `v173.59`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.

## Текущая рабочая блокировка — кандидат v173.58 / цикл 1732

- Входной Development HEAD: `EFHC_Bot_v173_57.zip`, SHA-256 `9e99a8368b387ad3208f4b2daec76a041b88c4070e3b512f8fd2f43ce97bffc0`.
- Внедрён адресный production patch `FRONTEND_TO_EFHC_Bot_v173_57_PATCH_002.zip`, SHA-256 `0297adb9b34e049a58652a61f9166e539443a407fda9465813390ef29edd4f36`, рассчитанный именно на `v173.57`. Проверено: `131/131` modify source SHA совпали с HEAD, `45/45` add отсутствовали в HEAD; исходные target SHA overlay совпали `176/176`.
- Overlay: `162` frontend-файла и `14` backend bridge/OpenAPI-файлов; standalone/demo/simulation runtime в overlay отсутствует. Frontend contract patch содержит `128` production HTTP contracts: `126` уже существовали, добавлены `GET /auth/profile-photos` и `GET /tasks/earnings/me`.
- Supplied OpenAPI artifact после patch: `138 paths / 143 operations / 168 schemas`. В inventory также появился уже существовавший в source `GET /meta/health_db`; новый runtime route для него в 1732 не создавался. Frontend page floor: `39`. Protected Python/file floor остаётся `312 symbols / 58 modules / 68 files`.
- Новый selected-wallet seam адаптирован к Wallet/global_id CANON: внешний owner остаётся string `global_id`, BIGINT создаётся только через canonical DB-boundary helper. Новый Tasks bridge не добавляет лишний numeric coercion поверх уже разрешённого `NonFinancialReadOwner`.
- Новый Admin diagnostics helper сохранён как техническая диагностика, но его launcher/title приведены к человеческому русскому языку. Новые инженерные docstring/comments/error messages patch приведены к `RUSSIAN_ENGINEERING_LANGUAGE_NORM`; технические идентификаторы не переводились.
- Frontend release metadata синхронизированы по фактическим patched bytes без запуска build/generator scripts: `.efhc-build-id = efhc-783246813342a1d0`, актуализированы `pwa-build.json` и `release-assets-manifest.json`.
- Последний предоставленный exact-head CI остаётся `85157912581` на `v173.56`. Exact-head CI для входного `v173.57` в цикле 1732 не предоставлялся; новый `v173.58` требует отдельного GitHub CI пользователя.
- Локальные pytest/guards/Ruff/Flake8/Mypy/Bandit/compileall/frontend build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий feature-cycle автоматически не назначается.

## Текущая рабочая блокировка — кандидат v173.57 / цикл 1731

- Exact-head GitHub CI `85157912581` проверил `v173.56`: CI `efhc.zip` размером `11975213` bytes совпадает с загруженным `EFHC_Bot_v173_56.zip`; checkout `5f16ea3d9008a0f53e949bd64b4f5794192419c3`. SHA-256 загруженного входного HEAD: `829c9380f98dafaa2a0889ca49d2061e93d89ce3921ea20c4d7c2961b68c6ebd`; CI-лог не публикует SHA-256 самого `efhc.zip`.
- Все canonical gates в предоставленном gate summary имеют `exit=0`: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci, frontend build и pytest. Pytest: `1502 passed / 22 skipped / 1 warning`.
- Цикл 1731 выполнен как статический backend/frontend + SSOT/CANON audit и handoff без запуска локальных tests/guards/lint/type/build/Alembic/CI.
- Подтверждённый protected floor: `312 symbols / 58 modules / 68 files / 135 OpenAPI paths / 140 operations / 38 frontend pages`; отсутствующих зарегистрированных элементов не найдено.
- Runtime/backend/frontend production code в цикле 1731 не изменяется: подтверждённые системные долги вынесены в handoff backlog, destructive cleanup запрещён.
- Синхронизируются только active audit/current-state/function-surface/OpenAPI metadata и обязательная cycle/report документация.
- Статус кандидата v173.57: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий номер feature/audit-цикла не назначается самовольно; сначала требуется exact-head CI нового кандидата, затем работа продолжается по зафиксированному handoff backlog по решению пользователя.

## Текущая рабочая блокировка — кандидат v173.56 / цикл 1730 continuation

- GitHub CI `85153784574` проверил `efhc.zip` размером `12053999` bytes; размер совпадает с загруженным `EFHC_Bot_v173_55.zip`. Checkout: `f5371d8f896486a2cbffe10584d76e65ebb7d959`.
- SHA-256 входного `EFHC_Bot_v173_55.zip` в рабочей среде: `9f4dc2aca6f0b191d2eec09e46317789e65c5647212cb05995683684dc15742d`; CI-лог не публикует SHA-256 самого входного `efhc.zip`, поэтому криптографическое равенство payload не утверждается.
- GREEN по предоставленному gate summary: Alembic/PostgreSQL, Bandit, compileall, Flake8 critical/full, Mypy, Ruff, npm ci и frontend build. FAILED только pytest.
- Pytest: `1 failed / 1501 passed / 22 skipped / 1 warning`; единственный failure — `manifest_sha_mismatch:docs/cycles/WORK_CYCLES_1701-1800.md`.
- Подтверждённая причина: `reports/manifests/CYCLE_ARCHIVE_MANIFEST.csv` содержал stale SHA `624741...8601`, тогда как фактический SHA cycle-range документа в v173.55 — `37dfdc83d5040fca169d82c2e2652c2ffeb202928841a8b7f050345139895eb8`. Это manifest drift; runtime/backend/frontend defect данным CI не подтверждён.
- Исправление ограничено cycle history manifest и обязательной current-state/reporting синхронизацией. Business semantics, compatibility surfaces, aliases, migrations и function-preservation floor не меняются.
- Function-preservation floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02259__cycle_1730_exact_head_ci_manifest_drift_followup.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Плановый следующий цикл: `1731 — backend/frontend audit + handoff`; начинать только после exact-head CI кандидата v173.56 без незакрытых failures.

## Текущая рабочая блокировка — кандидат v173.55 / цикл 1730

- GitHub CI `85145865998` проверил `efhc.zip` размером `12046473` bytes; размер совпадает с загруженным `EFHC_Bot_v173_54.zip`. Checkout: `3dd76713f4dea04ebb8d728385eab80f1726e41d`.
- CI-лог не содержит SHA-256 самого `efhc.zip`; принадлежность к `v173.54` дополнительно подтверждается содержимым failures: `TEST_GUARD_MANIFEST.version=v173.54` и новым consolidation document цикла 1729.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci и frontend build. FAILED: Mypy `4`; pytest `3 failed / 1499 passed / 22 skipped / 1 warning`.
- Исправлены только подтверждённые причины: четыре `no-any-return` на явных `global_id -> BIGINT` DB-boundaries; stale traceability exception list для active plan/consolidation docs; рассинхронизация `TEST_GUARD_MANIFEST` и `IDENTITY_MIGRATION_STATE_CURRENT`.
- String `global_id` contract, решения 1719–1729, compatibility surfaces и alias policy не менялись; нового cleanup не выполнялось.
- Function-preservation floor не изменён: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Immutable report: `reports_02258__cycle_1730_exact_head_ci_error_burn_down.md`.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий плановый цикл: `1731 — backend/frontend audit + handoff`; если новый exact-head CI выявит failures, сначала продолжается error burn-down цикла 1730.

## Текущая рабочая блокировка — кандидат v173.54 / цикл 1729

- GitHub CI `85124642409` проверил `efhc.zip` размером `11948789` bytes, совпадающим с входным `v173.53`; checkout `4814a284047508f2d825bf2edcfdfd6e716505cc`.
- GREEN по предоставленным логам: Ruff, Bandit, Flake8 critical/full, compileall, Alembic/PostgreSQL, npm ci. FAILED: Mypy `4`, pytest `4 failed / 1498 passed / 22 skipped`, frontend TypeScript build `4` errors.
- Исправлены только подтверждённые причины: typed global_id DB-boundary, compatibility markers, Admin notification owner string contract, stale payment test expectation и четыре frontend identifier/dataKind ошибки.
- Завершена консолидация решений 1719–1728; active matrix: `docs/audits/FUNCTION_RECOVERY_CONSOLIDATION_1719_1728.md`.
- Аудит алиасов удалил только 7 private transitional SQL aliases с полным delete-proof; ENV/provider/wire/history aliases и утверждённые compatibility facades сохранены.
- Function floor: 312 symbols / 58 modules / 68 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1730 — exact-head qualification и error burn-down`.

## Текущая рабочая блокировка — кандидат v173.53 / цикл 1728

- Exact-head GitHub CI `85114913383` проверил `v173.52` (`12015787` bytes, checkout `72c11ce34eb3ef9e75ee0e92164e0379fbe59128`): Ruff `1`, Mypy `5`, Bandit `B608 x2`, pytest `30 failed / 1472 passed / 22 skipped`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, compileall и npm ci — GREEN по предоставленным логам.
- Исправлены только подтверждённые CI-причины без отката string-`global_id`: DB-boundary typing, nullable reconciliation seam, Ruff import order, статический Bonus SQL, Admin Bank identifiers и конкретные stale integer-global-id test/architecture contracts.
- Цикл 1728 закрепляет runtime compatibility canon: `no caller != delete proof`.
- Бессрочные facades: `create_app`, DB getters, `d8`, `order_models.ShopOrder`; `app.bot.states` — официальный стабильный public FSM facade.
- `admin__main__handlers`, scheduler compatibility types/entrypoints и `tasks_maintenance.run_once` сохраняются бессрочно как compatibility-only; новый код строится на canonical modules/services.
- `RBAC.is_superadmin` — только helper уже разрешённого AdminUser, не auth-path.
- В каждом compatibility/тупиковом месте оставлены подробные русские комментарии-послания будущим аудитам; active canon: `docs/backend/RUNTIME_COMPATIBILITY_CANON.md`.
- Function floor: 312 symbols / 58 modules / 67 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1729 — консолидация десяти решений`.

## Текущая рабочая блокировка — кандидат v173.52 / цикл 1727

- Завершён цикл 1727 — Wallets, Payment Intents, Watcher и Reconciliation.
- GitHub CI `85097059497` на `v173.51`: Ruff 2, pytest 6 failures, Bandit dynamic-SQL failure, frontend checksum `pwa-build.json`; подтверждённые причины исправлены минимально.
- `payment_reconciliation_service.confirm_payment_intent` — единственная canonical точка подтверждения Payment Intent.
- Wallet/Payment/Watcher/Reconciliation boundaries используют строковый 10-значный `global_id`; BIGINT допускается только на явной DB-boundary через identity types.
- Payment UI использует `payment.flow.*` message keys и 13 локализаций вместо backend English user_message.
- Compatibility wallet/watcher seams сохранены fail-closed и помечены `DO NOT USE IN NEW CODE`.
- Function floor: 312 symbols / 58 modules / 66 files / 135 paths / 140 operations / 38 frontend pages.
- Локальные application tests/guards/lint/type/build/Alembic/CI не запускались.
- Статус: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1728 — Общие runtime compatibility surfaces.

## Текущая рабочая блокировка — кандидат v173.51 / цикл 1726

- Завершён цикл 1726 — Bonus Awards, Withdraw и Admin manual credits.
- Единственный ручной денежный путь: `/admin/transfer -> BankService.manual_bank_user_transfer -> BANK_EFHC <-> USER(global_id)`.
- Создан Admin-раздел «Бонусы и начисления» на активных источниках; dead `bonus_awards` не возвращён.
- Bonus/Withdraw разделены; EFHCb не выводится; `admin_mark_withdraw_paid` — compatibility-only `REPLACED_BY_CANON`.
- Function floor: 305 symbols / 56 modules / 63 files / 135 paths / 140 operations / 38 frontend pages.
- Последний supplied exact-head CI: `85014433515` на `v173.50`; новый `v173.51` требует следующего exact-head GitHub CI.
- Следующий цикл: 1727 — Wallets, payment intents, watcher и reconciliation.
## Текущая рабочая блокировка — кандидат v173.49

- Завершён цикл 1724 — входящие TON-платежи, депозиты и безопасное восстановление.
- Раздел `/admin/efhc-deposits` объединяет понятный обзор, список входящих операций, несопоставленные операции, повторную обработку и сверку за период.
- Произвольная ручная смена финансового статуса не возвращена; аварийная ручная обработка отделена от обычного восстановления.
- Admin Panel для пройденных разделов переводится на человеческие названия действий и состояний без изменения внутренних API-контрактов.
- Подтверждённые ошибки GitHub CI `85001150793` исправлены; локальные проверки приложения не запускались.
- Следующий цикл: 1725 — Admin NFT, VIP и manual claim.
- Релизные и служебные скрипты остаются защищённой операционной поверхностью.
## Cycle 1722 continuation — exact-head CI + Referrals/Ranks frontend merge lock — v173.47 candidate

- GitHub CI `84992216032` проверил exact `v173.46` (`12200437` bytes): Ruff `1`, pytest `2 failures`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, Mypy, Bandit, compileall, npm ci GREEN.
- Исправлены только подтверждённые CI causes; локальные tests/guards/lint/type/build/Alembic/CI не запускаются.
- Более позднее прямое решение пользователя в cycle 1722 отменяет промежуточный frontend defer: применён предоставленный Referral/Ranks patch поверх `v173.46`.
- `/referrals`, `/referrals/active`, `/referrals/inactive`, `/ranks` теперь protected `UI_CONNECTED` capability.
- `RankMode=kwh|referrals`, cache keys разделены; backend routes не дублируются.
- Referral stats/link/bonus asset/levels/list — только real backend; offline/demo/mock/sandbox запрещены.
- `global_id` остаётся внутренним owner/key и не выводится как публичное имя.
- Release/ops scripts остаются protected operational surface.
- Active frontend canon: `docs/frontend/REFERRALS_RANKS_FRONTEND_CANON.md`.
- Следующий цикл: `1723 — Admin financial/status utilities`.

## Cycle 1722 exact-head CI repair / Referral-Ranks defer lock — v173.46 candidate

- GitHub CI `84984088652` проверил `v173.45`: Ruff `7`, pytest `9 failures`, frontend TypeScript build FAILED; Alembic/PostgreSQL, Flake8, Mypy, Bandit и compileall GREEN.
- Исправляются только подтверждённые CI regressions Shop/contracts/generators; локальные tests/builds/guards не запускаются.
- Referral и Ranks по прямому решению пользователя **не меняются**: их полный frontend существует отдельно и будет объединяться позднее.
- `/ranks/referrals/my-plus-top/me` и `/ranks/referrals/top/me` сохраняются как protected backend contracts.
- Отсутствие current frontend caller для Referral/Ranks не является основанием cleanup/delete.
- Статус Referral/Ranks: `DEFERRED_TO_FRONTEND_MERGE`.
- Release/ops scripts остаются protected operational surface.
- Следующий цикл: `1723 — Admin financial/status utilities`.

## Cycle 1721 unified Shop Management lock — v173.45 candidate

- `/admin/shop`, `/browser-shop`, `/shopfront/profile`, Shop catalog и Order Control являются одной защищённой capability.
- Canonical Shop item storage: `sku/title/description/quantity_efhc/is_active/extra JSONB`; новые card types расширяются через `extra`.
- Admin Shop Editor управляет карточками, ценами, payment methods, status, history, category/badge/action/delivery/sort order.
- `/admin/shop/orders/status-counters` — global whole-table dashboard; historical status utility больше не потерян.
- `admin_force_fulfill_order` восстановлен на `global_id`; EFHC recovery credit только через BANK/idempotency.
- `/shopfront/profile` подключён к внешнему Browser Shop после signed handoff.
- Physical delete карточки блокируется при order history; history сохраняется.
- `tg_id` ownership в Shop запрещён.
- Release/ops scripts остаются protected operational surface.
- Новый exact-head CI обязателен; локальные tests/builds/guards не запускались.
- Следующий цикл: `1722`.

## Cycle 1720 Admin Tasks Editor lock — v173.44 candidate

- Полный Tasks Editor (`create/detail/update/deactivate/safe-delete`) является действующей Admin capability и не подлежит cleanup без прямого ТЗ.
- Physical delete fail-closed: при submissions/status/bonus-log/complete-lock history используется деактивация.
- `code` задания после появления истории не меняется.
- Submissions/moderation и банковская idempotent выплата сохраняются как основа Tasks.
- `/admin/tasks/refresh-statuses` — compatibility имя; фактическая функция только retention maintenance `task_complete_lock`.
- Task maintenance нельзя смешивать с TON transaction watcher: `check_ton_inbox/job_ton_watcher` — отдельная active payment/reconciliation capability.
- `/admin/ads` — отдельный защищённый provider contour; Tasks не дублирует секретную конфигурацию провайдеров.
- Release/ops scripts остаются protected operational surface.
- Новый exact-head CI обязателен; локальные tests/builds/guards не запускались.
- Следующий цикл: `1721`.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V3 -->
Identity anchor: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`.

## Cycle 1719 Admin Reports/Observability lock — v173.43

- `/admin/observability/events` — сознательная compatibility-заглушка `disabled_duplicate`; причина — дублирование `/admin/logs/transfers`. DB-read в заглушке запрещён без нового решения пользователя.
- Пять `/admin/reports/{users,bank,panels,withdrawals,deposits}` — действующие Admin capabilities и подключены к `/admin/reports`.
- Users report ownership join — только `global_id`.
- BANK report — только единый `EFHC_MAIN`; ledger filter — `system_entity=BANK_EFHC`.
- Release/ops scripts защищены: удаление, переименование, semantics cleanup и потеря executable mode без прямого ТЗ или конкретного CI evidence запрещены. Release archives готовятся после завершения code phase по отдельному решению пользователя.
- Статус нового HEAD: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`. Следующий цикл: `1720`.

## Cycle 1718 exact-head CI repair + function recovery plan lock — v173.42

- GitHub CI `84954546920` проверил exact archive `v173.41` (`12135299` bytes).
- Green gates: Alembic/PostgreSQL, Flake8, Bandit, compileall, Ruff, frontend production build.
- Failed gates: Mypy (`2` no-any-return) и pytest (`17 failed, 1485 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes: Admin facade typing, Account Registration ordering по active SSOT, stale final-cutover test contracts/fixtures, payment watcher injection contract и новые нарушения Russian engineering language policy.
- Retired `tg_id` ownership, `users.tg_id` fallback, migration-control/read-switch layers не возвращены.
- Подтверждён packaging defect `v173.41`: восстановлены executable modes `50` release/ops scripts и `28` Unicode historical report filenames с неизменным содержимым.
- Создан active план `docs/PLANS/WORK_PLAN_1719-1731_FUNCTION_RECOVERY.md`: 1719–1728 — 10 волн согласования; 1729 — consolidation; 1730 — exact-head CI qualification; 1731 — frontend/audit handoff preparation.
- Локальные application tests/builds/guards/CI не запускались.
- Статус `v173.42`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1719 — Admin Observability и Reports: исследование и согласование`.

## Cycle 1717 exact-head CI + extended function preservation lock — v173.41

- GitHub CI `84948550953` проверил exact archive `v173.40` (`12124946` bytes), checkout `c7b68ff0cf7b1ae4562b967cccc3979209d86c3d`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, frontend production build.
- Failed gates: Ruff (`1` I001) и pytest (`45 failed, 1456 passed, 22 skipped`).
- Исправлены только подтверждённые CI causes; stale final-cutover test contracts не используются для возврата retired `tg_id` ownership/migration-control layers.
- Подтверждённый payment compatibility loss восстановлен на `global_id`: wallet `_confirm_payment_intent`, bank-credit facade и watcher/reconciliation injection seam; external-shop reason приведён к размеру DB-поля.
- По прямому ТЗ продолжен `v171.89` Admin/function/routes/docs audit: восстановлены safe Admin MAIN/BONUS credit facades и NFT-maintenance compatibility wrappers; старые tg-owned Admin CRUD/security authorities не возвращены.
- Active function registry расширен до `259` symbols / `44` modules / `14` required files. Расширенный control test локально **не запускался**.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.41`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1718 — exact-head CI follow-up`.

## Cycle 1716 exact-head CI + function preservation audit lock — v173.40

- GitHub CI `84942802763` проверил exact archive `v173.39` (`12095859` bytes), checkout `0eeaffa5a4c099ef2605585f886b60d165f86958`.
- Green gates: Alembic/PostgreSQL, flake8, Mypy, Bandit, compileall, npm ci/frontend production build.
- Failed gates: Ruff (`3` I001) и pytest (`61 failed, 1307 passed, 22 skipped, 130 errors`).
- Массовый pytest setup-cluster подтверждён stale test references к retired `efhc_core.identity_migration_control`; production schema не откатывалась, потому что final global_id cutover и GREEN Alembic/PostgreSQL подтверждают retirement transition table.
- По прямому ТЗ пользователя выполнен historical function-preservation audit against `v171.89`, Admin/routes/docs audit и создан fail-closed application function surface manifest + CI control test. Контрольный тест локально **не запускался**.
- Safe compatibility entrypoints восстановлены только там, где они делегируют current canonical implementation и не возвращают `tg_id` ownership. Legacy tg-owned Admin CRUD/migration compatibility не восстанавливалась.
- Active function catalog: `docs/SSOT/APPLICATION_FUNCTION_SURFACE.md`; audit: `docs/audits/APPLICATION_FUNCTION_PRESERVATION_AUDIT.md`.
- Статус `v173.40`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: `1717 — exact-head CI follow-up.


## Cycle 1715 exact-head CI repair lock — v173.39

- GitHub CI `84940689623` проверил exact current archive `v173.38` (`11816383` bytes), checkout `cd0bea87936db8f218290d25121e41d0ba784b3f`.
- Green gates на `v173.38`: Alembic upgrade, PostgreSQL preflight, flake8 critical/full, Mypy, Bandit, compileall, npm ci, frontend production build.
- Failed gates: Ruff (`22` import-hygiene diagnostics) и pytest collection (`4` collection errors; test execution не началось).
- Cycle 1715: исправлены только эти подтверждённые причины. Ruff patch ограничен import ordering/placement; четыре CI-failed test locations минимально переведены на уже действующие canonical `global_id`/idempotency interfaces. Retired migration read-switch/control wrappers в production не возвращались.
- Локальные test/lint/type/build/Alembic/CI проверки не запускались. Статус `v173.39`: `PATCH IMPLEMENTED / NEXT EXACT-HEAD GITHUB CI REQUIRED`.
- Следующий цикл: 1716 exact-head CI follow-up.

## Post-migration qualification lock v173.37 / циклы 1712–1713

- GitHub CI `84923645231` проверил byte-exact Development archive `v173.36`.
- Checkout SHA: `cb915ded036615efaec297689787a3a5053a36e0`.
- `efhc.zip`: `11877960` bytes; Git blob SHA-1 `7139f9e65515d4fd553fad0872710d72dc842336` совпадает с локальным `EFHC_Bot_v173_36.zip`.
- Все canonical gates GREEN; pytest `1498 passed / 22 skipped / 1 warning`.
- Cycle 1712: ownership migration квалифицирована: `business_owner_tg_id=0`, actionable identity queue=0, semantic mix=0, PostgreSQL `0001` PASS, exact-head CI GREEN.
- Cycle 1713: выполнен post-migration runtime cleanup. Retired business `tg_id` routes/switches, dual-write/read-switch infrastructure, dead aliases/stubs/test façades и no-caller compatibility modules удалены.
- Сохранены только доказуемые внешние/исторические boundaries: Telegram provider ingress/delivery, TON memo/deposit read-through, historical idempotency replay и bounded stored-data compatibility.
- `v173.37` содержит cleanup patch и требует нового exact-head GitHub CI. Следующий цикл: `1714 — Alias cleanup qualification`.

## Cross-layer/admin access lock v173.26 — HISTORICAL / SUPERSEDED

Историческая запись момента, когда 1705 был выполнен раньше 1704. В текущем
HEAD оба цикла 1704 и 1705 уже завершены. Admin rights определяются только server-side session +
canonical `global_id` + active `admin_whitelist` + explicit RBAC role. Provider
subject не выдаёт admin rights; frontend показывает admin entry только после
успешного `GET /admin/access`. Автоматический fallback до SuperAdmin запрещён.

## Security/audit identity lock v173.24

Цикл 1703: privileged/session owner и audit actor используют только canonical `global_id`. Provider subjects (`tg_id`, `ton_wallet_id` и остальные provider subjects) не являются privileged/audit owner, не включаются в новые internal handoff claims и редактируются из diagnostics/logs. Admin Bank financial owner остаётся `global_id`; Telegram metadata допустима только как delivery или bounded historical read-through.

## TON provider-subject canon lock v173.23

Утверждено пользователем 2026-08-08: `provider=ton`, provider subject
`ton_wallet_id`, значение `ton_wallet_id` — сам адрес TON-кошелька. При первом
подтверждённом входе новый `ton_wallet_id` получает новый `global_id`; при
повторном входе используется существующая связь. `ton_address` запрещено как
provider-subject alias. Generic `user_identities.provider_subject` для TON
хранит значение `ton_wallet_id`. Технические address concepts
`wallet_bindings.wallet_address`, `users.ton_wallet`, `dest_ton_address` и
`app.lib.ton_address` не являются provider-subject aliases и не
переименовываются этим каноном.


## Identity-stage interpretation lock v173.06

Любые нижние блоки с `users.user_id`, Alembic `0002`, pre-read-switch или
legacy-authoritative ownership являются историческими cycle snapshots. Они не
могут переопределять current canon: `users.global_id` — physical owner, `tg_id`
— Telegram provider subject, один Alembic head — `0001_initial_release_schema.py`.

# Текущий статус v173.02 — цикл 1685

Цикл исправляет критическое повреждение v173.01 и продолжает
fix-forward переход referral/identity-resolution контура на
единственного business owner `global_id`.

GitHub CI v173.01 не завершился: pytest дошёл до 94%, показал три
реферальных падения, после чего PostgreSQL удерживал блокировки
`referral_links/users` до принудительной отмены job по лимиту времени.
Причина находилась в изменениях цикла 1684: чрезмерный test codemod
создал `provider_provider_tg_id`, рассинхронизировал provider fixtures,
оставил старые referral SQL/test contracts и допустил lock cascade.
GitHub infrastructure не является причиной сбоя.

В v173.02 повреждённые provider-имена и fixtures восстановлены, а
принудительный переход тестов контролируется семантическим AST-guard:
вызовов business services через `tg_id` — `0`. Telegram/provider,
physical schema и historical read-through употребления сохраняются
только как построчно зарегистрированные исключения.

Referral domain переведён по цепочке schema → ORM → CRUD → services →
routes → frontend → tests. `referral_links`, `referral_codes` и
`referral_bonus_ledger` используют обязательный `global_id` как owner;
Telegram-поля остаются nullable provider metadata без business FK,
unique или self-check. Concurrent Telegram `/start` сериализуется
advisory transaction lock до проверки и создания аккаунта.

Текущая матрица содержит `3349` identity token-употреблений. Из них
`1764` открыто либо требует symbol-level решения, `1585` разрешено или
сохранено. За цикл actionable/review-остаток сокращён на `117`.
Миграция не завершена.

```text
CURRENT_HEAD_V173_02
CI_FAILURES_CORRECTED_LOCALLY
CRITICAL_CI_TIMEOUT_CAUSE_REPAIRED_LOCALLY
REFERRALS_GLOBAL_OWNER_CUTOVER
REFERRAL_PHYSICAL_SCHEMA_GLOBAL_OWNER
SEMANTIC_TEST_GLOBAL_ID_CUTOVER
TEST_BUSINESS_SELECTOR_VIOLATIONS_ZERO
TG_ID_FINAL_MATRIX_UPDATED
BUSINESS_OWNER_TG_ID_NOT_ZERO
NEXT_CYCLE_1686
REMAINING_PLAN_CYCLES_5
EXACT_HEAD_CI_REQUIRED
```

---

# Утверждённый канон провайдеров — 2026-08-05

```text
Telegram → tg_id
TON      → ton_wallet_id
Google   → google_id
Apple    → apple_id
Facebook → fb_id
Discord  → discord_id
GitHub   → github_id
provider + subject → global_id
```

`global_id` — единственный business owner. Один `global_id` может иметь несколько provider identities. После identity resolution весь business runtime использует только `global_id`.

SSOT: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
Причинность: `docs/SSOT/PROVIDER_IDENTITY_MAPPING_SSOT.md`.
NORM: `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`.
Следующий цикл: реализация канона в runtime, ORM, API, migration, tests и guards.

---

# Текущий статус v172.70 — исправление CI и продолжение циклов 1641–1646

Fresh CI run `30944313472`, commit `02667638d2b423fbc733a8e32a88b44996a3ba6e`, подтвердил зелёные Alembic, Flake8, Mypy, Bandit, compileall, PostgreSQL diagnostic и frontend build. Исправлены 2 Ruff errors и 2 pytest failures. Tasks read API переведён на canonical `global_id` signatures с централизованным legacy alias boundary. Полный inventory `tg_id` хранится в `reports/generated/`.

```text
CURRENT_HEAD_V172_67
CI_FAILURES_CORRECTED_LOCALLY
TASKS_READ_OWNER_BATCH_IMPLEMENTED
TG_ID_GLOBAL_INVENTORY_GENERATED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.66 — безопасная пересборка global owner

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как доказательства и не переопределяют v172.66.

Fresh main CI run `30937377315` exact v172.65 подтвердил Alembic,
Flake8, compileall, PostgreSQL diagnostic и `npm ci`. Он выявил
механическое повреждение массового codemod:

- Ruff: 9 ошибок;
- Mypy: 22 ошибки;
- Bandit: 1 ошибка;
- frontend build: ошибки TypeScript;
- pytest: `181 failed, 3080 passed, 28 skipped`.


Обязательный процесс работы с пользовательскими CI-логами закреплён в
`docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md и docs/AI/TOPIC_READING_ROUTES.md`. При наличии полного
архива логов запрещены бессмысленные дублирующие полные локальные CI,
pytest-shards и повторы уже зелёных этапов. Разрешены только проверки,
непосредственно связанные с подтверждёнными failures.

Корневая причина — слепая замена семантически разных provider-полей и
business-owner полей одинаковым именем `global_id`. Она создала
duplicate arguments, повреждённые SQL, DTO и frontend contracts.

В v172.66 выполнена controlled rebase пересборка:

- рабочее runtime-ядро циклов 1641–1646 восстановлено из v172.64;
- canonical бизнес-владелец остаётся `global_id`;
- временный `global_owner_alias.py` сохранён как единая граница;
- Telegram provider ingress и физические legacy-поля изолированы;
- compatibility baseline заморожен: он может только уменьшаться;
- новые runtime-файлы с `tg_id` запрещены machine guard;
- ошибки Ruff/Mypy/frontend из повреждённого codemod устранены возвратом
  корректных реализаций;
- Bandit `B101` устранён без `assert`;
- точечный набор всех 90 test-файлов, упавших в переданном CI,
  прошёл: `384 passed, 90 skipped`;
- test collection: `3358 tests`;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_66
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1646_RUNTIME_KERNEL_RESTORED
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
TG_ID_COMPATIBILITY_BASELINE_FROZEN
TG_ID_COMPATIBILITY_MAY_ONLY_DECREASE
MECHANICAL_BIG_BANG_CODEMOD_REJECTED
USER_PROVIDED_CI_LOGS_REPAIR_CANON_LOCKED
EXACT_CI_FAILURE_SET_TARGETED_PASS
EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.65 — Global Owner Big-Bang Rewrite

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.65.

Выполнен глобальный аудит всех `tg_id` и массовый switch бизнес-runtime
на canonical `global_id` по методу первых identity-циклов.

- изменено 158 runtime-файлов;
- введён единый `global_owner_alias.py`;
- Telegram provider fact имеет каноническое имя `tg_id`;
- `User.tg_id` хранит только внешний Telegram ID и не является business owner;
- business runtime debt вне allowlist равен нулю;
- provider/schema/history/test употребления сохранены контролируемо;
- backend compileall завершён успешно;
- функциональные тесты, PostgreSQL и static CI намеренно отложены на
  следующую фазу;
- production cutover не выполнялся;
- public visual, Admin UX, screenshot workflow и canonical CI не менялись.

```text
CURRENT_HEAD_V172_65
APPROVED_PLAN_1640_1665_LOCKED
GLOBAL_TG_ID_AUDIT_COMPLETE
BUSINESS_RUNTIME_BULK_REWRITE_COMPLETE
GLOBAL_OWNER_ALIAS_HARNESS_ACTIVE
BUSINESS_RUNTIME_TG_ID_DEBT_ZERO_BY_BOUNDARY_GUARD
GLOBAL_OWNER_BULK_REWRITE_READY_FOR_TEST_REPAIR
FUNCTIONAL_TEST_QUALIFICATION_NOT_STARTED
RUNTIME_NOT_QUALIFIED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.64 — циклы 1641–1646

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.64.

Fresh main CI run `30927024899` exact v172.63 подтвердил Alembic,
Ruff, Flake8, Bandit, compileall, PostgreSQL diagnostic и production
frontend build. Mypy нашёл одну nullable-selector ошибку. Pytest
завершился результатом `5 failed, 3251 passed, 28 skipped`.

В v172.64 локально исправлено:

- Exchange selector получил явное type narrowing для Mypy;
- cutover tests используют `efhc_core.alembic_version` и реальное
  shadow mismatch вместо записи в read-only telemetry view;
- nullable Tasks cursor имеет явный PostgreSQL `TEXT` cast;
- clean-schema contract приведён к фактическим 40 FK после `0002`;
- concurrency reset восстанавливает обязательный migration-control row;
- Alembic `0002` поддерживает offline SQL generation;
- проведён полный аудит legacy aliases;
- удалены четыре финансовых `*_by_tg_id` wrappers без runtime-callers;
- удалён мёртвый Payment Intent alias `STATUS_SENT`;
- provider-ingress и активные compatibility seams сохранены;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline и Admin UX не изменялись;
- production cutover не выполнялся.

```text
CURRENT_HEAD_V172_64
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1646_ALIAS_AUDIT_COMPLETE
CYCLE_1646_SAFE_ALIAS_REMOVAL_STARTED
CYCLE_1646_EXACT_HEAD_CI_REQUIRED
CYCLE_1647_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.63 — коррекция циклов 1641–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.63.

Fresh main CI run `30921046975` exact v172.62 подтвердил Flake8,
Mypy, compileall, PostgreSQL diagnostic и production frontend build.
Alembic остановился на schema guard: ожидалось 38 FK на
`users.global_id`, фактически после Achievements их стало 39. Ruff нашёл
четыре unused Referral imports, Bandit — четыре dynamic SQL boundary.
Pytest завершился результатом `32 failed, 3094 passed, 28 skipped` и
`130 errors`; основная часть errors была каскадом незавершённого Alembic.

В v172.63 локально исправлено:

- schema validator и architecture contract приведены к фактическим 39 FK;
- четыре unused Referral imports удалены;
- cutover, Admin backend и Exchange используют фиксированные SQL/ORM;
- post-cutover read control поддерживает полный режим `0001 -> 0002`;
- readiness признаёт обе поддерживаемые revisions: `0001` и `0002`;
- переходные compatibility seams сохранены до циклов 1646–1647;
- HTTP self-routes продолжают использовать canonical `global_id`;
- прямые legacy-вызовы тестов не публикуют `tg_id` в новых HTTP API;
- wallet gate и Withdraw используют canonical owner;
- line-72 и identity-boundary guards исправлены без роста legacy scope;
- canonical main CI и screenshot workflow не изменялись;
- public visual baseline не изменён;
- production cutover не выполнялся.

Локальная полная проверка текущего дерева:

- полный pytest: `3107 passed, 252 skipped`;
- architecture registry: `2507 passed, 6 skipped`;
- domain sweep циклов 1641–1645: `126 passed, 97 skipped`;
- test collection: `3348 tests`;
- backend compileall: `PASS`.

```text
CURRENT_HEAD_V172_63
APPROVED_PLAN_1640_1665_LOCKED
CYCLES_1641_1645_CI_FAILURES_CORRECTED_LOCALLY
CYCLES_1641_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.62 — циклы 1644–1645

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.62.

Fresh main CI run `30869292077` exact v172.61 подтвердил Ruff, Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic `0001` и
production frontend build. Pytest завершился результатом
`21 failed, 3227 passed, 28 skipped`.

В v172.62 локально исправлено:

- nullable Referral idempotency parameter получил явный PostgreSQL cast;
- Tasks JSON expression приведён к единому JSONB contract;
- concurrency fixtures больше не сохраняют пустую строку `ton_wallet`;
- stale architecture baselines и запрещённый identifier alias устранены;
- cycle 1644 guards приведены к canonical Tasks/Ranks/Wallet ownership;
- текущие user routes, bot handlers и service callers используют
  canonical `global_id` после server-side identity resolution;
- `/sync/me`, Exchange, Panels, Tasks, Ranks, Withdrawals и Payment
  Intents больше не требуют Telegram ID как business owner;
- Payment Intent watcher принимает canonical token `G##########` и
  TON-only wallet binding;
- Achievements и referral codes подготовлены к обязательному `global_id`;
- добавлена Alembic revision `0002` для cutover preparation;
- добавлен изолированный операторский preflight/cutover/rollback service;
- migration `0002` не переключает production flags автоматически;
- public UI, Admin UX, screenshot workflow и canonical main CI не менялись.

```text
CURRENT_HEAD_V172_62
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1644_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1645_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1644_1645_EXACT_HEAD_CI_REQUIRED
CYCLE_1646_NOT_STARTED
PRODUCTION_CUTOVER_PREPARED_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.61 — циклы 1643–1644

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.61.

Fresh main CI run `30870996170` exact v172.60 подтвердил Flake8,
Mypy, Bandit, compileall, PostgreSQL diagnostic, Alembic и production
frontend build. Ruff остановился на одном SIM117. Pytest завершился
результатом `36 failed, 3210 passed, 28 skipped`.

В v172.61 локально исправлено:

- duplicate seed обязательного `identity_migration_control` заменён
  идемпотентным `ON CONFLICT DO NOTHING`;
- nullable Referral SQL parameter получил явный `BIGINT` cast;
- bank mirror отделён от пользовательского owner и больше не создаёт
  orphan provider mapping;
- Admin, Panel и Payment Intent fixtures приведены к реальному identity
  contract без ослабления production dual-write triggers;
- цикл 1644 переводит Tasks, ad rewards, Ranks, Leaderboard и Wallet reads
  на canonical `global_id`;
- TON-only account поддержан в task reward, wallet reads и rankings;
- Telegram join/proof/connect остаются provider-specific operations;
- ranks snapshot включает всех active owners и хранит nullable `tg_id`;
- visual, Admin UX, screenshot workflow, canonical main CI и production
  cutover flags не изменялись.

```text
CURRENT_HEAD_V172_61
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1643_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1644_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1643_1644_EXACT_HEAD_CI_REQUIRED
CYCLE_1645_NOT_STARTED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.60 — циклы 1641–1643

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.60.

Fresh main CI run `30864230797` exact v172.59 подтвердил Alembic,
PostgreSQL diagnostic, compileall, Flake8 и production frontend build. Он
выявил четыре реальные группы ошибок: отсутствие обязательного singleton
после test-TRUNCATE, static/type/security нарушения, потерянный повторный
idempotency read-through и legacy referral fixtures без shadow global_id.

В v172.60 локально исправлено:

- test infrastructure восстанавливает обязательный
  `identity_migration_control` после очистки схемы;
- production resolver не ослаблен и не создаёт control row автоматически;
- Ruff, Mypy, Bandit и русскоязычные engineering-policy причины устранены;
- post-lock idempotency read-through возвращён в transaction entrypoints;
- цикл 1643 переводит referral reward ownership на canonical `global_id`;
- исторические referral rows читаются по `tg_id` только при
  `global_id IS NULL`;
- `REF_ACT_UNIT`, `REF_LVL` и exchange keys получили canonical
  `G##########` форму с compatibility read-through старых ключей;
- до cutover новые операции сохраняют legacy key при
  `legacy_authoritative=TRUE`, после cutover выбирают canonical key;
- visual, Admin, screenshot workflow, canonical main CI и production flags
  не изменялись.

```text
CURRENT_HEAD_V172_60
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1641_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1642_CI_FAILURES_CORRECTED_LOCALLY
CYCLE_1643_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1643_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.59 — циклы 1641–1642

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.59.

По прямой команде пользователя работа продолжена без screenshot-контура.
Frontend, Admin и screenshot workflow не изменялись. Изменения ограничены
каноническим финансовым владельцем и доменными сервисами.

Выполнено локально:

- денежные entrypoints принимают `global_id` или временный `tg_id`;
- каждая операция нормализуется до canonical `global_id`;
- ledger dual-write сохраняет `global_id` и nullable provider `tg_id`;
- idempotency read-through един для обоих selector;
- TON-only account поддержан в транзакциях без Telegram ID;
- Panels переведены на canonical owner;
- Withdraw request, hold, cancel и refund используют `global_id`;
- новые Payment Intents создаются по canonical owner;
- payload поддерживает legacy Telegram token и `G##########`;
- provider-колонки финансовых таблиц подготовлены как nullable;
- migration-control и production cutover flags не переключались.

Открытые границы:

- watcher ещё должен получить canonical payload owner в цикле callers;
- referral idempotency нормализуется отдельно;
- legacy aliases удаляются только в утверждённых cleanup-циклах;
- PostgreSQL, полный pytest и static gates требует exact-head CI.

```text
CURRENT_HEAD_V172_59
APPROVED_PLAN_1640_1665_LOCKED
CYCLE_1640_WRITE_OWNER_FOUNDATION_PRESERVED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.58 — цикл 1640 visual corrective

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены как evidence и не переопределяют v172.58.

Пользователь полностью утвердил план циклов 1640–1665 и потребовал немедленно
удалить неутверждённый декоративный слой v172.51. v172.58 является
селективным visual rollback поверх v172.57: backend/global_id foundation не
откатывается.

Выполнено:

- `EFHC_Bot_v172_50.zip` закреплён как public visual baseline;
- удалены premium dock, halo, многослойные тени, active lift и separators;
- восстановлен простой `KwhIcon`;
- удалён Energy marker поверх progress bar;
- восстановлена исходная profile topbar;
- полностью удалён поздний 336-строчный CSS override layer;
- сохранены `navigateBackWithinApp()`, profile sections, safe-area и QA attrs;
- добавлен architecture guard против возврата отклонённых tokens;
- утверждённый план записан в
  `docs/cycles/WORK_CYCLES_1601-1700.md`.
- рабочий screenshot workflow run `30855423325` закреплён без переписывания.

Не изменялись schema, migrations, financial formulas, global_id write-side
foundation, canonical main CI и production cutover flags.

```text
CURRENT_HEAD_V172_58
APPROVED_PLAN_1640_1665_LOCKED
PUBLIC_VISUAL_BASELINE_V172_50_LOCKED
V172_51_DECORATIVE_LAYER_REMOVED
CYCLE_1639_SCREENSHOT_CAPTURE_PASS_102_OF_102_EXACT_V172_56
CYCLE_1639_VISUAL_ACCEPTANCE_FAILED_AND_CORRECTED_LOCALLY
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.57 — цикл 1640

> Этот верхний раздел является текущим SSOT. Исторические разделы ниже
> сохранены только как evidence и не переопределяют v172.57.

Директива пользователя изменила порядок работы: visual screenshots остаются
отдельной незакрытой evidence-задачей, но больше не блокируют развитие
`global_id` business ownership.

Подтверждено для базового exact v172.56:

- main GitHub CI PASS;
- PostgreSQL 16 и canonical Alembic `0001` PASS;
- pytest: `3220 passed`, `28 skipped`;
- Flake8, Ruff, Mypy, Bandit, compileall и frontend build PASS.

В v172.57 реализован фундамент цикла 1640:

- новый `resolve_and_lock_financial_write_owner()`;
- ровно один selector: `global_id` или `tg_id`;
- результат всегда нормализуется до canonical `global_id`;
- строка `users` блокируется через `FOR UPDATE`;
- write path требует `dual_write_enabled`;
- TON-only owner разрешён без `legacy_tg_id`;
- read/write используют единый loader migration control;
- завершён audit idempotency ownership;
- выявлены три Telegram-coupled key path для исправления в циклах 1641/1643.

Application services массово ещё не переключены. Schema/migration/finance
semantics в v172.57 не изменялись.

```text
CURRENT_HEAD_V172_57
CYCLE_1639_EXACT_HEAD_MAIN_CI_PASS
CYCLE_1639_VISUAL_EVIDENCE_DEFERRED_BY_USER
CYCLE_1640_WRITE_OWNER_FOUNDATION_IMPLEMENTED
CYCLE_1640_IDEMPOTENCY_AUDIT_COMPLETE
CYCLE_1640_LOCAL_TESTS_PASS
CYCLE_1640_EXACT_HEAD_CI_REQUIRED
CYCLE_1641_NOT_STARTED
CYCLE_1642_NOT_STARTED
CYCLE_1643_NOT_STARTED
CYCLE_1644_NOT_STARTED
CYCLE_1645_NOT_STARTED
CYCLE_1646_NOT_STARTED
CYCLE_1647_NOT_STARTED
CYCLE_1648_NOT_STARTED
CYCLE_1649_NOT_STARTED
CYCLE_1650_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Текущий статус v172.56 — цикл 1639 corrective

Fresh GitHub CI `83583696254` проверил exact `v172.55`:

- размер: `12670026` байт;
- SHA-256: `cb90140a7aab41f3e9cd7210a517ab032c056db80b7dafecd0ccbe5afbe774f1`;
- PostgreSQL, Alembic `0001`, Flake8, Ruff, Mypy, Bandit, compileall и
  production frontend build: PASS;
- pytest: `3219 passed`, `28 skipped`, один PostgreSQL failure;
- Chromium: корректно пропущен после обязательного pytest failure;
- CI artifacts успешно загружены; fresh PNG отсутствуют.

Единственный failure находился в qualification fixture
`test_межпровайдерный_cycle_не_создаётся_late_binding`: fixture назначал
TON-first пользователю `tg_id` и в той же транзакции добавлял
`ReferralCode`, но не задавал явную точку flush. Поскольку ORM relationship
между этими операциями отсутствует, SQLAlchemy мог отправить INSERT кода до
UPDATE `users.tg_id`, и строгий PostgreSQL FK корректно отклонял запись.

`v172.56` исправляет только порядок qualification fixture:

- после назначения `b_user.tg_id` выполняется `await session.flush()`;
- затем вставляется `ReferralCode`;
- существующий FK `referral_codes_inviter_tg_id_fkey` не ослабляется;
- production registration code, ORM models, migration `0001`, referral
  attribution, locks, sessions, financial logic и public UI не меняются;
- цикл `1640` не начат.

```text
CURRENT_HEAD_V172_56
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_RUNTIME_QUALIFIED
CYCLE_1638_REFERRAL_TRANSPORT_RUNTIME_QUALIFIED
CYCLE_1639_ALL_PROVIDER_CALLERS_IMPLEMENTED
CYCLE_1639_POSTGRESQL_FIXTURE_CORRECTED
CYCLE_1639_EXACT_HEAD_CI_REQUIRED
ALL_REGISTRATION_PATHS_USE_SINGLE_CENTER
PROVIDER_NEUTRAL_FIRST_REGISTRATION_IMPLEMENTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```
---
# Актуальный kernel status — v172.39 corrective

Fresh CI `83288192546` прошёл все gates, кроме одного pytest contract
архивной гигиены. Причина — повреждение 28 русских имён при цепочке
Info-ZIP → Python extraction → повторная упаковка. v172.39 является
только corrective package цикла `1630`; physical rename не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Universal CI неизменяем. Alembic head `0012`; migration `0013`
отсутствует. Следующий gate — полный exact-head CI v172.39.

---

# Актуальный kernel status — v172.38 corrective

Fresh CI `83283286008` проверил exact v172.37. Все database,
static, security и build gates прошли, но pytest и общий Chromium
gate остались красными. v172.38 является только corrective package
цикла `1630`; physical rename не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Universal CI неизменяем. Alembic head `0012`; migration `0013`
отсутствует. Следующий gate — полный exact-head CI v172.38.

---

# Актуальный kernel status — v172.37 corrective

Fresh CI `83263164491` квалифицировал exact v172.36 по всем gates,
кроме общего route-backed Chromium audit. Единственный finding:
`51` admin marker failures (`17 × 3`), при HTTP `200` и нулевых
page/console errors. Исправлен порядок Telegram identity bootstrap в
`frontend/src/pages/_app.tsx`; universal CI, migrations и financial
runtime не изменены.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Primary Operator Kernel route остаётся `ci_log_exact_failure_repair`.
Alembic head `0012`; `0013` отсутствует.

---

# Актуальный kernel status — v172.36 corrective

```text
CYCLE_1630_CROSS_PROVIDER_SESSION_CHROMIUM_PROOF_PASS
CYCLE_1630_ROUTE_BACKED_VISUAL_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83255023989` на exact v172.35 подтвердил PostgreSQL,
Alembic `0012`, static/type/security gates, frontend build и отдельный
Telegram/TON cross-provider Chromium proof. Общий route-backed browser
gate выявил CSP/status/admin-build findings; pytest выявил stale
historical current-CI assertions. Corrective v172.36 исправляет только
эти доказанные findings. Primary route остаётся
`cross_provider_e2e_fallback_closure`; `0013` отсутствует.

---

# Актуальный kernel status — v172.35 corrective

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83240274364` на exact v172.34 выполнил real PostgreSQL и
real Chromium, но Chromium audit завершился `exit=1`. Corrective v172.35
исправляет только доказанные tests/lint findings, ожидание auth request,
browser failure diagnostics и canonical CI embedding. Alembic head —
`0012`; `0013` отсутствует. Primary route остаётся
`cross_provider_e2e_fallback_closure`.

---

# Актуальный kernel status — v172.34 corrective

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83236222987` не дал exit gate цикла `1630`: corrected
cross-provider API test не дошёл до assertion из-за test DB dependency,
а Chromium E2E был пропущен. В `v172.34` harness исправлен, visual proof
встроен в существующий route-backed Chromium audit без изменения
workflow. Current Alembic head — `0012`; migration `0013` отсутствует.
Primary route остаётся `cross_provider_e2e_fallback_closure`.

---

# Актуальный kernel status — v172.33

```text
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_EXACT_HEAD_PASS
CYCLE_1629_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1630_CROSS_PROVIDER_E2E_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83193385549` на exact v172.32 не выявил critical blocker.
Simple pytest/Mypy/TypeScript findings исправлены. Цикл `1630` закрывает
business-auth fallback на raw Telegram `initData`, сохраняет explicit
Telegram session exchange и проверяет Telegram/TON sessions одного
`global_id` через PostgreSQL/API/Chromium contracts. Alembic head
`0012`; `0013` отсутствует. Primary Operator Kernel route:
`cross_provider_e2e_fallback_closure`. Current development HEAD:
`EFHC_Bot_v172_33.zip`.

---

# Актуальный kernel status — v172.32

```text
CYCLE_1628_EXTENDED_DOMAIN_OWNER_EXACT_HEAD_PASS
CYCLE_1628_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1629_SESSION_FIRST_FULL_SWITCH_PACKAGE_READY
CYCLE_1629_EXACT_HEAD_CI_REQUIRED
CYCLE_1630_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83181651259` на exact v172.31 применил real PostgreSQL `0012`.
Fail-closed `owner conflict` был ожидаемым negative contract, но старый
harness ловил неверный класс исключения. Cleanup двух payment tests
удалял canonical migration control. Эти и остальные локальные findings
исправлены без изменения production semantics. Alembic head остаётся
`0012`; `0013` отсутствует. Cycle `1629` делает server-side Bearer
session primary transport для common/admin API, сохраняет измеряемый
legacy fallback и переводит frontend owner cache на `GlobalId`.
Primary Operator Kernel route: `session_first_full_switch`.
Current canonical development HEAD: `EFHC_Bot_v172_32.zip`.

---

# Актуальный kernel status — v172.31

```text
CYCLE_1627_FINANCIAL_READ_SWITCH_EXACT_HEAD_PASS
CYCLE_1627_SIMPLE_CI_FINDINGS_CORRECTED
CYCLE_1628_PACKAGE_READY
CYCLE_1628_EXACT_HEAD_CI_REQUIRED
CYCLE_1629_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83164293703` на exact v172.30 доказал real PostgreSQL `0011`,
financial global reads, rollback, legacy-authoritative dual-write, zero
telemetry и точное `0.00000000`. Остались только simple test/lint
findings, исправленные в v172.31. Alembic code head теперь `0012`, parent
`0011`; migration ограничена Shop/NFT/cosmetics schema gaps. Primary
Operator Kernel route: `extended_domain_owner_migration`. Current
canonical development HEAD: `EFHC_Bot_v172_31.zip`.

---

# Актуальный kernel status — v172.30

```text
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_EXACT_HEAD_PASS
CYCLE_1627_FINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1627_EXACT_HEAD_CI_REQUIRED
CYCLE_1628_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83151379137` квалифицировал real PostgreSQL financial shadow
validation цикла `1626`; единственный failure был release marker.
Alembic code head теперь `0011`, parent `0010`. `0011` включает только
financial owner read switch после нулевой telemetry и точного денежного
равенства. Legacy writes и dual-write остаются активными. Primary route:
`financial_read_switch`. Current canonical development HEAD:
`EFHC_Bot_v172_30.zip`.

---

# Актуальный kernel status — v172.29

```text
CYCLE_1625_POSTGRESQL_0010_PASS
CYCLE_1626_CI_FINDINGS_CORRECTED_IN_V172_29
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_REQUALIFICATION_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83144620488` подтвердил real PostgreSQL `0010`, но не
квалифицировал financial shadow validation: integration fixture упал до
вызова reconciliation gate из-за отсутствующих обязательных timestamps.
Corrective package не начинает `1627`. Alembic head остаётся `0010`;
`0011` отсутствует. Primary route: `ci_log_exact_failure_repair`.
Current canonical development HEAD: `EFHC_Bot_v172_29.zip`.

---

# Актуальный kernel status — v172.28

```text
CYCLE_1625_POSTGRESQL_0010_PASS_CI_FINDINGS_CORRECTED
CYCLE_1626_FINANCIAL_SHADOW_VALIDATION_PACKAGE_READY
CYCLE_1626_EXACT_HEAD_CI_REQUIRED
CYCLE_1627_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83121417737` доказал real PostgreSQL `0010`.
Alembic code head остаётся `0010`; `0011` отсутствует.
Cycle `1626` — только financial shadow validation: read-only telemetry,
точное денежное сравнение, precision/idempotency proof. Financial read
switch `1627` запрещён до fresh exact-HEAD qualification.

Primary route: `financial_shadow_validation`.
Current canonical development HEAD: `EFHC_Bot_v172_28.zip`.

---

# Актуальный kernel status — v172.27

```text
CYCLE_1624_POSTGRESQL_0009_PASS_SIMPLE_CI_FINDING_CORRECTED
CYCLE_1625_NONFINANCIAL_READ_SWITCH_PACKAGE_READY
CYCLE_1625_EXACT_HEAD_CI_REQUIRED
CYCLE_1626_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Fresh CI `83098311619` доказал real PostgreSQL `0009`.
Alembic code head теперь `0010`, parent `0009`.
`0010` включает только управляемый non-financial read switch.
Legacy writes и dual-write остаются активными. Financial read switch
запрещён до циклов `1626–1627`.

---

# ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER

Current canonical development HEAD: `EFHC_Bot_v172_26.zip`.
Route-backed dispatch использует canonical anchors из Operator Kernel.
Development и release контуры разделены.

# Актуальный kernel status — v172.26

```text
CYCLE_1624_CRITICAL_POSTGRESQL_0009_BLOCKER_CONFIRMED
CYCLE_1624_CORRECTIVE_PACKAGE_READY
CYCLE_1624_EXACT_HEAD_CI_REQUIRED
CYCLE_1625_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Primary route: `ci_log_exact_failure_repair`.
Fresh CI input: run `83093436890` на exact `v172.25`.
Alembic code head: `0009`, parent `0008`.
Legacy ownership authoritative; read switch отсутствует.

---

# Актуальный статус — corrective cycle 1619, v172.19

```text
CYCLE_1619_CRITICAL_CI_BLOCKER_CONFIRMED
CORRECTIVE_PACKAGE_READY
CYCLE_1620_NOT_STARTED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82961004593` выполнен на exact input HEAD
`EFHC_Bot_v172_18.zip` размером `11933560` байт. PostgreSQL profile,
PSQL preflight, Alembic upgrade до `0005`, flake8, Ruff, Bandit,
compileall, `npm ci` и frontend production build прошли. Mypy выявил
одну потерю типа в `TelegramInitDataAdapter.verify_subject`, а pytest —
три локальных нарушения identity/language guards. Поскольку Mypy finding
находится на authentication boundary, переход к циклу `1620` запрещён.

`v172.19` является corrective-only package. Исправлены только exact CI
findings: fail-closed строковое сужение provider subject, error codes с
каноническим `TG_ID`, self-trigger static guard и русское значение в
machine registry. Telegram HMAC, replay/session semantics, PostgreSQL,
Alembic, frontend и финансовая логика не изменялись. Migration `0006`
отсутствует. Цикл `1620` не начат.
---

# Актуальный статус — цикл 1618, v172.17

```text
CYCLE_1617_POSTGRESQL_ALEMBIC_MYPY_BANDIT_FRONTEND_PASS_ON_V172_16
CYCLE_1617_CONFIRMED_CI_ERRORS_FIXED_IN_V172_17
CYCLE_1618_TON_AUTH_SESSION_LOGOUT_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1619_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82943922606` выполнен на exact HEAD
`EFHC_Bot_v172_16.zip`. PostgreSQL preflight, Alembic upgrade до
`0005`, Mypy, Bandit, compileall, flake8 и frontend build прошли.
В `v172.17` исправляются только подтверждённые причины общего red gate:
один Ruff `I001` и одиннадцать устаревших identity/architecture tests.

Цикл `1618` добавляет атомарную выдачу hashed server-side session после
успешного TON Proof, `GET /api/auth/session`, `POST /api/auth/logout` и
изолированный frontend bearer transport через `sessionStorage`. Raw token
возвращается один раз и не хранится в PostgreSQL. `global_id` остаётся
строкой из десяти ASCII-цифр на внешней границе. Migration `0006` не
создаётся; Alembic head остаётся `0005`. Telegram adapter цикла `1619` не
начат.

---

# Актуальный статус — цикл 1617, v172.16

```text
CYCLE_1616_CONFIRMED_CI_ERRORS_FIXED_IN_V172_16
CYCLE_1617_TON_ACCOUNT_REGISTRATION_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1618_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Run `82923200235` выполнен на exact HEAD `EFHC_Bot_v172_15.zip`.
PostgreSQL preflight, Alembic upgrade до `0004`, Bandit, compileall,
flake8 и frontend build прошли. Исправлены только подтверждённые CI
ошибки: три Ruff `I001`, две Mypy boundary errors и десять pytest failures.

Цикл `1617` добавляет ограниченную EXPAND migration `0005`, nullable
`users.tg_id`, `wallet_bindings.global_id` и transactional TON account
registration. Один wallet может принадлежать только одному `global_id`.
Новый TON-only account создаётся без фиктивного `tg_id`; session не
выдаётся. Цикл `1618` не начат.

# Актуальный статус — цикл 1616, v172.15

```text
CYCLE_1615_RUNTIME_STATIC_POSTGRESQL_FRONTEND_PASS_ON_V172_14
CYCLE_1615_EIGHT_CONFIRMED_CI_ERRORS_FIXED_IN_V172_15
CYCLE_1616_TON_PROOF_VERIFICATION_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1617_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82909483300` выполнен на exact HEAD
`EFHC_Bot_v172_14.zip`. PostgreSQL preflight, Alembic upgrade до
`0004`, Bandit, compileall, flake8 и frontend build прошли. CI
подтвердил три Ruff findings, одну Mypy error и четыре architecture
failures. В `v172.15` исправлены только эти восемь причин.

Цикл `1616` добавляет provider-neutral `POST /api/auth/ton/proof` и
fail-closed проверку TON Connect v2 proof: domain, timestamp, network,
state-init, authoritative public key, Ed25519 signature, challenge TTL
и atomic replay protection по exact challenge ID. Proof verification
не создаёт account, identity или session и не зависит от Telegram.
Alembic head остаётся `0004`; migration `0005` отсутствует.

Похожие tests объединены параметризацией и общими cryptographic
fixtures без удаления отдельных failure vectors. Локально проверяется
только изменённый scope с жёстким timeout. Реальный PostgreSQL, полный
pytest, frontend build и итоговый integration run выполняет
существующий канонический GitHub CI. CI workflow не изменяется.

---

# Актуальный статус — цикл 1615, v172.14

```text
CYCLE_1614_POSTGRESQL_STATIC_FRONTEND_PASS_ON_V172_13
CYCLE_1614_FOUR_ARCHITECTURE_CORRECTIONS_INCLUDED
CYCLE_1615_TON_CHALLENGE_AND_ADDRESS_FOUNDATION_PREPARED
EXACT_HEAD_CI_REQUIRED
CYCLE_1616_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82897904509` выполнен на exact HEAD
`EFHC_Bot_v172_13.zip`. PostgreSQL preflight, Alembic upgrade до `0004`,
Ruff, Mypy, Bandit, compileall, flake8 и frontend build прошли. Pytest:
`2974 passed`, `20 skipped`, `4 failed`, `1 warning`. Четыре ошибки относятся
только к retention-version reports, русскоязычным machine keys и устаревшему
roadmap marker; runtime, migration, PostgreSQL и financial defects не выявлены.

`v172.14` исправляет только эти четыре подтверждённые причины и реализует
цикл `1615`: отдельный `POST /api/auth/ton/challenge` без Telegram context,
hashed one-time challenge через `auth_challenges`, строгий canonical TON
address resolver и единый address parser для будущего TON Proof. Endpoint не
создаёт account, identity или session и не проверяет подпись — cryptographic
verification остаётся циклом `1616`. Alembic head остаётся `0004`; migration
`0005` отсутствует. Полный regression, PostgreSQL и frontend build выполняет
канонический GitHub CI.

---

# Актуальный статус — цикл 1614, v172.13

```text
CYCLE_1613_REAL_POSTGRESQL_ALEMBIC_0004_EXECUTED
CYCLE_1614_INTEGRATION_CLOSURE_PACKAGE_READY
EXACT_HEAD_CI_REQUIRED
CYCLE_1615_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

GitHub CI run `82888503300` выполнен на exact HEAD
`EFHC_Bot_v172_12.zip`. PostgreSQL preflight, Alembic upgrade до `0004`,
Mypy, compileall, flake8 и frontend build прошли. Исправлены только
подтверждённые ошибки: три Ruff `I001`, два Bandit `B105`, шесть
architecture/document contracts и два PostgreSQL integration tests.

Текущий source HEAD: `EFHC_Bot_v172_13.zip`. Цикл `1614` закрывает
только auth-core PostgreSQL evidence: migration `0004`, concurrency,
logout и roles. Alembic head остаётся `0004`; migration `0005`, TON Proof,
public auth endpoints, Telegram switch, ownership и financial changes
отсутствуют. Полный regression и реальный PostgreSQL выполняет только
канонический GitHub CI. Цикл `1615` до fresh exact-HEAD PASS не начинается.

---

# Актуальный статус — цикл 1613, v172.12

```text
CYCLE_1612_FUNCTIONAL_POSTGRESQL_STATIC_GATES_PASS
CYCLE_1612_HANDOFF_MARKER_FIX_INCLUDED
CYCLE_1613_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

## Операционный канон реализации циклов

Главная цель — последовательная реализация roadmap, а не повторный аудит неизменённого кода. Обязательная последовательность:

```text
реализация текущего цикла → локальная проверка изменённого scope → архивы → канонический CI GitHub → точечное исправление подтверждённых ошибок → закрытие цикла → следующий цикл
```

Правила исполнения:

1. Перед каждой проверкой фиксируется причинный scope по списку новых и изменённых файлов.
2. Проверяются только новые/изменённые файлы и непосредственно зависящие от них контракты и tests.
3. PASS не повторяется, пока не изменился связанный файл или его зависимость.
4. Повторный запуск разрешён только из-за изменения связанного файла/зависимости, конкретной ошибки CI, доказанного противоречия либо финальной проверки нового архива.
5. Общий аудит, соседние подсистемы и полный импорт приложения без конкретного дефекта запрещены. Enum, модели, константы и отдельные contracts проверяются AST/текстовым анализом или узкими tests.
6. Каждая команда имеет жёсткий timeout. Зависший процесс немедленно останавливается и заменяется статическим анализом или узкой проверкой.
7. PostgreSQL, полный pytest, frontend build, Chromium E2E и итоговая интеграция выполняются существующим каноническим CI GitHub. CI workflow без прямой команды не меняется.
8. Ведётся machine-readable реестр: `CHECK_ID`, exact HEAD, scope, result, связанные файлы, причина запуска и допустимое условие повторения.
9. Формулировки «для уверенности», «ещё раз проверю» и «проверю соседние контракты» не являются основанием для запуска.
10. Следующий цикл не начинается до реализации, упаковки и необходимого CI-подтверждения текущего цикла.

Для цикла `1613` scope ограничен migration `0004`, новыми auth-моделями, services, dependencies и непосредственно связанными tests. `AuthProvider`, migration `0003` и неизменённые identity-контракты после подтверждённого PASS повторно не проверяются без нового факта.


Канонический source HEAD: `EFHC_Bot_v172_12.zip`.

GitHub CI run `82865834601` выполнен на exact HEAD
`EFHC_Bot_v172_11.zip` размером `11 666 314` байт. PostgreSQL preflight,
Alembic `0001 → 0002 → 0003`, Ruff, Mypy, Bandit, compileall, flake8 и
frontend build прошли. Pytest: `2942 passed`, `20 skipped`, `1 failed`,
`1 warning`. Единственная ошибка — в `CONTINUE_IN_NEW_CHAT.md` отсутствовал
обязательный marker `EFHC_Bot_v172_11_RELEASE.zip`; code, migration,
PostgreSQL и financial defects не выявлены. Исправление включено в `v172.12`.

Цикл `1613` добавляет только provider-neutral auth-core foundation:
`auth_challenges`, `auth_sessions`, `user_roles`, migration `0004`,
транзакционные services и FastAPI dependencies. Challenge и session token
хранятся только как namespaced SHA-256 hashes; challenge потребляется
атомарно один раз; роли принадлежат только `global_id`; malformed/inactive
session завершается `401`, отсутствие роли — `403`.

Запрещены и отсутствуют: account/identity creation, public login endpoint,
TON Proof, Telegram login switch, auto-merge, backfill, read switch,
ownership switch и любые financial changes. Alembic code head: `0004`.
Цикл `1614` не начат. Полный regression и реальный PostgreSQL выполняются
пользователем только через существующий GitHub CI.

---

# Цикл 1612 — transactional IdentityResolver, v172.11

```text
CYCLE_1611_EXACT_HEAD_PASS
CYCLE_1612_CODE_AND_POSTGRESQL_TEST_PACKAGE_PREPARED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Канонический GitHub CI run `82850316409` выполнен на exact HEAD
`EFHC_Bot_v172_10.zip`: все gates PASS, pytest — `2918 passed`,
`20 skipped`, `0 failed`, `0 errors`, `1 warning`. Цикл `1611`
закрыт.

В цикле `1612` реализован `PostgreSQLIdentityResolver`: вход только
`VerifiedIdentity`, transaction-scoped `pg_advisory_xact_lock` для
lookup-key, `SELECT FOR UPDATE` для существующей строки и fail-closed
outcomes `resolved/not_found/conflict`. Resolver не создаёт account,
identity, session или role, не выполняет auto-merge и не меняет
финансовые данные. Alembic head остаётся `0003`; migration `0004`
отсутствует.

Локально выполняются только короткие причинные проверки. Реальный
PostgreSQL, полный regression, Docker и Chromium выполняет пользователь
через существующий канонический GitHub CI. До fresh exact-HEAD PASS на
`v172.11` цикл `1613` не начинается.

Следующий цикл: `1613`, только после закрытия `1612`.

---

# Актуализация цикла 1611 после CI run 82837535263 — v172.10

```text
V172_10_CI_CORRECTION_PACKAGE_READY
V172_09_REAL_POSTGRESQL_AND_STATIC_EVIDENCE_RECORDED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Run `82837535263` выполнен на development archive `v172.09` размером
`11 566 965` байт. PostgreSQL preflight, Alembic `0001 → 0002 → 0003`,
Mypy, Bandit, compileall, flake8, frontend `npm ci` и production build
прошли. Gate остановили один Ruff `I001` и двенадцать архитектурных tests,
связанных только с active documentation, version-budget contracts и
русскоязычными machine reports.

`v172.10` исправляет эти причины поверх чистого `v172.09`. Migration `0003`,
`user_identities` constraints, CI workflow и financial/domain owner files не
изменяются. Полный regression локально не выполняется; требуется fresh
exact-HEAD CI GitHub на `EFHC_Bot_v172_10.zip`.

Цикл `1612` не начинается до полного PASS. Активный roadmap заканчивается
циклом `1633`; migration squash выполняется только в цикле `1632` с gate
`PRE_RELEASE_MIGRATION_SQUASH_PASS`.

---

# Цикл 1611 — корректирующий exact-HEAD пакет v172.09

Статус:

```text
V172_09_STATIC_CI_FIX_PACKAGE_READY
V172_08_REAL_POSTGRESQL_EVIDENCE_RECORDED
EXACT_HEAD_CI_REQUIRED
NOT_PRODUCTION_RELEASE_READY
```

Исходный development HEAD: `EFHC_Bot_v172_08.zip`.
Исправленный development HEAD: `EFHC_Bot_v172_09.zip`.
Релизный кандидат: `EFHC_Bot_v172_09_RELEASE.zip`.
Технический архив: `EFHC_Bot_v172_09_MATRIX_TECHNICAL.zip`.

Канонический GitHub CI run `82789912844` доказал на точном `v172.08`:
реальный PostgreSQL, `PG-0` preflight, Alembic upgrade `0001 → 0002 → 0003`,
`compileall`, flake8, полный pytest (`2918 passed`, `20 skipped`, `0 failed`,
`0 errors`), `npm ci` и frontend build. Expected PostgreSQL errors из negative
constraint tests являются доказательством fail-closed constraints, а не падением.
Общий gate остановили только Ruff, Mypy и Bandit.

В `v172.09` причинно исправлены все `50` findings Ruff, две ошибки Mypy и два
ложных `B105` Bandit. Migration `0003`, ORM/storage semantics
`user_identities`, финансовые и доменные owner-файлы не изменены. Пять
небезопасных Ruff `UP042` не применялись: историческая `str, Enum` семантика
сохранена и подавлена только точечными `# noqa: UP042`.

Run `82791721379` классифицирован как `WRONG_INPUT_ARCHIVE_PROFILE`: в
канонический development CI ошибочно передан `_RELEASE.zip`. Отсутствие
`requirements-test.txt` в release archive является нормой. Release purity не
ослабляется; tests, test dependencies и CI evidence в release не добавляются.

Exact-HEAD CI на `v172.09` ещё не выполнялся. До fresh PASS цикл `1611` не
закрыт, а цикл `1612` запрещено начинать. Канонические CI workflow не
изменялись.

Локально разрешены только короткие причинные проверки изменённой области.
Полный regression, PostgreSQL, Docker и Chromium в среде чата не запускаются;
зависшая или неподдерживаемая проверка прекращается со статусом `NOT RUN` либо
`BLOCKED_BY_ENVIRONMENT`. Полные tests выполняет пользователь через
существующий GitHub CI.

Активный roadmap заканчивается циклом `1633`. Цикл `1632` зарезервирован только
для schema freeze и pre-release migration squash в единый
`0001_initial_release_schema.py`; exit gate —
`PRE_RELEASE_MIGRATION_SQUASH_PASS`. Финальная exact-HEAD release qualification
перенесена в цикл `1633`.

Следующее действие: запустить существующий канонический GitHub CI только на
`EFHC_Bot_v172_09.zip`. `_RELEASE.zip` в development CI не передавать.

---

# Цикл 1611 — user_identities schema и PostgreSQL test package

Статус: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_08.zip`.
Релизный кандидат: `EFHC_Bot_v172_08_RELEASE.zip`.
Технический архив: `EFHC_Bot_v172_08_MATRIX_TECHNICAL.zip`.

Подготовлен provider-neutral storage foundation для внешних identities:
ORM-модель `UserIdentity`, канонический storage-contract, Alembic
revision `0003`, read-only `PG-0` preflight и PostgreSQL integration
package. Таблица `efhc_core.user_identities` связывает проверенный
`(provider, provider_tenant, provider_subject)` ровно с одним
логическим `global_id`; физический FK переходного этапа направлен на
`efhc_core.users.user_id`.

Migration `0003` является только `EXPAND`: она не выполняет backfill,
не изменяет `users` и финансовые таблицы, не создаёт аккаунты или
sessions, не включает runtime resolver и не переключает ownership.
Duplicate provider subject, недопустимый provider, `mock` в production,
несогласованные verification timestamps и более одной primary identity
на один account блокируются constraints.

По прямому указанию пользователя PostgreSQL в среде чата не
устанавливался и не запускался. Канонические GitHub CI workflows не
создавались и не изменялись. Поэтому реальный `PG-0 PASS`, применение
migration на PostgreSQL и PostgreSQL constraint/concurrency proof не
заявляются. Цикл 1612 остаётся заблокированным до контролируемого запуска
существующего CI GitHub и получения `PG-0 PASS`.

# Цикл 1611 — migration user_identities и PostgreSQL test package

Статус: `PG-0 TEST_PACKAGE_PREPARED_NOT_EXECUTED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_08.zip`.
Релизный кандидат: `EFHC_Bot_v172_08_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_08_MATRIX_TECHNICAL.zip`.

Подготовлена линейная Alembic revision `0003`, ORM-модель
`UserIdentity`, точный storage contract, fail-closed constraints,
read-only PG-0 preflight и PostgreSQL integration tests. Таблица
`efhc_core.user_identities` связывает проверенный provider subject с
исторической удалённой колонкой `users.user_id`; текущий owner — `users.global_id`, которая представляет
канонический `global_id` до physical rename цикла 1631.

Миграция является только `EXPAND`: не выполняет backfill, не изменяет
`users`, финансовые таблицы, balances, kWh или ownership, не создаёт
account/session и не подключает runtime `IdentityResolver`. Duplicate
provider/tenant/subject, неизвестный `global_id`, production `mock`,
некорректный verification state и более одной primary identity на
account закрываются PostgreSQL constraints.

PostgreSQL в среде чата не устанавливался и не запускался. Канонические
CI workflow не создавались и не изменялись; их исходные SHA-256
зафиксированы contract guard. Реальный PG-0, upgrade/downgrade и
constraint tests подготовлены, но не исполнены. До их контролируемого
запуска нельзя заявлять `PG-0 PASS` или начинать runtime resolver цикла
1612.

Следующее действие: `Необходимо запустить канонический CI GitHub`.
До подтверждённого PostgreSQL PASS цикл 1612 заблокирован.

# Цикл 1610 — AuthContext contracts и resolver interfaces

Статус: `LOCAL_AUTH_CONTEXT_CONTRACTS_READY / PG-0_REQUIRED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_07.zip`.
Релизный кандидат: `EFHC_Bot_v172_07_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_07_MATRIX_TECHNICAL.zip`.

Создан provider-neutral контракт `AuthContext`, который формируется
только из nominal `GlobalId` и `VerifiedIdentity`. Внутренний контекст
не содержит `tg_id`, wallet address, raw proof, token или initData.
Безопасный endpoint response содержит только `global_id`, `provider` и
детерминированный набор `roles`; provider subject и session reference
во внешний контракт не попадают.

Добавлены fail-closed interfaces будущего `IdentityResolver` со
статусами `resolved`, `not_found` и `conflict`. Они не выполняют lookup
в БД, не создают account/session, не присваивают `global_id` и не
поддерживают auto-merge. Security/redaction skeleton рекурсивно скрывает
provider subject, session reference, proof, tokens, initData, nonce и
другие credentials в diagnostics и общем logging filter.

Operator Kernel получил exact primary route цикла 1610. Legacy
`backend/app/deps.py::AuthContext(tg_id, is_admin)` и действующие routes
намеренно не переключались. Alembic head остаётся `0002`; PostgreSQL
DDL/data, backfill, ownership и экономика не изменялись. Следующий цикл:
`1611 — реальный PG-0 и migration user_identities`. После цикла 1610
остаётся `22` обязательных цикла `1611–1632`. GitHub CI пока не запускать.

# Цикл 1609 — AuthProvider и provider registry foundation

Статус: `LOCAL_PROVIDER_REGISTRY_READY / PG-0_REQUIRED / NOT_PRODUCTION_RELEASE_READY`.
Архив разработки: `EFHC_Bot_v172_06.zip`.
Релизный кандидат: `EFHC_Bot_v172_06_RELEASE.zip`.
Технический архив матриц: `EFHC_Bot_v172_06_MATRIX_TECHNICAL.zip`.

Создан provider-neutral фундамент авторизации: строгий `AuthProvider`,
закрытый результат `VerifiedIdentity`, fail-closed provider registry,
раздельные runtime/test feature flags, стабильные machine error codes и
test-only mock adapter. Неподдержанный, незарегистрированный либо
выключенный provider не активируется. `VerifiedIdentity` не содержит
`global_id`, не создаёт пользователя или session и не меняет domain.

Все production providers зарегистрированы как reserved/disabled до
появления проверенных adapters в последующих циклах. Mock provider
разрешён только в `ENV=ci`. Добавлен exact Operator Kernel route цикла
1609; устаревший заголовок accelerated roadmap исправлен без изменения
исторических документов.

Alembic head остаётся `0002`; migration, PostgreSQL DDL/data, backfill,
read switch, ownership и экономика не изменялись. Реальный `PG-0` не
выполнен. Следующий цикл: `1610 — AuthContext contracts, resolver
interfaces и security/redaction skeleton без DDL`. После цикла 1609
остаётся `23` обязательных цикла `1610–1632`. GitHub CI пока не запускать.

# Цикл 1608 — semantic allowlist и compatibility registry

Статус: `LOCAL_IDENTITY_REGISTRY_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_05.zip`.
Release candidate: `EFHC_Bot_v172_05_RELEASE.zip`.
Matrix/technical archive: `EFHC_Bot_v172_05_MATRIX_TECHNICAL.zip`.

Создан единый semantic registry для `global_id`, физического
LEGACY-имени `user_id`, локального `id`, Telegram provider `tg_id`,
разрешённых compatibility aliases и исторических областей. Registry
является единственным active allowlist для новых identity guards;
временные aliases имеют sunset budget до цикла `1631`.

Причина двукратного роста development-архива доказана: накопление
исторических XLSX, raw identity JSON/CSV, JUnit/XML, collection-списков
и runtime logs. Код и production assets не являлись причиной роста.
Поставка разделена на три архива: компактный development HEAD, чистый
release и отдельный matrix/technical archive со всеми подробными XLSX,
текущим raw-аудитом, JUnit и индексом перемещений.

Alembic, PostgreSQL data, ownership и экономика не переключались.
Следующий цикл: `1609 — AuthProvider и provider registry foundation`.
После цикла 1608 остаётся `24` обязательных цикла `1609–1632`.
GitHub CI пока не запускать.

# Цикл 1607 — Cross-language разделение GlobalId и TelegramId

Статус: `LOCAL_CROSS_LANGUAGE_IDENTITY_SEPARATION_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_04.zip`.
Release candidate: `EFHC_Bot_v172_04_RELEASE.zip`.

Backend `GlobalId` и `TelegramId` остаются отдельными nominal value
objects. Frontend получил несовместимые branded-типы: строковый
`GlobalId` и числовой provider-only `TelegramId`. Telegram WebApp
boundary проверяет `user.id` до передачи в приложение. Прямое и
косвенное смешение, а также передача `global_id` в Telegram API
блокируются compile/runtime/AST guards.

Активные routes, Alembic, backfill, ownership и экономика не
переключались. Реальный PostgreSQL `PG-0` остаётся обязательным.

Roadmap ускорен: прежние 94 плановых слота были избыточной
safety-maximal декомпозицией. После цикла 1607 остаётся 25 обязательных
циклов `1608–1632`; `1633–1700` являются только условным резервом.

Следующий цикл: `1608 — semantic allowlist и compatibility registry`.
GitHub CI пока не запускать.

# Цикл 1606 — API-контракт global_id

Статус: `LOCAL_GLOBAL_ID_API_CONTRACT_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_03.zip`.
Release candidate: `EFHC_Bot_v172_03_RELEASE.zip`.

Создан единый изолированный контракт
`backend DTO ↔ OpenAPI fixture ↔ frontend DTO`. Поле `global_id`
передаётся только строкой из десяти ASCII-цифр с format
`efhc-global-id`; ведущие нули сохраняются, `0000000000` отклоняется.
Действующие LEGACY routes и DTO не переключались.

Alembic head остаётся `0002`; historical backfill, runtime read switch
и financial ownership switch не выполнялись. Реальный PostgreSQL
`PG-0` по-прежнему обязателен до цикла 1613.

Следующий цикл: `1607 — Cross-language разделение GlobalId и TelegramId`.
После завершения 1606 до цикла 1700 остаётся `94` цикла.
GitHub CI пока не запускать.

# Цикл 1605 — Frontend GlobalId string system

Статус: `LOCAL_FRONTEND_GLOBAL_ID_STRING_READY / PG-0_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_02.zip`.
Release candidate: `EFHC_Bot_v172_02_RELEASE.zip`.

Frontend `GlobalId` закреплён как branded string из десяти ASCII-цифр.
`0000000000`, JavaScript number/BigInt, numeric conversion, arithmetic и
unsafe casts запрещены fail-closed guard. Текущий Telegram-specific
`tg_id: number` не заменялся механически. Alembic, данные, экономика,
backfill, dual-write и read switch не изменены.

Roadmap оптимизирован по code/data линиям и gates `PG-0…PG-4`.
Следующий цикл: `1606 — API-контракт global_id`.
Следующая изменённая версия: `v172.03`.

# Цикл 1604 — Backend GlobalId type finalization

Статус: `LOCAL_BACKEND_TYPES_FINALIZED / POSTGRESQL_PROOF_REQUIRED`.
Development HEAD: `EFHC_Bot_v172_01.zip`.
Release candidate: `EFHC_Bot_v172_01_RELEASE.zip`.

Канонический пакет `app.identity` экспортирует только `GlobalId`,
`TelegramId` и связанные канонические контракты. Историческое семейство `UserId` и модуль
`app.identity.legacy_user_id` удалены из active HEAD; historical bytes хранятся только во внешнем `EFHC_Bot_v173_18_ARTIFACTS_HISTORY.zip`; active
backend пакет экспортирует только канонические `GlobalId` и provider
identity types. Возврат legacy type names запрещён.

Закреплены явные границы `GlobalId ↔ database` и
`TelegramId ↔ provider`, стабильные машинные коды ошибок и русские
сообщения. Alembic остаётся `0002`; historical backfill, dual-write,
runtime read switch и financial ownership switch не выполнялись.

Реальный PostgreSQL proof всё ещё отсутствует. Следующий цикл:
`1605 — Frontend GlobalId string system`. GitHub CI пока не запускать.

# Цикл 1603 — Global ID PostgreSQL reconciliation baseline

Статус: `GATE_PREPARED / REAL_POSTGRESQL_BLOCKED_BY_ENVIRONMENT`.
Development HEAD: `EFHC_Bot_v172_00.zip`.
Release candidate: `EFHC_Bot_v172_00_RELEASE.zip`.

Подготовлен воспроизводимый read-only PostgreSQL gate для канонического
`global_id` над физической EXPAND-колонкой `users.user_id`. Gate требует
реальное синхронное PostgreSQL-соединение, снимает один согласованный
снимок в транзакции `REPEATABLE READ READ ONLY DEFERRABLE` и всегда
выполняет `ROLLBACK`.

В текущей среде реальный PostgreSQL запуск заблокирован: отсутствуют
PostgreSQL Server, клиентские binaries, Docker/Podman, синхронный driver
и PostgreSQL URL; установка через APT не состоялась из-за недоступного
DNS/mirror. Статус не повышается до PASSED. Historical backfill,
dual-write, read switch и financial ownership switch не выполнялись.

Следующий цикл: `1604 — Backend GlobalId type finalization`.
Следующая изменённая версия: `v172.01`.

# Цикл 1602 — канонизация Global ID

Статус: `GLOBAL_ID_CANON_ACTIVE / POSTGRESQL_PROOF_REQUIRED`.
Current HEAD на входе: `EFHC_Bot_v171_98.zip`.
Целевой changed HEAD: `EFHC_Bot_v171_99.zip`.

`global_id` является главным неизменяемым идентификатором единого
аккаунта EFHC. Физическая EXPAND-колонка временно называется
`users.user_id`; новый код использует `GlobalId` и `User.global_id`.
Отдельная колонка `global_id` не создаётся. `id` остаётся локальным PK,
а `tg_id` — Telegram provider ID. Historical backfill, runtime read
switch, financial ownership switch и GitHub CI в цикле 1602 запрещены.

Активные источники:

- `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`;
- `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md`;
- `docs/cycles/WORK_CYCLES_1601-1700.md`.

# Цикл 1601 — открытие диапазона и приёмка фундамента

Статус: `LOCAL_FOUNDATION_ACCEPTED / POSTGRESQL_PROOF_REQUIRED`.
Development HEAD: `EFHC_Bot_v171_98.zip`.
Release candidate: `EFHC_Bot_v171_98_RELEASE.zip`.

Независимо подтверждены SHA-256, ZIP entries, CRC и безопасная
распаковка `v171.89` и `v171.97`. Diff `v171.89 → v171.97` не выявил
скрытого runtime read switch, historical backfill либо изменения
финансового ownership. Alembic остаётся на линейной цепочке
`0001 → 0002`, `users.id` остаётся primary key, а `users.user_id` —
nullable EXPAND-полем.

Исправлен дефект provenance: генераторы identity-аудита и PostgreSQL
preflight теперь обязаны получать точные `source_head`, `baseline_head`
и номер цикла, поэтому новый evidence не может молча наследовать
метаданные циклов 1598–1599.

Реальная PostgreSQL reconciliation по-прежнему не выполнена: в среде
нет PostgreSQL URL, синхронного драйвера, `psql`, PostgreSQL Server,
Docker или Podman. Historical backfill, runtime read switch и
финансовый switch запрещены. GitHub CI не запускается: основной
интегрированный auth-пакет ещё не готов.

Следующий цикл: `1602 — независимый reconciliation baseline`.
Следующая изменённая версия: `v171.99`.

# Цикл 1600 — закрытие фундаментального диапазона 1593–1600

Статус: LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL_PROOF_REQUIRED.
Archive: `v171.97`.

Диапазон `1593–1600` локально закрыт: зафиксированы аудит
идентификаторов, строгий `UserId`, внешний строковый API-контракт,
nullable EXPAND `users.user_id`, LEGACY alias, backfill harness и
read-only PostgreSQL reconciliation gate.

Реальная PostgreSQL-сверка недоступна в текущей среде. Historical
backfill, runtime read switch и изменение финансового ownership
остаются запрещёнными. Финансовый допуск — `0.00000000`.

GitHub CI не запускается по указанию пользователя. Основной пакет
изменений ещё не готов. Команда `запусти тесты CI GitHub` будет выдана
только после интеграции auth core, TON Proof login, Telegram adapter и
необходимых PostgreSQL-контуров.

Все новые и изменяемые тесты, отчёты, документы, docstring и авторские
комментарии оформляются на русском языке. Технические идентификаторы и
внешние протоколы не переводятся.

Следующий цикл: `1601`.
Следующая изменённая версия: `v171.98`.

# EFHC Bot Operator Kernel

# Operator Kernel

Status: ACTIVE OPERATOR KERNEL / FULL DETAILED DISPATCH LAYER.
Archive: `v171.97`.
Cycle: `1600 — FOUNDATION RANGE CLOSURE / NO READ SWITCH`.

## 1. Current HEAD

- Current canonical development HEAD: `EFHC_Bot_v171_97.zip`.
- Input development HEAD: `EFHC_Bot_v171_96.zip`.
- Current production release candidate: `EFHC_Bot_v171_97_RELEASE.zip`.
- Preserved forensic baseline: `EFHC_Bot_v171_47.zip`.
- Preserved baseline Kernel:
  `docs/AI/PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md`.
- Exact route: `user_id_foundation_range_closure`; fallback is not used.
- Current cycle: `1600 — FOUNDATION RANGE CLOSURE — LOCAL_FOUNDATION_RANGE_CLOSED / POSTGRESQL PROOF REQUIRED`.
- Status: `LOCAL_RELEASE_CANDIDATE /
  FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED /
  NOT LIVE PRODUCTION READY`.
- Exact v171.89 development and release GitHub CI are green and remain
  the inherited input proof. Они не доказывают изменённые архивы v171.97.
- Target system/domain owner is `UserId` / `user_id`; Telegram
  provider identity is `TelegramId` / `tg_id`. Cycle 1597 adds only nullable `users.user_id`, sequence and Alembic `0002`. Existing rows stay NULL; routes, DTOs, AuthContext and ownership reads remain legacy.
- Cycle 1598 adds only the explicit bounded alias
  `User.legacy_runtime_id -> User.id` and a pure render-only backfill
  harness. The future `User.id -> User.user_id` compatibility alias is
  inactive. No database backfill, AuthContext switch, route switch or
  financial/domain read switch occurs.
- Future historical-row mapping is deterministic:
  `NULL users.user_id -> users.id`. Existing non-null `user_id` values
  are preserved. `tg_id`, wallet address and provider subject never
  derive `user_id`.
- Active direct referral means the permanent `Activ` activation flag:
  `referral_links.activated_at IS NOT NULL`. The flag is set exactly
  once by `activate_referral()` at the first panel activation and is
  never re-evaluated from current panel count or panel existence.
  Archive, expiry or future physical panel deletion cannot clear it;
  `panels_count` is display-only.
- Cycle 1592 correction: the former wording "has ever created a panel"
  was ambiguous and previously allowed runtime consumers to derive
  Activ from current `panels` rows instead of the activation flag.
- Active/Inactive filtering and `(invited_at, invitee_tg_id)` cursor pagination execute in PostgreSQL before ordering.
- `/me` referral routes use authenticated TG ID only. Deprecated routes are self-only, reject foreign TG IDs with `403` and expose the deprecation header.
- Admin referral totals include both `referral_active_unit` and `referral_level_bonus`.
- ETag depends on owner, filter, cursor, limit and dataset mutation state.
- Direct and Lvl reward idempotency is re-read after row locks to avoid concurrent late unique-key conflicts.
- Real PostgreSQL runtime and API integration tests are a distinct mandatory CI stage.
- Invalid supplied referral code fails before user creation; no-invite creates a permanent 0 user.
- Referral economics remain `1 000 + 1 411 = 2 411 EFHCb`.
- Alembic is now a linear `0001 -> 0002` chain; head is `0002`. The ORM table count remains 44.
- The local pre-release gate now rejects stale CI evidence fail-closed. Fresh exact-HEAD GitHub CI, PostgreSQL integration, frontend build, Docker clean deploy/update/rollback and VPS/live proof remain open.
- Next changed archive after delivery of v171.97: `EFHC_Bot_v171_98.zip`.
- PostgreSQL performance proof parses `EXPLAIN (FORMAT JSON)` nodes and accepts only the canonical referral and panel index sets.
- Complete frontend inventory is 15 public, 17 Admin and two safe system routes, protected by a machine visual manifest.
- Visual readiness requires real `page.goto()` proof at 360, 390 and 430 px; synthetic HTML is forbidden.

## 2. Kernel role

Operator Kernel is the active operational dispatch layer of EFHC Bot.

It is not only navigation.

It must:

1. identify the user task by EFHC-specific keywords;
2. map keywords to canonical task types;
3. route the task to exact files and documents;
4. show where each rule is fixed in CANON / SSOT / NORM / AI / HEALER;
5. prevent full archive reading when a precise route exists;
6. prevent canonical drift in UI, economy, navigation, i18n, Telegram, TonConnect, TonProof, transactions and release evidence;
7. define the patch boundary before edits;
8. require targeted validation;
9. require route-backed screenshots for frontend work;
10. require green local logs or an exact failure boundary before development archive delivery;
11. distinguish local checks from fresh exact-HEAD GitHub CI;
12. create the next sequential archive.

Kernel may be detailed operationally, but it must not duplicate the full text of CANON, SSOT, NORM, Healer history, cycle history or reports. It stores keywords, route summaries, boundaries, proof gates and exact anchors.

## 3. Working tree / archive source rule

Every new chat or execution session begins from the latest canonical ZIP supplied by the user:

```text
latest canonical ZIP
→ verify exact name and ZIP integrity
→ unpack once into the current-session working tree
→ read START_HERE and this Kernel
→ resolve the exact route
→ edit only the current working tree
→ validate the bounded change
→ build the next sequential ZIP
→ deliver it to the user
```

The ChatGPT sandbox is temporary. A previous `/mnt/data` workspace is not persistent HEAD. Historical archives are forensic references only and never replace the latest canonical HEAD.

## 4. Mandatory startup route

The only startup order is defined by `START_HERE.md`:

1. `START_HERE.md`;
2. `KERNEL.md`;
3. `docs/AI/AI_ARCHIVE_LAWS.md`;
4. `docs/AI/AI_ARCHIVE_LAWS_LOCK.json`;
5. `docs/SSOT/AI_ARCHIVE_LAWS_CANON.md`;
6. `docs/NORM/AI_ARCHIVE_LAWS_ENFORCEMENT_NORM.md`;
7. `docs/AI/AI_OPERATOR_RULES_EFHC.md`;
8. `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`;
9. `docs/SSOT/SSOT_INDEX.md`;
10. `docs/NORM/ARCHITECTURAL_LOCKS.md`;
11. `docs/AI/EFHC_OPERATOR_KERNEL_PROTOCOL.md`;
12. `docs/NORM/EFHC_OPERATOR_KERNEL_STANDARD.md`;
13. `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`;
14. `ops/operator_kernel/config/routes.yaml` through the runtime resolver;
15. `ops/operator_kernel/cache/file_map.summary.json`;
16. exact route files returned by Kernel;
17. exact source files before edit;
18. exact tests and validation route;
19. no more than the latest two task-relevant entries from `reports/numbered`, `docs/cycles`, `docs/chats` and supplied logs unless the user or a forensic route requires older history.

Do not full-read `file_map.json`, `HEALER_ATLAS.md`, `HEALER_CASEBOOK.md`, `atlas.json` or `casebook.json` during ordinary startup. Use `file_map.summary.json`, `docs/healer/HEALER_CAPSULE.md` and exact routed cases. Full Healer/history reading is reserved for an explicit regression or forensic route.

## 5. Kernel-first rule

Before opening broad project areas, run the task through:

```text
user request
→ task_classifier.py
→ task type
→ routes.yaml
→ route_resolver.py
→ canonical anchors
→ required_read
→ allowed_write
→ validation
→ context capsule
```

If a precise route exists, full archive reading is forbidden. If classification is ambiguous, preserve the current task as primary, expose secondary signals and choose the smallest safe route. A fallback must include Kernel and route hints; it must not silently become `full_audit`.

## 6. Key project keywords and triggers

Compact trigger groups:

| Keyword group | Canonical task type | Runtime route |
|---|---|---|
| `cycle 1594`, `UserId contract`, `negative identity guards`, `type foundation` | `user_id_contract_foundation` | `user_id_contract_foundation` |
| `user_id`, `tg_id`, `identity resolver`, `AuthContext`, `TON Proof login` | `user_id_identity_migration` | `user_id_identity_migration` |
| `frontend`, `visual`, `UI`, `UX`, `screenshots`, `скриншоты`, `route-backed`, `page.goto`, `overflow` | `frontend_visual_route_backed_work` | `frontend_visual_route_backed_recovery` |
| `bottom nav`, `нижняя навигация`, `нижние кнопки`, `6 buttons`, `Energy`, `Panels`, `Exchange`, `Tasks`, `Referrals`, `Ranks` | `canonical_bottom_navigation_guard` | `frontend_canonical_navigation_guard` |
| `Native-wallet adapter`, `WalletProvider`, `Wallet in Telegram`, `Native Gram Wallet`, `не привязывать только к TonConnect` | `wallet_provider_adapter_work` | `wallet_provider_adapter_layer` |
| `clean first-boot`, `чистый первый запуск`, `пустой VPS`, `44 tables`, `Alembic head`, `one-command deploy`, `v171.71 RELEASE` | `clean_first_boot_release` | `clean_first_boot_release_candidate` |
| `provider-independent release`, `OVHcloud`, `Docker Compose`, `new VPS`, `backup restore`, `pg_dump pg_restore`, `cycles 1574-1578` | `provider_independent_release_portability` | `provider_independent_release_portability` |
| `Telegram`, `Telegram Mini App`, `live Telegram`, `TonConnect`, `TonProof`, `wallet`, `transaction contour`, `real TON`, `Jetton` | `live_telegram_tonconnect_tonproof_transaction_gate` | `cycle_1573_live_telegram_transaction_contours` |
| `cycle 1574`, `local RC audit`, `release candidate audit`, `идём дальше`, `deferred post-release` | `cycle_1574_local_release_candidate_audit` | `cycle_1574_local_release_candidate_audit` |
| `i18n`, `13 languages`, `локализация`, `Activ`, `VIP`, `hardcoded text`, `translation` | `frontend_i18n_guarded_work` | `i18n_public_surface_guard` |
| `logs`, `green logs`, `GitHub CI`, `pytest`, `ruff`, `mypy`, `bandit`, `compileall`, `typecheck`, `npm build` | `ci_logs_repair_or_verification` | `ci_log_exact_failure_repair` |
| `archive`, `архив`, `new zip`, `development archive`, `release archive`, `screenshots archive`, `sequential number` | `archive_build_and_release_boundary` | `archive_numbering_and_release_gate` |
| `kernel`, `Operator Kernel`, `routes.yaml`, `route_resolver`, `task_classifier`, `file_map`, `context capsule`, `anchors`, `v171.47` | `operator_kernel_full_restore` | `operator_kernel_full_restore_from_v171_47` |

The authoritative full table is `docs/AI/EFHC_OPERATOR_KERNEL_KEYWORDS_AND_ANCHORS.md`.

## 7. Keyword → task type → route → canonical anchors map

The operational sequence is:

```text
keyword group
→ task type
→ configured route name
→ exact canonical anchors
→ exact runtime files
→ allowed patch surface
→ targeted validation
→ evidence and archive boundary
```

The authoritative domain map is `docs/AI/EFHC_OPERATOR_KERNEL_ROUTE_MAP.md`. `routes.yaml` is the primary runtime route source. Hardcoded Python routes are bootstrap/fallback compatibility only.

## 8. Current active cycle boundary

- Cycles 1574-1595: `COMPLETE locally`.
- Current stage: `USERS.USER_ID NULLABLE EXPAND / ALEMBIC 0002`.
- Current status: `LOCAL_RELEASE_CANDIDATE /
  FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED`.
- Exact route: `user_id_api_contract`.
- Fallback: `false`.
- Source HEAD: `EFHC_Bot_v171_91.zip`.
- Value contract: immutable `UserId`, `TelegramId`, validated
  `UserIdDisplay`, strict external parser and explicit DB boundaries.
- Identity boundary: `21` Telegram-specific files, `179` legacy runtime
  files and zero provider/system semantic mix offenders.
- Patch boundary: `481` runtime/schema/frontend files protected by
  Python semantic hashes or exact bytes.
- Production code outside `backend/app/identity` has zero imports of the
  new value types.
- ORM, Alembic, AuthContext, routes, services, schemas, frontend
  ownership and financial data remain unchanged.
- PostgreSQL reconciliation is not claimed by this no-data cycle.
- Next cycle: `1597 — users.user_id expand migration design`.

## 9. Canonical UI boundary

The public UI may not be redesigned, simplified, reordered or renamed without direct user instruction and a matching CANON/SSOT/NORM route.

Canonical bottom navigation is exactly six bottom buttons in fixed order:

1. `Energy`;
2. `Panels`;
3. `Exchange`;
4. `Tasks`;
5. `Referrals`;
6. `Ranks`.

Do not rename, remove, reorder, replace or change the routes/icons of these six buttons without direct user instruction and synchronized CANON/SSOT/NORM updates.

Global Header, balance panel, status indicators, avatar/profile entry, layout proportions and responsive behavior are protected by frontend visual anchors and screenshot proof. Product labels, routes and economic values are never changed by visual preference alone.

## 10. Frontend visual proof boundary

Any frontend visual change requires:

1. exact changed route/component identification;
2. applicable frontend CANON/NORM/SSOT anchors;
3. targeted typecheck/build when dependencies are available;
4. a real running frontend;
5. browser navigation with `page.goto()`;
6. HTTP, route and app-root checks;
7. page-error and critical console-error checks;
8. horizontal-overflow check;
9. fresh PNG for affected routes/viewports;
10. screenshots shown to the user and delivered in a separate companion archive when requested.

Manual HTML, `page.set_content`, synthetic/mock imitation, inherited PNG and component-only demos are not application proof.

## 11. Telegram / TonConnect / TonProof / transaction boundary

Telegram, TonConnect, TonProof and transaction work uses the wallet/withdraw SSOT anchors. The route `cycle_1573_live_telegram_transaction_contours` remains the external release/post-release evidence intake route and no longer blocks unrelated development cycles after explicit user-authorized deferral.

Local code and tests may prove implementation boundaries. They cannot prove:

- a live Telegram client interaction;
- a real wallet signature;
- a real TonProof signature;
- a real TON/Jetton transfer;
- a real transaction hash;
- production HTTPS behavior.

Those remain `UNVERIFIED_LIVE_BOUNDARY` until real external evidence exists.

## 12. Money-flow / wallet / withdraw boundary

Money-flow, wallet ownership, exchange, deposit, direct deposit, shop checkout and withdraw changes are high-risk. They require:

- an explicit route and patch scope;
- exact SSOT/NORM anchors;
- idempotency and atomicity review;
- anti-double-spend and ownership checks;
- targeted backend tests;
- frontend confirmation/error-state checks where affected;
- no invented live proof.

The invariant `1 EFHC = 1 kWh` cannot be changed without direct user instruction and synchronized canonical updates.

## 13. I18N boundary

The project has 13 supported languages. I18N work must:

- route through `i18n_public_surface_guard`;
- read the language/localization anchors;
- scan changed surfaces for hardcoded strings;
- preserve permanent English account-status labels `Activ` and `VIP` in all 13 locales; generic/tab term `Active` remains distinct;
- validate locale differences and fallback behavior;
- create visual proof for affected routes when UI output changes.

A translation repair may not change product meaning, economic values, routes or UI structure.

## 14. Admin boundary

Admin work must remain separated from player-facing UI and APIs. Admin permissions, confirmations and audit trails are protected. Admin routes/components cannot be exposed to public navigation. User-facing changes must not be introduced as a side effect of admin work.

## 14A. AI operational memory boundary

- `docs/AI/` is the active operational brain of the AI, not cycle history.
- `AI_TEMPORARY_MEMORY_PENDING.md` contains only unresolved or immediately actionable items.
- Approved decisions are transferred to CANON / SSOT / NORM and then removed from temporary memory.
- Obsolete historical snapshots are externalized in the separate artifacts history ZIP and are not default-read.
- Reports, audits and cycles stay in the archive, but ordinary familiarization is limited to the latest two relevant entries per layer.

## 15. Healer / regression boundary

Use `docs/healer/HEALER_CAPSULE.md` as the short startup entry. Read full Atlas/Casebook only through an explicit Healer/regression route.

A Healer update requires:

- established incident;
- root cause;
- violated rule;
- affected versions/files;
- corrective action;
- preventive guard;
- independent test/evidence;
- residual risk.

Healer cannot prove its own cure. Kernel demotion, route drift and keyword loss are protected by the three v171.62 Healer guards.

## 16. CI / logs / validation boundary

- Read the exact supplied error before repair.
- Run targeted verification first.
- Broad tests/builds are allowed when relevant, with timeout and saved output. GitHub CI job timeout is 10 minutes (user-approved range: 5–10 minutes).
- Do not loop a hanging command.
- Do not delete, skip, archive or weaken a protection test to obtain green status.
- A local pass is `LOCAL_AUX_CHECK_ONLY`.
- Never claim fresh GitHub CI green without a fresh exact-HEAD GitHub log.
- If a command cannot run, record the exact blocked boundary and continue with safe independent work.

## 17. Screenshots boundary

Screenshots are mandatory evidence for frontend visual work and are local user-facing proof. PNG is not a mandatory GitHub CI input. Screenshot scripts may be guarded for `page.goto`, app-root, errors and provenance, but historical PNG hashes cannot be the only blocking CI criterion.

## 18. Archive numbering / development-release archive boundary

- Every changed pass creates the next sequential development ZIP.
- Archive names receive no unsolicited prefixes or suffix pollution.
- Development archive and release archive are separate artifacts.
- Frontend screenshots are delivered in a separate companion ZIP when required.
- Main development ZIP excludes screenshot PNG, nested ZIP, `node_modules`, `.next`, caches, temporary builds, secrets and unnecessary runtime logs.
- Missing live proof blocks release claims, not honest development archive delivery.

## 19. Patch permission boundary

Every patch must identify:

1. task type and route;
2. active truth anchors;
3. exact files to read;
4. exact files allowed to change;
5. restricted/manual-control files;
6. targeted tests;
7. evidence/report requirements.

No file may be changed merely because it is nearby. Each runtime diff must answer which confirmed regression or explicit task requirement it addresses.

## 20. Forbidden drift list

Forbidden:

1. demoting Kernel to navigation-only;
2. removing project keyword groups;
3. removing canonical anchors or route map;
4. treating `routes.yaml` as dead configuration;
5. using only hardcoded Python routes as active truth;
6. ignoring EFHC-specific keywords in `task_classifier.py`;
7. forcing full-read of `file_map.json`;
8. forcing full Healer Atlas/Casebook read for every task;
9. accepting frontend work without real route-backed proof;
10. claiming GitHub CI green without a fresh exact log;
11. claiming release-ready without live Telegram, TonConnect/TonProof and transaction evidence;
12. changing the six canonical bottom buttons without direct instruction;
13. changing economy/wallet/money-flow without high-risk route validation;
14. mixing development and release archives;
15. copying historical Current HEAD blocks into active Kernel;
16. updating CANON/SSOT/NORM to justify an unauthorized runtime change.

## 21. Active truth hierarchy

1. Direct current user instruction.
2. Factual content of the latest canonical HEAD.
3. AI Archive Laws and lock.
4. Active CANON.
5. Active SSOT.
6. Active NORM and Architectural Locks.
7. Active AI execution documents.
8. Fresh runtime evidence and logs.
9. Healer, cycles and reports.
10. Historical archives and preserved references.

A report, generated JSON, manifest or Healer entry cannot self-certify the behavior it is intended to prove.

## 22. Reference boundary

- `v171.63` is the input tree for the current governance synchronization pass.
- `v171.47` is a preserved forensic baseline, not current HEAD.
- `docs/AI/PRESERVED_OPERATOR_KERNEL_v171_47_FULL.md` is reference evidence.
- External artifacts history, reports, audits and cycles remain history and cannot override current direct instruction or active truth. Without explicit request, read only the latest two relevant entries per layer.
- Runtime and guards are restored by confirmed requirements, not blind file copying.

## 23. Compact compatibility anchors

Legacy navigation tokens remain searchable as compatibility pointers, not active historical state:

- `ACTIVE_DASHBOARD_COMPONENT_CONTRACT`;
- `ACTIVE_MINI_CHARTS_FOUNDATION`;
- `ACTIVE_SIMULATION_DASHBOARD_UI_KIT_FOUNDATION`;
- `ACTIVE_ADMIN_DASHBOARD_UI_KIT_FOUNDATION`;
- `ACTIVE_GRAFANA_REFERENCE_MAP_FOR_DASHBOARD_DIRECTION`;
- `ACTIVE_ENERGY_DASHBOARD_VISUAL_QA`;
- `DASHBOARD_TOOLBAR_FOUNDATION`;
- `ENERGY_DASHBOARD_RUNTIME_PORT`;
- `PANEL_CHROME_FOUNDATION`;
- `VARIABLES_FILTERS_SYSTEM`;
- `WalletBinding`;
- `PACK-02 tails cleanup`;
- `crypto_wallets` is not active wallet-binding storage;
- `Kernel lock: Withdraw V1 payout canon`;
- `GitHub CI Rerun Proof`;
- `live Telegram proof`.

The exact destination is resolved by `routes.yaml`, `file_map.summary.json`, route map and the relevant SSOT/NORM.


## 23A. Historical compatibility route anchors

Canonical archive lineage: `v171.64 → v171.65 → v171.66 → v171.67`.
These entries are searchable routing pointers, not alternate Current HEAD
blocks and not mandatory startup reads.

- historical route: `v171_31 / v171.31`, cycle `1556`;
- `DASHBOARD_COMPONENT_CONTRACT.md`;
- `v170.31 / dashboard visual kernel`;
- `v170.32 / sandbox dashboard inventory`;
- `v170.33 / Grafana Visual Pattern Map`;
- `v170.34 / Dashboard Design Tokens Foundation`;
- `GRAFANA_EFHC_ELEMENT_USAGE_MAP`;
- `GRAFANA_PATTERN_MAP_COMPLETION.md`;
- `DASHBOARD_TOOLBAR_FOUNDATION` / `DashboardToolbar.tsx`;
- `ENERGY_DASHBOARD_RUNTIME_PORT` / `EnergyDashboardRuntime.tsx`;
- `ENERGY_DASHBOARD_SANDBOX_PROTOTYPE`;
- `Energy Dashboard Visual QA`;
- `PANEL_CHROME_FOUNDATION` / `PanelChrome.tsx`;
- `MINI_CHARTS_FOUNDATION` / `MiniCharts.tsx`;
- `VARIABLES_FILTERS_SYSTEM` / `DashboardFilters.tsx`;
- `SimulationDashboardUiKit.tsx`;
- `Dashboard UI Kit Consolidation QA`;
- `Panels Portfolio Sandbox Prototype`;
- `Real Time-Series Backend Contracts`;
- `Synthetic Data Cleanup / Truth Hardening`;
- `Visual Performance / Bundle Safety`;
- `WITHDRAW_ADMIN_TONCONNECT_SSOT.md`;
- `WATCHER_INCOMING_DEPOSIT_ACCOUNTING_CANON.md`.

The exact destination is still resolved by `routes.yaml`, the short file
map and the current SSOT/NORM. Historical labels cannot override current
runtime architecture such as the `WalletProvider` adapter boundary.

Additional historical guard pointers:

- `EFHC_Bot_v171_64.zip`;
- `EFHC_Bot_v171_65.zip`;
- `compaction`;
- `AdminDashboardUiKit.tsx`;
- `EnergyDashboardSandboxPrototype.tsx`;
- `PANELS_PORTFOLIO_SANDBOX_PROTOTYPE`;
- `WITHDRAW_FLOW_NORM.md`;
- `test_dashboard_toolbar_foundation.py`;
- `test_energy_dashboard_runtime_port.py`;
- `test_energy_dashboard_visual_qa.py`;
- `test_grafana_pattern_map_completion.py`;
- `test_mini_charts_foundation.py`;
- `test_panel_chrome_foundation.py`;
- `test_variables_filters_system.py`.

## 24. Runtime route resolver requirement

`ops/operator_kernel/route_resolver.py` must use `ops/operator_kernel/config/routes.yaml` as the primary runtime source. A change to configured route data must change resolution behavior without a Python route edit. Hardcoded routes may exist only as bootstrap/fallback compatibility and must be reported as fallback usage.

## 25. File map freshness requirement

Refresh command: `python ops/operator_kernel/file_map.py --refresh`.

- `file_map.summary.json` is the short startup map.
- `file_map.json` is a machine index, not a full-read AI document.
- Refresh `file_map.json` after all file changes.
- Refresh summary from the final map.
- A stale/missing map must be reported, not silently treated as current.

## 26. Context capsule requirement

A context capsule must contain:

- пользовательскую задачу и архив;
- классификацию задачи и маршрут;
- границу активного цикла;
- обязательные правила и инварианты;
- канонические опорные точки;
- точно выбранные файлы;
- ограниченные релевантные фрагменты;
- разрешённые записи и файлы с ограничением изменений;
- целевую валидацию;
- граница доказательств и архива.

Капсула контекста — не просто список путей и по умолчанию не должна включать весь архив.

## 27. Граница утверждений о release/readiness

Формулировки `release-ready`, `production-ready`, `GitHub CI green`, `live Telegram verified`, `TonConnect verified`, `TonProof verified` и `transaction verified` являются доказательными утверждениями и требуют свежих подтверждений именно для заявленного scope.

Current verdict:

```text
LOCAL_RELEASE_CANDIDATE
FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED
NOT LIVE PRODUCTION READY
```

Исторический успешный CI-прогон, repair-report или локальный процент
полноты не являются доказательством для более позднего HEAD. Release gate
обязан сравнить `source_head` доказательства с точным текущим development
архивом и завершиться fail-closed при любом несовпадении. Отложенное внешнее
доказательство остаётся явно непроверенным.

Обязательные внешние проверки остаются:

- развёртывание на реальном production VPS и проверка HTTPS;
- реальный Telegram client и webhook;
- реальный `TonConnect` и `TonProof`;
- контролируемые операции пополнения, `Browser Shop` и вывода средств;
- Disaster Recovery на новом заменяющем VPS без одновременной второй production VPS.

## 28. Текущая граница миграции идентичности

Текущий этап расширяет физическую колонку `user_id`, не изменяя
владение runtime:

```text
canonical JSON value = string
pattern = ^[0-9]{10}$
PydanticUserId input = canonical string or validated UserId
PydanticUserId storage = UserId
PydanticUserId output = canonical ten-digit string
ApiExternalUserId = scalar path/query preparation
```

Следующие элементы остаются неизменными и защищёнными:

```text
users.id INTEGER primary key
users.tg_id BIGINT unique not null
AuthContext.tg_id
active routes and current Pydantic DTOs
all domain and financial ownership reads
Alembic head 0001
```

Контроль исторического цикла 1596 включает точный маршрут
`user_id_api_contract`, контрактные тесты OpenAPI и защищённый
манифест runtime/API. После этого исторического этапа выполнялись
проектирование expand-миграции и пробный прогон PostgreSQL.

Фактическим источником этого исторического состояния является
`EFHC_Bot_v171_95.zip`. Для v171.95 по-прежнему требовался отдельный
GitHub CI на точном HEAD.

## 29. v171.71 — контракт чистого первого запуска релиза

Единственная каноническая команда первого production-запуска:

```text
./scripts/release/deploy.sh
```

Цепочка зависимостей релиза:

```text
db healthy
→ migrate completed successfully
→ backend + scheduler healthy
→ frontend healthy
→ proxy healthy
```

Сервис миграции обязан создать обе канонические схемы, применить Alembic
head, проверить ровно 44 ORM-таблицы и вставить только идемпотентные
системные данные. Он не должен читать файлы документации. Ошибка миграции
не позволяет считать ни один прикладной сервис развёрнутым.

Оставшийся внешний gate этого исторического состояния — реальная Docker-
сборка без кэша и чистый запуск на VPS с последующим повторным deploy.
До появления такого доказательства `production_release_ready` остаётся false.


## Исторические опорные маршруты guard сохранены для действующей проверки

- `test_energy_dashboard_sandbox_prototype.py`;
- `PanelsPortfolioSandboxPrototype.tsx`;
- `test_panels_portfolio_sandbox_prototype.py`;
- `WITHDRAW_AUDIT_CANON.md`.


## 30. Накопительный контракт обновления полного release-архива


Production не устанавливает каждый промежуточный development number.
Release может обновляться напрямую с любой объявленной поддерживаемой
предыдущей production version. Updater отклоняет same-version install,
downgrade, source старше minimum manifest, неподдерживаемую Alembic revision,
неполный cumulative migration path, неверное target environment или отсутствие
проверенного pre-update backup перед изменением БД. Alembic применяет все
пропущенные revisions по порядку; соседство application archives не требуется.

Production update использует полный cumulative release archive, а не
пофайловую перезапись. Канонический маршрут:

```text
current release update.sh
→ external SHA-256
→ safe extraction + internal SHA256SUMS
→ RELEASE_METADATA + UPDATE_POLICY
→ source-range and cumulative migration compatibility
→ target deploy.sh
→ healthchecks
→ atomic /opt/efhc/current switch
```

Application rollback разрешён только когда `rollback_compatibility` явно
разрешает его без database restore. Восстановление БД всегда является отдельной
явной операцией.

## Цикл 1597 — действующая граница миграции идентичности

- Физическая колонка того периода: `efhc_core.users.user_id BIGINT NULL`.
- Выделение: независимая последовательность `users_user_id_seq`.
- Диапазон: `1..9999999999`; уникальность для ненулевых значений.
- Существующие строки: без backfill в цикле 1597.
- Legacy primary key: `users.id` оставался primary key.
- Telegram key: `users.tg_id` тогда оставался `NOT NULL`.
- Runtime read/write ownership в том цикле не менялся.
- TON Login был спроектирован, но не включён.
- Проверенный TON wallet должен был разрешать существующего пользователя.
- Новый проверенный TON wallet мог атомарно создать новый `user_id`.
- Подключение wallet без корректного TON Proof не является аутентификацией.
- Автоматическое объединение двух существующих аккаунтов запрещено.
- Следующий этап: LEGACY alias и migration harness.
## HISTORICAL / SUPERSEDED — граница migration identity периода 1598

> Этот блок сохраняется только как исторический контекст и **не является active authority**.
> Текущий канон: `docs/SSOT/GLOBAL_IDENTITY_SSOT.md`,
> `docs/NORM/GLOBAL_IDENTITY_RUNTIME_NORM.md` и active plan 1693–1707.
> Единственный account/business owner — `global_id`; единственный active Alembic head — `0001_initial_release_schema.py`.

- В периоде 1598 использовался alias `User.legacy_runtime_id -> User.id`.
- Планировался будущий alias `User.id -> User.user_id` и backfill `NULL users.user_id -> users.id`.
- В том периоде PostgreSQL SQL только рендерился, а runtime domain/financial reads ещё не переключались.
- Упоминание Alembic `0002` относится только к тому историческому этапу и **отменено** текущим single-head `0001` каноном.
- Историческим следующим циклом тогда был `1599 — PostgreSQL reconciliation gate`.

## Актуализация цикла 1677

Текущий изменённый HEAD: `v172.96`. Исправлены подтверждённые CI-сбои v172.93; следующий обязательный шаг — exact-head GitHub CI.