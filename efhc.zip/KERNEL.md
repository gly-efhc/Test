# EFHC FRONTEND OPERATOR KERNEL — SINGLE ACTIVE KERNEL

Last completed MAIN-cycle: `FRONTEND_ADMIN_CYCLE_0472` (OWNER-declared closure; Flake8 unqualified)
Current iteration: `0473/05` / physical checkpoint `FRONTEND_v752` / last report `00703` / OWNER upgrade-only version law and local external CI correction (Node24, Python3.12); previous v751 scope syntax and HTML title repair retained / financial v749 runtime unchanged / PostgreSQL, Flake8, FULL NOT RUN / Cycle0472 OWNER CLOSED / 0474–0505 planned NOT STARTED / no remote writes.

Назначение: ограничить работу одной текущей целью. Kernel — маршрутизатор и execution whitelist, а не исторический справочник.

## Вход
- physical HEAD из `START_HERE.md`;
- прямое текущее решение OWNER;
- текущий roadmap/operation.

## Разрешённые источники
Kernel читает только: `START_HERE.md`, `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`, `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`, `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md` и текущие CANON/SSOT/NORM, необходимые заявленной цели.

Historical `reports/`, старые cycles, historical OWNER decisions и `Артефакты` не читаются по умолчанию. Current report manifest/README/rules разрешены только как navigation/closure authority. Stale report pointer/manifest metadata не блокирует OWNER-authorized work: Kernel возвращает `REPORT_NAVIGATION_DRIFT` для bounded correction; строгая sequence остаётся closure gate.

## OWNER matrix lifecycle

Старая EAM matrix/derived CSS registries и старые theme census snapshots исключены OWNER вместе с тестами только этих snapshot-артефактов. Новая матрица ожидается; прежнюю автоматически не восстанавливать. `ELEMENT_AUTHORITY_POLICY.md` остаётся guard, но текущей EAM machine matrix нет. Прямые source/CT/design contracts и остальные tests продолжают действовать.

## Current-only machine law
- Kernel не требует и не создаёт per-release `OWNER_DECISION_vNNN.md`; direct current-session OWNER request является runtime authority.
- Kernel не использует versioned Theme snapshots, historical EAM audits или historical remediation plans как startup authority.
- Release identity проверяется через `VERSION` + `START_HERE.md` + matching root HTML/Shop artifacts.
- Current authority выбирается только через unversioned CANON/SSOT/NORM и `ACTIVE_DOCUMENTATION_INDEX.md`.

## OWNER-approved plugin whitelist / causality
Kernel разрешает только: **EFHC CODE, PostHog, Linear, Notion, Context7, DigitalOcean, Railway, Atlassian, GitHub**. Любой иной plugin = `REQUIRES_OWNER_APPROVAL`; до согласования его нельзя искать/подключать/использовать как рабочую зависимость.

- EFHC CODE = governance/orchestration/report/release/verification routing.
- GitHub = repository source/history/CI; bounded sync, не interactive filesystem.
- Linear = primary work-state metadata.
- Railway = runtime/deploy evidence and operations.
- PostHog = product telemetry/analytics.
- Context7 = current external technical docs.
- Notion = durable project knowledge.
- DigitalOcean = persistent remote engineering execution environment.
- Atlassian = reserve-only enterprise branch; no duplicate Jira backlog beside Linear.

Causal core: `OWNER → EFHC CODE → local workspace → bounded GitHub sync → GitHub CI evidence → EFHC CODE/report`. Optional Context7/Linear/Notion/Railway/PostHog/DigitalOcean/Atlassian branches включаются только когда текущий scope реально требует их capability.

## GitHub execution split
- Local chat workspace is the primary mutable engineering workspace. GitHub `main` is repository source/history/CI authority beneath OWNER/SSOT/CANON/NORM and is synchronized only in bounded batches.
- Physical `FRONTEND_vNNN.zip` remains the immutable release/provenance artifact and never becomes a mutable working filesystem.
- Canonical flow: local bounded development → one logical GitHub sync → heavy lint/type/test/build/security/integrity/release work in GitHub Actions → read summary first and only failed job/step/log slice when needed → continue locally.
- `_import/` — OWNER-protected persistent transfer boundary and must remain in local workspace, full physical release and GitHub repository. Primary transport is the complete immutable `FRONTEND_vNNN.zip`, uploaded by OWNER into `_import/`; patch-only transport is not primary. After validated mirror sync, only the transport ZIP is removed; `_import/README.md` and the directory persist. The folder itself is never auto-deleted.

## Один запуск
Для одного MAIN-cycle/operation Kernel по умолчанию запускается ровно один раз. Fail-closed не разрешает второй запуск автоматически.

**OWNER correction / repeat authorization (Cycle0464, 2026-10-18).** После каждого нового ответа OWNER допускается уточняющий или повторный запрос Kernel **только по необходимости**: если OWNER прямо разрешил повтор или сообщил новые решения, требующие повторной маршрутизации. Перед повтором зафиксировать причину, предыдущую ошибку/изменившийся scope и ожидаемый результат; исправить параметры, явно перечислить affected paths и не обходить fail-closed. Сам ответ OWNER не является безусловным разрешением на неограниченные повторы, особенно без изменения входных условий. Для Cycle0464 OWNER прямо разрешил один повтор после ошибки `task_class=implementation`; повтор с `project_cycle` завершился PASS; один дополнительный OWNER-разрешённый уточняющий вызов на новых точно установленных regression/release paths завершился PASS без расширения функциональной цели.


## Обязательный результат Kernel
Kernel обязан вернуть:
- `GOAL` — одна цель;
- `ALLOWED_READ` — закрытый список документов/source;
- `ALLOWED_WRITE` — закрытый список файлов/семейств;
- `ALLOWED_CHECKS` — конечный список проверок;
- `FORBIDDEN` — явно запрещённый scope;
- `STOP_CONDITION` — когда работа немедленно останавливается;
- `EXPECTED_OUTPUT` — ожидаемый артефакт/результат.

Любое действие вне whitelist требует прямого OWNER-разрешения. Kernel не может добавлять historical guards «на всякий случай».

Для мутирующей операции каждый разрешённый writable path передаётся Kernel явно через `--affected-file`. Kernel не угадывает writable scope по названию семейства/цикла. Если `--affected-file` не передан, `ALLOWED_WRITE = []` и операция остаётся read-only/fail-closed. Это не требует второго Kernel-run: affected paths должны быть определены из прямой OWNER задачи и current-only startup context до единственного запуска.

## Current cache lifecycle
`ops/operator_kernel/cache/file_map.summary.json` is non-authoritative cache only. It must be regenerated/synchronized during release closure to the new physical HEAD, current cycle state, latest report and next report. A stale cache may be ignored at startup but must not be carried forward as the released current cache.

## Regression
Regression определяется только относительно OWNER-good baseline и ближайших изменений после него. Historical wildcard corpus не является default gate. Baseline failure = `BASELINE/OUT_OF_SCOPE`, а не новая задача.

## Admin freeze
Admin panel считается завершённой и frozen. Kernel не разрешает Admin mutation без прямого отдельного OWNER-решения.

## Stop
После достижения `EXPECTED_OUTPUT` работа останавливается. Следующий cycle автоматически не стартует.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

