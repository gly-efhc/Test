# EFHC FRONTEND OPERATOR KERNEL — SINGLE ACTIVE KERNEL

Last completed MAIN-cycle: `FRONTEND_ADMIN_CYCLE_0535` — инженерный блок завершён, CI PARTIAL.
Last OWNER-authorized MAIN-cycle: `FRONTEND_ADMIN_CYCLE_0535` (iteration02: partial checkpoint; exact-final CI unqualified)
Current checkpoint: версия из `VERSION` явно выбранного OWNER ZIP; последний report из manifest, статус SAVEPOINT / PARTIAL; старт из чистой распаковки либо разрешённая рабочая копия, см. раздел о физической привязке.

Аудит возможностей инженерной среды: `docs/AI/ENGINEERING_ENVIRONMENT_CAPABILITY_REGISTER.md`; повторная безопасная проверка команд: `python ops/quality/probe_engineering_environment.py`. Доступность среды заново сверять до вывода о блокерах; изолированная сетевая проверка npm не равна exact-HEAD CI.

Назначение: ограничить работу одной текущей целью. Kernel — маршрутизатор и execution whitelist, а не исторический справочник.

## Вход
- physical HEAD из `START_HERE.md`;
- прямое текущее решение OWNER;
- текущий roadmap/operation.

## Разрешённые источники
Kernel читает только: `START_HERE.md`, `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`, `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`, `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md` и текущие CANON/SSOT/NORM, необходимые заявленной цели.

Historical `reports/`, старые cycles, historical OWNER decisions и `Артефакты` не читаются по умолчанию. Current report manifest/README/rules разрешены только как navigation/closure authority. Stale report pointer/manifest metadata не блокирует OWNER-authorized work: Kernel возвращает `REPORT_NAVIGATION_DRIFT` для bounded correction; строгая sequence остаётся closure gate.

## OWNER matrix lifecycle

Старая EAM matrix/derived CSS registries и старые theme census snapshots исключены OWNER вместе с тестами только этих snapshot-артефактов. Новая матрица ожидается; прежнюю автоматически не восстанавливать. `ELEMENT_AUTHORITY_POLICY.md` остаётся guard, но текущей EAM machine matrix нет. Прямые source/CT/design contracts и остальные tests продолжают действовать.

## Current-only machine law
- Kernel не требует и не создаёт per-release `OWNER_DECISION_vNNN.md`; direct current-session OWNER request является runtime authority.
- Kernel не использует versioned Theme snapshots, historical EAM audits или historical remediation plans как startup authority.
- Release identity проверяется через `VERSION` + `START_HERE.md` + matching root HTML/Shop artifacts.
- Current authority выбирается только через unversioned CANON/SSOT/NORM и `ACTIVE_DOCUMENTATION_INDEX.md`.

## OWNER-approved plugin whitelist / causality
Kernel разрешает только: **EFHC CODE, PostHog, Linear, Notion, Context7, DigitalOcean, Railway, Atlassian, GitHub**. Любой иной plugin = `REQUIRES_OWNER_APPROVAL`; до согласования его нельзя искать/подключать/использовать как рабочую зависимость.

- EFHC CODE = governance/orchestration/report/release/verification routing.
- GitHub = repository source/history/CI; bounded sync, не interactive filesystem.
- Linear = primary work-state metadata.
- Railway = runtime/deploy evidence and operations.
- PostHog = product telemetry/analytics.
- Context7 = current external technical docs.
- Notion = durable project knowledge.
- DigitalOcean = persistent remote engineering execution environment.
- Atlassian = reserve-only enterprise branch; no duplicate Jira backlog beside Linear.

Causal core: `OWNER → EFHC CODE → local workspace → bounded GitHub sync → GitHub CI evidence → EFHC CODE/report`. Optional Context7/Linear/Notion/Railway/PostHog/DigitalOcean/Atlassian branches включаются только когда текущий scope реально требует их capability.

## GitHub execution split
- Local chat workspace is the primary mutable engineering workspace. GitHub `main` is repository source/history/CI authority beneath OWNER/SSOT/CANON/NORM and is synchronized only in bounded batches.
- Physical `FRONTEND_vNNN.zip` remains the immutable release/provenance artifact and never becomes a mutable working filesystem.
- Canonical flow: local bounded development → one logical GitHub sync → heavy lint/type/test/build/security/integrity/release work in GitHub Actions → read summary first and only failed job/step/log slice when needed → continue locally.
- `_import/` — OWNER-protected persistent transfer boundary and must remain in local workspace, full physical release and GitHub repository. Primary transport is the complete immutable `FRONTEND_vNNN.zip`, uploaded by OWNER into `_import/`; patch-only transport is not primary. After validated mirror sync, only the transport ZIP is removed; `_import/README.md` and the directory persist. The folder itself is never auto-deleted.

## Operator Kernel — максимум 8 вызовов за MAIN-cycle и 2 за итерацию (OWNER Cycle0511, 23.10.2026)

В одном прямо разрешённом MAIN-cycle допускается **не более 8 физических запусков Operator Kernel суммарно**, а внутри **одной самостоятельной OWNER-итерации — максимум 2 запуска**. Каждый вызов, включая `FAIL-CLOSED`, входит одновременно в оба счётчика. Один штатный вызов предпочтителен; второй за итерацию допустим при зафиксированной необходимости исправить входные данные/whitelist. В одной итерации третий вызов запрещён даже при наличии свободного циклового лимита. После восьмого циклового запуска дальнейшие вызовы запрещены независимо от количества итераций. Новая итерация требует прямой OWNER-команды и действительного самостоятельного work scope; нельзя выдумывать итерации ради обхода ограничения.

Смена числового лимита сама по себе **не отменяет `FAIL-CLOSED`**, whitelist, запреты удалённых операций и необходимость прямо разрешённого scope. Каждый task-specific вызов использует физический HEAD, правильный `--archive`, точные `--affected-file`. Учёт вести отдельно по циклу и итерациям: для Cycle0511/iteration01 исторически 2 вызова (FAIL-CLOSED, PASS), для iteration02 первый подтверждён PASS (итого 3/8). Эти факты не переписываются. Новое правило действует с прямого OWNER-решения Cycle0511/iteration02.

Эта норма применяется к цикловому task-specific Kernel; read-only bootstrap нового физического HEAD выполняется однократно в стартовом intake и не открывает цикл автоматически. Успешная проверка Kernel не заменяет Flake8, регрессионные тесты или release qualification.

Исторический факт: в Cycle0464 OWNER отдельно разрешал уточняющие вызовы по текущему на тот момент контракту. Новый предел действует вперёд с Cycle0509 и не переписывает историческую запись.


## Обязательный результат Kernel
Kernel обязан вернуть:
- `GOAL` — одна цель;
- `ALLOWED_READ` — закрытый список документов/source;
- `ALLOWED_WRITE` — закрытый список файлов/семейств;
- `ALLOWED_CHECKS` — конечный список проверок;
- `FORBIDDEN` — явно запрещённый scope;
- `STOP_CONDITION` — когда работа немедленно останавливается;
- `EXPECTED_OUTPUT` — ожидаемый артефакт/результат.

Любое действие вне whitelist требует прямого OWNER-разрешения. Kernel не может добавлять historical guards «на всякий случай».

Для мутирующей операции каждый разрешённый writable path передаётся Kernel явно через `--affected-file`. Kernel не угадывает writable scope по названию семейства/цикла. Если `--affected-file` не передан, `ALLOWED_WRITE = []` и операция остаётся read-only/fail-closed. Обычно whitelist определяется до первого запуска; при подтверждённом изменении входных условий допускается обоснованный второй вызов в пределах **2 за итерацию и 8 за цикл**.

## Current cache lifecycle
`ops/operator_kernel/cache/file_map.summary.json` is non-authoritative cache only. It must be regenerated/synchronized during release closure to the new physical HEAD, current cycle state, latest report and next report. A stale cache may be ignored at startup but must not be carried forward as the released current cache.

## Regression
Regression определяется только относительно OWNER-good baseline и ближайших изменений после него. Historical wildcard corpus не является default gate. Baseline failure = `BASELINE/OUT_OF_SCOPE`, а не новая задача.

## Admin freeze
Admin заморожен **только визуально**. Подтверждённые ошибки Admin исправляются в текущем OWNER-authorized scope приоритетно и не блокируются из-за расположения файла в Admin. Неизменны утверждённые дизайн/геометрия/цвета; самостоятельный редизайн требует отдельного OWNER-решения. При функциональной/форматирующей правке Admin необходимо сохранить визуальную композицию и независимые финансовые/security/identity/ENV контракты. Возможные прежние `BLOCKED_OWNER` по одному признаку Admin подлежат пересмотру.

## Stop
После достижения `EXPECTED_OUTPUT` работа останавливается. Следующий cycle автоматически не стартует.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

## OWNER — физический архив как единственная идентичность запуска Kernel (25.10.2026)

- **Единственный источник исходной версии:** `VERSION` внутри **последнего явно выбранного OWNER-архива** `FRONTEND_vNNN.zip`. Его имя обязано совпадать с внутренней версией; CRC, дубли, пути и исходные артефакты проверяются строго. Нельзя выбирать максимальную версию автоматически или искать старый каталог как HEAD.
- Запуск: `python ops/operator_kernel/run.py --root /workspace --archive /path/FRONTEND_vNNN.zip --clean-extract --json` **только для пустого** `/workspace`; для уже распакованного и изменённого workspace — та же команда **без** `--clean-extract`, с полным перечнем разрешённых `--affected-file`. Допускается `--archive-prefix FRONTEND_vNNN --archive-directory /path` только при точном имени.
- После старта сравниваются побайтово пути исходного ZIP и текущего дерева: **добавления, изменения и удаления допустимы только в перечисленном OWNER whitelist**, иначе FAIL-CLOSED. ENV и `_import/` не являются исключением из сравнения. Разрешённый выпуск следующей версии возможен лишь с явным `VERSION` в whitelist и парой matching HTML; исходный архив не меняется.
- Заголовки, `START_HERE.md`, `KERNEL.md`, `README.md`, roadmap и другие human-readable страницы **не являются версионными authority**. Устаревшие текущие указатели фиксируются предупреждением и исправляются при ближайшем разрешённом выпуске, не вызывая ложного FAIL-CLOSED. **Заголовки без дублирующих номеров**; история выпусков и report provenance сохраняются.
- Номер отчёта определяется `reports/FRONTEND_REPORT_MANIFEST.json`, отдельные текущие указатели в документах не обязательны; каждый законченный материальный блок получает новый numbered report. Next MAIN-cycle не стартует автоматически.
- Реальное нарушение целостности ZIP, неверный `VERSION`, несанкционированные файловые изменения или защищённые потери по-прежнему дают FAIL-CLOSED. Лимиты вызовов Kernel сохраняются.
