<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **Действующий канон идентичности EFHC.** `global_id` — главный и единственный
> персональный идентификатор единого аккаунта EFHC и owner всех внутренних
> доменных, финансовых и административных объектов. `global_id` передаётся во
> внешнем API как строка ровно из 10 ASCII-цифр. Любой внешний вход описывается
> формулой `provider + subject → global_id`. Telegram использует `tg_id` только
> как provider subject на границах Telegram authentication, `initData`, update,
> Bot API, channel membership, notification/payment delivery и identity mapping.
> После разрешения identity внутренний runtime использует только `global_id`.
> Исторические упоминания `user_id` и прежнего owner-значения `tg_id` не являются
> действующим законом и не могут возвращаться в новые контракты.

# Обязательное правило пользовательских CI-логов

Если пользователь передал полный архив CI-логов, запрещены полный
локальный CI, полный pytest, test-shards и повторы уже зелёных этапов
без доказанной необходимости. Нужно исправлять failures из переданных
логов, выполнить только короткие точечные проверки и сразу собрать
следующую версию.

Полный канон:
`docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md`.

---

# Текущий статус v172.52 — циклы 1636–1637

Fresh GitHub CI `83405061075` проверил exact
`EFHC_Bot_v172_51.zip` размером `12650102` байта. PostgreSQL,
единая migration `0001`, production frontend build и все `102`
route-backed Chromium checks прошли. Красный итог вызвали только
`13` статических/документных pytest guards, один Ruff import-order
finding и один Mypy return-type finding. Runtime, schema, auth и
financial regression не подтверждены.

Цикл `1636` квалифицирован реальным PostgreSQL-прогоном ядра.
В `v172.52` выполнен цикл `1637`:

- Telegram Bot `/start` создаёт новый account только через
  `AccountRegistrationService`;
- raw SQL вставка `users` из referral onboarding удалена;
- `User`, immutable `ReferralLink` и Telegram `UserIdentity`
  создаются атомарно в одной транзакции;
- invalid/missing referral отклоняется до создания account;
- существующий пользователь, включая permanent `0 user`, не может
  получить позднюю referral-привязку;
- WebApp и TON callers не переключались и остаются scope цикла `1639`;
- migration, schema, экономика и шесть нижних маршрутов не менялись.

Visual gate exact `v172.51` прошёл `102/102`, но переданный архив
`ci_artifacts (3).zip` не содержит PNG. Поэтому пользовательская
visual acceptance follow-up цикла `1635` остаётся открытой.

```text
CURRENT_HEAD_V172_52
CYCLE_1635_VISUAL_ACCEPTANCE_REQUIRED
CYCLE_1636_ACCOUNT_REGISTRATION_CORE_QUALIFIED
CYCLE_1637_BOT_REGISTRATION_IMPLEMENTED
CYCLE_1637_EXACT_HEAD_CI_REQUIRED
CYCLE_1638_NOT_STARTED
CYCLE_1639_NOT_STARTED
CYCLE_1640_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---
# Актуализация qualification boundary — v172.39

Fresh CI `83288192546` не закрыл цикл `1630` только из-за повреждённых
имён файлов в development ZIP. В v172.39 исправлены имена и механизм
упаковки. Universal CI, schema, auth и financial runtime не менялись.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Physical rename и migration `0013` запрещены до полного CI PASS.

---

# Актуализация qualification boundary — v172.38

Fresh CI `83283286008` не закрыл цикл `1630`: pytest дал шесть
current-head failures, Chromium — `51` admin marker failures. В
v172.38 выполнено только corrective-исправление application/test
harness и metadata. Universal CI и schema не менялись.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

Physical rename и migration `0013` запрещены до полного CI PASS.

---

# Актуализация qualification boundary — v172.37

Fresh exact-head CI v172.36 дал `3170 passed, 21 skipped` и нулевые
cross-provider failures. Единственный красный gate — `51` route-backed
admin marker failures. v172.37 устраняет преждевременное решение admin
guard до завершения Telegram identity bootstrap. Migration `0013`
отсутствует; циклы `1631` и `1632` не начаты.

```text
CYCLE_1630_EXACT_HEAD_CI_FAILED
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
CYCLE_1632_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.36

Fresh exact-head CI v172.35 подтвердил Telegram/TON cross-provider
Chromium proof, но route-backed visual gate и полный pytest остались
красными. v172.36 исправляет только подтверждённые CSP, expected-status,
admin build-profile и stale-contract findings. Physical rename цикла
`1631` не начат; migration `0013` отсутствует.

---

# Актуализация qualification boundary — v172.35

Fresh exact-head CI v172.34 реально запустил Chromium, но audit завершил
работу `exit=1`; поэтому цикл `1631` заблокирован. Corrective v172.35
меняет только test/evidence harness, stale contracts, Ruff и однократно
обновлённый универсальный canonical CI. Production ownership, financial
semantics и migrations не меняются.

```text
CYCLE_1630_EXACT_HEAD_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация qualification boundary — v172.34

Fresh exact-head CI v172.33 не закрыл цикл `1630`: PostgreSQL/API
negative contract получил wrong DB input profile, а Chromium proof был
пропущен. Corrective v172.34 исправляет только evidence/test harness,
stale contracts и Ruff. Production ownership, financial semantics,
migrations и CI workflows не меняются. Цикл `1631` не начат.

```text
CYCLE_1630_EXACT_HEAD_CI_INCOMPLETE
CYCLE_1630_CI_FINDINGS_CORRECTED
CYCLE_1630_CORRECTIVE_PACKAGE_READY
CYCLE_1630_CANONICAL_AND_VISUAL_CI_REQUIRED
CYCLE_1631_NOT_STARTED
NOT_PRODUCTION_RELEASE_READY
```

---

# Актуализация cross-provider session boundary — v172.33

Current HEAD: `EFHC_Bot_v172_33.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin business API требуют server-side Bearer
session. Raw Telegram `initData` допускается только как credential для
явного `/auth/telegram/session`, а не как business-auth fallback.
Canonical owner остаётся `global_id`; internal legacy `tg_id` selector
до `1631` разрешён только после session → global_id resolution.
Financial write semantics, precision, idempotency и formulas не менялись.
Цикл `1631` не начат. SSOT имеет приоритет при конфликте канона.

---

# Актуализация session-first ownership — v172.32

Current HEAD: `EFHC_Bot_v172_32.zip`. Alembic head `0012`; migration
`0013` отсутствует. Common/admin API используют server-side Bearer
session как primary transport и canonical `global_id` как owner.
Legacy Telegram transport остаётся измеряемой compatibility-веткой.
Frontend owner cache использует `GlobalId`. Financial write semantics,
precision, idempotency и formulas не менялись. Cycle `1630` не начат.
SSOT имеет приоритет над техническими заданиями при конфликте канона.

---

# Актуализация identity ownership — v172.31

Current HEAD: `EFHC_Bot_v172_30.zip`. Alembic head `0011`. Financial read switch использует `global_id`; legacy writes, dual-write, precision, idempotency и formulas неизменны. Cycle `1628` не начат. SSOT имеет приоритет над техническими заданиями при конфликте текущего канона.

---

# Активный пакет v172.29

Corrective-only qualification цикла `1626`. Fresh CI `83144620488`
подтвердил real PostgreSQL `0010`, но financial validation test fixture
упал до reconciliation gate. Исправляются только exact findings.
Financial read switch `1627` не начат.

---

# Активный пакет v172.28

Cycle `1626`: read-only financial shadow validation. Real PostgreSQL
`0010` подтверждён run `83121417737`. Head остаётся `0010`; migration
`0011` отсутствует. Monetary discrepancy обязано быть `0.00000000`;
precision/idempotency должны остаться неизменными. Financial read switch
`1627` не начат.

---

# Активный пакет v172.27

Cycle `1625`: provider-neutral non-financial read switch.
Real PostgreSQL `0009` подтверждён run `83098311619`.
Head `0010`; legacy writes остаются активными.
Financial shadow validation `1626` не начата.

---

# EFHC — текущий инженерный контекст

Current package: `v172.26`, corrective qualification цикла `1624`.

Fresh CI run `83093436890` на exact `v172.25` обнаружил critical
PostgreSQL blocker migration `0009`: telemetry view SQL содержала
`UNION ALL` перед новым `WITH`, что недопустимо в таком set-operation.

Обязательные ограничения:

- owner — только `global_id`;
- физический FK target — `users.global_id`; прежняя стадия до 1631 историческая;
- legacy owner/source fields остаются authoritative;
- financial amounts, precision и idempotency semantics не меняются;
- CI workflow остаётся побайтно неизменным;
- цикл `1625` не начинать до fresh exact-HEAD CI `v172.26`.

Use `START_HERE.md` as the only startup entrypoint.
