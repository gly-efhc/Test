# CLAUDE — EFHC FRONTEND

Mandatory entrypoint: `START_HERE.md`.

Этот архив предназначен только для frontend development. Не использовать унаследованные общепроектные backend/DB/DevOps правила как frontend authority. Main archive читается только для backend/OpenAPI/runtime contracts. Frontend HEAD + standalone HTML являются writable frontend authority. Обновлять EAM, frontend docs, regression evidence и cycle report вместе с реализацией.

## ENV OWNER-PROTECTED — ABSOLUTE ANTI-LOSS LAW

**Прямая OWNER-команда: ENV является OWNER-PROTECTED данными.** Под ENV понимаются `.env`, `.env.*`, `env.*`, ENV templates, recovered copies, deployment/runtime ENV manifests и все содержащиеся в них значения.

Без отдельного прямого разрешения OWNER в текущей задаче **АБСОЛЮТНО ЗАПРЕЩЕНО**: удалять ENV-файл или отдельное ENV-значение; очищать/truncate/обнулять; заменять конкретное значение placeholder/empty/default; redaction/sanitization с потерей исходника; исключать ENV из full physical release/repository/workspace/backup; удалять через cleanup/security hardening/refactor/import/mirror; переименовывать или переносить так, что исходник теряется; считать `.gitignore`, `.dockerignore`, security best practice или наличие потенциального секрета разрешением на удаление.

Если обнаружен security concern, агент/скрипт обязан **STOP destructive mutation → сохранить исходные bytes → сообщить OWNER → ждать прямое решение**. Любая разрешённая OWNER-модификация ENV должна иметь before/after evidence и выполняться через новый immutable physical release. Repository/full-release mirror обязан fail-closed, если входящий release удалит или изменит уже существующий ENV без exact OWNER approval.

Текущий incident status: **ENV НЕ ВОССТАНОВЛЕН / `RECOVERY_REQUIRED`**. Нельзя объявлять ENV восстановленным, придумывать утраченные значения или заменять неизвестные значения placeholders. Machine status: `release_config/ENV_RECOVERY_STATUS.json`; machine protection policy: `release_config/ENV_OWNER_PROTECTION.json`; human SSOT: `docs/SSOT/ENV_PROTECTION_SSOT.md`.

