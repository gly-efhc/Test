# Change cycle 1557 — Tasks, Ads alias and typography

Cycle 1557 replaces competing Tasks surfaces with one React Query catalogue,
closes the automatic-ad status refetch gap, proves replay-safe custom claims,
and makes the application typography compact and Arial-like.

Browser evidence confirms one claim POST, one advertising callback POST,
three `/tasks/my` reads, visible claimed states, no horizontal overflow and
working modal confirmation at 390 px. Separate screenshots confirm that
Panels and Exchange values remain on one line.

The release evidence register advances from 13 to 15 verified points because
REL-023 is now verified. All later cycles remain open and are not executed in
this iteration.

## Final local verification

- Exact inventory: `2389` unique test nodes.
- Regression: `2263 passed`, `126 skipped`, `0 failed`.
- New explicit `skip` or `xfail` markers: `0`.
- Browser E2E after final build: `2 passed`.
- Clean `npm ci`: passed with `0` vulnerabilities.
- TypeScript and frontend architecture: passed.
- Consecutive production builds: `2 passed`.
- Generated Next pages per build: `34`.
- Release evidence score: `15 / 100`.

Only the current work scope is completed. Fresh GitHub CI, live Telegram,
real TonConnect, real PostgreSQL concurrency and final release audit remain
fail-closed.
