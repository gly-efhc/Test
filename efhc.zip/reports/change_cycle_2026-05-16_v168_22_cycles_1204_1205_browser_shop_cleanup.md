# Change report v168_22 cycles 1204-1205

## HEAD

Input HEAD:
`EFHC_Bot_v168_21_cycles_1202_1203_browser_shop_layout.zip`.

Output archive:
`EFHC_Bot_v168_22_cycles_1204_1205_browser_shop_cleanup.zip`.

## Main result

Cycles 1204-1205 cleaned the public Browser-Shop storefront.

The page was no longer only a separate layout.  It is now also a clean
public storefront without operator diagnostics, manual payment rows,
copy wallet/copy memo blocks, SKU/Type detail rows or payment-chain
facts.

## Code changes

Changed:

- `frontend/src/features/browser-shop/BrowserShopPage.tsx`;
- `frontend/src/pages/admin/diagnostics.tsx`;
- `frontend/public/locale/*.json`.

Added:

- `tests/architecture/`
  `test_browser_shop_public_cleanup_guard.py`;
- `docs/audits/BROWSER_SHOP_PUBLIC_CLEANUP_1204_1205.md`;
- `reports/generated/browser_shop_public_cleanup_1204_1205.json`.

## Public UI result

The public storefront now renders:

- `Витрина EFHC` / localized storefront title;
- short human explanation;
- ready EFHC cards;
- title, description, TON/USDT price display and `Pay` action;
- simple human payment states.

The public storefront no longer renders:

- endpoint labels;
- `truth-layer` blocks;
- search and category filters;
- custom amount form;
- SKU, Type or USDT jetton rows;
- wallet and memo rows;
- copy buttons;
- payment-chain diagnostics.

## Admin diagnostics

`/admin/diagnostics` now contains a Browser-Shop operator diagnostics
section.  Endpoint and payment-status details are kept there as admin
information instead of public UI content.

## Checks

- Source ZIP `unzip -t`: OK.
- Targeted visual pytest: 19 passed.
- Frontend `npm ci --ignore-scripts`: OK.
- Frontend `npx tsc --noEmit`: OK.
- Locale JSON validation: OK.
- Next build reached route summary and generated `/browser-shop`, but
  the shell wrapper did not return a captured exit code before timeout.
- Result ZIP `unzip -t`: OK after archive build.

## Not claimed

- GitHub CI was not run.
- Full visual release readiness is not claimed.
- Immediate TonConnect wallet-open from Pay remains the next active
  product/payment integration target.
- Browser screenshot proof was not run.
