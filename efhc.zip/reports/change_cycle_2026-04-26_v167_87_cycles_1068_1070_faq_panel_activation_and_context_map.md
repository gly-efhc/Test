# v167_87 — cycles 1068-1070 FAQ panel activation and context map

## What was found

After the earlier corrective passes, the active FAQ still needed one bounded
all-locale panel check to ensure every language uses the panel activation
canon and avoids `buy panel` / `panel price` style wording.

The helper forbidden guard also still reports a suspicious non-blocker context
layer around `reward / prize / win`, which requires Russian iteration before
semantic rewrites.

## What was changed

- active FAQ panel wording was normalized across all active FAQ languages;
- section 7-1 panel question and the related activation answer were updated to
  activation wording where old cost wording remained;
- `frontend/src/data/faq/catalogs.ts` was synchronized with the SSOT FAQ files;
- audit docs for panel activation, suspicious context map and final range
  verdict were added;
- cycle docs, reports index, Q&A and Healer follow-up notes were updated.

## Helper checks

- forbidden gaming contour guard: `forbidden_findings: 0`
- no admin leak: `admin_leak_findings: 0`
- admin ru-only: `admin_ru_raw_keys: 0`, `admin_ru_empty_values: 0`
- placeholders: `placeholder_mismatches: 0`
- identical-to-English: `identical_findings: 0`

## Boundary

No automatic semantic rewrite was applied to `reward / prize / win` because
those terms are context-sensitive and user requested Russian iteration for
such cases.
