# EFHC Bot — change report
## 2026-04-11 — v166_61 — cycles 851-853 audit-answers sync wave

### What changed
- synced the new 851+ work block with the user answers to the 10 audit
  questions.
- updated the withdraw TonConnect SSOT so that the decisive proof is the
  operator pressing `Send` in Tonkeeper / MyTonWallet / a compatible
  wallet, while `tx_hash` remains a secondary technical attribute.
- updated the external storefront norm to reflect that the approved
  handoff binds the browser-shop to the player profile context.
- recorded the audit-iteration answers in the Q&A register.
- added an execution note that block 851-870 is fixed as a list but may
  be regrouped and executed partially.

### Honesty boundary
- this pass mostly advances the new block at the SSOT / planning level.
- no claim is made yet that the withdraw/hub/browser-shop runtime has
  been fully rebuilt; this is the work of the next implementation cycles.
