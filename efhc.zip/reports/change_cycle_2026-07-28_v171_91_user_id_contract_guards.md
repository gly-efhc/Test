# EFHC Bot v171.91 — cycle 1594 UserId contract guard report

## Input and status

- Source HEAD: `EFHC_Bot_v171_90.zip`.
- Source SHA-256:
  `96b30753f1d2d9ca469a3fed3f67ce57f561719271ebbfb8a6db1cc3c98317d1`.
- Source ZIP entries: `4885`.
- Cycle: `1594`.
- Target development HEAD: `EFHC_Bot_v171_91.zip`.
- Target release candidate: `EFHC_Bot_v171_91_RELEASE.zip`.
- Schema migration: `NONE`.
- Runtime ownership switch: `NONE`.
- Honest status: `LOCAL_RELEASE_CANDIDATE`.

## Implemented changes

Cycle 1594 converts the new identity doctrine from documentation-only intent
into an executable, side-effect-free value contract and a stronger negative CI
boundary.

Implemented:

- backend `UserId`, `TelegramId`, `UserIdDisplay` and `ExternalUserId` types;
- strict validation and ten-digit formatting;
- V2 semantic boundary guard;
- indirect identity-mixing detection for Python and TypeScript;
- semantic category, migration wave and sunset metadata for all legacy files;
- `485`-file exact SHA-256 patch-boundary lock;
- generated-cache exclusion in the patch-boundary checker;
- positive, negative and regression tests;
- reconciliation metadata corrected to cycle 1594 and target v171.91;
- current canonical documents, Healer, Kernel, release docs and environment
  templates updated to the new doctrine.

No model, migration, service, CRUD, route, Pydantic schema, frontend ownership
file or financial invariant was changed.

## Final audit

The final machine audit is stored in:

```text
reports/generated/user_id_global_id_audit_v171_91.json
reports/generated/user_id_global_id_usage_matrix_v171_91.csv
reports/generated/user_id_global_id_usage_matrix_v171_91.json
reports/generated/user_id_global_id_orm_fields_v171_91.csv
reports/generated/user_id_global_id_service_signatures_v171_91.csv
reports/generated/user_id_global_id_routes_v171_91.csv
```

The `2054` real domain dependency rows, `32` ORM fields and `336` service
signatures remain unchanged from the cycle-1593 baseline. Increased total text
inventory comes only from doctrine, tests and guards.

## Verification

```text
Full collection: 2740
Passed: 2568
Skipped: 172
Failed: 0
Errors: 0
Targeted UserId/guard suite: 43 passed
Integration inventory: 25 collected
Integration runtime: 25 skipped because PostgreSQL URL is unavailable
Compileall: passed
Identity boundary: passed
Patch boundary: passed
Reconciliation: NOT_RUN_DB_UNAVAILABLE
```

Proof paths:

```text
reports/generated/global_id_domain_boundary_v171_91.json
reports/generated/user_id_contract_patch_boundary_v171_91.json
reports/generated/cycle_1594_pytest_summary_v171_91.json
reports/generated/user_identity_reconciliation_v171_91.json
reports/junit/cycle_1594_targeted_v171_91.xml
reports/junit/cycle_1594_integration_v171_91.xml
reports/junit/cycle_1594_full_chunk_01_v171_91.xml
...
reports/junit/cycle_1594_full_chunk_08_v171_91.xml
reports/runtime_logs/cycle_1594_targeted_v171_91.txt
reports/runtime_logs/cycle_1594_integration_v171_91.txt
```

## Honest limitations

Fresh exact-HEAD GitHub CI is required for v171.91. The local environment did
not provide PostgreSQL, psycopg, Ruff, Mypy, Bandit or cached frontend
dependencies. Therefore PostgreSQL runtime tests, frontend typecheck/build,
real Chromium proof and static CI gates are not claimed.

`PRODUCTION_RELEASE_READY` is forbidden without deployment, restore and live
Telegram/TON proof.
