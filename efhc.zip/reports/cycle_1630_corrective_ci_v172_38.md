# Цикл 1630 — corrective qualification v172.38

Fresh universal canonical CI `83283286008` проверил exact
`EFHC_Bot_v172_37.zip` размером `12594830` байт. SHA-256 fresh logs:
`a663e3f51e37150389e16305aca643cadc328fe8f8099bc5d28f2536569f1920`.

Прошли PostgreSQL service/preflight, PostgreSQL-only profile, Alembic
`0012`, проверки Flake8, Ruff, Mypy, Bandit, compileall, `npm ci`,
а также production build Next.js и Telegram/TON cross-provider Chromium proof.

Полный pytest завершился результатом `6 failed`, `3165 passed`,
`21 skipped`, `1 warning`. Общий route-backed Chromium создал `103`
evidence files и выявил `51` failures: `17` admin routes в каждом из
трёх viewport. Все ответы имели ожидаемый HTTP `200`, отсутствовали
page/console errors, но `marker_count=0`. Cross-provider failures: `0`.

Pytest findings:

1. Два tests ожидали current release marker v172.37 в frontend budgets.
2. Release compose сохранял image defaults v172.36.
3. Новое имя state содержало запрещённый provider alias fragment.
4. Current evidence v172.37 нарушала русскоязычную authoring policy.
5. Handoff не содержал current release archive marker.

Все pytest findings классифицированы как `SIMPLE_CORRECTIVE_SCOPE`.
Chromium admin marker finding классифицирован как `CRITICAL_BLOCKER`.
Любой red gate запрещает cycle `1631`, поэтому v172.38 остаётся
corrective-only package без migration `0013`.

Исправления v172.38:

- current release markers синхронизированы;
- provider bootstrap state получил нейтральное имя;
- handoff и active evidence приведены к current HEAD;
- route-backed harness передаёт точный admin proof path;
- proof разрешён только при `navigator.webdriver` на localhost либо
  при явном configured proof profile;
- backend authorization, Telegram allowlist и production origin не
  ослаблены;
- универсальный CI, migrations `0001–0012`, financial runtime, Telegram
  HMAC и TON Proof не изменялись.

Alembic head остаётся `0012`; migration `0013` отсутствует. Циклы
`1631` и `1632` не начаты. Следующий gate — fresh exact-head universal
canonical CI v172.38.
