# Change report — v165_66 — cycles 586-590 — frontend stitching wave 13

## Scope
- start actual user-flow stitching after the two new PDF audits;
- reduce hidden-route and split-surface friction between portal, web profile and Telegram entry.

## Done
- strengthened portal/profile cross-navigation;
- added clearer route ownership wording;
- added route ownership and terminology notes.
