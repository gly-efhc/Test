# Change report — v167_30 cycle 941

## Scope
- Cycle 941 — ProfileModal vs Web-Profile final role split

## What was found
- ProfileModal still contained role-confusing account-center/history wording.
- Some quick-overlay rows still behaved like local profile-detail navigation instead of resolving into Web-Profile.
- Docs/runtime semantics needed a stricter explicit split between quick overlay and canonical account center.

## What was changed
- Reinforced role split wording in ProfileModal, Web-Profile, continuity copy and core docs.
- Routed detailed account/history shortcuts from ProfileModal into `/web-profile`.
- Kept shortcut-level actions in ProfileModal without introducing new screens.

## Validation
- compileall backend/app
- compileall frontend/src
