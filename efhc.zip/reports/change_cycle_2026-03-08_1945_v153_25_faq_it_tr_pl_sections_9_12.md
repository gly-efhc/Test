# Change Cycle v153_25 — FAQ IT/TR/PL sections 9–12

Date: 2026-03-08

## Scope
- Continued multilingual migration of the new 12-section user FAQ.
- Added item-level translations for Italian, Turkish and Polish.
- Covered sections 9–12: Top up and purchases, Levels and rank,
  Common situations, FAQ help.

## Facts
- No new GitHub Actions log was provided in this cycle.
- Local checks completed:
  - canon_guard: OK
  - changed-file line72: OK
  - targeted TypeScript compile for FAQ data-layer: OK

## Files
- frontend/src/data/faq/localized.ts
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
