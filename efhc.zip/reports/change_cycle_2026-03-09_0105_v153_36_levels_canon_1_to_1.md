# v153_36 — FAQ levels canon 1:1 from public PDF

Date: 2026-03-09

## What changed

- Updated FAQ section `10.2` in `frontend/src/data/faq/ru.ts`.
- Replaced all 12 progress-level descriptions with the canonical
  wording from `EFHC_FAQ_PUBLIC_RU_v20_profile_settings.pdf`.
- Preserved `line72` by reflowing source lines only; semantic text was
  kept 1:1.

## Scope

- `10.2-1` Eco Initiate
- `10.2-2` Hope Bringer
- `10.2-3` Energy Seeker
- `10.2-4` Nature's Voice
- `10.2-5` Earth Ally
- `10.2-6` Climate Fighter
- `10.2-7` Green Sentinel
- `10.2-8` Planet Defender
- `10.2-9` Eco Champion
- `10.2-10` Planet Saver
- `10.2-11` Green Commander
- `10.2-12` Guardian of Earth

## Verification

- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK
