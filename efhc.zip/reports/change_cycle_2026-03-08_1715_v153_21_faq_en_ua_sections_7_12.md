# Change cycle 2026-03-08 17:15 — v153_21

## Scope
- Continued multilingual content migration for the rebuilt
  user-facing FAQ.
- Added EN/UA item-level overrides for sections 7–12 of the new FAQ
  structure.

## What changed
- `frontend/src/data/faq/localized.ts`
  - Added EN translations for:
    - section 7 `VIP NFT`
    - section 8 `Shop and skins`
    - section 9 `Top up and purchases`
    - section 10 `Levels and rank`
    - section 11 `Common situations`
    - section 12 `FAQ help`
  - Added UA translations for the same sections.

## Local checks
- `python ops/canon_guard.py` → OK
- targeted TypeScript compile of FAQ data-layer → OK
- changed-file `line72` → OK

## Notes
- Full green CI is not claimed without a fresh `logs_*.zip` on the
  new archive.
- Some older uploads in the chat have expired; current work relied on
  the active HEAD ZIP only.
