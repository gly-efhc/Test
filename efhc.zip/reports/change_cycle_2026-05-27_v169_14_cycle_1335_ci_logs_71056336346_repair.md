# Change report — v169_14 — cycle 1335

Cycle: `1335 — CI logs 71056336346 repair: test dependency bootstrap lock`

## Input

- HEAD: `EFHC_Bot_v169_13_cycle_1334_ci_logs_71033084031_repair.zip`
- Log: `logs_71056336346.zip`

## Confirmed failure

`pytest -q` failed during collection because `freezegun` was missing.
All visible non-pytest gates were green in the uploaded log, including frontend
Next.js 16.2.6 build.

## Changed files

- `ci.yml`
- `requirements-test.txt`
- `docs/audits/CI_LOGS_71056336346_REPAIR_V169_14.md`
- `docs/backend/CI_TEST_DEPENDENCY_BOOTSTRAP_LOCK.md`
- `docs/backend/CI_TEST_DEPENDENCY_SANITY_CANON.md`
- `docs/backend/BACKEND_DEPENDENCY_RUNTIME_POLICY.md`
- `docs/cycles/WORK_CYCLES_1321-1350_ADMIN_RECOVERY_EXTENSION_PLAN.md`
- `docs/AI/AI_DOCS_INDEX.md`
- `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/NORM/CHAT_TRANSCRIPT.md`
- `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`
- `tests/architecture/test_ci_logs_71056336346_repair.py`

## Result

CI now uses a single test dependency bootstrap layer and proves all pytest-only
packages before pytest collection.

## Next cycle

`1336 — Shop admin actions and Web3 payment separation on UI Kit`
