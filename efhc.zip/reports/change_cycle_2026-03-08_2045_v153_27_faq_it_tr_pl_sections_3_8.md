# Change cycle v153_27 — FAQ it/tr/pl sections 3–8

Date: 2026-03-08

## Scope
- Continue item-level localization of the new 12-section user FAQ.
- Add Italian, Turkish, and Polish translations for sections 3–8.
- Clean line72 violations in localized FAQ strings.

## Implemented
- Added translations for sections:
  - 3 Panels and energy
  - 4 Exchange and withdrawal
  - 5 Wallet
  - 6 Referrals
  - 7 VIP NFT
  - 8 Shop and skins
- Languages updated:
  - it
  - tr
  - pl
- Fixed 7 line72 violations introduced during editing.

## Verification
- python ops/canon_guard.py -> OK
- changed-file line72 -> OK

## Notes
- Full green CI is not claimed without a fresh logs_*.zip for this archive.
