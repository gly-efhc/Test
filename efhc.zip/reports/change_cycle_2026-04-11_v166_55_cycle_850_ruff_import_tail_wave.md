# EFHC Bot — change report
## 2026-04-11 — v166_55 — cycle 850 ruff import tail wave

### What changed
- cleaned the fresh `ruff` import-order tail across the remaining
  backend/ops/test files surfaced by the latest GitHub CI log.
- reordered and normalized imports in admin routes, scheduler,
  reconciliation/watcher surfaces, ops scripts and test files.
- removed the unused `_RE_INTENT_SUBSTR` import from
  `watcher_service.py` and moved reconciliation/sqlalchemy imports back
  to the top import block.
- converted `ops/shop_payments/run_shop_payments_blitz_once.py` to local
  imports inside `_run()` so that `sys.path` bootstrap no longer causes
  `E402` module-level import violations.

### Verification done locally
- `python -m py_compile` for all changed Python files in this pass.
- archive build without claiming GitHub CI green.

### Honesty boundary
- full GitHub CI was not run locally.
- this pass is based on the exact import-order/error surface reported by
  the fresh CI log.
