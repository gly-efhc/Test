# Change report v168_37

Cycle range: 1226-1228
Focus: independent EFHC shell and Profile route repair

## What changed

1. Profile no longer opens from the active layout as a stacked overlay.
2. `openProfile()` routes to `/web-profile`.
3. `/web-profile` was rebuilt as a normal account page with Back and
   Exit controls.
4. The profile page no longer requires a Telegram access token to
   render.
5. The layout now has an independent EFHC game-shell frame.
6. Bottom navigation is centered to the app width in browser/PWA mode.
7. EN/RU profile copy was updated away from Telegram-shell dependence.
8. TypeScript embedded-locale casting was corrected.
9. A new architecture guard was added for the independent shell and
   profile-route rule.
10. The Dragon first-page RAR was treated as visual reference only;
    full code extraction was not claimed.

## Files changed

- `frontend/src/components/Layout.tsx`
- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/src/lib/i18n.ts`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/en.json`
- `frontend/public/locale/ru.json`
- `tests/architecture/test_independent_shell_guard.py`
- `docs/audits/FRONTEND_INDEPENDENT_SHELL_PROFILE_ROUTE_V168_37.md`
- `reports/generated/frontend_independent_shell_v168_37.json`
- this report

## Checks

- `python3 -m json.tool frontend/public/locale/en.json`: passed.
- `python3 -m json.tool frontend/public/locale/ru.json`: passed.
- `npx tsc --noEmit --pretty false`: passed.
- Targeted architecture tests: 29 passed.
- `npm run build`: compiled successfully, then timed out during
  page-data collection. Full build success is not claimed.

## Release honesty

GitHub CI was not run. Docker runtime proof was not run. Live Cloudflare
proof after this archive was not run. Frontend 99% readiness is not
claimed.
