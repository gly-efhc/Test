# line72 cycle 026

## Goal
Close "tails" after v145_37 lifetime lock:
- Mirror lock: available_kwh must be derived from
  total_generated_kwh - exchanged_kwh_total.
- Audit completeness for EXCHANGE_ALL.
- Static guard against direct debit of available_kwh.

## Changes (<=5 files)
1) docs/ARCHITECTURAL_LOCKS.md
   - Added Generation & Exchange SSOT mirror locks.

2) backend/app/services/transactions_service.py
   - Added _available_from_total_exchanged() helper.
   - EXCHANGE_ALL uses mirror helper for available/new_available.
   - Rejected audit now includes full before/after snapshots and
     invariant_ok.

3) tests/test_exchange_audit_fields_complete.py
   - Ensures EXCHANGE_ALL audit dict includes required before/after
     fields.

4) tests/architecture/test_no_available_kwh_direct_debit.py
   - Repo-wide static test banning available_kwh -= patterns.

## Notes
- No new endpoints, entities, or aliases.
- No banned substrings introduced.
