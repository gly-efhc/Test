# Change cycle — v169.73 / cycle 1391 pytest bootstrap guard

## Goal

Continue cycle 1391 from the current HEAD and avoid hiding collection/domain
failures behind test-suite edits.

## Input

- HEAD: `EFHC_Bot_v169_72_cycle_1390_filename_hygiene_repair.zip`.
- Fresh logs: not supplied in this turn.
- Local collection triage: `PYTHONPATH=backend pytest --collect-only -q`.

## Finding

Full collect-only did not complete in the current sandbox because required
backend/test dependencies are absent:

- `alembic`;
- `freezegun`;
- `psycopg`;
- `sqlalchemy`.

This is a bootstrap dependency blocker for the local run, not a reason to
remove, skip, xfail, archive or weaken any test.

## Repair

- `scripts/ci/check_test_suite_integrity.py` now verifies the bootstrap
  dependency layer before full collect-only.
- If dependencies are missing, the script reports the exact root cause and the
  required install files: `backend/requirements.txt` and
  `requirements-test.txt`.
- `tests/architecture/test_test_suite_integrity_repair.py` now protects this
  behavior.

## Checks

- `python3 -m py_compile scripts/ci/check_test_suite_integrity.py` — passed.
- `python3 -m py_compile tests/architecture/test_test_suite_integrity_repair.py`
  — passed.
- `python3 scripts/ci/check_ai_archive_laws_integrity.py` — passed.
- `python3 scripts/ci/check_test_suite_integrity.py --no-collect` — passed.
- Targeted guard pytest set — `20 passed`.

## Not checked

- Full pytest green: not checked; local sandbox lacks backend/test dependency
  layer.
- GitHub CI green: not claimed.
- Frontend build / npm build: not checked.
- Browser screenshots, live Telegram client and TonConnect proof: not checked.

## Test-control statement

No test was deleted, archived, skipped, xfailed, hidden through pytest.ini or
replaced by a weaker smoke check. No CI workflow was changed.
