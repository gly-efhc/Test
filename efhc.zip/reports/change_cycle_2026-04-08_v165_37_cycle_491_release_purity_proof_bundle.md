# Change report

Release purity proof bundle assembled from current HEAD code and build guards.
