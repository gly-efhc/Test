# Change report v150_38

## Scope

- Admin withdrawals: канонизирован ответ 409 Conflict для конкуренции.

## Changes

1) Добавлено доменное исключение EfhcConflictError.
   - backend/app/services/common_errors.py

2) Admin WithdrawalsService:
   - финальные статусы/обработка другим ключом -> EfhcConflictError.
   - backend/app/services/admin/admin_withdrawals_service.py

3) Admin routes:
   - EfhcConflictError маппится на HTTP 409.
   - backend/app/routes/admin_withdrawals_routes.py
