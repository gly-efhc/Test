# Internal Logbook v152_17

## Purpose

This file consolidates the internal repair trail for the current head
chain so the next session does not lose CI context, canon context, or
critical follow-up notes.

## Chain

- Base control version: v150_68
- Working chain:
  - v152_10
  - v152_11
  - v152_12
  - v152_13
  - v152_14
  - v152_15
  - v152_16
  - v152_17

## Confirmed CI trail

1. logs_59531030045.zip
   - confirmed: ruff=2, pytest=1, mypy=130
   - fixed in v152_11: 51 confirmed issues removed

2. logs_59558267803.zip
   - confirmed: mypy=111
   - fixed in v152_12: mypy local tail reduced to zero

3. logs_59561095770.zip
   - confirmed: mypy=59
   - fixed in v152_13:
     - mypy tail to zero locally
     - WHERE id = :tg_id corrected to WHERE tg_id = :tg_id
     - broken SQL literals with schema text fragments removed
     - # nosec markers removed from SQL text in touched areas

4. logs_59599234560.zip
   - confirmed: bandit=10, pytest=1
   - fixed in v152_14:
     - baseline files restored
     - B608 string SQL removed from confirmed files

5. logs_59600924781.zip
   - confirmed: pytest=1
   - fixed in v152_15:
     - one line72 overflow in reports_service removed

## Follow-up canon notes

### ranks

- v152_16 fixes tg_id vs User.id confusion in ranks_crud.
- Canon is tg_id-only at route/service/external semantics.
- Live ranking now uses tg_id lookup and tg_id tiebreak.

### SQL nosec markers

- v152_17 moves # nosec B608 outside SQL triple-quoted strings in:
  - backend/app/services/admin/admin_withdrawals_service.py
  - backend/app/services/nft_check_service.py
- Reason: '#' inside SQL causes PostgresSyntaxError near '#'.

## Control audit vs v150_68

- Tables preserved: 38
- Routes preserved: 96
- Critical services preserved:
  panels, energy, referrals, lotteries, withdraw, shop, watcher,
  bank/admin bank.

## Internal log files that must stay updated

- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/CI_FIXES_INTERNAL_LOG.md
- reports/REPORTS_INDEX.md
- reports/change_cycle_*.md
- reports/INTERNAL_LOGBOOK_v152_17.md

## Status

Internal logging is now explicitly backfilled and consolidated.
