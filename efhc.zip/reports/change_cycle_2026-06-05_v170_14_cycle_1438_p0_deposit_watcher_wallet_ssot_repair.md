# v170.14 — cycle 1438 P0 Deposit watcher wallet SSOT repair

## Short result

Cycle `1438` closes local runtime finding `F-002`: deposit watcher and admin replay now use canonical `efhc_core.wallet_bindings` for wallet-owner lookup.

Overall release status remains blocked because `F-003` and later linkage findings are still open.

## Changed files

- `backend/app/services/watcher_service.py`
- `tests/architecture/test_deposit_watcher_wallet_ssot_repair.py`
- `docs/cycles/WORK_CYCLES_1438_P0_DEPOSIT_WATCHER_WALLET_SSOT_REPAIR.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/SSOT/EFHC_CANON.md`
- `docs/SSOT/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`
- `docs/SSOT/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `reports/REPORTS_INDEX.md`
- `map_element.md`
- `KERNEL.md`

## Runtime repair facts

- Watcher `_find_user_by_wallet()` reads `efhc_core.wallet_bindings`.
- Lookup uses `wallet_address` as the wallet address column.
- Lookup requires `is_active = TRUE`.
- Lookup requires `proof_verified = TRUE`.
- Admin replay uses the same `process_incoming_tx()` path as scheduler watcher.
- Legacy `efhc_core.user_wallets` is no longer used by `watcher_service.py`.
- No new table was created.
- No migration was added.
- No EFHC economic invariant was changed.

## Bank start balance answer

The start balance `5000000.00000000 EFHC` is seeded in `backend/migrations/versions/0001_initial_release_schema.py` into `efhc_core.bank_balance` with `key='EFHC_MAIN'`. The runtime fallback is `BANK_INITIAL_TOTAL` in `backend/app/services/admin/admin_bank_service.py`. The live bank balance is `efhc_core.bank_balance`.

## Local checks

Executed locally:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py -q
# 7 passed

python -m py_compile backend/app/services/watcher_service.py backend/app/routes/admin_routes.py backend/app/services/wallets_service.py backend/app/services/admin/admin_bank_service.py
# passed
```

Additional local checks:

```text
python -m pytest tests/architecture/test_deposit_watcher_wallet_ssot_repair.py tests/architecture/test_admin_bank_ssot_repair.py tests/architecture/test_archive_filename_hygiene.py tests/architecture/test_operator_kernel_routes.py tests/architecture/test_operator_kernel_config_loading.py -q
# 27 passed
```

## Non-claims

No GitHub CI green, full pytest green, frontend build green, release-ready, browser screenshot, live Telegram proof or real TonConnect proof is claimed.

## Next cycle

`1439 — Admin reports bank table repair`.
