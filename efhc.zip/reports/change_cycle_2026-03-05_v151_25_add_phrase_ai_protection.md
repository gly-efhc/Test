# Change report: v151_25 (2026-03-05)

## Scope
- Update terms glossary: add one sentence to 'ИИ-защита (EFHC Bot)'.

## Files changed
- docs/TERMS_GLOSSARY.md
- reports/REPORTS_INDEX.md
- reports/change_cycle_2026-03-05_v151_25_add_phrase_ai_protection.md

## Notes
- Text content preserved 1:1; line breaks adjusted to line72.
