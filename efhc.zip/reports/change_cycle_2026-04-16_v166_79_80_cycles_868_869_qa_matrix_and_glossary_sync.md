# EFHC Bot change report — v166_79_80

Дата: 2026-04-16

## Активный диапазон
- 851-870

## Что закрыто в этом проходе
- Cycle 868 — release-hardening QA matrix.
- Cycle 869 — glossary / AI-docs sync for 851-868.
- CI repair wave on top of the same HEAD.

## Acceptance matrix

### Withdraw
- Request/create works without false success states.
- Cancel keeps lifecycle truthful and visible.
- Admin completion must keep proof semantics explicit.
- Telegram/user copy must reflect the real completion stage.

### Wallet / deposit
- Wallet sync is visible before money actions.
- Deposit entry does not create a second state machine.
- Storefront/profile reuse the same truth source.
- User sees the honest next step after reload/return.

### Hub / browser-shop
- Signed handoff is visible as a real prerequisite.
- Hub truth shows blockers, next step and active intent.
- Browser-shop can resume the active intent truthfully.
- Guest/auth states do not over-promise completion.

### Helper / draft separation
- Helper/internal pages keep soft truth badges.
- Read-only/draft surfaces are not styled as combat modules.
- Helper cluster stays visible but secondary.
- Admin menu keeps combat domains dominant.

### Money-path truth
- Status chain distinguishes initiated / network_seen /
  manual_review / credited / failed / expired / canceled.
- Terminal vs non-terminal states are explicit.
- User copy explains wait / retry / proof / done correctly.
- Web-Profile and Browser-Shop show the same active truth.

## Operator checklist
- Open admin home and confirm combat domains dominate visually.
- Open diagnostics / ads / sale-packages and confirm soft truth
  badges + info blocks are visible.
- Open Hub and confirm blockers / next step / active intent state.
- Open Browser-Shop after reload and confirm active intent can be
  resumed with the same truth message.
- Open Web-Profile and confirm active payment + intent history +
  order history + withdraw shortcuts are present.
- Open DepositModal and confirm it only launches the canonical flow
  without local polling semantics.
- Check withdraw user path and confirm copy does not claim proof the
  system does not actually have.

## Glossary sync recorded
- helper
- internal
- draft
- read-only
- not release contour
- Web-Profile = canonical account center
- ProfileModal = cockpit
- DepositModal = thin launcher
- backend/storefront truth leads

## Локально подтверждено
- `python -m py_compile ...` on changed backend files — passed.
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false`
  — passed.
- `mypy backend/app` — passed.
- `pytest -q tests/architecture/test_cycle_and_docs_canon.py`
  — passed.

## Что не заявляется
- Green GitHub CI is not claimed until the user runs a fresh GitHub
  CI pass.
- Full closure of 851-870 is not claimed in this pass.
