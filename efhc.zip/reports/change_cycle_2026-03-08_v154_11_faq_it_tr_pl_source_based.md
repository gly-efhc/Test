# Change cycle v154_11 FAQ it/tr/pl source-based

## What was confirmed
- No fresh logs_*.zip for this HEAD.
- Direct audit confirmed zero item-level FAQ overrides for it/tr/pl.
- Other languages already had item-level FAQ overrides: en/ua/de/fr/es.

## Root cause
- localized.ts still had empty blocks for it/tr/pl.
- Because of this, these languages fell back to Russian FAQ text.

## What changed
- Added item-level FAQ overrides for Italian (it), Turkish (tr),
  and Polish (pl) in frontend/src/data/faq/localized.ts.
- Kept Russian source FAQ as the primary base.
- Fixed line72 after inserting the new language blocks.

## Local checks
- test_max_line_length_72.py: passed
- test_no_banned_rank_terms.py: passed
- test_no_legacy_words.py: passed
- test_no_placeholders.py: passed

## Remaining work
- FAQ item-level adaptation still remains for da/hi/id/sw.
- Full green CI is not claimed without fresh logs_*.zip.
