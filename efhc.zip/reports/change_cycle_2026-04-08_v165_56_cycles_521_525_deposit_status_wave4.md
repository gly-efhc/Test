# Change report — v165_56 — cycles 521-525 — deposit status wave 4

## Scope
- close Mini App deposit result/status UX gap;
- keep existing payment-intent truth-layer;
- improve repeat-entry and anti-duplicate behavior in deposit modal.

## Done
- deposit modal now shows live status block for current intent;
- last open deposit intent is restored via session storage;
- duplicate intent creation is blocked while current status is active;
- terminal intent state can be cleared explicitly by the user;
- cycle/control/report docs synced.

## Not claimed
- no GitHub CI proof;
- no full frontend build proof;
- browser-shop remains MVP storefront, not claimed as full release-ready shop.
