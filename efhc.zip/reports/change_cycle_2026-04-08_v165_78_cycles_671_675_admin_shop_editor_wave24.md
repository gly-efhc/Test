# Change report — 2026-04-08 — v165_78 — cycles 671-675 admin shop editor wave 24

## Scope
Shop product-card editor stage through admin panel plus small usability improvements on external shop cards.

## Code changes
- admin shop loads catalog and supports search/filter selection
- editor shell with TON + USDT prices and visibility save
- preview card with neutral image slot
- browser shop dual-price + package pills

## Docs
- ADMIN_SHOP_EDITOR_AUDIT_671_675_2026_04_08.md
- ADMIN_SHOP_EDITOR_WAVE_671_675_2026_04_08.md
- ADMIN_SHOP_EDITOR_REAUDIT_SLICE_671_675_2026_04_08.md

## Validation
- locale JSON parsed successfully
- archive rebuilt
- no GitHub CI run
