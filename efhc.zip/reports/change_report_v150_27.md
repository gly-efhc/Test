# Change report v150_27

Источник истины цикла: logs_59127346361.zip.

## Что упало

- pytest -q: массовые падения из-за SyntaxError при импорте
  backend/app/services/transactions_service.py

## Где

- backend/app/services/transactions_service.py

## Root cause

В f-string SQL-шаблонах присутствовали литералы "{}".
Внутри f-string это трактуется как пустое выражение и приводит к:
"SyntaxError: f-string: empty expression not allowed".

## Исправление

- Экранированы JSON-литералы в f-string как "{{}}".
- Логика UPDATE meta согласована с meta как TEXT (JSON-строка):
  merge выполняется через CAST(meta AS jsonb) и обратно ::text.

## Файлы

- backend/app/services/transactions_service.py
- reports/alias_sanitation_report_v150_27.md
- reports/change_report_v150_27.md

