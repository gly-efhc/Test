# Change report v150_51

- Squashed Alembic migrations into single 0001_init.py.
- Removed 0002_bank_balance_system_object.py and
  0003_bank_balance_seed_main_only.py.
- Added BANK_EFHC bank_balance seeding
  (EFHC_MAIN=5000000.00000000) into 0001.
