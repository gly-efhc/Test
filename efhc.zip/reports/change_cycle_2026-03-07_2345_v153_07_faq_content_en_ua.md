# v153_07 FAQ content corrections + EN/UA item translations

## What changed

- Fixed two malformed RU FAQ splits in `frontend/src/data/faq/ru.ts`:
  - `7.2-4` / `7.2-5`
  - `14.1-2` / `14.1-3`
- Added item-level FAQ localization layer in
  `frontend/src/data/faq/localized.ts`.
- Added EN and UA translations for critical FAQ content blocks:
  - Profile / Settings
  - Wallet
  - Balances and internal logic
  - Exchange and Withdraw
- Updated `getFaqCatalog(lang)` to apply per-item overrides.

## Why

The FAQ shell and multilang navigation already existed, but some RU
content entries were malformed after import from the PDF structure, and
non-RU users still saw RU question/answer bodies.

## Validation

- `python ops/canon_guard.py`
- `tsc --noEmit --target es2020 --module esnext`
- `--lib es2020,dom src/data/faq/types.ts src/data/faq/meta.ts`
- `src/data/faq/localized.ts src/data/faq/index.ts src/lib/i18n.ts`
