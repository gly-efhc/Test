# Change report — v170.65 / cycle 1489

`/admin/system` now has a read-only health dashboard. Log repair fixed stale guards, lockfile registry hygiene, Energy balance-chip marker, locale parity, wave-3 i18n tails, UK Russian tails and degraded `_main_` token.
