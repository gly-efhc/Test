# Cycle 036 — Panels SSOT backend tests (cycle 6/10)

## Scope
- Add minimal backend SSOT tests for Panels.

## Changes
- Added a static test suite that asserts canonical invariants in
  panels_service and panels_routes:
  - public_id inserted as NULL then updated;
  - public_id format ID########;
  - replay path marked and does not create new panel rows;
  - audit schema key present;
  - list filters use :server_now_utc param;
  - routes return server_now_utc from utcnow().

## Commands
- python -m compileall backend -q
- pytest -q
