# EFHC Bot — change report
## 2026-04-11 — v166_54 — cycle 850 tasks next_available_at typing fix

### What changed
- fixed the fresh frontend typing tail in `frontend/src/pages/tasks.tsx`.
- `MyTaskItem` now declares optional `next_available_at?: string | null`,
  which matches the page's optional access pattern and removes the new
  TypeScript blocker without changing runtime behavior.

### Verification done locally
- changed-file review for `frontend/src/pages/tasks.tsx`.
- archive build without claiming GitHub CI green.

### Honesty boundary
- full GitHub CI was not run locally.
