# Change Report · v165_96 · cycles 749-752

## Scope
- second page-by-page audit package
- target pages: hub, browser-shop, web-profile
- close real route/data mismatches without new product questions

## Real fixes
- hub page now points to `/browser-shop` instead of the stale `/shop` path
- web-profile order payload now uses the real `updated_at` field
- recorded the second page-audit report for this connected page package

## Narrow local checks
- `py_compile` for `backend/app/routes/shopfront_routes.py`
- TypeScript transpile/syntax check for `frontend/src/features/hub/HubPage.tsx`

## Archive
- EFHC_Bot_v165_96_cycles_749_752_page_audit_hub_browser_shop_profile_wave.zip
