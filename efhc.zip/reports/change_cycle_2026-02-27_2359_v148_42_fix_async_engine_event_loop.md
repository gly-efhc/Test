# v148_42 — Fix async test engine loop binding

## Context (SSOT)
- CI logs: logs_58824951756.zip (2026-02-27 UTC)
- Symptom: pytest failures in concurrency tests:
  - RuntimeError: got Future attached to a different loop
  - asyncpg InterfaceError: another operation is in progress

## Root cause
AsyncEngine was created by a sync session-scoped fixture (`def async_engine`),
so the first real connection/pool initialization could occur in a different
event loop than the one used by pytest-asyncio during test execution.

## Fix (cause-level, not workaround)
- `tests/conftest.py`
  - `event_loop` now sets the created loop as current via
    `asyncio.set_event_loop(loop)`.
  - `async_engine` is now an async session-scoped fixture that depends on
    `event_loop`.
  - Engine uses `NullPool` in tests to avoid reusing busy connections.
  - Engine is warmed up with `SELECT 1` inside the session loop.
  - Engine is disposed at session end.

## Verification
- Local static: `python -m compileall tests -q` should pass.
- CI required: rerun GitHub Actions and attach new logs for SSOT confirmation.
