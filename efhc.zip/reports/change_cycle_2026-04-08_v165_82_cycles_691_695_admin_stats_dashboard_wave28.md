# Change report — v165_82 — cycles 691-695 — admin stats dashboard wave 28

## What changed
- Upgraded `AdminCharts` visual grammar.
- Added Russian counter labels to reports page.
- Added economy/user chart groups to `/admin/reports`.
- Expanded quick-facts table.

## Files
- frontend/src/components/AdminCharts.tsx
- frontend/src/pages/admin/reports.tsx
- docs/audits/ADMIN_STATS_DASHBOARD_WAVE_691_695_2026_04_08.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_601-700.md
- reports/REPORTS_INDEX.md
