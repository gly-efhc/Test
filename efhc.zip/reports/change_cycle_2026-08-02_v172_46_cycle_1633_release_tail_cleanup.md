# v172.46 — цикл 1633: release tail cleanup

Fresh CI `83344929071` подтвердил основной runtime. Единственный failure
был документным: исторический аудит не содержал явную цифру `44`.

Исправлено:

- аудит functional parity;
- active SSOT и contracts после migration squash;
- public identity API больше не экспортирует pre-release harnesses;
- production release исключает legacy backfill/expand modules;
- audit scripts переведены на единую migration `0001`;
- функциональная сверка выполнена напрямую с exact `v171.89`.

Потерь функций не найдено. Production release остаётся заблокирован до
exact-head CI, deployment, rollback/restore и live smoke.
