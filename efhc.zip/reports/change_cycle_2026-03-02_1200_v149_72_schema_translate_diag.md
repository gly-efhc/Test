# Cycle v149_72

## Goal
Fix schema-drift after Alembic and add DB diagnostics.

## Changes
- backend/migrations/env.py
  - Add schema_translate_map: None -> efhc_core.
  - Keep search_path: efhc_core, efhc_admin.
  - Keep include_schemas=True and version_table_schema=efhc_core.
  - Keep Postgres-only URL selection.
- ops/ci_verify_db_objects.py
  - Print DB diagnostics: current_database/current_schema/search_path.
  - If expected table missing, also check public.<table>.

## Notes
No YAML changes.
