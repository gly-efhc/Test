# v153_02 — Release ZIP cache cleanup

Date: 2026-03-07

## What was found

The previous release ZIP v153_01 contained cache/machine-generated
artifacts that are forbidden in EFHC release archives:

- `__pycache__/`
- `*.pyc`

## What was changed

No application code was changed in this cycle.

The release archive was rebuilt as a clean FLAT ZIP after removing:

- all `__pycache__/` directories
- all `*.pyc` files
- cache directories covered by release canon
- temporary `ci_*.txt` files if present

## Result

v153_02 is a cache-clean release packaging fix.
