# Change report v150_48

Цель: канонизация центрального банка BANK_EFHC и переход на
системный объект efhc_core.bank_balance (EFHC_MAIN) с алиасами.

## Изменено

- docs/EFHC_CANON.md
  - BANK_TG_ID помечен как историческое имя, теперь BANK_EFHC.
  - Банк хранит только EFHC_MAIN, старт 5000000.00000000.

- backend/app/scheduler/bankstate_recalc.py
  - bank_state пересчитывается от истины bank_balance (main).

- backend/app/services/admin/admin_bank_service.py
  - Админ-операции mint/burn и чтение баланса переведены на
    efhc_core.bank_balance (EFHC_MAIN).
  - Убрана проверка «банк не может уйти в минус» для burn.

## Примечания

- Алиасы (BANK_EFHC как tg_id для зеркальных логов) сохранены.
- Объединение миграций в 0001 выполняется после стабилизации.
