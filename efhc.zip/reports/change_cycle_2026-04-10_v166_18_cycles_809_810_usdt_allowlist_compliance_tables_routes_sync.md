# Change report — v166_18 — cycles 809-810 — 2026-04-10

## What changed
- added `backend/app/services/jetton_parsing_service.py`
- watcher now delegates payment-intent transport parsing to the dedicated helper/service line
- synchronized SSOT tables docs with `tx_hash_locks`
- synchronized SSOT route docs so `/admin/ton/reconcile` and `/shop/order-external` explicitly reflect the new lock contour
- added compliance audit guard for the full 801-810 payment block including AdminTonReconcile
- recorded future continuation block 811-820

## Narrow checks
- `python ops/routes/audit_shop_payments_compliance.py`
- `python -m py_compile backend/app/services/jetton_parsing_service.py backend/app/services/payment_reconciliation_service.py backend/app/services/watcher_service.py ops/routes/audit_shop_payments_compliance.py`

## Honest limits
- local pytest import through the backend stack is still limited here by missing `sqlalchemy`; not presented as CI
