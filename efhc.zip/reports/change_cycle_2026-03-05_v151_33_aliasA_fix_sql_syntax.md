# Change report: v151_33

Date: 2026-03-05

Scope:
- Alias-layer stabilisation for Variant A migration.
- Fix CI blockers from logs_59412285708 (SyntaxError + Ruff).

What was fixed

1) backend/app/services/wallet_binding_service.py
- Removed broken escaped triple-quote patterns (\"\"\").
- Rewrote all SQL calls to deterministic templates + _core_sql().
- No f-string SQL in this module.

2) Ruff cleanup
- Auto-fixed safe categories (I001, F401) and remaining issues.
- Fixed SIM102 in lotteries_crud.
- Fixed broken placeholders in SQL templates in admin services.

3) SQL placeholder correctness
- Fixed "WHERE {where}" and "ORDER BY {order}" templates that were
  not being formatted, by switching to .replace()-based templates.

Notes
- No business logic changes were intended; changes are formatting/
  determinism fixes plus SQL string construction safety.
- Aliases remain in place as a transition layer.
