# Change cycle — 2026-03-07 14:15 — v152_29

## Source of truth
- HEAD ZIP: `EFHC_Bot_v152_28_runtime_load_logged.zip`
- Fresh CI log: `logs_59684341738.zip`
- Prior runtime load/startup logs already recorded in cycles v152_27 and
  v152_28

## What failed
- `pytest` only; all other canon gates passed.
- Exact failures: 3.
- Startup defects from prior runtime logs remained confirmed in code:
  `panels_routes` and `lotteries_routes`.

## Root cause
1. `backend/app/integrations/telegram_bot_api.py`
   introduced banned identifier `user_id`, violating tg_id canon and
   tripping:
   - `test_great_canon_guard`
   - `test_no_banned_identifiers_in_code_names`
   - `test_no_banned_identifiers_in_source_text_including_comments`
2. `backend/app/routes/panels_routes.py`
   still used `Response | None` in route signatures, matching prior
   startup smoke failure.
3. `backend/app/routes/lotteries_routes.py`
   imported missing `LatestWinnersOut`; schema file had only partial
   `LatestWinnerOut` and no aggregate response model.

## What changed
- Replaced keyword call using banned name in Telegram adapter with
  positional `get_chat_member(chat, tg_id)`.
- Canonicalized `panels_routes` response injection to `response:
  Response`.
- Completed lotteries winner schemas:
  - `LatestWinnerOut`
  - `LatestWinnersOut`
- Kept route/service contract aligned with existing
  `svc_get_latest_winners()` payload.

## Verification performed locally
- `ruff check backend api ops tests` → pass
- `mypy backend/app` → pass
- `python -m compileall backend/app` → pass
- `pytest -q tests/test_no_banned_identifiers.py \
  tests/architecture/test_great_canon_guard.py` → pass
- `python` import smoke for:
  - `app.routes.panels_routes`
  - `app.routes.lotteries_routes`
  → pass

## Limits
No claim of full green GitHub CI until a new `logs_*.zip` is produced on
this archive.
