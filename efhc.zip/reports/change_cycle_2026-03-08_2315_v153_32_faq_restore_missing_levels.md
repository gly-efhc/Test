# Change cycle v153_32 — FAQ restore missing content and levels

Date: 2026-03-08

## What changed

- Restored missing user-facing FAQ questions in `frontend/src/data/faq/ru.ts`.
- Added wallet practical questions:
  - why primary wallet is needed
  - can primary wallet be changed
  - can a linked wallet be removed
  - what happens when a flow requires Wallet
- Added panel lifecycle questions:
  - panel price
  - what the first panel gives immediately
  - when generation starts
  - panel lifetime
  - active panel limit
- Expanded `Levels and rank` with full 12-level descriptions.
- Expanded FAQ help/navigation with usage and related-question logic.

## Coverage note

- PDF baseline questions found: 115
- Current RU FAQ items after this cycle: 96
- The new FAQ remains on the new 12-section user structure.
- Multilingual sync for newly added RU-only items is still pending.

## Validation

- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK
