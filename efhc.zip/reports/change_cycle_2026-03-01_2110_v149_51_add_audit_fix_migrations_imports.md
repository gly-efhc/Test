# Change report — v149_51 (audit + migration import stability)

## What changed
- Added RU-only audit: docs/audits/2026-03-01_audit_migrations_timestampmixin_ru.md
- Ensured TimestampMixin is available in app.models (backend/app/models/__init__.py) to prevent ImportError during 0001 model imports.
- Removed forbidden schema= from Index(...) in backend/app/models/tasks_models.py (CI Alembic TypeError).
- Updated docs/SSOT_INDEX.md with link to the new audit.
- Updated EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md with new CI log classes (no duplicates).

## Notes
- Canon: audits RU-only; migration stability depends on import safety of every *_models.py module.
