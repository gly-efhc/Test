# EFHC Bot — change report
## 2026-04-11 — v166_64 — cycle 856 money-center web-profile wave

### What changed
- started the money-center UX direction in the external profile surface.
- rewired the web-profile quick actions into an explicit 3-step
  money-center block: wallet sync → browser shop top-up → Telegram
  return for history/withdraw.
- replaced the generic quick-sections wording with a clearer financial
  journey explanation.

### Honesty boundary
- this is the first money-center UX pass, not the full unification of
  all profile/wallet/deposit/withdraw screens.
