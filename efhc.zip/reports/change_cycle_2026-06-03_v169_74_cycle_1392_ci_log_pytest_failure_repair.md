# v169.74 / cycle 1392 — CI log pytest failure repair

## Input

- HEAD: `EFHC_Bot_v169_73_cycle_1391_pytest_collection_bootstrap_guard.zip`
- Logs: `logs_72176795654.zip`

## Log facts

The gate summary showed all listed CI gate steps green except pytest. Pytest
reported `8 failed`, `1105 passed`, `8 skipped`.

## Repairs

1. Restored the exact `IDEMPOTENCY_CONFLICT` marker protected by the economic
   guard.
2. Repaired `_enqueue_resync_energy` SQL formatting so the guard parses SQL
   without swallowing `await db.commit()`.
3. Removed forbidden removed-domain literal self-hits from the active i18n
   forbidden-contour guard.
4. Replaced bot-text parity import with a file loader that does not import
   Telegram runtime dependencies.
5. Repaired a stale whitespace-specific route-prefix test into a semantic
   `register_routes(..., prefix=settings.API_PREFIX)` guard.
6. Restored the TonConnect generated-report path as a contiguous resolver
   source anchor through a line-length-safe constant.
7. Repaired the Ukrainian exact-allowlist guard call anchor without violating
   line-length 72.
8. Restored the USDT disabled-reason catalog marker through a shared constant.

## Test-control statement

No active test was deleted, archived, skipped, xfailed or hidden. No pytest
configuration was weakened. No consolidation was performed.

## Verification

- `63 passed` for the targeted architecture/policy set.
- `python3 -m compileall backend/app ops tests/architecture -q` passed.
- `python3 scripts/ci/check_ai_archive_laws_integrity.py` passed.
- `python3 scripts/ci/check_test_suite_integrity.py --no-collect` passed.
- `python3 ops/i18n/audit_bot_texts_parity.py` passed.
- `python3 ops/i18n/audit_uk_locale_value_quality.py` passed.
- `python3 ops/i18n/audit_forbidden_gaming_contour.py` passed with
  `forbidden_findings: 0`.

## Non-claims

No GitHub CI green, full pytest green, release-ready, npm build, browser
screenshot, live Telegram or real TonConnect/wallet proof is claimed in this
local pass.
