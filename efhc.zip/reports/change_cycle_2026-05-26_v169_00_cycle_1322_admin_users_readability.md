# Change report — v169_00 cycle 1322

Cycle: 1322 — Users table readability and safe operator actions.

HEAD: `EFHC_Bot_v168_99_cycle_1321_admin_users_audit.zip`.

## Code changes

- Reworked `frontend/src/pages/admin/users.tsx` from a route-diagnostic
  style page into a readable operator users screen.
- Removed `AdminRouteHealthStrip` from Admin Users.
- Added a scrollable users table with columns: user, statuses, balances,
  wallet and action.
- Split view-only safe actions from sensitive operator actions.
- Added operator confirmation before balance correction.
- Fixed balance correction direction values to backend contract values:
  `credit` and `debit`.

## Guard

- Added `tests/architecture/test_admin_users_variant_a.py`.

## Notes

No route deletion and no new user-facing business function were introduced.
