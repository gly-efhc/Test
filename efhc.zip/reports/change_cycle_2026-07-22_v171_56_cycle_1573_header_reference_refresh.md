# v171.56 / cycle 1573 — compact header reference refresh

## What was done

1. Refined the top GlobalHeader balance block to better match the supplied reference:
   - the balance pill is longer;
   - the balance remains fully visible and copyable;
   - Activ/VIP stay text-only, smaller and aligned to one gold active treatment.
2. Tightened the mobile Profile route again:
   - compact single-row topbar;
   - denser hero card;
   - preserved sticky tabs;
   - preserved safe-area bottom protection.
3. Re-verified the French FAQ mirrors:
   - section 2, question 2.3 uses `Que dois-je regarder en premier ?`;
   - question 2.7 remains unchanged.
4. Generated seven fresh browser-captured visual proofs for the changed surfaces.

## Checks actually run

- `pytest -q tests/architecture/test_cycle_1573_profile_header_faq_guard.py tests/architecture/test_global_header_balanced_actions_current_release.py tests/architecture/test_global_header_vip_status_guard.py tests/healer/test_critical_delivery_protocol.py`
- Result: `12 passed`.
- Browser proof generator: `python ops/frontend/profile_header_component_proof_v171_56.py`.

## Visual proof boundary

The new PNG files are fresh Chromium browser captures of isolated header/profile surfaces aligned to the current UI contract.
They are not a live Next.js route, not a Telegram-client proof, and not a TonConnect/TonProof or transaction proof.

## Cycle status

- Cycle 1572: complete by the user's green GitHub logs.
- Cycle 1573: active and not complete.
- Cycle 1574: not started.

## Next real step

Continue cycle 1573 only with factual live Telegram, real TonConnect/TonProof and real transaction evidence, or with the next user-supplied logs.
