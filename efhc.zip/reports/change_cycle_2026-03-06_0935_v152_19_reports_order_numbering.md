# Change report v152_19

## Что сделано

- Обновлено правило ведения `reports/`: все записи теперь
  фиксируются строго по порядку.
- Возвращена нумерация в `reports/REPORTS_INDEX.md`.
- Индекс переведён в формат нумерованного `append-only`
  реестра.
- Канонические правила синхронизированы в
  `docs/EFHC_CANON.md`, `docs/SSOT_INDEX.md` и
  `docs/ARCHITECTURAL_LOCKS.md`.

## Изменённые файлы

- `reports/REPORTS_INDEX.md`
- `reports/change_cycle_2026-03-06_0935_
  v152_19_reports_order_numbering.md`
- `docs/EFHC_CANON.md`
- `docs/SSOT_INDEX.md`
- `docs/ARCHITECTURAL_LOCKS.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`

## Проверка

- Проверен факт наличия нумерации в `reports/REPORTS_INDEX.md`.
- Проверено, что правило про порядок и `append-only`
  зафиксировано в SSOT-документах.
