# CHANGE REPORT v168_14 CYCLES 1189-1190

## Scope

This pass continues the road-audit repair range after cycle 1188.  The
work fixes two economic-road findings:

- cycle 1189: exchange route and contract drift;
- cycle 1190: panel activation route and audit-trail drift.

## Cycle 1189

Exchange was moved from path-tg-id routes to self routes:

- `GET /exchange/preview`;
- `POST /exchange/convert`;
- `GET /exchange/history`.

The old user exchange preview alias was removed from active backend
code.  Frontend generated seams and the Exchange page now use the self
routes.
OpenAPI and route SSOT packs were updated to match the active paths.

## Cycle 1190

Panel activation was moved to the self route:

- `POST /panels/activate`.

The old active buy/path-tg-id alias was removed.  The frontend Panels
page now calls the canonical self route.  The panel activation audit
meta now includes qty, price, total amount, spent bonus, spent main and
`bonus_first` proof fields.

## Evidence

Generated evidence:

- `reports/generated/exchange_road_1189.json`;
- `reports/generated/panel_activation_1190.json`.

Guards:

- `ops/routes/check_exchange_road.py`;
- `ops/routes/check_panel_activation.py`.

Tests:

- `tests/architecture/test_exchange_road_guard.py`;
- `tests/architecture/test_panel_activation_guard.py`.

## Boundary

This report does not claim global release readiness.  It closes only the
specific exchange and panel activation findings repaired in cycles 1189
and 1190.  Full GitHub CI remains the user's responsibility.
