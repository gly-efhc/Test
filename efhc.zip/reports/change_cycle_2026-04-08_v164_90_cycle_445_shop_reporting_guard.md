# change_cycle_2026-04-08_v164_90_cycle_445_shop_reporting_guard

- Added `test_wave20_admin_reporting_order_reader_uses_shop_orders_ssot` in `tests/architecture/test_economic_audit_guards.py`.
- The guard locks `admin_list_orders` to canonical `shop_orders` fields plus `extra` for `sku` and `payment_method`, and forbids relapsing into legacy `item_id` / `shop_items` joins.
- This closes the planned reporting-proof slice after the earlier `admin_list_orders` cleanup wave.
