# v152_25 — withdraw admin canon sync

Основание: ручной аудит текущего v152_24.

Исправлено:
- route/service mismatch: admin reject now matches service
  signature
- admin withdraw joins use users.tg_id, not users.id
- WithdrawRequest ORM now includes external_address and
  processing_idempotency_key
- added architecture guard test for this contract
