# change_cycle_2026-04-08_v164_91_cycle_446_nested_zip_fix

- Found the real reason for the oversized archive: the staging snapshot included the previously built `efhc.zip`, so the next release ZIP packed a ZIP inside itself.
- Fixed `ops/build_efhc_zip.sh`: it now removes stale `${ZIP_OUT}` before staging and excludes `${ZIP_OUT}` explicitly from `rsync`.
- Added guard expectations in `tests/test_release_cleanup_guards.py`.
- Recorded the relapse in Healer so the same packaging mistake is not normalized again.
