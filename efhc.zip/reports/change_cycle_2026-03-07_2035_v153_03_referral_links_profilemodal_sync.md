# v153_03 — referral_links / ProfileModal sync by fresh CI log

Дата: 2026-03-07
Источник факта: logs_59700209433.zip

## Что упало
1. `tests/architecture/test_referral_level_bonus_runtime.py::test_referral_level_bonus_auto_to_bonus_from_bank`
2. `tests/test_build_sanity.py::test_canon_guard_passes`

## Root cause

### 1) referral_links runtime
В `backend/app/services/referral_service.py` часть SQL использовала
неканоничные и несуществующие колонки `referred_tg_id` и
`inviter_tg`, тогда как ORM и таблица `efhc_core.referral_links`
используют `invitee_tg_id` и `inviter_tg_id`.

Это ломало:
- поиск реферальной связи при первой покупке панели
- вставку новой связи
- SQL для списков/счётчиков активных рефералов

### 2) canon guard
В `frontend/src/components/ProfileModal.tsx` был user-facing label
с запрещённым термином `lottery_prize` / «Приз лотереи», что падало
на `TERMINOLOGY_BAN_CONTENT`.

## Что изменено
- В `backend/app/services/referral_service.py` синхронизированы SQL
  по `invitee_tg_id` / `inviter_tg_id`.
- В `frontend/src/components/ProfileModal.tsx` удалён прямой banned
  token `lottery_prize` из словаря labels; legacy reason теперь
  нормализуется без запрещённого литерала в исходнике и выводится как
  `Приз Lotteries`.

## Локальная проверка
- `python ops/canon_guard.py` → OK
- `python -m py_compile backend/app/services/referral_service.py` → OK

## Ограничение
Полный зелёный CI не заявляется без нового `logs_*.zip` на новый архив.
