# change cycle 2026-05-29 v169_17 cycle 1338 ci logs 71459043999 repair

## 1. HEAD

Input HEAD:
`EFHC_Bot_v169_16_cycle_1337_ci_logs_71060357686_repair.zip`

Output archive:
`EFHC_Bot_v169_17_cycle_1338_ci_logs_71459043999_repair.zip`

## 2. Goal

Repair confirmed failures from `logs_71459043999.zip` and keep CI files
under manual-control rules.

## 3. Confirmed failures

Final gate summary showed:

- pytest failed;
- ruff failed.

Frontend `npm ci` and `npm build` were green in the uploaded log.
Backend compile, flake8, mypy, bandit, psql and Alembic were green.

## 4. Root causes

- stale Docker/package guard still expected the pre-migration baseline;
- ruff found import-order and import-source issues;
- generated `frontend/tsconfig.tsbuildinfo` was present in the archive;
- generated Operator Kernel cache included archived original-source names;
- backend dependency doc used a word containing a banned legacy token.

## 5. Code and test repairs

- fixed ruff issues in Operator Kernel and core economics test;
- updated the stale cycle 1262 guard to the active frontend standard;
- removed `frontend/tsconfig.tsbuildinfo`;
- updated Operator Kernel file map skip list;
- updated Operator Kernel archive hygiene to reject `.tsbuildinfo`.

## 6. Documents updated

- added CI audit for `logs_71459043999.zip`;
- added cycle 1338 repair canon;
- updated cycle plan, AI index, synaptic links, Q/A, transcript,
  Master Document Index, reports index, Healer and error registry.

## 7. CI boundary

`ci.yml` was not edited. CI/workflow files remain manual-control files.

## 8. Local checks

Local auxiliary checks only:

- compileall backend: passed;
- compileall Operator Kernel: passed;
- ruff backend/api/ops/tests: passed;
- targeted pytest for failed areas: passed;
- Operator Kernel guards: passed;
- canon guard: passed;
- ZIP integrity: passed.

## 9. Not checked

Full GitHub CI is not claimed. It must be run by the user.

## 10. Next cycle

Next planned cycle shifts to:
`1339 — Shop admin actions and Web3 payment separation on UI Kit`.
