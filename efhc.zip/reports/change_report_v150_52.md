# Change report v150_52

- Канон: внешние пополнения/покупка EFHC зачисляются только в user MAIN.
- Канон: вывод возможен только из user MAIN; bonus не выводится.
- Канон: BANK_EFHC хранит только EFHC_MAIN (bonus банка отсутствует).
- Документация: пометки BANK_TG_ID как исторического имени во всех docs.
- Код: удалена ORM-модель efhc_admin.bank_balances (BankBalanceRow).
- Admin route: GET /bank/balance читает efhc_core.bank_balance.
