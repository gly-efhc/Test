# change report — v166_30 — cycles 833-834

## Done
- Added universal 2-decimal UI helper `formatD8ToHuman()`.
- Applied 2-decimal rendering to key user-facing financial screens and admin payout/balance cards.
- Isolated legacy `orders_service.py` write paths with explicit runtime guards.
- Added reproducible audit script for legacy read-only isolation.
- Recorded chat-audit backlog block 846-850 without executing it early.

## Files
- frontend/src/lib/format.ts
- frontend/src/pages/withdraw.tsx
- frontend/src/pages/exchange.tsx
- frontend/src/pages/index.tsx
- frontend/src/pages/referrals.tsx
- frontend/src/pages/tasks.tsx
- frontend/src/pages/admin/bank.tsx
- frontend/src/pages/admin/users.tsx
- frontend/src/pages/admin/withdrawals.tsx
- backend/app/services/orders_service.py
- ops/routes/audit_legacy_shop_read_only.py
- docs/audits/UX_ROUNDING_AND_LEGACY_ISOLATION_833_834_2026_04_10.md
- docs/audits/CHAT_AUDIT_PLAN_846_850_2026_04_10.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_801-900.md
- reports/REPORTS_INDEX.md
