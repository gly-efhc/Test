# Change report — v166_22 — cycles 817-818 — 2026-04-10

## What changed
- added `backend/app/services/confirm__path__guards_service.py`
- payment reconciliation now uses shared exact-guard checks
- added focused nanoton/commercial-policy fraud tests

## Checks
- `PYTHONPATH=backend pytest -q tests/architecture/test_confirm__path__guards_service.py -q`
- `python -m py_compile backend/app/services/confirm__path__guards_service.py backend/app/services/payment_reconciliation_service.py`
