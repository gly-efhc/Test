# EFHC Bot v166_69_70 — cycles 858/860 shop-hub truth-layer wave

## What changed
- Added `GET /hub/shop-truth` as a dedicated truth-layer endpoint for the Hub → browser-shop contour.
- Added backend truth helpers that expose whether external handoff is configured, whether wallet sync is still required and whether the user already has an active non-terminal intent.
- Extended browser-shop bootstrap/profile contracts with `flow_truth` so the storefront can resume the last active intent instead of inviting duplicate creation.
- Updated Hub page to preload truthful readiness state instead of behaving like a blind launcher.
- Updated BrowserShop page to surface blockers, next step and active-intent resume semantics.
- Synced SSOT route registries and refreshed the OpenAPI snapshot from the route registry.

## Validation
- `python -m py_compile backend/app/routes/hub_routes.py backend/app/routes/shopfront_routes.py backend/app/schemas/hub_schemas.py` passed.
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` passed.
- No fresh GitHub CI log was provided, so green CI is not claimed.
