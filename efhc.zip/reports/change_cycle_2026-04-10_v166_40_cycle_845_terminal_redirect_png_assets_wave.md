# Change report — v166_40 — cycle 845

Дата: 2026-04-10

## Что сделано
- Terminal redirect 1.5s for withdraw terminal actions.
- Local EFHC logo PNG assets prepared under `public/images/`.
- Ads redirect kept explicit `/tasks` compatibility path.
- Fresh CI defects closed where safe in this pass.
