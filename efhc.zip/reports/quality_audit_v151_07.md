# Quality audit v151_07

Ruff total issues (all rules): 3763

Top codes (from ruff --statistics):

- 1186	UP007 	[ ] non-pep604-annotation
- 726	UP006 	[*] non-pep585-annotation
- 577	F822  	[ ] undefined-export
- 251	UP009 	[*] utf8-encoding-declaration
- 223	UP035 	[ ] deprecated-import
- 215	I001  	[*] unsorted-imports
- 132	B008  	[ ] function-call-in-default-argument
- 126	F401  	[ ] unused-import
- 82	UP017 	[*] datetime-timezone-utc
- 53	B904  	[ ] raise-without-from-inside-except
- 48	E402  	[ ] module-import-not-at-top-of-file
- 19	UP037 	[*] quoted-annotation
- 16	F841  	[*] unused-variable
- 15	UP034 	[*] extraneous-parentheses
- 11	B009  	[*] get-attr-with-constant
- 10	SIM102	[ ] collapsible-if
- 10	F811  	[ ] redefined-while-unused
- 9	UP038 	[*] non-pep604-isinstance
- 6	SIM105	[ ] suppressible-exception
- 5	B010  	[*] set-attr-with-constant
