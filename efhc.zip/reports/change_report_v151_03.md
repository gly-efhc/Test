# Change report v151_03

## CI additions

- Added non-blocking tooling reports:
  - Ruff full report -> ci_artifacts/04c_ruff_full.txt
  - MyPy full report -> ci_artifacts/04d_mypy_full.txt
  - Bandit full report -> ci_artifacts/04e_bandit_full.txt
- Added report-only endpoint discovery based on SSOT pack:
  - Script: ops/ci_checks/endpoint_discovery_report.py
  - Output: ci_artifacts/04f_endpoint_discovery.txt

## Tests

- Added hard gate admin routes guard:
  - tests/architecture/test_admin_routes_guarded.py
  - Rule: any file defining /admin routes must reference require_admin
  - Excludes routes/__init__.py

## Notes

- Endpoint discovery is report-only to avoid blocking while SSOT route-table
  map is being completed.
