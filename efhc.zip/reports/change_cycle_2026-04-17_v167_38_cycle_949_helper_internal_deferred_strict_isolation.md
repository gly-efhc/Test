# Change report — v167_38 — cycle 949 helper/internal/deferred strict isolation

## Summary
Cycle 949 executed as a strict isolation pass. The goal was not to build new functionality, but to separate release-core admin evidence from helper/internal/deferred surfaces after the EFHC deposits production-hardening and action-chain audit.

## What was found
- `/admin/efhc-deposits` still appeared inside the helper cluster in the admin shell, which created false maturity noise around the helper/internal/deferred contour.
- Diagnostics still listed EFHC deposits inside support/helper sections even though the module had already become automation-first and release-core eligible.

## What changed
- Reclassified `/admin/efhc-deposits` in the admin shell from `helper/non_core` to `live/core`.
- Moved EFHC deposits into the finance module cluster.
- Narrowed the helper cluster to Diagnostics, Ads and Sale packages.
- Added a dedicated `Release-core finance actions` block on the diagnostics page.
- Kept `Support and helper sections` limited to Diagnostics, Ads and Sale packages.
- Added an architecture guard to keep the admin shell isolation stable.
- Synced AI/cycles/reports/Q&A to the new status.

## Release-truth effect
The admin shell now reflects the real contour boundary: EFHC deposits is no longer visually grouped with helper/internal/deferred surfaces, and the helper cluster no longer inflates or distorts release-core evidence.
