# Change Report · v165_97 · cycles 753-758

## Scope
- third page-by-page audit package
- target pages: referrals, panels, tasks, ranks
- close real page↔route↔data mismatches without new product questions

## Real fixes
- tasks page now sends `task_id` and respects backend `can_claim`
- panels page now uses a correct cursor query and loads backend summary data
- referrals pages now show richer backend activity fields
- ranks page now forwards `exclude_global_id` to the backend top page route

## Narrow local checks
- TypeScript transpile/syntax checks for touched referral, tasks, panels and ranks files

## Archive
- EFHC_Bot_v165_97_cycles_753_758_page_audit_referrals_panels_tasks_ranks_wave.zip
