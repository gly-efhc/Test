# Change report — v149_60_fix_env_alembic_sanity_admin_table

## CI logs evidence
- logs_58960838296.zip

## What failed
- Sanity DB objects after alembic (core_admin): missing efhc_core.users, efhc_core.withdraw_requests, efhc_admin.efhc_sale_packages

## Fix
- backend/migrations/env.py:
  - enforce search_path to efhc_core, efhc_admin (kept)
  - extend alembic online-mode sanity to also require efhc_admin.efhc_sale_packages
  - log schemas (core+admin) for easier debugging in CI

## Registry
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md: marked seen-again for this class with evidence logs_58960838296.zip
