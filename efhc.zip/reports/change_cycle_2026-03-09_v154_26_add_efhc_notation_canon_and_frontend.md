# change_cycle_2026-03-09_v154_26_add_efhc_notation_canon_and_frontend

## Что исправлено
- Добавлен канон обозначений EFHC в `docs/EFHC_CANON.md`.
- Добавлены краткие канонические термины `EFHC`, `EFHCm`,
  `EFHCb`, `EFHCj` в `docs/TERMS_GLOSSARY.md`.
- Добавлены обозначения для FAQ/UI в `docs/FAQ_SSOT.md`.
- Расширен блок `faq_ssot.notation_canon`
  в `ops/canon_rules.yaml`.
- Во frontend уточнены обозначения балансов
  в `ProfileHistorySection` и на странице `Exchange`.
- Добавлен guard-тест на новые обозначения
  во frontend.

## Локальные проверки
- `pytest -q tests/architecture/test_efhc_notation_frontend.py \
  tests/architecture/test_max_line_length_72.py`
- `ops/canon_rules.yaml` парсится через `yaml.safe_load()`.
