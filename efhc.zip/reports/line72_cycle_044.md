# line72 cycle 044

## Goal

Reset Alembic history to a single стартовая миграция `0001_init.py`
и добавить smoke-проверку `upgrade head` на чистой БД.

## Changes

1) `backend/migrations/versions/0001_init.py`

- `users`: `exchanged_kwh_total` создаётся в `0001` (без ensure_column).
- Добавлены критичные CHECK-инварианты генерации/обмена:
  - `total_generated_kwh >= 0`
  - `exchanged_kwh_total >= 0`
  - `exchanged_kwh_total <= total_generated_kwh`
- `panels`: `activated_at/expires_at` сделаны NOT NULL.
- Добавлен CHECK: `expires_at > activated_at`.

2) `tests/test_migrations_upgrade_head.py`

- Smoke: чистая SQLite БД -> `alembic upgrade head` ->
  `SELECT 1` из ключевых таблиц (`users`, `panels`, `efhc_transfers_log`).
- В minimal окружении тест корректно SKIP без SQLAlchemy.
- В full CI тест должен выполняться (env `EFHC_CI_FULL=1`).

## Checks

- `python -m compileall backend -q` PASS
- `pytest -q` PASS

## Remaining

- Для обязательного прогона smoke миграций в CI нужен full job
  с установленным SQLAlchemy (и `EFHC_CI_FULL=1`).
