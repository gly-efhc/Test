# EFHC Bot v166_66 — cycles 857/866 money-center withdraw and proof-card wave

## What changed
- Deepened Money-Center UX on `/withdraw` by adding a unified financial context card and recent EFHC operations next to the withdraw lifecycle.
- Extended the submissions moderation surface with a proof card that shows timestamps, moderator context and proof preview/open actions.

## Why
- User set absolute priority on the monolithic route `ProfileModal -> /withdraw -> history context`.
- User also set proof visibility as the first invariant for task moderation before bulk actions.

## Validation
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` passed.
