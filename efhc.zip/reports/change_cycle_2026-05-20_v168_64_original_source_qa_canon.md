# Change report v168_64 — original-source Q/A canon

## HEAD

`EFHC_Bot_v168_63_original_sources_intake_100_questions.zip`.

## User instruction

Remove PDF original sources from archive, keep only MD intent layer, write
new clarified data into frontend function canon and Q/A register.

## Changes

- Removed `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/pdf/`.
- Removed `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/text/`.
- Created `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/`.
- Created `docs/frontend/FRONTEND_FUNCTION_RECOVERY_CANON.md`.
- Created `docs/frontend/FRONTEND_RECOVERY_20_FOLLOWUP_QUESTIONS.md`.
- Updated Q/A register and chat transcript.
- Updated AI/frontend docs with original-source priority rules.
- Updated document retention guard to enforce MD-only source layer.

## Code

Frontend/backend code was not changed.
