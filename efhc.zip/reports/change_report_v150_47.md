# Change report v150_47

Цель: канонизация банка BANK_EFHC и переход на системный объект
bank_balance (вариант A) с алиасами.

Изменения:
- Канон банка BANK_EFHC закреплён в docs/EFHC_CANON.md.
- Введено правило: банк хранит только EFHC main;
  начальный баланс 5000000.00000000.
- Добавлена миграция 0003: seed EFHC_MAIN=5000000.00000000,
  удаление EFHC_BONUS ключа из bank_balance.
- Удалены ссылки на BANK_TG_ID (историческое; теперь BANK_EFHC) в активном коде; используется BANK_EFHC.
- bank_balance_models: только KEY_MAIN.
- transactions_service: bank_balance читает только EFHC_MAIN;
  bonus в банке всегда 0.
- config_core: BANK_EFHC как логический алиас для зеркальных логов.
- .env.example: добавлен BANK_EFHC.
