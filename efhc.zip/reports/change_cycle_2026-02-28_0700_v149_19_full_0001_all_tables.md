# Change report: v149_19 — full 0001 migration (schemas/tables/sanity)

## Goal
Собрать полную первичную миграцию 0001: все схемы, таблицы и проверки
наличия объектов (to_regclass), опираясь на собранные SSOT-данные.

## What changed
- Переписан `backend/migrations/versions/0001_init.py`:
  - создаёт схемы `efhc_core`, `efhc_admin`
  - создаёт все ORM-таблицы проекта через `Base.metadata.create_all()`
    в `efhc_core` (через `SET search_path TO efhc_core`)
  - создаёт таблицы, требуемые raw SQL и не покрытые ORM:
    `payment_intents`, `unmatched_incoming`, `wallet_connect_idempotency`,
    `scheduler_task_log`, `processed_external_events`,
    `admin_nft_whitelist`
  - создаёт admin-таблицы `efhc_admin.efhc_sale_packages`,
    `efhc_admin.bank_balances`
  - выполняет sanity-check: схемы + все ORM таблицы + extra_required.

## Why
Ранее 0001 была неполной и содержала запрещённые паттерны
(`schema=...` в `sa.Column`). Также отсутствовала детерминированная
проверка полного набора объектов.

## Verification
- compileall backend: ожидаемо PASS (валидный Python)
- alembic upgrade head: ожидаемо создаёт схемы/таблицы и проходит
  sanity-check при чистой БД Postgres.

## Files
- backend/migrations/versions/0001_init.py
- reports/change_cycle_2026-02-28_0700_v149_19_full_0001_all_tables.md
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
