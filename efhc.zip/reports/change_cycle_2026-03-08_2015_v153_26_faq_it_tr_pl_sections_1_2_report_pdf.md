# Change cycle v153_26

## Scope
- Continued FAQ translations for the new 12-section user structure.
- Added item-level translations for `it`, `tr`, `pl`.
- Covered sections `1-2`:
  - Balances
  - Balance history
- Generated an external progress report.
- Generated a PDF with the current canonical FAQ questions and answers.

## What was changed
- `frontend/src/data/faq/localized.ts`
  - added `it` item overrides for sections `1-2`
  - added `tr` item overrides for sections `1-2`
  - added `pl` item overrides for sections `1-2`
  - fixed one `line72` overflow in Polish text

## Checks
- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK
- targeted TypeScript compile for FAQ data-layer -> OK

## Current FAQ language coverage
- Full new 12-section FAQ:
  - `ru`
  - `en`
  - `ua`
  - `de`
  - `fr`
  - `es`
- Partial new 12-section FAQ:
  - `it` sections `1-2`, `9-12`
  - `tr` sections `1-2`, `9-12`
  - `pl` sections `1-2`, `9-12`
- Remaining for the new structure:
  - `it` sections `3-8`
  - `tr` sections `3-8`
  - `pl` sections `3-8`
  - `da`, `hi`, `id`, `sw` all sections

## Artifacts
- FAQ progress report markdown
- PDF with current FAQ questions and answers
