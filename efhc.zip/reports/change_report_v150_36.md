# Change report v150_36 (logs_59169554348)

## Fixed

1) Withdraw approve concurrency

- Added explicit row lock (SELECT ... FOR UPDATE) before the
  atomic PENDING->PAID transition.
- Now the second concurrent approve observes the final status and
  fails with "transition forbidden" (as required by the tests).

Files:
- backend/app/services/withdraw_service.py

2) Admin action logging (details_json)

- Fixed PostgreSQL bind parameter casting for details_json.
- Replaced ":details_json::jsonb" with CAST(:details_json AS jsonb).

Files:
- backend/app/services/admin/admin_logging.py
