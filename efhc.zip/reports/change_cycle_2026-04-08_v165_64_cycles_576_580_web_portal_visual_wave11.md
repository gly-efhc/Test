# Change report — v165_64 — cycles 576-580 — web portal visual wave 11

## Scope
- improve visual presentation of the external portal, web profile and shop entry;
- keep current logic intact while making the external surface feel more product-ready.

## Done
- added hero sections;
- added compact summary blocks;
- aligned visual framing across entry / portal / profile.
