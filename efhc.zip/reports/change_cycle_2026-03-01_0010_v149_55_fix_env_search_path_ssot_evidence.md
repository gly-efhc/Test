# Change report: v149_55_fix_env_search_path_ssot_evidence

Основание: CI logs_58958883850.zip (Sanity DB objects after alembic: missing efhc_core.users / efhc_core.withdraw_requests / efhc_admin.efhc_sale_packages)
Цель: стабилизировать alembic upgrade head (Postgres-only) и привести SSOT evidence по 5 маршрутам.

## Сделано

### Alembic env (search_path)
- backend/migrations/env.py
  - search_path выставляется на две схемы: efhc_core, efhc_admin (вместо только efhc_core).
  - Это устраняет класс ошибок, когда DDL/CREATE TABLE без явной schema уезжает в public или в неверную схему.

### SSOT evidence (5 маршрутов)
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv
  - Добавлены evidence_refs (handler file:line) для:
    - GET /admin/ads/providers
    - GET /cron/tick
    - GET /health
    - GET /nft/has_vip
    - GET /skins/catalog
  - read/write tables для этих маршрутов пустые (таблиц нет).

## Артефакт
- Выпущен FLAT ZIP: EFHC_Bot_v149_55_fix_logs_routes_ssot.zip
