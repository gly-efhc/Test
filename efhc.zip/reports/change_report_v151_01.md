# Change report v151_01

Источник: logs_59320080777.zip (flake8 critical).

## Исправлено

### Flake8 F821 / Syntax

1) backend/app/routes/admin_routes.py
- Исправлены ошибочные `details=f(` на корректные f-строки.

2) backend/app/services/tasks_service.py
- Добавлен импорт `HTTPException`.

3) ops/audits_md_lint.py
- Исправлены ошибочные `die(f(` на корректные f-строки.

4) backend/app/services/referral_service.py
- Добавлены отсутствующие helpers:
  - `_normalize_cursor`
  - `_next_cursor`
  - `build_referral_link`
  - `_generate_referral_code`

5) backend/app/services/lotteries_service.py
- Добавлена отсутствующая функция `_force_lotteries_internal`.

6) tests/test_migrations_upgrade_head.py
- Переписан файл (был сломан блоками кода/отступами).
- Исправлены отсутствующие импорты и переменные.

## Проверки (локально)
- flake8 critical: PASS
- tests/architecture/test_max_line_length_72.py: PASS

## Кеши
Перед упаковкой удалены: __pycache__, .pytest_cache, *.pyc,
frontend/node_modules, frontend/.next, frontend/dist, frontend/build.
