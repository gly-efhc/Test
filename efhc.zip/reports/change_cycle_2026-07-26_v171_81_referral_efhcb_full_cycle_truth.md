# v171.81 — Referral EFHCb full-cycle truth

## Input

- Development HEAD: `EFHC_Bot_v171_80.zip`.
- User correction: direct referral and Lvl rewards are EFHCb; maximum complete
  cycle is `1 000 + 1 411 = 2 411 EFHCb`.

## Cause

The numeric backend total was correct, but the public scale omitted the
cumulative Lvl-reward subtotal and used generic EFHC labels. This made the Lvl 5
card appear to add `1 000 + 1 000` while displaying `2 411`.

## Repair

The API now publishes the canonical asset and explicit full-cycle subtotals.
The UI displays all arithmetic components. Active documentation, FAQ SSOT,
locales and guards were synchronized.

## Unchanged

Referral attribution, activation conditions, idempotency, bank debit/credit,
level thresholds, reward amounts, six-button navigation, 13-language support,
44-table schema and migration head were not changed.

## Local validation

- Targeted runtime/API/UI/OpenAPI: 22 passed, 2 skipped.
- Broad referral/FAQ/localization/OpenAPI architecture: 308 passed.
- Final Kernel/file-map/startup guards: 86 passed.
- Canon Guard, OpenAPI strict gate, Python compilation, 772 JSON files and shell syntax: PASS.
- PostgreSQL integration, frontend npm build, Chromium proof and fresh GitHub CI were not executed locally.
