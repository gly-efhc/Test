# Change report: v149_61_tests_pass

Цель: все тесты PASS + канон 72 символа.

Факты прогона (локально):
- python -m compileall backend ops -q: PASS
- PYTHONPATH=backend pytest -q: 102 passed, 18 skipped

Исправления:
- Починен SyntaxError в referral_codes_models.py.
- Починен __repr__ и структура referral_models.py.
- Починен admin_logging.py (SQL строка, import-safe).
- Исправлены ops/audits_index_lint.py и ops/ci_verify_db_objects.py.
- Возвращены baseline файлы: .gitignore, .githooks/pre-commit.
- Убраны запрещённые алиасы из docs/reports.
- SSOT plan JSON: bans хранятся в unicode-escape.
- 0001_init.py: добавлены payment_intents и ключевой constraint tag.
- PaymentIntent UniqueConstraint: name=uq_payment_intents_idempo.
- Приведено к канону 72 символа: backend/ops/docs.
