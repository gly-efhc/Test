# CHANGE REPORT — v167_42 glossary-first sync and term cleanup

## Scope
Document-layer corrective pass without touching product cycles.

## What changed
- synced `docs/SSOT/TERMS_GLOSSARY.md` with approved document terminology;
- expanded glossary entries for AI/SSOT/NORM/GENERAL/AUDIT/HEALER/REPORT/CYCLE terms with English term + Russian term + definition/use note;
- removed active use of the unapproved `ARCHIVE-REMOVED` term from AI-layer control docs;
- clarified in AI docs that canonical layer terminology lives in `docs/SSOT/TERMS_GLOSSARY.md`;
- updated Q&A register with glossary-first rules and the cancellation of `ARCHIVE-REMOVED`.

## Notes
- This pass does not start cycle 951 and does not modify product/runtime scope.
- No historical change reports were rewritten.
