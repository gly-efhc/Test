# v154_31 — run pytest, fix docs/catalog/tg_id/canon_guard

## Что упало
- pytest collection initially blocked locally by missing SQLAlchemy in the run environment.
- Failing tests after environment prep:
  - tests/architecture/test_docs_ssot_sync.py::test_overview_docs_have_current_counts
  - tests/architecture/test_docs_ssot_sync.py::test_tests_catalog_matches_repo
  - tests/architecture/test_forbidden_identifiers_repo.py::test_forbidden_identifiers_repo
  - tests/test_build_sanity.py::test_canon_guard_passes

## Что исправлено
- Synced overview docs test-files count from 74 to 81.
- Added missing new tests to docs/TESTS_CATALOG.md.
- Renamed frontend local variable tgId -> tg_id in ProfileModal.
- Extended ops/canon_guard.py to allow canon top-level sections:
  faq_ssot, faq_ssot_files, generation_rate_canon.

## Проверка
- pytest: 124 passed, 25 skipped.
