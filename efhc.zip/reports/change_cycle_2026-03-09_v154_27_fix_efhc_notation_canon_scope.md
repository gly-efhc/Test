# v154_27 — fix EFHC notation canon scope

## Что изменено
- Зафиксировано, что `EFHC`, `EFHCm`, `EFHCb`, `EFHCj` — это
  только пользовательские frontend/UI/FAQ/doc обозначения.
- Добавлена карта соответствий:
  - `EFHCm` -> `main_balance`
  - `EFHCb` -> `bonus_balance`
  - `EFHCj` -> внешний EFHC jetton
  - `EFHC` -> `main_balance + bonus_balance`

## Изменённые файлы
- docs/EFHC_CANON.md
- docs/TERMS_GLOSSARY.md
- docs/FAQ_SSOT.md
- ops/canon_rules.yaml
