# Change cycle — 2026-03-06 11:05 — v152_21

## Scope

Синхронизация смысла после CI-ремонта: обзорные документы, каталог
тестов, карта `model → table → route → test`, фоновые задачи,
структурированный admin-audit и guard на актуальность docs.

## What changed

- Обновлены обзорные документы под текущий SSOT.
- `docs/TESTS_CATALOG.md` пересобран по реальному `tests/**`.
- Добавлены документы:
  - `docs/OVERVIEW_SSOT_SYNC.md`
  - `docs/MODEL_TABLE_ROUTE_TEST_MAP.md`
  - `docs/BANK_CANON_SHORT.md`
  - `docs/AI_RESILIENCE_CANON.md`
  - `docs/BACKGROUND_TASKS_STANDARD.md`
  - `docs/DTO_INPUT_CANON.md`
  - `docs/OBSERVABILITY_METRICS_PLAN.md`
  - `docs/SECURITY_EXCEPTIONS_REGISTER.md`
- Добавлен guard:
  - `tests/architecture/test_docs_ssot_sync.py`
- Убраны предупреждения:
  - pytest-asyncio custom event loop fixture
  - pydantic `json_encoders` deprecation
  - ruff top-level lint settings deprecation
- Добавлен helper фоновых задач:
  - `backend/app/core/async_tasks.py`
- `AdminLogger.write()` усилен структурированными полями:
  `before`, `after`, `meta`, `error`.

## Local checks

- `python -m compileall backend/app tests` → pass
- `python -m pytest -q tests/architecture/test_docs_ssot_sync.py
  tests/architecture/test_max_line_length_72.py` → pass

## Notes

Это слой синхронизации смысла, а не попытка заявить зелёный CI без
нового `logs_*.zip`.
