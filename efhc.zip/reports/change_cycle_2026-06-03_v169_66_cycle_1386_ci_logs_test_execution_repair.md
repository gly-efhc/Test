# Change cycle 2026-06-03 — v169.66 / cycle 1386

Cycle: 1386 — CI logs 72103768470 repair / test skip-root fix.

Changed: scoped E2E skip hook, restored SQLAlchemy `__table_args__`, made `/app` a route alias, updated TonConnect closure guard, added cycle 1386 regression guard and docs.

Not claimed: no GitHub CI green, release-ready, screenshots, Telegram client proof, TonConnect transaction proof or full local build success.
