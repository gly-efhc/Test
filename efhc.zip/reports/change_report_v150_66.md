# Change report v150_66

Источник логов: logs_59241811632.zip

## Исправлено по CI

1) tests/efhc_backend/unit/test_prizes_autocycle_ssot.py
- Добавлена функция `_auto_lotteries_if_sold_out()` и вызов из покупки.
- Реализована sold-out авто-логика: winner + результат + приз + автозапуск.

2) tests/test_tonconnect_wallets_ssot.py
- На buy endpoint добавлен wallet gate с `feature="lotteries"` через
  wrapper dependency `_wallet_gate_lotteries()`.

## Дополнительно (устранение реальных дефектов)

- `svc_buy_tickets()` переписана: убран битый блок NFT/winner,
  добавлены:
  - partial fill по остаткам билетов
  - лимит max 10 на draw
  - списание bonus-first через transactions_service
  - claim на каждый VIP-билет
  - read-through idempotency

## Файлы

- backend/app/services/lotteries_service.py
- backend/app/routes/lotteries_routes.py
- reports/change_report_v150_66.md
