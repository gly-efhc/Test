# Change report v149_68

- tests/test_alembic_healthcheck_soft.py:
  заменить вызовы `alembic` на `python -m alembic`.
- docs/TESTS_CATALOG.md:
  уточнить, что healthcheck использует `python -m alembic`.
