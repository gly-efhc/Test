# Change Report · v165_92 · cycles 730-734

## Scope
- close no-question residuals from the cross-audit
- add reusable admin route diagnostics strip
- add persistent backend-side shop item history
- expose persistent history in admin shop UI

## Real fixes
- added `AdminRouteHealthStrip` and wired it into admin index, referrals and shop
- added persistent `shop_items.extra_json.history` trail for item upsert and status changes
- exposed `history_count` and `history_tail` from admin shop items
- merged backend persistent history into the admin shop history tab

## Narrow local checks
- `py_compile` for touched backend files
- TypeScript transpile/syntax checks for touched frontend files

## Archive
- EFHC_Bot_v165_92_cycles_730_734_route_diagnostics_persistent_shop_history_wave.zip
