# Change report — v171.70 / cycle 1578 — clean first-boot release candidate

The v171.70 pass repairs the production contour for the first EFHC deployment on an empty VPS and empty PostgreSQL instance. It does not introduce a new architecture or demonstration application.

Implemented:

- removed the migration runtime dependency on SSOT CSV/documentation;
- added exact ORM metadata validation for 44 production tables and both schemas;
- added fail-closed Alembic migration, database validation and idempotent initial seed;
- added the Compose `migrate` and separate `scheduler` services;
- normalized Telegram webhook and TON environment contracts;
- aligned ranks SQL/ORM/API behavior and mandatory admin shop/hub imports;
- restored periodic idempotent TON reconciliation with persisted cadence/last-success state;
- added strict production ENV preflight and one canonical deploy command;
- retained provider-independent Docker Compose, standard PostgreSQL and secret isolation;
- corrected the invalid development `hooks/hooks.json` and exact Kernel route.

Local evidence:

- focused migration, release, ranks, routes, scheduler, webhook, portability and canonical hygiene tests: 111 passed, 1 skipped;
- exact ORM table contract: 44;
- Alembic offline CREATE TABLE statements: 45 including `efhc_core.alembic_version`;
- production application imports with all mandatory route families;
- production ENV preflight, Python compilation, JSON/YAML parsing and shell syntax/modes pass.

External boundary:

Docker is unavailable in this environment. Therefore no claim is made for a real no-cache Docker build, empty-volume PostgreSQL deployment, live HTTPS/Telegram/TonProof/transactions or second-provider restore. The release metadata must remain `production_release_ready: false`.
