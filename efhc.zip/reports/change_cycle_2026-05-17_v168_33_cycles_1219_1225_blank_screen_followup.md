# Change report v168_33 cycles 1219-1225 blank screen follow-up

## HEAD

`EFHC_Bot_v168_32_cycles_1219_1225_browser_independence.zip`

## Summary

Follow-up repair after user reported blank / white frontend start.

## Code changes

- dark first paint in `document.tsx`;
- default theme changed to dark;
- SplashScreen no longer waits for non-empty dictionaries;
- Energy progress fill is visible at zero percent;
- Referrals pages do not fetch user data without global_id;
- new locale keys for browser-mode referrals.

## Documents

- blank screen repair audit;
- visible frontend chat agreement list;
- unanswered chat audit;
- cycle/norm/glossary/healer updates.

## Checks

- targeted pytest;
- TypeScript check;
- locale JSON validation;
- generated JSON validation;
- ZIP integrity check.

## Not claimed

GitHub CI was not run.
Live browser proof was not run.
Full visual release readiness is not claimed.
