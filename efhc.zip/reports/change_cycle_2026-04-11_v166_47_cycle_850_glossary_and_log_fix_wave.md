# change_cycle_2026-04-11_v166_47_cycle_850_glossary_and_log_fix_wave

## Scope
Continuation of active cycle 850 only.

## What was fixed
- `jetton_parsing_service.py` now resolves transport env values through the
  runtime settings object when environment variables are not populated,
  which restores the watcher USDT transport tests that monkeypatch only
  `ws.settings`.
- `frontend/src/pages/admin/shop.tsx` switched the category pills call from
  the stale `value/onChange` props to the current `activeId/onSelect`
  contract from `TelegramCategoryPills`.
- `payment_reconciliation_service.py` line72 tail is fully cleared in the
  current local recount.
- `ops/routes/audit_tx_hash_locks_core_contour.py` line72 tail was reduced.
- `docs/SSOT/TERMS_GLOSSARY.md` was expanded only with the terms explicitly
  approved by the user, using English terms with Russian duplicates in
  parentheses, and with added entries for Cycle and Pass.

## What remains open
- active line72 residual count is still non-zero under the current scope;
  latest local recount is lower than the fresh CI log and still dominated
  by `frontend/src/features/**` plus several ops audit files.
- the CI failure in
  `tests/test_payment_intents_usdt_tx_and_confirm.py::test_watcher_confirm_shop_external_rejects_non_exact_amount`
  is caused by a test-side SQL fragment `:extra::jsonb`; this pass did not
  modify tests and therefore does not claim closure of that item.
- fresh GitHub CI proof is still required.
