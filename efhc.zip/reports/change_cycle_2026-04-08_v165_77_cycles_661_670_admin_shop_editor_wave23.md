# Change report — 2026-04-08 — v165_77 — cycles 661-670 admin shop editor wave 23

## Scope
Переход к admin product-card management для EFHC package cards.

## Code changes
- admin shop loads catalog and supports selection/filtering
- editor shell with TON+USDT prices and visibility control
- preview card with neutral image slot
- browser shop dual-price/quick-filter improvements

## Docs
- ADMIN_SHOP_EDITOR_AUDIT_661_670_2026_04_08.md
- ADMIN_SHOP_EDITOR_WAVE_661_670_2026_04_08.md
- ADMIN_SHOP_EDITOR_REAUDIT_SLICE_661_670_2026_04_08.md

## Validation
- locale JSON parsed successfully
- archive rebuilt
- no GitHub CI run
