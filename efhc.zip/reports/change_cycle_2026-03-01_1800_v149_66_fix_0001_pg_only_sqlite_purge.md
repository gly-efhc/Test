# Change report

Cycle: v149_66

## Fix logs_58968563741
- Alembic upgrade head failed.
- 0001_init.py required list used users_models.
- Real module is user_models.
- Fix: users_models -> user_models.

## Postgres-only cleanup
- Removed SQLite branches in services:
  exchange_service, panels_service, payment_intents_service,
  transactions_service, withdraw_service.
- Removed backend/app/database.py.

## Economics tests
- Added tests/test_economics_transactions.py:
  - purchase: BONUS then MAIN (atomic + idempotent)
  - withdraw: only MAIN

## Docs
- Updated docs/TESTS_CATALOG.md.

- Added docs/audits/2026-03-01_inventory_tables_routes_schemas_v149_66.md
