# v154_30

Synced live RU FAQ with docs/faq_ssot/ru canonical files.
