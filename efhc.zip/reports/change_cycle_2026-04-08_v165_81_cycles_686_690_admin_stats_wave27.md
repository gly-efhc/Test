# Change report — v165_81 — cycles 686-690 — admin stats wave 27

## What changed
- Patched backend admin stats aggregation and reports overview facts/counters.
- Added user active/inactive/total counters.
- Added bank/users parity diff and match fact.
- Added referral total bonus and withdraw-bonus fact.
- Updated reports page labels and ordering for new facts.

## Files
- backend/app/services/admin/admin_stats_service.py
- backend/app/routes/admin_routes.py
- frontend/src/pages/admin/reports.tsx
- docs/audits/ADMIN_STATS_WAVE_686_690_2026_04_08.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_601-700.md
- reports/REPORTS_INDEX.md
