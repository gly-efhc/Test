# CHANGE REPORT — v165_55 — cycles 516-520

## Scope
- operator workflow wave 3.

## Changed code
- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/referrals.tsx`

## Changed docs
- `docs/audits/OPERATOR_WORKFLOW_WAVE_516_520_2026_04_08.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_501-600.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `reports/REPORTS_INDEX.md`

## What changed
1. Built a dedicated admin workflow page for EFHC deposit processing.
2. Removed the raw deposit action from admin index and replaced it with a module entry.
3. Added effect preview to referral manual bonus.
4. Added effect preview + mandatory reason to referral reassign.
