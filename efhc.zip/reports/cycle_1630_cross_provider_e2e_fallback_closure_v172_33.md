# Цикл 1630 — cross-provider qualification и закрытие fallback

## Входная qualification

Fresh CI `83193385549` проверил exact `EFHC_Bot_v172_32.zip`
размером `12203082` байт. Real PostgreSQL preflight и Alembic upgrade
через `0012` прошли. Ruff, Bandit, flake8 и compileall также прошли.

CI findings:

- 8 устаревших architecture assertions — `SIMPLE_CORRECTIVE_SCOPE`;
- 2 Mypy findings в `backend/app/deps.py` —
  `SIMPLE_CORRECTIVE_SCOPE`;
- TypeScript fixture без `profile.global_id` —
  `SIMPLE_CORRECTIVE_SCOPE`;
- `CRITICAL_BLOCKER` — отсутствует.

Pytest: `8 failed, 3145 passed, 20 skipped, 1 warning`.
Frontend build остановился только на указанном TypeScript contract.
PostgreSQL/migration/financial/auth/security blocker не подтверждён.
По правилу partial PASS цикл `1629` квалифицирован; findings исправлены.

## Реализация 1630

Common/admin business API больше не используют raw Telegram `initData`
как альтернативу server-side Bearer session. `initData` сохраняется
только как explicit credential для `/auth/telegram/session`.
`get_current_tg_id` остаётся внутренним compatibility selector до `1631`
и доступен только после session → canonical `global_id` resolution.
Provider-neutral financial/nonfinancial read dependencies требуют
активную server-side session.

Добавлены:

- real PostgreSQL/API contract для Telegram и TON sessions одного owner;
- API negative contract: raw initData без Bearer не авторизует business
  endpoint;
- Chromium E2E contract для Telegram/TON server-side sessions;
- статический architecture contract закрытия fallback.

Schema не менялась: Alembic head `0012`, migration `0013` отсутствует.
OpenAPI остаётся `131 paths / 136 operations`.
Linkage generator исправлен для двухаргументных `apiRequest` calls;
фактический результат теперь `99/99 complete`, `0 partial` вместо
неполного учёта `84/84`. Routes при этом не добавлялись.

## Ограничения

Финансовые formulas, balances, amounts, precision и idempotency,
legacy-authoritative writes, TON cryptography и Telegram HMAC не
изменялись. CI workflow не изменялся. Physical rename `users.user_id`
не начинался. Cycle `1631` не начат.

## Exit gate

Package `v172.33` не квалифицирует `1630` самостоятельно. Fresh exact
HEAD GitHub CI обязан дать real PostgreSQL + real Chromium evidence без
critical skips. До этого `PRODUCTION_RELEASE_READY` запрещён.
