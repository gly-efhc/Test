# Change report — v171.73 / dual GitHub CI log repair

Both supplied GitHub CI failures were repaired against the v171.72
sources. The development archive received the exact Ruff, Mypy,
Bandit and pytest root-cause fixes. The minimal production archive now
contains an explicit release CI profile, test dependency manifest and
configuration files, so the generic archive CI validates production
runtime contracts without requiring the full development test layer.

The repair does not delete tests, increase skips, weaken financial
truth, bypass PostgreSQL migration checks or claim fresh GitHub CI.
Frontend production build was already green in the supplied development
log and its release-asset contract remains unchanged.
