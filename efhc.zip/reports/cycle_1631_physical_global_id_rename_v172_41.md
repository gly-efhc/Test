# Цикл 1631 — physical rename global_id

Migration `0013` выполняет одно контролируемое изменение схемы:
физическая колонка `users.user_id` становится `users.global_id`.
Значения идентификаторов и финансовые данные не пересчитываются.

Перед DDL migration fail closed проверяет:

- отсутствие NULL, duplicates и значений вне диапазона GlobalId;
- готовность dual-write и двух read switches;
- нулевые fallback, mismatch, orphan и ambiguous показатели;
- денежное расхождение `0.00000000`;
- точный inventory из 38 validated FK;
- безопасное следующее значение sequence.

После rename migration обновляет sequence, имена constraints и FK,
а также PostgreSQL trigger functions. Downgrade возвращает физические
имена и не изменяет данные.

Пакет не является production-ready до fresh exact-head CI `v172.41`.
Цикл `1632` не начат.
