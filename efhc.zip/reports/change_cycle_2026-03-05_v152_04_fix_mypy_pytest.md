# Change report: v152_04

Источник лога: logs_59488407043.zip

## Исправления под pytest (5 failed)
- energy_service._now_utc: datetime.now(tz=timezone.utc)
- transactions_service: убран text(TextClause) в exchange_all
- panels_service: SSOT-маркер p.expires_at <= :server_now_utc
- watcher_service: # nosec вынесен из SQL-текста (idempotent unmatched)
- transactions_service: TxResult заполнен всеми обязательными полями
  в ветках idempotent/success (mypy call-arg)

## Mypy (везде) — снято по мотивам отчёта
- withdraw_schemas: validators теперь Any->cast(...) (no-any-return)
- referral_schemas: d8_str -> cast(str, ...) (no-any-return)
- wallets_service: добавлен credit_user_from_bank re-export
  для watcher_service (attr-defined)
- shop_service: purchase_with_efhc принимает qty (call-arg)

## Риски/контроль
- Экономика не менялась (panel=100, exchange 1:1, withdraw only main).
- Маршруты не менялись.
- Миграции не менялись.

