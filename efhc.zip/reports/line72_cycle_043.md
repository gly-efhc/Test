# line72_cycle_043

Scope: docs full audit + исправления текста/орфографии + интеграция
описания EFHC и SSOT-констант генерации.

## What changed
- Обновлён общий RU overview проекта: добавлено описание EFHC,
  раздел SSOT-констант и цели/принципы.
- Расширены правила генерации энергии (Energy Rules) до SSOT-уровня.
- Исправлены технические огрехи форматирования в ADR/specification.
- Приведены docs к line72 (нет строк > 72) в затронутых SSOT-доках.

## Checks
- python -m compileall backend -q: PASS
- pytest -q: PASS
