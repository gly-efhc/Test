# Change cycle 1595 — v171.92 Backend UserId value type

## 1. Root task

Expand backend UserId typing and unit-level use without changing ORM,
PostgreSQL schema, AuthContext or domain ownership.

## 2. Runtime implementation

Only the provider-independent identity package gained executable logic:

```text
backend/app/identity/__init__.py
backend/app/identity/types.py
```

Implemented immutable value objects and strict boundaries:

- `UserId` for system IDs in `1..9999999999`;
- `TelegramId` as a physically separate provider type;
- `UserIdDisplay` for exactly ten ASCII digits;
- strict Pydantic-ready `ExternalUserId`;
- explicit database and external conversion helpers;
- rejection of raw, Boolean, floating, provider and wallet values.

## 3. Runtime non-change proof

A semantic/exact manifest protects `481` model, migration, service, CRUD,
route, schema, dependency and frontend-source files. Result:

```text
missing = 0
unexpected = 0
semantic_changes = 0
premature_runtime_imports = 0
```

Three active comments were corrected to mark `global_id` as LEGACY runtime.
Their Python AST remained unchanged.

## 4. Identity boundary

```text
Telegram-specific files: 21
Identity-package files: 2
LEGACY runtime files: 179
Tracked runtime files: 202
get_current_tg_id files: 20
Semantic identity-mix offenders: 0
```

## 5. Database and finance

No migration, data write or ownership switch occurred. Balances, kWh,
panels, transactions, deposits, withdrawals, referrals, rewards, roles,
wallet bindings, idempotency and locks were not recalculated or mutated.

Reconciliation is read-only and reports:

```text
NOT_RUN_DB_UNAVAILABLE
financial tolerance = 0.00000000
```

## 6. Tests

```text
2757 unique tests collected
2585 passed
172 skipped
0 failed
0 errors
58.011 seconds aggregate JUnit time
54 targeted tests passed
25 PostgreSQL integration tests collected
```

PostgreSQL runtime, frontend typecheck/build and real Chromium route proof
were not available locally and are not claimed.

## 7. Status

`LOCAL_RELEASE_CANDIDATE` after packaging and archive verification.
Fresh exact-HEAD GitHub CI remains required. Production readiness remains
false until deployment, restore and live Telegram/TON/settlement proof.
