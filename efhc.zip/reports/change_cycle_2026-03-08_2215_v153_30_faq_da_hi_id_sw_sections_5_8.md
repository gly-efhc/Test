# v153_30 — FAQ da/hi/id/sw sections 5–8

Date: 2026-03-08

## What changed

- Added item-level FAQ translations for `da`, `hi`, `id`, `sw`
  for sections `5–8` of the new 12-section user FAQ.
- Covered:
  - Wallet
  - Referrals
  - VIP NFT
  - Shop and skins
- Fixed 2 line72 violations in Swahili strings.
- Verified `canon_guard` passes.

## Notes

- No fresh `logs_*.zip` was provided for this archive.
- Green CI is not claimed.
