# v153_06 — FAQ multilang navigation layer

Date: 2026-03-07
Archive: EFHC_Bot_v153_06_faq_multilang_navigation.zip

## Scope

Continue FAQ implementation after v153_05.
This cycle focuses on factual multilang runtime wiring for the
existing FAQ catalog without inventing new routes or DTO.

## What was changed

1. Added a dedicated FAQ metadata layer:
   - `frontend/src/data/faq/meta.ts`
2. Localized FAQ structural titles for all 13 bot languages:
   - catalog title
   - 17 section titles
   - 25 subsection titles
3. Updated `getFaqCatalog(lang)` so the runtime catalog now returns:
   - RU content body as current source text
   - localized section/subsection titles for the active language
4. Preserved existing search behavior while making section/subsection
   search language-aware through the localized catalog overlay.

## Verified locally

- `python ops/canon_guard.py` -> OK
- `tsc --noEmit --target es2020 --module esnext --lib es2020,dom \
  src/data/faq/meta.ts src/data/faq/index.ts src/lib/i18n.ts` -> OK
- line72 for changed FAQ files -> OK

## Not claimed

No full green CI is claimed in this cycle because no fresh
`logs_*.zip` exists for the new archive.

## Remaining work

1. Translate FAQ question/answer bodies for all 13 languages.
2. Add language-specific FAQ keywords for stronger search quality.
3. Re-check full frontend build and CI with a fresh GitHub log.
