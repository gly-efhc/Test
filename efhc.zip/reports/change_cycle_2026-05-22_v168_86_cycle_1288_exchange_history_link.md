# Change report — v168_86 / cycle 1288

Cycle: 1288 — Exchange History link light boundary.

HEAD:

`EFHC_Bot_v168_85_cycle_1287_exchange_preview.zip`

## Code changes

- `frontend/src/pages/exchange.tsx`
  - replaced the standalone History button with a light secondary
    navigation row;
  - added `data-exchange-history-boundary="light-link-only"`;
  - added `data-exchange-history-link-light="1288"`;
  - kept navigation to common account History;
  - did not add History tables, filters or rows.
- `frontend/src/styles/globals.css`
  - changed Exchange History access from a heavy card-like button to
    a light text link;
  - added hint-row styling for the cycle 1288 boundary.
- `frontend/public/locale/*.json`
  - added `exchange.history_hint` for all public locales;
  - humanized `exchange.open_history` values outside English.
- `tests/architecture/test_exchange_history_link.py`
  - added guard for the light History boundary.

## Documentation changes

- updated work-cycle logs and implementation plan;
- updated frontend matrix, screen registry and checklist;
- updated `CHAT_TRANSCRIPT.md` and Q/A register;
- updated tests catalog, master index and reports index;
- added generated proof JSON and audit report.

## Not changed

- backend routes;
- database models;
- migrations;
- Exchange convert contract;
- withdraw route;
- bottom navigation;
- History page implementation.
