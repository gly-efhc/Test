# v167_26 — language canon sync and player-facing rollback

## Scope
- refresh AI/NORM/SSOT language canon under the updated EFHC Bot rule;
- roll back recent Russian wording introduced into player-facing continuity surfaces;
- keep admin/operator Russian-first wording intact;
- do not rewrite historical cycles or old reports.

## What was found
- Recent passes introduced Russian wording into live player-facing continuity surfaces (`DepositModal`, `Hub`, `Browser-Shop`, `Web-Profile`, continuity copy helpers).
- Existing docs needed an explicit language split to prevent future drift: player-facing English-first, admin/operator Russian-first, trust-sensitive player fallback English.

## What was changed
- Added `docs/SSOT/LANGUAGE_CANON_SSOT.md`.
- Updated AI docs, NORM and SSOT references so the new language split is explicit.
- Reverted recent player-facing Russian wording in the touched continuity surfaces back to English-first.
- Left live admin/operator Russian wording intact.
- Historical cycle records were not rewritten; the correction is fixed through this new report and updated canon docs.

## Files touched
- `docs/AI/AI_DOCS_INDEX.md`
- `docs/AI/AI_BRAIN_MEMORY_MODEL.md`
- `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`
- `docs/AI/AI_OPERATOR_RULES_EFHC.md`
- `docs/NORM/ARCHITECTURAL_LOCKS.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/SSOT/FAQ_SSOT.md`
- `docs/SSOT/SSOT_INDEX.md`
- `docs/SSOT/USER_FACING_WORDING_CANON.md`
- `docs/SSOT/LANGUAGE_CANON_SSOT.md`
- `frontend/src/components/DepositModal.tsx`
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
- `frontend/src/features/hub/HubPage.tsx`
- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/src/lib/portal/continuityCopy.ts`

## Verification
- `python -m compileall backend/app frontend/src/lib/portal frontend/src/features/hub frontend/src/features/browser-shop frontend/src/features/profile frontend/src/components`
- manual grep over touched player-facing files for Cyrillic leftovers

## Cycle status
- This pass was a canon-correction and runtime-wording rollback required by the user.
- Cycle 938 was not declared closed in this report.
