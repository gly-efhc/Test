# Cycle change report: v149_71

Inputs:
- logs_59040565965.zip
- Symptom: post-alembic sanity misses core/admin tables

Fixes:
- backend/migrations/env.py
  - Postgres-only URL selection:
    PSYCOPG_URL -> SYNC_DATABASE_URL -> DATABASE_URL
  - Two-schema canon comments (efhc_core + efhc_admin)
  - CI diagnostics: current_database + search_path log

- backend/migrations/versions/0001_init.py
  - CI diagnostics: print current_database and search_path
  - Enforce default schema for core tables:
    Base.metadata.schema = "efhc_core" for create_all

Notes:
- No sqlite fallback remains in env.py.
- Goal: prevent tables landing in public and
  make DSN/schema drift visible in CI logs.
