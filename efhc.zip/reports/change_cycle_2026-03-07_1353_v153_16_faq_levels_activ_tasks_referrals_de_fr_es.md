# Change cycle v153_16 — FAQ levels/activ/tasks/referrals de/fr/es

- Added item-level FAQ translations for de/fr/es:
  - 10.1 Levels
  - 11.1 Activ
  - 11.2 Referral logic
  - 12.1 Tasks
  - 13.1 Referrals page
- Removed Spanish `todo` placeholder hits that triggered guard.
- Fixed line72 overflow in Spanish FAQ question.
- Verified:
  - `python ops/canon_guard.py` OK
  - targeted FAQ TypeScript compile OK
