# v171.58 / cycle 1573 — balance digits and control-layer sync

## Scope

Cycle 1573 remains active. This pass performs one bounded UI correction and one bounded documentation/control-layer synchronization.

## Primary blocker

No new factual live Telegram route/client evidence, real TonConnect evidence, real TonProof evidence or real transaction evidence was provided in this workspace. Therefore cycle 1573 cannot be completed and cycle 1574 is not started.

Required live evidence remains:

- `LIVE_TELEGRAM_NOT_VERIFIED`;
- `REAL_TONCONNECT_NOT_VERIFIED`;
- `REAL_TONPROOF_NOT_VERIFIED`;
- `REAL_TRANSACTION_NOT_VERIFIED`.

## Implemented independent work

- Updated `frontend/src/styles/globals.css` so the top EFHC balance pill uses one numeric scale for the whole and fractional digits and tabular numerals for a more stable visual rhythm.
- Synchronized active control documents so the real current head, current blocker state and next archive route are explicit.
- Recorded the `WalletProvider` architectural option as a future adapter layer only, without runtime refactor.
- Prepared an inherited screenshot companion package with explicit provenance for the requested surfaces.

## Proof boundary

This pass does not execute Telegram, TonConnect, TonProof or a real TON transaction. It does not change wallet/payment runtime logic, dependencies or lockfiles.

The result remains deliberately fail-closed for cycle 1573: `BLOCKED_MISSING_LIVE_EVIDENCE`.

## Screenshot policy

The v171.58 screenshots companion is `inherited baseline` proof, not fresh browser-captured proof for this pass. Reason: `frontend/node_modules` is absent in the workspace and the user rule forbids `npm ci` without direct permission. Therefore only existing verified screenshots may be used, and they are explicitly marked as inherited.

Proof types used in the companion package:

- `inherited baseline` for header/profile/browser section screenshots;
- no `live-route` proof;
- no new `browser-captured component/page proof` was created in this pass.

## Checks actually run

- `pytest -q tests/healer/test_critical_delivery_protocol.py tests/healer/test_healer_atlas_rules.py tests/healer/test_healer_casebook_sync.py tests/healer/test_healer_atlas_sync.py`.
- archive ZIP integrity / SHA-256 / forbidden-artifact checks after packaging.
- `python ops/healer/check_critical_delivery_protocol.py` after packaging.

## Not run

Full CI, full pytest, full regression, `npm ci`, production build, local GitHub-CI copy, broad browser sweep and live Telegram/TonConnect/TonProof/transaction execution were not run.

## Root causes addressed locally

- Mixed whole/fraction font sizing in the top EFHC balance pill reduced visual consistency.
- Active AI/control-layer docs still exposed stale or incomplete current-head orientation for the new pass.

## Status

- cycle 1572: closed by green user-run GitHub logs;
- cycle 1573: active and not complete;
- cycle 1574: not started;
- next archive after v171.58 delivery: `EFHC_Bot_v171_59.zip`.
