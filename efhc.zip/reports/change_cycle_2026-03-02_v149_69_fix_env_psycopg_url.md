# v149_69: env.py uses PSYCOPG_URL first

- Alembic env теперь берёт URL в приоритете:
  PSYCOPG_URL -> SYNC_DATABASE_URL -> DATABASE_URL.
- Убрано расхождение между Alembic и post-sanity,
  где sanity подключается через PSYCOPG_URL.
