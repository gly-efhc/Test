# Циклы 1666–1667 — v172.83

Исправлены все подтверждённые ошибки пользовательского CI. Административные user routes переведены на canonical global_id, OpenAPI и frontend seam contracts пересобраны. Telegram provider identity сохранена. Выполнено 500 семантических business-owner замен. Связанные архитектурные проверки прошли. Exact-head CI v172.83 требуется.
