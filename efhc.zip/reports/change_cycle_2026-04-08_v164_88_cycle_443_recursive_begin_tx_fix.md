# change_cycle_2026-04-08_v164_88_cycle_443_recursive_begin_tx_fix

- Fixed recursive `_begin_tx` residuals in `backend/app/services/referral_service.py`, `backend/app/services/wallet_binding_service.py`, and `backend/app/services/tasks_service.py`.
- The broken else-path now calls `await db.begin()` instead of recursively calling `_begin_tx(db)`.
- Added architecture guard `test_wave19_no_recursive_begin_tx_residuals` to prevent relapse.
- Transferred the defect into Healer as a chronic pattern after the earlier `energy_service` incident.
