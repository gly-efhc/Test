# Frontend line72 cycle 003
## Edited files (safe edits)
- `frontend/src/pages/tasks.tsx`: remaining >72 lines = 6
- `frontend/src/pages/shop.tsx`: remaining >72 lines = 14
- `frontend/src/pages/ranks.tsx`: remaining >72 lines = 13
- `frontend/src/pages/admin/bank.tsx`: remaining >72 lines = 9
- `frontend/src/pages/lotteries.tsx`: remaining >72 lines = 12

## Global status
- Files with >72 lines (frontend): 38
- Total >72 lines (frontend): 399

## Notes
- Some long user-visible strings and JSX were kept
  over 72 to avoid semantic or readability risk.
- Next targets remain: ProfileModal, admin/users,
  exchange, index, Layout.
