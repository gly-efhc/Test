# v167_03 — AI operator rules PDF sync

## Что изменено
- В `docs/AI/AI_OPERATOR_RULES_EFHC.md` перенесён и закреплён
  полный блок правил из PDF:
  - Think Before Code
  - Simplicity
  - Surgical Edits
  - Goal-Oriented Execution
- Добавлены базовый принцип, четыре главных правила,
  дополнительный EFHC-specific control layer,
  операционный чек-лист и краткая каноническая версия.

## Что не менялось
- Код backend/frontend не менялся.
- Cycle status и active range не менялись.
- Новый продуктовый цикл не закрывался этим проходом.

## Подтверждение
- Изменение подтверждено прямой правкой AI-документа в HEAD-архиве.
- Выполнена текстовая проверка наличия нового блока в
  `docs/AI/AI_OPERATOR_RULES_EFHC.md`.
