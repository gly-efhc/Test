# Change report v150_62

Источник: EFHC_Bot_v150_61_imports_app_only.zip
Основание: CI logs_59238358816.zip

## Исправлено (по CI)

1) SyntaxError в backend/app/routes/lotteries_routes.py
- Закрыта скобка вызова svc_list_lotteries_history()

2) SyntaxError/indentation + line72 в backend/app/services/lotteries_service.py
- Переписаны функции:
  - _auto_restart_lotteries()
  - svc_admin_create_lotteries()
- Добавлен импорт timedelta
- Устранены 3 нарушения line72

3) Great Canon Guard: запрещённый токен "draw"
- Удалены standalone токены "draw" из backend/app и ops
- Обновлены комментарии/строки:
  - backend/app/services/lotteries_service.py
  - backend/app/core/config_core.py
  - ops/canon_rules.yaml (удалены lowercase raffle/draw/draws)

## Локальные проверки (не CI)

- python -m compileall backend (PASS)
- pytest -q tests/architecture/test_max_line_length_72.py (PASS)
- pytest -q tests/architecture/test_great_canon_guard.py (PASS)
- pytest -q tests/architecture/test_no_backend_app_imports_repo.py (PASS)

