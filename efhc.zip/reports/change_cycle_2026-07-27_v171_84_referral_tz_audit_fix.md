# Change cycle 1587 — v171.84 referral TZ audit and repair

## Input

- `EFHC_Bot_v171_83.zip`;
- `EFHC_Bot_v171_83_RELEASE.zip`;
- two referral/release technical specifications;
- development/release GitHub logs, both green for v171.83.

## Decision

Use the specifications as audit evidence, not as copy-paste source. Direct user
canon and exact runtime remain authoritative.

## Changes

- corrected TG ID SQL, Active/Inactive filtering and cursor pagination;
- repaired legacy CRUD and stale health registry;
- secured deprecated routes and added `/counters/me`;
- corrected admin totals and ETag behavior;
- hardened reward concurrency with post-lock idempotency read-through;
- added real PostgreSQL runtime/API integration tests and explicit CI stage;
- corrected release documentation and policy;
- recorded audit adaptations and external proof boundary.

## Invariants preserved

- `0.1 EFHCb` direct reward, Lvl rewards and `2 411 EFHCb` full cycle;
- immutable first-creation attribution;
- one atomic first-panel transaction;
- one Alembic head and 44 ORM tables;
- cumulative release updates and one-step application rollback.

## Status

`LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED /
VPS_DEPLOYMENT_DEFERRED / production_release_ready=false`.
