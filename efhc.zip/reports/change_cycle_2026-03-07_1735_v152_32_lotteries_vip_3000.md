# v152_32 — Lotteries VIP NFT: 3000 tickets

## Что проверено
- backend config default for `LOTTERIES_VIP_TOTAL_TICKETS`
- lotteries bootstrap `_ensure_default_rounds()`
- lotteries auto-restart `_auto_restart_lotteries()`
- admin create path via `DEFAULT_LOTTERIES_TOTAL_TICKETS_NFT`
- canonical docs `docs/LOTTERIES.md`

## Что найдено
- VIP NFT lotteries still used SSOT value `1000` in code defaults and docs.
- Auto-restart cloned old `lot.total_tickets`, so changing only the
  default constant was insufficient for future rounds.

## Что изменено
- `backend/app/core/config_core.py`
  - `LOTTERIES_VIP_TOTAL_TICKETS: 1000 -> 3000`
- `backend/app/services/lotteries_service.py`
  - canonical NFT default `1000 -> 3000`
  - auto-restart now rebuilds new rounds from current settings
    (`LOTTERIES_VIP_TOTAL_TICKETS` / `LOTTERIES_EFHC_TOTAL_TICKETS`)
    instead of blindly cloning old `total_tickets`
- `docs/LOTTERIES.md`
  - VIP draw size `1000 -> 3000`
  - ENV example `LOTTERIES_VIP_TOTAL_TICKETS=3000`
  - winner range `1..3000`
  - probability note updated for 3000-ticket draw

## Аудит-вывод
- Новые VIP NFT rounds from bootstrap/admin create now use `3000`.
- Auto-restarted VIP NFT rounds also use `3000`.
- Исторические отчёты в `reports/` сознательно не переписывались, так
  как они append-only и фиксируют прошлые состояния.
