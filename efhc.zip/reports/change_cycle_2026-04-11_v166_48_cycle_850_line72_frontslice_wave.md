# change_cycle_2026-04-11_v166_48_cycle_850_line72_frontslice_wave

## Scope
Continuation of active cycle 850 only.

## What was fixed
- reduced the active line72 residual wave from 92 to 66 under the current
  architecture-test scope.
- fully cleaned `ops/routes/audit_final_release_gate.py` from line72
  violations.
- fully cleaned `frontend/src/features/admin/AdminHubPage.tsx` from line72
  violations.
- fully cleaned `frontend/src/features/browser-shop/BrowserShopPage.tsx`
  from line72 violations.
- fixed the new frontend type tail in `/admin/shop` by removing the
  unsupported `size="sm"` prop from `Button` and keeping the action flow
  intact.

## Vocabulary audit
Current exact glossary entries:
- `Cycle (цикл)` — нумерованная рабочая единица проекта, фиксируемая в
  control-layer как отдельный шаг исполнения.
- `Pass (проход)` — один фактический рабочий проход внутри активного
  цикла, в котором выполняется совместимый объём правок за раз.

Similar missing candidates not yet added to glossary:
- Active range (активный диапазон)
- Active block (активный блок)
- queue (очередь)
- wave (волна)
- tail (хвост)
- closure (закрытие)
- remediation (ремедиация)
- sync drift (дрейф синхронизации)
- release candidate (кандидат релиза)
- donor audit (донорский аудит)

## Honesty gate
Fresh GitHub CI proof is still required.
The pytest SQL fragment `:extra::jsonb` remains a test-side blocker and was
not changed in this pass.
