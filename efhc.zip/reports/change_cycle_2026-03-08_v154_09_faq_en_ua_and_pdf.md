# Change cycle — 2026-03-08 — v154_09

## Scope
- Continued FAQ adaptation from the Russian source.
- Added full item-level FAQ overrides for EN and UA.
- Generated a full Russian FAQ PDF from the current FAQ source.

## Confirmed findings
- Fresh `logs_*.zip` for `v154_08` was not provided.
- Direct audit confirmed that `frontend/src/data/faq/localized.ts`
  contained no item-level translations.
- As a result, non-RU FAQ content still fell back to Russian text.

## Changes made
- `frontend/src/data/faq/localized.ts`
  - Added full EN overrides for all 72 FAQ items.
  - Added full UA overrides for all 72 FAQ items.
  - Kept other languages unchanged in this cycle.
  - Removed banned `rating` substring hits from EN wording by
    replacing `generating` with `producing energy`.
- `docs/EFHC_FAQ_FULL_RU_v154_09.pdf`
  - Added a full Russian FAQ PDF built from the current FAQ source.

## Local checks
- `tests/architecture/test_max_line_length_72.py` — passed
- `tests/architecture/test_no_banned_rank_terms.py` — passed
- `tests/efhc_backend/unit/test_no_legacy_words.py` — passed
- `tests/test_no_placeholders.py` — passed
- Local syntax parse for `localized.ts` override object — passed
- PDF rendered locally: 8 pages, visually checked

## Remaining work
- Adapt FAQ item-level translations from the Russian source for:
  `de`, `fr`, `es`, `it`, `tr`, `pl`, `da`, `hi`, `id`, `sw`.
- If needed, refine EN/UA wording after UI review.
- Full green CI is not claimed without a fresh `logs_*.zip`.
