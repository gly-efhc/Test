# Change cycle 1509 — PACK-03 Final Cleanup

Input HEAD: `v170.84`.

Output HEAD: `v170.85`.

Changes:

- removed runtime `UserWallet` alias usage;
- removed `backend/app/models/wallet_models.py` shim;
- added direct EFHC payment intent canon;
- added watcher incoming deposit accounting canon;
- updated direct EFHC confirmation to account different `tx_hash`;
- added DB drift matrix;
- added admin button coverage matrix;
- added frontend/API/i18n consistency matrix;
- added release proof status.

No EFHC economy change.

PACK-01 and PACK-02 canons preserved.
