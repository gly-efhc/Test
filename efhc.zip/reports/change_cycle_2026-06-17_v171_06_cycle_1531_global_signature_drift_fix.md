# Change report — v171.06 / cycle 1531

Cycle: `1531 — Global Signature Drift Fix`.

## Summary

Closed the global audit kwarg/signature mismatch findings from
`AUDIT_V171_05_GLOBAL.md` / `CYCLE_1525_GLOBAL.md` under the current cycle
number `1531`.

## Runtime changes

- Fixed panels pagination cursor payload.
- Fixed scheduler archive panels call and return shape.
- Fixed bot referrals signature call and display access.
- Fixed bot ranks signature call, 3-value unpacking and exception logging.
- Fixed NFT has_vip route signature call and controlled invalid wallet error.
- Fixed admin decimal formatting kwarg.
- Expanded staged mypy file list.

## Validation

- Targeted signature drift pack: `16 passed, 2 skipped, 2 warnings`.
- Hygiene/current guard pack: `30 passed`.
- Max line length guard: `1 passed`.
- Compileall: passed.

Full pytest green, ruff, mypy, bandit, frontend build green, live Telegram,
real TonConnect and release-ready are not claimed for `v171.06`.
