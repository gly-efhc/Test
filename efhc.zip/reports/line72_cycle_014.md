# line72 cycle 014

## Goal

- Ужесточить входящие DTO (Pydantic v2) против mass assignment:
  extra поля запрещены (extra='forbid') для денежных POST с
  Idempotency-Key и критичных входов withdraw/lotteries.

## Changes

1) backend/app/schemas/common_schemas.py
   - Добавлен StrictIn (ConfigDict(extra='forbid')).
   - IdempotencyContract теперь наследуется от StrictIn.

2) backend/app/schemas/withdraw_schemas.py
   - WithdrawCreateIn / AdminWithdrawTakeIn /
     AdminWithdrawDecisionIn / AdminWithdrawMarkPaidIn
     переведены на StrictIn.
   - Убраны model_config extra='ignore' для входящих DTO.

3) backend/app/schemas/lotteries_schemas.py
   - BuyTicketsIn переведён на StrictIn.

## line72

- Нарушений >72 символов не добавлено.
- Исключения не требовались.

## Checks

- python -m compileall backend -q
- pytest -q
