# v167_98 — cycles 1151-1155 — pre-release bonus-column refactor

## Scope

- Continue pre-release migration / routes / aliases repair after v167_97.
- Do not rewrite historical cycles.
- Keep single-base `0001` canon.

## Closed cycles

### Cycle 1151 — pre-release tasks.bonus_efhc rename
- moved active ORM/schema/service reads from `reward_bonus_efhc` to `bonus_efhc`;
- kept bounded compatibility alias on the ORM model.

### Cycle 1152 — pre-release task_submissions.bonus_amount_efhc rename
- moved active ORM/schema/service reads from `reward_amount_efhc` to `bonus_amount_efhc`;
- kept bounded compatibility alias on the ORM model.

### Cycle 1153 — task route/service claim catalog repair
- removed remaining broken references to `Task.reward_amount_efhc`;
- aligned task catalog and user-task list to `Task.bonus_efhc`.

### Cycle 1154 — tasks CRUD global_id audit repair
- fixed `TaskSubmission.user_global_id` drift in CRUD helpers;
- aligned status update storage to `bonus_amount_efhc`.

### Cycle 1155 — docs / SSOT / audit sync
- updated glossary and neutral alias canon;
- added fresh audits and synced report/cycle indexes.

## Notes

Historical reports may still mention `reward_bonus_efhc` / `reward_amount_efhc` as evidence of earlier states. This report records the current pre-release canon instead of rewriting history.
