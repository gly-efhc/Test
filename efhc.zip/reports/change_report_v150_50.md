# Change report v150_50

- Removed legacy bank alias names from active code and docs.
- Dropped set_admin_bank_tg_id re-exports from admin CRUD facades.
- Moved legacy bank_tg_id audit into artifacts/legacy_bank_tg_id.
- Replaced bank_tg_id identifiers in tests with bank_efhc_id.
- docs/EFHC_CANON.md now uses BANK_EFHC only.

