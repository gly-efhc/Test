# Change report v168_19 cycles 1198-1199

## HEAD

Input archive:
`EFHC_Bot_v168_18_cycles_1196_1197_profile_language_repair.zip`.

## Scope

Repair the Direct Deposit visual road and backend split after the
imported visual audit. Recheck profile language switching and keep the
language bar behavior protected.

## Code changes

- Rewrote `frontend/src/components/DepositModal.tsx` as a clean
  Direct Deposit wallet-open modal.
- Updated `frontend/src/components/GlobalHeader.tsx` so the direct
  deposit action is the canonical `+` and opens the modal directly.
- Added `DirectDepositOpenOut` to backend deposit schemas.
- Added `POST /deposit/direct-open` to backend deposit routes.
- Added Direct Deposit locale keys for all active languages.

## Documentation changes

- Added `docs/audits/DIRECT_DEPOSIT_REPAIR_1198_1199.md`.
- Updated cycle plans, API contracts, road matrix, visual public UI
  norm, tests catalog, Healer and reports index.
- Updated SSOT route CSV layers for `POST /deposit/direct-open`.

## Tests and checks

- Targeted pytest for Direct Deposit and profile language guards:
  passed.
- Backend py_compile for touched route and schema: passed.
- Backend compileall: passed.
- Frontend TypeScript check: passed.
- Runtime OpenAPI export: blocked by missing local `sqlalchemy`.
- Frontend production build: timed out during optimized build stage.

## Not claimed

- GitHub CI was not run.
- Full browser screenshot proof was not run.
- HUB and Browser-Shop visual blockers remain open.
- Full release readiness is not claimed.
