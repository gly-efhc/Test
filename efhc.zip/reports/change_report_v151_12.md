# v151_12 — CI: logs even on failure

## Изменения
- CI: gate-этапы больше не останавливают job сразу.
  Они пишут exit-код в ci_artifacts/exit_*.txt и продолжают выполнение.
- Добавлен финальный шаг `Gate summary`, который:
  - печатает все exit-коды
  - валит job (exit 1), если любой gate не прошёл.
- Workflow продублирован в `.github/workflows/ci.yml` + оставлен `ci.yml`
  в корне (для ручного копирования).

## Зачем
- Чтобы даже при падении flake8/pytest/npm build ты видел полный набор
  логов и артефактов, а job при этом оставался failed.

## Кеши
- Перед упаковкой очищены стандартные кеши (py/pytest/mypy/ruff/next/npm).
