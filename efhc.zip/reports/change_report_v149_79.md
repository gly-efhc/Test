# Change report v149_79

Источник истины:
- Код: v149_78_tx_nested_fixes (предыдущий цикл).
- Логи: без новых logs_*.zip (изменения требуют проверки CI).

## Цель

Привести watcher_service к SSOT-правилу пользователя:

1) Входящие транзакции без MEMO:
   - идентифицировать пользователя по привязанному кошельку
     (efhc_core.user_wallets),
   - начислять EFHC в main через Банк (transactions_service),
   - при этом фиксировать событие в efhc_core.unmatched_incoming.

2) Все оплаты через TonConnect / payment_intents:
   - жёстко привязаны к payload (EFHC:purpose:intent_id:tg_id),
   - watcher подтверждает intent по payload с приоритетом над
     любыми иными правилами.

## Изменения

1) backend/app/services/watcher_service.py
- Добавлен флаг found_by_wallet.
- Добавлен ранний кейс:
  found_by_wallet + пустой memo -> record_unmatched_incoming +
  попытка _resolve_simple_deposit_qty + credit_user_from_bank,
  иначе STATUS_PENDING_MAP.
- Для неподдерживаемого memo при found_by_wallet:
  перевод в STATUS_PENDING_MANUAL + запись в unmatched_incoming
  (вместо STATUS_ERROR_MEMO).
- Обновлено описание правила в _record_unmatched_incoming().

## Приёмка (требуется новый logs_*.zip)

В CI должны пройти:
- canon/13 alembic upgrade head
- canon/21 sanity required tables
- pytest -q
