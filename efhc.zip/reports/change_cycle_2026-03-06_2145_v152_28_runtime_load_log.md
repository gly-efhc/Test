# Change cycle: 2026-03-06 21:45 / v152_28

## Source of truth
- HEAD archive under audit:
  `EFHC_Bot_v152_27_runtime_routes_startup_fix.zip`
- Fresh runtime diagnostic log:
  `logs_59680752483.zip`

## What the runtime load run showed
The runtime workflow itself is healthy:
- backend process started;
- Alembic upgrade completed;
- `/health` was reachable;
- k6 completed without HTTP failures.

Diagnostic load parameters from the log:
- VUs: `1000`
- duration: `60s`
- think time: `200 ms`

Observed runtime metrics:
- `http_req_failed = 0.00%`
- `avg = 1.19 s`
- `p95 = 1.26 s`
- `p99 = 1.30 s`
- `max = 24.79 s`
- completed iterations: `43121`
- checks passed: `86862 / 86862`

## Startup integrity status
Backend startup is still not complete.
The startup smoke log confirms exactly two skipped route modules:
- `app.routes.panels_routes`
- `app.routes.lotteries_routes`

## Confirmed root causes from startup log
1. `panels_routes`
   - skipped with FastAPI error:
     `Invalid args for response field`
   - the error text points to a non-canonical annotation using
     `starlette.responses.Response | None`
   - this is a route signature contract defect, not a load defect.

2. `lotteries_routes`
   - skipped due to import error:
     `cannot import name 'LatestWinnersOut'`
   - this is a schema/import sync defect between route and
     `app.schemas.lotteries_schemas`.

## Conclusions
1. The runtime workflow is now useful and stable as a diagnostic tool.
2. The current archive survives soft-to-medium diagnostic load without
   HTTP failures.
3. Performance is not the primary blocker right now.
4. The primary blocker remains startup completeness of the route layer.
5. Because two route modules are still skipped, current runtime numbers
   cannot yet be treated as full-backend performance truth.

## Required next actions
1. Fix `panels_routes` FastAPI signature contract.
2. Restore schema/route sync for `LatestWinnersOut` in lotteries.
3. Re-run the same runtime diagnostic on the next archive.
4. Accept runtime baselines as representative only after startup shows
   zero skipped route modules.
