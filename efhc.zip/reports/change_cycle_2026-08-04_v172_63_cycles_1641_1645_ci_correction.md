# v172.63 — исправление CI циклов 1641–1645

## Основание

Fresh main CI run `30921046975` проверил exact v172.62.

Прошли Flake8, Mypy, compileall, PostgreSQL diagnostic и production
frontend build. Не прошли Alembic, Ruff, Bandit и pytest.

## Первая causal причина

После добавления canonical owner в Achievements фактическое число FK на
`efhc_core.users.global_id` выросло с 38 до 39. Migration validator остался
на старом значении и остановил Alembic. Отсутствующие таблицы и большая
часть PostgreSQL errors были следствием этого раннего отказа.

## Исправления

- migration validator и ORM architecture proof обновлены до 39 FK;
- удалены четыре unused Referral imports;
- dynamic SQL заменён фиксированными statements или ORM select;
- read control совместим с полным post-cutover режимом;
- readiness поддерживает revisions `0001` и `0002`;
- сохранены переходные direct-call seams до циклов 1646–1647;
- новые HTTP self-routes не публикуют legacy owner selector;
- Wallet/Withdraw используют canonical owner;
- исправлены line-72 и identity-boundary guards;
- canonical CI, screenshot workflow и public visual source не изменялись.

## Локальные доказательства

- полный pytest: `3107 passed, 252 skipped`;
- architecture registry: `2507 passed, 6 skipped`;
- domain sweep: `126 passed, 97 skipped`;
- test collection: `3348 tests`;
- compileall backend: `PASS`.

## Ограничения

Локальная среда не содержит PostgreSQL и пакеты Ruff, Flake8, Mypy,
Bandit. Поэтому Alembic `0001 -> 0002`, PostgreSQL integration и exact
static gates должен подтвердить fresh GitHub CI v172.63. Production
cutover не выполнялся.
