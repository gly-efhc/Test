# Cycle 459

- Updated canon/legacy guard-tests so user-approved archival baskets in `artifacts/` are not scanned as active repository surface.
- Preserved strict scanning for active code, active docs and Healer.
