# Change report v150_43

Source logs: logs_59179683846.zip

## Fixed

- tests/test_concurrency_withdraw_double.py
  - Added _ensure_admin() helper that inserts actor tg_id into
    efhc_admin.admin_whitelist (active).
  - Applied before approve calls to align tests with security canon:
    service-level whitelist check must block non-admin actors.
