# change_cycle_2026-04-08_v164_94_cycle_449_ci_ownership_and_concurrency_setup

- Reinforced the project rule that GitHub CI runs are executed by the user, while AI local checks remain auxiliary only.
- Added the reminder to AI docs and Healer.
- Updated `tests/test_concurrency_exchange_withdraw.py` to create the canonical user setup before the exchange/withdraw race, matching the test's own stated invariants.
