# Change cycle 2026-03-01 0815 — v149_36_fix_unzip_and_0001_sanity

## Scope
- Fix CI unzip failure caused by overlong / non-ASCII legacy filenames under `docs/audits/_raw/legacy_md/`.
- Fix Alembic 0001 sanity-check to_regclass qualification bug (`efhc_core.efhc_core.<table>`).

## What was broken (evidence)
- `logs_58934396257.zip`: step `Unzip efhc.zip` failed with `File name too long` for multiple files in `docs/audits/_raw/legacy_md/`.
- `logs_58933931956.zip`: `alembic upgrade head` failed in `0001_init.py` when calling `to_regclass` with `efhc_core.efhc_core.achievements`.

## Changes
### C) SSOT tables for routes №26–№30
- Updated `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv` for routes:
  - 26) GET /admin/withdrawals
  - 27) POST /admin/withdrawals/{request_id}/approve
  - 28) POST /admin/withdrawals/{request_id}/reject
  - 29) POST /ads/callback/{provider}
  - 30) GET /ads/slot
  with read/write tables and evidence refs.

## Changes
### A) Docs legacy filenames sanitization (no content loss)
- Renamed 5 files in `docs/audits/_raw/legacy_md/` to short ASCII names `legacy_001.md`..`legacy_005.md`.
- Added `docs/audits/_raw/legacy_md/RENAMED_MAP.csv` mapping old → new.

### B) Alembic migration 0001 sanity fix
- `backend/migrations/versions/0001_init.py`:
  - qualify table name as:
    - `t` if already contains a dot (`schema.table`)
    - otherwise prefix with `efhc_core.`

## Files changed / added
- backend/migrations/versions/0001_init.py
- docs/audits/_raw/legacy_md/* (renames)
- docs/audits/_raw/legacy_md/RENAMED_MAP.csv (added)
- reports/REPORTS_INDEX.md (updated)
- reports/change_cycle_2026-03-01_0815_v149_36_fix_unzip_and_0001_sanity.md (added)

## Notes
- This cycle does not claim CI PASS; only addresses failures evidenced by the attached GitHub Actions logs.
