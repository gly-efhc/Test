# Change report v150_41

- Fix ORM: remove AdminActionLog.admin relationship; no FK.
- Add comment explaining audit design.
