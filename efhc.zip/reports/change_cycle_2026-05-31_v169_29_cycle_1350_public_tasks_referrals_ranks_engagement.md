# Change report

Cycle: 1350
Archive: v169_29
Name: Public Tasks / Referrals / Ranks engagement
Date: 2026-05-31

## Goal

Continue public UI interactivity wave after Energy, Panels and Exchange.

## Added

- `PublicEngagementPreview` public component;
- Tasks engagement preview;
- Referrals engagement preview;
- Ranks engagement preview;
- cycle docs and audit;
- architecture guard.

## Changed

- `/tasks` now shows a safe engagement preview before task cards;
- `/referrals` now shows active/total/level progress preview;
- `/ranks` now shows position/score/focus preview;
- locale keys were added to all 13 locale files;
- public UI roadmap updated.

## Boundaries

- no hidden task execution log;
- no admin trace;
- no endpoint labels;
- no backend route changes;
- no CI/workflow changes.

## Checks

Local auxiliary checks were run for compile, typecheck, lint and targeted
architecture guards. Full GitHub CI is not claimed locally.

## Next

Cycle 1351: Public Profile / Wallet / History trust layer.
