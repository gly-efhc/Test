# v171.78 — immutable referral attribution at first user creation

## Scope

Source HEAD: `EFHC_Bot_v171_77.zip`.
Target development archive: `EFHC_Bot_v171_78.zip`.
Target release archive: `EFHC_Bot_v171_78_RELEASE.zip`.
Kernel route: `referral_persistence_webhook_repair`.

## Canonical result

- Referral ownership is fixed only in the transaction that first creates the
  player's PostgreSQL `users` row.
- A new user with a valid generated referral code is created together with one
  direct `referral_links` row.
- A new user without a referral becomes a permanent 0 user. No referral row and
  no referral reward are created.
- Existing users cannot be attached, reattached or reassigned.
- Invalid supplied referral payloads fail before user insertion.
- Public bind/attach, Admin inviter reassignment and Admin manual referral
  payout surfaces are absent.
- Profile and money paths fail closed for a missing player; they cannot create
  an implicit 0 user.
- Every user may invite new users. Only direct invitees count.
- The only monetary referral reward is one `0.1 EFHC` credit when a direct
  invitee activates the first panel. Referral levels remain achievements and
  ranking only.
- No new Alembic migration file was added. No production deployment exists;
  consolidated `0001` remains the single head and builds current ORM metadata.

## Transaction boundaries

- User creation and direct referral-link creation share one commit/rollback
  boundary.
- First-panel debit, panel rows, `activated_at` and the one referral reward
  share the panel-owned transaction.
- Replay uses the canonical `REF_ACT_UNIT:<buyer_tg>` idempotency key.
- A reward failure rolls back the panel debit, panel rows, activation marker and
  transfer record.

## Permanent guards

- source/AST first-panel wiring guard retained;
- single player-creation entrypoint architecture guard;
- no late public/Admin mutation guard;
- PostgreSQL onboarding, 0-user, invalid-code and rollback tests;
- PostgreSQL first-panel reward, replay and forced-failure rollback tests;
- dependency-light reward-call signature execution test;
- standalone release acceptance of the packaged runtime;
- local `mypy` default scope aligned to `backend/app`, matching CI.

## Local verification

- Full collected development suite executed in non-overlapping bounded groups:
  `2491 passed, 148 skipped, 0 failed`.
- Architecture: `2309 passed, 6 skipped, 0 failed`.
- Canon Guard: PASS.
- Python compilation: PASS.
- release shell `bash -n`: PASS.
- JSON/YAML validation: PASS.
- static frontend/backend and OpenAPI route contract: PASS, 129 operations.

Skipped tests require unavailable local PostgreSQL, Playwright/browser or other
external test services. Ruff, Mypy, npm production build and exact-HEAD GitHub
CI remain external gates for this delivery.

## Honest status

`LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED /
VPS_DEPLOYMENT_DEFERRED_BY_USER / production_release_ready=false`.
