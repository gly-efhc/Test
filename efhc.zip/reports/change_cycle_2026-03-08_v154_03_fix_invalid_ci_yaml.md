# v154_03 — fix invalid ci.yml YAML structure

## Что найдено
- `ci.yml` не парсился как YAML.
- Падение подтверждено прямым аудитом файла и проверкой
  `yaml.safe_load()`.

## Root cause
- Несколько step-блоков потеряли вложенность под
  `jobs.canon.steps`.
- Из-за этого элементы `- name:` начинались с колонки 1 и ломали
  структуру workflow.

## Что исправлено
- Восстановлена корректная вложенность всех повреждённых шагов.
- Сохранены `continue-on-error`, `if: always()`, gate summary и
  upload artifacts.
- Блоки shell-команд разложены так, чтобы YAML читался стабильно.

## Локальная проверка
- `python -c "import yaml; yaml.safe_load(open('ci.yml').read())"`
  проходит.
- Полный зелёный CI не заявляется без нового `logs_*.zip`.
