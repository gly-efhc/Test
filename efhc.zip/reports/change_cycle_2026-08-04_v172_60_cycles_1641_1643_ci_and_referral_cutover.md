# v172.60 — исправление CI циклов 1641–1642 и цикл 1643

## Основание

Fresh main CI run `30864230797` проверил exact v172.59. Alembic,
PostgreSQL diagnostic, compileall, Flake8 и frontend production build прошли.
Не прошли Ruff, Mypy, Bandit и pytest. Pytest завершился результатом
`37 failed, 3206 passed, 28 skipped`.

## Первый causal failure

`tests/conftest.py` очищал все таблицы PostgreSQL через TRUNCATE после
миграции и удалял обязательную singleton-строку
`efhc_core.identity_migration_control`. Новый write-side boundary корректно
отказывался работать без control row, поэтому одна ошибка test
infrastructure каскадно сломала transactions, panels, withdrawals,
payment intents и referral tests.

Исправление выполнено в test fixture: после TRUNCATE singleton
восстанавливается в подготовительном состоянии. Production resolver не
создаёт строку автоматически и его safety semantics не ослаблены.

## Остальные исправленные ошибки CI

- исправлен порядок импортов и SIM117 в пяти местах Ruff;
- словарь параметров transaction UPDATE аннотирован как `dict[str, object]`;
- dynamic SQL withdrawal lookup заменён фиксированными parameterized SQL;
- англоязычный новый комментарий и текст отчёта переведены;
- возвращён второй `_find_log_by_idk` после owner lock для concurrency;
- существующие guards обновлены без изменения их бизнес-смысла.

## Цикл 1643

Referral activation и rewards разрешают владельца по canonical `global_id`.
Legacy `global_id` используется только для исторических ReferralLink, где shadow
`global_id` ещё NULL. Новые reward credits выполняются по inviter global_id.

Identifier-coupled keys нормализованы:

- `REF_ACT_UNIT:G##########`;
- `REF_LVL:G##########:<level>`;
- `exchange:G##########:<digest>`.

Перед выбором нового ключа выполняется read-through canonical и legacy key.
При `legacy_authoritative=TRUE` новая операция сохраняет legacy key для
совместимости. После cutover автоматически выбирается canonical key. Уже
существующий исторический ключ всегда переиспользуется, поэтому смена
selector не создаёт повторную выплату.

## Ограничения

- production cutover flags не переключались;
- старые aliases не удалялись до циклов 1646–1647;
- Admin, public UI, screenshots и GitHub workflows не изменялись;
- PostgreSQL и полный static toolchain должны подтвердиться exact-head CI.
