# Cycle 1559 — Profile, Wallet, History, FAQ and 13 languages

Status: `DONE LOCALLY`.

## MVP scenario

The cycle repairs the complete account-information route:

`Profile -> Wallet -> financial History -> withdrawal History -> FAQ`.

## Root causes

- `/web-profile` mounted three competing account interfaces.
- Wallet and both histories did not share one typed query layer.
- History pagination was managed manually in the page.
- Earlier visual checks concentrated on one smartphone width.
- A screenshot report was not treated as a required cycle output.

## Implementation

- Added Zod wallet and history response validation.
- Added dedicated React Query hooks and query keys.
- Preserved primary-wallet and wallet-removal actions.
- Replaced manual history cursor accumulation with infinite queries.
- Removed two legacy visual layers from the active route while retaining
  their source files and replacement mapping.
- Added responsive rules for narrow Android, standard phones, large phones
  and tablet/PWA widths.
- Kept FAQ as a full vertical tree.

## Browser evidence

Responsive matrix:

- Profile: `360x800`;
- Wallet: `390x844`;
- History and withdrawals: `430x932`;
- Profile tablet: `768x1024`;
- FAQ: `390x844`.

All five checks passed without horizontal overflow, blank content or a
visible splash.

Language matrix:

- Profile and FAQ passed in all thirteen canonical languages;
- total checks: `26 / 26`;
- screenshots: `26` language screenshots plus `5` responsive screenshots.

## Regression and build

- Exact pytest inventory: `2399` unique nodes;
- passed: `2271`;
- skipped: `128` existing environment-gated nodes;
- failed: `0`;
- omitted: `0`.

Frontend production build and typecheck are verified separately in the
cycle closure record.

## Protected canon

No economy, balance formula, referral rule, wallet proof, TonConnect,
payment-intent, withdraw-processing, authentication, DB schema or Alembic
canon changed.

## Unverified external status

Fresh GitHub CI, live Telegram, real TonConnect, real PostgreSQL concurrency,
release-ready and production-ready status are not claimed.
