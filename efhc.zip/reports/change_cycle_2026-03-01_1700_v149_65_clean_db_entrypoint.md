# Change report v149_65_clean_db_entrypoint

SSOT inputs:
- HEAD: EFHC_Bot_v149_64_inventory_fix_alembic_0001.zip
- LOGS: none (code-only refactor per user request)

Changes:
- backend/app/main.py: migrate DB import to database_core
- backend/app/deps.py: use database_core get_session_factory
- scheduler modules: use database_core, no app.database
- services/nft_check_service.py: use database_core
- backend/app/database.py: deprecated shim to database_core

Notes:
- SQLite/offline path removed from entrypoint usage
- Compileall: PASS on this build

