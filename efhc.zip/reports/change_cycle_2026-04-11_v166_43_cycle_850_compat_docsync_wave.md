# Change report — v166_43 — cycle 850 compatibility and doc-sync wave

Date: 2026-04-11

## Scope
- Continue only the active cycle 850 residual tail from fresh GitHub CI logs.
- Sandboxes were opened in the environment and treated as donor/reference
  layer only; no blind transplant into HEAD was performed in this pass.

## Confirmed fixes in this pass
- fixed the remaining swapped guard reason in
  `backend/app/services/payment_reconciliation_service.py`
- restored watcher compatibility markers expected by architecture guards:
  `_RE_INTENT` alias and `deposit_efhc_confirm` marker
- added jetton memo fallback in `watcher_service.py` so strict USDT master
  still accepts legacy substring payload format when full envelope is absent
- added legacy shop-order compatibility fallback for empty `extra` snapshot
  in `payment_reconciliation_service.py`
- fixed admin bank frontend type drift by using the canonical
  `efhc_main` field only
- synchronized migration-count docs and migration-plan JSON to the current
  36-table SSOT
- regenerated route inventory freeze CSV/markdown to the current 95-route SSOT
- removed remaining banned rank substrings from active docs

## Local narrow checks
- `python -m py_compile` passed for touched backend files
- `npx tsc --noEmit --pretty false` passed in `frontend/`
- targeted guard subset passed locally:
  - no banned rank terms
  - no legacy rank words
  - route inventory freeze sync
  - migration count doc sync
  - migration invariants count sync
  - watcher payment-intent payload marker sync

## Honest note
- This pass does not claim green GitHub CI.
- Cycle 850 remains the active verification tail until a fresh GitHub CI run
  confirms the remaining runtime/test residuals.
