# REPORTS

Статус: **ACTIVE + IMMUTABLE HISTORY**

- `reports/current/` — текущие machine/readable evidence и состояние цикла.
- `reports/numbered/` — immutable последовательность `reports_NNNNN`.
- `reports/manifests/` — manifests нумерации и архивной истории.
- `reports/generated/` — воспроизводимые технические результаты инструментов.

Закрытые numbered reports не переносятся в отдельную «мусорную» папку и не
перезаписываются. Исторические reports не являются active SSOT/CANON.
