# v166_99 — cycle 887 — multilingual moderation path

## What was found
- the main Tier 1 trust-sensitive gap remained in user-facing moderation comments and notification prefixes;
- frontend i18n already existed, but moderation outcome content still depended on Russian-only backend wording;
- the user approved the architecture `locale-aware templates in system_templates + backend language selection`, with fixed UI i18n keys only for shell/fallback.

## What changed
- tasks moderation backend now resolves user language from `efhc_core.users.meta` when available;
- template lookup now supports locale-aware keys like `task_reject_fallback.en` and `task_approve_prefix.uk`;
- fallback chain is: exact locale -> Russian locale variant -> base key -> built-in canonical default;
- migration seed `0001_init.py` now inserts locale-aware moderation template variants for all 13 supported languages;
- admin templates page now explains locale-aware key syntax to operators/admins.

## Result
The moderation path now has a controlled multilingual architecture that is editable through `system_templates` and selected in backend logic, instead of a Russian-only hardcoded backend prefix path.
