# Change cycle report — v169.94 / cycles 1415-1416

## Summary

The supplied CI log archive was read first. The failing gates were ruff full
report and pytest. The repair pass fixes the exact logged failures without
removing, archiving, skipping, xfail-ing or hiding tests.

## Fixed from logs

- Ruff `SIM102` in `backend/migrations/versions/0001_initial_release_schema.py`.
- Filename/content hygiene drift from numbered work-pass labels.
- Stale GlobalHeader balance aria guard after i18n localization.
- Line-length 72 violations in backend and ops sources.
- Stale withdraw road/core guards after atomic no-commit hold repair.
- Failed-hold runtime invariant now matches atomic no-persist behavior.
- Healer atlas enum drift.
- Canon-guard terminology violation.

## Modified files

- `backend/migrations/versions/0001_initial_release_schema.py`
- `backend/app/crud/referrals_crud.py`
- `backend/app/services/exchange_service.py`
- `backend/app/services/transactions_service.py`
- `backend/app/services/efhc_deposits_service.py`
- `ops/operator_kernel/file_map.py`
- `ops/i18n/locale_quality_allowlist.py`
- `ops/routes/check_withdraw_road.py`
- `tests/architecture/test_energy_header_balance_boundary.py`
- `tests/architecture/test_withdraw_runtime_invariants.py`
- `tests/core/test_core_math_econ.py`
- `atlas.json`
- healer/backend/frontend documentation files affected by hygiene/canon drift

## Checks

- Targeted logged pytest: `7 passed, 3 warnings`.
- Ruff full report: `All checks passed`.
- Py compile: passed for modified Python files.
- ZIP `testzip`: `None`.

## Non-claims

No GitHub CI green, full pytest green, frontend build, release-ready,
screenshots, live Telegram proof or real wallet proof is claimed.
