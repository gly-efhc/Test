# Change report — v168_47 — Docker history runtime fix

## HEAD

Base archive:
`EFHC_Bot_v168_46_cycle_1262_docker_known_good_rollback.zip`.

## User input

The user provided Docker history showing the real runtime failure after
Docker startup.

## Root cause

The previous npm-ci diagnosis was incomplete. The history shows backend
health checks returning `200 OK`, then runtime requests fail because the
asyncpg DB connection receives unsupported `sslmode`.

## Code changes

- `backend/app/core/database_core.py`
  - Added `_normalise_asyncpg_connect`.
  - Strips `sslmode` from asyncpg DSN.
  - Maps SSL-required modes to `connect_args={"ssl": True}`.
- `backend/app/core/config_core.py`
  - Removed local async default `?sslmode=disable`.
- `docker-compose.yml`
  - Removed local async `?sslmode=disable`.
- `ops/docker/docker-compose.yml`
  - Removed local async `?sslmode=disable` and fixed multiline DSN.
- `env.docker.example`
  - Removed local async `?sslmode=disable`.
- `env.local.example`
  - Removed local async `?sslmode=disable`.

## Tests

- Added `test_docker_asyncpg_sslmode_guard.py`.
- Targeted Docker/asyncpg guards passed.
- Ruff passed.
- Compileall passed.

## Non-claims

Docker runtime was not executed in this environment.
GitHub CI was not executed by the assistant.
