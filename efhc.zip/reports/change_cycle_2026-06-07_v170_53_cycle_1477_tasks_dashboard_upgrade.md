# Change cycle 2026-06-07 — v170.53 — cycle 1477

## Cycle

`1477 — Tasks Dashboard Upgrade`

## Summary

The public `/tasks` route now includes an EFHC-owned progress-based
Tasks dashboard. It summarizes the existing task catalog and current
user task statuses as raw + derived snapshot data.

## Changed

- Added `TasksDashboardRuntime.tsx`.
- Integrated the dashboard into `frontend/src/pages/tasks.tsx`.
- Added task dashboard locale keys to all active locale JSON files.
- Added CSS for mobile-safe task dashboard cards.
- Fixed a residual duplicate unit render in `SimHeroEnergyCard`.

## Boundaries

- No backend change.
- No economy change.
- No OpenAPI change.
- No dependency or lock file change.
- No new public task history/log route.
- No public execution log, idempotency/debug data or admin trace.
- No Grafana or Песочница runtime code copied.
