# v153_05 — FAQ localized shell and Profile FAQ sync

Date: 2026-03-07
Archive base: v153_04
New archive: v153_05

## Scope

Feature cycle only.
No new `logs_*.zip` for this archive.
No claims about green CI.

## What was changed

1. FAQ page chrome was localized through locale dictionaries for all
   13 bot languages.
2. FAQ page labels were moved away from hardcoded English strings.
3. Search now has localized placeholder and localized empty state.
4. Profile / Settings -> FAQ block now uses real FAQ data instead of
   hardcoded demo questions.
5. Profile FAQ block now opens wallet and balance-history entry points
   directly through FAQ deep links.
6. FAQ search scoring now supports `keywords` for future language-aware
   indexing.
7. FAQ helpers were added for preview cards and related questions.

## Local checks

- `python ops/canon_guard.py` -> OK
- `frontend: npx tsc --noEmit` -> NOT CONFIRMED IN ENVIRONMENT
  because frontend dependencies are not installed in this local
  container image and TypeScript stops on missing React / Next modules

## Notes

This cycle strengthens the FAQ foundation for the next step:
full per-language FAQ content translation for all 13 languages.
