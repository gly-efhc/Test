# Change report v149_67

SSOT:
- HEAD: EFHC_Bot_v149_66_fix_0001_pg_only_sqlite_purge_econ_tests.zip
- LOGS: logs_58970975145.zip

## Fixed
- backend/migrations/env.py:
  - removed sqlite fallback for SYNC_DATABASE_URL
  - require SYNC_DATABASE_URL or DATABASE_URL
  - removed startswith("sqlite") checks
  - updated comments to 2 schemas (efhc_core, efhc_admin)
- backend/migrations/versions/0001_init.py:
  - fixed alembic logging: impl.stdout -> sys.stdout

## Registry
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md:
  - added AE entry for impl.stdout AttributeError
