# Change cycle — 2026-03-07 15:15 — v152_30

## Source of truth
- HEAD ZIP: `EFHC_Bot_v152_29_runtime_pytest_startup_sync.zip`
- User-approved TЗ for referrals page in this chat
- Canon checks kept under control:
  - tg_id only
  - bank → user bonus flow
  - Telegram-native frontend style
  - Energy progress bar reuse

## What was implemented
1. New user route `GET /referrals/stats`.
2. New frontend main page `/referrals` per TЗ.
3. New separate pages:
   - `/referrals/active`
   - `/referrals/inactive`
4. New runtime test proving referral level bonus goes automatically
   from bank to user bonus balance on level reach.

## Backend changes
- Added `ReferralPageStats` and
  `get_referrals_page_stats(...)` in
  `backend/app/services/referral_service.py`.
- Added aggregation of referral totals from canonical bank log
  `efhc_core.efhc_transfers_log` by reasons:
  - `referral_active_unit`
  - `referral_level_bonus`
- Added `GET /referrals/stats` in
  `backend/app/routes/referrals_routes.py`.

## Frontend changes
- Rebuilt `/referrals` as Telegram-native page with:
  - bonus balance
  - referral bonuses total
  - referral link
  - share buttons
  - FAQ link
  - current referral level
  - Energy-style progress bar
  - buttons to active/inactive pages
- Added separate list pages for active/inactive referrals.
- Kept list rows minimal by TЗ:
  - `@username` or `TG <id>`
  - status only
- Updated bottom nav highlighting so `/referrals/*` keeps the
  referrals tab active.
- Added a minimal `/faq` placeholder route to avoid dead link.

## Verification performed locally
- `python -m compileall backend/app` → pass
- `ruff check backend/app/routes/referrals_routes.py \
  backend/app/services/referral_service.py \
  tests/architecture/test_referral_level_bonus_runtime.py` → pass
- `pytest -q tests/architecture/test_referral_level_bonus_runtime.py` →
  skipped locally because Postgres test DB URL was not provided in this
  environment
- `pytest -q tests/architecture/test_no_tg_id_aliases_repo.py \
  tests/architecture/test_great_canon_guard.py` → pass

## Audit conclusion on the bonus condition
Confirmed by code path:
- trigger: `on_user_first_panel_purchase(...)`
- level sync: `_sync_inviter_level_rewards(...)`
- money move: `credit_user_bonus_from_bank(...)`
- reason: `referral_level_bonus`
- idempotency: `REF_LVL:<tg_id>:<level>`

This matches the required condition:
referral level bonus is credited automatically from BANK_EFHC to the
user bonus balance when the level threshold is reached.

## Limits
- No claim of green GitHub CI for this archive until a new
  `logs_*.zip` is provided.
- Frontend was changed carefully by source audit, but full Next build was
  not run in this environment.
