# Change cycle 2026-03-01_1010 — v149_40_fix_alembic_import_routes_46_50

## Summary
- CI(Actions): fixed Alembic failure `ModuleNotFoundError: No module named 'backend'` by making `app.models` self-contained (no `backend.*` imports).
- Routes #46–#50: passports/tables/evidence synced in `SSOT_ROUTE_TABLE_MAP.csv`.
- /api/v1/me: ensured persistence for new user creation and VIP sync (commit).
- Deposit packages: removed dependency on non-ORM `efhc_admin.efhc_sale_packages`; now reads from ORM `efhc_core.shop_items`.
- Payment intents: still uses `efhc_core.payment_intents` (raw SQL). Marked as P0 `NEED_ORM_MODEL_PAYMENT_INTENTS` for future harmony with 0001/ORM-31.

## Files changed
- backend/app/models/__init__.py
- backend/app/crud/user_crud.py
- backend/app/routes/me_routes.py
- backend/app/routes/deposit_routes.py
- backend/app/services/payment_intents_service.py
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- reports/change_cycle_2026-03-01_1010_v149_40_fix_alembic_import_routes_46_50.md
- reports/REPORTS_INDEX.md

## Notes
- Cache cleaned before packaging (no __pycache__/pyc/.pytest_cache/node_modules/.next).
