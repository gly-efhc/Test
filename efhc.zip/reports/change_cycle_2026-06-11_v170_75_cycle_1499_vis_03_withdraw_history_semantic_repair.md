# Change report — v170.75 / work item 1499

## Title

VIS-03 Withdraw History Semantic Repair / Final Range Cleanup

## Input

- `EFHC_Bot_v170_74_cycle_1498_ci_log_repair_public_dashboard_i18n_hardening.zip`
- `logs_73559592200.zip`

## Summary

VIS-03 is closed for the public withdraw history surface. The history row now
renders a localized semantic balance label through `balanceTypeLabel(...)` and
carries guard markers proving that raw balance type values are hidden from the
public UI.

The uploaded logs are green and are recorded as input-line CI proof. New GitHub
CI green for v170.75 is not claimed until CI is rerun on v170.75.

## Changed files

- `frontend/src/pages/withdraw.tsx`
- `docs/NORM/VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md`
- `docs/NORM/VIS_03_WITHDRAW_HISTORY_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1499_VIS_03_WITHDRAW_HISTORY_SEMANTIC_REPAIR.md`
- `reports/generated/vis_03_withdraw_history_semantic_repair_v170_75.json`
- `reports/generated/green_ci_log_proof_v170_75.json`
- `tests/architecture/test_vis_03_withdraw_history_semantic_repair.py`
- Kernel/map/manifest/report index files

## Boundaries

No backend write-flow, money-flow, economy, migration, OpenAPI route set,
dependency, lock file or CI/workflow change.
