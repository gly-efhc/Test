# Change report v150_40

## Added
- backend/app/services/facade.py
- backend/app/schemas/facade.py
- audits/FACADE_AUDIT_v150_40.md

## Updated
- docs/EFHC_CANON.md (facade rules)

## Notes
- __init__.py в services/schemas остаются без агрегации импортов.
