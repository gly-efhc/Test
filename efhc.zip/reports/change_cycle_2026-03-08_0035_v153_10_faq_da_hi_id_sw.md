# Change Cycle — 2026-03-08 00:35 — v153_10

## Scope
- continued FAQ multilingual rollout on top of v153_09
- extended item-level translations for the remaining 4 bot
  languages in the critical FAQ blocks
- preserved existing FAQ search and EN fallback behaviour

## Changed
- added item-level FAQ translations for:
  - da
  - hi
  - id
  - sw
- kept coverage focused on the critical FAQ subsections:
  - 5.1 Profile / Settings
  - 6.1 Wallet
  - 7.1 Balance types
  - 7.2 Full cycle
  - 14.1 Exchange
  - 14.2 Withdraw

## Validation
- local `python ops/canon_guard.py` -> OK
- targeted TypeScript compile of FAQ data layer -> OK
- line72 check for changed file -> OK

## Notes
- no fresh `logs_*.zip` was provided for this cycle
- full green CI is not claimed
