# Change report v151_05

## Fixed (from logs_59326940696.zip)
- CI: mypy cache no longer pollutes repo scan tests.
- Tests: legacy-word and banned-rank-term guards ignore .mypy_cache.
- Migrations smoke test: Alembic script_location now absolute to
  backend/migrations.

## Files changed
- ci.yml
- tests/efhc_backend/unit/test_no_legacy_words.py
- tests/architecture/test_no_banned_rank_terms.py
- tests/test_migrations_upgrade_head.py
