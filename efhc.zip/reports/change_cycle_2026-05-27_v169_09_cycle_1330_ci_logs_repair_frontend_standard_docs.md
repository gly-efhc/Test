# Change report — v169_09 / cycle 1330

## Cycle

`1330 — CI logs repair and frontend code standard actualization`

## Input

- HEAD: `EFHC_Bot_v169_08_cycle_1329_audit_repair_security_admin_guard.zip`
- Log: `logs_70999423442.zip`

## Confirmed errors

`pytest -q` failed with 3 confirmed failures:

1. Docker frontend npm-ci guard missed stable registry / npm flags.
2. Docker frontend npm-ci guard missed npm noise-disabling env vars.
3. Line72 guard found 14 lines above 72 characters.

## Fixed

- `ops/docker/Dockerfile.frontend` restored stable npm registry and flags.
- Backend/frontend line72 violations fixed.
- Active frontend standard docs updated to target:
  Next.js 16.2.6 / React 19.2.6 / Tailwind CSS v4.3.
- Added migration plan document.
- Shifted planned Shop cycle to 1331.

## Migration status

Dependency migration has not started. It remains a separate controlled
migration pass.
