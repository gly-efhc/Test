# v167_35 — cycle 946 — controlled EFHC deposits release decision

## Scope
- Source HEAD: `EFHC_Bot_v167_34_cycle_945_admin_bank_payment_user_history_consistency.zip`
- Fresh GitHub logs: `logs_65123263601.zip` (green; no new repair wave opened)
- Cycle: 946

## What was found
- Fresh GitHub logs are green and do not justify a new repair wave.
- `/admin/efhc-deposits` was already marked as controlled, but the project still lacked one explicit SSOT boundary that states the module is operator-assisted, non-core, and excluded from unconditional full public release claims.

## What was changed
- Added `docs/SSOT/EFHC_DEPOSITS_RELEASE_BOUNDARY_SSOT.md`.
- Updated `docs/SSOT/SSOT_INDEX.md` and `docs/AI/AI_DOCS_INDEX.md` so the new release boundary becomes part of the active control layer.
- Strengthened `release_gate_note` in `backend/app/routes/admin_routes.py`.
- Tightened admin/operator wording in `frontend/src/pages/admin/efhc-deposits.tsx`, `frontend/src/pages/admin/diagnostics.tsx`, and admin locale notes so the module is explicitly shown as `controlled_mode` / `manual_operator_assisted` and not as production-grade automation.
- Synced cycle docs, reports index and Q&A register.

## Decision
- `EFHC deposits` remains `controlled_mode`.
- Automation remains `manual_operator_assisted`.
- The module is useful for operators, but it stays `non_core` and is excluded from unconditional full public release claims.
- Cycle 947 is reserved for boundary implementation consistency, not for feature inflation.

## Verification
- Green GitHub logs acknowledged as evidence that no fresh repair wave is needed.
- `python -m compileall backend/app frontend/src`
- targeted grep/read-through on EFHC deposits boundary markers and docs sync

## Artifact
- `EFHC_Bot_v167_35_cycle_946_controlled_efhc_deposits_release_decision.zip`
