# Change report — v149_02_fix_required_tables_schema

Дата/время: 2026-02-28 00:00 (Europe/Uzhgorod)
База (откат): EFHC_Bot_v148_52_fix_alembic_column_schema_kw.zip
Логи CI: logs_58886229272.zip

## Что упало
- CI step: Sanity DB objects after alembic (core_admin)
- Симптом: required tables missing after alembic (to_regclass)

## Excerpt (1:1) из logs_58886229272.zip
```text
2026-02-28T10:02:32.1093805Z ERROR: required tables missing after alembic:
2026-02-28T10:02:32.1094361Z  - efhc_core.users
2026-02-28T10:02:32.1094744Z  - efhc_core.withdraw_requests
2026-02-28T10:02:32.1095187Z  - efhc_admin.efhc_sale_packages
2026-02-28T10:02:32.1324658Z ##[error]Process completed with exit code 2.
```

## Root cause
Часть таблиц в миграции 0001 создавались без явного schema=..., из-за чего они попадали не в efhc_core/efhc_admin (обычно в public).
Sanity-check ожидает наличие таблиц именно в схемах efhc_core/efhc_admin.

## Fix
1) В backend/migrations/versions/0001_init.py:
   - добавлено явное создание схем:
     - CREATE SCHEMA IF NOT EXISTS efhc_core
     - CREATE SCHEMA IF NOT EXISTS efhc_admin
   - добавлены schema=... в вызовы ensure_table_with_basics для таблиц:
     - efhc_core: users, payment_intents, wallet_bindings, panels, efhc_transfers_log, ton_inbox_logs, shop_orders, withdraw_requests
     - efhc_admin: efhc_sale_packages

## Verification (локально на распакованном ZIP)
- Repo-wide bans: PASS
- python -m compileall backend -q: PASS
(Дальше Alembic/pytest/npm build должен подтвердить CI.)

## Файлы изменены
- backend/migrations/versions/0001_init.py
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/change_cycle_2026-02-28_0000_v149_02_fix_required_tables_schema.md
- reports/REPORTS_INDEX.md
