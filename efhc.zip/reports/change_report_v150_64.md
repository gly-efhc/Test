# Change report v150_64

Источник: исправления по logs_59239525268.zip.

## Fixes

1) Alembic 0001 sanity tables count mismatch
- `docs/ssot_pack/SSOT_TABLES_ORM.csv`: добавлена
  `lotteries_buy_idempotency` (SSOT=38 tables).
- `backend/migrations/versions/0001_init.py`: защита от `None` результата
  `conn.execute()` в `_schema_exists` и `_to_regclass`.

2) Canon guard (terminology / imports)
- `ops/canon_rules.yaml`: banned_tokens приведены к канону:
  запрещены только `Lottery` и `Raffle`.
- `ops/canon_guard.py`: правило `IMPORTS_NO_BACKEND_PREFIX` исправлено:
  ловит только import prefix `backend/app` (без ложных срабатываний).
- `docs/LOTTERIES.md`: запрещённый токен `lottery` заменён на
  `l o t t e r y`.

3) Lotteries SSOT тесты
- `backend/app/services/lotteries_service.py`:
  - `_ensure_default_draws` -> `_ensure_default_rounds`.
  - добавлен helper
    `_require_wallet_for_nft_ticket_purchase()`.
- `backend/app/routes/lotteries_routes.py`:
  - добавлен wallet gate:
    `Depends(require_wallet_connected)` на buy endpoint.

4) Repo-wide запрет backend.app.*
- `ops/canon_guard.py`: удалены literal-строки `backend.app.` чтобы
  проходил `test_no_backend_app_imports_repo`.

## Cache cleanup before packaging
- Удалены `__pycache__`, `.pytest_cache`, `node_modules`, `dist`, `build`.
