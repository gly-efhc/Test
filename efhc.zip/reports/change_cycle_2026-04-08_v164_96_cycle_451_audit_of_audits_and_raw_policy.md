# Cycle 451

- Performed audit-of-audits for `docs/audits`.
- Separated active truth-layer from historical audit debt.
- Defined `_raw` as evidence archive rather than active daily working surface.
