# v152_24 — idempotency + background tasks runtime layer

Дата: 2026-03-06

## Что сделано

1. Убран raw `asyncio.create_task()` из активного кода:
   - `backend/app/routes/shop_routes.py`
   - `backend/app/services/scheduler_service.py`

2. Введены новые тесты:
   - `tests/architecture/test_no_raw_create_task.py`
   - `tests/architecture/test_route_idempotency_policy.py`
   - `tests/core/test_async_tasks.py`

3. Обновлены обзорные документы и каталог тестов под новый срез
   `tests/**`.

## Локальная проверка

- `pytest -q tests/architecture/test_no_raw_create_task.py`
- `pytest -q tests/architecture/test_route_idempotency_policy.py`
- `pytest -q tests/core/test_async_tasks.py`
- `pytest -q tests/architecture/test_max_line_length_72.py`

Результат: passed.

## Инварианты слоя

- raw `asyncio.create_task()` разрешён только в
  `backend/app/core/async_tasks.py`;
- write-routes класса `MUST` обязаны иметь
  `require_idempotency_key`;
- helper `create_logged_task()` обязан:
  - возвращать результат корутины;
  - логировать исключение;
  - не логировать отмену как ошибку.
