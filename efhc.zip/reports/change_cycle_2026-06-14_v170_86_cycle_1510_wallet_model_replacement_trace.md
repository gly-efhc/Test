# Change cycle 2026-06-14 — v170.86 — cycle 1510

## Cycle

1510 — Wallet Model Replacement Trace.

## Summary

Closed the audit tail asking which active code replaces the deleted
`backend/app/models/wallet_models.py`.

## Answer

The replacement is:

```text
backend/app/models/wallets_models.py::WalletBinding
```

Supporting active runtime pieces:

- `backend/app/lib/ton_address.py::canonicalize_ton_address`
- `backend/app/services/wallets_service.py`
- `backend/app/services/tonconnect_proof_service.py`
- `backend/app/routes/wallets_routes.py`
- `backend/app/crud/wallets_crud.py`

## Changed files

- `docs/NORM/WALLET_MODEL_REPLACEMENT_TRACE.md`
- `docs/cycles/WORK_CYCLES_1510_WALLET_MODEL_REPLACEMENT_TRACE.md`
- `reports/generated/wallet_model_replacement_trace_v170_86.json`
- `tests/architecture/test_wallet_model_replacement_trace.py`
- `KERNEL.md`
- `map_element.md`
- cycle/report/test guard indexes

## Boundary

No runtime behavior change was required.
No EFHC economy change was made.
No PACK-01 or PACK-02 canon was changed.
