# Change cycle — 2026-03-08 — v154_12

## Scope
Complete the last missing FAQ item-level overrides from the new
Russian source for `da`, `hi`, `id`, and `sw`.

## Confirmed input state
- No fresh `logs_*.zip` for this HEAD.
- Direct audit confirmed that
  `frontend/src/data/faq/localized.ts` still had empty FAQ blocks:
  `da: {}`, `hi: {}`, `id: {}`, `sw: {}`.
- That meant 4 languages still fell back to Russian FAQ text.

## Root cause
The Russian FAQ source had already been refactored, but the final
four languages had not yet received item-level overrides.

## Fix
- Added complete item-level FAQ overrides for:
  - `da`
  - `hi`
  - `id`
  - `sw`
- Total added FAQ item ids: 288.
- Fixed 3 line72 violations that appeared after inserting the new
  text blocks.

## Local checks
Passed locally:
- `tests/architecture/test_max_line_length_72.py`
- `tests/architecture/test_no_banned_rank_terms.py`
- `tests/efhc_backend/unit/test_no_legacy_words.py`
- `tests/test_no_placeholders.py`

## Result
All 12 non-RU languages now have item-level FAQ overrides based on
the new Russian source structure.

## Notes
- Full green CI is not claimed without a fresh `logs_*.zip`.
