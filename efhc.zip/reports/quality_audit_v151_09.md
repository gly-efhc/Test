# Quality audit v151_09
- Date: 2026-03-04T17:33:33.890125Z

## Ruff
- Before (from last green CI full report): 3763
- After this session (ruff check backend/api/ops/tests): 840
- Delta: -2923

Top remaining codes (after):
  8	SIM102	[ ] collapsible-if
  4	B007  	[ ] unused-loop-control-variable
  3	B023  	[ ] function-uses-loop-variable
  2	B017  	[ ] assert-raises-exception
  2	E101  	[ ] mixed-spaces-and-tabs
  1	B005  	[ ] strip-with-multi-characters
  1	B028  	[ ] no-explicit-stacklevel
  1	SIM105	[ ] suppressible-exception
  1	SIM113	[ ] enumerate-for-loop
  1	I001  	[*] unsorted-imports
  1	F811  	[ ] redefined-while-unused
  1	F821  	[ ] undefined-name
