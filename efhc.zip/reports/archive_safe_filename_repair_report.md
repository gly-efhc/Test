# Archive safe filename repair report

Дата: 2026-06-01.
База: `EFHC_Bot_v169_35_cycle_1356_admin_regression_proof_pass.zip`.

## Что исправлено

- Нормализованы только имена файлов в `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/`.
- Удалены только точные дубликаты `docs/NORM/CHAT_BRANCHES/21.md` и `docs/NORM/CHAT_BRANCHES/22.md`.
- Обновлены связанные индексы.
- Добавлен безопасный guard имён файлов.

## Что намеренно сохранено

- Версионные метки `v169_35`, `v169_34` и другие release labels в audit/report/test/cycle слоях.
- Описательные имена admin/audit/report/test файлов.
- Canonical chat filenames `docs/NORM/CHATS/21.md` и `docs/NORM/CHATS/22.md`.

## Переименовано в md: 15

- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/dopolnenie_k_tz_efhc_bot_v3_1_vosstanovlenie_poteryannyh_funkcii.md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_bot_tz_lost_functions_recovery.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/zhivye_tochki_samovosstanovleniya_ii_zashchit_v_nashem_tekushchem_sreze_2.md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/ai_self_recovery_protection_points.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├¡Γòñ├⌐Γò¿ΓûæΓòñ├⌐Γòñ├óΓòñ├╝Γòñ├» Γò¿ΓöÉΓò¿Γò¢Γò¿ΓòùΓòñ├«Γò¿ΓòûΓò¿Γò¢Γò¿ΓûôΓò¿ΓûæΓòñ├⌐Γò¿ΓòíΓò¿ΓòùΓò¿ΓòíΓò¿Γòú Γò¿Γûô EFHC Bot (2).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/user_statuses_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿Γò¢Γò¿ΓöÉΓò¿ΓòòΓòñ├╝Γò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿ΓûÆΓò¿ΓûæΓò¿Γò£Γò¿ΓòæΓò¿Γûæ_EFHC_Energy_for_Humanity_Coin (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_bank_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿Γò¢Γò¿ΓöÉΓò¿ΓòòΓòñ├╝Γò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γòñ├¬Γò¿ΓòæΓò¿ΓûæΓò¿Γòù_Γò¿ΓöñΓò¿Γò¢Γòñ├╝Γòñ├⌐Γò¿ΓòòΓò¿ΓòóΓò¿ΓòíΓò¿Γò£Γò¿ΓòòΓò¿Γòú_EFHC_Bot (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/achievement_scales_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿Γò¢Γò¿ΓöÉΓò¿ΓòòΓòñ├╝Γò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γòñ├╝Γò¿ΓòòΓòñ├╝Γòñ├⌐Γò¿ΓòíΓò¿Γò¥Γòñ├»_Γò¿ΓûÆΓò¿Γò¢Γò¿Γò£Γòñ├óΓòñ├╝Γò¿Γò¢Γò¿Γûô_EFHC_Bot (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/bonus_system_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γö¼┬╜Γò¿├íΓò¿ΓòíΓò¿ΓòúΓòñ├⌐Γò¿ΓòòΓò¿Γò£Γò¿Γöé_RatingΓö¼Γòù (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/rating_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γö¼┬╜Γò¿├íΓò¿ΓòíΓòñ├ñΓò¿ΓòíΓòñ├çΓò¿ΓûæΓò¿ΓòùΓòñ├»_ReferralsΓö¼Γòù (2).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/referrals_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γö¼┬╜Γò¿├┤Γò¿ΓòùΓò¿ΓûæΓò¿ΓûôΓò¿Γò£Γò¿ΓûæΓòñ├à_DashboardΓö¼Γòù (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/dashboard_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γö¼┬╜Γò¿┬úΓò¿ΓûæΓò¿ΓöéΓò¿ΓûæΓò¿ΓòûΓò¿ΓòòΓò¿Γò£_ShopΓö¼Γòù (2).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/shop_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├ëΓò¿ΓöñΓò¿Γò¥Γò¿ΓòòΓò¿Γò£_Γò¿ΓöÉΓò¿ΓûæΓò¿Γò£Γò¿ΓòíΓò¿ΓòùΓòñ├«_EFHC_Bot (2).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/admin_panel_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/Γò¿╞ÆΓòñ├çΓò¿Γò¢Γò¿ΓòíΓò¿ΓòæΓòñ├⌐ EFHC ╬ô├ç├╢ Energy for Humanity Coin (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/efhc_project_overview.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/╬ô├£├¡_Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γò¿ΓéºΓò¿ΓûÆΓò¿Γò¥Γò¿ΓòíΓò¿Γò£_Exchange_╬ô├ç├╢_EFHC_WebApp (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/exchange_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/╬ô├£├¡_Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γò¿├╣Γò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├à_Tasks_╬ô├ç├╢_EFHC_WebApp (1).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/tasks_page_tz.md`
- `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/╬ô├£├¡_Γò¿├│Γò¿ΓòíΓòñ├áΓò¿Γò£Γò¿ΓòòΓòñ├ºΓò¿ΓòíΓòñ├╝Γò¿ΓòæΓò¿Γò¢Γò¿Γòí_Γò¿ΓòûΓò¿ΓûæΓò¿ΓöñΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓò¿Γòí_Γò¿├¡Γòñ├⌐Γòñ├çΓò¿ΓûæΓò¿Γò£Γò¿ΓòòΓòñ├ÑΓò¿Γûæ_Γò¿╞ÆΓò¿ΓûæΓò¿Γò£Γò¿ΓòíΓò¿ΓòùΓò¿Γòò_Panels_╬ô├ç├╢_EFHC_WebApp (3).md` → `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/md/panels_page_tz.md`

## Удалены точные дубликаты: 2

- `docs/NORM/CHAT_BRANCHES/21.md`
- `docs/NORM/CHAT_BRANCHES/22.md`
