# Change report: v152_06 (Mypy cleanup, admin routes)

Source log (latest confirmed): logs_59488407043.zip

Scope (strict): remove mypy "valid-type" sources in admin routes.

Changes
- backend/app/routes/admin_referral_routes.py
  - Removed constr(...) annotations.
  - total_bonus_efhc and amount are now plain str with validators.
- backend/app/routes/admin_tasks_routes.py
  - Removed constr(...) optional fields in TaskUpdate.
  - title/kind now use Field(min_length/max_length).

Notes
- No DB schema changes.
- No route path/method changes.
- No economic rule changes.
