# EFHC Bot change report — v166_89_90 — cycles 877-878

## Scope
- Cycle 877 — Deposit Entry Consistency
- Cycle 878 — i18n key naming/style rules
- Strategic canon correction docs and 893-900 planning block

## Confirmed work
- Added shared launcher helper for canonical shop entry behavior.
- Unified Hub, DepositModal, ProfileModal route to launcher, Web-Profile shortcuts and shop-entry flow around one truth-path.
- Added SSOT for Telegram-first / one-profile / external economic sector.
- Added TZ correction audit doc.
- Added i18n key naming/style rules doc before rollout.
- Added plan block 893-900 into cycle control docs.

## Verification
- No new GitHub CI failures were provided for this pass.
- Local frontend type-check and selected pytest guards were run before zip.
