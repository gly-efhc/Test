# Change cycle — 2026-04-25 — v167_76

Cycle: 1009.
Range: 983-1022 manual localization repair.
Status: completed for cycle 1009 only.

## What changed

Cycle 1009 closed the first frontend hardcoded-string repair pass:

- migrated the highest-impact Withdraw page copy to locale-backed keys;
- migrated Exchange confirmation and next-step copy to locale keys;
- migrated ExchangePanel shared-widget labels to locale keys;
- migrated Panels activation-context copy to locale keys;
- migrated PanelsList shared-widget labels to locale keys;
- added the new keys to all 13 active EFHC Bot locale bundles;
- repaired remaining panel activation wording tails such as old buy-copy
  values in locale bundles;
- repaired a residual FAQ commerce-wording tail in RU/UK FAQ SSOT and
  regenerated runtime `frontend/src/data/faq/catalogs.ts`;
- refined the frontend hardcoded-string audit guard so i18n key literals
  are not counted as user-visible hardcoded strings;
- created `docs/audits/FRONTEND_HARDCODED_REPAIR_1009.md`.

## Checks actually run

Local helper checks only, not GitHub CI:

- `/usr/bin/python3 ops/i18n/audit__all__locale_parity.py`
- `/usr/bin/python3 ops/i18n/audit_frontend_hardcoded_strings.py`
- `/usr/bin/python3 ops/i18n/audit_notification_template_repair.py`
- `/usr/bin/python3 ops/i18n/audit_bot_texts_parity.py`
- `/usr/bin/python3 ops/i18n/audit_faq_localization_consistency.py`

An attempted local `npx --no-install tsc --noEmit` did not complete in
this sandbox and is not reported as proof.

No GitHub CI green claim is made in this report.

## Boundary

The localization range is not fully closed. Cycle 1010 remains next:
hardcoded frontend string repair pass 2. Remaining frontend hardcoded
copy candidates are not hidden or declared fixed without edits.
