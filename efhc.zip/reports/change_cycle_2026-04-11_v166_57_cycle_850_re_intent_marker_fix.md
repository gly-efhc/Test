# EFHC Bot — change report
## 2026-04-11 — v166_57 — cycle 850 `_RE_INTENT` marker fix

### What changed
- restored the literal `_RE_INTENT` compatibility marker in
  `watcher_service.py` after the previous `ruff --fix` pass collapsed the
  alias import and left the source-marker test failing.
- kept the watcher module lint-clean by importing
  `_RE_INTENT_SUBSTR`, assigning `_RE_INTENT = _RE_INTENT_SUBSTR`, and
  preserving `_CREDIT_ORIG`.

### Verification done locally
- `ruff check --select I,E402,F401,F821 backend/app/services/watcher_service.py`
- `python -m py_compile backend/app/services/watcher_service.py`
- grep confirmation for `_RE_INTENT` and `_CREDIT_ORIG`
- archive build without claiming GitHub CI green.

### Honesty boundary
- full GitHub CI was not run locally.
- final closure of cycle 850 still depends on the next GitHub CI log.
