# Change cycle v154_22 — admin dashboard panel/kWh/balance totals

## Что сделано
- В `/admin/reports/overview` добавлены агрегаты для админ-панели:
  - panels_total_bought
  - panels_total_active
  - panels_total_archived
  - panels_total_paid_efhc
  - users_total_generated_kwh
  - users_total_exchanged_kwh
  - users_total_main_efhc
  - users_total_bonus_efhc
- На `frontend/src/pages/admin/index.tsx` эти значения показаны отдельным
  списком в блоке Overview.
- Добавлен guard-тест на присутствие новых ключей overview.

## Локальные проверки
- `tests/architecture/test_admin_reports_overview_metrics.py` — passed
- `tests/architecture/test_max_line_length_72.py` — passed
- `py_compile backend/app/routes/admin_routes.py` — passed
