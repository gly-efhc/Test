# Change report — v165_61 — cycles 546-550 — web portal future entry wave 9

## Scope
- move the external page from a narrow storefront framing toward a fuller web portal framing;
- keep honest future-game-entry semantics without pretending the full standalone game already exists.

## Done
- bootstrap contract now exposes portal access model and future game entry state;
- external page is now framed as EFHC Web Portal;
- portal shell shows modules available now and future game-entry status.

## Not claimed
- no full standalone web game release;
- no GitHub CI proof.
