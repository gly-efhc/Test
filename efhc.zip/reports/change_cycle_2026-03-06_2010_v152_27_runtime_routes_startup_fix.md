# Change cycle: v152_27 runtime routes startup fix

Date: 2026-03-06
Source diagnostics:
- logs_59669787488.zip
- logs_59630336677.zip

## What fell
- Runtime diagnostic startup skipped route modules during import.
- Confirmed skipped modules in startup log:
  - panels_routes
  - shop_routes
  - lotteries_routes
  - tasks_routes
  - ads_routes
  - sync_routes
  - admin_shop_routes
  - admin_referral_routes

## Root cause
1. `etag` alias was imported by several route modules, but `app.deps`
   exported only `make_etag`.
2. `get_shop_service()` declared `db: AsyncSession` directly, without
   `Depends(get_db)`, which made FastAPI treat `AsyncSession` as a route
   field and fail startup for `shop_routes`.
3. `tasks_service.py` imported missing module
   `app.integrations.telegram_bot_api`.
4. `admin_shop_service.py` imported missing module
   `app.services.user_service`.
5. `sync_routes.py` used `Request | None` and `Response | None` in the
   route signature, which broke FastAPI field generation for startup.

## What changed
- Added backward-compatible `etag()` alias in `app.deps`.
- Re-exported `etag` through `app.core.deps`.
- Fixed `get_shop_service()` to use `Depends(get_db)`.
- Replaced missing `user_service` import in admin shop service with
  canonical lookup via `crud.user_crud.get_user_by_telegram()`.
- Added minimal import-safe `app.integrations.telegram_bot_api` adapter
  with `TelegramAPI.batch_is_user_subscribed()`.
- Fixed `sync_routes.py` request/response signature to canonical FastAPI
  injection.

## Local checks
- py_compile on all changed files: pass
- line72 on all changed files: pass
- compileall on backend/app after patch: pass

## Limits
- No claim of green CI and no claim of fully clean runtime startup
  without a new GitHub Actions diagnostic log for the new archive.
