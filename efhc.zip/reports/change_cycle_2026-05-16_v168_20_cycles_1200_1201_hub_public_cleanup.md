# Change report v168_20 cycles 1200-1201

## HEAD

Input HEAD:
`EFHC_Bot_v168_19_cycles_1198_1199_direct_deposit_repair.zip`.

Output archive:
`EFHC_Bot_v168_20_cycles_1200_1201_hub_public_cleanup.zip`.

## Main result

Cycle 1200 recorded the corrected bridge verdict: the 1176-1200 range is
not release-ready because imported visual blockers remain open.

Cycle 1201 repaired the public HUB surface.  The public `/hub` page now
shows only two approved actions:

1. Top up EFHC.
2. EFHC VIP NFT.

## Code changes

Changed:

- `frontend/src/features/hub/HubPage.tsx`;
- `frontend/src/pages/admin/diagnostics.tsx`;
- `frontend/public/locale/*.json`.

Added:

- `tests/architecture/test_hub_public_cleanup_guard.py`.

## Public HUB changes

Removed from the public HUB code path:

- `readShopLauncherTruth`;
- `SurfaceFactsStrip`;
- `TelegramSectionRow`;
- `TelegramStatusBadge`;
- readiness/product-state/canonical-center copy;
- extra FAQ/help and availability sections.

Preserved:

- internal EFHC handoff call;
- VIP URL `https://getgems.io/efhc-nft`;
- language-driven user labels.

## Admin diagnostics

Added a HUB / Storefront operator diagnostics block to
`/admin/diagnostics`.  Technical route and truth references are kept in
admin, not in the public HUB.

## Checks

- Source ZIP `unzip -t`: OK.
- Targeted pytest: 11 passed.
- TypeScript `npx tsc --noEmit`: OK.
- Next build: timeout during optimized production build.
- Result ZIP `unzip -t`: OK after archive build.

## Not claimed

- GitHub CI was not run.
- Full visual release readiness is not claimed.
- Browser-Shop layout cleanup remains open.
- Browser screenshot proof was not run.
