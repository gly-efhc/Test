# Change Report — v167_37 — Cycle 948

## Title
Admin action-chain audit pass for EFHC deposits automation-first contour.

## What was found
- The post-947 contour already had the required automation-first routes.
- The longest admin chain needed a clearer audit-first reading:
  runtime summary → replay → exception path only if unresolved → final result.
- Result-path semantics on the admin page were not explicit enough for a clean audit verdict.

## What was changed
- Added explicit audit-chain guidance to the admin EFHC deposits page.
- Added a final-result stat block and wording for replay/exception result interpretation.
- Added an architecture guard to keep the action-chain audit-first semantics stable.
- Synced AI/cycles/reports/Q&A control layer to the new HEAD and cycle status.

## Why
To prove that the new automation-first status from cycle 947 remains honest across the full operator chain without expanding the module into a new feature wave.

## Local checks
- pytest on architecture continuity/action-chain tests
- compileall for backend/app and frontend/src

## Archive note
Archive packed flat and cleaned from transient junk.
