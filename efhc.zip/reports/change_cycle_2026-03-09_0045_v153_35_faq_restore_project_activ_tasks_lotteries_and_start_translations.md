# v153_35 — FAQ restore: project, Activ, Tasks, lotteries, Ads

## Что сделано
- В `frontend/src/data/faq/ru.ts` возвращены и добавлены пользовательские
  FAQ-вопросы по блоку "О проекте", Activ-статусу, Tasks, лотереям,
  Ads, минимальному выводу и правилу 1 kWh = 1 EFHC.
- Добавлены точечные вопросы по VIP NFT и энергии/панелям.
- В `frontend/src/data/faq/localized.ts` начат перевод новых вопросов и
  ответов на EN и UA для ключевых новых id.

## Проверки
- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK
