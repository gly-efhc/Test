# Cycle 461

- Removed the user-approved archive basket from HEAD.
- Synced active audit/report docs so they no longer point to deleted artifact-basket paths.
