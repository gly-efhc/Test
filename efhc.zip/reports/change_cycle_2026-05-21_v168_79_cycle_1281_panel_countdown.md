# Change report — v168_79 / cycle 1281

## Cycle

1281 — panel countdown model audit.

## HEAD

`EFHC_Bot_v168_78_cycle_1280_panel_activation_cta.zip`.

## Что проверено

Проверен backend-алгоритм дат панели:

- создание панели;
- срок жизни 180 дней;
- `activated_at`;
- `expires_at`;
- active/archive фильтрация;
- `server_now_utc` в route response;
- frontend countdown source.

## Что исправлено

Backend route contract списка панелей усилен без миграции:

- `PanelItemOut.public_id`;
- `PanelItemOut.activated_at`;
- `list_user_panels()` отдаёт `activated_at` явно;
- frontend получил marker источника countdown.

## Что не менялось

Не менялись:

- БД;
- миграции;
- экономика панели;
- цена панели;
- списание EFHC;
- нижнее меню;
- admin routes.

## Проверки

- `check_frontend_routes.py`;
- `compileall`;
- targeted pytest guards;
- `tsc --noEmit`;
- JSON validation;
- `unzip -t` нового ZIP.

## Следующий цикл

1282 — panel countdown backend/source repair.
