# Change report — v168_89 — cycle 1291

Cycle: 1291 — Tasks earning module boundary  
Date: 2026-05-25  
HEAD: `EFHC_Bot_v168_88_cycle_1290_audit_tz_repair.zip`

## Purpose

Lock `/tasks` as a compact earning module for bonus EFHC actions.
The page must show what to do, what reward is earned, and the primary
user action. It must not become a public task history, backend log or
technical/debug screen.

## Code changes

- Updated `frontend/src/pages/tasks.tsx`.
- Removed public technical help block from the Tasks page.
- Removed `useTD` and `GameDetails` from Tasks.
- Added proof markers:
  - `data-tasks-earning-boundary="1291"`
  - `data-tasks-list-card-layout="compact"`
  - `data-task-card="earning"`
  - `data-task-reward="bonus-efhc"`
  - `data-task-action-row="primary"`
- Added action markers:
  - `data-task-action="watch-ad"`
  - `data-task-action="claim-bonus"`
- Added `aria-label` values to primary task action buttons.

## Documentation changes

- Updated Tasks rows in frontend matrix, screen registry and checklist.
- Updated cycle plan 1268-1320 and frontend implementation plan.
- Updated transcript, Q/A register, tests catalog, master index and
  reports index.
- Added cycle audit and generated JSON proof.

## Tests

Added:

- `tests/architecture/test_tasks_earning_boundary.py`

Scope:

- earning-card markers exist;
- reward/action markers exist;
- public task history/log/debug/idempotency text is not rendered;
- cycle documentation and report index record the boundary.

## Not claimed

- GitHub CI green is not claimed.
- Docker runtime smoke is not claimed.
- Browser screenshot proof is not claimed.
- npm build/typecheck is not claimed.
