# Change report — v168_45 — Docker frontend npm ci hardening

## Task

User reported that Docker does not work and pasted a build log.  Backend
finished, while frontend was left at `RUN npm ci`.

## Root cause classification

The provided fragment shows the frontend image stuck or failing during
frontend dependency installation.  It is not a backend build failure and
not a Telegram WebApp runtime failure.

## Code changes

- Updated `ops/docker/Dockerfile.frontend`.
- Added npm registry, retry and quiet deterministic install flags.
- Added Dockerfile guard:
  `tests/architecture/test_docker_frontend_npm_ci_guard.py`.

## Document changes

- Added `docs/audits/DOCKER_FRONTEND_NPM_CI_V168_45.md`.
- Added generated JSON report.
- Updated AI memory, cycles, Q/A register and reports index.

## Checks

- `pytest` targeted Dockerfile guard: 2 passed.
- `ruff check backend api ops tests`: passed.
- `compileall backend/app ops/routes tests/architecture`: passed.
- `npx tsc --noEmit --pretty false`: passed.
- ZIP integrity will be checked before delivery.

## Non-claims

Docker runtime proof is not claimed because Docker is not installed in
this assistant environment.  GitHub CI was not run by the assistant.
