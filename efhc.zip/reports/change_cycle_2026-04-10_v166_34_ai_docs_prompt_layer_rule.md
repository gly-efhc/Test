# change report — v166_34 — AI docs prompt-layer rule

## Done
- Added an explicit rule that `docs/AI/*` is the mandatory working prompt-layer and operational brain for EFHC Bot.
- Explicitly fixed that deviation from AI docs must be treated as process drift.

## Files
- docs/AI/AI_DOCS_INDEX.md
- docs/AI/AI_OPERATOR_RULES_EFHC.md
- docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md
- docs/audits/AI_DOCS_PROMPT_LAYER_RULE_2026_04_10.md
- docs/cycles/WORK_CYCLES.md
- reports/REPORTS_INDEX.md
