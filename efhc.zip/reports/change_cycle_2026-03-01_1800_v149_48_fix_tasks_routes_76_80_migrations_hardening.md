# Change Cycle — v149_48_fix_tasks_routes_76_80_migrations_hardening

## Scope
- Harden Alembic/0001 import stability (prevent повторяемые падения на импортах/Index(schema=...)).
- Close routes passports/tables for №76–№80 with evidence.
- Add missing ORM table required by code path: efhc_core.processed_external_events (webhook dedupe).
- Implement missing public tasks service functions used by routes/tasks_routes.py.

## Key changes
### Migrations / Alembic
- backend/migrations/versions/0001_init.py:
  - expected tables count now derived from SSOT_TABLES_ORM.csv if present (fallback: len(Base.metadata.tables)).
  - avoids ручной синхронизации "31/34/..." при добавлении ORM-таблиц.

### ORM / Models
- backend/app/models/__init__.py:
  - removed backend.app.models import strings → app.models (alembic cwd=backend compatibility).
- backend/app/models/tasks_models.py:
  - removed invalid Index(schema=...) kwarg.
- backend/app/models/external_events_models.py (new):
  - ProcessedExternalEvent → efhc_core.processed_external_events (required by external_event_dedupe_dep).

### Services
- backend/app/services/tasks_service.py:
  - added list_tasks_catalog, list_user_tasks, claim_task_reward (routes/tasks_routes.py depended on missing symbols).
  - monetary credit uses transactions_service (economic canon).
- backend/app/deps.py:
  - external_event_dedupe_dep now commits when insert occurs (write operation).

### SSOT
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv: filled routes №76–№80 (read/write/flags/evidence).
- docs/ssot_pack/SSOT_TABLES_ORM.csv: appended processed_external_events.
- docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv: appended processed_external_events.
- docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv: regenerated full joined matrix.

## Notes
- No CI status claims in this report (requires fresh logs_*.zip for v149_48).
