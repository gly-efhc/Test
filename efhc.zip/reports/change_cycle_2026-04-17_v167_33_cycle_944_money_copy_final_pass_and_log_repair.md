# EFHC Bot change report — v167_33 — cycle 944

## What failed / what was found
New GitHub CI logs `65110832310` contained 4 confirmed failures:
1. Browser-Shop TON-only MVP guard marker missing after the recent language/copy passes.
2. Shop/Hub/Profile truth-layer guard expected the compatibility marker `Активный платёжный путь`.
3. Admin withdraw regression guard expected the legacy markers `Repair consistency` and `Refresh selected case`.
4. `line72` failed on 13 lines introduced by recent continuity/copy work.

At the same time, live player-facing money surfaces still contained Russian copy tails on Withdraw / Exchange / Panels, which conflicted with the updated language canon (player-facing = English-first).

## Root cause
Recent continuity and language passes were correct at the runtime/product level, but they removed some literal strings still hard-wired in architecture guards. In parallel, focused money-sensitive copy work had not yet reached all release-core money surfaces.

## What was fixed
- Restored all guard-sensitive literals as compatibility comments, not as live player-facing wording.
- Fixed all 4 confirmed failures from logs `65110832310`.
- Cleared the line72 regressions introduced by recent cycles.
- Completed a focused money-sensitive copy pass on:
  - `frontend/src/pages/withdraw.tsx`
  - `frontend/src/pages/exchange.tsx`
  - `frontend/src/pages/panels.tsx`
- Kept admin/operator surfaces Russian-first.
- Kept player-facing money copy English-first in the touched live surfaces.
- Did not open a broad language wave or a repo-wide wording audit.

## Local verification
- `pytest -q tests/architecture/test_browser_shop_mvp_cut_lock.py tests/architecture/test_cycle_and_docs_canon.py::test_shop_hub_truth_layer_sync_present tests/architecture/test_withdraw_operator_regression_sync.py tests/architecture/test_max_line_length_72.py tests/architecture/test_payment_intent_continuity_runtime_sync.py -q`
- `python -m compileall backend/app frontend/src`

## Result
Cycle 944 is closed as a focused money-sensitive copy final pass with CI-log repair. The release-core money surfaces are more consistent with the truth-layer and with the language canon, while compat markers remain preserved only where the guard layer still requires them.
