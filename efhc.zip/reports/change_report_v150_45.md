# Change report v150_45

## Scope

- Canon: bank can be negative; emission only bank-only.
- Docs: update EFHC_CANON and exchange/withdraw SSOT.
- Security: admin whitelist only; remove virtual ROOT admin.
- Backend: remove bank non-negative stop-cran.
- Admin bank: double-check whitelist in mint/burn.

## Files changed

- docs/EFHC_CANON.md
- docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md
- docs/audits/AUD-2026-03-03-BANK-CANON-001.md
- backend/app/services/transactions_service.py
- backend/app/services/admin/admin_rbac.py
- backend/app/services/admin/admin_bank_service.py
- reports/CI_FIXES_INTERNAL_LOG.md
- reports/change_report_v150_45.md
