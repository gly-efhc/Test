# Change report — v170.81 / cycle 1505

Cycle: `1505 — GitHub CI Rerun Proof`.
Input: `EFHC_Bot_v170_80_cycle_1504_grafana_pattern_map_completion.zip`.
Output: `EFHC_Bot_v170_81_cycle_1505_github_ci_rerun_proof.zip`.
Log: `logs_73728142603.zip`.

## Summary

The provided GitHub CI log was red. The log was read first and the exact
failures were repaired without disabling tests or weakening guards.

## Repaired

- Ruff import-format failure in the orphan bank dashboard deletion guard.
- Admin route module canon updated for `admin_reports_routes.py`.
- Chat legacy guard anchor restored in `CHATS_INDEX.md`.
- Forbidden frontend `tsconfig.tsbuildinfo` artifact removed.
- Stale OpenAPI route-count guard updated to `130`.
- `_main_` dunder false positive removed from Python source while keeping
  runtime SQL alias semantics.
- Route inventory freeze markdown count updated to `130`.

## Non-claims

No GitHub CI green claim is made for the output archive. A new rerun is
required.
