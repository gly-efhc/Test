# Change report — v166_15 — cycle 806

Дата: 2026-04-10
HEAD before: EFHC_Bot_v166_14_cycles_801_805_shop_payments_ssot_baseline_wave.zip
HEAD after: EFHC_Bot_v166_15_cycle_806_direct_pending_alignment.zip

## Выполнено
- цикл 806: direct alignment of payment intent server state to strict `PENDING` under the new shop payments SSOT;
- `STATUS_SENT` left only as a legacy alias;
- deposit modal no longer forces a local `SENT` transition after TonConnect send.

## Проверки
- `python -m pytest -q tests/test_payment_intents_usdt_tx_and_confirm.py -q`
- `node` transpile check for `frontend/src/components/DepositModal.tsx`
- `python -m py_compile backend/app/services/payment_intents_service.py backend/app/schemas/payment_intents_schemas.py`

## Ограничение
- `tests/test_payment_intent_status_owner_only.py` could not be collected in this environment because `sqlalchemy` is missing here.
