# Change cycle — 2026-04-25 — v167_75

Cycles: 1007-1008.
Range: 983-1022 manual localization repair.
Status: completed for cycles 1007 and 1008 only.

## What changed

Cycle 1007 closed the notification/template manual repair pass:

- localized shop order Telegram payment success/error notifications
  across all 13 active EFHC Bot languages;
- added language resolution from order `extra` and user `meta`;
- kept unknown player language fallback as English;
- expanded withdraw outcome promo fallback buckets from 3 languages to
  all 13 active languages;
- verified task moderation template defaults across all 13 languages;
- added `ops/i18n/audit_notification_template_repair.py`;
- created notification template repair audit for cycle 1007.

Cycle 1008 closed the frontend hardcoded string audit pass:

- added `ops/i18n/audit_frontend_hardcoded_strings.py`;
- created `docs/audits/FRONTEND_HARDCODED_STRINGS_1008.md`;
- separated candidate hardcoded strings into admin/operator,
  player-facing and shared groups;
- documented false positives and the repair boundary for cycles
  1009-1010.

## Checks actually run

Local helper checks only, not GitHub CI:

- `python3 -S ops/i18n/audit_notification_template_repair.py`
- `python3 -S ops/i18n/audit_frontend_hardcoded_strings.py`
- `python3 -S ops/i18n/audit_notifications_templates_inventory.py`
- `python3 -S ops/i18n/audit_bot_texts_parity.py`
- AST parse check for changed backend Python files

No GitHub CI green claim is made in this report.

## Boundary

The localization range is not fully closed. Cycle 1009 remains next:
hardcoded frontend string repair pass 1. Cycles 1009-1022 remain planned
until confirmed by real work and their own reports.
