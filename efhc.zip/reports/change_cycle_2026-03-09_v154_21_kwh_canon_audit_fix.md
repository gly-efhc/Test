# v154_21 kWh canon audit fix

- Added audit AUD-2026-03-09-KWH-CANON-001 to docs/audits.
- Removed forbidden daily rates from sync_routes and sync snapshot.
- Removed daily fields from frontend snapshot hook.
- Clarified available_kwh as computed mirror only.
- Fixed admin panel limit to count only active panels.
- Added guard tests for banned daily generation tokens and
  active-only admin panel limit.
