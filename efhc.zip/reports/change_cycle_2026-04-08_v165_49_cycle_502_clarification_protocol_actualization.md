# Cycle 502 — Clarification protocol actualization

- Added explicit `Уточняющая итерация:` format to AI docs.
- Clarification mode is now fixed as a user-facing label for ambiguity-driven cases.
