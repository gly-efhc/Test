# Change report v150_63

Источник: исправления по logs_59239525268.zip.

## Fixes

1) Alembic 0001 sanity tables count mismatch
- Добавлена отсутствующая таблица `lotteries_buy_idempotency` в
  `docs/ssot_pack/SSOT_TABLES_ORM.csv`.
- Усилена защита `0001_init.py` от `None` результата `conn.execute()`.

2) Canon guard terminology / imports
- `ops/canon_rules.yaml`: banned_tokens приведены к канону: ban
  только `Lottery` и `Raffle` (разрешено `Lotteries`, `draw_id`).
- `ops/canon_guard.py`: правило `IMPORTS_NO_BACKEND_PREFIX` исправлено:
  теперь ловит только `backend.app.*`, не `app.*`.
- `docs/LOTTERIES.md`: запрещённый токен `lottery` заменён на
  `l o t t e r y` (без совпадения в guard).

3) Lotteries SSOT тесты
- `backend/app/services/lotteries_service.py`:
  - переименовано `_ensure_default_draws` -> `_ensure_default_rounds`.
  - добавлен helper
    `_require_wallet_for_nft_ticket_purchase()` (SSOT).
- `backend/app/routes/lotteries_routes.py`:
  - добавлен wallet-gate dependency
    `Depends(require_wallet_connected)` на buy.

## Cache cleanup before packaging
- Удалены `__pycache__`, `.pytest_cache`, `node_modules`, `dist`, `build`.
