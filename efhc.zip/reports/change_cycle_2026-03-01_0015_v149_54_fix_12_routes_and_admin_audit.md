# EFHC Change Report — v149_54 (fix 12 routes + audit logs)

## Цель цикла
Исправить 12 маршрутов из аудита и закрыть корневые причины их поломки:
- runtime import errors (nft/skins),
- неработающий админ-аудит (AdminLogger),
- отсутствие ORM-таблицы bank_balances (нарушение канона миграций/0001),
- SSOT evidence/table-map для указанных маршрутов.

## Исправления (факт)

### 1) /nft/has_vip (GET)
- backend/app/routes/nft_routes.py
  - исправлен импорт: использована каноничная функция `wallet_has_nft_in_collection`
  - в ответ добавлено поле `has_vip` (совместимость), `has_nft` сохранено

### 2) /skins/catalog (GET)
- backend/app/routes/skins_routes.py
  - исправлен импорт get_db: теперь используется `app.deps.get_db` (в app.database нет get_db)

### 3) Админ-аудит (AdminLogger) — “аудит аудитов”
- backend/app/services/admin/admin_logging.py
  - приведён к рабочему виду: методы реально находятся внутри `class AdminLogger`
  - исправлена схема/таблица: запись в `efhc_admin.admin_action_log`
  - best-effort стратегия: при проблемах FK повторная запись без admin_id с сохранением admin_id_raw в details_json

### 4) /admin/lotteries/nft-claims (GET)
- backend/app/routes/admin_routes.py
  - query-параметр `status_` заменён на `status` через alias (исправляет фактический контракт ручки)

### 5) /admin/lotteries/nft-claims/{claim_id}/mark-sent (POST)
- backend/app/routes/admin_routes.py
  - добавлен admin-аудит через AdminLogger.write (best-effort)
  - лог фиксирует переход pending -> approved + idempotency_key

### 6) /admin/lotteries/{lotteries_id}/auto-lotteries (POST)
- backend/app/routes/admin_routes.py
  - добавлен admin-аудит через AdminLogger.write (best-effort)
  - лог фиксирует enabled=true|false + idempotency_key

### 7) /admin/bank/* (GET/POST)
- backend/app/models/admin_models.py
  - добавлена ORM-таблица `efhc_admin.bank_balances` (BankBalanceRow)
  - закрыт класс ошибки “таблица используется сервисом, но не создаётся 0001”
- bank mint/burn используют AdminLogger (после фикса он работает)

### 8) Тайм-канон
- backend/app/routes/admin_routes.py
  - `reports_overview.ts` теперь tz-aware UTC: `datetime.now(timezone.utc)`

## SSOT обновления
- docs/ssot_pack/SSOT_ROUTES_NUMBERED.csv — обновлены line для 12 маршрутов
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv — заполнены read/write_tables + evidence
- docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv — синхронизировано с mapping + 0001-coverage
- docs/ssot_pack/SSOT_TABLES_ORM.csv — добавлена `efhc_admin.bank_balances`

## Примечание по реестру ошибок
EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md в этом цикле не обновлялся (нет нового logs_*.zip, только фиксы по аудиту).
