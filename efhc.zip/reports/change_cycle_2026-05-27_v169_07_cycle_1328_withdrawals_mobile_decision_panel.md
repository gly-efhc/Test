# Change Report — v169_07 / cycle 1328

Дата: 2026-05-27  
Архив: `EFHC_Bot_v169_07_cycle_1328_withdrawals_mobile_decision_panel.zip`

## Цикл

`1328 — Withdrawals operator decision template on shared UI Kit`

## Цель

Сделать Admin Withdrawals mobile-first интерактивной state-machine панелью,
используя Песочницу как donor-source и сохраняя экономический withdraw canon.

## Выполнено

- Открыт HEAD `v169_06`.
- Открыта `Песочница.xz`.
- Прочитаны AI/Admin/Frontend/Withdraw документы.
- Добавлен `AdminWithdrawalsMobileDecisionPanel`.
- `/admin/withdrawals` подключён к новой mobile-first панели.
- Верхний route diagnostics strip убран с рабочей поверхности withdrawals.
- Добавлены lanes: `PENDING / PAID / REJECTED / CANCELED / ERROR`.
- Добавлен VIP/all фильтр.
- Добавлен preview mode фильтр.
- Добавлены KPI-карточки, flow map, mobile decision deck, selected-case table.
- Зафиксирован ответ по public UI интерактивности в отдельном frontend backlog.
- Добавлен guard cycle 1328.

## Проверки

- ZIP input checked.
- Sandbox extracted and inspected.
- `python -m compileall -q backend` passed.
- Targeted architecture guards passed: cycle 1326, 1327, 1328.
- `npm ci --no-audit --no-fund --progress=false` passed.
- `npx tsc --noEmit` passed after dependency install.
- `npm run build` reached successful compile, then local environment failed at
  `Collecting page data` with `EPIPE`; full build is therefore not claimed green.

## Следующий цикл

`1329 — Shop admin actions and Web3 payment separation on UI Kit`
