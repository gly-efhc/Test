# Change report — v149_64 (inventory + logs fix)

SSOT inputs:
- HEAD: EFHC_Bot_v149_63_fix_0001_imports_metadata_guard.zip
- LOGS: logs_58966466620.zip

## Что упало (CI)
- Step: canon/13_Alembic upgrade head (Postgres-only)
- Ошибка: NameError: _backend_dir is not defined
- Файл: backend/migrations/versions/0001_init.py:35

## Root cause
Переменная `_backend_dir` использовалась до определения.

## Исправление
- backend/migrations/versions/0001_init.py
  - добавлен `_backend_dir = Path(__file__).resolve().parents[2]`
  - sys.path insert выполняется после определения переменной
  - поправлена функция чтения SSOT_TABLES_ORM (ровные отступы)

## Инвентаризация (аудит)
Добавлен аудит:
- docs/audits/2026-03-01_db-ssot_v149_64__tables_routes_
  schemas_inventory.md
Обновлён индекс:
- docs/audits/audits_index.json

Итог инвентаризации:
- схемы: efhc_core, efhc_admin
- ORM tables: 38
- SSOT tables: 38
- routes in SSOT: 91
- evidence_refs пустых: 0
- NEED_TRACE: 0
- NO_DB маршруты: 5 (health/cron/admin ads providers/nft/skins)

## Реестр ошибок
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
  - добавлен класс AF (NameError в 0001_init.py по CI logs)

## Упаковка
- новый ZIP: EFHC_Bot_v149_64_inventory_fix_alembic_0001.zip
- формат: FLAT
