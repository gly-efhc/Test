# Alias sanitation report v150_25

Источник: logs_59123718270.zip

## Итог

В этом цикле выполнена санация только по коду (не трогая
исторические логи и реестры).

### Заменено

- legacy telegram id aliases: 0
- legacy tg id camelcase aliases: 0
- legacy u-id aliases: 0
- legacy user id aliases: 0
- legacy rank terms: 0

Примечание: отчёт не содержит запрещённых токенов в исходном
виде, чтобы не ломать repo-wide bans. Исторические логи и
реестры в этом цикле не переписывались.
