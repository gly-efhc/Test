# v154_04 — locale + FAQ 13-language parity

## What was found

Direct audit of the current HEAD showed two confirmed localization gaps:

1. `frontend/public/locale/*.json`
   - missing keys versus `ru.json`
   - `en`: 13 missing
   - `ua`: 166 missing
   - `de/fr/es/it/tr/pl/da/hi/id/sw`: 171 missing each

2. `frontend/src/data/faq/localized.ts`
   - missing FAQ item overrides versus `ru.ts`
   - `en`: 39 missing leaf ids
   - `ua/de/fr/es`: depended on English fallback for part of the
     new FAQ content

## What was changed

### UI locale files

Filled all missing keys in every non-RU locale JSON.
Rule used:
- use `en.json` value if present
- otherwise use `ru.json`

This closed the runtime key gap for all 13 languages.

### FAQ localized overrides

Added the missing English FAQ overrides for:
- top bar
- panel price / start / lifetime / limit
- wallet primary / switch / unlink
- referral bonuses
- Activ status
- Lotteries
- Ads
- 12 progress levels
- FAQ usage help

Then mirrored the same new ids into:
- `ua`
- `de`
- `fr`
- `es`

via controlled clone from the English override set.

## Guard fixes during the cycle

After adding the FAQ block, local guard tests found:
- 1 line72 violation
- 2 banned legacy substring hits caused by the word pattern inside
  `generating`

These were fixed in the same cycle.

## Local evidence

Confirmed locally:
- all locale JSON files have full key parity with `ru.json`
- all FAQ languages have full leaf-id parity with `ru.ts`
- `tests/architecture/test_max_line_length_72.py` — passed
- `tests/architecture/test_no_banned_rank_terms.py` — passed
- `tests/efhc_backend/unit/test_no_legacy_words.py` — passed
- `tests/test_no_placeholders.py` — passed

## CI status

No fresh `logs_*.zip` was provided for the new archive.
Full green CI is not claimed.
