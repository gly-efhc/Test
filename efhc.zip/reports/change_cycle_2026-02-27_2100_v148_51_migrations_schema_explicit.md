# v148_51 — Fix: explicit schema in 0001 migration (core/admin)

## Причина (CI stop-crane)
Sanity DB objects after alembic reported missing tables:
- efhc_core.users
- efhc_core.withdraw_requests
- efhc_admin.efhc_sale_packages

Root cause: migration 0001 used ensure_table_with_basics(...) without explicit schema,
while inspector.has_table(schema=None) checks default schema and op.create_table(schema=None)
may create outside required schemas depending on connection/search_path.

## Fix
In backend/migrations/versions/0001_init.py:
- Added schema="efhc_core" to all core ensure_table_with_basics calls.
- Added schema="efhc_admin" to efhc_sale_packages.

This makes table creation deterministic and aligned with sanity-check and tests.

## Verification
- python -m compileall backend -q (expected OK)
- Alembic upgrade head in CI must create required tables; sanity-check should pass.
