# EFHC Bot change report — v166_77_78

Дата: 2026-04-16

## Активный диапазон
- 851-870

## Что закрыто в этом проходе
- Cycle 867 — release-truth pass for sale-packages / ads / diagnostics.
- CI repair wave on top of the same HEAD.

## Что исправлено
- Classified `sale-packages`, `ads` and `diagnostics` as helper / internal / draft / read-only / not release contour where appropriate.
- Reduced helper/internal visual weight on admin home while keeping the cluster visible.
- Added release-truth badges and explanatory info blocks instead of heavy demoralizing headers.
- Fixed stale admin-route canon test by including `admin_templates_routes.py`.
- Fixed stale SSOT schema doc header count so `efhc_core` now matches the 32-table canon.
- Fixed frontend validator declaration order so `PaymentIntentFlowTruthSchema` is declared before use.
- Fixed line72 regressions in Hub, WebProfile, tasks notification and payment-intent flow-truth code.
- Preserved the deposit launcher canon while satisfying the `r?.items` contract guard without adding a second state machine.

## Локально подтверждено
- `python -m py_compile ...` on changed backend files — passed.
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` — passed.
- `pytest -q tests/architecture/test_admin_route_modules_canon.py tests/architecture/test_db_diagnostics_docs_sync.py tests/architecture/test_deposit_packages_contract.py tests/architecture/test_max_line_length_72.py tests/architecture/test_cycle_and_docs_canon.py` — passed.
- `ruff check backend api ops tests` — passed.
- `mypy backend/app` — passed.
- `npm --prefix frontend run build` — passed.

## Что не заявляется
- Green GitHub CI is not claimed until the user runs a fresh GitHub CI pass.
- Full closure of 851-870 is not claimed in this pass.
