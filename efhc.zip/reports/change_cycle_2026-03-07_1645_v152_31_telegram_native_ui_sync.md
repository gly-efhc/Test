# Change cycle v152_31 — Telegram-native UI sync

Date: 2026-03-07

## Scope
- frontend Telegram-native visual sync
- admin-layer visual cleanup
- remove browser prompt() flows
- remove obsolete non-Telegram fallback screens
- lotteries progress/token cleanup
- legacy component style cleanup
- profile/settings checked for Telegram token compatibility

## Confirmed changes
- Added Telegram-native admin helpers:
  - `frontend/src/components/admin/AdminPage.tsx`
  - `frontend/src/components/admin/AdminPromptModal.tsx`
- Reworked admin pages to `var(--tg-*)` / EFHC Telegram-native cards,
  buttons and tables.
- Removed `prompt()` usage from admin pages and replaced with modal
  forms.
- Removed hardcoded web colors from admin pages and legacy components.
- Removed obsolete `need_telegram_webapp` fallback screens from user
  pages and replaced with neutral loading placeholders.
- Replaced lotteries progress fill use of `--tg-accent` with canonical
  Energy-style progress bar classes.
- Added Telegram-native admin table/status/link/pre styles to globals.

## Files touched
- `frontend/src/styles/globals.css`
- `frontend/src/components/admin/AdminPage.tsx`
- `frontend/src/components/admin/AdminPromptModal.tsx`
- `frontend/src/components/ExchangePanel.tsx`
- `frontend/src/components/PanelsList.tsx`
- `frontend/src/components/RanksTable.tsx`
- `frontend/src/components/ShopGrid.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/lotteries.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/ranks.tsx`
- `frontend/src/pages/tasks.tsx`
- `frontend/src/pages/admin/ads.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/pages/admin/logs.tsx`
- `frontend/src/pages/admin/panels.tsx`
- `frontend/src/pages/admin/prizes.tsx`
- `frontend/src/pages/admin/referrals.tsx`
- `frontend/src/pages/admin/reports.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/pages/admin/tasks.tsx`
- `frontend/src/pages/admin/users.tsx`
- `frontend/src/pages/admin/withdrawals.tsx`

## Local factual checks
- `prompt(` search in `frontend/src/pages` + `frontend/src/components`:
  no matches.
- `--tg-accent` search in `frontend/src/pages` + `frontend/src/components`:
  no matches.
- hardcoded admin/public web-color search (`bg-white`, `text-black`,
  `text-gray`, `border-white`, `bg-red`, `bg-green`, `bg-yellow`) in
  `frontend/src/pages` + `frontend/src/components`: no matches.
- obsolete `need_telegram_webapp` page fallback search:
  no matches in `frontend/src/pages` + `frontend/src/components`.

## Limits
- Full frontend build / runtime confirmation still requires new CI log on
  this archive.
- Profile/settings layer was audited and kept on Telegram token styling;
  the main practical mismatch was the admin/public legacy layer, which is
  what this cycle addressed.
