# Change report — v149_59_fix_env_py_indent

## Причина
CI падал на `python -m compileall extracted/backend -q` из-за `IndentationError` в `backend/migrations/env.py`.

## Что сделано
- `backend/migrations/env.py`: исправлены отступы в `_set_search_path()` и закрывающих скобках `connection.execute(...)`.

## Ожидаемый эффект
- `compileall` проходит стабильно, CI продолжает выполнение до Alembic/sanity.
