# Cycle 1572 workspace recovery and plan synchronization

Archive target: `EFHC_Bot_v171_49.zip`.

## Intake

`/mnt/data/efhc_workspace` was absent in the new sandbox. The canonical
`EFHC_Bot_v171_48.zip` passed SHA-256 calculation and ZIP integrity testing and
was unpacked exactly once into the canonical workspace. The screenshots archive,
`Песочница.xz` and `grafana-main.zip` were not merged into the project tree.

## Factual stop point

- Previous factual application implementation: `v171.47`, cycle 1571 done locally.
- `v171.48`: transfer and execution-boundary repair.
- Active unfinished cycle: 1572.
- Last supplied CI evidence: 2416 passed, 19 skipped, 3 PNG-evidence failures.
- Those PNG checks are already excluded from blocking CI in v171.48.
- No fresh rerun for the current lineage is available in this iteration.

## Plan synchronization

The remaining route is fixed in strict order:

1. finish cycle 1572 from fresh user-supplied GitHub logs and reconcile current-head blockers;
2. cycle 1573 live Telegram/TonConnect/TonProof/transaction proof under operator control;
3. cycle 1574 fail-closed RC audit and truthful release decision.

## Change boundary

Only control-plane documentation, maps and evidence were updated. No frontend,
backend, database, migration, auth, wallet, payment, financial or CI runtime file
was changed. No UI changed and no screenshots archive is required.

## Validation boundary

Targeted documentation consistency and archive/canon guards are required before
packaging. Full regression, typecheck, production build and browser proof are not
run by design because no implementation or UI changed.
