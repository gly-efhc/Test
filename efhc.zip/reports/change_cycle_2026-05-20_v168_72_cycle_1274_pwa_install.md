
# Change report — v168_72 cycle 1274 PWA install policy

## HEAD

`EFHC_Bot_v168_71_cycle_1273_splash_i18n_guard.zip`

## Cycle

1274 — PWA install policy lock.

## What was done

- Locked the rule that PWA installation uses the browser/system button.
- Verified that no custom EFHC install button is active in frontend code.
- Added a guard against future custom install button drift.
- Documented the policy in the frontend control layer.

## Files added

- `docs/frontend/FRONTEND_PWA_INSTALL_POLICY.md`
- `docs/audits/FRONTEND_CYCLE_1274_PWA_INSTALL_AUDIT_V168_72.md`
- `reports/generated/frontend_cycle_1274_pwa_install_v168_72.json`
- `tests/architecture/test_pwa_install_policy_guard.py`

## Files updated

- `docs/cycles/WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md`
- `docs/frontend/FRONTEND_IMPLEMENTATION_PLAN.md`
- `docs/NORM/CHAT_TRANSCRIPT.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/NORM/TESTS_CATALOG.md`
- `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`
- `reports/REPORTS_INDEX.md`

## Code changes

No runtime frontend/backend code was changed.

## Checks

- frontend route checker;
- Python compileall for ops/tests;
- targeted architecture guards;
- ZIP integrity check.

## Not claimed

- GitHub CI green;
- Docker runtime smoke;
- live browser screenshot proof;
- full frontend visual readiness.

## Next cycle

1275 — Energy canonical composition.
