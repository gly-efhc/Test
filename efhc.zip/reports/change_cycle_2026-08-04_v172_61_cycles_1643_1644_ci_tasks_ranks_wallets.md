# v172.61 — исправление CI цикла 1643 и цикл 1644

## Основание

Свежий основной запуск CI `30870996170` проверил exact v172.60 на commit
`dc6c2e0d3e0ed6c7bfc6d0f97cbf9475c60ebfe5`.

Прошли:

- Flake8;
- Mypy;
- Bandit;
- compileall;
- PostgreSQL diagnostic;
- Alembic `0001`;
- production-сборка frontend.

Не прошли:

- Ruff: один SIM117;
- pytest: `36 failed, 3210 passed, 28 skipped`.

## Первый causal failure

Тестовая инфраструктура и отдельные устаревшие fixtures не соблюдали уже
действующий контракт dual-write identity. Они повторно создавали singleton,
записывали provider `tg_id` без связь аккаунта либо создавали строки без
канонический `global_id`. Production-триггеры корректно блокировали orphan
ownership.

Production-безопасность не ослаблена. Исправлены тестовые исходные данные и fixtures вызывающего кода.

## Исправленные классы ошибок

- singleton seed стал идемпотентным;
- SIM117 устранён одним `async with`;
- nullable-параметр Referral получил явный `BIGINT` cast;
- банковское зеркало перестал маскироваться под владельца пользователя;
- Fixture белого списка Admin сначала создаёт связь аккаунта;
- Fixture конфликта Panel создаёт реального provider owner;
- Fixtures Payment Intent создают control и связь аккаунтаs;
- все подтверждённые ошибки осиротевшего dual-write закрыты у источника.

## Цикл 1644

Tasks, runtime рекламных наград, Ranks, Leaderboard и read-side Wallet переведены
на канонический `global_id`.

Владелец только с TON может:

- получить список задач;
- выполнить `задание `watch_ad`;
- получить подтверждённую выплату рекламной награды;
- читать историю наград за задания;
- читать привязки кошельков;
- участвовать в общем снимке рейтинга и leaderboard.

Операции только Telegram не переименованы в операции владения:

- `join_channel` требует provider Telegram;
- TonConnect proof/connect требует provider Telegram до цикле вызывающего кода 1645.

Снимок Ranks теперь хранит обязательный `global_id` и nullable `global_id`.
Устаревший Telegram leaderboard временно фильтрует provider-less rows, а global
read mode включает все активных владельцев.

## Ограничения

- production-флаги переключения не переключались;
- routes вызывающего кода, bot handlers и watcher переводятся в цикле 1645;
- устаревшие aliases удаляются только в циклах 1646–1647;
- Admin UX, public UI, screenshots и GitHub workflows не изменялись;
- PostgreSQL и полный набор статических инструментов должен подтвердить CI exact-head.
