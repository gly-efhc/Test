# EFHC Bot Change Report v151_00

## Источник
- База: EFHC_Bot_v150_69_alias_sanitation_flake8_ci.zip
- Логи: logs_59312303473.zip

## Что упало в CI (по логам)
- Alembic offline (--sql) запускал 0001_init.py и падал на sanity,
  потому что в offline режиме нет живого коннекта и SELECT/to_regclass
  возвращали NULL.

## Исправления
1) backend/migrations/versions/0001_init.py
- Добавлен offline guard через alembic_context.is_offline_mode().
- В offline режиме отключены:
  - диагностические SELECT current_database()/SHOW search_path
  - sanity проверки pg_namespace/to_regclass
  - жёсткая проверка missing_after_create_all
- Удалён ошибочный/битый отступ после create_all.

2) ci.yml
- flake8 (critical): добавлены флаги
  --count --show-source --statistics
  и новый артефакт 04a_flake8_critical.txt.
- Добавлен второй шаг:
  flake8 (full report, non-blocking)
  с --exit-zero, чтобы собрать ВСЕ ошибки flake8 за один прогон,
  не блокируя пайплайн на некритичных нарушениях.
  Артефакт: 04b_flake8_full.txt.

## Кеши
- Перед упаковкой удалены __pycache__, .pytest_cache, frontend/.next,
  node_modules, build/dist и *.pyc.
