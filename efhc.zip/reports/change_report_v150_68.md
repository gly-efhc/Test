# Change report v150_68

## Fixed
- Frontend Next.js build error in `frontend/src/pages/lotteries.tsx`:
  - Replaced invalid JSX attribute concatenations:
    - `className="..." + "..."` (invalid in JSX)
    - with `className={{ "..." + "..." }}` blocks.

## Notes
- Cleaned caches before packaging:
  - `__pycache__`, `.pytest_cache`, `node_modules`, `dist`, `build`, `.next`.

