# Change report v167_13

- Unified wallet wording across Hub, DepositModal, Browser-Shop, Web-Profile, ProfileModal.
- Payment-intent UX wording now reads backend `next_action`, `product_state`, `return_path`.
- Return-path copy polished toward canonical destinations.
