# v154_13 - FAQ precision restore from PDF

- Source of truth used: EFHC_FAQ_PUBLIC_RU_v20_profile_settings.pdf
- Restored exact FAQ facts in ru.ts for balances, panels, energy,
  exchange/withdraw, wallet, Activ, and VIP NFT.
- Fixed meta.ts syntax defects and corrected Russian meta titles.
- Removed stale localized item overrides for critical FAQ ids so
  those items now fall back to corrected Russian source instead of
  outdated generic translations.
- Local checks passed:
  - test_max_line_length_72.py
  - test_no_banned_rank_terms.py
  - test_no_legacy_words.py
  - test_no_placeholders.py
