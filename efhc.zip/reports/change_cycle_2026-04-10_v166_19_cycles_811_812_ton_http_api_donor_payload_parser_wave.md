# Change report — v166_19 — cycles 811-812 — 2026-04-10

## What changed
- audited `ton-http-api-master.zip` as donor material for TON/Jetton API surface
- extracted `EFHC:` payment-intent payload parsing into `backend/app/services/intent_payload_parsing_service.py`
- updated watcher to use the shared parser service
- added focused parser tests

## Narrow checks
- `PYTHONPATH=backend pytest -q tests/architecture/test_intent_payload_parsing_service.py -q`
- `python -m py_compile backend/app/services/intent_payload_parsing_service.py backend/app/services/watcher_service.py`
