# EFHC Bot change cycle — v149_43

## Источник
- Base: v149_42 (SSOT ZIP)
- CI logs: logs_58939510200.zip (Index(schema=...)), ранее logs_58938592468.zip

## Что упало (CI)
1) Alembic upgrade head: `TypeError ... got 'schema'` из `Index(..., schema=ADMIN_SCHEMA)` в `backend/app/models/admin_models.py`.
2) Проблема согласования: отсутствовала ORM-таблица `payment_intents` при наличии кода/маршрута, использующих `efhc_core.payment_intents`.

## Что исправлено
- admin_models: убран `schema=` из `Index(...)` (SQLAlchemy не поддерживает kwarg `schema` для Index).
- Добавлена ORM-модель `PaymentIntent` (таблица `efhc_core.payment_intents`) + включение в models registry.
- 0001_init: expected_tables обновлён до 32; таблицы берутся из Base.metadata; sanity остаётся детерминированным.
- ops/ci_verify_db_objects: REQUIRED расширен на `efhc_core.payment_intents` (32 таблицы).
- SSOT: обновлены `SSOT_TABLES_ORM.csv` (32), `SSOT_TABLES_MIGRATIONS.csv` (2 схемы + 32), `SSOT_ROUTE_TABLE_MAP.csv` для маршрутов №61–№65.
- ranks_service: убран self-DDL и приведено использование `ranks_top_cache` вместо legacy `ranks_cache`.
- referral_service: добавлены публичные API-обёртки (`ensure_consistency`, `list_active_referrals`, `list_inactive_referrals`, `get_counters`) и DTO, согласовано с routes/referrals_routes.py.

## Реестр ошибок
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md обновлён: добавлен класс ошибки Index(schema=...).

## Кеш
- Перед упаковкой очищены __pycache__, *.pyc, .pytest_cache, .mypy_cache, .ruff_cache, node_modules, .next.
