# v171.59 / cycle 1573 — corrective fresh browser proof

## Status

`DEVELOPMENT SNAPSHOT / CYCLE 1573 ACTIVE / NOT RELEASE READY`.

Cycle 1573 remains active. Cycle 1574 is not started.

## Root causes corrected

- v171.58 incorrectly treated missing `frontend/node_modules` as a blocker for browser component screenshots.
- Chromium, Xvfb and Python Playwright were available but not checked before the blocker claim.
- `ProfileModal.tsx` existed but was not mounted anywhere.
- UI changes were packaged before fresh screenshot proof existed.

## Runtime correction

Changed runtime file:

- `frontend/src/features/profile/WebProfilePage.tsx`.

Implemented:

- imports and mounts the existing `ProfileModal`;
- adds a visible Settings button inside Profile → Interface;
- preserves Profile / Wallet / History / FAQ navigation;
- passes existing wallet, balances, settings, admin and Telegram state into the modal;
- does not change money, wallet binding, TonConnect, TonProof or transaction logic.

Verified but not changed in this pass:

- `frontend/src/styles/globals.css` — whole and fractional balance digits use the same scale and tabular numerals;
- `frontend/src/components/GlobalHeader.tsx`;
- `frontend/src/components/ProfileModal.tsx`.

## Archive regression guard repair

Modified:

- `ops/build_efhc_zip.sh`.

The builder now excludes `reports/screenshots/` during staging and rejects technical screenshots during the post-pack guard. This closes the regression that initially placed fresh PNG inside the main archive.

## Fresh visual proof

Added:

- `ops/frontend/cycle_1573_v171_59_browser_proof.py`;
- `reports/generated/browser_component_page_proof_v171_59.json`;
- `reports/generated/screenshots_companion_manifest_v171_59.json`.

Fresh Chromium component/page proof covers:

- Header at 360×800;
- Header at 390×844;
- Header at 430×932;
- Header at 768×1024;
- Panels;
- Referrals;
- Tasks;
- Exchange;
- Energy;
- History;
- FAQ;
- Profile;
- full ProfileModal settings screen.

Proof type: `BROWSER_CAPTURED_COMPONENT_PAGE_PROOF`.

This is fresh source-backed local browser proof. It is not live Next.js route or live Telegram proof.

## Native Wallet Adapter

Retained as planning-only:

`WalletProvider → TonConnectAdapter / TelegramWalletAdapter / NativeGramWalletAdapter`.

No runtime wallet-provider refactor was started.

## Targeted checks

- fresh Chromium capture script: passed, 13 PNG;
- Python compile of the screenshot script: passed;
- targeted pytest guard pack: `31 passed`.

## Not run

- `npm ci`;
- production frontend build;
- full pytest;
- full regression;
- local GitHub-CI replica;
- fresh GitHub CI;
- live Telegram Mini App;
- real TonConnect;
- real TonProof;
- real transaction.

## Remaining external blockers

The only release-blocking contours still requiring factual external execution are:

- live Telegram client / public Mini App route;
- real wallet confirmation;
- real TonProof signature and backend verification;
- real network transaction and backend confirmation;
- fresh full GitHub CI for the exact release candidate.

These blockers do not prevent delivery of this development snapshot.

## Cycle boundary

- cycle 1572: complete by supplied green user-run logs;
- cycle 1573: active, not complete;
- cycle 1574: not started;
- next permitted archive after v171.59: `EFHC_Bot_v171_60.zip`.
