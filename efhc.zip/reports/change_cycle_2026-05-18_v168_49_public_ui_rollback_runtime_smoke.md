# Change report — v168_49 — cycle 1265

## Goal

Repair public UI regressions while preserving Docker fixes from v168_48.
Add a local runtime smoke test so the PC setup can be checked in a
controlled way.

## Code changes

- Removed public technical `GameNotice` from HUB.
- Removed HUB and Wallet/Profile action cards from Energy.
- Restored Energy to canonical first-screen content.
- Restored visible header balance by removing the CSS hide rule.
- Removed browser/PWA/independent-shell labels from Web Profile.
- Added dark contrast guardrails inside `.efhc-independent-shell`.
- Added `ops/local/runtime_smoke.py`.

## Documentation changes

- Added public UI rollback audit.
- Added local ENV and smoke test runbook.
- Updated Docker local document with a data-safety warning.
- Updated cycles, AI temporary memory, Q/A register and report index.

## Checks

- `npm ci --no-audit --no-fund --progress=false`: passed.
- `npx tsc --noEmit --pretty false`: passed.
- Targeted pytest guard pack: 8 passed.
- `compileall` for backend/app, ops/routes, ops/local and tests: passed.
- Generated JSON validation: passed.
- ZIP integrity after build: passed.

## Not claimed

- Docker runtime proof was not run in the assistant environment.
- GitHub CI was not run by the assistant.
- `npm run build` was attempted but timed out during production build.
