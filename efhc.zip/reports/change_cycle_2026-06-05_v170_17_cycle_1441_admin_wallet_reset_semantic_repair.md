# Change report — v170.17 / cycle 1441 Admin wallet reset semantic repair

## Summary

Cycle 1441 repaired `F-005` from the active migrations/routes/backend-frontend linkage audit.

Admin wallet reset now performs a full canonical wallet unbind instead of only clearing legacy `users.ton_wallet`.

## Runtime changed

- `backend/app/services/wallets_service.py`
  - added `admin_reset_wallet_bindings()`;
  - deactivates canonical `efhc_core.wallet_bindings` by `global_id`;
  - clears `is_active` and `is_primary`;
  - does not commit inside helper.

- `backend/app/routes/admin_users_routes.py`
  - route `POST /admin/users/{global_id}/wallet/reset` now clears legacy `users.ton_wallet` and deactivates canonical `wallet_bindings` in the same transaction boundary;
  - admin audit log records `wallet_bindings_deactivated=...`.

- `frontend/src/pages/admin/users.tsx`
  - reset action is no longer disabled only because legacy `selected.ton_wallet` is empty;
  - detail and list are reloaded after backend confirmation.

## Runtime not changed

- No EFHC economy changes.
- No financial invariant changes.
- No migration changes.
- No OpenAPI rebuild.
- No CI/workflow/lock-file changes.
- No public UI route changes.

## Tests added

- `tests/architecture/test_admin_wallet_reset_semantic_repair.py`

## Local validation

- `python -m pytest tests/architecture/test_admin_wallet_reset_semantic_repair.py -q` → `7 passed`.
- Related linkage/kernel/filename/line72 guard pack → `47 passed`.
- Targeted `py_compile` for changed backend files → passed.

## Healer / audit tails routed forward

Next cycles must keep the remaining tails visible:

- `1442` — OpenAPI rebuild and strict contract gate.
- `1443` — full linkage architecture tests and critical UI state guards.
- `1444` — repeat linkage audit plus HEALER tail reconciliation.
- `1445` — fresh CI/log proof and residual audit-tail closure if logs are supplied.

## Non-claims

No GitHub CI green, no full pytest green, no frontend build green, no release-ready, no browser screenshots, no live Telegram proof and no real TonConnect proof are claimed.
