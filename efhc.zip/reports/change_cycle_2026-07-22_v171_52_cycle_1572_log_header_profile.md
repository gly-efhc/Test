# Cycle 1572 — fresh GitHub log repair, header refinement and Profile visual disclosure / v171.52

Status: `LOCAL_REPAIR_COMPLETE / FRESH_GITHUB_RERUN_REQUIRED`.

## Input facts

- source HEAD: `v171.51`;
- supplied log: `logs_81110261160.zip`;
- SHA-256: `f700bb6577bdd3d046f38f174b93eec30b6794141cbfa374fa172f7673a235de`;
- GitHub pytest: `2422 passed`, `19 skipped`, `2 failed`;
- Ruff, frontend build, 36 route budgets, mypy, bandit, flake8, compileall, PostgreSQL precheck and Alembic passed.

## Confirmed root causes and repair

1. `CONTINUE_IN_NEW_CHAT.md` and `docs/healer/HEALER_ATLAS.md` contained current wording that matched the protected numbered-work-label regex. The wording was changed; the guard was not weakened.
2. `test_header_uses_universal_energy_mark_and_only_efhc_label` depended on exact JSX indentation. It now verifies the semantic `<span>EFHC</span>` markup.

Targeted validation: `9 passed`.

## GlobalHeader visual change

- exact balance remains one unchanged value;
- whole and fractional portions have separate typography for clearer reading;
- the balance card uses a restrained gold border/gradient and remains fully visible at 360 px;
- inactive Activ/VIP remain gray text only;
- active Activ and VIP now use exactly the same gold glow;
- no status container, pill, border or background was introduced;
- Profile and balance remain vertically aligned.

Three fresh isolated Chromium screenshots were created for the changed header. This is visual proof, not a claim of full-app E2E.

## Profile screenshots

The Profile route was not modified in this iteration. Actual existing application screenshots were extracted from the established companion evidence and surfaced to the user:

- mobile `360x800`;
- tablet `768x1024`;
- current public route baseline.

They are not edited or regenerated images. Their header reflects the earlier baseline; the new header is proven separately by the fresh v171.52 screenshots.

## Validation boundary

Not run by design: full pytest, local GitHub-equivalent CI, `npm ci`, local typecheck, local production build and broad browser matrix. The user runs CI and supplies the next log.

## Cycle route

Cycle 1572 remains active until the next GitHub rerun for `v171.52` is reconciled. The next planned cycle after green CI is `1573 — live Telegram, real TonConnect/TonProof and real transaction-boundary proof`.
