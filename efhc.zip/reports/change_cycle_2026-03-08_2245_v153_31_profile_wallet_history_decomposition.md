# v153_31 — Profile / Wallet / History decomposition

## Что сделано

- Добавлены новые reusable-компоненты профиля для Wallet и History.
- ProfileModal частично декомпозирован: wallet/history ветки
  вынесены в отдельные подкомпоненты.
- Добавлены отдельные компоненты списка кошельков, баннера
  подключения, карточки основного кошелька, карточек баланса,
  списка истории, пустого состояния и кнопки догрузки.

## Новые файлы

- frontend/src/components/profile/ProfileWalletSection.tsx
- frontend/src/components/profile/ProfileHistorySection.tsx
- frontend/src/components/profile/wallet/WalletListItem.tsx
- frontend/src/components/profile/wallet/WalletConnectBanner.tsx
- frontend/src/components/profile/wallet/WalletPrimaryCard.tsx
- frontend/src/components/profile/history/BalanceSummaryCard.tsx
- frontend/src/components/profile/history/BalanceHistoryItem.tsx
- frontend/src/components/profile/history/BalanceHistoryList.tsx
- frontend/src/components/profile/history/BalanceHistoryEmptyState.tsx
- frontend/src/components/profile/history/BalanceHistoryLoadMore.tsx

## Изменённые файлы

- frontend/src/components/ProfileModal.tsx

## Проверки

- ops/canon_guard.py — OK
- changed-file line72 — OK
- TypeScript compile в этой среде не подтверждён как полноценное
  доказательство сборки; локальный вызов tsc без проектного конфига
  показывает ошибки режима JSX/moduleResolution и не используется как
  финальное доказательство состояния архива.
