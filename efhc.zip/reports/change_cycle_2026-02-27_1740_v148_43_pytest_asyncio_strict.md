# EFHC Bot change report v148_43

UTC time: 2026-02-27T17:40:00+00:00

## Stop-crane (CI)
- pytest -q fails with loop mismatch during async fixture teardown:
  - RuntimeError: got Future attached to a different loop

Source logs: logs_58827640670.zip, logs_58824951756.zip

## Root cause
pytest-asyncio `asyncio_mode=auto` runs async tests/fixtures via `asyncio.run`
(new loop), causing teardown to run in a different loop than setup for
session-scoped async resources.

## Fix
- Set `asyncio_mode = strict` in pytest.ini to keep a single loop per configured
  scope and avoid cross-loop teardown.

## Files changed
- pytest.ini

## Verification
- python -m compileall tests -q (expected OK)
- CI pytest -q should no longer raise cross-loop teardown errors.
