# v171.76 — exact CI log repair and FastAPI route inventory compatibility

## Inputs

- `logs_81738302374.zip` — development archive CI.
- `logs_81740060489.zip` — release archive CI.
- Exact source HEAD: `EFHC_Bot_v171_75.zip`.

## Root causes

1. Ruff `I001` rejected import grouping in two backend schemas and one
   cumulative-update architecture test.
2. FastAPI 0.137+ represents included routers as nested `_IncludedRouter`
   nodes. The release required-route test assumed a flat `app.routes` list and
   therefore saw only framework documentation routes.

## Repair

- Applied the exact Ruff-compatible first-party import grouping.
- Added `backend/app/release/route_validation.py::collect_route_paths()` as the
  shared production and release-CI route inventory helper.
- New FastAPI releases use the public `iter_route_contexts()` API, preserving
  composed prefixes and hidden routes; older releases use the guarded recursive
  compatibility collector.
- Added behavioral coverage for nested routers and an `include_in_schema=False`
  route.

## Protected invariants

- Mandatory production routes were not reduced.
- `/api/tg/webhook` remains required even though it is absent from OpenAPI.
- No test, guard, workflow or expected route was removed or skipped.
- Product runtime, economy, UI, migrations and transaction truth were unchanged.

## Proof boundary

Local tests can prove the patched behavior in the available dependency set.
Only fresh exact-HEAD GitHub CI can prove Ruff 0.16 and FastAPI 0.140 behavior
for the delivered v171.76 archives.
