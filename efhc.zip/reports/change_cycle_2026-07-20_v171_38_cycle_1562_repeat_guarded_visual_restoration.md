# Repeated cycle 1562 — guarded visual restoration

## Input

- Archive: `EFHC_Bot_v171_37.zip`.
- Output target: `EFHC_Bot_v171_38.zip`.
- Scope remains cycle `1562`; cycle `1563` was not started.

## Corrected unauthorized changes

- Restored the canonical `EFHC VIP NFT` HUB action and official GetGems
  link.
- Restored tests that previously protected the two-action HUB.
- Removed Wallet balance cards and Exchange actions from Energy.
- Restored current named Energy level below the progress bar.
- Fixed available-kWh unit duplication.
- Rebuilt six bottom navigation controls as wide equal rounded cells.
- Replaced the mixed icon shapes with one rounded-outline SVG system.

## Browser Shop repeated proof

- TON/GRAM and USDT methods remain available.
- Web access-key and Telegram linking preserve token, SKU and method.
- Return reaches the same checkout.
- Payment intent uses backend TTL.
- React Query polls every five seconds and stops on terminal status.
- Controlled Chromium E2E passes for phone and tablet layouts.

## Guard audit

The prior cycle changed product behaviour and its guards together. The exact
confirmed test inversions and permanent repair rules are recorded in:

`docs/audits/RECENT_GUARD_CONTRADICTION_AUDIT_1562.md`.

## Evidence boundary

Local browser and build evidence is established. Live Telegram linking, real
TonConnect signatures, real TON/USDT settlement and fresh GitHub CI are not
claimed.

## Final local verification

- architecture: `2125 passed`, `7 skipped`, `0 failed`;
- full regression: `2296 passed`, `135 skipped`, `0 failed`;
- production builds: `2 / 2`;
- controlled Browser Shop E2E: `2 / 2`;
- current screenshots: `7`.
