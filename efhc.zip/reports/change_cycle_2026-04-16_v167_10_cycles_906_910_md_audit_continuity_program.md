# Change report — v167_10 cycles 906-910 md-audit continuity program

## Summary
- removed `.pdf` and `.docx` audit variants from `docs/audits/`
- added canonical markdown audit version
- added archive rule: audits inside the archive are markdown-only
- started the linked money-sensitive continuity program 906-910
- added role matrix and payment-intent state machine SSOT docs
- reinforced user-facing role/continuity copy in Hub, Web-Profile and ProfileModal
