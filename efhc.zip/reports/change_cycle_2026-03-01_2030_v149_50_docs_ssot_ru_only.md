# Change report — v149_50 (RU-only audits + SSOT descriptions)

## Changes
- Удалены украинские аудиты (`*_uk.md`) — канон: только русский.
- Переписаны объяснения SSOT по схемам/таблицам/маршрутам:
  - docs/ssot_pack/SSOT_TABLES_SCHEMAS_DESCRIPTION_RU.md
  - docs/ssot_pack/SSOT_TABLES_PURPOSE_RU.md
  - docs/ssot_pack/SSOT_ROUTES_DESCRIPTION_RU.md (включая таблицу формата "Маршрут | Суть | Таблицы | Статус" для №76–№80)
- Обновлён docs/SSOT_INDEX.md (ссылки на новые RU SSOT документы).
