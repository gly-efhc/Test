# Change Report — v166_28 — Cycles 829-830

Дата: 2026-04-10
HEAD: EFHC_Bot_v166_28_cycles_829_830_usdt_hardcode_admin_sop_wave.zip

## Scope
- 829 — hardcoded USDT master address sync across layers
- 830 — short Admin SOP linked to canonical documents

## Confirmed changes
- set backend default `USDT_JETTON_MASTER_ADDRESS` to the approved canon value
- added frontend `USDT_JETTON_MASTER_ADDRESS` constant
- added fallback usage in browser-shop USDT helpers
- extended `WITHDRAW_ADMIN_TONCONNECT_SSOT.md` with the full outbound Blitz flow
- created `docs/ADMIN_SOP.md` linked to RC1 and withdraw SSOT

## Narrow checks actually run
- `python -m py_compile backend/app/core/config_core.py`
- local TypeScript transpile checks for browser-shop USDT helper files

## Honest residuals
- no live blockchain proof
