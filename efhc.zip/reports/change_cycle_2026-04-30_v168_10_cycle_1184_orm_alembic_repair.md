# Change report v168_10 cycle 1184

## Scope

Cycle 1184 repaired the ORM versus Alembic 0001 audit risk.

## Changed

- Expanded `required_columns` in the 0001 migration file.
- Added static guard `ops/routes/check_orm_0001_columns.py`.
- Added architecture test for the guard.
- Added audit documentation and updated cycle-control documents.

## Not changed

- No pre-release `0002` migration was created.
- Frontend and FAQ files were not edited.
- CI configuration was not changed.

## Verification

The static guard reports all required critical columns present.  Local
checks are helper checks only and do not replace GitHub CI.
