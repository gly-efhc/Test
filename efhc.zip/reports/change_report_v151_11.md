# Change Report v151_11

## Scope
- Fix CI pytest failures from logs_59353591933.zip.

## Changes
1) backend/app/services/wallets_service.py
   - Added missing SSOT status constants referenced by tests:
     - STATUS_CREDITED = "credited"
     - STATUS_ERROR_SYS = "error_retry"

## Notes
- No behavior change for wallet bindings logic.
- Cache directories removed before packaging.
