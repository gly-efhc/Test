
# Change report v168_73 — cycle 1275 Energy

## HEAD

`EFHC_Bot_v168_72_cycle_1274_pwa_install_policy.zip`

## Cycle

1275 — Energy canonical composition.

## Code changes

- `frontend/src/pages/index.tsx`
- `frontend/src/styles/globals.css`

## What changed

- Energy center is now generation-first.
- Public balance chips were removed from the Energy center.
- Base rate and exchanged total mini-card were removed from Energy.
- VIP is shown only as a status pill when active.
- Canonical actions remain Panels and Exchange only.

## Docs

- Updated plan 1268-1320.
- Created plan 1301-1400.
- Added audit and generated report.

## Checks

See final chat report for executed checks.

## Not claimed

- GitHub CI green.
- Docker runtime smoke.
- Live screenshot proof.
- Full frontend readiness.
