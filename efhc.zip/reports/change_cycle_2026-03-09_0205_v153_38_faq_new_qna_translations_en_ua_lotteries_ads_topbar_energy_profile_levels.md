# change_cycle_2026-03-09_0205_v153_38_faq_new_qna_translations_en_ua_lotteries_ads_topbar_energy_profile_levels

- Added EN translations for new FAQ items: top bar, Energy page, Lotteries, Ads, 12 progress levels, Profile/Settings.
- Added UA translations for new FAQ items: top bar, Energy page, Lotteries, Ads, 12 progress levels, Profile/Settings.
- Preserved line72 in localized.ts.
- Fixed terminology guard violations by replacing banned Lottery forms with canonical Lotteries forms.
