# Change Cycle 2026-03-01_1200 — v149_42_fix_alembic_backend_imports_models_panels_nft_errors_registry

## Source of truth
- HEAD input ZIP: EFHC_Bot_v149_41_fix_core_imports_ssot_routes_51_55.zip
- CI logs analyzed: logs_58938592468.zip

## What failed (CI)
- Alembic upgrade head failed with ModuleNotFoundError: No module named 'backend' when importing app.models.* (achievements_models.py). Confirmed by logs_58938592468.zip.

## Fixes applied
### 1) Import namespace canon (app.* / relative) inside backend/app/**
- Replaced remaining `backend.app.*` imports across `backend/app/**` with `app.*` to keep code runnable when CI runs from `cd backend` (top-level package = `app`).

### 2) Routes #56–#60 passports (SSOT_ROUTE_TABLE_MAP)
- Filled read/write tables + evidence_refs for:
  - GET /nft/has_vip (EXTERNAL_NFT_API, no DB)
  - GET /panels/{tg_id}/summary (efhc_core.panels)
  - GET /panels/{tg_id}/active (efhc_core.panels; optional force_sync write via energy_service)
  - GET /panels/{tg_id}/archive (efhc_core.panels; optional force_sync write via energy_service)
  - POST /panels/buy/{tg_id} (money op; via transactions_service; idempotency required)

### 3) CI error registry
- Appended new CI error classes (with logs_*.zip IDs) into EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md to avoid повторений.

## Canon checks
- Repo-wide bans: PASS (telegram-id, tg_id, user-key, rank*)
- No schema= in sa.Column introduced.

## Artifacts updated
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/REPORTS_INDEX.md
