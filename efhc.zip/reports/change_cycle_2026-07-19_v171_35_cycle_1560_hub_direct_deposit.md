# Cycle 1560 — HUB and Direct Deposit

Status: `DONE LOCALLY`.

## User path

`HUB -> EFHC handoff or VIP NFT`.

`Global Header + -> amount -> TON wallet -> watcher -> confirmation`.

## Root causes

- HUB still mixed navigation and direct transport access.
- Direct Deposit did not accept a user-entered amount.
- The wallet handoff did not include the amount in nanoTON.
- Public status was not linked to watcher reconciliation.
- The old modal exposed an incomplete operational contour.

## Implementation

- Added typed HUB and Direct Deposit services.
- Added React Query mutation and status hooks.
- Kept exactly two equal HUB actions.
- Added a clean TON amount input.
- Preserved backend-generated canonical memo handling.
- Added wallet URL amount binding.
- Added polling through the financial history endpoint.
- Added human checking, retry and confirmed states.
- Kept raw wallet and payment internals out of public copy.

## Visual proof

Five current screenshots cover four viewport classes.

- HUB mobile;
- Direct Deposit amount entry;
- watcher checking state;
- confirmed deposit state;
- HUB tablet layout.

No checked viewport has horizontal overflow.

## Regression

- Inventory: `2403` unique nodes.
- Result: `2274 passed`, `129 skipped`, `0 failed`.
- New explicit skips: `0`.
- New xfails: `0`.
- Deleted tests: `0`.

## Protected canon

No economic formula, EFHC conversion rule, wallet binding rule,
withdraw rule, authentication model, DB schema or Alembic canon changed.

## External boundary

Fresh GitHub CI, live Telegram, a real TON payment and the final
release audit are not claimed.
