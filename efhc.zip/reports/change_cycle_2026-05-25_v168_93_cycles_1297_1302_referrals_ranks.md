# v168_93 cycles 1297-1302 — Referrals/Ranks


## v168_93 cycles 1297-1302 result

Cycles completed in one pass:

- 1297 — referral progress and levels;
- 1298 — referral bonus wording;
- 1299 — Ranks card layout;
- 1300 — Ranks filters;
- 1301 — show me in rating;
- 1302 — Ranks proof pass.

Status: completed.

Result:

- Referrals progress is now visible as a main card, not hidden in a
  collapsed details-only area;
- referral level, progress bar, achievements marker and next-level value
  are protected by guard;
- referral bonus wording is fixed as `+0.1 EFHC` in the rules/progress
  block, without overloading each referral row;
- Ranks uses vertical player cards and username/neutral fallback only;
- Ranks public filters are exactly `kWh` and `Referrals`;
- Ranks frontend uses current-user backend routes instead of `global_id` or
  `exclude_tg_id` query strings;
- current-user kWh routes and current-user referrals rank routes were
  added to backend;
- the Show me button focuses the user and a nearby competitor window.

Next cycle: 1303 — Profile status model.
