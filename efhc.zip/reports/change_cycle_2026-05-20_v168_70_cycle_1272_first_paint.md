# Change report v168_70 — cycle 1272 first paint guard

Дата: 2026-05-20.
HEAD: EFHC_Bot_v168_69_cycle_1271_browser_login_demo.zip.
Новый архив: EFHC_Bot_v168_70_cycle_1272_first_paint_guard.zip.

## Что сделано

Выполнен цикл 1272: защита первого экрана от белого/пустого состояния.

Кодовые изменения:

- `frontend/src/pages/document.tsx` получил dark first paint CSS;
- `frontend/src/styles/globals.css` получил root `#__next` dark shell;
- `frontend/src/pages/app.tsx` получил splash timeout escape;
- добавлен dataset marker `data-efhc-shell` через `root.dataset.efhcShell`;
- добавлен guard `test_first_paint_guard.py`.

Документы:

- обновлены планы циклов 1268-1320;
- обновлены `CHAT_TRANSCRIPT.md` и Q/A register;
- создан аудит цикла 1272;
- создан generated JSON report.

## Что не менялось

Backend, migrations, database, payment logic, admin routes и экономика
не менялись.

## Проверки

- `python3 ops/local/check_frontend_routes.py`;
- `python3 -m compileall -q ops/local tests/architecture`;
- targeted pytest по frontend guards;
- `npm --prefix frontend ci`;
- `frontend tsc --noEmit`;
- locale JSON validation;
- `unzip -t` нового ZIP.

## Что не заявляется

Не заявляется GitHub CI green, Docker runtime smoke и live screenshot proof.
