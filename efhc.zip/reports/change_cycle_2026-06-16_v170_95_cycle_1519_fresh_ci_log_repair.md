# v170.95 — Fresh CI proof / red-log repair

Status: `DONE_LOCALLY_RED_LOG_REPAIRED`

Input log `logs_74249190312.zip` was red. The cycle repaired the exact pytest
and frontend gate failures from that log.

## Fixed

- `frontend/package-lock.json`: removed internal registry marker.
- Migration docs and plan: active ORM table count updated to `44`.
- `backend/app/services/admin/admin_withdrawals_service.py`: normal withdraw
  list/approve flow no longer depends on legacy `bonus_awards` table.
- `ops/frontend/admin_visual_button_click_proof.py`: line length repaired and
  generation-rate literals removed from mock data.
- `frontend/src/features/admin/AdminHubPage.tsx`: seam guard anchor preserved
  after line wrapping.
- `KERNEL.md`: navigation restored while numbered work-pass labels were removed
  from the root non-exception file.

## Local validation

- Targeted replay of all logged pytest failures: passed locally.
- `ruff check backend api ops tests`: passed locally.
- `bandit -r backend/app -q -f txt`: passed locally with warnings only.
- `python -m compileall -q backend ops scripts tests`: passed locally.
- `npm audit --audit-level=high`: 0 vulnerabilities locally.
- `npm run typecheck`: passed locally.

## Not claimed

- GitHub CI green for the output archive;
- full pytest green;
- full frontend build green;
- release-ready;
- live Telegram proof;
- real TonConnect proof.
