# EFHC Bot — change report
## 2026-04-11 — v166_56 — cycle 850 ruff tail regression repair

### What changed
- repaired the watcher import-hygiene regression introduced by the
  previous pass: restored the `_RE_INTENT` compatibility alias and
  restored `_CREDIT_ORIG = credit_user_from_bank` for the confirm-path
  test/runtime bridge.
- ran focused `ruff --fix` on the exact files from the fresh GitHub CI
  log to normalize import ordering in backend, ops and tests without
  changing business logic.
- kept the earlier `E402`-safe local-import pattern in the blitz runner
  and aligned the remaining import blocks to the linter expectation.

### Verification done locally
- `ruff check --select I,E402,F401,F821` on the exact affected files.
- `python -m py_compile` on the changed Python files.
- line72 recheck for `backend/app/services/watcher_service.py`.
- archive build without claiming GitHub CI green.

### Honesty boundary
- full GitHub CI was not run locally.
- final closure of cycle 850 still depends on the next GitHub CI log.
