# CHANGE REPORT — v165_53 — cycles 506-510

## Scope
- release blockers wave 1 from the two new v165 release audits.

## Changed code
- `backend/app/services/withdraw_service.py`
- `tests/architecture/test_withdraw_runtime_invariants.py`
- `frontend/src/pages/withdraw.tsx`
- `frontend/src/pages/exchange.tsx`
- `frontend/src/components/profile/ProfileHistorySection.tsx`
- `frontend/src/features/admin/AdminSalePackagesPage.tsx`
- `frontend/src/pages/admin/index.tsx`
- `frontend/src/components/DepositModal.tsx`

## Changed docs
- `docs/audits/RELEASE_AUDITS_COMPARATIVE_AGAINST_HEAD_2026_04_08.md`
- `docs/audits/RELEASE_REMEDIATION_PLAN_506_530_2026_04_08.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_501-600.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `reports/REPORTS_INDEX.md`

## What changed
1. Fixed the release-blocking withdraw cancel signature drift.
2. Added a dedicated `/withdraw` journey with request creation, list, detail and cancel.
3. Added explicit entrypoints to `/withdraw` from exchange and profile history.
4. De-lived `sale-packages` from the main admin release surface and marked the page as internal draft / read-only.
5. Synced the active cycle layer, Healer and audit plan for the next 20-cycle remediation block.
