# Cycle 479/500

- Connected `orders_service.py` to live admin runtime via legacy-read endpoints in `admin_shop_routes.py`.
- Added `GET /admin/shop/order/legacy/{order_id}`.
- Added `GET /admin/shop/orders/user/legacy/{global_id}`.
