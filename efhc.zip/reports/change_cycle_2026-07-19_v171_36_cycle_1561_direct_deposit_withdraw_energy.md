# Cycle 1561 — Direct Deposit repair, Withdraw and Energy

## Input

- `EFHC_Bot_v171_35.zip`;
- Direct Deposit status from the input head was downgraded to
  `INCORRECT_IMPLEMENTATION / REPAIR_REQUIRED`.

## Root cause

Tests were present but encoded a temporary native-TON direct deposit,
TON-only store and disabled USDT state. Their green result therefore
protected the wrong product semantics. No cross-contour guard compared
header `+`, HUB, store methods, watcher asset and public labels.

## Corrected canons

- `Прямое пополнение`: direct EFHC jetton -> EFHCm;
- `Пополнение`: purchase EFHCm for TON/GRAM or USDT jetton;
- direct deposit never accepts native TON and never applies pricing;
- store purchase never impersonates direct deposit.

## Implementation

- direct EFHC TEP-74 transaction metadata and frontend builder;
- watcher accepts only canonical EFHC jetton for direct deposits;
- exact asset quantity credits EFHCm;
- Browser Shop exposes TON/GRAM and USDT methods;
- Withdraw uses React Query create/cancel/status/history linkage;
- Energy preserves exact progress and tiny generation rates.

## Visual evidence

Screenshots are stored in:
`reports/screenshots/direct_deposit_withdraw_energy_1561/`.

They cover Direct Deposit, HUB, Browser Shop, Withdraw states and
Energy at four viewport classes.

## Honest boundary

Public browser proof passed. Operator Withdraw browser proof remains
open. Real EFHC, USDT and payout transactions were not executed.

## Final verification

- exact inventory: `2420` nodes;
- result: `2287 passed`, `133 skipped`, `0 failed`;
- two production builds: `PASSED`;
- generated pages: `34 / 34`;
- screenshots: `10`;
- operator browser visual proof: open.
