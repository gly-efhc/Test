# v154_23 — generation rate canon tests

- Added guard test enforcing only canonical per-second generation rates.
- Banned daily/derived rate tokens and literals in runtime/API/UI files.
- Expanded canon_rules.yaml with banned literals for generation-rate drift.
