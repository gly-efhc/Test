# EFHC Bot — change report
## 2026-04-17 — v167_29 — cycle 940

## What was found
The `return_path` / `canonical_center` pair existed in runtime truth, but Hub bootstrap still relied partly on default schema behavior and live continuity surfaces did not always read both fields together. This left room for Browser-Shop to feel like a second account center instead of an execution path.

## What was changed
- hardened `backend/app/routes/hub_routes.py` so Hub flow truth now carries explicit `canonical_center` from active intent truth;
- aligned `frontend/src/lib/portal/continuityCopy.ts` to coupled semantics `return_path + canonical_center`;
- aligned `BrowserShopPage`, `HubPage`, `WebProfilePage` and `ProfileModal` to read `return_path` together with `canonical_center`;
- added focused architecture coverage for backend-first return-path semantics.

## Why it matters
Cycle 940 keeps one-profile continuity honest: Browser-Shop remains the external execution path, while Web-Profile remains the canonical account center for final state and money-sensitive review.

## Verification
- `pytest -q tests/architecture/test_payment_intent_continuity_runtime_sync.py`
- `python -m compileall backend/app`

## Artifact
- `EFHC_Bot_v167_29_cycle_940_return__path__canonical_center_hardening.zip`
