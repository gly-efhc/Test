# Change cycle v153_28 — FAQ da/hi/id/sw sections 9–12

Date: 2026-03-08

## Summary
- Added item-level translations for the new 12-section user FAQ.
- Languages covered in this cycle:
  - da
  - hi
  - id
  - sw
- Sections covered in this cycle:
  - 9 Popolnenie i pokupki / Top up and purchases
  - 10 Urovni i rang / Levels and rank
  - 11 Chastye situatsii / Common situations
  - 12 Pomoshch po FAQ / FAQ help

## Root cause
After v153_27 the new user FAQ was fully covered for
ru/en/ua/de/fr/es/it/tr/pl, but da/hi/id/sw still fell back to
en/ru for sections 9–12.

## Changes
- Updated frontend/src/data/faq/localized.ts
- Added question/answer/keyword overrides for da/hi/id/sw
  for sections 9–12

## Verification
- python ops/canon_guard.py -> OK
- changed-file line72 -> OK
- targeted TypeScript compile -> not proven in this environment
