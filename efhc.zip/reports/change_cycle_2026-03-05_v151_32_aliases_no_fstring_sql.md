Cycle v151_32

- Fixed injected canon_schema imports causing SyntaxError.
- Removed f-strings used for SQL schema interpolation.
- Added safe schema aliasing via canon_schema in migrations safe.py.
- Fixed wallet_binding_service SQL templating using _core_sql.
