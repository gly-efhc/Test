# Change cycle v153_33 — FAQ restore, referral levels and missing Q&A

## What was done

- restored additional missing RU FAQ questions from the earlier full FAQ
- added missing panel questions: price, first panel effect, generation start,
  panel life cycle, active panel limit
- added missing wallet questions: primary wallet purpose, primary wallet
  change, unlink wallet, wallet-required button behavior
- added referral bonus and referral progress FAQ subsection
- added referral progress levels 0..5 with threshold and one-time payout
- restored and expanded progress/rank FAQ with 12 energy levels and their
  meanings
- expanded FAQ help/navigation questions

## Validation

- canon_guard: OK
- TypeScript transpile of frontend/src/data/faq/ru.ts: OK
- changed-file line72: OK

## Notes

- no new CI log was provided for this archive
- the new questions are added in RU catalog first; other locales will use
  fallback until explicit localized overrides are added
