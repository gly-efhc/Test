# Change report

Cycle: 2026-03-05
Build: v151_31_fix_import_injection

Root cause (logs_59410725378):
- E999 SyntaxError caused by canon_schema import inserted
  inside parenthesized imports (sqlalchemy.orm / system_locks /
  utils_core).

Fixes:
- backend/app/models/__init__.py: move canon_schema import to
  standalone line; keep sqlalchemy.orm import block valid.
- backend/app/routes/user_routes.py: move canon_schema import
  out of system_locks import block; canonize SCHEMA.
- backend/app/services/admin/admin_*_service.py: move canon_schema
  import out of utils_core import blocks.

Notes:
- No behavior changes; only import structure and schema
  canonicalization.
