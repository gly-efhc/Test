# Change report — v165_67 — cycles 591-600 — frontend localization wave 14

## Summary
This wave addressed the most visible localization drift in the external web
surfaces introduced and expanded during prior portal/storefront/profile waves.

## Code changes
- `frontend/src/features/shop/ShopEntryPage.tsx`
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/public/locale/*.json`

## Docs
- `docs/audits/FRONTEND_LOCALIZATION_WAVE_591_600_2026_04_08.md`
- `docs/audits/FRONTEND_SANDBOX_REVIEW_NOTE_2026_04_08.md`

## Notes
- No GitHub CI run claimed.
- No full frontend build claimed.
- Sandbox reviewed, but no donor code transplanted blindly.
