# EFHC Bot — change report
## 2026-04-11 — v166_53 — cycle 850 tasks catalog type fix

### What changed
- fixed the fresh frontend typing drift in `frontend/src/pages/tasks.tsx`.
- `TaskCatalogItem` now includes `id: number`, which matches the
  backend `TaskOut` schema and the actual page logic using `it.id`.

### Verification done locally
- targeted source audit of `backend/app/schemas/tasks_schemas.py`
  confirmed that `TaskOut` includes `id`.
- changed-file review for `frontend/src/pages/tasks.tsx`.
- archive build without claiming GitHub CI green.

### Honesty boundary
- full GitHub CI was not run locally.
