# Change report — v166_17 — cycles 807-808 — 2026-04-10

## Canon correction
- removed stray `backend/migrations/versions/0002_tx_hash_locks.py` because it conflicted with the project migration canon around `0001_init.py` as the single derived ORM migration

## What changed
- kept `TxHashLock` as ORM truth
- added `payment_reconciliation_service.py`
- watcher now delegates shared confirmation rules to that service
- audit guard now explicitly checks that stray `0002` is absent

## Narrow checks
- `python ops/routes/audit_tx_hash_locks_core_contour.py`
- `python -m py_compile backend/app/services/payment_reconciliation_service.py backend/app/services/watcher_service.py backend/app/services/shop_payment_tx_hash_lock_service.py backend/app/models/shop_payment_tx_hash_lock_models.py ops/routes/audit_tx_hash_locks_core_contour.py`

## Honest limits
- local pytest remained limited by missing `sqlalchemy` in this environment
