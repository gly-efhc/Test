# Change report — v166_41 — cycles 846-850 splash and CI/doc-sync fix wave

Date: 2026-04-10

## Closed cycles
- 846 — SplashScreen component layer
- 847 — breathe animation
- 848 — initialization lifecycle integration
- 849 — Blitz/V1 splash positioning fixed in docs and cycle layer

## 850 safe subset
- updated stale NORM/SSOT counts to 36 tables / 95 routes / 90 paths
- imported `Text` in shop models and enabled `extend_existing` guard on `ShopItem`
- restored watcher compatibility alias `_parse_intent_payload`
- restored watcher compatibility marker for note propagation e2e audit
- final local release gate audit passes

## Honest note
- This report does not claim green GitHub CI.
- Cycle 850 remains the active next step until a fresh GitHub CI run confirms the remaining backend/doc-sync defect set.
