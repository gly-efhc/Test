# Change report — v170.27 / cycle 1451 CI log repair

## Summary

Cycle 1451 repaired factual failures from `logs_72682359351.zip`.
The work was limited to CI/log repair, generated frontend seam typing,
compatibility anchors, canon wording cleanup and regression guards.

## Files changed

- `backend/app/services/admin/admin_bank_service.py`
- `backend/app/services/transactions_service.py`
- `tests/architecture/test_chat_docs_intake.py`
- `tests/architecture/test_ci_log_repair_v170_27_guards.py`
- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/src/pages/admin/shop.tsx`
- `frontend/src/lib/api/generated/adminSeams.ts`
- `ops/openapi/generate_frontend_seam_types.py`
- `KERNEL.md`
- `docs/NORM/CHATS/CHATS_INDEX.md`
- `docs/NORM/CHATS/26.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1451_CI_LOG_REPAIR.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `reports/REPORTS_INDEX.md`
- `reports/generated/ci_log_repair_v170_27.json`
- `map_element.md`
- `ops/operator_kernel/cache/file_map.json`

## Deleted

No source, test or runtime file was deleted.
Transient local build/cache folders were excluded from the archive.

## Validation

- Ruff: passed.
- Canon guard: passed.
- AI laws integrity: passed.
- Targeted pytest: passed.
- Compileall for tooling/tests: passed.
- Full local pytest: not claimed due missing local dependency layer.
- Full frontend build green: not claimed.
