# Change report v150_34

- Исправлен NameError в tests/test_concurrency_exchange_all.py: добавлен импорт
  d8_str из common_schemas.
- Исправлен SQL в withdraw_service._idem_mark_used(): CAST(:pj AS jsonb)
  вместо синтаксиса с ::jsonb для bindparam.
- wallets_service: реэкспортирован STATUS_ERROR_SYS из watcher_service.
