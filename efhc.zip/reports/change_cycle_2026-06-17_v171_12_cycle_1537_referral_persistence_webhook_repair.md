# Change cycle 2026-06-17 — v171.12 / cycle 1537

Implemented referral persistence and Telegram webhook DB DI repair.

Closed locally: P0 referral attach no-commit, P0 webhook DB DI bypass, P1
static-only route proof, P2 exchange fallback and P3 WebApp bind retry marker.

No economy, money-flow, withdraw, wallet or TonConnect changes.
