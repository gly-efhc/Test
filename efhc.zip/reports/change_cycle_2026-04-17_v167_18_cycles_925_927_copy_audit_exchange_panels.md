# Change Report — v167_18 — cycles 925-927

## Summary
- Completed the linked block 925-927 without opening a new audit branch.
- Cleaned old alias wording traces on money-sensitive user surfaces.
- Unified money-sensitive copy around Hub / Browser-Shop / Web-Profile.
- Added exchange result link-back actions to Profile history and Wallet.
- Hardened panel activation consistency copy and nearest-expire display.

## Changed files
- frontend/src/lib/portal/continuityCopy.ts
- frontend/src/features/hub/HubPage.tsx
- frontend/src/features/profile/WebProfilePage.tsx
- frontend/src/features/browser-shop/BrowserShopPage.tsx
- frontend/src/pages/exchange.tsx
- frontend/src/pages/panels.tsx
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_901-1000.md
- docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md
- reports/REPORTS_INDEX.md

## Validation
- line72 checked on all changed files
- no top-level new audit/SSOT branch opened ahead of runtime work
- archive prepared as FLAT ZIP
