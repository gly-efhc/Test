# Cycle 1555 — shell, Energy runtime and public browser proof

Date: `2026-07-16`.
Output target: `EFHC_Bot_v171_30.zip`.

## Accepted HEAD

- Input: `EFHC_Bot_v171_29.zip`.
- SHA-256:
  `2c3a5e0dfa2084e678943299239b04eb5b78d4dedf9d79603670ae68e320fb08`.
- ZIP: `testzip=None`.
- Records: `4097`.
- Files: `3876`.
- Directories: `221`.
- Forbidden artifacts: `0`.

## Completed user scenario

`Browser/PWA entry -> shell -> Energy -> protected navigation -> public route`.

The browser fallback no longer replaces the application with a duplicate
mock Energy screen. It renders one compact notice and the real route. Energy
starts from validated snapshot data, exact zero remains zero and the shell
exposes localized accessible navigation while retaining protected English
visual labels.

## Language-scope root cause

The repeated three-language statement was not the runtime canon. It resulted
from conflating four independent contours:

1. the complete thirteen-language EFHC Bot interface;
2. the `RU/UK/EN` minimum smoke-test sample;
3. the three external Google Sites;
4. the English visual-label exception for bottom navigation.

The exact bot runtime remains:
`ru`, `en`, `uk`, `de`, `fr`, `es`, `it`, `tr`, `pl`, `da`, `hi`, `id`,
`sw`.

The repair is enforced by SSOT, Operator Rules, NORM, exact locale-file and
key-parity guards, document-language synchronization and browser evidence for
all thirteen languages.

## Browser proof

Public proof passed for all twelve protected routes at `390x844`:

- `/`;
- `/panels`;
- `/exchange`;
- `/tasks`;
- `/referrals`;
- `/ranks`;
- `/web-profile`;
- `/faq`;
- `/hub`;
- `/browser-shop`;
- `/withdraw`;
- `/ads`.

For each route the harness verified HTTP success, real page content, hidden
splash, no horizontal overflow, no raw runtime or i18n error, and a non-empty
screenshot. The thirteen-language matrix verifies `html lang` and localized
navigation accessibility where navigation exists.

The managed Chromium URL-block policy was not modified. Local server HTML and
resources are delivered through a controlled proof proxy before Next
hydration.

## Build repair

The default production build uses one Next worker. Two workers were not
reliably deterministic on this host. An explicit environment override remains
available. The clean webpack build path is retained.

## Tests and gates

- AI Archive Laws: passed.
- compileall: passed.
- Agent Skills Adapter: passed.
- public-copy firewall: passed.
- direct-public-API gate: passed.
- locale coverage: thirteen files and `1465` equal keys.
- targeted shell and language guards: `32 passed`.
- final archive-tree focused replay: `54 passed`.
- architecture collection: `2070 passed, 7 skipped`.
- full pytest collection: `2235 passed, 123 skipped`.
- npm clean install: passed, `103` packages; audit was not invoked.
- TypeScript: passed.
- frontend architecture: passed.
- production build: two consecutive clean passes.
- generated Next routes: `34`.
- public browser proof: `12/12` routes and `13/13` languages.
- `ruff`, `mypy`, `bandit`: not available in the local environment.

The architecture and full collections were executed in deterministic batches
created from one collected node inventory. A monolithic process accumulated
host resources and stalled, while every collected node passed in the isolated
replay. No test was omitted and no new skip or xfail was added.

## Status boundary

Established locally:

- `CODE_FIXED`;
- `TARGETED_TESTS_PASSED`;
- `LOCAL_FRONTEND_BUILD_PASSED`;
- public-scope `LOCAL_VISUAL_PROOF_PASSED`.

Not established:

- admin visual proof;
- `GITHUB_CI_VERIFIED`;
- `LIVE_TELEGRAM_VERIFIED`;
- `REAL_TONCONNECT_VERIFIED`;
- `MVP_RELEASE_AUDIT_PASSED`;
- release-ready or production-ready.

## Protected canons

Economy, panel cost, generation and balance formulas, referral rewards,
wallet binding, TonConnect, deposit, withdraw, idempotency, auth, Telegram
InitData, admin authorization, DB schema and Alembic `0001 only` were not
changed.
