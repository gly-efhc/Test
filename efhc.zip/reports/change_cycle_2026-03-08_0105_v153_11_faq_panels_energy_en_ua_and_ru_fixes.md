# Change cycle — 2026-03-08 01:05 — v153_11

## Scope
- continued FAQ implementation on top of `v153_10`
- fixed malformed RU FAQ content imported from PDF
- added EN/UA item-level translations for Panels and Energy
  generation blocks

## What changed

### 1. RU FAQ content fixes
Fixed three malformed RU FAQ pairs caused by split PDF import:
- `8.1-11` / `8.1-12`
- `11.1-2` / `11.1-3`
- `11.2-4` / `11.2-5`

These fixes restored complete questions/answers and removed
truncated fragments like `Archive?`, `обменял?`, and `регистрации?`.

### 2. FAQ item localization
Added item-level FAQ translations for:
- `8.1` Panels
- `9.1` Energy generation

Languages added in this cycle:
- `en`
- `ua`

This covers:
- panel price and lifecycle
- Activ / Archive states
- active panel limit
- base/VIP generation values
- rating/progress dependency on kWh generation

## Validation
- `python ops/canon_guard.py` — OK
- targeted TypeScript compile for FAQ data-layer — OK
- line72 for changed files — OK

## Notes
- no new `logs_*.zip` was provided in this cycle
- CI green is not claimed for the new ZIP without fresh logs
