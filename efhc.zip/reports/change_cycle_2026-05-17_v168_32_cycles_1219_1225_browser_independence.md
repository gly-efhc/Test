# Change report v168_32 cycles 1219-1225

## Scope

Emergency frontend repair after user browser launch report.

## Root cause

Core public pages treated missing Telegram `tg_id` as a reason to show
only loading UI.  This broke the browser/PWA target where the same app
must render without Telegram identity.

## Code changed

- `frontend/src/lib/browserFallback.ts`
- `frontend/src/pages/app.tsx`
- `frontend/src/pages/index.tsx`
- `frontend/src/pages/panels.tsx`
- `frontend/src/pages/exchange.tsx`
- `frontend/src/pages/tasks.tsx`
- `frontend/src/pages/ranks.tsx`
- `frontend/src/pages/withdraw.tsx`
- `frontend/public/locale/*.json`

## Documents changed

- `docs/audits/BROWSER_INDEPENDENCE_AND_BLANK_SCREEN_REPAIR_`
  `1219_1225.md`
- `docs/audits/FRONTEND_VISIBLE_ELEMENTS_CHAT_AGREEMENT_1219.md`
- `docs/audits/WEBAPP_SIMULATOR_MODEL_1220.md`
- `docs/SSOT/TERMS_GLOSSARY.md`
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- cycle plans and reports index

## Tests

- targeted architecture pytest: passed
- TypeScript check: passed after `npm ci --ignore-scripts --no-audit`
- npm build: timeout during optimized production build; not claimed

## Not claimed

- GitHub CI green
- live browser click-proof
- full visual release readiness
- real financial action without identity
