# Change report v150_69

## Changes
- Добавлен файл ci.yml (пример workflow) с шагом flake8.
- Добавлен отчёт: reports/alias_sanitation_v150_69.md.

## Alias sanitation
- В backend/frontend не найдено backend.app.* импортов.
- Tg-id алиасы (telegram_id/user_id/tgId) не обнаружены в backend/frontend.
