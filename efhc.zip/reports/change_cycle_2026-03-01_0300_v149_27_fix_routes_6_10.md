# Change cycle 2026-03-01_0300 — v149_27_fix_routes_6_10

## Что делали
Цель цикла: продолжить ремонт маршрутов по нумерованному списку — исправить маршруты №6–№10.

## Обязательные проверки (локально на распакованном ZIP)
### Repo-wide bans (backend/frontend/ops/migrations)
- telegram-id (слитно): PASS
- rank|rank|rank: PASS
- tg_id: PASS
- user-key: PASS

### Backend
- python -m compileall backend -q: PASS

### Alembic
- python -m alembic -c alembic.ini upgrade head: FAIL (в окружении чата отсутствует модуль alembic)

### Pytest
- pytest -q: FAIL (в окружении чата отсутствует sqlalchemy; это проблема окружения, не кода)

### Frontend
- package-lock.json: OK
- запрет в package-lock (applied-caas-gateway/internal.api.openai/artifactory): PASS
- npm ci / npm run build: частично проверено; исправлен TypeScript compile error (см. ниже). Полный прогон в среде чата нестабилен из‑за ограничений выполнения команд.

## Маршруты 6–10 — паспорт/фиксы

### №6 GET /admin/lotteries/history
- from: backend/app/routes/admin_routes.py:439
- goes_to: backend/app/services/lotteries_service.py::svc_list_lotteries_history
- read tables: efhc_lotteries.lotteries, efhc_lotteries.lotteries_results (LEFT JOIN)
- write tables: нет
- evidence: сервис использует модели Lotteries/LotteriesResult (schema=DB_SCHEMA_LOTTERIES)

**Фикс:**
- В svc_list_lotteries_history дефолтные статусы были ["finished","archived"], что не совпадает с каноном модели (draft/active/closed/completed).
- Заменено на ["completed","closed"].

### №7 GET /admin/lotteries/nft-claims
- from: backend/app/routes/admin_routes.py:491
- read tables: efhc_lotteries.lotteries_nft_claims
- write tables: нет

**Фикс:**
- Уточнено описание очереди статусов: pending/approved/rejected (вместо pending/sent/rejected).

### №8 POST /admin/lotteries/nft-claims/{claim_id}/mark-sent
- from: backend/app/routes/admin_routes.py:520
- read/write tables: efhc_lotteries.lotteries_nft_claims
- idempotency: Idempotency-Key header only

**Root cause (P0):**
- Роут пытался писать status="sent", но в модели LotteriesNFTClaim канон статусов: pending/approved/rejected (CHECK CONSTRAINT).
- Также отсутствовал commit(), поэтому изменения не сохранялись.

**Фикс:**
- «mark-sent» трактуем как «approved» (историческое имя ручки).
- Добавлен запрет: если claim уже rejected → HTTP 409.
- Добавлен commit().

### №9 POST /admin/lotteries/{lotteries_id}/auto-lotteries
- from: backend/app/routes/admin_routes.py:557
- goes_to: svc_admin_set_auto_lotteries
- write tables: efhc_lotteries.lotteries

**Root cause (P0):**
- Сервис менял поле auto_lotteries без commit() → изменения терялись.

**Фикс:**
- Добавлен await db.commit() в роут после вызова сервиса.

### №10 GET /admin/panels/
- from: backend/app/routes/admin_panels_routes.py:86
- read tables: efhc_core.panels (raw SQL with explicit schema)
- write tables: нет

**Root cause (P0):**
- В FastAPI ручка была объявлена как @router.get("") (то есть /admin/panels без trailing slash). В списке канона маршрут указан как /admin/panels/ — возможен 307 redirect и несовпадение surface.

**Фикс:**
- Заменено на @router.get("/") чтобы ручка была именно /admin/panels/.

## Дополнительный фикс (Frontend build blocker)
- frontend/src/pages/admin/users.tsx: использовалась функция sumScaledDown без импорта → next build падал.
- Исправлено: добавлен импорт sumScaledDown из ../../lib/format.

## Change report (файлы)
Изменены:
- backend/app/services/lotteries_service.py
- backend/app/routes/admin_routes.py
- backend/app/routes/admin_panels_routes.py
- frontend/src/pages/admin/users.tsx

Добавлены:
- reports/change_cycle_2026-03-01_0300_v149_27_fix_routes_6_10.md
