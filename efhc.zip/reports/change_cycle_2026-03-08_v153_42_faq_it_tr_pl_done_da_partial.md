# EFHC change cycle — v153_42

Date: 2026-03-08
Base ZIP: EFHC_Bot_v153_40_faq_it_tr_pl_pytest_fix.zip

## Scope
- completed remaining FAQ translations for `it`, `tr`, `pl`
- added the same new FAQ blocks for `da`

## Files changed
- frontend/src/data/faq/localized.ts
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/change_cycle_2026-03-08_v153_42_faq_it_tr_pl_done_da_partial.md

## Added item ranges
For `it`, `tr`, `pl`, `da`:
- 8.3-1 .. 8.3-14
- 8.4-1 .. 8.4-4
- 10.1-5 .. 10.1-7
- 10.2-1 .. 10.2-12
- 12.1-5 .. 12.1-7
- 12.2-1 .. 12.2-4

## Validation
- no legacy `lottery` word in `localized.ts`
- changed-file line72: OK
- targeted tests: `3 passed`

## Coverage after cycle
- `it`: 0 missing
- `tr`: 0 missing
- `pl`: 0 missing
- `da`: 35 missing
- `hi`: 75 missing
- `id`: 75 missing
- `sw`: 75 missing

## CI note
No green CI claim for this ZIP without a new GitHub
`logs_*.zip` for the new archive.
