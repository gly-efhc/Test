# Change cycle v154_19

## Что изменено
- Обновлён верхний уровень FAQ SSOT до 20 разделов по новому канону.
- В FAQ SSOT явно зафиксировано: подразделы сейчас не используются.
- Синхронизированы `docs/FAQ_SSOT.md`,
  `docs/ssot_pack/FAQ_SSOT_20_SECTIONS.json`,
  `ops/canon_rules.yaml`, `docs/SSOT_INDEX.md`,
  `docs/EFHC_CANON.md`.

## Новый верхний уровень
1. О проекте
2. Главный экран
3. Верхняя панель
4. Профиль
5. Wallet
6. Балансы и история
7. Panels
8. Energy
9. Exchange
10. Withdraw
11. Tasks
12. Referrals
13. Shop
14. Lotteries
15. Ads
16. Ranks
17. Activ-статус
18. VIP NFT
19. Уровни
20. FAQ / Помощь
