# Cycle 458

- Restored high-impact historical audit docs required by guard-tests into `docs/audits/`.
- Kept the archived copies in `artifacts/` as the deletion basket.
- Fixed the new log-driven failure cluster caused by over-aggressive archive cleanup.
