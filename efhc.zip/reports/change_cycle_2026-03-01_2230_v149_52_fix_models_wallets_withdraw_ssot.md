# Change Cycle — 2026-03-01 22:30 — v149_52

Артефакт цикла: **EFHC_Bot_v149_52_fix_models_wallets_withdraw_ssot.zip**

## 1) Что упало (истина: logs_58950476465.zip)

**Падение:** CI step `python -m compileall extracted/backend -q`.

**Excerpt:**

```text
*** Error compiling 'extracted/backend/app/models/__init__.py'...
File "extracted/backend/app/models/__init__.py", line 51
  """Примесь created_at / updated_at (UTC, tz-aware)."""
     ^^^^^^^
SyntaxError: invalid syntax
```

## 2) Root cause

`backend/app/models/__init__.py` был повреждён: внутрь docstring класса `Base`
попал фрагмент кода с определением `TimestampMixin` (сломанный merge/вклейка),
что привело к `SyntaxError` на этапе compileall.

## 3) Выбранное лечение

### A) Исправить файл целиком как каноничную «точку входа» моделей (выбрано)
- корректные `Base` и `TimestampMixin` (экспортируются из `app.models`),
- безопасный авто-импорт модулей `*_models` для наполнения `Base.metadata`,
- без бизнес-логики и DDL.

### B) Локально «закрыть» SyntaxError точечно
Не выбрано: высок риск повторного повреждения и скрытых импорто-циклов.

### C) Откатить до старой версии
Не выбрано: это ломает текущий SSOT/архитектуру v149.

## 4) Патчи (ключевые изменения)

1. **Fix compileall:** переписан `backend/app/models/__init__.py`.
2. **Импортная стабильность моделей:**
   - `backend/app/models/wallets_models.py` исправлен неверный импорт `Base` и
     добавлены `__table_args__` со схемой.
3. **Канон «таблица должна быть ORM»:**
   - добавлена ORM-модель `WalletConnectIdempotency` для
     `efhc_core.wallet_connect_idempotency` (используется
     `wallets_service.connect_wallet`).
4. **Экономическое правило (efhc_transfers_log только через transactions_service):**
   - добавлены каноничные хелперы:
     - `append_transfer_extra_info()`
     - `append_transfer_extra_info_by_idempotency_key()`
   - `withdraw_service` и `exchange_service` переведены на эти хелперы
     (убраны прямые `UPDATE efhc_transfers_log ...`).
   - `panels_service` переведён на `append_transfer_extra_info_by_idempotency_key`
     вместо прямых `UPDATE efhc_transfers_log`.
5. **Детерминированный sanity 0001:**
   - `backend/migrations/versions/0001_init.py` теперь берёт
     `expected_tables` из `docs/ssot_pack/SSOT_TABLES_ORM.csv`.

## 5) SSOT обновления

- `docs/ssot_pack/SSOT_TABLES_ORM.csv`:
  - добавлена таблица `efhc_core.wallet_connect_idempotency`.
- `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv`:
  - заполнены маршруты №81–91 (user/wallets/withdraw) с read/write_tables,
    флагами и evidence.
- `docs/ssot_pack/SSOT_ROUTES_TABLES_MIGRATIONS.csv`:
  - заполнены маршруты №81–91 и подтверждено покрытие 0001.

## 6) Реестр ошибок

- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`:
  - добавлена запись по CI failure `logs_58950476465.zip` (compileall/SyntaxError).

## 7) Ожидаемая проверка в CI (цель цикла)

- `python -m compileall backend -q` — PASS (закрывает текущий CI-fail).
- Далее по канону CI должен дойти до:
  - `cd backend && alembic -c alembic.ini upgrade head` (Postgres-only)
  - `pytest -q`

