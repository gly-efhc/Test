# v167_41 — document layer cleanup and audit transfers

## What changed
- fixed approved 9-layer vocabulary in AI layer;
- added `docs/AI/AI_DOCUMENT_LAYERS_CANON.md`;
- moved obvious audit and release-evaluation documents from `docs/GENERAL/*` to `docs/audits/*`;
- kept temporary and operational status documents below SSOT;
- did not rewrite historical change reports.

## Documents moved from GENERAL to AUDIT
- MVP_AUDIT_300.md
- READINESS_AUDIT.md
- RELEASE_RISK_AUDIT_310.md
- RELEASE_RISK_AUDIT_328.md
- SANDBOX_AUDIT_INDEX.md
- SHIP_NO_SHIP_AUDIT_324.md
- USDT_REAL_JETTON_DONOR_AUDIT_AND_TRANSFER_MAP.md

## Notes
This pass is a document architecture cleanup pass, not a new product feature cycle.
