# Change Cycle — 2026-03-08 — v154_05

## Что подтверждено
- По прямому аудиту `frontend/public/locale/*.json`:
  все 13 JSON-словарей имеют полный key parity с `ru.json`.
- По прямому аудиту `frontend/src/data/faq/localized.ts`:
  все 12 не-RU языков имеют по 144 FAQ override-id,
  то есть полный parity с `ru.ts`.
- Локально проходят:
  - `tests/architecture/test_max_line_length_72.py`
  - `tests/architecture/test_no_banned_rank_terms.py`
  - `tests/efhc_backend/unit/test_no_legacy_words.py`
  - `tests/test_no_placeholders.py`

## Что было сделано
- Добит отсутствующий FAQ-хвост для:
  `en`, `ua`, `de`, `fr`, `es`, `it`, `tr`, `pl`.
- Убран русский fallback по отсутствующим FAQ-id
  в этих языках.
- Исправлены guard-дефекты после добивки:
  - long lines > 72
  - banned legacy substring внутри `generating`

## Ограничение
- Свежего `logs_*.zip` на новый архив нет.
- Полный зелёный CI не заявляется.

## Итог
- Внедрение 13 языков по UI locale parity завершено.
- Внедрение 13 языков по FAQ id parity завершено.
- Для части новых FAQ-хвостов в `ua/de/fr/es/it/tr/pl`
  использован английский fallback-текст вместо русского,
  чтобы закрыть реализацию без пропусков по id.
