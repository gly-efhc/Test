# Change report — v166_21 — cycles 815-816 — 2026-04-10

## What changed
- added `backend/app/services/reconcile_diagnostics_service.py`
- `AdminTonReconcile` now returns structured diagnostics summary
- added precision-edge transport fraud tests

## Checks
- `PYTHONPATH=backend pytest -q tests/architecture/test_watcher_transport_precision_edges.py -q`
- `python -m py_compile backend/app/services/reconcile_diagnostics_service.py backend/app/routes/admin_routes.py`
