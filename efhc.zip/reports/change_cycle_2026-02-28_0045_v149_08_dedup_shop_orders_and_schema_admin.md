# Change cycle 2026-02-28_0045 (v149_08) — Dedup shop_orders + DB_SCHEMA_ADMIN canon

## SSOT inputs
- HEAD: efhc.zip (uploaded in chat)
- Logs: logs_58890615032.zip (ModuleNotFoundError: No module named 'backend')

## What was fixed
1) **ORM duplicate for `shop_orders`**
- Problem: `ShopOrder` / `shop_orders` was declared in two modules:
  - backend/app/models/order_models.py
  - backend/app/models/shop_models.py
- Fix: `order_models.py` now only re-exports the canonical `ShopOrder` from `shop_models.py` (single ORM definition).

2) **Canonical admin schema config**
- Problem: admin schema name was used via fallbacks like `getattr(settings, "DB_SCHEMA_ADMIN", "efhc_admin")`, which makes schema naming non-canonical and “floating”.
- Fix:
  - Added `DB_SCHEMA_ADMIN` to backend/app/core/config_core.py (Settings).
  - Replaced fallbacks in code with `settings.DB_SCHEMA_ADMIN` / `S.DB_SCHEMA_ADMIN`.

3) **Wrong schema used for core table in admin stats**
- Problem: admin stats queried `shop_orders` via `{SCHEMA_ADMIN}.shop_orders`, but `shop_orders` is a core table by meaning and by ORM.
- Fix: admin_stats_service now uses `{SCHEMA_CORE}.shop_orders` and defines `SCHEMA_CORE = S.DB_SCHEMA_CORE`.

## Verification (local, on extracted ZIP)
- Repo-wide bans (telegram-id, rank/rank/rank, tg_id, user-key): PASS
- python -m compileall backend -q: PASS

## Files changed
- backend/app/models/order_models.py
- backend/app/core/config_core.py
- backend/app/routes/deposit_routes.py
- backend/app/services/nft_check_service.py
- backend/app/services/admin/admin_*.py (schema fallback cleanup)
- backend/app/services/admin/admin_stats_service.py
- reports/REPORTS_INDEX.md
- reports/change_cycle_2026-02-28_0045_v149_08_dedup_shop_orders_and_schema_admin.md
