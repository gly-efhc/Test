# CHANGE CYCLE 2026-06-08 / v170.62 / cycle 1486

## Cycle

1486 — Admin Withdrawals Dashboard Upgrade

## Summary

`/admin/withdrawals` now has a read-only Grafana-like dashboard layer for
withdrawal queue control, status distribution, operator attention, age
buckets and safe decision-order visibility.

## Added

- `frontend/src/components/admin/AdminWithdrawalsDashboardRuntime.tsx`
- `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_WITHDRAWALS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1486_ADMIN_WITHDRAWALS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_withdrawals_dashboard_upgrade_v170_62.json`
- `tests/architecture/test_admin_withdrawals_dashboard_upgrade.py`

## Changed

- `frontend/src/pages/admin/withdrawals.tsx`
- `frontend/src/styles/globals.css`
- kernel, map, cycle, report and test manifests

## Safety

No backend, economy, OpenAPI, dependency, lock-file, CI/workflow,
wallet, money-flow or write-flow changes.

Approve, reject, TonConnect payment and consistency repair remain in the
existing guarded controls.

Grafana and Песочница remain reference-only layers.
