# Change report v150_06

Источник истины:
- logs_59094682436.zip
- HEAD ZIP: EFHC_Bot_v150_05_clean_no_cache.zip

## Что упало
alembic upgrade head упал на 0001 sanity:
"tables_count_expected_38_got_39".

## Root cause
SSOT_TABLES_ORM.csv не был обновлён после добавления ORM-таблицы
"efhc_core.unmatched_incoming" (модель UnmatchedIncoming).
0001_init.py берёт ожидаемое число таблиц из SSOT_TABLES_ORM.csv,
поэтому sanity стала ложнопадающей.

## Что исправлено
1) docs/ssot_pack/SSOT_TABLES_ORM.csv
   - добавлена строка для efhc_core.unmatched_incoming.

2) docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv
   - добавлена строка для efhc_core.unmatched_incoming (0001/create).

## Ожидаемый эффект
0001 sanity использует актуальный SSOT_TABLES_ORM.csv и не падает на
расхождении количества таблиц.
