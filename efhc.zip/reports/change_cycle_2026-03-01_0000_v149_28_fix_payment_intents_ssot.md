# Change report — v149_28_fix_payment_intents_ssot

## Scope
SSOT sync for route `/payment-intents/{intent_id}`: align tables evidence with actual SQL usage in `payment_intents_service.py`.

## Changes
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
  - GET /payment-intents/{intent_id}
    - read_tables: `efhc_core.payment_intents`
    - write_tables: empty
    - flags: empty (removed any admin-schema implication)
    - evidence_refs: `backend/app/services/payment_intents_service.py:603;253;327`

## Rationale (code truth)
`SCHEMA = DB_SCHEMA_CORE (default efhc_core)` and the route handler reads intent status via SELECT from `{SCHEMA}.payment_intents` (line 603). Table references at lines 253/327 confirm table identity within service.

