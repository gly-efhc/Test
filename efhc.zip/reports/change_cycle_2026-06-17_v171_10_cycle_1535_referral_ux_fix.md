# Change cycle report — v171.10 / cycle 1535

Closed referral deeplink binding P0 and public UX P2 findings from
`a_v171_09.md` / `tz_v171_09.md`.

Runtime economy, money-flow, wallet-flow, withdraw business logic and
TonConnect canon were not changed.

Local checks:

- targeted referral/frontend/i18n guards: `20 passed`;
- `python -m compileall -q backend ops scripts tests`: passed.

Not claimed: GitHub CI green, full pytest green, frontend build green, live
Telegram proof, real TonConnect proof, release-ready, production-ready.
