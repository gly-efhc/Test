# Change Report — v149_58 — SSOT NO_DB flags

Дата (UTC): 2026-03-01T00:50:00Z

## Изменения
- SSOT_ROUTE_TABLE_MAP.csv: добавлены flags `NO_DB` для маршрутов:
  - GET /health
  - GET /cron/tick (дополнительно: CRON_ORCHESTRATOR; сохранён cron_secret_optional)
  - GET /admin/ads/providers
  - GET /nft/has_vip (дополнительно: EXTERNAL_INTEGRATION)
  - GET /skins/catalog
- SSOT_ROUTES_TABLES_MIGRATIONS.csv: синхронизированы flags + all_tables_created_in_0001=TRUE для этих маршрутов.
- docs/ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md: добавлено правило аудита NO_DB:
  - при наличии NO_DB пустые read/write допустимы, но evidence_refs обязателен.

## Причина
Эти маршруты не требуют БД (health/cron orchestration/static catalog/external integration), поэтому паспорт маршрута фиксируется через NO_DB + evidence_refs без read/write таблиц.
