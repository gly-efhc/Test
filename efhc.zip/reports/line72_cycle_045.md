# line72_cycle_045

## What was done

- Tightened migration smoke so it cannot silently skip in full CI.
- Kept minimal environments lightweight: missing deps become skip only when
  EFHC_CI_FULL is not enabled.

## Files changed

- tests/test_migrations_upgrade_head.py
  - Replaced importorskip() with a small helper:
    - EFHC_CI_FULL=1 -> missing deps = hard fail.
    - otherwise -> skip.

## line72 exceptions

- None.

## Checks

- python -m compileall backend -q: PASS
- pytest -q: PASS

## What remains

- Nothing for this subtask.
