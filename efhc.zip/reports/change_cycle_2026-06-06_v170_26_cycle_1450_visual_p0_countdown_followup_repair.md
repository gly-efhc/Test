# Change report — v170.26 / cycle 1450

Cycle: `1450 — visual P0 countdown follow-up repair`.

## Summary

Repaired and guarded the additional visual/i18n/buttons UX audit findings
from the v170.23/v170.24 audit bundle. The cycle keeps runtime changes in
frontend display/i18n/UX only and does not touch economics, backend
contracts, DB migrations or CI/workflows.

## Main changes

- Panels countdown proof strengthened with explicit second constants and
  arithmetic tests.
- Admin Withdrawals mobile filter/KPI labels kept Russian and operator
  readable.
- Withdraw history balance type remains humanized through
  `balanceTypeLabel(...)`.
- Admin Tasks runtime badges are Russian and no longer expose internal
  English helper/moderation labels.
- Locale ghost nested objects were removed; all locale files are flat and
  keep equal key counts.
- HUB trust rail now has only the two canonical visual spans.
- Added/imported the additional audit source files into docs/reports.

## Not changed

- EFHC economics.
- Backend contracts.
- DB migrations.
- CI/workflows/lock files.
- Test suite coverage was not weakened.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Frontend build green.
- Release-ready.
- Browser screenshots.
- Live Telegram/TonConnect proof.
