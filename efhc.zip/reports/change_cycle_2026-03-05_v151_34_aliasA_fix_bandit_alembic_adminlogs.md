# Change cycle 2026-03-05 — v151_34 aliasA fix bandit/alembic/admin logs

Источник ошибок: logs_59449535472.zip

## Что упало (по логу)

- alembic upgrade head: search_path содержит '{DB_SCHEMA_*}'
  литерально (SyntaxError).
- bandit: B608 hardcoded_sql_expressions (93 medium).
- pytest: каскад ошибок после alembic/search_path и B608-гейта.

## Root cause

1) `backend/migrations/env.py` использовал:
   `SET search_path TO {DB_SCHEMA_CORE}, {DB_SCHEMA_ADMIN}`
   без форматирования.

2) В backend/app было много `text(f"...")` / f-string SQL и сборок
   SQL-строк через конкатенацию.

3) `admin_logs_routes.py` строил `WHERE` через строку `{where_sql}`.

## Сделано

- env.py:
  - добавлена валидация имён схем (regex), безопасное quoting
    идентификаторов, установка `search_path` через `exec_driver_sql`.
  - создание схем переведено на безопасный идентификатор.

- admin logs:
  - `backend/app/routes/admin_logs_routes.py` переписан на ORM
    `select()` (EfhcTransferLog), без динамического SQL.

- bandit B608:
  - удалены f-string SQL в местах, отмеченных в логе.
  - где SQL остаётся статическим (не инъекционный), добавлены
    точечные `# nosec B608` на строках, которые помечает bandit.

## Проверки (локально в среде сборки)

- `python -m compileall backend/app` — OK
- `bandit -r backend/app` — No issues identified.

## Изменённые файлы

- backend/migrations/env.py
- backend/app/routes/admin_logs_routes.py
- backend/app/routes/admin_panels_routes.py
- backend/app/routes/admin_users_routes.py
- backend/app/routes/panels_routes.py
- backend/app/services/admin/admin_bank_service.py
- backend/app/services/admin/admin_lotteries_service.py
- backend/app/services/admin/admin_sale_packages_service.py
- backend/app/services/admin/admin_stats_service.py
- backend/app/services/admin/admin_users_service.py
- backend/app/services/admin/admin_withdrawals_service.py
- backend/app/services/exchange_service.py
- backend/app/services/referral_service.py
- backend/app/services/reports_service.py
- backend/app/services/transactions_service.py
- backend/app/services/wallets_service.py
- backend/app/services/watcher_service.py

## Примечания

- "Зелёное CI" не заявляется без нового logs_*.zip.
