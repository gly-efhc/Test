# Change cycle 2026-03-01_1900 — v149_49_fix_timestampmixin_docs_audits

## Основание (logs)
- logs_58945844276.zip: ImportError TimestampMixin from app.models (alembic upgrade head)

## Изменения
- Fix: добавлен TimestampMixin в app.models (__init__.py); tasks_models переведён на общий mixin.
- Docs: добавлены RU-описания SSOT для таблиц/схем и маршрутов.
- Audits: добавлен новый аудит (UA) + перевод (RU).
- Registry: добавлена запись про ImportError TimestampMixin.

## Кэш/мусор
Перед упаковкой очищены __pycache__, *.pyc, .pytest_cache и прочие кеши (не включены в ZIP).
