# Change report v150_39

Источник: logs_59174134732

## Исправления
- Убран агрегатор импортов в backend/app/services/__init__.py для устранения
  циклических импортов при импортировании подмодулей пакета.
- Добавлен backend/app/services/common_errors.py (EfhcConflictError и базовые
  ошибки), требуемый admin_withdrawals_service и роутами.

## Примечания
- ZIP FLAT, без кешей.
