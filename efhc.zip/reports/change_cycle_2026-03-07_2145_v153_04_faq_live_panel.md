# Change Cycle — 2026-03-07 21:45 — v153_04

## Scope
- live FAQ panel instead of placeholder
- RU SSOT FAQ content from approved PDF
- indexed search by words
- Telegram-native section -> subsection -> question navigation

## Confirmed input basis
- HEAD ZIP: `EFHC_Bot_v153_03_referral_links_profilemodal_sync.zip`
- approved RU FAQ PDF content
- no fresh CI log for this new archive yet

## What was implemented
- replaced `/faq` placeholder page with a live FAQ screen
- added FAQ catalog structure:
  - 17 sections
  - 25 subsections
  - 115 questions and answers
- added search across:
  - section titles
  - subsection titles
  - questions
  - answers
- added deep-link state support via query params:
  - `section`
  - `subsection`
  - `item`
- kept Telegram-native mobile card flow:
  - sections list
  - subsection list
  - accordion questions
  - related questions block

## Files
- `frontend/src/pages/faq.tsx`
- `frontend/src/data/faq/types.ts`
- `frontend/src/data/faq/index.ts`
- `frontend/src/data/faq/ru.ts`

## Local verification
- `python ops/canon_guard.py` -> OK
- `npx tsc --noEmit` in `frontend/` -> OK
- line72 checked on changed files -> OK

## Important status note
- full green CI is NOT claimed
- 13-language adaptive FAQ translations are NOT completed in this
  cycle
- current implementation uses approved RU FAQ content as canonical
  source and is ready for later per-language catalogs
