# EFHC Bot Change Cycle — v149_34_fix_routes_16_20_ssot_numbered

## Scope
- Routes 16–20: паспорта (tables + evidence) в SSOT_ROUTE_TABLE_MAP.csv
- SSOT: добавлен SSOT_ROUTES_NUMBERED.csv (нумерация маршрутов)
- Code: добавлены alias-функции в transactions_service для admin_routes

## Changes
1) backend/app/services/transactions_service.py
   - Added wrappers:
     - credit_user_main_from_bank_by_tg_id
     - credit_user_bonus_from_bank_by_tg_id
     - debit_user_main_to_bank_by_tg_id
     - debit_user_bonus_to_bank_by_tg_id

2) docs/ssot_pack/SSOT_ROUTES_NUMBERED.csv
   - Generated from SSOT_ROUTES.csv; sort: path, method, file, line; n=1..N

3) docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv
   - Filled routes 16–20 (read_tables/write_tables/flags/evidence_refs)

## Notes
- CI падения фиксируются только по logs_*.zip.
