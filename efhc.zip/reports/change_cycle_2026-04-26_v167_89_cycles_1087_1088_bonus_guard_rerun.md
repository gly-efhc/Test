# Change report — v167_89 — cycles 1087-1088

## Summary
- reran focused FAQ panel activation guard and user-text bonus canon guard after 1079-1086;
- active FAQ and active locale values remain clean under the panel + bonus canon;
- mixed user-facing slice closed with residual technical backend naming only.
