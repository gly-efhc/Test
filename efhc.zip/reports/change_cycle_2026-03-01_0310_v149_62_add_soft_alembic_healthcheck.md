# Change cycle 2026-03-01 03:10 (v149_62)

## Goal
Add a SOFT Alembic healthcheck test.
Must never fail CI, only warn and print diagnostics.

## Changes
- tests/test_alembic_healthcheck_soft.py
  Add SOFT healthcheck for repo structure, compileall,
  alembic history, and offline --sql.

- docs/TESTS_CATALOG.md
  Register the new test in the SSOT tests catalog.

## Notes
- The test always ends with `assert True`.
- Long output is emitted via warnings + print.

## Checks
- Line length <= 72 for the new test file.
