# line72_cycle_032

SSOT Panels — цикл 3/10 (Services).

## Что сделано

- Обновлён `panels_service` под SSOT-нити панелей:
  - создание панелей теперь пишет `public_id` по схеме `ID########` через
    `NULL` при INSERT и UPDATE в той же транзакции;
  - активность/архив определяются сравнением `expires_at` с
    server_now_utc (передаётся как параметр запроса), без `now()` БД;
  - добавлена replay-устойчивость покупки: при повторе по одному
    Idempotency-Key сервис возвращает те же панели и не берёт новый
    sequence id;
  - audit-поля для операции создания панелей мержатся в `extra_info`
    записи списания (schema_version v1, op_type, status).

## Изменённые файлы

- backend/app/services/panels_service.py

## Исключения 72

- Нет.

## Проверки

- python -m compileall backend -q  PASS
- pytest -q  PASS
