# Change report — v167_17 — cycles 922-924

## Scope
- Withdraw/operator long-run regression pack
- No new audit branch; runtime/UI hardening only

## What changed
- Admin withdrawals page now exposes explicit regression controls for repeat/conflict cases: refresh selected case, repair consistency, operator regression guidance.
- User-facing withdraw page now reads the latest final outcome bundle from `/api/v1/me/withdraw-outcomes/{request_id}` and renders it next to request/history context.
- Removed duplicate return-to-money-center call after withdraw creation.
- Added architecture guard test that locks both operator regression controls and latest outcome consistency.

## Verification
- `pytest -q tests/architecture/test_withdraw_operator_regression_sync.py` → 2 passed
- Frontend full build not used as CI proof in this environment.
