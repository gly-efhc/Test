# Change report v151_02

## Source
Fixes based on CI logs: logs_59324278244.zip

## Fixed
- tests/test_migrations_upgrade_head.py
  - Canon DB schemas: check tables in efhc_core schema, not public.
  - Replaced `SELECT 1 FROM users` with schema-qualified query
    using env `DB_SCHEMA_CORE` (default efhc_core).
  - Kept line72.

## Packaging
- Removed caches before ZIP: __pycache__, .pytest_cache, node_modules,
  .next, dist/build, *.pyc
- ZIP is FLAT (repo root at archive root)
