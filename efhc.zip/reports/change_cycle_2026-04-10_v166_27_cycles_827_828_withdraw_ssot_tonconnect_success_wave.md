# Change Report — v166_27 — Cycles 827-828

Дата: 2026-04-10
HEAD: EFHC_Bot_v166_27_cycles_827_828_withdraw_ssot_tonconnect_success_wave.zip

## Scope
- 827 — withdraw admin TonConnect contour + SSOT actualization
- 828 — Browser-Shop success-screen completion

## Confirmed changes
- added `docs/SSOT/WITHDRAW_ADMIN_TONCONNECT_SSOT.md`
- enriched admin withdrawals backend response with payout metadata for ready cards
- updated `frontend/src/pages/admin/withdrawals.tsx` with pending payout cards and TonConnect wallet action
- added `frontend/src/lib/ton/efhc-withdraw-transfer.ts`
- updated Browser-Shop confirmed-state copy to a closed success message

## Narrow checks actually run
- `python -m py_compile backend/app/services/admin/admin_withdrawals_service.py`
- local TypeScript transpile checks for `frontend/src/pages/admin/withdrawals.tsx`
- local TypeScript transpile checks for `frontend/src/features/browser-shop/BrowserShopPage.tsx`

## Honest residuals
- live TonConnect operator payout was not proven in this environment
- this is not a mainnet payout proof
