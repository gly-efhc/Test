# Cycle 454

- Fixed the new GitHub CI failure in `test_concurrency_exchange_withdraw`.
- The canonical concurrent outcome now allows either withdraw-raced-out (`50/-50`) or successful exchange+withdraw (`40/-40`).
