v149_76
- 0001_init.py: create_all(checkfirst=False)
- 0001_init.py: added diag tables_in_schemas
- env.py: avoid reassigning connection; use conn2
