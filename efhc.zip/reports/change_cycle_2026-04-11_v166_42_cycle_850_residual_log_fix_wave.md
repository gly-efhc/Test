# Change report — v166_42 — cycle 850 residual log fix wave

Date: 2026-04-11

## Scope
- Continue only the active residual hard-fix wave for cycle 850 from fresh GitHub CI logs.
- No new cycle range was invented or started.

## Confirmed fixes in this pass
- fixed swapped guard-reason returns in
  `backend/app/services/payment_reconciliation_service.py`
  so asset mismatch returns `asset_guard.reason` and amount mismatch returns
  `amount_guard.reason`
- replaced broad `except ...: pass` in the same service with warning logging
  to remove Bandit `B110` residual
- tightened watcher compatibility typing in
  `backend/app/services/watcher_service.py` and
  `backend/app/services/wallets_service.py` for the shared
  `ConfirmPaymentResult` bridge
- fixed frontend seam type drift in
  `frontend/src/lib/api/generated/adminSeams.ts`
  so `AdminReferralSummaryResponse.items` points to
  `AdminReferralSummaryItem[]`
- fixed the generator source in
  `ops/openapi/generate_frontend_seam_types.py`
  so future regeneration preserves the corrected referral item alias
- reduced duplicate model-import pressure in
  `backend/migrations/versions/0001_initial_release_schema.py`
  by importing only not-yet-loaded `*_models.py` modules during 0001

## Local narrow checks
- `python -m py_compile` passed for touched backend files
- `python ops/openapi/generate_frontend_seam_types.py` passed
- `npx tsc --noEmit --pretty false` passed in `frontend/`

## Honest note
- This pass does not claim green GitHub CI.
- Cycle 850 remains the active verification tail until a fresh GitHub CI run
  confirms the residual Alembic / pytest / lint / type-check state.
