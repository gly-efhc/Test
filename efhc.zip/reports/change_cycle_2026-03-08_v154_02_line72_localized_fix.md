# Change Cycle v154_02

Date: 2026-03-08

## Source of truth
- HEAD ZIP: EFHC_Bot_v154_01_faq_da_hi_id_sw_full.zip
- No fresh logs_*.zip for this HEAD ZIP
- Work based on direct code audit and local targeted checks

## What was found
- frontend/src/data/faq/localized.ts had 208 line72 violations
- All violations were long string literals in FAQ translations

## What was changed
- Split long string literals in localized.ts without changing FAQ ids
  or 12-section structure
- Kept all language blocks and existing FAQ mappings intact

## Local checks
- test_no_banned_rank_terms.py -> passed
- test_no_legacy_words.py -> passed
- test_no_placeholders.py -> passed
- test_max_line_length_72.py -> passed

## Notes
- Full green CI is not claimed because no fresh logs_*.zip exists for
  the new archive
