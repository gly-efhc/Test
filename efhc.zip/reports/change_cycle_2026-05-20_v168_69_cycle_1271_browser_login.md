# Change report — v168_69 — cycle 1271 browser login

## HEAD

`EFHC_Bot_v168_68_cycles_1268_1270_frontend_control.zip`

## Cycle

1271 — browser login page / demo preview.

## Summary

Added a browser/PWA login/demo panel shown when Telegram `tg_id` is
absent. The panel opens Telegram login and shows an Energy demo preview,
so browser launch is not perceived as a blank or white screen.

## Code changed

- `frontend/src/components/BrowserLoginDemo.tsx`
- `frontend/src/components/Layout.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`
- `tests/architecture/test_browser_login_demo_guard.py`

## Docs changed

- `docs/cycles/WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md`
- `docs/frontend/FRONTEND_IMPLEMENTATION_PLAN.md`
- `docs/NORM/CHAT_TRANSCRIPT.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/audits/FRONTEND_CYCLE_1271_BROWSER_LOGIN_AUDIT_V168_69.md`
- `reports/REPORTS_INDEX.md`
- `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`

## Not changed

Backend code, database schema, migrations, Energy economics and bottom
navigation were not changed.

## Checks

- frontend route checker: OK;
- Python compileall: OK;
- architecture guard tests: 32 passed;
- `npm ci`: OK;
- `tsc --noEmit`: OK;
- locale JSON validation: OK;
- `next build --no-lint`: compiled successfully but timed out
  while collecting page data;
- release ZIP integrity check.

## Not claimed

No GitHub CI green, no Docker runtime smoke and no live screenshot proof
are claimed in this cycle.
