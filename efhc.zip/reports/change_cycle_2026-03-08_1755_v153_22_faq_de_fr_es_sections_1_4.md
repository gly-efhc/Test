# v153_22 — FAQ de/fr/es sections 1-4

## What changed

Added item-level translations for the rebuilt user-facing FAQ on:

- `de`
- `fr`
- `es`

Covered sections:

1. Balances
2. Balance history
3. Panels and energy
4. Exchange and withdraw

## Files

- `frontend/src/data/faq/localized.ts`
- `reports/REPORTS_INDEX.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`

## Local checks

- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK
- targeted TypeScript compile of FAQ data-layer -> not proven in this
  environment because `tsc` is unavailable locally

## Notes

This cycle continues the new 12-section user-facing FAQ model.
Fallback order remains `language -> en -> ru`.
No fresh `logs_*.zip` on this new archive, so green CI is not claimed.
