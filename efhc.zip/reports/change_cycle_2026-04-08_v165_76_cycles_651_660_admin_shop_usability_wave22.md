# Change report — 2026-04-08 — v165_76 — cycles 651-660 admin+shop usability wave 22

## Scope
Еще один sandbox-driven pass по admin analytics readability и внешнему shop catalog UX.

## Code changes
- Admin shop surface improved
- Browser shop search/filter/product-card workflow added
- Reports page gained charts/table analytics slice

## Docs
- ADMIN_SHOP_SANDBOX_AUDIT_651_660_2026_04_08.md
- ADMIN_SHOP_USABILITY_WAVE_651_660_2026_04_08.md
- ADMIN_SHOP_REAUDIT_SLICE_651_660_2026_04_08.md

## Validation
- locale JSON parsed successfully
- archive rebuilt
- no GitHub CI run
