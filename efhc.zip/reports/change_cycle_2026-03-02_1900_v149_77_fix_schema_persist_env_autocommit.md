v149_77

Fix: persistent schemas/tables after alembic.

- env.py: create schemas via AUTOCOMMIT before migrations.
- 0001_init.py: remove CREATE SCHEMA, add hard to_regclass check.

Logs evidence: logs_59080491321.zip (missing tables after alembic).
