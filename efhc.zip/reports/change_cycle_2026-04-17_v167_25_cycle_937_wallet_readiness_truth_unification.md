# Change Report — v167_25 — Cycle 937

## What was found
The live launcher path still treated almost any `action_denied` state as if the only next step were wallet sync. This contradicted the backend readiness contract when `primary_cta` was `open_telegram_handoff` or `unavailable`.

## Root cause
The backend truth-layer had already become richer than the frontend launcher branch. `readiness_state` and `primary_cta` were canonical, but the launcher still used an older coarse rule that collapsed blocked states into a wallet-only redirect.

## What changed
- `frontend/src/lib/portal/shopLauncher.ts` now classifies launcher state by canonical `primary_cta` before deciding where to send the user.
- `DepositModal` now distinguishes wallet sync, Telegram handoff and external-unavailable states instead of showing one generic wallet-sync block.
- `BrowserShopPage` now renders separate blocked-state cards for wallet sync, Telegram handoff and external-flow missing.
- `HubPage` no longer opens wallet sync from the readiness row unless backend truth explicitly says `wallet_sync_required`.
- Per approved policy, alias cleanup stayed limited to live-facing traces and did not touch legacy compat markers.

## Verification
- `python -m compileall backend/app`
- `pytest tests/architecture/test_payment_intent_continuity_runtime_sync.py -q`
- attempt to run `tests/test_payment_intent_status_owner_only.py` stopped in this environment because `sqlalchemy` is not installed
- attempt to run `npm run build` stopped in this environment because `next` is not available

## Result
Cycle 937 strengthens the backend truth → launcher contract → surface alignment chain without opening new UI scope. Readiness routing now follows canonical backend truth more honestly on the live release-core surfaces.
