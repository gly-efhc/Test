# v174.35 — Admin unified identity resolver

Parent authority: `EFHC_Bot_v174_34`.

Owner-authorized scope only:
- add read-only `GET /admin/users/resolve-provider?q=...`;
- resolve exact Global ID, username, active verified provider subject, or active verified TON wallet into one Global ID;
- return 404 when unknown and 409 when identifiers point to different owners;
- expose no provider metadata;
- add provider-subject index to the current first-release schema authority;
- synchronize OpenAPI, SSOT route inventory, generated frontend seam and tests.

No changes to financial semantics, panel economics, auth/session write behavior, VIP/NFT write behavior, wallet-reset behavior, or Offline Demo machinery.
