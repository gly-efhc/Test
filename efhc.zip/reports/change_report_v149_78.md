# Change report v149_78

Источник логов: logs_59083780685.zip.
Источник кода: EFHC_Bot_v149_77_fix_env_autocommit_schema_persist.zip.

## Что упало

1) pytest:
- InvalidRequestError: A transaction is already begun on this Session.
- Payment intents: PACKAGE_NOT_FOUND.
- Payment intents: AmbiguousParameterError (text vs bigint).
- Тестовые вставки: bool columns vs int (DatatypeMismatch).
- Тестовая вставка users: INSERT has more expressions than columns.

2) Runtime (в логах тестов):
- watcher_service пишет в efhc_core.unmatched_incoming,
  но таблицы нет.

## Где

- backend/app/services/transactions_service.py
- backend/app/services/panels_service.py
- backend/app/services/withdraw_service.py
- backend/app/services/payment_intents_service.py
- backend/app/models/ton_logs_models.py
- tests/test_concurrency_exchange_all.py
- tests/test_concurrency_exchange_withdraw.py
- tests/test_concurrency_withdraw_double.py
- tests/test_payment_intents_lifecycle_double_payments.py
- tests/test_payment_intents_payload_unique.py
- tests/test_payment_intent_status_owner_only.py

## Root cause

- AsyncSession (SQLAlchemy 2.x) включает autobegin при первом
  запросе. Сервисы, которые делают `await db.begin()`,
  падают при уже открытой транзакции.

- create_intent_deposit_by_package требует активный package
  в efhc_core.shop_items (quantity_efhc + extra.price_asset_d8).
  Тесты не создавали пакет.

- В SQL-конкатенации payload параметры использовались как bigint
  и как text без cast → AmbiguousParameterError.

- В тестах использовались 0/1 для boolean столбцов.

- watcher_service обращается к таблице unmatched_incoming,
  но ORM/0001 её не создавали.

## Выбранный вариант

Единый вариант: привести транзакционную семантику сервисов
к канону Autobegin-safe через begin_nested и убрать ложные
DDL/данные из тестов.

## Патч

- transactions_service:
  - добавлен `_tx_context()`;
  - `_run_idempotent` переведён на контекстный менеджер,
    begin_nested при активной транзакции;
  - `spend_user_to_bank_bonus_then_main` переведён на `_tx_context()`;
  - добавлен запрет ухода банка в минус (ValueError).

- panels_service:
  - добавлен `_tx_context()`;
  - begin() заменён на `_tx_context()`.

- withdraw_service:
  - audit-insert переведён на begin_nested.

- payment_intents_service:
  - cast в payload SQL (`nid::text`, `(:tg)::text`);
  - get_intent_status_for_user возвращает `{ok: bool, ...}`.

- ton_logs_models:
  - добавлена ORM-модель UnmatchedIncoming (efhc_core).

- tests:
  - поправлены raw INSERT под boolean;
  - добавлен seed deposit package в shop_items;
  - убран SQLite-код из payment_intents_payload_unique;
  - исправлены SELECT/ASSERT в concurrency_exchange_all.

## Реестр ошибок

- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md:
  - добавлены записи AG/AH (истина: logs_59083780685.zip).

## SSOT / docs

- SSOT CSV не регенерировались в этом цикле.
  Требуется следующий цикл: обновить SSOT_TABLES_ORM/0001,
  чтобы отражать efhc_core.unmatched_incoming.

