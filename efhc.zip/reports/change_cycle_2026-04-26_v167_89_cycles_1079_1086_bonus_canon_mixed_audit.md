# Change report — v167_89 — cycles 1079-1086

## Summary
- active FAQ across all locales aligned to Russian baseline under the bonus/accrual canon;
- active locale bundle values no longer use reward/nagrada wording in user-facing values;
- active user-facing canon now prefers bonus for tasks/ads/referrals and accrual for cold balance operations;
- historical docs, audits, logs and Healer history were not rewritten.

## Guard results
- bonus_canon_findings: 0
- forbidden_gaming_contour blocker findings: 0
- admin leak findings: 0
- admin ru-only raw/empty findings: 0
- identical-to-English findings: 0
- placeholder mismatches: 0
