# line72_cycle_046

## 1) Что сделано

- Исправлен единый Declarative Base для ORM моделей: Base теперь
  определяется в backend/app/models/__init__.py и не тянет движок.
- Все модели переведены на импорт Base из backend/app/models.
- Исправлен guard по SSOT per-sec литералам: тест больше не
  сканирует tests/ и reports/ (только код проекта).
- Исправлена формулировка в panels_service, чтобы не ломать
  SSOT-guard по public_id NULL.

## 2) Изменённые файлы

- backend/app/models/__init__.py
- backend/app/models/*.py
- backend/app/services/panels_service.py
- tests/test_per_sec_literals_guard.py
- reports/line72_cycle_046.md

## 3) Исключения 72

- Нет.

## 4) Проверки

- python -m compileall backend -q: PASS
- pytest -q: PASS

## 5) Что осталось

- Ничего обязательного по этому циклу.
