# v154_24 — user withdraw requests view

- Added user-facing withdraw requests block inside Profile -> History.
- Wired frontend to existing `/withdraw/list` API.
- Added withdraw status cards with amount and timestamps.
- Added architecture test to keep the view wired.
