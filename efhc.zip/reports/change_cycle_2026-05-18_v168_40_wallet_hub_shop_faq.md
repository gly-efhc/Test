# Change Report v168.40

## Range

Cycles 1231-1232.

## Summary

This pass continues the frontend visual repair after v168.39. It fixes
FAQ overflow, extends the EFHC Game UI Kit to Wallet / HUB /
Browser-Shop, and records the attempted live check result.

## Code changed

- `frontend/src/components/ui/GameShell.tsx`
- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/src/features/hub/HubPage.tsx`
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`

## Tests added

- `tests/architecture/test_cycle_1231_1232_`
  `wallet_hub_shop_faq_guard.py`

## Fix details

### FAQ

The FAQ shell now applies strict containment and wrapping rules so long
sections, answers, breadcrumbs and category labels cannot escape the app
frame.

### Wallet

Wallet and History inside `/web-profile` now use shared game stat and
notice primitives. The route-page profile model remains canonical.

### HUB

HUB is now rendered with EFHC Game UI Kit primitives instead of old
Telegram action blocks.

### Browser-Shop

Browser-Shop now renders hero, sections, notices and product cards using
EFHC Game UI Kit primitives. Raw exception text is no longer displayed
in the public storefront error state.

## Checks

- Locale JSON validation: passed.
- Generated JSON validation: passed before new JSON write.
- Targeted architecture tests: passed.
- TypeScript attempted, but not accepted as proof because the archive
  has no `node_modules` and dependency types are absent.
- New ZIP integrity must be checked after packaging.

## Non-claims

No GitHub CI, Docker runtime proof or successful live Cloudflare visual
proof is claimed in this report.
