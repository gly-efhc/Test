# Change report — v169.97 / cycle 1422 economic risk repair

## Summary

Cycle 1422 repaired two surgical findings from the P0 economic audit:

- `FIND-002`: all-bonus spend idempotency retry now read-throughs via either
  `:main` or `:bonus` derived key.
- `FIND-004`: admin manual debit no longer passes nonexistent kwargs to
  canonical debit functions.

## Changed files

- `backend/app/services/transactions_service.py`
- `backend/app/services/admin/admin_bank_service.py`
- `tests/architecture/test_economic_risk_guards.py`
- `tests/architecture/test_heal0018_transaction_boundary_repair.py`
- `docs/backend/P0_ECONOMIC_RISK_REPAIR_PLAN.md`
- `docs/cycles/WORK_CYCLES_1422_ECONOMIC_RISK_REPAIR.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `HEALER_ATLAS.md`
- `docs/healer/HEALER_ATLAS.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `atlas.json`
- `casebook.json`
- `map_element.md`
- `docs/audits/P0_ECONOMIC_AUDIT_TRANSACTIONS_SERVICE_V169_91.md`
- `docs/audits/p0_economic_audit_transactions_service_v169_91.json`
- `ops/operator_kernel/cache/file_map.json`

## Deleted files

None.

## Guard hygiene alignment

HEAL-0018 stale guard evidence was moved to the allowed cycle log layer: the test now checks numbered history in `docs/cycles/WORK_CYCLES.md` instead of requiring a numbered label in `docs/backend/`.

## Test control

No test was deleted, archived, skipped, xfailed or hidden.

## Checks

Targeted checks passed locally. Full CI is not claimed.

## Next

Cycle 1423 should address `FIND-001` panel activation atomicity after the
architecture decision is confirmed.
