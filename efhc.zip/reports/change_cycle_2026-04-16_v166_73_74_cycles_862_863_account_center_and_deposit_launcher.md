# EFHC Bot v166_73_74 — cycles 862/863 account center and deposit launcher

## What changed
- Web-profile moved further toward the heavy canonical account center: it now exposes current active payment, recent payment intent history, order history and direct shortcuts back to the Telegram operational contour.
- `shopfront/profile` now returns recent payment intent history so the external profile can show what is happening now and what happened earlier without inventing a second truth source.
- DepositModal was rebuilt as a thin launcher only: it reads `/hub/shop-truth`, shows the next honest step, and opens the signed Browser-Shop flow without local polling, local resume memory or a second payment state machine.

## Validation
- `python -m py_compile backend/app/services/payment_intents_service.py backend/app/routes/shopfront_routes.py backend/app/schemas/hub_schemas.py` passed.
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` passed.
- `pytest -q tests/architecture/test_cycle_and_docs_canon.py tests/architecture/test_route_inventory_freeze_sync.py tests/architecture/test_openapi_startup_consistency.py -q` passed.
- No fresh GitHub CI log was provided, so green CI is not claimed.
