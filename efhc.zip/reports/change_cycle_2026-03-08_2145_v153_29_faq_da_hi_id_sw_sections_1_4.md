# v153_29 — FAQ da/hi/id/sw sections 1–4

- Added item-level translations for the new user FAQ structure.
- Languages covered in this cycle: da, hi, id, sw.
- Sections covered: 1–4.
- Fixed 3 line72 violations in localized.ts.
- canon_guard passes locally.
- No new CI log was provided for this archive.
