# Change cycle 2026-03-01_1330 — v149_44

## Inputs (SSOT)
- HEAD ZIP: EFHC_Bot_v149_43_fix_admin_index_payment_intents_routes_61_65.zip
- Logs analyzed: logs_58940265094.zip (Alembic ImportError Base in bank_models)

## Changes
### CI/Alembic fixes
- bank_models: import Base from app.models (not app.core.database_core) to stop Alembic ImportError.

### DB canon (code → table → migrations)
- Added ORM table: efhc_core.referral_codes (ReferralCode) — replaces legacy on-demand DDL in referral_service.
- referral_service: removed CREATE TABLE IF NOT EXISTS referral_codes; uses ORM select/insert instead.

### Shop routes surface fixes
- shop_service: implemented get_catalog (efhc_core.shop_items) and create_external_order wrapper (calls create_order_external).
- ShopFacade.list_orders now returns dict {items,next_cursor} (fixes route expectation).

### SSOT updates
- SSOT_ROUTE_TABLE_MAP.csv filled for routes #66-#70 with read/write tables + evidence file:line.
- SSOT_TABLES_ORM.csv and SSOT_TABLES_MIGRATIONS.csv updated to include referral_codes.
- ops/ci_verify_db_objects.py updated REQUIRED to include efhc_core.referral_codes.
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md updated with new CI error class (Base import).

## Notes
- Economic rule respected: денежные списания/лог efhc_transfers_log остаются через transactions_service (shop purchase uses bank alias to transactions_service).
- Cache cleanup: caches/pyc were excluded before packaging.
