# Change report v150_42

Source logs: logs_59178178105.zip

## Fixes

1) withdraw_service
- Added missing helper `_fetch_withdraw_request` for approve idem-hit.
- Added `_ensure_admin_whitelisted` and applied to approve/reject.

2) deps.require_admin
- Enforced admin access strictly via efhc_admin.admin_whitelist
  (is_active=true) using request.state.tg_id only.

## Files changed
- backend/app/services/withdraw_service.py
- backend/app/deps.py
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/CI_FIXES_INTERNAL_LOG.md
- reports/change_report_v150_42.md
