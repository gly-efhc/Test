# Change report: v151_28_sql_aliases_phase1

## Цель
Переходный слой «алиасы» для варианта A: убрать форматирование
SQL по схемам и привести схемы к канону efhc_core/efhc_admin.

## Изменения
- Удалены f-string вставки {SCHEMA} в SQL (10 файлов).
- SQL теперь использует явную схему efhc_core (без подстановок).
- В моделях схемы канонизированы через canon_schema(settings.*).
- Удалены неиспользуемые константы SCHEMA в сервисах/роутах.

## Файлы
- backend/app/services/* (см. git diff в архиве).
- backend/app/routes/sync_routes.py, shop_routes.py.
- backend/app/models/*: schema через canon_schema().

## Статус
- PENDING: требуется CI logs для подтверждения отсутствия регрессий.

