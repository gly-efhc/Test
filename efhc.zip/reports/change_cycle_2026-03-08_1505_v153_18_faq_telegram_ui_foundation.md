# Change Cycle — 2026-03-08 15:05 — v153_18

## Scope

Telegram-native UI foundation + FAQ decomposition for the current
frontend on top of `v153_17_term_pesochnica`.

## What was changed

1. Added reusable Telegram UI layer:
   - `TelegramSectionRow`
   - `TelegramStatusBadge`
   - `TelegramSearchBar`
   - `TelegramAccordionItem`
   - `TelegramEmptyState`
   - `TelegramActionCard`
   - `TelegramInfoBlock`
   - `TelegramCategoryPills`

2. Added FAQ component layer:
   - `FaqHeader`
   - `FaqSearchBar`
   - `FaqPopularQuestions`
   - `FaqSectionList`
   - `FaqSubsectionList`
   - `FaqAccordionList`
   - `FaqQuestionItem`
   - `FaqRelatedQuestions`
   - `FaqQuickLinks`
   - `FaqNoResultsState`
   - `FaqBreadcrumbHeader`
   - `FaqKeywordTags`

3. Added FAQ hooks/helpers:
   - `useFaqCatalog`
   - `useFaqNavigation`
   - `useFaqSearch`
   - `lib/faq/search.ts`
   - `lib/faq/navigation.ts`

4. Rebuilt `frontend/src/pages/faq.tsx` into an orchestrator page:
   - header + sticky search
   - category pills
   - popular questions block
   - section/subsection lists
   - accordion questions
   - related questions block
   - quick links to wallet/history/pages
   - router-query sync via dedicated hook

5. Started Profile decomposition:
   - extracted `ProfileFaqSection`
   - wired Profile FAQ preview through the new component instead of
     inline ad-hoc markup in `ProfileModal.tsx`

## Checks

Confirmed locally:
- `python ops/canon_guard.py` -> OK
- `line72` on all changed frontend files -> OK
- changed-file TS/TSX transpile syntax check -> OK

Not confirmed:
- `npm run build` was not proven in this environment because `next`
  binary is unavailable here; package install is not proven
- no fresh `logs_*.zip` exists for this new archive

## Risk notes

- FAQ logic was moved but not rewritten from scratch; current search,
  query params and multilingual FAQ catalog remain in use.
- Wallet and History full component decomposition is not finished in
  this cycle.
- Profile refactor is started, not completed.
