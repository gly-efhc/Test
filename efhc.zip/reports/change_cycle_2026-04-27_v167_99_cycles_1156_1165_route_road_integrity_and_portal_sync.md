# v167_99 — cycles 1156-1165

Date: 2026-04-27
HEAD in: EFHC_Bot_v167_98_cycles_1151_1155_pre_release_bonus_column_refactor.zip
HEAD out: EFHC_Bot_v167_99_cycles_1156_1165_route_road_integrity_and_portal_sync.zip

## What was done
- audited task/ads/admin route roads from route entrypoints to service/table targets;
- repaired `/tasks/catalog` payload drift to canonical `bonus_efhc` / `kind` / `meta` fields;
- repaired `/tasks/my/{global_id}` claimability so paid submissions are no longer shown as claimable;
- canonicalized admin submissions list route from `/admin/tasks/tasks/{task_id}/subs` to `/admin/tasks/{task_id}/subs`;
- synced static route inventories and OpenAPI snapshot strings for admin task moderation/submissions paths;
- switched player-facing header and profile history shortcut labels to i18n keys.

## Residuals
- provider-facing ads DTO still uses `reward_bonus_efhc` as a bounded technical contract;
- static historical reports continue to mention older route/path states as evidence.
