# v171.60 — единый вход, навигационный Kernel и восстановление control-layer

Status: `DEVELOPMENT SNAPSHOT / CYCLE 1573 FROZEN / NOT RELEASE READY`.
Source archive: `EFHC_Bot_v171_59.zip`.
Runtime/business/economy/TON/database change: **NO**.

## Архивное восстановление истины

Сопоставлены доступные канонические архивы `v171.47`, `v171.48`, `v171.49`, `v171.50`, `v171.56`, `v171.57`, `v171.58`, `v171.59`.

Подтверждена причинная линия:

- `v171.47` — последний предоставленный full-regression и route-backed visual baseline;
- `v171.48` — пользовательское требование не допускать зависаний было ошибочно расширено до правила, будто полный CI принадлежит только пользователю;
- `v171.49–v171.59` — в KERNEL, AI entrypoints, SSOT/NORM и handoff начали накапливаться параллельные порядки чтения и повторные «текущие» блоки;
- `v171.54–v171.59` — manual HTML / `page.set_content` был ошибочно принят за application screenshot proof;
- Healer, reports и manifests начали подтверждать друг друга без независимого runtime evidence.

Полная архивная линия: `reports/generated/archive_truth_lineage_v171_60.json`.

## Новый единый порядок

Создан `START_HERE.md` как единственный активный startup entrypoint:

```text
последний канонический архив
→ проверить ZIP integrity
→ распаковать один раз в текущей сессии
→ полностью прочитать START_HERE
→ полностью прочитать KERNEL
→ пройти AI laws / CANON / SSOT / NORM / AI / Healer
→ выполнить ограниченную задачу
→ создать новый последовательный архив
→ передать архив пользователю
```

Песочница закреплена как временная и не считается persistent workspace между чатами.

## Роли документов

- `KERNEL.md` — только навигация и текущая граница; сокращён с 1032 до 146 строк.
- `docs/SSOT/SSOT_INDEX.md` — индекс активных источников истины; сокращён с 331 до 116 строк и приведён к приоритету `START_HERE`.
- `docs/AI/TOPIC_READING_ROUTES.md` — тематическая навигация; сокращён с 833 до 101 строки.
- `AGENTS.md`, `CLAUDE.md`, `READING_ENTRYPOINT.md`, Kernel Protocol и First Standard — compatibility pointers, не альтернативные порядки.
- AI Archive Laws, их lock, CANON и NORM остаются верхним архивным законом.
- CANON/SSOT/NORM/AI/Healer остаются раздельными критическими слоями и не могут заменять друг друга.

Исторические циклы и отчёты не удалены, но больше не являются активным startup-контуром.

## CI и screenshots

Исправлена ошибочная трактовка:

- пользователь не запрещал CI, pytest, build, typecheck, lint или browser tests;
- широкие прогоны разрешены с timeout, checkpoint и запретом бесконечных повторов;
- зависший прогон не должен блокировать development archive;
- PNG остаются локальным визуальным evidence и не являются обязательными артефактами GitHub CI;
- application screenshot proof обязан запускать реальный frontend и использовать `page.goto()`;
- `page.set_content`, manual HTML и synthetic imitation запрещены как application proof.

## Восстановление истины Healer

Созданы `HEAL-0114 / CASE-0123`.

`HEAL-0113 / CASE-0122` помечены как superseded: source-изменения ProfileModal/баланса сохранены, но screenshot claim v171.59 признан недействительным. Активные manual-HTML proof scripts удалены из `ops/frontend` и сохранены только в forensic history.

## Машинные блокировки регресса

Добавлены:

- `scripts/ci/check_governance_entrypoints.py`;
- `scripts/ci/check_application_screenshot_provenance.py`;
- обновлён `scripts/ci/check_ai_archive_laws_integrity.py`;
- `tests/architecture/test_governance_entrypoint_recovery_v171_60.py`;
- semantic filenames для active guards и live-contour gate;
- обновлён `start_core` в `routes.yaml`, `route_resolver.py`, `file_map.py`;
- устранён дубликат `FAQ_SSOT.md` в `ops/canon_rules.yaml`;
- зафиксированы канонические английские статусы `Activ` в i18n audit allow rules.

Replacement mapping: `docs/testing/GOVERNANCE_V171_60_REPLACEMENT_MAPPING.md`.
Diff manifest: `reports/generated/v171_59_to_v171_60_diff.json`.

## Выполненные проверки

- startup critical documents: `READ_FULL_CONFIRMED_BEFORE_EDIT`;
- governance entrypoint guard: PASS;
- application screenshot provenance guard: PASS;
- AI Archive Laws integrity guard: PASS;
- Canon Guard: PASS;
- consolidated governance/KERNEL/SSOT/NORM/AI/Healer compatibility suite: **584 passed**;
- additional focused route/document suite: **41 passed**;
- Python compile for modified guards/operator scripts: PASS.

Полный pytest, production frontend build, live Telegram, real TonConnect, real TonProof и real transaction в этом governance-only проходе не выполнялись.

## Граница

- Приложение и финансовая логика v171.59 не изменялись.
- Скриншоты v171.59 не считаются application proof.
- Цикл 1573 остаётся замороженным и незавершённым.
- Цикл 1574 не начат.
- Следующий технический проход должен восстановить real build + route-backed visual audit до продолжения live Telegram/TON доказательств.
