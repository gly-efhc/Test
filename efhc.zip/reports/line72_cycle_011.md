# Frontend line72 — cycle 011

## Summary
- Ran `pytest -q` and collected remaining line length violations (>72).
- Fixed the remaining violations with safe line wraps / JSX formatting.
- No SSOT/economy changes.
- No new identifiers (only `tg_id`) and no banned substrings introduced.

## Changed files (4)
1. frontend/src/lib/sfx.ts
2. frontend/src/pages/tasks.tsx
3. frontend/src/pages/admin/ads.tsx
4. frontend/src/pages/admin/reports.tsx

## Exclusions added
- None.

## Checks
- `python -m compileall backend -q`: PASS
- `pytest -q`: PASS
