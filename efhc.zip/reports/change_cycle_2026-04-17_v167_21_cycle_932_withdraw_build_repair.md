# Change report — v167_21 — cycle 932

## Scope
- Source: GitHub CI log package `logs_65034931133.zip`.
- Fix only the confirmed frontend build error in `withdraw.tsx`.

## Confirmed issue
- `Cannot find name 'TelegramInfoBlock'` in `frontend/src/pages/withdraw.tsx`.

## Root cause
- The page rendered `TelegramInfoBlock` inside the latest withdraw outcome card but the import was missing.

## Changes
- Restored `TelegramInfoBlock` import in `frontend/src/pages/withdraw.tsx`.
- Performed limited alias cleanup in the same touched block:
  - `Promo zone` -> `Промозона`
  - `Comment` -> `Комментарий`
  - updated the fallback description to Russian
- Kept the compatibility marker `Latest withdraw outcome` unchanged.

## Verification
- Local syntax smoke check on the touched file.
- Await next GitHub CI for full confirmation.
