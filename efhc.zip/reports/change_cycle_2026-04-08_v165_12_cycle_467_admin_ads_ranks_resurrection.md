# Cycle 467/470

- Connected `AdsBanner.tsx` to `pages/tasks.tsx`.
- Connected `RanksTable.tsx` to `pages/ranks.tsx`.
- Connected `AdminCharts.tsx` and `AdminTable.tsx` to admin pages.
- No deletions performed.
