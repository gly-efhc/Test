# Change report v150_44

- Tests: use real admin tg_id from settings (ADMIN_TG_IDS/ADMIN_TG_ID).
- Tests: seed efhc_admin.admin_whitelist for that admin tg_id.
- Line72: fixed long lines in tests/conftest.py.
