# Change Cycle — 2026-03-08 — v153_20

## Scope
- Continue FAQ content migration after the new 12-section user-facing
  structure introduced in v153_19.
- Add item-level multilingual FAQ content for the most important new
  user sections.

## Changed files
- frontend/src/data/faq/localized.ts
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md

## What changed
- Added EN item-level FAQ translations for sections 1-6 of the new
  FAQ structure:
  - balances
  - balance history
  - panels and energy
  - exchange and withdraw
  - wallet
  - referrals
- Added UA item-level FAQ translations for sections 1-6 of the new
  FAQ structure.
- Preserved the existing fallback order in FAQ catalog assembly:
  language -> en -> ru.

## Local checks
- canon_guard: OK
- changed-file line72: OK
- no fresh logs_*.zip on this archive, so green CI is not claimed.
