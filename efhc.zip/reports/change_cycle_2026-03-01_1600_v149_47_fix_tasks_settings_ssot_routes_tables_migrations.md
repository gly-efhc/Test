# v149_47 — Fix Alembic model import: missing Settings TASK_REWARD_BONUS_EFHC_DEFAULT + SSOT routes↔tables↔migrations

## Root cause (logs_58944299025.zip)
- Alembic 0001 импортирует все ORM-модули, но app/models/tasks_models.py обращался к settings.TASK_REWARD_BONUS_EFHC_DEFAULT, которого не было в Settings → AttributeError.

## Fix
- backend/app/core/config_core.py: добавлено поле Settings.TASK_REWARD_BONUS_EFHC_DEFAULT (Decimal, default=0).
- backend/app/models/tasks_models.py: default reward_bonus_efhc переведён на getattr(settings, ..., 0) для устойчивости при импорте.
- docs/ssot_pack: добавлен SSOT_ROUTES_TABLES_MIGRATIONS.csv и ссылка в docs/SSOT_INDEX.md.
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md: добавлен класс ошибки по logs_58944299025.zip.

## Notes
- Кеши исключены из ZIP (pycache/pytest_cache/node_modules/.next/etc).
