# Change report — v170.66 / cycle 1490

## Summary

`1490 — Admin Logs / Events Dashboard` is complete locally.

## Log repair

`logs_73159210416.zip` failed only in pytest:

```text
energy.dashboard_raw_snapshot: Локализовано: raw snapshot != исходный снимок
```

The locale drift is repaired in `frontend/public/locale/*.json`.

## Runtime

`/admin/logs` now includes `AdminLogsEventsDashboardRuntime` with read-only
snapshot metrics, safe event feed, display-only filters and truth/safety
boundary.

## Not claimed

- GitHub CI green for the new archive;
- full pytest green;
- full frontend build green;
- release-ready;
- browser screenshot proof;
- live Telegram proof.
