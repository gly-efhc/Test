# Change cycle — v153_01

## What fell in fresh CI log logs_59697304282.zip

- mypy: 4 errors in `backend/app/services/referral_service.py`
- pytest: 7 failures
  - docs counts stale (`74` tests expected)
  - tests catalog missing new runtime test
  - forbidden tg_id alias names in admin frontend (`tgId`)
  - line72 violations in admin/frontend files
  - banned rank substring in `frontend/public/locale/en.json`
  - referral runtime test used wrong column `referred_tg_id`

## Root causes

- New referrals stats helpers returned values through untyped scalar path.
- Docs were not updated after adding
  `tests/architecture/test_referral_level_bonus_runtime.py`.
- Admin frontend used banned camel alias `tgId`.
- Telegram-native admin refactor left several lines >72.
- English locale used banned wording with `rating` substring.
- Runtime test inserted into non-existent `referred_tg_id` column while
  ORM canon uses `invitee_tg_id`.

## Fixed

- `referral_service.py`: typed Decimal returns for referrals page stats.
- Overview docs / README / tests catalog synced to `74` test files.
- Admin logs/panels filters renamed from `tgId` to canonical neutral
  filter variable while keeping query param `tg_id`.
- Admin pages and helper components cleaned to line72.
- English locale strings shortened and banned rank term removed.
- Referral runtime test fixed to `invitee_tg_id`.

## Local checks

- `mypy backend/app` — pass
- pytest targeted failures bundle — pass
- line72 targeted files — pass
- `compileall backend/app` — pass

## Limits

- Full green CI for v153_01 is not claimed without new `logs_*.zip`.
