# line72 cycle 021

Scope: Energy T2 контрольные точки.

## Changes
- Energy: вынес live-обновления в memo-компонент, чтобы не
  перерисовывать весь экран ~3 раза/сек.
- Границы уровней: оставляем remaining=0 на точном пороге,
  затем переключаем уровень. LVL12 фиксируется при E>=20000.
- Форматирование: format8 теперь всегда DOWN без Number/toFixed.
- Snapshot drift: мягкий reset при новом server_now_iso,
  без скачков назад и с плавной коррекцией вперёд.

## line72
No exceptions.
