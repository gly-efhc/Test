# Change cycle v152_35 — Profile subsections wallet/history/faq

Date: 2026-03-07 19:00

## Scope
- Split Profile / Settings into 3 subsections:
  - Wallet
  - История баланса
  - FAQ
- Move balance summary from Wallet to История баланса.
- Keep Wallet focused on TON wallet connect and linked wallets.

## Files
- frontend/src/components/ProfileModal.tsx
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md

## Details
- Added third subsection button FAQ.
- History subsection now shows:
  - total balance
  - main balance
  - bonus balance
  - balance history list
- Wallet subsection now shows only wallet connect and linked wallets.
- FAQ subsection includes quick prompts and button to open /faq.
