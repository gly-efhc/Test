- 2026-03-05 v152_06: change_cycle_2026-03-05_v152_06_fix_mypy_routes.md
# Reports index (SSOT)
Эта папка содержит общие логи проекта: отчёты циклов,
архитектурные отчёты (например, line72), и аудит-чаты.
## Правило (MUST)
- Каждый цикл исправлений обязан создавать новый файл в `reports/`.
- Имя: `reports/change_cycle_YYYY-MM-DD_HHMM_vNNN.md`.
- Внутри: список изменённых файлов, причина, проверка, ссылка на logs.
## Список файлов
- `REPORTS_INDEX.md` — Индекс и правила ведения reports/.
- `change_cycle_2026-02-27_1714_v148_39.md` — Отчёт конкретного цикла
  изменений.
- `chat_audit_2026-02-27.md` — Аудит изменений по чату с датами и
  временем.
- `line72_cycle_001.md` — История приведения строк к <=72 символов.
- `line72_cycle_002.md` — История приведения строк к <=72 символов.
- `line72_cycle_003.md` — История приведения строк к <=72 символов.
- `line72_cycle_004.md` — История приведения строк к <=72 символов.
- `line72_cycle_005.md` — История приведения строк к <=72 символов.
- `line72_cycle_006.md` — История приведения строк к <=72 символов.
- `line72_cycle_007.md` — История приведения строк к <=72 символов.
- `line72_cycle_008.md` — История приведения строк к <=72 символов.
- `line72_cycle_009.md` — История приведения строк к <=72 символов.
- `line72_cycle_010.md` — История приведения строк к <=72 символов.
- `line72_cycle_011.md` — История приведения строк к <=72 символов.
- `line72_cycle_012.md` — История приведения строк к <=72 символов.
- `line72_cycle_013.md` — История приведения строк к <=72 символов.
- `line72_cycle_014.md` — История приведения строк к <=72 символов.
- `line72_cycle_015.md` — История приведения строк к <=72 символов.
- `line72_cycle_016.md` — История приведения строк к <=72 символов.
- `line72_cycle_017.md` — История приведения строк к <=72 символов.
- `line72_cycle_018.md` — История приведения строк к <=72 символов.
- `line72_cycle_019.md` — История приведения строк к <=72 символов.
- `line72_cycle_020.md` — История приведения строк к <=72 символов.
- `line72_cycle_021.md` — История приведения строк к <=72 символов.
- `line72_cycle_022.md` — История приведения строк к <=72 символов.
- `line72_cycle_023.md` — История приведения строк к <=72 символов.
- `line72_cycle_024.md` — История приведения строк к <=72 символов.
- `line72_cycle_025.md` — История приведения строк к <=72 символов.
- `line72_cycle_026.md` — История приведения строк к <=72 символов.
- `line72_cycle_027.md` — История приведения строк к <=72 символов.
- `line72_cycle_028.md` — История приведения строк к <=72 символов.
- `line72_cycle_029.md` — История приведения строк к <=72 символов.
- `line72_cycle_030.md` — История приведения строк к <=72 символов.
- `line72_cycle_031.md` — История приведения строк к <=72 символов.
- `line72_cycle_032.md` — История приведения строк к <=72 символов.
- `line72_cycle_033.md` — История приведения строк к <=72 символов.
- `line72_cycle_034.md` — История приведения строк к <=72 символов.
- `line72_cycle_035.md` — История приведения строк к <=72 символов.
- `line72_cycle_036.md` — История приведения строк к <=72 символов.
- `line72_cycle_038.md` — История приведения строк к <=72 символов.
- `line72_cycle_040.md` — История приведения строк к <=72 символов.
- `line72_cycle_041.md` — История приведения строк к <=72 символов.
- `line72_cycle_042.md` — История приведения строк к <=72 символов.
- `line72_cycle_043.md` — История приведения строк к <=72 символов.
- `line72_cycle_044.md` — История приведения строк к <=72 символов.
- `line72_cycle_045.md` — История приведения строк к <=72 символов.
- `line72_cycle_046.md` — История приведения строк к <=72 символов.
- `line72_frontend_report.md` — История приведения строк к <=72
  символов.
- 2026-02-27 23:59 — v148_40 — аудит #3 (fullfix)
- change_cycle_2026-02-27_2355_v148_41_fix_0001_tables_artifacts.md —
  fix 0001 tables + remove artifacts (CI stop-crane)
- change_cycle_2026-02-27_2359_v148_42_fix_async_engine_event_loop.md:
  fix async_engine loop binding in tests
- change_cycle_2026-02-27_1740_v148_43_pytest_asyncio_strict.md —
  pytest-asyncio strict mode to fix loop mismatch
- 2026-02-27 17:55 UTC — v148_44 — pytest strict marks + manifest update
- change_cycle_2026-02-27_1805_v148_45_fix_pytest_asyncio_fixtures.md —
  pytest-asyncio fixtures strict fix
- change_cycle_2026-02-27_rollback_tg_id_ssot_fix_v148_46.md
- change_cycle_2026-02-27_2359_v148_47_add_build_script.md
- 2026-02-27_1900:
  change_cycle_2026-02-27_1900_v148_49_alembic_sanity_required_tables.md
  — alembic sanity required tables
- 2026-02-27 23:59 UTC — v148_50 — Audit #4 fullfix
- 2026-02-27_2100 —
  change_cycle_2026-02-27_2100_v148_51_migrations_schema_explicit.md
- 2026-02-28:
  change_cycle_2026-02-28_0000_v149_02_fix_required_tables_schema.md
## Cycles
- change_cycle_2026-02-
  28_0045_v149_08_dedup_shop_orders_and_schema_admin.md
- `change_cycle_2026-02-28_1135_v149_04_db_ssot_30tables.md` —
  Восстановлен из v149_07 (архивный отчёт).
- `change_cycle_2026-02-28_0000_v149_07_diagnostic_inventory.md` —
  Восстановлен из v149_07 (инвентаризация).
- `change_cycle_2026-02-28_0130_v149_10_restore_diagnostics.md` —
  Восстановление диагностических файлов (без правок кода).
- `change_cycle_2026-02-28_0200_v149_11_add_audits_section.md` —
  добавлен раздел docs/audits и PDF-аудиты
- [change_cycle_2026-02-
  28_0230_v149_12_audits_pdf_to_md.md](./change_cycle_2026-02-
  28_0230_v149_12_audits_pdf_to_md.md)
- change_cycle_2026-02-28_0300_v149_13_audits_ssot_upgrade.md
- change_cycle_2026-02-28_0300_v149_14_audits_ssot_json_ci.md
- change_cycle_2026-02-28_0330_v149_15_audit_db_tables2_referrals_fix.md
  (Audit-Id: AUD-2026-02-28-DB-INVENTORY-002)
## 2026-02-28
- 2026-02-28 04:00 — EFHC_Bot_v149_16_add_registry_audits:
  change_cycle_2026-02-28_0400_v149_16_add_registry_audits.md
- 2026-02-28 05:00 — EFHC_Bot_v149_17_add_audits: change_cycle_2026-02-
  28_0500_v149_17_add_audits_route_table_duplicates.md (Audit-Id:
  AUD-2026-02-28-ROUTES-INVENTORY-003, AUD-2026-02-28-DB-INVENTORY-005)
- `change_cycle_2026-02-28_0600_v149_18_add_audit_db_ssot_schemas.md` —
  Добавлен SSOT-аудит схем (db-ssot).
- `change_cycle_2026-02-28_0700_v149_19_full_0001_all_tables.md` —
  Полная сборка 0001 (схемы/таблицы/sanity).
- change_cycle_2026-02-28_0800_v149_20_ssot_pack_embedded.md
- `change_cycle_2026-03-01_0010_v149_21_add_audit_sources_inventory.md`
  — Добавлен аудит источников аудита (AUD-2026-03-01-GUARDS-SSOT-002).
- 2026-03-01 00:20 — v149_22 — Add audit AUD-2026-03-01-DB-INVENTORY-006
  (change_cycle_2026-03-
  01_0020_v149_22_add_audit_tables_schemas_search.md)
- reports/change_cycle_2026-03-
  01_0030_v149_23_add_audit_backend_clean.md
- change_cycle_2026-03-01_0200_v149_26_fix_routes_1_5.md
- change_cycle_2026-03-01_0315_v149_29_fix_migrations_create_schemas.md
- change_cycle_2026-03-01_0335_v149_30_fix_ci_schema_and_routes_11_15.md
- 2026-03-01 0410 — v149_31 —
  EFHC_Bot_v149_31_db_0001_2schemas_31tables_orm_only.zip: change_cycle_
  2026-03-01_0410_v149_31_db_0001_2schemas_31tables_orm_only.md
- change_cycle_2026-03-01_0400_v149_32_routes_migrations_playbook.md
- 2026-03-01 05:00 — v149_33 —
  EFHC_Bot_v149_33_plan_json_with_route_numbers.zip: change_cycle_2026-
  03-01_0500_v149_33_update_plan_json_route_numbers.md- 2026-03-01
  v149_34_fix_routes_16_20_ssot_numbered
- 2026-03-01 07:30 — v149_35 — EFHC_Bot_v149_35_fix_routes_21_25_admin_u
  sers_commit_admin_log_core.zip: change_cycle_2026-03-
  01_0730_v149_35_fix_routes_21_25_admin_users_commit_admin_log_core.md
- `change_cycle_2026-03-01_0815_v149_36_fix_unzip_and_0001_sanity.md` —
  Фикс unzip (длинные имена legacy_md) + фикс sanity 0001 to_regclass.
- `change_cycle_2026-03-01_0524_v149_37_fix_0001_tables_routes_31_35.md`
  — Исправление 0001 (31 таблица) + маршруты №31–№35.
- `change_cycle_2026-03-
  01_0905_v149_38_fix_ci_alembic_settings_routes_36_40.md` — Отчёт цикла
  v149_38 (fix alembic ImportError settings + routes 36-40 SSOT).
- 2026-03-01 09:40 — v149_39 —
  EFHC_Bot_v149_39_fix_0001_dupe_import_routes_41_45.zip: change_cycle_2
  026-03-01_0940_v149_39_fix_0001_dupe_import_routes_41_45.md
- 2026-03-01_1010 — v149_40_fix_alembic_import_routes_46_50 — change_cyc
  le_2026-03-01_1010_v149_40_fix_alembic_import_routes_46_50.md
- 2026-03-01 1100 — v149_41 —
  EFHC_Bot_v149_41_fix_core_imports_ssot_routes_51_55.zip: change_cycle_
  2026-03-01_1100_v149_41_fix_core_imports_ssot_routes_51_55.md
- change_cycle_2026-03-
  01_1200_v149_42_fix_alembic_backend_imports_models_panels_nft_errors_r
  egistry.md
- change_cycle_2026-03-
  01_1245_v149_43_fix_admin_index_imports_payment_intents_routes_61_65.m
  d
- change_cycle_2026-03-
  01_1330_v149_44_fix_routes_66_70_referral_codes_shop_facade.md
- change_cycle_2026-03-
  01_1435_v149_45_fix_bank_index_sync_scheduler_task_log.md
- change_cycle_2026-03-01_1510_v149_46_fix_index_schema_and_guard.md
- change_cycle_2026-03-
  01_1600_v149_47_fix_tasks_settings_ssot_routes_tables_migrations.md
- change_cycle_2026-03-
  01_1800_v149_48_fix_tasks_routes_76_80_migrations_hardening.md
- change_cycle_2026-03-01_1900_v149_49_fix_timestampmixin_docs_audits.md
- change_cycle_2026-03-01_2030_v149_50_docs_ssot_ru_only.md: RU-only
  audits + SSOT descriptions (schemas/tables/routes)
- change_cycle_2026-03-
  01_2110_v149_51_add_audit_fix_migrations_imports.md: audit + migration
  import stability (TimestampMixin/Index schema)
- change_cycle_2026-03-
  01_2230_v149_52_fix_models_wallets_withdraw_ssot.md: CI compileall fix
  + wallets idempotency ORM + transfers_log hardening + SSOT routes
  81-91
- change_cycle_2026-03-
  01_2355_v149_53_fix_admin_schema_sale_packages_ci_sanity.md: CI sanity
  after alembic (missing required tables) + efhc_admin sale packages ORM
  + SSOT routes 5-10

- reports/change_cycle_2026-03-
  01_0015_v149_54_fix_12_routes_and_admin_audit.md

- change_cycle_2026-03-
  01_0010_v149_55_fix_env_search_path_ssot_evidence.md
- change_cycle_2026-03-01_0030_v149_56_fix_ci_verify_db_objects.md:
  улучшение sanity проверки таблиц/схем + диагностические подсказки по
  schema drift
- change_cycle_2026-03-01_0050_v149_58_ssot_no_db_flags.md
- 2026-03-01_1349: v149_59_fix_env_py_indent →
  reports/change_cycle_2026-03-01_1349_v149_59_fix_env_py_indent.md

- change_cycle_2026-03-
  01_0150_v149_60_fix_env_alembic_sanity_admin_table.md

- reports/change_cycle_2026-03-01_0200_v149_61_tests_pass.md (v149_61)
  tests pass + line72
- `change_cycle_2026-03-01_0310_v149_62_add_soft_alembic_healthcheck.md`
  — SOFT alembic healthcheck тест.
- 2026-03-01 v149_63: fix 0001 imports/metadata guard
- 2026-03-01 v149_64: inventory + fix CI logs_58966466620
  (0001_init NameError) → change_cycle_2026-03-
  01_1610_v149_64_inventory_and_fix_logs_58966466620.md
- change_cycle_2026-03-01_1700_v149_65_clean_db_entrypoint.md
- change_cycle_2026-03-01_1800_v149_66_fix_0001_pg_only_sqlite_purge.md
- 2026-03-01 v149_67: remove sqlite fallback, fix 0001 stdout
- change_cycle_2026-03-01_1805_v149_68_soft_alembic_python_module.md
- change_cycle_2026-03-02_v149_69_fix_env_psycopg_url.md
- reports/change_cycle_2026-03-02_1100_v149_70_fix_env_url_alignment.md
- 2026-03-02 v149_71 fix schema diag (alembic)
- reports/change_cycle_2026-03-02_1200_v149_72_schema_translate_diag.md
- reports/change_cycle_2026-03-02_1325_v149_73_fix_schema_autocommit.md
- reports/change_cycle_2026-03-
  02_1405_v149_74_fix_autocommit_invalidrequest.md
- 2026-03-02 v149_75 fix 0001 autocommit
- change_cycle_2026-03-02_1800_v149_76_fix_ddl_persist_diag.md

- change_cycle_2026-03-
  02_1900_v149_77_fix_schema_persist_env_autocommit.md
- reports/change_cycle_2026-03-05_v151_23_add_internal_logs.md
- reports/change_cycle_2026-03-05_v151_24_backfill_logs_add_ai
_protection_term.md
- change_cycle_2026-03-05_v151_25_add_phrase_ai_protection.md
- change_cycle_2026-03-05_v151_26_fix_ci_env.py.md
- change_cycle_2026-03-05_v151_27_sql_alias_layer.md
- 2026-03-05: change_cycle_2026-03-05_v151_28_sql_aliases_phase1.md
- change_cycle_2026-03-05_v151_29_sql_aliases_fix_canon_schema.md
- change_cycle_2026-03-05_v151_30_aliases_phase3_canon_schema.md
- change_cycle_2026-03-05_v151_31_fix_import_injection.md
- change_cycle_2026-03-05_v151_32_aliases_no_fstring_sql.md
- change_cycle_2026-03-05_v151_33_aliasA_fix_sql_syntax.md
- change_cycle_2026-03-05_v151_34_aliasA_fix_bandit_alembic_adminlogs.md
- 2026-03-05: change_cycle_2026-03-05_v151_35_fix_logs_59461946216.md
- change_cycle_2026-03-05_v152_01_fix_logs_59479799492.md

- 2026-03-05: change_cycle_2026-03-05_v152_02_fix_logs_59483039589.md

- change_cycle_2026-03-05_v152_03_fix_logs_59488407043.md
- change_cycle_2026-03-05_v152_04_fix_mypy_pytest.md
- change_cycle_2026-03-05_v152_07_fix_logs_59518246593.md
- 2026-03-06: change_cycle_2026-03-06_v152_11.md
- 2026-03-06: `change_cycle_2026-03-06_v152_12.md`
