# REPORTS INDEX

## Правило (MUST)

1. Все изменения в `reports/` записываются строго по порядку.
2. Индекс `REPORTS_INDEX.md` ведётся как append-only реестр.
3. Каждая новая запись получает следующий номер без пропусков.
4. Порядок записей: дата/время → версия → файл.
5. Запрещено удалять старые записи из индекса без явного решения.
6. Для новых циклов использовать файл вида
   `change_cycle_YYYY-MM-DD_HHMM_vNNN_XX_slug.md`.

## Текущий порядок записей

0001. `CI_FIXES_INTERNAL_LOG.md`
0002. `INTERNAL_LOGBOOK_v152_17.md`
0003. `alias_sanitation_report_v150_24.md`
0004. `alias_sanitation_report_v150_25.md`
0005. `alias_sanitation_report_v150_28.md`
0006. `alias_sanitation_v150_69.md`
0007. `change_cycle_2026-02-27_1714_v148_39.md`
0008. `change_cycle_2026-02-27_1740_v148_43_pytest_asyncio_strict.md`
0009. `change_cycle_2026-02-
      27_1755_v148_44_fix_pytest_strict_marks_manifest.md`
0010. `change_cycle_2026-02-
      27_1805_v148_45_fix_pytest_asyncio_fixtures.md`
0011. `change_cycle_2026-02-
      27_1900_v148_49_alembic_sanity_required_tables.md`
0012. `change_cycle_2026-02-
      27_2100_v148_51_migrations_schema_explicit.md`
0013. `change_cycle_2026-02-
      27_2355_v148_41_fix_0001_tables_artifacts.md`
0014. `change_cycle_2026-02-27_2359_v148_40.md`
0015. `change_cycle_2026-02-
      27_2359_v148_42_fix_async_engine_event_loop.md`
0016. `change_cycle_2026-02-27_2359_v148_47_add_build_script.md`
0017. `change_cycle_2026-02-27_2359_v148_50_audit4_fullfix.md`
0018. `change_cycle_2026-02-27_rollback_tg_id_ssot_fix_v148_46.md`
0019. `change_cycle_2026-02-
      28_0000_v149_02_fix_required_tables_schema.md`
0020. `change_cycle_2026-02-28_0000_v149_07_diagnostic_inventory.md`
0021. `change_cycle_2026-02-
      28_0045_v149_08_dedup_shop_orders_and_schema_admin.md`
0022. `change_cycle_2026-02-28_0130_v149_10_restore_diagnostics.md`
0023. `change_cycle_2026-02-28_0200_v149_11_add_audits_section.md`
0024. `change_cycle_2026-02-28_0230_v149_12_audits_pdf_to_md.md`
0025. `change_cycle_2026-02-28_0300_v149_13_audits_ssot_upgrade.md`
0026. `change_cycle_2026-02-28_0300_v149_14_audits_ssot_json_ci.md`
0027. `change_cycle_2026-02-
      28_0330_v149_15_audit_db_tables2_referrals_fix.md`
0028. `change_cycle_2026-02-28_0400_v149_16_add_registry_audits.md`
0029. `change_cycle_2026-02-
      28_0500_v149_17_add_audits_route_table_duplicates.md`
0030. `change_cycle_2026-02-
      28_0600_v149_18_add_audit_db_ssot_schemas.md`
0031. `change_cycle_2026-02-28_0700_v149_19_full_0001_all_tables.md`
0032. `change_cycle_2026-02-28_0800_v149_20_ssot_pack_embedded.md`
0033. `change_cycle_2026-02-28_1135_v149_04_db_ssot_30tables.md`
0034. `change_cycle_2026-03-01_0000_v149_28_fix_payment_intents_ssot.md`
0035. `change_cycle_2026-03-
      01_0010_v149_21_add_audit_sources_inventory.md`
0036. `change_cycle_2026-03-
      01_0010_v149_55_fix_env_search_path_ssot_evidence.md`
0037. `change_cycle_2026-03-
      01_0015_v149_54_fix_12_routes_and_admin_audit.md`
0038. `change_cycle_2026-03-
      01_0020_v149_22_add_audit_tables_schemas_search.md`
0039. `change_cycle_2026-03-01_0030_v149_23_add_audit_backend_clean.md`
0040. `change_cycle_2026-03-01_0030_v149_56_fix_ci_verify_db_objects.md`
0041. `change_cycle_2026-03-01_0050_v149_58_ssot_no_db_flags.md`
0042. `change_cycle_2026-03-
      01_0150_v149_60_fix_env_alembic_sanity_admin_table.md`
0043. `change_cycle_2026-03-01_0200_v149_26_fix_routes_1_5.md`
0044. `change_cycle_2026-03-01_0200_v149_61_tests_pass.md`
0045. `change_cycle_2026-03-01_0300_v149_27_fix_routes_6_10.md`
0046. `change_cycle_2026-03-
      01_0310_v149_62_add_soft_alembic_healthcheck.md`
0047. `change_cycle_2026-03-
      01_0315_v149_29_fix_migrations_create_schemas.md`
0048. `change_cycle_2026-03-
      01_0335_v149_30_fix_ci_schema_and_routes_11_15.md`
0049. `change_cycle_2026-03-
      01_0400_v149_32_routes_migrations_playbook.md`
0050. `change_cycle_2026-03-
      01_0410_v149_31_db_0001_2schemas_31tables_orm_only.md`
0051. `change_cycle_2026-03-
      01_0500_v149_33_update_plan_json_route_numbers.md`
0052. `change_cycle_2026-03-
      01_0524_v149_37_fix_0001_tables_routes_31_35.md`
0053. `change_cycle_2026-03-
      01_0600_v149_34_fix_routes_16_20_ssot_numbered.md`
0054. `change_cycle_2026-03-
      01_0730_v149_35_fix_routes_21_25_admin_users_commit_admin_log_core
      .md`
0055. `change_cycle_2026-03-
      01_0815_v149_36_fix_unzip_and_0001_sanity.md`
0056. `change_cycle_2026-03-
      01_0905_v149_38_fix_ci_alembic_settings_routes_36_40.md`
0057. `change_cycle_2026-03-
      01_0940_v149_39_fix_0001_dupe_import_routes_41_45.md`
0058. `change_cycle_2026-03-
      01_1010_v149_40_fix_alembic_import_routes_46_50.md`
0059. `change_cycle_2026-03-
      01_1100_v149_41_fix_core_imports_ssot_routes_51_55.md`
0060. `change_cycle_2026-03-
      01_1200_v149_42_fix_alembic_backend_imports_models_panels_nft_erro
      rs_registry.md`
0061. `change_cycle_2026-03-
      01_1245_v149_43_fix_admin_index_imports_payment_intents_routes_61_
      65.md`
0062. `change_cycle_2026-03-
      01_1330_v149_44_fix_routes_66_70_referral_codes_shop_facade.md`
0063. `change_cycle_2026-03-01_1349_v149_59_fix_env_py_indent.md`
0064. `change_cycle_2026-03-
      01_1435_v149_45_fix_bank_index_sync_scheduler_task_log.md`
0065. `change_cycle_2026-03-
      01_1510_v149_46_fix_index_schema_and_guard.md`
0066. `change_cycle_2026-03-
      01_1600_v149_47_fix_tasks_settings_ssot_routes_tables_migrations.m
      d`
0067. `change_cycle_2026-03-
      01_1610_v149_64_inventory_and_fix_logs_58966466620.md`
0068. `change_cycle_2026-03-
      01_1630_v149_63_fix_0001_imports_metadata_guard.md`
0069. `change_cycle_2026-03-01_1700_v149_65_clean_db_entrypoint.md`
0070. `change_cycle_2026-03-
      01_1735_v149_67_remove_sqlite_fallback_fix_0001_stdout.md`
0071. `change_cycle_2026-03-
      01_1800_v149_48_fix_tasks_routes_76_80_migrations_hardening.md`
0072. `change_cycle_2026-03-
      01_1800_v149_66_fix_0001_pg_only_sqlite_purge.md`
0073. `change_cycle_2026-03-
      01_1805_v149_68_soft_alembic_python_module.md`
0074. `change_cycle_2026-03-
      01_1900_v149_49_fix_timestampmixin_docs_audits.md`
0075. `change_cycle_2026-03-01_2030_v149_50_docs_ssot_ru_only.md`
0076. `change_cycle_2026-03-
      01_2110_v149_51_add_audit_fix_migrations_imports.md`
0077. `change_cycle_2026-03-
      01_2230_v149_52_fix_models_wallets_withdraw_ssot.md`
0078. `change_cycle_2026-03-
      01_2355_v149_53_fix_admin_schema_sale_packages_ci_sanity.md`
0079. `change_cycle_2026-03-02_1100_v149_70_fix_env_url_alignment.md`
0080. `change_cycle_2026-03-02_1200_v149_72_schema_translate_diag.md`
0081. `change_cycle_2026-03-02_1325_v149_73_fix_schema_autocommit.md`
0082. `change_cycle_2026-03-02_1400_v149_71_fix_schema_diag.md`
0083. `change_cycle_2026-03-
      02_1405_v149_74_fix_autocommit_invalidrequest.md`
0084. `change_cycle_2026-03-02_1500_v150_03_fix_efhc_decimals_d8.md`
0085. `change_cycle_2026-03-02_1800_v149_76_fix_ddl_persist_diag.md`
0086. `change_cycle_2026-03-
      02_1900_v149_77_fix_schema_persist_env_autocommit.md`
0087. `change_cycle_2026-03-02_v149_69_fix_env_psycopg_url.md`
0088. `change_cycle_2026-03-02_v149_75_fix_0001_no_autocommit.md`
0089. `change_cycle_2026-03-05_v151_23_add_internal_logs.md`
0090. `change_cycle_2026-03-
      05_v151_24_backfill_logs_add_ai_protection_term.md`
0091. `change_cycle_2026-03-05_v151_25_add_phrase_ai_protection.md`
0092. `change_cycle_2026-03-05_v151_26_fix_ci_env.py.md`
0093. `change_cycle_2026-03-05_v151_27_sql_alias_layer.md`
0094. `change_cycle_2026-03-05_v151_28_sql_aliases_phase1.md`
0095. `change_cycle_2026-03-05_v151_29_sql_aliases_fix_canon_schema.md`
0096. `change_cycle_2026-03-05_v151_30_aliases_phase3_canon_schema.md`
0097. `change_cycle_2026-03-05_v151_31_fix_import_injection.md`
0098. `change_cycle_2026-03-05_v151_32_aliases_no_fstring_sql.md`
0099. `change_cycle_2026-03-05_v151_33_aliasA_fix_sql_syntax.md`
0100. `change_cycle_2026-03-
      05_v151_34_aliasA_fix_bandit_alembic_adminlogs.md`
0101. `change_cycle_2026-03-05_v151_35_fix_logs_59461946216.md`
0102. `change_cycle_2026-03-05_v152_01_fix_logs_59479799492.md`
0103. `change_cycle_2026-03-05_v152_02_fix_logs_59483039589.md`
0104. `change_cycle_2026-03-05_v152_03_fix_logs_59488407043.md`
0105. `change_cycle_2026-03-05_v152_04_fix_mypy_pytest.md`
0106. `change_cycle_2026-03-05_v152_06_fix_mypy_routes.md`
0107. `change_cycle_2026-03-05_v152_07_fix_logs_59518246593.md`
0108. `change_cycle_2026-03-06_0935_v152_19_reports_order_numbering.md`
0109. `change_cycle_2026-03-06_v152_11.md`
0110. `change_cycle_2026-03-06_v152_12.md`
0111. `change_cycle_2026-03-06_v152_13.md`
0112. `change_cycle_2026-03-06_v152_14.md`
0113. `change_cycle_2026-03-06_v152_15.md`
0114. `change_report_v149_78.md`
0115. `change_report_v149_79.md`
0116. `change_report_v150_01.md`
0117. `change_report_v150_06.md`
0118. `change_report_v150_07_ssot_pack.md`
0119. `change_report_v150_14.md`
0120. `change_report_v150_26.md`
0121. `change_report_v150_27.md`
0122. `change_report_v150_28.md`
0123. `change_report_v150_29.md`
0124. `change_report_v150_30.md`
0125. `change_report_v150_31.md`
0126. `change_report_v150_32.md`
0127. `change_report_v150_33.md`
0128. `change_report_v150_34.md`
0129. `change_report_v150_35.md`
0130. `change_report_v150_36.md`
0131. `change_report_v150_37.md`
0132. `change_report_v150_38.md`
0133. `change_report_v150_39.md`
0134. `change_report_v150_40.md`
0135. `change_report_v150_41.md`
0136. `change_report_v150_42.md`
0137. `change_report_v150_43.md`
0138. `change_report_v150_44.md`
0139. `change_report_v150_45.md`
0140. `change_report_v150_47.md`
0141. `change_report_v150_48.md`
0142. `change_report_v150_50.md`
0143. `change_report_v150_51.md`
0144. `change_report_v150_52.md`
0145. `change_report_v150_53.md`
0146. `change_report_v150_54.md`
0147. `change_report_v150_55.md`
0148. `change_report_v150_57.md`
0149. `change_report_v150_58.md`
0150. `change_report_v150_59.md`
0151. `change_report_v150_60.md`
0152. `change_report_v150_61.md`
0153. `change_report_v150_62.md`
0154. `change_report_v150_63.md`
0155. `change_report_v150_64.md`
0156. `change_report_v150_66.md`
0157. `change_report_v150_67.md`
0158. `change_report_v150_68.md`
0159. `change_report_v150_69.md`
0160. `change_report_v151_00.md`
0161. `change_report_v151_01.md`
0162. `change_report_v151_02.md`
0163. `change_report_v151_03.md`
0164. `change_report_v151_04.md`
0165. `change_report_v151_05.md`
0166. `change_report_v151_06.md`
0167. `change_report_v151_07.md`
0168. `change_report_v151_08.md`
0169. `change_report_v151_09.md`
0170. `change_report_v151_11.md`
0171. `change_report_v151_12.md`
0172. `chat_audit_2026-02-27.md`
0173. `cycle_v151_07_ruff_fix.txt`
0174. `doc_audit_2026-02-27.md`
0175. `line72_cycle_001.md`
0176. `line72_cycle_002.md`
0177. `line72_cycle_003.md`
0178. `line72_cycle_004.md`
0179. `line72_cycle_005.md`
0180. `line72_cycle_006.md`
0181. `line72_cycle_007.md`
0182. `line72_cycle_008.md`
0183. `line72_cycle_009.md`
0184. `line72_cycle_010.md`
0185. `line72_cycle_011.md`
0186. `line72_cycle_012.md`
0187. `line72_cycle_013.md`
0188. `line72_cycle_014.md`
0189. `line72_cycle_015.md`
0190. `line72_cycle_016.md`
0191. `line72_cycle_017.md`
0192. `line72_cycle_018.md`
0193. `line72_cycle_019.md`
0194. `line72_cycle_020.md`
0195. `line72_cycle_021.md`
0196. `line72_cycle_022.md`
0197. `line72_cycle_023.md`
0198. `line72_cycle_024.md`
0199. `line72_cycle_025.md`
0200. `line72_cycle_026.md`
0201. `line72_cycle_027.md`
0202. `line72_cycle_028.md`
0203. `line72_cycle_029.md`
0204. `line72_cycle_030.md`
0205. `line72_cycle_031.md`
0206. `line72_cycle_032.md`
0207. `line72_cycle_033.md`
0208. `line72_cycle_034.md`
0209. `line72_cycle_035.md`
0210. `line72_cycle_036.md`
0211. `line72_cycle_038.md`
0212. `line72_cycle_040.md`
0213. `line72_cycle_041.md`
0214. `line72_cycle_042.md`
0215. `line72_cycle_043.md`
0216. `line72_cycle_044.md`
0217. `line72_cycle_045.md`
0218. `line72_cycle_046.md`
0219. `line72_frontend_report.md`
0220. `quality_audit_ruff.txt`
0221. `quality_audit_v151_07.md`
0222. `quality_audit_v151_09.md`
0223. `change_cycle_2026-03-06_1015_v152_20_2schemas_only.md`
0224. `change_cycle_2026-03-06_1105_v152_21_ssot_docs_sync.md`
0225. `change_cycle_2026-03-06_1145_v152_23_bank_withdraw_invariants.md`
0153. `change_cycle_2026-03-06_1205_v152_24_idem_tasks_runtime.md`


0154 | 2026-03-06 | v152_25 | withdraw admin canon sync
0226. `change_cycle_2026-03-06_1435_v152_26_ci_runtime_sync.md`

0227.
`change_cycle_2026-03-06_2010_v152_27_runtime_routes_startup_fix.md`

0228. `change_cycle_2026-03-06_2145_v152_28_runtime_load_log.md`

0229.
`change_cycle_2026-03-07_1415_v152_29_runtime_pytest_
startup_sync.md`

0230. `change_cycle_2026-03-07_1515_v152_30_referrals_page_stats_bonus.md`

0231. `change_cycle_2026-03-07_1645_v152_31_telegram_native_ui_sync.md`
- 2026-03-07 17:35 — `change_cycle_2026-03-07_1735_v152_32_lotteries_vip_3000.md`

0232. `change_cycle_2026-03-07_1815_v152_33_wallet_history.md`

- change_cycle_2026-03-07_1835_v152_34_wallet_subsections.md

0233. `change_cycle_2026-03-07_1900_v152_35_profile_wallet_history_faq.md`

0234. `change_cycle_2026-03-07_1945_v153_01_ci_mypy_pytest_sync.md`

- 2026-03-07 — v153_02 — release ZIP cache cleanup — reports/change_cycle_2026-03-07_2015_v153_02_release_zip_cache_cleanup.md
