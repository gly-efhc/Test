v150_57

- Updated repo file integrity baseline manifest to reflect
  legacy bank-tg_id files moved to artifacts.
- Removed baseline expectations for three legacy paths:
  backend/app/models/bank_models.py
  backend/app/scheduler/bankstate_recalc.py
  backend/app/scheduler/jobs/job_bankstate_recalc.py
