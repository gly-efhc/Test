# Change cycle 2026-06-17 — v171.17 / cycle 1542

## Input

- HEAD: `EFHC_Bot_v171_16_cycle_1541_fresh_ci_frontend_noise_log_repair.zip`
- Log: `logs_74653569841.zip`
- Log ZIP: readable, `testzip=None`.

## Log verdict

Failed gates: `pytest`.

Passed gates in the uploaded log: flake8 critical/full, `ruff`,
`mypy backend/app`, `bandit`, `compileall`, Alembic, `npm ci` and frontend
build.

Pytest in the uploaded log: `1 failed, 2083 passed, 8 skipped, 2 warnings`.

## Root cause

The only failed pytest was a stale architecture guard that expected an exact
blank line in a referral runtime test import block. The source file itself was
already accepted by `ruff` and `flake8`; therefore the correct repair was to
make the guard semantic rather than formatting-fragile.

## Local repair

- Updated `tests/architecture/test_fresh_ci_artifact_hygiene_log_repair.py`.
- Added `tests/architecture/test_fresh_ci_frontend_noise_rerun_confirmation.py`.
- Added generated report and NORM note for cycle 1542.
- Refreshed Kernel/map/cycles/reports/testing-manifest/healer/registry surfaces.

## Protected boundaries

No economy, rates, balances, referral bonus amount, wallet binding, TonConnect
proof, idempotency, money-flow or withdraw business logic changed.

## Claims not made

No GitHub CI green, full pytest green, live Telegram proof, real TonConnect
proof, release-ready or production-ready claim is made for the output archive.
