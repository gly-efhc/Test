# Циклы 1641–1642 — canonical global owner

## Результат

Финансовые транзакции, Panels, Withdrawals и создание Payment Intents
переведены на canonical `global_id`. Временный `global_id` остаётся только
provider selector и nullable audit attribute.

## Причина

До этого сервисы могли разрешить canonical owner, но затем возвращались к
`global_id`. Это блокировало TON-only аккаунты и создавало разные ownership
пути для одной бизнес-операции.

## Исправление

- transaction entrypoints принимают ровно один selector;
- владелец разрешается и блокируется через write-side boundary;
- ledger читает и пишет canonical `global_id`;
- повтор по другому selector проходит тот же idempotency read-through;
- панели создаются и архивируются по `global_id`;
- withdraw request, hold, cancel и refund используют `global_id`;
- три create-flow Payment Intents используют canonical owner;
- payload поддерживает numeric Telegram token и `G##########`;
- provider-колонки `tg_id` сделаны nullable;
- existing-schema repair создаёт global owner idempotency index.

## Влияние

TON-only account больше не требует Telegram ID в реализованных write-path.
Финансовая математика, Decimal precision, migration-control flags и
production cutover не изменялись. Frontend, Admin, screenshot workflow и
канонический CI не изменялись.

## Проверки

- целевые финансовые и доменные тесты: 45 пройдено, 12 пропущено;
- дополнительная проверка миграции и идентичности: 20 пройдено;
- первая треть архитектурного реестра: 805 пройдено;
- полный граф на последней проверке: 3335 тестов;
- компиляция backend и миграции: пройдена;
- PostgreSQL-зависимые тесты локально пропущены.

## Открытые хвосты

- watcher должен принять canonical payment payload owner;
- referral и exchange idempotency keys переводятся в следующих циклах;
- route, bot, admin и scheduler callers переводятся отдельно;
- legacy aliases удаляются только в циклах 1646–1647;
- exact-head GitHub CI обязателен для полной квалификации.

## Статус

```text
CURRENT_HEAD_V172_59
CYCLE_1641_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1642_LOCAL_SCOPE_IMPLEMENTED
CYCLE_1641_1642_EXACT_HEAD_CI_REQUIRED
PRODUCTION_CUTOVER_NOT_EXECUTED
NOT_PRODUCTION_RELEASE_READY
```
