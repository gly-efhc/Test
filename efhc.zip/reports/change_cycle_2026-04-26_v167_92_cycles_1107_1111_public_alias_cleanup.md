# CHANGE REPORT v167_92 — cycles 1107-1111

What changed:
- imported fresh green logs and confirmed no active CI failure wave;
- removed public `reward*` aliases from active task/ads/profile/admin user-visible paths;
- removed old locale alias keys `profile.reason.ad_reward`, `profile.reason.task_reward`, `tasks.ad_reward_ok`;
- kept technical runtime/DB `reward*` names under the approved neutral-alias transition policy;
- reran focused guards and kept blocker layers clean.

Archive note:
- FLAT ZIP
- no junk caches
- migration canon still 0001-only
