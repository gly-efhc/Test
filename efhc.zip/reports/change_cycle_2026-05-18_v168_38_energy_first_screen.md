# Change report v168_38

Date: 2026-05-18
Cycles: 1226-1228
Focus: Energy first-screen visual repair

## Summary

This pass continues the approved route: close the launch and strong
Energy first-screen block before moving to the shared EFHC Game UI Kit.

The user confirmed that Profile stays a page, not an overlay, and that
Energy should use Dragon-like first-screen structure without copying
Dragon branding or assets.

## Changed code

- `frontend/src/pages/index.tsx`
  - Energy now has a stronger game-stage first screen;
  - live kWh and progress remain visible;
  - active panels and generation rate appear as compact chips;
  - first-screen actions go to Panels and Exchange;
  - line72 issues in the file were corrected.

- `frontend/src/components/Layout.tsx`
  - removed the duplicate pre-page skin hero on `/`.

- `frontend/src/styles/globals.css`
  - added Energy first-screen visual classes.

- `frontend/public/locale/en.json`
- `frontend/public/locale/ru.json`
  - added Energy action labels.

## Changed tests

- Added
  `tests/architecture/`
  `test_energy_first_screen_guard.py`.

## Changed documents

- Added
  `docs/audits/FRONTEND_ENERGY_FIRST_SCREEN_V168_38.md`.
- Added
  `reports/generated/frontend_energy_first_screen_v168_38.json`.
- Updated reports index, AI temporary memory and Q/A register.

## Checks

- JSON validation: passed.
- Targeted architecture tests: 14 passed.
- Changed-file line72 check: passed.
- TypeScript attempted: failed because `node_modules` are absent in the
  archive, causing missing React/Next type dependency errors.
- New ZIP integrity check: run after packaging.

## Not claimed

- GitHub CI was not run.
- Docker runtime proof was not run.
- Live browser proof was not run after this package.
- Frontend 99 percent readiness is not claimed yet.
