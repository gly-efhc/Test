# change_cycle_2026-04-11_v166_46_cycle_850_watcher_shop_line72_terms_wave

## Scope
Continuation of active cycle 850 only.

## What was fixed
- fixed regression in `payment_reconciliation_service.py` where
  `amount_guard` had been referenced before definition and guard reasons
  were swapped again.
- restored watcher compatibility for monkeypatched `_confirm_payment_intent`
  call sites that do not accept `return_note`; legacy test/runtime shims now
  fall back to the older call shape instead of dropping into
  `pending_manual`.
- restored the exact watcher compatibility marker string
  `if purpose == "shop_external":` required by the architecture guard.
- fixed frontend `/admin/shop` force-fulfill idempotency call to match the
  current zero-argument `newIdempotencyKey()` signature.
- fixed an extra closing JSX wrapper in
  `frontend/src/pages/admin/withdrawals.tsx` discovered during narrow local
  parsing.
- continued line72 reduction in active backend/ops files and lowered the
  residual count from 115 to 102 under the current architecture test scope.

## Audit work
- re-read active AI / cycles / SSOT documents from HEAD before edits.
- verified that frontend is **not** fully excluded from line72: pages,
  components and styles are excluded, but `frontend/src/features/**`,
  hooks, lib, config and generated seam files remain inside the scan scope.
- audited `docs/SSOT/TERMS_GLOSSARY.md` against active AI / canon / NORM /
  chat vocabulary and prepared a missing-terms candidate set for approval;
  glossary itself was not expanded without user approval.

## Local narrow checks
- `python -m py_compile` on touched backend/ops files: passed.
- targeted line72 recount script: 115 -> 102.
- targeted frontend syntax check uncovered and then removed an extra JSX
  closer in `admin/withdrawals.tsx`.
- fresh local `npx tsc --noEmit` is not equivalent to GitHub CI here because
  this sandbox lacks installed frontend dependencies; it now proceeds past
  the fixed syntax point and stops on dependency-env noise instead.

## Honesty gate
Cycle 850 remains open.
No claim of green GitHub CI is made in this pass.
