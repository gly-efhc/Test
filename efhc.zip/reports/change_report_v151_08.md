# Change report v151_08

## Scope

Cycle: Ruff sanitation, 50 fixes per cycle.

## Fixed in this cycle

- Ruff: **50** fixes (codes: **I001**, **F401**)
- Command:
  - `ruff check --select I001,F401 --fix <selected_files>`

## Remaining (same codes)

- Ruff I001/F401 remaining: **181**

## Files changed

(50 files, each had exactly 1 I001/F401 issue)

- backend/app/bot/handlers/admin/admin_ads_handlers.py
- backend/app/bot/handlers/admin/admin_lotteries_handlers.py
- backend/app/bot/handlers/admin/admin_main_handlers.py
- backend/app/bot/handlers/admin/admin_panels_handlers.py
- backend/app/bot/handlers/admin/admin_referrals_handlers.py
- backend/app/bot/handlers/admin/admin_shop_handlers.py
- backend/app/bot/handlers/admin/admin_stats_handlers.py
- backend/app/bot/handlers/admin/admin_tasks_handlers.py
- backend/app/bot/handlers/admin/admin_users_handlers.py
- backend/app/bot/handlers/admin/admin_withdrawals_handlers.py
- backend/app/bot/handlers/admin_handlers.py
- backend/app/bot/handlers/ads_handlers.py
- backend/app/bot/handlers/balance_handlers.py
- backend/app/bot/handlers/errors_handlers.py
- backend/app/bot/handlers/exchange_handlers.py
- backend/app/bot/handlers/lotteries_handlers.py
- backend/app/bot/handlers/panels_handlers.py
- backend/app/bot/handlers/profile_handlers.py
- backend/app/bot/handlers/ranks_handlers.py
- backend/app/bot/handlers/referrals_handlers.py
- backend/app/bot/handlers/shop_handlers.py
- backend/app/bot/handlers/start_handlers.py
- backend/app/bot/handlers/subscriptions_handlers.py
- backend/app/bot/handlers/tasks_handlers.py
- backend/app/bot/handlers/webapp_handlers.py
- backend/app/bot/handlers/withdraw_handlers.py
- backend/app/bot/keyboards.py
- backend/app/bot/middlewares.py
- backend/app/bot/states.py
- backend/app/contracts/admin_contract.py
- backend/app/core/__init__.py
- backend/app/core/config_core.py
- backend/app/core/database_core.py
- backend/app/core/system_locks.py
- backend/app/core/utils_core.py
- backend/app/crud/order_crud.py
- backend/app/crud/shop_crud.py
- backend/app/crud/tasks_crud.py
- backend/app/crud/transactions_crud.py
- backend/app/crud/transfers_crud.py
- backend/app/crud/user_crud.py
- backend/app/crud/wallets_crud.py
- backend/app/integrations/nft_api.py
- backend/app/main.py
- backend/app/middleware/telegram_webapp_auth.py
- backend/app/models/admin_models.py
- backend/app/models/external_events_models.py
- backend/app/models/payment_intents_models.py
- backend/app/models/referral_codes_models.py
- backend/app/models/scheduler_models.py

## Safety

- No business-logic changes intended.
- Only import ordering / removal of truly unused imports.

## Local checks

- `pytest -q tests/architecture/test_max_line_length_72.py` -> PASS
