# Change report v151_07

## Scope

Cycle 1: fix 50 Ruff issues (safe set): I001 + F401.

## Result

- Fixed: 50
- Codes: I001 (unsorted-imports), F401 (unused-import)
- Command (scoped):
  - ruff check --select I001,F401 --fix <files>

## Files changed (9)

- backend/app/services/lotteries_service.py
- backend/app/services/referral_service.py
- backend/app/deps.py
- backend/app/models/tasks_models.py
- backend/app/services/orders_service.py
- backend/app/utils.py
- backend/app/integrations/ads_providers.py
- backend/app/bot/bot.py
- backend/app/crud/lotteries_crud.py

## Checks

- tests/architecture/test_max_line_length_72.py: PASS

## Notes

Only import sorting and unused import cleanup were applied.
No business logic, DB logic, or monetary rules were changed.
