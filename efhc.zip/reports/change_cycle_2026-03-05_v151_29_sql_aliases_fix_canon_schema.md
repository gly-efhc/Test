# Change report 2026-03-05 v151_29

- Fix canon_schema NameError in models used by tests/alembic.
- Normalize SCHEMA in models via canon_schema(get_settings()).
- Fix import ordering in config_core.py (ruff I001).
- Add SEEN entry for logs_59405477317.
