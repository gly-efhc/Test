# change_cycle_2026-03-01_1510_v149_46_fix_index_schema_and_guard

## Что упало (истина по logs_58943419183.zip)

- Alembic upgrade head (Postgres-only)
- Ошибка: `TypeError: Additional arguments ... got 'schema'`
- Root cause: в ORM-модели использован `schema=` внутри `Index(...)` (SQLAlchemy не поддерживает).
- Evidence: `backend/app/models/shop_models.py` (несколько Index с `schema=CORE_SCHEMA`).

## Что сделано

1) Удалён `schema=` из всех `Index(...)` в ORM-моделях, где он встречался (включая shop_models и другие модели core).
2) Усилен `ops/canon_guard.py`:
   - запрет `backend.app.*` импортов в `backend/app/**` (CI/Alembic запускается из `backend/`, верхний пакет = `app`).
   - запрет `schema=` kwarg в `Index(...)` и `Column(...)` (schema только на уровне таблицы).
3) Обновлён `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` новым классом ошибки по shop_models (с привязкой к logs).

## Изменённые файлы

- backend/app/models/shop_models.py
- backend/app/models/panels_models.py
- backend/app/models/ranks_models.py
- backend/app/models/referral_models.py
- backend/app/models/ton_logs_models.py
- backend/app/models/transactions_models.py
- backend/app/models/user_models.py
- ops/canon_guard.py
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/change_cycle_2026-03-01_1510_v149_46_fix_index_schema_and_guard.md

## Проверки

- Repo bans (telegram-id/tg_id/user-key/rank*): ожидаемо PASS (не добавлялись)
- CI истины: будет подтверждено только по новым logs_*.zip после прогона
