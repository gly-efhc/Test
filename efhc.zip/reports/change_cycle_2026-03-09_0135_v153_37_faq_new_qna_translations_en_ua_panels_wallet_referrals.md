# v153_37 — FAQ new Q&A translations EN/UA (panels/wallet/referrals)

Date: 2026-03-09

## Scope
- Continue FAQ saturation translations after v153_36
- Translate newly added RU-only questions to EN and UA
- Keep canon_guard and line72 clean

## Added translations
- EN: 3.1-6..10, 5.1-6..9, 6.2-1..11
- UA: 3.1-6..10, 5.1-6..9, 6.2-1..11

## Notes
- Fixed UA wording to use `гаманець` instead of mixed forms
- No CI claims without fresh logs_*.zip

## Checks
- canon_guard: OK
- changed-file line72: OK
- targeted tsc: not proven in this environment
