# Change report v150_67

## CI fixes (logs_59307514171)

1) Frontend build (Next.js) failed:
- File: frontend/src/pages/lotteries.tsx
- Fix: repaired invalid JSX attributes where className was split as
  `className=\n  "..."` (invalid TSX).
  Now each className is a valid TSX attribute value.

2) Cleanup:
- Deleted folder: artifacts/ (user разрешил удалить; удалено полностью).

3) Pre-pack cleanup:
- Removed caches before packaging: __pycache__, .pytest_cache,
node_modules,
  dist, build, .next (если были).

## Notes
- ZIP is FLAT (no wrapping folder).
