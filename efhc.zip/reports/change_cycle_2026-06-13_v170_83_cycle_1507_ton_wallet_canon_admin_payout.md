# Change report — v170.83 / cycle 1507

## Cycle

`1507 — PACK-02 TON Wallet Canon / Admin Payout Canon`

## Input

`EFHC_Bot_v170_82_cycle_1506_pack_01_withdraw_canon_clarification.zip`

## Output

`EFHC_Bot_v170_83_cycle_1507_ton_wallet_canon_admin_payout.zip`


## Mandatory clarification applied

The user clarification for PACK-02 is applied as binding scope:

- PACK-02 is not an exploratory audit.
- The single active mechanism is TonConnect proof -> signature
  verification -> `global_id` binding -> `wallet_bindings` -> replay
  protection -> idempotency.
- Legacy `wallet_binding_service.py` is removed from active runtime.
- Admin payout is operator wallet-flow, not treasury/private funds
  access.

## Changes

- Added canonical TON address helper in `backend/app/lib/ton_address.py`.
- Updated active wallet connect path to store canonical address.
- Updated watcher/deposit lookup normalization for valid TON addresses.
- Removed legacy memo/bind-request wallet binding runtime service.
- Added wallet/admin payout canon docs.
- Added architecture and canonical address regression tests.

## Non-changes

- Economy changed: no.
- Withdraw PACK-01 canon changed: no.
- Backend money write-flow changed: no.
- OpenAPI changed: no.
- Migration changed: no.
- CI/workflow/lock files changed: no.
- Runtime code copied from Grafana/Sandbox: no.

## Claims not made

- GitHub CI green is not claimed.
- Full pytest green is not claimed.
- Release-ready is not claimed.
- Browser screenshot proof is not claimed.
