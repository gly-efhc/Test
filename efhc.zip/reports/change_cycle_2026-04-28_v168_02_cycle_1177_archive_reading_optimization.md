# Change Report — v168_02 — cycle 1177

## Theme

Archive reading optimization and synaptic routing layer.

## User task

Optimize EFHC archive reading so a new chat does not load old logs,
old reports, all FAQ languages, full frontend or full backend by
  default.
Create convenient archive synaptic links for task-based work.

## Root cause

The previous startup reading habit was too broad. It mixed mandatory
prompt/canon reading with historical reports, old logs, full FAQ/i18n
payloads and large code areas. This increased token pressure and made
it easier for the assistant to drown in repeated data instead of loading
the exact road required by the task.

## What changed

Created a new fast reading control layer in `docs/AI/`:

- `READING_ENTRYPOINT.md`;
- `READING_BUDGET.md`;
- `TOPIC_READING_ROUTES.md`;
- `FAQ_READING_POLICY.md`;
- `LOGS_AND_REPORTS_RETENTION_POLICY.md`;
- `ARCHIVE_SYNAPTIC_LINKS.md`;
- `ARCHIVE_FAST_MANIFEST.md`.

Updated existing AI control files:

- `docs/AI/AI_DOCS_INDEX.md`;
- `docs/AI/AI_OPERATOR_RULES_EFHC.md`;
- `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`.

Updated project memory:

- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`;
- `HEALER_ATLAS.md`.

## New reading contours

A — Start Core:
AI reading docs, active AI layer, key NORM/SSOT, Healer, guard registry,
`atlas.json` as an index and latest relevant report.

B — Topic Core:
route-based loading by feature, for example withdraw, panels, exchange,
shop/payment, TonConnect, FAQ, multilingual audit, admin, CI or release.

C — Historical Archive:
old reports, old logs, old audits and old cycle documents. Loaded only
for regression, history, comparison or Healer-linked investigation.

D — Heavy Data:
full backend, full frontend, all FAQ languages, FAQ catalogs and large
data/index files. Loaded only for explicit full audit or narrow task
need.

## FAQ decision

RU FAQ is now the mandatory default canonical FAQ reading language.
Other FAQ languages remain in the archive and are loaded only for
multilingual audit, release QA, translation repair or requested locale
work. This changes reading order only; it does not delete or downgrade
13-language localization.

## Validation performed

- ZIP was tested with `unzip -t` before work.
- Archive was physically unpacked into a workdir.
- Root structure was inspected.
- New files were created in the unpacked archive.
- Updated AI files were checked for expected markers.
- Local text line-length check was run for newly created reading docs.
- New release ZIP was built as FLAT archive with system `zip`.
- New release ZIP was tested with `unzip -t`.

## Boundary

No backend runtime code was changed.
No frontend runtime code was changed.
No CI workflow file was changed.
No migration history was changed.
No historical report was rewritten.
