# line72_cycle_022

Goal: T3A Bottom Navigation canon (6 tabs, fixed order, icons, labels).

Changes:
- Layout.tsx: bottom tabs remain SSOT array with canon href+key,
  added canon labels, icons, and active-click no-op.
- Bottom nav now renders icon + one-line label for all 6 tabs.

Line72:
- No exceptions.

Checks:
- python -m compileall backend -q
- pytest -q
