# v153_23 — FAQ DE/FR/ES sections 5-8

## Scope
Added item-level translations for the rebuilt user-facing FAQ on:
- section 5: Wallet
- section 6: Referrals
- section 7: VIP NFT
- section 8: Shop and skins

Languages covered in this cycle:
- de
- fr
- es

## What changed
- Extended `frontend/src/data/faq/localized.ts` with new item-level
  overrides for the rebuilt FAQ ids:
  - `5.1-1`..`5.1-5`
  - `6.1-1`..`6.1-6`
  - `7.1-1`..`7.1-5`
  - `8.1-1`..`8.1-4`
  - `8.2-1`..`8.2-3`
- Fixed two line72 violations introduced during translation edits.

## Checks
- `python ops/canon_guard.py` -> OK
- changed-file `line72` -> OK

## Notes
- No fresh `logs_*.zip` was provided for this archive.
- Full green CI is not claimed.
