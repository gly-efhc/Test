# Change report v149_75

- Fix: Alembic 0001_init.py removed AUTOCOMMIT switch.
- Reason: CI failed with InvalidRequestError on
  conn.execution_options(isolation_level='AUTOCOMMIT').
- New: CREATE SCHEMA uses conn.exec_driver_sql within txn.
