# Change cycle — 2026-03-01 0410 — v149_31

## Цель
Привести первичную миграцию 0001 к канону: **2 схемы** (`efhc_core`, `efhc_admin`) + **ровно 31 таблица** из ORM (`Base.metadata`) в `efhc_core`.
Миграция = производный артефакт, подтверждающий истину ORM детерминированным sanity (`pg_namespace` + `to_regclass`).

## Что изменено (по файлам)
### P0 — убрать третью схему лотерей
- `backend/app/models/lotteries_models.py`
  - `SCHEMA` переведён на `DB_SCHEMA_CORE` (канон: lotteries в `efhc_core`).
- `backend/app/services/admin/admin_lotteries_service.py`
  - убран `DB_SCHEMA_LOTTERIES`; все SQL-операции лотерейного админ-сервиса теперь используют `DB_SCHEMA_CORE`.
- `backend/migrations/env.py`
  - убран `DB_SCHEMA_LOTTERIES` и создание/упоминание третьей схемы.

### P0 — 0001 ORM-only (без extra/raw SQL таблиц)
- `backend/migrations/versions/0001_init.py`
  - заменён целиком на ORM-only версию:
    - создаёт схемы `efhc_core`, `efhc_admin`
    - `SET search_path TO efhc_core`
    - `Base.metadata.create_all(bind=conn)`
    - sanity: `pg_namespace` + `to_regclass('efhc_core.<table>')`
    - контроль count: `expected 31`

### P0 — CI sanity под канон 2 схемы + 31 в core
- `ops/ci_verify_db_objects.py`
  - `REQUIRED` = ровно 31 `efhc_core.<table>` (истина = `Base.metadata.tables`).
  - добавлена проверка существования схем `efhc_core` и `efhc_admin` через `pg_namespace`.
  - не требуются `efhc_admin.*` таблицы.

### SSOT-pack (таблицы)
- `docs/ssot_pack/SSOT_TABLES_ORM.csv`
  - пересобран из `backend/app/models/**` (31 строка, schema=`efhc_core`, `file/line` из определения модели).
- `docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv`
  - отражает 0001: 2 схемы (table=`__schema__`) + 31 таблица `efhc_core.<table>`.

### Документация канона
- `docs/SSOT_DB_0001_CANON.md` — добавлен краткий канон 0001.
- `docs/SSOT_INDEX.md` — добавлена ссылка на `SSOT_DB_0001_CANON.md`.

## Проверки канона (локально, без утверждений про CI)
- repo-wide bans по зонам backend/frontend/ops/migrations: `telegram-id`, `tg_id`, `user-key`, `rank*` — **не обнаружены**.
- `DB_SCHEMA_LOTTERIES` / `efhc_lotteries` в backend — **не обнаружены**.

## Артефакт
- Новый ver-ZIP (FLAT): `EFHC_Bot_v149_31_db_0001_2schemas_31tables_orm_only.zip`
