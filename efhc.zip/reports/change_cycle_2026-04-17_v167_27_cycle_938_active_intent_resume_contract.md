# Cycle 938 — active intent / resume contract hardening

Date: 2026-04-17
Artifact: `EFHC_Bot_v167_27_cycle_938_active_intent_resume_contract.zip`

## What was found

The active-intent seam was still not strict enough for the release-core
continuity path:

- backend create-intent routes could still try to open a new intent path
  without a dedicated truth-first conflict guard;
- Browser-Shop still relied too much on local `intentStatus` when deciding
  whether a new intent could be created;
- if local state lagged behind bootstrap truth, the page could still look
  closer to `create new` than to `resume existing`.

## What was done

- hardened `backend/app/routes/hub_routes.py` so the create-intent path now
  checks `_get_active_intent_truth(...)` first and returns an honest
  `409 CONFLICT` when an unfinished intent already exists;
- kept the message explicit: the user must resume the current payment path,
  not create a duplicate;
- hardened `frontend/src/features/browser-shop/BrowserShopPage.tsx` so the
  resume gate is derived not only from local `intentStatus`, but also from
  backend truth (`flow_truth.active_intent`, `flow_truth.next_step`);
- added a shared `refreshActiveIntentStatus()` helper and a focused
  `handleResumeConflict()` path instead of falling back to a generic local
  error;
- aligned create buttons and disabled states with the backend-first resume
  contract;
- kept language-tail cleanup strictly incidental and only inside touched
  player-facing continuity/payment surfaces.

## Verification done locally

- `python -m compileall backend/app frontend/src`
- `pytest -q tests/architecture/test_payment_intent_continuity_runtime_sync.py`

## Result

Cycle 938 moved the product closer to the intended order for Block B:
backend truth first, response contract second, surface alignment third.
An existing active intent now blocks duplicate create attempts more
honestly and consistently across the runtime path.
