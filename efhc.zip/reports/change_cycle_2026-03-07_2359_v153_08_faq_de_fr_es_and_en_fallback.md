# v153_08 — FAQ DE/FR/ES critical content + EN fallback

Date: 2026-03-07
Archive base: EFHC_Bot_v153_07_faq_content_en_ua.zip
New archive: EFHC_Bot_v153_08_faq_de_fr_es_and_en_fallback.zip

## What changed

Extended item-level FAQ localization in critical user-facing blocks:

- Profile / Settings
- Wallet
- Balances and internal logic
- Exchange
- Withdraw

Added full localized Q/A overrides for:

- de
- fr
- es

Added runtime fallback for critical FAQ item overrides:

- if active language has no item-level override and language is not RU,
  use EN override before falling back to RU source text

## Why

After v153_07, item-level translations existed only for EN and UA.
Users on the remaining locales still saw RU Q/A in key FAQ blocks.
That broke the intended multilingual UX.

## Files changed

- frontend/src/data/faq/index.ts
- frontend/src/data/faq/localized.ts
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md

## Validation

Confirmed locally:

- `python ops/canon_guard.py` -> OK
- targeted TypeScript compile for changed FAQ data layer -> OK
- line72 for changed files -> OK

## Limitations

This cycle does not claim full FAQ translation for all 13 languages.
Remaining languages still need native item-level Q/A translation, but
critical blocks now fall back to EN instead of RU where a local override
is still missing.
