# Change report — 2026-04-08 — v165_75 — cycles 641-650 admin+shop usability wave 21

## Scope
Sandbox donor audit plus useful admin/shop usability improvements for information density, statistics and convenient product-card work.

## Code changes
- richer admin reusable grammar (stat cards, list/detail/settings shells, tabs)
- admin shop surface improved
- browser shop got search/filter/product-card grid/detail pane

## Docs
- ADMIN_SANDBOX_AUDIT_641_650_2026_04_08.md
- ADMIN_AND_SHOP_EXPANSION_WAVE_641_650_2026_04_08.md
- ADMIN_AND_SHOP_REAUDIT_SLICE_641_650_2026_04_08.md

## Validation
- locale JSON parsed successfully
- archive rebuilt
- no GitHub CI run
