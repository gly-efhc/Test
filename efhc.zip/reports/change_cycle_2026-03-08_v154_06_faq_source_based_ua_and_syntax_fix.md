# Change Cycle v154_06

Date: 2026-03-08

## Confirmed findings

- `frontend/src/data/faq/localized.ts` had broken string quotes in
  Italian, Turkish and Polish FAQ items.
- Ukrainian FAQ still depended on English fallback cloning at the end
  of `localized.ts`.
- Remaining English clone fallback still exists for: de, fr, es.

## Applied fixes

- Fixed broken quoted strings for `Ricarica`, `Yükle`, `Doładuj`.
- Replaced Ukrainian `cloneEnFaqItems(...)` fallback with explicit
  Ukrainian source-based FAQ overrides derived from the Russian
  primary meaning.
- Kept FAQ 12-section structure unchanged.

## Local checks

- `test_max_line_length_72.py` passed
- `test_no_banned_rank_terms.py` passed
- `test_no_legacy_words.py` passed
- `test_no_placeholders.py` passed

## Remaining work

- Replace English fallback clones for `de`, `fr`, `es` with
  source-based localized overrides from the Russian primary text.
- Then rerun targeted FAQ checks and package the next ZIP.
