# Change Report — v169.47 / cycle 1369 — i18n critical audit repair

## Input

- Base HEAD: `EFHC_Bot_v169_46_public_visual_trust_pass_hub_browser_shop_withdraw_ads.zip`
- User-provided audit: `I18N_FULL_AUDIT_REPORT_v169_45_2026_06_02.md`
- User-provided summary: `i18n_audit_summary_v169_45.json`

## Goal

Repair the critical localization blockers found by the audit before continuing
TMA shell or wallet UX polish.

## Code changes

- `frontend/src/lib/i18n.ts`: player-facing fallback is now English-first.
- `frontend/public/locale/*.json`: five empty keys filled in all 13 languages.
- `frontend/public/locale/hi.json`: restored `{count}` and `{id}` placeholders.
- `frontend/src/pages/app.tsx`: main shell admin guard fallback copy changed to English.
- `frontend/src/components/ShopLayout.tsx`: hardcoded Russian fallback removed.
- `frontend/src/components/Layout.tsx` and `ShopLayout.tsx`: description fallback no longer forces `ruDict`.
- `ops/i18n/audit_bot_texts_parity.py`: importlib typo fixed.

## Documentation changes

- Added critical repair pass doc.
- Added repair audit.
- Imported the original i18n audit into `docs/audits/`.
- Imported audit summary JSON into `reports/generated/`.
- Updated cycle plan and AI reading routes.
- Updated `TRANSLATION_STATUS.md` to avoid false `complete` claims.

## Test / guard changes

- Added `tests/architecture/test_i18n_critical_audit_repair.py`.

## Not claimed

- Full translation completion for all languages.
- FAQ wave-3 translation completion.
- Browser screenshots.
- GitHub CI green.
- Full frontend build/typecheck.
