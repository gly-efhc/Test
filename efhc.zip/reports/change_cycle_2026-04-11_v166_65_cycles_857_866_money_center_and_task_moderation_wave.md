# EFHC Bot v166_65 — cycles 857/866 money-center and task moderation wave

## What changed
- Deepened Money-Center UX inside `ProfileModal` by adding a unified financial card for wallet, balance, latest withdraw status and history entrypoints.
- Replaced the old helper-only `admin/tasks` page with an operator-oriented submissions moderation surface.
- Added task list selection, per-task submissions queue, status filter, refresh action and idempotent approve/reject controls.

## Why
- User requested a seamless financial contour across profile, wallet, history and withdraw with no dead ends.
- User also set `Submissions Moderation Surface` as the next operational priority before shop polishing.

## Validation
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` passed.
