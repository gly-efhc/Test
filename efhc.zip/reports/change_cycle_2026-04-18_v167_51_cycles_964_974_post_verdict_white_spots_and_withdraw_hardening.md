# v167_51 — cycles 964-974 — post-verdict white-spots and withdraw hardening

## Scope
- normalize white spots from external audit and HEAD;
- harden player-facing truth for ADS / NFT / FAQ-help / Browser-Shop payment guidance;
- harden withdraw path against a second active PENDING request;
- refresh AI/cycle/Q&A/report control layer.

## Closed cycles
- 964 — white spots registry normalization
- 965 — TonConnect timeout and cancel UX audit
- 966 — deposit waiting/progress feedback hardening
- 967 — return-path reinforcement
- 968 — Browser-Shop payment instruction clarity
- 969 — Web-Profile transaction visibility expansion
- 970 — ProfileModal bounded quick-view refinement
- 971 — ADS route truth decision
- 972 — NFT surface truth decision
- 973 — FAQ / help linkage reinforcement
- 974 — withdraw protection hardening

## Key runtime changes
- `/ads` now states clearly that it is a compatibility alias to `/tasks`.
- Hub now exposes FAQ / Help directly and marks VIP / NFT as an external beta contour.
- Browser-Shop now exposes clearer payment instructions, progress, and return-path actions.
- `request_withdraw()` blocks a second active PENDING request after row lock + idempotency-first check.
