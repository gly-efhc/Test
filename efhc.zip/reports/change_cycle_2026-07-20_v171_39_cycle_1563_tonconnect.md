# Change report — v171.39 / cycle 1563

## Scope

Cycle 1563 closes the local TonConnect wallet and transaction UX contour:
manifest, reactive session restore, complete TonProof binding, connection
rejection, transaction rejection and controlled browser interaction proof.

## Main repairs

1. The frontend previously verified TonProof and then sent an incomplete
   `/wallets/connect` request. It now sends the complete proof envelope.
2. The compatibility wallet hook previously read a connector snapshot without
   subscribing to status changes. Wallet restore and connect are now reactive.
3. Restore-in-progress, restored-disconnected and restored-connected are now
   distinct states.
4. TonConnect user rejection is shown as a human state instead of a generic
   API failure.
5. Direct Deposit and Browser Shop use the shared transaction UX wrapper.

## Runtime proof

- Manifest API proof: passed.
- Wallet connect / rejection / proof / restore Chromium scenario: passed.
- Transaction reject / sign / watcher-confirm Chromium scenario: passed.
- Current screenshots: seven.
- Real Ed25519 proof verification boundary: passed.

## Full verification

- Exact test inventory: `2441`.
- Passed: `2304`.
- Skipped: `137`.
- Failed: `0`.
- Omitted: `0`.
- Release evidence score: `29 / 100`.

## Evidence boundary

The controlled connector is enabled only in the E2E build seam. Production
code continues to use the published TonConnect SDK. A live HTTPS manifest,
real wallet signature and real network transaction are not claimed.
