# Change report — v170.88 / cycle 1512

## Cycle

1512 — Admin Runtime P1 Fix / Admin Seams Cleanup.

## Input

- Archive: `EFHC_Bot_v170_87_cycle_1511_github_ci_log_repair.zip`
- Log: `logs_74012116642.zip`

## Log status

The input GitHub CI log is green:

- ruff passed;
- mypy passed;
- bandit passed;
- pytest: `1850 passed, 8 skipped, 1 warning`;
- frontend build passed;
- gate summary: `OK: all gate steps passed`.

## Fixes

- Removed unsupported kwargs from withdraw hold repair call.
- Added `meta` to `debit_user_bonus_to_bank` and forwarded it to
  `_run_idempotent`.
- Added runtime regression tests for withdraw hold repair and admin
  BONUS debit.
- Added AST call-signature guard for admin money call sites.
- Extended admin seam path constants to cover all current OpenAPI
  `/admin` paths.
- Documented tracked raw admin `apiRequest` migration debt.
- Documented `/admin/shop/items/set-price` and `/admin/tasks/{task_id}`
  as legacy/internal routes until a later UI/removal cycle.

## Not claimed

No fresh GitHub CI green is claimed for v170.88 until a rerun proves it.
No release-ready or visual OK status is claimed.
