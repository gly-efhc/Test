# v153_13 — FAQ VIP / Shop / Lotteries / Common situations EN+UA

Date: 2026-03-08
Source HEAD ZIP: v153_12
Fresh logs ZIP: not provided for this cycle

## What changed

- Added EN item-level FAQ translations for blocks:
  - 15.1 VIP NFT
  - 15.2 Shop
  - 16.1 Lotteries general mechanics
  - 16.2 Tickets and draw
  - 16.3 Prizes
  - 17.1 Common situations
- Added UA item-level FAQ translations for the same blocks.
- Kept the existing override fallback chain:
  user lang -> en -> ru.

## Scope

This cycle continues FAQ content localization beyond the already
translated critical blocks. It does not claim full CI green, because no
fresh logs_*.zip was provided for the new archive.

## Local checks

- canon_guard: OK
- targeted FAQ data-layer TypeScript compile: OK
- changed file line72: OK
