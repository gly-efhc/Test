# Change cycle — 2026-03-07 18:15 — v152_33 wallet history

## Что сделано

Добавлена пользовательская история изменения балансов в разделе Wallet
(ProfileModal wallet section).

## Аудит

Источником истины для истории выбран каноничный банковский журнал
`efhc_core.efhc_transfers_log`.

Это правильно по смыслу, потому что именно он фиксирует:
- приход в `main` / `bonus`
- расход из `main` / `bonus`
- `reason`
- `direction`
- время операции

## Backend

Добавлено:
- `GET /wallets/balance-history`
- новый desc-cursor helper для user transfers
- новые wallet schemas для response DTO

Маршрут возвращает историю от новых к старым и не требует `tg_id`
в query/body — используется текущий Telegram user context.

## Frontend

В `ProfileModal` добавлен новый блок `История баланса`.

Показывается:
- причина операции
- пришло / ушло
- MAIN / BONUS
- сумма EFHC
- дата и время
- пагинация `Загрузить ещё`

## Логика причин

Для частых причин добавлены человекочитаемые подписи:
- пополнение
- покупка панели
- покупка в Shop
- обмен kWh
- вывод
- реферальный бонус
- реферальный уровневый бонус
- награда за задание
- приз лотереи
- admin credit/debit

Неизвестные reason fallback-показываются как raw reason с заменой `_`
на пробел.

## Проверка

Локально подтверждено:
- `py_compile` changed backend files — ok
- `compileall backend/app` — ok
- line72 на изменённых файлах — ok

Ограничение:
- frontend build не был подтверждён в контейнере, потому что локально
  отсутствует `next` binary / не подняты frontend dependencies.
- полный CI/runtime статус ждёт новый `logs_*.zip`.
