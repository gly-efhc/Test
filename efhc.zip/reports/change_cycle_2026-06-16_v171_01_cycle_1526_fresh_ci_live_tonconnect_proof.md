# Change report — v171_01 — cycle 1526

## Cycle

`1526 — Fresh CI Rerun / Live Telegram / Real TonConnect Proof`.

## Status

`DONE_LOCALLY_FAIL_CLOSED`.

## Summary

Cycle 1526 refreshed the release proof gate for the canonical `v171.00`
HEAD and produced a `v171.01` output archive without claiming external proof.

## Changed

- `ops/release/release_readiness_proof_gate.py` now supports explicit cycle,
  input head, output target and fresh CI status parameters.
- Added current gate report for cycle 1526 and `v171.01`.
- Added guard for the current cycle 1526 gate report.
- Updated Kernel, cycle index, report index, map and test guard manifest.

## Not changed

Runtime service code, money-flow, withdraw logic, wallet binding logic,
TonConnect behavior, EFHC economy, frontend runtime and backend API logic were
not changed.

## Proof boundary

No `logs_*.zip` was provided. GitHub CI green, live Telegram proof, real
TonConnect proof and release-ready status are not claimed.
