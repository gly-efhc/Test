# Изменения v172.66 — коррекция global owner rewrite

Fresh CI run `30937377315` exact v172.65 выявил 181 pytest failure,
22 Mypy errors, 9 Ruff errors, Bandit B101 и frontend TypeScript errors.

Корень — механическое смешение provider и owner полей. В v172.66
повреждённый codemod удалён как единый слой, восстановлено рабочее
runtime-ядро и сохранён controlled alias-harness. Все test-файлы
проверены точечным набором файлов, реально упавших в переданном
CI. Fresh exact-head CI остаётся обязательным.

## Точечная проверка подтверждённых failures

Проверены все `90` test-файлов, реально упавших в exact `v172.65` CI.

```text
384 passed, 90 skipped
```

Дополнительно выполнены только `compileall`, test collection и
machine guards изменённого контура. Полный локальный CI не
используется как замена пользовательскому GitHub CI.

## Зафиксированное правило работы по логам

Пользовательский полный ZIP CI-логов является главным источником
текущего repair-pass. Полные локальные CI, полный pytest, test-shards и
повторы уже зелёных этапов запрещены без доказанной необходимости.
После исправлений выполняются только точечные проверки failures,
compileall, collection и связанные machine guards.

Правило обязательно переносится во все будущие handoff-промты. Его
SSOT: `docs/NORM/USER_PROVIDED_CI_LOGS_REPAIR_CANON.md`.
