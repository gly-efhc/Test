# EFHC change cycle — v153_41

Date: 2026-03-08
Base ZIP: EFHC_Bot_v153_40_faq_it_tr_pl_pytest_fix.zip

## Scope
Completed remaining FAQ translations in `localized.ts`
for `it`, `tr`, `pl`.

## Files changed
- frontend/src/data/faq/localized.ts
- reports/REPORTS_INDEX.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/change_cycle_2026-03-08_v153_41_faq_it_tr_pl_completion.md

## What was added
Added missing FAQ item overrides for `it`, `tr`, `pl`:
- 8.3-1 .. 8.3-14
- 8.4-1 .. 8.4-4
- 10.1-5 .. 10.1-7
- 10.2-1 .. 10.2-12
- 12.1-5 .. 12.1-7
- 12.2-1 .. 12.2-4

## Validation
- `localized.ts`: no `lottery` legacy word remains
- changed-file line72: OK
- targeted tests:
  - tests/architecture/test_no_banned_rank_terms.py
  - tests/efhc_backend/unit/test_no_legacy_words.py
  - tests/test_no_placeholders.py
  result: `3 passed`

## Coverage after cycle
- `it`: 0 missing FAQ item overrides vs `ru.ts`
- `tr`: 0 missing FAQ item overrides vs `ru.ts`
- `pl`: 0 missing FAQ item overrides vs `ru.ts`
- `da`: still pending
- `hi`: still pending
- `id`: still pending
- `sw`: still pending

## CI note
No green CI claim for this ZIP without a new GitHub
`logs_*.zip` for the new archive.
