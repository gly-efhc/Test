# Change report v150_07 (SSOT pack обновление)

## Изменения
- Обновлён SSOT пакет (routes/tables/schemas) под текущий ORM.
- Добавлено описание таблицы efhc_core.unmatched_incoming.
- Обновлены описания SSOT по схемам и маршрутам (с числами).
- Переписан тест unmatched_incoming под Postgres-only и fixtures.

## Файлы
- docs/ssot_pack/SSOT_TABLES_PURPOSE_RU.md
- docs/ssot_pack/SSOT_TABLES_SCHEMAS_DESCRIPTION_RU.md
- docs/ssot_pack/SSOT_ROUTES_DESCRIPTION_RU.md
- docs/ssot_pack/README.md
- tests/test_unmatched_incoming_recording.py
- reports/change_report_v150_07_ssot_pack.md
