# Line length 72 audit - cycle 004
Fixed files (cycle 004):
- frontend/src/components/ProfileModal.tsx
- frontend/src/components/Layout.tsx
- frontend/src/pages/index.tsx
- frontend/src/pages/exchange.tsx
- frontend/src/pages/admin/users.tsx

Notes:
- Files were adjusted conservatively: no logic changes.
- Added lockfile exclusions to 72-test (package-lock/pnpm-lock/yarn.lock).

Current violations summary:
- Total violations (scoped dirs): 251
- Frontend violations: 251

Top remaining frontend offenders:
- frontend/src/pages/admin/users.tsx: 32 (max 139)
- frontend/src/pages/admin/index.tsx: 21 (max 117)
- frontend/src/pages/admin/panels.tsx: 18 (max 123)
- frontend/src/pages/admin/shop.tsx: 15 (max 104)
- frontend/src/pages/shop.tsx: 14 (max 95)
- frontend/src/pages/ranks.tsx: 13 (max 142)
- frontend/src/pages/admin/referrals.tsx: 13 (max 94)
- frontend/src/pages/admin/logs.tsx: 13 (max 106)
- frontend/src/pages/lotteries.tsx: 12 (max 185)
- frontend/src/pages/admin/bank.tsx: 9 (max 117)
- frontend/src/pages/admin/withdrawals.tsx: 9 (max 113)
- frontend/src/pages/admin/tasks.tsx: 9 (max 105)
- frontend/src/pages/admin/prizes.tsx: 9 (max 102)
- frontend/src/styles/globals.css: 8 (max 125)
- frontend/src/pages/_app.tsx: 6 (max 187)
