# Change cycle — 2026-02-28 00:00 (Europe/Uzhgorod) — v149_01 — rollback + fix 0001 syntax (SSOT)

## SSOT inputs
- HEAD ZIP (base): EFHC_Bot_v148_52_fix_alembic_column_schema_kw.zip
- CI logs: logs_58885628855.zip

## What failed
- CI step: `python -m compileall extracted/backend -q`
- Error: `SyntaxError: '(' was never closed`
- File: `backend/migrations/versions/0001_init.py:63`

## Root cause
- Невалидные правки `0001_init.py` (вставка `schema=...` не в том месте + мусорные `,,`) сделали миграцию невалидной для Python.

## Fix
- Откат `backend/migrations/versions/0001_init.py` на корректный вариант (из v148_52).
- Schema фиксируется канонично: **только** на уровне создания таблицы (параметр `schema=` у `ensure_table_with_basics` / `op.create_table`), без `schema=` внутри `sa.Column`.

## Verification (локально на распакованном ZIP)
- Repo-wide bans (text-only scan): PASS
- `python -m compileall backend -q`: PASS

## Files changed in this cycle
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md (новая запись CI-58885628855)
- reports/change_cycle_2026-02-28_0000_v149_01_rollback_fix_0001_syntax.md
- reports/REPORTS_INDEX.md

## Notes
- Alembic upgrade / pytest / frontend build должны быть подтверждены в CI Postgres-only после коммита efhc.zip в репозиторий.
