# v154_20 remove FAQ translations

- Removed FAQ item overrides for all non-RU languages.
- Removed FAQ meta translations for all non-RU languages.
- Kept bot UI locale files unchanged.
- Non-RU FAQ now uses Russian canon via fallback.
