# Change report — v168_48 Docker sync SSL mode

## HEAD

Input archive: `EFHC_Bot_v168_47_cycle_1263_`
`docker_history_runtime_fix.zip`.

## Confirmed problem

User-provided Docker output shows a new runtime blocker after the
asyncpg repair: backend startup fails because psycopg2/Alembic requires
SSL against local Docker Postgres.

## Code changes

- `backend/migrations/env.py`
  - local/dev/ci/test no longer auto-force `sslmode=require`;
  - compose hosts `db` and `postgres` are treated as local DB hosts.
- `docker-compose.yml`
  - local `PSYCOPG_URL` uses `sslmode=disable`.
- `ops/docker/docker-compose.yml`
  - local `PSYCOPG_URL` uses `sslmode=disable`.
- `env.docker.example`
  - mirrors local `PSYCOPG_URL`.

## Tests

- Added cycle 1264 Docker sync SSL guard.
- Updated cycle 1263 guard: sync SSL is local-only;
  asyncpg URL stays clean.

## Verification

- targeted docker sslmode guards: passed.
- ruff: passed.
- compileall: passed.
- ZIP integrity: passed.

## Not claimed

Docker runtime proof was not executed in the assistant environment.
