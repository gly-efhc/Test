# EFHC Bot change report — v167_90 — cycles 1089-1098

## Summary

Closed cycles 1089-1098 with a neutral alias canon, transition alias bridge for task-related payloads, admin bonus wording pass, locale-key aliases and a rerun of repaired tails 1041-1090.

## Main outcomes

- created `docs/SSOT/NEUTRAL_ALIASES_CANON_SSOT.md`;
- added transition field `bonus_efhc` next to legacy `reward_efhc` in safe task-related route responses and payload handling;
- aligned active Russian admin wording from `награда` to `бонус`;
- added locale-key aliases `profile.reason.task_bonus`, `profile.reason.ad_bonus`, `tasks.ad_bonus_ok`;
- reran active user-facing bonus/forbidden/admin guards.

## Honest boundary

Legacy technical names (`reward_bonus_efhc`, `task_rewards_log`, etc.) still exist in the backend and database layer. They are now tracked by the neutral-alias canon and were not destructively renamed in this pass.
