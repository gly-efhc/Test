# Change report — v168_94 cycles 1303-1310

HEAD: EFHC_Bot_v168_93_cycles_1297_1302_referrals_ranks.zip

Completed cycles:

- 1303 — Profile status model;
- 1304 — Profile FAQ button;
- 1305 — Wallet as wallet list;
- 1306 — wallet error microcopy;
- 1307 — History account timeline;
- 1308 — History data contract audit;
- 1309 — FAQ full list compact tree;
- 1310 — Profile/Wallet/FAQ proof pass.

Code changes:

- `frontend/src/features/profile/WebProfilePage.tsx`
- `frontend/src/components/profile/ProfileWalletSection.tsx`
- `frontend/src/components/profile/ProfileHistorySection.tsx`
- `frontend/src/pages/faq.tsx`
- `frontend/src/components/faq/FaqVerticalTree.tsx`
- `frontend/src/components/ui/Button.tsx`
- `frontend/src/components/ui/GameShell.tsx`
- `frontend/src/components/ui/telegram/TelegramInfoBlock.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`

Tests:

- added `tests/architecture/test_profile_wallet_history_faq.py`.
