# EFHC Bot — change report — v166_84 — cycle 872

## Scope
- Fix fresh CI tails from logs
- Publish money-path truth table
- Publish hardcoded UI strings replacement audit list

## Code
- fixed generated frontend validator declaration-order tail via `z.lazy(...)`
- narrowed global_id alias guard to runtime roots only, per approved canon
- preserved runtime-only global_id rule without weakening code-layer enforcement

## Docs
- added `docs/audits/MONEY_PATH_TRUTH_TABLE_872_2026_04_16.md`
- added `docs/audits/HARDCODED_UI_STRINGS_REPLACEMENT_LIST_872_2026_04_16.md`
- updated cycles and report index

## Canon
- one canonical truth table for payment intent semantics
- one controlled replacement list for future i18n migration
- no mass UI copy migration in cycle 872
