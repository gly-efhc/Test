# Change cycle report — v169.90 / cycles 1409-1410

## Summary

Cycle 1409 transaction-boundary map was re-used as the repair base. Cycle 1410
implemented the first HEAL-0018 runtime repair for core money-service transaction
ownership.

## Changed

- `backend/app/services/transactions_service.py`: `_tx_context()` no longer uses
  hidden `begin_nested()` fallback. It now owns commit/rollback for the money
  service boundary.
- `backend/app/services/exchange_service.py`: read-only preflight autobegin is
  closed before entering the money service.

## Added

- `docs/backend/P0_HEAL0018_TRANSACTION_BOUNDARY_REPAIR.md`
- `docs/audits/P0_HEAL0018_TRANSACTION_BOUNDARY_REPAIR_AUDIT_V169_90.md`
- `tests/architecture/test_heal0018_transaction_boundary_repair.py`
- `reports/generated/p0_heal0018_transaction_boundary_repair_v169_90.json`

## Not changed

- No EFHC economics.
- No wallet/TonConnect logic.
- No CI workflow.
- No package lock.
- No frontend runtime.
- No sandbox runtime import.
- No AI Archive Laws changes.

## Residual

- Cycle 1411 must handle HEAL-0024 withdraw/exchange atomicity, especially
  withdraw create/hold/mark state transition.
