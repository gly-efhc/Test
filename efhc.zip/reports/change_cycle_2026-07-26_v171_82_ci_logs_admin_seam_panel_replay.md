# v171.82 — CI logs: Admin seam and panel replay

## Input

- Development HEAD: `EFHC_Bot_v171_81.zip`.
- Development logs: `logs_81865323695.zip`.
- Release logs: `logs_81865822733.zip`.

## Development log result

`4 failed, 2550 passed, 20 skipped`; eight Ruff errors and three frontend
TypeScript contract errors. Mypy checked 294 files successfully. Alembic,
Bandit and compilation were green.

## Release log result

Release pytest: `12 passed`. The release gate failed only on three Ruff errors
and the same frontend TypeScript errors.

## Corrections

- Generated Admin withdrawal validators now include all backend/OpenAPI fields
  and the outcome-preview parser.
- Idempotent panel replay is resolved before current balance/panel-limit checks.
- Current version literals are synchronized to `v171.82`.
- Exact Ruff and 72-column failures are repaired.
- Regression guards protect generator parity and replay ordering.

## Verification boundary

Local bounded validation is recorded separately. Fresh exact-HEAD GitHub CI for
both archives remains mandatory before the next pre-deployment decision.
