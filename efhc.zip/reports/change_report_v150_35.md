# Change report v150_35

Цель: исправление пакета Pydantic-схем (schemas) и канона d8.

## Изменения
- backend/app/schemas/__init__.py:
  - убрана динамическая агрегация экспортов;
  - исключены конфликты имён и нестабильные импорты.
- backend/app/schemas/common_schemas.py:
  - добавлен EfhcBaseModel с json_encoders для Decimal -> d8_str.
- backend/app/schemas/*.py:
  - схемы переведены на наследование от EfhcBaseModel
    (где ранее использовался BaseModel).
- docs/EFHC_CANON.md:
  - уточнён канон сериализации d8;
  - приведены строки к line72.

## Примечания
- Тесты считаются второстепенными; цель патча — согласованность схем
  и единая сериализация Decimal как str d8 в JSON.
