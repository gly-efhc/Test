# Change report

Date: 2026-03-02
Version: v149_73

## Scope

- Fix class: alembic prints metadata, but DB has no schemas/tables.
- Make schema creation and create_all deterministic.

## Evidence

- logs_59048630986.zip
  - post-alembic: only default schemas, required tables missing.

## Changes

### backend/migrations/env.py

- Create efhc_core and efhc_admin schemas in AUTOCOMMIT.

### backend/migrations/versions/0001_init.py

- Create schemas in AUTOCOMMIT.
- Use schema_translate_map {None: efhc_core} for create_all.
- Add stdout markers: create_all_done, ok.

### EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md

- Add class AF: DDL not persisted / pipefail note.
