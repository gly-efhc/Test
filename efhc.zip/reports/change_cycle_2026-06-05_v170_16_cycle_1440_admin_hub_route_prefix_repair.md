# Change report — v170.16 / cycle 1440 Admin Hub route prefix repair

## Summary

Cycle 1440 repaired `F-004` from the active migrations/routes/backend-frontend linkage audit.

Admin Hub is now a dedicated backend route module registered as `/admin/hub/*`, not a nested router inside `/admin/shop/*`.

## Runtime changed

- Added `backend/app/routes/admin_hub_routes.py`.
- Updated `backend/app/routes/__init__.py` to include `admin_hub_routes`.
- Removed nested Hub router from `backend/app/routes/admin_shop_routes.py`.

## Runtime not changed

- No EFHC economy changes.
- No financial invariant changes.
- No migration changes.
- No CI/workflow/lock-file changes.
- No public UI route changes.
- No frontend workaround for backend drift.

## Tests added

- `tests/architecture/test_admin_hub_route_prefix_repair.py`

## Local validation

- `python -m pytest tests/architecture/test_admin_hub_route_prefix_repair.py -q` → `7 passed`.
- Targeted `py_compile` for changed backend route files → passed.

## Non-claims

No GitHub CI green, no full pytest green, no frontend build green, no release-ready, no browser screenshots, no live Telegram proof and no real TonConnect proof are claimed.
