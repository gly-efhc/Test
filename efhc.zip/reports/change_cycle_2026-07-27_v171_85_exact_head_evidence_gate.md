# Change cycle 1588 — v171.85 exact-HEAD evidence gate repair

## Input

- `EFHC_Bot_v171_84.zip`;
- `EFHC_Bot_v171_84_RELEASE.zip`;
- master continuation prompt.

## Confirmed defect

The active local pre-release gate could accept the green v171.67 CI intake as
proof for a later current HEAD and return a false 99-percent completion status.

## Treatment

The gate now resolves the current release version and archive name, accepts only
a green CI record with an exact `source_head` match, records older evidence as
historical/rejected and remains fail-closed when current evidence is absent. Generated release metadata also no longer claims unconditional 99-percent completion; it records the current candidate/proof boundary.

## Status

`LOCAL_RELEASE_CANDIDATE / FRESH_EXACT_HEAD_GITHUB_CI_REQUIRED /
production_release_ready=false`.


## Local validation

Non-overlapping groups:

- architecture top-level files: `2164 passed, 6 skipped` across four
  deterministic filename chunks;
- architecture case modules: `158 passed`;
- root tests: `100 passed, 28 skipped`;
- core/backend/frontend/healer: `98 passed, 115 skipped`;
- local PostgreSQL integration: `1 passed, 22 skipped`;
- independently extracted release profile: `12 passed, 1 skipped`.

Additional checks:

- Canon Guard: PASS;
- workflow parity: PASS;
- Python compilation: PASS;
- 24 release shell scripts: syntax PASS;
- JSON/YAML parse: `778 JSON`, `24 YAML`, PASS;
- packaged frontend assets: `29` files, PASS;
- release internal SHA-256: `744/744`;
- development-source to release production mirror: `742/742`
  byte-identical.

Unavailable or deferred:

- Ruff, Mypy and Bandit commands unavailable in the local environment;
- `npm ci` timed out, so frontend typecheck/build were not run;
- fresh exact-HEAD GitHub CI, Docker/PostgreSQL deployment and live gates were
  not run.


## Non-green auxiliary check

The repository-wide `ops/precommit_canon_check.py` still reports historical
72-column violations across legacy root/config/map files outside this patch.
Newly written `CONTINUE_IN_NEW_CHAT.md` and `README_RELEASE.md` lines were
wrapped; the authoritative architecture max-line guard passes. No test or check
was disabled to conceal this baseline.
