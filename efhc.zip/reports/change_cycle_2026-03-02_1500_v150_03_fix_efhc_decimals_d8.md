# Cycle v150_03: EFHC jetton decimals d8

Дата: 2026-03-02

## Причина

Пользователь подтвердил: внешний EFHC jetton использует d8
(8 знаков после запятой). Внутриигровые балансы EFHC bonus/main
должны быть прямым аналогом внешнего EFHC jetton и тоже d8.

## Исправления

- config: EFHC_JETTON_DECIMALS default=8.
- watcher: fallback decimals=8 при конвертации raw->Decimal.

## Риски

Если decimals не d8, начисления/списания будут неверными
(ошибка масштаба). Исправление устраняет этот класс дефектов
для EFHC jetton.
