# Change Report — v168_81 / cycle 1283

## Cycle

1283 — panel card date display repair.

## HEAD

`EFHC_Bot_v168_80_cycle_1282_panel_countdown_source.zip`

## What changed

- Panels cards now visibly show panel ID;
- activation date is labelled and visible;
- deactivation date is labelled and visible;
- generated kWh remains visible;
- countdown remains visible;
- date fields are no longer hidden only in details;
- locale keys were added for active frontend locales;
- targeted guard was added.

## Files changed

- `frontend/src/pages/panels.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`
- `tests/architecture/test_panel_card_date_display.py`
- `docs/audits/FRONTEND_CYCLE_1283_PANEL_CARD_DATES_AUDIT_V168_81.md`
- `docs/cycles/WORK_CYCLES_1268-1320_FRONTEND_RECOVERY_IMPLEMENTATION_PLAN.md`
- `docs/frontend/FRONTEND_IMPLEMENTATION_PLAN.md`
- `docs/NORM/CHAT_TRANSCRIPT.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/NORM/TESTS_CATALOG.md`
- `docs/GENERAL/MASTER_DOCUMENT_INDEX.csv`
- `reports/REPORTS_INDEX.md`

## Not changed

- backend;
- database;
- migrations;
- payment logic;
- panel economy;
- bottom navigation;
- admin routes.

## Checks

See final chat report for executed commands and results.
