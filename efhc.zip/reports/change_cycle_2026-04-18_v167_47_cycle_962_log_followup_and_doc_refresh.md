# v167_47 — cycle 962 log follow-up and document refresh

## What was found
Fresh CI logs `65150008974` left a narrow post-verdict repair tail:
- `mypy` failed in `backend/app/routes/admin_routes.py`;
- `ruff` failed on the same file because `Mapping` still came from `typing`;
- `pytest` and frontend build were already green in the fresh log pack.

## What was changed
- switched `Mapping` import to `collections.abc`;
- normalized runtime-summary mapping rows via `dict(...)` before assigning to typed mappings;
- fixed the remaining line72 tail in the same function;
- refreshed AI/cycle/report/Q&A control memory to HEAD `v167_47`.

## Verification
- `mypy backend/app/routes/admin_routes.py`
- `ruff check backend/app/routes/admin_routes.py`
- `pytest -q tests/architecture/test_cycle_and_docs_canon.py tests/architecture/test_payment_intent_continuity_runtime_sync.py tests/architecture/test_max_line_length_72.py -q`
- `python -m compileall backend/app`

## Notes
This is a follow-up pass of cycle 962, not a new cycle. No 963+ planning was opened.
