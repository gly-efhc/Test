# EFHC Bot change report — v150_29

Дата (UTC): 2026-03-03

## Цель

1) Исключить `reports/`, `audits/` и реестр ошибок
   из repo-wide guard-тестов.
2) Зафиксировать канон сериализации d8: всегда `0.00000000`.

## Изменения

### Тесты

- `tests/architecture/test_no_tg_id_aliases_repo.py`
  - исключены `reports/`, `audit/`, `audits/`.
- `tests/architecture/test_no_banned_rank_terms.py`
  - исключены `reports/`, `audit/`, `audits/`;
  - добавлено исключение лог-артефактов по `_is_log_artifact()`.
- `tests/efhc_backend/unit/test_no_legacy_words.py`
  - исключены `reports/`, `audit/`, `audits/`;
  - исключён реестр ошибок;
  - исключены файлы `logs_*`.

### Сериализация d8

- `backend/app/schemas/common_schemas.py`
  - `d8_str()` теперь возвращает фиксированный формат d8
    через `format(d, 'f')`.
