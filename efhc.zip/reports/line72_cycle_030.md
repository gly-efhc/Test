# line72_cycle_030

Cycle goal: Panels SSOT implementation (step 1/10)

## What changed

Implemented Alembic migration (PostgreSQL-only) to align the existing
`panels` table with Panels SSOT storage invariants, without adding any new
routes/UI logic.

Key points:

* Adds `public_id` column as `TEXT UNIQUE` with NULL allowed until filled
  inside the service transaction.
* Adds `activated_at` column and backfills from `created_at` when present.
* Backfills `expires_at` for legacy rows as `activated_at + 180 days`.
* Adds DB invariant `expires_at > activated_at` using NOT VALID + VALIDATE.
* Adds index on `tg_id` (idempotent).

## Canon / locks respected

* No new endpoints, no aliases.
* No economic logic changes.
* Time filtering remains an application-layer responsibility (server_now_utc).

## Verification

* python -m compileall backend -q : PASS
* pytest -q : PASS
