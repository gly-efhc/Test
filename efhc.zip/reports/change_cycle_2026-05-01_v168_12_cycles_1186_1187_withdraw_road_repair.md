# CHANGE CYCLE v168_12 1186-1187

## Scope

This pass starts from v168_11.  It checks the 1186 tail and repairs the
1187 withdraw economic road.

## 1186 tail

The active backend keeps `/user/me/panels-summary` and does not keep the
old `/{global_id}/panels-summary` route.  Historical reports may still
mention the old route as past evidence.

## 1187 repair

Changed files:
- `backend/app/routes/withdraw_routes.py`;
- `backend/app/services/admin/admin_withdrawals_service.py`;
- `docs/NORM/API_CONTRACTS.md`;
- road-audit control docs and report index.

New files:
- `ops/routes/check_withdraw_road.py`;
- `tests/architecture/test_withdraw_road_guard.py`;
- `docs/audits/WITHDRAW_ECONOMIC_ROAD_REPAIR_1187.md`;
- `docs/cycles/WORK_CYCLES_1186-1187_DETAILED_PLAN.md`;
- `reports/generated/withdraw_road_1187.json`.

## Result

The withdraw road now has explicit evidence for auth self-source,
idempotency, hold, refund, admin approve, admin reject, outcome
event and API contract anchors.  This is not a global release-ready
verdict.
