# Change report v150_37

Источник: logs_59170631954.zip

## Исправления

1) efhc_admin.admin_action_log: снят FK на admin_whitelist
   - audit-лог не должен ломать денежные транзакции.

2) AdminLogger.write: запись лога через SAVEPOINT
   - begin_nested() для best-effort и без порчи транзакции.

## Файлы

- backend/app/models/admin_models.py
- backend/app/services/admin/admin_logging.py
