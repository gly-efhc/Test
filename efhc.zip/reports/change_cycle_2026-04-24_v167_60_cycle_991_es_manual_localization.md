# Change report — v167_60 — cycle 991

Date: 2026-04-24
Cycle: 991
Range: `983-1020+`
Block: full manual localization repair

## 1. What was found

The Spanish locale had broad English fallback tails and Russian-tail
fragments. Key parity existed, but value quality was not release-grade.

## 2. Where

Primary scope:

- `frontend/public/locale/es.json`

Control-layer scope:

- `docs/audits/*`
- `docs/cycles/*`
- `docs/AI/*`
- `docs/healer/*`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `reports/*`

## 3. Root cause

The Spanish bundle had been structurally aligned with English, but many
values were still inherited from English or from Russian admin/report
copy. The bundle needed a dedicated manual pass.

## 4. What was fixed

- Repaired Spanish fallback values manually.
- Removed Russian-tail fragments from Spanish admin/report/log copy.
- Added a Spanish value-quality guard.
- Updated cycle, audit, report, Healer and AI indexes.

## 5. Total cycles / errors

Active range: `983-1020+`.
This report closes one cycle: `991`.

## 6. Fixed in this pass

Closed cycle `991`.

## 7. Remaining

Remaining planned work starts with cycle `992`:

- Italian manual localization pass;
- Polish, Turkish, Danish, Hindi, Indonesian and Swahili passes;
- all-locale guards;
- admin/player screen matrices;
- backend/bot texts;
- FAQ path;
- notifications/system templates;
- hardcoded frontend strings;
- long-language layout risk review.

## 8. Files changed

Primary:

- `frontend/public/locale/es.json`
- `ops/i18n/audit_es_locale_value_quality.py`
- `docs/audits/LOCALIZATION_ES_MANUAL_REVIEW_991_2026_04_24.md`

Control-layer:

- `docs/audits/audits_index.json`
- `docs/cycles/WORK_CYCLES_901-1000.md`
- `docs/cycles/WORK_CYCLES_1001-1100.md`
- `docs/AI/AI_DOCS_INDEX.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/healer/HEALER_CASEBOOK.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
- `reports/REPORTS_INDEX.md`

## 9. Archive

Output archive:

`EFHC_Bot_v167_60_cycle_991_es_manual_localization.zip`

## 10. Evidence

Commands:

```bash
python3 -S ops/i18n/audit_es_locale_value_quality.py
```

Result:

```text
OK: checked Spanish locale value quality.
Accepted identical keys: 37
Accepted Cyrillic language names: 2
```

Additional local checks:

- locale JSON parse;
- RU/UK/DE/FR/ES guards;
- `docs/audits` contains no PDF/DOCX;
- migration filename check: only `0001_init.py`;
- release ZIP deflate compression check.

## Non-claims

GitHub CI is not claimed. Full multilingual release readiness is not
claimed yet.
