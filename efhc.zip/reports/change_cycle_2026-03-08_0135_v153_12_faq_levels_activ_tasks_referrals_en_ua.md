# Change cycle 2026-03-08 01:35 — v153_12

## Scope
- continue FAQ rollout after v153_11
- extend item-level FAQ translations for EN and UA
- keep RU catalog as content SSOT

## What changed
- added EN item-level FAQ translations for:
  - `10.1` Levels
  - `11.1` Activ
  - `11.2` Referral logic
  - `12.1` Tasks
  - `13.1` Referrals page
- added UA item-level FAQ translations for the same blocks
- kept existing fallback chain:
  - target lang
  - `en`
  - `ru`

## Verification
- `python ops/canon_guard.py` -> OK
- line72 on changed file -> OK
- local full frontend TypeScript proof is unavailable in container
  because frontend packages are missing

## Notes
- no fresh `logs_*.zip` on this archive
- full CI green is not claimed
