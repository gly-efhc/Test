# Change report — v169_48 cycle 1370 public i18n untranslated remediation

## Summary

Cycle 1370 updates public i18n translations for the most visible untranslated tail after v169_47 critical i18n repair.

## Code/data changed

- `frontend/public/locale/*.json` — 12 non-English locale bundles plus selected RU/UK cleanup where values were English-identical.
- `docs/frontend/PUBLIC_I18N_UNTRANSLATED_KEYS_REMEDIATION.md` — remediation map.
- `tests/architecture/test_public_i18n_untranslated_remediation.py` — guard for remediated key set and placeholders.

## Documents changed

- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1364-1375_PUBLIC_VISUAL_EXTENSION_PLAN.md`
- `docs/AI/AI_DOCS_INDEX.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/AI/ARCHIVE_FAST_MANIFEST.md`
- `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md`
- `reports/REPORTS_INDEX.md`
- `map_element.md`
- Operator Kernel route/classifier/resolver

## Not claimed

- Full translation completion for all public keys.
- FAQ wave-3 completion.
- GitHub CI green.
- Browser screenshots.
