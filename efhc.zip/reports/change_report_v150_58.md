# Change report v150_58

## Scope

- Add ENV configuration for Lotteries parameters (SSOT).
- Add documentation page docs/LOTTERIES.md (SSOT).

## Files changed

- backend/app/core/config_core.py
- .env.example
- .env.local.example
- .env.prod.example
- .env.ci.example
- .env.neon.example
- docs/LOTTERIES.md
- reports/change_report_v150_58.md

