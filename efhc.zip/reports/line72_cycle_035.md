# line72 cycle 035

Scope: SSOT UTC Now helper (intermediate cycle 5.1)

## Done

- Added a single SSOT UTC time helper `utcnow()` (tz-aware UTC).
- Switched Panels service time logic to use SSOT UTC now.
- Switched Panels routes to return `server_now_utc` from SSOT UTC now.
- Extended Panels list responses with `server_now_utc` (no new endpoints).
- Added lightweight tests guarding the SSOT UTC now contract.

## Files changed

- backend/app/lib/time.py
- backend/app/lib/__init__.py
- backend/app/services/panels_service.py
- backend/app/routes/panels_routes.py
- tests/test_utcnow_ssot.py
- reports/line72_cycle_035.md

## Checks

- python -m compileall backend -q
- pytest -q
