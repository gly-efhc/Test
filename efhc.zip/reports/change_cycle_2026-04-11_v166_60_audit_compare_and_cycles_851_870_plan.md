# EFHC Bot — change report
## 2026-04-11 — v166_60 — audit compare and cycles 851-870 planning

### What changed
- read the new expanded release-readiness audit and compared its main
  claims against the current HEAD code.
- confirmed in code that the audit is directionally correct about three
  major release themes: withdraw completion semantics, hub/browser-shop
  dependence on external handoff config, and helper/draft admin
  surfaces.
- recorded the user correction that withdraw proof must be modeled
  around wallet-send confirmation in Tonkeeper / MyTonWallet / similar
  wallets, because the transaction then goes to bot-embedded requisites
  automatically.
- created the next planned block `851-870` as an audit-driven release
  hardening program.
- prepared a 10-question audit iteration that must be answered before
  safe execution of the new block.

### Code-level compare notes
- withdraw audit claim is materially confirmed by code: admin approval
  still accepts optional `tx_hash` (`tx_hash: str | None = None`) in
  `backend/app/services/admin/admin_withdrawals_service.py`.
- hub/browser-shop conditionality is materially confirmed by code:
  `backend/app/routes/hub_routes.py` still depends on
  `HUB_EFHC_BUY_URL` and returns 503 when the external buy-flow is not
  connected.
- helper/draft audit claim is materially confirmed by code:
  `backend/app/routes/admin_sale_packages_routes.py` explicitly says the
  surface is an internal draft contour and blocks write-actions.

### Honesty boundary
- this pass does not start executing cycles 851-870 yet.
- this pass creates the planned block and the clarification iteration.
