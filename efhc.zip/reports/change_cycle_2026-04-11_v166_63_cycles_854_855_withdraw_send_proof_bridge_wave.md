# EFHC Bot — change report
## 2026-04-11 — v166_63 — cycles 854-855 withdraw send-proof bridge wave

### What changed
- started the new implementation block with the withdraw action-chain.
- extended admin withdraw approve payload to accept wallet-send proof
  metadata: `payout_ref`, `wallet_send_confirmed`, `wallet_provider`
  and `sender_wallet_address`.
- updated the admin withdrawals frontend so the TonConnect wallet path
  sends explicit wallet-send proof metadata after `sendTransaction()`.
- preserved `tx_hash` as optional secondary technical evidence.

### Honesty boundary
- this pass strengthens the withdraw proof bridge and audit trail, but it
  does not yet claim full completion of the larger 851-870 hardening
  block.
