# change report — v166_31 — cycles 835-836

## Done
- Regenerated SSOT-derived OpenAPI snapshot.
- Regenerated frontend seam types.
- Added a hard limit of 5 active pending intents per global_id/purpose.
- Added reproducible audit script for freeze + blitz limit baseline.

## Files
- backend/openapi/openapi.json
- backend/openapi/openapi_manifest.json
- frontend/src/lib/api/generated/adminSeams.ts
- backend/app/services/payment_intents_service.py
- ops/routes/audit_blitz_limits_and_openapi_freeze.py
- docs/audits/OPENAPI_FREEZE_AND_BLITZ_LIMITS_835_836_2026_04_10.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_801-900.md
- reports/REPORTS_INDEX.md
