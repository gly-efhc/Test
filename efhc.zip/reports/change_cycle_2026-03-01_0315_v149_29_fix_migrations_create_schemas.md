# EFHC Bot — Change Cycle Report

**Cycle:** 2026-03-01_0315 (UTC)

**Version:** EFHC_Bot_v149_29_fix_migrations_create_schemas

## What failed (from GitHub Actions logs)
- **Alembic upgrade head** failed with: `psycopg.errors.InvalidSchemaName: schema "efhc_lotteries" does not exist` while executing `CREATE TABLE efhc_lotteries.lotteries (...)`.

## Where
- GitHub Actions step: `Alembic upgrade head (Postgres-only)`
- Trace points to migration `backend/migrations/versions/0001_init.py` calling `Base.metadata.create_all(bind=conn)`.
- Root cause is environmental DB state (fresh Postgres) + missing schema creation for non-core schemas before `create_all`.

## Root cause
`backend/migrations/env.py` created only `DB_SCHEMA_CORE` (default `efhc_core`) before running migrations.
However, ORM models include tables with table-level schema `efhc_lotteries` (and potentially `efhc_admin`).
On a clean CI database these schemas do not exist, so `Base.metadata.create_all` fails on the first table in a missing schema.

## Fix
- Updated `backend/migrations/env.py` (online mode): create all required schemas before setting search_path and running migrations:
  - `DB_SCHEMA_CORE` (default `efhc_core`)
  - `DB_SCHEMA_ADMIN` (default `efhc_admin`)
  - `DB_SCHEMA_LOTTERIES` (default `efhc_lotteries`)

This keeps schema definitions at **table level** (no `schema=` in `sa.Column`) and makes migrations deterministic on clean CI Postgres.

## Files changed
- `backend/migrations/env.py`

## Notes / invariants
- This is a **real CI failure** (confirmed by `logs_58929493282.zip`).
- Local missing modules in chat runtime are **not** recorded as defects.
