# Change cycle 2026-03-06 10:15 / v152_20

## Что исправлено

- Убран обход канона двух схем в `orders_service.py`: удалена идея
  `DB_SCHEMA_SHOP` / `efhc_shop`.
- В `admin_referral_service.py`, `admin_stats_service.py` и
  `admin_users_service.py` реферальная схема принудительно возвращена
  к `SCHEMA_CORE`; обход `DB_SCHEMA_REFERRAL` / `efhc_ref*` удалён.
- В `tasks_models.py` исправлен вводящий в заблуждение docstring:
  задачи живут только в `efhc_core`, без `DB_SCHEMA_TASKS` /
  `efhc_tasks`.
- В `docs/EFHC_CANON.md` зафиксирован запрет на третьи схемы и обход
  `canon_schema()`.

## Затронутые файлы

- `backend/app/services/orders_service.py`
- `backend/app/services/admin/admin_referral_service.py`
- `backend/app/services/admin/admin_stats_service.py`
- `backend/app/services/admin/admin_users_service.py`
- `backend/app/models/tasks_models.py`
- `docs/EFHC_CANON.md`
