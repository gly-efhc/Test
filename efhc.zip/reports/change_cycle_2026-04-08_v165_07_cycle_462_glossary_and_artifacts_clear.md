# Cycle 462

- Added `artifacts/` to the terms glossary as the archive basket for temporary retention of deleted objects.
- Cleared the current `artifacts/` basket by user request and left only an empty `artifacts/` directory.
