# Change Report — v149_45

SSOT base: EFHC_Bot_v149_44_fix_routes_66_70_referral_codes_shop_facade.zip  
Evidence logs: logs_58942307881.zip (CI Alembic)

## What broke
- CI Alembic upgrade head failed with `TypeError: ... got 'schema'` due to `Index(..., schema=CORE_SCHEMA)` in ORM model.

## Fixes
1) **ORM: remove invalid `schema=` from Index**
- File: backend/app/models/bank_models.py
- Change: removed `schema=CORE_SCHEMA` from Index declarations (schema is defined at table level via `__table_args__`).

2) **sync: ensure fallback enqueue is durable**
- File: backend/app/routes/sync_routes.py
- Change: added `await db.commit()` in `_enqueue_resync_energy()` after INSERT into `scheduler_task_log`.

3) **DB: add missing table required by sync fallback**
- File added: backend/app/models/scheduler_models.py
- New ORM model: `SchedulerTaskLog` → efhc_core.scheduler_task_log

4) **SSOT/Migrations/CI sanity**
- docs/ssot_pack/SSOT_TABLES_ORM.csv: added efhc_core.scheduler_task_log
- docs/ssot_pack/SSOT_TABLES_MIGRATIONS.csv: added efhc_core.scheduler_task_log (0001)
- backend/migrations/versions/0001_init.py: expected_tables updated to 34 (sync with SSOT_TABLES_ORM.csv)
- ops/ci_verify_db_objects.py: REQUIRED includes efhc_core.scheduler_task_log

5) **Routes SSOT (71–75)**
- docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv: filled read/write tables + evidence for:
  - /skins/* (catalog/my/buy/activate)
  - /sync/user/{tg_id}

6) **Errors registry**
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md: added entry for `Index(..., schema=...)` CI class error (logs_58942307881.zip).

## Notes
- Cache cleaned before packaging; zip-to-zip guard respected.
