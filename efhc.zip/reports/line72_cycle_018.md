# line72 cycle 018

Goal

- Add global EFHC header (sticky) across all tabs.
- Show Main/Bonus/Total balances with EFHC coin icon.
- Keep canon: tg_id only, no forbidden substrings.

Files changed

1) frontend/src/components/GlobalHeader.tsx

- New sticky header component.
- Shows avatar, username, LVL N, balances and actions.
- Actions: + -> /exchange, Shop -> /shop.

2) frontend/src/components/Layout.tsx

- Integrate GlobalHeader above all pages.
- Use snapshot profile data for username and balances.
- Compute level via getUserLevel(total_generated_kwh).

3) frontend/src/pages/_app.tsx

- Pass snapshot to Layout.

4) frontend/src/lib/format.ts

- Add formatFixedDown for string-safe fixed decimals (DOWN).
- Add sumScaledDown for total (BigInt scaled).

Exceptions

- None.
