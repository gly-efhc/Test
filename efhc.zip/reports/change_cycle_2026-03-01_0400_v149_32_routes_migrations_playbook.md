# Change Report v149_32 — Playbook + JSON plan

## Added
- docs/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json
- docs/ROUTES_TABLES_MIGRATIONS_PLAYBOOK.md

## Goal
Provide a single canonical instruction for repairing routes with
compatibility chain: code → routes → tables → migrations.
