# Change report v150_59

Дата: 2026-03-03 (Europe/Uzhgorod)

## Контекст
Вход: EFHC_Bot_v150_58_lotteries_env_docs.zip (HEAD ver-ZIP в чате).

CI logs_*.zip для этого HEAD в чат не загружены, поэтому ниже
зафиксированы только изменения по коду/SSOT в ZIP и локальные
архитектурные проверки (line72).

## Что исправлено / добавлено

### Backend (Lotteries)
1) SSOT ENV применён в автосоздании draw:
- создаются 2 активных draw: EFHC (200) и VIP NFT (1000)
  по значениям Settings LOTTERIES_* (bootstrap при первом /api/lotteries).
2) Покупка билетов:
- enforced max tickets per user per draw (лимит 10) ДО списаний.
3) Выплата приза EFHC:
- сумма берётся из LOTTERIES_EFHC_PRIZE_BONUS_D8 (d8), а не "100".
4) Новый endpoint winners:
- GET /api/lotteries/winners/latest (последний winner для EFHC и VIP).

### Backend (Bot handler)
- /lotteries handler корректно распаковывает (items, next_cursor)
  и больше не использует несуществующие поля ends_at/ticket_price_efhc.

### Frontend
- Страница Lotteries переработана под новый SSOT:
  - 2 текущих draw (EFHC + VIP NFT) с прогрессом и лимитом 10
  - My tickets для каждого draw
  - Winners (latest) через новый endpoint.

### Docs / SSOT pack
- SSOT_ROUTES.csv / SSOT_ROUTES_NUMBERED.csv:
  - актуализированы line для lotteries_routes.py
  - добавлен /api/lotteries/winners/latest
- SSOT_ROUTE_TABLE_MAP.csv и SSOT_ROUTES_TABLES_MIGRATIONS.csv:
  - добавлена строка маппинга для winners/latest
- Терминология: заменены точечные упоминания "lottery" → "Lotteries"
  в docs/TERMS_GLOSSARY.md и ops/canon_rules.yaml.

## Локальные проверки (не CI)
- pytest tests/architecture/test_max_line_length_72.py: PASS

## Риски / что требует CI logs_*.zip
- Любые утверждения "прошло/упало" по CI невозможны без logs_*.zip.
  После прогона CI нужно сверить новый лог и закрыть Task A.
