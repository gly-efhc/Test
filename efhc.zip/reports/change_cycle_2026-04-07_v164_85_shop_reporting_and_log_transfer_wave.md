# v164_85 — shop reporting and old GitHub CI log transfer wave

## What changed
- audited residual shop read/reporting legacy assumptions
- moved admin_list_orders from legacy item_id/shop_items reading to canonical shop_orders + extra
- transferred chronic old GitHub CI log errors into Healer and prepared deletion batch docs

## Proof
- local proof should be re-run in next pass or confirmed in GitHub CI
