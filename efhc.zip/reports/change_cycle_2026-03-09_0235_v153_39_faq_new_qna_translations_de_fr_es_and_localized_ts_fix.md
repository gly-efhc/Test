# v153_39 — FAQ new Q&A translations for DE/FR/ES + localized.ts fix

## Done
- added DE item-level translations for new FAQ questions
- added FR item-level translations for new FAQ questions
- added ES item-level translations for new FAQ questions
- covered top bar, panel extras, Energy page, Wallet extras,
  referral bonuses and referral levels 0-5, Activ status,
  Lotteries, Ads, extra purchase/payment questions, extra
  progress questions, 12 progress levels, FAQ usage and
  Profile/Settings helper questions
- fixed syntax structure in localized.ts so targeted TypeScript
  compile passes again

## Checks
- python ops/canon_guard.py -> OK
- changed-file line72 -> OK
- targeted TypeScript compile FAQ data-layer -> OK
