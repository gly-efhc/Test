# v148_53 — Fix Alembic safe.table_exists for multi-schema

## Симптом (CI)
Sanity after alembic: required tables missing (efhc_core.users, efhc_core.withdraw_requests, efhc_admin.efhc_sale_packages).

## Root cause
backend/migrations/lib/safe.py использовал inspector.has_table(), что давало
нестабильную проверку в multi-schema окружении с активным SET search_path.

## Fix
Заменил table_exists() на проверку через SELECT to_regclass('schema.table').

## Verification
Ожидается: ensure_table_with_basics создаёт таблицы в правильных схемах;
sanity-check после alembic становится зелёным.
