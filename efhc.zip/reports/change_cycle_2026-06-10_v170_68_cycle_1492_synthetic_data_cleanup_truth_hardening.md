# Change report — v170.68 / cycle 1492

## Cycle

`1492 — Synthetic Data Cleanup / Truth Hardening`

## Summary

Runtime `/admin` no longer renders a synthetic-looking banking simulator
series from a single overview snapshot. It now renders a read-only
observability dashboard backed by `/admin/observability/timeseries` with
`data_kind=real_timeseries` and `synthetic=false`.

## Backend clarity fixes

- `_route_for_reason` now matches referral reasons precisely.
- `efhc_transfer_amount` is labelled as `EFHC gross turnover`.
- Added `efhc_credit_amount` and `efhc_debit_amount` metrics.

## Safety

No write actions, idempotency creation, money-changing services, raw
payload, debug JSON, secrets, Grafana runtime code or sandbox runtime code
were added.
