# line72 cycle 012

Goal

- Make EFHC coin icon visible wherever EFHC balances are shown
  (MAIN / BONUS), while keeping line72 guard.

Changes

- Admin users page: add EFHC coin icon next to Main/Bonus/Total EFHC
  balance values.

Line72

- No exceptions added.

Notes

- Uses existing PNG-backed EfhcCoinIcon with canonical assets
  (56/64/96/128/256).
