# v167_40 — document layer corrective pass

## What changed

This pass corrects document-layer drift caused by placing temporary or operational
module-status documents inside `docs/SSOT/*`.

## Confirmed drift

The following documents were operational or transition-status documents rather
than stable canonical SSOT:

- `docs/SSOT/EFHC_DEPOSITS_RELEASE_BOUNDARY_SSOT.md`
- `docs/SSOT/EFHC_DEPOSITS_PRODUCTION_GRADE_SSOT.md`
- `docs/SSOT/SALE_PACKAGES_FINAL_STATUS_SSOT.md`

## Corrective action

These documents were moved out of `docs/SSOT/*` into `docs/NORM/*`:

- `docs/NORM/EFHC_DEPOSITS_RELEASE_BOUNDARY_STATUS.md`
- `docs/NORM/EFHC_DEPOSITS_PRODUCTION_GRADE_STATUS.md`
- `docs/NORM/SALE_PACKAGES_FINAL_STATUS.md`

The AI-layer was updated to forbid creating temporary release-status documents
in `docs/SSOT/*`.

## Audit notes

Additional document-layer drift still visible after this pass and requiring
user-confirmed follow-up scope:

1. `docs/AI/AI_DOCS_INDEX.md` still contains stale historical priority notes and
   duplicate sections that should be cleaned in a separate AI-doc audit pass.
2. `docs/cycles/WORK_CYCLES.md` upper control block is outdated and does not
   reflect the real HEAD and current active cycle status.
3. Some prior `reports/change_cycle_*` files still mention the old SSOT paths as
   historical facts. These references were not rewritten to avoid falsifying
   historical reports.

## No-history-rewrite rule

Historical cycle reports were not rewritten. The corrective pass changes only
current active docs, indexes, references and runtime guards.
