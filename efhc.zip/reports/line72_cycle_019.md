# line72 cycle 019

Goal: simplify global header balances.

Changes:
- Global header now shows only Total (main + bonus).
- Main/Bonus rows removed from header UI.

Line 72:
- No exceptions added.

Notes:
- Total formatting remains fixed 8 decimals, DOWN rounding.
- No new routes, aliases, or banned substrings introduced.
