# Change cycle v154_10

- FAQ item-level adaptation from Russian source added for de/fr/es.
- Fixed Spanish placeholder collisions with TODO-style guard.
- Fixed one line72 violation in localized.ts.
- Local checks passed: line72, banned rank terms, legacy words, placeholders.
