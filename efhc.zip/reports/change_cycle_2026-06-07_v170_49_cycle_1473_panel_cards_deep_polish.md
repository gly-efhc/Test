# Change report — v170.49 cycle 1473 Panel Cards Deep Polish

## Summary

Cycle 1473 polishes runtime panel cards and hardens sandbox preview
math.

## Files added

- `docs/NORM/PANEL_CARDS_DEEP_POLISH.md`
- `docs/NORM/PANEL_CARDS_DEEP_POLISH_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1473_PANEL_CARDS_DEEP_POLISH.md`
- `reports/generated/panel_cards_deep_polish_v170_49.json`
- `tests/architecture/test_panel_cards_deep_polish.py`

## Runtime UI changes

- `PanelsPortfolioRuntime` gained panel-card micro states.
- Cards now expose `data-panel-card-polish="1473"`.
- Cards now have accessibility labels.
- Dates are displayed as formatted UTC minutes.
- Active cards show countdown + lifecycle progress.
- Archived cards show one lifecycle progress, not duplicate progress.

## Sandbox formula changes

- Static inconsistent generation rates removed.
- Preview generation rates are derived from generated kWh and period
  seconds.

## Not changed

- EFHC economy.
- Backend routes.
- DB migrations.
- OpenAPI.
- Dependencies.
- Lock files.
- CI workflows.
- Write/money flows.
