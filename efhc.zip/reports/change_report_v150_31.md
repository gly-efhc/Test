EFHC Bot change report

Cycle: v150_31
Logs: logs_59159509480.zip
Date: 2026-03-03

Changes

- Fixed indentation in concurrency withdraw test helper function.
  File: tests/test_concurrency_withdraw_double.py
