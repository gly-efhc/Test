# EFHC Bot v167_96 — cycles 1141-1145

Date: 2026-04-27
Archive base: v167_95
Result archive: v167_96
Status: done

## Scope

- Re-read HEAD prompt-layer documents.
- Import fresh GitHub logs from `logs_66340952440.zip`.
- Repair only confirmed release blockers.
- Keep Песочница as a separate donor source.

## Confirmed blockers from logs

1. `pytest` failed on `tests/architecture/test_max_line_length_72.py`.
2. `bandit` failed on `/ads/slot` because the route used raw SQL text.

## Applied changes

- Wrapped exact long lines in `backend/app/services/tasks_service.py`.
- Shortened long active strings in
  `ops/i18n/identical_to_english_allowlist.json`.
- Shortened active description/exclusion strings in
  `ops/i18n/forbidden_release_scope_exclusions.json`.
- Replaced `/ads/slot` raw SQL with ORM `select(Task...)`.
- Synced AI / cycle / report / Q&A / Healer / glossary docs.

## Boundary

- No migration edits.
- No schema rename.
- No mass removal of technical `reward*` names.
- No claim of full green CI beyond the supplied logs.
