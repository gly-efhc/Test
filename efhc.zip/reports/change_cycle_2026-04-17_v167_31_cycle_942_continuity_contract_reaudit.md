# EFHC Bot — change report
## Version
- v167_31

## Cycle
- 942 — continuity contract re-audit

## Scope
- Clean re-audit cycle for continuity seam 937-941.
- No new functional expansion.
- Only incidental fix allowed if it surfaced directly during the audit.

## What was re-audited
- Telegram -> Hub -> Browser-Shop -> Web-Profile -> outcome
- wallet readiness truth
- active intent / resume contract
- terminal / non-terminal clarity
- return_path / canonical_center semantics
- ProfileModal vs Web-Profile role split

## Findings
1. Wallet readiness now behaves as backend-first truth and no longer collapses deny states into one wallet redirect path.
2. Active intent / resume is guarded backend-first; duplicate create flow is blocked and redirected into resume semantics.
3. Terminal vs non-terminal payment guidance is now coherent through `product_state`, `next_action` and continuity wording.
4. `return_path` and `canonical_center` now read as one continuity pair instead of separate local UI guesses.
5. ProfileModal is no longer positioned as a second account center; Web-Profile remains the canonical account center.
6. One incidental player-facing language tail still existed in the audited contour: latest withdraw labels in `ProfileModal` were still Russian.

## Incidental fix applied
- `ProfileModal` latest withdraw labels were returned to English-first:
  - pending
  - approved
  - paid
  - rejected
  - canceled

## Guard reinforcement
- Extended `tests/architecture/test_payment_intent_continuity_runtime_sync.py`
  to freeze the confirmed role-split and withdraw-label canon.

## Honest verdict of cycle 942
- Continuity seam 937-941 is stronger and more coherent than at cycle 930.
- The core chain now behaves as one release-core contour:
  Telegram -> Hub -> Browser-Shop -> Web-Profile -> outcome.
- This is still a continuity re-audit verdict, not a claim of green GitHub CI
  and not a blanket full-release declaration.

## Files touched
- frontend/src/components/ProfileModal.tsx
- tests/architecture/test_payment_intent_continuity_runtime_sync.py
- docs/AI/AI_DOCS_INDEX.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_901-1000.md
- docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md
- reports/REPORTS_INDEX.md
- reports/change_cycle_2026-04-17_v167_31_cycle_942_continuity_contract_reaudit.md
