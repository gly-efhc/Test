# line72 cycle 010

Date: 2026-02-23

## Summary
- Reduced max-line-length (>72) violations by fixing 5 frontend files.
- No SSOT/economy changes.
- No new identifiers/aliases; only existing tg_id canon preserved.
- No new banned substrings introduced.

## Files changed (5)
1) frontend/src/components/ui/EfhcCard.tsx
- Split props type definition across multiple lines.

2) frontend/src/components/ui/EfhcStatus.tsx
- Wrapped long if-conditions into multi-line blocks.
- Replaced long className template with an array join.

3) frontend/src/components/icons/EfhcCoin.tsx
- Broke long SVG element attribute lines into multi-line JSX.

4) frontend/src/hooks/useCursorList.ts
- Split generic response type and apiRequest call into multi-line form.

5) frontend/src/lib/i18n.ts
- Split Lang union type and SUPPORTED_LANGS list.
- Multi-line fetch init options.

## Exclusions
- None added in this cycle.

## Checks
- python -m compileall backend -q: PASS
- pytest -q: FAIL only on test_max_line_length_72
  - Remaining: 16 lines >72 across 4 files.
