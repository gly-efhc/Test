# Change report v150_54

## Fixed
- migrations/versions/0001_init.py: moved Base.metadata.create_all to correct
  scope so it executes; kept checkfirst=True.

## Evidence
- logs_59203693346: 0001 sanity failed; missing objects; create_all unreachable.
