# Change report — v169_51 — cycles 1371/1372 FAQ semantic approval gate

## Summary

Performed a corrective FAQ semantic approval gate before continuing public/TMA
cycles.

## Changes

- Repaired FAQ item 48 non-RU semantic drift.
- Repaired FAQ item 51 non-RU semantic drift.
- Regenerated `frontend/src/data/faq/catalogs.ts` from FAQ SSOT.
- Added FAQ approval manifest/register entry `FAQ-APPROVAL-0013`.
- Updated FAQ SSOT and FAQ reading policy with Q/A-first semantic hierarchy.
- Added semantic gate audit, generated JSON report and architecture guard.

## Non-claims

- No GitHub CI green claim.
- No full human linguistic certification.
- No browser screenshot claim.
- No unrelated FAQ rewrite approval.
