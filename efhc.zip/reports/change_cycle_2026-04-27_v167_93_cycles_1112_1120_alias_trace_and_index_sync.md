# CHANGE REPORT v167_93 — cycles 1112-1120

Date: 2026-04-27

Closed cycles:
- 1112 — 1040-1120 drift/index/reports alignment pass.
- 1113 — Песочница usage-map read as separate donor source.
- 1114 — tasks route compatibility helper for bonus field reading.
- 1115 — ad bonus placeholder cleanup in active locale bundles.
- 1116 — frontend copy-map public reward alias removal.
- 1117 — admin tasks local validator naming cleanup.
- 1118 — tasks service SQL lock statement repair.
- 1119 — archive hygiene cleanup of generated caches.
- 1120 — control-layer report and cycle index sync.

What changed:
- Updated the active 1101-1200 cycle file so its header no longer stops at
  cycle 1098 and now reflects the factual `1112-1120` completion.
- Used `Песочница_full.zip` only as a separate donor/reference source.
  The EFHC HEAD workdir was not mixed with the Песочница archive.
- Kept technical DB/runtime `reward_bonus_efhc` and `reward_efhc`
  compatibility where removal is still unsafe.
- Removed remaining public placeholder `{{reward}}` in `tasks.ad_bonus_ok`
  across all 13 active locale bundles and synchronized the frontend code to
  use `{{bonus}}`.
- Removed frontend `taskReward` public copy alias and replaced the active
  copy-map phrase with `Task bonus`.
- Added a bounded tasks route helper that exposes only `bonus_efhc` while
  retaining a legacy DB-key fallback internally.
- Repaired a duplicated SQL `UPDATE efhc_core.task_complete_lock` line in
  `tasks_service.py`; this was a runtime SQL defect, not a migration change.
- Cleaned generated cache directories from the release worktree before ZIP
  assembly.

Compatibility boundary:
- No migration files were changed.
- No route paths were renamed.
- No admin panel route was removed.
- No i18n locale was disabled.
- Technical `reward*` DB/service names remain under the approved transition
  boundary where compatibility still depends on them.

Local confirmations:
- `unzip -t` on the EFHC HEAD archive passed before work.
- `Песочница_full.zip` index/docs were read separately.
- `python3 -S -m py_compile` passed for the changed backend Python files.
- Locale placeholder scan confirms no `{{reward}}` remains in active frontend
  locale bundles.
- Frontend copy scan confirms no `taskReward`, `Task reward` or
  `rewards_social` remains in the active copy helper files.

Important boundary:
- GitHub CI was not run by the assistant.
- Full frontend build was not claimed.
- Historical reports were not rewritten.
