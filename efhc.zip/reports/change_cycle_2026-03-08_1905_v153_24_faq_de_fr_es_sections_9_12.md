# Change cycle v153_24 — FAQ de/fr/es sections 9-12

Date: 2026-03-08

## Scope
- Continue item-level localization of the new 12-section user FAQ.
- Cover sections 9-12 for de/fr/es.

## What changed
- Added de item-level translations for sections 9-12.
- Added fr item-level translations for sections 9-12.
- Added es item-level translations for sections 9-12.
- Kept fallback order: active language -> en -> ru.

## Sections covered
- 9 Popолнение и покупки / Top-ups and purchases
- 10 Уровни и ранг / Levels and rank
- 11 Частые ситуации / Frequent situations
- 12 Помощь по FAQ / FAQ help

## Checks
- canon_guard: OK
- changed-file line72: OK

## Notes
- Full green CI is not claimed without a fresh logs_*.zip for this new ZIP.
