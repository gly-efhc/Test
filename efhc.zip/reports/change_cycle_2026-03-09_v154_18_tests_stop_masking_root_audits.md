# Change Report — v154_18 — tests stop masking root audits

## Что изменено
- Из guard-тестов убрано общее исключение директории `audits`.
- Вместо этого добавлено точечное исключение только для `docs/audits`.
- Это не позволяет тестам молча игнорировать возможное повторное
  появление корневой папки `audits/` в архиве.

## Изменённые файлы
- tests/architecture/test_no_banned_rank_terms.py
- tests/architecture/test_no_tg_id_aliases_repo.py
- tests/efhc_backend/unit/test_no_legacy_words.py
