# Change cycle 2026-02-28_1135 — v148_54_fix_0001_schema_args

## Stop-crane (logs_58885071692.zip)
Sanity DB objects after alembic failed: required tables missing:
- efhc_core.users
- efhc_core.withdraw_requests
- efhc_admin.efhc_sale_packages

Alembic reported Running upgrade -> 0001, so migration ran but objects were not created
in expected schemas.

## Root cause
`backend/migrations/versions/0001_init.py` использует `ensure_table_with_basics(...)`
без явного `schema=...`. В multi-schema окружении это приводит к созданию таблиц
в неверной схеме (часто `public`) или к пропуску создания из-за search_path.

## Fix
В `0001_init.py` всем вызовам `ensure_table_with_basics` добавлен явный `schema`:
- core таблицы -> `schema="efhc_core"`
- admin таблицы -> `schema="efhc_admin"`

Это делает миграцию детерминированной и согласованной с тестами/CI sanity-check.

## Files changed
- backend/migrations/versions/0001_init.py

## Verification plan
CI:
1) Alembic upgrade head PASS
2) Sanity DB objects after alembic PASS (to_regclass != NULL)
3) pytest -q proceeds past DB setup
