# Change report — v169_39 — cycle 1361 Public UI QA preparation

Date: 2026-06-01
Archive target: `EFHC_Bot_v169_39_public_ui_qa_preparation_complete.zip`

## Goal

Complete cycle 1361 as Public UI screenshot QA preparation, while also closing
the user's additional residual audit findings after the v169_37/v169_38 audit
fix implementation.

## Code changes

- Added `common.session_expired` and `common.load_error` to all 13 locale JSON files.
- Upgraded E2E interaction smoke tests:
  - Exchange now fills the amount input, clicks convert and asserts `POST /api/exchange/convert`;
  - HUB now clicks the EFHC top-up action and asserts `POST /api/hub/efhc-handoff`;
  - Withdraw now fills the amount input, submits and asserts `POST /api/withdraw/request`.
- Expanded E2E public smoke scope to 14 routes.
- Expanded E2E admin smoke scope to 17 routes.
- Added common E2E Telegram/browser fallback mocks.
- Updated `offline.html` with a multilingual fallback line.

## Documentation changes

- `docs/frontend/PUBLIC_UI_SCREENSHOT_QA_PREPARATION.md` now includes `/withdraw`, `/ads`, `/referrals/active` and `/referrals/inactive`.
- `docs/AI/AI_DOCS_INDEX.md`, `docs/AI/TOPIC_READING_ROUTES.md`, `docs/AI/ARCHIVE_FAST_MANIFEST.md` and `docs/AI/ARCHIVE_SYNAPTIC_LINKS.md` now point to v169_39 public QA readiness.
- `docs/cycles/WORK_CYCLES.md` and `docs/cycles/WORK_CYCLES_1351-1375_ADMIN_PUBLIC_EXTENSION_PLAN.md` mark 1361 as done and 1362 as next.
- `map_element.md` now records the residual-audit-to-sandbox mapping.

## Guards

Added or updated:

- `tests/architecture/test_public_ui_qa_preparation_complete.py`;
- `tests/architecture/test_frontend_e2e_scope_guard.py`;
- `tests/architecture/test_public_pages_error_state_guard.py`;
- selected existing cycle/admin/public guards updated to v169_39 state.

## Non-claims

This local pass does not claim GitHub CI green, real Playwright browser verdict,
frontend build verdict or captured screenshot verdict.
