# Change report v151_06

- Fix CI pytest failure: migrations smoke used wrong DATABASE_URL.
  tests/test_migrations_upgrade_head.py now temporarily overrides
  DATABASE_URL/SYNC/ASYNC/PSYCOPG_URL during alembic upgrade to
  point to the newly created smoke database.
