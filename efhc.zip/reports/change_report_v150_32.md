# Change report v150_32

Основание: logs_59160577808.zip.

## Исправления

1) tests/test_concurrency_exchange_all.py
- Починен флейк по available_kwh=0: зеркальная колонка
  users.available_kwh переведена на numeric без typmod.

2) backend/app/services/withdraw_service.py
- Добавлен _admin_approve_idem_hit(): идемпотентность approve
  читается из efhc_admin.admin_action_log.

3) backend/app/services/watcher_service.py
- Для deposit_efhc подтверждения выбран хук credit_user_from_bank:
  поддержаны monkeypatch как для watcher_service, так и wallets_service.

4) backend/app/services/wallets_service.py
- Реэкспортирован STATUS_CREDITED для совместимости тестов.

5) backend/migrations/lib/safe.py
- Приведены строки к канону line72 (без изменения логики).
