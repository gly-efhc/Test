# v149_74 fix: Alembic 0001 autocommit InvalidRequestError

CI logs showed Alembic upgrade crashed inside 0001_init.py when
trying to set isolation_level=AUTOCOMMIT on an already started
transaction (SQLAlchemy InvalidRequestError). The pipe to tee hid
this failure, so later sanity saw missing tables.

Changes
- backend/migrations/versions/0001_init.py:
  - remove conn.execution_options(isolation_level="AUTOCOMMIT")
  - use conn.exec_driver_sql("CREATE SCHEMA IF NOT EXISTS ...")
- backend/migrations/env.py:
  - create schemas with connection.execute(...)
  - call connection.commit() before running migrations

Notes
- Recommended CI YAML improvement: add `set -o pipefail` before
  `python -m alembic ... | tee ...` so Alembic failures stop job.
