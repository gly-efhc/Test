# Change cycle — v169.72 / cycle 1390 filename hygiene repair

## Goal

Repair the forbidden cycle suffix in `docs/testing/` and make the filename
policy explicit enough to prevent repeat regression.

## Changed

- `docs/testing/TEST_CONSOLIDATION_MAPPING_1390.md` became
  `docs/testing/TEST_CONSOLIDATION_MAPPING.md`.
- References were updated.
- Filename policy now states hard limits: 120 UTF-8 bytes per component and
  220 UTF-8 bytes per archive-relative path.
- `docs/testing/` is explicitly not a cycle-label exception layer.
- Filename hygiene guard now has an explicit `docs/testing/` filename check.

## Not changed

- No unrelated tests were removed, archived, skipped, xfailed or excluded.
- No CI workflow was changed.
- No project runtime code was changed.

## Status

Repair completed. Continue with cycle 1391 after fresh logs or remaining
known domain failures.
