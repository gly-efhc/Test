# EFHC Bot v166_71_72 — cycles 861/862 money-path truth and web-profile foundation

## What changed
- Payment intents now expose `flow_truth` with lifecycle stage, terminal marker, next step, watcher evidence and order-level error context.
- Browser-shop bootstrap/profile can preload the active payment state so the storefront survives tab close/reopen without falling back to a raw `PENDING` badge.
- Browser-shop now shows honest state guidance: wait for network, wait for manual review, return to Telegram, or create a new intent.
- Web-profile now exposes the active payment path as the first canonical user-cockpit block.

## Validation
- `python -m py_compile backend/app/routes/hub_routes.py backend/app/routes/shopfront_routes.py backend/app/services/payment_intents_service.py backend/app/schemas/payment_intents_schemas.py backend/app/schemas/hub_schemas.py` passed.
- `npm --prefix frontend run -s tsc -- --noEmit --pretty false` passed.
- `pytest -q tests/architecture/test_cycle_and_docs_canon.py tests/architecture/test_route_inventory_freeze_sync.py tests/architecture/test_openapi_startup_consistency.py -q` planned after sync.
- No fresh GitHub CI log was provided, so green CI is not claimed.
