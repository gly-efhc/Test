# Change cycle v154_08

- Refactored FAQ Russian source to 16-section human style.
- Switched FAQ fallback logic to Russian source instead of English.
- Rebuilt FAQ meta titles for 13 languages to match 16 sections.
- Reset localized item overrides to clean state for next
  source-based translation cycles.