# Change Report — v167_28 — Cycle 939 terminal / non-terminal payment state clarity

## What was found
- `payment_intents_service` still mixed terminal/non-terminal wording: `pending_external` used vague `wait_processing`, and player-facing `user_message` in truth-layer remained Russian despite the new language canon.
- Browser-Shop and ProfileModal did not consistently present payment phase as terminal vs non-terminal in the touched continuity surfaces.

## What was changed
- Switched canonical pending-external next-action to `wait_network`.
- Rewrote player-facing payment truth `user_message` strings to English-first.
- Added focused continuity wording branches for `wait_network` and `pay_or_wait`.
- Updated Browser-Shop payment phase labels to `terminal state` / `non-terminal state`.
- Rolled touched ProfileModal payment labels back to English-first.
- Added a focused architecture test for terminal/non-terminal wording canon.

## Why it matters
Cycle 939 is about payment-state clarity in the truth layer first. The user must see whether a path is terminal, non-terminal, waiting for network, waiting for manual review, or safe to retry, without local UI guesses.

## Scope discipline
- No new screens.
- No wide language wave.
- Only incidental language cleanup in touched continuity/payment surfaces.
- No compatibility-marker expansion.
