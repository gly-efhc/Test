# Change report: v151_27_sql_alias_layer

## Цель
Ввести переходный слой алиасов для SQL-идентификаторов (схема/таблица)
для безопасной поэтапной миграции от raw SQL к SQLAlchemy Core.

## Изменения
- backend/app/core/config_core.py:
  - валидаторы DB_SCHEMA_CORE/DB_SCHEMA_ADMIN с алиасами.
- backend/app/core/sql_aliases_core.py:
  - canon_schema/canon_ident/canon_admin_table.
- backend/app/services/nft_check_service.py:
  - table валидируется через canon_admin_table.

## Инварианты
- Схемы строго efhc_core и efhc_admin.
- Таблицы для подстановки проходят whitelist.
- line72 соблюдён.
