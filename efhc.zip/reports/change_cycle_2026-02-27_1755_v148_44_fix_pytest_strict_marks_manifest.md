# EFHC Bot change report — v148_44

Дата/время (UTC): 2026-02-27 17:55

## Причина (CI stop-crane)
- Pytest (pytest-asyncio strict): async fixture `async_engine` requested without
  asyncio marker -> `PytestRemovedIn9Warning` treated as error.
- Integrity test: baseline manifest listed deleted files
  `backend/app/services/orders_service.py.new(.new2)`.

## Изменения
1) Tests: добавлен `pytestmark = pytest.mark.asyncio` в модули:
- tests/test_concurrency_exchange_all.py
- tests/test_concurrency_exchange_withdraw.py
- tests/test_concurrency_withdraw_double.py

2) Tests fixtures: обновлён baseline manifest:
- tests/fixtures/repo_file_manifest_v139.json
  - удалены записи:
    - backend/app/services/orders_service.py.new
    - backend/app/services/orders_service.py.new2
  - `file_count` синхронизирован.

## Проверка
- Ожидаемо: убирает stop-crane по PytestRemovedIn9Warning и integrity-deletion.
