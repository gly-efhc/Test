# CHANGE REPORT v168_11 CYCLES 1185-1186

## Scope

This pass restores cycle 1185 from v168_10 and continues into cycle
1186.
It repairs concrete route-road findings from the road integrity audit.

## Cycle 1185

The duplicate self-profile alias was removed after checking active code,
frontend consumers, API contracts and tests.  `GET /user/me` is the only
active self-profile route.  The removed alias was
`GET /user/{global_id}/me`.

## Cycle 1186

The panels-summary road was changed from a tg-id path to a canonical
self-route.  The active route is now `GET /user/me/panels-summary`.  The
old `GET /user/{global_id}/panels-summary` route was removed from active
backend code after consumer checks.

## Files changed

Code:
- `backend/app/routes/user_routes.py`.
- `backend/openapi/openapi.json`.

Guards and tests:
- `ops/routes/check_profile_route_canon.py`.
- `ops/routes/check_panels_summary_canon.py`.
- `tests/architecture/test_me_user_route_overlap_canon.py`.
- `tests/architecture/test_user_panels_route_canon.py`.

Docs:
- `docs/NORM/API_CONTRACTS.md`.
- `docs/NORM/ROAD_INTEGRITY_MATRIX.md`.
- `docs/cycles/WORK_CYCLES.md`.
- `docs/cycles/WORK_CYCLES_1101-1200.md`.
- `docs/cycles/WORK_CYCLES_1182-1200_FIX_PLAN.md`.
- `docs/cycles/WORK_CYCLES_1185-1186_DETAILED_PLAN.md`.
- `docs/audits/PROFILE_ROUTE_ALIAS_REMOVAL_1185.md`.
- `docs/audits/PANELS_SUMMARY_ROUTE_REPAIR_1186.md`.
- `docs/AI/AI_DOCS_INDEX.md`.
- `reports/REPORTS_INDEX.md`.

Generated evidence:
- `reports/generated/profile_route_canon_1185.json`.
- `reports/generated/panels_summary_canon_1186.json`.

## Checks

Local helper checks passed for cycles 1185 and 1186.  Changed Python
files passed built-in compile.  GitHub CI was not run and is not
claimed.
