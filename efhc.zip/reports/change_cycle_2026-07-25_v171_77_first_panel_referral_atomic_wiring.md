# v171.77 — first-panel referral atomic wiring

## Input evidence

Both v171.76 GitHub CI archives passed all configured gates:

- development: 2538 passed, 20 skipped;
- release: 9 passed;
- lint, mypy, Bandit, Alembic and frontend build: green.

An independent runtime source audit found that
`on_user_first_panel_activation()` had no production caller.

## Root cause

The existing referral bonus test directly invoked the downstream function. It
proved reward calculation but not that the first-panel event called it. No test
covered the complete business chain or its transaction boundary.

## Runtime repair

- panel service calls the referral hook after first panel creation;
- call remains inside the panel-owned transaction;
- BONUS rewards use a no-commit bank helper;
- reward failures roll back the whole first activation;
- replay does not create a second panel or reward.

## Proof boundary

Local source/architecture tests are complete. PostgreSQL tests are included but
require the CI database service. Fresh exact-HEAD GitHub CI is mandatory before
any deployment decision.
