# EFHC Bot — change report

Date: 2026-04-27
Archive: v167_95
Cycles: 1131-1140
Title: reward technical migration-safe plan and portal English-first UX repair

## Scope

This pass continued from v167_94 with two approved goals:
1. close the technical rename plan for remaining `reward*` names without
   breaking migrations or runtime contracts;
2. move immediately into admin/shop/portal UX refinement with release focus.

## What was changed

- tasks service now prefers `bonus_efhc` first in admin payload handling;
- admin route stopped injecting `reward_efhc` when `bonus_efhc` is already
  provided;
- moderation route switched to `bonus_override_efhc` call usage while service
  kept bounded compatibility fallback;
- canonical service entrypoint became `claim_task_bonus()`;
  `claim_task_reward()` stays as a compatibility wrapper;
- `ShopEntryPage` no longer contains hardcoded Russian strings in the active
  player-facing portal flow block;
- new locale keys were added for the shop entry flow block in active locale
  bundles;
- continuity copy `pay_or_wait` text was repaired.

## Boundaries kept

- migrations remain untouched;
- DB/runtime contract names such as `reward_bonus_efhc`,
  `reward_amount_efhc` and `task_rewards_log` remain unchanged;
- no route paths were renamed;
- no donor code from `Песочница_full.zip` was copied.

## Evidence

- `backend/app/services/tasks_service.py`
- `backend/app/routes/tasks_routes.py`
- `backend/app/routes/admin_tasks_routes.py`
- `frontend/src/features/shop/ShopEntryPage.tsx`
- `frontend/src/lib/portal/continuityCopy.ts`
- `frontend/public/locale/*.json`
- `docs/audits/REWARD_TECHNICAL_MIGRATION_SAFE_PLAN_1131_1140.md`
- `docs/audits/PORTAL_SHOP_ENTRY_ENGLISH_FIRST_REPAIR_1131_1140.md`

## Result

The technical `reward*` cleanup is now closed at the active route/service
boundary. Remaining legacy names are narrowed to schema/runtime compatibility
contracts. The portal shop entry surface is aligned better with the
English-first player-facing canon and release direction.
