# Change report v150_60

Дата (UTC): 2026-03-03T20:17:49Z

## Цель

Довести Lotteries до SSOT по твоим ответам:
- две активные карточки
- bonus-first
- кнопка buy активна только при достатке средств
- max 10 на draw
- partial fill по остаткам билетов
- winners: draw_id + tg_id + username + ticket_number
- VIP: wallet из профиля, каждый билет создаёт claim
- хранить 1000 завершённых draw, старше удалять

## Изменения

### Docs
- Обновлён `docs/LOTTERIES.md` под финальный SSOT:
  partial fill, ошибки 409, claims per ticket, хранение 1000 draw.

### Backend
- `backend/app/models/lotteries_models.py`
  - добавлен `LotteriesBuyIdempotency`
  - `LotteriesNFTClaim` переписан под claim-per-ticket
  - статусы claim: pending/issued/rejected/canceled

- `backend/app/services/lotteries_service.py`
  - `svc_buy_tickets`: строгий le=10, read-through idempotency,
    wallet via wallet_bindings, partial fill по remaining,
    claims per ticket для VIP, 409 ошибки
  - `svc_get_latest_winners`: добавлены username + ticket_number
  - `_force_lotteries_internal`: NFT-путь больше не создаёт
    один claim на draw; проверяет claim winning ticket
  - `_auto_restart_lotteries`: cleanup history > 1000 completed draw

- `backend/app/schemas/lotteries_schemas.py`
  - `LatestWinnerOut`: winner_username, winning_ticket_number
  - `BuyTicketsIn.qty`: le=10

### Frontend
- `frontend/src/pages/lotteries.tsx`
  - исправлена разметка
  - две карточки одновременно
  - stepper (-/+) вместо произвольного ввода
  - buy disabled если qty не покрывается (bonus+main)
  - показываем cost, progress-bar, remaining
  - winners latest: draw_id + tg_id + username + ticket_number

## Проверки (локально)

- `pytest tests/architecture/test_max_line_length_72.py` — PASS

## Риски/заметки

- Изменение структуры `lotteries_nft_claims` повлияет на
  уже существующие БД, если она не пересоздаётся в CI.
  В режиме Postgres CI обычно поднимает чистую БД.

