# Change report v150_53

## Source log
- logs_59201398678.zip

## Fixes
- Alembic 0001 made idempotent: metadata.create_all(checkfirst=True)
  to avoid DuplicateObject on enum types when upgrade runs twice.
- enum_admin_role now created in efhc_admin schema (explicit schema).
- tests/conftest db_migrated uses `python -m alembic` via sys.executable.
