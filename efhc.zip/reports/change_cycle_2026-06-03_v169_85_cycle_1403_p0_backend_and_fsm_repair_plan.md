# Change cycle 2026-06-03 — v169.85 / cycle 1403 P0 backend and FSM repair plan

## Summary

Cycle 1403 performed an audit/TZ planning pass for P0 backend red-zone issues and the `states.py` single-responsibility problem. Runtime code was not changed.

## Added

- `docs/audits/P0_RED_ZONE_BACKEND_AND_FSM_AUDIT_V169_85.md`
- `docs/backend/P0_RED_ZONE_BACKEND_REPAIR_PLAN.md`
- `docs/backend/FSM_STATES_SPLIT_TZ.md`
- `docs/cycles/WORK_CYCLES_1403-1417_P0_BACKEND_AND_FSM_REPAIR_PLAN.md`
- `reports/generated/p0_red_zone_backend_and_fsm_audit_v169_85.json`

## Updated

- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1401-1500_POST_I18N_STABILIZATION_PLAN.md`
- `docs/cycles/WORK_CYCLES_1401-1500_FUTURE_RANGE_PLAN.md`
- `docs/AI/AI_DOCS_INDEX.md`
- `docs/audits/audits_index.json`
- `reports/REPORTS_INDEX.md`
- `map_element.md`

## Findings

- HEAL-0045: active global_id/User.id drift confirmed.
- HEAL-0040: active payment_intents package_id contract drift confirmed.
- HEAL-0023: partial idempotency repair with residual detector weakness.
- HEAL-0024: withdraw atomicity residual risk confirmed.
- HEAL-0018: nested transaction workaround remains.
- HEAL-0044: model clean with schema/migration proof still required.
- `backend/app/bot/states.py`: SRP violation confirmed; split TZ created.

## Non-claims

No GitHub CI green, full pytest green, npm build, screenshots, live Telegram proof, real wallet proof or release-ready verdict is claimed.
