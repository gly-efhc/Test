# v153_09 — FAQ item translations for IT / PL / TR

Date: 2026-03-08
Archive base: EFHC_Bot_v153_08_faq_de_fr_es_and_en_fallback.zip

## Scope
- continue FAQ localization work from v153_08
- extend item-level localized FAQ content for critical blocks
- keep search, fallback and Telegram-native FAQ structure intact

## Changed
- added item-level FAQ translations for `it`
- added item-level FAQ translations for `pl`
- added item-level FAQ translations for `tr`
- preserved EN fallback for other non-RU locales

## Covered blocks
- 5.1 Profile / Settings
- 6.1 Wallet
- 7.1 Balance types
- 7.2 Full cycle
- 14.1 Exchange
- 14.2 Withdraw

## Validation
- `python ops/canon_guard.py` → OK
- targeted TypeScript compile for FAQ data layer → OK
- line72 check for changed file → OK

## Notes
- this cycle does not claim green CI
- full CI status still requires a fresh `logs_*.zip`
  for the new archive
