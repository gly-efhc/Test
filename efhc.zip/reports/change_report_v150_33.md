# Change report v150_33 (2026-03-03)

## Исправления

- Withdraw approve: идемпотентность через efhc_admin.idempotency_key
  (SELECT FOR UPDATE), без гаданий по admin_action_log.
- Withdraw approve: добавлен _admin_approve_withdraw_nocommit; обёртка
  admin_approve_withdraw сохраняет commit-совместимость.
- D8 канон: тест exchange_all сравнивает d8 через d8_str(), ноль всегда
  '0.00000000'.
- Документация: добавлен раздел про канон d8 в docs/EFHC_CANON.md.

## Файлы

- backend/app/services/withdraw_service.py
- tests/test_concurrency_exchange_all.py
- docs/EFHC_CANON.md
