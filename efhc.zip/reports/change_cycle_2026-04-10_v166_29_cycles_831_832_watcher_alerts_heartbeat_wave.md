# change report — v166_29 — cycles 831-832

## Done
- Added watcher alert fan-out via Telegram notifications list/dedicated chat support.
- Added watcher failure escalation from `check_ton_inbox` timeout/error paths.
- Added `/health/runtime` route with watcher heartbeat details.
- Surfaced backend/db/watcher runtime badges in `AdminRouteHealthStrip`.

## Files
- backend/app/core/config_core.py
- backend/app/services/admin/admin_notifications.py
- backend/app/scheduler/check_ton_inbox.py
- backend/app/routes/system_routes.py
- frontend/src/components/admin/AdminRouteHealthStrip.tsx
- docs/audits/BLITZ_WATCHER_ALERTS_HEARTBEAT_831_832_2026_04_10.md
- docs/cycles/WORK_CYCLES.md
- docs/cycles/WORK_CYCLES_801-900.md
- reports/REPORTS_INDEX.md
