# Change report v150_26

Source CI log: logs_59124386845.zip

## Цель цикла

- Устранить падения pytest из logs_59124386845.zip.

## Исправления

1) Repo-wide bans (архитектурные тесты)
- Санитизированы внутренние отчёты/реестры, чтобы не содержать
  запрещённые legacy-токены в исходном виде.
- Файлы:
  - reports/alias_sanitation_report_v150_25.md
  - EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
  - reports/CI_FIXES_INTERNAL_LOG.md

2) users.available_kwh: строковая форма нуля
- Поле оставлено зеркальным (generated), но переведено на NUMERIC без
  typmod и выражение приведено к numeric, чтобы asyncpg не отдавал
  Decimal('0E-8') в сыром SELECT.
- Файл: backend/app/models/user_models.py

3) efhc_transfers_log.meta: совместимость с тестами
- meta хранится как JSON-строка (TEXT), т.к. тесты читают meta через
  raw SQL и делают json.loads(str(raw)).
- transactions_service вставляет/мерджит meta через CAST(meta AS jsonb)
  и возвращает обратно ::text.
- Файлы:
  - backend/app/models/transactions_models.py
  - backend/app/services/transactions_service.py
  - backend/app/services/reports_service.py

4) Withdraw approve: совместимость сигнатуры
- approve_withdraw_request теперь имеет безопасные значения по
  умолчанию для actor/idk, т.к. тесты вызывают функцию только
  с request_id.
- Файл: backend/app/services/withdraw_service.py

5) Payment intents
- deposit intent response включает to_address.
- shop_external intent всегда пишет efhc_amount_d8=0 (NOT NULL) и
  возвращает efhc_amount_d8 и to_address.
- Файл: backend/app/services/payment_intents_service.py

## Артефакты

- Обновлён реестр ошибок: EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- Обновлён внутренний лог фиксов: reports/CI_FIXES_INTERNAL_LOG.md
