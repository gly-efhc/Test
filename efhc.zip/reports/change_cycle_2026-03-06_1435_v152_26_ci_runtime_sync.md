# Change cycle 2026-03-06 14:35 — v152_26 CI/runtime sync

## Source evidence
- HEAD: `EFHC_Bot_v152_25_withdraw_admin_sync.zip`
- CI logs: `logs_59623844608.zip`

## What failed in fresh CI
- Ruff: 9 issues.
- MyPy: 2 issues in `backend/app/core/async_tasks.py`.
- Pytest: 4 failed, 12 errors.

## Root causes
1. `create_logged_task()` accepted `Awaitable[T]`, but passed it to
   `asyncio.create_task()` without a coroutine cast and without an
   explicit task annotation.
2. Async pytest loop scope was inconsistent with the session-scoped async
   DB fixtures, which produced `Future attached to a different loop`
   during `AsyncSession.close()` teardown.
3. `_run_idempotent()` in `transactions_service.py` did not perform an
   early read-through check by `idempotency_key`; repeated calls could
   return `detail="ok"` instead of `detail="idempotent"`.
4. `test_withdraw_request_uses_only_main_balance` was stale against the
   withdraw canon: the canon says `withdraw_requests` is not deleted,
   while the test expected `COUNT(*) == 0`.
5. Overview docs and `TESTS_CATALOG.md` were stale after the repository
   reached 73 test files.
6. A few tests had import-order / E402 issues under Ruff.
7. Direct local MyPy audit after the main fixes also found two return-type
   issues in `backend/app/crud/referrals_crud.py`.

## What was changed
- Typed and casted `create_logged_task()` correctly.
- Set `asyncio_default_test_loop_scope = session` in `pytest.ini`.
- Added early read-through idempotency return in
  `backend/app/services/transactions_service.py`.
- Synced withdraw runtime invariant test with the canon
  (`PENDING`, `hold_done=FALSE`, `refund_done=FALSE`).
- Regenerated `docs/TESTS_CATALOG.md` and updated overview docs to
  `test files: 73`.
- Normalized imports in Ruff-failing files.
- Fixed local MyPy return typing in `referrals_crud.py`.

## Local verification actually performed
- `python -m ruff check backend api ops tests` → pass.
- `python -m mypy backend/app --cache-dir /tmp/mypyefhc` → pass.
- `python -m compileall backend api ops tests` → pass.
- `PYTHONPATH=backend pytest -q tests/architecture/test_docs_ssot_sync.py \
  tests/architecture/test_route_idempotency_policy.py \
  tests/architecture/test_withdraw_admin_contract.py \
  tests/core/test_async_tasks.py` → 9 passed.

## Important limit
No fresh GitHub Actions log exists yet for this new archive, so full CI is
not claimed green in this report.
