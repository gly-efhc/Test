# line72 cycle 016

Цель: санация псевдо-ID к канону tg_id без изменения поведения.

Сделано:
- В backend лог-корреляции теперь хранится tg_id без псевдо-имён.
- В deps.py переменные request.state приведены к канону tg_id.
- В канон-доках заменён пример запрещённого алиаса на u_id.

Файлы:
- backend/app/core/logging_core.py
- backend/app/deps.py
- docs/EFHC_CANON.md
- docs/TERMS_GLOSSARY.md
- reports/line72_cycle_016.md

Исключения 72: нет.

Проверки:
- python -m compileall backend -q: PASS
- pytest -q: PASS
