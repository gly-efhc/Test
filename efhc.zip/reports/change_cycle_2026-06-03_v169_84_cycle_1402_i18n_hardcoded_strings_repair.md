# Change report — v169.84 / cycle 1402

## HEAD

Input: `EFHC_Bot_v169_83_cycle_1401_i18n_reaudit_low_signal_repair.zip`  
Output: `EFHC_Bot_v169_84_cycle_1402_i18n_hardcoded_strings_repair.zip`

## Goal

Repair the v169.83 i18n hardcoded audit/TZ findings on public/shared UI text.

## Changed source files

- `frontend/src/components/ErrorBoundary.tsx`
- `frontend/src/pages/_app.tsx`
- `frontend/src/components/AdsBanner.tsx`
- `frontend/src/components/EnergyGauge.tsx`
- `frontend/src/components/ui/SurfaceFactsStrip.tsx`
- `frontend/src/components/ui/Modal.tsx`
- `frontend/src/components/ui/telegram/TelegramProductCard.tsx`
- `frontend/src/components/GlobalHeader.tsx`
- `frontend/src/components/ShopLayout.tsx`
- `frontend/public/locale/*.json`

## New files

- `docs/audits/I18N_HARDCODED_AUDIT_AND_TZ_V169_83_2026_06_03.md`
- `docs/audits/I18N_HARDCODED_STRINGS_REPAIR_AUDIT_V169_84.md`
- `docs/frontend/I18N_HARDCODED_STRINGS_REPAIR.md`
- `reports/generated/i18n_hardcoded_strings_repair_v169_84.json`
- `tests/architecture/test_i18n_hardcoded_strings_guard.py`

## Test control

- Tests deleted: 0
- Tests archived as `test_*.py`: 0
- Skips added: 0
- Xfails added: 0
- `pytest.ini` weakened: no
- New active guard: `tests/architecture/test_i18n_hardcoded_strings_guard.py`

## Checks

- Locale parity: PASS
- Locale inventory: PASS
- No admin leak: PASS
- Forbidden gambling/chance contour: `forbidden_findings: 0`
- All 12 locale value-quality scripts: PASS
- Targeted new guard: `6 passed, 3 warnings`

## Non-claims

No GitHub CI green, full local pytest green, full frontend build, screenshots,
live Telegram proof, real wallet proof or release-ready status is claimed.
