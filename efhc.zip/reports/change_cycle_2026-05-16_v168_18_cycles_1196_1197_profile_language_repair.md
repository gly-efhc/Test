# CHANGE REPORT v168_18 CYCLES 1196-1197 PROFILE LANGUAGE REPAIR

## Source HEAD

`EFHC_Bot_v168_17_cycles_1195_1230_visual_fix_plan.zip`.

## Task

Continue from the HEAD archive, read AI/cycle/SSOT/report documents,
update cycle plans, repair the profile language switcher and continue
cycles 1196-1197 as far as safely possible in one pass.

## Result

- Profile language selection now drives runtime UI labels through the
  selected locale dictionary.
- Settings persistence is protected by a hydration gate, so defaults are
  not saved before stored settings finish loading.
- Profile language selector is now a horizontal language bar.
- Bottom navigation remains English by component-level canon.
- A new architecture guard locks the repaired behavior.

## Files changed

Code:
- `frontend/src/pages/app.tsx`
- `frontend/src/components/Layout.tsx`
- `frontend/src/components/ProfileModal.tsx`
- `frontend/src/hooks/useT.ts`
- `frontend/src/styles/globals.css`

Tests:
- `tests/architecture/test_profile_language_switch_guard.py`

Docs/reports:
- `docs/audits/PROFILE_LANGUAGE_REPAIR_1196_1197.md`
- `docs/cycles/WORK_CYCLES.md`
- `docs/cycles/WORK_CYCLES_1101-1200.md`
- `docs/cycles/WORK_CYCLES_1182-1200_FIX_PLAN.md`
- `docs/cycles/WORK_CYCLES_1195-1230_VISUAL_FIX_PLAN.md`
- `docs/cycles/WORK_CYCLES_1196-1230_DETAILED_PLAN.md`
- `docs/NORM/TESTS_CATALOG.md`
- `docs/NORM/VISUAL_FRONTEND_PUBLIC_UI_NORM.md`
- `docs/healer/VISUAL_UI_HEALER_CASE.md`
- `reports/REPORTS_INDEX.md`
- `reports/generated/profile_language_repair_1196_1197.json`

## Checks

- Source ZIP `unzip -t`: OK before work.
- Source ZIP extracted: OK.
- `python3 -m pytest -q` targeted architecture guards: OK.
- `npm ci --ignore-scripts`: completed to enable local TS check.
- `npx tsc --noEmit`: OK.
- `npm run build`: timed out during optimized production build.
- Changed docs/test line72: checked before packaging.
- New ZIP `unzip -t`: must be checked after packaging.

## Not claimed

- GitHub CI was not run.
- Browser visual screenshot audit was not run.
- Full Direct Deposit/HUB/Browser-Shop visual cleanup is not complete.
- Release readiness for the full 1176-1230 range is not claimed.
