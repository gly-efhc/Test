# Change Report — v166_25 — Cycles 823-824

Дата: 2026-04-10
HEAD: EFHC_Bot_v166_25_cycles_823_824_blitz_launch_ops_runner_notifications_wave.zip

## Scope
- 823 — minimal ops-runner using existing backend core
- 824 — simple bot notifications for successful and failed shop order outcomes

## Confirmed changes
- added `ops/shop_payments/run_shop_payments_blitz_once.py`
- added `backend/app/services/shop_order_notifications_service.py`
- wired notification dispatch after `shop_external` auto success
- wired notification dispatch after manual `Force Fulfill`
- added order-level notification dedupe marks in `shop_orders.extra`
- started writing shop payment mismatch reasons into `shop_orders.payment_error_log`
- fixed a confirmed diagnostics bug: `amount_guard` mismatch now returns `amount_guard.reason`, not `asset_guard.reason`

## Narrow checks actually run
- `python -m py_compile backend/app/services/shop_order_notifications_service.py backend/app/services/payment_reconciliation_service.py backend/app/services/shop_service.py ops/shop_payments/run_shop_payments_blitz_once.py`
- `PYTHONPATH=backend pytest -q tests/architecture/test_confirm__path__guards_service.py -q`
- local TypeScript transpile checks for `frontend/src/pages/admin/efhc-deposits.tsx` and `frontend/src/pages/admin/shop.tsx`

## Honest residuals
- live Telegram delivery is not proven in this environment
- no GitHub CI claim
- no mainnet claim
