# Change report v151_04

## Fixed (by logs_59326940696.zip)

1) Pytest failures caused by `.mypy_cache` in repo tree

- Root cause: CI mypy step created `extracted/.mypy_cache/` with cached
  JSON containing legacy/banned substrings (e.g. `user_rating`).
  Repo-scanning tests flagged this as canon violations.
- Fix: CI now runs mypy with an explicit cache dir outside the repo tree
  (`ci_artifacts/_mypy_cache`) and removes any accidental
  `extracted/.mypy_cache` before pytest.

Files:
- `ci.yml`

2) Migration smoke test created DB but tables in efhc_core were missing

- Root cause: `tests/test_migrations_upgrade_head.py` built Alembic
  `Config()` without loading `backend/alembic.ini`. That can break
  `engine_from_config()` in `migrations/env.py`, causing upgrade to run
  without a proper engine setup.
- Fix: build Alembic Config from `backend/alembic.ini` and only override
  `sqlalchemy.url`.

Files:
- `tests/test_migrations_upgrade_head.py`

## Packaging

- Removed caches before archiving: `__pycache__`, `.pytest_cache`,
  `.mypy_cache`, `frontend/.next`, `node_modules`, `dist`, `build`.
