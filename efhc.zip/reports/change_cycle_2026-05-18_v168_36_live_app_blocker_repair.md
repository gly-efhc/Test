# Change report v168_36 — live app blocker repair

## Scope

Cycle range: 1226-1230 emergency frontend follow-up.

## Finding

The live Cloudflare URL showed raw translation keys and technical
browser fallback naming. This confirms the user's complaint that the
current browser frontend still looks unfinished.

## Code changes

- `frontend/src/lib/i18n.ts`
  - added embedded EN/RU fallback dictionaries;
  - made `loadDict()` safe when `/locale/*.json` cannot be loaded;
  - made `tFromDicts()` fall back to embedded RU/EN before raw key.
- `frontend/src/pages/app.tsx`
  - initialized UI/RU/description dictionaries with embedded fallbacks;
  - preserved async dictionary loading for selected language.
- `frontend/src/lib/browserFallback.ts`
  - changed browser preview username to `EFHC Player`.
- `frontend/src/pages/index.tsx`
  - started Energy first-screen conversion into one strong game stage.
- `frontend/src/styles/globals.css`
  - added Dragon-inspired EFHC-only shell, header, Energy hero,
    progress and bottom-nav visual layer.
- `frontend/public/locale/en.json`
  - corrected `energy.title` from generic `Title` to `Energy`.
- `frontend/src/lib/settings.ts`
  - line72-safe formatting only.
- `frontend/src/features/browser-shop/BrowserShopPage.tsx`
  - line72-safe formatting only.

## Test changes

- added `tests/architecture/test_live_visual_guard.py`.
- updated browser independence guard to reject technical
  `browser-player` public naming.

## Documents

- added `docs/audits/FRONTEND_LIVE_APP_BLOCKER_AUDIT_V168_36.md`.
- added generated JSON report.
- updated reports index.
- updated temporary AI memory.
- updated questions and answers register.

## Not claimed

- GitHub CI was not run.
- Full npm build was not run in this pass.
- Docker runtime proof is not claimed.
- 99% frontend readiness is not claimed.
