# Change cycle v170.96 / cycle 1520

Cycle 1520 closed frontend i18n and local visual proof tails.

## Changed

- Added 37 missing used i18n keys to all 13 locales.
- Fixed current UK locale Russian-tail marker.
- Hardened TonConnect wallet-list failure handling.
- Added public browser visual proof harness and report.
- Hardened admin visual proof against runtime overlays.
- Added public frontend buttons/API/i18n drift guard.

## Not claimed

- GitHub CI green.
- Full pytest green.
- Full frontend build green.
- Live Telegram proof.
- Real TonConnect proof.
- Release-ready.
