# Change report — v149_53

Дата: 2026-03-01

## Источник истины цикла
- HEAD ZIP (SSOT): EFHC_Bot_v149_52_fix_models_wallets_withdraw_ssot.zip
- CI логи (SSOT): logs_58956904319.zip

## Что упало в CI
- Шаг: **Sanity DB objects after alembic (core_admin)**
- Симптом: отсутствуют обязательные таблицы после `alembic upgrade head`:
  - `efhc_core.users`
  - `efhc_core.withdraw_requests`
  - `efhc_admin.efhc_sale_packages`

## Root cause
- Таблица `efhc_admin.efhc_sale_packages` используется кодом (admin_sale_packages_service), но отсутствовала в ORM и, как следствие, не создавалась `0001_init`.
- Админские ORM-модели были привязаны к `DB_SCHEMA_CORE`, что противоречит канону 2 схем (`efhc_core` + `efhc_admin`) и усложняет детерминированную проверку объектов.
- `ops/ci_verify_db_objects.py` был логически некорректен (битая индентация + устаревший/жёстко прошитый список REQUIRED).

## Что исправлено
1) **DB/ORM**
- `backend/app/models/admin_models.py`:
  - схема админских таблиц переведена на `settings.DB_SCHEMA_ADMIN`;
  - добавлена ORM-модель `EFHCSalePackage` для таблицы `efhc_admin.efhc_sale_packages`.

2) **Alembic / 0001**
- `backend/migrations/versions/0001_init.py`:
  - `SET search_path TO efhc_core, efhc_admin` (исключаем уход в `public`);
  - добавлена проверка, что ключевые таблицы (`efhc_core.users`, `efhc_core.withdraw_requests`, `efhc_admin.efhc_sale_packages`) присутствуют в `Base.metadata` до `create_all()`.

3) **CI sanity script (ops)**
- `ops/ci_verify_db_objects.py`:
  - исправлена структура/индентация;
  - список REQUIRED теперь читается из `docs/ssot_pack/SSOT_TABLES_ORM.csv`.

4) **SSOT**
- `docs/ssot_pack/SSOT_TABLES_ORM.csv`:
  - админские таблицы отмечены схемой `efhc_admin`;
  - добавлена строка для `efhc_admin.efhc_sale_packages`.
- `docs/ssot_pack/SSOT_ROUTE_TABLE_MAP.csv` и `SSOT_ROUTES_TABLES_MIGRATIONS.csv`:
  - заполнены паспорта маршрутов **#5–#10** (admin logs/lotteries/panels) с read/write таблицами и evidence.

5) **Реестр ошибок**
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`:
  - добавлен класс ошибки по `logs_58956904319.zip` (sanity missing tables after alembic) + каноничное лечение.

## Риски/заметки
- Перенос админских ORM-таблиц в `efhc_admin` меняет фактическое расположение таблиц. Для CI (пустая БД) это корректно. Для прод/существующих БД потребуется отдельная миграция-перенос, если такие таблицы уже были созданы в другой схеме.
