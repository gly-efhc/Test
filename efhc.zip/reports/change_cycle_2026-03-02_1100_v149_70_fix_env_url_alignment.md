# Change report v149_70

- Fix env.py: align Alembic URL with PSYCOPG_URL priority.
- Remove SYNC_DATABASE_URL global override in config.set_main_option.
- Postgres-only: no sqlite fallback; raise if URL missing.

Source logs: logs_59025053078.zip