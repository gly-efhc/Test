# line72 cycle 029 — Panels SSOT doc: канонизация правок

## 1) Что сделано
- Добавлен SSOT-док по вкладке Panels с учётом канона: global public_id, срок 180 дней (UTC), Active/Archive, idempotency и audit, таймер от server_now_utc.
- Обновлён SSOT_INDEX: Panels SSOT добавлен в список источников истины.

## 2) Изменённые файлы
- docs/PANELS_SSOT.md
  - Встроены 5 правок канона: INSERT с public_id=NULL, жёсткий инвариант идемпотентности (один ключ → одна панель), таймер только от server_now_utc, фильтр Active/Archive через :server_now_utc, правило одного каноничного пути покупки.
- docs/SSOT_INDEX.md
  - Добавлена ссылка на docs/PANELS_SSOT.md как SSOT по Panels.

## 3) Исключения 72
- Нет.

## 4) Проверки
- python -m compileall backend -q : PASS
- pytest -q : PASS

## 5) Релиз
- Архив: EFHC_Bot_v146_04_panels_ssot_doc_edits.zip
