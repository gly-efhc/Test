# Change report v150_61

Дата: 2026-03-03

## Цель

1) Автозамена префикса импортов: `backend.app.` → `app.`
2) Тест-стопкран: запрет `backend.app.` в коде репозитория.

## Изменения

### A) Автозамена импортов

Заменено во всех кодовых файлах, где встречалось `backend.app.`.

Изменённые файлы (23):

- api/index.py
- backend/run.py
- ops/canon_guard.py
- tests/core/test_monetary_idempotency_middleware.py
- tests/efhc_backend/unit/test_cursor_codec_ssot.py
- tests/efhc_backend/unit/test_finance_spend_rules.py
- tests/efhc_backend/unit/test_telegram_init_data.py
- tests/test_concurrency_exchange_all.py
- tests/test_concurrency_exchange_withdraw.py
- tests/test_concurrency_withdraw_double.py
- tests/test_gen_rate_vip_switch.py
- tests/test_panels_180_days.py
- tests/test_panels_active_archive.py
- tests/test_panels_global_id.py
- tests/test_panels_idempotent_create.py
- tests/test_payment_intent_status_owner_only.py
- tests/test_payment_intents_lifecycle_double_payments.py
- tests/test_payment_intents_payload_unique.py
- tests/test_payment_intents_usdt_tx_and_confirm.py
- tests/test_per_sec_constants_settings.py
- tests/test_unmatched_incoming_recording.py
- tests/test_utcnow_ssot.py
- tests/test_wallets_connect_hardening.py

### B) Тест-стопкран

Добавлен файл:

- tests/architecture/test_no_backend_app_imports_repo.py

Правило:
- В кодовых файлах (.py/.ts/.tsx/.js/.jsx) запрещён
  префикс `backend.app.`
- Исключены docs/, reports/, logs/ и регистр ошибок (traceback).

## Локальные проверки (не CI)

- pytest tests/architecture/test_max_line_length_72.py — PASS
- pytest tests/architecture/test_no_backend_app_imports_repo.py — PASS

