# Change report — v165_87 — cycles 711-713

## Done
- compared EFHC admin/shop contour against donor sandboxes
- recorded honest donor-gap audit in docs/audits
- restored `Selected item facts` panel into full frontend admin/shop
- synced cycle/report control layer to restored 711-713 state

## Notes
These changes were originally made in a frontend-only branch and are now
restored onto the last full stable archive so the project remains whole.
