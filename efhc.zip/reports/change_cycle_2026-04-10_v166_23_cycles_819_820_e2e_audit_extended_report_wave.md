# Change report — v166_23 — cycles 819-820 — 2026-04-10

## What changed
- added end-to-end audit guard for the full external payment chain 801-819
- fixed signal-loss gap by carrying confirm-layer reason into `ton_inbox_logs.note`
- published extended technical report: guaranteed / fail-closed / remaining

## Checks
- `python ops/routes/audit_external_payment_flow_e2e.py`
- `python -m py_compile ops/routes/audit_external_payment_flow_e2e.py backend/app/services/payment_reconciliation_service.py backend/app/services/watcher_service.py`
