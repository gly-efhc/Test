# Change report v150_01

## Scope

Fix watcher behavior for incoming TON tx without memo.

## Change

- watcher_service: if memo is empty and sender wallet is NOT bound
  to any tg_id, the tx is ignored.
  - No credits.
  - No unmatched_incoming record.
  - ton_inbox_logs is updated with status error_user_not_found and
    a clear note.

## Files

- backend/app/services/watcher_service.py

