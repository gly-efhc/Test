# Change report — v170.12 cycle 1436 user decisions doc update

## Summary

The user answered the open linkage-repair questions from cycle 1436. The archive documents now lock these decisions before runtime repair cycles begin.

## Created

- `docs/NORM/ITERATION_QUESTIONS_FORMAT_STANDARD.md`
- `docs/cycles/WORK_CYCLES_1436_USER_DECISIONS_DOC_UPDATE.md`
- `reports/change_cycle_2026-06-05_v170_12_cycle_1436_user_decisions_doc_update.md`

## Updated

- `KERNEL.md`
- `docs/AI/READING_ENTRYPOINT.md`
- `docs/AI/TOPIC_READING_ROUTES.md`
- `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md`
- `docs/audits/P0_MIGRATIONS_ROUTES_BACKEND_FRONTEND_LINK_AUDIT_V170_10.md`
- `reports/generated/migrations_routes_backend_frontend_link_audit_v170_10.json`
- `docs/testing/TEST_GUARD_MANIFEST.md`
- `docs/testing/TEST_GUARD_MANIFEST.json`
- `docs/cycles/WORK_CYCLES.md`
- `reports/REPORTS_INDEX.md`
- `map_element.md`
- `ops/operator_kernel/config/routes.yaml`
- `ops/operator_kernel/cache/file_map.json`

## User decisions

- Do not create `efhc_mint_burn` ledger/table for rare admin mint/burn operations.
- Admin wallet reset must fully unbind canonical `wallet_bindings`.
- Admin Hub canonical path is `/admin/hub/*`.
- Future iteration questions use the approved simple Russian format.

## Not changed

Runtime code, tests, migrations, frontend code, backend services/routes/models, CI/workflows, lock files, business logic, economy, security/auth logic and money-flow were not changed.
