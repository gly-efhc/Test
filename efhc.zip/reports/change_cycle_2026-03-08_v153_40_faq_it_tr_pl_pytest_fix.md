# Change cycle v153_40 — FAQ it/tr/pl + pytest fixes

## Что упало
- pytest падал на 4 тестах.
- 3 падения были связаны с `frontend/src/data/faq/localized.ts`.
- 1 падение было связано с runtime-логикой реферального бонуса.

## Где
- `tests/architecture/test_no_banned_rank_terms.py`
- `tests/efhc_backend/unit/test_no_legacy_words.py`
- `tests/test_no_placeholders.py`
- `tests/architecture/test_referral_level_bonus_runtime.py`

## Root cause
- В `localized.ts` появились строки, которые случайно задевали
  guard по banned legacy terms (`rating` как подстрока внутри
  `generating`) и placeholder-guard (`TODO` как слово внутри
  испанского `todo`).
- В реферальной проверке активных приглашённых сервис считал
  только канонический вариант `panels.tg_id = invitee_tg_id` и
  не учитывал mixed legacy-данные, где в `panels.tg_id` мог
  лежать внутренний `users.id`.

## Что исправлено
- В `localized.ts` заменены проблемные формулировки:
  - `generating` -> `producing energy`
  - испанское `todo` -> `la totalidad del`
  - скорректирована ещё одна испанская строка с `todo`
- Добавлены новые переводы FAQ для `it`, `tr`, `pl` по
  приоритетным новым RU-only блокам:
  - верхняя панель
  - панели: цена / первый panel / старт генерации / 180 дней /
    лимит 1000
  - страница Energy
  - Wallet: основной wallet / смена / удаление / кнопка с wallet
  - реферальные бонусы уровней 0–5
  - Activ-статус
- В `referral_service.py` подсчёт активных рефералов расширен
  совместимым JOIN-условием для mixed legacy-данных:
  `p.tg_id = rl.invitee_tg_id OR p.tg_id = u.id`

## Локальная проверка
Запущены точечно:
- `tests/architecture/test_no_banned_rank_terms.py`
- `tests/efhc_backend/unit/test_no_legacy_words.py`
- `tests/test_no_placeholders.py`
- `tests/architecture/test_referral_level_bonus_runtime.py`

Результат:
- 3 passed
- 1 skipped

## Остаток по FAQ after cycle
Сравнение `ru.ts` vs `localized.ts` показывает:
- `it`: missing 40
- `tr`: missing 40
- `pl`: missing 40
- `da`: missing 75
- `hi`: missing 75
- `id`: missing 75
- `sw`: missing 75

## Примечание по CI
Свежий GitHub logs подтверждает, что в HEAD до фикса падал
только `pytest`. Новый green CI не заявляется, потому что для
нового архива свежего `logs_*.zip` ещё нет.
