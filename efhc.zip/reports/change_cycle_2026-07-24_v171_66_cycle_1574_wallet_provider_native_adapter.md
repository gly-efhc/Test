# v171.66 / cycle 1574 — WalletProvider and Native-wallet adapter layer

Status: `DEVELOPMENT SNAPSHOT / CYCLE 1574 ACTIVE / NOT RELEASE READY`.

## User requirement

Remove the WebApp's architectural dependence on one current TonConnect implementation and introduce an application-owned boundary:

```text
WalletProvider
├── TonConnectAdapter
├── TelegramWalletAdapter   (Wallet in Telegram)
└── NativeGramWalletAdapter (Native Gram Wallet)
```

## Implemented

- Added the common `WalletAdapter` contract and `WalletProvider` React root.
- Moved the TonConnect SDK/provider and current TonProof/binding flow inside `TonConnectAdapter`.
- Added independent `TelegramWalletAdapter` and `NativeGramWalletAdapter` modules.
- Added the stable `EfhcWalletAdapterBridgeV1` boundary for APIs that are not published or authorized yet.
- Added fail-closed behavior: an unavailable adapter cannot fabricate an address, proof, signature, transaction or settlement.
- Added adapter selection by `NEXT_PUBLIC_EFHC_WALLET_PROVIDER`, remembered selection and safe fallback order.
- Added late bridge-installation re-evaluation so a provider injected after initial render can become active without restarting or rewriting feature pages.
- Migrated app shell, wallet flow, EFHC direct deposit, Browser Shop, profile surfaces and admin payout to the generic provider.
- Converted the unused legacy `useTonConnectLinkage` hook into a compatibility facade over `WalletProvider`; it no longer imports the TonConnect SDK/helper directly.
- Added exact Operator Kernel classifier/route for Native-wallet adapter tasks.
- Added Wallet Provider SSOT, Adapter NORM, Q/A and Healer recurrence guard.

## Preserved boundaries

- EFHC economics, database schema, backend settlement and reconciliation were not changed.
- Six-button navigation, routes, public labels and visual layout were not changed.
- TonConnect remains the current operational transport.
- Wallet in Telegram and Native Gram Wallet remain unavailable until a real authorized API/bridge exists.
- A provider result is not settlement truth; backend/on-chain reconciliation remains authoritative.
- No seed phrase, private key or secret was requested, stored or logged.

## Validation

- changed TypeScript/TSX parser-transpile: `18 PASS`;
- wallet/deposit/withdraw/Telegram/TonProof architecture selection: `298 PASS`;
- exact WalletProvider/TonConnect/TonProof security pack: `32 PASS`;
- Operator Kernel classification: YAML primary route, no fallback;
- release-readiness evidence score remains `57 / 100`, therefore not release-ready.

The full architecture suite is not green because the input `v171.65` already contains legacy control-document/guard drift. The bounded audit stopped after `20 failed, 671 passed, 2 skipped`; five representative failures reproduce unchanged on the original input archive. They are recorded as remaining cycle-1574 audit work and were not hidden by changing expected values.

Production TypeScript typecheck/build was not executed because frontend dependencies are absent in this environment. Parser validation is not represented as a full typecheck or build.

## Visual proof

Rendered UI output was not intentionally changed, so no new screenshot archive was created. This report does not substitute for route-backed proof if a future provider selector or provider-specific UI is added.

## External non-claims

No claim is made that Telegram has published the final wallet API, that Native Gram Wallet is live, or that live Telegram, real TonConnect, TonProof, transaction confirmation or settlement has been verified for this HEAD.

## Next work

Cycle 1574 remains active. The next bounded pass must continue the pre-existing architecture/control-guard audit and the remaining locally executable release-candidate checks. Next safe archive: `EFHC_Bot_v171_67.zip`.
