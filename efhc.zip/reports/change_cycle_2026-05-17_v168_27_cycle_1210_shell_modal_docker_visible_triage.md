# Change report v168_27 — cycle 1210

## HEAD

Input archive:
`EFHC_Bot_v168_26_cycle_1209_visible_functions_browser_shell.zip`.

## Scope

Cycle 1210 applied the user's targeted corrections and produced the
visible-function triage table.

## Code changes

- `ops/docker/Dockerfile.backend`: added `COPY docs /app/docs`.
- `docker-compose.yml`: backend healthcheck uses `/api/health`.
- `ops/docker/docker-compose.yml`: aligned to `/api/health`.
- `frontend/src/pages/document.tsx`: added Telegram WebApp SDK.
- `frontend/src/components/ui/Modal.tsx`: bottom-sheet shell.
- `frontend/src/components/GlobalHeader.tsx`: game-header visual shell.
- `frontend/src/components/Layout.tsx`: game-shell and nav classes.
- `frontend/src/styles/globals.css`: modal/header/shell classes only.

## Documents

- Added `GAME_SHELL_MODAL_DOCKER_REPAIR_1210.md`.
- Added `VISIBLE_FUNCTIONS_TRIAGE_TABLE_1210.md`.
- Added generated JSON triage evidence.
- Updated cycle plan, visual norm, tests catalog, Q/A and reports.

## Checks

- Targeted architecture guards passed.
- TypeScript check passed after `npm ci --ignore-scripts`.
- JSON validation passed.
- ZIP integrity check passed on output archive.

## Not claimed

GitHub CI was not run.  Live browser install proof was not run.
Full visual release readiness is not claimed.
