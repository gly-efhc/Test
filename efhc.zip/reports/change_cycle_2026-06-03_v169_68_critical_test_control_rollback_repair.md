# v169.68 — critical test control rollback repair

Base: `EFHC_Bot_v169_66_cycle_1386_ci_logs_test_execution_repair.zip`.
Unsafe branch rejected: v169.67 test-suite consolidation.

## Result

- Old active architecture tests: 271.
- Restored active architecture tests: 271.
- Newly added integrity guard tests: 1 file.
- Real consolidation in this pass: 0.
- Deleted tests in this pass: 0.
- Archived `test_*.py` files in this pass: 0.

## Log repair

`frontend/src/pages/document.tsx` was moved to
`frontend/src/pages/_document.tsx` to fix the Next `/document` build blocker.

## Control

Added `docs/testing/TEST_GUARD_MANIFEST.json` and
`scripts/ci/check_test_suite_integrity.py`.

## Known boundary

Full pytest green is not claimed. Active test failures must be repaired in
following domain cycles; they must not be hidden by skip/archive/xfail.
