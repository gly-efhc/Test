# Change cycle 1556 — Panels, Exchange and release readiness

## Result

Panels and Exchange were converted from partially linked public pages into
React Query-driven mutation flows with generated DTO validation, backend
boundary tests and real browser interaction evidence.

A complete fail-closed release-readiness plan was added. It defines twelve
release domains, 100 weighted evidence points and cycles 1557–1574 leading to
fresh CI and a 99-percent release-candidate audit.

## Panels repair

Root cause: the page owned server state manually and bypassed the active query
layer. List, summary and activation could drift after a mutation.

Repair:

- generated panel DTOs and Zod validators;
- validated panel service responses;
- infinite-query list and summary query;
- activation mutation with dependent query invalidation;
- visible new panel after server-state refetch;
- browser interaction screenshot and machine evidence.

## Exchange repair

Root cause: query hooks existed but the page maintained a parallel local
preview and conversion state. Query invalidation did not control the visible
result.

Repair:

- page uses `useExchangePreview` and `useExchangeConvert`;
- normalized request amount `10.00000000`;
- idempotency header preserved;
- preview refetched after conversion;
- visible amount changed from `100` to `90`;
- browser interaction screenshot and machine evidence.

## Frontend production build

A blocking TypeScript pass precedes the official Next webpack build. Two
consecutive clean `npm run build` executions exited naturally with code zero
and verified all thirty-four routes.

## Full regression

A single collected inventory contained `2379` unique node IDs. Execution in
24 deterministic batches produced `2255 passed`, `124 skipped` and
`0 failed`, with no omitted node, new skip/xfail or deleted test.

The architecture collection produced `2088 passed`, `7 skipped` and
`0 failed`.

## Transaction proof boundary

Unit tests prove route-to-service parameter preservation and scoped
idempotency. No PostgreSQL process or container runtime is available locally,
so database locking, rollback and concurrent replay remain mandatory CI and
cycle-1566 evidence.

## Release plan

Authoritative files:

- `docs/audits/MVP_RELEASE_READINESS_MASTER_PLAN_1556.md`;
- `reports/generated/mvp_release_readiness_master_plan_v171_31.json`;
- `ops/release/mvp_release_readiness_master_gate.py`.

The plan cannot report 99 percent while any critical item is unverified. It
requires fresh GitHub CI, live Telegram and a real TonConnect transaction.
The current fail-closed evidence score is `13 / 100`; it is not an estimate
of source-code completion.

## Exact non-claims

This cycle does not claim:

- real PostgreSQL transactional proof;
- fresh GitHub CI for the output archive;
- live Telegram client verification;
- real TonConnect verification;
- release-ready or production-ready status.
