# Cycle 472/500

- Connected `efhc_deposits_service.py` to a live admin runtime path.
- Added `POST /admin/efhc-deposits/process` to `admin_routes.py`.
- This keeps the service user-required and operational without deleting any file.
