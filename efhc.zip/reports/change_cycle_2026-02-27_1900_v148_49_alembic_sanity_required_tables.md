# Change Cycle 2026-02-27_1900 — v148_49 Alembic sanity required tables

## Why
CI logs show pytest failing with UndefinedTableError for efhc_core.users and
efhc_core.withdraw_requests after `alembic upgrade head`. This indicates that
migration 0001 either didn't create the tables in efhc_core or created them
elsewhere. We add hard sanity checks to fail earlier and with a clear message.

## What changed
- backend/migrations/versions/0001_init.py: added to_regclass sanity checks
  for efhc_core.users and efhc_core.withdraw_requests at end of upgrade().
- backend/migrations/env.py: added post-run_migrations sanity checks for same
  tables to fail at Alembic step (canon/12) instead of pytest (canon/13).

## Verification
- python -m compileall backend -q
- python -m compileall backend/migrations -q

