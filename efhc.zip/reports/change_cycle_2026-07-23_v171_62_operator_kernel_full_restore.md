# EFHC Bot v171.62 — Operator Kernel full restore from v171.47

Status: DEVELOPMENT SNAPSHOT / KERNEL RESTORED / NOT RELEASE READY.  
Date: 2026-07-23.  
Active cycle: 1573 — FROZEN / NOT COMPLETE.

## Inputs

- Current HEAD: `EFHC_Bot_v171_61.zip`.
- Forensic baseline: `EFHC_Bot_v171_47.zip`.
- Target: `EFHC_Bot_v171_62.zip`.
- Direct authority: full user TЗ to restore the detailed Operator Kernel.

## Root cause repaired

The active role had been reduced to `navigation only`, and that demotion was protected by governance tests/scripts. The pass restores the active full dispatch role and replaces the regression guards without removing their protection purpose.

## Restored control flow

```text
user request
→ EFHC-specific keywords
→ task type
→ routes.yaml primary route
→ canonical anchors
→ exact required reads
→ exact allowed writes/restrictions
→ targeted validation
→ proof/archive boundary
```

## Runtime changes

- `route_resolver.py` now consumes `routes.yaml` as primary behavioral configuration.
- A temporary YAML route mutation changes resolver behavior without editing Python.
- `task_classifier.py` recognizes Kernel restore, canonical six-button navigation, live Telegram/TonConnect/TonProof/transactions, i18n, CI/log and archive tasks.
- `context_capsule.py` includes bounded routed excerpts and explicit proof/restriction boundaries.
- `file_map.json` is machine-only; `file_map.summary.json` is the bounded startup map.
- Patch planning no longer requires a Healer update for every arbitrary change.

## Governance and documentation

- Active detailed `KERNEL.md` created with all 28 required operational sections.
- Full v171.47 Kernel preserved unchanged.
- Single `START_HERE.md` startup order retained.
- Kernel SSOT, restoration NORM, keyword/anchor map, route map and startup route created.
- AI law lock chain synchronized under direct user permission.
- Three Healer guards protect against demotion, drift and keyword loss.
- Broken `navigation only` assertions were replaced with behavior guards.

## Validation

- Python compileall: passed.
- New v171.62 behavior tests: 8 passed.
- Operator Kernel + governance test set: 26 passed.
- Governance entrypoint guard: passed.
- AI Archive Laws integrity guard: passed.
- Canon guard: passed.

All checks are `LOCAL_AUX_CHECK_ONLY`; fresh GitHub CI is not claimed.

## Scope boundary

No frontend or backend application runtime was changed. Therefore frontend build and screenshot proof were not required for this Kernel-only restoration pass. Live Telegram, TonConnect, TonProof and real transaction evidence remain open.

## Cycle and next archive

- Cycle 1573 remains frozen/not complete.
- Cycle 1574 was not started.
- Next safe archive: `EFHC_Bot_v171_63.zip`.
- Next pass: close route-backed visual proof and live TON boundaries for cycle 1573.
