# Change report — v168_51 FAQ / tunnel / routes / admin

## HEAD

Input HEAD: `v168_50_cycle_1266_faq_routes_buttons_repair`.

## Changes

- Replaced button/pill FAQ shell with a vertical `details/summary` tree.
- Added `FaqVerticalTree` component.
- Kept FAQ as a Profile tab and added a visible full FAQ entry.
- Added `ops/local/tunnel_probe.ps1` for Cloudflare quick-tunnel diagnosis.
- Added `ops/local/check_frontend_routes.py` route target checker.
- Added `AdminAppButtonGrid` and moved admin root navigation toward a
  clear app launcher model.
- Removed the explicit release-proof text block from admin root.
- Added audit and guard for this correction.

## Checks

- `npm ci --no-audit --no-fund --progress=false`: passed.
- `npx tsc --noEmit --pretty false`: passed.
- `python3 ops/local/check_frontend_routes.py`: passed.
- `pytest tests/architecture/test_faq_routes_admin_guard.py`:
  passed, 4 tests.
- `compileall ops/local tests/architecture`: passed.

## Not claimed

- Docker runtime proof was not run in this environment.
- Cloudflare tunnel success is not claimed; the tunnel issue requires
  user-side network / Cloudflare quick tunnel proof.
