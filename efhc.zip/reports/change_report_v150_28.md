# Change report v150_28

Source log: logs_59131187894.zip

## Fixed

1) Repo-wide bans
- Removed unsafe report with forbidden tokens written подряд.
- Added safe report: reports/alias_sanitation_report_v150_28.md

2) users.available_kwh
- Fixed mirror column type to Numeric(30,8).
- Computed expression now CAST(... AS numeric(30,8)).

3) payment_intents confirm / tests monkeypatch
- watcher_service теперь вызывает wallets_service.credit_user_from_bank.
- wallets_service реэкспортирует transactions_service.credit_user_from_bank.

## Files changed

- backend/app/models/user_models.py
- backend/app/services/watcher_service.py
- backend/app/services/wallets_service.py
- reports/alias_sanitation_report_v150_28.md
- reports/CI_FIXES_INTERNAL_LOG.md
- EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md
- reports/change_report_v150_28.md

## Notes

- ZIP собран FLAT.
- Cache dirs excluded.
