# Change report v168_78 — cycle 1280 panel activation CTA

## HEAD

Input HEAD:

`EFHC_Bot_v168_77_cycle_1279_panels_layout.zip`

## Cycle

1280 — panel activation CTA.

## What changed

- Panels activation CTA now has a guarded `100 EFHC` marker.
- Panels activation note explains the debit order:
  bonus first, then main.
- UI availability check uses bonus plus main balance, not main only.
- New locale keys were added for all active frontend locales.
- A dedicated architecture guard was added.

## Files changed

- `frontend/src/pages/panels.tsx`
- `frontend/src/styles/globals.css`
- `frontend/public/locale/*.json`
- `tests/architecture/test_panel_activation_cta.py`
- `docs/audits/FRONTEND_CYCLE_1280_PANEL_ACTIVATION_AUDIT_V168_78.md`
- `reports/generated/frontend_cycle_1280_panel_activation_v168_78.json`

## What was not changed

- Backend.
- Database.
- Migrations.
- Payment logic.
- Panel economy.
- Bottom navigation.

## Verification

- `python3 ops/local/check_frontend_routes.py`
- `python3 -m compileall -q ops/local tests/architecture`
- targeted `pytest`
- `npm ci`
- `tsc --noEmit`
- locale JSON validation
- `unzip -t` on the release ZIP

GitHub CI and Docker runtime proof are not claimed.
