# Change report v150_30

## Цель

- Канон approve withdraw: обязательный idempotency_key.
- Идемпотентный повтор approve с тем же ключом.
- Обновить concurrency тесты под новый контракт.

## Изменения

### Backend

- backend/app/services/withdraw_service.py
  - approve_withdraw_request теперь требует actor_tg_id и idempotency_key.
  - Добавлены helpers:
    - _fetch_withdraw_request()
    - _admin_approve_idem_hit()
  - Добавлен SCHEMA_ADMIN.

### Tests

- tests/test_concurrency_withdraw_double.py
  - concurrency approve теперь передаёт idempotency_key.
  - Добавлен тест идемпотентного повторного approve.
