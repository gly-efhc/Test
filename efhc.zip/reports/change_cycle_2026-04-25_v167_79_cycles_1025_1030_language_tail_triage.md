# Change report — v167_79 — cycles 1025-1030

## Scope

Cycles `1025-1030` continue the language extension range `983-1040`.
The pass also repairs the release artifact size bug reported by the
user.

## User question answered

`identical-to-English tail` is the measured remainder of non-English
locale values that are exactly the same as the English baseline after
approved technical tokens are ignored.

It is not the same as a missing key. The key exists, but its value still
looks like English fallback.

## Archive size bug

The previous `v167_78` archive was about `14 MB`. Nearby artifacts were
about `4.8 MB`. Healer already described this systematic class as
`HEAL-ARCH-001`: stored ZIP compression failure.

Treatment for this release:

- rebuilt with explicit deflate compression;
- kept the archive FLAT;
- checked for cache/log/nested ZIP leakage before delivery;
- recorded slow unpack / timeout risk as `HEAL-ARCH-002`.

## Completed cycles

### 1025

Approved technical identical-value triage and user explanation.

Deliverables:

- `ops/i18n/identical_to_english_allowlist.json`;
- externalized allowlist use in `audit_identical_to_english.js`;
- `docs/audits/IDENTICAL_TO_ENGLISH_TAIL_EXPLAINED_1025.md`;
- `docs/audits/ARCHIVE_SIZE_BUG_REPAIR_1025.md`.

### 1026

Admin/operator identical-value triage.

Deliverable:

- `docs/audits/ADMIN_OPERATOR_IDENTICAL_VALUE_TRIAGE_1026.md`.

### 1027

Player money-path identical-value triage.

Deliverable:

- `docs/audits/PLAYER_MONEYPATH_IDENTICAL_TRIAGE_1027.md`.

### 1028

Profile and wallet identical-value triage.

Deliverable:

- `docs/audits/PROFILE_WALLET_IDENTICAL_TRIAGE_1028.md`.

### 1029

FAQ and help identical-value triage.

Deliverable:

- `docs/audits/FAQ_HELP_IDENTICAL_TRIAGE_1029.md`.

### 1030

Notification/template identical-value triage.

Deliverable:

- `docs/audits/NOTIFICATION_TEMPLATE_IDENTICAL_TRIAGE_1030.md`.

## Local helper checks

- `node ops/i18n/audit_identical_to_english.js`
  - expected non-zero exit because residual findings remain;
  - findings remain routed to cycles `1031-1040`.
- `node ops/i18n/audit_locale_placeholders.js`
  - placeholder parity remains the active guard.

## GitHub CI

GitHub CI was not run by the assistant. No green CI claim is made.

## Next cycle

Cycle `1031` — German residual tail repair pass.

## Final packaging check

The interrupted packaging step was completed in the follow-up pass.
The delivered `v167_79` ZIP is rebuilt with deflate compression, remains
FLAT, and was verified with `unzip -tq` before delivery.

The size returned to the normal release-artifact range instead of the
`v167_78` stored/no-compression anomaly.
