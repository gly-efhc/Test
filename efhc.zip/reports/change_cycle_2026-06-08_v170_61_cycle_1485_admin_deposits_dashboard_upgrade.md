# CHANGE CYCLE 2026-06-08 / v170.61 / cycle 1485

## Cycle

1485 — Admin Deposits Dashboard Upgrade

## Summary

`/admin/efhc-deposits` now has a read-only Grafana-like dashboard layer
for runtime summary, automation health, exception backlog and money-path
operator order.

## Added

- `frontend/src/components/admin/AdminDepositsDashboardRuntime.tsx`
- `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`
- `docs/NORM/ADMIN_DEPOSITS_DASHBOARD_GRAFANA_ELEMENT_ANALYSIS.md`
- `docs/cycles/WORK_CYCLES_1485_ADMIN_DEPOSITS_DASHBOARD_UPGRADE.md`
- `reports/generated/admin_deposits_dashboard_upgrade_v170_61.json`
- `tests/architecture/test_admin_deposits_dashboard_upgrade.py`

## Changed

- `frontend/src/pages/admin/efhc-deposits.tsx`
- `frontend/src/styles/globals.css`
- kernel, map, cycle, report and test manifests

## Safety

No backend, economy, OpenAPI, dependency, lock-file, CI/workflow,
wallet, money-flow or write-flow changes.

Grafana and Песочница remain reference-only layers.
