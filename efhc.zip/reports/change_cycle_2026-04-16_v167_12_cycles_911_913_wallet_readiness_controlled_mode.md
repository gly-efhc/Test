# EFHC Bot — Change Report

- Cycle pack: 911–913
- Scope: backend wallet readiness flags, CTA binding, manual EFHC deposits controlled mode.
- Backend now exposes wallet_ready / wallet_blocked / action_allowed / action_denied / readiness_state / primary_cta in hub/browser-shop truth-layer.
- Launcher and user-facing shells now bind CTA to backend readiness truth instead of local-only wallet guesses.
- Manual EFHC deposits remain explicitly marked as controlled_mode until release review.
