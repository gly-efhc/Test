# Change Cycle v153_15 — FAQ Panels and Energy for DE/FR/ES

Date: 2026-03-08

## What changed
- Added item-level FAQ translations for `8.1` Panels to:
  - de
  - fr
  - es
- Added item-level FAQ translations for `9.1` Energy generation to:
  - de
  - fr
  - es
- Kept existing fallback order:
  - active language
  - en
  - ru

## Checks
- `python ops/canon_guard.py` -> OK
- targeted FAQ TypeScript compile -> OK
- `line72` on changed files -> OK

## Files
- `frontend/src/data/faq/localized.ts`
- `reports/change_cycle_2026-03-08_0315_v153_15_faq_panels_energy_de_fr_es.md`
- `reports/REPORTS_INDEX.md`
- `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`
