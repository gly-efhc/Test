# Frontend line-72 audit: cycle 006

## Scope

- This cycle focused on the heaviest remaining offenders from the prior run.
- Changes are formatting-only: line wrapping, JSX prop splitting, and safe
  string concatenation.
- No logic changes.

## Files processed (5)

1. frontend/src/pages/admin/users.tsx
2. frontend/src/pages/admin/index.tsx
3. frontend/src/pages/admin/panels.tsx
4. frontend/src/pages/admin/shop.tsx
5. frontend/src/pages/shop.tsx

## Result

- Total frontend violations now: **141**
- Files with violations now: **24**

Top remaining offenders:

- frontend/src/pages/ranks.tsx: 13 (max 142)
- frontend/src/pages/admin/referrals.tsx: 13 (max 94)
- frontend/src/pages/admin/logs.tsx: 13 (max 106)
- frontend/src/pages/lotteries.tsx: 12 (max 185)
- frontend/src/pages/admin/bank.tsx: 9 (max 117)
- frontend/src/pages/admin/withdrawals.tsx: 9 (max 113)
- frontend/src/pages/admin/tasks.tsx: 9 (max 105)
- frontend/src/pages/admin/prizes.tsx: 9 (max 102)
- frontend/src/styles/globals.css: 8 (max 125)
- frontend/src/pages/_app.tsx: 6 (max 187)

## Test exclusions

No new file exclusions were added in this cycle.

