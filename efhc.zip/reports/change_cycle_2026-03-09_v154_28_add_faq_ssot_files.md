# change_cycle_2026-03-09_v154_28_add_faq_ssot_files

- Added normative directory `faq_ssot/`.
- Added RU canonical files from uploaded SSOT sources.
- Added placeholder structures for en/uk/de/fr/es/it/tr/pl/da/hi/id/sw.
- Linked `docs/FAQ_SSOT.md`, `docs/SSOT_INDEX.md`,
  `docs/EFHC_CANON.md`, `ops/canon_rules.yaml` to the new FAQ SSOT
  files.
