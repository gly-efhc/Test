
# Change report v168_63 - original sources intake

## HEAD

Input HEAD: `EFHC_Bot_v168_62_frontend_ancient_page_sources.zip`.

## User input

The user uploaded `Первоисточники EFHC bot.zip` and asked to use the
first source documents of EFHC Bot to compare lost, removed and
distorted
functions.

## Changes

- Added original source PDFs and extracted text under
  `docs/GENERAL/ORIGINAL_SOURCES/EFHC_BOT_START/`.
- Added `INDEX.md` for the source layer.
- Added `ORIGINAL_SOURCES_100_QUESTIONS_V168_63.md`.
- Added `docs/audits/ORIGINAL_SOURCES_INTAKE_AUDIT_V168_63.md`.
- Updated `FRONTEND_PAGE_SOURCE_MAP.md`.
- Updated chat transcript and Q/A register.
- Updated master document index and reports index.

## Code

Frontend/backend code was not changed.

## Next step

The user answers the 100 questions. Then we build a loss-map and decide
what to restore, keep, delete or mark as obsolete.

