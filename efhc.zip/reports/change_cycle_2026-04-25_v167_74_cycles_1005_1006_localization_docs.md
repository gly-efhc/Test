# Change cycle — 2026-04-25 — v167_74

Cycles: 1005-1006.
Range: 983-1022 manual localization repair.
Status: completed for cycles 1005 and 1006 only.

## What changed

Cycle 1005 closed the FAQ localization consistency pass:

- added the 13-language localization scope rule to AI-layer documents;
- added the same stable rule to the language canon document;
- repaired FAQ commerce wording tails across all 13 FAQ languages;
- regenerated `frontend/src/data/faq/catalogs.ts` from SSOT JSON;
- added `ops/i18n/audit_faq_localization_consistency.py`;
- verified 20 sections and 250 Q&A items per language;
- verified markdown/json/runtime FAQ catalog consistency.

Cycle 1006 closed the notification and system template inventory:

- created localization notification/template inventory doc;
- mapped admin notifications, shop order notifications, system
  templates, outcome service, task moderation templates and admin
  templates UI;
- added `ops/i18n/audit_notifications_templates_inventory.py`;
- documented 27 bot handler files, 55 `message.answer` occurrences and
  2 `call.answer` occurrences for later manual review.

## Checks actually run

Local helper checks only, not GitHub CI:

- `python -S ops/i18n/audit_faq_localization_consistency.py`
- `python -S ops/i18n/audit_notifications_templates_inventory.py`
- `python -S ops/i18n/audit_bot_texts_parity.py`
- `python -S ops/i18n/audit__all__locale_parity.py`
- `python -m compileall` on changed Python guard scripts

No GitHub CI green claim is made in this report.

## Boundary

The localization range is not fully closed. Cycle 1007 remains next:
notification/template manual repair. Cycles 1007-1022 remain planned
until confirmed by real work and their own reports.
