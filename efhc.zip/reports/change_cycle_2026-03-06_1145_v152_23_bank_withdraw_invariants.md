# v152_23 — bank / withdraw invariants

## Scope

Следующий слой после синхронизации docs/DTO/security:
усиление смысловых тестов на банковый контур и вывод.

## Added tests

1. `tests/architecture/test_bank_runtime_invariants.py`
   - банк может уходить в минус;
   - повтор по тому же idempotency_key не даёт второй кредит;
   - пользователь не может уйти в минус.

2. `tests/architecture/test_withdraw_runtime_invariants.py`
   - withdraw использует только MAIN;
   - cancel делает refund в MAIN и не трогает BONUS;
   - статус после cancel = `CANCELED`.

## Docs sync

- пересобран `docs/TESTS_CATALOG.md` по реальному дереву `tests/**`;
- обзорные документы синхронизированы под `test files: **69**`;
- карта `MODEL → TABLE → ROUTE → TEST` дополнена
  runtime-инвариантами bank/withdraw.

## Local checks

- `python -m compileall backend/app tests`
- `python -m pytest -q tests/architecture/test_bank_runtime_invariants.py`
- `python -m pytest -q tests/architecture/test_withdraw_runtime_invariants.py`
- `python -m pytest -q tests/architecture/test_docs_ssot_sync.py`
- `python -m pytest -q tests/architecture/test_max_line_length_72.py`

## Result

Смысловые инварианты банка и вывода теперь прикрыты не только
строковыми/архитектурными guard-тестами, но и runtime-проверками.
