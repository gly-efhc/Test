# Element Authority Policy — EAM-001

1. **OWNER-approved cleanup 2026-10-18:** prior EAM machine matrix and derivative registries have been retired as stale. No current EAM machine matrix is asserted until the OWNER supplies the replacement. Direct OWNER commands and remaining CANON/SSOT/NORM retain their priority.
2. Existing owner-visible elements reuse a canonical EAM family; a new family is registered before implementation.
3. Before an owner-visible edit resolve the current owner chain: family → production source → standalone counterpart → DOM markers → CSS candidates/importance/specificity → variables/theme → semantic exceptions → protected geometry/runtime → allowed edit point.
4. Screen proximity is not ownership evidence; actual source/cascade ownership must be resolved before visual mutation.
5. CSS selectors remain inside their declared component/route/theme scope. Broad inherited-variable shortcuts are not authority.
6. Production and standalone are independent renderers and require explicit mapping when both are in scope.
7. Admin is completed and frozen; Admin source/material/geometry changes require a direct OWNER decision.
8. Financial/status semantic colors are protected from decorative recolor: credit/incoming/accrual green; debit/outgoing/spending red; done/pending/failed green/gold/red; total/main/bonus neutral/blue/gold; partial-data warning warning-gold.
9. EAM generator/resolver tools remain available for the incoming OWNER matrix, but historical generated registries must not be recreated or used as current authority. Without new input EAM resolution is unavailable; determine affected elements from live source and current theme/design registries.
10. Matrix and current registries contain current state only. Historical audits, certifications and superseded registry snapshots are not authority.
11. Raw selector/leak detector hits are evidence candidates, not final defect verdicts. A comma-scope leak is proven only when static owner evidence shows that one branch escapes the intended route/theme/component scope. Fully scoped groups and intentional bridges are not rewritten merely because a detector flags them.
12. `AMBIGUOUS` ownership/scope remains fail-closed until owner-chain proof resolves it.
13. CSS removal requires independent proof of a superseded owner: same renderer, exact selector, exact at-context and declarations fully covered by the later owner. Absence of EAM instance binding is never deletion authority.
14. Custom-property definitions, state/media/pseudo ownership and semantic exceptions are fail-closed for deletion unless independently proven safe.
15. Exact production↔standalone selector/context/declaration equality is valid static material-parity evidence, but production and standalone remain independent renderers.
16. Explicit renderer-specific material/typography frozen by current CANON is an intentional difference, not drift. Unresolved family-level owners are not promoted by parity analysis alone.

**INTERIM / AWAITING OWNER MATRIX:** удалённые устаревшие снимки не восстанавливать автоматически. Защиты runtime, текущие цветовые и design-реестры, локализации и история reports сохраняются.

## Единый CSS ownership и матрица элементов 2.0

OWNER разрешил начать последовательное объединение USER CSS-веток и Browser Shop без изменения защищённых внешних эталонов. Для одного логического элемента существует один стабильный ID; цветовая тема CT задаёт **chroma**, группа универсального дизайна — **геометрию и материал**, а финансовый/статусный контекст сохраняет собственную семантику. Специальная окраска не является разрешением создавать второй слой под содержимым или менять размеры элементов. CT03 и Admin визуально защищены.

Внешняя предоставленная OWNER `EFHC_ELEMENT_MATRIX_SCHEMA` формализует раздельные `sources`, `elements`, `design_groups`, `observations`, `findings` и `evidence`. Для новых исправлений требуется точный selector/cascade/provenance и computed CSS одного и того же дизайна/состояния по цветовым темам; STATIC SOURCE не равнозначен браузерному PASS. Схема и вспомогательные результаты её заполнения остаются **вне физического frontend release**, не становятся второй версией или обязательным startup/CI-контуром. Точечные подтверждённые исправления закрепляются постоянными регрессионными тестами.

Read-only статический инвентарь `python ops/quality/audit_css_ownership.py --root .` выявляет лишь *кандидатов* смешения CT и геометрии во всех 29 группах; результат нельзя использовать как разрешение на массовую замену CSS. Производные матрицы и runtime evidence хранятся вне immutable physical source. Унификация проводится небольшими проверенными атомарными семействами без изменения финансов, идентификации, TON, Theme03, Admin и иных protected contracts.
