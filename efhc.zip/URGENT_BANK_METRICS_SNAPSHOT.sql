BEGIN;

CREATE SCHEMA IF NOT EXISTS efhc_core;

CREATE TABLE IF NOT EXISTS efhc_core.bank_metrics_snapshot (
    id SMALLINT PRIMARY KEY DEFAULT 1,
    reserve_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    circulation_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    users_main_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    users_bonus_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    actual_mass_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    panel_spent_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    generated_kwh_d8 BIGINT NOT NULL DEFAULT 0,
    new_obligations_efhcm_d8 BIGINT NOT NULL DEFAULT 0,
    fixed_obligations_efhcm_d8 BIGINT NOT NULL DEFAULT 0,
    converted_kwh_d8 BIGINT NOT NULL DEFAULT 0,
    pending_kwh_d8 BIGINT NOT NULL DEFAULT 0,
    expected_supply_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    integrity_delta_efhc_d8 BIGINT NOT NULL DEFAULT 0,
    reserve_pct_d8 BIGINT NOT NULL DEFAULT 0,
    circulation_pct_d8 BIGINT NOT NULL DEFAULT 0,
    new_obligations_pct_d8 BIGINT NOT NULL DEFAULT 0,
    users_main_pct_d8 BIGINT NOT NULL DEFAULT 0,
    users_bonus_pct_d8 BIGINT NOT NULL DEFAULT 0,
    actual_mass_pct_d8 BIGINT NOT NULL DEFAULT 0,
    fixed_obligations_pct_d8 BIGINT NOT NULL DEFAULT 0,
    panel_spent_pct_d8 BIGINT NOT NULL DEFAULT 0,
    generated_pct_d8 BIGINT NOT NULL DEFAULT 0,
    converted_pct_d8 BIGINT NOT NULL DEFAULT 0,
    pending_pct_d8 BIGINT NOT NULL DEFAULT 0,
    integrity_pct_d8 BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
    CONSTRAINT ck_bank_metrics_snapshot_singleton CHECK (id = 1),
    CONSTRAINT ck_bank_metrics_snapshot_spent_nonnegative CHECK (panel_spent_efhc_d8 >= 0),
    CONSTRAINT ck_bank_metrics_snapshot_generated_nonnegative CHECK (generated_kwh_d8 >= 0),
    CONSTRAINT ck_bank_metrics_snapshot_converted_nonnegative CHECK (converted_kwh_d8 >= 0)
);

INSERT INTO efhc_core.bank_metrics_snapshot (id)
VALUES (1)
ON CONFLICT (id) DO NOTHING;

COMMIT;
