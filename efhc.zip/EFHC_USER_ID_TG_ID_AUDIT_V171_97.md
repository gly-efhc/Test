<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **HISTORICAL / SUPERSEDED.** Этот план или аудит сохранён для истории.
> Действующий закон: `global_id` — главный персональный идентификатор и owner;
> `tg_id` — только Telegram provider subject. Старые стадии `user_id` не являются
> текущим контрактом.

# Аудит UserId и tg_id — v171.97

Цикл: `1600`.
Исходный архив: `EFHC_Bot_v171_96.zip`.
Целевой архив: `EFHC_Bot_v171_97.zip`.

## Результат

- строк машинной матрицы: `5460`;
- файлов с употреблениями: `682`;
- реальных доменных зависимостей: `2054`;
- ORM-полей семейства `tg_id`: `32`;
- сервисных сигнатур: `336`;
- FastAPI routes: `143`;
- routes с `tg_id`: `65`.

Рост реальной доменной зависимости от `tg_id` не обнаружен.
`user_id` остаётся целевым системным владельцем, а `tg_id` — внешним
Telegram ID.

## Схема

Alembic head остаётся `0002`. `users.user_id` остаётся nullable EXPAND
полем. `users.id` сохраняет runtime ownership до отдельного доказанного
read switch.

## PostgreSQL

Реальная PostgreSQL-сверка не выполнена из-за отсутствия среды.
Historical backfill и runtime read switch запрещены.

## Следующий этап

Цикл `1601` принимает фундамент и начинает основной диапазон
`1601–1700` с Current HEAD `EFHC_Bot_v171_97.zip`.
