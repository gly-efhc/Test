---
description: Simplify only when EFHC locks and do-not-simplify areas are preserved.
---

Use the EFHC Agent Skills Adapter before acting.

Read `AGENTS.md` and `docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md` first. Apply the
EFHC threshold model, preserve AI Archive Laws / SSOT / NORM, and do not create
`SPEC.md` or `tasks/plan.md` by default.

Do not claim GitHub CI green, live proof, release-ready or production-ready
without current evidence.

Command intent: Simplify only when EFHC locks and do-not-simplify areas are preserved.
