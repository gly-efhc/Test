---
description: Run EFHC go/no-go review without production-ready claim unless evidence exists.
---

Use the EFHC Agent Skills Adapter before acting.

Read `AGENTS.md` and `docs/AI/AI_AGENT_SKILLS_EFHC_ADAPTER.md` first. Apply the
EFHC threshold model, preserve AI Archive Laws / SSOT / NORM, and do not create
`SPEC.md` or `tasks/plan.md` by default.

Do not claim GitHub CI green, live proof, release-ready or production-ready
without current evidence.

Command intent: Run EFHC go/no-go review without production-ready claim unless evidence exists.

Never claim release-ready without current evidence.
Never claim production-ready without current evidence.
