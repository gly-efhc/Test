# EFHC Bot — Реестр проявившихся ошибок CI/pytest и предохранителей (SSOT-команда)

Дата обновления: 2026-02-28

Назначение: общий командный документ. Содержит **только классы ошибок, которые
фактически проявлялись в реальных прогонах CI/pytest**, и предохранители,
которые не дают им возвращаться.

---

## 0) Правило пользования документом

- Логи записываются 1:1 (как есть): excerpt из CI/traceback
  не редактируются и могут содержать любые строки.
- Каждая запись в реестре должна иметь подтверждение: `logs_*.zip` / CI-run.
- Фиксы выполняются **минимально** и **канонично**, без изменения бизнес-логики,
  если это не требуется для устранения падения.
- Предохранители (guards) должны быть автоматическими и воспроизводимыми.

---

## AA. Локальные падения (аудит ZIP в чате)

Примечание: эти записи подтверждены выводом команд в этом
чате (pytest/npm). При появлении соответствующих падений в
GitHub Actions, дополнить ссылкой на `logs_*.zip`.

### AA1. `pytest` падал на правиле `MAX_LEN=72`

**Симптом (pytest):**

```
FAILED tests/architecture/test_max_line_length_72.py
backend/app/core/config_core.py:128: L=84 > 72
```

**Причина:** строка описания `Field(... description=...)` длиннее 72.

**Фикс:** перенос строки через конкатенацию строк в `description=(...)`.

### AA2. `npm run build` падал на TypeScript типах

**Симптом (Next build):**

```
Type error: Property 'items' does not exist on type '{}'.
./src/components/DepositModal.tsx:49:27
Type error: Property 'wallets' does not exist on type '{}'.
./src/components/ProfileModal.tsx:98:25
```

**Причина:** вызовы `apiRequest()` без generic-типа приводили к
`{}` и ломали доступ к полям ответа.

**Фикс:** добавить типы ответов и вызывать
`apiRequest<...>(...)`.

### AA3. `npm run build` падал на несовпадении props

**Симптом (Next build):**

```
Property 'hint' does not exist on type ...
./src/pages/shop.tsx:307:17
```

**Фикс:** заменить `hint=` на каноничное `detail=`.

---
---

## A. Ошибки CI-профиля/раннера (workflow), не связанные с бизнес-логикой

### A1. `pytest: command not found` (не установлен pytest в CI)
**Симптом:** `/bin/sh: pytest: command not found` (exit code 127).  
**Причина:** pytest не установлен в окружении workflow.  
**Предохранитель (MUST):**
- В workflow гарантированно устанавливать `pytest` (и плагины) после зависимостей проекта:
  - `pip install -U pytest pytest-asyncio`

### A2. Pytest exit code 5 (тесты «не найдены» из-за неверной рабочей директории)
**Симптом:** `pytest` завершается с code 5 (0 tests collected).  
**Причина:** запуск pytest не из корня проекта, где лежит `tests/`.  
**Предохранитель (MUST):**
- Запускать `pytest -q` из корня проекта (где `tests/`).
- `PYTHONPATH` должен включать корень проекта, если импорты вида `backend.app...` используются в тестах.

### A3. Недостающие runtime/test зависимости в CI (PyJWT / pytest-asyncio / aiosqlite)
**Симптомы:**
- `ModuleNotFoundError: No module named 'jwt'` (нужен пакет `PyJWT`)
- `PytestUnknownMarkWarning: Unknown pytest.mark.asyncio` (нужен `pytest-asyncio`)
- `ModuleNotFoundError: No module named 'aiosqlite'`
**Предохранитель (MUST):**
- В CI ставить явный «стек тестов» (минимум): `pytest`, `pytest-asyncio`, `PyJWT`, `aiosqlite`,
  либо включить их в `backend/requirements.txt` как обязательные зависимости тестов.


## B. Ошибки A2 (Frontend build) и правило про lockfile

### B1. `package-lock.json` с internal mirror ломает `npm ci`
**Симптом (CI/pytest):** `npm ci` падает (401/timeout) из-за `resolved` на internal/artifactory/mirror
(например, `applied-caas-gateway...`).  
**Предохранитель (MUST):**
- Для A2.2 `package-lock.json` **должен** содержать `resolved` только на `https://registry.npmjs.org/...`.
- Lockfile пересоздаётся в среде, где registry контролируется (CI/локально):
  - `npm config set registry https://registry.npmjs.org/`
  - `rm -f package-lock.json && rm -rf node_modules`
  - `npm install @tonconnect/ui-react@2.4.0 --save-exact`
  - `npm ci && npm run build`
- Перед публикацией: grep-guard на запрет internal mirrors в `frontend/package-lock.json`.

### B2. Запрет на vendor/file:-подмены и отключение проверок ради сборки
**Симптом:** сборка «проходит» за счёт подмены источника зависимости или обхода quality-checks.  
**Предохранитель (MUST NOT):**
- Запрещены `file:` зависимости, `frontend/vendor/*` как подмена npm-пакета,
и отключение typecheck/eslint для прохождения сборки.

---

## C. Ошибки импортов/экспортов (pytest падает на collection)

### C1. Несуществующий импорт AdminService
**Симптом:** `ModuleNotFoundError: backend.app.services.admin_service`
из `backend/app/services/__init__.py`.  
**Предохранитель (MUST):**
- Экспорт `AdminService` должен идти из каноничного фасада (например, `admin.admin_facade`),
и путь должен соответствовать реальным файлам.

### C2. Фасад импортирует символы, которых нет (AdminLotteriesService / LotteriestatusSummary)
**Симптом:** `ImportError: cannot import name ...` из `admin_lotteries_service.py`.  
**Предохранитель (MUST):**
- В сервисе должны существовать ожидаемые фасадом имена (через алиасы-экспорты,
  без смены поведения).
- `__all__` должен отражать реальные публичные экспорты.

### C3. Pagination отсутствует там, где её ожидают (`admin_logging.py`)
**Симптом:** `ImportError: cannot import name 'Pagination' ... admin_logging`.  
**Предохранитель (MUST):**
- Если фасад импортирует `Pagination` — он обязан существовать и экспортироваться.

---

## AE. CI падение: Alembic не может импортировать `backend.*` при запуске из каталога `backend/`

**Симптом (GitHub Actions, alembic upgrade head):**

```
ModuleNotFoundError: No module named 'backend'
.../extracted/backend/migrations/versions/0001_init.py
```

**Причина:** workflow запускает Alembic из `extracted/backend`. В таком режиме
импорт `backend.migrations...` не работает, потому что `backend` перестаёт быть
пакетом верхнего уровня.

**Фикс:** в миграциях использовать импорт без префикса `backend.`:
`migrations.lib.safe` вместо `backend.migrations.lib.safe`.

**Excerpt из CI (сокращено):**

```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from backend.migrations.lib.safe import (
ModuleNotFoundError: No module named 'backend'
```

---

### C4. Ожидаемый экспорт `services` из `backend.app` отсутствует
**Симптом:** `ImportError: cannot import name 'services' from 'backend.app'`
при `from backend.app import services`.  
**Предохранитель (MUST):**
- В `backend/app/__init__.py` должен существовать экспорт `services`
  (желательно ленивый через `__getattr__`), чтобы импорт не тянул тяжёлые зависимости на import-time.

### C5. Фасад импортирует символы, которых нет в `admin_bank_service.py` (AdminBankService/*DTO/*Request)
**Симптом:** `ImportError: cannot import name 'AdminBankService' ... admin_bank_service` (и связанные DTO/Request).  
**Предохранитель (MUST):**
- `admin_bank_service.py` должен экспортировать ожидаемые фасадом имена
  (через алиасы на существующие классы, без изменения поведения) и поддерживать `__all__`.


## D. Ошибки конфигурации/Settings

### D1. Отсутствует `parsed_ref_bonus_thresholds`
**Симптом:** `AttributeError: Settings has no attribute parsed_ref_bonus_thresholds`.  
**Предохранитель (MUST):**
- Любые методы, которые вызываются сервисами, должны быть частью Settings SSOT
и покрываться тестом, который импортирует сервис без выполнения бизнес-логики.

---

## E. База/SQLite vs Postgres (массовые падения тестов)

### E1. SQLite не поддерживает `FOR UPDATE` / `SKIP LOCKED`
**Симптом:** `sqlite3.OperationalError: near "FOR": syntax error`.  
**Предохранитель (MUST):**
- Если CI workflow гоняет SQLite, код в ветках тестов должен избегать
Postgres-only конструкций или иметь sqlite-safe ветвление.
- Либо CI должен быть явно Postgres-only (тогда sqlite smoke тесты отключаются канонично).
Важно: это должно быть зафиксировано как единый канон CI-профиля.

### E2. SQLite не знает `now()`, Postgres cast `::numeric`, и некоторые CTE-вставки
**Симптомы:**
- `no such function: now`
- `unrecognized token: ":"` (из-за `::numeric`)
- `near "INSERT": syntax error` в CTE-INSERT.
**Предохранитель (MUST):**
- Использовать параметризованный `utcnow()` на уровне Python, а не `now()` в SQL.
- Избегать `::numeric` в sqlite-профиле.
- Не использовать Postgres-only SQL-шаблоны в sqlite тестовом профиле.

---

## F. Ошибки валидации кошельков (TON)

### F1. Некорректная эвристика валидатора (например, запрет символа) ломает валидные адреса
**Симптом:** `InvalidWalletAddress: INVALID_WALLET_ADDRESS` для валидных TON-адресов.  
**Предохранитель (MUST):**
- Валидатор должен проверять формат TON-адреса корректным способом (тон-формат),
а не через запрет отдельных символов.

---

## G. Ошибки типов времени (Panels)

### G1. Сравнение `str` и `datetime`

### G2. В панелях начинается транзакция поверх уже начатой Session
**Симптом:** `PanelPurchaseError: A transaction is already begun on this Session.`
в тестах панелей.  
**Предохранитель (MUST):**
- Сервис панелей не должен открывать вложенную транзакцию поверх уже открытой.
- Использовать единый шаблон: либо сервис управляет транзакцией, либо вызывающий код,
  но не оба одновременно (зафиксировать в SSOT).



**Симптом:** `TypeError: '>' not supported between instances of 'str' and 'datetime'`.  
**Предохранитель (MUST):**
- Время в сервисах должно быть tz-aware UTC datetime (через `utcnow()`),
а входные строки времени должны парситься в datetime до сравнений.

---

## H. Миграции

### H1. Smoke-тест миграций падает на `NoneType`
**Симптом:** `TypeError: expected string or bytes-like object, got 'NoneType'`.  
**Предохранитель (MUST):**
- Тестовый режим миграций должен иметь чётко определённый источник DB URL
(или sqlite URL), и код не должен пытаться regex/parse по `None`.


### H2. SQLite падает на DDL с `SCHEMA` (Postgres-only)
**Симптом:** `sqlite3.OperationalError: near "SCHEMA": syntax error`
в smoke-тесте миграций на sqlite.  
**Предохранитель (MUST):**
- Либо CI-профиль миграций для sqlite должен использовать sqlite-safe DDL,
  либо smoke-тест миграций должен быть явно Postgres-only (зафиксировать в каноне CI).


---

## I. Канон запретов (grep/guard)

### I1. Запрещённые подстроки должны ловиться guard’ом
**Симптом:** сборка падает на repo-wide guards, либо запреты “проскальзывают”.  
**Предохранитель (MUST):**
- Repo-wide guard на banned substrings/identifiers обязателен.
- Любая правка должна проходить guard до запуска CI.

---


---

### I2. Line-length guard (72) ломает CI при одной длинной строке
**Симптом:** падение архитектурного теста/guard на строках длиной > 72 (пример: `line too long`).  
**Предохранитель (MUST):**
- Любые строки > 72 символов переносить (без изменения логики).
- Guard должен указывать файл/строку, а фиксы не должны использовать `(x as any)` ради «короткости».


## J. Concurrency / идемпотентность (реальные падения)

### J1. UNIQUE на `idempotency_key` в логах переводов (гонка)
**Симптом:** `sqlite UNIQUE constraint failed: efhc_transfers_log.idempotency_key`
в concurrency-тестах (два параллельных запроса пытаются вставить один и тот же ключ).  
**Предохранитель (MUST):**
- Идемпотентные операции должны обрабатывать повтор как replay без падения:
  - атомарная вставка/обновление по `idempotency_key` (UPSERT / INSERT OR IGNORE + SELECT),
  - обязательный аудит replay,
  - тест на конкурентный двойной вызов, который допускает ровно один “первичный” успех.

### J2. Инварианты обмена/вывода ломаются при конкуренции
**Симптомы:** `assert 0 == 1` (ожидали 1 успешную операцию), расхождение балансов.  
**Предохранитель (MUST):**
- Транзакционные операции exchange/withdraw должны быть атомарны и сериализуемы
  в выбранном CI-профиле (sqlite/postgres), а логика блокировок должна
  иметь sqlite-safe ветвление или единый Postgres-only профиль.

---

## K. Pytest warnings / unraisable exceptions превращаются в FAIL

### K1. `ExceptionGroup: unraisable exception warnings`
**Симптом:** тест падает из-за `ExceptionGroup: multiple unraisable exception warnings`
(обычно неосвобождённые ресурсы/соединения, исключения в `__del__`).  
**Предохранитель (MUST):**
- Все соединения/сессии/клиенты должны закрываться явным образом (context manager / finally).
- В тестах запрещать “тихие” утечки ресурсов: pytest должен оставаться зелёным
  при включённых warning-as-error режимах.

### K2. Pydantic deprecated warnings подняты до FAIL
**Симптом:** падения только из-за `pydantic.warnings.PydanticDeprecatedSince20`
(например, `GenericModel` → `BaseModel`).  
**Предохранитель (MUST):**
- Устранить использование `pydantic.generics.GenericModel` в пользу `BaseModel`
  (или обновить типы/модели до Pydantic v2-совместимого API).
- Не “глушить” warnings глобально; исправлять источник предупреждения.


## Приложение: подтверждённый свежий пример (последний лог)
`logs_58693507222.zip`: подтверждает классы E1/E2 + J1/J2 + K1/K2 + H2 + G2.


## Приложение: подтверждённый свежий пример (новый лог)
`logs_58695322208.zip`:

### P1 — SQLite несовместимость SQL в payment_intents_service
**Симптомы:**
- `sqlite3.OperationalError: unrecognized token: ":"` из-за `::numeric`
- `sqlite3.OperationalError: near "INSERT": syntax error` из-за data-modifying CTE
  (`WITH ... INSERT ... ON CONFLICT ... RETURNING`) в SQLite.

**Фикс (DONE):**
- Для SQLite убрать `::numeric` (использовать выражение без кастов).
- Для SQLite заменить CTE+RETURNING на схему `INSERT OR IGNORE` + `SELECT`.

### W1 — Неверная валидация TON адреса (ложный запрет букв E/e)
**Симптом:**
- `InvalidWalletAddress: INVALID_WALLET_ADDRESS` на валидном адресе, содержащем `E`.

**Фикс (DONE):**
- Удалить запрет на наличие `E/e` в строке адреса.
  Адрес TON — base64url, буквы допустимы.

### P2 — PydanticDeprecatedSince20 (GenericModel)
**Симптом:**
- тесты падают только на `pydantic.warnings.PydanticDeprecatedSince20`
  из-за `pydantic.generics.GenericModel`.

**Фикс (DONE):**
- `CursorPage(GenericModel, Generic[T])` → `CursorPage(BaseModel, Generic[T])`
  и убрать импорт `GenericModel`.


## CANON: CI DB PROFILE

**MUST:** CI DB profile = Postgres-only.

**MUST NOT:** SQLite in CI (tests/workflow) is forbidden.


---

## P-POSTGRES-ONLY / Alembic SSL mode mismatch (CI local Postgres без SSL)

**Run:** `logs_58700796381.zip`  
**Симптом (excerpt):**
```
psycopg.OperationalError: connection failed: connection to server at "127.0.0.1", port 5432 failed:
server does not support SSL, but SSL was required
```
**Root cause:** `backend/migrations/env.py` принудительно добавлял `sslmode=require` для любого non-sqlite URL, даже для `localhost`.  
**Fix:** добавлять `sslmode=require` только если хост не `localhost/127.0.0.1/::1` и параметр ещё не задан.

---

## T-PYTEST / IndentationError в helper `_init_sqlite_schema` (после перехода на Postgres-only)

**Run:** `logs_58700796378.zip`  
**Симптом (excerpt):**
```
File ".../tests/test_concurrency_exchange_all.py", line 53
  @event.listens_for(engine.sync_engine, "connect")
IndentationError: unexpected indent
```
**Root cause:** в нескольких тестах блок SQLite-init остался “обрубленным”: после `pytest.fail(...)` шёл неиндентированный код.  
**Fix:** для Postgres-only канона заменить `_init_sqlite_schema(...)` на 3 строки: `pytest.fail(...)` + `return`, без дальнейшего кода.


---

## CI Failure: logs_58702480076 (compileall)

**Symptom (excerpt):**

```text
2026-02-26T17:32:23.3594249Z *** Error compiling 'extracted/backend/migrations/env.py'...
2026-02-26T17:32:23.3595407Z Sorry: IndentationError: expected an indented block after 'if' statement on line 84 (env.py, line 85)
2026-02-26T17:32:23.3662990Z ##[error]Process completed with exit code 1.
```

**Root cause:** `backend/migrations/env.py` — broken indentation and duplicate assignment in sslmode block.

**Fix:** normalize sslmode-injection block for localhost/non-localhost and remove duplicate `if`/bad assignment.

**Status:** fixed in patch13.

---

## CI / flake8: массовые ошибки lint (F821/F722/F811) — logs_58704053518.zip

**Symptom (excerpt):**
```
backend/app/bot/handlers/balance_handlers.py:61:19: F821 undefined name 'sender'
backend/app/bot/handlers/ranks_handlers.py:102:15: F821 undefined name 'tg_id'
backend/app/routes/admin_routes.py:73:17: F722 syntax error in forward annotation '^(bank_to_user|user_to_bank)$'
backend/app/bot/states.py:586:5: F811 redefinition of unused '_set' from line 578
```

**Root cause:**
- handlers использовали несуществующие переменные (`sender`, `tg_id`, `t`),
- `admin_routes.py` использовал `constr(...pattern=...)` под `from __future__ import annotations`,
  что ломало парсер forward-annotations в flake8,
- в `states.py` был дублирован метод `_set`,
- ряд модулей имели реальные опечатки/недостающие импорты.

**Fix (patch15):**
- handlers: ввели `sender = message.from_user`, `tg_id = int(message.from_user.id)`, импортировали `t`,
- `admin_routes.py`: заменили `constr(...)` на `Field(..., pattern=...)`,
- `states.py`: удалили дублирование `_set`, восстановили fallback в `_get`,
- исправлены реальные опечатки/импорты (res_u→res, bank_id init, Request imports, timezone, datetime, и т.д.),
- добавлен `.flake8` с каноничным смысловым профилем:
  `select=E9,F7,F82` + `extend-ignore=F822`.

**Status:** fixed in patch15.



## AB. CI падение: отсутствует `project.zip` в корне репозитория

**Симптом (GitHub Actions):** шаг распаковки падает до любых guard/pytest/npm.

**Excerpt (logs_58712857957.zip / `canon/7_Unzip project.zip.txt`):**
```
2026-02-26T19:03:51.5530823Z   LD_LIBRARY_PATH: /opt/hostedtoolcache/Python/3.11.14/x64/lib
2026-02-26T19:03:51.5531115Z ##[endgroup]
2026-02-26T19:03:51.5603815Z ERROR: project.zip not found in repo root
2026-02-26T19:03:51.5616962Z ##[error]Process completed with exit code 1.
```

**Причина:** в корне репозитория нет файла `project.zip` (часто загружен/закоммичен ZIP с другим именем, например `EFHC_Bot_...zip`, либо файл лежит не в корне).

**Каноничное действие (MUST):**
- в корне репозитория должен лежать **ровно один** архив **с именем** `project.zip` (не папка, не другой путь).

**Предохранитель (рекомендуется):**
- в `.github/workflows/ci.yml` добавить fallback: если `project.zip` отсутствует, попытаться найти `EFHC_Bot_*.zip` и скопировать в `project.zip`, затем продолжать (с явным логом). Это не ослабляет канон, а делает CI самовосстанавливающимся при человеческой ошибке.


## AC — CI FAIL: guard bans false-positive in binary assets (png)

**Дата:** 2026-02-26  
**Симптом (GitHub Actions):** падение шага "Guard grep bans (repo-wide in extracted)" на случайном совпадении `\buid\b` внутри `frontend/public/skins/1.png`.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- \buid\b: ./frontend/public/skins/1.png @ 53039
##[error]Process completed with exit code 1.
```

**Причина:** guard в CI сканировал **все** файлы и декодировал бинарные как текст, поэтому случайные байты в PNG могли совпасть с banned-паттерном.

**Фикс (канон):** в workflow использовать ripgrep с флагом `-I` (ignore binary) и не сканировать бинарные файлы на banned-токены.
**Примечание:** pytest-guard `tests/architecture/test_forbidden_identifiers_repo.py` уже исключает бинарные суффиксы (png/jpg/woff и т.д.) и остаётся источником истины внутри `project.zip`.


### AD) CI FAIL: Canon bans scan обнаружил запрещённую подстроку `tg` + `Id` — 2026-02-26

Источник: `logs_58716260680.zip` → шаг `Canon bans scan (text-only)`.

Excerpt (сокращено):
```
- banned_ids: extracted/frontend/src/lib/admin.ts ... getAdminTg" + "Ids() ...
- banned_ids: extracted/frontend/src/pages/_app.tsx ... isAdminTg" + "Id ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/logs.tsx ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/panels.tsx ... setTg" + "Id ...
```

Fix (в ZIP v147_45):
- Удалены все вхождения подстроки `tg` + `Id` (любой регистр) во фронтенде.
- Переименование на каноничный `tg_id` (snake_case):
  - getAdminTg" + "Ids → get_admin_tg_ids
  - isAdminTg" + "Id → is_admin_tg_id
  - setTg" + "Id → set_tg_id

Проверки локально: repo-wide bans scan (text-only) — PASS.


## AF — CI: Alembic не находит модуль helpers при загрузке ревизии 0001_init — 2026-02-26

Источник: `logs_58718278834.zip` → шаг `Alembic upgrade head (Postgres)`.

Excerpt (сокращено):
```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from migrations.lib.safe import (
ModuleNotFoundError: No module named 'migrations'
```

Причина:
- Ревизии Alembic загружаются как отдельные модули, и импорт helpers должен быть устойчивым к текущей рабочей директории.

Fix (в ZIP v147_47):
- В `backend/migrations/versions/0001_init.py` добавлена гарантия, что корень проекта (extracted/) добавлен в `sys.path`.
- Импорты helpers переведены на `backend.migrations.lib.safe` (без зависимостей от cwd).

## AG — 2026-02-26 — CI: Alembic init migration падает на ensure_table_with_basics(schema=...)

**Симптом (GitHub Actions):**
```
TypeError: ensure_table_with_basics() got an unexpected keyword argument 'schema'
```

**Причина:**
`backend/migrations/versions/0001_init.py` вызывает `ensure_table_with_basics(..., schema="efhc_admin")`,
а `backend/migrations/lib/safe.py` не поддерживал параметр `schema` и работал только в текущем search_path.

**Фикс:**
Добавлена schema-aware поддержка в `safe.py`:
- `table_exists/column_exists/index_exists/unique_constraint_exists` принимают `schema`
- `ensure_table/ensure_column/ensure_index/ensure_unique_constraint/ensure_table_with_basics` принимают `schema`
- DDL (`op.create_table/add_column/create_index/create_unique_constraint`) вызывается с `schema=schema`

**Статус:** patched in ZIP v147_48


### AH (2026-02-26) CI / Alembic: ensure_table_with_basics не умеет sa.Index

**Симптом (CI):** `TypeError: cannot unpack non-iterable Index object` в `backend/migrations/lib/safe.py` при обработке `indexes=[sa.Index(...)]` из `0001_init.py`.

**Причина:** helper `ensure_table_with_basics()` ожидал список кортежей `(name, [cols], unique)` и пытался распаковать `sa.Index` как кортеж.

**Фикс:** `ensure_table_with_basics()` теперь принимает и `sa.Index`, нормализует в `(name, cols, unique)` и вызывает `ensure_index()`.
## AC. CI падение: ложное срабатывание bans-guard по бинарному файлу

**Симптом (GitHub Actions):** guard-запреты падают на совпадении токена
в бинарном файле (PNG/шрифт), хотя в коде/доках нарушения нет.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- u_id: ./frontend/public/skins/1.png ...
##[error]Process completed with exit code 1.
```

**Root cause:** репо-сканер читает бинарные файлы как текст и ловит
случайные байты.

**Что помогло (Fix that worked):**
- Перевести bans-scan в режим *text-only* (игнорировать бинарники),
  либо не сканировать `frontend/public/**` и иные бинарные каталоги.

**Verification:** после исключения бинарников guard перестаёт падать на PNG.


## AD. CI падение: запрещённые алиасы tg_id в frontend

**Симптом (GitHub Actions):** bans-scan падает на подстроке tg_id во
фронтенде.

**Root cause:** в `frontend/src/**` были функции/переменные в camelCase
с фрагментом tg_id.

**Что помогло (Fix that worked):**
- Переименование на каноничный `tg_id` (snake_case) во фронтенде:
  - `frontend/src/lib/admin.ts`
  - `frontend/src/pages/_app.tsx`
  - `frontend/src/pages/admin/logs.tsx`
  - `frontend/src/pages/admin/panels.tsx`

**Verification:** bans-scan проходит, сборка двигается дальше.


## AE. CI падение: Alembic — ModuleNotFoundError из-за import path

**Симптом (GitHub Actions):** `alembic upgrade head` падает на импорте в
init-миграции.

**Excerpt (CI):**
```
ModuleNotFoundError: No module named 'backend'
```

**Root cause:** Alembic запускается не из того cwd/py-path, а ревизия
импортирует `backend.*`.

**Что помогло (Fix that worked):**
- Сделать ревизию cwd-независимой: добавлять корень проекта в `sys.path`
  перед импортами helper-функций миграций.

**Verification:** Alembic начинает исполнять upgrade(), а не падает на
import.


## AF. CI падение: Alembic — helper не принимает schema=

**Симптом (GitHub Actions):** TypeError в `ensure_table_with_basics()` при
вызове с `schema=...`.

**Root cause:** helper-функции `backend/migrations/lib/safe.py` не имели
параметра `schema`, но миграция вызывала их со schema.

**Что помогло (Fix that worked):**
- Добавить `schema: str | None = None` во все relevant helpers и
  пробрасывать `schema=` в `op.create_table/add_column/create_index/
  create_unique_constraint`.

**Verification:** Alembic проходит место с `schema=` и двигается дальше.


## AG. CI падение: Alembic — cannot unpack Index object

**Симптом (GitHub Actions):** TypeError: cannot unpack non-iterable Index
object в `ensure_table_with_basics()`.

**Root cause:** миграция передавала `indexes=[sa.Index(...)]`, а helper
ожидал список кортежей `(name, cols, unique)`.

**Что помогло (Fix that worked):**
- В `ensure_table_with_basics()` принять оба формата:
  - `sa.Index` → нормализовать в `(ix.name, [cols], ix.unique)`
  - кортежный формат оставить как есть.

**Verification:** Alembic проходит блок indexes и продолжает upgrade().

### [AI] CI: Alembic — script_location указывает на несуществующий путь

**Симптом:** Alembic upgrade head падает с сообщением, что путь scripts folder не найден.

**Причина:** в `backend/alembic.ini` `script_location` был задан как `backend/migrations`, а CI запускает Alembic из каталога `backend/`, поэтому ожидаемый путь становится `backend/backend/migrations`.

**Что помогло (Fix that worked):**
- В `backend/alembic.ini` `script_location` изменён на `migrations` (относительно `backend/`).

**Excerpt (CI, 1:1):**
```
FAILED: Path doesn't exist: backend/migrations.  Please use the 'init' command to create a new scripts folder.
```

### [AJ] CI: Alembic — ValueError unpack uniques (sa.UniqueConstraint)

**Симптом:** Alembic upgrade head падает в ensure_table_with_basics при обработке uniques (ValueError unpack).

**Причина:** init-миграция передала uniques как sa.UniqueConstraint(...), а helper ожидал кортеж (name, cols) и пытался распаковать объект.

**Что помогло (Fix that worked):**
- backend/migrations/lib/safe.py: ensure_table_with_basics теперь принимает uniques как:
  - кортежи ("uq_name", ["col1", ...])
  - sa.UniqueConstraint(...): нормализуем в (uq.name, [col names])

**Excerpt (CI, 1:1):**
```text
ValueError: not enough values to unpack (expected 2, got 0)
```


---

## ARCHIVE_ARTIFACT_REGRESSION_AUDIT

- v148_04: из артефакта исчезли `docs/` и `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` (урезанная сборка). Восстановлено в последующих FULL сборках.


## ARTIFACT_REGRESSIONS

### [AR01] Урезание артефакта (исторический инцидент)

**Симптом:** в одном из выпусков артефакт был опубликован в «урезанном» виде (без docs/ и без реестра ошибок), что нарушает канон.
**Когда:** выпуск `EFHC_Bot_v148_04_pack_flat_min_upload_nodocs_noregistry.zip`.
**Что пропало:** каталог `docs/` и файл `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`.
**Что помогло:** введён архитектурный тест `tests/architecture/test_artifact_full_build_required.py`, который валит CI при отсутствии SSOT‑якорей.



### [BA] Alembic: UniqueConstraint empty columns in ensure_table_with_basics (payment_intents)

**Симптом:** `alembic upgrade head` падал с `RuntimeError: UniqueConstraint for payment_intents resolved to empty columns`.

**Причина:** `sa.UniqueConstraint` в миграции может быть создан строками и до привязки к Table иметь пустой `.columns`; имена колонок лежат в `._pending_colargs`.

**Что помогло:** В `backend/migrations/lib/safe.py` добавлена нормализация UniqueConstraint: если `.columns` пустой, брать колонки из `._pending_colargs`.


### [BB] 2026-02-27 CI: pytest collection failed due to IndentationError in tests (fixed)

**Symptom:** `pytest -q` interrupted during collection with multiple `IndentationError` in test files.

**Root cause:** inconsistent indentation (tabs/misaligned indents) introduced in recent test edits.

**Fix that worked:** restored and normalized indentation for 10 test modules:
- `tests/test_migrations_upgrade_head.py`
- `tests/test_panels_180_days.py`
- `tests/test_panels_active_archive.py`
- `tests/test_panels_global_id.py`
- `tests/test_panels_idempotent_create.py`
- `tests/test_payment_intent_status_owner_only.py`
- `tests/test_payment_intents_payload_unique.py`
- `tests/test_payment_intents_usdt_tx_and_confirm.py`
- `tests/test_unmatched_incoming_recording.py`
- `tests/test_wallets_connect_hardening.py`

**Verification:** `python -m compileall tests -q` passes (local).


## [BC] 2026-02-27 — Pytest collection/SQLite хвосты/async режим (v148_31)

**Симптом (CI):** pytest падал на SQLite forbidden/aiosqlite missing/async def not supported/NameError helpers.

**Причина:** legacy SQLite ветки и отсутствие глобального asyncio режима.

**Что помогло:**
- Добавлен `pytest.ini` с `asyncio_mode = auto`.
- Переписаны sqlite-ветки тестов на Postgres-only (asyncpg) и схемы `efhc_core/efhc_admin`.
- Добавлен `get_async_db_url()` в `tests/conftest.py` + создание схем перед TRUNCATE.

**Проверка:** CI `pytest -q` должен запускать тесты без ошибок collection.


### [BD] Pytest collection: missing backend module + freezegun

**Симптом (CI Step):** `pytest -q` падает на collection (`ModuleNotFoundError: backend`, `ModuleNotFoundError: freezegun`).

**Причина:** `tests/conftest.py` добавлял корень репозитория в `sys.path` только внутри фикстуры, но импорты происходят раньше — на этапе collection. Плюс `freezegun` не был закреплён в `backend/requirements.txt`.

**Что помогло (Fix that worked):**
- `tests/conftest.py`: вызов `_ensure_repo_root_on_syspath()` выполнен при импорте модуля.
- `backend/requirements.txt`: добавлен `freezegun`.

**Verification:** следующий прогон должен пройти collection и перейти к выполнению тестов.


---

## CI-FALL-2026-02-27-LOOP-ASYNC-01

**Симптом (CI step):** `canon/13_pytest -q (Postgres-only)` падает на setup.

**Root cause:** session-scoped `async_engine` создаётся/используется через разные asyncio event loop’ы (pytest-asyncio), из‑за чего asyncpg/SQLAlchemy получают Future/операции “в другом loop” и/или параллельную операцию на одном соединении.

**Fix that worked:** зафиксировать **один** asyncio event loop на всю тестовую сессию (session-scoped `event_loop`), чтобы session-scoped async fixtures жили в одном loop.

**Verification:** локально/CI: `pytest -q` проходит без `attached to a different loop` / `another operation is in progress`.

**Excerpt (1:1, 3–10 строк):**
```text
2026-02-27T10:31:33.4145191Z 
2026-02-27T10:31:33.4145318Z >   ???
2026-02-27T10:31:33.4148415Z E   RuntimeError: Task <Task pending name='Task-80' coro=<_wrap_asyncgen_fixture.<locals>._asyncgen_fixture_wrapper.<locals>.setup() running at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/pytest_asyncio/plugin.py:309> cb=[_run_until_complete_cb() at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/asyncio/base_events.py:181]> got Future <Future pending cb=[BaseProtocol._on_waiter_completed()]> attached to a different loop
2026-02-27T10:31:33.4150257Z 
2026-02-27T10:31:33.4150453Z asyncpg/protocol/protocol.pyx:369: RuntimeError
2026-02-27T10:31:33.4151216Z __________ ERROR at setup of test_panels_expires_exactly_180_days_utc __________
2026-02-27T10:31:33.4151502Z 
2026-02-27T10:31:33.4151819Z self = <AdaptedConnection <asyncpg.connection.Connection object at 0x7fba3948c220>>
```

## CI-FALL-2026-02-27-ASYNCOP-02

**Симптом (CI step):** `canon/13_pytest -q (Postgres-only)` падает на setup фикстур.

**Root cause:** конкурентное использование async БД‑ресурсов в тестах:
- DDL `CREATE SCHEMA` выполнялся в `db_clean` **для каждого теста**,
  повышая вероятность конфликтов.
- Конкурентные тесты использовали **один и тот же AsyncSession**
  внутри `asyncio.gather()`, что приводит к ошибкам asyncpg
  `another operation is in progress`.

**Fix that worked:**
1) `tests/conftest.py`: создать схемы `efhc_admin/efhc_core` один раз
   на сессию (`schemas_ready`), а в `db_clean` делать только TRUNCATE.
2) `tests/test_concurrency_*.py`: каждая конкурентная задача получает
   **свой** `AsyncSession`.

**Verification (local):**
- `pytest -q tests/architecture/test_max_line_length_72.py` ✅
- `pytest -q tests/test_build_sanity.py` ✅
- `pytest -q tests/test_no_placeholders.py` ✅

**Excerpt (1:1, 3–10 строк):**
```text
2026-02-27T10:59:16.7360788Z >                   raise translated_error from error
2026-02-27T10:59:16.7361859Z E                   sqlalchemy.exc.InterfaceError: (sqlalchemy.dialects.postgresql.asyncpg.InterfaceError) <class 'asyncpg.exceptions._base.InterfaceError'>: cannot perform operation: another operation is in progress
2026-02-27T10:59:16.7362810Z E                   [SQL: CREATE SCHEMA IF NOT EXISTS efhc_admin]
2026-02-27T10:59:16.7363273Z E                   (Background on this error at: https://sqlalche.me/e/20/rvf5)
```



## v148_35 — Пакет Variant A (фикс по аудиту)
- require_admin: X-Admin-Id не участвует в авторизации
- tests: добавлен db_migrated (alembic upgrade head) перед DB-тестами
- pytest.ini: единый конфиг + loop scope session
- pre-commit: исправлена ссылка на несуществующий тест

## CI-FALL-2026-02-27-COLLECTION-INDENT-01

- **Symptom (CI step):** `pytest -q` fails during collection (exit code 2).
- **Root cause:** `IndentationError: unexpected indent` in 2 tests.
- **Fix that worked:** Fix indentation in:
  - `tests/test_concurrency_exchange_all.py` (indent `bank_tg_id`, `user_tg_id`)
  - `tests/test_concurrency_withdraw_double.py` (indent `user_tg_id` and following)
- **Verification:** should pass collection; rerun CI logs required for SSOT.

**Excerpt (1:1):**
```
2026-02-27T13:08:23.5771174Z E     File "/home/runner/work/Test/Test/extracted/tests/test_concurrency_exchange_all.py", line 59
2026-02-27T13:08:23.5771905Z E       user_tg_id = 100001
2026-02-27T13:08:23.5772332Z E   IndentationError: unexpected indent
2026-02-27T13:08:23.5790125Z E     File "/home/runner/work/Test/Test/extracted/tests/test_concurrency_withdraw_double.py", line 59
2026-02-27T13:08:23.5790906Z E       async with Session() as db_session:
2026-02-27T13:08:23.5791378Z E   IndentationError: unexpected indent
```


## v148_40 — Пакет Audit #3 (fullfix)
- Telegram initData: исправлен алгоритм WebAppData HMAC
- Scheduler backoff: job не замерзает, reset next_allowed_at
- tests: db_migrated рекурсия устранена (schemas_ready)
- tests: PRAGMA guard на Postgres (no-op вне sqlite)
- CORS: credential-режим с явными methods/headers + origin normalize
- frontend: initDataUnsafe fallback только вне production
- ruff: line-length = 72


## v148_42 — pytest async loop binding for AsyncEngine (CI)
- **Symptom (CI step):** canon/13_pytest -q (Postgres-only) fails in
  concurrency tests.
- **Root cause:** session-scoped AsyncEngine was created by a sync fixture,
  allowing pool/connection init in a different event loop; connection reuse
  could also trigger asyncpg "another operation is in progress".
- **Fix that worked:** `tests/conftest.py`:
  - `event_loop` sets current loop via asyncio.set_event_loop(loop)
  - `async_engine` is async session fixture depending on event_loop
  - test engine uses NullPool + warmup SELECT 1 + dispose
- **Verification:** requires new CI logs after rerun.

**Excerpt (1:1):**
```
<ADD AFTER CI RERUN: logs_58824951756.zip excerpt lines here>
```

## CI-FALL-2026-02-27-LOOP-TEARDOWN-03

- Symptom: pytest -q fails during async fixture teardown (db_session close)
- Root cause: pytest-asyncio asyncio_mode=auto runs teardown in a different loop
- Fix that worked: set pytest.ini asyncio_mode=strict
- Verification: rerun CI pytest -q
- Logs (excerpt 1:1) from logs_58827640670.zip:
```text
2026-02-27T17:37:14.2033422Z 
2026-02-27T17:37:14.2033552Z >   ???
2026-02-27T17:37:14.2036037Z E   RuntimeError: Task <Task pending name='Task-107' coro=<AsyncSession.close() running at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/sqlalchemy/ext/asyncio/session.py:1016> cb=[shield.<locals>._inner_done_callback() at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/asyncio/tasks.py:891]> got Future <Future pending cb=[BaseProtocol._on_waiter_completed()]> attached to a different loop
2026-02-27T17:37:14.2037503Z 
2026-02-27T17:37:14.2037870Z asyncpg/protocol/protocol.pyx:369: RuntimeError
```

## 2026-02-27 — CI pytest async fixture handling (v148_45)

Симптом (CI step): canon/13_pytest -q (Postgres-only) — setup errors

Root cause: async fixtures declared with @pytest.fixture in STRICT mode.

Fix that worked: switch async fixtures to @pytest_asyncio.fixture and fix
_ensure_schema SQL.

Verification: compileall tests; ожидаем CI pytest PASS по setup.

Logs (excerpt 1:1): см. logs_58829966802.zip (PytestRemovedIn9Warning).



## v148_46 — SSOT tg_id unification (audit-driven)

- Symptom: SSOT/code mismatch for tg_id semantics and FK targets.
- Fix: unified tg_id queries to users.tg_id; FK tg_id -> users.tg_id; 0001 schema explicit for FKs.
- Verification: compileall backend/tests.

## CI 2026-02-27 — Audit #4 blockers (logs_58835186075.zip)

### Symptom
- CI step: canon/13_pytest -q (Postgres-only)
- async tests fail in strict asyncio mode without marker
- payment_intents sequence missing (nextval on efhc_core.payment_intents_id_seq)
- teardown loop mismatch

### Root cause
- Async tests were not marked with @pytest.mark.asyncio under strict mode.
- payment_intents.id was not configured to autogenerate ids in Postgres.
- CI doc allowed upgrading pytest stack with -U (teardown instability).

### Fix
- Mark async tests.
- Make payment_intents.id autoincrement.
- Expand Alembic sanity required list.
- Add explicit source_schema/referent_schema for FK.
- Remove -U from CI workflow canon doc (install from requirements*).

### Verification
- python -m compileall backend -q: PASS
- python -m compileall tests -q: PASS

### Logs (excerpt 1:1)
```text
2026-02-27T18:51:45.6912087Z 
2026-02-27T18:51:45.6912624Z /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/sqlalchemy/dialects/postgresql/asyncpg.py:797: ProgrammingError
2026-02-27T18:51:45.6913361Z ___________________ test_panels_expires_exactly_180_days_utc ___________________
2026-02-27T18:51:45.6913781Z async def functions are not natively supported.
2026-02-27T18:51:45.6914231Z You need to install a suitable plugin for your async framework, for example:
2026-02-27T18:51:45.6914579Z   - anyio
2026-02-27T18:51:45.6914753Z   - pytest-asyncio
2026-02-27T18:51:45.6914949Z   - pytest-tornasync
2026-02-27T18:51:45.6915138Z   - pytest-trio
2026-02-27T18:51:45.6915311Z   - pytest-twisted
```

```text
2026-02-27T18:51:45.7256377Z _____________ test_two_shop_external_intents_same_user_no_conflict _____________
2026-02-27T18:51:45.7256385Z 
2026-02-27T18:51:45.7256763Z self = <sqlalchemy.dialects.postgresql.asyncpg.AsyncAdapt_asyncpg_cursor object at 0x7f7c8732aa40>
2026-02-27T18:51:45.7258055Z operation = "WITH next_id AS (\n  SELECT nextval('efhc_core.payment_intents_id_seq') AS nid\n), ins AS (\n  INSERT INTO efhc_core....SELECT * FROM efhc_core.payment_intents\n WHERE tg_id = $1\n   AND purpose = $2\n   AND idempotency_key = $6\n LIMIT 1"
2026-02-27T18:51:45.7258360Z parameters = (9002, 'shop_external', 'TON', Decimal('2.00000000'), 'SENT', 'k1', ...)
2026-02-27T18:51:45.7258369Z 
2026-02-27T18:51:45.7258556Z     async def _prepare_and_execute(self, operation, parameters):
2026-02-27T18:51:45.7258688Z         adapt_connection = self._adapt_connection
2026-02-27T18:51:45.7258750Z     
2026-02-27T18:51:45.7258887Z         async with adapt_connection._execute_mutex:
```


## v148_51 — Alembic sanity: missing required tables

Симптом: CI step 'Sanity DB objects after alembic' reports missing efhc_core.users / efhc_core.withdraw_requests / efhc_admin.efhc_sale_packages.
Root cause: 0001 migration created tables without explicit schema.
Fix: added schema=... to ensure_table_with_basics calls in 0001.


---

## CI-58886229272 — required tables missing after alembic (sanity to_regclass)

**Симптом (CI step):**
Sanity DB objects after alembic (core_admin) → exit code 2

**Root cause:**
Часть таблиц создавалась без schema=... → попадала не в efhc_core/efhc_admin (обычно public), поэтому to_regclass('efhc_core.*') возвращал NULL.

**Fix that worked (в v149_02):**
- В 0001_init.py добавлено CREATE SCHEMA IF NOT EXISTS для efhc_core/efhc_admin.
- Вызовам ensure_table_with_basics для ключевых таблиц добавлен schema="efhc_core"/"efhc_admin" (на уровне TABLE, не Column).

**Verification:**
- python -m compileall backend -q: PASS
- Ожидаемо: Alembic upgrade head создаёт таблицы в нужных схемах; sanity-check проходит.

**Excerpt 1:1 (logs_58886229272.zip)**
```text
2026-02-28T10:02:32.1093805Z ERROR: required tables missing after alembic:
2026-02-28T10:02:32.1094361Z  - efhc_core.users
2026-02-28T10:02:32.1094744Z  - efhc_core.withdraw_requests
2026-02-28T10:02:32.1095187Z  - efhc_admin.efhc_sale_packages
2026-02-28T10:02:32.1324658Z ##[error]Process completed with exit code 2.
```


## 2026-02-28 — CI: несоответствие SSOT БД (2 схемы / 30 таблиц)

### Симптом (CI step)
- Sanity DB objects after alembic / Alembic sanity: required tables missing / TypeError schema in Column.

### Root cause
- Истина проекта: код моделей требует **30 таблиц** (по __tablename__), а 0001 создавал только часть и ещё создавал таблицы с именами, которых нет в моделях.
- В одном из циклов ошибочно добавляли `schema=...` внутрь `sa.Column(...)`, что приводило к падению Alembic:
  TypeError: Additional arguments ... got 'schema'.

### Fix that worked
- Введён SSOT-документ `docs/SSOT_DB_SCHEMAS_TABLES.md` (2 схемы / 30 таблиц).
- Полностью переписана 0001: создаёт 2 схемы и 30 таблиц по канону имён.
- Sanity в Alembic (`backend/migrations/env.py`) расширен на проверку 2 схем / 30 таблиц.
- Добавлен CI-скрипт `ops/ci_verify_db_objects.py` для отдельного шага в workflow.

### Verification
- `python -m compileall backend -q` (локально на распакованном ZIP) — PASS.

### Excerpt (1:1) из logs_58886479735.zip
```text
TypeError: Additional arguments should be named <dialectname>_<argument>, got 'schema'
```
