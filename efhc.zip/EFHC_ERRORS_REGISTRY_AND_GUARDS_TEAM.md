# EFHC Bot — Реестр проявившихся ошибок CI/pytest и предохранителей (SSOT-команда)

Дата обновления: 2026-03-02

Назначение: общий командный документ. Содержит **только классы ошибок,
которые
фактически проявлялись в реальных прогонах CI/pytest**, и
предохранители,
которые не дают им возвращаться.

## CI.logs_59111063507.zip

**Симптом**
- `TypeError: CheckConstraint.__init__() missing 1 required positional
  argument: 'sqltext'` при импорте моделей во время Alembic/pytest.

**Где**
- `backend/app/models/transactions_models.py`

**Root cause**
- В `EfhcTransferLog.__table_args__` создан `CheckConstraint(` без
  обязательного выражения `sqltext` (передали только `name=`).

**Fix (v150_16)**
- Добавлено выражение:
  `direction IN ('credit','debit','bank_to_user','user_to_bank')`.

**SEEN_AGAIN**
- Нет (первое появление по этому логу).

---

## 0) Правило пользования документом

- Логи записываются 1:1 (как есть): excerpt из CI/traceback
не редактируются и могут содержать любые строки.
- Каждая запись в реестре должна иметь подтверждение: `logs_*.zip` /
  CI-run.
- Фиксы выполняются **минимально** и **канонично**, без изменения
  бизнес-логики,
если это не требуется для устранения падения.
- Предохранители (guards) должны быть автоматическими и
  воспроизводимыми.

---

## AA. Локальные падения (аудит ZIP в чате)

Примечание: эти записи подтверждены выводом команд в этом
чате (pytest/npm). При появлении соответствующих падений в
GitHub Actions, дополнить ссылкой на `logs_*.zip`.

### AA1. `pytest` падал на правиле `MAX_LEN=72`

**Симптом (pytest):**

```
FAILED tests/architecture/test_max_line_length_72.py
backend/app/core/config_core.py:128: L=84 > 72
```

**Причина:** строка описания `Field(... description=...)` длиннее 72.

**Фикс:** перенос строки через конкатенацию строк в `description=(...)`.

### AA2. `npm run build` падал на TypeScript типах

**Симптом (Next build):**

```
Type error: Property 'items' does not exist on type '{}'.
./src/components/DepositModal.tsx:49:27
Type error: Property 'wallets' does not exist on type '{}'.
./src/components/ProfileModal.tsx:98:25
```

**Причина:** вызовы `apiRequest()` без generic-типа приводили к
`{}` и ломали доступ к полям ответа.

**Фикс:** добавить типы ответов и вызывать
`apiRequest<...>(...)`.

### AA3. `npm run build` падал на несовпадении props

**Симптом (Next build):**

```
Property 'hint' does not exist on type ...
./src/pages/shop.tsx:307:17
```

**Фикс:** заменить `hint=` на каноничное `detail=`.

---
---

## A. Ошибки CI-профиля/раннера (workflow), не связанные с бизнес-логикой

### A1. `pytest: command not found` (не установлен pytest в CI)
**Симптом:** `/bin/sh: pytest: command not found` (exit code 127).
**Причина:** pytest не установлен в окружении workflow.
**Предохранитель (MUST):**
- В workflow гарантированно устанавливать `pytest` (и плагины) после
  зависимостей проекта:
  - `pip install -U pytest pytest-asyncio`

### A2. Pytest exit code 5 (тесты «не найдены» из-за неверной рабочей директории)
**Симптом:** `pytest` завершается с code 5 (0 tests collected).
**Причина:** запуск pytest не из корня проекта, где лежит `tests/`.
**Предохранитель (MUST):**
- Запускать `pytest -q` из корня проекта (где `tests/`).
- `PYTHONPATH` должен включать корень проекта, если импорты вида
  `backend.app...` используются в тестах.

### A3. Недостающие runtime/test зависимости в CI (PyJWT / pytest-asyncio / aiosqlite)
**Симптомы:**
- `ModuleNotFoundError: No module named 'jwt'` (нужен пакет `PyJWT`)
- `PytestUnknownMarkWarning: Unknown pytest.mark.asyncio` (нужен
  `pytest-asyncio`)
- `ModuleNotFoundError: No module named 'aiosqlite'`
**Предохранитель (MUST):**
- В CI ставить явный «стек тестов» (минимум): `pytest`,
  `pytest-asyncio`, `PyJWT`, `aiosqlite`,
либо включить их в `backend/requirements.txt` как обязательные
зависимости тестов.


## B. Ошибки A2 (Frontend build) и правило про lockfile

### B1. `package-lock.json` с internal mirror ломает `npm ci`
**Симптом (CI/pytest):** `npm ci` падает (401/timeout) из-за `resolved`
на internal/artifactory/mirror
(например, `applied-caas-gateway...`).
**Предохранитель (MUST):**
- Для A2.2 `package-lock.json` **должен** содержать `resolved` только на
  `https://registry.npmjs.org/...`.
- Lockfile пересоздаётся в среде, где registry контролируется
  (CI/локально):
  - `npm config set registry https://registry.npmjs.org/`
  - `rm -f package-lock.json && rm -rf node_modules`
  - `npm install @tonconnect/ui-react@2.4.0 --save-exact`
  - `npm ci && npm run build`
- Перед публикацией: grep-guard на запрет internal mirrors в
  `frontend/package-lock.json`.

### B2. Запрет на vendor/file:-подмены и отключение проверок ради сборки
**Симптом:** сборка «проходит» за счёт подмены источника зависимости или
обхода quality-checks.
**Предохранитель (MUST NOT):**
- Запрещены `file:` зависимости, `frontend/vendor/*` как подмена
  npm-пакета,
и отключение typecheck/eslint для прохождения сборки.

---

## C. Ошибки импортов/экспортов (pytest падает на collection)

### C1. Несуществующий импорт AdminService
**Симптом:** `ModuleNotFoundError: backend.app.services.admin_service`
из `backend/app/services/__init__.py`.
**Предохранитель (MUST):**
- Экспорт `AdminService` должен идти из каноничного фасада (например,
  `admin.admin_facade`),
и путь должен соответствовать реальным файлам.

### C2. Фасад импортирует символы, которых нет (AdminLotteriesService / LotteriestatusSummary)
**Симптом:** `ImportError: cannot import name ...` из
`admin_lotteries_service.py`.
**Предохранитель (MUST):**
- В сервисе должны существовать ожидаемые фасадом имена (через
  алиасы-экспорты,
без смены поведения).
- `__all__` должен отражать реальные публичные экспорты.

### C3. Pagination отсутствует там, где её ожидают (`admin_logging.py`)
**Симптом:** `ImportError: cannot import name 'Pagination' ...
admin_logging`.
**Предохранитель (MUST):**
- Если фасад импортирует `Pagination` — он обязан существовать и
  экспортироваться.

---

## AE. CI падение: Alembic не может импортировать `backend.*` при запуске из каталога `backend/`

**Симптом (GitHub Actions, alembic upgrade head):**

```
ModuleNotFoundError: No module named 'backend'
.../extracted/backend/migrations/versions/0001_init.py
```

**Причина:** workflow запускает Alembic из `extracted/backend`. В таком
режиме
импорт `backend.migrations...` не работает, потому что `backend`
перестаёт быть
пакетом верхнего уровня.

**Фикс:** в миграциях использовать импорт без префикса `backend.`:
`migrations.lib.safe` вместо `backend.migrations.lib.safe`.

**Excerpt из CI (сокращено):**

```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from backend.migrations.lib.safe import (
ModuleNotFoundError: No module named 'backend'
```

---

### C4. Ожидаемый экспорт `services` из `backend.app` отсутствует
**Симптом:** `ImportError: cannot import name 'services' from
'backend.app'`
при `from backend.app import services`.
**Предохранитель (MUST):**
- В `backend/app/__init__.py` должен существовать экспорт `services`
(желательно ленивый через `__getattr__`), чтобы импорт не тянул тяжёлые
зависимости на import-time.

### C5. Фасад импортирует символы, которых нет в `admin_bank_service.py` (AdminBankService/*DTO/*Request)
**Симптом:** `ImportError: cannot import name 'AdminBankService' ...
admin_bank_service` (и связанные DTO/Request).
**Предохранитель (MUST):**
- `admin_bank_service.py` должен экспортировать ожидаемые фасадом имена
(через алиасы на существующие классы, без изменения поведения) и
поддерживать `__all__`.


## AF. CI падение: Alembic upgrade head падает на NameError в 0001

**Симптом (GitHub Actions, alembic upgrade head):**

```
File ".../backend/migrations/versions/0001_init.py", line 35, in <module>
  if str(_backend_dir) not in sys.path:
NameError: name '_backend_dir' is not defined
```

**Причина:** переменная `_backend_dir` использовалась до определения.

**Фикс:** определить `_backend_dir = Path(__file__).resolve().parents[2]`
до проверки `sys.path`.

**Подтверждение:** logs_58966466620.zip (canon/13).

## D. Ошибки конфигурации/Settings

### D1. Отсутствует `parsed_ref_bonus_thresholds`
**Симптом:** `AttributeError: Settings has no attribute
parsed_ref_bonus_thresholds`.
**Предохранитель (MUST):**
- Любые методы, которые вызываются сервисами, должны быть частью
  Settings SSOT
и покрываться тестом, который импортирует сервис без выполнения
бизнес-логики.

---

## E. База/SQLite vs Postgres (массовые падения тестов)

### E1. SQLite не поддерживает `FOR UPDATE` / `SKIP LOCKED`
**Симптом:** `sqlite3.OperationalError: near "FOR": syntax error`.
**Предохранитель (MUST):**
- Если CI workflow гоняет SQLite, код в ветках тестов должен избегать
Postgres-only конструкций или иметь sqlite-safe ветвление.
- Либо CI должен быть явно Postgres-only (тогда sqlite smoke тесты
  отключаются канонично).
Важно: это должно быть зафиксировано как единый канон CI-профиля.

### E2. SQLite не знает `now()`, Postgres cast `::numeric`, и некоторые CTE-вставки
**Симптомы:**
- `no such function: now`
- `unrecognized token: ":"` (из-за `::numeric`)
- `near "INSERT": syntax error` в CTE-INSERT.
**Предохранитель (MUST):**
- Использовать параметризованный `utcnow()` на уровне Python, а не
  `now()` в SQL.
- Избегать `::numeric` в sqlite-профиле.
- Не использовать Postgres-only SQL-шаблоны в sqlite тестовом профиле.

---

## F. Ошибки валидации кошельков (TON)

### F1. Некорректная эвристика валидатора (например, запрет символа) ломает валидные адреса
**Симптом:** `InvalidWalletAddress: INVALID_WALLET_ADDRESS` для валидных
TON-адресов.
**Предохранитель (MUST):**
- Валидатор должен проверять формат TON-адреса корректным способом
  (тон-формат),
а не через запрет отдельных символов.

---

## G. Ошибки типов времени (Panels)

### G1. Сравнение `str` и `datetime`

### G2. В панелях начинается транзакция поверх уже начатой Session
**Симптом:** `PanelPurchaseError: A transaction is already begun on this
Session.`
в тестах панелей.
**Предохранитель (MUST):**
- Сервис панелей не должен открывать вложенную транзакцию поверх уже
  открытой.
- Использовать единый шаблон: либо сервис управляет транзакцией, либо
  вызывающий код,
но не оба одновременно (зафиксировать в SSOT).



**Симптом:** `TypeError: '>' not supported between instances of 'str'
and 'datetime'`.
**Предохранитель (MUST):**
- Время в сервисах должно быть tz-aware UTC datetime (через `utcnow()`),
а входные строки времени должны парситься в datetime до сравнений.

---

## H. Миграции

### H1. Smoke-тест миграций падает на `NoneType`
**Симптом:** `TypeError: expected string or bytes-like object, got
'NoneType'`.
**Предохранитель (MUST):**
- Тестовый режим миграций должен иметь чётко определённый источник DB
  URL
(или sqlite URL), и код не должен пытаться regex/parse по `None`.


### H2. SQLite падает на DDL с `SCHEMA` (Postgres-only)
**Симптом:** `sqlite3.OperationalError: near "SCHEMA": syntax error`
в smoke-тесте миграций на sqlite.
**Предохранитель (MUST):**
- Либо CI-профиль миграций для sqlite должен использовать sqlite-safe
  DDL,
либо smoke-тест миграций должен быть явно Postgres-only (зафиксировать в
каноне CI).


---

## I. Канон запретов (grep/guard)

### I1. Запрещённые подстроки должны ловиться guard’ом
**Симптом:** сборка падает на repo-wide guards, либо запреты
“проскальзывают”.
**Предохранитель (MUST):**
- Repo-wide guard на banned substrings/identifiers обязателен.
- Любая правка должна проходить guard до запуска CI.

---


---

### I2. Line-length guard (72) ломает CI при одной длинной строке
**Симптом:** падение архитектурного теста/guard на строках длиной > 72
(пример: `line too long`).
**Предохранитель (MUST):**
- Любые строки > 72 символов переносить (без изменения логики).
- Guard должен указывать файл/строку, а фиксы не должны использовать `(x
  as any)` ради «короткости».


## J. Concurrency / идемпотентность (реальные падения)

### J1. UNIQUE на `idempotency_key` в логах переводов (гонка)
**Симптом:** `sqlite UNIQUE constraint failed:
efhc_transfers_log.idempotency_key`
в concurrency-тестах (два параллельных запроса пытаются вставить один и
тот же ключ).
**Предохранитель (MUST):**
- Идемпотентные операции должны обрабатывать повтор как replay без
  падения:
  - атомарная вставка/обновление по `idempotency_key` (UPSERT / INSERT
    OR IGNORE + SELECT),
  - обязательный аудит replay,
  - тест на конкурентный двойной вызов, который допускает ровно один
    “первичный” успех.

### J2. Инварианты обмена/вывода ломаются при конкуренции
**Симптомы:** `assert 0 == 1` (ожидали 1 успешную операцию), расхождение
балансов.
**Предохранитель (MUST):**
- Транзакционные операции exchange/withdraw должны быть атомарны и
  сериализуемы
в выбранном CI-профиле (sqlite/postgres), а логика блокировок должна
иметь sqlite-safe ветвление или единый Postgres-only профиль.

---

## K. Pytest warnings / unraisable exceptions превращаются в FAIL

### K1. `ExceptionGroup: unraisable exception warnings`
**Симптом:** тест падает из-за `ExceptionGroup: multiple unraisable
exception warnings`
(обычно неосвобождённые ресурсы/соединения, исключения в `__del__`).
**Предохранитель (MUST):**
- Все соединения/сессии/клиенты должны закрываться явным образом
  (context manager / finally).
- В тестах запрещать “тихие” утечки ресурсов: pytest должен оставаться
  зелёным
при включённых warning-as-error режимах.

### K2. Pydantic deprecated warnings подняты до FAIL
**Симптом:** падения только из-за
`pydantic.warnings.PydanticDeprecatedSince20`
(например, `GenericModel` → `BaseModel`).
**Предохранитель (MUST):**
- Устранить использование `pydantic.generics.GenericModel` в пользу
  `BaseModel`
(или обновить типы/модели до Pydantic v2-совместимого API).
- Не “глушить” warnings глобально; исправлять источник предупреждения.


## Приложение: подтверждённый свежий пример (последний лог)
`logs_58693507222.zip`: подтверждает классы E1/E2 + J1/J2 + K1/K2 + H2 +
G2.


## Приложение: подтверждённый свежий пример (новый лог)
`logs_58695322208.zip`:

### P1 — SQLite несовместимость SQL в payment_intents_service
**Симптомы:**
- `sqlite3.OperationalError: unrecognized token: ":"` из-за `::numeric`
- `sqlite3.OperationalError: near "INSERT": syntax error` из-за
  data-modifying CTE
(`WITH ... INSERT ... ON CONFLICT ... RETURNING`) в SQLite.

**Фикс (DONE):**
- Для SQLite убрать `::numeric` (использовать выражение без кастов).
- Для SQLite заменить CTE+RETURNING на схему `INSERT OR IGNORE` +
  `SELECT`.

### W1 — Неверная валидация TON адреса (ложный запрет букв E/e)
**Симптом:**
- `InvalidWalletAddress: INVALID_WALLET_ADDRESS` на валидном адресе,
  содержащем `E`.

**Фикс (DONE):**
- Удалить запрет на наличие `E/e` в строке адреса.
Адрес TON — base64url, буквы допустимы.

### P2 — PydanticDeprecatedSince20 (GenericModel)
**Симптом:**
- тесты падают только на `pydantic.warnings.PydanticDeprecatedSince20`
из-за `pydantic.generics.GenericModel`.

**Фикс (DONE):**
- `CursorPage(GenericModel, Generic[T])` → `CursorPage(BaseModel,
  Generic[T])`
и убрать импорт `GenericModel`.


## CANON: CI DB PROFILE

**MUST:** CI DB profile = Postgres-only.

**MUST NOT:** SQLite in CI (tests/workflow) is forbidden.


---

## P-POSTGRES-ONLY / Alembic SSL mode mismatch (CI local Postgres без SSL)

**Run:** `logs_58700796381.zip`
**Симптом (excerpt):**
```
psycopg.OperationalError: connection failed: connection to server at "127.0.0.1", port 5432 failed:
server does not support SSL, but SSL was required
```
**Root cause:** `backend/migrations/env.py` принудительно добавлял
`sslmode=require` для любого non-sqlite URL, даже для `localhost`.
**Fix:** добавлять `sslmode=require` только если хост не
`localhost/127.0.0.1/::1` и параметр ещё не задан.

---

## T-PYTEST / IndentationError в helper `_init_sqlite_schema` (после перехода на Postgres-only)

**Run:** `logs_58700796378.zip`
**Симптом (excerpt):**
```
File ".../tests/test_concurrency_exchange_all.py", line 53
  @event.listens_for(engine.sync_engine, "connect")
IndentationError: unexpected indent
```
**Root cause:** в нескольких тестах блок SQLite-init остался
“обрубленным”: после `pytest.fail(...)` шёл неиндентированный код.
**Fix:** для Postgres-only канона заменить `_init_sqlite_schema(...)` на
3 строки: `pytest.fail(...)` + `return`, без дальнейшего кода.


---

## CI Failure: logs_58702480076 (compileall)

**Symptom (excerpt):**

```text
2026-02-26T17:32:23.3594249Z *** Error compiling 'extracted/backend/migrations/env.py'...
2026-02-26T17:32:23.3595407Z Sorry: IndentationError: expected an indented block after 'if' statement on line 84 (env.py, line 85)
2026-02-26T17:32:23.3662990Z ##[error]Process completed with exit code 1.
```

**Root cause:** `backend/migrations/env.py` — broken indentation and
duplicate assignment in sslmode block.

**Fix:** normalize sslmode-injection block for localhost/non-localhost
and remove duplicate `if`/bad assignment.

**Status:** fixed in patch13.

---

## CI Failure: logs_58950476465 (compileall)

**Symptom (excerpt):**

```text
2026-03-01T10:33:43.6995109Z *** Error compiling 'extracted/backend/app/models/__init__.py'...
2026-03-01T10:33:43.6995955Z   File "extracted/backend/app/models/__init__.py", line 51
2026-03-01T10:33:43.6996834Z     """Примесь created_at / updated_at (UTC, tz-aware)."""
2026-03-01T10:33:43.6997257Z        ^^^^^^^
2026-03-01T10:33:43.6997580Z SyntaxError: invalid syntax
2026-03-01T10:33:43.7069014Z ##[error]Process completed with exit code 1.
```

**Root cause:** `backend/app/models/__init__.py` был повреждён (внутрь
docstring класса `Base` попал фрагмент кода с определением
`TimestampMixin`, из-за чего Python получил «сломанный» блок строк и
упал на `SyntaxError`).

**Fix:** переписать `backend/app/models/__init__.py` как чистую
каноничную точку входа моделей:
- корректно экспортировать `Base` и `TimestampMixin`,
- исключить «вклейки» кода внутрь docstring,
- оставить безопасный авто-импорт модулей `*_models`.

**Предохранитель (MUST):** CI step `python -m compileall backend -q`


## CI Failure: logs_58956904319 (Sanity DB objects after alembic)

**Симптом (GitHub Actions, шаг sanity после `alembic upgrade head`):**

```
ERROR: required tables missing after alembic:
 - efhc_core.users
 - efhc_core.withdraw_requests
 - efhc_admin.efhc_sale_packages
Process completed with exit code 2.
```

**Причина (класс):** таблицы, которые ожидает CI sanity, не созданы
миграциями, потому что **нет ORM-описания/0001-покрытия** для части
таблиц (в частности `efhc_admin.efhc_sale_packages`), и/или схема
админ-таблиц расходится с каноном `efhc_admin`.

**Фикс:**
- добавить ORM-модель `EFHCSalePackage` (таблица
  `efhc_admin.efhc_sale_packages`),
- привести админ-ORM таблицы к схеме `settings.DB_SCHEMA_ADMIN`,
- в `0001_init.py`:
  - `SET search_path TO efhc_core, efhc_admin` (без `public`),
  - проверять, что ключевые таблицы присутствуют в `Base.metadata`
    до `create_all()`.

**Предохранитель (MUST):** `0001_init.py` обязан падать с
читаемым `RuntimeError`, если `efhc_core.users`,
`efhc_core.withdraw_requests`, `efhc_admin.efhc_sale_packages` отсутствуют
в `Base.metadata`.
остаётся обязательным перед любыми миграциями/pytest (фиксирует класс
ошибок «синтаксис/битый merge» раньше). (guard уже есть в workflow)

---

## CI / flake8: массовые ошибки lint (F821/F722/F811) — logs_58704053518.zip

**Symptom (excerpt):**
```
backend/app/bot/handlers/balance_handlers.py:61:19: F821 undefined name 'sender'
backend/app/bot/handlers/ranks_handlers.py:102:15: F821 undefined name 'tg_id'
backend/app/routes/admin_routes.py:73:17: F722 syntax error in forward annotation '^(bank_to_user|user_to_bank)$'
backend/app/bot/states.py:586:5: F811 redefinition of unused '_set' from line 578
```

**Root cause:**
- handlers использовали несуществующие переменные (`sender`, `tg_id`,
  `t`),
- `admin_routes.py` использовал `constr(...pattern=...)` под `from
  __future__ import annotations`,
что ломало парсер forward-annotations в flake8,
- в `states.py` был дублирован метод `_set`,
- ряд модулей имели реальные опечатки/недостающие импорты.

**Fix (patch15):**
- handlers: ввели `sender = message.from_user`, `tg_id =
  int(message.from_user.id)`, импортировали `t`,
- `admin_routes.py`: заменили `constr(...)` на `Field(...,
  pattern=...)`,
- `states.py`: удалили дублирование `_set`, восстановили fallback в
  `_get`,
- исправлены реальные опечатки/импорты (res_u→res, bank_id init, Request
  imports, timezone, datetime, и т.д.),
- добавлен `.flake8` с каноничным смысловым профилем:
`select=E9,F7,F82` + `extend-ignore=F822`.

**Status:** fixed in patch15.



## AB. CI падение: отсутствует `project.zip` в корне репозитория

**Симптом (GitHub Actions):** шаг распаковки падает до любых
guard/pytest/npm.

**Excerpt (logs_58712857957.zip / `canon/7_Unzip project.zip.txt`):**
```
2026-02-26T19:03:51.5530823Z   LD_LIBRARY_PATH: /opt/hostedtoolcache/Python/3.11.14/x64/lib
2026-02-26T19:03:51.5531115Z ##[endgroup]
2026-02-26T19:03:51.5603815Z ERROR: project.zip not found in repo root
2026-02-26T19:03:51.5616962Z ##[error]Process completed with exit code 1.
```

**Причина:** в корне репозитория нет файла `project.zip` (часто
загружен/закоммичен ZIP с другим именем, например `EFHC_Bot_...zip`,
либо файл лежит не в корне).

**Каноничное действие (MUST):**
- в корне репозитория должен лежать **ровно один** архив **с именем**
  `project.zip` (не папка, не другой путь).

**Предохранитель (рекомендуется):**
- в `.github/workflows/ci.yml` добавить fallback: если `project.zip`
  отсутствует, попытаться найти `EFHC_Bot_*.zip` и скопировать в
  `project.zip`, затем продолжать (с явным логом). Это не ослабляет
  канон, а делает CI самовосстанавливающимся при человеческой ошибке.


## AC — CI FAIL: guard bans false-positive in binary assets (png)

**Дата:** 2026-02-26
**Симптом (GitHub Actions):** падение шага "Guard grep bans (repo-wide
in extracted)" на случайном совпадении `\buid\b` внутри
`frontend/public/skins/1.png`.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- \buid\b: ./frontend/public/skins/1.png @ 53039
##[error]Process completed with exit code 1.
```

**Причина:** guard в CI сканировал **все** файлы и декодировал бинарные
как текст, поэтому случайные байты в PNG могли совпасть с
banned-паттерном.

**Фикс (канон):** в workflow использовать ripgrep с флагом `-I` (ignore
binary) и не сканировать бинарные файлы на banned-токены.
**Примечание:** pytest-guard
`tests/architecture/test_forbidden_identifiers_repo.py` уже исключает
бинарные суффиксы (png/jpg/woff и т.д.) и остаётся источником истины
внутри `project.zip`.


### AD) CI FAIL: Canon bans scan обнаружил запрещённую подстроку `tg` + `Id` — 2026-02-26

Источник: `logs_58716260680.zip` → шаг `Canon bans scan (text-only)`.

Excerpt (сокращено):
```
- banned_ids: extracted/frontend/src/lib/admin.ts ... getAdminTg" + "Ids() ...
- banned_ids: extracted/frontend/src/pages/_app.tsx ... isAdminTg" + "Id ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/logs.tsx ... setTg" + "Id ...
- banned_ids: extracted/frontend/src/pages/admin/panels.tsx ... setTg" + "Id ...
```

Fix (в ZIP v147_45):
- Удалены все вхождения подстроки `tg` + `Id` (любой регистр) во
  фронтенде.
- Переименование на каноничный `tg_id` (snake_case):
  - getAdminTg" + "Ids → get_admin_tg_ids
  - isAdminTg" + "Id → is_admin_tg_id
  - setTg" + "Id → set_tg_id

Проверки локально: repo-wide bans scan (text-only) — PASS.


## AF — CI: Alembic не находит модуль helpers при загрузке ревизии 0001_init — 2026-02-26

Источник: `logs_58718278834.zip` → шаг `Alembic upgrade head
(Postgres)`.

Excerpt (сокращено):
```
File ".../extracted/backend/migrations/versions/0001_init.py", line 25, in <module>
  from migrations.lib.safe import (
ModuleNotFoundError: No module named 'migrations'
```

Причина:
- Ревизии Alembic загружаются как отдельные модули, и импорт helpers
  должен быть устойчивым к текущей рабочей директории.

Fix (в ZIP v147_47):
- В `backend/migrations/versions/0001_init.py` добавлена гарантия, что
  корень проекта (extracted/) добавлен в `sys.path`.
- Импорты helpers переведены на `backend.migrations.lib.safe` (без
  зависимостей от cwd).

## AG — 2026-02-26 — CI: Alembic init migration падает на ensure_table_with_basics(schema=...)

**Симптом (GitHub Actions):**
```
TypeError: ensure_table_with_basics() got an unexpected keyword argument 'schema'
```

**Причина:**
`backend/migrations/versions/0001_init.py` вызывает
`ensure_table_with_basics(..., schema="efhc_admin")`,
а `backend/migrations/lib/safe.py` не поддерживал параметр `schema` и
работал только в текущем search_path.

**Фикс:**
Добавлена schema-aware поддержка в `safe.py`:
- `table_exists/column_exists/index_exists/unique_constraint_exists`
  принимают `schema`
- `ensure_table/ensure_column/ensure_index/ensure_unique_constraint/ensure_table_with_basics`
  принимают `schema`
- DDL
  (`op.create_table/add_column/create_index/create_unique_constraint`)
  вызывается с `schema=schema`

**Статус:** patched in ZIP v147_48


### AH (2026-02-26) CI / Alembic: ensure_table_with_basics не умеет sa.Index

**Симптом (CI):** `TypeError: cannot unpack non-iterable Index object` в
`backend/migrations/lib/safe.py` при обработке `indexes=[sa.Index(...)]`
из `0001_init.py`.

**Причина:** helper `ensure_table_with_basics()` ожидал список кортежей
`(name, [cols], unique)` и пытался распаковать `sa.Index` как кортеж.

**Фикс:** `ensure_table_with_basics()` теперь принимает и `sa.Index`,
нормализует в `(name, cols, unique)` и вызывает `ensure_index()`.
## AC. CI падение: ложное срабатывание bans-guard по бинарному файлу

**Симптом (GitHub Actions):** guard-запреты падают на совпадении токена
в бинарном файле (PNG/шрифт), хотя в коде/доках нарушения нет.

**Excerpt (CI):**
```
ERROR: forbidden identifiers found:
- tg_id: ./frontend/public/skins/1.png ...
##[error]Process completed with exit code 1.
```

**Root cause:** репо-сканер читает бинарные файлы как текст и ловит
случайные байты.

**Что помогло (Fix that worked):**
- Перевести bans-scan в режим *text-only* (игнорировать бинарники),
либо не сканировать `frontend/public/**` и иные бинарные каталоги.

**Verification:** после исключения бинарников guard перестаёт падать на
PNG.


## AD. CI падение: запрещённые алиасы tg_id в frontend

**Симптом (GitHub Actions):** bans-scan падает на подстроке tg_id во
фронтенде.

**Root cause:** в `frontend/src/**` были функции/переменные в camelCase
с фрагментом tg_id.

**Что помогло (Fix that worked):**
- Переименование на каноничный `tg_id` (snake_case) во фронтенде:
  - `frontend/src/lib/admin.ts`
  - `frontend/src/pages/_app.tsx`
  - `frontend/src/pages/admin/logs.tsx`
  - `frontend/src/pages/admin/panels.tsx`

**Verification:** bans-scan проходит, сборка двигается дальше.


## AE. CI падение: Alembic — ModuleNotFoundError из-за import path

**Симптом (GitHub Actions):** `alembic upgrade head` падает на импорте в
init-миграции.

**Excerpt (CI):**
```
ModuleNotFoundError: No module named 'backend'
```

**Root cause:** Alembic запускается не из того cwd/py-path, а ревизия
импортирует `backend.*`.

**Что помогло (Fix that worked):**
- Сделать ревизию cwd-независимой: добавлять корень проекта в `sys.path`
перед импортами helper-функций миграций.

**Verification:** Alembic начинает исполнять upgrade(), а не падает на
import.

**SEEN AGAIN (logs_58968563741):**
```
ModuleNotFoundError: No module named 'app.models.users_models'
```
**Причина:** в `0001_init.py` required-модуль был указан как
`users_models`, но реальный файл модели: `user_models.py`.
**Fix:** заменить `users_models` → `user_models` в required list.


## AF. CI падение: Alembic — helper не принимает schema=

**Симптом (GitHub Actions):** TypeError в `ensure_table_with_basics()`
при
вызове с `schema=...`.

**Root cause:** helper-функции `backend/migrations/lib/safe.py` не имели
параметра `schema`, но миграция вызывала их со schema.

**Что помогло (Fix that worked):**
- Добавить `schema: str | None = None` во все relevant helpers и
пробрасывать `schema=` в `op.create_table/add_column/create_index/
create_unique_constraint`.

**Verification:** Alembic проходит место с `schema=` и двигается дальше.


## AG. CI падение: Alembic — cannot unpack Index object

**Симптом (GitHub Actions):** TypeError: cannot unpack non-iterable
Index
object в `ensure_table_with_basics()`.

**Root cause:** миграция передавала `indexes=[sa.Index(...)]`, а helper
ожидал список кортежей `(name, cols, unique)`.

**Что помогло (Fix that worked):**
- В `ensure_table_with_basics()` принять оба формата:
  - `sa.Index` → нормализовать в `(ix.name, [cols], ix.unique)`
  - кортежный формат оставить как есть.

**Verification:** Alembic проходит блок indexes и продолжает upgrade().

### [AI] CI: Alembic — script_location указывает на несуществующий путь

**Симптом:** Alembic upgrade head падает с сообщением, что путь scripts
folder не найден.

**Причина:** в `backend/alembic.ini` `script_location` был задан как
`backend/migrations`, а CI запускает Alembic из каталога `backend/`,
поэтому ожидаемый путь становится `backend/backend/migrations`.

**Что помогло (Fix that worked):**
- В `backend/alembic.ini` `script_location` изменён на `migrations`
  (относительно `backend/`).

**Excerpt (CI, 1:1):**
```
FAILED: Path doesn't exist: backend/migrations.  Please use the 'init' command to create a new scripts folder.
```

### [AJ] CI: Alembic — ValueError unpack uniques (sa.UniqueConstraint)

**Симптом:** Alembic upgrade head падает в ensure_table_with_basics при
обработке uniques (ValueError unpack).

**Причина:** init-миграция передала uniques как
sa.UniqueConstraint(...), а helper ожидал кортеж (name, cols) и пытался
распаковать объект.

**Что помогло (Fix that worked):**
- backend/migrations/lib/safe.py: ensure_table_with_basics теперь
  принимает uniques как:
  - кортежи ("uq_name", ["col1", ...])
  - sa.UniqueConstraint(...): нормализуем в (uq.name, [col names])

**Excerpt (CI, 1:1):**
```text
ValueError: not enough values to unpack (expected 2, got 0)
```


---

## ARCHIVE_ARTIFACT_REGRESSION_AUDIT

- v148_04: из артефакта исчезли `docs/` и
  `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` (урезанная сборка).
  Восстановлено в последующих FULL сборках.


## ARTIFACT_REGRESSIONS

### [AR01] Урезание артефакта (исторический инцидент)

**Симптом:** в одном из выпусков артефакт был опубликован в «урезанном»
виде (без docs/ и без реестра ошибок), что нарушает канон.
**Когда:** выпуск
`EFHC_Bot_v148_04_pack_flat_min_upload_nodocs_noregistry.zip`.
**Что пропало:** каталог `docs/` и файл
`EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md`.
**Что помогло:** введён архитектурный тест
`tests/architecture/test_artifact_full_build_required.py`, который валит
CI при отсутствии SSOT‑якорей.



### [BA] Alembic: UniqueConstraint empty columns in ensure_table_with_basics (payment_intents)

**Симптом:** `alembic upgrade head` падал с `RuntimeError:
UniqueConstraint for payment_intents resolved to empty columns`.

**Причина:** `sa.UniqueConstraint` в миграции может быть создан строками
и до привязки к Table иметь пустой `.columns`; имена колонок лежат в
`._pending_colargs`.

**Что помогло:** В `backend/migrations/lib/safe.py` добавлена
нормализация UniqueConstraint: если `.columns` пустой, брать колонки из
`._pending_colargs`.


### [BB] 2026-02-27 CI: pytest collection failed due to IndentationError in tests (fixed)

**Symptom:** `pytest -q` interrupted during collection with multiple
`IndentationError` in test files.

**Root cause:** inconsistent indentation (tabs/misaligned indents)
introduced in recent test edits.

**Fix that worked:** restored and normalized indentation for 10 test
modules:
- `tests/test_migrations_upgrade_head.py`
- `tests/test_panels_180_days.py`
- `tests/test_panels_active_archive.py`
- `tests/test_panels_global_id.py`
- `tests/test_panels_idempotent_create.py`
- `tests/test_payment_intent_status_owner_only.py`
- `tests/test_payment_intents_payload_unique.py`
- `tests/test_payment_intents_usdt_tx_and_confirm.py`
- `tests/test_unmatched_incoming_recording.py`
- `tests/test_wallets_connect_hardening.py`

**Verification:** `python -m compileall tests -q` passes (local).


## [BC] 2026-02-27 — Pytest collection/SQLite хвосты/async режим (v148_31)

**Симптом (CI):** pytest падал на SQLite forbidden/aiosqlite
missing/async def not supported/NameError helpers.

**Причина:** legacy SQLite ветки и отсутствие глобального asyncio
режима.

**Что помогло:**
- Добавлен `pytest.ini` с `asyncio_mode = auto`.
- Переписаны sqlite-ветки тестов на Postgres-only (asyncpg) и схемы
  `efhc_core/efhc_admin`.
- Добавлен `get_async_db_url()` в `tests/conftest.py` + создание схем
  перед TRUNCATE.

**Проверка:** CI `pytest -q` должен запускать тесты без ошибок
collection.


### [BD] Pytest collection: missing backend module + freezegun

**Симптом (CI Step):** `pytest -q` падает на collection
(`ModuleNotFoundError: backend`, `ModuleNotFoundError: freezegun`).

**Причина:** `tests/conftest.py` добавлял корень репозитория в
`sys.path` только внутри фикстуры, но импорты происходят раньше — на
этапе collection. Плюс `freezegun` не был закреплён в
`backend/requirements.txt`.

**Что помогло (Fix that worked):**
- `tests/conftest.py`: вызов `_ensure_repo_root_on_syspath()` выполнен
  при импорте модуля.
- `backend/requirements.txt`: добавлен `freezegun`.

**Verification:** следующий прогон должен пройти collection и перейти к
выполнению тестов.


---

## CI-FALL-2026-02-27-LOOP-ASYNC-01

**Симптом (CI step):** `canon/13_pytest -q (Postgres-only)` падает на
setup.

**Root cause:** session-scoped `async_engine` создаётся/используется
через разные asyncio event loop’ы (pytest-asyncio), из‑за чего
asyncpg/SQLAlchemy получают Future/операции “в другом loop” и/или
параллельную операцию на одном соединении.

**Fix that worked:** зафиксировать **один** asyncio event loop на всю
тестовую сессию (session-scoped `event_loop`), чтобы session-scoped
async fixtures жили в одном loop.

**Verification:** локально/CI: `pytest -q` проходит без `attached to a
different loop` / `another operation is in progress`.

**Excerpt (1:1, 3–10 строк):**
```text
2026-02-27T10:31:33.4145191Z
2026-02-27T10:31:33.4145318Z >   ???
2026-02-27T10:31:33.4148415Z E   RuntimeError: Task <Task pending name='Task-80' coro=<_wrap_asyncgen_fixture.<locals>._asyncgen_fixture_wrapper.<locals>.setup() running at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/pytest_asyncio/plugin.py:309> cb=[_run_until_complete_cb() at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/asyncio/base_events.py:181]> got Future <Future pending cb=[BaseProtocol._on_waiter_completed()]> attached to a different loop
2026-02-27T10:31:33.4150257Z
2026-02-27T10:31:33.4150453Z asyncpg/protocol/protocol.pyx:369: RuntimeError
2026-02-27T10:31:33.4151216Z __________ ERROR at setup of test_panels_expires_exactly_180_days_utc __________
2026-02-27T10:31:33.4151502Z
2026-02-27T10:31:33.4151819Z self = <AdaptedConnection <asyncpg.connection.Connection object at 0x7fba3948c220>>
```

## CI-FALL-2026-02-27-ASYNCOP-02

**Симптом (CI step):** `canon/13_pytest -q (Postgres-only)` падает на
setup фикстур.

**Root cause:** конкурентное использование async БД‑ресурсов в тестах:
- DDL `CREATE SCHEMA` выполнялся в `db_clean` **для каждого теста**,
повышая вероятность конфликтов.
- Конкурентные тесты использовали **один и тот же AsyncSession**
внутри `asyncio.gather()`, что приводит к ошибкам asyncpg
`another operation is in progress`.

**Fix that worked:**
1) `tests/conftest.py`: создать схемы `efhc_admin/efhc_core` один раз
на сессию (`schemas_ready`), а в `db_clean` делать только TRUNCATE.
2) `tests/test_concurrency_*.py`: каждая конкурентная задача получает
**свой** `AsyncSession`.

**Verification (local):**
- `pytest -q tests/architecture/test_max_line_length_72.py` ✅
- `pytest -q tests/test_build_sanity.py` ✅
- `pytest -q tests/test_no_placeholders.py` ✅

**Excerpt (1:1, 3–10 строк):**
```text
2026-02-27T10:59:16.7360788Z >                   raise translated_error from error
2026-02-27T10:59:16.7361859Z E                   sqlalchemy.exc.InterfaceError: (sqlalchemy.dialects.postgresql.asyncpg.InterfaceError) <class 'asyncpg.exceptions._base.InterfaceError'>: cannot perform operation: another operation is in progress
2026-02-27T10:59:16.7362810Z E                   [SQL: CREATE SCHEMA IF NOT EXISTS efhc_admin]
2026-02-27T10:59:16.7363273Z E                   (Background on this error at: https://sqlalche.me/e/20/rvf5)
```



## v148_35 — Пакет Variant A (фикс по аудиту)
- require_admin: X-Admin-Id не участвует в авторизации
- tests: добавлен db_migrated (alembic upgrade head) перед DB-тестами
- pytest.ini: единый конфиг + loop scope session
- pre-commit: исправлена ссылка на несуществующий тест

## CI-FALL-2026-02-27-COLLECTION-INDENT-01

- **Symptom (CI step):** `pytest -q` fails during collection (exit code
  2).
- **Root cause:** `IndentationError: unexpected indent` in 2 tests.
- **Fix that worked:** Fix indentation in:
  - `tests/test_concurrency_exchange_all.py` (indent `bank_efhc_id`,
    `user_tg_id`)
  - `tests/test_concurrency_withdraw_double.py` (indent `user_tg_id` and
    following)
- **Verification:** should pass collection; rerun CI logs required for
  SSOT.

**Excerpt (1:1):**
```
2026-02-27T13:08:23.5771174Z E     File "/home/runner/work/Test/Test/extracted/tests/test_concurrency_exchange_all.py", line 59
2026-02-27T13:08:23.5771905Z E       user_tg_id = 100001
2026-02-27T13:08:23.5772332Z E   IndentationError: unexpected indent
2026-02-27T13:08:23.5790125Z E     File "/home/runner/work/Test/Test/extracted/tests/test_concurrency_withdraw_double.py", line 59
2026-02-27T13:08:23.5790906Z E       async with Session() as db_session:
2026-02-27T13:08:23.5791378Z E   IndentationError: unexpected indent
```


## v148_40 — Пакет Audit #3 (fullfix)
- Telegram initData: исправлен алгоритм WebAppData HMAC
- Scheduler backoff: job не замерзает, reset next_allowed_at
- tests: db_migrated рекурсия устранена (schemas_ready)
- tests: PRAGMA guard на Postgres (no-op вне sqlite)
- CORS: credential-режим с явными methods/headers + origin normalize
- frontend: initDataUnsafe fallback только вне production
- ruff: line-length = 72


## v148_42 — pytest async loop binding for AsyncEngine (CI)
- **Symptom (CI step):** canon/13_pytest -q (Postgres-only) fails in
concurrency tests.
- **Root cause:** session-scoped AsyncEngine was created by a sync
  fixture,
allowing pool/connection init in a different event loop; connection
reuse
could also trigger asyncpg "another operation is in progress".
- **Fix that worked:** `tests/conftest.py`:
  - `event_loop` sets current loop via asyncio.set_event_loop(loop)
  - `async_engine` is async session fixture depending on event_loop
  - test engine uses NullPool + warmup SELECT 1 + dispose
- **Verification:** requires new CI logs after rerun.

**Excerpt (1:1):**
```
<ADD AFTER CI RERUN: logs_58824951756.zip excerpt lines here>
```

## CI-FALL-2026-02-27-LOOP-TEARDOWN-03

- Symptom: pytest -q fails during async fixture teardown (db_session
  close)
- Root cause: pytest-asyncio asyncio_mode=auto runs teardown in a
  different loop
- Fix that worked: set pytest.ini asyncio_mode=strict
- Verification: rerun CI pytest -q
- Logs (excerpt 1:1) from logs_58827640670.zip:
```text
2026-02-27T17:37:14.2033422Z
2026-02-27T17:37:14.2033552Z >   ???
2026-02-27T17:37:14.2036037Z E   RuntimeError: Task <Task pending name='Task-107' coro=<AsyncSession.close() running at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/sqlalchemy/ext/asyncio/session.py:1016> cb=[shield.<locals>._inner_done_callback() at /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/asyncio/tasks.py:891]> got Future <Future pending cb=[BaseProtocol._on_waiter_completed()]> attached to a different loop
2026-02-27T17:37:14.2037503Z
2026-02-27T17:37:14.2037870Z asyncpg/protocol/protocol.pyx:369: RuntimeError
```

## 2026-02-27 — CI pytest async fixture handling (v148_45)

Симптом (CI step): canon/13_pytest -q (Postgres-only) — setup errors

Root cause: async fixtures declared with @pytest.fixture in STRICT mode.

Fix that worked: switch async fixtures to @pytest_asyncio.fixture and
fix
_ensure_schema SQL.

Verification: compileall tests; ожидаем CI pytest PASS по setup.

Logs (excerpt 1:1): см. logs_58829966802.zip (PytestRemovedIn9Warning).



## v148_46 — SSOT tg_id unification (audit-driven)

- Symptom: SSOT/code mismatch for tg_id semantics and FK targets.
- Fix: unified tg_id queries to users.tg_id; FK tg_id -> users.tg_id;
  0001 schema explicit for FKs.
- Verification: compileall backend/tests.

## CI 2026-02-27 — Audit #4 blockers (logs_58835186075.zip)

### Symptom
- CI step: canon/13_pytest -q (Postgres-only)
- async tests fail in strict asyncio mode without marker
- payment_intents sequence missing (nextval on
  efhc_core.payment_intents_id_seq)
- teardown loop mismatch

### Root cause
- Async tests were not marked with @pytest.mark.asyncio under strict
  mode.
- payment_intents.id was not configured to autogenerate ids in Postgres.
- CI doc allowed upgrading pytest stack with -U (teardown instability).

### Fix
- Mark async tests.
- Make payment_intents.id autoincrement.
- Expand Alembic sanity required list.
- Add explicit source_schema/referent_schema for FK.
- Remove -U from CI workflow canon doc (install from requirements*).

### Verification
- python -m compileall backend -q: PASS
- python -m compileall tests -q: PASS

### Logs (excerpt 1:1)
```text
2026-02-27T18:51:45.6912087Z
2026-02-27T18:51:45.6912624Z /opt/hostedtoolcache/Python/3.11.14/x64/lib/python3.11/site-packages/sqlalchemy/dialects/postgresql/asyncpg.py:797: ProgrammingError
2026-02-27T18:51:45.6913361Z ___________________ test_panels_expires_exactly_180_days_utc ___________________
2026-02-27T18:51:45.6913781Z async def functions are not natively supported.
2026-02-27T18:51:45.6914231Z You need to install a suitable plugin for your async framework, for example:
2026-02-27T18:51:45.6914579Z   - anyio
2026-02-27T18:51:45.6914753Z   - pytest-asyncio
2026-02-27T18:51:45.6914949Z   - pytest-tornasync
2026-02-27T18:51:45.6915138Z   - pytest-trio
2026-02-27T18:51:45.6915311Z   - pytest-twisted
```

```text
2026-02-27T18:51:45.7256377Z _____________ test_two_shop_external_intents_same_user_no_conflict _____________
2026-02-27T18:51:45.7256385Z
2026-02-27T18:51:45.7256763Z self = <sqlalchemy.dialects.postgresql.asyncpg.AsyncAdapt_asyncpg_cursor object at 0x7f7c8732aa40>
2026-02-27T18:51:45.7258055Z operation = "WITH next_id AS (\n  SELECT nextval('efhc_core.payment_intents_id_seq') AS nid\n), ins AS (\n  INSERT INTO efhc_core....SELECT * FROM efhc_core.payment_intents\n WHERE tg_id = $1\n   AND purpose = $2\n   AND idempotency_key = $6\n LIMIT 1"
2026-02-27T18:51:45.7258360Z parameters = (9002, 'shop_external', 'TON', Decimal('2.00000000'), 'SENT', 'k1', ...)
2026-02-27T18:51:45.7258369Z
2026-02-27T18:51:45.7258556Z     async def _prepare_and_execute(self, operation, parameters):
2026-02-27T18:51:45.7258688Z         adapt_connection = self._adapt_connection
2026-02-27T18:51:45.7258750Z
2026-02-27T18:51:45.7258887Z         async with adapt_connection._execute_mutex:
```


## v148_51 — Alembic sanity: missing required tables

Симптом: CI step 'Sanity DB objects after alembic' reports missing
efhc_core.users / efhc_core.withdraw_requests /
efhc_admin.efhc_sale_packages.
Root cause: 0001 migration created tables without explicit schema.
Fix: added schema=... to ensure_table_with_basics calls in 0001.


---

## CI-58886229272 — required tables missing after alembic (sanity to_regclass)

**Симптом (CI step):**
Sanity DB objects after alembic (core_admin) → exit code 2

**Root cause:**
Часть таблиц создавалась без schema=... → попадала не в
efhc_core/efhc_admin (обычно public), поэтому to_regclass('efhc_core.*')
возвращал NULL.

**Fix that worked (в v149_02):**
- В 0001_init.py добавлено CREATE SCHEMA IF NOT EXISTS для
  efhc_core/efhc_admin.
- Вызовам ensure_table_with_basics для ключевых таблиц добавлен
  schema="efhc_core"/"efhc_admin" (на уровне TABLE, не Column).

**Verification:**
- python -m compileall backend -q: PASS
- Ожидаемо: Alembic upgrade head создаёт таблицы в нужных схемах;
  sanity-check проходит.

**Excerpt 1:1 (logs_58886229272.zip)**
```text
2026-02-28T10:02:32.1093805Z ERROR: required tables missing after alembic:
2026-02-28T10:02:32.1094361Z  - efhc_core.users
2026-02-28T10:02:32.1094744Z  - efhc_core.withdraw_requests
2026-02-28T10:02:32.1095187Z  - efhc_admin.efhc_sale_packages
2026-02-28T10:02:32.1324658Z ##[error]Process completed with exit code 2.
```


## 2026-02-28 — ORM duplicate table definition (`shop_orders`) + non-canonical admin schema fallback

**Symptom**
- Risk of MetaData conflicts / inconsistent fields due to duplicate
  `shop_orders` ORM definition.
- “Floating” admin schema name via fallbacks (`getattr(...,
  "efhc_admin")`) causes non-canonical schema usage and future drift.

**Root cause**
- `shop_orders` declared in both `order_models.py` and `shop_models.py`.
- `DB_SCHEMA_ADMIN` was not defined in core settings; code used fallback
  strings instead of a single canonical source.

**Fix that worked**
- Made `order_models.py` a compatibility re-export of the canonical
  `ShopOrder` from `shop_models.py`.
- Added `DB_SCHEMA_ADMIN` to core settings and replaced fallbacks with
  `settings.DB_SCHEMA_ADMIN` / `S.DB_SCHEMA_ADMIN`.
- Fixed admin stats query to use `DB_SCHEMA_CORE` for `shop_orders`.

**Verification**
- `python -m compileall backend -q` PASS


## DOCS: Архив PDF-аудитов добавлен в docs/audits

- Добавлены PDF-аудиты в `docs/audits/` и ссылки в документации.
## 2026-02-28 — v149_12 — Аудиты переведены в Markdown
Симптом: пользователь попросил хранить аудиты не PDF, а в MD.
Root cause: PDF неудобны для поиска/диффа/ссылок.
Fix that worked: заменены PDF на структурированные MD-конспекты в
`docs/audits/`.
Verification: файлы присутствуют, индекс `docs/audits/README.md`
обновлён.


## 2026-02-28 — Audits SSOT upgrade (v149_13)
- Симптом: audit-md не были SSOT-активом (нет метаданных/статусов,
смешаны факты и решения, сырьё не ограничено).
- Root cause: отсутствие канонического шаблона audit-md.
- Fix: введён шаблон (Source/Scope/Date/Status/Superseded by),
разделение Findings/Actions/Appendix, очистка служебных токенов,
ограничение 72 символа.
- Verification: проверена структура всех docs/audits/*.md.

## Audits SSOT governance
- Added audits SSOT linters and JSON navigator (v149_14).

## 2026-02-28 — v149_15 — ReferralLink/ReferralBonusLedger + 0001 fixes

Симптом: runtime/CI риск (несовместимые колонки referral_links, отсутствующая
ReferralBonusLedger, отсутствие bank_balances, некорректный schema kw в
efhc_sale_packages).

Root cause: рассинхрон ORM↔CRUD↔0001 и запрещённый schema kw внутри Column.

Fix: см. Audit AUD-2026-02-28-DB-INVENTORY-002 и отчёт reports/change_cycle_2026-02-28_0330_v149_15_audit_db_tables2_referrals_fix.md.

Verification: compileall PASS; audits linters PASS.

## v149_19: 0001 full migration (schemas/tables/sanity)
- Причина: неполная 0001 + запрещённый schema kwarg в Column.
- Фикс: переписан 0001 с create_all(ORM) + raw SQL tables + to_regclass sanity.
- Report: reports/change_cycle_2026-02-28_0700_v149_19_full_0001_all_tables.md

## 2026-03-01 — Audit added: AUD-2026-03-01-DB-INVENTORY-006

- Added SSOT audit md and raw source into docs/audits.


---

## CI.logs_58934396257 — Unzip efhc.zip: File name too long в docs/audits/_raw/legacy_md

**Симптом (CI):**
```
unzip efhc.zip
... File name too long ...
exit code 50
```

**Причина:** в архиве присутствовали файлы с чрезмерно длинными/битым-юникод именами в `docs/audits/_raw/legacy_md/`.

**Фикс:** переименование файлов в короткие ASCII-имена + карта `RENAMED_MAP.csv` (контент сохранён).

**Guard:** при упаковке ZIP запрещать пути с длиной имени > 180 и запрещать non-UTF8 суррогаты (pre-pack scan).


---

## CI.logs_58933931956 — Alembic sanity: двойной префикс схемы efhc_core.efhc_core

**Симптом (CI):**
```
to_regclass('efhc_core.efhc_core.<table>') ...
cross-database references are not implemented
```

**Причина:** sanity в 0001 добавлял `efhc_core.` к имени таблицы, которое уже включало `efhc_core.`.

**Фикс:** `fq = t if '.' in t else f'efhc_core.{t}'`.

**Guard:** unit-test sanity helper на входах `table` и `schema.table`.


---

## CI.logs_58934886722 — Alembic sanity: tables_count_expected_31_got_17 (недоимпорт моделей)

**Симптом (CI):**
```
0001 sanity failed ... tables_count_expected_31_got_17
```

**Причина:** `Base.metadata` был неполным из‑за мягких/неполных импортов `*_models.py` (часть модулей не загружалась и не регистрировала таблицы).

**Фикс:** детерминированный импорт всех `*_models.py` перед `Base.metadata.create_all()`.

**Guard:** в 0001 обязательный `_import_all_model_modules()` + sanity `len(Base.metadata.tables)==31`.


---

## CI.logs_58935568518 — Alembic import: config_core не экспортировал settings (ImportError)

**Симптом (CI):**
```
ImportError: cannot import name 'settings' from app.core.config_core
```

**Причина:** модули ожидали `settings`, но `config_core.py` экспортировал только `get_settings()`.

**Фикс:** добавить `settings = get_settings()` и включить в `__all__`.

**Guard:** smoke-test импорта `from app.core.config_core import settings`.


---

## CI.logs_58936111325 — Alembic: Table already defined (двойной импорт моделей под разными namespace)

**Симптом (CI):**
```
InvalidRequestError: Table 'efhc_core.admin_whitelist' is already defined for this MetaData instance.
```

**Причина:** один и тот же модуль моделей загружался как `app.models.*` и как `backend.app.models.*`, класс выполнялся дважды.

**Фикс:** единый каноничный namespace импорта в 0001 (только `app.models`), запрет `backend.app.*` в миграциях.

**Guard:** в 0001 запрещать строку `backend.app.` и проверять `Base.metadata.tables` на дубли.


---

## CI.logs_58936503633 — Alembic: ModuleNotFoundError backend (модели импортировали backend.app.*)

**Симптом (CI):**
```
ModuleNotFoundError: No module named 'backend'
```

**Причина:** `app.models` (cwd=backend) не имеет пакета `backend`, но модели/инициализация ссылались на `backend.app.*`.

**Фикс:** заменить импорты на относительные или `app.*` внутри `app`-пакета.

**Guard:** repo-wide ban: `from backend.app` внутри `backend/app/**` (кроме README/комментариев).


---

## CI.logs_58938125974 — Alembic: ModuleNotFoundError backend в core/system_locks

**Симптом (CI):**
```
ModuleNotFoundError: No module named 'backend' (при импорте app.core.system_locks)
```

**Причина:** core-модули использовали `backend.app.*` при запуске из `backend/`.

**Фикс:** привести core импорты к `app.*`/относительным.

**Guard:** repo-wide ban: `backend.app.` внутри `backend/app/core/**`.


---

## CI.logs_58938592468 — Alembic: ModuleNotFoundError backend в achievements_models (и других models)

**Симптом (CI):**
```
.../app/models/achievements_models.py:15
from backend.app.core.config_core import get_settings
ModuleNotFoundError: No module named 'backend'
```

**Причина:** отдельные `*_models.py` продолжали использовать `backend.app.*`, несмотря на запуск из `backend/`.

**Фикс:** массовая правка импортов моделей на относительные/`app.*` (каноничный namespace).

**Guard:** repo-wide ban: `backend.app.` внутри `backend/app/models/**`.

## CI Failure: SQLAlchemy Index() got unexpected kwarg 'schema' (AdminWhitelist index)
- **Logs:** logs_58939510200.zip
- **Step:** Alembic upgrade head (Postgres-only)
- **Symptom:** `TypeError: Additional arguments should be named <dialectname>_<argument>, got 'schema'`
- **Root cause:** `backend/app/models/admin_models.py` declared `Index(..., schema=ADMIN_SCHEMA)` which is invalid in SQLAlchemy.
- **Fix:** remove `schema=` kwarg from `Index(...)` (table schema already defined via `__table_args__`).
- **Guard:** ban `Index(... schema=...)` pattern in repo-wide lint/grep.


## 2026-03-01 — CI Alembic: ImportError Base (bank_models)

- **Logs:** `logs_58940265094.zip` → step `Alembic upgrade head (Postgres-only)`
- **Симптом:** `ImportError: cannot import name 'Base' from 'app.core.database_core'`
- **Root cause:** `app/models/bank_models.py` импортировал `Base` из `app.core.database_core`, но `Base` канонично определён в `app.models` (`backend/app/models/__init__.py`), а не в database_core.
- **Фикс:** `bank_models.py`: `from ..core.database_core import Base` → `from . import Base`
- **Гарды/профилактика:** запретить `database_core import Base` в `backend/app/models/**` (repo-wide ban/grep).

## CI / Alembic — TypeError: Index(..., schema=...) (SQLAlchemy)

**Observed in logs:** `logs_58942307881.zip`  
**Step:** `Alembic upgrade head (Postgres-only)`  
**Symptom:** `TypeError: Additional arguments should be named <dialectname>_<argument>, got 'schema'`  
**Root cause:** В ORM-модели использован `Index(..., schema=CORE_SCHEMA)` — SQLAlchemy не принимает `schema` как аргумент `Index`.  
**Fix:** Удалить `schema=...` из `Index(...)`. Схема задаётся только на уровне таблицы (`__table_args__={"schema": ...}`), индекс наследует схему таблицы.  
**Patched:** `backend/app/models/bank_models.py` (удалены `schema=CORE_SCHEMA` в индексах).

---

## CI / Alembic: TypeError из-за `Index(..., schema=...)` в ORM (shop_models)

- **Observed in logs:** `logs_58943419183.zip`
- **Step:** `Alembic upgrade head (Postgres-only)`
- **Symptom:** `TypeError: Additional arguments ... got 'schema'`
- **Root cause:** В ORM-модели использован kwarg `schema=` внутри `Index(...)` (SQLAlchemy не поддерживает `schema` для Index).
- **Evidence:** `backend/app/models/shop_models.py` (индексы `ix_shop_items_created_id` и др. содержали `schema=CORE_SCHEMA`).
- **Fix:** Удалить `schema=` из всех `Index(...)`. Схема задаётся **только** на уровне таблицы (`__table_args__={'schema': ...}`), индексы наследуют схему таблицы.
- **Guard:** `ops/canon_guard.py` → правило `ORM_INDEX_NO_SCHEMA_KWARG`.

## CI/Alembic: AttributeError Settings missing TASK_REWARD_BONUS_EFHC_DEFAULT

- Симптом: `AttributeError: 'Settings' object has no attribute 'TASK_REWARD_BONUS_EFHC_DEFAULT'`
- Где: `app/models/tasks_models.py` при импорте моделей в `0001_init.py`
- Логи: `logs_58944299025.zip`
- Root cause: в `app/core/config_core.Settings` отсутствовало поле `TASK_REWARD_BONUS_EFHC_DEFAULT`, но модель `Task` использовала его как default.
- Fix: добавить `TASK_REWARD_BONUS_EFHC_DEFAULT` в `Settings` (Decimal, default=0).
## CI/Alembic ImportError: TimestampMixin отсутствует в app.models
- Symptom: `ImportError: cannot import name 'TimestampMixin' from 'app.models'`
- Evidence: `logs_58945844276.zip` / `canon/13_Alembic upgrade head (Postgres-only).txt`
- Root cause: `external_events_models.py` импортирует `TimestampMixin` из `app.models`, но он не экспортирован.
- Fix: добавить `TimestampMixin` в `backend/app/models/__init__.py` и использовать его в моделях.

## CI/Alembic TypeError: Index(..., schema=...) в tasks_models.py
- Evidence: logs_58945067490.zip
- Root cause: запрещённый/неправильный импорт/аргумент при импорте моделей для 0001.
- Fix: см. change report v149_51 (TimestampMixin экспорт + удаление schema= из Index).


## CI: Sanity DB objects after alembic — missing required tables (core_admin)
- Evidence: logs_58958883850.zip (step: Sanity DB objects after alembic (core_admin))
- Symptom: missing efhc_core.users / efhc_core.withdraw_requests / efhc_admin.efhc_sale_packages
- Root cause class: search_path/schema drift between efhc_core and efhc_admin during migrations/DDL.
- Fix (v149_55): backend/migrations/env.py set search_path to efhc_core, efhc_admin for online migrations.
- Guard: keep post-alembic sanity check; ensure schemas exist and never use backend.app.* imports.


### SEEN_AGAIN: required tables missing after alembic (core_admin)
- Evidence: logs_58960838296.zip
- Symptom: efhc_core.users, efhc_core.withdraw_requests, efhc_admin.efhc_sale_packages missing in post-alembic sanity
- Root class: schema/search_path drift OR ORM/0001 mismatch; guard: env.py creates schemas+search_path core+admin and enforces required tables.

## AE) Alembic: AttributeError impl.stdout в 0001_init.py

**Симптом (GitHub Actions, alembic upgrade head):**
```
AttributeError: 'PostgresqlImpl' object has no attribute 'stdout'
.../backend/migrations/versions/0001_init.py
```

**Истина:** logs_58970975145.zip (canon/13).

**Причина:** попытка писать лог через
`op.get_context().impl.stdout.write(...)`. У impl нет stdout.

**Фикс:** использовать `sys.stdout.write(...)` или `print(...)`
в миграции.

**Предохранитель:** запрет на использование `impl.stdout` в миграциях
(canon_guard).

## SEEN AGAIN: Missing required tables after alembic (core_admin)

Evidence:
- logs_59040565965.zip (canon/14)

Fix v149_71:
- env.py: log db/search_path; Postgres-only URL selection
- 0001_init.py: set Base.metadata.schema="efhc_core" for create_all

## AF) Alembic: миграция печатает только metadata, таблиц нет

**Симптом:**
- canon/13 печатает: `0001: metadata_tables=...`
- post-alembic psql: нет схем efhc_core/efhc_admin и нет таблиц

**Истина:** logs_59048630986.zip.

**Причина класса:** DDL не фиксируется в БД.
Частые источники:
- создание схем внутри транзакции + rollback
- create_all на соединении без schema_translate_map
- YAML: pipe в `tee` без `set -o pipefail` скрывает exit code

**Фикс (v149_73):**
- env.py: CREATE SCHEMA в AUTOCOMMIT
- 0001_init.py: create_all через schema_translate_map
- 0001_init.py: печать `create_all_done` и `ok`

**Рекомендация YAML:**
- для шагов с `| tee` добавить `set -o pipefail`


- SEEN_AGAIN: missing tables after alembic (logs_59080491321.zip); fix: schema create in env.py AUTOCOMMIT; hard check in 0001.

## AG) InvalidRequestError: transaction already begun on Session

**Симптом (CI):**
- pytest падает на `A transaction is already begun on this Session.`
- Встречается в:
  - backend/app/services/transactions_service.py
  - backend/app/services/panels_service.py

**Истина:** logs_59083780685.zip

**Причина класса:**
- AsyncSession включает autobegin при первом execute().
- Прямой `await db.begin()` в сервисах пытается начать
  вторую транзакцию и валится.

**Фикс (v149_78):**
- transactions_service: `_tx_context()` и begin_nested при
  активной транзакции.
- panels_service: begin → `_tx_context()`.

## AH) Payment intents: PACKAGE_NOT_FOUND / ambiguous param types

**Симптом (CI):**
- ValueError: PACKAGE_NOT_FOUND
- asyncpg AmbiguousParameterError (text vs bigint)

**Истина:** logs_59083780685.zip

**Причина класса:**
- Тесты не создают deposit package в efhc_core.shop_items.
- SQL строит payload через конкатенацию без явных cast.

**Фикс (v149_78):**
- payment_intents_service: cast `next_id.nid::text` и `:tg::text`.
- Тесты: seed shop_items(id=1) перед create_intent_deposit...


---

## CI.logs_59100123471 — pytest collection: SyntaxError (unterminated string)

**Логи:** `logs_59100123471.zip`

**Симптом (pytest):**

```
SyntaxError: unterminated string literal
```

**Root cause:** сломан шаблон SQL-строки в тестах:
`text("\\n".join([...]))` был разорван на 2 строки и превратился в
незакрытую кавычку.

**Фикс:** восстановить `"\\n".join([...])`.

**Файлы:**

- `tests/test_concurrency_exchange_all.py`
- `tests/test_payment_intents_lifecycle_double_payments.py`

**Guard (MUST):** запрет многострочных "дыр" в `text("..."` внутри
tests: grep на паттерн `text(\s*"$` и fail.

---

## CI.logs_59100123471 — next build: No QueryClient set

**Логи:** `logs_59100123471.zip`

**Симптом (next build):**

```
Error: No QueryClient set, use QueryClientProvider to set one
Error occurred prerendering page "/admin/..."
```

**Root cause:** `useSnapshot()` (React Query) был вызван в `_app.tsx`
до монтирования `QueryClientProvider`.

**Фикс:** вынести `useSnapshot()` и snapshot-зависимую логику в
внутренний компонент, который рендерится внутри `QueryClientProvider`.

**Файл:** `frontend/src/pages/_app.tsx`

---
## CI.logs_59108438734 — pytest: ImportError + direction truncation

**Логи:** `logs_59108438734.zip`

### Симптом 1 (pytest)
`ImportError` при импорте из `transactions_service`.

**Root cause:** тесты импортируют `append_transfer_extra_info`, а в коде
осталась только `append_transfer_meta` (потеря совместимости имени).

**Фикс:** вернуть `append_transfer_extra_info()` как thin-wrapper над
`append_transfer_meta()`.

**Файл:** `backend/app/services/transactions_service.py`

### Симптом 2 (DB)
`StringDataRightTruncationError` для `efhc_transfers_log.direction`.

**Root cause:** поле `direction` было `varchar(8)`, а значение
`user_to_bank` длиннее (12), поэтому запись падает.

**Фикс:** расширить `direction` до `varchar(24)` в ORM и согласовать
санити/SSOT при необходимости.

**Файл:** `backend/app/models/efhc_transfers_log_models.py`


## CI Fixes (заполнено задним числом)

### logs_59094682436.zip — Alembic 0001 sanity: SSOT tables count
- Date: 2026-03-03
- Root cause: SSOT_TABLES_ORM expected!=ORM tables (38 vs 39).
- Fix: v150_06+ (SSOT updated)

### logs_59101666230.zip — Pytest collection: importorskip misuse
- Date: 2026-03-03
- Root cause: pytest.importorskip result treated as callable.
- Fix: v150_10

### logs_59105730534.zip — Pytest DB/logging/sql issues
- Date: 2026-03-03
- Root cause: CHECK/CAST/DDL mismatches in tests and models.
- Fix: v150_11

### logs_59107281886.zip — Pytest: transfers_log meta + line72 + intents
- Date: 2026-03-03
- Root cause: Wrong column name extra_info vs meta, bad binds, kw name.
- Fix: v150_12

### logs_59109762688.zip — Pytest: transfers_log direction enum + intent tg bind
- Date: 2026-03-03
- Root cause: ck_efhc_transfers_direction_enum too narrow; payment_intents query used :tg with conflicting casts.
- Fix: v150_15

### logs_59111638616.zip — Pytest cascade + frontend lock grep
- Date: 2026-03-03
- Root cause:
  - transfers_log direction CHECK failed on non-canon direction values
    (bank_to_user/user_to_bank/noop), which aborted transactions and
    cascaded into panels/economics tests.
  - payment_intents_service had empty receiver address in CI.
  - withdraw concurrency test used amount below min withdraw.
- Fix: v150_17

### logs_59117257940.zip — Pytest: idempotency uniqueness + intent purpose bind
- Date: 2026-03-03
- Root cause:
  - efhc_transfers_log: уникальный ключ uq_efhc_transfers_idem_key
    нарушался при конкурентной записи лога (один idk два раза).
  - payment_intents: параметр purpose использовался как text и как
    varchar в одном SQL (asyncpg вывел AmbiguousParameterError).
- Fix: v150_21
  - transfers_log insert: ON CONFLICT(idempotency_key) DO NOTHING
    + read-through SELECT по idk.
  - payment_intents: CTE vals хранит purpose/idk как varchar один раз;
    далее используется vals.purpose/vals.ikey.

### logs_59118696585.zip — Pytest: TxResult fields + meta + panels archive
- Date: 2026-03-03
- Failures:
  - TypeError TxResult missing required fields in exchange_all reject.
  - UndefinedColumn extra_info in efhc_transfers_log queries.
  - payment_intents: missing FROM-clause entry for table "pi".
  - withdraw: wrong append_transfer_extra_info kwargs.
  - panels: tests expect is_archived column and archive flow.
- Root cause:
  - TxResult dataclass became strict; one reject path returned partial.
  - efhc_transfers_log column name is meta, but some services queried
    extra_info.
  - payment_intents read-through SELECT used pi.* without alias.
  - withdraw used old helper signature.
  - panels model lacked is_archived.
- Fix: v150_22

### CI.logs_59120872029.zip

- Symptom: 21 tests fail at collection/runtime with IndentationError
  in backend/app/services/withdraw_service.py:310.
- Root cause: accidental extra indent before await append_transfer_meta.
- Fix: align indentation; compileall passes.
- Guards/notes: repo-wide bans check would fail if literal user-id/u-id
  present; sanitized strings to tg_id.

### CI.logs_59122082604.zip

- Symptom: 6 failed tests (concurrency + payment_intents).
- Root causes:
  - d8 zero printed as 0E-8; tests expect 0.00000000.
  - tests selected extra_info but column is meta.
  - WithdrawRequestDTO not subscriptable; tests use dict-style.
  - wallets_service missing _confirm_payment_intent wrapper.
  - payment_intents.shop_external inserted NULL package_id.
  - BANK_EFHC not set in service due to config alias.
- Fix: v150_24.

## CI.logs_59123718270
- Symptom: pytest collection failed.
- Where: backend/app/standards/finance_rules.py:30
- Root cause: unexpected indent (duplicated lines after return).
- Fix: sanitize d8() function to valid quantize block.
- Zip: v150_25

## CI.logs_59124386845

- Symptom: pytest fails (8 tests).
- Where:
  - tests/architecture/test_no_banned_rank_terms.py
  - tests/architecture/test_no_tg_id_aliases_repo.py
  - tests/efhc_backend/unit/test_no_legacy_words.py
  - tests/test_concurrency_exchange_all.py
  - tests/test_concurrency_exchange_withdraw.py
  - tests/test_concurrency_withdraw_double.py
  - tests/test_payment_intents_lifecycle_double_payments.py
  - tests/test_payment_intents_payload_unique.py
- Root causes:
  - repo-wide bans tripped by internal report text containing forbidden
    legacy tokens.
  - users.available_kwh NUMERIC(?,8) returned as Decimal('0E-8') via
    asyncpg, but tests compare string forms ('0'/'0.00000000').
  - efhc_transfers_log.meta stored/returned as JSONB dict; tests read
    raw SQL and do json.loads(str(raw)), which fails on dict repr.
  - approve_withdraw_request required actor/idk args; tests call it with
    request_id only.
  - payment_intents: deposit intent response lacked to_address; shop
    external inserted NULL efhc_amount_d8 (NOT NULL constraint).
- Fix: v150_26 (sanitized docs, adjusted available_kwh typmod/cast,
  stored meta as JSON-string, made approve args optional, fixed payment
  intents fields).

## logs_59127346361 — SyntaxError in transactions_service f-strings

- Symptom:
  - SyntaxError: f-string: empty expression not allowed
  - Path: backend/app/services/transactions_service.py
- Root cause:
  - JSON literal "{}" used inside f-string SQL template.
- Fix:
  - Escape braces: "{{}}".
  - For meta merge, use CAST(meta AS jsonb) and return ::text.


## logs_59131187894 — v150_28

### FAIL: repo-wide bans (pytest)

- Симптом: падали архитектурные тесты на запретные термины.
- Где: reports/alias_sanitation_report_v150_27.md
- Root cause: в отчёте были записаны запрещённые токены подряд.
- Fix: отчёт заменён на безопасный текст без подряд идущих токенов:
  reports/alias_sanitation_report_v150_28.md

### FAIL: available_kwh строка нуля

- Симптом: test_concurrency_exchange_all ожидал "0"/"0.00000000",
  а получал "0E-8".
- Где: efhc_core.users.available_kwh (ORM Computed).
- Root cause: тип NUMERIC без scale.
- Fix: Numeric(30,8) + CAST(... AS numeric(30,8)).

### FAIL: payment_intents confirm (Insufficient bank funds)

- Симптом: тесты payment_intents падали ValueError: Insufficient bank
  funds.
- Root cause: watcher_service использовал
  transactions_service.credit_user_from_bank напрямую; монкипатч
  wallets_service.credit_user_from_bank в тестах не влиял.
- Fix: watcher_service вызывает
  wallets_service.credit_user_from_bank (реэкспорт).


## v150_29 — user_request_exclude_reports_audits

### FAIL: repo-wide bans из-за отчётов/аудитов

- Симптом: guard-тесты падали на исторических текстах в `reports/`,
  `audits/` и реестре ошибок.
- Root cause: repo-wide scan охватывал артефакты, которые по канону
  фиксируются 1:1 и могут содержать строки из CI.
- Fix: исключить `reports/`, `audit/`, `audits/` и
  `EFHC_ERRORS_REGISTRY_AND_GUARDS_TEAM.md` из guard-сканов.

### Канон: сериализация d8 (ноль)

- Симптом: в отдельных местах "0E-8" вместо "0.00000000".
- Root cause: `str(Decimal)` не гарантирует фиксированный формат.
- Fix: `d8_str()` возвращает `format(d, 'f')` после quantize.

## SEEN_AGAIN: withdraw approve без idempotency_key

- Симптом: concurrency approve тесты не передавали idempotency_key.
- Причина: контракт approve_withdraw_request не был жёстко задан.
- Фикс v150_30: сделать idempotency_key обязательным и добавить idem-hit.

## v150_31 — logs_59159509480

### ERROR: pytest collection IndentationError

- Симптом: pytest прерывается на collection.
- Где: tests/test_concurrency_withdraw_double.py
- Root cause: нарушена вложенность блока после `async def _approve()`.
- Fix: восстановлена корректная вложенность `async with Session()`.

## logs_59160577808 (SEEN)

1) available_kwh string mismatch
- Symptom: str(Decimal) == '0E-8' ломает тест на '0'/'0.00000000'.
- Fix: users.available_kwh -> numeric без typmod; выражение cast.

2) approve withdraw idempotency NameError
- Symptom: NameError _admin_approve_idem_hit.
- Fix: добавить helper, читать admin_action_log.

3) payment intents confirm
- Symptom: wallets_service.STATUS_CREDITED отсутствует;
  monkeypatch credit не срабатывает в разных модулях.
- Fix: реэкспорт STATUS_CREDITED; выбор credit hook в watcher_service.

## SEEN_AGAIN 2026-03-03 — d8/idem canon hardening
- approve_withdraw_request: use IdempotencyKey table, not admin logs.
- d8: avoid str(Decimal) asserts; use d8_str().

## logs_59167731792 (2026-03-03)
- pytest FAIL: NameError d8_str in test_concurrency_exchange_all
- pytest FAIL: idempotency_key UPDATE sql bindparam syntax
- pytest FAIL: wallets_service missing STATUS_ERROR_SYS

## 2026-03-03 v150_35

- SCHEMAS: removed dynamic schema facade to avoid name conflicts.

## logs_59169554348 (2026-03-03)

1) AdminLogger details_json bindparam casting
- Symptom: PostgresSyntaxError near ':' in INSERT admin_action_log.
- Root cause: ":details_json::jsonb" is not a valid bindparam cast
  with asyncpg ($1/$2 params).
- Fix: CAST(:details_json AS jsonb).

2) Withdraw approve concurrency non-determinism
- Symptom: two concurrent approve calls both returned success.
- Root cause: relying only on UPDATE ... WHERE status='PENDING'
  allowed both callers to observe success in this setup.
- Fix: add SELECT ... FOR UPDATE pre-lock and explicit status check
  before the atomic transition.

## logs_59170631954 (SEEN)

- Symptom: admin_action_log insert FK violation,
  admin_id not in admin_whitelist.
- Impact: transaction aborted; concur approve returned 2 ok.
- Fix v150_37:
  - Remove FK on admin_action_log.admin_id.
  - AdminLogger.write uses begin_nested() savepoint.

## SEEN — v150_38

- Admin approve withdrawal: конкурентный повтор
  должен возвращать 409 Conflict (already processed),
  а не 500.
  Fix: доменное исключение EfhcConflictError
  + маппинг на 409 в admin_withdrawals_routes.

## logs_59174134732 (2026-03-03)
- Root cause: app.services.__init__ выполнял агрегирующие импорты и создавал цикл;
  отсутствовал модуль app.services.common_errors.
- Fix: минимализировать __init__, добавить common_errors.

## v150_40
- Added facade modules to avoid __init__ aggregation loops.

## 2026-03-03 — logs_59176724950

- FAIL: SQLAlchemy mapper init.
- Root cause: relationship AdminActionLog.admin without FK.
- Fix: removed relationship; audit log keeps admin_id as plain BIGINT.

## 2026-03-03 — logs_59178178105

- FAIL: withdraw approve idem-hit падает NameError
  (_fetch_withdraw_request отсутствует).
  Fix: добавить helper SELECT по withdraw_requests.id.

- Security canon: require_admin обязан проверять
  efhc_admin.admin_whitelist; заголовкам не доверять.
  Fix: заменить проверку efhc_core.admin_nft_whitelist
  на efhc_admin.admin_whitelist (is_active=true).

## 2026-03-03 — logs_59179683846

- FAIL: withdraw approve tests (concurrency + idem)
  все вызовы упали с ValueError "admin not whitelisted".
- Root cause: service-level whitelist check активирован (правильно),
  но тесты не создают запись efhc_admin.admin_whitelist для actor_tg_id.
- Fix: tests seed admin_whitelist для actor_tg_id=900001.

### SEEN: logs_59176724950 — admin whitelist in tests
- Root: tests used hardcoded actor id, not seeded in whitelist.
- Fix: admin_tg_id fixture from settings + whitelist seed helper.

## 2026-03-03 v150_45

- Canon update: bank may be negative; removed stop-cran.
- Security: forbid virtual ROOT admin; whitelist only.

## 2026-03-03 v150_53

### SEEN: logs_59201398678 — DuplicateObject enum_admin_role
- Where: alembic upgrade head in tests fixture (db_migrated)
- Root: 0001_init create_all(checkfirst=False) re-runs in same DB;
  Postgres enum type already exists.
- Fix: create_all(checkfirst=True) + enum_admin_role schema=efhc_admin.

### logs_59203693346 — 0001 sanity missing tables
- Root cause: create_all unreachable due to indentation.
- Fix: unindent create_all + idempotent comment.
