# HEAL-0126 / CASE-0139 — закрытие фундамента без ложного доказательства

- Цикл: `1600`.
- Версия: `v171.97`.
- Риск: локальное закрытие диапазона может ошибочно разрешить backfill
  либо скрыть недоступность реальной PostgreSQL.
- Исправление: машинный шлюз закрытия, точный handoff, сохранённые
  блокировки backfill/read switch и отложенный GitHub CI.
- Статус: локальный фундамент закрыт; PostgreSQL proof обязателен.

# HEAL-0125 / CASE-0138 — PostgreSQL reconciliation gate

- Цикл: `1599`.
- Версия: `v171.96`.
- Причина: реальная PostgreSQL недоступна, поэтому коллизии и
финансовая сверка не могут считаться доказанными.
- Исправление: read-only environment preflight, reconciliation gate,
финансовый допуск `0.00000000` и fail-closed запрет historical
backfill.
- Guard: PostgreSQL gate, patch-boundary и русскоязычный guard.
- Статус: подтверждено; backfill остаётся запрещённым.

# HEAL-0122 / CASE-0135 — provider/system ID runtime separation

- Cycle: 1595.
- Severity: P1 architecture and future financial-ownership risk.
- Symptom: static aliases could document different identity spaces while
  still allowing raw integers to cross helper boundaries accidentally.
- Root cause: the contract existed, but backend identity values did not
  yet enforce nominal separation at runtime.
- Treatment:
  - immutable `UserId` and `TelegramId` value objects;
  - strict external `UserIdDisplay` and Pydantic-ready contract;
  - explicit database/external conversion boundaries;
  - 481-file semantic patch lock against premature runtime adoption;
  - fail-closed tg_id/provider/wallet-to-user_id guards.
- Runtime fix boundary: identity helpers only; no ORM, migration, owner
  query, AuthContext, balance or transaction change.
- Regression proof: 54 targeted tests and 2585/172 full regression result.
- Forbidden workaround: make `UserId` an `int` subclass, accept raw
  Telegram/wallet values, or wire the type into owner reads before expand
  and reconciliation gates.

---

# HEAL-0121 / CASE-0134 — canonical UserId guard compatibility

- Cycle: 1594.
- Severity: P1 architecture and delivery-gate conflict.
- Symptoms:
  - a legacy test rejected the new canonical `user_id` spelling itself;
  - cycle-numbered technical filenames violated archive hygiene;
  - a flat path-to-SHA JSON manifest violated the 72-character gate;
  - release version surfaces still named the previous HEAD.
- Root cause: pre-migration quality guards encoded the historical
  Telegram-only naming model and were not yet aligned with the approved
  provider-independent identity doctrine.
- Treatment:
  - explicitly allow only canonical `user_id` and `tg_id` spellings;
  - continue rejecting ambiguous aliases such as `userid`, `userId`,
    `telegram_id` and `tgId`;
  - use semantic technical filenames without cycle-number suffixes;
  - preserve all 485 protected hashes in line-safe `path_parts` and
    `sha256_parts` entries;
  - synchronize release policy, assets, images and environment examples.
- Runtime fix: none; schema and ownership remain unchanged.
- Guards:
  - `tests/test_no_banned_identifiers.py`;
  - `tests/architecture/test_archive_filename_hygiene.py`;
  - `tests/architecture/test_max_line_length_72.py`;
  - `tests/architecture/test_release_v171_71_frontend_build_repair.py`;
  - `ops/identity/check_user_id_contract_patch_boundary.py`.
- Prohibited workaround: allow arbitrary aliases, exempt the new identity
  package from quality gates, remove protected hashes, or rename an old
  archive without factual changes.

---

# HEAL-0115 / CASE-0124 — trusted frontend source recovery with proof boundary

- Cycle: 1573 frozen.
- Severity: P1.
- Confirmed causes:
  - late compact header/profile CSS overrides displaced the trusted visual direction;
  - split whole/fraction balance rendering violated the user requirement that all digits have one size;
  - settings discoverability was repaired with a large text action before the user clarified the canonical compact gear treatment;
  - old tests continued to defend invalid synthetic/compact behavior.
- Treatment in v171.61:
  - restore trusted header/profile source geometry;
  - render the entire exact balance as one tabular-numeric text run;
  - keep a compact settings gear strictly inside Profile;
  - freeze exactly six bottom game-navigation items;
  - replace stale proof guards with equal or stronger route-backed guards;
  - require real `page.goto()` application evidence.
- Current boundary: source repair is confirmed; real build/typecheck and fresh application screenshots remain open and cannot be substituted.

---

# HEAL-0114 / CASE-0123 — governance route drift and false application proof

- Cycle: 1573 frozen.
- Severity: P0.
- Confirmed causes:
  - multiple competing startup orders;
  - Kernel accumulation of historical Current HEAD blocks;
  - persistent-sandbox assumption;
  - over-broad user-owned-CI prohibition;
  - manual HTML / `page.set_content` presented as application screenshot proof;
  - reports/Healer/SSOT validating self-authored manifests instead of runtime.
- Treatment in v171.60:
  - single `START_HERE.md`;
  - navigation-only Kernel;
  - corrected AI laws, lock, CANON, NORM and execution bounds;
  - route/file-map start core synchronization;
  - invalid proof scripts removed from active ops;
  - machine guards added.
- Current boundary: no runtime repair claimed; route-backed visual audit remains required.

---

# HEAL-0113 / CASE-0122 — SUPERSEDED / INVALID APPLICATION-PROOF CLAIM

- The source repairs in v171.59 (ProfileModal mounting and balance numeral normalization) remain source changes.
- The claimed application screenshot proof is invalidated by `HEAL-0114 / CASE-0123` because it used manual HTML / `page.set_content`, not the running application routes.
- The 31 targeted checks did not prove the real application UI.
- Status: historical record retained for traceability; application-proof claim must not be reused.
---

# Critical incident follow-up — v171.57 live contour evidence gate

- Healer card: `HEAL-0112`.
- Casebook case: `CASE-0121`.
- Cycle: `1573`, still active.
- Treatment update: added a fail-closed live contour evidence intake gate for live Telegram, real TonConnect, real TonProof and real transaction proof.
- Current blocker: `BLOCKED_MISSING_LIVE_EVIDENCE`.
- Guard: `tests/architecture/test_live_contour_gate.py`.
- Generated evidence: `reports/generated/cycle_1573_live_contour_gate_v171_57.json`.
- Forbidden: do not advance to cycle 1574 and do not claim live proof until all four contours are factual and accepted.
---

# Critical incident — v171.55 fail-closed delivery protocol

- Healer card: `HEAL-0112`.
- Casebook case: `CASE-0121`.
- Severity: `P0`; zone: `red_protocol_blocked`; priority: `immediate`.
- Disease: stale HEAD, invalid screenshot provenance, premature cycle
  advancement or unverified archive delivery being presented as a complete
  canonical transfer.
- Treatment: `docs/NORM/HEALER_CRITICAL_DELIVERY_PROTOCOL.md` plus executable
  gate `ops/healer/check_critical_delivery_protocol.py`.
- Fail-closed state: `BLOCKED_PROTOCOL`.
- Release state after all checks: `USER_DELIVERY_ALLOWED`.
- Prevention: synchronized control documents, Healer triple-write, explicit
  screenshot mode, independent ZIP/hash verification and PASS delivery receipt.
- Cycle 1573 remains active.
---

# HEALER — work item 1572 execution-loop and PNG/CI repair

Closed locally:

- `C1572-CI-PNG-EVIDENCE-BLOCKING`;
- `C1572-AI-FULL-CI-SCOPE-OVERRUN`;
- `C1572-CHROMIUM-RETRY-LOOP`;
- `C1572-NPM-EXTERNAL-RETRY-LOOP`;
- `C1572-ARCHIVE-DELAYED-BY-OPTIONAL-EVIDENCE`.

Treatment:

- PNG checks are marked `visual_evidence` and excluded from blocking CI;
- the user owns full GitHub CI by default;
- the AI uses targeted checks and packages after the requested repair;
- Chromium and external registry failures have mandatory stop conditions;
- optional audits cannot block archive delivery;
- every transfer archive includes `CONTINUE_IN_NEW_CHAT.md`.

Work item 1572 remains active; fresh GitHub CI is not claimed.

---

# HEALER — full regression and workflow normalization v171.47

Closed locally:

- `C1571-CI-SW-GUARD-STALE`;
- `C1571-CI-LOCALE-COUNT-DRIFT`;
- `C1571-CI-OPENAPI-ROUTE-DRIFT`;
- `C1571-CI-TONCONNECT-LAZY-GUARD`;
- `C1571-CI-ARCHIVE-NAME-FALSE-POSITIVE`;
- `C1571-CI-WORKFLOW-DIVERGENCE`;
- `C1571-FAQ-WORKER-UNAVAILABLE-FATAL`;
- `C1571-CACHE-BYTE-LIMIT-MISSING`;
- `C1571-PERSISTED-CATALOG-BOUNDARY`.

Treatment:

- the full regression runner collects unique node IDs, checkpoints batches
  and is shared by local and GitHub workflow paths;
- FAQ Worker failure falls back to the same bounded main-thread search;
- locale/FAQ downloads use checksums;
- cache tiers enforce entries, bytes and age;
- persistence is requested only after install or explicit action;
- learned prefetch excludes Admin and financial routes;
- React Query persistence accepts only immutable public-static catalogs;
- Admin datasets above 10000 local rows use Worker filtering;
- Web Vitals aggregate p50/p75/p95 by platform and build ID.

External boundary:

Fresh GitHub CI, production cache eviction/persistence, field Web Vitals,
live Telegram, real wallet/network operations and release readiness remain
unverified.

---

# HEALER — observability, deployment and rollback v171.44

Closed locally:

- `C1567-CI-NUMBERED-WORK-PASS-LABELS`;
- `C1567-CI-SCREENSHOT-COMPANION-DRIFT`;
- `C1567-AXIOS-HIGH-ADVISORY`;
- `C1567-MONETARY-API-PREFIX-BYPASS`;
- `C1567-DB-ERROR-DISCLOSURE`;
- `C1567-SENSITIVE-LOG-FIELDS`;
- `C1567-SECURITY-HEADERS-MISSING`;
- `C1567-REQUEST-BODY-UNBOUNDED`;
- `C1567-LEGAL-POLICY-SURFACE-MISSING`;
- `C1567-LEGAL-ONBOARDING-OBSTRUCTION`.

Treatment:

- screenshot guards validate the companion manifest, path, size and SHA-256;
- Axios is updated to a non-vulnerable exact version;
- API-prefix normalization protects monetary rate-limit and idempotency;
- backend/frontend security headers and bounded request bodies are active;
- public infrastructure errors are generic;
- structured logs recursively redact sensitive proof and key fields;
- Privacy and Terms are rendered in all thirteen canonical languages;
- first-launch onboarding does not cover active legal surfaces;
- TonConnect manifest legal URLs point to active in-app surfaces.

Open evidence boundary:

- nonce/hash CSP migration;
- production secret inventory and rotation;
- automated data-rights operations;
- broad non-monetary abuse budgets;
- incident-response exercise;
- fresh GitHub CI, live Telegram and real network proof.

---

# HEALER — TonConnect reactive restore and proof-envelope repair

Closed locally:

- `C1563-TONCONNECT-NONREACTIVE-WALLET-STATE`;
- `C1563-TONPROOF-INCOMPLETE-BIND-ENVELOPE`;
- `C1563-RESTORE-SETTLED-CONNECTED-CONFLATION`;
- `C1563-CONNECTION-REJECTION-GENERIC-ERROR`;
- `C1563-TRANSACTION-REJECTION-GENERIC-ERROR`.

Root cause:

The compatibility hook returned a connector property without a React
subscription, and the frontend checked a proof before sending an incomplete
wallet-binding body. Existing guards verified function names but did not prove
that the full proof envelope reached `/wallets/connect` or that restore changed
the rendered state.

Treatment:

- connector status is now reactive;
- restore settlement is separate from restored connectivity;
- one complete proof envelope is submitted to the binding route;
- rejection code `300` has a dedicated visible state;
- transaction UX distinguishes signing, signed, rejected and failed states;
- browser and Ed25519 boundary tests protect the repaired chain.

External boundary:

A real wallet signature and real network transaction are not claimed.

---

# HEALER — current closure v171.36

Closed locally:

- `C1561-DIRECT-DEPOSIT-NATIVE-TON-CONTOUR-REPAIR`;
- `C1561-FUNDING-CONTOUR-ANTI-MIXING-GUARD`;
- `C1561-BROWSER-SHOP-TON-USDT-RESTORE`;
- `C1561-WITHDRAW-REACT-QUERY-LINKAGE`;
- `C1561-ENERGY-RATE-PRECISION-VISUAL-PROOF`.

Root cause:

The existing tests encoded a temporary native-TON Direct Deposit and
TON-only shop model. Green tests therefore protected the wrong model.
The repaired guards now compare the header `+`, HUB, Browser Shop,
watcher asset and public labels as one cross-contour contract.

Open evidence boundary:

- real EFHC jetton transfer is not executed locally;
- real USDT jetton purchase is not executed locally;
- admin Withdraw browser proof remains open;
- real payout, live Telegram and GitHub CI remain external.

---

# HEALER — current closure v171.35

Closed locally:

- `C1560-HUB-TWO-ACTION-LINKAGE`;
- `C1560-DIRECT-DEPOSIT-AMOUNT-WALLET-HANDOFF`;
- `C1560-WATCHER-HISTORY-RECONCILIATION`;
- `C1560-DIRECT-DEPOSIT-HUMAN-STATUS`;
- `C1560-HUB-DEPOSIT-RESPONSIVE-VISUAL-PROOF`.

External proof remains open for live Telegram and a real TON payment.

---

# Current release healer update

## HEAL-0159 — profile duplication and history linkage repair

- Severity: P1 MVP usability, state and responsive presentation.
- Status: locally treated; external release proofs remain open.
- Root causes: three simultaneously mounted account surfaces, manual
  history cursor state and viewport rules concentrated around one phone
  width.
- Treatment: one routed Profile surface, typed Zod services, React Query
  history pagination and an explicit multi-viewport responsive contract.
- Proof: four responsive viewport checks, five surface screenshots and
  twenty-six Profile/FAQ language screenshots.
- Guards: current profile query guard, responsive release guard, legacy
  replacement guards and browser E2E.
- Forbidden action: do not restore simultaneous account dashboards or
  reduce the language scope below the canonical thirteen.

---

# Current release healer update

## HEAL-0158 — referral/ranks runtime and icon repair

- Severity: P1 MVP usability and linkage.
- Status: locally treated; external release proofs remain open.
- Root causes: page-owned or direct transport state, competing dashboard
  surfaces, unscoped referral bind marker, dense legacy coin image and
  inconsistent navigation symbols.
- Treatment: typed services and React Query hooks, retry-safe bind state,
  one kWh-only Ranks surface, universal energy SVG and one six-icon system.
- Guards: `test_referrals_ranks_navigation_current_release.py`, referral
  backend tests and the current browser interaction test.
- Forbidden action: do not restore direct public transport, fake ranks,
  `Total` in the header or mixed navigation icon families.

---

# Healer update — Tasks, Ads alias and compact typography

Closed findings:

- `C1557-TASKS-SINGLE-QUERY-CATALOG`: one routed catalogue now owns Tasks.
- `C1557-ADS-STATUS-REFETCH-GAP`: `/tasks/my` merges submissions and
  `user_tasks_status` so automatic rewards become visible after refetch.
- `C1557-TASK-CLAIM-BALANCE-READER`: claim replay uses the existing balance
  snapshot service instead of a nonexistent function.
- `C1557-MODAL-NAV-OVERLAP`: shared modals render through a body portal above
  fixed bottom navigation.
- `C1557-GLOBAL-TYPOGRAPHY-COMPACT-ARIAL`: global Arial-like compact scale and
  one-line Panels/Exchange values are protected by browser evidence.

No economy, payment, auth, database schema or migration canon changed.

Exact regression: `2389` nodes, `2263 passed`, `126 skipped`,
`0 failed`. Final browser E2E: `2 passed`.

---

# Healer update — Panels, Exchange and release readiness

Closed findings:

- `C1556-PANELS-REACT-QUERY-LINKAGE`: panel list, summary and activation
  now use validated service and React Query state with dependent invalidation.
- `C1556-EXCHANGE-PAGE-HOOK-BYPASS`: preview and conversion hooks now own
  the visible Exchange state and balance refresh.
- `C1556-ECONOMIC-SEAM-GENERATOR-DRIFT`: checked-in DTOs and validators
  reproduce from the canonical generators.
- `C1556-DUPLICATE-PANELS-EXCHANGE-SURFACES`: each routed page now exposes
  one active user flow; retained legacy sources have replacement mapping.
- `C1556-PANELS-EXCHANGE-BROWSER-INTERACTION-PROOF`: browser actions at
  `390x844` proved panel activation and `10 kWh` conversion with refetch.
- `C1556-NEXT-BUILD-PROCESS-BOUNDARY`: blocking typecheck precedes Next;
  two consecutive standard builds exited naturally and verified all routes.
- `C1556-RELEASE-READINESS-MASTER-PLAN`: the fail-closed release register
  defines twelve domains, 81 checkpoints and exactly 100 evidence points.

Full regression covered one inventory of `2379` unique test nodes:
`2255 passed`, `124 skipped`, `0 failed`. No test was omitted, deleted or
newly skipped/xfail-marked.

Open evidence finding:

- `C1556-POSTGRES-TRANSACTION-PROOF-ENV`: route/service boundary proof
  passed, but real PostgreSQL atomicity, rollback and concurrent replay
  remain assigned to the database reliability stage and fresh CI.

No economic, payment, auth, DB schema or migration canon changed.

---

# Healer update — shell, Energy runtime and public browser proof

Closed findings:

- `C1555-LANGUAGE-SCOPE-COMPRESSION`: the operator no longer treats
  `RU/UK/EN`, three external sites or English visual navigation labels as the
  complete EFHC Bot locale scope. The exact runtime canon is thirteen.
- `C1555-SHELL-BROWSER-FALLBACK-DUPLICATION`: browser mode now displays one
  compact notice and the real routed screen instead of a second fake Energy
  surface.
- `C1555-ENERGY-FIRST-PAINT-ZERO-FLASH`: initial progress is derived from the
  validated snapshot and exact zero no longer renders a fake minimum.
- `C1555-PUBLIC-BROWSER-PROOF-PROXY`: the local visual harness works under
  the managed Chromium local-URL block without changing system policy.
- `C1555-NEXT-BUILD-WORKER-DETERMINISM`: the default production build uses
  one deterministic worker while preserving an explicit environment override.

Public proof passed for twelve protected routes and all thirteen canonical
languages at `390x844`.

Open evidence item:

- `C1555-ADMIN-VISUAL-HARNESS-SEQUENTIAL-BLOCK`: the legacy admin proof
  process still requires isolated batch execution. Admin visual success is
  not claimed.

No economic, backend, payment, wallet, auth, DB or migration canon changed.

---

# Healer update — MVP Energy and frontend shell repair

Closed findings:

- `C1554-SNAPSHOT-SERVICE-DTO-CHAIN`: direct transport access and a manually
  duplicated snapshot type were replaced by Zod DTO, service and React Query
  query-key linkage.
- `C1554-ENERGY-TRIPLE-SURFACE-REPAIR`: three simultaneous Energy surfaces
  were reduced to the generated-kWh hero plus one cohesive MVP summary.
- `C1554-CANONICAL-SHELL-WIRING`: active `Layout` now uses the canonical shell
  root, frame and main primitives without changing protected navigation.
- `C1554-NEXT-BUILD-WORKER-BOUND`: production compilation uses the stable
  official webpack path, `prebuild` removes only `.next` and
  `tsconfig.tsbuildinfo`, and page collection is bounded. Two consecutive
  clean standard builds completed on the operator host.

Evidence limitation:
`C1554-VISUAL-PROOF-ENVIRONMENT-BLOCK` remains an external proof blocker. The
managed Chromium policy blocks localhost and no alternate Playwright browser
was available. No screenshot success is claimed.

No economic, payment, wallet, withdraw, auth, DB or migration canon changed.

---

# Healer update — Fresh CI archive and skills log repair

The uploaded CI log for `v171_27` was red on `ruff` and `pytest`.
The repair closed stale and hygiene failures left after the archive-purity
and Agent Skills cycles: unused variables in tests, missing fail-closed
release wording, CI-created local log artifacts, line72 drift and legacy
Ranks-forbidden substrings in adapted skills/personas.

No runtime business logic, money-flow, wallet, TonConnect, withdraw,
auth, DB or migration logic was changed.

---

# Healer update — Archive Purity / Naming Guard Repair

The prior archive carried a transient runtime log artifact. The repair removes
that artifact from the release tree, strengthens hygiene guards and changes the
active filename convention to a short archive name: `EFHC_Bot_v171_27.zip`.

No runtime business logic, money-flow, wallet, TonConnect, withdraw, auth, DB or
migration logic was changed.

---

# Healer update — Agent Skills Adapter Fix

This pass repaired foundation defects left by the Agent Skills Adapter
integration. The repair keeps Agent Skills subordinate to AI Archive Laws, SSOT
and NORM, and hardens the adapter scanner so invalid command TOML and broken
persona links cannot pass silently.

The public UI direct API gate now also covers EventSource and WebSocket in
public UI zones. No runtime business logic, money-flow, wallet, TonConnect,
withdraw, auth, DB or migration logic was changed.

---

# Healer update — Agent Skills Adapter Foundation

The previous Agent Skills foundation pass added Agent Skills as an EFHC-controlled workflow layer. The repair
closed the missing agent-entrypoint gap without modifying runtime business
logic. Root `AGENTS.md`, `CLAUDE.md`, EFHC adapter docs, adapted skills,
commands, personas and scanner/guard are now present.

Agent Skills remain subordinate to AI Archive Laws, SSOT and NORM. Local checks
are not GitHub CI. Release-ready and production-ready are not claimed.

---

# Healer update — Fresh CI Service API Gate Log Repair

The uploaded fresh CI log `logs_74815399993.zip` was red on `pytest` only.
The repair updated stale architecture guards that still expected API constants
and route strings directly in public UI pages after the DTO / Service API /
React Query migration gate moved those roads into services and hooks.

The public UI direct API gate and public copy firewall remain enabled. No
economy, wallet, TonConnect, idempotency, withdraw or money-flow logic was
changed. Not claimed: GitHub CI green for output `v171.24`, full pytest green,
frontend build green, visual runtime verified, live Telegram proof, real
TonConnect proof, release-ready or production-ready.

---

# Healer update — API Service React Query Migration Gate

Closed locally:

- `PUBLIC_UI_DIRECT_API_GATE` — public UI zones cannot call API directly.
- `DTO_SERVICE_LAYER_FOR_P0_FLOWS` — P0 flows now use service boundaries.
- `REACT_QUERY_STANDARD_DOCUMENTED` — query keys and query layer created.
- `PUBLIC_COPY_FIREWALL_STILL_PASSING` — copy firewall remains active.

Safety note: no economy, wallet, TonConnect, idempotency, withdraw or
money-flow logic changed.

---

# Healer note — v171.22 fresh CI public-copy log repair

The uploaded fresh CI log `logs_74688208405.zip` was red only on `ruff` and
`pytest`. The repair closed tool/guard drift created by the public-copy
firewall and visual-proof work: scanner style, import ordering, public FAQ
copy cleanup, regenerated FAQ catalog, non-English profile empty-state copy
and stale exact-copy tests.

No economy, wallet, TonConnect, idempotency, withdraw or money-flow logic was
changed. Not claimed: GitHub CI green for output `v171.22`, full pytest green,
frontend build green, visual runtime verified, live Telegram proof, real
TonConnect proof, release-ready or production-ready.

---

# Healer note — v171.21 visual proof splash settle guard

Visual proof repair pass repaired visual proof infrastructure, not the product UI. The
public/admin screenshot scripts now wait for shell readiness, wait for splash
hidden state and enforce a fixed minimum settle time of `2500ms` before a
screenshot can be accepted. Successful records must include
`splash_visible: false`.

Not claimed: GitHub CI green, full pytest green, frontend build green, visual
runtime verified, live Telegram proof, real TonConnect proof, release-ready or
production-ready.

---

# Healer note — v171.20 public copy firewall guard

Public copy firewall pass enabled a public-copy firewall so technical development wording
cannot silently return to user-visible EFHC Bot screens. The repair adds a
policy JSON, a scanner, a pytest guard, Makefile/frontend command linkage,
public documentation and locale/source copy cleanup. The guard scans public
locale values, likely visible JSX text and visible string attributes while
excluding backend, tests, docs, reports and closed admin/internal zones.

Not claimed: GitHub CI green for output `v171.20`, full pytest green,
frontend build green, DOM visual proof, live Telegram proof, real TonConnect
proof, release-ready or production-ready.

---

# Healer note — v171.19 fresh CI memo log repair

Memo log repair pass repaired uploaded CI log `logs_74672087378.zip` after work pass 1543.
The active failures were guard/tooling drift, not money-flow regression:
ruff style in new tests, mypy typing at the watcher memo adapter boundary,
and stale i18n key-count guards. The memo SSOT repair remains protected;
the watcher still uses `parse_memo_for_watcher(...)`, and the architecture
guard now checks that semantic bridge instead of one exact return string.

Not claimed: GitHub CI green for output `v171.19`, full pytest green,
frontend build green, live Telegram proof, real TonConnect proof,
release-ready or production-ready.

---

# Healer note — v171.18 memo canon / webhook / raw error repair

Audit/TZ `a_v171_17.md` and `tz_v171_17.md` were repaired locally. The
release blocker `P0-MEMO-CANON-DUPLICATION-AND-DRIFT` is closed by making
`backend/app/integrations/ton_memo.py` the single source of truth and making
the watcher consume `parse_memo_for_watcher(...)`. The official direct deposit
memo `EFHC:<tg_id>` is now recognised by watcher parser tests. Panels
activation UX, webhook defensive commit/rollback, admin raw error tails, raw
error guards and middleware transaction-boundary comment drift were also
closed. Manual fallback remains a safety net, not the primary success path. No
economy, rates, balances, wallet binding, TonConnect proof, idempotency,
money-flow, referral bonus amount or withdraw business logic changed.

---

# Healer note — v171.17 fresh CI rerun guard repair

Uploaded log `logs_74653569841.zip` was red only on one stale pytest guard.
The CI log already had flake8, ruff, mypy backend/app, bandit, compileall,
Alembic, npm ci and frontend build passing. The repair changes the historical
referral import-block assertion from exact whitespace to semantic import checks
and adds a work pass guard for the no-overclaim boundary. No economy, rates,
balances, wallet binding, TonConnect proof, idempotency, money-flow, referral
bonus amount or withdraw business logic changed.

---

# Healer note — v171.16 fresh CI frontend-noise log repair

Uploaded log `logs_74645134614.zip` was red on `ruff` and `pytest` for the
frontend error-noise cleanup output. The repair keeps the user-facing safe
error-state canon and fixes the actual logged drift: import ordering,
stale guards that still expected duplicate error toasts, stale ErrorBoundary
assertions, untranslated non-English public error-state strings, PWA offline
shell compatibility, line-length hygiene and root documentation hygiene.
No economy, rates, balances, wallet binding, TonConnect proof, idempotency,
money-flow, referral bonus amount or withdraw business logic changed.

---

# Healer note — v171.15 frontend error-noise cleanup

Audit/TZ `a_v171_12.md` and `tz_v171_12.md` were treated in the latest frontend error-noise pass. The repair removes raw HTTP/backend/exception text from primary frontend UI through structured `ApiError`, public/admin safe mappers, ErrorBoundary safe fallback, public profile/shop cleanup, admin safe summaries, non-duplicating error channels, deduped accessible toast layer, route/offline product fallbacks and calm i18n copy. Chat 36 was added to the canonical chat section. Economy, rates, balances, wallet binding, TonConnect proof, idempotency, money-flow, referral bonus amount and withdraw business logic were not changed.

---

# Healer note — v171.14 proof-gate refresh

Fresh CI/live referral proof gate was refreshed fail-closed. No new external
`logs_*.zip`, audit or TZ evidence was provided, so no CI green or live proof
is claimed. Added a guard for the no-overclaim boundary and refreshed Kernel,
map, reports, work passes and operator-kernel routing. No runtime economy,
money-flow, withdraw, wallet, TonConnect, referral bonus or frontend money
semantics changed.

---

# Healer note — v171.13 artifact hygiene repair

Fresh CI artifact hygiene drift from `logs_74600883162.zip` was repaired locally:
ruff import ordering, transient frontend build-info artifact, stale route
count markers and bot middleware identity spelling. No runtime economy,
money-flow, withdraw, wallet or TonConnect semantics changed.

---

# Referral persistence webhook repair healer note

Audit/TZ `a_v171_11.md` and `tz_v171_11.md` were treated locally.
Root causes were missing explicit commit boundary after referral attach,
Telegram webhook bypassing `process_update(db, payload)`, source-only
route proof, exchange fallback dead branch and non-retryable WebApp bind
marker. Economy, money-flow, withdraw canon and TonConnect were unchanged.

---

# Fresh CI referral log repair healer note

Red CI evidence from `logs_74569153381.zip` was treated locally. Root
causes were import ordering, start payload return typing, locale fallback
coverage and OpenAPI/static route drift after referral bind endpoints.
Runtime economy and money-flow were unchanged.

---

# Referral binding / UX healer note

Closed local repair from `a_v171_09.md` / `tz_v171_09.md`:

- referral deeplink entrypoint now reaches backend attach service;
- WebApp start_param fallback is best-effort and authenticated;
- public error messages no longer expose raw withdraw exceptions;
- exchange mutation uses operation-specific error copy;
- first-run onboarding is implemented as UI-only state.

No runtime code was copied from Песочница.

---

# Scheduler notify/facade signature drift healer note

Closed findings from `a_v171.07.md` / `tz_v171.07.md`:

- withdrawals processor stale alert notify drift;
- daily reports notify drift;
- admin facade approve/reject withdraw contract drift;
- mypy staged scope expansion for scheduler/facade files.

No runtime code was copied from Песочница.

---

# HEALER NOTE — fresh CI / mypy scope log repair

This pass repairs red CI evidence from `logs_74475316189.zip`. Root causes: ruff I001 in
new tests and stale exact-version Kernel guard. Runtime and economy unchanged.

---

# HEALER NOTE — v171.06 global signature drift fix

Current pass closes the global kwarg/signature mismatch class found in
`v171.05`. Guard anchor: `tests/architecture/test_backend_signature_drift.py`.
Release remains fail-closed until fresh CI for `v171.06` plus live Telegram
and real TonConnect proof.

---

## HEAL-1524 — withdrawals runtime test isolation repair

- Cycle: current fresh CI repair.
- Severity: CI red / test isolation defect.
- Status: locally treated; fresh CI rerun required for output archive.
- Symptom: `logs_74379950976.zip` showed two pytest failures in
  `test_admin_withdrawals_list_runtime.py` caused by duplicate empty
  `users.ton_wallet` values under `uq_users_ton_wallet`.
- Treatment: DB-backed withdrawals runtime test helpers now insert `NULL`
  for absent legacy wallet values.
- Guard: `tests/architecture/test_withdrawals_runtime_wallet_null_fixture_guard.py`.
- Forbidden action: do not restore empty-string wallet fixtures for users who
  have no legacy `users.ton_wallet` value.

## 2026-06-16 — v170.99 P0 admin withdrawals list regression fix

- Finding: `P0-ADMIN-WITHDRAWALS-LIST-ALWAYS-EMPTY`.
- Symptom: `GET /admin/withdrawals` could return an empty queue because
  `list_withdrawals()` depended on absent legacy `bonus_awards`.
- Treatment: remove the legacy guard from live `withdraw_requests` list
  flow; keep the guard only in legacy bonus-award methods.
- Tests: service runtime, route runtime, AST guard scope and previous repair
  regression guard added.
- Release remains fail-closed until fresh CI, live Telegram and real
  TonConnect proof are supplied.

## 2026-06-05 — v170.22 CI rerun CI rerun log repair

- Source logs: `logs_72627437860.zip`.
- Failing gates were read first: ruff and pytest.
- Treatment: repair ruff import ordering in admin bank / transactions
  service files and add the required historical status note to
  `ROUTE_INVENTORY_FREEZE.md`.
- Guard impact: `tests/architecture/test_ci_log_repair_guards.py` added.
- No runtime economy, migration, CI/workflow or lock-file change.
- Release-ready remains forbidden until fresh CI and release audit proof.

## 2026-06-05 — v170.20 step 1444 linkage repeat audit + HEALER tail reconciliation

- Local repeat audit for active linkage findings `F-001…F-008` produced `status=ok` and `blockers=[]`.
- New report: `reports/generated/linkage_repeat_audit_healer_tail_v170_20.json`.
- New guard: `tests/architecture/test_linkage_repeat_audit_healer_tail.py`.
- HEALER loader tail repaired: `ops/healer/loader.py` now normalizes historical compact atlas/casebook entries into the strict dataclass boundary.
- `ops/healer/run_once.py` now accepts both explicit `atlas_version`/`casebook_version` and compact `version` keys.
- `F-006` remains live FastAPI proof pending; release-ready is still forbidden without external proof gates.

## 2026-06-05 — v170.19 step 1443 full linkage guard tail

- `F-007` is locally guarded: critical API-driven UI surfaces now have static loading/error/empty state checks.
- `F-008` is locally guarded: frontend API calls are checked against backend routes and OpenAPI through the full linkage scanner.
- New scanner: `ops/linkage/build_full_linkage_report.py`.
- New report: `reports/generated/full_linkage_report_v170_19.json`.
- Remaining HEALER tail is not hidden: repeat linkage audit, fresh CI/log proof and release audit are still required before release-ready language.

## 2026-06-05 — v170.17 step admin-wallet-reset audit/HEALER tail routing

- `F-005` admin wallet reset semantic mismatch is locally repaired: reset now clears legacy `users.ton_wallet` and deactivates canonical `wallet_bindings`.
- Remaining linkage tails are not hidden:
  - `F-006` OpenAPI incomplete/stale routes → OpenAPI gate.
  - `F-007` critical UI loading/error/empty-state guard tail → full linkage guard pass.
  - `F-008` frontend API call → backend route guard tail → full linkage guard pass.
- HEALER/fresh-proof tails remain visible: repeat linkage audit, fresh CI/log proof and release audit are still required before release-ready language.
- Next bounded tail repair slots: OpenAPI gate OpenAPI gate, full linkage tests, repeat audit + HEALER reconciliation, CI/log proof if logs are supplied.

## 2026-06-04 — v169.96 CI log-repair update

- Latest supplied CI logs were read first.
- The only failing gate was pytest; exact failures were repaired by root cause.
- FSM background tasks now use `create_logged_task()` instead of raw `asyncio.create_task()`.
- Non-exception numbered work-pass wording was removed from Healer/backend/source comments.
- `HEAL-0055` Atlas confirmation now reflects the completed DB-backed non-expiring deposit idempotency repair.

## 2026-06-04 — v169.89 HEAL-0023 / HEAL-0018 work pass note

- `HEAL-0023`: explicit `IDEMPOTENCY_CONFLICT:<key>` is now a first-class idempotency conflict marker in `transactions_service._is_idempotency_conflict()`. Direct case-sensitive branch checks were replaced with the shared helper.
- `HEAL-0018`: transaction-boundary map was created before runtime repair. This prevents blind nested-transaction edits and preserves controlled work pass discipline.
- Next treatment: repair pass transaction-boundary repair, then repair pass withdraw/exchange atomicity.

## 2026-04-08 dead-but-needed modules require revival, not deletion

- Если модуль или компонент выглядит мёртвым по смысловому аудиту, но
  пользователь подтвердил, что он нужен, следующий шаг — не удаление, а
  план по подключению, ремонту и повторной интеграции.
- Дубли по таким зонам сначала сравниваются, данные переносятся,
  пользователю показывается предложение на согласование, и только потом
  допускается удаление одного из дублей.

## 2026-04-08 archival baskets must be skipped by canon guards

- После переноса старых документов в `artifacts/` guard-тесты не должны
  читать эту архивную корзину как активный кодовый или документный слой.
- Иначе пользовательское согласованное архивирование начинает ломать CI
  бан-словами и legacy терминами из исторических файлов.

## 2026-04-08 high-impact historical audit stubs must stay visible

- Даже после зачистки старых audit-файлов несколько high-impact
  historical docs должны оставаться в `docs/audits/`, если на них
  завязаны guard-тесты и continuity status-notes.
- Нельзя убирать такие документы из active docs surface, пока test-layer
  и control-layer ещё требуют их присутствия.

## 2026-04-08 transferred audit backbone

- Economy Healer backbone: bank split-brain, mirror direction drift,
  idempotency conflict drift, exchange autobegin drift, energy
  `_begin_tx` recursion, self-healing queue breakage, shop
  schema/reporting mismatch.
- Release Healer backbone: transient junk in ZIP, nested release ZIP
  relapse, build-script drift, confusion between transient junk and
  `artifacts/`.
- Frontend/UX Healer backbone: visual white spots, inconsistent
  loading/error/empty states, wording drift after canon updates, browser
  shop / hub residual mismatches.
- Process Healer backbone: false work pass closure, GitHub CI ownership
  drift, stale cycle-control panel, dependency-precheck drift, keeping
  unique errors only in old audits/reports.

## 2026-04-08 transferred reports backbone

- Старые reports перенесены из active surface; уникальная память по
  исправлениям должна сохраняться в Healer, work pass docs и свежих
  `change_cycle_*`.
- Legacy report naming (`change_report_*`, internal logs, alias
  sanitation reports и т.п.) больше не должен быть главным носителем
  решений.

## 2026-04-08 audit debt must move to Healer

- Старые audit-файлы не должны оставаться единственным носителем ошибок
  проекта.
- Перед будущей зачисткой `docs/audits/` нужно перенести economy,
  release, self-healing, frontend, cycle-control и process defects в
  Healer как долговременный memory-layer.
- `_raw` допустим как evidence-архив, но не как место, где живут
  уникальные ошибки без переноса в Healer.

## 2026-04-08 reports retention debt

- Раздел `reports/` разросся до большого исторического слоя;
  каноническая память должна остаться в `change_cycle_*`, а
  переходные/дублирующие форматы нужно разметить на `оставить /
  artifacts / удалить после согласования`.
- Старые internal logs и legacy report naming не должны сохранять
  уникальные ошибки мимо Healer.

## 2026-04-08 GitHub CI ownership reminder drift

- GitHub CI прогоны делает пользователь; ИИ не должен путать их со
  своими локальными вспомогательными проверками и не должен выдавать их
  за свои проходы.
- Это правило нужно удерживать одновременно в AI docs, циклах и
  чат-отчётах.

## 2026-04-08 nested release zip relapse

- build script staging captured existing `efhc.zip`, so the next archive
  packed the previous archive inside itself and almost doubled the
  release weight.
- Guard rule: before staging, delete `ZIP_OUT` in repo root and exclude
  it explicitly from rsync packaging.

## 2026-04-08 recursive _begin_tx residual transfer

- После фикса `energy_service` тот же рекурсивный `_begin_tx` оставался
  живым в `referral_service`, `wallet_binding_service` и
  `tasks_service`.
- Паттерн должен считаться Healer-хроникой: при отсутствии транзакции
  `_begin_tx` обязан вызывать `db.begin()`, а не сам себя.

## 2026-04-07 watcher/reporting residual transfer

- legacy helper paths через `shop_orders.item_id` и `shop_items` в
  watcher/reporting слое — хронический residual drift после смены канона
  shop_orders.
- сырой слой `docs/audits/_raw` должен переноситься в Healer/artifacts
  после картирования на активные аудиты.

## 2026-04-07 old GitHub CI log transfer

- Старые GitHub CI log-audits про `0002`, import-order и stale frontend
  typing/build дрейф должны считаться Healer-хроникой, а не active
  truth.
- Повторяющиеся `ruff I001`, stale typing/builder drifts и
  migration-memory conflicts — переносим в Healer даже если они уже
  встречались в старых логах и аудитах.

- Подмена реального GitHub CI локальными прогонами как будто это одно и
  то же — хроническая болезнь.
## 2026-04-07 correction wave consolidation

- Ложное закрытие циклов без реального выполнения — хроническая болезнь.
- Закрытие visual/frontend цикла без песочницы пользователя —
  хроническая болезнь.
- Stale временные тестовые артефакты, ломающие следующие прогоны, —
  хроническая болезнь.
- Отсутствие dependency-precheck (`pytest`, `ruff`, `compileall`,
  `mypy`, `bandit`, `sqlalchemy`, `aiosqlite`) перед циклами —
  хроническая болезнь.
- Старые GitHub CI log-аудиты должны передавать хронические ошибки в
  Healer, а не бесконечно оставаться в active audit-surface.
- Каждый новый подтверждённый CI/log defect должен в том же цикле сразу
  быть привязан к существующей Healer-карте или зафиксирован новой
  записью без отложенного переноса.
- Рецидив AI-layer: попытка подменять пользовательский GitHub CI
  локальным почти-CI прогоном запрещена и должна считаться процессной
  болезнью.
- Рецидив AI-layer: отсутствие вопросов при реальной неясности запрещено
  и должно считаться процессной болезнью.
- CI-файлы правятся только в чате по прямому поручению пользователя;
  самовольное изменение CI внутри архива запрещено.

# Work passes 250-251 note — 2026-04-02

- Work passes 250-251 cleaned the main AI operator document and marked the
  prompt layer as reviewed historical material.
- The main AI layer now carries the primary continuity model more
  cleanly.

# Work pass 249 note — 2026-04-02

- Work pass 249 closed the current root helper-level merge phase as
  sufficiently cleaned.
- The AI layer now more strictly forbids English names for next cycles
  and roadmap points in chat.
- The repeated chat-language slip was treated as an AI continuity issue
  and fixed in the main AI docs.

# Work pass 248 note — 2026-04-02

- Work pass 248 normalized the key AI continuity docs into a more coherent
  Russian-facing layer.
- The current continuation prompt now reflects the line after work pass 247.
- Mixed-language wording remains acceptable only in secondary AI
  materials where precision benefits from it.

# Work pass 247 note — 2026-04-02

- Work pass 247 applied a controlled helper-level consolidation to the
  wallet/TON root cluster.
- The dynamic wallet-connect test pack now shares a testkit, while
  static SSOT and route guards remain explicit.
- The root merge phase is now close to saturation and may only need a
  final cleanup review.

# Work pass 246 note — 2026-04-02

- Work pass 246 applied a controlled helper-level consolidation to the root
  panels tests.
- Explicit scenario guards were preserved; only duplicate reload and
  seed boilerplate were consolidated.
- The panels cluster is no longer the strongest remaining root merge
  candidate.

# Work pass 245 note — 2026-04-02

- Work pass 245 applied a controlled helper-level consolidation to the
  concurrency root tests.
- The local verification also revealed two collection-shape hazards,
  which were corrected pointwise.
- The main AI doc now explicitly requires asking the user first when
  something is unclear.

# Work pass 244 note — 2026-04-02

- Work pass 244 fixed the final priority ladder in the main AI doc.
- Drift must now be reported, agreed through Q&A and only then
  synchronized.
- AI menu now has a START HERE marker for quick entry into the AI layer.

# Work pass 243 note — 2026-04-02

- Work pass 243 added a fast startup/communication protocol for new chats.
- Prompt files are now explicitly treated as secondary archival traces
  rather than the main continuity carrier.
- SSOT and NORM are explicitly treated as very important
  instruction-memory layers.

# Work pass 242 note — 2026-04-02

- Work pass 242 structurized the AI layer into index + brain/memory model +
  current continuation prompt.
- The archive is now explicitly modeled as a complement to the chat and
  as part of long-term continuity memory.
- `WORK_CYCLES.md` is explicitly treated as both memory and roadmap.

# Work pass 241 note — 2026-04-02

- Work pass 241 aligned the AI layer with the user's framing: AI docs are
  the working brains/prompt-layer, while logs, Q/A, Healer, registries
  and reports are the memory layer.
- The planned queue was renumbered so the former 241–242 entries now
  continue as 242–243.
- Chat-facing work pass naming remains Russian-only.

# Work pass 240 note — 2026-04-02

- Work pass 240 performed an AI continuity sweep after the previous chat
  audit and controlled test merge wave.
- The AI layer now explicitly records that user-facing cycle
  descriptions must be sent in Russian.
- Internal AI documents may remain in English or mixed language when
  this preserves precision and continuity.

# Work pass 239 note — 2026-04-02

- Work pass 239 applied a controlled helper-level merge wave for the
  payment-intents root tests.
- The refactor initially exposed a collection-time import risk and was
  corrected pointwise by moving `sqlalchemy` import inside the helper
  function.
- Explicit scenario tests were preserved; only duplicate setup helpers
  were consolidated.

# Work pass 238 note — 2026-04-02

- Chat audit confirmed AI-doc drift against the current post-233
  continuation state.
- AI active docs were synchronized in work pass 238.
- Tests catalog was rebuilt into active / merge-review / retired
  sections.

Work pass 237 note: latest CI log `logs_63001257876.zip` is green; no fresh
blocker surfaced, so the work pass was used for manual review/clustering of
the root integration/concurrency/payment tests instead of speculative
code churn.

Work pass 236 note: manual cleanup wave retired stale pre-reorg architecture
lock tests that were failing only because they still required removed or
relocated docs; active path-sensitive tests were synchronized to the new
docs layout, and fresh line72/canon-guard blockers were fixed.

Work pass 235 note: fixed post-install CI blocker from
`logs_62998295115.zip`; alembic 0001 sanity was reading
`SSOT_TABLES_ORM.csv` from stale pre-reorg path `docs/ssot_pack/...`
instead of `docs/SSOT/ssot_pack/...`. Also removed duplicate
`__future__` imports and fixed ruff import blocks in two route files.

Work pass 234 note: fixed CI install blocker from `logs_62996991668.zip`;
`backend/requirements.txt` contained an uncommented narrative bullet
that broke `pip install -r ...` before pytest. Added test-layer audit
plan and candidate stale-lock inventory.

Work pass 73 note: froze Hub admin entity design around `hub_links`; admin
migration must remove price/order semantics from the future Hub links
manager while keeping legacy `/admin/shop` as a temporary alias.

Work pass 69 note: aligned VIP user-facing layer to external GetGems
semantics in active runtime FAQ and locale help-texts; Hub no longer
suggests buying VIP NFT inside Shop-level wording.

Work pass 68 note: added first backend/frontend Hub EFHC handoff layer;
`/hub/efhc-handoff` now issues a signed token and Hub EFHC card opens
the external URL only after backend response, with fallback modal when
buy-flow URL is not configured.

# HEALER_ATLAS

Work pass 66 note: removed residual Shop/store wording from active Russian
runtime FAQ section 13 and wallet answer 5-1; Hub user-facing layer now
states only external EFHC flow, external VIP via GetGems and skins as
12-level rewards.

Work pass 64 note: added first route alias wave for `shop -> hub`; new
user-facing entry points `/hub` and `/admin/hub` exist, bot menu opens
`/hub`, legacy `/shop` alias remains.

Work pass 60 note: added `docs/SSOT/HUB_SSOT.md` as the single source of
truth for Hub; work pass journal and Q&A register now reference the document
for backend/frontend/admin/FAQ/QA alignment.

Work pass 56 note: Shop → Hub planning answers and future work pass descriptions
were synced into the work pass journal/Q&A register; operator rules now
explicitly ban justificatory phrasing in user-facing texts.

Version: 1.3.0

Cards total: 76

Work pass 29 note: Healer JSON structure re-normalized; active docs/test
catalog counts resynced; active terminology drift removed from current
docs layer.

## HEAL-0001 — Line72 violation

- category: `style_guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- L=84 > 72
- test_max_line_length_72.py failed

**Where to look**

- backend/**
- frontend/**
- tests/**

**Treatment**

- Перенести длинную строку на несколько строк.
- Для описаний Field использовать description=(...) с
- конкатенацией.

**Verification**

- pytest line72
- ruff/compileall не деградировали

## HEAL-0002 — apiRequest generics missing

- category: `frontend_types`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- Property 'items' does not exist on type '{}'

**Where to look**

- frontend/src/components
- frontend/src/pages

**Treatment**

- Добавить тип ответа и вызывать apiRequest<Resp>(...).

**Verification**

- npm run build
- tsc/next build green

## HEAL-0003 — Props contract drift

- category: `frontend_contract`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- Property 'hint' does not exist on type ...

**Where to look**

- frontend/src/pages
- frontend/src/components

**Treatment**

- Сверить интерфейс props и все вызовы компонента.

**Verification**

- next build
- поиск похожих вызовов

## HEAL-0004 — CI missing pytest

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- pytest: command not found

**Where to look**

- ci.yml
- .github/workflows/**

**Treatment**

- Добавить pip install pytest и нужные плагины в
- workflow.

**Verification**

- CI step pytest exists
- pytest -q runs from workflow

## HEAL-0005 — Pytest wrong cwd

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- exit code 5
- no tests ran

**Where to look**

- ci.yml
- Makefile
- scripts

**Treatment**

- Запускать pytest из корня, где лежит tests/.

**Verification**

- CI shows collected tests > 0

## HEAL-0006 — CI dependency gap

- category: `ci_runner`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- ModuleNotFoundError: jwt
- missing pytest-asyncio

**Where to look**

- backend/requirements.txt
- ci.yml

**Treatment**

- Синхронизировать CI install step с requirements и test
- deps.

**Verification**

- missing import errors gone
- pytest collection green

## HEAL-0007 — Broken npm lockfile source

- category: `frontend_build`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- npm ci failed
- package-lock points to mirror

**Where to look**

- frontend/package-lock.json

**Treatment**

- Пересобрать lockfile на публичном registry npmjs.

**Verification**

- npm ci
- lockfile has no vendor/file refs

## HEAL-0008 — Vendor patch bypass

- category: `frontend_build`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- file: dependency
- vendor override in package json

**Where to look**

- frontend/package.json
- frontend/package-lock.json

**Treatment**

- Вернуть нормальные semver зависимости и честный
- lockfile.

**Verification**

- npm ci
- guard bans passes

## HEAL-0009 — Missing symbol import/export

- category: `imports`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ImportError
- cannot import name

**Where to look**

- backend/app/services
- backend/app/models
- facades

**Treatment**

- Сверить реальный экспорт и импорт; фасад держать
- честным.

**Verification**

- pytest collection
- compileall

## HEAL-0010 — Pagination contract missing

- category: `backend_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Pagination expected
- admin_logging missing pagination

**Where to look**

- backend/app/routes/admin_logging.py

**Treatment**

- Добавить/импортировать Pagination там, где она нужна.

**Verification**

- pytest collection
- admin logs flow tests

## HEAL-0011 — Alembic backend import path

- category: `alembic_imports`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ModuleNotFoundError: backend
- alembic cannot import backend.*

**Where to look**

- backend/migrations/env.py
- backend/migrations/versions

**Treatment**

- Перевести импорты на app.* или migrations.* под
- текущий cwd.
- Не смешивать backend.app.* и app.* в одном контуре.

**Verification**

- alembic upgrade head
- compileall migrations

## HEAL-0012 — Migration env NameError

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- NameError
- _backend_dir used before define

**Where to look**

- backend/migrations/env.py
- 0001_init.py

**Treatment**

- Определить path helper до first use и перепроверить
- sys.path.

**Verification**

- compileall
- alembic import env

## HEAL-0013 — Settings field missing

- category: `settings`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- parsed_ref_bonus_thresholds missing
- TASK_REWARD_BONUS_EFHC_DEFAULT missing

**Where to look**

- backend/app/core/config_core.py

**Treatment**

- Добавить поле в Settings и sane default по канону.

**Verification**

- compileall
- settings import
- pytest affected flow

## HEAL-0014 — SQLite row lock unsupported

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- FOR UPDATE
- SKIP LOCKED
- sqlite syntax error

**Where to look**

- tests/**
- services using raw SQL locks

**Treatment**

- Не адаптировать доменную логику под SQLite.
- Тесты перевести на Postgres-only профиль.

**Verification**

- pytest on Postgres profile
- no sqlite lock errors

## HEAL-0015 — SQLite SQL function drift

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- now() missing
- ::numeric
- sqlite incompatible SQL

**Where to look**

- tests/**
- services/payment_intents_service.py

**Treatment**

- Убрать SQLite profile из таких тестов или переписать
- tests.

**Verification**

- pytest
- no sqlite sql syntax errors

## HEAL-0016 — TON validator false ban

- category: `wallet_validation`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- invalid TON address
- false ban letters E/e

**Where to look**

- wallet validator
- TON address parsing

**Treatment**

- Перейти на нормальную валидацию формата TON и тесты
- примеров.

**Verification**

- wallet validation tests
- real known address passes

## HEAL-0017 — str vs datetime

- category: `time_types`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- '>' not supported between str and datetime

**Where to look**

- panels services
- scheduler code

**Treatment**

- Нормализовать тип времени до сравнения и на границе
- ввода.

**Verification**

- panel tests
- mypy if typed

## HEAL-0018 — Session already begun

- category: `transactions`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- InvalidRequestError: transaction already begun

**Where to look**

- panel services
- withdraw/exchange services

**Treatment**

- Убрать вложенный begin().
- Держать одну транзакционную границу в сервисе.

**Verification**

- pytest affected flow
- no nested tx error

## HEAL-0019 — Migration smoke NoneType

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- NoneType in migration smoke

**Where to look**

- backend/migrations/versions/0001*

**Treatment**

- Сверить helper contract и защитить от None перед
- обращением.

**Verification**

- migration smoke test
- alembic upgrade head

## HEAL-0020 — SQLite schema DDL in tests

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- near SCHEMA syntax error
- sqlite DDL schema

**Where to look**

- tests/**
- migration smoke tests

**Treatment**

- Запускать такие тесты только на Postgres-only профиле.

**Verification**

- pytest on Postgres profile

## HEAL-0021 — Guard binary false positive

- category: `guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- guard bans hit png
- binary asset false positive

**Where to look**

- ops/canon_guard.py
- frontend/public/**

**Treatment**

- Исключить binary assets или детектировать mime/binary
- mode.

**Verification**

- guard scan passes on png/jpg

## HEAL-0022 — Guard alias ban hit

- category: `guard`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- bans scan found tg alias
- forbidden substring found

**Where to look**

- frontend/src/**
- backend/**
- ops/canon_rules.yaml

**Treatment**

- Санировать алиасы до канона tg_id without new bypass
- names.

**Verification**

- guard bans passes
- grep on aliases clean

## HEAL-0023 — Idempotency unique race

- category: `idempotency`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- duplicate key
- uq_efhc_transfers_idem_key

**Where to look**

- transactions_service.py
- transfer logs

**Treatment**

- Сделать read-through поиск по ключу до insert.
- Повтор отдавать как idempotent result.

**Verification**

- idempotency tests
- concurrency retry tests

## HEAL-0024 — Exchange/withdraw race

- category: `financial_invariants`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- race in exchange
- withdraw invariants broken

**Where to look**

- withdraw service
- exchange service
- bank ledger

**Treatment**

- Держать атомарные state transitions.
- Использовать row locks и idempotent service path.

**Verification**

- concurrency tests
- ledger invariants hold

## HEAL-0025 — Warnings promoted to fail

- category: `pytest_policy`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- unraisable exception warnings
- deprecated warnings fail

**Where to look**

- pytest.ini
- tests/**
- pydantic generics

**Treatment**

- Исправить источник warning, а не глушить его globally.

**Verification**

- pytest clean warnings

## HEAL-0026 — SSL mode mismatch local Postgres

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- sslmode require local postgres fail

**Where to look**

- backend/migrations/env.py

**Treatment**

- Добавлять sslmode только для non-local hosts.

**Verification**

- alembic upgrade head local/ci

## HEAL-0027 — Leftover sqlite helper

- category: `test_db_profile`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- IndentationError __init__sqlite_schema

**Where to look**

- tests/**

**Treatment**

- Удалить/заменить sqlite helper на Postgres fixture
- path.

**Verification**

- compileall tests
- pytest collection

## HEAL-0028 — Broken migration env formatting

- category: `alembic_env`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- compileall env.py failed
- broken indentation

**Where to look**

- backend/migrations/env.py

**Treatment**

- Нормализовать блок search_path injection.
- Проверить quoting и indentation.

**Verification**

- compileall
- bandit B608 context

## HEAL-0029 — models __init__ contaminated

- category: `models_facade`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- models __init__ damaged
- unexpected code in __init__

**Where to look**

- backend/app/models/init.py

**Treatment**

- Переписать init.py как чистую фасадную re-export
- точку.

**Verification**

- pytest collection
- compileall

## HEAL-0030 — Missing required tables

- category: `db_sanity`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- required tables missing after alembic

**Where to look**

- 0001_init.py
- env.py
- ORM metadata
- SSOT tables

**Treatment**

- Сверить ORM tables, 0001, search_path и sanity list.
- Явно указывать схему там, где нужно.

**Verification**

- alembic upgrade head
- sanity db objects
- tables count

## HEAL-0031 — Duplicate ORM table define

- category: `orm_metadata`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Table already defined
- duplicate table definition

**Where to look**

- backend/app/models/**
- import graph

**Treatment**

- Унифицировать import path на app.* внутри backend cwd.
- Избегать двойной загрузки app.models и
- backend.app.models.

**Verification**

- alembic import
- pytest collection

## HEAL-0032 — Archive filename too long

- category: `release_artifact`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- unzip file name too long

**Where to look**

- release zip
- docs/healer/**

**Treatment**

- Укорачивать имена артефактов и путей внутри релиза.

**Verification**

- unzip efhc.zip in CI

## HEAL-0033 — Double schema prefix

- category: `db_sanity`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- efhc_core.efhc_core.table

**Where to look**

- 0001_init.py
- sanity helpers

**Treatment**

- Нормализовать имя таблицы перед to_regclass/sanity
- check.

**Verification**

- alembic sanity green

## HEAL-0034 — Incomplete metadata from soft imports

- category: `orm_metadata`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- tables_count_expected got lower count

**Where to look**

- backend/app/models/init.py
- metadata load

**Treatment**

- Импортировать все model modules жёстко и единообразно.

**Verification**

- metadata tables count
- alembic sanity

## HEAL-0035 — Config settings export drift

- category: `settings`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- config_core did not export settings

**Where to look**

- backend/app/core/config_core.py

**Treatment**

- Вернуть каноничный export settings из config_core.

**Verification**

- imports from app.core.config_core work

## HEAL-0036 — Index schema kwarg invalid

- category: `orm_sqlalchemy`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- Index() got unexpected kwarg 'schema'

**Where to look**

- backend/app/models/**

**Treatment**

- Убрать schema= из Index(...).
- Схему задавать только на таблице.

**Verification**

- alembic import
- compileall
- pytest collection

## HEAL-0037 — TimestampMixin export missing

- category: `models_facade`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ImportError TimestampMixin absent in app.models

**Where to look**

- backend/app/models/init.py
- external_events_models.py

**Treatment**

- Добавить TimestampMixin в фасад и унифицировать import
- path.

**Verification**

- alembic import
- pytest collection

## HEAL-0038 — Migration writes to impl.stdout

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- AttributeError impl.stdout

**Where to look**

- 0001_init.py

**Treatment**

- Убрать такой вывод и использовать безопасный logger/op
- context.

**Verification**

- alembic upgrade head

## HEAL-0039 — DDL not committed

- category: `migrations`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- migration prints metadata, but tables absent

**Where to look**

- 0001_init.py
- migration transaction flow

**Treatment**

- Проверить transaction scope и op.execute path для DDL.

**Verification**

- tables exist after upgrade
- sanity green

## HEAL-0040 — Payment intent contract drift

- category: `payments`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- PACKAGE_NOT_FOUND
- ambiguous param types

**Where to look**

- payment_intents_service.py
- payment routes/tests

**Treatment**

- Сверить service, route, tests и SQL path по одному
- канону.

**Verification**

- pytest payment intents
- DB flow tests

## HEAL-0041 — Broken SQL string in tests

- category: `tests_syntax`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- SyntaxError in pytest collection
- broken SQL template

**Where to look**

- tests/**

**Treatment**

- Починить шаблон SQL literal и compileall tests.

**Verification**

- pytest collection
- compileall tests

## HEAL-0042 — React Query provider missing

- category: `frontend_runtime`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- No QueryClient set

**Where to look**

- frontend/src/pages/app.tsx
- hooks using React Query

**Treatment**

- Поднять QueryClientProvider выше места вызова hook.

**Verification**

- next build
- runtime page render

## HEAL-0043 — Function import drift in tests

- category: `tests_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- append_transfer_extra_info import error

**Where to look**

- tests/**
- services/ledger helpers

**Treatment**

- Синхронизировать тестовый импорт с каноничным именем в
- коде.

**Verification**

- pytest collection
- grep old name clean

## HEAL-0044 — Direction column too short

- category: `db_schema`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- value too long for type varchar(8)
- direction truncation

**Where to look**

- transfer log model
- migration for direction column

**Treatment**

- Расширить длину/constraint под полный набор direction
- values.

**Verification**

- DB migration
- insert/update direction tests

## HEAL-0045 — tg_id vs users.id drift

- category: `identity_canon`
- severity: `P0`
- zone: `red`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `immediate`

**Symptoms**

- JOIN u.id = w.tg_id
- WHERE id = :tg_id

**Where to look**

- routes/services/sql joins
- admin lists
- shop lookups

**Treatment**

- Санировать все join/filter path до tg_id only.
- Не вводить алиасы и обходные имена.

**Verification**

- grep suspicious joins
- critical flow tests



### v169_87 / repair pass repair note

Confirmed defect repaired in `backend/app/crud/referrals_crud.py::admin_top_inviters()`:

- `ReferralLink.inviter_tg_id` now joins to `User.tg_id`;
- `active_subq.c.tg_id` now joins to `User.tg_id`;
- `bonus_subq.c.tg_id` now joins to `User.tg_id`;
- admin aggregate exposes `inviter_tg_id`, not internal `users.id`.

Active guard: `tests/architecture/test_heal0045_tg_id_identity_canon.py`.

## HEAL-0046 — Route/service signature drift

- category: `backend_contract`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- unexpected keyword argument
- missing positional arg

**Where to look**

- backend/app/routes/**
- backend/app/services/**

**Treatment**

- Сверить сигнатуры route и service.
- Убрать лишний arg или добавить его в service только
- если он
- реально
- нужен по логике.

**Verification**

- pytest affected flow
- search similar calls

## HEAL-0047 — ORM/service/route drift

- category: `ssot_sync`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- field missing in model/service
- route points to wrong table

**Where to look**

- models
- services
- routes
- migrations

**Treatment**

- Проверять связку route → service → table → migration
- одним
- циклом.
- Обновлять map docs и tests вместе с кодом.

**Verification**

- targeted tests
- MODEL_TABLE_ROUTE_TEST_MAP sync

## HEAL-0048 — Unsafe raw SQL schema handling

- category: `sql_safety`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- B608
- unsafe search_path sql
- CREATE SCHEMA f-string
- WHERE {' AND '.join(where)}
- AND '.join(where)
- string-built WHERE

**Where to look**

- backend/migrations/env.py
- backend/app/services/admin/**
- backend/app/services/**
- raw SQL helpers

**Treatment**

- Убрать string-built WHERE и raw schema SQL.
- Перевести на безопасный builder или text() с параметрами.
- Сохранить бизнес-смысл и проверки доступа.

**Verification**

- bandit
- compileall
- search_path works

## HEAL-0049 — Documentation table count drift

- category: `docs_ssot`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- ORM-таблицы: 38
- Таблицы (ровно 30)
- SSOT docs mismatch

**Where to look**

- docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md
- docs/OVERVIEW_SSOT_SYNC.md
- docs/audits/DIAGNOSTIC_DB_INVENTORY.md
- README.md

**Treatment**

- Синхронизировать `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md` с
  `docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv`.
- Указать реальные counts: `efhc_core=33`, `efhc_admin=5`, `total=38`.

**Verification**

- Проверить числа 38/33/5 в `README.md`, `docs/OVERVIEW_SSOT_SYNC.md`,
  `docs/audits/DIAGNOSTIC_DB_INVENTORY.md`,
  `docs/SSOT/SSOT_DB_SCHEMAS_TABLES.md`.

## HEAL-0050 — Lotteries terminology scope drift

- category: `terms_canon`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- draw/draws banned everywhere
- prize draw in locale text
- Lotteries terminology conflict

**Where to look**

- docs/SSOT/TERMS_GLOSSARY.md
- frontend/public/locale/**
- frontend/src/pages/lotteries.tsx

**Treatment**

- Сузить запрет: запрещать `draw/draws` как новые технические и
  канонические имена домена Lotteries.
- Разрешить естественный English текст про событие розыгрыша, если это
  не имя сущности, поля, route alias или ключа локализации.

**Verification**

- Проверить `docs/SSOT/TERMS_GLOSSARY.md` и убедиться, что scope запрета
  больше не противоречит UI/locale смыслу.

## HEAL-0051 — Duplicate dataclass decorator

- category: `backend_runtime`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- @dataclass followed by @dataclass(frozen=True)
- duplicate class decoration

**Where to look**

- backend/app/services/withdraw_service.py

**Treatment**

- Оставить только один декоратор `@dataclass(frozen=True)` для
  `WithdrawRequestDTO`.

**Verification**

- `python -m compileall backend/app`
- Точечный импорт `withdraw_service.py` не должен ломаться.



## HEAL-0052 — Shop spending order drift

- category: `business_invariant`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- debit_user_bonus_to_bank(
- debit_user_to_bank(
- shop_service manual split debit

**Where to look**

- backend/app/services/shop_service.py
- backend/app/services/transactions_service.py

**Treatment**

- Перевести shop flow на
- spend_user_to_bank_bonus_then_main(...).

**Verification**

- pytest tests/architecture/test_shop_spending_order_canon.py

## HEAL-0053 — Missing two-schema guard test

- category: `guard_coverage`
- severity: `P2`
- zone: `white`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `observe`

**Symptoms**

- missing explicit schemas count == 2 test

**Where to look**

- tests/architecture/*
- docs/SSOT/ssot_pack/SSOT_TABLES_ORM.csv

**Treatment**

- Добавить architecture test на schemas == 2.

**Verification**

- pytest tests/architecture/test__schema__count_two.py


## HEAL-0054 — Energy page archive leakage
- Severity: P2
- Zone: green
- Симптом: на странице Energy отображается архивный счётчик панелей.
- Лечение: убрать archived_count с Energy и оставить только active_count
  + текущую генерацию активных панелей.


## HEAL-0055 — In-memory idempotency TTL cache

- category: `backend_resilience`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- self._ttl_seen
- TTL cache in memory process
- MonetaryIdempotencyMiddleware in-memory duplicate lock

**Where to look**

- backend/app/core/system_locks.py
- backend/app/models/admin_models.py
- tests/core/test_monetary_idempotency_middleware.py

**Treatment**

- Убрать process-local TTL dict из MonetaryIdempotencyMiddleware.
- Перевести TTL duplicate lock на efhc_admin.idempotency_key.
- Держать middleware только как HTTP safeguard поверх DB source of
  truth.

**Verification**

- В system_locks.py больше нет self._ttl_seen.
- TTL lock идёт через общую таблицу efhc_admin.idempotency_key.
- Тест middleware обновлён под shared-lock helper.


## HEAL-0056 — GlobalHeader status/menu discoverability gap

- category: `frontend_header`
- severity: `P3`
- zone: `green`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- GlobalHeader missing VIP badge
- GlobalHeader missing Activ badge
- profile entry hidden behind avatar only

**Where to look**

- frontend/src/components/GlobalHeader.tsx
- frontend/src/components/ProfileModal.tsx
- frontend/src/components/Layout.tsx
- backend/app/routes/sync_routes.py

**Treatment**

- Добавить в GlobalHeader badges VIP и Activ.
- Добавить явную кнопку Menu, открывающую профиль.
- Отдавать persistent Activ status из backend snapshot.

**Verification**

- Проверить profile.has_activ в sync snapshot.
- Проверить badges VIP/Activ в GlobalHeader и ProfileModal.
- Проверить явную кнопку Menu в GlobalHeader.

## HEAL-0057 — Profile/settings terminology drift

- Symptoms: old split profile wording in user-facing texts.
- Treatment: replace the old wording with `Профиль` / `Профіль` /
  `Profile` and sync FAQ runtime, FAQ SSOT, locales and docs.
- Casebook: CASE-0057.

## HEAL-0058 — Incomplete Docker local environment

- category: `devops_docker`
- severity: `P2`
- zone: `yellow`
- symptom: compose поднимает только db, frontend не проксирует backend,
  backend не ждёт БД и миграции.
- treatment: полный stack db/backend/frontend, wait-for-db, alembic,
  docs.


## HEAL-0059 — Missing tg_id monetary rate limit

- category: `backend_security_rate_limit`
- severity: `P2`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `confirmed`
- medical_maturity: `fully_protocolized`
- action_priority: `planned`

**Symptoms**

- no rate limiting for monetary operations
- thousands of monetary requests per tg_id
- MonetaryRateLimitMiddleware missing

**Where to look**

- backend/app/core/system_locks.py
- backend/app/main.py
- backend/app/routes/withdraw_routes.py
- backend/app/routes/exchange_routes.py
- backend/app/routes/shop_routes.py
- backend/app/routes/panels_routes.py

**Treatment**

- Добавить MonetaryRateLimitMiddleware для денежных путей.
- Ограничивать частоту запросов по tg_id в общем DB-backed контуре.
- Подключить middleware в backend/app/main.py.

**Verification**

- `python -m compileall backend/app/core/system_locks.py
  backend/app/main.py`
- `pytest tests/architecture/test_monetary_rate_limit_enabled.py`

## HEAL-0060 — HTTPException leaked into service layer

- Severity: P2
- Zone: yellow
- Symptom: service layer imports/raises `HTTPException`.
- Treatment: use `EFHCError` subclasses in services; map to HTTP in
  routes/handlers.
- Casebook: `CASE-0060`.

## HEAL-0061 — Opaque retry policy in _run_idempotent

- Severity: P3
- Zone: yellow
- Symptom: retry/read-through/idempotency conflict logic compressed into
  one broad except block.
- Treatment: extract helpers for idempotency conflict, transient tx
  error, read-through and conflict mark; keep retries only for unique
  idempotency_key, deadlock and serialization.
- Casebook: `CASE-0061`.


## HEAL-0062 — Continuation prompt and AL docs drift

- Category: `docs_governance`
- Severity: `P3`
- Zone: `yellow`
- Summary: отсутствие отдельного continuation prompt для нового чата и
  рассинхрон AL-документов при переходе к новой серии архивов.
- Treatment: создать continuation prompt, синхронизировать AI rules,
  architectural locks, SSOT index и README.
- Casebook: `CASE-0062`.

## HEAL-0063 — Release ZIP cache contamination and FAQ profile term
   drift

- Category: `release_hygiene`
- Severity: `P3`
- Zone: `yellow`
- Summary: релизный ZIP содержал кэши, а русский FAQ ещё держал
  user-facing термин `Профиль/Настройки`.
- Treatment: очистить релиз от `__pycache__`/`*.pyc`/`.pytest_cache`,
  привести FAQ SSOT и runtime к канону `Профиль`.
- Casebook: `CASE-0063`.


## v157_02 / logs_60244480535
- Circular import around `app.models.Base` caused alembic/pytest
  failures.
- Fixed by extracting shared ORM base into `backend/app/models/base.py`.
- Also fixed mypy, bandit, frontend type drift and ruff issues confirmed
  by log `60244480535`.


## CASE-0065 — Tournament-themed user-facing copy sync

- Heal ID: `HEAL-0065`
- Archive: `v157_04`
- Fix: синхронизированы user-facing тексты Турниры / Начать раунд /
  Стоимость входа / Раунд в locale, runtime FAQ и русском FAQ SSOT.
- Result: `resolved`.


## HEAL-0066 — FAQ section-name wording drift
- category: docs-consistency
- severity: medium
- zone: faq / runtime-faq / ssot
- card_status: active
- treatment_status: fixed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит `frontend/src/data/faq/*`,
  `docs/SSOT/faq_ssot/**`,
  `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`
- root_cause: user-facing название раздела 14 было рассинхронизировано
  по языкам и слоям FAQ.
- treatment: раздел 14 приведён к канону `Турниры / Турніри /
  Tournaments`; старые section-name формулировки удалены из FAQ-слоёв.
- verification: поиск по FAQ-слоям на старые section-name термины
  пустой.
- related_reports:
  `reports/change_cycle_2026-03-12_v157_05_faq_wording_cleanup.md`


## HEAL-0067 — Residual tournaments wording drift in FAQ and bot UI

- zone: frontend / docs / bot
- severity: medium
- symptom_patterns: `Tournamentsr`, `lotteries`, `розіграш`, `Çekiliş`,
  bot fallback `Lotteries`
- root_cause: неполная санация пользовательских формулировок сразу в
  нескольких слоях
- treatment: дочистить locale, runtime FAQ, FAQ SSOT, bot handlers и
  visible error strings, не трогая технический домен `lotteries_*`
- verification: поиск по user-facing слоям на legacy terms после патча
  чистый
- related_report:
  `change_cycle_2026-03-12_v157_06__name__drift_cleanup_and_faq_sync.md`


## HEAL-0068 — Residual user-facing tournaments drift in FAQ SSOT pack

- category: user_facing_copy_drift
- severity: medium
- zone: frontend / docs / faq
- card_status: active
- treatment_status: fixed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит `frontend/src/data/faq/*`,
  `docs/SSOT/faq_ssot/**`,
  `docs/SSOT/ssot_pack/FAQ_SSOT_20_SECTIONS.json`, `README.md` + job
  logs в `logs/canon/`
- root_cause: после `v157_06` дочистка не охватила все многоязычные
  FAQ/SSOT источники; часть хвостов осталась в markdown/json и
  агрегированном ssot pack.
- treatment: повторная санация user-facing FAQ/SSOT текстов на 13
  языках; `lotteries.cost` приведён к канону `Стоимость входа / Вартість
  входу / Entry cost`; technical domain `lotteries_*` не
  переименовывался.
- verification: поиск по FAQ/source слоям на legacy terms пустой;
  значения в `frontend/public/locale/*.json` проверены JSON-парсером и
  чисты.
- related_reports:
  `reports/change_cycle_2026-03-25_v157_07_user_facing_tournaments_
reaudit.md`


## HEAL-0069 — Lotteries full-domain decommission required

- category: domain_decommission
- severity: high
- zone: backend / frontend / docs / tests / ops / env
- card_status: resolved
- treatment_status: completed
- medical_maturity: confirmed
- confirmation_basis: прямой аудит HEAD архива; 1977 совпадений по
  lotteries-related patterns, включая backend
  routes/services/models/crud, frontend page/locale and SSOT docs.
- root_cause: предыдущие циклы лечили только user-facing wording, но сам
  технический домен lotteries оставался активным и связанным с API, ORM,
  docs и runtime.
- treatment: controlled decommission in 20 work passes with import/export
  audit first, then frontend removal, route removal,
  services/crud/models removal, docs/SSOT rebuild and final residual
  search.
- verification: в финале серии поиск по коду и архиву не должен находить
  active feature references to lotteries outside preserved historical
  records.
- related_reports:
  `reports/change_cycle_2026-03-25_v157_08_lotteries_full_domain_audit_
cycle_01.md`


### Update 2026-03-25 / Work pass 02
- import/export audit completed
- confirmed coupling across frontend pages, bot routers, public/admin
  routes, schemas, services, crud, models and SSOT route maps
- next safe step: remove frontend entry points before touching backend
  route/service layer


### Update 2026-03-25 / Work pass 03
- removed frontend entry points from `frontend/src/pages/panels.tsx`
- removed user-facing navigation from Panels to `/lotteries`
- kept `frontend/src/pages/lotteries.tsx` alive intentionally for staged
  removal in work pass 05
- local verification: `npm --prefix frontend run build` = OK


### Update 2026-03-25 / Work pass 03
- removed frontend entry points from `frontend/src/pages/panels.tsx`
- removed user-facing navigation from Panels to `/lotteries`
- kept `frontend/src/pages/lotteries.tsx` alive intentionally for staged
  removal in work pass 05
- local `next build` not confirmed in container: `node_modules` absent,
  `next` not found


### Follow-up — CASE-0070 (2026-03-25)
- runtime locale keys cleaned after entry-point removal
- runtime FAQ section 14 removed
- FAQ meta labels `14` / `14.1` removed
- general runtime FAQ cross-references cleaned


### Update 2026-03-25 / Work pass 05
- removed `frontend/src/pages/lotteries.tsx`
- removed direct frontend client calls to `/api/lotteries*` by deleting
  the page module
- kept runtime locale keys `lotteries.*` temporarily as dead data for
  later API/docs removal cycles


### Update 2026-03-25 / Work pass 06
- removed `backend/app/bot/handlers/lotteries_handlers.py`
- removed `backend/app/bot/handlers/admin/admin_lotteries_handlers.py`
- removed bot dispatcher include/import for lotteries router
- removed admin aggregate include/import for admin lotteries router
- removed `🎟 Лотереи` button from `kb__main__menu()`


### Update 2026-03-25 / Work pass 07
- removed `backend/app/routes/lotteries_routes.py`
- removed `lotteries_routes` from FastAPI route aggregator
- synced route-coupled tests for wallet gate semantics
- synced route-coupled docs `WALLETS_TONCONNECT_SSOT.md` and
  `API_CONTRACTS.md`

## HEAL-0069 — work pass 08 update

- Removed admin lotteries routes from admin FastAPI layer.
- Removed lotteries exposure from admin facade.
- Kept service/domain removal for later cycles.


## HEAL-0069 — work pass 09 update

- Removed standalone lotteries schema/contract layer.
- Removed admin lotteries schema re-export surface.
- Kept service/CRUD/model removal for later cycles.

- HEAL-0075 / work pass 10: removed lotteries service layer; synced
  service-coupled tests and stale doc references to deleted service
  files.


## HEAL-0069 — work pass 11 update

- Removed `backend/app/crud/lotteries_crud.py`.
- Removed `backend/app/crud/admin/admin_lotteries_crud.py`.
- Removed lotteries alias and health-check requirements from
  `backend/app/crud/init.py`.
- Synced decommission guard test for CRUD-layer removal.


## HEAL-0069 — work pass 13 update

- Removed lotteries-specific test files from the archive.
- Reduced generic service/guard tests to non-lotteries scope.
- Synced tests catalog and overview-doc counts after deleting test
  files.

- 2026-03-25 v157_21: work pass 14 removed lotteries env/config surface
  (`LOTTERIES_*` example vars, config_core settings block,
  admin_settings lotteries keys).

## HEAL-0069 — work pass 15 update

- Removed lotteries-only ops guard
  `check_lotteries_auto_cycle_ssot(...)`.
- Removed lotteries idempotency route patterns from
  `ops/canon_rules.yaml`.
- Removed scheduler soft-import and default registration for
  `lotteries_autorestart`.
- Kept non-ops leftovers for later cycles.


## v157_23 / work pass 16
- Rebuilt docs layer and removed active lotteries-domain references from
  docs/overview/glossary/API descriptions.

## HEAL-0069 — Lotteries domain decommission
- 2026-03-25 v157_24: work pass 17 removed residual structural SSOT traces
  from `docs/SSOT/ssot_pack` (`SSOT_TABLES_PURPOSE_RU.md`,
  `SSOT_TABLES_MIGRATIONS.csv`,
  `SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md`).

- HEAL-0069 / work pass 18: зафиксирована политика historical DB/migration
  traces; active SSOT/runtime не может возвращать lotteries-domain,
  historical mentions допустимы только в audit/report/healer/migration
  history.


## HEAL-0069 — work pass 19 update
- Removed final active residual traces after domain decommission.
- Deleted dead locale keys and stale release logs.
- Cleared remaining lotteries wording from active backend/doc comments
  and identifiers.


### Update 2026-03-25 / Work pass 20
- final residual grep по active tree дал `FOUND 0` при исключении
  historical buckets
- контрольные проверки `compileall` и архитектурные `pytest` прошли
- серия decommission завершена, активный lotteries-domain отсутствует
- case status: resolved

- 2026-03-26 v157_29: work pass 21 зафиксировал единый реестр циклов 1–40 и
  inventory mismatch-классов SSOT/runtime/docs/tests/release artifact;
  активных lotteries-traces в active tree не подтверждено.

- 2026-03-26 v157_30 work pass 22: FAQ/runtime sync hardened with
  deterministic SSOT generator and exact-match guard.

- HEAL-0070 / Route surface drift: local route modules embedded `/api`
  instead of relying on app-level API_PREFIX. Treatment: normalize route
  modules and add repository guard. Status: treated.

- 2026-03-26 / Work pass 24: admin route surface canonicalized; added admin
  route module guard; synced docs counts/catalog; line72 tail fixed.

- 2026-03-26 / Work pass 27: resolved route/service/table docs drift —
  active docs held stale route counts 91/92 while SSOT CSV had 82;
  synced docs and added `test_ssot_route_count_docs_sync.py`.
- 2026-03-26 / Work pass 28: resolved startup/OpenAPI drift — `api/index.py`
  ended after env bootstrap and did not export `app`;
  `backend/openapi/openapi.json` held only 2 stale paths while SSOT
  route surface had 82. Restored Vercel entry, regenerated OpenAPI from
  SSOT route registry, added `test_openapi_startup_consistency.py`.

## HEAL-0073 — FAQ banned-term residual in active runtime
- symptom: active EN FAQ still contained запретный user-facing хвост and
  runtime inherited it.
- root_cause: FAQ ban guard did not scan SSOT/runtime FAQ layers.
- treatment: removed запретный user-facing хвост from EN FAQ,
  regenerated runtime catalogs, tightened canon rules and added
  dedicated FAQ ban-term test.
- verification: grep FAQ layers + pytest
  `test_faq_banned_terms_absent.py`.
- HEAL-0074: route freeze map drift / missing freeze index. Fixed by
  creating route freeze CSV and markdown synced to SSOT routes.


## HEAL-0075 — idempotency policy audit looked only at local route path
- symptom: architecture guard checked only decorator local path and
  missed policy drift on full route path `router prefix + local path`.
- root_cause: weak AST audit ignored router prefix and default
  Depends(...) parsing.
- treatment: rebuilt route idempotency guard to inspect full path and
  dependency defaults, synced `ops/canon_rules.yaml`, generated
  `docs/SSOT/ssot_pack/SSOT_IDEMPOTENCY_SURFACE.csv`.
- verification: `pytest -q
  tests/architecture/test_route_idempotency_policy.py
  tests/architecture/test_idempotency_surface_docs_sync.py`.

- HEAL-0076 — Response/error canon drift: `HTTPException` handler
  registration missing + non-canonical object-detail keys in routes.
  Status: resolved in work pass 34.


## Work pass 36
- Confirmed by `logs_62194714005.zip`: banned tg_id alias terms remained
  in `docs/SSOT/ssot_pack/ROUTES_TABLES_MIGRATIONS_PLAN.json`.
- Treatment: replaced alias mentions with tg_id-only wording, updated
  migration invariants to 32 tables / 2 schemas / ORM-only 0001, added
  dedicated guard.

- HEAL-0076: DB diagnostics docs drift — stale totals in
  `SSOT_DB_SCHEMAS_TABLES.md` and malformed legacy policy tails in DB
  docs. Treatment: synced all DB diagnostic docs to `SSOT_TABLES_ORM`
  and added dedicated guard.

- 2026-03-26 / Work pass 38: resolved route-matrix/OpenAPI docs drift —
  `MODEL_TABLE_ROUTE_TEST_MAP.md` had stale counts and pointed to
  missing `backend/app/models/exchange_routes.py`; synchronized with
  SSOT/OpenAPI and added dedicated guard.

- HEAL-0078: release artifact hygiene wave 2 fixed packaging of runtime
  log artifacts and added dedicated guard.

- HEAL-0080: residual docs-count drift in final route/migration
  regression pack (`MODEL_TABLE_ROUTE_TEST_MAP.md` kept stale test files
  count).

## HEAL-0078
- Симптом: перед RU purge wave отсутствовал freeze FAQ totals и
  runtime-source mapping.
- Лечение: добавлены `docs/FAQ_INVENTORY_FREEZE.md`,
  `docs/FAQ_INVENTORY_FREEZE.csv`, guard
  `test_faq_inventory_freeze_sync.py`, RU candidate list wave 1.

- HEAL-0081: FAQ RU wave 2 needs manual confirmation before deleting
  low-value section 14 questions.

- HEAL-0082: faq section 14 weak-but-non-risk questions require
  refinement instead of deletion when totals must stay stable.
- work pass 45: faq translations/runtime parity wave 1 — done (v158_22)
- HEAL-0084: work pass 46 confirmed zero new RU direct-risk FAQ candidates
  after wave 1 and refinement; next FAQ work must target weak and
  duplicate Q/A.



- HEAL-0085: after direct-risk cleanup, FAQ work must pivot to weak and
  duplicate RU Q/A review instead of forced deletions.

- HEAL-0079: FAQ weak/duplicate wave 1 review groups must resolve by
  point refinements or justified merge, never by silent drift.

- HEAL-0086: RU duplicate wave 2 groups must resolve by clearer scenario
  split, not by silent deletions.

- HEAL-0087: non-RU FAQ parity wave 2 can lag after RU
  duplicate-resolution cycles; confirm by checking 6 mirrored IDs across
  12 languages and runtime catalogs.


- Work pass 52: FAQ RU duplicate audit wave 3 completed as audit_only;
  confirmed 4 review groups / 8 Q-A, no automatic removals or
  replacements.

## HEAL-0088 — faq ru duplicate wave 3 may persist after audit without
   resolution
- Категория: faq_governance
- Severity: P3
- Подтверждение: work pass 53 потребовал разводки 4 duplicate-групп / 8 RU
  Q/A после audit_only wave 3.
- Лечение: точечно усиливать формулировки, не удаляя Q/A; после правки
  пересобирать runtime FAQ и переводить review-файл в resolved.


## HEAL-0089
- Name: faq translations/runtime parity wave 3 may stay stale after ru
  duplicate resolution wave 3
- Status: confirmed and treated in work pass 54.


## HEAL-0090 — faq ru duplicate wave 4 may remain after parity wave 3
- symptom: после work pass 54 в RU FAQ остаются подтверждённые user-facing
  overlap-кластеры вокруг постоянства Activ и карточек реферальных
  уровней.
- root_cause: после закрытия предыдущих wave-серий следующий слой
  пересечений не был ещё вынесен в отдельный audit-lock.
- treatment: work pass 55 создал audit-only файл
  `docs/archive_removed_elements/FAQ_RU_DUPLICATE_CANDIDATES_WAVE4.md` и
  guard `test_faq_ru_duplicate_wave4_audit_lock.py` без автоматической
  правки FAQ.
- verification: прямой аудит RU FAQ markdown/json + targeted pytest
  guard.


## HEAL-0091 / CASE-0103
- Symptom: after work pass 56 the project had a planned Shop → Hub queue,
  but
  the unified work pass journal still had a 56–60 gap and the repository did
    not yet have a direct active-surface inventory for the old Shop
  domain.
- Fix in work pass 57: added `docs/audits/SHOP_HUB_TRANSITION_INVENTORY.md`
  and
  backfilled work passes 56–60 with descriptions in
  `docs/cycles/WORK_CYCLES.md`.
- Verification: direct audit of active
  frontend/backend/bot/admin/FAQ/test
  files containing Shop domain traces in HEAD archive `v159_02`.


## HEAL-0092 / CASE-0104
- Symptom: unified work pass journal file name stayed
  `docs/WORK_CYCLES_01_40.md`
    even after the register already contained work passes 61–100, so the file
  path
  no longer matched its real scope.
- Fix in work pass 58: renamed the journal to `docs/cycles/WORK_CYCLES.md`,
  updated
  textual references to the new canonical path, and marked future cycle
  logging to use the range-free file name.
- Verification: direct audit of docs/report/healer references in HEAD
  archive
  `v159_03`.


## HEAL-0093 / CASE-0105
- Symptom: `docs/cycles/WORK_CYCLES.md` simultaneously contained two
  different
  56–60 ranges: an obsolete FAQ planned block and the actual Shop → Hub
    preparation block, creating numbering drift inside the unified
  journal.
- Fix in work pass 59: removed the obsolete duplicate 56–60 FAQ block,
  preserved the actual Shop → Hub sequence, corrected the work pass 58
  wording, and synced the register HEAD/version note.
- Verification: direct audit of `docs/cycles/WORK_CYCLES.md`,
    `docs/NORM/QUESTIONS_AND_ANSWERS_REGISTER.md` and appended change
  report.



## HEAL-0094 / CASE-0106
- Symptom: after `docs/SSOT/HUB_SSOT.md` was added, the repository still
  lacked
    a quantitative pre-migration baseline proving how wide the active
  `shop`
  implementation surface remained across frontend, backend, FAQ/runtime,
  docs and tests.
- Fix in work pass 61: added `docs/HUB_PRE_AUDIT_BASELINE.md`, counted
  active
  `shop` traces by layer, confirmed that implementation-level `hub`
  adoption had not started yet, and kept alias removal blocked.
- Verification: direct archive grep/audit of HEAD `v159_06`, including
  file-name hits, per-layer counts, and confirmed active module map.


## HEAL-0095 / CASE-0107
- Symptom: after `docs/SSOT/HUB_SSOT.md` freeze and the quantitative
  baseline in work pass 61, the repository still lacked a direct
  implementation-alignment audit mapping current active Shop code to
  concrete Hub SSOT MUST / MUST NOT violations and migration waves.
- Fix in work pass 62: added
  `docs/HUB_SSOT_IMPLEMENTATION_ALIGNMENT_AUDIT.md`, confirmed
  frontend/backend/admin/bot/locale mismatch points, documented guard
  insertion points, and kept alias removal blocked until staged
  migration completes.
- Verification: direct audit of HEAD `v159_07`, including
  `frontend/src/pages/shop.tsx`,
  `frontend/src/pages/admin/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/routes/admin_shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/models/shop_models.py`,
  `backend/app/schemas/shop_schemas.py`,
  and active locale/runtime traces.


## HEAL-0097 / CASE-0108
- Symptom: after the Hub SSOT freeze and implementation audit, the
  repository still exposed `Shop` in primary user-facing labels:
  GlobalHeader button text, locale navigation/title values and FAQ
  section 13 labels.
- Fix in work pass 63: switched the first user-facing naming layer to `Hub`
  without removing technical `shop` aliases, added
  `docs/HUB_UI_NAMING_WAVE1_AUDIT.md`, and locked the change with
  `tests/architecture/test_hub_ui_naming_wave1_lock.py`.
- Verification: direct audit of
  `frontend/src/components/GlobalHeader.tsx`,
  `frontend/public/locale/*.json`,
  `frontend/src/data/faq/meta.ts`, and
  `frontend/src/data/faq/ru.ts`.

- HEAL-0097 / 2026-03-28: Hub screen refactor wave 1 — user-facing
  `shop.tsx` переведён в cards-only Hub screen без commerce-layer.

## HEAL-0098 / CASE-0109
- Symptom: after Hub screen refactor and user-facing FAQ cleanup, the
  repository still had no dedicated EFHC handoff architecture boundary;
  Hub could not yet call a backend-issued signed token flow, and the
  old Shop commerce contract remained the only active purchase contour.
- Fix in work pass 67: added
  `docs/HUB_EFHC_HANDOFF_ARCHITECTURE_AUDIT.md`, confirmed that
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`, and
  `backend/app/contracts/shop_contract.py` are still commerce-layer
  files, froze the requirement for signed short-lived one-time handoff
  tokens with `exp` and `jti`, and blocked direct reuse of Shop
  contracts as the future Hub public contract.
- Verification: direct audit of HEAD `v159_12`, including
  `frontend/src/pages/shop.tsx`,
  `backend/app/routes/shop_routes.py`,
  `backend/app/services/shop_service.py`,
  `backend/app/schemas/shop_schemas.py`,
  `backend/app/contracts/shop_contract.py`,
  and `docs/SSOT/HUB_SSOT.md`.

Work pass 70 note: active skin locale wording no longer sells skins; texts
now describe unlocks by account progress and keep the 12-level canon.


## HEAL-0099 / CASE-0110
- Symptom: after the user-facing skin wording cleanup, the active
  model/data/service/API/helper layer still retained a legacy commerce
  bridge for skins.
- Fix in work pass 71: added `docs/SKINS_MODEL_DATA_AUDIT.md`, confirmed the
  active legacy markers `price_efhc`, `purchased_at`,
  `POST /skins/buy/{skin_id}`, `buy_skin(...)`, `skin_purchase`,
  `getShopSkinBgUrl(...)`, and `efhc_shop_skin_changed`, and added
  `tests/architecture/test_skins_model_data_audit_lock.py`.
- Verification: direct audit of HEAD `v159_16`, including
  `backend/app/models/skins_models.py`,
  `backend/app/routes/skins_routes.py`,
  `backend/app/schemas/skins_schemas.py`,
  `backend/app/services/skins_service.py`,
  `backend/app/standards/skins_catalog.py`, and
  `frontend/src/lib/skins.ts`.


## 2026-03-28 — Work pass 75 Hub admin routes/services
- Подтверждён archive-first drift: следующий цикл по HEAD — `75`, не
  `76`.
- Закрыт backend слой Hub admin manager:
  list/create/update/toggle/reorder.
- Добавлены новые active endpoints `/admin/hub/links` и технические
  алиасы `/admin/shop/hub-links`.
- Price/order semantics не переносились в `hub_links`.


## 2026-03-28 — Work pass 76 Hub admin UI wave
- Подтверждено: frontend admin page ещё жила на legacy
  Shop-orders/set-price semantics.
- `frontend/src/pages/admin/shop.tsx` переведён на Hub Links Manager.
- Active UI вызывает `/admin/hub/links`, create/update/toggle/reorder.
- Из active admin UI убраны order/price fields; `/admin/shop` сохранён
  как технический route alias.


## HEAL-0100 / CASE-0111
- Symptom: the active Russian runtime FAQ had already moved section 13
  to
  `Hub`, while the Russian SSOT export file still kept the old section
  `13. Shop`.
- Fix in work pass 77: added `docs/HUB_FAQ_SECTION_13_RU_DRAFT.md`, froze
  the
  13-question Russian approval draft, and confirmed the active runtime
  total `233/250`.
- Verification: direct audit of `frontend/src/data/faq/ru.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`, and `docs/cycles/WORK_CYCLES.md`.


## HEAL-0101 / CASE-0112
- Symptom: the prior chat claimed that Russian runtime FAQ had already
  moved section 13 to `Hub`, but the HEAD archive still keeps active
  `Shop` traces in `frontend/src/data/faq/catalogs.ts`.
- Fix in work pass 78: added `docs/HUB_FAQ_CROSS_SECTION_DRIFT_AUDIT.md` and
  froze the real drift map across runtime, SSOT, bot, and locale layers.
- Verification: direct audit of `frontend/src/data/faq/catalogs.ts`,
  `docs/SSOT/faq_ssot/ru/faq_ru.md`,
  `docs/SSOT/faq_ssot/ru/faq_ru.json`,
  `backend/app/bot/handlers/shop_handlers.py`, and
  `frontend/public/locale/*.json`.


## HEAL-0102 / CASE-0113
- Symptom: the Russian SSOT FAQ still described `Shop` as a user-facing
  section in navigation answers and in section 13, while the Hub canon
  required a navigation-layer model.
- Fix in work pass 79: rewrote the Russian SSOT FAQ in
  `docs/SSOT/faq_ssot/ru/faq_ru.md` and
  `docs/SSOT/faq_ssot/ru/faq_ru.json`, moved section 13 to `Hub`,
  described EFHC/VIP as external flows, and fixed related
  navigation/top-bar answers.
- Verification: direct audit of `docs/SSOT/faq_ssot/ru/faq_ru.md`,
  `docs/SSOT/faq_ssot/ru/faq_ru.json`, and `docs/cycles/WORK_CYCLES.md`.


## HEAL-0103 / CASE-0114
- Symptom: `frontend/src/data/faq/catalogs.ts` still kept runtime FAQ
  text behind the rewritten Russian SSOT FAQ.
- Fix in work pass 80: rebuilt runtime FAQ with
  `ops/scripts/generate_faq_catalogs_from_ssot.py`, then verified exact
  parity with the generator guard.
- Verification: `pytest -q
  tests/architecture/test_faq_catalogs_generated_from_ssot.py`, direct
  audit of the RU runtime chunk, and count check `20 sections / 250
  Q/A`.


## 2026-03-28 — Work pass 81 bot help/text Hub drift
- Подтверждено: bot/help слой оставался частично на Shop-терминах, а
  helper `t()` не совпадал с фактическим способом вызова из хэндлеров.
- Исправлено: `backend/app/bot/texts.py` переведён на
  backward-compatible helper API и наполнен реальными bot/help ключами.
- Исправлено: `backend/app/bot/handlers/shop_handlers.py` и
  `backend/app/bot/handlers/admin/admin_shop_handlers.py` теперь
  описывают `Hub` как primary surface, сохраняя `/shop` и `/admin_shop`
  как технические алиасы.
- Проверено: `python -m compileall backend/app/bot`.

## HEAL-0104 / CASE-0116
- Symptom: non-Russian SSOT FAQ files still kept active `Shop` wording
  in section 13 and related top-bar/navigation answers, so multilingual
  FAQ drifted away from the Hub canon.
- Fix in work pass 82: rewrote the confirmed Hub FAQ surface in all 12
  non-Russian languages, regenerated `docs/SSOT/faq_ssot/*/faq_*.md`,
  rebuilt runtime FAQ via
  `ops/scripts/generate_faq_catalogs_from_ssot.py`, and confirmed parity
  with `test_faq_catalogs_generated_from_ssot.py`.
- Verification: direct audit of `docs/SSOT/faq_ssot/*/faq_*.json`,
  residual grep for `Shop`, runtime rebuild, and generator guard pass.


- 2026-03-28 work pass 83: docs/openapi sync closed; Hub admin surface
  `/admin/hub/links*` and public handoff `POST /hub/efhc-handoff` added
  to SSOT/OpenAPI/docs, route count synced to 88.


## HEAL-0105 / CASE-0117
- Symptom: Hub migration no longer had a dedicated regression pack
  locking the alias `shop -> hub`, the signed EFHC handoff, the external
  VIP flow, and the ban on prices/internal purchase/skin SKU inside the
  active Hub UI.
- Fix in work pass 84: added
  `tests/architecture/test_hub_guards_regression_pack.py` and
  `docs/HUB_GUARDS_REGRESSION_PACK.md` as a direct post-migration freeze
  for the active Hub surface.
- Verification: `pytest -q
  tests/architecture/test_hub_guards_regression_pack.py
  tests/architecture/test_hub_screen_refactor_lock.py
  tests/architecture/test_hub_efhc_handoff_implementation_wave1_lock.py
  tests/architecture/test_hub_vip_getgems_alignment_wave1_lock.py`.


## HEAL-0106 / CASE-0118
- Symptom: after the main Hub migration waves, the repository still
  contained a broad `shop` footprint, but the traces were mixed across
  active backend commerce code, temporary aliases, historical audit
  records, and true cleanup-ready residues.
- Fix in work pass 85: added `docs/LEGACY_SHOP_RESIDUE_AUDIT.md` and
  classified the remaining `shop` traces into keep-as-commerce,
  keep-as-alias, keep-as-history, and cleanup-candidates-for-cycle-86
  buckets.
- Verification: direct HEAD grep across `backend`, `frontend`, `docs`,
  and `tests`, plus usage checks for locale keys and active
  admin/profile surfaces.

## 2026-03-28 — work pass 86
- Подтверждённая проблема: после residue-аудита оставались cleanup-ready
  user-facing/docs residuals `Shop`, хотя backend commerce domain и
  compatibility aliases ещё нужны.
- Исправлено: удалены 143 мёртвых locale-ключа
  `admin.shop_orders_summary`, `desc.shop.*`, `shop.*` из
  `frontend/public/locale/*.json`; исправлены stale docs wording в
  `docs/FAQ_COVERAGE_MATRIX.md`, `docs/NORM/ADMIN_RBAC.md`,
  `docs/GENERAL/specification.md`, `frontend/public/skins/README.txt`.
- Проверено: direct grep по `frontend/public/locale` больше не находит
  удалённые dead keys; JSON всех locale-файлов валиден.

## HEAL-0107 / CASE-SECURITY-REGRESSION
- Symptom: after cleanup wave 1 the transition layer still needed a
  dedicated pressure test proving that old deep links, bot entry points,
  and admin aliases keep working without restoring `Shop` as the primary
  surface.
- Fix in work pass 87: added
  `tests/architecture/test_hub_alias_pressure_test.py` and
  `docs/HUB_ALIAS_PRESSURE_TEST.md` to lock `/hub` as primary while
  preserving `/shop`, `/admin_shop`, and `/admin/shop/hub-links*` as
  compatibility aliases.
- Verification: `pytest -q
  tests/architecture/test_hub_alias_pressure_test.py
  tests/architecture/test_hub_guards_regression_pack.py`.

## HEAL-0108 / CASE-0120
- Symptom: after the alias pressure test the repository still lacked a
  formal pre-removal design splitting safe `shop` alias deletion away
  from backend commerce code, compatibility surfaces, and history-only
  traces.
- Fix in work pass 88: added `docs/HUB_FINAL_ALIAS_REMOVAL_DESIGN.md` and
  updated `docs/SSOT/HUB_SSOT.md` so alias removal can proceed only by
  confirmed candidates, preconditions, and wave-based evidence.
- Verification: direct audit of `docs/SSOT/HUB_SSOT.md`,
  `docs/LEGACY_SHOP_RESIDUE_AUDIT.md`,
  `docs/HUB_ALIAS_PRESSURE_TEST.md`, and `docs/cycles/WORK_CYCLES.md`.

- Work pass 89: internal alias drift cured by moving active Hub
  implementation into canonical `hub`-named frontend and bot files while
  preserving `shop` wrappers for compatibility.

- 2026-03-28 / work pass 90: final commerce cleanup + release stabilization
  — removed dead `frontend/src/components/ShopGrid.tsx`, aligned active
  UI doc `docs/GENERAL/UI_PAGES_ACHIEVEMENTS_RU.md`, renamed canonical
  admin component export to `AdminHubPage`, preserved `/shop` and
  `/admin/shop` compatibility aliases, targeted regression pack
  required.


## 2026-03-28 — work pass 91
- Symptom: skin-layer kept a known concept gap — work pass 72 was still
  planned, while progression canon and legacy commerce bridge coexisted
  without a separate switcher SSOT.
- Fix: added `docs/SSOT/SKIN_SWITCHER_CONCEPT_SSOT.md`, linked it from
  `docs/SSOT/HUB_SSOT.md`, and locked it with
  `tests/architecture/test_skin_switcher_concept_closure_lock.py`.
- Verification: direct audit of `frontend/src/lib/skins.ts`, backend
  skins route/service/schema/model files, and targeted pytest pass.


## 2026-03-28 — work pass 92
- Symptom: the switcher concept was already fixed, but runtime/API still
  had no separate switcher-facing surface and active skin storage could
  drift from the progression canon.
- Fix: added `/skins/switcher`, `/skins/switcher/activate/{skin_id}`,
  new switcher schema/helper surface, and storage sync for
  `active_skin_id` against unlocked progression skins.
- Verification: direct audit of skins route/service/schema/frontend
  helper files, targeted pytest, and backend compileall.


## 2026-03-28 — work pass 93
- Symptom: the archive still lacked a precise wave-2 caller map for
  `/shop` and `/admin/shop`; alias-removal work could easily over-delete
  compatibility surfaces without splitting active callers away from
  wrappers and history-only traces.
- Fix: added `docs/HUB_ALIAS_CALLER_AUDIT_WAVE2.md`, documented active
  bot/admin callers, and locked the findings in
  `tests/architecture/test_hub_alias_caller_audit_wave2_lock.py`.
- Verification: direct audit of bot handlers, admin index, keyboards,
  and targeted pytest pass.


## 2026-03-28 — work pass 94
- Symptom: after caller audit wave 2 the repo still kept one internal
  admin caller to `/admin/shop` and two thin alias wrapper modules that
  were no longer part of live bot wiring.
- Fix: switched the admin internal link to `/admin/hub` and removed
  `shop_handlers.py` plus `admin_shop_handlers.py` while preserving all
  remaining external compatibility surfaces.
- Verification: direct audit of admin index, bot wiring, targeted
  pytest, and `python -m compileall backend/app/bot`.


## 2026-03-28 — work pass 95
- Symptom: admin bot entrypoints still relied on the generic main menu
  after the alias sunset waves, and help texts did not explicitly expose
  `/admin_hub` and `/admin_shop`.
- Fix: added a dedicated `kb_admin_entry()` keyboard, switched `/admin`
  and `/admin_hub` handlers to direct Admin Hub entry, and aligned help
  texts with the canonical admin entry aliases.
- Verification: direct audit of bot keyboards/handlers/texts, targeted
  pytest, and backend compileall.


## 2026-03-28 — work pass 96
- Symptom: post-alias waves changed the bot/admin entry layer, but
  active docs still carried stale wording about `/admin/shop` as the
  current internal admin entry while OpenAPI itself had not changed.
- Fix: added `docs/POST_ALIAS_DOCS_OPENAPI_FREEZE.md`, refreshed
  `docs/NORM/TESTS_CATALOG.md`, and locked the freeze with
  `tests/architecture/test_post_alias_docs_openapi_freeze_lock.py`.
- Verification: direct audit of active docs, admin index, OpenAPI
  snapshot, and targeted pytest pass.


## 2026-03-28 — work pass 97
- Symptom: after the post-alias freeze the remaining risk lived in
  admin/reporting semantics — Hub manager and commerce-domain Shop stats
  could be conflated in docs or labels.
- Fix: added `docs/ADMIN_REPORTING_HUB_HARDENING.md`, clarified
  admin/reporting docstrings, and locked the split with
  `tests/architecture/test_admin_reporting_hub_hardening_lock.py`.
- Verification: direct audit of admin index, admin stats service,
  reports service, and targeted pytest pass.

## Work pass 98 — legacy cleanup wave 2
- Symptom: последние active locale/runtime traces оставались shop-named
  (`admin.shop`, `nav.shop`, `shop.title`,
  `profile.reason.shop_purchase`).
- Fix: active runtime переведён на `admin.hub`, `nav.hub`,
  `profile.reason.hub_operation`; compatibility и commerce-domain layer
  сохранены.

## Work pass 99 — final release audit
- Symptom: финальный release audit вскрыл syntax-ошибку в bot help
  texts.
- Fix: `backend/app/bot/texts.py` исправлен; compileall подтверждён;
  OpenAPI snapshot подтверждён прямой проверкой checked-in файла.

## Work pass 100 — release stabilization and handoff
- Symptom closed: итоговая серия 61–100 имела неполный closure layer в
  плане 91–100 и без финального handoff doc.
- Fix: добавлен final handoff doc, выровнен цикл 92/100 в closure plan,
  серия закрыта документально.

## Work pass 101 — log-driven fixes and 101–110 plan
- Symptom: post-handoff CI logs showed alembic/document drift and
  frontend Hub build drift.
- Fix: synced SSOT table inventory with `hub_links`, fixed Hub admin/hub
  page frontend issues, planned full CI parity as work pass 102.

## Work pass 102 — log remediation wave
- Symptom: fresh CI logs failed on Alembic 0002 duplicate create and
  ruff import-order drift.
- Fix: migration 0002 split into offline/online branches; ruff surface
  cleaned.
- Honest state: log blockers are healed, but full parity still reveals
  non-log docs/FAQ/healer drift.

## Work pass 102 continuation
- User-directed treatment: stop keeping transition aliases after
  transition end.
- User-directed treatment: make first install effectively single-base
  migration by squashing hub_links create/seed into 0001.

## Work pass 102 — docs/route-count continuation
- Symptom: after alias/migration fixes the next exposed layer was stale
  counts and incomplete route freeze inventory.
- Fix: rebuilt freeze inventory to 88 routes and synced overview/docs
  counters.

## 2026-03-29 — work pass 102 closure
- Подтверждено: полный `pytest -q` на HEAD зелёный: 275 passed, 25
  skipped.
- Закрыт work pass 102 как full CI parity wave.
- Сняты legacy alias expectations в tests/docs после фактического sunset
  `/shop` и `/admin_shop` в active bot/page/help слое.
- Нормализованы `atlas.json` и `casebook.json` под текущий schema guard.
- Синхронизированы FAQ/translation expectations с текущим HEAD.

## 2026-03-29 — work pass 103
- Восстановлен обязательный governance layer для FAQ.
- Добавлены FAQ approval register и approval manifest.
- Зафиксировано, что FAQ waves 79–82 обошли approval gate быстрее, чем
  он был восстановлен.
- Historical draft section 13 из work pass 77 оформлен как retroactive
  approval entry `FAQ-APPROVAL-0001`.

## 2026-03-29 — work pass 104
- Проведён прямой FAQ runtime vs SSOT parity audit.
- Подтверждено по 13 языкам: 20 sections, 250 Q/A, section 13 = Hub.
- Прямого parity drift, требующего rewrite в этом же цикле, не найдено.
- Зафиксировано правило пользователя: в текущем цикле делать максимально
  возможный объём подтверждаемой работы без искусственного переноса на
  следующий цикл.

## 2026-03-29 — work pass 105
- Generator FAQ runtime now validates approval manifest before rebuild.
- Added hardening for manifest count, entry fields, 20/250 inventory,
  and section 13 = Hub.
- Runtime `catalogs.ts` rebuilt with generated header and governance
  source marker.

## 2026-03-29 — work pass 106
- Bot/help layer synced with current FAQ state.
- Added direct `/faq` bot command and FAQ entry keyboard.
- RU/EN help texts now mention current FAQ inventory 20/250.

## 2026-03-29 — Work pass 107
- Case: multilingual FAQ legal wording drift after Hub migration.
- Rule: multilingual FAQ rewrite requires draft + manifest/register
  entry + explicit approval before SSOT rewrite and runtime rebuild.

## Case 2026-03-30 — latent panel docs drift after approved RU FAQ
   rewrite

- Symptom: `docs/SSOT/faq_ssot/ru/faq_ru.*` already used approved panel
  wording `Активация панели`, but `docs/SSOT/PANELS_SSOT.md` and
  `docs/SSOT/FAQ_SSOT.md` still kept stale phrases `купить панель`,
  `цена панели`, and `после покупки первой панели`.
- Risk: SSOT/doc layer drift could falsely signal that work pass 126 was
  unfinished even though the Russian FAQ source was already rewritten.
- Fix in work pass 126: synced `docs/SSOT/PANELS_SSOT.md` and
  `docs/SSOT/FAQ_SSOT.md` to the approved panel canon without touching
  runtime or backend route names.
- Verification: direct grep audit of the updated docs confirmed removal
  of those stale user-facing phrases from the rewritten sections.

- 2026-03-30: Work pass 127 — устранён drift reason-кода панели: backend ещё
  писал `panel_purchase`, admin overview суммировал только legacy
  reason, а history runtime учитывал legacy mapping. Канон выровнен на
  `panel_activation` с backward-compatible чтением исторических записей.

- 2026-03-30: Work pass 128 — active defect не подтверждён; выполнен
  controlled prep-layer для multilingual panel wording package без
  runtime rewrite.

- 2026-03-31: Work pass 129 — healed multilingual panel-line drift in
  SSOT/runtime and fixed `FAQ_APPROVAL_MANIFEST.json` count mismatch
  that blocked FAQ runtime rebuild.

- 2026-03-31: Work pass 130 — active panel wording drift closed; residual
  traces reclassified into legacy/non-runtime FAQ layer and internal
  technical naming layer.

- 2026-03-31: Work pass 131 — backend panel wording drift reclassified as
  technical naming debt; current compatibility anchors frozen for a
  later controlled refactor.

- 2026-03-31: Work passes 132-135 — panel wording refactor moved active
  backend/frontend/API surfaces to activation canon while preserving
  technical compatibility names and paths.

- 2026-03-31: Work pass 136 — active panels parity confirmed; residual panel
  drift reclassified from user-facing flow to admin-facing PB5-3
  accounting visibility.
- 2026-03-31: Work passes 137-140 — PB5-3 split counters healed in active
  admin layer; backend dual-read of `panel_purchase` +
  `panel_activation` preserved while UI switched to approved
  total/main/bonus labels.

- 2026-03-31: Work pass 141 — isolated stale non-runtime FAQ source
  `frontend/src/data/faq/ru.ts`; active FAQ source remains generated
  `catalogs.ts`.
- 2026-03-31: Work pass 142 — converted legacy `faqRuCatalog` file into a
  compatibility alias to generated runtime data and removed French
  section-13 `Boutique` drift from FAQ meta.
- 2026-03-31: Work passes 143-144 — backend panel naming cleanup limited to
  internal docs/comments/examples; compatibility anchors remain frozen.
- 2026-03-31: Work pass 145 — post-panel release audit confirmed cycles
  129-145 are reflected in HEAD archive state.

- 2026-03-31: Work pass 146 — removable aliases identified: `etag`,
  `purchase_panel`, `on_user_first_panel_purchase`; public compatibility
  surfaces remain frozen.
- 2026-03-31: Work pass 147 — safe internal aliases removed and callers
  repaired.
- 2026-03-31: Work pass 148 — canonical panels activation route added as
  `/panels/activate/{tg_id}`; `/panels/buy/{tg_id}` retained as
  compatibility wrapper.
- 2026-03-31: Work pass 149 — static migration parity audit found no new
  archive-proven migration defect.
- 2026-03-31: Work pass 150 — post-alias release audit closed series 146-150
  on HEAD.

Work pass 152 note: confirmed `/admin/shop/*` no longer has active admin UI
or bot callers in HEAD; remaining surface is backend admin compatibility
only.
Work pass 151 note: confirmed `/shop/*` no longer has active frontend or bot
callers in HEAD; remaining surface is backend compatibility/API only.

Work pass 160 note: closed post-alias release audit for series 146–159;
canonical panels route sync, migration readiness audit and alias-freeze
boundary are now fixed in release docs.
Work pass 158 note: `/shop/*` and `/admin/shop/*` remain frozen backend
compatibility surfaces; no safe contract-preserving deletion was
confirmed in this wave.
Work pass 157 note: added new locks for canonical panels activation route in
SSOT/OpenAPI/frontend and for migration live-run readiness audit
presence.
Work pass 153 note: synced canonical `POST /panels/activate/{tg_id}` into
SSOT route registries and exported OpenAPI while keeping compat `POST
/panels/buy/{tg_id}`.

Work pass 170 plan note: finish the next series with a full
archive-vs-chat-vs-logs parity audit so that unresolved proof gaps are
either closed or explicitly frozen.
Work pass 164 plan note: obtain real Alembic proof instead of relying only
on structural readiness audit.
Work pass 161 plan note: historical docs now need explicit archival marking
because some old audit files describe already-removed alias states.

Work pass 165 note: `/shop/*` and `/admin/shop/*` are now explicitly frozen
backend compatibility contracts pending a future canonical
contract-migration wave.
Work pass 164 note: live Alembic proof is blocked in this environment
because `sqlalchemy` is not installed.
Work pass 162 note: key stale-state docs now carry archival markers and
should not be read as active current-state truth.

Work pass 170 note: full archive-vs-chat-vs-logs parity audit closed the
current series; fresh logs are still absent, but freeze/proof boundaries
are now explicit and test-backed.
Work pass 169 note: added deterministic route inventory markdown
regeneration helper to reduce manual route-doc drift.
Work pass 168 note: `POST /panels/buy/{tg_id}` is frozen as a compatibility
path while frontend stays on canonical `/panels/activate/{tg_id}`.
Work pass 166 note: `/shop/*` and `/admin/shop/*` freeze moved from
decision-only to explicit docs/tests implementation.

Work pass 175 note: active backend/frontend/bot wording drift is now
synchronized with Hub/external-flow canon for the current release line
and backed by targeted tests.
Work pass 172 note: active locale keys in Hub, wallet and settings were
refreshed across all 13 locale files to remove stale buy/purchase
wording from active UI paths.

- 2026-03-31: Healer note -> log-driven stabilization wave fixed
  syntax/doc-count/catalog/archive-lock drift for work pass 176.

- 2026-03-31: Resolved historical blocker: work pass 164 closed after CI
  proved live Alembic upgrade head.

- 2026-03-31: Multilingual care wave 177-180 -> first active locale sync
  completed for nav/faq/hub/core titles/common shell.

- 2026-03-31: Manual multilingual treatment 181-182 -> Profile and
  Wallet wave 1 completed.

- 2026-03-31: Manual multilingual treatment 183-185 -> Panels,
  Exchange+Energy, Tasks+Referrals wave 1 completed.

- 2026-03-31: Manual multilingual treatment 186-187 -> History+Withdraw
  and Ranks+Prizes wave 1 completed.

- 2026-03-31: Manual multilingual treatment 188 + audit 189 ->
  common/balances synced; prizes/tournaments classified as non-confirmed
  active public section.

- 2026-03-31: Active `prizes/tournaments` tail removed from current
  code/doc layer; allowed only as historical evidence in reports/work
  cycles/healer.

- 2026-03-31: Manual treatment 191 -> Hub + FAQ shell wave 2 completed;
  current page inventory fixed in separate doc.

- 2026-03-31: Manual treatments 193-194 -> admin high-traffic locale
  sync completed; 195 verified no regression of removed
  prizes/tournaments tail.

- 2026-03-31: Overview docs treatment 196 completed; pages inventory
  drift removed, and migration summary was then re-normalized in cycle
  197 to strict `0001 only`.

- 2026-03-31: Migration reset treatment 197 completed; active Alembic
  layer now expected as `0001` only.

- 2026-03-31: Documentation treatment 198 completed; migration canon
  clarified in-place inside existing docs.

- 2026-03-31: Registry normalization treatment 199 completed; recent
  append-only notes now reflect `0001 only` canon consistently.

- 2026-03-31: Final docs closeout 200 completed; historical audit files
  now carry explicit archival markers where needed.

- 2026-03-31: Work pass 201 — в реестр добавлены 15 уточняющих вопросов по
  полной ревизии документации архива; дальнейшая работа должна идти по
  полному списку документов с пофайловым согласованием действий `удалить
  / объединить / актуализировать`.

- 2026-03-31: Work pass 202 — построен полный master-index документации
  архива; audit-документы и лог-аудиты перенесены в `docs/audits/`,
  `reports/` оставлен вне текущего ручного обзора.

- 2026-03-31: Work pass 203 — зафиксированы решения пользователя по первой
  пятёрке документов; выполнено объединение legacy root
  `ARCHITECTURAL_LOCKS`, перенос `CHANGELOG` в `reports/`, перенос
  `CODE_OF_CONDUCT` в `artifacts/` и актуализация `CONTRIBUTING`.

- 2026-03-31: Work pass 204 — повторный audit чата и стартовых правил
  завершён; подготовлен обновлённый полный промт продолжения в новом
  чате с фиксацией документной фазы и точки продолжения по master-index.

- 2026-04-01: Work pass 205 — документная ревизия продолжена по решениям
  пользователя: `README.md` актуализирован, `REPORT_COMMANDS.txt`
  перемещён в `artifacts/misc/`, `SECURITY.md` расширен; дополнительно
  зафиксировано правило, что `artifacts/` не проверяется в пакетах
  ревизии как архивная корзина.

- 2026-04-01: Work pass 206 — мягко актуализированы
  migration/OpenAPI/requirements слои по прямому аудиту HEAD; текущий
  миграционный канон для первого релиза зафиксирован как `0001 only`,
  checked-in OpenAPI snapshot оставлен в active слое с обновлённым
  audit-note, а `backend/requirements.txt` дополнен недостающими
  зависимостями `PyJWT`, `cryptography` и `PyYAML`, которые используются
  в текущем архиве.

- 2026-04-01: Work pass 207 — `docker-compose.yml` мягко актуализирован по
  текущему Docker/archive layer;
  `docs/ACTIVE_WORDING_GUARDS_WAVE_2026_03_31.md` выведен в
  `artifacts/docs/`; `docs/GENERAL/ADMIN_PANEL_SPEC.md` объединён с
  более полным описанием админ-панели; `docs/NORM/ADMIN_RBAC.md`
  сохранён как active NORM и мягко актуализирован без ослабления
  ролевого канона.

- 2026-04-01: Work pass 208 — semantic boundary из
  `docs/ADMIN_REPORTING_HUB_HARDENING.md` интегрирована в
  `docs/GENERAL/ADMIN_PANEL_SPEC.md`, а сам файл выведен в
  `artifacts/docs/`; ADR 0001/0002/0003 и
  `docs/AI/AI_OPERATOR_RULES_EFHC.md` мягко актуализированы по текущему
  HEAD и текущему prompt-режиму документной фазы.

- 2026-04-01: Work pass 209 — `docs/API_REFERENCE.md` объединён с
  `docs/NORM/API_CONTRACTS.md` и выведен в `artifacts/docs/`;
  `docs/AI/AI_RESILIENCE_CANON.md`, `docs/NORM/API_CONTRACTS.md`,
  `docs/NORM/ARCHITECTURAL_LOCKS.md` и
  `docs/GENERAL/ARCHITECTURE_DEPENDENCIES_RU.md` актуализированы по
  текущему HEAD и document-phase rules.

- 2026-04-01: Work pass 210 — три wave/plan документа сведены по смыслу в
  `docs/cycles/WORK_CYCLES.md` и выведены в `artifacts/docs/`;
  `docs/GENERAL/ARCHIVE_NAV_INDEX.md` мягко актуализирован;
  `docs/NORM/TASKS_STANDARD.md` признан достаточно сильным для NORM-слоя
  и добавлен в `docs/SSOT/SSOT_INDEX.md`.

- 2026-04-01: Work pass 211 — `docs/BACKGROUND_TASKS_STANDARD.md`
  переименован в `docs/NORM/TASKS_STANDARD.md`; связанные active реестры
  и индексы синхронизированы с новым путём.

- 2026-04-01: Work pass 212 — `docs/SSOT/BANK_CANON.md` проверен против
  bank/economy SSOT и добавлен в NORM через `docs/SSOT/SSOT_INDEX.md`;
  `docs/BOT_PAGES_INVENTORY_2026_03_31.md` перенесён в `docs/audits/`;
  `docs/BOT_WEBAPP_ENTRYPOINT_STABILIZATION.md`,
  `docs/CI_WORKFLOW_CANON_EFHC_BOT_V_ZIP.yml` и
  `docs/CODE_CLEANUP_AND_IMPROVEMENT_10_CYCLES_PLAN.md` выведены из
  active слоя; в `docs/AI/AI_OPERATOR_RULES_EFHC.md` добавлен
  обязательный формат `цикл X/Y завершён`.

- 2026-04-01: Work pass 213 — `docs/GENERAL/DOCKER_LOCAL.md` синхронизирован
  с текущим Docker layer; `docs/SSOT/DTO_INPUT_CANON.md` повышен до NORM
  через `docs/SSOT/SSOT_INDEX.md`; `docs/SSOT/EFHC_CANON.md` мягко
  вычищен по подтверждённой точке drift; `docs/SSOT/ENERGY_RULES.md`
  дополнен явной связью с exchange/available_kwh SSOT;
  `docs/NORM/ERROR_CODES.md` дополнен кодами `WALLET_REQUIRED` и
  `HUB_HANDOFF_NOT_CONNECTED`.

- 2026-04-01: Work pass 214 — `EVENTS_MATRIX.md` оставлен как active NORM и
  получил compat-оговорку для panel technical naming;
  `EXCHANGE_WITHDRAW_MECHANICS_SSOT.md` дополнен cross-reference слоем;
  `FAQ_APPROVAL_GOVERNANCE.md` и `FAQ_CODE_GENERATION_HARDENING.md`
  мягко актуализированы по current HEAD; `FAQ_BOT_HELP_PARITY_WAVE.md`
  выведен в `artifacts/docs/`.
- 2026-04-01: Work pass 215 — FAQ helper/rewrite/freeze документы убраны из
  active docs слоя: `FAQ_COVERAGE_MATRIX.md` переведён в
  `artifacts/docs/`, а `FAQ_EXCHANGE_RU_REWRITE_WAVE1.md`,
  `FAQ_FORBIDDEN_WORDING_RU_REWRITE_WAVE1.md`,
  `FAQ_HUB_RU_REWRITE_WAVE1.md` и `FAQ_INVENTORY_FREEZE.csv` переведены
  в `docs/audits/`.
- 2026-04-01: Work pass 216 — `FAQ_INVENTORY_FREEZE.md` переведён в
  `docs/audits/`; `FAQ_MULTILINGUAL_LEGAL_WORDING_DRAFT.md`,
  `FAQ_PANELS_BOT_UI_RU_REWRITE_WAVE1.md`,
  `FAQ_PANELS_RATES_RU_DRAFT.md` и `FAQ_PANELS_RU_REWRITE_WAVE1.md`
  выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Work pass 217 — `FAQ_REPLACEMENT_LEDGER.md` актуализирован и
  переведён в `docs/audits/`; `FAQ_SSOT.md` мягко актуализирован;
  `FAQ_TOPBAR_RU_REWRITE_WAVE1.md`, `FAQ_VIP_RU_REWRITE_WAVE1.md` и
  `FAQ_WALLET_RU_REWRITE_WAVE1.md` выведены в `artifacts/docs/`.
- 2026-04-01: Work pass 218 — `FRONTEND_ACTIVE_LOCALE_SYNC_2026_03_31.md`,
  `HUB_ADMIN_ENTITY_DESIGN.md` и `HUB_ADMIN_MIGRATION_MODEL_WAVE.md`
  переведены в `docs/audits/`; important pressure-test context перенесён
  в `docs/cycles/WORK_CYCLES.md`; `HUB_ALIAS_PRESSURE_TEST.md` и
  `HUB_ALIAS_REMOVAL_WAVE2.md` выведены в `artifacts/docs/`.
- 2026-04-01: Work pass 219 — смысл `HUB_CYCLES_91_100_PLAN.md` сведен в
  `docs/cycles/WORK_CYCLES.md`;
  `HUB_EFHC_HANDOFF_IMPLEMENTATION_WAVE1.md`,
  `HUB_FAQ_SECTION_13_RU_DRAFT.md` и `HUB_FINAL_ALIAS_REMOVAL_DESIGN.md`
  переведены в `docs/audits/`; `HUB_FINAL_ALIAS_REMOVAL_WAVE1.md`
  выведен в `artifacts/docs/`.
- 2026-04-01: Work pass 220 — смысл
  `HUB_FINAL_COMMERCE_CLEANUP_RELEASE_STABILIZATION.md` сведен в
  `docs/cycles/WORK_CYCLES.md`; `HUB_GUARDS_REGRESSION_PACK.md`,
  `HUB_SERIES_61_100_FINAL_HANDOFF.md` и
  `I18N_ADMIN_VERIFICATION_2026_03_31.md` переведены в `docs/audits/`;
  `HUB_SSOT.md` мягко актуализирован.
- 2026-04-01: Work pass 221 — historical i18n wave-docs
  (`I18N_ADMIN_WAVE1_2026_03_31.md`, `I18N_ADMIN_WAVE2_2026_03_31.md`,
  `I18N_COMMON_BALANCES_WAVE1_2026_03_31.md`,
  `I18N_EXCHANGE_ENERGY_WAVE1_2026_03_31.md`,
  `I18N_HISTORY_WITHDRAW_WAVE1_2026_03_31.md`) выведены из active docs
  слоя в `artifacts/docs/`.
- 2026-04-01: Work pass 222 — historical i18n Hub/matrix/plan/wave документы
  (`I18N_HUB_FAQ_WAVE2_2026_03_31.md`,
  `I18N_MISSING_KEY_MATRIX_2026_03_31.md`,
  `I18N_MISSING_TRANSLATIONS_PLAN_191_195.md`,
  `I18N_PANELS_WAVE1_2026_03_31.md`, `I18N_PROFILE_WAVE1_2026_03_31.md`)
  выведены из active docs слоя в `artifacts/docs/`.
- 2026-04-01: Work pass 223 — `I18N_SYNC_PLAN_181_190.md`,
  `I18N_TASKS_REFERRALS_WAVE1_2026_03_31.md`,
  `I18N_WALLET_WAVE1_2026_03_31.md`, `LEGACY_CLEANUP_WAVE2.md`,
  `LEGACY_FRONTEND_FAQ_SOURCES_CLEANUP_2026_03_31.md` выведены из active
  docs слоя в `artifacts/docs/`; исторически важные выводы двух legacy
  cleanup документов сохранены в `docs/cycles/WORK_CYCLES.md`.
- 2026-04-01: Work pass 224 — historical смысл
  `LIVE_ALEMBIC_PROOF_BLOCKER_2026_03_31.md` и
  `LOTTERIES_DECOMMISSION_CYCLES.md` сохранён в
  `docs/cycles/WORK_CYCLES.md`; master-index очищен от слоя
  `artifacts/`; `MIGRATION_INVARIANTS_HARDENING.md` актуализирован и
  переведён в NORM.
- 2026-04-01: Work pass 225 — historical смысл
  `MIGRATION_RESET_TO_0001_2026_03_31.md`,
  `OBSERVABILITY_METRICS_PLAN.md` и
  `OPENAPI_RELEASE_DOCS_FREEZE_2026_03_31.md` сохранён в
  `docs/cycles/WORK_CYCLES.md`/active docs;
  `MODEL_TABLE_ROUTE_TEST_MAP.md` актуализирован и переведён в NORM;
  `MODULES_DEPENDENCIES.md` мягко актуализирован по current HEAD.
- 2026-04-01: Work pass 226 — важный смысл
  `OVERVIEW_DOCS_REFRESH_2026_03_31.md`,
  `PANELS_ADMIN_COUNTERS_DESIGN_2026_03_31.md`,
  `PANELS_API_WORDING_SYNC_2026_03_31.md` сохранён в
  `docs/cycles/WORK_CYCLES.md`; summary-данные `OVERVIEW_SSOT_SYNC.md` и
  panels approval package absorbed by active NORM/SSOT docs; standalone
  files выведены в `artifacts/docs/`.
- 2026-04-01: Work pass 227 — важный panels compatibility смысл absorbed by
  `docs/SSOT/PANELS_SSOT.md` and `docs/cycles/WORK_CYCLES.md`;
  standalone panels draft/sync/freeze docs выведены в `artifacts/docs/`.
- 2026-04-01: Work pass 228 — panels/project/release pack cleaned;
  historical notes absorbed by `docs/cycles/WORK_CYCLES.md`,
  `README.md`, `docs/GENERAL/architecture.md`;
  `QUESTIONS_AND_ANSWERS_REGISTER.md` and `RANKS_RULES.md` promoted to
  NORM.
- 2026-04-01: Work pass 229 — referral canon and routes/migrations playbook
  promoted to NORM; release hygiene and old repair plan absorbed into
  `docs/cycles/WORK_CYCLES.md`; `ROUTE_INVENTORY_FREEZE.md` left pending
  separate decision as a freeze snapshot rather than current live
  inventory.

## work pass — Ручная log-fix wave по logs_63144383921.
- Лечённые симптомы: flake8 F821, ruff import ordering, frontend TS
  nullability, frontend line72, stale FAQ guard expectations.
- Ограничение лечения: partial local proof из-за environment drift
  (sqlalchemy/bandit unavailable).

## work pass — Manual log-fix continuation from logs_63146798186.
- Main treated symptoms: mypy undefined name, frontend type error.
- Residual symptom: ruff/import drift wave in multiple tests remains
  active.

## work pass — Manual continuation of ruff/import drift wave.
- Result: targeted ruff subset now clean.
- Next evidence source must be a fresh CI log.

## work pass — Manual pytest-gate wave.
- Symptom: async panel tests were collected as unsupported coroutine
  tests.
- Treatment: async-marking restored for four panel tests.
- Next evidence source: fresh CI log.

## work pass — Green CI proof recorded from logs_63150433402.zip.
- Healer wave 331-334 considered factually closed by fresh CI proof.

## work pass — Control-rule treatment for delayed documentation before build.
- Build-before-docs drift is now explicitly prohibited.

## work pass — Treated critical control breach: user withdraw list no longer triggers
  repair or money mutations.
- Treated exchange contract breach: explicit `amount_kwh` now maps to
  partial exchange instead of silent exchange-all.
- Treated startup drift: `.env` loads before `app.main`, and
  `create_app()` now delegates to canonical `main.app`.
- Treated USDT live risk by disabling pseudo-payload flow until real
  jetton transfer exists.
- Remaining open item: work pass for real jetton transfer or stronger
  deferred-state guards.

## work pass — Honest deferred-state closure for USDT.
- Symptom: USDT had been disabled at tx assembly, but could still leak
  through earlier hub/shop/catalog layers.
- Treatment: added earlier guard rejections and marked live checkout
  TON-only until real TEP-74 payload support exists.

## work pass — Curated donor sandbox folder added to HEAD.
- Symptom treated: future donor work risked scattering across many
  unrelated
  sandboxes.
- Treatment: 10 prioritized sources were copied into `песочница/` and
  ranked.
- Main donor fixed: `sdk-main`.


## work pass — Donor audit and canon synchronization for EFHC jetton.
- Symptom treated: the project needed a clean pre-implementation map for
  real USDT jetton transfer, and the user requested the EFHC jetton to
  be fixed in canon instead of living only in config.
- Treatment: canonical EFHC jetton master address and decimals were
  synchronized from config into SSOT; a donor transfer map was created
  from curated sandboxes with `sdk-main` fixed as the primary donor.
- Honest boundary: no real USDT jetton transfer live implementation was
  claimed in this cycle.

## work pass — Pre-implementation donor integration package for real USDT jetton
  transfer.
- Symptom treated: after sandbox curation, the project still lacked a
  narrow donor extraction, adapter plan, backend alignment map,
  guard-test package and explicit live gates.
- Treatment: created six linked docs covering donor surface, frontend
  adapter plan, recipient/payload/fee decisions, backend intent/watcher
  alignment, test package and live gating.
- Honest boundary: the project remains in TON-only live mode until these
  gates are passed by a future implementation wave.

## work pass current pass
- Implementation wave started carefully from safe frontend foundations.
- Symptom treated: the project had transfer plans and donor maps, but
  still lacked real local EFHC-owned helper files to begin the adapter
  series.
- Treatment: added `frontend/src/lib/ton/units.ts`, `payload.ts`,
  `policy.ts` and barrel export `index.ts`; kept live USDT disabled and
  avoided fake completion claims for SDK-backed builder work.
- Verification: targeted TypeScript compilation for the new files
  passed.

## work pass current pass
- Dependency manifest wave was applied carefully at the repository
  level.
- Symptom treated: the future jetton builder needed declared
  dependencies and a bit more local policy/config scaffolding, but the
  environment still lacked install-proof.
- Treatment: updated frontend package manifests for `@ton/core`,
  `@ton/ton`, `@ton-community/assets-sdk`; added `constants.ts` and
  `recipient.ts`; kept honest note that npm install is blocked by E401
  in this environment.
- Verification: targeted TypeScript compilation for local helper files
  passed.

## work pass current pass
- Added a local plan-level transfer layer after the dependency manifest
  wave.
- Symptom treated: helper files existed, but there was still no single
  normalized object describing a future USDT transfer operation before
  the real SDK-backed builder step.
- Treatment: added `tx.ts` and `usdt-transfer-plan.ts`; the plan layer
  now normalizes payload, amount, recipient, fee and sender fields
  before any future TEP-74 body serialization.
- Verification: targeted TypeScript compilation for `src/lib/ton/*.ts`
  passed.

## work pass backend intent enrichment pass
- Backend transport contract was enriched before the real builder step.
- Symptom treated: the future frontend builder path still lacked
  structured optional metadata in intent/status responses.
- Treatment: added `build_transport_meta(...)` and extended backend
  schemas with optional transport fields; frontend local types were
  aligned.
- Verification: compileall for changed backend Python files passed.

## work pass SDK-backed builder pass
- An unverified builder/adaptor layer was written after the helper and
  contract waves.
- Symptom treated: the project still lacked actual source files for
  sender wallet resolution, transfer body creation and TonConnect tx
  assembly.
- Treatment: added `jetton-transfer-builder.ts` and `usdt-transfer.ts`;
  kept an explicit honest boundary that only syntax-level proof exists
  so far.
- Verification: TypeScript transpileModule for the two new files
  reported no diagnostics.

## Current pass — browser-shop transport integration
- Browser-shop received a local helper that translates backend transport
  metadata into a builder-ready transfer plan.
- Symptom treated: transport metadata existed, but there was still no
  dedicated integration helper between browser-shop intent responses and
  the local transfer-plan/builder layers.
- Treatment: added `browser-shop-intent.ts` and transport metadata
  preview in `BrowserShopPage.tsx`.
- Verification: targeted local TypeScript proof passed; syntax-level
  transpile proof for the page passed.

## Current pass — readiness and tx normalization
- Browser-shop received an honest readiness/preview layer.
- Symptom treated: the page could show raw intent data, but could not
  explicitly tell whether the future USDT builder path had enough
  metadata to proceed.
- Treatment: added `tonconnect-normalize.ts`, `usdt-readiness.ts`, and
  page-level preview of normalized tx and missing transport fields.
- Verification: targeted local TypeScript proof passed; syntax-level
  transpile proof for the page passed.

## 2026-04-03 — runtime gate state integration
- Снята ещё одна причина UI drift: readiness preview и feature-gate
  состояние больше не размазаны по странице, а сведены в отдельный
  runtime-state helper.
- Guard: BrowserShopPage не должен сам вычислять блокировки USDT
  checkout ad-hoc; для этого теперь есть `browser-shop-usdt-runtime.ts`.
- Жёсткая граница сохранена: disabled/live distinction по USDT нельзя
  стирать даже при росте локального preview слоя.

## 2026-04-03 — server-truth USDT mode integration
- Убрана ещё одна точка drift: режим USDT больше не должен жить только в
  frontend helper.
- Guard: source of truth для `disabled/preview/staged/live` должен
  приходить с сервера и дублироваться во frontend только как
  отображение/guard, а не как самостоятельное решение страницы.
- Ограничение сохранено: наличие server mode не означает runtime-proof
  send path.

## 2026-04-03 — watcher transport split + command summary integration
- Guard: watcher mode split должен жить отдельным transport layer, а не
  быть размазан по `watcher_service.py` ad-hoc ветками.
- Guard: runtime command summary во frontend должен оставаться отдельным
  слоем поверх runtime state.
- Контроль циклов обновлён: 365 и 367 переведены из чистого pending в
  partial.

## 2026-04-03 — watcher validation hardening
- Guard: watcher не должен пытаться подтверждать payment intent по
  неподдержанному jetton transport path как будто это TON/USDT.
- Guard: `unknown_jetton` и `efhc_jetton` для payment intents должны
  блокироваться явно и уходить в manual path.
- Контроль циклов обновлён: 366 переведён из чистого pending в partial.

## 2026-04-03 — log-fix wave: repo hygiene + mypy/ruff
- Guard: donor-store `песочница/` не должен ломать product repo-wide
  canon tests, потому что это не live product code.
- Guard: frontend helper files должны использовать только canonical
  `tg_id`, без alias `tg-id alias`.
- Guard: generated frontend artifacts (`tsbuildinfo`, caches) не должны
  попадать в релизный архив.

## 2026-04-03 — tg-id alias doc cleanup + blocker registry
- Guard: даже журналы и отчёты не должны возвращать запрещённые
  alias-формы вокруг `tg_id`.
- Guard: нельзя помечать 356, 358–364, 368–370 как done, пока не закрыты
  их реальные proof/blocker-условия.

- 2026-04-03 / work pass continued: watcher hardening now covered by
  process-level tests for short-circuit and native TON intent branches;
  keep extending beyond helper-only checks before marking 368 done.

- 2026-04-03 / work pass expanded: process-level watcher coverage now
  includes confirm-failure -> pending_manual and native TON intent path.
  Keep 368 partial until wider backend/watcher suite is complete.

- 2026-04-03 / log 63240230827: fixed watcher-service schema drift
  (`ton_inbox_logs.utime` absent in current schema) and cleaned
  remaining tg-id alias wording in `WORK_CYCLES.md`. Local re-proof:
  mypy 0, ruff 0, targeted pytest 16 passed / 3 skipped.

- 2026-04-03 / log 63241331034: fixed asyncpg ambiguous parameter issue
  in watcher ton_inbox_logs upsert (`status` text vs varchar) by casting
  insert status and literalizing final-status comparisons. Local proof
  package back to green on targeted tests/ruff/mypy.

- 2026-04-03: sandbox expanded with `ton-access-main` and
  `ton-crypto-master` to support TON stack simplification and
  dependency-path cleanup.

- 2026-04-03: one-pass blocker attack removed
  `@ton-community/assets-sdk`; active runtime path now depends only on
  `@tonconnect/ui-react`, `@ton/core`, `@ton/ton`. Remaining blocker is
  install access to remaining TON tarballs.

- 2026-04-03: sandbox expanded with `ton-core-main` and `ton-main` to
  support local TON runtime integration without relying only on npm
  install.

- 2026-04-03: blocker chain reduced again. Active frontend path now uses
  local sandbox sources for `@ton/core`, `@ton/ton`, and `@ton/crypto`;
  remaining npm blocker moved to TonConnect UI packages.

- 2026-04-03: sandbox index refreshed. `sdk-main` locked as the main
  donor for TonConnect UI; local TON source donors and endpoint donors
  are now separated explicitly.
- 2026-04-03: case update — main frontend blocker narrowed and partially
  solved. npm install/runtime package barrier removed by localizing TON
  core + TonConnect dependencies; remaining issue is local donor
  TypeScript compatibility under Next build/type-check.
- 2026-04-03: sandbox enlarged with secondary donor/reference archives
  from the new batch; no change to the main blocker diagnosis.
- 2026-04-03: sandbox enlarged again with second-batch UI/reference
  donors; no change to the core blocker diagnosis.
- 2026-04-03: build/type blocker narrowed again. TonConnect local compat
  + npm ci remain green; residual blocker sits in
  isolatedModules/export-type friction inside local sdk/protocol donor
  sources.
- 2026-04-03: local donor build blocker narrowed again. Protocol
  entrypoint friction partly patched; current top stop is
  `sdk/src/models/index.ts` export-type compatibility under Next
  isolatedModules.
- 2026-04-03: deeper build-blocker audit confirms the current top stop
  is `sdk/src/models/index.ts`; install barrier remains solved.
- 2026-04-03: current blocker audit — donor-source build stop moved to
  `sdk/src/models/index.ts`; separate environment registry instability
  observed on repeated `npm ci` (`@twa-dev/types`,
  `@tanstack/query-core`).
- 2026-04-03: plan locked. Current work order changed from scattered
  work pass pressure to stable-environment strategy: one TON runtime path ->
  browser polyfills -> runtime checks -> USDT logic.

- 2026-04-04: Problem narrowed to runtime artifact delivery, not project
  business logic. Added donor batch and strategy lock for
  TON/TonConnect.

- 2026-04-04 / runtime path drift: do not claim TON/TonConnect published
  runtime path until `frontend/tsconfig.json` aliases are checked
  directly. This pass removed raw donor aliases for `@ton/core`,
  `@ton/ton`, `@ton/crypto`, and `@tonconnect/sdk`; remaining blocker
  moved to npm mirror E401, not isolatedModules over donor sources.

- 2026-04-04 / sandbox cleanup rule: category overlap is not enough for
  removal. Only move a sandbox donor into artifacts when a direct
  logical duplicate is confirmed by structure and purpose, as in
  `demo-dapp-with-react-ui-master` vs
  `sdk-main/apps/demo-dapp-with-react-ui`.

- 2026-04-04 / cycle-queue guard: historical `WORK_CYCLES` snapshots may
  preserve old front edges. After the runtime-path shift, do not keep
  saying the next work pass is `368`; the active queue returns to `358-364`
  first, then `365-370`.

- 2026-04-04: new guard lesson — do not “fix” VIP external verification
  by removing the external storefront from backend/admin. The repo
  location does not redefine the flow as in-Telegram sale. Fix only
  Telegram-side wording, norms and guards.

- 2026-04-04: new cycle-audit lesson — do not keep unfinished queues
  frozen in an old technical narrative after the user clarifies product
  topology. Preserve work pass numbers, but rebase unfinished work pass meaning
  to the current agreed direction.

- 2026-04-04: common-shell lesson — when a compat layer returns a fake
  hardcoded state like `useIsConnectionRestored() = false`, treat it as
  a real product-path defect, not as a harmless stub. Guard it at
  architecture level.

- 2026-04-05: повторно зафиксирована Healer-болезнь AI-layer — попытка
  вынести active work pass queue / plan в новый отдельный документ вместо
  ведения единственного канонического журнала
  `docs/cycles/WORK_CYCLES.md`.
  Новый жёсткий запрет закреплён в `docs/AI/AI_OPERATOR_RULES_EFHC.md`
  и `docs/AI/AI_STARTUP_AND_COMMUNICATION_PROTOCOL.md`:
  нельзя создавать cycle-plan / cycle-status / cycle-register /
  wave-plan документы для active cycles.


## 2026-04-08 — release blockers wave 1
- Guard: withdraw route/service contract must stay aligned; never
  reintroduce a
  route-only `idempotency_key` argument that service cannot accept.
- Guard: repeated cancel must return a replay-safe `CANCELED` outcome
  and must
    be able to finish refund if the first pass stopped after status
  transition.
- Guard: withdraw must remain a standalone user-facing path, not only a
  hidden
  subsection of exchange/profile.
- Guard: `sale-packages` cannot be shown as a release-ready operator
  SSOT while
  user-facing deposit packages come from `efhc_core.shop_items`.


## 2026-04-08 — release hardening wave 2
- Guard: if `sale-packages` is not SSOT, backend mutating routes must
  not stay
  writable in the release contour.
- Guard: detailed work pass logs are mandatory because work pass docs are
  project memory,
  direction and off-chat storage of the repair path.
- Guard: approve/reject withdrawals and bank mint/burn must expose a
  context
  block before confirmation, not only a raw action button.


## 2026-04-08 — operator workflow wave 3
- Guard: EFHC deposit processing must not stay as a raw button on admin
  index;
    it needs its own workflow page with input, confirmation and result
  surface.
- Guard: referral manual actions must show effect preview before
  confirmation.
- Guard: referral reassign must require an explicit operator reason.


## 2026-04-08 — deposit status wave 4
- Guard: Mini App deposit must not end at sendTransaction; user must see
  current intent status and next step.
- Guard: last active deposit intent should be re-openable from the modal
  without guessing by balance only.
- Guard: while deposit intent is active (`PENDING` or `SENT`), UI should
  not invite duplicate intent creation.


## 2026-04-08 — external shop prep wave 5
- Guard: external `browser-shop` must be described honestly as MVP
  storefront until the dedicated release-grade block is closed.
- Guard: browser-shop intent flow should support repeat entry and must
  not invite duplicate active intents.
- Guard: release-grade external shop requires separate route/UX/SSOT
  proof, not only a visually working page.


## 2026-04-08 — external shop release wave 6
- Guard: describe browser-shop architecture precisely — shared
  backend/admin truth with separate user-facing surfaces, but not two
  independent frontend applications.
- Guard: payment details block must explicitly warn against mismatched
  wallet / memo / amount changes.
- Guard: terminal storefront states should expose a visible return path,
  not leave the user at a dead end.


## 2026-04-08 — shopfront access module wave 7
- Guard: external shop page should open as a separate internet page, but
  access must come from Telegram through a short-lived signed key, not
  as an open anonymous checkout URL.
- Guard: separate user-facing modules are allowed, but backend/admin
  economic truth must remain shared.
- Guard: a dedicated storefront namespace (`/shopfront/*`) is safer and
  clearer than keeping all browser-storefront routes mixed into a
  generic hub-only surface.


## 2026-04-08 — storefront wallet preload wave 8
- Guard: after Telegram-authenticated storefront entry, bootstrap should
  preload bound wallets from the shared backend truth-layer.
- Guard: storefront may show wallet state, but must not invent a
  separate wallet source of truth.
- Guard: active wallet and linked wallets should be visible immediately
  after access, not hidden behind a later manual fetch guess.


## 2026-04-08 — web portal future entry wave 9
- Guard: the external page should already look like a portal surface,
  not only a narrow shop widget, if it is intended to become the future
  full web entry.
- Guard: future full web-game entry must be exposed honestly as planned,
  not as already enabled.
- Guard: portal evolution must preserve the shared
  backend/economy/wallet truth-layer.


## 2026-04-08 — independent user id optional track
- Guard: independent `user_id` is not a mandatory immediate change if
  the site still logs in only through Telegram external binding.
- Guard: keep this as an optional autonomy track unless the product
  wants multi-auth or survival without Telegram login.
- Guard: do not confuse future autonomy planning with a current
  must-fix.


## 2026-04-08 — web profile wave 10
- Guard: separate web profile is allowed as a user-facing surface as
  long as it remains tied to the same Telegram-authenticated backend
  truth-layer.
- Guard: web profile may show wallets and purchases, but must not create
  a separate account reality.
- Guard: signed Telegram access key remains the identity bridge for the
  web profile.


## 2026-04-08 — web portal visual wave 11
- Guard: visual polish may improve the external portal perception, but
  must not fake missing logic or readiness.
- Guard: entry, portal and profile should look like one product family.
- Guard: do not rewrite access/truth layers under the pretext of visual
  work.


## 2026-04-08 — frontend stitching wave 13
- Guard: portal and web profile must cross-link clearly so they stop
  feeling like hidden parallel routes.
- Guard: route ownership must be explained directly in UI, not only
  implied by code structure.
- Guard: stitching user-flow is a structural repair, not a cosmetic one.

## 2026-04-08 portal/profile localization drift wave

- External portal surfaces must use `useT()` and locale dictionaries
  instead of direct hardcoded wording.
- Sandbox/donor code may be inspected, but portal/frontend waves must
  not blindly transplant external code into HEAD.

## 2026-04-08 admin module-state truth wave

- Admin surfaces that are helper or draft must say so visually;
  otherwise they create a false-ready operator illusion.
- Sandbox must remain a donor/reference layer; importing external
  admin/shop patterns blindly into HEAD is prohibited.

## 2026-04-08 sandbox donor primitives wave

- Sandbox is most useful as a donor of reusable surface primitives (hero
  sections, badge grouping, page rhythm), not as a source of blind
  application imports.
- Shared portal/profile/storefront visual grammar should be extracted
  into EFHC-native components before any future broad web/admin
  redesign.

## 2026-04-08 admin foundation donor stage

- For the upcoming full admin-panel work, sandbox donors are valuable
  mainly for shell hierarchy, KPI cards and data-heavy admin
  composition.
- Full foreign dashboard stacks must not be transplanted blindly; EFHC
  needs its own admin shell primitives first.

## 2026-04-08 admin home grouping wave

- A future full admin panel should not stay a flat list of modules; it
  needs grouped finance / people / system sections and KPI-first
  overview surfaces.
- Horizon-style dashboard composition and Refine-style resource grouping
  can be translated into EFHC-native primitives without importing
  foreign stacks.

## 2026-04-08 admin financial data blocks wave

- A future full admin panel must spread its shell into financial
  operator pages, not stay concentrated only on admin home.
- Bank and withdrawals are the first priority pages for KPI/data-block
  hardening because they are sensitive and statistics-heavy.

- 2026-04-08 — admin panel surfaces wave 19: users/reports/logs aligned
  with new dashboard shell; next expansion block 631-640 planned from
  sandbox donor audit.

- 2026-04-08 — admin panel expansion wave 20: reusable admin shells and
  segmented dashboard grammar introduced for next-stage
  settings/statistics growth.

- 2026-04-08 — admin/shop usability wave 21: reusable admin shells
  expanded and browser shop moved to searchable/filterable product-card
  workflow.

- 2026-04-08 — admin/shop usability wave 22: reports analytics slice
  improved, admin shop clarified, browser shop moved to
  searchable/filterable product-card flow.

- 2026-04-08 — admin shop editor wave 23: product-card selection,
  dual-price editor shell, visibility control and preview stage
  introduced.

- 2026-04-08 — admin shop editor wave 24: catalog selection, dual-price
  editor and preview stage added through admin panel.

- 2026-04-08 — admin operator tails wave 25: stats, emission, correction
  and logs surfaces strengthened after explicit chat-tail audit.

## 2026-04-09 — admin shop status inventory wave 29

- Admin shop must expose explicit item-status control instead of forcing
  every operator action through full content upsert.
- Archive semantics for shop cards must map to `draft` status, not fake
  deletion or silent disappearance of rows.
- Inventory-heavy admin surfaces need status counts, filters and
  ordering, otherwise operator control degrades into blind scrolling.

- 2026-04-09 — log healing wave: removed stale shop alias, fixed admin
  shop idempotency drift, restored browser-shop MVP lock texts, fixed
  admin TSX blockers.

- 2026-04-09 — Healer case: chronic Next.js downgrade drift. Rule: no
  downgrade below 14.2.35 in frontend package.json/package-lock; guard
  test added.

## 2026-04-11 — work pass residual CI tail
- Residual CI tails must be treated as the same active work pass when the
  user has not approved a new range.
- Generated seam types are part of the runtime contract; fix the
  generator together with the generated file.
- Alembic 0001 must avoid duplicate model-import pressure once
  `app.models` has already preloaded ORM modules.

## 2026-04-11 — work pass compatibility/doc-sync tail
- Legacy-compatible watcher parsing may need a guarded fallback path
  even after stricter envelope parsing is introduced.
- Route freeze and migration-count docs must be regenerated whenever
  SSOT counts change; manual stale numbers are a recurring drift class.

## 2026-04-11 — work pass logo canon and audit metadata tail
- Canon logo refresh must always start from the exact approved SVG and
  then regenerate all runtime PNG tiers from that source, not from
  previous PNG derivatives.
- Route freeze audit docs must keep an explicit status note and
  non-empty metadata fields or the audit-of-audits guard starts failing.

## 2026-04-11 — work pass 36-canon and line72 continuation
- Once the user explicitly approves a disputed canon value, stale
  hard-coded guards must be synchronized immediately; keeping them as
  historical disagreement is no longer valid.
- Archive-diff verification is the correct way to prove whether a pass
  contained silent removal; assumptions are not enough.

## 2026-04-11 — work pass watcher/shop compat and line72 scope tail
- Compatibility bridges must preserve older monkeypatched helper
  signatures when architecture/runtime tests still exercise them;
  tightening wrappers without that fallback creates false
  `pending_manual` regressions.
- Frontend is not globally exempt from line72: pages/components/styles
  are excluded, but `frontend/src/features/**`, hooks, lib and generated
  seams still count.

## 2026-04-11 — work pass glossary and transport-env tail
- Runtime helpers that read env-like settings for watcher transport must
  support both real environment variables and monkeypatched runtime
  settings, otherwise architecture tests and fallback runtimes diverge.
- Glossary expansion must be approval-driven: add only explicitly
  approved terms and preserve English terms with Russian duplicates in
  parentheses.

## 2026-04-11 — work pass line72 front-slice tail
- Once pages/components are excluded from line72, the real residual
  frontend burden moves into `frontend/src/features/**`; this must be
  treated as active scope, not assumed excluded.
- Small UI prop drifts like unsupported button-size props can surface
  only after earlier type blockers are removed; they still belong to the
  same active verification cycle.

- 2026-04-11 — Process/Continuity: glossary meaning drift on core cycle
  terms fixed by syncing the live terms to exact user definitions
  instead of assistant paraphrase.

- 2026-04-11 — Verification tail: active line72 residual moved into
  backend/ops/exchange leftovers and was treated as the same 850
  continuity defect family.

- 2026-04-11 — Process/Tests: test-layer edits require a separate
  iteration and 5 clarifying questions per target test before any
  modification.

- 2026-04-11 — Process/Tests: test-setup compatibility fixes are allowed
  without separate iteration when the test purpose is preserved; only
  logic-changing test rewrites require 5 questions first.

- 2026-04-11 — Frontend typing drift: `TaskCatalogItem` in `tasks.tsx`
  lagged behind backend `TaskOut` and missed `id`.

- 2026-04-11 — Frontend typing drift: local `MyTaskItem` in `tasks.tsx`
  lagged behind actual optional usage and needed `next_available_at`.

- 2026-04-11 — Verification tail: fresh CI narrowed to import-order
  drift across backend/ops/tests and watcher import hygiene.

- 2026-04-11 — Regression hygiene: import-order cleanup must preserve
  watcher compatibility markers (`_RE_INTENT`, `_CREDIT_ORIG`) when
  tests and canon docs assert their presence.

- 2026-04-11 — Source-marker canon: compatibility aliases that are
  asserted by tests must remain as literal markers in the source, not
  only as equivalent runtime imports.

## 2026-04-11 — work pass consolidated system errors from logs and cycle
   history
- System error family: reconciliation guard drift. Observed symptoms
  across 850: swapped `asset_guard` / `amount_guard` reasons,
  amount-guard regression and use-before-def around the exact-amount
  confirm path. Healed by restoring deterministic guard mapping and
  keeping confirm-path reasons aligned with the real failing guard.
- System error family: watcher compatibility drift. Observed symptoms
  across 850: old `_confirm_payment_intent` monkeypatch signatures
  breaking, USDT transport/env fallback drift, legacy substring payload
  parsing tails, source-marker loss of `_RE_INTENT`, removal of
  `_CREDIT_ORIG`, and false `pending_manual` outcomes. Healed by
  preserving compatibility bridges, runtime settings fallback, literal
  source markers and stable confirm-path wiring.
- System error family: generated seam / local type drift. Observed
  symptoms across 850: `SummaryItem[]` alias mismatch, admin bank field
  drift (`efhc_balance` vs `efhc_main`), missing `id`, missing
  `next_available_at`, missing `formatD8ToHuman`, category-pills
  contract drift, unsupported `Button` prop drift. Healed by
  synchronizing local frontend types and generated seams to
  backend/source contracts without changing runtime intent.
- System error family: line72 residual cleanup wave. Observed symptoms
  across 850: repeated max-line-length failures moving between backend,
  ops, exchange, admin pages and `frontend/src/features/**`. Healed
  through repeated targeted reduction passes while honestly keeping
  work pass open until fresh GitHub CI proof.
- System error family: import-order / hygiene drift. Observed symptoms
  across 850: `ruff I001`, `E402`, `F401`, `F821` across backend, ops
  and tests, plus a regression where lint cleanup removed canon
  compatibility aliases. Healed by focused import normalization and by
  treating watcher aliases as canon markers, not disposable lint noise.
- System error family: test setup / fixture compatibility tails.
  Observed symptoms across 850: `:extra::jsonb` SQL syntax tail in test
  setup and process confusion around what kinds of test edits require
  separate iteration. Healed by switching to `CAST(:extra AS JSONB)`
  without changing test purpose and by clarifying AI rules: only
  logic-changing test rewrites require the 5-question iteration.
- System error family: doc-sync / SSOT drift. Observed symptoms across
  850: stale 35-table canon, stale route inventory freeze, stale
  migration counts, missing status-note metadata, glossary gaps and
  process-term meaning drift. Healed by moving to the approved 36-table
  canon, rebuilding route/migration inventories, fixing audit metadata
  and writing exact user-approved glossary/process definitions.
- System error family: asset / visual canon drift. Observed symptoms
  across 850: runtime PNG logos diverged from the approved EFHC SVG
  source and splash/logo surface carried minor visual defects. Healed by
  fixing a single approved SVG canon source, rebuilding PNG tiers from
  it and refreshing runtime logo references.
- System error family: archive / process hygiene drift. Observed
  symptoms across 850: suspicion of silent deletions, accidental
  inclusion of nested `efhc.zip` in a release archive, and over-broad
  test-edit restrictions that later required refinement. Healed by
  archive-diff verification, clean FLAT ZIP rebuild and clearer AI-layer
  boundaries.

- 2026-04-11 — work pass reached sterile closure on fresh GitHub CI: all
  tracked gate steps passed with `exit=0`; no new disease family
  remained open in this cycle.

- 2026-04-11 — Post-850 audit phase: the next disease family is no
  longer CI instability but release-truth gaps in withdraw proof
  semantics, hub/browser-shop E2E closure, wallet/deposit UX unification
  and helper/draft maturity masking.

- 2026-04-11 — Post-850 implementation canon: for withdraw in the
  current release-hardening line, the decisive proof is the wallet Send
  action on bot-embedded requisites; requiring full chain-finality proof
  at admin approve would mis-model operator reality.

- 2026-04-11 — Audit wording correction: a module can be weak at the
  current UI surface while its backend domain is already strong; admin
  tasks is exactly this kind of split-strength case.

- 2026-04-11 — Withdraw hardening implementation: operator wallet-send
  proof can be captured as explicit metadata (`payout_ref`, provider,
  sender wallet, send-confirmed flag) without forcing `tx_hash` to be
  the only truth signal.

- 2026-04-11 — Money-Center UX healing starts when the financial journey
  is made explicit in one place: wallet readiness first, top-up second,
  operational return path third.

- 2026-04-11 v166_65: Money-Center UX fragmentation was reduced by
  linking wallet, balances, latest withdraw status and history in one
  profile surface; admin tasks operator paralysis was reduced by
  replacing helper-only shell with submissions moderation surface.

- 2026-04-11 v166_66: Money-Center continuity was deepened on
  `/withdraw`; moderation safety improved by replacing bare proof links
  with an expanded proof card for each submission.

- 2026-04-11 v166_67: closed-loop Money-Center healing added a
  deterministic return from `/withdraw` back into profile financial
  context, removing a trust-breaking dead-end after success actions.

- 2026-04-11 v166_68: moderation black-box risk reduced by storing
  moderator notes, adding fallback templates and exposing a global
  templates truth-layer for admin-managed responses.

- 2026-04-16 v166_69_70: work pass advanced — added
  `/hub/shop-truth`, surfaced active-intent resume semantics, and
  removed blind storefront entry behaviour from Hub/browser-shop.


## BROWSER_SHOP_PENDING_BADGE_OVERCONFIDENCE
- Symptom: storefront showed a raw pending-like status without
  explaining whether payment was seen, waiting for network, manual
  review or terminal retry state.
- Fix: backend `flow_truth` now exposes lifework pass stage, terminal
  marker, next step and watcher/order evidence; storefront and
  web-profile render it.


- 2026-04-16 v166_73_74: Web-profile account-center drift was reduced by
  surfacing recent intent history and Telegram withdraw shortcuts;
  DepositModal duplicate-state risk was reduced by converting it into a
  thin launcher over the existing Hub/browser-shop truth-path.

- 2026-04-16 — CI repair family: fresh GitHub logs exposed four linked
  tails on the same HEAD — undefined `settings` in `hub_routes.py`,
  generated seam drift for `PaymentIntentStatusResponse.flow_truth`,
  stale migration-count docs below the 37-table canon, and banned legacy
  rank substrings leaking into active memory docs. Healed by targeted
  code/doc synchronization without changing the approved product
  direction.

## 2026-04-16 release-truth and generated-seam drift

- После truth-layer и generated seam wave легко возникает вторичный
  drift: backend truth уже расширен, а admin classification tests,
  generated validators и docs-count заголовки остаются на старом слое.
- Лечим пакетом в том же цикле: route-canon tests, generated validator
  order, SSOT count headings, line72 copy tails и release-truth labels
  для helper/internal surfaces.

## 2026-04-16 — work pass QA and glossary sync
- Added the release-hardening QA matrix and operator checklist.
- Promoted the current release-truth labels and money-path roles into
  AI-layer canon to reduce semantic drift.

- 2026-04-16 — Forbidden-substring drift in active AI docs can trigger
  canon guards through innocent English words; preferred treatment is
  wording repair, not broad test weakening.


- 2026-04-16 — work pass: fixed frontend validator declaration-order
  drift and materialized forbidden words / narrow exceptions policy into
  SSOT to stop semantic drift in AI/docs/runtime wording layers.
- 2026-04-16 v166_86 work pass web-profile hardening and CI fix

- 2026-04-16: work pass follow-up — keep ProfileModal compact; do
  not grow a second heavy cabinet. Shared copy-layer must land before
  broad UI string migration.
- 2026-04-16 — launcher entry drift: Hub / ProfileModal / Web-Profile /
  shop-entry risked diverging into separate top-up behaviors; cured by
  one shared launcher helper and one truth-path.

- 2026-04-16 v166_91_92: fixed cycle-control assertions for
  `/hub/shop-truth` visibility and line72 drift after launcher
  unification; added governance/UI consistency control layer for
  maturity labels.

- 2026-04-16 — Control-layer healer note: post-gate AI/docs drift after
  880 is now treated as a first-class disease; work pass refreshed
  AI docs and synced the strategic Telegram-first / one-profile /
  external-sector frame into the main control layer.


## 2026-04-16 — v166_97_98
- Added governance note: multilingual user-facing moderation comments
  remain a Tier 1 finishing gap.

- 2026-04-16 / work pass: multilingual moderation path moved to
  locale-aware `system_templates` with backend language selection;
  Russian-only backend moderation prefixes are no longer canonical.

## 2026-04-25 localization scope compression guard

- Defect: AI attempted to describe work pass as RU/EN-focused while the
  user assigned bot localization work that must cover all 13 languages.
- Treatment: AI-layer and language canon now require full 13-language
  coverage for bot translation/localization passes unless the user
  explicitly narrows the scope.
- Prevention: any future RU/EN-only closure of a localization work pass is
  process drift and must be recorded instead of being treated as done.
- Related work pass.

## 2026-04-25 — v167_75 notification/template and frontend copy tails

- work pass treated notification/template fallback tails by localizing
  shop order Telegram notifications and withdraw outcome promo fallback
  buckets across all 13 active EFHC Bot languages.
- work pass inventoried frontend hardcoded string candidates and split
  them into admin/operator, player-facing and shared groups for work pass.
- Guards: `ops/i18n/audit_notification_template_repair.py` and
  `ops/i18n/audit_frontend_hardcoded_strings.py`.

## 2026-04-25 — v167_76 frontend hardcoded repair pass 1

- work pass treated the first money-path hardcoded-copy tail.
- Withdraw, Exchange, ExchangePanel, Panels and PanelsList received
  locale-backed copy for the repaired strings.
- New keys were added across all 13 active locale bundles.
- Remaining frontend hardcoded candidates stay in the work pass queue.

## 2026-04-25 — v167_77 localization guards and shortcut repair

- work pass repaired another player-facing shortcut copy slice.
- work pass added placeholder parity guard.
- work pass added identical-to-English review guard and measured an
  honest
  remaining baseline.
- work pass documented long-language layout risk without claiming
  visual
  release readiness.

## Healer cards — v167_78 language proof and extension

### HEAL-L10N-1015 — static proof confused with browser proof

- Severity: medium.
- Symptom: reports can sound like visual proof even when only code and
  locale checks were run.
- Treatment: work pass now explains static proof versus browser proof
  and lists the screens for later human browser checking.
- Prevention: never claim browser proof without a human visual pass.

### HEAL-L10N-1022 — false closure risk at range boundary

- Severity: high.
- Symptom: localization range could be closed while a measured language
  tail still exists.
- Treatment: work pass closes the proof range but extends language work
  to 1040 without claiming final release readiness.
- Prevention: residual language tails must be routed into a bounded next
  range, not hidden.

### HEAL-L10N-1024 — identical-to-English signal too coarse

- Severity: medium.
- Symptom: the guard had a total count and sample but not enough summary
  data for manual repair planning.
- Treatment: work pass adds `by_lang` and `by_prefix` summaries.
- Prevention: future language repair passes must use distribution data
  before editing translations.

- 2026-04-25 — v167_79 — HEAL-ARCH-001-R archive compression
  recurrence treated with explicit deflate rebuild and size check.
- 2026-04-25 — v167_79 — HEAL-L10N-1025 identical-to-English tail
  explanation added and technical allowlist externalized.
- 2026-04-25 — v167_79 — HEAL-ARCH-002 slow unpack / timeout
  risk recorded as systematic release artifact hygiene problem.


### HEAL-L10N-1039 — persistent identical-to-English tail

- category: `localization_guard`
- severity: `P1`
- zone: `yellow`
- card_status: `confirmed`
- treatment_status: `active`
- medical_maturity: `partially_protocolized`
- action_priority: `treat`

**Symptoms**

- Non-English locale keys exist, but values remain identical to English.
- The UI can look structurally complete while still showing fallback
  copy.
- The tail can return after new locale keys are added.

**Treatment**

- Keep `ops/i18n/audit_identical_to_english.js` active.
- Use `ops/i18n/identical_to_english_allowlist.json` only for short
  protocol/product identifiers.
- Repair long user-visible sentences manually by language and screen.

**Verification**

- Re-run the identical-to-English guard after each locale repair.
- Record remaining counts by language and prefix.
- Do not call localization release-ready while unreviewed tails remain.

2026-04-26 follow-up:
- User ordered the residual findings to be reduced from 794 to 0.
- The work pass addendum repaired remaining exact-English values across
  affected non-English locale bundles.
- Local helper result: `identical_findings: 0`.
- The Healer class remains active as a regression guard; any future
  non-zero result is a recurrence.


## HEALER-L10N-ADMIN-RU-ONLY

Severity: high.

Problem:
The assistant previously mixed the user multilingual contour with the
admin/operator contour and treated admin localization as if it belonged
to
mandatory all-locale coverage.

Root cause:
Process drift and insufficient iteration before applying localization
rules.

Treatment:
Admin panel is fixed as Russian operator contour. admin.* in non-ru
locale
is not a blocker. user-facing use of admin.* is a blocker.

Prevention guard:
Admin ru-only guard and no-admin-leak guard must be used in active
release
scope.

## HEALER-L10N-FORBIDDEN-GAMING-CONTOUR

Severity: blocker.

Problem:
Old removed-domain gaming copy can return through i18n, FAQ, functions,
routes, tests, templates or stale copy.

Root cause:
Legacy residue and unsafe silent normalization of old vocabulary.

Treatment:
Do not replace the old removed contour with another product term without
user approval. If active code/function/route/model/key residue is found,
prepare a deletion risk map and ask the user in Russian.

Prevention guard:
Smart forbidden contour guard checks active release scope and excludes
historical reports, audits, logs, Healer and old work pass records.

## 2026-04-26 — active forbidden contour approval blocker

- `backend/app/core/errors_core.py` contains `ParticipationClosedError`
  with
  `Round is closed.`; replacement requires user approval.

### 2026-04-26 — v167_84 follow-up: active round artifact removal

User approved removal of active `Round / раунд` residue after v167_83.
Treatment applied:
- removed unused `ParticipationClosedError` from active backend errors;
- replaced energy-service technical `rounds` with neutral processing
  `passes / проходы` while preserving stable energy generation;
- repaired active FAQ and panel/referral wording;
- active forbidden-contour guard result: `forbidden_findings: 0`.

Boundary:
- historical reports, audits, Healer records and logs were not
  rewritten;
- suspicious `reward/win/prize` findings remain contextual and require
  Russian iteration if a future pass changes them.


### 2026-04-26 — corrective note: game != gambling

- The assistant over-cleaned the active FAQ by treating `игровой` as if
  it
  were automatically forbidden.
- Correct canon: EFHC Bot may be described as a game / gaming project /
  gameplay.
- Forbidden contour is limited to gambling, loto, draw-prize, tournament
  financial competition, betting and random-win semantics.
- Treatment: restore active FAQ from the previous valid version and keep
  guards focused on the forbidden financial contour instead of the word
  `игровой` itself.
- Prevention: when the assistant sees `игра / игровой`, it must evaluate
  context and ask a Russian iteration if there is any doubt.


### 2026-04-26 — FAQ panel activation drift across all locales

- After the bounded English FAQ correction, a wider all-locale FAQ pass
  confirmed that panel wording must stay on the activation canon in
  every active FAQ language.
- Treatment: normalize section 7 panel wording in active FAQ files and
  in `frontend/src/data/faq/catalogs.ts` so the user sees activation
  wording, not panel purchase/price wording.
- Boundary: suspicious `reward / prize / win` contexts remain
  manual-review territory and must not be auto-rewritten.


- Follow-up 2026-04-26: для language/canon проблем дополнительно
  закреплена граница между игрой и азартным контуром; слово «игровой» не
  должно чиститься автоматически.

- 2026-04-26: work pass — active user-facing canon changed from
  `reward / награда` to `bonus / accrual` logic; `reward` is no longer
  canonical in active FAQ/locale values, while historical documents
  remain untouched.

- Follow-up 2026-04-26: neutral alias transition for legacy `reward*`
  names added; no immediate destructive removal of compatibility names
  is allowed until all paths are verified.

- v167_92 follow-up: public alias tails can be removed only after
  compatibility proof; technical runtime/DB reward names remain under
  transition policy, not blind deletion.


- H-ALIAS-TRACE-1120 — public alias residual cleanup and tasks lock SQL
  repair recorded in `docs/healer/HEALER_CASEBOOK.md`.


## 2026-04-27 ads slot SQL missing FROM + alias cleanup boundary

- Finding: `/ads/slot` had a SQL query selecting task fields without
  `FROM {SCHEMA}.tasks`, which could break ad slot issuance at runtime.
- Treatment: add the missing `FROM` clause and keep canonical response
  field
  `bonus_efhc`.
- Prevention: alias cleanup must include route/runtime sanity checks,
  not only
  text search.
- Boundary: technical `reward*` DB/runtime names are compatibility
  contracts
  until a migration-safe plan exists; do not mass-rename them.


## 2026-04-27 portal English-first drift + reward bridge closeout

- Finding: `ShopEntryPage` still had hardcoded Russian explanatory text
  in an
    active player-facing portal surface, and the active task service
  entrypoint
  name still leaned on legacy `claim_task_reward()`.
- Treatment: switch the active route/service bridge to bonus-first
  naming,
    keep compatibility wrappers for legacy reward names, and replace the
  portal
  hardcoded block with locale keys.
- Prevention: after public alias cleanup, always check route/service
  entrypoint
  names and player-facing portal copy before declaring the contour
  release-ready.


## 2026-04-27 line72 + bandit log-driven release blockers

- Finding: fresh GitHub logs confirmed one `line72` failure class and
  one
  `bandit` finding in `/ads/slot`.
- Treatment: wrap the exact long lines, shorten active guard JSON
  strings and
  replace the raw ads SQL text with ORM `select(Task...)`.
- Prevention: fresh log imports must drive only confirmed blocker
  repair,
  not speculative refactors.


## 2026-04-27 pre-release task schema drift and reward-log table rename

- Finding: the active tasks runtime still depended on helper tables and
    field assumptions that were not promoted into ORM/`0001`, while the
  product
  had not launched yet.
- Treatment: move helper tables into first-class ORM metadata, extend
  `0001`
  sanity for the task contour, rename `task_rewards_log` to
  `task_bonus_log`, and align service SQL with the real `tasks` schema.
- Prevention: before release, any active route/service table must exist
  in
  ORM, `0001`, SSOT table maps and Healer notes at the same time.

- v167_98: closed pre-release task column drift (`reward_bonus_efhc` /
  `reward_amount_efhc` -> `bonus_efhc` / `bonus_amount_efhc`) and fixed
  `TaskSubmission.user_tg_id` CRUD drift before launch.

- admin task duplicated submissions path drift: route used
  `/admin/tasks/tasks/{task_id}/subs` while SSOT/frontend canon expected
  `/admin/tasks/{task_id}/subs`; repaired pre-release in work pass.
- task can_claim paid-flag drift: `/tasks/my/{tg_id}` ignored submission
  `paid` and could show claimability incorrectly; repaired by selecting
  the real paid flag in work pass.

- hidden hub browser-shop helper-route drift: `/hub/browser-shop-*`
  physically existed as compatibility transport routes while the public
  shop/browser contour already moved to `/shopfront/*`; repaired
  pre-release by freezing them as internal helper routes with
  `include_in_schema=False` instead of exposing duplicate public roads.
- task payload reward-echo drift: task/admin service payloads still
  emitted legacy `reward_*` echoes after the schema/runtime became
  bonus-first; repaired in work pass by keeping bonus-first
  outputs and leaving only bounded input compatibility aliases.

- v168_01: tail-zero bonus-first sweep removed remaining active
  `reward*` bridges from task service payloads, schemas and ORM helper
  properties; left only bounded `VerifiedAdEvent.reward_bonus_efhc`
  property alias inside ads provider compatibility layer.


## 2026-04-28 archive reading overload and context drowning risk

- Finding: the EFHC startup reading habit could overload context by
  mixing active AI/canon reading with old logs, old reports, all FAQ
  languages and broad frontend/backend loading.
- Treatment: introduce a dedicated reading optimization layer in
  `docs/AI/`: entrypoint, token budget, topic routes, FAQ policy,
  logs/reports policy, synaptic links and fast manifest.
- Prevention: normal startup reads Start Core first, then only the
  thematic route required by the task. Historical and heavy layers are
  loaded only by topic, regression, release QA or explicit full audit.
- Boundary: the optimization changes reading order only; it does not
  delete FAQ languages, weaken localization scope or replace direct
  evidence from files.

## 2026-04-28 — Healer case: line72 scope overload

Risk:
A request to normalize all documents to line72 can become too large
for one safe pass and may accidentally touch frontend or FAQ layers.

Treatment:
Split line72 cleanup into controlled cycles. Exclude `frontend/` and
FAQ files when the user gives that scope. Preserve all archive files
and build the next ZIP by copying the full previous HEAD plus verified
document changes only.

Status:
Applied in work pass.

## Case: road-audit PDF must not trigger unsafe deletion

Risk:
- an external route-road audit can correctly identify drift classes but
  still refer to an older HEAD.

Treatment:
- convert the audit into an audit-of-audit;
- create a matrix and proof cycles;
- verify every road against the current HEAD before code deletion;
- mark helper or legacy roads before any removal.

Status:
- treatment opened in work pass.

## 2026-05-29 — Operator Kernel acceleration case

Disease: repeated over-reading, route drift and procedural-order mistakes
when working with a large EFHC Bot archive.

Treatment: work pass adds Operator Kernel. It builds file maps, route
indexes, context capsules and patch plans. It also encodes the CI
manual-control boundary so the assistant does not silently modify CI files
while trying to repair logs.

Status: mitigated by `ops/operator_kernel/` and architecture guards.

## Healer card — CI-1337 optional test helper collection failure

Disease: pytest collection fails because a core architecture test imports an
optional helper package (`freezegun`) that is not guaranteed in the active CI
bootstrap.

Treatment: remove the optional helper from the test when the invariant can be
proved with the Python standard library. Keep CI/workflow files under manual
chat-approved control.

Case: `logs_71060357686.zip`, work pass, archive v169_16.


## work pass — CI logs 71459043999

Disease: stale guard plus generated cache contamination.

Cause: old work pass guard expected pre-migration frontend versions and the
Operator Kernel cache indexed historical original-source paths.

Repair: update the guard to active canon, remove generated frontend
artifact, avoid legacy-token cache entries and keep CI manual-control.

Status: repaired in v169_17.

## 2026-05-29 — work pass green CI checkpoint

Symptom: no failure. User supplied green CI logs `logs_71469302879.zip`.

Evidence: Gate summary confirmed all gate steps passed.

Action: no CI repair. Work returned to planned Shop Admin cycle.

Protection: CI/workflow file was not changed. Manual-control CI boundary
remains active.


## Healer case — work pass dependency/config drift

Symptoms: dev/test dependency mismatch, production webhook secret not enforced, Operator Kernel YAML configs acting as declarations only.

Treatment: sync dev/test pytest versions, add production webhook secret validator, add stdlib config loader and guards.


## work pass — Admin Tasks route-diagnostics surface healed

Symptom: `/admin/tasks` still opened with route diagnostics and helper wording
before the operator catalog.

Treatment: add `AdminTasksCatalogUxPanel`, connect it to the page, keep
approve/reject moderation and move normal operator UX above diagnostics.

Status: healed in v169_20.

## work pass — Admin Tasks trace boundary healed

Symptom: Admin Tasks had moderation visibility but no clear boundary for
execution traces after approval and task_bonus ledger events.

Treatment: add `AdminTasksExecutionTracePanel`, connect it to admin logs and
show only sanitized `task_bonus` traces.

Status: healed in v169_21. Public Tasks execution history remains forbidden.

## work pass — Admin Reports visual pass

Disease: Reports page degradation into static counters or route diagnostics.

Treatment:

- add `AdminReportsVisualDashboardPanel`;
- keep `/admin/reports/overview` as read-only source;
- remove top route diagnostics from normal operator surface;
- add filter / zoom / clickable point patterns;
- use Sandbox as donor-source without copying dependencies.

Recurrence guard:
`tests/architecture/test_admin_reports_visual_dashboard.py`.

## work pass — Reports export/download boundary

Symptom prevented: reports export drifting into raw payload dumps,
backend mutations or workflow actions.

Treatment: add a sanitized client-side export panel, document the
boundary and guard that `/admin/reports` stays read-only.

## 2026-05-31 — work pass Diagnostics boundary

Symptom prevented: diagnostics leaking into normal operator or public screens.

Healing: `/admin/diagnostics` gets a technical-only boundary panel and public UI
interactivity is planned separately.

## HEALER-work-pass-PUBLIC-UI-SANDBOX-BOUNDARY

Symptom: public UI interactivity could accidentally import foreign framework
runtime layers from donor templates.

Treatment: work pass records donor-source usage as pattern adoption only.
Nuxt, Vue, Solid, Vanilla renderer and jQuery runtime layers are not imported.


## HEALER NOTE — work pass public/admin boundary

Symptom prevented: public UI starts reusing admin diagnostics or raw payload
patterns.

Treatment: `PublicEnergyInteractiveOverview` is public-only and has guard
coverage. Admin route labels, diagnostics strips and raw payloads remain
forbidden on public Energy.


## work pass — Public Panels preview guard

Symptom prevented: public Panels screen becomes static or leaks Admin/Diagnostics
concepts. Guard: `test_public_panels_activation_preview.py`.


## HEALER card work pass
Public Exchange preview must not reintroduce reverse exchange, raw payload, endpoint labels or admin diagnostics.

## 2026-05-31 — work pass public engagement

Healer note: public engagement must not reintroduce hidden task execution
history or admin diagnostics into public UI.

## 2026-05-31 — work pass public profile trust boundary

Symptom: Public UI interactivity wave needed a final trust layer for Profile /
Wallet / History without exposing admin internals.

Treatment: Added `PublicProfileTrustLayer` as a public-only Web-Profile summary
with explicit no-admin/no-raw-payload markers and architecture guard.

Status: guarded in `test_public_profile_wallet_history_trust.py`.

## 2026-05-31 — work pass ZIP extraction healer card

Symptom: Linux `unzip` fails before full extraction because two original-source
markdown filenames are too long after CP437/UTF-8 mojibake expansion.

Treatment: rename only the two problematic filenames to ASCII transliteration
and keep the exact 15-file original-source retention guard.

Status: guarded by `test_document_retention_guard.py` and
`test_zip_encoding_wallets_crud_hotfix.py`.

## 2026-05-31 — work pass wallets CRUD import healer card

Symptom: active CRUD code imports `WalletBinding` through the legacy
`wallet_models` compatibility shim.

Treatment: import from canonical `app.models.wallets_models`.

## 2026-05-31 — Admin UI Kit adoption proof pass

Symptom: shared Admin UI Kit could be treated as a foundation file without
visible adoption proof.

Treatment: work pass adds an Admin-home proof panel and guard to show the
active adoption chain across Bank, Users, Withdrawals, Shop, Tasks, Reports
and Diagnostics.

Status: treated in v169_32.

## work pass — Admin screenshot QA preparation

Prevents the recurring defect of claiming visual readiness from code-only
changes. Screenshot proof must remain manual/evidence-based.
## work pass — Admin route-map drift prevention

Symptom: Admin docs can drift after multiple UI cycles.
Treatment: `ADMIN_DOCS_SSOT_ROUTE_MAP.md` links every Admin surface
to page/component/backend/canon anchors and has an architecture guard.


## repair pass alignment note — HEAL-0055 deposit cache

- cycle: `1404`
- version: `v169_86`
- status: `alignment_updated`
- user_decision: deposit duplicate protection must not use process-local `_ttl_seen`/memory TTL cache as source of truth.
- required_source_of_truth: `efhc_admin.idempotency_key` with durable/long-retention deposit/payment records.
- current_code_check: active runtime `_ttl_seen` was not found in `backend/app/core/system_locks.py`; DB-backed `_acquire_idempotency_ttl_lock()` uses `IdempotencyKey`.
- residual_risk: long-retention deposit/payment idempotency policy still needs explicit proof/guard in repair pass.



### v169_88 / repair pass repair note

HEAL-0040 repaired at code/schema-contract level: `PaymentIntent.package_id` is nullable for custom/package-less intents, package-based paths keep real `package_id`, package-less SQL paths store `NULL`, and fake package sentinel `0` is forbidden. Guard: `tests/architecture/test_heal0040_0044_payment_schema_contract.py`.

HEAL-0044 repaired at migration/schema-proof level: `EfhcTransferLog.direction` remains `String(24)`, Alembic 0001 widens existing live DB columns below `varchar(24)`, and sanity fails if the live width is still below 24.

## 2026-06-04 — v169.90 HEAL-0018 repair pass runtime repair

- `HEAL-0018`: repair pass map remains the evidence base.
- repair pass repaired the first core money-service boundary:
  `transactions_service._tx_context()` no longer uses hidden `begin_nested()`
  fallback.
- `exchange_service.exchange_kwh_to_efhc()` now closes read-only preflight
  autobegin before entering transactions_service.
- Residual: withdraw create/hold/mark atomicity remains `HEAL-0024` / repair pass.

## v169.91 — HEAL-0024 primary withdraw atomicity

repair pass repaired the primary withdraw create/hold/mark race by moving request row creation, no-commit balance hold, transfer audit meta and `hold_done=TRUE` into one service-owned transaction boundary. Operator Kernel refresh/version validation was added as a controlled optimization.


## v169.92 — HEAL-0055 deposit DB idempotency + Kernel Start Core

Status: applied in repair pass.

Treatment:

- `process_efhc_deposit()` now records long-retention deposit idempotency in `efhc_admin.idempotency_key`;
- deposit scope is `deposit:efhc`;
- deposit records use `expires_at=NULL`;
- replay returns stored `response_payload_json`;
- Operator Kernel became mandatory Start Core navigation and root `KERNEL.md` was added.

Regression guard: `tests/architecture/test_heal0055_deposit_idempotency_kernel_start_core.py`.

## HEAL-0056 — FSM states.py single responsibility split

Status: treated in the FSM split range-closure repair pass.

Symptom: `backend/app/bot/states.py` exceeded 50 KB and mixed DTO, backend,
manager, singleton factory and decorators.

Treatment: split implementation into `backend/app/bot/fsm/` modules and keep
`backend/app/bot/states.py` as compatibility facade.

Guard: `tests/architecture/test_fsm_states_split_facade.py`.

## Economic risk surgical repair

- Finding repaired: all-bonus spend idempotency retry/read-through drift.
- Finding repaired: admin manual debit nonexistent kwargs drift.
- Guard added: `tests/architecture/test_economic_risk_guards.py`.
- Remaining economic audit findings move to later planned stages.

## Economic risk panel atomicity repair

- Finding repaired: panel activation spend and panel row creation were split
  across transactions.
- Treatment: added nocommit BONUS→MAIN spend helper and made
  `panels_service.py` own one atomic transaction for debit plus panel creation.
- Additional guard: activation replay payload reads both `:main` and `:bonus`
  spend logs to protect all-bonus panel purchases.
- Guard updated: `tests/architecture/test_economic_risk_guards.py`.


## HEAL — economic risk withdraw/exchange atomicity repair

Status: confirmed / treated.

Symptoms:

- withdraw cancel/reject committed final status separately from refund;
- exchange helpers checked idempotency before user row lock.

Treatment:

- added `credit_user_from_bank_nocommit`;
- moved withdraw cancel/reject refund into one transaction;
- moved exchange idempotency read-through inside lock/retry loop;
- added exchange preflight/autobegin rollback guard;
- protected by `tests/architecture/test_economic_risk_guards.py`.

Forbidden regression:

- final withdraw status without atomic refund path;
- exchange idempotency precheck before `FOR UPDATE`;
- committing refund helper inside cancel/reject split flow.


## HEAL — economic cleanup and reconciliation hardening

Status: confirmed / treated in work pass `1425`.

Symptoms:

- rejected zero-amount exchange was recorded as a financial debit log;
- direct exchange helpers needed an explicit guard for direct-call transaction
  safety;
- withdraw service had a local transaction-context copy;
- strict kWh check trusted stored `available_kwh`;
- bonus credit accepted `meta` without persisting it to transfer log metadata.

Treatment:

- rejected zero-amount exchange now returns audit data without writing a false
  financial transfer log;
- exchange direct-call rollback guard is protected;
- withdraw imports canonical `_tx_context` from `transactions_service.py`;
- strict kWh check uses `total_generated_kwh - exchanged_kwh_total`;
- bonus credit passes `meta=meta` into `_run_idempotent`;
- `INV-08` reconciliation hardening is documented and guarded.

Guard: `tests/architecture/test_economic_risk_guards.py`.

## HEAL — panel dead transaction-context cleanup

Status: confirmed / treated in work pass `1426`.

Symptoms:

- `panels_service.py` contained an unused local `_tx_context` helper;
- the helper used `db.begin_nested()`, the forbidden HEAL-0018 savepoint
  fallback pattern;
- current runtime did not call it, but future work could accidentally reuse it.

Treatment:

- remove the local helper;
- keep panel activation on canonical `bank._tx_context(db)`;
- add `test_panels_service_no_local_tx_context`.

Non-claims:

- this cleanup satisfies the economic re-audit condition locally;
- it does not claim GitHub CI green or general release-ready status.

## HEAL — CI log repair after economic cleanup

Status: confirmed / treated in work pass `1427`.

Archive: `EFHC_Bot_v170_02_cycle_1427_ci_log_repair.zip`.

Symptoms:

- ruff `I001` import ordering failure in `withdraw_service.py`;
- line72 failures in `panels_service.py`;
- degraded `_main_` token failures in new economic helper names;
- Healer atlas schema failures in `atlas.json`.

Treatment:

- sorted imports without changing withdraw economics;
- wrapped long panel lines;
- renamed new helpers to dunder-safe `then__main__` spelling;
- completed Healer card fields and fixed invalid action priority enum.

Prevention:

- keep line72, dunder integrity and Healer schema guards active;
- do not hide log failures by disabling tests;
- keep EFHC economic behavior unchanged during CI hygiene repairs.

## HEAL — security audit truth reconciliation

Status: confirmed / planning-treated in work pass `1428`.

Symptoms:

- supplied P0 security audit carries a `v170.01` title but states that
  `v170.02` was the actually inspected archive;
- wallet binding canon was ambiguous between proof-based and legacy contours;
- production entrypoint truth was ambiguous between `main.py` and compat
  `create_app`;
- P0 blockers could be hidden by treating the audit as only a label mismatch.

Treatment:

- archive the audit as security evidence;
- set `v170.02` as factual HEAD for the security repair line;
- answer Q1-Q3 in Q&A and security canon documents;
- plan follow-up work passes for P0 blockers, P2 cleanup and regression hardening;
- add a documentation guard so the P0 release-blocked verdict stays visible.

Prevention:

- do not claim P0 fixed from a planning/reconciliation pass;
- do not let address-only wallet binding become verified ownership;
- do not leave cron control-plane protection on a repo-known default secret.

## HEAL-0104 — P0 security wallet proof and cron secret repair

- Cycle: security P0 repair pass.
- Severity: P0.
- Status: locally repaired; repeat security audit required before release-ready.
- Symptoms: address-only wallet binding; repository-known cron secret.
- Treatment: TonConnect proof is mandatory for `/wallets/connect`; wallet gates
  require verified bindings; cron secret has no working default and prod/stage
  fail fast on unsafe values.
- Guard: `tests/architecture/test_security_p0_repair_guards.py`.

## HEAL-0104 — Security P2 replay / OPSEC / legacy-header repair

- Severity: P2.
- Zone: security replay / OPSEC / frontend-backend boundary.
- Treatment: strict Telegram `auth_date`, expanded secrets redaction aliases,
  removal of legacy frontend/admin headers from runtime and CORS layers.
- Prevention: keep `test_security_p2_replay_opsec_headers.py` active.


## HEAL-0107 — security regression hardening guard layer

- Category: security_regression_control
- Severity: P1
- Zone: red_release_blocked / regression hardening
- First seen: 2026-06-04
- Last seen: 2026-06-04
- Status: locally treated; repeat security audit pending.
- Symptom: after P0/P2 security repair, the archive still needed active guards
  for admin backend auth, owner-scoped money routes, prod docs/CORS safety and
  webhook secret-before-dedupe ordering.
- Treatment: the security regression pass added
  `tests/architecture/test_security_regression_hardening.py` and changed
  Telegram webhook order so dedupe registration happens after webhook secret
  validation.
- Forbidden action: do not remove the guard or claim release-ready without
  repeat security audit / CI proof.

## HEAL-0108 — security minor findings repair after v170.08 audit

- Category: security_minor_repair
- Severity: P1
- Zone: security_minor_findings
- First seen: 2026-06-05
- Last seen: 2026-06-05
- Status: locally treated; fresh CI/audit proof pending.
- Symptom: v170.08 repeat security audit found no P0 but left two P1 findings
  and one P2 housekeeping issue: `ADS_TEST_MODE` prod fail-fast, missing
  `/deposit` and `/payment-intents` rate-limit prefixes and real-looking TON
  addresses in `env.prod.example`.
- Treatment: the latest security minor repair added prod/stage fail-fast for `ADS_TEST_MODE`, added
  the missing monetary prefixes and replaced the addresses with placeholders.
- Guard: `tests/architecture/test_security_audit_v170_08_minor_repair.py`.
- Forbidden action: do not re-enable ads test mode in prod/stage or remove
  deposit/payment-intents from monetary middleware defaults.

## v170.18 / step 1442 — OpenAPI contract gate tail

- `F-006` checked-in OpenAPI drift repaired locally by rebuilding snapshot from backend route source.
- Static contract gate added: `tests/architecture/test_openapi_rebuild_strict_contract_gate.py`.
- Guard report: `reports/generated/openapi_strict_contract_gate_v170_18.json` → `status=ok`.
- Live FastAPI `app.openapi()` proof remains unclaimed in local tool environment because `sqlalchemy` is missing.
- Remaining healer tails: `F-007` UI loading/error/empty-state guards, full linkage architecture matrix/reporting and repeat audit.

## Work pass 1445 — CI/log repair and old BNB/source skin cleanup

- HEAL-0111 / CASE-0120 added for `logs_72623328892.zip` repair.
- Root causes: ruff import order, mypy bank typing, stale guards, Kernel marker, line72, route inventory count, Healer schema tail, wallet test isolation and old PNG skin.
- Old source skin removed: `frontend/public/skins/1.png`.
- Active runtime skin remains: `frontend/public/skins/1.webp`.
- No tests were deleted or disabled.

## HEAL — compact WebApp accumulation and checkout return repair

- Work scope: current Browser Shop compact checkout repair.
- Status: locally repaired with controlled browser proof.
- Symptoms: duplicate Energy metrics, numeric ellipsis, narrow six-cell
  navigation, obsolete two-card HUB, manual Browser Shop status state and
  lost checkout context after Web linking.
- Root cause: new public surfaces were accumulated instead of replacing old
  surfaces, while guards protected historical composition.
- Treatment: two-action canonical HUB, Energy without Wallet/Exchange
  duplication, named levels, full-width navigation, React Query checkout
  polling, backend TTL and token/SKU/method return.
- Guards:
  `test_hub_browser_shop_compact_current_release.py`,
  `test_energy_compact_numeric_layout.py` and
  `test_compact_public_visual_alignment.py`.
- Boundary: live Telegram linking and real payments remain unverified.


## HEAL — guarded public function deletion during visual cleanup

- Status: repaired locally in the repeated Browser Shop correction.
- Symptom: the EFHC VIP NFT action was removed from HUB and guards were
  inverted to require the deletion; Energy guards were changed to require
  Wallet/Exchange blocks and to hide canonical level names.
- Root cause: visual simplification was incorrectly treated as authority to
  delete guarded product functions.
- Treatment: restored both HUB actions, removed non-Energy functions from
  Energy, restored current named levels and added cross-release preservation
  guards.
- Audit: `docs/audits/RECENT_GUARD_CONTRADICTION_AUDIT_1562.md`.
- Forbidden action: do not reverse a guarded public function when a test
  conflicts with an interpretation; request a direct user decision.

## HEAL — active public copy and persistent header status

- Symptom: visible public translations could contain internal terms even while
  the legacy whole-corpus copy scan stayed green; VIP disappeared when false.
- Root cause: the guard did not map real public translation-key usage and the
  header rendered statuses conditionally instead of representing state.
- Treatment: active-key copy scanning across all 13 locales and persistent
  Active/VIP badges with state-specific tone.
- Guards: `test_public_ui_active_copy_guard.py` and
  `test_global_header_vip_status_guard.py`.
- Forbidden action: do not hide a guarded status merely because it is false.

## HEAL — UI/query/service linkage drift

- Cycle: `1565`; archive: `v171.41`.
- Symptom: public linkage was mostly normalized, while several Admin
  surfaces still used manual transport/local state and health widgets
  bypassed a typed service/query boundary.
- Treatment: Admin health and wallet actions now use typed services,
  Zod validation and React Query invalidation; the header action geometry
  is stable and VIP remains visible without a crown.
- Guard: `tests/architecture/test_full_ui_backend_linkage_matrix.py`.
- Evidence: `docs/audits/FULL_UI_BACKEND_LINKAGE_MATRIX_1565.md` and
  `reports/generated/full_ui_backend_linkage_v171_41.json`.
- Boundary: PostgreSQL runtime proof is deferred to the next DB proof pass; no live
  payment or production Admin mutation is claimed.

## HEAL — PostgreSQL proof and CI dependency drift

- Cycle: `1566`; archive target: `v171.42`.
- Symptoms: the supplied CI run failed on 14 ruff findings and nineteen E2E
  imports because `requests` was absent; PostgreSQL runtime proof was still
  partial after the linkage cycle.
- Root causes: proof files were not normalized to current ruff rules, the E2E
  helper dependency was outside test locks, and one async test passed a sync
  PostgreSQL URL directly to `create_async_engine`.
- Treatment: repaired lint findings, added `requests` only to test/dev locks,
  normalized async PostgreSQL URLs and added a fail-closed migration,
  rollback, concurrency and backup/restore proof tool.
- Guard: `tests/architecture/test_postgres_release_proof_contract.py`.
- Evidence:
  `docs/audits/POSTGRESQL_ATOMICITY_CONCURRENCY_BACKUP_RESTORE_1566.md`.
- Forbidden action: never replace PostgreSQL transaction proof with SQLite,
  and never claim production DB proof from this local isolated environment.

## HEAL — observability, deployment and rollback readiness

- Cycle: `1568`; archive target: `v171.44`.
- Symptoms: supplied CI had mypy, stale Axios-guard and line-length failures;
  correlation headers were malformed and middleware was not installed;
  readiness route model inference could prevent system-route registration.
- Treatment: repaired CI causes, installed safe request correlation and bounded
  metrics, added fail-closed readiness, immutable deployment contracts and a
  plan-only rollback tool. Implemented all 20 approved visual improvements.
- Guards: `test_observability_deployment_rollback_readiness.py`,
  `test_visual_improvement_bundle.py` and
  `test_runtime_observability_readiness.py`.
- Boundary: local contracts do not prove a real staging/production rollout,
  live alerts or a cluster rollback.

## HEAL — PWA cache, WebView and CI snapshot drift

- Cycle: `1569`; archive target: `v171.45`.
- Symptoms: supplied CI contained 21 failures from stale OpenAPI, locale,
  visual-companion and source-marker guards; runtime caching covered only an
  offline file and did not materially reduce repeat traffic.
- Treatment: repaired every exact failure class, added privacy-safe PWA
  strategies for immutable assets and locale JSON, preserved network-only
  API/Admin/financial boundaries and added device, Telegram, offline,
  keyboard-focus and reduced-motion proof.
- Guard:
  `tests/architecture/test_pwa_webview_wcag_performance_current_release.py`.
- Boundary: controlled browser proof does not establish real Telegram
  clients, production HTTPS service-worker updates, full WCAG conformance or
  staging Web Vitals.


## HEAL — complete interaction matrix and adaptive cache

- Cycle: `1570`; archive target: `v171.46`.
- Symptoms: supplied CI had stale route/OpenAPI, locale and PWA guards plus
  proof formatting errors; startup and cache work had no separate numeric
  progress and cache capacity was static.
- Treatment: repaired all supplied-log failure classes, completed protected
  public/Admin visual matrices, added isolated interaction/recovery runners,
  split optional frontend payloads and installed adaptive privacy-safe cache
  tiers with visible progress and financial-update deferral.
- Guard: `tests/architecture/test_dynamic_cache_performance_matrix.py`.
- Evidence:
  `docs/audits/FULL_PUBLIC_ADMIN_INTERACTION_LOAD_RECOVERY_MATRIX_1570.md`.
- Boundary: controlled proof is not production Cache Storage, load/soak,
  live Telegram, real TonConnect or fresh GitHub CI evidence.

## v171.49 / work item 1572 planning synchronization

- State: `CONTROL_PLANE_SYNCED`; runtime code unchanged.
- Canonical workspace: `/mnt/data/efhc_workspace`.
- Factual stop point: application implementation `v171.47`; transfer repair
  `v171.48`; work item 1572 remains active.
- Guarded next route: fresh GitHub rerun intake -> live operator proof ->
  fail-closed RC audit.
- No defect was marked healed without new runtime or CI evidence.

## v171.75 — cumulative update compatibility and release CI hardening

- Failure: Ruff import order and START_HERE numbered work-pass guard failed in
  development CI; release CI route discovery stopped at FastAPI pathless nested
  containers.
- Root cause: shared release-CI source drift plus an assumption that every route
  object directly exposes `path`.
- Fix: canonical import ordering, unnumbered active startup status, recursive
  route-container traversal and a dedicated regression test.
- Update-system defect: previous implementation mixed persistent data with
  release-local paths and treated archive-number adjacency as compatibility.
- Fix: resolved `.env` validation, persistent backup/secret paths, stable systemd
  entrypoint, safe staging extraction, cumulative application/Alembic
  compatibility checks, verified pre-update backup, atomic activation,
  coordinated app rollback and explicit cleanup.
- Guard: `tests/architecture/test_release_v171_72_archive_update.py` and the
  standalone release CI contract. Never replace compatibility checks with
  strict adjacent archive numbering.

## v171.76 — FastAPI route-tree inventory compatibility

- Symptom: development CI failed only on three Ruff `I001` findings; release CI
  additionally reported every mandatory business route missing while the
  application imported successfully.
- Root cause: FastAPI 0.137+ no longer guarantees a flat `app.routes` list and
  stores included routers as `_IncludedRouter` nodes without a direct `path`.
  The release guard used a flat-route assumption.
- Treatment: canonicalize imports and centralize route inventory in
  `app.release.route_validation.collect_route_paths()`. New FastAPI versions use
  the supported `iter_route_contexts()` API; older versions retain a guarded
  recursive compatibility path.
- Guard: nested-prefix and hidden-route behavior in
  `ops/release/ci_profile/test_release_archive_contract.py`, plus exact mandatory
  route assertions in production validation.
- Forbidden action: do not use OpenAPI alone for route truth because the
  canonical Telegram webhook is intentionally hidden from schema output; do not
  weaken or remove the mandatory route set.
- Proof boundary: fresh exact-HEAD GitHub CI is required for the delivered
  FastAPI/Ruff dependency versions.

## v171.77 — P0 first-panel referral chain was disconnected

**What broke**

`referral_service.on_user_first_panel_activation()` existed, was exported and
passed an isolated PostgreSQL test, but no runtime code invoked it. A user's
first panel could therefore be paid for and created while the referral link
remained inactive and the inviter received no unit or level reward.

**Why the previous safeguards failed**

The test called the hook directly and therefore proved only its internal
calculation. It did not prove call-site wiring. GitHub CI already type-checked all of `backend/app` (295 source files), but
type checking cannot identify a missing business call. The release profile checked
archive/runtime shape, not this business flow.

**Treatment**

- `panels_service.activate_panel()` invokes the referral hook only when the
  pre-purchase active-panel count is zero.
- The hook executes after panel rows are created and before
  `bank._tx_context` exits.
- New `credit_user_bonus_from_bank_nocommit()` preserves the caller-owned
  transaction boundary.
- Reward failures are no longer swallowed; a failure rolls back debit, panel,
  activation flag and rewards together.
- Idempotency keys prevent duplicate rewards during replay.

**Permanent guards**

- source/AST wiring and transaction-location guard;
- PostgreSQL full-flow test from referral link through first panel and reward;
- idempotent replay test;
- forced referral failure rollback test;
- standalone release source-wiring acceptance.

## v171.78 — Referral ownership was not locked at the only creation boundary

**What broke**

The first-panel reward was repaired in v171.77, but player creation still had
implicit side roads. `/v1/me` and the money service could create a missing user,
which could permanently classify an invited player as a 0 user before the bot
processed the invite. Old public/Admin mutation seams and monetary referral
level rewards also contradicted the user's final rule.

**Treatment**

- One player-creation entrypoint:
  `onboard_user_at_first_creation(...)`.
- Valid invite: user and direct referral link are inserted atomically.
- No invite: permanent 0 user, no link and no referral reward.
- Existing user: immutable ownership; no late binding or reassignment.
- Invalid invite: no user row.
- Profile and money services fail closed for missing players.
- Only the reserved `BANK_EFHC` seed may create another `users` row.
- Historical v171.78 treatment (SUPERSEDED): it temporarily kept only one `0.1 EFHCb` direct-referral first-panel reward and treated referral levels as ranking-only.
- Active rule since v171.79/v171.82: every active direct referral pays `0.1 EFHCb`; Lvl 1–5 additionally pay automatic one-time rewards `1 / 10 / 100 / 300 / 1000 EFHCb`; the full 10,000-referral cycle is `1,000 + 1,411 = 2,411 EFHCb`.

**Permanent guards**

The architecture scan protects all production `users` insert sites. PostgreSQL
integration protects onboarding, 0 users, invalid codes, cycle impossibility,
atomic relation insertion, first-panel reward, replay and rollback. Standalone
release acceptance verifies the same rules in the packaged runtime.

### v171.78 follow-up — reward helper call-signature execution guard

- Risk class: PostgreSQL-only referral reward tests can be skipped in a local
  environment and therefore cannot be the sole protection against Python call
  signature drift.
- Treatment: keep the real PostgreSQL flow tests and add a dependency-light
  execution test around `_maybe_reward_active_unit_bonus(...)`.
- Guard: `tests/efhc_backend/referrals/test_referral_reward_call_signature.py`.
- Protected invariant: `_count_active_referrals` receives exactly one session,
  the inviter is credited exactly `0.1 EFHCb`, and the idempotency key is derived
  from the direct invitee.

## v171.79 — Unauthorized referral-level monetary reward deletion

- Symptom: v171.78 retained referral levels visually but removed automatic
  milestone payouts `1 / 10 / 100 / 300 / 1000 EFHC`.
- Root cause: the assistant conflated the per-referral first-panel reward with
  the separate canonical level milestone reward system.
- Runtime repair: `_sync_inviter_level_rewards(...)` is restored inside
  `on_user_first_panel_activation(...)` using the no-commit bank path and
  idempotency keys `REF_LVL:<inviter_tg>:<level>`.
- Protected invariant: first-creation attribution remains immutable; automatic
  level payouts are canonical; manual Admin payout/reassignment remains banned.
- Guards: static threshold contract, dependency-light five-level credit test,
  PostgreSQL integration test and standalone release acceptance.

## v171.80 — Referrals page contract and cumulative reward ambiguity

- Symptom: Active/Inactive were navigation buttons to separate pages instead of
  Panels-style inline tabs; current level was shown as an unlabeled number; the
  UI did not expose the full Lvl reward scale. A previous report described the
  tenth-referral event `0.1 + 1 = 1.1 EFHC` as if it were the cumulative Lvl 1
  total.
- Root cause: page-shape guards checked marker presence but not the complete
  product interaction, and event delta was confused with cumulative economics.
- Treatment: inline segmented lists, explicit `Lvl 0–5`, backend-owned level
  steps and cumulative totals. Lvl 1 is `10 × 0.1 + 1 = 2 EFHC`.
- Guards: architecture page contract, frontend progress/economy guard,
  cumulative reward unit/integration tests and standalone release acceptance.

# HEALER — shared Ruff import-order drift v171.83

Incident: both development and release CI passed every functional gate
but failed on the same two Ruff `I001` findings in shared runtime files.

Root cause: SQLAlchemy imports were positioned before app-service
imports while the repository Ruff/isort classification required the
opposite ordering.

Treatment:

- move `AsyncSession` after the Admin app-service import block;
- move `text` and `AsyncSession` after the referral app-service block;
- preserve all runtime statements and behavior;
- add `test_ci_v171_83_ruff_import_order.py`;
- retain Ruff as the authoritative CI delivery gate.

Evidence boundary: local targeted checks pass; fresh exact-HEAD GitHub CI
for both archives remains required.



# HEALER — referral TG-ID, API and PostgreSQL proof repair v171.84

Incident: two audit specifications exposed functional gaps not visible in the
green v171.83 CI runs.

Root causes:

- referral SQL mixed Telegram identity with internal `users.id`;
- Active/Inactive filters were composed outside the valid WHERE position;
- legacy CRUD referenced removed fields;
- compatibility routes lacked self-only authorization;
- Admin totals omitted Lvl rewards;
- idempotency was checked before locks but not re-read after locks;
- the CRUD health registry still required removed `ensure_user`;
- static guards did not provide complete PostgreSQL/API behavioral proof.

Treatment:

- TG-ID-only joins and counts;
- permanent Active semantics based on any panel plus `activated_at`;
- PostgreSQL cursor pagination and ETag mutation contract;
- self-only deprecated routes with 403/deprecation header;
- complete Admin reward sum;
- post-lock idempotency read-through;
- real integration CI modules and performance/EXPLAIN guard;
- release policy and documentation cleanup.

Proof boundary: supplied v171.83 logs are green, but fresh v171.84 CI, real
PostgreSQL execution, frontend build and Docker/deployment proof remain open.


# HEAL-0116 / CASE-0129 — stale CI evidence accepted by local release gate v171.85

- Cycle: 1588.
- Severity: P0 release-evidence integrity defect.
- Incident: `ops/release/local_pre_release_gate.py` selected fixed v171.67 CI
  intake and v171.69 repair evidence and could report a later development HEAD
  as `LOCAL_PRE_RELEASE_99_PERCENT_COMPLETE`.
- Root cause: hardcoded evidence paths, hardcoded source/output versions and no
  exact equality check between evidence `source_head` and current HEAD.
- Treatment:
  - derive the active version from `release_config/UPDATE_POLICY.json`;
  - discover available CI intake records without a fixed historical filename;
  - accept green evidence only when `source_head` exactly equals the current
    development archive;
  - list older evidence as rejected/ignored;
  - return `LOCAL_RELEASE_CANDIDATE` and fail closed when exact-HEAD evidence is
    absent.
- Guard: `tests/architecture/test_provider_independent_release_portability.py`.
- Prohibited workaround: copying, renaming or editing historical evidence so it
  appears to belong to the current HEAD.
- Proof boundary: local targeted tests validate the gate behavior; fresh
  development and release GitHub CI for v171.85 remains required.


# HEAL-0117 / CASE-0130 — duplicate activation and paper integration proof v171.86

- Cycle: 1589.
- Severity: P0 financial-proof integrity / concurrency-maintenance risk.
- Root cause: two owners of the same activation transition and tests that could
  pass without exercising the full production attribution path.
- Treatment: locked CRUD single owner, explicit `activated_now`, real onboarding
  E2E tests, ten-referral Lvl 1 runtime proof, and zero-skip JUnit enforcement.
- Prohibited workaround: restoring inline activation SQL, replacing runtime
  tests with AST/string assertions, or allowing CI skips to count as green.
- Proof boundary: locally validated; exact v171.86 GitHub CI required.

## HEAL-0118 — PostgreSQL bind and monetary lock repair v171.87

Fresh development CI exposed ambiguous asyncpg parameters, a stale panel
balance expectation and an invalid `SKIP LOCKED` monetary lock. Repair uses
explicit PostgreSQL casts and blocking same-user `FOR UPDATE`. Fresh exact
v171.87 GitHub CI remains required.

## HEAL-0119 — exact index-name plan assertion and route inventory drift

Fresh v171.87 development CI failed although PostgreSQL used a valid
index-backed plan. The test required one exact planner-selected index name.
The same audit found no single active inventory covering all 34
physical routes. `/app`, `/admin/system`, `/404` and `/500` were the
first explicit omissions; other routes existed only in scattered
historical sections.

Treatment:

- parse `EXPLAIN (FORMAT JSON)` plan nodes;
- accept the canonical set of indexes over `panels.tg_id`;
- keep `Limit`, referral-index and panel-index requirements;
- compare physical Next.js pages with the screen registry, source map and
  machine visual manifest;
- require real route-backed Chromium proof before visual readiness claims.

Proof boundary: static and documentation guards pass. Exact v171.88
Chromium proof is deferred because the configured npm registry returned
HTTP 503. Fresh exact-HEAD GitHub CI remains required.

## HEAL-0120 — permanent Activ flag consolidation

- Cycle/version: `1592 / v171.89`.
- Fault class: semantic SSOT split across runtime consumers.
- Diagnostic signature: search referral status readers for joins or
  `EXISTS` against `efhc_core.panels`; only display-only panel counting
  may remain.
- Canonical cure: `referral_links.activated_at IS NOT NULL`.
- Runtime proof: delete all panels after first activation and re-read
  counters, public list, Admin summary and Admin user detail.
- Защита от повторения: статический guard исходников, guard release
  и PostgreSQL CI с 25 тестами без пропусков.
