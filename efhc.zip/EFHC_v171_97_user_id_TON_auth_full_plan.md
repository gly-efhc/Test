<!-- EFHC_IDENTITY_HISTORICAL_NOTICE_V2 -->
> Статус identity-содержимого: **HISTORICAL / SUPERSEDED**. Старые формулировки
> `tg_id`/`user_id` описывают состояние соответствующего периода и
> сохранены без переписывания истории. Они не являются действующим
> owner-контрактом и не могут переопределять текущий канон:
> `docs/SSOT/GLOBAL_IDENTITY_AUTH_SSOT.md`. Сейчас `global_id` —
> единственный внутренний owner, а `tg_id` — только Telegram provider
> subject до identity resolution.

<!-- EFHC_GLOBAL_IDENTITY_CANON_V1 -->
> **HISTORICAL / SUPERSEDED.** Этот план или аудит сохранён для истории.
> Действующий закон: `global_id` — главный персональный идентификатор и owner;
> `tg_id` — только Telegram provider subject. Старые стадии `user_id` не являются
> текущим контрактом.

# План UserId и TON-аутентификации — v171.97

## Закрытый фундамент 1593–1600

Диапазон локально сформировал аудит, типы `UserId` и `TelegramId`,
строковый API-контракт, nullable EXPAND `users.user_id`, LEGACY alias,
backfill harness и read-only PostgreSQL reconciliation gate.

## Текущая истина базы

```text
Alembic chain: 0001 -> 0002
Alembic head: 0002
users.id: legacy INTEGER primary key
users.user_id: nullable BIGINT, unique, bounded, sequence-backed
users.tg_id: legacy BIGINT NOT NULL
historical backfill: запрещён
runtime read switch: запрещён
```

## TON-вход

1. Существующая подтверждённая TON identity открывает прежний
   `user_id`.
2. Уникальная активная proof-verified wallet binding связывается с тем
   же существующим `user_id`.
3. Новый подтверждённый кошелёк атомарно создаёт нового пользователя,
   новый `user_id`, TON identity и wallet binding.
4. Подключение кошелька без TON Proof не является входом.
5. Автоматическое объединение существующих аккаунтов запрещено.

## Незакрытые gates

- реальная PostgreSQL reconciliation;
- auth core: identities, challenges, sessions и roles;
- независимый TON Proof login;
- Telegram adapter через IdentityResolver;
- последующие backfill, dual-write и read switch;
- exact-HEAD GitHub CI после готовности основного пакета.

## Следующий цикл

`1601 — открытие диапазона и приёмка фундамента`.
Current HEAD: `EFHC_Bot_v171_97.zip`.
Следующая изменённая версия: `v171.98`.
