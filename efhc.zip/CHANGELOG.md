# EFHC Bot — v147_06 → v147_07
## Exchange: D8 compare (no float cast)

## v149_79
- watcher: автозачисление без MEMO по привязанному кошельку
  + запись в unmatched_incoming (требует проверки CI).

## v150_01
- watcher: если MEMO пустой и кошелёк не привязан к tg_id,
  транзакция игнорируется.

## v150_04
- docs: TERMS_GLOSSARY добавлены каноничные определения:
  EFHC main, EFHC bonus, EFHC jetton (все d8).

- Убран Number() для available_kwh в Exchange.
- Сравнение сделано через cmp8() (BigInt-scale, DOWN).

# EFHC Bot — v144 → v145
## Документация: аудит + reflow под 72

- Актуализированы документы после унификации admin-модулей.
- Переформатированы тексты документации: перенос строк до 72.
- Удалён артефакт .pytest_cache из архива релиза.
- RAW-логи помечены как вывод команд; строки могут быть длиннее.

# EFHC Bot — v138 → v139
## Telegram-native UX + каркас состояний + guard-тесты


## Что изменено

### Telegram-native UX (frontend)
- Confirm/alert теперь через Telegram WebApp popup/confirm (fallback →
browser), без изменения канона настроек.
- Добавлены Telegram BackButton-интеграции для overlay-модалок (Profile
и выбор skins на главной).
- Добавлена интеграция Telegram MainButton на вкладке Exchange: кнопка
появляется только когда форма валидна.
- Добавлены haptics notification (success/error) через Telegram WebApp.

### UI “99%” каркас: loading/empty/error
- Добавлен ErrorBoundary на уровне приложения (защита от белого экрана).
- Добавлен EmptyState компонент и подключён на
Tasks/Referrals/Panels/Ranks.
- Убраны остаточные светлые блоки (`bg-white/...`) в карточках списков
(приведено к чёрному/золото/оранж).

### Skins каталог “без кода”
- Каталог скрывает битые/пустые (0 bytes) файлы, чтобы не появлялись
мёртвые позиции.

### Backend security hardening
- Исправлен баг: `_get_secret_key()` теперь корректно читает
`SECRET_KEY` через `get_settings()`.

## Тесты/гварды
- Добавлен тест на канон вкладок WebApp (ровно 6, фиксированный
порядок).
- Добавлен тест на MonetaryIdempotencyMiddleware: денежные POST без
`Idempotency-Key` → 400.

## Проверки
- `python -m compileall backend -q` ✅
- `pytest -q` ✅ PASS


# EFHC Bot — v137 → v138
## Telegram UI sync + skeletons + tg_id-only cleanup


## Что изменено

### Telegram WebApp UI синхронизация (frontend)
- Добавлены CSS vars для viewport/safe-area и мягкая синхронизация
цветов контейнера Telegram.
- Исправлена разметка Layout: учитываются safe-area inset сверху/снизу
(без изменения канона вкладок).

### UI каркас доведён до 100% на пользовательских вкладках
- Убраны светлые (bg-white) блоки на Panels/Referrals/Ranks/Shop —
единый чёрный/золото/оранж.
- Добавлены Skeleton-плейсхолдеры на загрузку списков/превью.
- Подключены toasts для ключевых действий (покупка панели,
exchange/withdraw, skins).

### Канон Panels
- Покупка панели строго **1 шт.** и только в разделе Panels (убран
prompt/qty).

### Канон идентификатора
- Удалены/исправлены остаточные упоминания алиасов в документах/SSOT;
репозиторий чист по запрещённым алиасам.

## Тесты/гварды
- NEW: `tests/architecture/test_no_tg_id_aliases_repo.py` — repo-scan на
запрет алиасов идентификатора (tg_id-only).

## Проверки
- `python -m compileall backend -q` ✅
- `pytest -q` ✅

# EFHC Bot — v137 (skins auto-catalog + canon guards)

## Что сделано

### Backend
- Skins: каталог стал полностью «без кода» — строится автоматически по
файлам `frontend/public/skins/<id>.png` (подхватывает новые файлы без
ручного добавления констант/списков).
- Skins service: исправлены синтаксические/логические дефекты
(корректный get_my(), _ensure_owned(), activate_skin()).
- Canon guard: расширен запрет прямых изменений балансов — теперь
запрещены прямые записи и в `main_balance`, и в `bonus_balance` вне
`transactions_service.py`.

### Frontend
- Главная (Energy): skin-блок стал кликабельным:
  - если активный скин не куплен — переход в `Shop` к секции `Skins`;
  - если куплен — открывается выбор купленных с активацией.
- Добавлены лёгкие in-app toasts (с учётом настройки в профиле).
- Shop: поддержан автоскролл в `Skins` по `?section=skins`.

### Tests
- Добавлен repo-scan тест на запрет legacy-подстрок для модуля Ranks
(запрещённые варианты ловятся как подстроки в любом файле).
- Добавлен «API-layer» guard на финансовый канон:
  - Exchange отдаёт только MAIN баланс;
  - Withdraw не трогает bonus_balance;
  - Покупка за EFHC в Shop тратит bonus→main в правильном порядке;
  - Frontend Exchange не обращается к `bonus_balance`.

## Проверка
- python -m compileall backend -q ✅
- pytest -q ✅ PASS


# EFHC Bot — v122 (frontend tg_id-only + sync POST canon)

## Что сделано
- Frontend: полная санация идентификатора пользователя на **tg_id**:
  - убраны `tg_id/tg_id` из переменных/props/типов/комментариев;
  - `useSnapshot()` теперь вызывает каноничный `POST
/sync/user/{tg_id}?fresh=1`;
  - пользовательские/админские страницы приводят query/body ключи к
`tg_id`, `parent_tg_id`, `child_tg_id`.
- Документы/SSOT не менялись по смыслу: правило tg_id-only сохраняется,
алиасы остаются запрещёнными.

## Проверка
- python -m compileall backend -q ✅
- pytest -q ✅ PASS


# EFHC Bot — v121 (канон tg_id в админ-фильтрах)

## Что сделано
- Frontend admin pages: приведены к канону **tg_id** (без tg_id) в
фильтрах и заголовках колонок:
  - `frontend/src/pages/admin/panels.tsx`
  - `frontend/src/pages/admin/logs.tsx`
- Логика/эндпоинты не менялись: в запросах по‑прежнему используется
каноничный параметр `tg_id`.

## Проверка
- Изменения только во frontend, без влияния на backend/pytest.


# EFHC Bot — v120 (merge v118 + v119)

## Что сделано
- Слияние двух веток:
  - База: v118 (восстановленные admin routes, tg_id-only).
  - Перенесены улучшения рейтинга из v119 (wiring/tests/ETag) без
введения алиасов.
- Исправлено: admin headers alias (X-Admin-Id / X-Admin-Token) без
пробелов.
- Исправлено: frontend ranks.tsx принимает tg_id (как во всём
приложении), но в API использует каноничный параметр tg_id и поле tg_id
в ответах.
- Гигиена репозитория: добавлено игнорирование /.local_artifacts/ и
удалены локальные артефакты/кеши из релизного архива.

## Проверка
- python -m compileall backend -q ✅
- pytest -q ✅ PASS


EFHC Bot — v27 → v28 (Build sanity tests + no stubs)

## Что добавлено/исправлено

### Tests: сборка и отсутствие заглушек
- Добавлены build-sanity тесты:
  - canon_guard должен проходить
  - backend должен импортироваться
  - compileall backend/ops должен проходить
- Добавлен тест на отсутствие маркеров незавершённости в shipping-коде
(backend/app и frontend/src):
  - запрещены TODO/FIXME/TBD/NotImplementedError/STUB и схожие маркеры
(UI placeholder= допускается)

### Bot state backend: убраны runtime-заглушки
- В `backend/app/bot/states.py` контракт backend-хранилища состояний
переведён на Protocol (`StateBackend`), без `NotImplementedError`.
- Ключ состояния трактуется как (tg_id, chat_id).

### Ads integration: убраны stub-маркеры и user_id
- Генерация fallback `tx_id` больше не содержит маркер `stub-`.
- Входной идентификатор пользователя в Ads контуре — только tg_user_id →
tg_id (без user_id).

---

# EFHC Bot — v26 → v27 (Admin Users/Panels/Logs)

## Что добавлено/исправлено

### Admin: Users (tg_id only)
- Добавлены полноценные backend endpoints `/admin/users/*`:
  - `GET /admin/users/search` — поиск по tg_id/username/ton_wallet.
  - `GET /admin/users/{tg_id}` — карточка пользователя.
  - `PATCH /admin/users/{tg_id}/vip` — VIP toggle (требует
Idempotency-Key).
  - `PATCH /admin/users/{tg_id}/active` — activation/deactivation
(Idempotency-Key).
  - `POST /admin/users/{tg_id}/wallet/reset` — сброс TON-кошелька
(Idempotency-Key).
- Реализована UI-страница Admin → Users (поиск, карточка, действия).

### Admin: Panels (activate/deactivate)
- Добавлены backend endpoints `/admin/panels`:
  - `GET /admin/panels` — список/фильтр по tg_id и активности.
  - `PATCH /admin/panels/{id}/activate` и `/deactivate` — управление
активностью (Idempotency-Key).
- Реализована UI-страница Admin → Panels.

### Admin: Logs (audit-first)
- Добавлен backend endpoint `/admin/logs/transfers` (журнал EFHC bank
transfers) с cursor pagination через `cursor_codec`.
- Реализована UI-страница Admin → Logs.

### Канон/инварианты
- В админке (backend+frontend) внешняя идентичность пользователя —
**только tg_id**.
- Мутации в админ-эндпоинтах защищены **Idempotency-Key**.
- Canon Guard / import / compileall / pytest проходят.


# EFHC Bot — v28 → v29 (Strict PEP8 Compiler tests)

- TEST: Add `tests/test_strict_pep8_compiler.py` enforcing hardcore
style rules (indentation, tabs, naming, imports, whitespace, line
length, blank lines, EOF newline).

# EFHC Bot — v31 → v32 (Session 1: R0 repo normalization)

- STYLE (R0): Replace any tab indentation with 4 spaces (no \t).
- STYLE (R0): Remove trailing whitespace.
- STYLE (R0): Enforce exactly one blank line at EOF for Python files
(file ends with \n\n).
- STYLE (R0): Split multi-import lines (e.g., `import os, sys`) into
one-import-per-line.
- TOOLING: Run `ops/strict_style_fix.py` over backend/ops/tests; store
log in `STRICT_FIX_R0_LOG.txt`.

## v123
- Filled empty `__init__.py` package markers (no side effects;
docstrings + empty `__all__`).
- No functional changes.


## v125
- Public module name unified as **Ranks**.
- WebApp route: `/ranks` (was `/ranks`).
- Backend HTTP router renamed: `ranks_routes.py` → `ranks_routes.py`,
prefix `/ranks`.
- Frontend page renamed: `ranks.tsx` → `ranks.tsx`; component
`RanksTable` → `RanksTable`.
- Locale display for ranks set to `Ranks`.
- Tests: `python -m compileall backend -q` OK; `pytest -q` PASS.

## v140

- Added repo integrity guard test to prevent accidental deletion of
canonical build files (baseline 526 files, new files allowed).
- Added baseline file manifest:
`tests/fixtures/repo_file_manifest_v139.json`.

### Checks
- `python -m compileall backend -q`
- `pytest -q`

## v141

### Backend
- Migration: added indexes for cold queries on `withdraw_requests`:
`(tg_id, status)` and `(status)`.
- Added `@idempotent_action(ttl_sec=...)` marker for точечной
идемпотентности (TTL) как UX-замок от двойных кликов.

### Tests / Tooling
- Extended max 72 chars/line architecture test to cover the whole bot
(repo), excluding builds/artifacts and migrations.
- Added test for TTL idempotency behavior (409 on duplicate click).
- Added optional local git hooks:
`.githooks/pre-commit` + `ops/install_githooks.sh` +
`ops/precommit_canon_check.py`.

### Checks
- `python -m compileall backend -q`
- `pytest -q`

## v142

### Frontend Evolution
- Added TanStack Query base wiring:
  - `frontend/src/lib/queryClient.ts`
  - QueryClientProvider in `frontend/src/pages/_app.tsx`
- Started EFHC Design System atoms (UI canon):
  - `frontend/src/components/ui/EfhcButton.tsx`
  - `frontend/src/components/ui/EfhcCard.tsx`
  - `frontend/src/components/ui/EfhcStatus.tsx`
- Migrated `Exchange` preview to React Query:
  - instant first paint from snapshot (if present)
  - background refresh (focus/reconnect)
  - convert mutation invalidates preview query

### Checks
- `python -m compileall backend -q`
- `pytest -q`

## v143

### Load / DB Safety
- Added real k6 scenario for 1000+ RPS purchases:
`tests/load/k6-scenarios/skins_buy.js`.
- Added load test instructions + PostgreSQL deadlock checks:
`tests/load/README.md`.

### Frontend Caching (React Query completion for hot screens)
- Snapshot is now cached via React Query (no refresh on each tab enter):
`frontend/src/hooks/useSnapshot.ts`, `frontend/src/pages/_app.tsx`.
- QueryClient defaults tuned to reduce API chatter:
`frontend/src/lib/queryClient.ts`.
- Migrated hot pages to React Query:
  - `frontend/src/pages/tasks.tsx`
  - `frontend/src/pages/referrals.tsx` (infinite query)
  - `frontend/src/pages/shop.tsx`
- API client dev fallback aligned to канон tg_id:
`frontend/src/lib/api.ts` now uses `X-Telegram-User-Id` only if
`initData` is absent.

### Backend Bugfix
- Fixed `get_current_tg_id` recursion bug and header name consistency:
`backend/app/deps.py`.

### Checks
- `python -m compileall backend -q`
- `pytest -q`

## v144
- Unify admin modules: move CRUD/schemas into admin/ subpackages; remove
root duplicates and plural schema wrappers.
- Remove unused legacy ranks CRUD file.
- Update repo integrity manifest baseline accordingly.

## v150_07
- SSOT pack: routes/tables/schemas updated;
  unmatched_incoming описана; тест Postgres-only.

## v150_14
- Updated errors registry for logs_59108438734.
- Added change_report_v150_14.
